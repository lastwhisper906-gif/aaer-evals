# STX MD&A — 0001137789-26-000088


## mdna

[0001137789-26-000088:mdna:1]
[same as prior period, unchanged from 0001137789-26-000026:mdna:1]

[0001137789-26-000088:mdna:2]
The following is a discussion of the Company’s financial condition, changes in financial condition and results of operations for the fiscal quarters ended April 3, 2026, January 2, 2026 and March 28, 2025, referred to herein as the “March 2026 quarter”, the “December 2025 quarter” and the “March 2025 quarter”, respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The March 2026 quarter, December 2025 quarter and March 2025 quarter were each 13 weeks.

[0001137789-26-000088:mdna:3]
[same as prior period, unchanged from 0001137789-26-000026:mdna:3]

[0001137789-26-000088:mdna:4]
[same as prior period, unchanged from 0001137789-26-000026:mdna:4]

[0001137789-26-000088:mdna:5]
•Overview of the March 2026 quarter. Highlights of events in the March 2026 quarter that impacted our financial position.

[0001137789-26-000088:mdna:6]
•Results of Operations. Analysis of our financial results comparing the March 2026 quarter to the December 2025 quarter and the March 2025 quarter.

[0001137789-26-000088:mdna:7]
[same as prior period, unchanged from 0001137789-26-000026:mdna:7]

[0001137789-26-000088:mdna:8]
[same as prior period, unchanged from 0001137789-26-000026:mdna:8]

[0001137789-26-000088:mdna:9]
[same as prior period, unchanged from 0001137789-26-000026:mdna:9]

[0001137789-26-000088:mdna:10]
[same as prior period, unchanged from 0001137789-26-000026:mdna:10]

[0001137789-26-000088:mdna:11]
Overview of the March 2026 quarter

[0001137789-26-000088:mdna:12]
During the March 2026 quarter, we shipped 199 exabytes of HDD storage capacity. We generated revenue of approximately $3.1 billion with a gross margin of 46.5% and net income of $748 million. Our operating cash flow was $1.1 billion, we retired $641 million principal amount of long-term debt, paid $161 million for the purchase of property, equipment and leasehold improvements and paid $161 million in dividends.

[0001137789-26-000088:mdna:13]
[same as prior period, unchanged from 0001137789-26-000026:mdna:13]

[0001137789-26-000088:mdna:14]
[same as prior period, unchanged from 0001137789-26-000026:mdna:14]

[0001137789-26-000088:mdna:15]
[same as prior period, unchanged from 0001137789-26-000026:mdna:15]

[0001137789-26-000088:mdna:16]
In the March 2026 quarter, we continued to operate in a strong demand environment, particularly within the data center end markets. We experienced sustained demand growth for our high capacity nearline drives across global cloud customers, as well as increasing sales for enterprise edge deployments. Customers continue to invest in data center infrastructure to support ongoing demand from traditional workloads along with growing AI related demand. This trend reflects the ongoing adoption of AI applications which drives increased data content generation and storage needs for inferencing, training and maintaining AI model integrity. At the same time, the macroeconomic environment remains dynamic, marked by heightened geopolitical uncertainty and evolving trade policies. These factors may impact our business and results of operations. We will continue to monitor the situation and assess plans to mitigate future risk to the business. Over the long-term we expect our hard drive storage business to benefit from growing demand for data and its increased value, particularly as AI applications continue to proliferate.

[0001137789-26-000088:mdna:17]
[same as prior period, unchanged from 0001137789-26-000026:mdna:17]

[0001137789-26-000088:mdna:18]
[same as prior period, unchanged from 0001137789-26-000026:mdna:18]

[0001137789-26-000088:mdna:19]
[same as prior period, unchanged from 0001137789-26-000026:mdna:19]

[0001137789-26-000088:mdna:20]
|  |  | For the Three Months Ended | For the Nine Months Ended |
| (Dollars in millions) |  | April 3, 2026 |  | January 2, 2026 |  | March 28, 2025 |  | April 3, 2026 |  | March 28, 2025 |
| Revenue |  | $ | 3,112 |  |  | $ | 2,825 |  |  | $ | 2,160 |  |  | $ | 8,566 |  |  | $ | 6,653 |  |
| Cost of revenue |  | 1,665 |  |  | 1,649 |  |  | 1,400 |  |  | 4,906 |  |  | 4,367 |  |
| Gross profit |  | 1,447 |  |  | 1,176 |  |  | 760 |  |  | 3,660 |  |  | 2,286 |  |
| Product development |  | 194 |  |  | 187 |  |  | 180 |  |  | 567 |  |  | 545 |  |
| Marketing and administrative |  | 143 |  |  | 143 |  |  | 139 |  |  | 430 |  |  | 407 |  |
| Legal settlement |  | 105 |  |  | — |  |  | — |  |  | 105 |  |  | — |  |
| Restructuring and other, net |  | 7 |  |  | 3 |  |  | 10 |  |  | 23 |  |  | 12 |  |
| Income from operations |  | 998 |  |  | 843 |  |  | 431 |  |  | 2,535 |  |  | 1,322 |  |
| Other expense, net |  | (134) |  |  | (136) |  |  | (76) |  |  | (350) |  |  | (301) |  |
| Income before income taxes |  | 864 |  |  | 707 |  |  | 355 |  |  | 2,185 |  |  | 1,021 |  |
| Provision for income taxes |  | 116 |  |  | 114 |  |  | 15 |  |  | 295 |  |  | 40 |  |
| Net income |  | $ | 748 |  |  | $ | 593 |  |  | $ | 340 |  |  | $ | 1,890 |  |  | $ | 981 |  |

[0001137789-26-000088:mdna:21]
[same as prior period, unchanged from 0001137789-26-000026:mdna:21]

[0001137789-26-000088:mdna:22]
|  |  | For the Three Months Ended | For the Nine Months Ended |
| (As a percentage of Revenue) |  | April 3, 2026 |  | January 2, 2026 |  | March 28, 2025 |  | April 3, 2026 |  | March 28, 2025 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 54 |  |  | 58 |  |  | 65 |  |  | 57 |  |  | 66 |  |
| Gross margin |  | 46 |  |  | 42 |  |  | 35 |  |  | 43 |  |  | 34 |  |
| Product development |  | 6 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 8 |  |
| Marketing and administrative |  | 5 |  |  | 5 |  |  | 6 |  |  | 5 |  |  | 6 |  |
| Legal settlement |  | 3 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |
| Restructuring and other, net |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating margin |  | 32 |  |  | 30 |  |  | 21 |  |  | 30 |  |  | 20 |  |
| Other expense, net |  | (4) |  |  | (5) |  |  | (4) |  |  | (4) |  |  | (4) |  |
| Income before income taxes |  | 28 |  |  | 25 |  |  | 17 |  |  | 26 |  |  | 16 |  |
| Provision for income taxes |  | 4 |  |  | 4 |  |  | 1 |  |  | 3 |  |  | 1 |  |
| Net income |  | 24 | % |  | 21 | % |  | 16 | % |  | 23 | % |  | 15 | % |

[0001137789-26-000088:mdna:23]
[same as prior period, unchanged from 0001137789-26-000026:mdna:23]

[0001137789-26-000088:mdna:24]
[same as prior period, unchanged from 0001137789-26-000026:mdna:24]

[0001137789-26-000088:mdna:25]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
|  |  | April 3, 2026 |  | January 2, 2026 |  | March 28, 2025 |  | April 3, 2026 |  | March 28, 2025 |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 79 | % |  | 81 | % |  | 79 | % |  | 81 | % |  | 80 | % |
| Distributors |  | 15 | % |  | 12 | % |  | 12 | % |  | 13 | % |  | 12 | % |
| Retailers |  | 6 | % |  | 7 | % |  | 9 | % |  | 6 | % |  | 8 | % |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |  |  |  |
| Americas |  | 52 | % |  | 44 | % |  | 51 | % |  | 50 | % |  | 49 | % |
| Asia Pacific |  | 38 | % |  | 46 | % |  | 39 | % |  | 41 | % |  | 41 | % |
| EMEA |  | 10 | % |  | 10 | % |  | 10 | % |  | 9 | % |  | 10 | % |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Data Center |  | 80 | % |  | 79 | % |  | 75 | % |  | 80 | % |  | 74 | % |
| Edge IoT |  | 20 | % |  | 21 | % |  | 25 | % |  | 20 | % |  | 26 | % |
| HDD Exabytes Shipped |  |  |  |  |  |  |  |  |  |  |
| Nearline |  | 175.4 |  |  | 165.0 |  |  | 119.6 |  |  | 499.7 |  |  | 359.9 |  |
| Non-nearline |  | 24.0 |  |  | 25.0 |  |  | 24.0 |  |  | 71.2 |  |  | 72.0 |  |
| Total |  | 199.4 |  |  | 190.0 |  |  | 143.6 |  |  | 570.9 |  |  | 431.9 |  |

[0001137789-26-000088:mdna:26]
[same as prior period, unchanged from 0001137789-26-000026:mdna:26]

[0001137789-26-000088:mdna:27]
[same as prior period, unchanged from 0001137789-26-000026:mdna:27]

[0001137789-26-000088:mdna:28]
Revenue in the March 2026 quarter increased by $287 million compared to the December 2025 quarter, primarily due to favorable pricing actions undertaken by the Company and an increase in exabytes shipped reflecting higher demand for nearline products.

[0001137789-26-000088:mdna:29]
Revenue for the three and nine months ended April 3, 2026, increased by $952 million and $1.9 billion from the three and nine months ended March 28, 2025, respectively, primarily due to an increase in nearline exabytes shipped reflecting higher demand for nearline products and favorable pricing actions undertaken by the Company.

[0001137789-26-000088:mdna:30]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 10% of gross revenue for the March 2026 quarter, 11% for the December 2025 quarter and 14% for the March 2025 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-26-000088:mdna:31]
[same as prior period, unchanged from 0001137789-26-000026:mdna:32]

[0001137789-26-000088:mdna:32]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |  |  |
| (Dollars in millions) |  | April 3, 2026 |  | January 2, 2026 |  | March 28, 2025 |  | April 3, 2026 |  | March 28, 2025 |  |  |  |
| Cost of revenue |  | $ | 1,665 |  |  | $ | 1,649 |  |  | $ | 1,400 |  |  | $ | 4,906 |  |  | $ | 4,367 |  |  |  |  |
| Gross profit |  | 1,447 |  |  | 1,176 |  |  | 760 |  |  | 3,660 |  |  | 2,286 |  |  |  |  |
| Gross margin |  | 47 | % |  | 42 | % |  | 35 | % |  | 43 | % |  | 34 | % |  |  |  |

[0001137789-26-000088:mdna:33]
Gross margin for the March 2026 quarter increased by 5 percentage points compared to the December 2025 quarter primarily driven by pricing actions undertaken by the Company.

[0001137789-26-000088:mdna:34]
Gross margin for the three and nine months ended April 3, 2026 increased by 12 percentage points and 9 percentage points from the three and nine months ended March 28, 2025, respectively, primarily driven by pricing actions undertaken by the Company, favorable volume and product mix, and $10 million of restructuring costs related to an inventory write down that did not recur.

[0001137789-26-000088:mdna:35]
Warranty cost related to new shipments was 1.0%, 0.9% and 0.7% of revenue for the March 2026 quarter, December 2025 quarter and March 2025 quarter, respectively.

[0001137789-26-000088:mdna:36]
[same as prior period, unchanged from 0001137789-26-000026:mdna:38]

[0001137789-26-000088:mdna:37]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |  |  |  |
| (Dollars in millions) |  | April 3, 2026 |  | January 2, 2026 |  | March 28, 2025 |  | April 3, 2026 |  | March 28, 2025 |  |  |  |  |
| Product development |  | $ | 194 |  |  | $ | 187 |  |  | $ | 180 |  |  | $ | 567 |  |  | $ | 545 |  |  |  |  |  |
| Marketing and administrative |  | 143 |  |  | 143 |  | 139 |  |  | 430 |  |  | 407 |  |  |  |  |  |
| Legal settlement |  | 105 |  |  | — |  |  | — |  |  | 105 |  |  | — |  |  |  |  |  |
| Restructuring and other, net |  | 7 |  |  | 3 |  |  | 10 |  |  | 23 |  |  | 12 |  |  |  |  |  |
| Operating expenses |  | $ | 449 |  |  | $ | 333 |  |  | $ | 329 |  |  | $ | 1,125 |  |  | $ | 964 |  |  |  |  |  |

[0001137789-26-000088:mdna:38]
Product development expense. Product development expenses increased by $7 million in the March 2026 quarter compared to the December 2025 quarter, primarily due to a $3 million increase in material expenses and a $2 million increase in compensation and other employee benefits.

[0001137789-26-000088:mdna:39]
Product development expenses increased by $14 million in the March 2026 quarter compared to the March 2025 quarter, primarily due to an $8 million increase in outside services costs and a $3 million increase in facilities costs.

[0001137789-26-000088:mdna:40]
Product development expenses increased by $22 million in the nine months ended April 3, 2026 compared to the nine months ended March 28, 2025, primarily due to a $17 million increase in outside services costs and a $7 million increase in facilities costs, partially offset by a $3 million decrease in material expenses.

[0001137789-26-000088:mdna:41]
Marketing and administrative expense. Marketing and administrative expenses remained relatively flat in the March 2026 quarter compared to the December 2025 quarter and the March 2025 quarter, respectively.

[0001137789-26-000088:mdna:42]
Marketing and administrative expenses increased by $23 million in the nine months ended April 3, 2026 compared to the nine months ended March 28, 2025, primarily due to a $12 million increase in compensation and other employee benefits, a $4 million increase in information technology expenses and a $3 million increase in facilities costs.

[0001137789-26-000088:mdna:43]
Legal settlement. We recorded a charge of $105 million in the March 2026 quarter related to a litigation matter. Refer to “Item 1. Financial Statements—Note 11. Legal, Environmental and Other Contingencies” for more details.

[0001137789-26-000088:mdna:44]
Restructuring and other, net. We recorded $7 million of restructuring charges in the March 2026 quarter, primarily related to employee related termination benefits.

[0001137789-26-000088:mdna:45]
28

[0001137789-26-000088:mdna:46]
[same as prior period, unchanged from 0001137789-26-000026:mdna:45]

[0001137789-26-000088:mdna:47]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 3, 2026 |  | January 2, 2026 |  | March 28, 2025 |  | April 3, 2026 |  | March 28, 2025 |
| Other expense, net |  | $ | (134) |  |  | $ | (136) |  |  | $ | (76) |  |  | $ | (350) |  |  | $ | (301) |  |

[0001137789-26-000088:mdna:48]
Other expense, net. Other expense, net for the March 2026 quarter primarily related to $69 million net loss from debt transactions and $68 million of interest expense partially offset by $6 million of interest income.

[0001137789-26-000088:mdna:49]
Other expense, net for the December 2025 quarter primarily related to $72 million of interest expense and $66 million net loss from debt transactions, partially offset by $7 million of interest income.

[0001137789-26-000088:mdna:50]
Other expense, net for the March 2025 quarter primarily related to $77 million of interest expense and $4 million net loss from debt transactions, partially offset by $4 million of interest income.

[0001137789-26-000088:mdna:51]
Other expense, net for the nine months ended April 3, 2026 primarily related to $220 million of interest expense and $141 million net loss from debt transactions, partially offset by $20 million of interest income.

[0001137789-26-000088:mdna:52]
Other expense, net for the nine months ended March 28, 2025 primarily related to $246 million of interest expense, $53 million net loss from certain investments and $4 million net loss from debt transactions, partially offset by $19 million of interest income.

[0001137789-26-000088:mdna:53]
[same as prior period, unchanged from 0001137789-26-000026:mdna:52]

[0001137789-26-000088:mdna:54]
For the March 2026 quarter, December 2025 quarter and March 2025 quarter, we recorded income tax expense of $116 million, $114 million and $15 million, respectively. For the nine months ended April 3, 2026 and March 28, 2025, we recorded income tax expense of $295 million and $40 million, respectively. For further discussion, refer to “Part I, Item 1. Financial Statements—Note 4. Income Taxes”.

[0001137789-26-000088:mdna:55]
[same as prior period, unchanged from 0001137789-26-000026:mdna:54]

[0001137789-26-000088:mdna:56]
[same as prior period, unchanged from 0001137789-26-000026:mdna:55]

[0001137789-26-000088:mdna:57]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of April 3, 2026. For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, see “Part II, Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q.

[0001137789-26-000088:mdna:58]
[same as prior period, unchanged from 0001137789-26-000026:mdna:57]

[0001137789-26-000088:mdna:59]
|  |  | As of |  |  |
| (Dollars in millions) |  | April 3, 2026 |  | June 27, 2025 |  | Change |
| Cash and cash equivalents |  | $ | 1,146 |  |  | $ | 891 |  |  | $ | 255 |  |

[0001137789-26-000088:mdna:60]
Our cash and cash equivalents as of April 3, 2026 increased by $255 million from June 27, 2025 primarily as a result of net cash of $2.4 billion provided by operating activities, partially offset by $1.1 billion cash paid for the partial retirement of 2028 Notes and repurchase of long-term debt, $468 million dividends paid to our shareholders, $382 million payments for capital expenditures and $111 million taxes paid related to net share settlement of equity awards.

[0001137789-26-000088:mdna:61]
[same as prior period, unchanged from 0001137789-26-000026:mdna:60]

[0001137789-26-000088:mdna:62]
Cash provided by operating activities for the nine months ended April 3, 2026 was $2.4 billion and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, and the following major working capital related movements:

[0001137789-26-000088:mdna:63]
•an increase of $346 million in accrued expenses, income taxes and warranty, primarily due to an increase in accrued legal settlements and income taxes; and

[0001137789-26-000088:mdna:64]
•an increase of $89 million in accounts payable, primarily due to an increase in direct materials purchased; partially offset by

[0001137789-26-000088:mdna:65]
•an increase of $238 million in accounts receivable, primarily due to increased revenue;

[0001137789-26-000088:mdna:66]
•an increase of $90 million in inventories, primarily related to an increase in work-in-process inventory, partially offset by a decrease in raw materials and components; and

[0001137789-26-000088:mdna:67]
•a decrease of $62 million in accrued employee compensation, primarily due to variable compensation payments.

[0001137789-26-000088:mdna:68]
[same as prior period, unchanged from 0001137789-26-000026:mdna:68]

[0001137789-26-000088:mdna:69]
Net cash used in investing activities for the nine months ended April 3, 2026 was $369 million, primarily attributable to payments of $382 million for the purchase of property, equipment and leasehold improvements, partially offset by proceeds of $15 million from our business divestiture from the sale of System-on-Chip Operations during fiscal year 2024.

[0001137789-26-000088:mdna:70]
[same as prior period, unchanged from 0001137789-26-000026:mdna:70]

[0001137789-26-000088:mdna:71]
Net cash used in financing activities of $1.7 billion for the nine months ended April 3, 2026 was primarily attributable to the following activities:

[0001137789-26-000088:mdna:72]
•$1.1 billion cash paid for the partial retirement of 2028 Notes and the partial repurchase of long-term debt;

[0001137789-26-000088:mdna:73]
•$468 million in dividends paid to our shareholders;

[0001137789-26-000088:mdna:74]
•$111 million taxes paid related to net share settlement of equity awards;

[0001137789-26-000088:mdna:75]
•$59 million in payments for repurchases of our ordinary shares; and

[0001137789-26-000088:mdna:76]
•$20 million debt fees relating to the Obligor Exchange and retirement and repurchase of long-term debt; partially offset by

[0001137789-26-000088:mdna:77]
•$54 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-26-000088:mdna:78]
[same as prior period, unchanged from 0001137789-26-000026:mdna:78]

[0001137789-26-000088:mdna:79]
Our primary sources of liquidity as of April 3, 2026, consist of: (1) approximately $1.1 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.3 billion available for borrowing under our senior unsecured revolving credit facility (“Revolving Credit Facility”), which is part of our Credit Agreement (as defined within “Part I, Item 1. Financial Statements—Note 3. Debt”).

[0001137789-26-000088:mdna:80]
As of April 3, 2026, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with a financial covenant and other customary conditions to borrowing.

[0001137789-26-000088:mdna:81]
As of April 3, 2026, the Credit Agreement includes one financial covenant, net leverage ratio of less than or equal to 6.75 to 1.00, commencing with the fiscal quarter ended June 27, 2025 and declining over time so that the maximum permitted net leverage ratio for each fiscal quarter ending after July 2, 2027 is 4.25 to 1.00. As of April 3, 2026, we were in compliance with all of the covenants under our debt agreements. We continue to evaluate our debt portfolio and structure to comply with our financial debt covenant.

[0001137789-26-000088:mdna:82]
[same as prior period, unchanged from 0001137789-26-000026:mdna:82]

[0001137789-26-000088:mdna:83]
[same as prior period, unchanged from 0001137789-26-000026:mdna:83]

[0001137789-26-000088:mdna:84]
[same as prior period, unchanged from 0001137789-26-000026:mdna:88]

[0001137789-26-000088:mdna:85]
[same as prior period, unchanged from 0001137789-26-000026:mdna:84]

[0001137789-26-000088:mdna:86]
[same as prior period, unchanged from 0001137789-26-000026:mdna:85]

[0001137789-26-000088:mdna:87]
[same as prior period, unchanged from 0001137789-26-000026:mdna:86]

[0001137789-26-000088:mdna:88]
Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. From time to time, we enter into long-term, non-cancelable purchase commitments or make large up-front investments with certain suppliers in order to secure certain components or technologies for the production of our products or to supplement our internal manufacturing capacity for certain components. As of April 3, 2026, we had unconditional purchase obligations of approximately $1.9 billion, primarily related to purchases of inventory components with our suppliers. We expect $1.5 billion of these commitments to be paid within one year. In addition, we also had certain long-term, market share-based, non-cancellable inventory purchase commitments as of April 3, 2026.

[0001137789-26-000088:mdna:89]
[same as prior period, unchanged from 0001137789-26-000026:mdna:89]

[0001137789-26-000088:mdna:90]
We incur material capital expenditures to design and manufacture our products that depend on advanced technologies and manufacturing techniques. As of April 3, 2026, we had unconditional commitments of $312 million primarily related to purchases of equipment, of which approximately $298 million is expected to be paid within one year. During fiscal year 2026, supporting volume ramp of hard drives utilizing heat-assisted magnetic recording (“HAMR”) technology, we expect capital expenditures to be higher than fiscal year 2025 and still within our target range of 4-6% of revenue.

[0001137789-26-000088:mdna:91]
[same as prior period, unchanged from 0001137789-26-000026:mdna:91]

[0001137789-26-000088:mdna:92]
As of April 3, 2026, the future principal payment obligation on our long-term debt was $3.9 billion, which will mature in more than one year. As of April 3, 2026, future interest payments on this outstanding debt are estimated to be approximately $1.4 billion, of which $255 million is expected to be paid within one year. As of the calendar quarter ended March 31, 2026, the conditional conversion option of the 2028 Notes was triggered in accordance with the terms of the 2028 Notes indenture. Accordingly, the 2028 Notes are exchangeable through June 30, 2026. As a result, we have classified the 2028 Notes within Current liabilities in our Condensed Consolidated Balance Sheets as of April 3, 2026. From time to time, we may refinance, repurchase, redeem or otherwise extinguish any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase or redeem outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 1. Financial Statements—Note 3. Debt” for more details.

[0001137789-26-000088:mdna:93]
Legal settlements

[0001137789-26-000088:mdna:94]
As of April 3, 2026, we accrued a total of $240 million relating to legal settlements, of which $150 million is expected to be paid within one year and $90 million thereafter. Refer to “Item 1. Financial Statements—Note 11. Legal, Environmental and Other Contingencies” for more details.

[0001137789-26-000088:mdna:95]
[same as prior period, unchanged from 0001137789-26-000026:mdna:95]

[0001137789-26-000088:mdna:96]
On April 28, 2026, our Board of Directors declared a quarterly cash dividend of $0.74 per share, which will be payable on July 7, 2026 to shareholders of record as of the close of business on June 24, 2026. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-26-000088:mdna:97]
[same as prior period, unchanged from 0001137789-26-000026:mdna:97]

[0001137789-26-000088:mdna:98]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means, including through the use of derivative transactions. During the nine months ended April 3, 2026, we repurchased approximately 0.7 million of our ordinary shares including approximately 0.4 million shares withheld for statutory tax withholdings related to vesting of employee equity awards. As of April 3, 2026, $4.9 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-26-000088:mdna:99]
[same as prior period, unchanged from 0001137789-26-000026:mdna:99]

[0001137789-26-000088:mdna:100]
[same as prior period, unchanged from 0001137789-26-000026:mdna:100]

[0001137789-26-000088:mdna:101]
[same as prior period, unchanged from 0001137789-26-000026:mdna:101]

[0001137789-26-000088:mdna:102]
[same as prior period, unchanged from 0001137789-26-000026:mdna:102]

[0001137789-26-000088:mdna:103]
[same as prior period, unchanged from 0001137789-26-000026:mdna:103]

[0001137789-26-000088:mdna:104]
[same as prior period, unchanged from 0001137789-26-000026:mdna:104]

[0001137789-26-000088:mdna:105]
[same as prior period, unchanged from 0001137789-26-000026:mdna:105]
