# STX note change history — 0001193125-17-148855 → 0001193125-17-323042


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-10-27):
[0001193125-17-323042:note_history:1]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al. On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “‘635 patent”) and U.S. Patent No. 5,638,267 (the “‘267 patent”), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe U.S. Patent No. 6,314,473 (the “‘473 patent”). The district court ruled in 2010 that the ‘267 patent was out of the case.
  (was, 2017-04-28, similarity 0.9224):
[0001193125-17-148855:note_history:1]
Convolve, Inc. ("Convolve") and Massachusetts Institute of Technology ("MIT") v. Seagate Technology LLC, et al.— On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the "'635 patent") and U.S. Patent No. 5,638,267 (the "'267 patent"), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringed U.S. Patent No. 6,314,473 (the "'473 patent"). The district court ruled in 2010 that the '267 patent was out of the case.

- changed (2017-10-27):
[0001193125-17-323042:note_history:2]
On August 16, 2011, the district court granted in part and denied in part the Company’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2017-04-28, similarity 0.9956):
[0001193125-17-148855:note_history:2]
On August 16, 2011, the district court granted in part and denied in part the Company's motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court's summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court's summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent. On July 11, 2014, the district court granted the Company's further summary judgment motion regarding the '473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- added (2017-10-27):
[0001193125-17-323042:note_history:3]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al. On June 5, 2013, Enova Technology Corporation (“Enova”) filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995 (the “‘995 patent”), “Cryptographic Device,” and U.S. Patent No. 7,900,057 (the “‘057 patent”), “Cryptographic Serial ATA Apparatus and Method.” The Company believes the claims are without merit and intends to vigorously defend this case. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the ‘995 and ‘057 patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ‘057 patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 patent are held unpatentable. Enova appealed PTAB’s decisions on the ‘995 patent and the ‘057 patent to the U.S. Court of Appeals for the Federal Circuit. On March 20, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the ‘995 patent. On September 6, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the ‘057 patent. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- changed (2017-10-27):
[0001193125-17-323042:note_history:4]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017.  No trial date has been set. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2017-04-28, similarity 0.6496):
[0001193125-17-148855:note_history:4]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al.—On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- changed (2017-10-27):
[0001193125-17-323042:note_history:5]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.
  (was, 2017-04-28, similarity 0.9961):
[0001193125-17-148855:note_history:5]
The Company's operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company's operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

- changed (2017-10-27):
[0001193125-17-323042:note_history:6]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.
  (was, 2017-04-28, similarity 0.9965):
[0001193125-17-148855:note_history:6]
While the Company's ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

- changed (2017-10-27):
[0001193125-17-323042:note_history:7]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.
  (was, 2017-04-28, similarity 0.9991):
[0001193125-17-148855:note_history:7]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.

- changed (2017-10-27):
[0001193125-17-323042:note_history:8]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.
  (was, 2017-04-28, similarity 0.6909):
[0001193125-17-148855:note_history:8]
The Company is involved in a number of other judicial, regulatory and administrative proceedings incidental to its business, and from time to time, the Company may be involved in various legal, regulatory or administrative investigation, negotiations or proceeding arising in the normal course of business.  Although occasional adverse decisions or settlements may occur or adverse actions taken against the Company, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.

- removed (2017-10-27):
[0001193125-17-148855:note_history:9]
Alexander Shukh v. Seagate Technology —On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination and wrongful failure to name him as an inventor on certain Seagate patents. On March 31, 2014, the district court granted Seagate’s summary judgment motion. Mr. Shukh filed a notice of appeal on April 7, 2014. On October 2, 2015, the U.S. Court of Appeals for the Federal Circuit vacated and remanded the district court’s grant of summary judgment on Mr. Shukh’s claim for correction of inventorship and affirmed the district court’s grant of summary judgment as to all other claims. On October 29, 2015, Mr. Shukh filed a petition for rehearing en banc with the court of appeals; the petition was denied on December 17, 2015. On March 16, 2016, Shukh filed a petition for writ of certiorari to the U.S. Supreme Court; the petition was denied on June 27, 2016. On March 30, 2017, the parties entered into a confidential settlement to resolve this matter. This settlement did not have a material impact on the Company’s condensed consolidated financial statements.

- removed (2017-10-27):
[0001193125-17-148855:note_history:10]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.—On June 5, 2013, Enova Technology Corporation (“Enova”) filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995 (the '"995 patent"), “Cryptographic Device,” and U.S. Patent No. 7,900,057 (the "'057 patent"), “Cryptographic Serial ATA Apparatus and Method.” The Company believes the claims are without merit and intends to vigorously defend this case. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the ‘995 and ‘057 patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ‘057 patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 patent are held unpatentable. Enova has appealed PTAB’s decisions on the ‘995 patent and the ‘057 patent to the U.S. Court of Appeals for the Federal Circuit. Oral argument for the appeal from PTAB’s decision on the ‘995 patent was held on March 13, 2017, at the court of appeals. On March 20, 2017, the court of appeals issued its judgment affirming PTAB's decision on the '995 patent. A hearing before the court of appeals for the appeal from PTAB’s decision on the ‘057 patent has not yet been scheduled. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-10-27):
[0001193125-17-323042:note_history:11]
Seagate Technology plc (the “Company”) is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSD”) and their related controllers, solid state hybrid drives (“SSHD”) and storage subsystems.
  (was, 2017-04-28, similarity 0.639):
[0001193125-17-148855:note_history:11]
Seagate Technology plc (the "Company" or "Seagate") is a leading provider of electronic data storage technology and solutions.  Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, it produces a broad range of electronic data storage products including solid state drives ("SSD") in its Enterprise market portfolio and solid state hybrid drives ("SSHD"). The Company's storage technology portfolio also includes storage subsystems, and high performance computing ("HPC") solutions.

- changed (2017-10-27):
[0001193125-17-323042:note_history:12]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data with most SSDs using NAND-based flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed data.
  (was, 2017-04-28, similarity 0.9686):
[0001193125-17-148855:note_history:12]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and most SSDs use NAND-based flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed data.

- changed (2017-10-27):
[0001193125-17-323042:note_history:13]
The Company’s products are designed for mission critical and nearline applications in enterprise servers and storage systems; edge / client compute applications, where its products are designed primarily for desktop and mobile computing; and edge / client non-compute applications, where its products are designed for a wide variety of end user devices such as portable external storage systems, surveillance systems, network-attached storage (“NAS”), digital video recorders (“DVRs”) and gaming consoles.
  (was, 2017-04-28, similarity 0.8367):
[0001193125-17-148855:note_history:13]
The Company's products are designed for mission critical and nearline applications in enterprise servers and storage systems; client compute applications, where its products are designed primarily for desktop and mobile computing; and client non-compute applications, where its products are designed for a wide variety of end user devices such as portable external storage systems, personal data backup systems, surveillance systems, digital video recorders ("DVRs") and gaming consoles.

- changed (2017-10-27):
[0001193125-17-323042:note_history:14]
The Company’s cloud systems and solutions extend innovation from the device into the information infrastructure, onsite and in the cloud. Its portfolio includes modular original equipment manufacturers (“OEM”) storage systems and scale-out storage servers.
  (was, 2017-04-28, similarity 0.6532):
[0001193125-17-148855:note_history:14]
The Company's Cloud Systems and Solutions product portfolio builds on the Seagate legacy to extend innovation from the device into the information infrastructure, onsite and in the cloud. This product portfolio includes HPC storage solutions, modular original equipment manufacturers ("OEM") storage systems and scale-out storage systems.

- changed (2017-10-27):
[0001193125-17-323042:note_history:15]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income, cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature. Certain prior period amounts in the condensed consolidated financial statements and notes to the condensed consolidated financial statements have been reclassified to conform to the current period's presentation.
  (was, 2017-04-28, similarity 0.9136):
[0001193125-17-148855:note_history:15]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income, cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature. Certain prior period amounts reported in the condensed consolidated financial statements and notes thereto have been reclassified to conform to the current period’s presentation.

- changed (2017-10-27):
[0001193125-17-323042:note_history:16]
The Company’s Consolidated Financial Statements for the fiscal year ended June 30, 2017, are included in its Annual Report on Form 10-K as filed with the United States Securities and Exchange Commission (“SEC”) on August 4, 2017. The Company believes that the disclosures included in the unaudited condensed consolidated financial statements, when read in conjunction with its Consolidated Financial Statements as of June 30, 2017, and the notes thereto, are adequate to make the information presented not misleading.
  (was, 2017-04-28, similarity 0.992):
[0001193125-17-148855:note_history:16]
The Company’s Consolidated Financial Statements for the fiscal year ended July 1, 2016, are included in its Annual Report on Form 10-K as filed with the United States Securities and Exchange Commission (“SEC”) on August 5, 2016. The Company believes that the disclosures included in the unaudited condensed consolidated financial statements, when read in conjunction with its Consolidated Financial Statements as of July 1, 2016, and the notes thereto, are adequate to make the information presented not misleading.

- added (2017-10-27):
[0001193125-17-323042:note_history:17]
The results of operations for the three months ended September 29, 2017, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending June 29, 2018. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three months ended September 29, 2017 and September 30, 2016 consisted of 13 weeks. Fiscal year 2018 will be comprised of 52 weeks and will end on June 29, 2018. The fiscal quarters ended September 29, 2017, June 30, 2017, and September 30, 2016, are also referred to herein as the “September 2017 quarter”, the “June 2017 quarter”, and the “September 2016 quarter”, respectively.

- changed (2017-10-27):
[0001193125-17-323042:note_history:18]
There have been no significant changes in the Company's significant accounting policies. Please refer to Note 1 of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2017, as filed with the SEC on August 4, 2017 for a discussion of the Company’s other significant accounting policies.
  (was, 2017-04-28, similarity 0.9947):
[0001193125-17-148855:note_history:18]
There have been no significant changes in the Company's significant accounting policies. Please refer to Note 1 of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended July 1, 2016, as filed with the SEC on August 5, 2016 for a discussion of the Company’s other significant accounting policies.

- changed (2017-10-27):
[0001193125-17-323042:note_history:19]
In May 2014, August 2015, April 2016, May 2016 and December 2016, the Financial Accounting Standards Board (“FASB”) issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, ASU 2016-12 (ASC Topic 606) Revenue from Contracts with Customers, Narrow-Scope Improvements and Practical Expedients, and ASU 2016-20 (ASC Topic 606) Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company is required to adopt the guidance in the first quarter of fiscal 2019. This standard may be applied retrospectively to all prior periods presented, or retrospectively with a cumulative adjustment to retained earnings in the year of adoption (“modified retrospective transition approach”). Based on its assessment, the Company plans to adopt the new revenue standard in the first quarter of fiscal 2019, utilizing the modified retrospective method of transition. While management has not yet completed its assessment of the impact of adopting this new standard on the Company’s consolidated financial statements, the Company expects the adoption of the new standard will result in the recognition of revenues generally upon shipment (sell-in basis) for sales of products to certain direct retail customers and customers in certain indirect retail channels which are currently being recognized on a sell-through basis. Accordingly, the Company will need to estimate variable consideration (e.g. rebates) related to customer incentives on these arrangements. These changes are not expected to have a material impact on the Company’s condensed consolidated financial statements.
  (was, 2017-04-28, similarity 0.6603):
[0001193125-17-148855:note_history:19]
In May 2014, August 2015, April 2016, May 2016 and December 2016, the Financial Accounting Standards Board ("FASB") issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, ASU 2016-12 (ASC Topic 606) Revenue from Contracts with Customers, Narrow-Scope Improvements and Practical Expedients, and ASU 2016-20 (ASC Topic 606) Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted for annual periods beginning after December 15, 2016, which is first quarter of fiscal 2018 for the Company. This standard may be applied retrospectively to all prior periods presented, or retrospectively with a cumulative adjustment to retained earnings in the year of adoption ("modified retrospective transition approach"). The Company is in the process of assessing the impact, on its condensed consolidated financial statements and plans to adopt the modified retrospective transition approach.

- changed (2017-10-27):
[0001193125-17-323042:note_history:20]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments—Overall Recognition and Measurement of Financial Assets and Financial Liabilities. The amendments in this ASU require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted for only certain portions of the ASU. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.
  (was, 2017-04-28, similarity 0.9981):
[0001193125-17-148855:note_history:20]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments - Overall Recognition and Measurement of Financial Assets and Financial Liabilities. The amendments in this ASU require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted for only certain portions of the ASU. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- added (2017-10-27):
[0001193125-17-323042:note_history:21]
In May 2017, the FASB issued ASU 2017-09 (ASC Topic 718), Stock Compensation: Scope of Modification Accounting. The amendments in this ASU provide guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- added (2017-10-27):
[0001193125-17-323042:note_history:22]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. This ASU became effective and was adopted by the Company in the September 2017 quarter on a prospective basis. The adoption of this guidance had no material impact on the Company’s condensed consolidated financial statements and disclosures.

- added (2017-10-27):
[0001193125-17-323042:note_history:23]
In March 2016, the FASB issued ASU 2016-09 (ASC Topic 718), Stock Compensation—Improvements to Employee Share-Based Payment Accounting. The amendments in this ASU are intended to simplify several areas of accounting for share-based compensation arrangements, including the income tax consequences, classification on the consolidated statement of cash flows and treatment of forfeitures. This ASU became effective and was adopted by the Company in the September 2017 quarter. Upon adoption, excess tax benefits or deficiencies from share-based award activity are reflected in the condensed consolidated statements of operations as a component of the provision for income taxes, whereas they previously were recognized in the Shareholder's equity in the condensed consolidated balance sheets. The Company also elected to continue to account for share-based compensation expense net of estimated forfeitures. The adoption of this ASU resulted in an increase in deferred tax assets relating to net operating losses of approximately $0.6 billion, offset by an equivalent increase in the valuation allowance with no impact to retained earnings. The adoption of this guidance had no material impact on the Company’s condensed consolidated financial statements and disclosures.

- added (2017-10-27):
[0001193125-17-323042:note_history:24]
In October 2016, the FASB issued ASU 2016-16 (ASC Topic 740), Income Taxes: Intra-Entity Transfers of Assets Other Than Inventory. The amendments in this ASU require the recognition of the income tax consequences for intra-entity transfers of assets other than inventory when the transfer occurs. The Company elected to adopt this ASU in the September 2017 quarter on a modified retrospective basis with no material impact on the Company's condensed consolidated financial statements and disclosures.

- removed (2017-10-27):
[0001193125-17-148855:note_history:25]
The results of operations for the three and nine months ended March 31, 2017, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending June 30, 2017. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three and nine months ended March 31, 2017 and the three and nine months ended April 1, 2016 consisted of 13 weeks and 39 weeks, respectively. Fiscal year 2017 will be comprised of 52 weeks and will end on June 30, 2017. The fiscal quarters ended March 31, 2017, December 30, 2016, and April 1, 2016, are also referred to herein as the “March 2017 quarter”, the “December 2016 quarter”, and the “March 2016 quarter”, respectively.

- removed (2017-10-27):
[0001193125-17-148855:note_history:26]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. The Company is required to adopt the guidance in the first quarter of fiscal 2018. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company is in the process of finalizing its assessment of the impact of this ASU, which is not expected to have a material impact on its condensed consolidated financial statements.

- removed (2017-10-27):
[0001193125-17-148855:note_history:27]
In March 2016, the FASB issued ASU 2016-09 (ASC Topic 718), Stock Compensation - Improvements to Employee Share-Based Payment Accounting. The amendments in this ASU are intended to simplify several areas of accounting for share-based compensation arrangements, including the income tax consequences, classification on the consolidated statement of cash flows and treatment of forfeitures. The Company is required to adopt the guidance in the first quarter of fiscal 2018. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- removed (2017-10-27):
[0001193125-17-148855:note_history:28]
In August 2016, the FASB issued ASU 2016-15 (ASC Topic 230), Statement of Cash Flows - Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU are intended to clarify how certain cash receipts and cash payment are presented and classified in the statement of cash flows. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- removed (2017-10-27):
[0001193125-17-148855:note_history:29]
In October 2016, the FASB issued ASU 2016-16 (ASC Topic 740), Income Taxes: Intra-Entity Transfers of Assets Other Than Inventory. The amendments in this ASU require the recognition of the income tax consequences for intra-entity transfers of assets other than inventory when the transfer occurs. Under current GAAP, current and deferred income taxes for intra-entity asset transfers are not recognized until the asset has been sold to an outside party. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- removed (2017-10-27):
[0001193125-17-148855:note_history:30]
In April 2015 and August 2015, the FASB issued ASU 2015-03 (ASC Subtopic 835-30), Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs and ASU 2015-15 (ASC Subtopic 835-30), Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements- Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting, respectively. The ASUs require that debt issuance costs related to a recognized debt liability, with the exception of those related to line-of-credit arrangements, be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability.  ASU 2015-03 became effective and was adopted by the Company in the September 2016 quarter on a retrospective basis. The adoption of this guidance resulted in a reduction to Other assets, net and Long-term debt by $39 million, within the Consolidated Balance Sheet as of July 1, 2016. ASU 2015-15 became effective and was adopted by the Company in the September 2016 quarter on a prospective basis with no material impact on the Company’s condensed consolidated financial statements and disclosures.

- removed (2017-10-27):
[0001193125-17-148855:note_history:31]
In September 2015, the FASB issued ASU 2015-16 (ASC Topic 805), Business Combinations Simplifying the Accounting for Measurement-Period Adjustments. The amendments in this update require that an acquirer recognize measurement period adjustments in the period in which the adjustments are determined. The income effects of such measurement period adjustments are to be recorded in the same period’s financial statements but calculated as if the accounting had been completed as of the acquisition date. The impact of measurement period adjustments to earnings that relate to prior period financial statements are to be presented separately on the income statement or disclosed by line item. The amendments in this update are for fiscal years, including interim periods within those fiscal years, beginning after December 15, 2015. This ASU became effective and was adopted by the Company in the September 2016 quarter on a prospective basis with no material impact on the Company’s condensed consolidated financial statements and disclosures.

- removed (2017-10-27):
[0001193125-17-148855:note_history:32]
In November 2016, the FASB issued ASU 2016-18 (ASC Topic 230), Statement of Cash Flows: Restricted Cash. The amendments in this update provide guidance on the classification and presentation of changes in restricted cash on the statement of cash flows. The ASU requires amounts generally described as restricted cash and restricted cash equivalents to be included with cash and cash equivalents when reconciling the total beginning and ending balances for the periods presented on the statement of cash flows. The amendments in this update are for fiscal years, including interim periods within those fiscal years, beginning after December 15, 2017. The Company elected to adopt this ASU in the December 2016 quarter on a retrospective basis with no material impact on the Company's condensed consolidated financial statements and disclosures. The Company classifies restricted cash within Other current assets in the condensed consolidated balance sheets.

- removed (2017-10-27):
[0001193125-17-148855:note_history:33]
In January 2017, the FASB issued ASU 2017-04 (ASC Topic 350), Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment. The amendments in this ASU eliminate Step 2 from the goodwill impairment test, which requires entities to calculate the implied fair value of goodwill to measure a goodwill impairment charge. Instead, entities will record an impairment charge based on the excess of a reporting unit's carrying amount over its fair value, determined in step 1. The Company elected to adopt this ASU in the March 2017 quarter on a prospective basis with no material impact on the Company's condensed consolidated financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-10-27):
[0001193125-17-323042:note_history:34]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to allow for higher net leverage levels. The Company was in compliance with the modified covenants as of September 29, 2017 and expects to be in compliance for the next 12 months.
  (was, 2017-04-28, similarity 0.9856):
[0001193125-17-148855:note_history:34]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio.  On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to allow for higher net leverage levels. The Company was in compliance with the modified covenants as of March 31, 2017 and expects to be in compliance for the next 12 months.

- changed (2017-10-27):
[0001193125-17-323042:note_history:35]
As of September 29, 2017, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.
  (was, 2017-04-28, similarity 0.9558):
[0001193125-17-148855:note_history:35]
As of March 31, 2017, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

- changed (2017-10-27):
[0001193125-17-323042:note_history:36]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2017 quarter, the Company repurchased $22 million aggregate principal amount of the 2018 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded an immaterial loss on the repurchase during the three months ended September 29, 2017, which is included in Other, net on the Condensed Consolidated Statements of Operations.
  (was, 2017-04-28, similarity 0.9294):
[0001193125-17-148855:note_history:36]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2017 quarter, the Company repurchased $34 million aggregate principal amount of the 2023 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded an immaterial loss on the repurchase during the three and nine months ended March 31, 2017, which is included in Other, net on the Condensed Consolidated Statements of Operations.

- changed (2017-10-27):
[0001193125-17-323042:note_history:37]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2017-04-28, similarity 0.6104):
[0001193125-17-148855:note_history:37]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2017 quarter, the Company repurchased $4 million aggregate principal amount of the 2027 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded an immaterial gain on the repurchase during the three and nine months ended March 31, 2017, which is included in Other, net on the Condensed Consolidated Statements of Operations.

- added (2017-10-27):
[0001193125-17-323042:note_history:38]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2017-10-27):
[0001193125-17-323042:note_history:39]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”). The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2017-04-28, similarity 0.6067):
[0001193125-17-148855:note_history:39]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2017 quarter, the Company repurchased $39 million aggregate principal amount of the 2018 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately $1 million during the three and nine months ended March 31, 2017, which is included in Other, net on the Condensed Consolidated Statements of Operations.

- changed (2017-10-27):
[0001193125-17-323042:note_history:40]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2017-04-28, similarity 0.6396):
[0001193125-17-148855:note_history:40]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2017 quarter, the Company repurchased $20 million aggregate principal amount of the 2025 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded a gain on the repurchase of approximately $1 million during the three and nine months ended March 31, 2017, which is included in Other, net on the Condensed Consolidated Statements of Operations.

- added (2017-10-27):
[0001193125-17-323042:note_history:41]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2017-10-27):
[0001193125-17-323042:note_history:42]
At September 29, 2017, future principal payments on long-term debt were as follows (in millions):
  (was, 2017-04-28, similarity 0.9438):
[0001193125-17-148855:note_history:42]
At March 31, 2017, future principal payments on long-term debt were as follows (in millions):

- changed (2017-10-27):
[0001193125-17-323042:note_history:43]
| Fiscal Year |  | Amount |
| Remainder of 2018 |  | $ | — |  |
| 2019 |  | 688 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| 2022 |  | 750 |  |
| Thereafter |  | 3,613 |  |
| Total |  | $ | 5,051 |  |
  (was, 2017-04-28, similarity 0.9114):
[0001193125-17-148855:note_history:43]
| Fiscal Year |  | Amount |
| Remainder of 2017 |  | $ | 158 |  |
| 2018 |  | — |  |
| 2019 |  | 761 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| Thereafter |  | 4,367 |  |
| Total |  | $ | 5,286 |  |

- removed (2017-10-27):
[0001193125-17-148855:note_history:44]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman, and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. On March 15, 2017, the Company exercised its call option by providing notice of the redemption to the trustee of its intention to redeem all of its remaining outstanding 2021 Notes. The Notes will be redeemed on May 1, 2017 (the "Redemption Date") at a redemption price equal to $102.333 per $100 principal amount of the 2021 Notes redeemed plus accrued interest to the Redemption Date. As a result, the 2021 Notes are classified as Current portion of long-term debt on the Company's Condensed Consolidated Balance Sheet at March 31, 2017.

- removed (2017-10-27):
[0001193125-17-148855:note_history:45]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). On February 3, 2017, Seagate HDD Cayman issued, in a private placement, $750 million in aggregate principal amount of 4.25% Senior Notes which will mature on March 1, 2022. The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year, commencing on September 1, 2017. At any time before February 1, 2022, Seagate HDD Cayman may redeem some or all of the 2022 Notes at a 'make whole' redemption price, plus accrued and unpaid interest, if any. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the 2022 Notes redeemed, plus (2) the excess, if any, of (a) the sum of the present values of the remaining scheduled payments of principal and interest on the 2022 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 40 basis points, minus accrued and unpaid interest, if any, on the 2022 Notes being redeemed to, but excluding, the redemption date over (b) the principal amount of the 2022 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the 2022 Notes being redeemed to, but excluding, the redemption date. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- removed (2017-10-27):
[0001193125-17-148855:note_history:46]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”).  On February 3, 2017, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 4.875% Senior Notes which will mature on March 1, 2024. The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year, commencing on September 1, 2017. At any time before January 1, 2024, Seagate HDD Cayman may redeem some or all of the 2024 Notes at a 'make whole' redemption price, plus accrued and unpaid interest, if any. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the 2024 Notes redeemed, plus (2) the excess, if any, of (a) the sum of the present values of the remaining scheduled payments of principal and interest on the 2024 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 45 basis points, minus accrued and unpaid interest, if any, on the 2024 Notes being redeemed to, but excluding, the redemption date over (b) the principal amount of the 2024 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the 2024 Notes being redeemed to, but excluding, the redemption date. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-10-27):
[0001193125-17-323042:note_history:47]
|  |  | September 29, 2017 |  | June 30, 2017 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 688 |  |  | $ | 701 |  |  | $ | 710 |  |  | $ | 726 |  |
| 4.25% Senior Notes due March 2022 |  | 748 |  |  | 746 |  |  | 748 |  |  | 765 |  |
| 4.75% Senior Notes due June 2023 |  | 951 |  |  | 963 |  |  | 951 |  |  | 987 |  |
| 4.875% Senior Notes due March 2024 |  | 497 |  |  | 493 |  |  | 497 |  |  | 511 |  |
| 4.75% Senior Notes due January 2025 |  | 975 |  |  | 949 |  |  | 975 |  |  | 984 |  |
| 4.875% Senior Notes due June 2027 |  | 695 |  |  | 659 |  |  | 695 |  |  | 698 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 459 |  |  | 489 |  |  | 488 |  |
|  |  | $ | 5,043 |  |  | $ | 4,970 |  |  | $ | 5,065 |  |  | $ | 5,159 |  |
| Less: debt issuance costs |  | (41 | ) |  | — |  |  | (44 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 5,002 |  |  | $ | 4,970 |  |  | $ | 5,021 |  |  | $ | 5,159 |  |

- removed (2017-10-27):
[0001193125-17-148855:note_history:48]
|  |  | March 31, 2017 |  | July 1, 2016 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 761 |  |  | $ | 781 |  |  | $ | 800 |  |  | $ | 804 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 162 |  |  | 158 |  |  | 164 |  |
| 4.25% Senior Notes due March 2022 |  | 748 |  |  | 743 |  |  | — |  |  | — |  |
| 4.75% Senior Notes due June 2023 |  | 956 |  |  | 961 |  |  | 990 |  |  | 857 |  |
| 4.875% Senior Notes due March 2024 |  | 496 |  |  | 491 |  |  | — |  |  | — |  |
| 4.75% Senior Notes due January 2025 |  | 975 |  |  | 958 |  |  | 995 |  |  | 795 |  |
| 4.875% Senior Notes due June 2027 |  | 695 |  |  | 654 |  |  | 698 |  |  | 514 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 446 |  |  | 489 |  |  | 357 |  |
|  |  | $ | 5,278 |  |  | $ | 5,196 |  |  | $ | 4,130 |  |  | $ | 3,491 |  |
| Less: debt issuance costs |  | (47 | ) |  | — |  |  | (39 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 5,231 |  |  | $ | 5,196 |  |  | $ | 4,091 |  |  | $ | 3,491 |  |
| Less: short-term borrowings and current portion of long-term debt |  | (158 | ) |  | (162 | ) |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 5,073 |  |  | $ | 5,034 |  |  | $ | 4,091 |  |  | $ | 3,491 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-10-27):
[0001193125-17-323042:note_history:49]
At September 29, 2017, future principal payments on long-term debt were as follows (in millions):
  (was, 2017-04-28, similarity 0.9438):
[0001193125-17-148855:note_history:49]
At March 31, 2017, future principal payments on long-term debt were as follows (in millions):

- changed (2017-10-27):
[0001193125-17-323042:note_history:50]
| Fiscal Year |  | Amount |
| Remainder of 2018 |  | $ | — |  |
| 2019 |  | 688 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| 2022 |  | 750 |  |
| Thereafter |  | 3,613 |  |
| Total |  | $ | 5,051 |  |
  (was, 2017-04-28, similarity 0.9114):
[0001193125-17-148855:note_history:50]
| Fiscal Year |  | Amount |
| Remainder of 2017 |  | $ | 158 |  |
| 2018 |  | — |  |
| 2019 |  | 761 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| Thereafter |  | 4,367 |  |
| Total |  | $ | 5,286 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2017-10-27):
[0001193125-17-323042:note_history:51]
Subsequent Events

- added (2017-10-27):
[0001193125-17-323042:note_history:52]
Dividend Declared

- added (2017-10-27):
[0001193125-17-323042:note_history:53]
On October 23, 2017, the Company’s Board of Directors approved and declared a quarterly cash dividend of $0.63 per share, which will be payable on January 3, 2018 to shareholders of record as of the close of business on December 20, 2017.
