# STX notes — 0001193125-17-323042


## invest:InvestmentTableTextBlock

[0001193125-17-323042:notes:1]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of June 30, 2017:

[0001193125-17-323042:notes:2]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 594 |  |  | $ | — |  |  | $ | 594 |  |
| Time deposits and certificates of deposit |  | 584 |  |  | — |  |  | 584 |  |
| Total |  | $ | 1,178 |  |  | $ | — |  |  | $ | 1,178 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 1,174 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 4 |  |
| Total |  |  |  |  |  |  |  | $ | 1,178 |  |

[0001193125-17-323042:notes:3]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of September 29, 2017:

[0001193125-17-323042:notes:4]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 623 |  |  | $ | — |  |  | $ | 623 |  |
| Time deposits and certificates of deposit |  | 207 |  |  | — |  |  | 207 |  |
| Total |  | $ | 830 |  |  | $ | — |  |  | $ | 830 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 826 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 4 |  |
| Total |  |  |  |  |  |  |  | $ | 830 |  |


## stx:ScheduleOfShareRepurchasesTableTextBlock

[0001193125-17-323042:notes:5]
The following table sets forth information with respect to repurchases of the Company’s shares during the three months ended September 29, 2017:

[0001193125-17-323042:notes:6]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Repurchases of ordinary shares |  | 5 |  |  | $ | 166 |  |
| Tax withholding related to vesting of equity awards |  | 1 |  |  | 20 |  |
| Total |  | 6 |  |  | $ | 186 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-17-323042:notes:7]
[same as prior period, unchanged from 0001193125-17-148855:notes:7]

[0001193125-17-323042:notes:8]
[same as prior period, unchanged from 0001193125-17-148855:notes:8]

[0001193125-17-323042:notes:9]
[same as prior period, unchanged from 0001193125-17-148855:notes:9]

[0001193125-17-323042:notes:10]
[same as prior period, unchanged from 0001193125-17-148855:notes:10]

[0001193125-17-323042:notes:11]
[same as prior period, unchanged from 0001193125-17-148855:notes:11]

[0001193125-17-323042:notes:12]
[same as prior period, unchanged from 0001193125-17-148855:notes:12]

[0001193125-17-323042:notes:13]
[same as prior period, unchanged from 0001193125-17-148855:notes:13]

[0001193125-17-323042:notes:14]
[same as prior period, unchanged from 0001193125-17-148855:notes:14]


## us-gaap:CommitmentsDisclosureTextBlock

[0001193125-17-323042:notes:15]
Commitments

[0001193125-17-323042:notes:16]
Investment commitment to acquire preferred equity securities. On September 28, 2017, the Company entered into an Equity Commitment Letter (“ECL”) with a consortium of investors led by Bain Capital Private Equity for the acquisition of Toshiba Memory Corporation (“TMC”). The ECL contemplates that, upon the closing of the acquisition, the Company or one of its subsidiaries would purchase up to JPY 139.5 billion (approximately USD 1.25 billion based on current exchange rates), of a newly issued non-convertible preferred equity security of a newly formed company, K. K. Pangea, for the purpose of acquiring TMC. The closing of the acquisition is subject to regulatory approvals and other closing conditions.


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-17-323042:notes:17]
[same as prior period, unchanged from 0001193125-17-148855:notes:21]

[0001193125-17-323042:notes:18]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income, cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature. Certain prior period amounts in the condensed consolidated financial statements and notes to the condensed consolidated financial statements have been reclassified to conform to the current period's presentation.

[0001193125-17-323042:notes:19]
The Company’s Consolidated Financial Statements for the fiscal year ended June 30, 2017, are included in its Annual Report on Form 10-K as filed with the United States Securities and Exchange Commission (“SEC”) on August 4, 2017. The Company believes that the disclosures included in the unaudited condensed consolidated financial statements, when read in conjunction with its Consolidated Financial Statements as of June 30, 2017, and the notes thereto, are adequate to make the information presented not misleading.


## us-gaap:DebtDisclosureTextBlock

[0001193125-17-323042:notes:20]
Debt

[0001193125-17-323042:notes:21]
Short-Term Borrowings

[0001193125-17-323042:notes:22]
The credit agreement entered into by the Company and its subsidiary Seagate HDD Cayman on January 18, 2011 and subsequently amended (the "Revolving Credit Facility") provides the Company with a $700 million senior secured revolving credit facility. The term of the Revolving Credit Facility is through January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Revolving Credit Facility) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. The loans made under the Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing, and for the issuance of letters of credit up to a sub-limit of $75 million.

[0001193125-17-323042:notes:23]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to allow for higher net leverage levels. The Company was in compliance with the modified covenants as of September 29, 2017 and expects to be in compliance for the next 12 months.

[0001193125-17-323042:notes:24]
As of September 29, 2017, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

[0001193125-17-323042:notes:25]
Long-Term Debt

[0001193125-17-323042:notes:26]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2017 quarter, the Company repurchased $22 million aggregate principal amount of the 2018 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded an immaterial loss on the repurchase during the three months ended September 29, 2017, which is included in Other, net on the Condensed Consolidated Statements of Operations.

[0001193125-17-323042:notes:27]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-17-323042:notes:28]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-17-323042:notes:29]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”). The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-17-323042:notes:30]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-17-323042:notes:31]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-17-323042:notes:32]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-17-323042:notes:33]
At September 29, 2017, future principal payments on long-term debt were as follows (in millions):

[0001193125-17-323042:notes:34]
| Fiscal Year |  | Amount |
| Remainder of 2018 |  | $ | — |  |
| 2019 |  | 688 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| 2022 |  | 750 |  |
| Thereafter |  | 3,613 |  |
| Total |  | $ | 5,051 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-17-323042:notes:35]
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity market risks relating to its ongoing business operations. The Company enters into foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses denominated in foreign currencies. The Company's accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The changes in the fair value of the effective portions of designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments and the ineffective portions of cash flow hedges are adjusted to fair value through earnings. The Company has no outstanding cash flow hedges as of September 29, 2017 and June 30, 2017.

[0001193125-17-323042:notes:36]
The Company dedesignates its cash flow hedges when the forecasted hedged transactions are realized or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company did not recognize any net gains or losses related to the loss of hedge designation on discontinued cash flow hedges during the three months ended September 29, 2017.

[0001193125-17-323042:notes:37]
As of September 29, 2017 and June 30, 2017, the Company does not have outstanding foreign currency forward exchange contracts.

[0001193125-17-323042:notes:38]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plan—the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees. As of September 29, 2017, the notional investments underlying the TRS amounted to $114 million. The contract term of the TRS is through January 2018 and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001193125-17-323042:notes:39]
As of September 29, 2017 and June 30, 2017, the Company has no outstanding foreign currency forward exchange contracts and the gross fair value of the TRS reflected in the Condensed Consolidated Balance Sheets, respectively, is immaterial.

[0001193125-17-323042:notes:40]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statement of Comprehensive Income and the Condensed Consolidated Statement of Operations for the three months ended September 29, 2017.

[0001193125-17-323042:notes:41]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | — |  |
| Total return swap |  | Operating expenses |  | 3 |  |

[0001193125-17-323042:notes:42]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statement of Comprehensive Income and the Condensed Consolidated Statement of Operations for the three months ended September 30, 2016:

[0001193125-17-323042:notes:43]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
| Foreign currency forward exchange contracts |  | $ | (1 | ) |  | Cost of revenue |  | $ | (1 | ) |  | Cost of revenue |  | $ | — |  |

[0001193125-17-323042:notes:44]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (1 | ) |
| Total return swap |  | Operating expenses |  | 3 |  |

[0001193125-17-323042:notes:45]
[same as prior period, unchanged from 0001193125-17-148855:notes:53]

[0001193125-17-323042:notes:46]
| (a) | The amount of gain or (loss) recognized in income related to the ineffective portion of the hedging relationships and the amount excluded from the assessment of hedge effectiveness were less than $1 million for the three months ended September 30, 2016. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-17-323042:notes:47]
[same as prior period, unchanged from 0001193125-17-148855:notes:60]

[0001193125-17-323042:notes:48]
The Company recorded approximately $32 million and $40 million of share-based compensation expense during the three months ended September 29, 2017 and September 30, 2016, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001193125-17-323042:notes:49]
[same as prior period, unchanged from 0001193125-17-148855:notes:62]

[0001193125-17-323042:notes:50]
Basic earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period. Diluted earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period and the number of additional shares that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding options, unvested restricted stock units and shares to be purchased under the Employee Stock Purchase Plan ("ESPP"). The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in fair market value of the Company’s share price can result in a greater dilutive effect from potentially dilutive securities. The following table sets forth the computation of basic and diluted net income per share attributable to the shareholders of the Company:

[0001193125-17-323042:notes:51]
|  |  | For the Three Months Ended |
| (In millions, except per share data) |  | September 29, 2017 |  | September 30, 2016 |
| Numerator: |  |  |  |  |  |  |
| Net income |  | $ | 181 |  |  | $ | 167 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 290 |  |  | 299 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |
| Employee equity award plans |  | 2 |  |  | 2 |  |
| Total shares for purpose of calculating diluted net income per share |  | 292 |  |  | 301 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 0.62 |  |  | $ | 0.56 |  |
| Diluted |  | $ | 0.62 |  |  | $ | 0.55 |  |

[0001193125-17-323042:notes:52]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share were 2 million and 3 million for the three months ended September 29, 2017 and September 30, 2016, respectively.


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001193125-17-323042:notes:53]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 622 |  |  | $ | 204 |  |  | $ | — |  |  | $ | 826 |  |
| Other current assets |  | 1 |  |  | 3 |  |  | — |  |  | 4 |  |
| Total assets |  | $ | 623 |  |  | $ | 207 |  |  | $ | — |  |  | $ | 830 |  |

[0001193125-17-323042:notes:54]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 593 |  |  | $ | 581 |  |  | $ | — |  |  | $ | 1,174 |  |
| Other current assets |  | 1 |  |  | 3 |  |  | — |  |  | 4 |  |
| Total assets |  | $ | 594 |  |  | $ | 584 |  |  | $ | — |  |  | $ | 1,178 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-17-323042:notes:55]
[same as prior period, unchanged from 0001193125-17-148855:notes:68]

[0001193125-17-323042:notes:56]
[same as prior period, unchanged from 0001193125-17-148855:notes:69]

[0001193125-17-323042:notes:57]
[same as prior period, unchanged from 0001193125-17-148855:notes:70]

[0001193125-17-323042:notes:58]
[same as prior period, unchanged from 0001193125-17-148855:notes:71]

[0001193125-17-323042:notes:59]
A fair value hierarchy is based on whether the market participant assumptions used in determining fair value are obtained from independent sources (observable inputs) or reflects the Company’s own assumptions of market participant valuation (unobservable inputs). A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The three levels of inputs that may be used to measure fair value are:

[0001193125-17-323042:notes:60]
[same as prior period, unchanged from 0001193125-17-148855:notes:73]

[0001193125-17-323042:notes:61]
[same as prior period, unchanged from 0001193125-17-148855:notes:74]

[0001193125-17-323042:notes:62]
[same as prior period, unchanged from 0001193125-17-148855:notes:75]

[0001193125-17-323042:notes:63]
[same as prior period, unchanged from 0001193125-17-148855:notes:76]

[0001193125-17-323042:notes:64]
[same as prior period, unchanged from 0001193125-17-148855:notes:77]

[0001193125-17-323042:notes:65]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of September 29, 2017:

[0001193125-17-323042:notes:66]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 622 |  |  | $ | — |  |  | $ | — |  |  | $ | 622 |  |
| Time deposits |  | — |  |  | 204 |  |  | — |  |  | 204 |  |
| Total cash equivalents |  | 622 |  |  | 204 |  |  | — |  |  | 826 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets |  | $ | 623 |  |  | $ | 207 |  |  | $ | — |  |  | $ | 830 |  |

[0001193125-17-323042:notes:67]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of June 30, 2017:

[0001193125-17-323042:notes:68]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 593 |  |  | $ | — |  |  | $ | — |  |  | $ | 593 |  |
| Time deposits |  | — |  |  | 581 |  |  | — |  |  | 581 |  |
| Total cash equivalents |  | 593 |  |  | 581 |  |  | — |  |  | 1,174 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets |  | $ | 594 |  |  | $ | 584 |  |  | $ | — |  |  | $ | 1,178 |  |

[0001193125-17-323042:notes:69]
[same as prior period, unchanged from 0001193125-17-148855:notes:83]

[0001193125-17-323042:notes:70]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair values of all of its cash equivalents. For the cash equivalents and short-term investments in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry standard data providers or other third party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of September 29, 2017, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts and the TRS. The Company recognizes derivative financial instruments in its consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001193125-17-323042:notes:71]
As of September 29, 2017 and June 30, 2017, the Company had no Level 3 assets or liabilities measured at fair value on a recurring basis.

[0001193125-17-323042:notes:72]
[same as prior period, unchanged from 0001193125-17-148855:notes:86]

[0001193125-17-323042:notes:73]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments primarily include cost basis investments representing those where the Company does not have the ability to exercise significant influence as well as equity method investments representing those where the Company does have the ability to exercise significant influence but does not have control. These investments are included in Other assets, net in the Condensed Consolidated Balance Sheets, and are periodically analyzed to determine whether or not there are indicators of impairment. The carrying value of the Company’s strategic investments at September 29, 2017 and June 30, 2017 totaled $125 million at both dates, and consisted primarily of privately held equity securities without a readily determinable fair value.

[0001193125-17-323042:notes:74]
For the three months ended September 29, 2017 and September 30, 2016, the Company did not have any equity investments accounted for under the cost method that were other-than-temporarily impaired and did not record any impairment charges.

[0001193125-17-323042:notes:75]
As of September 29, 2017 and June 30, 2017, the Company has $77 million held for sale assets included in Other current assets on the Condensed Consolidated Balance Sheets, which primarily consisted of $37 million of land and building in Korea and $26 million of land and building in China, with the remainder of the balance comprised of property at other locations (collectively, the “properties”). The respective properties to be sold met the criteria to be classified as held for sale during the quarters ended March 31, 2017 and June 30, 2017. Depreciation related to the properties ceased as of the date these were determined to be held for sale. During fiscal year 2017, the Company recorded impairment charges of $35 million to write down the carrying amount of such properties to their estimated fair values less costs to sell. The impairment charges were recorded in Operating expenses in the Consolidated Statement of Operations. No additional impairment charges related to these properties were recorded during the September 2017 quarter. The fair values were measured with the assistance of third-party valuation models which used inputs such as comparable market data for similar land sale transactions adjusted for differences in comparable properties to derive the estimated fair value of the subject properties and the cost approach valuation techniques for buildings as part of the analysis. The fair value measurement was categorized as Level 3 as significant unobservable inputs were used in the valuation analysis.

[0001193125-17-323042:notes:76]
[same as prior period, unchanged from 0001193125-17-148855:notes:90]

[0001193125-17-323042:notes:77]
[same as prior period, unchanged from 0001193125-17-148855:notes:91]

[0001193125-17-323042:notes:78]
|  |  | September 29, 2017 |  | June 30, 2017 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 688 |  |  | $ | 701 |  |  | $ | 710 |  |  | $ | 726 |  |
| 4.25% Senior Notes due March 2022 |  | 748 |  |  | 746 |  |  | 748 |  |  | 765 |  |
| 4.75% Senior Notes due June 2023 |  | 951 |  |  | 963 |  |  | 951 |  |  | 987 |  |
| 4.875% Senior Notes due March 2024 |  | 497 |  |  | 493 |  |  | 497 |  |  | 511 |  |
| 4.75% Senior Notes due January 2025 |  | 975 |  |  | 949 |  |  | 975 |  |  | 984 |  |
| 4.875% Senior Notes due June 2027 |  | 695 |  |  | 659 |  |  | 695 |  |  | 698 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 459 |  |  | 489 |  |  | 488 |  |
|  |  | $ | 5,043 |  |  | $ | 4,970 |  |  | $ | 5,065 |  |  | $ | 5,159 |  |
| Less: debt issuance costs |  | (41 | ) |  | — |  |  | (44 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 5,002 |  |  | $ | 4,970 |  |  | $ | 5,021 |  |  | $ | 5,159 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-17-323042:notes:79]
[same as prior period, unchanged from 0001193125-17-148855:notes:93]

[0001193125-17-323042:notes:80]
[same as prior period, unchanged from 0001193125-17-148855:notes:94]

[0001193125-17-323042:notes:81]
The changes in the carrying amount of goodwill for the three months ended September 29, 2017, are as follows:

[0001193125-17-323042:notes:82]
| (Dollars in millions) |  | Amount |
| Balance at June 30, 2017 |  | $ | 1,238 |  |
| Goodwill acquired |  | — |  |
| Goodwill disposed |  | (1 | ) |
| Foreign currency translation effect |  | — |  |
| Balance at September 29, 2017 |  | $ | 1,237 |  |

[0001193125-17-323042:notes:83]
[same as prior period, unchanged from 0001193125-17-148855:notes:97]

[0001193125-17-323042:notes:84]
Other intangible assets consist primarily of existing technology, customer relationships and trade names acquired in business combinations. Intangibles are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization is charged to Operating expenses in the Condensed Consolidated Statements of Operations.

[0001193125-17-323042:notes:85]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of September 29, 2017, is set forth in the following table:

[0001193125-17-323042:notes:86]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted-AverageRemaining Useful Life |
| Existing technology |  | $ | 279 |  |  | $ | (124 | ) |  | $ | 155 |  |  | 3.4 years |
| Customer relationships |  | 457 |  |  | (385 | ) |  | 72 |  |  | 3.7 years |
| Trade name |  | 17 |  |  | (10 | ) |  | 7 |  |  | 2.0 years |
| Other intangible assets |  | 35 |  |  | (14 | ) |  | 21 |  |  | 2.4 years |
| Total amortizable other intangible assets |  | $ | 788 |  |  | $ | (533 | ) |  | $ | 255 |  |  | 3.4 years |

[0001193125-17-323042:notes:87]
The carrying value of other intangible assets subject to amortization as of June 30, 2017 is set forth in the following table:

[0001193125-17-323042:notes:88]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted-AverageRemaining Useful Life |
| Existing technology |  | $ | 280 |  |  | $ | (112 | ) |  | $ | 168 |  |  | 3.6 years |
| Customer relationships |  | 487 |  |  | (395 | ) |  | 92 |  |  | 3.4 years |
| Trade name |  | 27 |  |  | (19 | ) |  | 8 |  |  | 2.1 years |
| Other intangible assets |  | 29 |  |  | (16 | ) |  | 13 |  |  | 2.6 years |
| Total amortizable other intangible assets |  | $ | 823 |  |  | $ | (542 | ) |  | $ | 281 |  |  | 3.4 years |

[0001193125-17-323042:notes:89]
For the three months ended September 29, 2017 and September 30, 2016, the amortization expense of other intangible assets were $36 million and $42 million, respectively. As of September 29, 2017, expected amortization expense for other intangible assets for each of the next five fiscal years and thereafter is as follows:

[0001193125-17-323042:notes:90]
| (Dollars in millions) |  | Amount |
| Remainder of 2018 |  | $ | 73 |  |
| 2019 |  | 71 |  |
| 2020 |  | 53 |  |
| 2021 |  | 25 |  |
| 2022 |  | 17 |  |
| Thereafter |  | 16 |  |
| Total |  | $ | 255 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-17-323042:notes:91]
[same as prior period, unchanged from 0001193125-17-148855:notes:106]

[0001193125-17-323042:notes:92]
The Company's income tax provision of $7 million in the three months ended September 29, 2017 included approximately $1 million of net discrete tax expense.

[0001193125-17-323042:notes:93]
The Company's income tax provision recorded for the three months ended September 29, 2017 differed from the provision from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.

[0001193125-17-323042:notes:94]
During the three months ended September 29, 2017, the Company’s unrecognized tax benefits excluding interest and penalties decreased by approximately $1 million to $73 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $73 million as of September 29, 2017, subject to certain future valuation allowance reversals. During the 12 months beginning September 30, 2017, the Company expects that its unrecognized tax benefits could be reduced by approximately $4 million, primarily as a result of the expiration of certain statutes of limitation.

[0001193125-17-323042:notes:95]
The Company's income tax provision of $6 million in the three months ended September 30, 2016 included approximately $5 million of net discrete tax benefits, primarily associated with the release of tax reserves associated with the expiration of certain statutes of limitation.

[0001193125-17-323042:notes:96]
The Company’s income tax provision recorded for the three months ended September 30, 2016 differed from the provision from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-17-323042:notes:97]
The fair value and amortized cost of the Company’s investments classified as available-for-sale as of September 29, 2017, by remaining contractual maturity were as follows:

[0001193125-17-323042:notes:98]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 830 |  |  | $ | 830 |  |
| Due in 1 to 5 years |  | — |  |  | — |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | — |  |  | — |  |
| Total |  | $ | 830 |  |  | $ | 830 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001193125-17-323042:notes:99]
Legal, Environmental and Other Contingencies

[0001193125-17-323042:notes:100]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001193125-17-323042:notes:101]
Intellectual Property Litigation

[0001193125-17-323042:notes:102]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al. On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “‘635 patent”) and U.S. Patent No. 5,638,267 (the “‘267 patent”), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe U.S. Patent No. 6,314,473 (the “‘473 patent”). The district court ruled in 2010 that the ‘267 patent was out of the case.

[0001193125-17-323042:notes:103]
On August 16, 2011, the district court granted in part and denied in part the Company’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-17-323042:notes:104]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al. On June 5, 2013, Enova Technology Corporation (“Enova”) filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995 (the “‘995 patent”), “Cryptographic Device,” and U.S. Patent No. 7,900,057 (the “‘057 patent”), “Cryptographic Serial ATA Apparatus and Method.” The Company believes the claims are without merit and intends to vigorously defend this case. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the ‘995 and ‘057 patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ‘057 patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 patent are held unpatentable. Enova appealed PTAB’s decisions on the ‘995 patent and the ‘057 patent to the U.S. Court of Appeals for the Federal Circuit. On March 20, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the ‘995 patent. On September 6, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the ‘057 patent. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-17-323042:notes:105]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017.  No trial date has been set. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-17-323042:notes:106]
Environmental Matters

[0001193125-17-323042:notes:107]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001193125-17-323042:notes:108]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001193125-17-323042:notes:109]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001193125-17-323042:notes:110]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001193125-17-323042:notes:111]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001193125-17-323042:notes:112]
Other Matters

[0001193125-17-323042:notes:113]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-17-323042:notes:114]
Recently Issued Accounting Pronouncements

[0001193125-17-323042:notes:115]
In May 2014, August 2015, April 2016, May 2016 and December 2016, the Financial Accounting Standards Board (“FASB”) issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, ASU 2016-12 (ASC Topic 606) Revenue from Contracts with Customers, Narrow-Scope Improvements and Practical Expedients, and ASU 2016-20 (ASC Topic 606) Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company is required to adopt the guidance in the first quarter of fiscal 2019. This standard may be applied retrospectively to all prior periods presented, or retrospectively with a cumulative adjustment to retained earnings in the year of adoption (“modified retrospective transition approach”). Based on its assessment, the Company plans to adopt the new revenue standard in the first quarter of fiscal 2019, utilizing the modified retrospective method of transition. While management has not yet completed its assessment of the impact of adopting this new standard on the Company’s consolidated financial statements, the Company expects the adoption of the new standard will result in the recognition of revenues generally upon shipment (sell-in basis) for sales of products to certain direct retail customers and customers in certain indirect retail channels which are currently being recognized on a sell-through basis. Accordingly, the Company will need to estimate variable consideration (e.g. rebates) related to customer incentives on these arrangements. These changes are not expected to have a material impact on the Company’s condensed consolidated financial statements.

[0001193125-17-323042:notes:116]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments—Overall Recognition and Measurement of Financial Assets and Financial Liabilities. The amendments in this ASU require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted for only certain portions of the ASU. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-17-323042:notes:117]
In February 2016, the FASB issued ASU 2016-02 (ASC Topic 842), Leases. The ASU amends a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The Company is required to adopt the guidance in the first quarter of fiscal 2020. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-17-323042:notes:118]
In January 2017, the FASB issued ASU 2017-01 (ASC Topic 805), Business Combination: Clarifying the Definition of a Business. The amendments in this ASU change the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-17-323042:notes:119]
In May 2017, the FASB issued ASU 2017-09 (ASC Topic 718), Stock Compensation: Scope of Modification Accounting. The amendments in this ASU provide guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-17-323042:notes:120]
Recently Adopted Accounting Pronouncements

[0001193125-17-323042:notes:121]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. This ASU became effective and was adopted by the Company in the September 2017 quarter on a prospective basis. The adoption of this guidance had no material impact on the Company’s condensed consolidated financial statements and disclosures.

[0001193125-17-323042:notes:122]
In March 2016, the FASB issued ASU 2016-09 (ASC Topic 718), Stock Compensation—Improvements to Employee Share-Based Payment Accounting. The amendments in this ASU are intended to simplify several areas of accounting for share-based compensation arrangements, including the income tax consequences, classification on the consolidated statement of cash flows and treatment of forfeitures. This ASU became effective and was adopted by the Company in the September 2017 quarter. Upon adoption, excess tax benefits or deficiencies from share-based award activity are reflected in the condensed consolidated statements of operations as a component of the provision for income taxes, whereas they previously were recognized in the Shareholder's equity in the condensed consolidated balance sheets. The Company also elected to continue to account for share-based compensation expense net of estimated forfeitures. The adoption of this ASU resulted in an increase in deferred tax assets relating to net operating losses of approximately $0.6 billion, offset by an equivalent increase in the valuation allowance with no impact to retained earnings. The adoption of this guidance had no material impact on the Company’s condensed consolidated financial statements and disclosures.

[0001193125-17-323042:notes:123]
In October 2016, the FASB issued ASU 2016-16 (ASC Topic 740), Income Taxes: Intra-Entity Transfers of Assets Other Than Inventory. The amendments in this ASU require the recognition of the income tax consequences for intra-entity transfers of assets other than inventory when the transfer occurs. The Company elected to adopt this ASU in the September 2017 quarter on a modified retrospective basis with no material impact on the Company's condensed consolidated financial statements and disclosures.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001193125-17-323042:notes:124]
[same as prior period, unchanged from 0001193125-17-148855:notes:144]

[0001193125-17-323042:notes:125]
[same as prior period, unchanged from 0001193125-17-148855:notes:145]

[0001193125-17-323042:notes:126]
Seagate Technology plc (the “Company”) is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSD”) and their related controllers, solid state hybrid drives (“SSHD”) and storage subsystems.

[0001193125-17-323042:notes:127]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data with most SSDs using NAND-based flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed data.

[0001193125-17-323042:notes:128]
The Company’s products are designed for mission critical and nearline applications in enterprise servers and storage systems; edge / client compute applications, where its products are designed primarily for desktop and mobile computing; and edge / client non-compute applications, where its products are designed for a wide variety of end user devices such as portable external storage systems, surveillance systems, network-attached storage (“NAS”), digital video recorders (“DVRs”) and gaming consoles.

[0001193125-17-323042:notes:129]
The Company’s cloud systems and solutions extend innovation from the device into the information infrastructure, onsite and in the cloud. Its portfolio includes modular original equipment manufacturers (“OEM”) storage systems and scale-out storage servers.

[0001193125-17-323042:notes:130]
[same as prior period, unchanged from 0001193125-17-148855:notes:150]

[0001193125-17-323042:notes:131]
The results of operations for the three months ended September 29, 2017, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending June 29, 2018. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three months ended September 29, 2017 and September 30, 2016 consisted of 13 weeks. Fiscal year 2018 will be comprised of 52 weeks and will end on June 29, 2018. The fiscal quarters ended September 29, 2017, June 30, 2017, and September 30, 2016, are also referred to herein as the “September 2017 quarter”, the “June 2017 quarter”, and the “September 2016 quarter”, respectively.

[0001193125-17-323042:notes:132]
[same as prior period, unchanged from 0001193125-17-148855:notes:152]

[0001193125-17-323042:notes:133]
There have been no significant changes in the Company's significant accounting policies. Please refer to Note 1 of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2017, as filed with the SEC on August 4, 2017 for a discussion of the Company’s other significant accounting policies.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-17-323042:notes:134]
[same as prior period, unchanged from 0001193125-17-148855:notes:154]

[0001193125-17-323042:notes:135]
[same as prior period, unchanged from 0001193125-17-148855:notes:155]

[0001193125-17-323042:notes:136]
On May 4, 2009, Seagate Technology, an exempted company incorporated with limited liability under the laws of the Cayman Islands (“Seagate-Cayman”), then the parent company, entered into a new form of indemnification agreement (the “Revised Indemnification Agreement”) with its officers and directors of Seagate-Cayman and its subsidiaries (each, an “Indemnitee”). The Revised Indemnification Agreement provides indemnification in addition to any of Indemnitee's indemnification rights under Seagate-Cayman's Articles of Association, applicable law or otherwise, and indemnifies an Indemnitee for certain expenses (including attorneys' fees), judgments, fines and settlement amounts actually and reasonably incurred by him or her in any action or proceeding, including any action by or in the right of Seagate-Cayman or any of its subsidiaries, arising out of his or her service as a director, officer, employee or agent of Seagate-Cayman or any of its subsidiaries or of any other entity to which he or she provides services at Seagate-Cayman's request. However, an Indemnitee shall not be indemnified under the Revised Indemnification Agreement for (i) any fraud or dishonesty in the performance of Indemnitee's duty to Seagate-Cayman or the applicable subsidiary of Seagate-Cayman or (ii) Indemnitee's conscious, intentional or willful failure to act honestly, lawfully and in good faith with a view to the best interests of Seagate-Cayman or the applicable subsidiary of Seagate-Cayman. In addition, the Revised Indemnification Agreement provides that Seagate-Cayman will advance expenses incurred by an Indemnitee in connection with enforcement of the Revised Indemnification Agreement or with the investigation, settlement or appeal of any action or proceeding against him or her as to which he or she could be indemnified.

[0001193125-17-323042:notes:137]
[same as prior period, unchanged from 0001193125-17-148855:notes:157]

[0001193125-17-323042:notes:138]
[same as prior period, unchanged from 0001193125-17-148855:notes:158]

[0001193125-17-323042:notes:139]
[same as prior period, unchanged from 0001193125-17-148855:notes:159]

[0001193125-17-323042:notes:140]
[same as prior period, unchanged from 0001193125-17-148855:notes:160]

[0001193125-17-323042:notes:141]
[same as prior period, unchanged from 0001193125-17-148855:notes:161]

[0001193125-17-323042:notes:142]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the three months ended September 29, 2017 and September 30, 2016 were as follows:

[0001193125-17-323042:notes:143]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 29, 2017 |  | September 30, 2016 |
| Balance, beginning of period |  | $ | 233 |  |  | $ | 206 |  |
| Warranties issued |  | 35 |  |  | 31 |  |
| Repairs and replacements |  | (27 | ) |  | (30 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | (11 | ) |  | 9 |  |
| Balance, end of period |  | $ | 230 |  |  | $ | 216 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-17-323042:notes:144]
[same as prior period, unchanged from 0001193125-17-148855:notes:164]

[0001193125-17-323042:notes:145]
| (Dollars in millions) |  | September 29, 2017 |  | June 30, 2017 |
| Property, equipment and leasehold improvements |  | $ | 9,529 |  |  | $ | 9,633 |  |
| Accumulated depreciation and amortization |  | (7,712 | ) |  | (7,758 | ) |
|  |  | $ | 1,817 |  |  | $ | 1,875 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-17-323042:notes:146]
[same as prior period, unchanged from 0001193125-17-148855:notes:166]

[0001193125-17-323042:notes:147]
For the three months ended September 29, 2017, the Company recorded restructuring charges of approximately $51 million, comprised primarily of charges related to workforce reduction costs and facility exit costs associated with the restructuring of its workforce during the fiscal year. The Company's significant restructuring plans are described below. All restructuring charges are reported in Restructuring and other, net on the Condensed Consolidated Statements of Operations.

[0001193125-17-323042:notes:148]
July 2017 Plan - On July 25, 2017, the Company committed to a restructuring plan (the “July 2017 Plan”) to reduce its cost structure. The July 2017 Plan included reducing the Company’s global headcount by approximately 600 employees. The July 2017 Plan was largely completed by the end of the September 2017 quarter.

[0001193125-17-323042:notes:149]
March 2017 Plan - On March 9, 2017, the Company committed to a restructuring plan (the “March 2017 Plan”) in connection with the continued consolidation of its global footprint. The Company closed its design center in Korea, resulting in the reduction of the Company’s headcount by approximately 300 employees. The March 2017 Plan was largely completed by the end of fiscal year 2017.

[0001193125-17-323042:notes:150]
July 2016 Plan—On July 11, 2016, the Company committed to a restructuring plan (the “July 2016 Plan”) for continued consolidation of its global footprint across Asia, EMEA and the Americas. The July 2016 Plan included reducing worldwide headcount by approximately 6,500 employees. The July 2016 Plan was largely completed by the end of fiscal year 2017.

[0001193125-17-323042:notes:151]
In addition, during fiscal year 2017, the Company committed to sell certain land and buildings primarily in Asia as part of the March 2017 and July 2016 plans which accordingly met the criteria to be classified as assets held for sale and were reclassified to Other current assets at that time. These assets remained included in Other current assets on the Condensed Consolidated Balance Sheet as of September 29, 2017.

[0001193125-17-323042:notes:152]
|  |  | July 2017 Plan |  | March 2017 Plan |  | July 2016 Plan |  | Other Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at June 30, 2017 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 22 |  |  | $ | 2 |  |  | $ | 6 |  |  | $ | 13 |  |  | $ | 43 |  |
| Restructuring charges |  | 38 |  |  | 4 |  |  | — |  |  | — |  |  | — |  |  | 6 |  |  | 2 |  |  | — |  |  | 50 |  |
| Cash payments |  | (14 | ) |  | (3 | ) |  | — |  |  | — |  |  | (16 | ) |  | (7 | ) |  | (4 | ) |  | (2 | ) |  | (46 | ) |
| Adjustments |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | (1 | ) |  | — |  |  | 1 |  |
| Accrual balances at September 29, 2017 |  | $ | 24 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 7 |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | 11 |  |  | $ | 48 |  |
| Total costs incurred to date as of September 29, 2017 |  | $ | 38 |  |  | $ | 4 |  |  | $ | 30 |  |  | $ | 3 |  |  | $ | 80 |  |  | $ | 26 |  |  | $ | 227 |  |  | $ | 50 |  |  | $ | 458 |  |
| Total expected costs to be incurred as of September 29, 2017 |  | $ | — |  |  | $ | 3 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 6 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 15 |  |


## us-gaap:ScheduleOfAccountsPayableAndAccruedLiabilitiesTableTextBlock

[0001193125-17-323042:notes:153]
[same as prior period, unchanged from 0001193125-17-148855:notes:172]

[0001193125-17-323042:notes:154]
| (Dollars in millions) |  | September 29, 2017 |  | June 30, 2017 |
| Dividends payable |  | $ | 182 |  |  | $ | 184 |  |
| Other accrued expenses |  | 476 |  |  | 466 |  |
| Total |  | $ | 658 |  |  | $ | 650 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-17-323042:notes:155]
[same as prior period, unchanged from 0001193125-17-148855:notes:174]

[0001193125-17-323042:notes:156]
| (Dollars in millions) |  | Unrealized Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Marketable Securities |  | Unrealized Gains (Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at June 30, 2017 |  | $ | — |  |  | $ | — |  |  | $ | (5 | ) |  | $ | (12 | ) |  | $ | (17 | ) |
| Other comprehensive income (loss) before reclassifications |  | — |  |  | — |  |  | — |  |  | 4 |  |  | 4 |  |
| Amounts reclassified from AOCI |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) |  | — |  |  | — |  |  | — |  |  | 4 |  |  | 4 |  |
| Balance at September 29, 2017 |  | $ | — |  |  | $ | — |  |  | $ | (5 | ) |  | $ | (8 | ) |  | $ | (13 | ) |
| Balance at July 1, 2016 |  | $ | (1 | ) |  | $ | — |  |  | $ | (7 | ) |  | $ | (17 | ) |  | $ | (25 | ) |
| Other comprehensive income (loss) before reclassifications |  | (1 | ) |  | — |  |  | — |  |  | 1 |  |  | — |  |
| Amounts reclassified from AOCI |  | 1 |  |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Other comprehensive income (loss) |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Balance at September 30, 2016 |  | $ | (1 | ) |  | $ | — |  |  | $ | (7 | ) |  | $ | (16 | ) |  | $ | (24 | ) |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-17-323042:notes:157]
[same as prior period, unchanged from 0001193125-17-148855:notes:177]

[0001193125-17-323042:notes:158]
| (Dollars in millions) |  | September 29, 2017 |  | June 30, 2017 |
| Raw materials and components |  | $ | 327 |  |  | $ | 350 |  |
| Work-in-process |  | 275 |  |  | 257 |  |
| Finished goods |  | 412 |  |  | 375 |  |
|  |  | $ | 1,014 |  |  | $ | 982 |  |


## us-gaap:ScheduleOfRestrictedCashAndCashEquivalentsTextBlock

[0001193125-17-323042:notes:159]
[same as prior period, unchanged from 0001193125-17-148855:notes:179]

[0001193125-17-323042:notes:160]
| (Dollars in millions) |  | September 29, 2017 |  | June 30, 2017 |  | September 30, 2016 |  | July 1, 2016 |
| Cash and cash equivalents |  | $ | 2,285 |  |  | $ | 2,539 |  |  | $ | 1,489 |  |  | $ | 1,125 |  |
| Restricted cash included in Other current assets |  | 4 |  |  | 4 |  |  | 6 |  |  | 7 |  |
| Total cash, cash equivalents, and restricted cash shown in the Statements of Cash Flows |  | $ | 2,289 |  |  | $ | 2,543 |  |  | $ | 1,495 |  |  | $ | 1,132 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-17-323042:notes:161]
[same as prior period, unchanged from 0001193125-17-148855:notes:181]

[0001193125-17-323042:notes:162]
[same as prior period, unchanged from 0001193125-17-148855:notes:182]

[0001193125-17-323042:notes:163]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 289,261,062 shares were outstanding as of September 29, 2017, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of September 29, 2017.

[0001193125-17-323042:notes:164]
Ordinary shares—Holders of ordinary shares are entitled to receive dividends as and when declared by the Company’s board of directors (the “Board of Directors”). Upon any liquidation, dissolution, or winding up of the Company, after required payments are made to holders of preferred shares, any remaining assets of the Company will be distributed ratably to holders of the preferred and ordinary shares. Holders of shares are entitled to one vote per share on all matters upon which the ordinary shares are entitled to vote, including the election of directors.

[0001193125-17-323042:notes:165]
[same as prior period, unchanged from 0001193125-17-148855:notes:185]

[0001193125-17-323042:notes:166]
[same as prior period, unchanged from 0001193125-17-148855:notes:186]

[0001193125-17-323042:notes:167]
[same as prior period, unchanged from 0001193125-17-148855:notes:187]

[0001193125-17-323042:notes:168]
On April 22, 2015, the Board of Directors authorized the Company to repurchase $2.5 billion of its outstanding ordinary shares.

[0001193125-17-323042:notes:169]
[same as prior period, unchanged from 0001193125-17-148855:notes:189]

[0001193125-17-323042:notes:170]
As of September 29, 2017, $1.1 billion remained available for repurchase under the existing repurchase authorization limit.


## us-gaap:SubsequentEventsTextBlock

[0001193125-17-323042:notes:171]
Subsequent Events

[0001193125-17-323042:notes:172]
Dividend Declared

[0001193125-17-323042:notes:173]
On October 23, 2017, the Company’s Board of Directors approved and declared a quarterly cash dividend of $0.63 per share, which will be payable on January 3, 2018 to shareholders of record as of the close of business on December 20, 2017.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-17-323042:notes:174]
[same as prior period, unchanged from 0001193125-17-148855:notes:191]

[0001193125-17-323042:notes:175]
[same as prior period, unchanged from 0001193125-17-148855:notes:192]

[0001193125-17-323042:notes:176]
As of September 29, 2017, the Company’s Other current assets included $4 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001193125-17-323042:notes:177]
As of September 29, 2017, the Company had no material available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined that no available-for-sale securities were other-than-temporarily impaired as of September 29, 2017.

[0001193125-17-323042:notes:178]
As of June 30, 2017, the Company’s Other current assets included $4 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001193125-17-323042:notes:179]
As of June 30, 2017, the Company had no material available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale securities were other-than-temporarily impaired as of June 30, 2017.

[0001193125-17-323042:notes:180]
[same as prior period, unchanged from 0001193125-17-148855:notes:197]

[0001193125-17-323042:notes:181]
[same as prior period, unchanged from 0001193125-17-148855:notes:198]

[0001193125-17-323042:notes:182]
[same as prior period, unchanged from 0001193125-17-148855:notes:199]

[0001193125-17-323042:notes:183]
[same as prior period, unchanged from 0001193125-17-148855:notes:200]

[0001193125-17-323042:notes:184]
[same as prior period, unchanged from 0001193125-17-148855:notes:201]
