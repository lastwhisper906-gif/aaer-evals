# STX MD&A — 0001193125-17-323042


## mdna

[0001193125-17-323042:mdna:1]
[same as prior period, unchanged from 0001193125-17-148855:mdna:1]

[0001193125-17-323042:mdna:2]
The following is a discussion of the financial condition, changes in financial condition, and results of operations for our fiscal quarters
ended September 29, 2017, June 30, 2017 and September 30, 2016, referred to herein as the “September 2017 quarter,” the “June 2017 quarter,” and the “September 2016 quarter,” respectively. We operate
and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The September 2017, June 2017 and September 2016 quarters were all 13 weeks.

[0001193125-17-323042:mdna:3]
You should read this discussion in conjunction with financial information and related notes included elsewhere in this report.
Unless the context indicates otherwise, as used herein, the terms “we,” “us,” “Seagate,” the “Company” and “our” refer to Seagate Technology plc, an Irish public limited company, and its
subsidiaries. References to “$” are to United States dollars.

[0001193125-17-323042:mdna:4]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is
provided in addition to the accompanying condensed consolidated financial statements and notes to assist readers in understanding our results of operations, financial condition, and cash flows. MD&A is organized as follows:

[0001193125-17-323042:mdna:5]
[same as prior period, unchanged from 0001193125-17-148855:mdna:5]

[0001193125-17-323042:mdna:6]
|  | • |  | Overview of the September 2017 Quarter. Highlights of events in the September 2017 quarter that impacted our financial position. |

[0001193125-17-323042:mdna:7]
|  | • |  | Results of Operations. An analysis of our financial results comparing the September 2017 quarter to the June 2017 quarter and the September 2016 quarter. |

[0001193125-17-323042:mdna:8]
[same as prior period, unchanged from 0001193125-17-148855:mdna:8]

[0001193125-17-323042:mdna:9]
|  | • |  | Contractual Obligations and Commitments. Overview of contractual obligations and contingent liabilities and commitments outstanding as of September 29, 2017. |

[0001193125-17-323042:mdna:10]
[same as prior period, unchanged from 0001193125-17-148855:mdna:9]

[0001193125-17-323042:mdna:11]
[same as prior period, unchanged from 0001193125-17-148855:mdna:11]

[0001193125-17-323042:mdna:12]
We are a leading provider of data storage technology and solutions. Our principal products are hard disk drives, commonly
referred to as disk drives, hard drives or HDDs. In addition to HDDs, we produce a broad range of data storage products including solid state drives (“SSD”) and their related controllers, solid state hybrid drives (“SSHD”) and
storage subsystems.

[0001193125-17-323042:mdna:13]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with
magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use
integrated circuit assemblies as memory to store data with most SSDs using NAND-based flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to
improve performance of frequently accessed data.

[0001193125-17-323042:mdna:14]
Our products are designed for mission critical and nearline applications
in enterprise servers and storage systems; edge / client compute applications, where our products are designed primarily for desktop and mobile computing; and edge / client non-compute applications,
where our products are designed for a wide variety of end user devices such as portable external storage systems, surveillance systems, network-attached storage (“NAS”), digital video recorders (“DVRs”) and gaming consoles.

[0001193125-17-323042:mdna:15]
Our cloud systems and solutions extend innovation from the device into the information infrastructure, onsite and in the
cloud. Our portfolio includes modular original equipment manufacturer (“OEM”) storage systems and scale-out storage servers.

[0001193125-17-323042:mdna:16]
Overview of the September 2017 Quarter

[0001193125-17-323042:mdna:17]
During the September 2017 quarter, we shipped 70 exabytes of HDD storage capacity, generating revenue of approximately
$2.6 billion and gross margin of 28%. Our operating cash flow was $237 million. We repurchased 5 million ordinary shares for $166 million and paid dividends of $184 million.

[0001193125-17-323042:mdna:18]
[same as prior period, unchanged from 0001193125-17-148855:mdna:18]

[0001193125-17-323042:mdna:19]
We list in the tables below summarized information from our Condensed Consolidated Statements of Operations by dollars and as a
percentage of revenue:

[0001193125-17-323042:mdna:20]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | September 29,2017 |  |  | June 30,2017 |  |  | September 30,2016 |  |
| Revenue |  | $ | 2,632 |  |  | $ | 2,406 |  |  | $ | 2,797 |  |
| Cost of revenue |  |  | 1,896 |  |  |  | 1,740 |  |  |  | 1,996 |  |
| Gross margin |  |  | 736 |  |  |  | 666 |  |  |  | 801 |  |
| Product development |  |  | 263 |  |  |  | 288 |  |  |  | 315 |  |
| Marketing and administrative |  |  | 145 |  |  |  | 149 |  |  |  | 155 |  |
| Amortization of intangibles |  |  | 22 |  |  |  | 19 |  |  |  | 28 |  |
| Restructuring and other, net |  |  | 51 |  |  |  | 14 |  |  |  | 82 |  |
| Income from operations |  |  | 255 |  |  |  | 196 |  |  |  | 221 |  |
| Other expense, net |  |  | (67) |  |  |  | (76) |  |  |  | (48) |  |
| Income before income taxes |  |  | 188 |  |  |  | 120 |  |  |  | 173 |  |
| Provision for income taxes |  |  | 7 |  |  |  | 6 |  |  |  | 6 |  |
| Net income |  | $ | 181 |  |  | $ | 114 |  |  | $ | 167 |  |

[0001193125-17-323042:mdna:21]
|  |  | For the Three Months Ended |  |
|  |  | September 29,2017 |  |  | June 30,2017 |  |  | September 30,2016 |  |
| Revenue |  |  | 100% |  |  |  | 100% |  |  |  | 100% |  |
| Cost of revenue |  |  | 72 |  |  |  | 72 |  |  |  | 71 |  |
| Gross margin |  |  | 28 |  |  |  | 28 |  |  |  | 29 |  |
| Product development |  |  | 10 |  |  |  | 12 |  |  |  | 11 |  |
| Marketing and administrative |  |  | 5 |  |  |  | 6 |  |  |  | 6 |  |
| Amortization of intangibles |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |
| Restructuring and other, net |  |  | 2 |  |  |  | 1 |  |  |  | 3 |  |
| Income from operations |  |  | 10 |  |  |  | 8 |  |  |  | 8 |  |
| Other expense, net |  |  | (3) |  |  |  | (3) |  |  |  | (2) |  |
| Income before income taxes |  |  | 7 |  |  |  | 5 |  |  |  | 6 |  |
| Provision for income taxes |  |  | — |  |  |  | — |  |  |  | — |  |
| Net income |  |  | 7% |  |  |  | 5% |  |  |  | 6% |  |

[0001193125-17-323042:mdna:22]
28

[0001193125-17-323042:mdna:23]
[same as prior period, unchanged from 0001193125-17-148855:mdna:23]

[0001193125-17-323042:mdna:24]
The following table summarizes HDD information regarding average drive selling prices (“ASPs”), exabytes shipped, and
revenues by channel and geography:

[0001193125-17-323042:mdna:25]
|  |  | For the Three Months Ended |  |
|  |  | September 29,2017 |  |  | June 30,2017 |  |  | September 30,2016 |  |
| ASPs (per unit) |  | $ | 64 |  |  | $ | 64 |  |  | $ | 67 |  |
| Exabytes Shipped |  |  | 70 |  |  |  | 62 |  |  |  | 67 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  |  | 67 | % |  |  | 67 | % |  |  | 70 | % |
| Distributors |  |  | 17 | % |  |  | 18 | % |  |  | 18 | % |
| Retailers |  |  | 16 | % |  |  | 15 | % |  |  | 12 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  |  | 26 | % |  |  | 28 | % |  |  | 33 | % |
| EMEA |  |  | 18 | % |  |  | 18 | % |  |  | 15 | % |
| Asia Pacific |  |  | 56 | % |  |  | 54 | % |  |  | 52 | % |

[0001193125-17-323042:mdna:26]
Revenue in the September 2017 quarter increased by $226 million from the June 2017
quarter as a result of an increase in exabytes shipped, partially offset by price erosion.

[0001193125-17-323042:mdna:27]
Revenue in the September 2017
quarter decreased by $165 million from the September 2016 quarter primarily as a result of price erosion partially offset by an increase in exabytes shipped.

[0001193125-17-323042:mdna:28]
We maintain various sales programs such as channel rebates and price masking. Sales programs were approximately 11%, 12% and
10% of gross drive revenue for the September 2017 quarter, June 2017 quarter and September 2016 quarter, respectively. Adjustments to revenues due to under or over accruals for sales programs related to revenues reported in prior quarterly periods
were less than 1% of quarterly gross revenue in all periods presented.

[0001193125-17-323042:mdna:29]
[same as prior period, unchanged from 0001193125-17-148855:mdna:30]

[0001193125-17-323042:mdna:30]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | September 29,2017 |  |  | June 30,2017 |  |  | September 30,2016 |  |
| Cost of revenue |  | $ | 1,896 |  |  | $ | 1,740 |  |  | $ | 1,996 |  |
| Gross margin |  |  | 736 |  |  |  | 666 |  |  |  | 801 |  |
| Gross margin percentage |  |  | 28 | % |  |  | 28 | % |  |  | 29 | % |

[0001193125-17-323042:mdna:31]
Gross margin as a percentage of revenue for the September 2017 quarter remained flat from the
June 2017 quarter due to improved product mix offset by price erosion. Compared to the September 2016 quarter, gross margin as a percentage of revenue decreased by 100 basis points driven by price erosion, partially offset by favorable product mix
and improved factory utilization resulting from cost savings due to our workforce reductions and manufacturing consolidation activities.

[0001193125-17-323042:mdna:32]
In the September 2017 quarter, total warranty cost was below the historical range of 1% to 1.5% of revenue and included a
favorable change in estimates of prior warranty accruals of less than 0.5% of revenue. Warranty cost related to new shipments was 1.3%, 1.4%, and 1.1% of revenue for each of the September 2017, June 2017 and September 2016 quarters, respectively.

[0001193125-17-323042:mdna:33]
[same as prior period, unchanged from 0001193125-17-148855:mdna:35]

[0001193125-17-323042:mdna:34]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | September 29,2017 |  |  | June 30,2017 |  |  | September 30,2016 |  |
| Product development |  | $ | 263 |  |  | $ | 288 |  |  | $ | 315 |  |
| Marketing and administrative |  |  | 145 |  |  |  | 149 |  |  |  | 155 |  |
| Amortization of intangibles |  |  | 22 |  |  |  | 19 |  |  |  | 28 |  |
| Restructuring and other, net |  |  | 51 |  |  |  | 14 |  |  |  | 82 |  |
| Operating expenses |  | $ | 481 |  |  | $ | 470 |  |  | $ | 580 |  |

[0001193125-17-323042:mdna:35]
29

[0001193125-17-323042:mdna:36]
Product development expense. Product development expense for the
September 2017 quarter decreased by $25 million from the June 2017 quarter due to a $10 million decrease in salaries and employee benefits as a result of the restructuring of our workforce in prior periods and a $20 million decrease
due to related operational efficiencies, offset by a $6 million increase in variable compensation and share-based compensation expenses.

[0001193125-17-323042:mdna:37]
Compared to the September 2016 quarter, product development expense decreased by $52 million due to a $20 million
decrease in salaries and employee benefits as a result of the restructuring of our workforce in prior periods, a $21 million decrease due to related operational efficiencies and an $11 million decrease in variable compensation and
share-based compensation expenses.

[0001193125-17-323042:mdna:38]
Marketing and administrative expense. Marketing and administrative expense
for the September 2017 quarter decreased by $4 million from the June 2017 quarter primarily due to a decrease in salaries and related benefits as a result of the restructuring of our workforce in prior periods offset by an increase in variable
compensation and share-based compensation expenses.

[0001193125-17-323042:mdna:39]
Compared to the September 2016 quarter, marketing and administrative
expense decreased by $10 million primarily due to a decrease in salaries and related benefits as a result of the restructuring of our workforce in prior periods and a decrease in variable compensation and share-based compensation expenses.

[0001193125-17-323042:mdna:40]
Amortization of intangibles. Amortization of intangibles for the September 2017 quarter stayed flat from the June
2017 quarter. Amortization of intangibles for the September 2017 quarter decreased by $6 million from the September 2016 quarter due to certain intangible assets reaching the end of their useful life.

[0001193125-17-323042:mdna:41]
Restructuring and other, net. Restructuring and other, net for the September 2017 quarter was comprised of
restructuring charges to reduce our global workforce by 600 employees. Restructuring and other, net for the June 2017 quarter was comprised of restructuring charges announced in prior periods. Restructuring and other, net for the September 2016
quarter was comprised of restructuring charges to reduce our global workforce by 6,500 employees. Each of these restructuring activities have reduced our workforce as we continue to consolidate our global footprint across Asia, EMEA and the
Americas. See “Part I, Item 1. Financial Statements—Note 7. Restructuring and Exit Costs” for more details.

[0001193125-17-323042:mdna:42]
Other
Expense, Net

[0001193125-17-323042:mdna:43]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | September 29,2017 |  |  | June 30,2017 |  |  | September 30,2016 |  |
| Other expense, net |  | $ | (67 | ) |  | $ | (76 | ) |  | $ | (48 | ) |

[0001193125-17-323042:mdna:44]
Other expense, net decreased by $9 million from the June 2017 quarter primarily due to a
$7 million loss on redemption and repurchase of debt in the June 2017 quarter which did not recur in the September 2017 quarter.

[0001193125-17-323042:mdna:45]
Compared to the September 2016 quarter, Other expense, net increased by $19 million primarily due to a $15 million
increase in interest expense on the issuance of $750 million of 4.25% Senior Notes due 2022 and $500 million of 4.875% Senior Notes due 2024 in the quarter ended March 31, 2017.

[0001193125-17-323042:mdna:46]
[same as prior period, unchanged from 0001193125-17-148855:mdna:52]

[0001193125-17-323042:mdna:47]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | September 29,2017 |  |  | June 30,2017 |  |  | September 30,2016 |  |
| Provision for income taxes |  | $ | 7 |  |  | $ | 6 |  |  | $ | 6 |  |

[0001193125-17-323042:mdna:48]
Our income tax provision of $7 million for the September 2017 quarter included
approximately $1 million of net discrete tax expense.

[0001193125-17-323042:mdna:49]
Our income tax provision recorded for the September 2017
quarter differed from the provision from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to
non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation
allowance for certain deferred tax assets.

[0001193125-17-323042:mdna:50]
In the September 2017 quarter, we adopted two accounting pronouncements with tax
implications—ASU 2016-09 (related to employee share-based payment accounting) and ASU 2016-16 (related to intra-entity transfers of assets).
There was no material impact to our financial statements as a result of the adoptions. However, the adoption of ASU 2016-09, resulted in an increase in gross deferred tax assets relating to net operating losses of approximately $0.6 billion
offset by an equivalent increase in valuation allowance. For additional detail about both ASU’s, please refer to “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting
Policies”.

[0001193125-17-323042:mdna:51]
During the three months ended September 29, 2017, our unrecognized tax benefits excluding interest
and penalties decreased by approximately $1 million to $73 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $73 million as of September 29, 2017, subject to certain future
valuation allowance reversals. During the 12 months beginning September 30, 2017, we expect that our unrecognized tax benefits could be reduced by approximately $4 million, primarily as a result of the expiration of certain statutes of
limitation.

[0001193125-17-323042:mdna:52]
Our income tax provision recorded for the September 2016 quarter included approximately $6 million of
net discrete tax benefits, primarily associated with the release of tax reserves associated with the expiration of certain statutes of limitation.

[0001193125-17-323042:mdna:53]
Our income tax provision recorded for the September 2016 quarter differed from the provision from income taxes that would be
derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are
subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.

[0001193125-17-323042:mdna:54]
[same as prior period, unchanged from 0001193125-17-148855:mdna:60]

[0001193125-17-323042:mdna:55]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity
and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist primarily of money market funds, time deposits and
certificates of deposit. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents and short-term investments are liquid and accessible. We operate in some
countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash have been and will continue to be sufficient to meet our cash needs for the
next 12 months. We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term investments.

[0001193125-17-323042:mdna:56]
Cash and Cash Equivalents and Short-term Investments

[0001193125-17-323042:mdna:57]
| (Dollars in millions) |  | September 29,2017 |  |  | June 30,2017 |  |  | Change |  |
| Cash and cash equivalents |  | $ | 2,285 |  |  | $ | 2,539 |  |  | $ | (254 | ) |

[0001193125-17-323042:mdna:58]
Our cash and cash equivalents decreased from June 30, 2017 as a result of net cash
outflows for dividends paid to our shareholders, repurchase of our ordinary shares, capital expenditures, and repayments of long-term debt. These cash outflows were partially offset by our net cash provided by operating activities.

[0001193125-17-323042:mdna:59]
[same as prior period, unchanged from 0001193125-17-148855:mdna:65]

[0001193125-17-323042:mdna:60]
Cash provided by operating activities for the three months ended September 29, 2017 of $237 million includes the
effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, and:

[0001193125-17-323042:mdna:61]
|  | • |  | a decrease of $87 million in accrued employee compensation, primarily due to cash paid to our employees as part of our variable compensation plans in the September 2017 quarter; |

[0001193125-17-323042:mdna:62]
|  | • |  | an increase of $32 million in inventory, primarily due to an increase in units built; and |

[0001193125-17-323042:mdna:63]
|  | • |  | a decrease of $30 million in accounts payable, primarily due to timing of payments for material purchases. |

[0001193125-17-323042:mdna:64]
[same as prior period, unchanged from 0001193125-17-148855:mdna:70]

[0001193125-17-323042:mdna:65]
Cash used for investing activities for the three months ended September 29, 2017 was $132 million, which was
primarily attributable to the payments for the purchase of property, equipment and leasehold improvements of $124 million.

[0001193125-17-323042:mdna:66]
[same as prior period, unchanged from 0001193125-17-148855:mdna:73]

[0001193125-17-323042:mdna:67]
Cash used in financing activities of $363 million for the three months ended September 29, 2017 was primarily
attributable to the following activities:

[0001193125-17-323042:mdna:68]
|  | • |  | $184 million in dividend payments; |

[0001193125-17-323042:mdna:69]
|  | • |  | $166 million paid to repurchase ordinary shares; |

[0001193125-17-323042:mdna:70]
|  | • |  | $22 million of redemption and repayments of long-term debt; |

[0001193125-17-323042:mdna:71]
|  | • |  | $20 million paid for taxes related to net share settlement of equity awards, partially offset by; |

[0001193125-17-323042:mdna:72]
|  | • |  | $29 million in proceeds from the issuance of ordinary shares under employee stock plans. |

[0001193125-17-323042:mdna:73]
Liquidity
Sources, Cash Requirements and Commitments

[0001193125-17-323042:mdna:74]
Our primary sources of liquidity as of September 29, 2017
consisted of: (1) approximately $2.3 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) a $700 million senior revolving credit facility.

[0001193125-17-323042:mdna:75]
As of September 29, 2017, no borrowings had been drawn under the revolving credit facility or had been utilized for
letters of credit issued under this credit facility. The line of credit is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001193125-17-323042:mdna:76]
The credit agreement that governs our revolving credit facility, as amended, includes three financial covenants:
(1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. On April 28, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net
leverage ratio to adjust for our current financial liquidity position. The term of the revolving credit facility is through January 15, 2020 provided that if we do not have Investment Grade Ratings (as defined in the revolving credit facility)
on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. We were in compliance with the modified covenants as of September 29, 2017 and expect to be in compliance for
the next 12 months.

[0001193125-17-323042:mdna:77]
Our liquidity requirements are primarily to meet our working capital, product development and capital
expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend. Our ability to fund these requirements will depend on our future cash flows, which are determined by future operating
performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001193125-17-323042:mdna:78]
For fiscal year 2018, we expect capital expenditures to be less than 5% of revenue.

[0001193125-17-323042:mdna:79]
From time to time we may repurchase any of our outstanding notes in open market or privately negotiated purchases or
otherwise, or may repurchase outstanding notes pursuant to the terms of the applicable indenture.

[0001193125-17-323042:mdna:80]
Dividends declared in
the September 2017 quarter of $182 million were subsequently paid on October 4, 2017. The Company’s Board of Directors declared a quarterly cash dividend of $0.63 per share on October 23, 2017, which is payable on January 3,
2018 to shareholders of record at the close of business on December 20, 2017.

[0001193125-17-323042:mdna:81]
From time to time we may repurchase
any of our outstanding ordinary shares through private, open market, or broker assisted purchases. As of September 29, 2017, $1.1 billion remained available for repurchase under our existing repurchase authorization limit. All
repurchases are effected as redemptions in accordance with the Company’s Articles of Association.

[0001193125-17-323042:mdna:82]
[same as prior period, unchanged from 0001193125-17-148855:mdna:92]

[0001193125-17-323042:mdna:83]
Our contractual cash obligations and commitments as of September 29, 2017, have been summarized in the table below:

[0001193125-17-323042:mdna:84]
|  |  |  |  |  | Fiscal Year(s) |  |
| (Dollars in millions) |  | Total |  |  | Remainder of2018 |  |  | 2019-2020 |  |  | 2021-2022 |  |  | Thereafter |  |
| Contractual Cash Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | $ | 5,051 |  |  | $ | — |  |  | $ | 688 |  |  | $ | 750 |  |  | $ | 3,613 |  |
| Interest payments on debt |  |  | 1,792 |  |  |  | 184 |  |  |  | 433 |  |  |  | 420 |  |  |  | 755 |  |
| Purchase obligations (2) |  |  | 857 |  |  |  | 857 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Operating leases (1) |  |  | 132 |  |  |  | 15 |  |  |  | 28 |  |  |  | 15 |  |  |  | 74 |  |
| Capital expenditures |  |  | 95 |  |  |  | 94 |  |  |  | 1 |  |  |  | — |  |  |  | — |  |
| Other funding requirements (3) |  |  | 26 |  |  |  | 12 |  |  |  | 14 |  |  |  | — |  |  |  | — |  |
| Subtotal |  |  | 7,953 |  |  |  | 1,162 |  |  |  | 1,164 |  |  |  | 1,185 |  |  |  | 4,442 |  |
| Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit or bank guarantees |  |  | 104 |  |  |  | 100 |  |  |  | 4 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 8,057 |  |  | $ | 1,262 |  |  | $ | 1,168 |  |  | $ | 1,185 |  |  | $ | 4,442 |  |

[0001193125-17-323042:mdna:85]
[same as prior period, unchanged from 0001193125-17-148855:mdna:95]

[0001193125-17-323042:mdna:86]
[same as prior period, unchanged from 0001193125-17-148855:mdna:96]

[0001193125-17-323042:mdna:87]
| (2) | Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and |

[0001193125-17-323042:mdna:88]
legally binding on us, and that specify all significant terms.

[0001193125-17-323042:mdna:89]
[same as prior period, unchanged from 0001193125-17-148855:mdna:98]

[0001193125-17-323042:mdna:90]
On September 28, 2017, we entered into an Equity Commitment Letter (“ECL”) with a consortium of investors led
by Bain Capital Private Equity for the acquisition of Toshiba Memory Corporation (“TMC”). The ECL contemplates that, upon the closing of the acquisition, we would purchase up to JPY 139.5 billion (approximately USD 1.25 billion
based on current exchange rates), of a newly issued non-convertible preferred equity security of a newly formed company, K. K. Pangea, for the purpose of acquiring TMC. The closing of the acquisition is
subject to regulatory approvals and other closing conditions.

[0001193125-17-323042:mdna:91]
As of September 29, 2017, we had a liability for
unrecognized tax benefits and an accrual for the payment of related interest totaling $14 million, none of which is expected to be settled within one year. Outside of one year, we are unable to make a reasonably reliable estimate of when
cash settlement with a taxing authority will occur.

[0001193125-17-323042:mdna:92]
[same as prior period, unchanged from 0001193125-17-148855:mdna:100]

[0001193125-17-323042:mdna:93]
Our discussion and analysis of financial condition and results of operations are based upon our Condensed Consolidated
Financial Statements, which have been prepared in accordance with U.S. generally accepted accounting principles. The preparation of such statements requires us to make estimates and assumptions that affect the reported amounts of revenues and
expenses during the reporting period and the reported amounts of assets and liabilities as of the date of the financial statements. Our estimates are based on historical experience and other assumptions that we consider to be appropriate in the
circumstances. However, actual future results may vary from our estimates.

[0001193125-17-323042:mdna:94]
Since our fiscal year ended June 30,
2017, there have been no material changes in our critical accounting policies and estimates. Refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in
Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended June 30, 2017, as filed with the SEC on August 4, 2017, for a discussion of our critical accounting
policies and estimates.

[0001193125-17-323042:mdna:95]
[same as prior period, unchanged from 0001193125-17-148855:mdna:103]

[0001193125-17-323042:mdna:96]
See “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of
Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.

[0001193125-17-323042:mdna:97]
[same as prior period, unchanged from 0001193125-17-148855:mdna:42]
