# STX MD&A — 0001104659-16-092467


## mdna

[0001104659-16-092467:mdna:1]
ITEM 2.            MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001104659-16-092467:mdna:2]
The following is a discussion of the financial condition, changes in financial condition, and results of operations for our fiscal quarters ended January 1, 2016, October 2, 2015, and January 2, 2015, referred to herein as the “December 2015 quarter”, the “September 2015 quarter”, and the “December 2014 quarter”, respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The December 2015, September 2015, and December 2014 quarters were 13 weeks.

[0001104659-16-092467:mdna:3]
You should read this discussion in conjunction with financial information and related notes included elsewhere in this report. Unless the context indicates otherwise, as used herein, the terms “we,” “us,” “Seagate,” the “Company” and “our” refer to Seagate Technology plc, an Irish public limited company, and its subsidiaries. References to “$” are to United States dollars.

[0001104659-16-092467:mdna:4]
[same as prior period, unchanged from 0001104659-15-074539:mdna:4]

[0001104659-16-092467:mdna:5]
·                  Our Company. Overview of our business.

[0001104659-16-092467:mdna:6]
·                  Overview of the December 2015 quarter. Highlights of events in the December 2015 quarter that impacted our financial position.

[0001104659-16-092467:mdna:7]
·                  Results of Operations. An analysis of our financial results comparing the December 2015 quarter to the September 2015 quarter and the December 2014 quarter.

[0001104659-16-092467:mdna:8]
·                  Liquidity and Capital Resources. An analysis of changes in our balance sheets and cash flows, and discussion of our financial condition including the credit quality of our investment portfolio and potential sources of liquidity.

[0001104659-16-092467:mdna:9]
·                  Critical Accounting Policies. Accounting policies and estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001104659-16-092467:mdna:10]
32

[0001104659-16-092467:mdna:11]
[same as prior period, unchanged from 0001104659-15-074539:mdna:10]

[0001104659-16-092467:mdna:12]
We are a leading provider of electronic data storage technology and solutions. Our principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, we produce a broad range of electronic data storage products including solid state hybrid drives (“SSHD”), solid state drives (“SSD”), PCIe cards and SATA controllers. Our storage technology portfolio also includes storage subsystems, high performance computing (“HPC”) solutions, and data storage services.

[0001104659-16-092467:mdna:13]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and most SSDs use NAND-based flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed data.

[0001104659-16-092467:mdna:14]
[same as prior period, unchanged from 0001104659-15-074539:mdna:15]

[0001104659-16-092467:mdna:15]
Our product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and HPC data storage solutions. Our storage subsystems support a range of high-speed interconnect technologies to meet demanding cost and performance specifications. Our modular subsystem architecture allows us to support many segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.

[0001104659-16-092467:mdna:16]
Overview of the December 2015 Quarter

[0001104659-16-092467:mdna:17]
During the December 2015 quarter, we shipped 46 million drive units totaling 61 exabytes of storage capacity, generating revenue of approximately $3.0 billion and gross margin of 25%. Our operating cash flow was $382 million. We repurchased $107 million in ordinary shares and paid $188 million for dividends to shareholders. Additionally, we completed our acquisition of Dot Hill Systems Corp. (“Dot Hill”), a supplier of software and hardware storage systems for $674 million in cash.

[0001104659-16-092467:mdna:18]
[same as prior period, unchanged from 0001104659-15-074539:mdna:20]

[0001104659-16-092467:mdna:19]
[same as prior period, unchanged from 0001104659-15-074539:mdna:21]

[0001104659-16-092467:mdna:20]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |
| (Dollars in millions) |  | January 1, 2016 |  | October 2, 2015 |  | January 2, 2015 |  | January 1, 2016 |  | January 2, 2015 |  |
| Revenue |  | $ | 2,986 |  | $ | 2,925 |  | $ | 3,696 |  | $ | 5,911 |  | $ | 7,481 |  |
| Cost of revenue |  | 2,245 |  | 2,236 |  | 2,669 |  | 4,482 |  | 5,403 |  |
| Gross margin |  | 741 |  | 689 |  | 1,027 |  | 1,429 |  | 2,078 |  |
| Product development |  | 304 |  | 328 |  | 341 |  | 632 |  | 683 |  |
| Marketing and administrative |  | 160 |  | 182 |  | 218 |  | 341 |  | 434 |  |
| Amortization of intangibles |  | 31 |  | 34 |  | 32 |  | 65 |  | 62 |  |
| Restructuring and other, net |  | 17 |  | 59 |  | 3 |  | 76 |  | 10 |  |
| Gain on litigation settlement, net |  | — |  | — |  | (620 | ) | — |  | (620 | ) |
| Income from operations |  | 229 |  | 86 |  | 1,053 |  | 315 |  | 1,509 |  |
| Other income (expense), net |  | (49 | ) | (55 | ) | 73 |  | (104 | ) | 8 |  |
| Income before income taxes |  | 180 |  | 31 |  | 1,126 |  | 211 |  | 1,517 |  |
| Provision for (benefit from) income taxes |  | 15 |  | (3 | ) | 193 |  | 13 |  | 203 |  |
| Net income |  | $ | 165 |  | $ | 34 |  | $ | 933 |  | $ | 198 |  | $ | 1,314 |  |

[0001104659-16-092467:mdna:21]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |
|  |  | January 1, 2016 |  | October 2, 2015 |  | January 2, 2015 |  | January 1, 2016 |  | January 2, 2015 |  |
| Revenue |  | 100 | % | 100 | % | 100 | % | 100 | % | 100 | % |
| Cost of revenue |  | 75 |  | 76 |  | 72 |  | 76 |  | 72 |  |
| Gross margin |  | 25 |  | 24 |  | 28 |  | 24 |  | 28 |  |
| Product development |  | 10 |  | 11 |  | 9 |  | 11 |  | 9 |  |
| Marketing and administrative |  | 5 |  | 7 |  | 6 |  | 6 |  | 6 |  |
| Amortization of intangibles |  | 1 |  | 1 |  | 1 |  | 1 |  | 1 |  |
| Restructuring and other, net |  | 1 |  | 2 |  | — |  | 1 |  | — |  |
| Gain on litigation settlement, net |  | — |  | — |  | (16 | ) | — |  | (8 | ) |
| Income from operations |  | 8 |  | 3 |  | 28 |  | 5 |  | 20 |  |
| Other (expense) income, net |  | (2 | ) | (2 | ) | 2 |  | (2 | ) | — |  |
| Income before income taxes |  | 6 |  | 1 |  | 30 |  | 3 |  | 20 |  |
| Provision for (benefit from) income taxes |  | — |  | — |  | 5 |  | — |  | 2 |  |
| Net income |  | 6 | % | 1 | % | 25 | % | 3 | % | 18 | % |

[0001104659-16-092467:mdna:22]
[same as prior period, unchanged from 0001104659-15-074539:mdna:75]

[0001104659-16-092467:mdna:23]
[same as prior period, unchanged from 0001104659-15-074539:mdna:24]

[0001104659-16-092467:mdna:24]
[same as prior period, unchanged from 0001104659-15-074539:mdna:25]

[0001104659-16-092467:mdna:25]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |
| (In millions, except percentages, exabytes and ASPs) |  | January 1, 2016 |  | October 2, 2015 |  | January 2, 2015 |  | January 1, 2016 |  | January 2, 2015 |  |
| Unit Shipments: |  |  |  |  |  |  |  |  |  |  |  |
| Enterprise |  | 8 |  | 8 |  | 9 |  | 16 |  | 18 |  |
| Client Compute |  | 25 |  | 28 |  | 36 |  | 53 |  | 75 |  |
| Client Non-Compute |  | 13 |  | 11 |  | 12 |  | 24 |  | 24 |  |
| Total Units Shipped |  | 46 |  | 47 |  | 57 |  | 93 |  | 117 |  |
| ASPs (per unit) |  | $ | 59 |  | $ | 58 |  | $ | 61 |  | $ | 59 |  | $ | 61 |  |
| Exabytes Shipped |  | 61 |  | 56 |  | 61 |  | 117 |  | 121 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 69 | % | 70 | % | 69 | % | 69 | % | 69 | % |
| Distributors |  | 16 | % | 18 | % | 18 | % | 17 | % | 18 | % |
| Retailers |  | 15 | % | 12 | % | 13 | % | 14 | % | 12 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | 26 | % | 28 | % | 26 | % | 27 | % | 27 | % |
| EMEA |  | 19 | % | 17 | % | 18 | % | 18 | % | 17 | % |
| Asia Pacific |  | 55 | % | 55 | % | 56 | % | 55 | % | 56 | % |

[0001104659-16-092467:mdna:26]
Revenue in the December 2015 quarter increased from the September 2015 quarter as a result of improved product mix and the consolidation of Dot Hill, partially offset by price erosion and a decrease in unit shipments.

[0001104659-16-092467:mdna:27]
Revenue in the December 2015 quarter and the six months then ended decreased by $0.7 billion and $1.6 billion, respectively, as compared to the December 2014 quarter and the six months then ended due to a decrease in unit shipments and price erosion, partially offset by improved product mix. The decrease in unit shipments of 11 million and 24 million units as compared to the December 2014 quarter and the six months then ended, respectively, was primarily the result of decreased demand for personal computing devices.

[0001104659-16-092467:mdna:28]
We maintain various sales programs such as point-of-sale rebates, sales price adjustments and price protection, aimed at increasing customer demand. Sales programs were approximately 14%, 13% and 9% of gross drive revenue for the December 2015 quarter, September 2015 quarter and December 2014 quarter, respectively. Adjustments to revenues due to under or over accruals for sales programs related to revenues reported in prior quarterly periods were less than 0.5% of quarterly gross revenue in the December 2015 quarter.

[0001104659-16-092467:mdna:29]
[same as prior period, unchanged from 0001104659-15-074539:mdna:30]

[0001104659-16-092467:mdna:30]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |
| (Dollars in millions) |  | January 1, 2016 |  | October 2, 2015 |  | January 2, 2015 |  | January 1, 2016 |  | January 2, 2015 |  |
| Cost of revenue |  | $ | 2,245 |  | $ | 2,236 |  | $ | 2,669 |  | $ | 4,482 |  | $ | 5,403 |  |
| Gross margin |  | 741 |  | 689 |  | 1,027 |  | 1,429 |  | 2,078 |  |
| Gross margin percentage |  | 25 | % | 24 | % | 28 | % | 24 | % | 28 | % |

[0001104659-16-092467:mdna:31]
Gross margin as a percentage of revenue for the December 2015 quarter increased by approximately 100 basis points to 25% compared to the September 2015 quarter as a result of improved product mix, partially offset by price erosion. Compared to the December 2014 quarter and the six months then ended, gross margin decreased by approximately 300 and 400 basis points, respectively, as a result of price erosion, partially offset by improved product mix.

[0001104659-16-092467:mdna:32]
In the December 2015 quarter, total warranty cost was 1.2% of revenue and included unfavorable changes in estimates of prior warranty accruals of approximately 0.1% of revenue. Warranty cost related to new unit shipments was 1.1% of revenue for each of the December 2015, September 2015 and December 2014 quarters, respectively.

[0001104659-16-092467:mdna:33]
[same as prior period, unchanged from 0001104659-15-074539:mdna:34]

[0001104659-16-092467:mdna:34]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |
| (Dollars in millions) |  | January 1, 2016 |  | October 2, 2015 |  | January 2, 2015 |  | January 1, 2016 |  | January 2, 2015 |  |
| Product development |  | $ | 304 |  | $ | 328 |  | $ | 341 |  | $ | 632 |  | $ | 683 |  |
| Marketing and administrative |  | 160 |  | 182 |  | 218 |  | 341 |  | 434 |  |
| Amortization of intangibles |  | 31 |  | 34 |  | 32 |  | 65 |  | 62 |  |
| Restructuring and other, net |  | 17 |  | 59 |  | 3 |  | 76 |  | 10 |  |
| Gain on litigation settlement, net |  | — |  | — |  | (620 | ) | — |  | (620 | ) |
| Operating expenses |  | $ | 512 |  | $ | 603 |  | $ | (26 | ) | $ | 1,114 |  | $ | 569 |  |

[0001104659-16-092467:mdna:35]
Product development expense.  Product development expense for the December 2015 quarter decreased by $24 million from the September 2015 quarter due to a decrease in salaries and other employee benefits of $11 million as a result of the restructuring of our work force in the September 2015 quarter and increased use of vacation, as well as increased operational efficiencies in our business, partially offset by the consolidation of Dot Hill in the December 2015 quarter. Compared to the December 2014 quarter, product development expense decreased by $37 million due to a decrease in salaries and other employee benefits of $33 million as a result of the restructuring of our work force in the September 2015 quarter, $15 million decrease in variable compensation, and increased operational efficiencies in our business, partially offset by the consolidation of Dot Hill in the December 2015 quarter.

[0001104659-16-092467:mdna:36]
Product development expense for the six months ended December 2015 decreased by $51 million as compared to the corresponding period in the prior year due to a decrease in salaries and other employee benefits of  $53 million as a result of the restructuring of our work force in the September 2015 quarter, a $26 million decrease in variable compensation and stock based compensation, increased operational efficiencies in our business, and additional expenses experienced in the 14-week September 2014 quarter, partially offset by the consolidation of Dot Hill in the December 2015 quarter.

[0001104659-16-092467:mdna:37]
Marketing and administrative expense. Marketing and administrative expense for the December 2015 quarter decreased by $22 million from the September 2015 quarter due to a decrease in salaries and other employee benefits of $15 million as a result of the restructuring of our work force in the September 2015 quarter and increased use of vacation, as well as increased operational efficiencies in our business. Compared to the December 2014 quarter, marketing and administrative expense decreased by $58 million due to a decrease in salaries and other employee benefits of $25 million as a result of the restructuring of our work force in the September 2015 quarter, $15 million decrease in variable compensation and stock based compensation, and increased operational efficiencies in our business.

[0001104659-16-092467:mdna:38]
Marketing and administrative expense for the six months ended December 2015 decreased by $93 million as compared to the corresponding period in the prior year due to a decrease in salaries and other employee benefits of $40 million as a result of the restructuring of our work force in the September 2015 quarter, a $29 million decrease in variable compensation and stock based compensation, additional expenses experienced in the 14-week September 2014 quarter, and increased operational efficiencies in our business.

[0001104659-16-092467:mdna:39]
Amortization of intangibles. Amortization of intangibles for the December 2015 quarter decreased from the September 2015 quarter and December 2014 quarter by $3 million and $1 million, respectively, due to certain intangible assets reaching the end of their useful life in the September 2015 quarter, partially offset by the intangibles acquired in the acquisition of Dot Hill.

[0001104659-16-092467:mdna:40]
Amortization of intangibles for the six months ended December 2015 increased by $3 million as compared to the corresponding period in the prior year as a result of the acquisitions of LSI Corporation’s Accelerated Solutions Division and Flash Components Division in September of 2014 and Dot Hill in the December 2015 quarter, offset by certain intangible assets reaching the end of their useful life in the September 2015 quarter,

[0001104659-16-092467:mdna:41]
36

[0001104659-16-092467:mdna:42]
Restructuring and other, net. Restructuring and other, net for the December 2015 quarter  decreased by $42 million as compared to the September 2015 quarter due to a restructuring charge recorded during the September 2015 quarter to reduce work force by approximately 1,000 employees. Compared to the December 2014 quarter, restructuring and other, net increased by $14 million primarily as a result of charges related to the September 2015 plan.

[0001104659-16-092467:mdna:43]
Restructuring and other, net for the six months ended December 2015 increased by $66 million as compared to the corresponding period in the prior year primarily as a result of a restructuring charge recorded during the September 2015 quarter to reduce work force by approximately 1,000 employees.

[0001104659-16-092467:mdna:44]
Gain on arbitration award, net. Gain on arbitration award, net for the December 2014 quarter and the six months then ended was related to the final award amount of $630 million, less litigation and other related costs of $10 million, in the Company’s case against Western Digital for the misappropriation of the Company’s trade secrets.

[0001104659-16-092467:mdna:45]
Other (expense) income, net

[0001104659-16-092467:mdna:46]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |
| (Dollars in millions) |  | January 1, 2016 |  | October 2, 2015 |  | January 2, 2015 |  | January 1, 2016 |  | January 2, 2015 |  |
| Other (expense) income, net |  | $ | (49 | ) | $ | (55 | ) | $ | 73 |  | $ | (104 | ) | $ | 8 |  |

[0001104659-16-092467:mdna:47]
Other (expense) income, net decreased by $6 million from the September 2015 quarter due to a $10 million loss related to the impairment of a strategic investment in the September 2015 quarter, partially offset by a $2 million change resulting from the  volatility of foreign  exchange rates in the December 2015 quarter. Compared to the December 2014 quarter, other (expense) income, net increased by $122 million due to the partial payment of $143 million for interest accrued on the final arbitration award amount in the Company’s case against Western Digital in the December 2014 quarter and $15 million in foreign currency remeasurement related to changes in foreign exchange rates, partially offset by a $36 million increase in losses from the early redemption and repurchase of debt in the December 2014 quarter.

[0001104659-16-092467:mdna:48]
Other (expense) income, net for the six months ended December 2015 increased $112 million due to the partial payment of $143 million for interest accrued on the final arbitration award amount in the Company’s case against Western Digital in the December 2014 quarter and $18 million increase in foreign currency remeasurement related to changes in foreign exchange rates, partially offset by a $50 million increase in losses from the early redemption and repurchase of debt in the six months ended December 2014.

[0001104659-16-092467:mdna:49]
[same as prior period, unchanged from 0001104659-15-074539:mdna:44]

[0001104659-16-092467:mdna:50]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |
| (Dollars in millions) |  | January 1, 2016 |  | October 2, 2015 |  | January 2, 2015 |  | January 1, 2016 |  | January 2, 2015 |  |
| Provision for (benefit from) income taxes |  | $ | 15 |  | $ | (3 | ) | $ | 193 |  | $ | 13 |  | $ | 203 |  |

[0001104659-16-092467:mdna:51]
Our income tax provision recorded for the first half of fiscal year 2016 included approximately $3 million of net discrete tax benefits primarily for the release of tax reserves due to the expiration of certain statutes of limitation.

[0001104659-16-092467:mdna:52]
Our income tax provision recorded for the December 2015 quarter and for the first half of fiscal year 2016 differed from the provision from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets. The acquisition of Dot Hill Systems Corporation is not expected to have a material impact on our effective tax rate in fiscal year 2016.

[0001104659-16-092467:mdna:53]
Consistent with the intent of ASU 2015-17 to simplify the presentation of deferred income taxes, we have elected to adopt ASU 2015-17 on a prospective basis as of the second quarter, fiscal year 2016. Prior periods were not retrospectively adjusted. As a result of this change in accounting principle, $120 million of our deferred tax assets were reclassified from current to non-current.

[0001104659-16-092467:mdna:54]
On December 18, 2015, the Protecting Americans from Tax Hikes (PATH) Act of 2015 was enacted. Among other provisions, the PATH Act retroactively reinstated and permanently extended the federal Research and Development (R&D) Tax Credit from December 31, 2014. The permanent extension of the R&D credit had no immediate impact on our income tax provision due to valuation allowances on our U.S. deferred tax assets. None of the other PATH Act changes are expected to have a material impact on our income tax provision.

[0001104659-16-092467:mdna:55]
During the six months ended January 1, 2016, our unrecognized tax benefits excluding interest and penalties decreased by approximately $6 million to $77 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate was $77 million at January 1, 2016, subject to certain future valuation allowance reversals. During the 12 months beginning January 2, 2016, we expect that our unrecognized tax benefits could be reduced by approximately $30 million primarily as a result of the expiration of certain statutes of limitation.

[0001104659-16-092467:mdna:56]
We are subject to taxation in many jurisdictions globally and we are required to file U.S. federal, U.S. state and non-U.S. income tax returns. In December 2015, we effectively settled all disputed issues with the IRS associated with our U.S. federal income tax returns for fiscal years 2008, 2009 and 2010. This effective settlement did not have a material impact on our financial statements. As a result of this settlement and expiration of the fiscal year 2011 statute of limitation, we are no longer subject to tax examination of U.S. federal income tax returns for years prior to fiscal year 2012.

[0001104659-16-092467:mdna:57]
Our income tax provision recorded for the December 2014 quarter and for the first half of fiscal year 2015 included approximately $181 million of net tax expense due to the final audit assessment received from the Jiangsu Province State Tax Bureau of the People’s Republic of China (China assessment) for calendar years 2007 through 2013.

[0001104659-16-092467:mdna:58]
Our income tax provision recorded for the December 2014 quarter and for the first half of fiscal year 2015 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) tax expense associated with the China assessment, and (iii) a decrease in valuation allowance for certain U.S. deferred tax assets. The acquisition of LSI’s Flash Business did not have a material impact on our effective tax rate in fiscal year 2015.

[0001104659-16-092467:mdna:59]
[same as prior period, unchanged from 0001104659-15-074539:mdna:51]

[0001104659-16-092467:mdna:60]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist primarily of money market funds, certificates of deposits, and other interest-bearing bank deposits. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, these restrictions have not impeded our ability to conduct our business, nor do we expect them to in the next 12 months. We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term investments and we do not believe the fair value of our short-term investments has significantly changed from the values reported as of January 1, 2016.

[0001104659-16-092467:mdna:61]
[same as prior period, unchanged from 0001104659-15-074539:mdna:53]

[0001104659-16-092467:mdna:62]
| (Dollars in millions) |  | January 1, 2016 |  | July 3, 2015 |  | Change |  |
| Cash and cash equivalents |  | $ | 1,258 |  | $ | 2,479 |  | $ | (1,221 | ) |
| Short-term investments |  | 6 |  | 6 |  | — |  |
| Total |  | $ | 1,264 |  | $ | 2,485 |  | $ | (1,221 | ) |

[0001104659-16-092467:mdna:63]
Our cash and cash equivalents and short-term investments decreased from July 3, 2015 as a result of net cash outflows for the acquisition of Dot Hill, repurchase of our ordinary shares, dividends paid to our shareholders, and capital expenditures. These cash outflows were partially offset by our net cash provided by operating activities.

[0001104659-16-092467:mdna:64]
[same as prior period, unchanged from 0001104659-15-074539:mdna:56]

[0001104659-16-092467:mdna:65]
Cash provided by operating activities for the six months ended January 1, 2016 of $1,206 million includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, and:

[0001104659-16-092467:mdna:66]
·                  a decrease of $384 million in accounts receivable, primarily due to improved linearity; and

[0001104659-16-092467:mdna:67]
·                  an increase of $257 million in accounts payable, primarily due to the timing of payments and improved payment terms with certain of our vendors.

[0001104659-16-092467:mdna:68]
[same as prior period, unchanged from 0001104659-15-074539:mdna:60]

[0001104659-16-092467:mdna:69]
Cash used for investing activities for the six months ended January 1, 2016 was $980 million and primarily attributable to the following activities

[0001104659-16-092467:mdna:70]
·                  $634 million paid for the acquisition of Dot Hill, net of cash acquired; and

[0001104659-16-092467:mdna:71]
·                  $346 million used for acquired property, equipment and leasehold improvements

[0001104659-16-092467:mdna:72]
[same as prior period, unchanged from 0001104659-15-074539:mdna:62]

[0001104659-16-092467:mdna:73]
Cash used in financing activities of $1,444 million for the six months ended January 1, 2016 was primarily attributable to the following activities:

[0001104659-16-092467:mdna:74]
·                  $1,061 million paid to repurchase ordinary shares; and

[0001104659-16-092467:mdna:75]
·                  $351 million in dividend payments.

[0001104659-16-092467:mdna:76]
[same as prior period, unchanged from 0001104659-15-074539:mdna:66]

[0001104659-16-092467:mdna:77]
Our primary sources of liquidity as of January 1, 2016 consisted of: (1) approximately $1.3 billion in cash, cash equivalents, and short-term investments, (2) cash we expect to generate from operations and (3) a $700 million senior revolving credit facility.

[0001104659-16-092467:mdna:78]
As of January 1, 2016, no borrowings have been drawn under the revolving credit facility or had been utilized for letters of credit issued under this credit facility. The line of credit is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001104659-16-092467:mdna:79]
The credit agreement that governs our revolving credit facility, as amended, contains certain covenants that we must satisfy in order to remain in compliance with the credit agreement, as amended. The agreement also includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. As of January 1, 2016, we were in compliance with all of the covenants under our Revolving Credit Facility and debt agreements. Based on our current outlook, we expect to be in compliance with the covenants of our debt agreements over the next 12 months.

[0001104659-16-092467:mdna:80]
[same as prior period, unchanged from 0001104659-15-074539:mdna:70]

[0001104659-16-092467:mdna:81]
[same as prior period, unchanged from 0001104659-15-074539:mdna:71]

[0001104659-16-092467:mdna:82]
From time to time we may repurchase any of our outstanding notes in open market or privately negotiated purchases or otherwise, or may repurchase outstanding notes pursuant to the terms of the applicable indenture.

[0001104659-16-092467:mdna:83]
The Company’s Board of Directors declared a quarterly cash dividend of $0.63 per share on January 29, 2016, which is payable on February 23, 2016 to shareholders of record at the close of business on February 9, 2016.

[0001104659-16-092467:mdna:84]
From time to time we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases. As of January 1, 2016, $1.8 billion remained available for repurchase under our existing repurchase authorization limit.  All repurchases are effected as redemptions in accordance with the Company’s Articles of Association.

[0001104659-16-092467:mdna:85]
[same as prior period, unchanged from 0001104659-15-074539:mdna:76]

[0001104659-16-092467:mdna:86]
[same as prior period, unchanged from 0001104659-15-074539:mdna:77]

[0001104659-16-092467:mdna:87]
[same as prior period, unchanged from 0001104659-15-074539:mdna:78]

[0001104659-16-092467:mdna:88]
[same as prior period, unchanged from 0001104659-15-074539:mdna:79]

[0001104659-16-092467:mdna:89]
[same as prior period, unchanged from 0001104659-15-074539:mdna:80]
