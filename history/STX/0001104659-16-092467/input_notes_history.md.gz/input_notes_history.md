# STX note change history — 0001104659-15-074539 → 0001104659-16-092467


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-01-29):
[0001104659-16-092467:note_history:1]
Alexander Shukh v. Seagate Technology - On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. On March 31, 2014, the district court granted Seagate's summary judgment motion and entered judgment in favor of Seagate. Mr. Shukh filed a notice of appeal on April 7, 2014. On October 2, 2015, the court of appeals vacated and remanded the district court’s grant of summary judgment on Mr. Shukh’s claim for correction of inventorship and affirmed the district court’s grant of summary judgment as to all other claims. On October 29, 2015, Mr. Shukh filed a petition for rehearing en banc with the court of appeals; the petition was denied on December 17, 2015. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2015-10-30, similarity 0.8246):
[0001104659-15-074539:note_history:1]
Alexander Shukh v. Seagate Technology - On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. On March 31, 2014, the district court granted Seagate's summary judgment motion and entered judgment in favor of Seagate. Mr. Shukh filed a notice of appeal on April 7, 2014. On October 2, 2015, the court of appeals vacated and remanded the district court’s grant of summary judgment on Mr. Shukh’s claim for correction of inventorship and affirmed the district court’s grant of summary judgment as to all other claims. On October 29, 2015, Mr. Shukh filed a petition for rehearing en banc with the court of appeals. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- changed (2016-01-29):
[0001104659-16-092467:note_history:2]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation ("Enova") filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995, "Cryptographic Device," and U.S. Patent No. 7,900,057, "Cryptographic Serial ATA Apparatus and Method." The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys' fees, and other relief. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the '995 and '057 Patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. The Company believes the claims are without merit and intends to vigorously defend this case. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 Patent are held unpatentable. On October 29, 2015, Enova filed a notice of appeal to appeal PTAB’s decision on the ‘995 Patent to the U.S. Court of Appeals for the Federal Circuit. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ’057 Patent are held unpatentable. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2015-10-30, similarity 0.7124):
[0001104659-15-074539:note_history:2]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995, "Cryptographic Device," and U.S. Patent No. 7,900,057, "Cryptographic Serial ATA Apparatus and Method." The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys' fees, and other relief. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the '995 and '057 Patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. The Company believes the claims are without merit and intends to vigorously defend this case. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 Patent are held unpatentable. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- changed (2016-01-29):
[0001104659-16-092467:note_history:3]
Seagate Technology LLC v. Western Digital Corp.  On October 8, 2014, the Minnesota Supreme Court ruled that the arbitration award in favor of the Company in its case against Western Digital for the misappropriation of the Company’s trade secrets should be confirmed. In the arbitration award, issued on January 23, 2012, the arbitrator determined that Western Digital and its former employee had misappropriated the Company’s trade secrets. The arbitrator awarded the Company $525 million in compensatory damages and, after adding interest, issued a final award of $630 million. Interest on the final award has been accruing at 10%. On October 14, 2014, the Company received a partial payment from Western Digital in the amount of $773 million. During the quarter ended January 2, 2015, the amount of the final award, less litigation and other related costs, was recorded by the Company in Gain on arbitration award, net, and the remaining amount received was recorded in Other, net. On April 7, 2015, the Hennepin County District Court of Minnesota (“district court”) denied Seagate’s motion for entry of judgment for an amount of additional interest owing on the arbitration award.  On January 25, 2016, the Minnesota Court of Appeals reversed and remanded the district court’s order regarding the unpaid interest. On January 27, 2016, the Company received a further payment from Western Digital in the amount of $32.6 million, which was the remaining balance of interest owed on the final award.
  (was, 2015-10-30, similarity 0.7942):
[0001104659-15-074539:note_history:3]
Seagate Technology LLC v. Western Digital Corp.  On October 8, 2014, the Minnesota Supreme Court ruled that the arbitration award in favor of the Company in its case against Western Digital for the misappropriation of the Company’s trade secrets should be confirmed. In the arbitration award, issued on January 23, 2012, the arbitrator determined that Western Digital and its former employee had misappropriated the Company’s trade secrets. The arbitrator awarded the Company $525 million in compensatory damages and, after adding interest, issued a final award of $630 million. Interest on the final award has been accruing at 10%. On October 14, 2014, the Company received a partial payment from Western Digital in the amount of $773 million. During the quarter ended January 2, 2015, the amount of the final award, less litigation and other related costs, was recorded by the Company in Gain on arbitration award, net, and the remaining amount received was recorded in Other, net.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-01-29):
[0001104659-16-092467:note_history:4]
Seagate Technology plc (the "Company") is a leading provider of electronic data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, it produces a broad range of electronic data storage products including solid state hybrid drives ("SSHD"), solid state drives ("SSD"), PCIe cards and SATA controllers. Its storage technology portfolio also includes storage subsystems, high performance computing ("HPC") solutions, and data storage services.
  (was, 2015-10-30, similarity 0.9927):
[0001104659-15-074539:note_history:4]
Seagate Technology plc (the "Company") is a leading provider of electronic data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, it produces a broad range of electronic data storage products including solid state hybrid drives ("SSHD"), solid state drives ("SSD"), PCIe cards and SATA controllers. Its storage technology portfolio also includes storage subsystems, high performance computing (HPC) solutions, and data storage services.

- changed (2016-01-29):
[0001104659-16-092467:note_history:5]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and most SSDs use NAND-based flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed data.
  (was, 2015-10-30, similarity 0.9662):
[0001104659-15-074539:note_history:5]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and most SSDs use NAND-based flash memory. In addition to HDDs and SSDs, Solid-state hybrid drives (SSHDs) combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed data.

- changed (2016-01-29):
[0001104659-16-092467:note_history:6]
The Company's product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and HPC data storage solutions. Its storage subsystems support a range of high-speed interconnect technologies to meet demanding cost and performance specifications. Its modular subsystem architecture allows it to support many segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.
  (was, 2015-10-30, similarity 0.9693):
[0001104659-15-074539:note_history:6]
The Company's product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and high performance computing ("HPC") data storage solutions. Its storage subsystems support a range of high-speed interconnect technologies to meet demanding cost and performance specifications. Its modular subsystem architecture allows it to support many segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.

- added (2016-01-29):
[0001104659-16-092467:note_history:7]
The results of operations for the three and six months ended January 1, 2016, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending July 1, 2016. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three and six months ended January 1, 2016 consisted of 13 weeks and 26 weeks, respectively. The three and six months ended January 2, 2015 consisted of 14 weeks and 27 weeks, respectively.  Fiscal year 2016 will be comprised of 52 weeks and will end on July 1, 2016. The fiscal quarters ended January 1, 2016, October 2, 2015, and January 2, 2015, are also referred to herein as the “December 2015 quarter”, the “September 2015 quarter”, and the “December 2014 quarter”, respectively.

- changed (2016-01-29):
[0001104659-16-092467:note_history:8]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. The amendments in this ASU are effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company is in the process of assessing the impact, if any, of this ASU on its consolidated financial statements.
  (was, 2015-10-30, similarity 0.9893):
[0001104659-15-074539:note_history:8]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. The amendments in this ASU are effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company is in the process of assessing the impact, if any, on its consolidated financial statements.

- added (2016-01-29):
[0001104659-16-092467:note_history:9]
In November 2015, the FASB issued ASU 2015-17 (ASC Topic 740), Income Taxes Balance Sheet Classification of Deferred Taxes. The amendments in this Update are effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company early adopted this ASU for the December 2015 quarter on a prospective basis. See footnote 4 for disclosure of the financial statement impact of this adoption.

- added (2016-01-29):
[0001104659-16-092467:note_history:10]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments- Overall Recognition and Measurement of Financial Assets and Financial Liabilities. The amendments in this ASU require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The amendments in this ASU are effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. Early adoption is permitted for only certain portions of the ASU. The Company is in the process of assessing the impact, if any, on its consolidated financial statements.

- removed (2016-01-29):
[0001104659-15-074539:note_history:11]
The Company's data storage services provide online backup, data protection and recovery solutions for small to medium-sized businesses.

- removed (2016-01-29):
[0001104659-15-074539:note_history:12]
The results of operations for the three months ended October 2, 2015, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending July 1, 2016. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three months ended October 2, 2015 consisted of 13 weeks. The three months ended October 3, 2014 consisted of 14 weeks.  Fiscal year 2016 will be comprised of 52 weeks and will end on July 1, 2016. The fiscal quarters ended October 2, 2015, July 3, 2015, and October 3, 2014, are also referred to herein as the “September 2015 quarter”, the “June 2015 quarter”, and the “September 2014 quarter”, respectively.

- removed (2016-01-29):
[0001104659-15-074539:note_history:13]
In August 2015, the FASB issued ASU 2015-13 (ASC Topic 815), Application of the Normal Purchases and Normal Sales Scope Exception to Certain Electricity Contracts within Nodal Energy Markets. ASC 815, Derivatives and Hedging, requires that a derivative contract be recognized at fair value unless the contract qualifies for a scope exception. The amendments in this update specify that electricity contracts for the use of locational marginal pricing by an independent system operator that necessitate transmission through a nodal energy market qualify for the normal purchases and normal sales scope exception. The amendments in this ASU are effective upon issuance and applied prospectively. The adoption of this new guidance is not expected to have a material impact on the Company’s consolidated financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-01-29):
[0001104659-16-092467:note_history:14]
The Company and its subsidiary Seagate HDD Cayman have entered into a Credit Agreement providing the Company with a $700 million senior secured revolving credit facility (the "Revolving Credit Facility"). On January 15, 2015, pursuant to the Third Amendment to the Credit Agreement, the commitments available under the Revolving Credit Facility were increased from $500 million to $700 million and the maturity date was extended until January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Credit Agreement) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. This Credit Agreement that was originally entered into by the Company and Seagate HDD Cayman on January 18, 2011 was subsequently amended with the Second Amendment to the Credit Agreement on April 30, 2013, which increased the commitments available under the Revolving Credit Facility from $350 million to $500 million. The loans made under the Credit Agreement will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings and for the issuance of letters of credit up to a sub-limit of $75 million. As of January 1, 2016, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.
  (was, 2015-10-30, similarity 0.9954):
[0001104659-15-074539:note_history:14]
The Company and its subsidiary Seagate HDD Cayman have entered into a Credit Agreement providing the Company with a $700 million senior secured revolving credit facility (the "Revolving Credit Facility"). On January 15, 2015, pursuant to the Third Amendment to the Credit Agreement, the commitments available under the Revolving Credit Facility were increased from $500 million to $700 million and the maturity date was extended until January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Credit Agreement) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. This Credit Agreement that was originally entered into by the Company and Seagate HDD Cayman on January 18, 2011 was subsequently amended with the Second Amendment to the Credit Agreement on April 30, 2013, which increased the commitments available under the Revolving Credit Facility from $350 million to $500 million. The loans made under the Credit Agreement will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings and for the issuance of letters of credit up to a sub-limit of $75 million. As of October 2, 2015, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

- changed (2016-01-29):
[0001104659-16-092467:note_history:15]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman, and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2015-10-30, similarity 0.6762):
[0001104659-15-074539:note_history:15]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman, and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2015 quarter, the Company repurchased $0.5 million aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The loss recorded on the repurchase was immaterial, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

- changed (2016-01-29):
[0001104659-16-092467:note_history:16]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2015-10-30, similarity 0.6737):
[0001104659-15-074539:note_history:16]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2015 quarter, the Company repurchased $10 million aggregate principal amount of its 2023 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The loss recorded on the repurchase was immaterial, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

- changed (2016-01-29):
[0001104659-16-092467:note_history:17]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2015-10-30, similarity 0.6749):
[0001104659-15-074539:note_history:17]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2015 quarter, the Company repurchased $5 million aggregate principal amount of its 2025 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The gain recorded on the repurchase was immaterial, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

- changed (2016-01-29):
[0001104659-16-092467:note_history:18]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, which commenced on December 1, 2015. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2015-10-30, similarity 0.9671):
[0001104659-15-074539:note_history:18]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on December 1, 2015. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2016-01-29):
[0001104659-16-092467:note_history:19]
At January 1, 2016, future principal payments on long-term debt were as follows (in millions):
  (was, 2015-10-30, similarity 0.9326):
[0001104659-15-074539:note_history:19]
At October 2, 2015, future principal payments on long-term debt were as follows (in millions):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-01-29):
[0001104659-16-092467:note_history:20]
|  |  | January 1, 2016 |  | July 3, 2015 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 800 |  |  | $ | 807 |  |  | $ | 800 |  |  | $ | 828 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 164 |  |  | 158 |  |  | 170 |  |
| 4.75% Senior Notes due June 2023 |  | 990 |  |  | 905 |  |  | 1,000 |  |  | 1,016 |  |
| 4.75% Senior Notes due January 2025 |  | 995 |  |  | 847 |  |  | 1,000 |  |  | 995 |  |
| 4.875% Senior Notes due June 2027 |  | 698 |  |  | 567 |  |  | 698 |  |  | 675 |  |
| 5.75% Senior Notes due December 2034 |  | 499 |  |  | 350 |  |  | 499 |  |  | 491 |  |
| Long-term debt |  | $ | 4,140 |  |  | $ | 3,640 |  |  | $ | 4,155 |  |  | $ | 4,175 |  |
| Less short-term borrowings and current portion of long-term debt |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 4,140 |  |  | $ | 3,640 |  |  | $ | 4,155 |  |  | $ | 4,175 |  |
  (was, 2015-10-30, similarity 0.9914):
[0001104659-15-074539:note_history:20]
|  |  | October 2, 2015 |  | July 3, 2015 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 800 |  |  | $ | 822 |  |  | $ | 800 |  |  | $ | 828 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 166 |  |  | 158 |  |  | 170 |  |
| 4.75% Senior Notes due June 2023 |  | 990 |  |  | 968 |  |  | 1,000 |  |  | 1,016 |  |
| 4.75% Senior Notes due January 2025 |  | 995 |  |  | 961 |  |  | 1,000 |  |  | 995 |  |
| 4.875% Senior Notes due June 2027 |  | 698 |  |  | 664 |  |  | 698 |  |  | 675 |  |
| 5.75% Senior Notes due December 2034 |  | 499 |  |  | 473 |  |  | 499 |  |  | 491 |  |
| Long-term debt |  | $ | 4,140 |  |  | $ | 4,054 |  |  | $ | 4,155 |  |  | $ | 4,175 |  |
| Less short-term borrowings and current portion of long-term debt |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 4,140 |  |  | $ | 4,054 |  |  | $ | 4,155 |  |  | $ | 4,175 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2016-01-29):
[0001104659-15-074539:note_history:21]
Subsequent Event

- removed (2016-01-29):
[0001104659-15-074539:note_history:22]
On October 6, 2015, the Company acquired all of the outstanding shares of Dot Hill Systems Corp. ("Dot Hill"), a supplier of software and hardware storage systems. The Company paid $9.75 per share or approximately $696 million in cash for the acquisition. The acquisition of Dot Hill further expands the Company's OEM-focused cloud storage systems business and advances the Company's strategic efforts. Because the initial accounting for the acquisition was incomplete at the time this Form 10-Q was filed with the Securities and Exchange Commission, certain disclosures required by ASC Topic 805 — Business Combinations have not been made herein.
