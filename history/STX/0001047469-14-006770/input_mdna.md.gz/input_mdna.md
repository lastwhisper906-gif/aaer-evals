# STX MD&A — 0001047469-14-006770


## mdna

[0001047469-14-006770:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001047469-14-006770:mdna:2]
The following is a discussion of the Company's financial condition, changes in financial condition and results
of operations for the fiscal years ended June 27, 2014, June 28, 2013, and June 29, 2012.

[0001047469-14-006770:mdna:3]
You should read this discussion in conjunction with "Item 6. Selected Financial Data" and "Item 8. Financial Statements and Supplementary
Data" included elsewhere in this Annual Report on Form 10-K. Except as noted, references to any fiscal year mean the twelve-month period ending on the Friday closest to June 30 of that
year.

[0001047469-14-006770:mdna:4]
Our
Management's Discussion and Analysis of Financial Condition and Results of Operations (MD&A) is provided in addition to the accompanying consolidated financial statements and notes
to assist readers in understanding our results of operations, financial condition, and cash flows. MD&A is organized as follows:

[0001047469-14-006770:mdna:5]
•

[0001047469-14-006770:mdna:6]
Our Company.  Discussion of our business.

[0001047469-14-006770:mdna:7]
•

[0001047469-14-006770:mdna:8]
Business Overview.  Discussion of industry trends and
their impact on our business.

[0001047469-14-006770:mdna:9]
•

[0001047469-14-006770:mdna:10]
Fiscal Year 2014 Summary.  Overview of financial and
other highlights affecting us for fiscal year 2014.

[0001047469-14-006770:mdna:11]
•

[0001047469-14-006770:mdna:12]
Results of Operations.  Analysis of our financial results
comparing fiscal year 2014 to 2013 and comparing fiscal years 2013 to 2012.

[0001047469-14-006770:mdna:13]
•

[0001047469-14-006770:mdna:14]
Liquidity and Capital Resources.  An analysis of changes
in our balance sheets and cash flows, and discussion of our financial condition including the credit quality of our investment portfolio and potential sources of liquidity.

[0001047469-14-006770:mdna:15]
•

[0001047469-14-006770:mdna:16]
Contractual Obligations and Off-Balance-Sheet
Arrangements.  Overview of contractual obligations and contingent liabilities and commitments outstanding as of June 27, 2014 and
an explanation of off-balance-sheet arrangements.

[0001047469-14-006770:mdna:17]
•

[0001047469-14-006770:mdna:18]
Critical Accounting Estimates.  Accounting estimates that
we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001047469-14-006770:mdna:19]
Our Company

[0001047469-14-006770:mdna:20]
We are a leading provider of electronic data storage solutions. Our principal products are hard disk drives, commonly referred to as
disk drives, hard drives or HDDs. Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass
data storage due to their performance attributes, high quality and cost effectiveness. In addition to HDDs, we produce a broad range of electronic data storage products including solid state hybrid
drives ("SSHD") and solid state drives ("SSD").

[0001047469-14-006770:mdna:21]
Our
products are designed for enterprise servers, and storage systems in mission critical and nearline applications; client compute applications, where our products are designed
primarily for desktop and mobile computing; and client non-compute applications, where our products are designed for a wide variety of end user devices such as digital video recorders ("DVRs"),
personal data backup systems, portable external storage systems and digital media systems.

[0001047469-14-006770:mdna:22]
We
continue to make strategic investments in order to expand our storage solutions, enter new market adjacencies, and expand our technical expertise. As a result of recent acquisitions,
our product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and high performance computing ("HPC") data storage solutions.
Our storage subsystems support a range of high-speed interconnect technologies to meet demanding cost and performance specifications. Our modular subsystem architecture allows us to support many
segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.

[0001047469-14-006770:mdna:23]
In
addition to our data storage products and subsystems, we provide data storage services for small to medium-sized businesses, including online backup, data protection and recovery
solutions.

[0001047469-14-006770:mdna:24]
Business Overview

[0001047469-14-006770:mdna:25]
Our industry is characterized by several trends and factors that have a material impact on our strategic planning, financial condition
and results of operations.

[0001047469-14-006770:mdna:26]
Industry Supply Balance

[0001047469-14-006770:mdna:27]
From time to time the industry has experienced periods of imbalance between supply and demand. To the extent that the disk drive
industry builds capacity based on expectations of demand that do not materialize, price erosion may become more pronounced. Conversely, during periods where demand exceeds supply, price erosion is
generally muted.

[0001047469-14-006770:mdna:28]
In
early October 2011, floodwaters north of Bangkok, Thailand inundated many manufacturing industrial parks that contained a number of the factories supporting the HDD industry's supply
chain. The HDD industry had concentrated a large portion of its supply chain participants within these industrial parks in an effort to reduce cost and improve logistics. As a result, the inundation
of floodwaters into these industrial parks had caused the closure or suspension of production by a number of participants within the HDD supply chain.

[0001047469-14-006770:mdna:29]
During
the supply chain disruption in fiscal year 2012, we believe demand exceeded supply due to the impact from the flooding in Thailand, resulting in an increase in the average selling
price ("ASP").

[0001047469-14-006770:mdna:30]
The
industry's ability to manufacture and ship drives had substantially recovered as of the end of fiscal year 2012. In fiscal years 2013 and 2014, we believe the HDD industry's capacity
to manufacture HDDs exceeded demand. However, following the impact of the flooding in Thailand and further industry consolidation in fiscal year 2012, the HDD industry has maintained improved pricing
discipline resulting in benign price erosion in fiscal years 2013 and 2014.

[0001047469-14-006770:mdna:31]
Demand Trends for Disk Drives

[0001047469-14-006770:mdna:32]
We believe that continued growth in digital content requires increasingly higher storage capacity in order to store, aggregate, host,
distribute, manage, backup and use such content. We also believe that as architectures evolve to serve the growing commercial and consumer user base throughout the world, the manner which hard drives
are delivered to market and utilized by our customers will evolve as well.

[0001047469-14-006770:mdna:33]
We
believe that in the foreseeable future the traditional enterprise and client compute markets that require high capacity storage solutions, as well as the data intensive client
non-compute markets, will continue to be best served by hard disk drives due to the industry's ability to deliver cost effective, reliable and energy efficient mass storage devices. Furthermore, the
increased use of client non-compute devices that consume media-rich digital content streamed from the cloud increases the demand for high capacity disk drives in nearline applications.

[0001047469-14-006770:mdna:34]
Price Erosion.    Historically, our industry has been characterized by price declines for disk drive products with comparable capacity,
performance and
feature sets ("like-for-like products").

[0001047469-14-006770:mdna:35]
Disk
drive manufacturers typically attempt to offset price erosion with an improved mix of disk drive products characterized by higher capacity, better performance and additional feature
sets and/or product cost reductions.

[0001047469-14-006770:mdna:36]
Seasonality

[0001047469-14-006770:mdna:37]
The disk drive industry traditionally experiences seasonal variability in demand with higher levels of demand in the second half of the
calendar year. This seasonality is driven by consumer spending in the back-to-school season from late summer to fall and the traditional holiday shopping season from fall to winter. In addition,
corporate demand is typically higher during the second half of the calendar year.

[0001047469-14-006770:mdna:38]
Fiscal Year 2014 Summary

[0001047469-14-006770:mdna:39]
During the fiscal year 2014, we shipped 220 million units totaling 202 exabytes, generating revenue of $13.7 billion and
gross margins of 28% of revenue. Our operating cash flow was $2.6 billion. We issued $1 billion of 4.75% Senior Notes due 2025 and $800 million of 3.75% Senior Notes due 2018
during the June 2014 and December 2013 quarters, respectively. We repurchased approximately 41 million of our ordinary shares during the year for approximately $1.9 billion, paid
dividends of $0.6 billion, paid $0.7 billion for the early redemption and repurchase of debt with a principal value of $0.7 billion. Additionally, we acquired all of the
outstanding shares of Xyratex Ltd ("Xyratex"), a leading provider of data storage technology, for approximately $0.4 billion. During the June 2014 quarter, we entered into an agreement
to acquire LSI's Accelerated Solutions Division and Flash Components Division from Avago for approximately $0.5 billion. The LSI acquisition is expected to close in the first quarter of the
fiscal year 2015.

[0001047469-14-006770:mdna:40]
45

[0001047469-14-006770:mdna:41]
Results of Operations

[0001047469-14-006770:mdna:42]
We list in the table below summarized information from our consolidated statements of operations by dollars and as a percentage of
revenue:

[0001047469-14-006770:mdna:43]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 27, 2014 |  | June 28, 2013 |  | June 29, 2012 |  |
| Revenue |  | $ | 13,724 |  | $ | 14,351 |  | $ | 14,939 |  |
| Cost of revenue |  |  | 9,878 |  |  | 10,411 |  |  | 10,255 |  |
| Gross margin |  |  | 3,846 |  |  | 3,940 |  |  | 4,684 |  |
| Product development |  |  | 1,226 |  |  | 1,133 |  |  | 1,006 |  |
| Marketing and administrative |  |  | 722 |  |  | 635 |  |  | 528 |  |
| Amortization of intangibles |  |  | 98 |  |  | 79 |  |  | 38 |  |
| Restructuring and other, net |  |  | 24 |  |  | 2 |  |  | 4 |  |
| Income from operations |  |  | 1,776 |  |  | 2,091 |  |  | 3,108 |  |
| Other expense, net |  |  | (220 | ) |  | (260 | ) |  | (226 | ) |
| Income before income taxes |  |  | 1,556 |  |  | 1,831 |  |  | 2,882 |  |
| (Benefit from) provision for income taxes |  |  | (14 | ) |  | (7 | ) |  | 20 |  |
| Net income |  | $ | 1,570 |  | $ | 1,838 |  | $ | 2,862 |  |

[0001047469-14-006770:mdna:44]
|  |  | Fiscal Years Ended |  |
| (as a percentage of Revenue) |  | June 27, 2014 |  | June 28, 2013 |  | June 29, 2012 |  |
| Revenue |  |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  |  | 72 |  |  | 73 |  |  | 69 |  |
| Gross margin |  |  | 28 |  |  | 27 |  |  | 31 |  |
| Product development |  |  | 9 |  |  | 8 |  |  | 7 |  |
| Marketing and administrative |  |  | 5 |  |  | 4 |  |  | 4 |  |
| Amortization of intangibles |  |  | 1 |  |  | 1 |  |  | — |  |
| Restructuring and other, net |  |  | — |  |  | — |  |  | — |  |
| Income from operations |  |  | 13 |  |  | 14 |  |  | 21 |  |
| Other expense, net |  |  | (2 | ) |  | (2 | ) |  | (2 | ) |
| Income before income taxes |  |  | 11 |  |  | 12 |  |  | 19 |  |
| (Benefit from) provision for income taxes |  |  | — |  |  | — |  |  | — |  |
| Net income |  |  | 11 | % |  | 12 | % |  | 19 | % |

[0001047469-14-006770:mdna:45]
46

[0001047469-14-006770:mdna:46]
The
following table summarizes information regarding revenue, volume shipments, exabytes, average selling prices (ASPs) and revenues by channel and geography:

[0001047469-14-006770:mdna:47]
|  |  | Fiscal Years Ended |  |
| (In millions, except percentages, exabytes and ASPs) |  | June 27, 2014 |  | June 28, 2013 |  | June 29, 2012 |  |
| Net Revenue |  | $ | 13,724 |  | $ | 14,351 |  | $ | 14,939 |  |
| Unit Shipments: |  |  |  |  |  |  |  |  |  |  |
| Enterprise |  |  | 31 |  |  | 30 |  |  | 29 |  |
| Client Compute |  |  | 144 |  |  | 151 |  |  | 156 |  |
| Client Non-Compute |  |  | 45 |  |  | 45 |  |  | 39 |  |
| Total Units Shipped |  |  | 220 |  |  | 226 |  |  | 224 |  |
| ASP (per unit) |  | $ | 61 |  | $ | 63 |  | $ | 66 |  |
| Exabytes Shipped |  |  | 202 |  |  | 185 |  |  | 150 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEM |  |  | 68 | % |  | 68 | % |  | 72 | % |
| Distributors |  |  | 20 | % |  | 21 | % |  | 21 | % |
| Retail |  |  | 12 | % |  | 11 | % |  | 7 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |
| Americas |  |  | 27 | % |  | 27 | % |  | 26 | % |
| EMEA |  |  | 19 | % |  | 19 | % |  | 19 | % |
| Asia Pacific |  |  | 54 | % |  | 54 | % |  | 55 | % |

[0001047469-14-006770:mdna:48]
Fiscal Year 2014 Compared to Fiscal Year 2013

[0001047469-14-006770:mdna:49]
Revenue

[0001047469-14-006770:mdna:50]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 27, 2014 |  | June 28, 2013 |  | Change |  | % Change |  |
| Revenue |  | $ | 13,724 |  | $ | 14,351 |  | $ | (627 | ) |  | (4 | )% |

[0001047469-14-006770:mdna:51]
Revenue
in fiscal year 2014 decreased approximately 4%, or $0.6 billion, from fiscal year 2013 as a result of a 3% decrease in units shipped and a $2 decrease in the ASP due to
price erosion, partially offset by a more favorable product mix.

[0001047469-14-006770:mdna:52]
Gross Margin

[0001047469-14-006770:mdna:53]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 27, 2014 |  | June 28, 2013 |  | Change |  | % Change |  |
| Cost of revenue |  | $ | 9,878 |  | $ | 10,411 |  | $ | (533 | ) |  | (5 | )% |
| Gross margin |  | $ | 3,846 |  | $ | 3,940 |  | $ | (94 | ) |  | (2 | )% |
| Gross margin percentage |  |  | 28 | % |  | 27 | % |  |  |  |  |  |  |

[0001047469-14-006770:mdna:54]
For
fiscal year 2014, gross margin as a percentage of revenue increased to 28% from 27% in the prior fiscal year, as a result of improved product mix and cost savings due to increases in
operational efficiencies, offset by modest price erosion.

[0001047469-14-006770:mdna:55]
Operating Expenses

[0001047469-14-006770:mdna:56]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 27, 2014 |  | June 28, 2013 |  | Change |  | % Change |  |
| Product development |  | $ | 1,226 |  | $ | 1,133 |  | $ | 93 |  |  | 8 | % |
| Marketing and administrative |  |  | 722 |  |  | 635 |  |  | 87 |  |  | 14 | % |
| Amortization of intangibles |  |  | 98 |  |  | 79 |  |  | 19 |  |  | 24 | % |
| Restructuring and other, net |  |  | 24 |  |  | 2 |  |  | 22 |  |  | 1,100 | % |
| Operating expenses |  | $ | 2,070 |  | $ | 1,849 |  | $ | 221 |  |  |  |  |

[0001047469-14-006770:mdna:57]
Product Development Expense.    Product development expenses for fiscal year 2014 increased from fiscal year 2013 due to increased
investments in HDD
and alternative storage technologies of approximately $35 million and headcount related costs of approximately $36 million, net of a decrease in variable performance based compensation
expenses of $26 million. In addition, the consolidation of Xyratex, acquired on March 31, 2014 contributed approximately $23 million to Product development expense.

[0001047469-14-006770:mdna:58]
Marketing and Administrative Expense.    Marketing and administrative expenses for fiscal year 2014 increased from fiscal year 2013 due to
a
$40 million increase in headcount related expenses due to annual focal increases and increased investments in certain strategic initiatives as well as enhancement of core businesses of
$25 million. In addition, the consolidation of Xyratex contributed approximately $15 million to Marketing and administrative expense.

[0001047469-14-006770:mdna:59]
Amortization of Intangibles.    Amortization of intangibles for fiscal year 2014 increased from fiscal year 2013 due to the commencement of
amortization
of certain in-process research and development assets acquired from Samsung's HDD business in December of 2011 and LaCie in August of 2012.

[0001047469-14-006770:mdna:60]
Restructuring and Other, net.    Restructuring and other, net for fiscal years 2014 increased from fiscal year 2013 primarily due to a
restructuring
charge recorded during the December 2013 quarter associated with a reduction in work force.

[0001047469-14-006770:mdna:61]
Other Expense, net

[0001047469-14-006770:mdna:62]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 27, 2014 |  | June 28, 2013 |  | Change |  | % Change |  |
| Other expense, net |  | $ | (220 | ) | $ | (260 | ) | $ | 40 |  |  | (15 | )% |

[0001047469-14-006770:mdna:63]
Other expense, net.    Other expense, net for fiscal year 2014 decreased by $40 million from fiscal year 2013 due to a
$60 million
decrease in losses from the early redemption and repurchase of debt and a decrease of $18 million in interest expense due to a reduction in the average interest rate on our outstanding debt.
These decreases were partially offset by insurance proceeds of $25 million received during fiscal year 2013 for equipment damaged during the severe flooding in Thailand in October of 2011 and
$17 million lower gains on sales of our available for sale securities and strategic investments.

[0001047469-14-006770:mdna:64]
Income Taxes

[0001047469-14-006770:mdna:65]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 27, 2014 |  | June 28, 2013 |  | Change |  | % Change |  |
| (Benefit from) provision for income taxes |  | $ | (14 | ) | $ | (7 | ) | $ | (7 | ) |  | 100 | % |

[0001047469-14-006770:mdna:66]
We recorded an income tax benefit of $14 million for fiscal year 2014 compared to an income tax benefit of $7 million for fiscal year 2013. Our
fiscal year 2014 benefit from income taxes included $58 million of income tax benefits related to the reversal of a portion of the valuation allowances recorded in prior periods and a net
decrease in tax reserves related to audit settlements offset by tax reserves on non-U.S. tax positions taken in prior fiscal years. Our fiscal year 2013 benefit for income taxes included
$52 million of income tax benefit from the reversal of a portion of the U.S. valuation allowance recorded in prior periods.

[0001047469-14-006770:mdna:67]
Our
Irish tax resident parent holding company owns various U.S. and non-U.S. subsidiaries that operate in multiple non-Irish tax jurisdictions. Our worldwide operating income is either
subject to varying rates of tax or is exempt from tax due to tax holidays or tax incentive programs we operate under in Malaysia, Singapore and Thailand. These tax holidays or incentives are scheduled
to expire in whole or in part at various dates through 2020.

[0001047469-14-006770:mdna:68]
Our
income tax benefit recorded for fiscal year 2014 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before
income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are
considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets. The acquisition of Xyratex is not expected to have a material
impact on our effective tax rate in future periods. Fiscal
year 2014 included a valuation allowance release associated with post-acquisitions restructuring. Our income tax benefit recorded for fiscal year 2013 differed from the provision for income taxes that
would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in
jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, and (ii) a decrease in valuation allowance for certain
U.S. deferred tax assets. The acquisition of a majority interest in the outstanding shares of LaCie did not have a material impact on our effective tax rate in fiscal year 2013.

[0001047469-14-006770:mdna:69]
Based
on our non-U.S. ownership structure and subject to (i) potential future increases in our valuation allowance for deferred tax assets; and (ii) a future change in our
intention to indefinitely reinvest earnings from our subsidiaries outside of Ireland, we anticipate that our effective tax rate in future periods will generally be less than the Irish statutory rate.

[0001047469-14-006770:mdna:70]
At
June 27, 2014, our deferred tax asset valuation allowance was approximately $888 million.

[0001047469-14-006770:mdna:71]
At
June 27, 2014, we had net deferred tax assets of $615 million. The realization of these deferred tax assets is primarily dependent on our ability to generate sufficient
U.S. and certain non-U.S. taxable income in future periods. Although realization is not assured, we believe that it is more likely than not that these deferred tax assets will be realized. The amount
of deferred tax assets considered realizable, however, may increase or decrease in subsequent periods when we re-evaluate the underlying basis for our estimates of future U.S. and certain non-U.S.
taxable income.

[0001047469-14-006770:mdna:72]
As
of June 27, 2014, the use of approximately $376 million and $90 million of our total U.S. net operating loss and tax credit carry forwards, respectively, is
subject to an aggregate annual limitation of $46 million pursuant to U.S. tax law. If certain ownership changes occur in the foreseeable future, there may be an additional annual limitation on
our ability to use our total U.S. federal and state net operating loss and credit carryforwards of $2.9 billion, $1.8 billion and $429 million, respectively. It is reasonably
possible that such a change could occur. If these ownership changes were to occur, we estimate a one-time charge for additional U.S. income tax expense of approximately $400 million to
$500 million may be recorded in the period such change occurs. This additional income tax expense results from a decrease in our net U.S. deferred tax assets recorded through a combination of
the write off of deferred tax assets and associated changes to our valuation allowance. We also estimate that the ensuing additional annual limitation on our ability to use our tax attribute
carryovers may result in increased U.S. income tax expense associated with such change of approximately $70 million to $85 million each year.

[0001047469-14-006770:mdna:73]
As
of June 27, 2014 and June 28, 2013, we had approximately $115 million and $157 million, respectively, of unrecognized tax benefits excluding interest and
penalties. The unrecognized tax benefits that, if recognized, would impact the effective tax rate is $115 million and $157 million as of June 27, 2014 and June 28, 2013,
respectively, subject to certain future valuation allowance reversals.

[0001047469-14-006770:mdna:74]
It
is our policy to include interest and penalties related to unrecognized tax benefits in the provision for taxes on the Consolidated Statements of Operations. During fiscal year 2014,
we recognized a net tax expense for interest and penalties of $8 million as compared to a net tax expense for interest and penalties of $2 million during each fiscal year 2013 and fiscal
year 2012. As of June 27, 2014, we had $27 million of accrued interest and penalties related to unrecognized tax benefits compared to $19 million in fiscal year 2013.

[0001047469-14-006770:mdna:75]
During
the fiscal year ended June 27, 2014, our unrecognized tax benefits excluding interest and penalties decreased by approximately $42 million primarily due to
(i) net decreases in prior years unrecognized tax benefits of $54 million, (ii) increases in current year unrecognized tax benefits of $13 million, (iii) decreases
associated with the expiration of certain statutes of limitation of $3 million, (iv) increases from other activity, including non-U.S. exchange gains, of $2 million.

[0001047469-14-006770:mdna:76]
During
the 12 months beginning June 28, 2014, we expect that our unrecognized tax benefits could be reduced anywhere from $3 million to $50 million as a
result of audit settlements and the expiration of certain statutes of limitation.

[0001047469-14-006770:mdna:77]
We
are subject to taxation in many jurisdictions globally and are required to file U.S. federal, U.S. state, and non-U.S income tax returns. In June, 2014, we received the Revenue
Agent's Report and Notices of Proposed Adjustments for our U.S. federal income tax returns for fiscal years 2008, 2009 and 2010. Our China subsidiaries are under examination by the Chinese tax
administration for years 2004 through 2012. These examinations may result in proposed adjustments to our income taxes as filed during these periods. We believe that we have adequately provided for
these matters, but there is a reasonable possibility that an adverse outcome of these examinations could have a material effect on our financial results. In this case, we would consider pursuing all
possible remedies available to us, including appeals, judicial review and competent authority.

[0001047469-14-006770:mdna:78]
We
are no longer subject to tax examination of U.S. federal income tax returns for years prior to fiscal year 2008. With respect to U.S. state and non-U.S. income tax returns, we are
generally no longer subject to tax examination for years ending prior to fiscal year 2004. We believe we have provided adequately for all reasonable outcomes.

[0001047469-14-006770:mdna:79]
Fiscal Year 2013 Compared to Fiscal Year 2012

[0001047469-14-006770:mdna:80]
Revenue

[0001047469-14-006770:mdna:81]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 28, 2013 |  | June 29, 2012 |  | Change |  | % Change |  |
| Revenue |  | $ | 14,351 |  | $ | 14,939 |  | $ | (588 | ) |  | (4 | )% |

[0001047469-14-006770:mdna:82]
Revenue
in fiscal year 2013 decreased approximately 4%, or $0.6 billion, from fiscal year 2012 due to a decrease in the average selling price per unit. The decrease in the average
selling price to $63 per unit during fiscal year 2013, as compared to $66 per unit in the prior year, was primarily due to supply constraints beginning in the second quarter of fiscal year 2012 as a
result of the severe flooding in Thailand, partially offset by a favorable product mix and slightly higher volumes in fiscal year 2013, which included a full period of Samsung labeled HDD products.

[0001047469-14-006770:mdna:83]
Gross Margin

[0001047469-14-006770:mdna:84]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 28, 2013 |  | June 29, 2012 |  | Change |  | % Change |  |
| Cost of revenue |  | $ | 10,411 |  | $ | 10,255 |  | $ | 156 |  |  | 2 | % |
| Gross margin |  | $ | 3,940 |  | $ | 4,684 |  | $ | (744 | ) |  | (16 | )% |
| Gross margin percentage |  |  | 27 | % |  | 31 | % |  |  |  |  |  |  |

[0001047469-14-006770:mdna:85]
For
fiscal year 2013, gross margin as a percentage of revenue decreased to 27% from 31% in the prior fiscal year, as a result of higher ASPs during fiscal year 2012. Our ASPs during
fiscal year 2012 were increased due to the limited industry supply of hard drives as a result of the severe flooding in Thailand.

[0001047469-14-006770:mdna:86]
Operating Expenses

[0001047469-14-006770:mdna:87]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 28, 2013 |  | June 29, 2012 |  | Change |  | % Change |  |
| Product development |  | $ | 1,133 |  | $ | 1,006 |  | $ | 127 |  |  | 13 | % |
| Marketing and administrative |  |  | 635 |  |  | 528 |  |  | 107 |  |  | 20 | % |
| Amortization of intangibles |  |  | 79 |  |  | 38 |  |  | 41 |  |  | 108 | % |
| Restructuring and other, net |  |  | 2 |  |  | 4 |  |  | (2 | ) |  | (50 | )% |
| Operating expenses |  | $ | 1,849 |  | $ | 1,576 |  | $ | 273 |  |  |  |  |

[0001047469-14-006770:mdna:88]
Product Development Expense.    Product development expenses for fiscal year 2013 increased from fiscal year 2012, primarily due to
increased
investments in HDD and alternative storage technologies of approximately $84 million, and headcount related costs of approximately $41 million, net of a decrease in variable performance
based compensation of approximately $7 million.

[0001047469-14-006770:mdna:89]
Marketing and Administrative Expense.    Marketing and administrative expenses for fiscal year 2013 increased from fiscal year 2012
primarily due to
further investments in certain strategic initiatives as well as enhancement of our core business operations. This, along with our annual focal increases, resulted in additional headcount related costs
of $64 million, net of a reduction in variable performance based compensation of $7 million. In addition, the consolidation of LaCie in fiscal year 2013 contributed approximately
$32 million to Marketing and administrative expense.

[0001047469-14-006770:mdna:90]
Amortization of Intangibles.    Amortization of intangibles for fiscal year 2013 increased as a result of the acquisition of Samsung's HDD
business in
December of 2011, and LaCie in August of 2012.

[0001047469-14-006770:mdna:91]
Restructuring and Other, net.    Restructuring and other, net for fiscal years 2013 and 2012, was not material and primarily related to
previously
announced restructuring plans.

[0001047469-14-006770:mdna:92]
Other Expense, net

[0001047469-14-006770:mdna:93]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 28, 2013 |  | June 29, 2012 |  | Change |  | % Change |  |
| Other expense, net |  | $ | (260 | ) | $ | (226 | ) | $ | (34 | ) |  | 15 | % |

[0001047469-14-006770:mdna:94]
Other
expense, net for fiscal year 2013 compared to fiscal year 2012 increased due to a loss of $141 million on the early redemption and repurchase of debt. These losses were
partially offset by gains recorded for sales of our available for sale securities and strategic investments of $61 million, insurance proceeds of $25 million for equipment damaged during
the severe flooding in Thailand in October of 2011,

[0001047469-14-006770:mdna:95]
and
a decrease in interest expense of $27 million due to a reduction in our average interest rate and total debt levels.

[0001047469-14-006770:mdna:96]
Income Taxes

[0001047469-14-006770:mdna:97]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 28, 2013 |  | June 29, 2012 |  | Change |  | % Change |  |
| (Benefit from) provision for income taxes |  | $ | (7 | ) | $ | 20 |  | $ | (27 | ) |  | (135 | )% |

[0001047469-14-006770:mdna:98]
We
recorded an income tax benefit of $7 million for fiscal year 2013 compared to an income tax provision of $20 million for fiscal year 2012. Our fiscal year 2013 benefit
for income taxes included $52 million of income tax benefit from the reversal of a portion of the U.S. valuation allowance recorded in prior periods. Our fiscal year 2012 provision for income
taxes included $35 million of income tax benefit from the reversal of a portion of the U.S. valuation allowance recorded in prior periods.

[0001047469-14-006770:mdna:99]
Our
income tax benefit recorded for fiscal year 2013 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before
income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are
considered indefinitely reinvested outside of Ireland, and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets. The acquisition of a majority interest in the outstanding
shares of LaCie did not have a material impact on our effective tax rate in fiscal year 2013. Our income tax provision recorded for fiscal year 2012 differed from the provision for income taxes that
would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in
jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, and (ii) a decrease in valuation allowance for certain
U.S. deferred tax assets. The acquisition of Samsung's HDD business did not have a significant impact on our effective tax rate in fiscal year 2012.

[0001047469-14-006770:mdna:100]
Liquidity and Capital Resources

[0001047469-14-006770:mdna:101]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and
capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist primarily
of readily marketable securities with remaining maturities of more than 90 days at the time of purchase. The principal objectives of our investment policy are the preservation of principal and
maintenance of liquidity. We intend to maintain a highly liquid portfolio by investing only in those marketable securities that we believe have active secondary or resale markets. We believe our cash
equivalents and short-term investments are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders.
However, these restrictions have not impeded our ability to conduct our business, nor do we expect them to in the next 12 months. We are not aware of any downgrades, losses or other significant
deterioration in the fair value of our cash equivalents or short-term investments and accordingly, we do not believe the fair value of our short-term investments has significantly changed from the
values reported as of June 27, 2014.

[0001047469-14-006770:mdna:102]
52

[0001047469-14-006770:mdna:103]
Cash and cash equivalents, short-term investments, and restricted cash and investments

[0001047469-14-006770:mdna:104]
|  |  | As of |  |
| (Dollars in millions) |  | June 27, 2014 |  | June 28, 2013 |  | Change |  |
| Cash and cash equivalents |  | $ | 2,634 |  | $ | 1,708 |  | $ | 926 |  |
| Short-term investments |  |  | 20 |  |  | 480 |  |  | (460 | ) |
| Restricted cash and investments |  |  | 4 |  |  | 101 |  |  | (97 | ) |
| Total |  | $ | 2,658 |  | $ | 2,289 |  | $ | 369 |  |

[0001047469-14-006770:mdna:105]
Our
cash and cash equivalents, short-term investments and restricted cash and investments increased from June 28, 2013 as a result of net cash provided by operating activities and
the proceeds from the issuance of $800 million of our 3.75% Senior Notes due 2018 and $1 billion of our 4.75% Senior Notes due 2025. These cash inflows were partially offset by
repurchases of our ordinary shares, redemption and repurchase of certain of our long-term debt, capital expenditures, dividends paid to our shareholders and the acquisition of Xyratex.

[0001047469-14-006770:mdna:106]
The
following table summarizes results from the statement of cash flows for the periods indicated:

[0001047469-14-006770:mdna:107]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 27, 2014 |  | June 28, 2013 |  | June 29, 2012 |  |
| Net cash flow provided by (used in): |  |  |  |  |  |  |  |  |  |  |
| Operating activities |  | $ | 2,558 |  | $ | 3,047 |  | $ | 3,262 |  |
| Investing activities |  |  | (322 | ) |  | (825 | ) |  | (1,114 | ) |
| Financing activities |  |  | (1,311 | ) |  | (2,222 | ) |  | (3,118 | ) |
| Effect of foreign currency exchange rates |  |  | 1 |  |  | 1 |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | 926 |  | $ | 1 |  | $ | (970 | ) |

[0001047469-14-006770:mdna:108]
Cash Provided by Operating Activities

[0001047469-14-006770:mdna:109]
Cash provided by operating activities for fiscal year 2014 was approximately $2.6 billion and includes the effects of net income
adjusted for non-cash items including depreciation, amortization, stock-based compensation, and:

[0001047469-14-006770:mdna:110]
•

[0001047469-14-006770:mdna:111]
a decrease of $217 million in vendor non-trade receivables primarily related to a change in the contractual
relationship with some of our contract manufacturers which reduced the volume of components we sold to them;

[0001047469-14-006770:mdna:112]
•

[0001047469-14-006770:mdna:113]
a decrease of $190 million in accounts payable due to a change in the contractual relationship with some of our
contract manufacturers which resulted in a reduction in direct materials purchased and subsequently sold to our contract manufacturers; and

[0001047469-14-006770:mdna:114]
•

[0001047469-14-006770:mdna:115]
a decrease of $104 million in restricted cash and investments primarily due to the restricted cash and investments
held in a rabbi trust being replaced with a standby letter of credit.

[0001047469-14-006770:mdna:116]
Cash
provided by operating activities for fiscal year 2013 was approximately $3.0 billion and includes the effects of net income adjusted for non-cash items including
depreciation, amortization, stock-based compensation, and:

[0001047469-14-006770:mdna:117]
•

[0001047469-14-006770:mdna:118]
a decrease of $661 million in accounts receivable, net, primarily due to a decrease in revenue in the fourth
quarter of fiscal year 2013 compared to the prior year period;

[0001047469-14-006770:mdna:119]
•

[0001047469-14-006770:mdna:120]
a decrease of $538 million in accounts payable, primarily due to a reduction in direct materials purchases due to
a decrease in build volume in the fourth quarter of fiscal year 2013 compared to the prior year period;

[0001047469-14-006770:mdna:121]
•

[0001047469-14-006770:mdna:122]
a decrease of $272 million in vendor non-trade receivables primarily due to a decrease in build volumes in the
fourth quarter of fiscal year 2013 compared to the prior year period;

[0001047469-14-006770:mdna:123]
•

[0001047469-14-006770:mdna:124]
a decrease of $170 million in accrued expenses, income taxes and warranty, primarily due to decreases in costs
related to sales activities resulting from lower sales volumes; and

[0001047469-14-006770:mdna:125]
•

[0001047469-14-006770:mdna:126]
a decrease of $102 million in inventory, due to lower volumes in the fourth quarter of fiscal year 2013 compared
to the prior year period.

[0001047469-14-006770:mdna:127]
Cash
provided by operating activities for fiscal year 2012 was approximately $3.3 billion and includes the effects of net income adjusted for non-cash items including
depreciation, amortization, stock-based compensation, impairment of long-lived assets, and:

[0001047469-14-006770:mdna:128]
•

[0001047469-14-006770:mdna:129]
an increase of $824 million in accounts receivable, net, due to an increase in revenues;

[0001047469-14-006770:mdna:130]
•

[0001047469-14-006770:mdna:131]
an increase of $157 million in accounts payable due to higher direct material purchases related to an increase in
volume, partially offset by a change in supplier payment terms; and

[0001047469-14-006770:mdna:132]
•

[0001047469-14-006770:mdna:133]
an increase of $145 million in accrued employee compensation reflecting an increase in variable performance-based
compensation.

[0001047469-14-006770:mdna:134]
Cash Used in Investing Activities

[0001047469-14-006770:mdna:135]
In fiscal year 2014, we used $0.3 billion for net cash investing activities, which was primarily due to payments for property,
equipment and leasehold improvements of approximately $559 million and the acquisition of Xyratex, of $285 million, partially offset by $508 million of proceeds from sales of
short-term investments.

[0001047469-14-006770:mdna:136]
In
fiscal year 2013, we used $0.8 billion for net cash investing activities, which was primarily due to payments for property, equipment and leasehold improvements.

[0001047469-14-006770:mdna:137]
In
fiscal year 2012, we used $1.1 billion for net cash investing activities, which was primarily due to payments for property, equipment and leasehold improvements of
approximately $0.6 billion and net payments for the acquisition of Samsung's HDD business of $0.6 billion.

[0001047469-14-006770:mdna:138]
Cash Used in Financing Activities

[0001047469-14-006770:mdna:139]
Net cash used in financing activities of $1.3 billion for fiscal year 2014 was primarily attributable to $1.9 billion
paid to repurchase 41 million of our ordinary shares, $0.7 billion for the repurchase and redemption of long term debt and $0.6 billion in dividends paid to our shareholders.
This use of cash was partially offset by $1.8 billion from aggregate cash generated from the issuance of our 3.75% Senior Notes due in 2018 and 4.75% Senior Notes due in 2025.

[0001047469-14-006770:mdna:140]
Net
cash used in financing activities of $2.2 billion for fiscal year 2013 was attributable to $1.7 billion paid to repurchase 54 million of our ordinary shares,
$1.2 billion for the repurchase and redemption of long term debt and $0.5 billion in dividends paid to our shareholders. This use of cash was partially offset by the proceeds from the
issuance of $1 billion of our 4.75% notes due 2023 and $0.3 billion in proceeds from the issuance of ordinary shares under employee stock plans.

[0001047469-14-006770:mdna:141]
Net
cash provided by financing activities of $3.1 billion for fiscal year 2012 was attributable to $2.4 billion paid to repurchase 101 million of our ordinary
shares, $0.7 billion in long term debt repayments and $0.4 billion in dividends paid to our shareholders. This use of cash was partially offset by $0.3 billion in proceeds from
the exercise of stock options and employee stock purchases.

[0001047469-14-006770:mdna:142]
54

[0001047469-14-006770:mdna:143]
Liquidity Sources

[0001047469-14-006770:mdna:144]
Our primary sources of liquidity as of June 27, 2014, consisted of: (1) approximately $2.7 billion in cash and
cash equivalents, and short-term investments, (2) cash we expect to generate from operations and (3) a $500 million revolving credit facility with an interest rate of LIBOR plus a
variable margin to be determined based on the corporate credit rating of the Company at the time a loan is made.

[0001047469-14-006770:mdna:145]
As
of June 27, 2014, no borrowings have been drawn under the revolving credit facility or had been utilized for letters of credit. The line of credit is available for borrowings,
subject to compliance with financial covenants and other customary conditions to borrowing.

[0001047469-14-006770:mdna:146]
The
credit agreement that governs our revolving credit facility, as amended, contains certain covenants that we must satisfy in order to remain in compliance with the credit agreement,
as amended. The agreement includes three financial covenants: (1) minimum cash, cash equivalents and marketable
securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. As of June 27, 2014, we were in compliance with all of the covenants under our Revolving Credit
Facility and debt agreements.

[0001047469-14-006770:mdna:147]
As
of June 27, 2014, cash and cash equivalents held by non-Irish subsidiaries was $2.6 billion. This amount is potentially subject to taxation in Ireland upon repatriation
by means of a dividend into our Irish parent. However, it is our intent to indefinitely reinvest earnings of non-Irish subsidiaries outside of Ireland and our current plans do not demonstrate a need
to repatriate such earnings by means of a taxable Irish dividend. Should funds be needed in the Irish parent company and should we be unable to fund parent company activities through means other than
a taxable Irish dividend, we would be required to accrue and pay Irish taxes on such dividend.

[0001047469-14-006770:mdna:148]
We
believe that our sources of cash will be sufficient to fund our operations and meet our cash requirements for at least the next 12 months.

[0001047469-14-006770:mdna:149]
Cash Requirements and Commitments

[0001047469-14-006770:mdna:150]
Our liquidity requirements are primarily to meet our working capital, research and development and capital expenditure needs, to fund
scheduled payments of principal and interest on our indebtedness, and to fund our dividend. Our ability to fund these requirements will depend on our future cash flows, which are determined by future
operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001047469-14-006770:mdna:151]
On
July 17, 2014, our Board of Directors approved a quarterly cash dividend of $0.43 per share, which will be payable on August 22, 2014 to shareholders of record as of the
close of business on August 8, 2014.

[0001047469-14-006770:mdna:152]
As
of June 27, 2014, we were in compliance with all of the covenants under our debt agreements. Based on our current outlook, we expect to be in compliance with the covenants of
our debt agreements over the next 12 months.

[0001047469-14-006770:mdna:153]
55

[0001047469-14-006770:mdna:154]
The
carrying value of our long-term debt as of June 27, 2014 and June 28, 2013 was $3.9 billion and $2.8 billion, respectively. The table below presents the
principal amounts of our outstanding long-term debt:

[0001047469-14-006770:mdna:155]
|  |  | As of |  |
| (Dollars in millions) |  | June 27, 2014 |  | June 28, 2013 |  | Change |  |
| 6.8% Senior Notes due October 2016 |  | $ | 335 |  | $ | 335 |  | $ | — |  |
| 3.75% Senior Notes due November 2018 |  |  | 800 |  |  | — |  |  | 800 |  |
| 7.75% Senior Notes due December 2018 |  |  | — |  |  | 238 |  |  | (238 | ) |
| 6.875% Senior Notes due May 2020 |  |  | 534 |  |  | 600 |  |  | (66 | ) |
| 7.00% Senior Notes due November 2021 |  |  | 251 |  |  | 600 |  |  | (349 | ) |
| 4.75% Senior Notes due June 2023 |  |  | 1,000 |  |  | 1,000 |  |  | — |  |
| 4.75% Senior Notes due January 2025 |  |  | 1,000 |  |  | — |  |  | 1,000 |  |
| Other |  |  | — |  |  | 4 |  |  | (4 | ) |
| Total |  | $ | 3,920 |  | $ | 2,777 |  | $ | 1,143 |  |

[0001047469-14-006770:mdna:156]
During
fiscal year 2014, we repurchased approximately 41 million of our ordinary shares. See "Item 5. Market for Registrant's Common Equity, Related Stockholder
Matters and Issuer Purchases of Equity Securities-Repurchases of Our Equity Securities."

[0001047469-14-006770:mdna:157]
On
May 29, 2014, we entered into a definitive asset purchase agreement under which we will acquire the assets of LSI's Accelerated Solutions Division ("ASD") and Flash Components
Division ("FCD") from Avago for $450 million in cash. The transaction is expected to close in the first quarter of fiscal year 2015, subject to the satisfaction of customary closing conditions
and the receipt of certain regulatory approvals, including those required by the Hart-Scott-Rodino Antitrust Improvements Act.

[0001047469-14-006770:mdna:158]
For
fiscal year 2015, we expect capital expenditures to be at or below our long-term targeted range of 6-8% of revenue. We require substantial amounts of cash to fund scheduled payments
of principal and interest on our indebtedness, future capital expenditures and any increased working capital requirements. We will continue to evaluate and manage the retirement and replacement of
existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging
existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases or otherwise. In addition, we may selectively pursue strategic
alliances, acquisitions and investments, which may require additional capital.

[0001047469-14-006770:mdna:159]
56

[0001047469-14-006770:mdna:160]
Contractual Obligations and Commitments

[0001047469-14-006770:mdna:161]
Our contractual cash obligations and commitments as of June 27, 2014, have been summarized in the table below:

[0001047469-14-006770:mdna:162]
|  |  |  |  | Fiscal Year(s) |  |
| (Dollars in millions) |  | Total |  | 2015 |  | 2016- 2017 |  | 2018- 2019 |  | Thereafter |  |
| Contractual Cash Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | $ | 3,920 |  | $ | — |  | $ | 335 |  | $ | 800 |  | $ | 2,785 |  |
| Interest payments on debt |  |  | 1,482 |  |  | 216 |  |  | 360 |  |  | 344 |  |  | 562 |  |
| Capital expenditures |  |  | 189 |  |  | 109 |  |  | 80 |  |  | — |  |  | — |  |
| Operating leases(1) |  |  | 200 |  |  | 42 |  |  | 52 |  |  | 37 |  |  | 69 |  |
| Purchase obligations(2) |  |  | 772 |  |  | 772 |  |  | — |  |  | — |  |  | — |  |
| Subtotal |  |  | 6,563 |  |  | 1,139 |  |  | 827 |  |  | 1,181 |  |  | 3,416 |  |
| Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit or bank guarantees |  |  | 104 |  |  | 104 |  |  | — |  |  | — |  |  | — |  |
| Total |  | $ | 6,667 |  | $ | 1,243 |  | $ | 827 |  | $ | 1,181 |  | $ | 3,416 |  |

[0001047469-14-006770:mdna:163]
(1)

[0001047469-14-006770:mdna:164]
Includes
total future minimum rent expense under non-cancelable leases for both occupied and vacated facilities (rent expense is shown net of sublease
income).

[0001047469-14-006770:mdna:165]
(2)

[0001047469-14-006770:mdna:166]
Purchase
obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that
specify all significant terms.

[0001047469-14-006770:mdna:167]
As
of June 27, 2014, we had a liability for unrecognized tax benefits and an accrual for the payment of related interest totaling $90 million, none of which is expected to
be settled within one year. Outside of one year, we are unable to make a reasonably reliable estimate of when cash settlement with a taxing authority will occur.

[0001047469-14-006770:mdna:168]
On
May 29, 2014, we entered into a definitive asset purchase agreement under which we will acquire the assets of LSI's Accelerated Solutions Division ("ASD") and Flash Components
Division ("FCD") from Avago for $450 million in cash. The transaction is expected to close in the first quarter of fiscal year 2015, subject to the satisfaction of customary closing conditions
and the receipt of certain regulatory approvals, including those required by the Hart-Scott-Rodino Antitrust Improvements Act.

[0001047469-14-006770:mdna:169]
Off-Balance Sheet Arrangements

[0001047469-14-006770:mdna:170]
As of June 27, 2014, we did not have any material off-balance sheet arrangements (as defined in Item 303(a)(4)(ii) of
Regulation S-K).

[0001047469-14-006770:mdna:171]
Critical Accounting Policies

[0001047469-14-006770:mdna:172]
The methods, estimates and judgments we use in applying our most critical accounting policies have a significant impact on the results
we report in our consolidated financial statements. The SEC has defined the most critical accounting policies as the ones that are most important to the portrayal of our financial condition and
operating results, and require us to make our most difficult and subjective judgments, often as a result of the need to make estimates of matters that are highly uncertain at the time of estimation.
Based on this definition, our most critical policies include: establishment of sales program accruals, establishment of warranty accruals, accounting for income taxes, and the accounting for goodwill
and other long-lived assets. Below, we discuss these policies further, as well as the estimates and judgments involved. We also have other accounting policies and accounting estimates relating to
uncollectible customer accounts, valuation of inventory, valuation of share-based payments and restructuring. We believe that these other accounting policies and accounting estimates either do not
generally require us to make

[0001047469-14-006770:mdna:173]
estimates
and judgments that are as difficult or as subjective, or it is less likely that they would have a material impact on our reported results of operations for a given period.

[0001047469-14-006770:mdna:174]
Establishment of Sales Program Accruals.    We establish certain distributor and OEM sales programs aimed at increasing customer demand.
For OEM sales,
rebates are typically based on an OEM customer's volume of purchases or other agreed upon rebate programs. For the distribution channel, these programs typically involve rebates related to a
distributor's level of sales, order size, advertising or point of sale activity and price protection adjustments. We provide for these obligations at the time that revenue is recorded based on
estimated requirements. We estimate these contra-revenue rebates and adjustments based on various factors, including price reductions during the period reported, estimated future price erosion,
customer orders, distributor sell-through and inventory levels, program participation, customer claim submittals and sales returns. Our estimates reflect contractual
arrangements but also our judgment relating to variables such as customer claim rates and attainment of program goals, and inventory and sell-through levels reported by our distribution customers.
Currently, our distributors' inventories are within the historical range.

[0001047469-14-006770:mdna:175]
While
we believe we have sufficient experience and knowledge of the market and customer buying patterns to reasonably estimate such rebates and adjustments, actual market conditions or
customer behavior could differ from our expectations. As a result, actual payments under these programs, which may spread over several months after the related sale, may vary from the amount accrued.
Accordingly, revenues and margins in the period in which the adjustment occurs may be affected.

[0001047469-14-006770:mdna:176]
Significant
actual variations in any of the factors upon which we base our contra-revenue estimates could have a material effect on our operating results. In fiscal year 2014, sales
programs were approximately 8% of gross revenue. For fiscal years 2013 and 2012, total sales programs ranged from 2% to 10% of gross revenues. Adjustments to revenues due to under or over accruals for
sales programs related to revenues reported in prior quarterly periods averaged 0.3% of quarterly gross revenue for fiscal years 2012 through 2013, and were approximately 0.5% of gross revenue in
fiscal year 2014. Any future shifts in the industry supply-demand balance as well as other factors may result in a more competitive pricing environment and may cause sales programs as a percentage of
gross revenue to increase from the current or historical levels. If such rebates and incentives trend upwards, revenues and margins will be reduced.

[0001047469-14-006770:mdna:177]
Establishment of Warranty Accruals.    We estimate probable product warranty costs at the time revenue is recognized. We generally warrant
our products
for a period of 1 to 5 years. Our warranty provision considers estimated product failure rates and trends (including the timing of product returns during the warranty periods), and estimated
repair or replacement costs related to product quality issues, if any. We also exercise judgment in estimating our ability to sell certain repaired disk drives. Should actual experience in any future
period differ significantly from our estimates, our future results of operations could be materially affected. Our judgment is subject to a greater degree of subjectivity with respect to newly
introduced products because of limited experience with those products upon which to base our warranty estimates.

[0001047469-14-006770:mdna:178]
The
actual results with regard to warranty expenditures could have an adverse or favorable effect on our results of operations if the actual rate of unit failure, the cost to repair a
unit, or the actual cost required to satisfy customer claims differs from those estimates we used in determining the warranty accrual. Since we typically outsource our warranty repairs, our repair
cost is subject to periodic negotiations with vendors and may vary from our estimates. We also exercise judgment in estimating our ability to sell certain repaired disk drives. To the extent such
sales fall below our forecast, warranty cost will be adversely impacted.

[0001047469-14-006770:mdna:179]
We
review our warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in
adjustments that impact the current period gross margins and income. In fiscal years 2014, 2013 and 2012 net changes in
estimates of prior warranty accruals as a percentage of revenue were immaterial. Our total warranty cost was 1.3%,

[0001047469-14-006770:mdna:180]
1.6%
and 1.5% of revenue during fiscal years 2014, 2013 and 2012, respectively, while warranty cost related to new shipments (exclusive of the impact of re-estimates of pre-existing liabilities) were
1.3%, 1.3% and 1.1% respectively, for the same periods. Changes in anticipated failure rates of specific products and significant changes in repair or replacement costs have historically been the
major reasons for significant changes in prior estimates. Any future changes in failure rates of certain products, as well as changes in repair costs or the cost of replacement parts, may result in
increased or decreased warranty accruals.

[0001047469-14-006770:mdna:181]
Accounting for Income Taxes.    We account for income taxes pursuant to Accounting Standards Codification (ASC) Topic 740 (ASC 740),
Income Taxes. In
applying, ASC 740, we make certain estimates and judgments in determining income tax expense for financial statement purposes. These estimates and judgments occur in the calculation of tax credits,
recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for tax and financial
statement purposes, as well as tax liabilities associated with uncertain tax positions. The calculation of tax liabilities involves uncertainties in the application of complex tax rules and the
potential for future adjustment of our uncertain tax positions by the Internal Revenue Service or other tax jurisdictions. If estimates of these tax liabilities are greater or less than actual
results, an additional tax benefit or provision will result. The deferred tax assets we record each period depend primarily on our ability to generate future taxable income in the United States and
certain non-U.S. jurisdictions. Each period, we evaluate the need for a valuation allowance for our deferred tax assets and, if necessary, we adjust the valuation allowance so that net deferred tax
assets are recorded only to the extent we conclude it is more likely than not that these deferred tax assets will be realized. If our outlook for future taxable income changes significantly, our
assessment of the need for a valuation allowance may also change.

[0001047469-14-006770:mdna:182]
Assessing Goodwill and Other Long-lived Assets for Impairment.    We account for goodwill in accordance with ASC Topic 350,  Intangibles—Goodwill and Other. As permitted by ASC 350, we perform a qualitative assessment at the end of each reporting period to
determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the
fair value of a reporting unit below its carrying amount. Based on the qualitative assessment, if it is not more likely than not that the fair value of a reporting unit is less than its carrying
amount, then the Company is not required to perform the two-step goodwill impairment test.

[0001047469-14-006770:mdna:183]
In
accordance with ASC 360-05-4, Impairment or Disposal of Long-lived Assets, we test other long-lived assets, including property,
equipment and leasehold improvements and other intangible assets subject to amortization, for recoverability whenever events or changes in circumstances indicate that the carrying values of those
assets may not be recoverable. We assess the recoverability of an asset group by determining if the carrying value of the asset group exceeds the sum of the projected undiscounted cash flows expected
to result from the use and eventual disposition of the assets over the remaining economic life of the primary asset in the asset group. If the recoverability test indicates that the carrying value of
the asset group is not recoverable, we will estimate the fair value of the asset group using the same approaches indicated above for ASC 360 step two and compare it to its carrying value. The excess
of the carrying value over the fair value is allocated pro rata to derive the adjusted carrying value of each asset in the asset group. The adjusted carrying value of each asset in the asset group is
not reduced below its fair value.

[0001047469-14-006770:mdna:184]
Recent Accounting Pronouncements

[0001047469-14-006770:mdna:185]
See "Item 8. Financial Statements and Supplementary Data-Note 1. Basis of Presentation and Summary of Significant
Accounting Policies" for information regarding the effect of new accounting pronouncements on our financial statements.
