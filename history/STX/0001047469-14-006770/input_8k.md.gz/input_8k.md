# STX 8-K — 0001104659-14-052019 filed 2014-07-17

## item codes, every 8-K on or before 2014-08-08

- 2014-07-23 0001104659-14-052995 — 5.02
- 2014-07-17 0001104659-14-052019 — 2.02, 7.01, 9.01
- 2014-06-18 0001104659-14-046714 — 8.01, 9.01
- 2014-06-09 0001104659-14-044575 — 7.01
- 2014-06-04 0001104659-14-043897 — 8.01
- 2014-05-28 0001104659-14-041862 — 1.01, 2.03, 8.01, 9.01
- 2014-05-20 0001104659-14-040454 — 8.01, 9.01
- 2014-05-20 0001104659-14-040220 — 8.01, 9.01
- 2014-04-29 0001104659-14-031916 — 2.02, 7.01, 9.01
- 2014-04-22 0001104659-14-029197 — 5.02
- 2014-02-24 0001104659-14-012465 — 5.02, 7.01, 9.01
- 2014-01-27 0001104659-14-004298 — 2.02, 7.01, 9.01
- 2014-01-23 0001104659-14-003803 — 5.02
- 2013-12-23 0001104659-13-091738 — 1.01, 8.01, 9.01
- 2013-11-05 0001104659-13-081194 — 1.01, 2.03, 9.01
- 2013-11-04 0001104659-13-080161 — 5.02, 5.03, 5.07, 9.01
- 2013-10-31 0001104659-13-079635 — 8.01, 9.01
- 2013-10-31 0001104659-13-079438 — 8.01, 9.01
- 2013-10-28 0001104659-13-078341 — 2.02, 7.01, 9.01
- 2013-10-28 0001104659-13-078316 — 5.02, 7.01, 9.01
- 2013-10-08 0001104659-13-074454 — 1.01, 1.02, 9.01
- 2013-09-20 0001104659-13-071413 — 5.02
- 2013-07-24 0001104659-13-056053 — 5.02, 7.01
- 2013-07-24 0001104659-13-056052 — 2.02, 7.01, 9.01
- 2013-06-14 0001104659-13-049436 — 8.01, 9.01
- 2013-05-31 0001104659-13-045928 — 8.01, 9.01
- 2013-05-22 0001104659-13-043876 — 1.01, 2.03, 9.01
- 2013-05-16 0001104659-13-042180 — 7.01, 9.01
- 2013-05-15 0001104659-13-042028 — 8.01, 9.01
- 2013-05-15 0001104659-13-041695 — 8.01, 9.01
- 2013-05-07 0001104659-13-038226 — 5.02
- 2013-05-01 0001104659-13-036004 — 2.02, 9.01
- 2013-03-15 0001104659-13-021156 — 7.01
- 2013-01-28 0001104659-13-005180 — 2.02, 9.01
- 2013-01-08 0001104659-13-001291 — 2.02, 9.01
- 2012-11-29 0001104659-12-080911 — 8.01, 9.01
- 2012-10-31 0001104659-12-072476 — 2.02, 9.01
- 2012-10-25 0001104659-12-071208 — 5.07
- 2012-10-16 0001104659-12-069238 — 7.01
- 2012-09-28 0001104659-12-066105 — 7.01
- 2012-09-21 0001104659-12-064869 — 7.01
- 2012-08-02 0001104659-12-053775 — 5.02
- 2012-07-30 0001104659-12-052298 — 2.02, 5.02, 8.01, 9.01
- 2012-07-05 0001104659-12-047737 — 2.02, 9.01
- 2012-04-26 0001104659-12-029099 — 5.02, 8.01, 9.01
- 2012-04-17 0001104659-12-025931 — 2.02, 9.01
- 2012-01-31 0001104659-12-005522 — 2.02, 9.01
- 2012-01-27 0001104659-12-004299 — 8.01, 9.01
- 2012-01-04 0001104659-12-000411 — 2.02, 9.01
- 2011-12-20 0001104659-11-070207 — 2.01, 3.02, 9.01
- 2011-12-12 0001104659-11-069005 — 8.01
- 2011-12-05 0001104659-11-067679 — 5.02, 9.01
- 2011-11-29 0001104659-11-066436 — 7.01, 9.01
- 2011-11-22 0001104659-11-065589 — 7.01, 9.01
- 2011-11-03 0001104659-11-060307 — 7.01
- 2011-10-21 0001104659-11-056997 — 2.02, 8.01, 9.01
- 2011-10-12 0001104659-11-055849 — 7.01, 9.01
- 2011-07-29 0001104659-11-041897 — 5.02
- 2011-07-20 0001104659-11-039922 — 2.02, 9.01
- 2011-06-01 0001104659-11-032473 — 8.01
- 2011-05-23 0001104659-11-030867 — 8.01
- 2011-05-18 0001104659-11-029869 — 1.01, 2.03, 9.01
- 2011-05-04 0001104659-11-025801 — 8.01, 9.01
- 2011-05-04 0001104659-11-025462 — 8.01, 9.01
- 2011-04-19 0001104659-11-020787 — 1.01, 2.02, 3.02, 9.01
- 2011-04-08 0001104659-11-019316 — 5.02, 9.01
- 2011-04-07 0001104659-11-019141 — 2.02, 8.01, 9.01
- 2011-03-09 0001104659-11-013084 — 5.02
- 2011-02-18 0001104659-11-008419 — 8.01
- 2011-02-01 0001104659-11-004106 — 5.02, 9.01
- 2011-01-19 0001104659-11-002037 — 1.01, 2.02, 2.03, 5.07, 9.01
- 2010-12-14 0001104659-10-062647 — 1.01, 2.03, 9.01
- 2010-12-08 0001104659-10-061747 — 8.01, 9.01
- 2010-12-08 0001104659-10-061643 — 7.01, 8.01, 9.01
- 2010-11-29 0001104659-10-060338 — 7.01, 9.01
- 2010-10-20 0001104659-10-052966 — 2.02, 9.01
- 2010-10-15 0001104659-10-052362 — 8.01, 9.01
- 2010-09-13 0001104659-10-048317 — 5.02, 9.01
- 2010-08-16 0001104659-10-044431 — 5.02
- 2010-07-29 0001104659-10-040519 — 5.02, 9.01
- 2010-07-20 0001104659-10-038670 — 2.02, 9.01
- 2010-07-06 0001104659-10-036996 — 1.01, 2.03, 3.01, 3.03, 5.01, 5.02, 8.01, 9.01
- 2010-06-25 0001104659-10-035630 — 8.01, 9.01
- 2010-05-26 0001104659-10-030931 — 5.02
- 2010-05-14 0001104659-10-028664 — 1.01, 2.03, 9.01
- 2010-04-30 0001104659-10-023493 — 8.01, 9.01
- 2010-04-29 0001104659-10-022773 — 1.02, 8.01, 9.01
- 2010-04-20 0001104659-10-020750 — 2.02, 9.01
- 2010-04-16 0001104659-10-020113 — 5.07
- 2010-03-22 0001104659-10-015668 — 1.01, 9.01
- 2010-03-03 0001104659-10-011870 — 1.01, 2.03, 9.01
- 2010-01-20 0001104659-10-002269 — 2.02, 9.01
- 2009-10-29 0001104659-09-060949 — 5.02, 7.01
- 2009-10-20 0001104659-09-059594 — 2.02, 9.01
- 2009-10-01 0001104659-09-057311 — 1.01, 2.03, 2.06, 9.01
- 2009-09-22 0001104659-09-055716 — 7.01, 9.01
- 2009-08-04 0001193125-09-163032 — 2.05
- 2009-07-31 0001193125-09-160678 — 5.02, 9.01
- 2009-07-21 0001193125-09-152269 — 2.02, 9.01
- 2009-07-09 0001193125-09-146452 — 5.02
- 2009-06-24 0001193125-09-136674 — 7.01, 9.01
- 2009-06-01 0001193125-09-122549 — 1.01, 2.03, 9.01
- 2009-05-14 0001193125-09-110016 — 8.01, 9.01
- 2009-05-13 0001193125-09-109216 — 2.05, 7.01, 9.01
- 2009-05-05 0001193125-09-099861 — 1.01, 2.03, 9.01
- 2009-04-21 0001193125-09-083544 — 2.02, 9.01
- 2009-04-17 0001193125-09-081018 — 8.01, 9.01
- 2009-04-13 0001193125-09-077471 — 2.02, 9.01
- 2009-04-13 0001193125-09-077470 — 8.01, 9.01
- 2009-04-06 0001193125-09-073113 — 1.01, 2.03, 9.01
- 2009-03-09 0001193125-09-048538 — 5.02
- 2009-03-04 0001193125-09-044916 — 5.02, 8.01
- 2009-02-06 0001193125-09-021262 — 5.02
- 2009-02-04 0001193125-09-018804 — 5.02, 8.01
- 2009-02-02 0001193125-09-016478 — 2.06 — amendment, the index does not say of what
- 2009-01-27 0001193125-09-012058 — 5.02
- 2009-01-21 0001193125-09-009019 — 2.02, 5.02, 9.01
- 2009-01-14 0001193125-09-005721 — 2.05, 7.01
- 2009-01-12 0001193125-09-004420 — 5.02, 7.01, 9.01
- 2008-12-24 0001193125-08-259972 — 2.06
- 2008-12-12 0001193125-08-252765 — 2.03
- 2008-12-10 0001193125-08-250840 — 7.01
- 2008-11-12 0001193125-08-233906 — 5.02
- 2008-10-22 0001193125-08-214482 — 2.02, 9.01
- 2008-09-19 0001193125-08-198664 — 2.05
- 2008-09-12 0001193125-08-195206 — 1.01
- 2008-08-27 0001193125-08-185448 — 1.02, 3.01, 5.02, 9.01
- 2008-07-15 0001193125-08-151292 — 2.02, 9.01
- 2008-07-11 0001193125-08-149749 — 2.05
- 2008-07-03 0001193125-08-146791 — 5.02
- 2008-04-29 0001193125-08-094835 — 5.02, 9.01
- 2008-04-15 0001193125-08-081743 — 2.02, 9.01
- 2008-03-12 0001193125-08-054331 — 8.01, 9.01
- 2008-03-04 0001193125-08-045657 — 7.01
- 2008-02-04 0001193125-08-019262 — 8.01, 9.01
- 2008-01-18 0001193125-08-008849 — 8.01, 9.01
- 2008-01-17 0001193125-08-008120 — 2.02, 9.01
- 2007-12-21 0001193125-07-269469 — 2.05
- 2007-12-05 0001193125-07-259675 — 5.02
- 2007-10-17 0001193125-07-220376 — 8.01, 9.01
- 2007-10-16 0001193125-07-219386 — 2.02, 9.01
- 2007-09-18 0000950134-07-020112 — 5.02, 9.01
- 2007-08-29 0000950134-07-019145 — 1.01, 2.02, 9.01
- 2007-07-20 0001193125-07-159001 — 8.01, 9.01
- 2007-07-19 0001193125-07-158214 — 2.02, 9.01
- 2007-04-18 0001193125-07-083845 — 8.01, 9.01
- 2007-04-17 0001193125-07-082824 — 2.02, 9.01
- 2007-04-10 0001193125-07-077251 — 2.02, 9.01
- 2007-02-27 0001193125-07-040081 — 5.02, 7.01
- 2007-01-24 0001193125-07-011834 — 8.01, 9.01
- 2007-01-23 0001193125-07-010955 — 2.02, 9.01
- 2006-12-21 0001193125-06-257603 — 8.01, 9.01
- 2006-12-07 0001193125-06-247897 — 5.02
- 2006-11-07 0001193125-06-225545 — 2.02, 7.01, 8.01, 9.01
- 2006-11-01 0001193125-06-220706 — 1.01, 9.01
- 2006-10-25 0001193125-06-214798 — 8.01, 9.01
- 2006-10-24 0001193125-06-213813 — 2.02, 9.01
- 2006-10-11 0001193125-06-206304 — 5.02
- 2006-10-03 0001193125-06-201845 — 5.02, 9.01
- 2006-09-21 0001193125-06-194878 — 1.01, 1.02, 2.03, 2.04, 8.01, 9.01
- 2006-09-19 0001193125-06-192726 — 8.01, 9.01
- 2006-09-12 0001193125-06-189437 — 5.02, 8.01, 9.01
- 2006-08-24 0001193125-06-179258 — 1.01
- 2006-08-09 0001193125-06-167961 — 8.01, 9.01
- 2006-08-08 0001193125-06-165853 — 2.02, 9.01
- 2006-06-01 0001193125-06-122124 — 7.01, 9.01
- 2006-05-25 0001193125-06-119646 — 1.01, 2.01, 2.03, 5.02, 9.01
- 2006-05-17 0001193125-06-114760 — 8.01, 9.01
- 2006-05-04 0001193125-06-099262 — 8.01, 9.01
- 2006-05-03 0001193125-06-098229 — 5.05, 9.01
- 2006-04-27 0001193125-06-090749 — 8.01
- 2006-04-20 0001193125-06-084566 — 8.01, 9.01
- 2006-04-18 0001193125-06-082414 — 2.02, 9.01
- 2006-04-13 0001193125-06-079690 — 8.01
- 2006-04-03 0001193125-06-071956 — 8.01
- 2006-03-13 0001193125-06-051798 — 8.01
- 2006-02-14 0001193125-06-030829 — 8.01, 9.01
- 2006-01-26 0001193125-06-012909 — 8.01, 9.01
- 2006-01-25 0001193125-06-011608 — 8.01, 9.01
- 2006-01-19 0001193125-06-008770 — 8.01, 9.01
- 2006-01-18 0001193125-06-007939 — 2.02, 9.01
- 2005-12-22 0001193125-05-247782 — 1.01, 5.02, 9.01
- 2005-12-22 0001193125-05-247766 — 1.01, 9.01
- 2005-12-21 0001193125-05-246701 — 8.01, 9.01
- 2005-12-01 0001193125-05-234733 — 7.01
- 2005-11-23 0001193125-05-231674 — 1.01, 1.02, 7.01, 9.01
- 2005-10-19 0001193125-05-203955 — 2.02, 9.01
- 2005-10-18 0001193125-05-203356 — 2.02, 7.01, 9.01
- 2005-09-08 0001193125-05-181893 — 7.01, 9.01
- 2005-09-07 0001193125-05-181605 — 1.01
- 2005-08-04 0001193125-05-157913 — 8.01, 9.01
- 2005-08-03 0001193125-05-156407 — 1.01, 8.01, 9.01
- 2005-07-19 0001193125-05-144591 — 2.02, 9.01
- 2005-06-08 0001193125-05-121880 — 7.01
- 2005-05-17 0001193125-05-109518 — 7.01
- 2005-04-19 0001193125-05-079453 — 2.02, 9.01
- 2005-03-22 0001193125-05-057519 — 1.01
- 2005-03-16 0001193125-05-052560 — 7.01
- 2005-03-07 0001193125-05-043752 — 7.01, 9.01
- 2005-02-08 0001193125-05-022340 — 1.01, 7.01
- 2005-01-18 0001193125-05-007666 — 2.02, 9.01
- 2004-12-13 0001193125-04-211590 — 7.01, 8.01, 9.01
- 2004-12-07 0001193125-04-208768 — 7.01, 9.01
- 2004-10-29 0001193125-04-181463 — 1.01, 5.02, 9.01
- 2004-10-19 0001193125-04-173795 — 2.02, 9.01
- 2004-09-23 0001193125-04-160889 — 8.01, 9.01
- 2004-09-21 0001193125-04-159593 — 8.01, 9.01
- 2004-09-07 0001193125-04-152868 — 7.01, 9.01
- 2004-07-28 0001193125-04-126152 — 5, 7
- 2004-07-20 0001193125-04-121017 — 12, 7
- 2004-06-02 0001193125-04-097697 — 7, 9
- 2004-04-30 0001193125-04-075386 — 5, 7
- 2004-04-20 0001193125-04-065621 — 12, 7
- 2004-04-06 0001193125-04-057855 — 12, 7
- 2004-03-16 0001193125-04-042542 — 5
- 2004-03-03 0001193125-04-033653 — 7, 9
- 2004-01-21 0001193125-04-006388 — 12, 5, 7
- 2003-10-31 0001193125-03-070294 — 5, 7
- 2003-10-27 0001193125-03-067685 — 5, 7
- 2003-10-22 0001193125-03-065398 — 12, 5, 7
- 2003-07-16 0001193125-03-019880 — 7, 9
- 2003-07-10 0001193125-03-018043 — 5
- 2003-07-07 0001193125-03-016864 — 5
- 2003-06-27 0001193125-03-014262 — 5, 7
- 2003-04-16 0001012870-03-001799 — 7, 9

## late-filing notifications on or before 2014-08-08

- none on or before 2014-08-08

## item 2.02 — earnings release, exhibit 99.1

[0001104659-14-052019:8k_2_02:1]
EX-99.1
2
a14-17247_1ex99d1.htm
PRESS RELEASE

[0001104659-14-052019:8k_2_02:2]
Exhibit 99.1

[0001104659-14-052019:8k_2_02:3]
|  | Media Relations Contact: |
| Brian Ziel (408) 658-1540 |
| brian.ziel@seagate.com |

[0001104659-14-052019:8k_2_02:4]
SEAGATE TECHNOLOGY REPORTS FISCAL FOURTH QUARTER AND FISCAL YEAR 2014 FINANCIAL RESULTS

[0001104659-14-052019:8k_2_02:5]
CUPERTINO, CA — July 17, 2014 — Seagate Technology plc (NASDAQ: STX) (the “Company” or “Seagate”) today reported financial results for the quarter and fiscal year ended June 27, 2014. For the fourth quarter, the Company reported revenue of approximately $3.3 billion, gross margin of 28.0%, net income of $320 million and diluted earnings per share of $0.95.  On a non-GAAP basis, which excludes the net impact of certain items, Seagate reported gross margin of 28.5%, net income of $370 million and diluted earnings per share of $1.10.

[0001104659-14-052019:8k_2_02:6]
During the fourth quarter, the Company generated approximately $577 million in operating cash flow and returned $166 million to shareholders in the form of dividends and share redemptions.

[0001104659-14-052019:8k_2_02:7]
For the fiscal year ended June 27, 2014, the Company reported revenue of $13.7 billion, gross margin of 28.0%, net income of $1.6 billion and diluted earnings per share of $4.52.  On a non-GAAP basis, Seagate reported gross margin of 28.5%, net income of $1.8 billion and diluted earnings per share of $5.04.

[0001104659-14-052019:8k_2_02:8]
In fiscal year 2014, the Company returned $2.5 billion to shareholders in the form of dividends and share redemptions. The Company also successfully raised $1.8 billion in investment grade debt in fiscal 2014, extending its weighted average maturity to approximately 7 years and decreasing its weighted average interest to approximately 5%.  Cash, cash equivalents, restricted cash, and short-term investments totaled approximately $2.7 billion at the end of the fiscal year. There were 327 million ordinary shares issued and outstanding as of the end of the fiscal year.

[0001104659-14-052019:8k_2_02:9]
“Throughout fiscal year 2014, Seagate delivered strong financial and operational performance and returned significant value to shareholders.  We made strategic investments in our technology portfolio, which enabled us to continue to innovate into higher capacity and power efficient storage solutions, and expanding our capabilities to serve a broader storage customer base in the future through new cloud systems and solutions and flash technology for connected storage,” said Steve Luczo, Seagate’s chairman and chief executive officer.

[0001104659-14-052019:8k_2_02:10]
“The shifting information technology market dynamics are disrupting the traditional storage industry in meaningful ways and continue to create more opportunities for Seagate. As we plan for our next fiscal year, we remain focused on investing in our storage technology product portfolio to deliver high quality storage products and solutions for our customers, as well as continuing to create long-term value for our shareholders.”

[0001104659-14-052019:8k_2_02:11]
For a detailed reconciliation of GAAP to non-GAAP results, see accompanying financial tables.

[0001104659-14-052019:8k_2_02:12]
Seagate has issued a Supplemental Commentary document. The Supplemental Commentary will not be read during today’s call, but rather it is available on Seagate’s Investor Relations website at www.seagate.com/investors.

[0001104659-14-052019:8k_2_02:13]
Quarterly Cash Dividend

[0001104659-14-052019:8k_2_02:14]
The Board of Directors has approved a quarterly cash dividend of $0.43 per share, which will be payable on August 22, 2014 to shareholders of record as of the close of business on August 8, 2014.  The payment of any future quarterly dividends will be at the discretion of the Board and will be dependent upon Seagate’s financial position, results of operations, available cash, cash flow, capital requirements and other factors deemed relevant by the Board.

[0001104659-14-052019:8k_2_02:15]
Investor Communications

[0001104659-14-052019:8k_2_02:16]
Seagate management will hold a public webcast today at 2:30 p.m. Pacific Time that can be accessed on its Investor Relations website at www.seagate.com/investors. During today’s webcast, the Company will provide an outlook for its first fiscal quarter of 2015, including key underlying assumptions.  Seagate is planning an investor and analyst meeting on September 12, 2014 to discuss the Company’s longer-term strategic plan.

[0001104659-14-052019:8k_2_02:17]
Replay

[0001104659-14-052019:8k_2_02:18]
A replay will be available beginning today at approximately 6:00 p.m. Pacific Time at www.seagate.com/investors.

[0001104659-14-052019:8k_2_02:19]
About Seagate

[0001104659-14-052019:8k_2_02:20]
Seagate is a world leader in hard disk drives and storage solutions. Learn more at www.seagate.com.

[0001104659-14-052019:8k_2_02:21]
Cautionary Note Regarding Forward-Looking Statements

[0001104659-14-052019:8k_2_02:22]
# # #

[0001104659-14-052019:8k_2_02:23]
SEAGATE TECHNOLOGY PLC

[0001104659-14-052019:8k_2_02:24]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-14-052019:8k_2_02:25]
(In millions)

[0001104659-14-052019:8k_2_02:26]
(Unaudited)

[0001104659-14-052019:8k_2_02:27]
|  |  | June 27, 2014 |  | June 28, 2013 (a) |  |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,634 |  | $ | 1,708 |  |
| Short-term investments |  | 20 |  | 480 |  |
| Restricted cash and investments |  | 4 |  | 101 |  |
| Accounts receivable, net |  | 1,729 |  | 1,670 |  |
| Inventories |  | 985 |  | 854 |  |
| Deferred income taxes |  | 126 |  | 115 |  |
| Other current assets |  | 279 |  | 484 |  |
| Total current assets |  | 5,777 |  | 5,412 |  |
| Property, equipment and leasehold improvements, net |  | 2,136 |  | 2,269 |  |
| Goodwill |  | 537 |  | 476 |  |
| Other intangible assets, net |  | 359 |  | 405 |  |
| Deferred income taxes |  | 499 |  | 456 |  |
| Other assets, net |  | 184 |  | 225 |  |
| Total Assets |  | $ | 9,492 |  | $ | 9,243 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |
| Accounts payable |  | $ | 1,549 |  | $ | 1,690 |  |
| Accrued employee compensation |  | 296 |  | 335 |  |
| Accrued warranty |  | 144 |  | 176 |  |
| Accrued expenses |  | 409 |  | 407 |  |
| Current portion of long-term debt |  | — |  | 3 |  |
| Total current liabilities |  | 2,398 |  | 2,611 |  |
| Long-term accrued warranty |  | 125 |  | 144 |  |
| Long-term accrued income taxes |  | 90 |  | 87 |  |
| Other non-current liabilities |  | 127 |  | 121 |  |
| Long-term debt, less current portion |  | 3,920 |  | 2,774 |  |
| Total Liabilities |  | 6,660 |  | 5,737 |  |
| Equity: |  |  |  |  |  |
| Total Equity |  | 2,832 |  | 3,506 |  |
| Total Liabilities and Equity |  | $ | 9,492 |  | $ | 9,243 |  |

[0001104659-14-052019:8k_2_02:28]
(a) The information in this column was derived from the Company’s audited Consolidated Balance Sheet as of June 28, 2013.

[0001104659-14-052019:8k_2_02:29]
SEAGATE TECHNOLOGY PLC

[0001104659-14-052019:8k_2_02:30]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-14-052019:8k_2_02:31]
(In millions, except per share data)

[0001104659-14-052019:8k_2_02:32]
(Unaudited)

[0001104659-14-052019:8k_2_02:33]
|  |  | For the Three Months Ended |  | For the Fiscal Years Ended |  |
|  |  | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 (a) |  |
| Revenue |  | $ | 3,301 |  | $ | 3,425 |  | $ | 13,724 |  | $ | 14,351 |  |
| Cost of revenue |  | 2,376 |  | 2,486 |  | 9,878 |  | 10,411 |  |
| Product development |  | 323 |  | 294 |  | 1,226 |  | 1,133 |  |
| Marketing and administrative |  | 161 |  | 176 |  | 722 |  | 635 |  |
| Amortization of intangibles |  | 27 |  | 20 |  | 98 |  | 79 |  |
| Restructuring and other, net |  | 4 |  | 1 |  | 24 |  | 2 |  |
| Total operating expenses |  | 2,891 |  | 2,977 |  | 11,948 |  | 12,260 |  |
| Income from operations |  | 410 |  | 448 |  | 1,776 |  | 2,091 |  |
| Interest income |  | 1 |  | 2 |  | 8 |  | 8 |  |
| Interest expense |  | (50 | ) | (50 | ) | (195 | ) | (214 | ) |
| Other, net |  | (77 | ) | (97 | ) | (33 | ) | (54 | ) |
| Other expense, net |  | (126 | ) | (145 | ) | (220 | ) | (260 | ) |
| Income before income taxes |  | 284 |  | 303 |  | 1,556 |  | 1,831 |  |
| Benefit from income taxes |  | (36 | ) | (45 | ) | (14 | ) | (7 | ) |
| Net income |  | $ | 320 |  | $ | 348 |  | $ | 1,570 |  | $ | 1,838 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.98 |  | $ | 0.97 |  | $ | 4.66 |  | $ | 4.97 |  |
| Diluted |  | 0.95 |  | 0.94 |  | 4.52 |  | 4.81 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |  |
| Basic |  | 326 |  | 359 |  | 337 |  | 370 |  |
| Diluted |  | 337 |  | 371 |  | 347 |  | 382 |  |
| Cash dividends declared per share |  | $ | 0.43 |  | $ | 0.38 |  | $ | 1.67 |  | $ | 1.40 |  |

[0001104659-14-052019:8k_2_02:34]
(a) The information in this column was derived from the Company’s audited Consolidated Statement of Operations for the year ended June 28, 2013.

[0001104659-14-052019:8k_2_02:35]
SEAGATE TECHNOLOGY PLC

[0001104659-14-052019:8k_2_02:36]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001104659-14-052019:8k_2_02:37]
(In millions)

[0001104659-14-052019:8k_2_02:38]
(Unaudited)

[0001104659-14-052019:8k_2_02:39]
|  |  | For the Fiscal Years Ended |  |
|  |  | June 27, 2014 |  | June 28, 2013 (a) |  |
| OPERATING ACTIVITIES |  |  |  |  |  |
| Net income |  | $ | 1,570 |  | $ | 1,838 |  |
| Adjustments to reconcile net income to net cash from operating activities: |  |  |  |  |  |
| Depreciation and amortization |  | 879 |  | 873 |  |
| Share-based compensation |  | 118 |  | 76 |  |
| Loss on redemption and repurchase of debt |  | 81 |  | 141 |  |
| Gain on sale of investments |  | (32 | ) | (61 | ) |
| Gain on sale of property and equipment |  | (4 | ) | (36 | ) |
| Deferred income taxes |  | (24 | ) | (70 | ) |
| Other non-cash operating activities, net |  | 14 |  | 12 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |
| Restricted cash |  | 104 |  | — |  |
| Accounts receivable, net |  | 44 |  | 661 |  |
| Inventories |  | (20 | ) | 102 |  |
| Accounts payable |  | (190 | ) | (538 | ) |
| Accrued employee compensation |  | (55 | ) | (14 | ) |
| Accrued expenses, income taxes and warranty |  | (123 | ) | (170 | ) |
| Vendor non-trade receivables |  | 217 |  | 272 |  |
| Other assets and liabilities |  | 19 |  | (39 | ) |
| Net cash provided by operating activities |  | 2,558 |  | 3,047 |  |
| INVESTING ACTIVITIES |  |  |  |  |  |
| Acquisition of property, equipment and leasehold improvements |  | (559 | ) | (786 | ) |
| Proceeds from the sale of property and equipment |  | 3 |  | 29 |  |
| Proceeds from the sale of strategic investments |  | 72 |  | — |  |
| Purchases of short-term investments |  | (88 | ) | (351 | ) |
| Sales of short-term investments |  | 508 |  | 296 |  |
| Maturities of short-term investments |  | 61 |  | 38 |  |
| Cash used in acquisition of businesses, net of cash acquired |  | (285 | ) | (36 | ) |
| Other investing activities, net |  | (34 | ) | (15 | ) |
| Net cash used in investing activities |  | (322 | ) | (825 | ) |
| FINANCING ACTIVITIES |  |  |  |  |  |
| Net proceeds from issuance of long-term debt |  | 1,781 |  | 986 |  |
| Repayments of long-term debt |  | (725 | ) | (1,224 | ) |
| Proceeds from issuance of ordinary shares under employee stock plans |  | 107 |  | 259 |  |
| Dividends to shareholders |  | (557 | ) | (518 | ) |
| Repurchases of ordinary shares |  | (1,912 | ) | (1,654 | ) |
| Other financing activities, net |  | (5 | ) | (71 | ) |
| Net cash used in financing activities |  | (1,311 | ) | (2,222 | ) |
| Effects of foreign currency exchange rate changes on cash and cash equivalents |  | 1 |  | 1 |  |
| Increase in cash and cash equivalents |  | 926 |  | 1 |  |
| Cash and cash equivalents at the beginning of the year |  | 1,708 |  | 1,707 |  |
| Cash and cash equivalents at the end of the year |  | $ | 2,634 |  | $ | 1,708 |  |

[0001104659-14-052019:8k_2_02:40]
(a) The information in this column was derived from the Company’s audited Consolidated Statement of Cash Flows for the year ended June 28, 2013.

[0001104659-14-052019:8k_2_02:41]
Use of non-GAAP financial information

[0001104659-14-052019:8k_2_02:42]
To supplement the preliminary consolidated financial information presented in accordance with generally accepted accounting principles (GAAP), the Company provides non-GAAP measures of net income, diluted net income per share, gross margin, gross margin as a percentage of revenue, operating margin, operating expenses, and operating income which are adjusted from results based on GAAP to exclude certain expenses, gains and losses. These non-GAAP financial measures are provided to enhance the user’s overall understanding of the Company’s current financial performance and its prospects for the future. Specifically, the Company believes non-GAAP results provide useful information to both management and investors as these non-GAAP results exclude certain expenses that the Company believes are not indicative of its core operating results and because they are consistent with the financial models and estimates published by financial analysts who follow the Company.

[0001104659-14-052019:8k_2_02:43]
These non-GAAP results are some of the primary measurements management uses to assess the Company’s performance, allocate resources and plan for future periods. Reported non-GAAP results should only be considered as supplemental to results prepared in accordance with GAAP, and not considered as a substitute for, or superior to, GAAP results. These non-GAAP measures may differ from the non-GAAP measures reported by other companies in the Company’s industry.

[0001104659-14-052019:8k_2_02:44]
SEAGATE TECHNOLOGY PLC

[0001104659-14-052019:8k_2_02:45]
ADJUSTMENTS TO GAAP NET INCOME, DILUTED NET INCOME PER SHARE AND OPERATING CASH FLOW

[0001104659-14-052019:8k_2_02:46]
(In millions, except per share amounts)

[0001104659-14-052019:8k_2_02:47]
(Unaudited)

[0001104659-14-052019:8k_2_02:48]
|  |  |  |  | For the Three Months Ended June 27, 2014 |  | For the Fiscal Year Ended June 27, 2014 |  |
| Reconciliation of GAAP Net Income: |  |  |  |  |  |  |  |
| GAAP Net Income |  |  |  | $ | 320 |  | $ | 1,570 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |
| Cost of revenue |  | A |  | 14 |  | 62 |  |
| Product development |  | B |  | — |  | 6 |  |
| Marketing and administrative |  | C |  | (25 | ) | (2 | ) |
| Amortization of intangibles |  | D |  | 27 |  | 98 |  |
| Restructuring and other, net |  | E |  | 4 |  | 24 |  |
| Other expense, net |  | F |  | 76 |  | 45 |  |
| Benefit from income taxes |  | G |  | (46 | ) | (52 | ) |
| Non-GAAP net income |  |  |  | $ | 370 |  | $ | 1,751 |  |
| Reconciliation of GAAP Diluted Net Income Per Share: |  |  |  |  |  |  |  |
| GAAP |  |  |  | $ | 0.95 |  | $ | 4.52 |  |
| Non-GAAP |  |  |  | $ | 1.10 |  | $ | 5.04 |  |
| Shares used in diluted net income per share calculation |  |  |  | 337 |  | 347 |  |
| Reconciliation of operating cash flow: |  |  |  |  |  |  |  |
| GAAP operating cash flow |  |  |  | $ | 577 |  | $ | 2,558 |  |
| Less: acquisition of property, equipment and leasehold improvements |  |  |  | (131 | ) | (559 | ) |
| Free cash flow |  |  |  | $ | 446 |  | $ | 1,999 |  |

[0001104659-14-052019:8k_2_02:49]
A For the three months and fiscal year ended June 27, 2014, Cost of revenue on a GAAP basis totaled $2.4 billion and $9.9 billion, respectively, while non-GAAP Cost of revenue, which excludes the impact of certain adjustments, was $2.4 billion and $9.8 billion, respectively.  These non-GAAP adjustments include amortization of intangibles and other acquisition related expenses associated with the December 2011 acquisition of Samsung Electronics Co., Ltd.’s hard disk drive business (the “Samsung HDD business”), the August 2012 acquisition of LaCie S.A. (“LaCie”) and the March 31, 2014 acquisition of Xyratex Ltd. (“Xyratex”).

[0001104659-14-052019:8k_2_02:50]
B For the three months and fiscal year ended June 27, 2014, Product development expense has been adjusted on a non-GAAP basis to exclude the impact of acquisition and integration costs associated with the acquisitions of the Samsung HDD business, LaCie and Xyratex.

[0001104659-14-052019:8k_2_02:51]
C For the three months ended June 27, 2014, Marketing and administrative expense has been adjusted on a non-GAAP basis primarily to exclude the impact of a legal cost reimbursement.

[0001104659-14-052019:8k_2_02:52]
For the fiscal year ended June 27, 2014, Marketing and administrative expense has been adjusted on a non-GAAP basis to exclude the impact of a legal cost reimbursement, partially offset by the impact of acquisition and integration costs associated with the acquisition of Samsung HDD business, LaCie and Xyratex.

[0001104659-14-052019:8k_2_02:53]
D For the three months and fiscal year ended June 27, 2014, Amortization of intangibles primarily related to our Samsung HDD business and LaCie acquisitions have been excluded on a non-GAAP basis.

[0001104659-14-052019:8k_2_02:54]
E For the three months and fiscal year ended June 27, 2014, Restructuring and other, net, has been adjusted on a non-GAAP basis primarily to exclude the impact from our existing restructuring plans.

[0001104659-14-052019:8k_2_02:55]
F For the three months ended June 27, 2014, Other expense, net, has been adjusted on a non-GAAP basis to exclude the net impact of losses recognized on the early redemption and repurchase of debt.

[0001104659-14-052019:8k_2_02:56]
For the fiscal year ended June 27, 2014, Other expense, net, has been adjusted on a non-GAAP basis primarily to exclude the net impact of losses recognized on the early redemption and repurchase of debt, partially offset by gains recognized upon sales of certain strategic investments.

[0001104659-14-052019:8k_2_02:57]
G For the three months and fiscal year ended June 27, 2014, Benefit from income taxes has been adjusted on a non-GAAP basis to exclude certain changes in deferred tax assets including a valuation allowance release associated with the Xyratex acquisition.
