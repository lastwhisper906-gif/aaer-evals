# STX 8-K — 0001193125-17-234440 filed 2017-07-25

## item codes, every 8-K on or before 2017-08-04

- 2017-07-28 0001137789-17-000046 — 5.02
- 2017-07-25 0001193125-17-234440 — 2.02, 2.05, 5.02, 7.01, 9.01
- 2017-06-02 0001193125-17-192960 — 5.02
- 2017-04-26 0001193125-17-138005 — 2.02, 7.01, 9.01
- 2017-03-10 0001193125-17-077510 — 2.05
- 2017-02-03 0001104659-17-006357 — 1.01, 2.03, 9.01
- 2017-01-31 0001104659-17-005357 — 8.01, 9.01
- 2017-01-31 0001104659-17-005173 — 8.01, 9.01
- 2017-01-27 0001104659-17-004448 — 8.01
- 2017-01-24 0001193125-17-016690 — 2.02, 7.01, 9.01
- 2017-01-20 0001193125-17-013685 — 5.02, 9.01
- 2016-10-24 0001104659-16-151422 — 5.02, 5.03, 5.07, 9.01
- 2016-10-19 0001193125-16-741277 — 2.02, 7.01, 9.01
- 2016-10-11 0001193125-16-734835 — 2.02, 9.01
- 2016-10-04 0001104659-16-148575 — 5.02
- 2016-09-27 0001104659-16-146813 — 5.02
- 2016-08-02 0001104659-16-135908 — 2.02, 7.01, 9.01
- 2016-07-28 0001104659-16-135046 — 5.02
- 2016-07-11 0001104659-16-131996 — 2.02, 2.05, 9.01
- 2016-07-08 0001104659-16-131749 — 5.02
- 2016-06-29 0001104659-16-130122 — 2.05
- 2016-06-27 0001104659-16-129505 — 5.02
- 2016-04-29 0001104659-16-115593 — 2.02, 7.01, 9.01
- 2016-04-13 0001104659-16-111266 — 2.02, 9.01
- 2016-01-29 0001104659-16-092323 — 2.02, 7.01, 9.01
- 2016-01-04 0001104659-16-087730 — 5.02, 9.01
- 2015-10-30 0001104659-15-074350 — 2.02, 7.01, 9.01
- 2015-10-21 0001104659-15-071908 — 5.02, 9.01
- 2015-10-21 0001104659-15-071906 — 5.07, 7.01, 9.01
- 2015-10-15 0001104659-15-070776 — 2.02, 9.01
- 2015-09-21 0001104659-15-066273 — 5.02
- 2015-09-10 0001104659-15-064389 — 2.05
- 2015-08-06 0001104659-15-057159 — 5.02
- 2015-07-31 0001104659-15-055040 — 2.02, 7.01, 9.01
- 2015-07-22 0001104659-15-052507 — 5.02, 9.01
- 2015-07-13 0001104659-15-050755 — 2.02, 9.01
- 2015-05-14 0001104659-15-038166 — 1.01, 2.03, 9.01
- 2015-05-12 0001104659-15-036968 — 8.01, 9.01
- 2015-05-11 0001104659-15-036533 — 8.01, 9.01
- 2015-05-01 0001104659-15-033202 — 5.02
- 2015-04-23 0001104659-15-029483 — 8.01, 9.01
- 2015-04-17 0001104659-15-028152 — 2.02, 7.01, 9.01
- 2015-04-07 0001104659-15-026148 — 7.01
- 2015-01-26 0001104659-15-004316 — 2.02, 7.01, 9.01
- 2015-01-16 0001104659-15-002732 — 1.01, 9.01
- 2015-01-02 0001104659-15-000147 — 8.01
- 2014-12-02 0001104659-14-084370 — 1.01, 2.03, 9.01
- 2014-11-25 0001104659-14-083066 — 8.01, 9.01
- 2014-11-24 0001104659-14-082837 — 8.01, 9.01
- 2014-10-27 0001104659-14-073832 — 2.02, 7.01, 9.01
- 2014-10-24 0001104659-14-073609 — 5.02, 5.07, 9.01
- 2014-10-22 0001104659-14-073104 — 7.01, 9.01
- 2014-10-08 0001104659-14-070767 — 8.01
- 2014-09-12 0001104659-14-066107 — 5.02
- 2014-09-12 0001104659-14-066101 — 7.01
- 2014-07-23 0001104659-14-052995 — 5.02
- 2014-07-17 0001104659-14-052019 — 2.02, 7.01, 9.01
- 2014-06-18 0001104659-14-046714 — 8.01, 9.01
- 2014-06-09 0001104659-14-044575 — 7.01
- 2014-06-04 0001104659-14-043897 — 8.01
- 2014-05-28 0001104659-14-041862 — 1.01, 2.03, 8.01, 9.01
- 2014-05-20 0001104659-14-040454 — 8.01, 9.01
- 2014-05-20 0001104659-14-040220 — 8.01, 9.01
- 2014-04-29 0001104659-14-031916 — 2.02, 7.01, 9.01
- 2014-04-22 0001104659-14-029197 — 5.02
- 2014-02-24 0001104659-14-012465 — 5.02, 7.01, 9.01
- 2014-01-27 0001104659-14-004298 — 2.02, 7.01, 9.01
- 2014-01-23 0001104659-14-003803 — 5.02
- 2013-12-23 0001104659-13-091738 — 1.01, 8.01, 9.01
- 2013-11-05 0001104659-13-081194 — 1.01, 2.03, 9.01
- 2013-11-04 0001104659-13-080161 — 5.02, 5.03, 5.07, 9.01
- 2013-10-31 0001104659-13-079635 — 8.01, 9.01
- 2013-10-31 0001104659-13-079438 — 8.01, 9.01
- 2013-10-28 0001104659-13-078341 — 2.02, 7.01, 9.01
- 2013-10-28 0001104659-13-078316 — 5.02, 7.01, 9.01
- 2013-10-08 0001104659-13-074454 — 1.01, 1.02, 9.01
- 2013-09-20 0001104659-13-071413 — 5.02
- 2013-07-24 0001104659-13-056053 — 5.02, 7.01
- 2013-07-24 0001104659-13-056052 — 2.02, 7.01, 9.01
- 2013-06-14 0001104659-13-049436 — 8.01, 9.01
- 2013-05-31 0001104659-13-045928 — 8.01, 9.01
- 2013-05-22 0001104659-13-043876 — 1.01, 2.03, 9.01
- 2013-05-16 0001104659-13-042180 — 7.01, 9.01
- 2013-05-15 0001104659-13-042028 — 8.01, 9.01
- 2013-05-15 0001104659-13-041695 — 8.01, 9.01
- 2013-05-07 0001104659-13-038226 — 5.02
- 2013-05-01 0001104659-13-036004 — 2.02, 9.01
- 2013-03-15 0001104659-13-021156 — 7.01
- 2013-01-28 0001104659-13-005180 — 2.02, 9.01
- 2013-01-08 0001104659-13-001291 — 2.02, 9.01
- 2012-11-29 0001104659-12-080911 — 8.01, 9.01
- 2012-10-31 0001104659-12-072476 — 2.02, 9.01
- 2012-10-25 0001104659-12-071208 — 5.07
- 2012-10-16 0001104659-12-069238 — 7.01
- 2012-09-28 0001104659-12-066105 — 7.01
- 2012-09-21 0001104659-12-064869 — 7.01
- 2012-08-02 0001104659-12-053775 — 5.02
- 2012-07-30 0001104659-12-052298 — 2.02, 5.02, 8.01, 9.01
- 2012-07-05 0001104659-12-047737 — 2.02, 9.01
- 2012-04-26 0001104659-12-029099 — 5.02, 8.01, 9.01
- 2012-04-17 0001104659-12-025931 — 2.02, 9.01
- 2012-01-31 0001104659-12-005522 — 2.02, 9.01
- 2012-01-27 0001104659-12-004299 — 8.01, 9.01
- 2012-01-04 0001104659-12-000411 — 2.02, 9.01
- 2011-12-20 0001104659-11-070207 — 2.01, 3.02, 9.01
- 2011-12-12 0001104659-11-069005 — 8.01
- 2011-12-05 0001104659-11-067679 — 5.02, 9.01
- 2011-11-29 0001104659-11-066436 — 7.01, 9.01
- 2011-11-22 0001104659-11-065589 — 7.01, 9.01
- 2011-11-03 0001104659-11-060307 — 7.01
- 2011-10-21 0001104659-11-056997 — 2.02, 8.01, 9.01
- 2011-10-12 0001104659-11-055849 — 7.01, 9.01
- 2011-07-29 0001104659-11-041897 — 5.02
- 2011-07-20 0001104659-11-039922 — 2.02, 9.01
- 2011-06-01 0001104659-11-032473 — 8.01
- 2011-05-23 0001104659-11-030867 — 8.01
- 2011-05-18 0001104659-11-029869 — 1.01, 2.03, 9.01
- 2011-05-04 0001104659-11-025801 — 8.01, 9.01
- 2011-05-04 0001104659-11-025462 — 8.01, 9.01
- 2011-04-19 0001104659-11-020787 — 1.01, 2.02, 3.02, 9.01
- 2011-04-08 0001104659-11-019316 — 5.02, 9.01
- 2011-04-07 0001104659-11-019141 — 2.02, 8.01, 9.01
- 2011-03-09 0001104659-11-013084 — 5.02
- 2011-02-18 0001104659-11-008419 — 8.01
- 2011-02-01 0001104659-11-004106 — 5.02, 9.01
- 2011-01-19 0001104659-11-002037 — 1.01, 2.02, 2.03, 5.07, 9.01
- 2010-12-14 0001104659-10-062647 — 1.01, 2.03, 9.01
- 2010-12-08 0001104659-10-061747 — 8.01, 9.01
- 2010-12-08 0001104659-10-061643 — 7.01, 8.01, 9.01
- 2010-11-29 0001104659-10-060338 — 7.01, 9.01
- 2010-10-20 0001104659-10-052966 — 2.02, 9.01
- 2010-10-15 0001104659-10-052362 — 8.01, 9.01
- 2010-09-13 0001104659-10-048317 — 5.02, 9.01
- 2010-08-16 0001104659-10-044431 — 5.02
- 2010-07-29 0001104659-10-040519 — 5.02, 9.01
- 2010-07-20 0001104659-10-038670 — 2.02, 9.01
- 2010-07-06 0001104659-10-036996 — 1.01, 2.03, 3.01, 3.03, 5.01, 5.02, 8.01, 9.01
- 2010-06-25 0001104659-10-035630 — 8.01, 9.01
- 2010-05-26 0001104659-10-030931 — 5.02
- 2010-05-14 0001104659-10-028664 — 1.01, 2.03, 9.01
- 2010-04-30 0001104659-10-023493 — 8.01, 9.01
- 2010-04-29 0001104659-10-022773 — 1.02, 8.01, 9.01
- 2010-04-20 0001104659-10-020750 — 2.02, 9.01
- 2010-04-16 0001104659-10-020113 — 5.07
- 2010-03-22 0001104659-10-015668 — 1.01, 9.01
- 2010-03-03 0001104659-10-011870 — 1.01, 2.03, 9.01
- 2010-01-20 0001104659-10-002269 — 2.02, 9.01
- 2009-10-29 0001104659-09-060949 — 5.02, 7.01
- 2009-10-20 0001104659-09-059594 — 2.02, 9.01
- 2009-10-01 0001104659-09-057311 — 1.01, 2.03, 2.06, 9.01
- 2009-09-22 0001104659-09-055716 — 7.01, 9.01
- 2009-08-04 0001193125-09-163032 — 2.05
- 2009-07-31 0001193125-09-160678 — 5.02, 9.01
- 2009-07-21 0001193125-09-152269 — 2.02, 9.01
- 2009-07-09 0001193125-09-146452 — 5.02
- 2009-06-24 0001193125-09-136674 — 7.01, 9.01
- 2009-06-01 0001193125-09-122549 — 1.01, 2.03, 9.01
- 2009-05-14 0001193125-09-110016 — 8.01, 9.01
- 2009-05-13 0001193125-09-109216 — 2.05, 7.01, 9.01
- 2009-05-05 0001193125-09-099861 — 1.01, 2.03, 9.01
- 2009-04-21 0001193125-09-083544 — 2.02, 9.01
- 2009-04-17 0001193125-09-081018 — 8.01, 9.01
- 2009-04-13 0001193125-09-077471 — 2.02, 9.01
- 2009-04-13 0001193125-09-077470 — 8.01, 9.01
- 2009-04-06 0001193125-09-073113 — 1.01, 2.03, 9.01
- 2009-03-09 0001193125-09-048538 — 5.02
- 2009-03-04 0001193125-09-044916 — 5.02, 8.01
- 2009-02-06 0001193125-09-021262 — 5.02
- 2009-02-04 0001193125-09-018804 — 5.02, 8.01
- 2009-02-02 0001193125-09-016478 — 2.06 — amendment, the index does not say of what
- 2009-01-27 0001193125-09-012058 — 5.02
- 2009-01-21 0001193125-09-009019 — 2.02, 5.02, 9.01
- 2009-01-14 0001193125-09-005721 — 2.05, 7.01
- 2009-01-12 0001193125-09-004420 — 5.02, 7.01, 9.01
- 2008-12-24 0001193125-08-259972 — 2.06
- 2008-12-12 0001193125-08-252765 — 2.03
- 2008-12-10 0001193125-08-250840 — 7.01
- 2008-11-12 0001193125-08-233906 — 5.02
- 2008-10-22 0001193125-08-214482 — 2.02, 9.01
- 2008-09-19 0001193125-08-198664 — 2.05
- 2008-09-12 0001193125-08-195206 — 1.01
- 2008-08-27 0001193125-08-185448 — 1.02, 3.01, 5.02, 9.01
- 2008-07-15 0001193125-08-151292 — 2.02, 9.01
- 2008-07-11 0001193125-08-149749 — 2.05
- 2008-07-03 0001193125-08-146791 — 5.02
- 2008-04-29 0001193125-08-094835 — 5.02, 9.01
- 2008-04-15 0001193125-08-081743 — 2.02, 9.01
- 2008-03-12 0001193125-08-054331 — 8.01, 9.01
- 2008-03-04 0001193125-08-045657 — 7.01
- 2008-02-04 0001193125-08-019262 — 8.01, 9.01
- 2008-01-18 0001193125-08-008849 — 8.01, 9.01
- 2008-01-17 0001193125-08-008120 — 2.02, 9.01
- 2007-12-21 0001193125-07-269469 — 2.05
- 2007-12-05 0001193125-07-259675 — 5.02
- 2007-10-17 0001193125-07-220376 — 8.01, 9.01
- 2007-10-16 0001193125-07-219386 — 2.02, 9.01
- 2007-09-18 0000950134-07-020112 — 5.02, 9.01
- 2007-08-29 0000950134-07-019145 — 1.01, 2.02, 9.01
- 2007-07-20 0001193125-07-159001 — 8.01, 9.01
- 2007-07-19 0001193125-07-158214 — 2.02, 9.01
- 2007-04-18 0001193125-07-083845 — 8.01, 9.01
- 2007-04-17 0001193125-07-082824 — 2.02, 9.01
- 2007-04-10 0001193125-07-077251 — 2.02, 9.01
- 2007-02-27 0001193125-07-040081 — 5.02, 7.01
- 2007-01-24 0001193125-07-011834 — 8.01, 9.01
- 2007-01-23 0001193125-07-010955 — 2.02, 9.01
- 2006-12-21 0001193125-06-257603 — 8.01, 9.01
- 2006-12-07 0001193125-06-247897 — 5.02
- 2006-11-07 0001193125-06-225545 — 2.02, 7.01, 8.01, 9.01
- 2006-11-01 0001193125-06-220706 — 1.01, 9.01
- 2006-10-25 0001193125-06-214798 — 8.01, 9.01
- 2006-10-24 0001193125-06-213813 — 2.02, 9.01
- 2006-10-11 0001193125-06-206304 — 5.02
- 2006-10-03 0001193125-06-201845 — 5.02, 9.01
- 2006-09-21 0001193125-06-194878 — 1.01, 1.02, 2.03, 2.04, 8.01, 9.01
- 2006-09-19 0001193125-06-192726 — 8.01, 9.01
- 2006-09-12 0001193125-06-189437 — 5.02, 8.01, 9.01
- 2006-08-24 0001193125-06-179258 — 1.01
- 2006-08-09 0001193125-06-167961 — 8.01, 9.01
- 2006-08-08 0001193125-06-165853 — 2.02, 9.01
- 2006-06-01 0001193125-06-122124 — 7.01, 9.01
- 2006-05-25 0001193125-06-119646 — 1.01, 2.01, 2.03, 5.02, 9.01
- 2006-05-17 0001193125-06-114760 — 8.01, 9.01
- 2006-05-04 0001193125-06-099262 — 8.01, 9.01
- 2006-05-03 0001193125-06-098229 — 5.05, 9.01
- 2006-04-27 0001193125-06-090749 — 8.01
- 2006-04-20 0001193125-06-084566 — 8.01, 9.01
- 2006-04-18 0001193125-06-082414 — 2.02, 9.01
- 2006-04-13 0001193125-06-079690 — 8.01
- 2006-04-03 0001193125-06-071956 — 8.01
- 2006-03-13 0001193125-06-051798 — 8.01
- 2006-02-14 0001193125-06-030829 — 8.01, 9.01
- 2006-01-26 0001193125-06-012909 — 8.01, 9.01
- 2006-01-25 0001193125-06-011608 — 8.01, 9.01
- 2006-01-19 0001193125-06-008770 — 8.01, 9.01
- 2006-01-18 0001193125-06-007939 — 2.02, 9.01
- 2005-12-22 0001193125-05-247782 — 1.01, 5.02, 9.01
- 2005-12-22 0001193125-05-247766 — 1.01, 9.01
- 2005-12-21 0001193125-05-246701 — 8.01, 9.01
- 2005-12-01 0001193125-05-234733 — 7.01
- 2005-11-23 0001193125-05-231674 — 1.01, 1.02, 7.01, 9.01
- 2005-10-19 0001193125-05-203955 — 2.02, 9.01
- 2005-10-18 0001193125-05-203356 — 2.02, 7.01, 9.01
- 2005-09-08 0001193125-05-181893 — 7.01, 9.01
- 2005-09-07 0001193125-05-181605 — 1.01
- 2005-08-04 0001193125-05-157913 — 8.01, 9.01
- 2005-08-03 0001193125-05-156407 — 1.01, 8.01, 9.01
- 2005-07-19 0001193125-05-144591 — 2.02, 9.01
- 2005-06-08 0001193125-05-121880 — 7.01
- 2005-05-17 0001193125-05-109518 — 7.01
- 2005-04-19 0001193125-05-079453 — 2.02, 9.01
- 2005-03-22 0001193125-05-057519 — 1.01
- 2005-03-16 0001193125-05-052560 — 7.01
- 2005-03-07 0001193125-05-043752 — 7.01, 9.01
- 2005-02-08 0001193125-05-022340 — 1.01, 7.01
- 2005-01-18 0001193125-05-007666 — 2.02, 9.01
- 2004-12-13 0001193125-04-211590 — 7.01, 8.01, 9.01
- 2004-12-07 0001193125-04-208768 — 7.01, 9.01
- 2004-10-29 0001193125-04-181463 — 1.01, 5.02, 9.01
- 2004-10-19 0001193125-04-173795 — 2.02, 9.01
- 2004-09-23 0001193125-04-160889 — 8.01, 9.01
- 2004-09-21 0001193125-04-159593 — 8.01, 9.01
- 2004-09-07 0001193125-04-152868 — 7.01, 9.01
- 2004-07-28 0001193125-04-126152 — 5, 7
- 2004-07-20 0001193125-04-121017 — 12, 7
- 2004-06-02 0001193125-04-097697 — 7, 9
- 2004-04-30 0001193125-04-075386 — 5, 7
- 2004-04-20 0001193125-04-065621 — 12, 7
- 2004-04-06 0001193125-04-057855 — 12, 7
- 2004-03-16 0001193125-04-042542 — 5
- 2004-03-03 0001193125-04-033653 — 7, 9
- 2004-01-21 0001193125-04-006388 — 12, 5, 7
- 2003-10-31 0001193125-03-070294 — 5, 7
- 2003-10-27 0001193125-03-067685 — 5, 7
- 2003-10-22 0001193125-03-065398 — 12, 5, 7
- 2003-07-16 0001193125-03-019880 — 7, 9
- 2003-07-10 0001193125-03-018043 — 5
- 2003-07-07 0001193125-03-016864 — 5
- 2003-06-27 0001193125-03-014262 — 5, 7
- 2003-04-16 0001012870-03-001799 — 7, 9

## late-filing notifications on or before 2017-08-04

- none on or before 2017-08-04

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-234440:8k_2_02:1]
EX-99.1
2
d431036dex991.htm
EX-99.1

[0001193125-17-234440:8k_2_02:2]
EX-99.1

[0001193125-17-234440:8k_2_02:3]
Exhibit 99.1

[0001193125-17-234440:8k_2_02:4]
Media Contact:

[0001193125-17-234440:8k_2_02:5]
Eric DeRitis,
(408) 658-1561

[0001193125-17-234440:8k_2_02:6]
eric.deritis@seagate.com

[0001193125-17-234440:8k_2_02:7]
SEAGATE TECHNOLOGY REPORTS FISCAL FOURTH QUARTER AND FISCAL YEAR 2017 FINANCIAL RESULTS

[0001193125-17-234440:8k_2_02:8]
CUPERTINO, CA – July 25, 2017 – Seagate Technology plc (NASDAQ: STX) (the “Company” or “Seagate”) today reported
financial results for the quarter and fiscal year ended June 30, 2017. For the fourth quarter, the Company reported revenue of $2.4 billion, gross margin of 27.7%, net income of $114 million and diluted earnings per share of $0.38. On
a non-GAAP basis, which excludes the net impact of certain items, Seagate reported gross margin of 28.9%, net income of $192 million and diluted earnings per share of $0.65.

[0001193125-17-234440:8k_2_02:9]
During the fourth quarter, the Company generated $243 million in cash flow from operations and returned approximately $400 million to shareholders
in the form of dividends and share repurchases.

[0001193125-17-234440:8k_2_02:10]
For the fiscal year ended June 30, 2017, the Company reported revenue of $10.8 billion, gross
margin of 29.5%, net income of $772 million and diluted earnings per share of $2.58. On a non-GAAP basis, Seagate reported gross margin of 30.5%, net income of $1.2 billion and diluted earnings per
share of $4.12.

[0001193125-17-234440:8k_2_02:11]
In fiscal year 2017, the Company generated approximately $1.9 billion in cash flow from operations and returned 53% of that to
shareholders in cash dividends of $561 million and share repurchases of 12.1 million ordinary shares for $460 million. Seagate’s balance sheet remains healthy and during the fiscal year the Company successfully raised
$1.25 billion in investment-grade debt and repurchased and redeemed approximately $316 million of outstanding debt. Cash and cash equivalents totaled approximately $2.5 billion at the end of the fiscal year. There were
292 million ordinary shares issued and outstanding as of the end of the fiscal year.

[0001193125-17-234440:8k_2_02:12]
“The results of our performance this fiscal year reflect
improved year-over-year profitability of our storage product portfolio and business operations,” said Steve Luczo, Seagate’s chairman and chief executive officer. “Although the near-term dynamics of technology shifts present demand
variations for the storage industry from time to time, we continue to see growing storage demand in the long-run driven by the proliferation of data growth from new technologies, emerging industries, and
growing businesses. We believe we have the vision, products, technology and experience to ensure our long-term success and shareholder value.”

[0001193125-17-234440:8k_2_02:13]
For a
detailed reconciliation of GAAP to non-GAAP results, see accompanying financial tables.

[0001193125-17-234440:8k_2_02:14]
Seagate has issued a
Supplemental Financial Information document, which is available on Seagate’s Investors Relations website at www.seagate.com/investors.

[0001193125-17-234440:8k_2_02:15]
Quarterly Cash Dividend

[0001193125-17-234440:8k_2_02:16]
The Board of Directors of the Company (the “Board”) has approved a quarterly cash dividend of $0.63 per share, which will be payable on
October 4, 2017 to shareholders of record as of the close of business on September 20, 2017. The payment of any future quarterly dividends will be at the discretion of the Board and will be dependent upon Seagate’s financial position,
results of operations, available cash, cash flow, capital requirements and other factors deemed relevant by the Board.

[0001193125-17-234440:8k_2_02:17]
Investor Communications

[0001193125-17-234440:8k_2_02:18]
Seagate management will hold a public webcast today at 6:00 a.m. Pacific Time that can be accessed on its Investor Relations website at
www.seagate.com/investors. During today’s webcast, the Company will provide an outlook for its first fiscal quarter of 2018, including key underlying assumptions.

[0001193125-17-234440:8k_2_02:19]
An archived audio webcast of this event will be available on Seagate’s Investors Relations website at www.seagate.com/investors shortly following the
event conclusion.

[0001193125-17-234440:8k_2_02:20]
About Seagate

[0001193125-17-234440:8k_2_02:21]
To learn more about
the Company’s products and services, visit www.seagate.com and follow us on Twitter, Facebook, LinkedIn, Spiceworks, YouTube and subscribe to our blog. The contents of our website and social media channels are not a part of this release.

[0001193125-17-234440:8k_2_02:22]
Cautionary Note Regarding Forward-Looking Statements

[0001193125-17-234440:8k_2_02:23]
The inclusion of Seagate’s website address in this press release is intended to be an inactive textual
reference only and not an active hyperlink. The information contained in, or that can be accessed through, Seagate’s website and social media channels are not part of this press release.

[0001193125-17-234440:8k_2_02:24]
SEAGATE TECHNOLOGY PLC

[0001193125-17-234440:8k_2_02:25]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-17-234440:8k_2_02:26]
(In millions)

[0001193125-17-234440:8k_2_02:27]
(Unaudited)

[0001193125-17-234440:8k_2_02:28]
|  |  | June 30,2017 |  |  | July 1,2016 (a) |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,539 |  |  | $ | 1,125 |  |
| Short-term investments |  |  | — |  |  |  | 6 |  |
| Accounts receivable, net |  |  | 1,199 |  |  |  | 1,318 |  |
| Inventories |  |  | 982 |  |  |  | 868 |  |
| Other current assets |  |  | 321 |  |  |  | 216 |  |
| Total current assets |  |  | 5,041 |  |  |  | 3,533 |  |
| Property, equipment and leasehold improvements, net |  |  | 1,875 |  |  |  | 2,160 |  |
| Goodwill |  |  | 1,238 |  |  |  | 1,237 |  |
| Other intangible assets, net |  |  | 281 |  |  |  | 448 |  |
| Deferred income taxes |  |  | 609 |  |  |  | 616 |  |
| Other assets, net |  |  | 224 |  |  |  | 219 |  |
| Total Assets |  | $ | 9,268 |  |  | $ | 8,213 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 1,626 |  |  | $ | 1,517 |  |
| Accrued employee compensation |  |  | 237 |  |  |  | 184 |  |
| Accrued warranty |  |  | 113 |  |  |  | 104 |  |
| Accrued expenses |  |  | 650 |  |  |  | 444 |  |
| Total current liabilities |  |  | 2,626 |  |  |  | 2,249 |  |
| Long-term accrued warranty |  |  | 120 |  |  |  | 102 |  |
| Long-term accrued income taxes |  |  | 15 |  |  |  | 14 |  |
| Other non-current liabilities |  |  | 122 |  |  |  | 164 |  |
| Long-term debt |  |  | 5,021 |  |  |  | 4,091 |  |
| Total Liabilities |  |  | 7,904 |  |  |  | 6,620 |  |
| Equity: |  |  |  |  |  |  |  |  |
| Total Equity |  |  | 1,364 |  |  |  | 1,593 |  |
| Total Liabilities and Equity |  | $ | 9,268 |  |  | $ | 8,213 |  |

[0001193125-17-234440:8k_2_02:29]
| (a) | The information in this column was derived from the Company’s audited Consolidated Balance Sheet as of July 1, 2016. |

[0001193125-17-234440:8k_2_02:30]
SEAGATE TECHNOLOGY PLC

[0001193125-17-234440:8k_2_02:31]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-17-234440:8k_2_02:32]
(In millions, except per share data)

[0001193125-17-234440:8k_2_02:33]
(Unaudited)

[0001193125-17-234440:8k_2_02:34]
|  |  | For the Three Months Ended |  |  | For the Fiscal Years Ended |  |
|  |  | June 30,2017 |  |  | July 1,2016 |  |  | June 30,2017 |  |  | July 1,2016 (a) |  |
| Revenue |  | $ | 2,406 |  |  | $ | 2,654 |  |  | $ | 10,771 |  |  | $ | 11,160 |  |
| Cost of revenue |  |  | 1,740 |  |  |  | 1,992 |  |  |  | 7,597 |  |  |  | 8,545 |  |
| Product development |  |  | 288 |  |  |  | 307 |  |  |  | 1,232 |  |  |  | 1,237 |  |
| Marketing and administrative |  |  | 149 |  |  |  | 143 |  |  |  | 606 |  |  |  | 635 |  |
| Amortization of intangibles |  |  | 19 |  |  |  | 29 |  |  |  | 104 |  |  |  | 123 |  |
| Restructuring and other, net |  |  | 14 |  |  |  | 80 |  |  |  | 178 |  |  |  | 175 |  |
| Total operating expenses |  |  | 2,210 |  |  |  | 2,551 |  |  |  | 9,717 |  |  |  | 10,715 |  |
| Income from operations |  |  | 196 |  |  |  | 103 |  |  |  | 1,054 |  |  |  | 445 |  |
| Interest income |  |  | 5 |  |  |  | 1 |  |  |  | 12 |  |  |  | 3 |  |
| Interest expense |  |  | (62 | ) |  |  | (51 | ) |  |  | (222 | ) |  |  | (193 | ) |
| Other, net |  |  | (19 | ) |  |  | 1 |  |  |  | (29 | ) |  |  | 19 |  |
| Other expense, net |  |  | (76 | ) |  |  | (49 | ) |  |  | (239 | ) |  |  | (171 | ) |
| Income before income taxes |  |  | 120 |  |  |  | 54 |  |  |  | 815 |  |  |  | 274 |  |
| Provision for (benefit from) income taxes |  |  | 6 |  |  |  | (16 | ) |  |  | 43 |  |  |  | 26 |  |
| Net income |  | $ | 114 |  |  | $ | 70 |  |  | $ | 772 |  |  | $ | 248 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.39 |  |  | $ | 0.23 |  |  | $ | 2.61 |  |  | $ | 0.83 |  |
| Diluted |  |  | 0.38 |  |  |  | 0.23 |  |  |  | 2.58 |  |  |  | 0.82 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 294 |  |  |  | 299 |  |  |  | 296 |  |  |  | 299 |  |
| Diluted |  |  | 297 |  |  |  | 300 |  |  |  | 299 |  |  |  | 302 |  |
| Cash dividends declared per share |  | $ | 0.63 |  |  | $ | 0.63 |  |  | $ | 2.52 |  |  | $ | 2.43 |  |

[0001193125-17-234440:8k_2_02:35]
| (a) | The information in this column was derived from the Company’s audited Consolidated Statement of Operations for the year ended July 1, 2016. |

[0001193125-17-234440:8k_2_02:36]
SEAGATE TECHNOLOGY PLC

[0001193125-17-234440:8k_2_02:37]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-17-234440:8k_2_02:38]
(In millions)

[0001193125-17-234440:8k_2_02:39]
(Unaudited)

[0001193125-17-234440:8k_2_02:40]
|  |  | For the Fiscal Years Ended |  |
|  |  | June 30,2017 |  |  | July 1,2016 (a) |  |
| OPERATING ACTIVITIES |  |  |  |  |  |  |  |  |
| Net income |  | $ | 772 |  |  | $ | 248 |  |
| Adjustments to reconcile net income to net cash from operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 749 |  |  |  | 815 |  |
| Share-based compensation |  |  | 137 |  |  |  | 120 |  |
| Loss (gain) on redemption and repurchase of debt |  |  | 7 |  |  |  | (3 | ) |
| Impairment of long-lived assets |  |  | 42 |  |  |  | 26 |  |
| Deferred income taxes |  |  | 3 |  |  |  | (2 | ) |
| Other non-cash operating activities, net |  |  | 20 |  |  |  | 12 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 122 |  |  |  | 464 |  |
| Inventories |  |  | (114 | ) |  |  | 145 |  |
| Accounts payable |  |  | 121 |  |  |  | (24 | ) |
| Accrued employee compensation |  |  | 53 |  |  |  | (78 | ) |
| Accrued expenses, income taxes and warranty |  |  | 47 |  |  |  | (42 | ) |
| Other assets and liabilities |  |  | (43 | ) |  |  | (1 | ) |
| Net cash provided by operating activities |  |  | 1,916 |  |  |  | 1,680 |  |
| INVESTING ACTIVITIES |  |  |  |  |  |  |  |  |
| Acquisition of property, equipment and leasehold improvements |  |  | (434 | ) |  |  | (587 | ) |
| Purchases of strategic investments |  |  | (37 | ) |  |  | — |  |
| Maturities of short-term investments |  |  | 6 |  |  |  | — |  |
| Cash used in acquisition of businesses, net of cash acquired |  |  | — |  |  |  | (634 | ) |
| Other investing activities, net |  |  | 6 |  |  |  | 10 |  |
| Net cash used in investing activities |  |  | (459 | ) |  |  | (1,211 | ) |
| FINANCING ACTIVITIES |  |  |  |  |  |  |  |  |
| Net proceeds from issuance of long-term debt |  |  | 1,232 |  |  |  | — |  |
| Redemption and repurchase of debt |  |  | (316 | ) |  |  | (22 | ) |
| Proceeds from issuance of ordinary shares under employee stock plans |  |  | 86 |  |  |  | 79 |  |
| Dividends to shareholders |  |  | (561 | ) |  |  | (727 | ) |
| Taxes paid related to net share settlement of equity awards |  |  | (27 | ) |  |  | (56 | ) |
| Repurchases of ordinary shares |  |  | (460 | ) |  |  | (1,090 | ) |
| Other financing activities, net |  |  | — |  |  |  | (4 | ) |
| Net cash used in financing activities |  |  | (46 | ) |  |  | (1,820 | ) |
| Effect of foreign currency exchange rate changes on cash and cash equivalents |  |  | — |  |  |  | (3 | ) |
| Increase (decrease) in cash, cash equivalents and restricted cash |  |  | 1,411 |  |  |  | (1,354 | ) |
| Cash, cash equivalents and restricted cash at the beginning of the year |  |  | 1,132 |  |  |  | 2,486 |  |
| Cash, cash equivalents and restricted cash at the end of the year |  | $ | 2,543 |  |  | $ | 1,132 |  |

[0001193125-17-234440:8k_2_02:41]
| (a) | The information in this column was derived from the Company’s audited Consolidated Statement of Cash Flows for the year ended July 1, 2016. |

[0001193125-17-234440:8k_2_02:42]
Use of non-GAAP financial information

[0001193125-17-234440:8k_2_02:43]
The Company uses non-GAAP measures of adjusted revenue, gross margin, net income, diluted earnings per share and
operating expenses which are adjusted from results based on GAAP to exclude certain expenses, gains and losses. These non-GAAP financial measures may be provided to enhance the user’s overall
understanding of the Company’s current financial performance and its prospects for the future. Specifically, the Company believes non-GAAP results provide useful information to both management and
investors as these non-GAAP results exclude certain expenses, gains and losses that it believes are not indicative of its core operating results and because it is similar to the approach used in connection
with the financial models and estimates published by financial analysts who follow the Company.

[0001193125-17-234440:8k_2_02:44]
These non-GAAP
results are some of the primary measurements management uses to assess the Company’s performance, allocate resources and plan for future periods. Reported non-GAAP results should only be considered as
supplemental to results prepared in accordance with GAAP, and not considered as a substitute for, or superior to, GAAP results. These non-GAAP measures may differ from the
non-GAAP measures reported by other companies in its industry.

[0001193125-17-234440:8k_2_02:45]
SEAGATE TECHNOLOGY PLC

[0001193125-17-234440:8k_2_02:46]
ADJUSTMENTS TO GAAP NET INCOME AND DILUTED NET INCOME PER SHARE

[0001193125-17-234440:8k_2_02:47]
(In millions, except per share amounts)

[0001193125-17-234440:8k_2_02:48]
(Unaudited)

[0001193125-17-234440:8k_2_02:49]
|  |  |  |  |  | For the ThreeMonths EndedJune 30, 2017 |  |  | For the FiscalYear EndedJune 30, 2017 |  |
| Reconciliation of GAAP Net Income: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP Net Income |  |  |  |  |  | $ | 114 |  |  | $ | 772 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue |  |  | A |  |  |  | — |  |  |  | (1 | ) |
| Cost of revenue |  |  | B |  |  |  | 30 |  |  |  | 109 |  |
| Product development |  |  | C |  |  |  | 13 |  |  |  | 44 |  |
| Marketing and administrative |  |  | D |  |  |  | 3 |  |  |  | 4 |  |
| Amortization of intangibles |  |  | E |  |  |  | 18 |  |  |  | 99 |  |
| Restructuring and other, net |  |  | F |  |  |  | 14 |  |  |  | 178 |  |
| Other expense, net |  |  | G |  |  |  | 6 |  |  |  | 30 |  |
| Provision for income taxes |  |  | H |  |  |  | (6 | ) |  |  | (3 | ) |
| Non-GAAP net income |  |  |  |  |  | $ | 192 |  |  | $ | 1,232 |  |
| Reconciliation of GAAP Diluted Net Income Per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  |  |  |  |  | $ | 0.38 |  |  | $ | 2.58 |  |
| Non-GAAP |  |  |  |  |  | $ | 0.65 |  |  | $ | 4.12 |  |
| Shares used in diluted net income per share calculation |  |  |  |  |  |  | 297 |  |  |  | 299 |  |

[0001193125-17-234440:8k_2_02:50]
| A | For the fiscal year ended June 30, 2017, Revenue has been adjusted on a non-GAAP basis for changes in the sales provision for discontinued products. |

[0001193125-17-234440:8k_2_02:51]
| B | For the three months and fiscal year ended June 30, 2017, Cost of revenue has been adjusted on a non-GAAP to exclude amortization of intangibles associated with acquisitions, accelerated depreciation, the write off of certain fixed assets and inventory related to restructuring and other charges. |

[0001193125-17-234440:8k_2_02:52]
| C | For the three months and fiscal year ended June 30, 2017, Product development expenses have been adjusted on a non-GAAP basis to exclude accelerated depreciation and the write off of certain assets related to restructuring and other charges. |

[0001193125-17-234440:8k_2_02:53]
| D | For the three months and fiscal year ended June 30, 2017, Marketing and administrative expenses have been adjusted on a non-GAAP basis primarily to reflect the impact of certain strategic development costs and the write off of certain fixed assets. |

[0001193125-17-234440:8k_2_02:54]
| E | For the three months and fiscal year ended June 30, 2017, Amortization of intangibles primarily related to our acquisitions has been excluded on a non-GAAP basis. |

[0001193125-17-234440:8k_2_02:55]
| F | For the three months and fiscal year ended June 30, 2017, Restructuring and other, net, has been adjusted on a non-GAAP basis primarily related to reductions in our workforce and facility exit costs as a result of our ongoing focus on cost efficiencies in all areas of our business. |

[0001193125-17-234440:8k_2_02:56]
| G | For the three months and fiscal year ended June 30, 2017, Other expense, net, has been adjusted on a non-GAAP basis to exclude the net impact of losses recognized on the early redemption and repurchase of debt and impairment of certain strategic investments. |

[0001193125-17-234440:8k_2_02:57]
| H | For the three months and fiscal year ended June 30, 2017, Provision for income taxes represents the tax effects of non-GAAP adjustments determined using a hybrid with and without method and effective tax rate for the applicable adjustment and jurisdiction. |

## item 5.02 — body, verbatim

[0001193125-17-234440:8k_body:1]
Item 5.02

[0001193125-17-234440:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0001193125-17-234440:8k_body:3]
On July 25, 2017 the Company’s Board of Directors (the “Board”) appointed William D. Mosley as Chief Executive Officer,
effective October 1, 2017. The Board also appointed Mr. Mosley as a Director of the Company, effective July 25, 2017. Mr. Mosley will serve as a Director until the Company’s next annual general meeting of shareholders (the
“AGM”) when he is expected to stand for election by a vote of Seagate Technology’s shareholders. There was not and is not any arrangement or understanding between Mr. Mosley and any other person pursuant to which Mr. Mosley
was selected to be a director. Additionally, Mr. Mosley will not receive any compensation for his service as a director.

[0001193125-17-234440:8k_body:4]
Mr. Mosley, 50, has served as the Company’s President, Chief Operating Officer since June 2016. He was previously the Company’s
President, Operations and Technology from October 2013 to June 2016 and its Executive Vice President, Operations from March 2011 until October 2013. Prior to that, he served as Executive Vice President, Sales and Marketing from September 2009
through March 2011; Executive Vice President, Sales, Marketing and Product Line Management from February 2009 to September 2009; Senior Vice President, Global Disk Storage Operations from 2007 to 2009; and Vice President, Research and Development,
Engineering from 2002 to 2007.

[0001193125-17-234440:8k_body:5]
The Board did not change Mr. Mosley’s annualized base salary of $800,100 or his bonus target of 125%
of his base salary for the first quarter of fiscal year 2018. Effective on the date of his appointment as Chief Executive Officer, however, the Board approved an annualized base salary increase to $1,000,000 and bonus target increase to 150% of his
base salary. The Board also approved a target value for long-term, equity-based grants, expected to be made in the future, to Mr. Mosley of $6,950,000 for fiscal year 2018. The vesting of such long-term, equity-based awards remain subject to the
terms of his equity agreements. He will also continue to be eligible for severance benefits pursuant to the Company’s Fifth Amended and Restated Executive Severance and Change in Control Plan as described in the Company’s Proxy Statement
filed with the SEC on September 9, 2016 (the “Severance Plan”).

[0001193125-17-234440:8k_body:6]
On July 25, 2017, the Company also announced that
Stephen J. Luczo will step down from his position as Chief Executive Officer, effective October 1, 2017. Mr. Luczo will remain with the Company in the role of Executive Chairman and will continue to serve as Chairman of the Board.

[0001193125-17-234440:8k_body:7]
The Board did not change Mr. Luczo’s annualized base salary of $1,200,056 or bonus target of 150% of his base salary for the first
quarter of fiscal year 2018. Effective on the date of his change of role to Executive Chairman, however, the Board approved an annualized base salary reduction to $750,000 and a bonus target reduction to 100% of his base salary. The Board also
approved a target value for long-term, equity-based grants, expected to be made in the future, to Mr. Luczo of $6,500,000 for fiscal year 2018. The vesting of such long-term, equity-based awards remain subject to the terms of his equity agreements.

[0001193125-17-234440:8k_body:8]
Effective October 1, 2017, Mr. Luczo will not be eligible for severance benefits pursuant to the
Severance Plan. If terminated without Cause (as that term is defined in the Severance Plan), Mr. Luczo will be entitled to up to 12 months of continued employment in an advisory role to the Company’s Chief Executive Officer and the Board with
an annual base pay of $250,000. He will not be eligible for the Company’s variable pay or any new equity grants, however, he will continue vesting in equity grants approved prior to termination and remain eligible for the Company’s health
and welfare benefits available to all employees.

[0001193125-17-234440:8k_body:9]
A copy of the press release announcing these changes is attached to this Current Report
on Form 8-K as Exhibit 99.2.

[0001193125-17-234440:8k_body:10]
As previously announced on June 2, 2017, Philip G. Brace, President, Cloud Systems and Silicon Group,
will be leaving the Company. On July 20, 2017, the Company and Mr. Brace agreed that the effective date of his departure will be October 2, 2017. Mr. Brace will receive benefits consistent with the Company’s obligations to
him under the Severance Plan.
