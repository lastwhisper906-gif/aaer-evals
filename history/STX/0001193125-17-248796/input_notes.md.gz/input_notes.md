# STX notes — 0001193125-17-248796


## invest:InvestmentTableTextBlock

[0001193125-17-248796:notes:1]
The following table summarizes, by major type, the fair value and amortized cost of the Company's investments as of July 1, 2016:

[0001193125-17-248796:notes:2]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 232 |  |  | $ | — |  |  | $ | 232 |  |
| Corporate bonds |  | 6 |  |  | — |  |  | 6 |  |
| Certificates of deposit |  | 5 |  |  | — |  |  | 5 |  |
| Total |  | $ | 243 |  |  | $ | — |  |  | $ | 243 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  | $ | 230 |  |
| Included in Short-term investments |  |  |  |  |  |  | 6 |  |
| Included in Other current assets |  |  |  |  |  |  | 7 |  |
| Total |  |  |  |  |  |  | $ | 243 |  |

[0001193125-17-248796:notes:3]
The following table summarizes, by major type, the fair value and amortized cost of the Company's investments as of June 30, 2017:

[0001193125-17-248796:notes:4]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 594 |  |  | $ | — |  |  | $ | 594 |  |
| Time deposits and certificates of deposit |  | 584 |  |  | — |  |  | 584 |  |
| Total |  | $ | 1,178 |  |  | $ | — |  |  | $ | 1,178 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  | $ | 1,174 |  |
| Included in Other current assets |  |  |  |  |  |  | 4 |  |
| Total |  |  |  |  |  |  | $ | 1,178 |  |


## stx:ScheduleOfShareBasedPaymentAwardStockOptionAndEmployeeStockPurchasePlanValuationAssumptionsAndFairValueDisclosuresTableTextBlock

[0001193125-17-248796:notes:5]
2017, 2016 and 2015 were estimated using the following assumptions:

[0001193125-17-248796:notes:6]
|  | Fiscal Years |
|  | 2017 |  | 2016 |  | 2015 |
| Options |  |  |  |  |  |  |  |  |
| Expected term (in years) | 4.2 |  |  | 2.1 - 4.2 |  |  | 4.2 |  |
| Volatility | 38 - 42% |  |  | 33 - 48% |  |  | 33 - 35% |  |
| Weighted-average volatility | 39 | % |  | 36 | % |  | 34 | % |
| Expected dividend rate | 4.9 - 6.4% |  |  | 4.6 - 11.0% |  |  | 2.9 - 4.0% |  |
| Weighted-average expected dividend rate | 6.3 | % |  | 5.6 | % |  | 3.0 | % |
| Risk-free interest rate | 1.1 - 1.8% |  |  | 0.6 - 1.5% |  |  | 1.1 - 1.5% |  |
| Weighted-average fair value | $ | 6.83 |  |  | $ | 12.28 |  |  | $ | 12.98 |  |
| RSU |  |  |  |  |  |
| Expected term (in years) | 4.2 |  |  | 4.2 |  |  | 4.2 |  |
| Expected dividend rate | 4.6 - 7.7% |  |  | 4.6 - 11.0% |  |  | 2.9% - 4.0% |  |
| Weighted-average expected dividend rate | 6.4 | % |  | 5.16 | % |  | 3.11 | % |
| Weighted-average fair value | $ | 30.85 |  |  | $ | 41.47 |  |  | $ | 46.1 |  |
| ESPP |  |  |  |  |  |  |  |  |
| Expected term (in years) | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Volatility | 36 - 49% |  |  | 28 - 46% |  |  | 28 - 29% |  |
| Weighted-average volatility | 43 | % |  | 39 | % |  | 28 | % |
| Expected dividend rate | 5.6 - 7.8% |  |  | 4.6 - 8.3% |  |  | 3.0 - 3.8% |  |
| Weighted-average expected dividend rate | 6.8 | % |  | 6.9 | % |  | 3.4 | % |
| Risk-free interest rate | 0.4 - 0.6% |  |  | 0.2 - 0.5% |  |  | 0.1 | % |
| Weighted-average fair value | $ | 9.78 |  |  | $ | 9.08 |  |  | $ | 12.21 |  |
| PSUs subject to market condition |  |  |  |  |  |  |  |  |
| Expected term (in years) | 3.0 |  |  | 3.0 |  |  | 3.0 |  |
| Volatility | 41 - 42% |  |  | 30 | % |  | 40 | % |
| Weighted-average volatility | 41 | % |  | 30 | % |  | 40 | % |
| Expected dividend rate | 6.3-7.0% |  |  | 4.3 | % |  | 2.8 | % |
| Weighted-average expected dividend rate | 7.0 | % |  | 4.3 | % |  | 2.8 | % |
| Risk-free interest rate | 0.9 - 1.3% |  |  | 1.1 | % |  | 1.1 | % |
| Weighted-average fair value | $ | 32.41 |  |  | $ | 47.34 |  |  | $ | 58.31 |  |
| PSUs subject to an AEPS condition |  |  |  |  |  |
| Expected term (in years) | 4.2 |  |  | 4.2 |  |  | 4.2 |  |
| Expected dividend rate | 5.9 - 6.4% |  |  | 4.6 - 7.3% |  |  | 3.0 - 4.0% |  |
| Weighted-average expected dividend rate | 6.2 | % |  | 5.9 | % |  | 3.3 | % |
| Weighted-average fair value | $ | 31.61 |  |  | $ | 42.09 |  |  | $ | 46.52 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0001193125-17-248796:notes:7]
2017, 2016 and 2015:

[0001193125-17-248796:notes:8]
| (In millions) | Number ofSharesRepurchased |  | Dollar Valueof SharesRepurchased |
| Cumulative repurchased through June 27, 2014 | 285 |  |  | $ | 7,398 |  |
| Repurchased in fiscal year 2015 | 19 |  |  | 1,087 |  |
| Cumulative repurchased through July 3, 2015 | 304 |  |  | 8,485 |  |
| Repurchased in fiscal year 2016(a) | 24 |  |  | 1,146 |  |
| Cumulative repurchased through July 1, 2016 | 328 |  |  | 9,631 |  |
| Repurchased in fiscal year 2017(a) | 13 |  |  | 487 |  |
| Cumulative repurchased through June 30, 2017 | 341 |  |  | $ | 10,118 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001193125-17-248796:notes:9]
Advertising Expense.    The cost of advertising is expensed as incurred. Advertising costs were approximately $16 million, $31 million and $64 million in fiscal years 2017, 2016 and 2015, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-17-248796:notes:10]
Acquisitions

[0001193125-17-248796:notes:11]
Dot Hill Systems Corp.

[0001193125-17-248796:notes:12]
On October 6, 2015, the Company acquired all of the outstanding shares of Dot Hill Systems Corp. (“Dot Hill”), a supplier of software and hardware storage systems. The Company paid $9.75 per share, or $674 million, in cash for the acquisition. The acquisition of Dot Hill further expands the Company's OEM-focused cloud storage systems business and advances the Company's strategic efforts.

[0001193125-17-248796:notes:13]
The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the acquisition date:

[0001193125-17-248796:notes:14]
| (Dollars in millions) |  | Amount |
| Cash and cash equivalents |  | $ | 40 |  |
| Accounts receivable, net |  | 48 |  |
| Inventories |  | 21 |  |
| Other current and non-current assets |  | 7 |  |
| Property, plant and equipment |  | 10 |  |
| Intangible assets |  | 252 |  |
| Goodwill |  | 364 |  |
| Total assets |  | 742 |  |
| Accounts payable, accrued expenses and other |  | (68 | ) |
| Total liabilities |  | (68 | ) |
| Total |  | $ | 674 |  |

[0001193125-17-248796:notes:15]
The following table shows the fair value of the separately identifiable intangible assets at the time of acquisition and the period over which each intangible asset will be amortized:

[0001193125-17-248796:notes:16]
| (Dollars in millions) |  | Fair Value |  | Weighted-AverageAmortizationPeriod |
| Existing technology |  | $ | 164 |  |  | 5.0 years |
| Customer relationships |  | 71 |  |  | 7.0 years |
| Trade names |  | 3 |  |  | 5.0 years |
| Total amortizable intangible assets acquired |  | 238 |  |  | 5.5 years |
| In-process research and development |  | 14 |  |  |  |
| Total acquired identifiable intangible assets |  | $ | 252 |  |  |  |

[0001193125-17-248796:notes:17]
The recognized goodwill, which is not deductible for income tax purposes, is primarily attributable to cost synergies expected to arise after the acquisition and the benefits the Company expects to derive from enhanced market opportunities.

[0001193125-17-248796:notes:18]
The expenses related to the acquisition of Dot Hill for the fiscal year ended July 1, 2016, which are included within Marketing and administrative expense on the Consolidated Statement of Operations, are not significant.

[0001193125-17-248796:notes:19]
The amounts of revenue and earnings of Dot Hill included in the Company's Consolidated Statement of Operations from the acquisition date were not significant.

[0001193125-17-248796:notes:20]
LSI's Flash Business

[0001193125-17-248796:notes:21]
On September 2, 2014, the Company completed the acquisition of certain assets and liabilities of LSI Corporation's ("LSI") Accelerated Solutions Division and Flash Components Division (collectively, the "Flash Business") from Avago Technologies Limited for $450 million in cash. The transaction is intended to strengthen Seagate's strategy to deliver a full suite of storage solutions, providing Seagate with established enterprise PCIe flash and SSD controller capabilities to deliver solutions for the growing flash storage market.

[0001193125-17-248796:notes:22]
| (Dollars in millions) |  | Amount |
| Inventories |  | $ | 37 |  |
| Property, plant and equipment |  | 22 |  |
| Intangible assets |  | 141 |  |
| Other assets |  | 6 |  |
| Goodwill |  | 337 |  |
| Total assets |  | 543 |  |
| Liabilities |  | (93 | ) |
| Total liabilities |  | (93 | ) |
| Total |  | $ | 450 |  |

[0001193125-17-248796:notes:23]
The following table shows the fair value of the separately identifiable intangible assets at the time of acquisition and the weighted-average period over which intangible assets within each category will be amortized:

[0001193125-17-248796:notes:24]
| (Dollars in millions) |  | Fair Value |  | Weighted-AverageAmortizationPeriod |
| Existing technology |  | $ | 84 |  |  | 3.5 years |
| Customer relationships |  | 40 |  |  | 3.8 years |
| Trade names |  | 17 |  |  | 4.5 years |
| Total acquired identifiable intangible assets |  | $ | 141 |  |  | 3.7 years |

[0001193125-17-248796:notes:25]
The goodwill recognized is primarily attributable to the benefits the Company expects to derive from enhanced market opportunities, and is not deductible for income tax purposes.

[0001193125-17-248796:notes:26]
The Company incurred approximately $1 million of expenses related to the acquisition of LSI's Flash Business in fiscal year 2015, which are included within Marketing and administrative expense on the Consolidated Statement of Operations.

[0001193125-17-248796:notes:27]
The amounts of revenue and earnings of LSI's Flash Business included in the Company's Consolidated Statement of Operations from the acquisition date through the end of fiscal year ended July 3, 2015 were not significant.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001193125-17-248796:notes:28]
Cash, Cash Equivalents and Short-Term Investments.   The Company considers all highly liquid investments with a remaining maturity of 90 days or less at the time of purchase to be cash equivalents. Cash equivalents are carried at cost, which approximates fair value. The Company's short-term investments are primarily comprised of money market funds, time deposits and certificates of deposits. The Company has classified its marketable securities as available-for-sale and they are stated at fair value with unrealized gains and losses included in Accumulated other comprehensive loss, which is a component of Shareholders' Equity. The Company evaluates the available-for sale securities in an unrealized loss position for other-than-temporary impairment. Realized gains and losses are included in Other, net on the Company's Consolidated Statements of Operations. The cost of securities sold is based on the specific identification method.

[0001193125-17-248796:notes:29]
Restricted Cash and Investments.    Restricted cash and investments represent cash and cash equivalents and investments that are restricted as to withdrawal or use for other than current operations.


## us-gaap:CommitmentsDisclosureTextBlock

[0001193125-17-248796:notes:30]
Commitments

[0001193125-17-248796:notes:31]
Leases. The Company leases certain property, facilities and equipment under non-cancelable lease agreements. Land and facility leases expire at various dates through 2082 and contain various provisions for rental adjustments including, in certain cases, a provision based on increases in the Consumer Price Index. Also, certain leases provide for renewal of the lease at the Company's option at expiration of the lease. The lease term begins on the date of initial possession of the leased property for purposes of recognizing lease expense on a straight-line basis over the term of the lease. The Company does not assume renewals in its determination of the lease term unless the renewals are deemed to be reasonably assured at lease inception. All of the leases require the Company to pay property taxes, insurance and normal maintenance costs which are expensed as incurred.

[0001193125-17-248796:notes:32]
Future minimum lease payments for operating leases (including accrued lease payments relating to restructuring plans) with initial or remaining terms of one year or more were as follows at June 30, 2017 (lease payments are shown net of sublease income):

[0001193125-17-248796:notes:33]
| Fiscal Years Ending |  | Operating Leases |
| (Dollars in millions) |  |  |
| 2018 |  | $ | 19 |  |
| 2019 |  | 15 |  |
| 2020 |  | 11 |  |
| 2021 |  | 9 |  |
| 2022 |  | 6 |  |
| Thereafter |  | 75 |  |
|  |  | $ | 135 |  |

[0001193125-17-248796:notes:34]
Total rent expense for all land, facility and equipment operating leases, net of sublease income, was $29 million, $43 million and $50 million for fiscal years 2017, 2016 and 2015, respectively. Total sublease rental income for fiscal years 2017, 2016 and 2015 was $2 million, $3 million and $3 million, respectively. The Company subleases a portion of its facilities that it considers to be in excess of current requirements. As of June 30, 2017, total future lease income to be recognized for the Company's existing subleases is approximately $9 million

[0001193125-17-248796:notes:35]
Capital Expenditures.    The Company's non-cancelable commitments for construction of manufacturing and product development facilities and purchases of equipment approximated $107 million at June 30, 2017.

[0001193125-17-248796:notes:36]
Unconditional Purchase Obligations. During fiscal year 2017, the Company had unconditional long-term purchase obligations of approximately $1.1 billion in the aggregate, of which $900 million in the aggregate remains outstanding as of June 30, 2017, to purchase minimum quarterly amounts of inventory components at fixed and variable prices. The Company expects the commitment to total $375 million, $350 million and $175 million for fiscal years 2018, 2019 and 2020, respectively with no remaining commitment thereafter.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001193125-17-248796:notes:37]
Comprehensive Income.    The Company presents comprehensive income in a separate statement. Comprehensive income is comprised of net income and other gains and losses affecting equity that are excluded from net income.


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-17-248796:notes:38]
The consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

[0001193125-17-248796:notes:39]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles also requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its consolidated financial statements. Certain prior years amounts reported in the consolidated financial statements and notes thereto have been reclassified to conform to the current year’s presentation.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0001193125-17-248796:notes:40]
Restructuring Costs.     The Company records restructuring activities including costs for one-time termination benefits in accordance with ASC Topic 420 ("ASC 420"), Exit or Disposal Cost Obligations. The timing of recognition for severance costs accounted for under ASC 420 depends on whether employees are required to render service until they are terminated in order to receive the termination benefits. If employees are required to render service until they are terminated in order to receive the termination benefits, a liability is recognized ratably over the future service period. Otherwise, a liability is recognized when management has committed to a restructuring plan and has communicated those actions to employees. Employee termination benefits covered by existing benefit arrangements are recorded in accordance with ASC Topic 712, Non-retirement Postemployment Benefits. These costs are recognized when management has committed to a restructuring plan and the severance costs are probable and estimable.


## us-gaap:DebtDisclosureTextBlock

[0001193125-17-248796:notes:41]
Debt

[0001193125-17-248796:notes:42]
Short-Term Borrowings

[0001193125-17-248796:notes:43]
The credit agreement entered into by the Company and its subsidiary Seagate HDD Cayman on January 18, 2011 and subsequently amended (the "Revolving Credit Facility") provides the Company with a $700 million senior secured revolving credit facility. The term of the Revolving Credit Facility is through January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Revolving Credit Facility) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. The loans made under the Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing, and for the issuance of letters of credit up to a sub-limit of $75 million.

[0001193125-17-248796:notes:44]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to allow for higher net leverage levels. The Company was in compliance with the modified covenants as of June 30, 2017 and expects to be in compliance for the next 12 months.

[0001193125-17-248796:notes:45]
As of June 30, 2017, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

[0001193125-17-248796:notes:46]
Long-Term Debt

[0001193125-17-248796:notes:47]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”).  On November 5, 2013, Seagate HDD Cayman, issued $800 million in aggregate principal amount of 3.75% Senior Notes, which mature on November 15, 2018, in a private placement. The interest on the Notes is payable semi-annually on May 15 and November 15 of each year. The Notes are redeemable at the option of Seagate HDD Cayman in whole or in part, on not less than 30, nor more than 60 days' notice, at a “make-whole” premium redemption price. The “make-whole” premium redemption price will be equal to the greater of (1) 100% of the principal amount of the notes being redeemed, or (2) the sum of the present values of the remaining schedule payments of principal and interest on the Notes being redeemed, discounted at the redemption date on a semi-annual basis at a rate equal to the sum of the applicable Treasury rate plus 50 basis points. Accrued and unpaid interest, if any will be paid to, but excluding, the redemption date. The Notes are fully and unconditionally guaranteed by the Company on a senior unsecured basis. During fiscal year 2017, the Company repurchased $90 million aggregate principal amount of the 2018 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately $3 million, which is included in Other, net in the Company's Consolidated Statements of Operations.

[0001193125-17-248796:notes:48]
$600 million Aggregate Principal Amount of 6.875% Senior Notes due May 2020 (the “2020 Notes”). On May 13, 2010, the Company's subsidiary, Seagate HDD Cayman, completed the sale of $600 million aggregate principal amount of the 2020 Notes, in a private placement exempt from the registration requirements of the Securities Act of 1933, as amended. The obligations under the 2020 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.  The interest on the 2020 Notes is payable semi-annually on May 1 and November 1 of each year. The 2020 Notes were redeemable any time prior to May 1, 2015 at the option of the Company, in whole or in part, at a redemption price of 100% of the principal amount plus an “applicable premium” and accrued and unpaid interest, if any, to the redemption date. The "applicable premium" was equal to the greater of (1) 1% of the principal amount of the 2020 Notes, or (2) the excess, if any, of (a) the present value of the redemption price on May 1, 2015 plus interest payments due through May 1, 2015, discounted at the applicable Treasury rate as of the redemption date plus 50 basis points; over (b) the principal amount of such note. The 2020 Notes are redeemable at any time on or after May 1, 2015 at various prices expressed as a percentage of principal amount, as set forth in the indentures, plus accrued and unpaid interest, if any, to the redemption date. The issuer under the 2020 Notes is Seagate HDD Cayman, and the obligations under the 2020 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During fiscal year 2015, the 2020 Notes were fully extinguished through repurchase and redemption for cash at a premium to their principal amount, plus accrued and unpaid interest.  The Company recorded a loss on the repurchase of approximately $26 million, which is included in Other, net in the Company's Consolidated Statement of Operations.

[0001193125-17-248796:notes:49]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”).  On May 18, 2011, the Company's subsidiary, Seagate HDD Cayman, completed the sale of $600 million aggregate principal amount of the 2021 Notes, in a private placement exempt from the registration requirements of the Securities Act of 1933, as amended. The obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.  The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year.  The 2021 Notes are redeemable any time prior to May 1, 2016 at the option of the Company, in whole or in part, at a redemption price of 100% of the principal amount plus an “applicable premium” and accrued and unpaid interest, if any, to the redemption date. The "applicable premium" will be equal to the greater of (1) 1% of the principal amount of the 2021 Notes, or (2) the excess, if any, of (a) the present value of the redemption price on May 1, 2016 plus interest payments due through May 1, 2016, discounted at the applicable Treasury rate as of the redemption date plus 50 basis points; over (b) the principal amount of such note. The 2021 Notes are redeemable at any time on or after May 1, 2016 at various prices expressed as a percentage of principal amount, as set forth in the indentures, plus accrued and unpaid interest, if any, to the redemption date. In addition, any time before May 1, 2014, the Company may redeem up to 35% of the principal amount with the net cash proceeds from permitted sales of the Company's stock at a redemption price of 107% of the principal amount plus accrued interest to the redemption date.  The issuer under the 2021 Notes is Seagate HDD Cayman and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During fiscal years 2016 and 2015, the Company repurchased $1 million and $93 million, respectively, aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. For fiscal year 2016, the loss recorded on the repurchase was immaterial and for fiscal year 2015, the Company recorded a loss on the repurchase of approximately $13 million, which were included in Other, net in the Company's Consolidated Statement of Operations. During fiscal year 2017, the 2021 Notes were fully extinguished through redemption for cash at a premium to their principal amount of $158 million, plus accrued and unpaid interest. For fiscal year 2017, the Company recorded a loss on the redemption of approximately $5 million, which is included in Other, net in the Company's Consolidated Statement of Operations.

[0001193125-17-248796:notes:50]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). On February 3, 2017, Seagate HDD Cayman issued, in a private placement, $750 million in aggregate principal amount of 4.25% Senior Notes which will mature on March 1, 2022. The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year, commencing on September 1, 2017. At any time before February 1, 2022, Seagate HDD Cayman may redeem some or all of the 2022 Notes at a "make whole" redemption price, plus accrued and unpaid interest, if any. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the 2022 Notes redeemed, plus (2) the excess, if any, of (a) the sum of the present values of the remaining scheduled payments of principal and interest on the 2022 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 40 basis points, minus accrued and unpaid interest, if any, on the 2022 Notes being redeemed to, but excluding, the redemption date over (b) the principal amount of the 2022 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the 2022 Notes being redeemed to, but excluding, the redemption date. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-17-248796:notes:51]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). On May 22, 2013, Seagate HDD Cayman, issued $1 billion in aggregate principal amount of 4.75% Senior Notes, which mature on June 1, 2023, in a private placement. The obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year.  The 2023 Notes are redeemable at the option of the Company in whole or in part, on not less than 30, nor more than 60 days' notice, at a "make-whole" premium redemption price.  The "make-whole" redemption price will be equal to the greater of (1) 100% of the principal amount of the notes being redeemed, or (2) the sum of the present values of the remaining scheduled payments of principal and interest on the 2023 Notes being redeemed, discounted at the redemption date on a semi-annual basis at a rate equal to the sum of the applicable Treasury rate plus 50 basis points.  Accrued and unpaid interest, if any, will be paid to, but excluding, the redemption date. During fiscal year 2016, the Company repurchased $10 million aggregate principal amount of its 2023 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The gain recorded on the repurchase was immaterial, which is included in Other, net in the Company's Consolidated Statement of Operations. During fiscal year 2017, the Company repurchased $39 million aggregate principal amount of its 2023 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The loss recorded on the repurchase was immaterial, which is included in Other, net in the Company's Consolidated Statement of Operations.

[0001193125-17-248796:notes:52]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”).  On February 3, 2017, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 4.875% Senior Notes which will mature on March 1, 2024. The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year, commencing on September 1, 2017. At any time before January 1, 2024, Seagate HDD Cayman may redeem some or all of the 2024 Notes at a "make whole" redemption price, plus accrued and unpaid interest, if any. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the 2024 Notes redeemed, plus (2) the excess, if any, of (a) the sum of the present values of the remaining scheduled payments of principal and interest on the 2024 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 45 basis points, minus accrued and unpaid interest, if any, on the 2024 Notes being redeemed to, but excluding, the redemption date over (b) the principal amount of the 2024 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the 2024 Notes being redeemed to, but excluding, the redemption date. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-17-248796:notes:53]
$1 billion Aggregate principal amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”).  On May 28, 2014, Seagate HDD Cayman issued, in a private placement, $1 billion in aggregate principal amount of 4.75% Senior Notes due 2025, which mature on January 1, 2025. The interest on the Notes will be payable in cash semiannually on January 1 and July 1 of each year, commencing on January 1, 2015. At any time, upon not less than 30 nor more than 60 days’ notice, Seagate HDD may redeem some or all of the Notes at a ‘‘make-whole’’ redemption price. The ‘‘make-whole’’ redemption price will be equal to the greater of (1) 100% of the principal amount of the Notes redeemed, and (2) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points. Accrued and unpaid interest, if any, will be paid to, but excluding, the redemption date. The Notes are fully and unconditionally guaranteed by the Company on a senior unsecured basis. During fiscal year 2016, the Company repurchased $5 million aggregate principal amount of its 2025 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The gain recorded on the repurchase was immaterial, which is included in Other, net in the Company's Consolidated Statement of Operations. During fiscal year 2017, the Company repurchased $20 million aggregate principal amount of the 2025 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded a gain on the repurchase of approximately $1 million, which is included in Other, net in the Company's Consolidated Statements of Operations.

[0001193125-17-248796:notes:54]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June, 2027 (the “2027 Notes”). On May 14, 2015, Seagate HDD Cayman issued, in a private placement, $700 million in aggregate principal amount of 4.875% Senior Notes, which mature on June 1, 2027. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on December 1, 2015. At any time before March 1, 2027, Seagate HDD Cayman may redeem some or all of the Notes at a “make-whole” redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 40 basis points, minus accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date. At any time on or after March 1, 2027, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During fiscal year 2017, the Company repurchased $4 million aggregate principal amount of the 2027 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded an immaterial gain on the repurchase, which is included in Other, net in the Company's Consolidated Statements of Operations.

[0001193125-17-248796:notes:55]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December, 2034 (the “2034 Notes”). On December 2, 2014, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 5.75% Senior Notes, which mature on December 1, 2034. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on June 1, 2015. At any time before June 1, 2034, Seagate HDD Cayman may redeem some or all of the Notes at a “make-whole” redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points, minus accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date. At any time on or after June 1, 2034, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During fiscal year 2016, the Company repurchased $10 million aggregate principal amount of its 2034 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded a gain on the repurchase of approximately $3 million, which is included in Other, net in the Company's Consolidated Statement of Operations.

[0001193125-17-248796:notes:56]
At June 30, 2017, future principal payments on long-term debt were as follows (in millions):

[0001193125-17-248796:notes:57]
| Fiscal Year |  | Amount |
| 2018 |  | $ | — |  |
| 2019 |  | 710 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| 2022 |  | 750 |  |
| Thereafter |  | 3,613 |  |
| Total |  | $ | 5,073 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-17-248796:notes:58]
Derivative Financial Instruments

[0001193125-17-248796:notes:59]
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity market risks relating to its ongoing business operations. The Company enters into foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses denominated in foreign currencies. The Company's accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives in the Consolidated Balance Sheets at fair value. The changes in the fair value of the effective portions of designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments and the ineffective portions of cash flow hedges are adjusted to fair value through earnings.  The Company has no outstanding cash flow hedges as of June 30, 2017. The amount of net unrealized loss on cash flow hedges was $2 million as of July 1, 2016.

[0001193125-17-248796:notes:60]
The Company de-designates its cash flow hedges when the forecasted hedged transactions are realized or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company did not recognize any net gains or losses related to the loss of hedge designation on discontinued cash flow hedges during fiscal year 2017 and did not recognize any material amounts during fiscal years 2016 and 2015.

[0001193125-17-248796:notes:61]
As of June 30, 2017, the Company does not have outstanding foreign currency forward exchange contracts. The following tables show the total notional value of the Company's outstanding foreign currency forward exchange contracts as of July 1, 2016:

[0001193125-17-248796:notes:62]
|  |  | As of July 1, 2016 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| British Pound Sterling |  | $ | 47 |  |  | $ | 10 |  |

[0001193125-17-248796:notes:63]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plan—the Seagate Deferred Compensation Plan (the “SDCP”).  In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees. As of June 30, 2017, the notional investments underlying the TRS amounted to $105 million. The contract term of the TRS is through January 2018 and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001193125-17-248796:notes:64]
As of June 30, 2017, the Company has no outstanding foreign currency forward exchange contracts and the gross fair value of the TRS reflected in the Consolidated Balance Sheets is immaterial.

[0001193125-17-248796:notes:65]
The following tables show the Company's derivative instruments measured at gross fair value as reflected in the Consolidated Balance Sheet as of July 1, 2016:

[0001193125-17-248796:notes:66]
|  |  | As of July 1, 2016 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (2 | ) |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | — |  |  | Accrued expenses |  | (1 | ) |
| Total return swap |  | Other current assets |  | 3 |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 3 |  |  |  |  | $ | (3 | ) |

[0001193125-17-248796:notes:67]
The following tables show the effect of the Company's derivative instruments on the Consolidated Statement of Comprehensive Income and the Consolidated Statement of Operations for the fiscal year ended June 30, 2017:

[0001193125-17-248796:notes:68]
| (Dollars in millions) Derivatives Designated as Cash Flow Hedges |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
| Foreign currency forward exchange contracts |  | $ | (3 | ) |  | Cost of revenue |  | $ | (4 | ) |  | Cost of revenue |  | $ | — |  |

[0001193125-17-248796:notes:69]
\

[0001193125-17-248796:notes:70]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 1 |  |
| Total return swap |  | Operating expenses |  | $ | 10 |  |

[0001193125-17-248796:notes:71]
___________________________________

[0001193125-17-248796:notes:72]
| (a) | The amounts of gain or (loss) recognized in income related to the ineffective portion of the hedging relationships and to the amount excluded from the assessment of hedge effectiveness were less than $1 million for the fiscal year ended June 30, 2017. |

[0001193125-17-248796:notes:73]
The following tables show the effect of the Company's derivative instruments on the Consolidated Statement of Comprehensive Income and the Consolidated Statement of Operations for the fiscal year ended July 1, 2016:

[0001193125-17-248796:notes:74]
| (Dollars in millions) Derivatives Designated as Cash Flow Hedges |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
| Foreign currency forward exchange contracts |  | $ | (4 | ) |  | Cost of revenue |  | $ | (2 | ) |  | Cost of revenue |  | $ | — |  |

[0001193125-17-248796:notes:75]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (5 | ) |
| Total return swap |  | Operating expenses |  | $ | (1 | ) |

[0001193125-17-248796:notes:76]
| (a) | The amounts of gain or (loss) recognized in income related to the ineffective portion of the hedging relationships and to the amount excluded from the assessment of hedge effectiveness were less than $1 million for the fiscal year ended July 1, 2016. |


## us-gaap:DerivativesPolicyTextBlock

[0001193125-17-248796:notes:77]
Derivative Financial Instruments.    The Company applies the requirements of ASC Topic 815 ("ASC 815"), Derivatives and Hedging. ASC 815 requires that all derivatives be recorded on the balance sheet at fair value and establishes criteria for designation and effectiveness of hedging relationships

[0001193125-17-248796:notes:78]
The Company's accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives in the Consolidated Balance Sheets at fair value. The changes in the fair value of the effective portions of designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments and the ineffective portions of cash flow hedges are adjusted to fair value through earnings.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-17-248796:notes:79]
Share-based Compensation

[0001193125-17-248796:notes:80]
Share-Based Compensation Plans

[0001193125-17-248796:notes:81]
The Company's share-based compensation plans have been established to promote the Company's long-term growth and financial success by providing incentives to its employees, directors, and consultants through grants of share-based awards. The provisions of the Company's share-based benefit plans, which allow for the grant of various types of equity-based awards, are also intended to provide greater flexibility to maintain the Company's competitive ability to attract, retain and motivate participants for the benefit of the Company and its shareholders.

[0001193125-17-248796:notes:82]
Seagate Technology plc 2012 Equity Incentive Plan (the “EIP”).  On October 26, 2011, the shareholders approved the EIP and authorized the issuance of up to a total of  27.0 million ordinary shares, par value $0.0001 per share, plus any shares remaining available for grant under the Seagate Technology plc 2004 Share Compensation Plan (the "SCP") as of the effective date of the EIP (which was equal to 11.0 million ordinary shares as of the effective date of the EIP and which will increase by such additional number of shares as will be returned to the share reserve in respect of awards previously granted under the SCP) (together, the “Share Reserve”). On October 22, 2014, the shareholders authorized the issuance from the EIP of an additional 25 million ordinary shares, par value $0.0001 per share. Any shares that are subject to options or share appreciation rights granted under the EIP will be counted against the Share Reserve as one share for every one share granted, and any shares that are subject to restricted share bonus awards, restricted share units, performance share bonus awards or performance share awards (collectively, “Full-Value Share Awards”) will generally be counted against the Share Reserve as two and five-tenths shares for every one share granted. On October 19, 2016, the shareholders authorized the issuance from the EIP of an additional 7.5 million ordinary shares, par value $0.0001 per share. As of June 30, 2017, there were approximately 30.8 million ordinary shares available for issuance under the EIP.

[0001193125-17-248796:notes:83]
Dot Hill Systems 2009 Equity Incentive Plan (the "DHEIP").  Seagate Technology plc acquired the Dot Hill Systems 2009 Equity Incentive Plan effective October 6, 2015. The Company assumed the remaining authorized but unused share reserve of approximately 2 million shares, based on the conversion ratio, from the DHEIP on the acquisition date. Any shares that are subject to options or share appreciation rights granted under the DHEIP will be counted against the Share Reserve as one share for every one share granted, and any shares that are subject to restricted share bonus awards, restricted share units, performance share bonus awards or performance share awards (collectively, “Full-Value Share Awards”) will generally be counted against the Share Reserve as one and five-tenths shares for every one share granted. As of June 30, 2017, there were approximately 1 million ordinary shares available for issuance under the DHEIP.

[0001193125-17-248796:notes:84]
Seagate Technology plc Employee Stock Purchase Plan (the "ESPP").  There are 50.0 million ordinary shares authorized to be issued under the ESPP. The ESPP consists of a six-month offering period with a maximum issuance of 1.5 million ordinary shares per offering period. The ESPP permits eligible employees to purchase ordinary shares through payroll deductions generally at 85% of the fair market value of the ordinary shares. As of June 30, 2017 there were approximately 4.8 million ordinary shares available for issuance under the ESPP.

[0001193125-17-248796:notes:85]
Equity Awards

[0001193125-17-248796:notes:86]
Full-Value Share Awards (e.g. restricted share units, "RSU") generally vest over a period of three to four years, with cliff vesting of a portion of each award occurring annually, subject to continuous employment with the Company through the vesting date. Options generally vest as follows:  25% of the options will vest on the first anniversary of the vesting commencement date and the remaining 75% will vest ratably each month thereafter over the next 36 months. Options granted under the EIP and SCP have an exercise price equal to the fair market value of the Company's ordinary shares on the grant date. Fair market value is defined as the closing price of the Company's ordinary shares on NASDAQ on the grant date.

[0001193125-17-248796:notes:87]
The Company granted awards of performance-based share units ("PSU") to its senior executive officers under the SCP and the EIP where vesting is subject to both the continued employment of the participant by the Company and the achievement of certain performance goals established by the Compensation Committee of the Company's Board of Directors, including market-based performance goals.  A single PSU represents the right to receive a single ordinary share of the Company. During fiscal years 2017, 2016 and 2015, the Company granted 0.6 million, 0.4 million and 0.3 million PSUs, respectively, where performance is measured based on a three-year average return on invested capital ("ROIC") goal and a relative total shareholder return ("TSR") goal, which is based on the Company's ordinary shares measured against a benchmark TSR of a peer group over the same three-year period (the "TSR/ROIC" awards). These awards vest after the end of the performance period of three years from the grant date. A percentage of these units may vest only if at least the minimum ROIC goal is met regardless of whether the TSR goal is met. The number of share units to vest will range from 0% to 200% of the targeted units. In evaluating the fair value of these units, the Company used a Monte Carlo simulation on the grant date, taking the market-based TSR goal into consideration. Compensation expense related to these units is only recorded in a period if it is probable that the ROIC goal will be met, and it is to be recorded at the expected level of achievement.

[0001193125-17-248796:notes:88]
The Company also granted 0.2 million, 0.2 million and 0.4 million PSUs during fiscal years 2017, 2016 and 2015 respectively, to its senior executive officers which are subject to a performance goal related to the Company's adjusted earnings per share (the "AEPS" awards). These awards have a maximum seven-year vesting period, with 25% annual vesting starting on the first anniversary of the grant date. If the performance goal is not achieved, vesting is delayed to a following year in which the AEPS goal is achieved. Any unvested awards from prior years may vest cumulatively in a future year within the seven-year vesting period if the annual AEPS goal is achieved during a subsequent year. If the AEPS goal has not been met by the end of the seven year period, any unvested shares will be forfeited.

[0001193125-17-248796:notes:89]
Determining Fair Value of Seagate Technology Stock Plans

[0001193125-17-248796:notes:90]
Valuation and amortization method - The Company estimates the fair value of stock options, RSU and performance awards subject to an AEPS condition granted using the Black-Scholes-Merton valuation model and a single share award approach. This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period or the remaining service (vesting) period.

[0001193125-17-248796:notes:91]
Expected Term - Expected term represents the period that the Company's share-based awards are expected to be outstanding and was determined based on historical experience of similar awards, giving consideration to the contractual terms of the share-based awards, vesting schedules and expectations of future employee behavior as influenced by changes to the terms of its share-based awards.

[0001193125-17-248796:notes:92]
Expected Volatility - The Company uses a combination of the implied volatility of its traded options and historical volatility of its share price.

[0001193125-17-248796:notes:93]
Expected Dividend - The Black-Scholes-Merton valuation model calls for a single expected dividend yield as an input. The dividend yield is determined by dividing the expected per share dividend during the coming year by the grant date share price.  The expected dividend assumption is based on the Company's current expectations about its anticipated dividend policy. Also, because the expected dividend yield should reflect marketplace participants' expectations, the Company does not incorporate changes in dividends anticipated by management unless those changes have been communicated to or otherwise are anticipated by marketplace participants.

[0001193125-17-248796:notes:94]
Risk-Free Interest Rate - The Company bases the risk-free interest rate used in the Black-Scholes-Merton valuation model on the implied yield currently available on U.S. Treasury zero-coupon issues with an equivalent remaining term.  Where the expected term of the Company's share-based awards do not correspond with the terms for which interest rates are quoted, the Company performed a straight-line interpolation to determine the rate from the available term maturities.

[0001193125-17-248796:notes:95]
The fair value of the Company's shares related to options and RSU granted to employees, shares issued from the ESPP and  PSUs subject to TSR/ROIC or AEPS conditions for fiscal years 2017, 2016 and 2015 were estimated using the following assumptions:

[0001193125-17-248796:notes:96]
Share-based Compensation Expense

[0001193125-17-248796:notes:97]
The Company recorded $137 million, $120 million and $137 million of share-based compensation during fiscal years 2017, 2016 and 2015, respectively. Management has made an estimate of expected forfeitures and is recognizing compensation costs only for those equity awards expected to vest. When estimating forfeitures, the Company considers voluntary termination behavior as well as analysis of actual forfeited awards.

[0001193125-17-248796:notes:98]
Stock Option Activity

[0001193125-17-248796:notes:99]
The Company issues new ordinary shares upon exercise of stock options. The following is a summary of option activities:

[0001193125-17-248796:notes:100]
| Options |  | Number ofShares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualTerm |  | AggregateIntrinsicValue |
|  |  | (In millions) |  |  |  | (In years) |  | (Dollars in millions) |
| Outstanding at July 1, 2016 |  | 5.4 |  |  | $ | 34.91 |  |  | 4.6 |  | $14 |
| Granted |  | 2.3 |  |  | $ | 36.78 |  |  |  |  |  |
| Exercised |  | (1.6 | ) |  | $ | 19.87 |  |  |  |  |  |
| Forfeitures |  | (0.3 | ) |  | $ | 41.07 |  |  |  |  |  |
| Expirations |  | (0.1 | ) |  | $ | 47.66 |  |  |  |  |  |
| Outstanding at June 30, 2017 |  | 5.7 |  |  | $ | 39.24 |  |  | 5.0 |  | $22 |
| Vested and expected to vest at June 30, 2017 |  | 5.5 |  |  | $ | 39.28 |  |  | 5.0 |  | $21 |
| Exercisable at June 30, 2017 |  | 2.1 |  |  | $ | 39.82 |  |  | 3.6 |  | $12 |

[0001193125-17-248796:notes:101]
The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company's ordinary shares for the options that were in-the-money at June 30, 2017. During fiscal years 2017, 2016 and 2015, the aggregate intrinsic value of options exercised under the Company's stock option plans was $29 million, $44 million and $92 million, respectively, determined as of the date of option exercise. The aggregate fair value of options vested during fiscal years 2017, 2016 and 2015 were approximately $15 million, $18 million and $10 million, respectively.

[0001193125-17-248796:notes:102]
At June 30, 2017, the total compensation cost related to options granted to employees but not yet recognized was approximately $25 million, net of estimated forfeitures of approximately $1 million. This cost is being amortized on a straight-line basis over a weighted-average remaining term of approximately 2.5 years and will be adjusted for subsequent changes in estimated forfeitures.

[0001193125-17-248796:notes:103]
Nonvested Awards Activity

[0001193125-17-248796:notes:104]
The following is a summary of nonvested award activities which do not contain a performance condition:

[0001193125-17-248796:notes:105]
| Nonvested Awards |  | Number ofShares |  | Weighted-AverageGrant-DateFair Value |
|  |  | (In millions) |  |  |
| Nonvested at July 1, 2016 |  | 4.8 |  |  | $ | 39.95 |  |
| Granted |  | 3.1 |  |  | $ | 30.85 |  |
| Forfeitures |  | (0.7 | ) |  | $ | 39.72 |  |
| Vested |  | (2.0 | ) |  | $ | 37.02 |  |
| Nonvested at June 30, 2017 |  | 5.2 |  |  | $ | 35.75 |  |

[0001193125-17-248796:notes:106]
At June 30, 2017, the total compensation cost related to nonvested awards granted to employees but not yet recognized was approximately $135 million, net of estimated forfeitures of approximately $8 million.  This cost is being amortized on a straight-line basis over a weighted-average remaining term of 2.6 years and will be adjusted for subsequent changes in estimated forfeitures.  The aggregate fair value of nonvested awards vested during fiscal years 2017, 2016 and 2015 were approximately $73 million, $102 million and $156 million, respectively.

[0001193125-17-248796:notes:107]
Performance Awards

[0001193125-17-248796:notes:108]
The following is a summary of nonvested award activities which contain a performance condition:

[0001193125-17-248796:notes:109]
| Performance Awards |  | Number ofShares |  | Weighted-AverageGrant-DateFair Value |
|  |  | (In millions) |  |  |
| Performance units at July 1, 2016 |  | 1.4 |  |  | $ | 47.41 |  |
| Granted |  | 0.8 |  |  | $ | 32.16 |  |
| Forfeitures |  | (0.3 | ) |  | $ | 41.06 |  |
| Vested |  | (0.4 | ) |  | $ | 41.91 |  |
| Performance units at June 30, 2017 |  | 1.5 |  |  | $ | 41.88 |  |

[0001193125-17-248796:notes:110]
At June 30, 2017, the total compensation cost related to performance awards granted to employees but not yet recognized was approximately $36 million. This cost is being amortized on a straight-line basis over a weighted-average remaining term of 3.29 years.

[0001193125-17-248796:notes:111]
ESPP

[0001193125-17-248796:notes:112]
During fiscal years 2017, 2016 and 2015, the aggregate intrinsic value of shares purchased under the Company's ESPP was approximately $24 million, $12 million and $15 million, respectively.  At June 30, 2017, the total compensation cost related to options to purchase the Company's ordinary shares under the ESPP but not yet recognized was approximately $1.7 million. This cost will be amortized on a straight-line basis over a weighted-average period of approximately one month. During fiscal year 2017, the Company issued 2.0 million ordinary shares with a weighted-average purchase price of $26.68 per share.

[0001193125-17-248796:notes:113]
Tax-Deferred Savings Plan

[0001193125-17-248796:notes:114]
The Company has a tax-deferred savings plan, the Seagate 401(k) Plan (the "40l(k) plan"), for the benefit of qualified employees.  The 40l(k) plan is designed to provide employees with an accumulation of funds at retirement. Qualified employees may elect to make contributions to the 401(k) plan on a bi-weekly basis. Pursuant to the 401(k) plan, the Company matches 50% of employee contributions, up to 6% of compensation, subject to maximum annual contributions of $4,500 per participating employee. During fiscal years 2017, 2016 and 2015, the Company made matching contributions of $18 million, $19 million and $18 million, respectively.

[0001193125-17-248796:notes:115]
Deferred Compensation Plan

[0001193125-17-248796:notes:116]
On January 1, 2001, the Company adopted the SDCP for the benefit of eligible employees. This plan is designed to permit certain discretionary employer contributions, in excess of the tax limits applicable to the 401(k) plan and to permit employee deferrals in excess of certain tax limits.  During fiscal year 2014, the Company entered into a TRS in order to manage the equity market risks associated with the SDCP liabilities. See "Note 8. Derivative Financial Instruments" contained in this report for additional information about the TRS.


## us-gaap:EarningsPerShareTextBlock

[0001193125-17-248796:notes:117]
Earnings Per Share

[0001193125-17-248796:notes:118]
The following table sets forth the computation of basic and diluted net income per share:

[0001193125-17-248796:notes:119]
|  | Fiscal Years Ended |
| (In millions, except per share data) | June 30, 2017 |  | July 1, 2016 |  | July 3, 2015 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 772 |  |  | $ | 248 |  |  | $ | 1,742 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share | 296 |  |  | 299 |  |  | 324 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |
| Employee equity award plans | 3 |  |  | 3 |  |  | 7 |  |
| Total shares for purpose of calculating diluted net income per share | 299 |  |  | 302 |  |  | 331 |  |
| Net income per share |  |  |  |  |  |
| Basic | $ | 2.61 |  |  | $ | 0.83 |  |  | $ | 5.38 |  |
| Diluted | $ | 2.58 |  |  | $ | 0.82 |  |  | $ | 5.26 |  |

[0001193125-17-248796:notes:120]
The following potential shares were excluded from the computation of diluted net income per share as their effect would have been anti-dilutive:

[0001193125-17-248796:notes:121]
|  | Fiscal Years Ended |
| (In millions) | June 30, 2017 |  | July 1, 2016 |  | July 3, 2015 |
| Employee equity award plans | 1 |  |  | 3 |  |  | — |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001193125-17-248796:notes:122]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 592 |  |  | $ | 582 |  |  | $ | — |  |  | $ | 1,174 |  |
| Other current assets |  | 1 |  |  | 3 |  |  | — |  |  | 4 |  |
| Total assets |  | $ | 593 |  |  | $ | 585 |  |  | $ | — |  |  | $ | 1,178 |  |

[0001193125-17-248796:notes:123]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 230 |  |  | $ | — |  |  | $ | — |  |  | $ | 230 |  |
| Short-term investments |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Other current assets |  | 2 |  |  | 8 |  |  | — |  |  | 10 |  |
| Total assets |  | $ | 232 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 246 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |
| Total liabilities |  | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-17-248796:notes:124]
Fair Value

[0001193125-17-248796:notes:125]
Measurement of Fair Value

[0001193125-17-248796:notes:126]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact and it considers assumptions that market participants would use when pricing the asset or liability.

[0001193125-17-248796:notes:127]
Fair Value Hierarchy

[0001193125-17-248796:notes:128]
A fair value hierarchy is based on whether the market participant assumptions used in determining fair value are obtained from independent sources (observable inputs) or reflects the Company's own assumptions of market participant valuation (unobservable inputs). A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The three levels of inputs that may be used to measure fair value:

[0001193125-17-248796:notes:129]
Level 1 - Quoted prices in active markets that are unadjusted and accessible at the measurement date for identical, unrestricted assets or liabilities;

[0001193125-17-248796:notes:130]
Level 2 - Quoted prices for identical assets and liabilities in markets that are inactive; quoted prices for similar assets and liabilities in active markets or financial instruments for which significant inputs are observable, either directly or indirectly; or

[0001193125-17-248796:notes:131]
Level 3 - Prices or valuations that require inputs that are both unobservable and significant to the fair value measurement.

[0001193125-17-248796:notes:132]
The Company considers an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and views an inactive market as one in which there are few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate the Company's or the counterparty's non-performance risk is considered in determining the fair values of liabilities and assets, respectively.

[0001193125-17-248796:notes:133]
Items Measured at Fair Value on a Recurring Basis

[0001193125-17-248796:notes:134]
The following table presents the Company's assets and liabilities that are measured at fair value on a recurring basis, excluding accrued interest components, as of June 30, 2017:

[0001193125-17-248796:notes:135]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 592 |  |  | $ | — |  |  | $ | — |  |  | $ | 592 |  |
| Time deposits |  | — |  |  | 582 |  |  | — |  |  | 582 |  |
| Total cash equivalents and short-term investments |  | 592 |  |  | 582 |  |  | — |  |  | 1,174 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets |  | $ | 593 |  |  | $ | 585 |  |  | $ | — |  |  | $ | 1,178 |  |

[0001193125-17-248796:notes:136]
The Company reclassified demand deposits from certificates of deposit and money market funds to cash as of July 1, 2016 in the table below to conform to the current year's presentation. This reclassification did not result in any change to the cash and cash equivalents balance as reported in the Consolidated Balance Sheets and Statements of Cash Flows for all periods presented.

[0001193125-17-248796:notes:137]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of July 1, 2016:

[0001193125-17-248796:notes:138]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 230 |  |  | $ | — |  |  | $ | — |  |  | $ | 230 |  |
| Corporate bonds |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total cash equivalents and short-term investments |  | 230 |  |  | 6 |  |  | — |  |  | 236 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Certificates of deposit |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Derivative assets |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets |  | $ | 232 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 246 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |
| Total liabilities |  | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |

[0001193125-17-248796:notes:139]
The Company classifies items in Level 1 if the financial assets consist of securities for which quoted prices are available in an active market.

[0001193125-17-248796:notes:140]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair values of all of its cash equivalents and short-term investments. For the cash equivalents and short-term investments in the Company's portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry standard data providers or other third party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of June 30, 2017, has not found it necessary to make any adjustments to the prices obtained. The Company's derivative financial instruments are also classified within Level 2. The Company's derivative financial instruments consist of foreign currency forward exchange contracts and the TRS. The Company recognizes derivative financial instruments in its consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001193125-17-248796:notes:141]
As of June 30, 2017 and July 1, 2016, we had no Level 3 assets or liabilities measured at fair value on a recurring basis.

[0001193125-17-248796:notes:142]
Items Measured at Fair Value on a Non-Recurring Basis

[0001193125-17-248796:notes:143]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments primarily include cost basis investments representing those where the Company does not have the ability to exercise significant influence as well as equity method investments representing those where the Company does have the ability to exercise significant influence but does not have control. These investments are included in Other assets, net in the Consolidated Balance Sheets, and are periodically analyzed to determine whether or not there are indicators of impairment. The carrying value of the Company's strategic investments at June 30, 2017 and July 1, 2016 totaled $125 million and $113 million, respectively, and consisted primarily of privately held equity securities without a readily determinable fair value.

[0001193125-17-248796:notes:144]
During the fiscal years 2017, 2016 and 2015, the Company determined that certain of its equity investments accounted for under the cost method were other-than-temporarily impaired, and recognized charges of $25 million, $13 million and $7 million, respectively, in order to write down the carrying amount of the investments to its estimated fair value. Since there was no active market for the equity securities of the investee, the Company estimated fair value of the investee by analyzing the underlying cash flows and future prospects of the investee. These amounts were recorded in Other, net in the Consolidated Statements of Operations.

[0001193125-17-248796:notes:145]
In connection with the Company's manufacturing footprint reduction, the Company has $77 million held for sale assets included in Other current assets on the Consolidated Balance Sheet as of June 30, 2017. These assets primarily consisted of $37 million of land and building in Korea and $26 million of land and building in China, with the remainder of the balance comprised of property at other locations (collectively, the “properties”). The respective properties to be sold met the criteria to be classified as held for sale during the June 2017 and March 2017 quarters. Depreciation related to the properties ceased as of the date these were determined to be held for sale. During fiscal year 2017, the Company recorded impairment charges of $35 million in order to write down the carrying amount of such properties to their estimated fair values less costs to sell. The impairment charges were recorded in Operating expenses in the Consolidated Statement of Operations. The fair values were measured with the assistance of third-party valuation models which used inputs such as market comparable data for similar land sale transactions adjusted for difference to indicate value of the subject properties and the cost approach valuation techniques for buildings as part of the analysis. The fair value measurement was categorized as Level 3 as significant unobservable inputs were used in the valuation analysis.

[0001193125-17-248796:notes:146]
Other Fair Value Disclosures

[0001193125-17-248796:notes:147]
The Company's debt is carried at amortized cost. The fair value of the Company's debt is derived using the closing price of the same debt instruments as of the date of valuation, which takes into account the yield curve, interest rates and other observable inputs.  Accordingly, these fair value measurements are categorized as Level 2. The following table presents the fair value and amortized cost of the Company's debt in order of maturity:

[0001193125-17-248796:notes:148]
|  |  | June 30, 2017 |  | July 1, 2016 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 710 |  |  | $ | 726 |  |  | $ | 800 |  |  | $ | 804 |  |
| 7.00% Senior Notes due November 2021 |  | — |  |  | — |  |  | 158 |  |  | 164 |  |
| 4.250% Senior Notes due March 2022 |  | 748 |  |  | 765 |  |  | — |  |  | — |  |
| 4.75% Senior Notes due June 2023 |  | 951 |  |  | 987 |  |  | 990 |  |  | 857 |  |
| 4.875% Senior Notes due March 2024 |  | 497 |  |  | 511 |  |  | — |  |  | — |  |
| 4.75% Senior Notes due January 2025 |  | 975 |  |  | 984 |  |  | 995 |  |  | 795 |  |
| 4.875% Senior Notes due June 2027 |  | 695 |  |  | 698 |  |  | 698 |  |  | 514 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 488 |  |  | 489 |  |  | 357 |  |
|  |  | 5,065 |  |  | 5,159 |  |  | 4,130 |  |  | 3,491 |  |
| Less: debt issuance costs |  | (44 | ) |  | — |  |  | (39 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 5,021 |  |  | $ | 5,159 |  |  | $ | 4,091 |  |  | $ | 3,491 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001193125-17-248796:notes:149]
Foreign Currency Remeasurement and Translation.    The U.S. dollar is the functional currency for the majority of the Company's foreign operations. Monetary assets and liabilities denominated in foreign currencies are remeasured into the functional currency of the subsidiary at the balance sheet date. The gains and losses from the remeasurement of foreign currency denominated balances into the functional currency of the subsidiary are included in Other, net on the Company's Consolidated Statements of Operations. The Company had $4 million and $0 million in remeasurement losses in fiscal years 2017 and 2016, respectively, with $30 million in remeasurement gains in fiscal year 2015.

[0001193125-17-248796:notes:150]
The Company translates the assets and liabilities of its non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recognized in foreign currency translation included in Accumulated Other comprehensive loss, which is a component of shareholders’ equity. The Company’s subsidiaries that use the U.S. dollar as their functional currency remeasure monetary assets and liabilities at exchange rates in effect at the end of each period, and inventories, property, and nonmonetary assets and liabilities at historical rates. Gains and losses from these remeasurements were not significant and have been included in the Company’s results of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-17-248796:notes:151]
Goodwill and Other Intangible Assets

[0001193125-17-248796:notes:152]
Goodwill

[0001193125-17-248796:notes:153]
The changes in the carrying amount of goodwill are as follows:

[0001193125-17-248796:notes:154]
| (Dollars in millions) | Amount |
| As of July 3, 2015 | $ | 874 |  |
| Goodwill acquired | 364 |  |
| Goodwill disposed | (1 | ) |
| Foreign currency translation effect | — |  |
| As of July 1, 2016 | $ | 1,237 |  |
| Goodwill acquired | — |  |
| Goodwill disposed | — |  |
| Foreign currency translation effect | 1 |  |
| As of June 30, 2017 | $ | 1,238 |  |

[0001193125-17-248796:notes:155]
Other Intangible Assets

[0001193125-17-248796:notes:156]
Other intangible assets consist primarily of existing technology, customer relationships and trade names acquired in business combinations. During fiscal year 2017, the in-process research and development ("IPR&D") of $14 million was completed and reclassified to existing technology. Intangibles are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization is charged to Operating expenses in the Consolidated Statements of Operations.

[0001193125-17-248796:notes:157]
In fiscal years 2017, 2016 and 2015, amortization expense for other intangible assets was $168 million, $174 million and $152 million, respectively.

[0001193125-17-248796:notes:158]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of June 30, 2017, is set forth in the following table:

[0001193125-17-248796:notes:159]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 280 |  |  | $ | (112 | ) |  | $ | 168 |  |  | 3.6 years |
| Customer relationships |  | 487 |  |  | (395 | ) |  | 92 |  |  | 3.4 years |
| Trade name |  | 27 |  |  | (19 | ) |  | 8 |  |  | 2.1 years |
| Other intangible assets |  | 29 |  |  | (16 | ) |  | 13 |  |  | 2.6 years |
| Total amortizable other intangible assets |  | $ | 823 |  |  | $ | (542 | ) |  | $ | 281 |  |  | 3.4 years |

[0001193125-17-248796:notes:160]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of July 1, 2016 is set forth in the following table:

[0001193125-17-248796:notes:161]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 297 |  |  | $ | (79 | ) |  | $ | 218 |  |  | 4.1 years |
| Customer relationships |  | 510 |  |  | (328 | ) |  | 182 |  |  | 3.2 years |
| Trade name |  | 29 |  |  | (14 | ) |  | 15 |  |  | 2.6 years |
| Other intangible assets |  | 29 |  |  | (10 | ) |  | 19 |  |  | 3.2 years |
| Total amortizable other intangible assets |  | $ | 865 |  |  | $ | (431 | ) |  | $ | 434 |  |  | 3.6 years |

[0001193125-17-248796:notes:162]
The carrying value of IPR&D not subject to amortization was $14 million on July 1, 2016.

[0001193125-17-248796:notes:163]
As of June 30, 2017, expected amortization expense for other intangible assets for each of the next five years and thereafter is as follows:

[0001193125-17-248796:notes:164]
| (Dollars in millions) |  | Amount |
| 2018 |  | $ | 108 |  |
| 2019 |  | 71 |  |
| 2020 |  | 53 |  |
| 2021 |  | 25 |  |
| 2022 |  | 17 |  |
| Thereafter |  | 7 |  |
|  |  | $ | 281 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001193125-17-248796:notes:165]
Assessment of Goodwill and Other Long-lived Assets for Impairment.  The Company accounts for goodwill in accordance with Accounting Standards Codification ("ASC") Topic 350 ("ASC 350"), Intangibles - Goodwill and Other. During fiscal year 2017, the Company adopted Accounting Standard Update ("ASU") No. 2017-04, Intangibles - Goodwill and Other (ASC Topic 350) - Simplifying the Test for Goodwill Impairment. The Company performs a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. If it is determined in the qualitative assessment that the fair value of a reporting unit is more likely than not below its carrying amount, including goodwill, then the Company will perform a quantitative impairment test. The quantitative  goodwill impairment test is performed by comparing the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit's goodwill over its fair value is recognized as an impairment loss, limited to the total amount of goodwill allocated to that reporting unit.

[0001193125-17-248796:notes:166]
The Company tests other long-lived assets, including property, equipment and leasehold improvements and other intangible assets subject to amortization, for recoverability whenever events or changes in circumstances indicate that the carrying value of those assets may not be recoverable. The Company performs a recoverability test to assess the recoverability of an asset group. If the recoverability test indicates that the carrying value of the asset group is not recoverable, the Company will estimate the fair value of the asset group and the excess of the carrying value over the fair value is allocated pro rata to derive the adjusted carrying value of assets in the asset group. The adjusted carrying value of each asset in the asset group is not reduced below its fair value.

[0001193125-17-248796:notes:167]
The Company tests other intangible assets not subject to amortization whenever events occur or circumstances change, such as declining financial performance, deterioration in the environment in which the entity operates or deteriorating macroeconomic conditions that have a negative effect on future expected earnings and cash flows that could affect significant inputs used to determine the fair value of the indefinite-lived intangible asset.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-17-248796:notes:168]
Income Taxes

[0001193125-17-248796:notes:169]
The provision for (benefit from) income taxes consisted of the following:

[0001193125-17-248796:notes:170]
|  | Fiscal Years Ended |
| (Dollars in millions) | June 30, 2017 |  | July 1, 2016 |  | July 3, 2015 |
| Current income tax expense (benefit): |  |  |  |  |  |
| U.S. Federal | $ | — |  |  | $ | 1 |  |  | $ | — |  |
| U.S. State | 1 |  |  | 2 |  |  | 4 |  |
| Non-U.S. | 39 |  |  | 25 |  |  | 222 |  |
| Total Current | 40 |  |  | 28 |  |  | 226 |  |
| Deferred income tax expense (benefit): |  |  |  |  |  |
| U.S. Federal | (5 | ) |  | — |  |  | (6 | ) |
| U.S. State | — |  |  | — |  |  | (2 | ) |
| Non-U.S. | 8 |  |  | (2 | ) |  | 10 |  |
| Total Deferred | 3 |  |  | (2 | ) |  | 2 |  |
| Provision for (benefit from) income taxes | $ | 43 |  |  | $ | 26 |  |  | $ | 228 |  |

[0001193125-17-248796:notes:171]
Income (loss) before income taxes consisted of the following:

[0001193125-17-248796:notes:172]
|  | Fiscal Years Ended |
| (Dollars in millions) | June 30, 2017 |  | July 1, 2016 |  | July 3, 2015 |
| U.S. | $ | (22 | ) |  | $ | — |  |  | $ | 101 |  |
| Non-U.S. | 837 |  |  | 274 |  |  | 1,869 |  |
|  | $ | 815 |  |  | $ | 274 |  |  | $ | 1,970 |  |

[0001193125-17-248796:notes:173]
The Company recorded no excess tax benefits associated with stock option deductions in fiscal year 2017. The Company recorded $0.6 million and $2.0 million of excess tax benefits associated with stock option deductions in fiscal years 2016 and 2015, respectively.

[0001193125-17-248796:notes:174]
Deferred income taxes reflect the net tax effects of temporary differences between the carrying amounts of assets and liabilities for financial reporting purposes and the amounts used for income tax purposes. The significant components of the Company's deferred tax assets and liabilities were as follows:

[0001193125-17-248796:notes:175]
|  | Fiscal Years Ended |
| (Dollars in millions) | June 30, 2017 |  | July 1, 2016 |
| Deferred tax assets |  |  |  |
| Accrued warranty | $ | 85 |  |  | $ | 74 |  |
| Inventory carrying value adjustments | 43 |  |  | 32 |  |
| Receivable allowance | 19 |  |  | 11 |  |
| Accrued compensation and benefits | 99 |  |  | 85 |  |
| Depreciation | 109 |  |  | 173 |  |
| Restructuring accruals | (1 | ) |  | 14 |  |
| Other accruals and deferred items | 51 |  |  | 50 |  |
| Net operating losses and tax credit carry-forwards | 1,224 |  |  | 1,252 |  |
| Other assets | 11 |  |  | 2 |  |
| Total deferred tax assets | 1,640 |  |  | 1,693 |  |
| Valuation allowance | (966 | ) |  | (984 | ) |
| Net deferred tax assets | 674 |  |  | 709 |  |
| Deferred tax liabilities |  |  |  |
| Unremitted earnings of certain non-U.S. entities | (7 | ) |  | (11 | ) |
| Acquisition-related items | (65 | ) |  | (92 | ) |
| Total deferred tax liabilities | (72 | ) |  | (103 | ) |
| Deferred taxes on intra-entity transactions | 2 |  |  | — |  |
| Total net deferred tax assets | $ | 604 |  |  | $ | 606 |  |
| As Reported on the Balance Sheet |  |  |  |  |  |
| Deferred income taxes | $ | 609 |  |  | $ | 616 |  |
| Other non-current liabilities | (5 | ) |  | (10 | ) |
| Total net deferred income taxes | $ | 604 |  |  | $ | 606 |  |

[0001193125-17-248796:notes:176]
The deferred tax asset valuation allowance decreased by $18 million in fiscal year 2017 and increased by $55 million and $41 million in fiscal years 2016 and 2015, respectively.

[0001193125-17-248796:notes:177]
At June 30, 2017, the Company recorded $602 million of net deferred tax assets, excluding $2 million of deferred taxes on intra-entity transactions. The realization of most of these deferred tax assets is primarily dependent on the Company's ability to generate sufficient U.S. and certain non-U.S. taxable income in future periods. Although realization is not assured, the Company's management believes it is more likely than not that these deferred tax assets will be realized. The amount of deferred tax assets considered realizable, however, may increase or decrease in subsequent periods when the Company reevaluates the underlying basis for its estimates of future U.S. and certain non-U.S. taxable income.

[0001193125-17-248796:notes:178]
At June 30, 2017, the Company had U.S. federal, state and non-U.S. tax net operating loss carryforwards of approximately $3.4 billion, $2.0 billion and $173 million, respectively, which will expire at various dates beginning in fiscal year 2018, if not utilized. Net operating loss carryforwards of approximately $68 million are scheduled to expire in fiscal year 2018. At June 30, 2017, the Company had U.S. federal and state tax credit carryforwards of $444 million and $105 million, respectively, which will expire at various dates beginning in fiscal year 2018, if not utilized.

[0001193125-17-248796:notes:179]
As of June 30, 2017, approximately $560 million and $101 million of the Company's total U.S. net operating loss and tax credit carryforwards, respectively, are subject to annual limitations ranging from $1 million to $45 million pursuant to U.S. tax law.

[0001193125-17-248796:notes:180]
For purposes of the reconciliation between the provision for (benefit from) income taxes at the statutory rate and the effective tax rate, the Irish statutory rate of 25% was applied as follows:

[0001193125-17-248796:notes:181]
|  | Fiscal Years Ended |
| (Dollars in millions) | June 30, 2017 |  | July 1, 2016 |  | July 3, 2015 |
| Provision at statutory rate | $ | 204 |  |  | $ | 69 |  |  | $ | 493 |  |
| Net U.S. federal and state income taxes | 1 |  |  | 3 |  |  | 7 |  |
| Permanent differences | 19 |  |  | 10 |  |  | 2 |  |
| Valuation allowance | (11 | ) |  | (1 | ) |  | 15 |  |
| Non-U.S. losses with no tax benefits | 17 |  |  | 1 |  |  | 2 |  |
| Non-U.S. earnings taxed at other than statutory rate | (186 | ) |  | (37 | ) |  | (463 | ) |
| Audit assessment | — |  |  | — |  |  | 173 |  |
| Reversal of previously recorded taxes | (4 | ) |  | (19 | ) |  | (5 | ) |
| Other individually immaterial items | 3 |  |  | — |  |  | 4 |  |
| Provision for (benefit from) income taxes | $ | 43 |  |  | $ | 26 |  |  | $ | 228 |  |

[0001193125-17-248796:notes:182]
A substantial portion of the Company's operations in Malaysia, Singapore and Thailand operate under various tax holiday programs, which expire in whole or in part at various dates through 2024. Certain tax holidays may be extended if specific conditions are met. The net impact of these tax holiday programs was to increase the Company's net income by approximately $163 million in fiscal year 2017 ($0.54 per share, diluted), to increase the Company's net income by approximately $67 million in fiscal year 2016 ($0.22 per share, diluted), and to increase the Company's net income by approximately $349 million in fiscal year 2015 ($1.05 per share, diluted).

[0001193125-17-248796:notes:183]
The Company consists of an Irish tax resident parent holding company with various U.S. and non-U.S. subsidiaries that operate in multiple non-Irish taxing jurisdictions. The amount of temporary differences (including undistributed earnings) related to outside basis differences in the stock of non-Irish resident subsidiaries considered indefinitely reinvested outside of Ireland for which Irish income taxes have not been provided as of June 30, 2017, was approximately $1.5 billion. If such amount were remitted to Ireland as a dividend, it is likely that tax at 25%, or approximately $375 million would result.

[0001193125-17-248796:notes:184]
As of June 30, 2017 and July 1, 2016, the Company had approximately $74 million and $76 million, respectively, of unrecognized tax benefits excluding interest and penalties. The amount of unrecognized tax benefits that, if recognized, would impact the effective tax rate are $74 million and $76 million as of June 30, 2017 and July 1, 2016, respectively, subject to certain future valuation allowance offsets.

[0001193125-17-248796:notes:185]
The following table summarizes the activity related to the Company's gross unrecognized tax benefits:

[0001193125-17-248796:notes:186]
|  | Fiscal Years Ended |
| (Dollars in millions) | June 30, 2017 |  | July 1, 2016 |  | July 3, 2015 |
| Balance of unrecognized tax benefits at the beginning of the year | $ | 76 |  |  | $ | 89 |  |  | $ | 120 |  |
| Gross increase for tax positions of prior years | 2 |  |  | 12 |  |  | 12 |  |
| Gross decrease for tax positions of prior years | (7 | ) |  | (8 | ) |  | (4 | ) |
| Gross increase for tax positions of current year | 16 |  |  | 11 |  |  | 9 |  |
| Gross decrease for tax positions of current year | — |  |  | — |  |  | — |  |
| Settlements | — |  |  | — |  |  | (45 | ) |
| Lapse of statutes of limitation | (13 | ) |  | (27 | ) |  | (3 | ) |
| Non-U.S. exchange (gain)/loss | — |  |  | (1 | ) |  | — |  |
| Balance of unrecognized tax benefits at the end of the year | $ | 74 |  |  | $ | 76 |  |  | $ | 89 |  |

[0001193125-17-248796:notes:187]
It is the Company's policy to include interest and penalties related to unrecognized tax benefits in the provision for income taxes on the Consolidated Statements of Operations. During fiscal year 2017, the Company recognized net income tax benefit for interest and penalties of $1 million, as compared to net income tax benefit of $8 million during fiscal year 2016, and  income tax expense of $26 million during fiscal year 2015. As of June 30, 2017, the Company had $4 million of accrued interest and penalties related to unrecognized tax benefits compared to $6 million in fiscal year 2016.

[0001193125-17-248796:notes:188]
During the 12 months beginning July 1, 2017, the Company expects that its unrecognized tax benefits could be reduced by approximately $14 million as a result of the expiration of certain statutes of limitation.

[0001193125-17-248796:notes:189]
The Company is required to file U.S. federal, U.S. state and non-U.S. income tax returns. The Company is no longer subject to examination of its U.S. federal income tax returns for years prior to fiscal year 2014. With respect to U.S. state and non-U.S. income tax returns, the Company is generally no longer subject to tax examination for years ending prior to fiscal year 2006.


## us-gaap:IncomeTaxPolicyTextBlock

[0001193125-17-248796:notes:190]
Accounting for Income Taxes. The Company accounts for income taxes pursuant to ASC Topic 740 ("ASC 740"), Income Taxes.  In applying ASC 740, the Company makes certain estimates and judgments in determining income tax expense for financial statement purposes.  These estimates and judgments occur in the calculation of tax credits, recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for income tax and financial statement purposes, as well as tax liabilities associated with uncertain tax positions. The calculation of tax liabilities involves uncertainties in the application of complex tax rules and the potential for future adjustment of the Company’s uncertain tax positions by the Internal Revenue Service or other tax jurisdictions. If estimates of these tax liabilities are greater or less than actual results, an additional tax benefit or provision will result. The deferred tax assets the Company records each period depend primarily on the Company’s ability to generate future taxable income in the United States and certain non-U.S. jurisdictions. Each period, the Company evaluates the need for a valuation allowance for its deferred tax assets and, if necessary, adjusts the valuation allowance so that net deferred tax assets are recorded only to the extent the Company concludes it is more likely than not that these deferred tax assets will be realized. If the Company’s outlook for future taxable income changes significantly, the Company’s assessment of the need for, and the amount of, a valuation allowance may also change.


## us-gaap:InventoryPolicyTextBlock

[0001193125-17-248796:notes:191]
Inventory.    Inventories are valued at the lower of cost (using the first-in, first-out method) or market. Market value is based upon an estimated average selling price reduced by estimated cost of completion and disposal.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-17-248796:notes:192]
The fair value and amortized cost of the Company's investments classified as available-for-sale at June 30, 2017 by remaining contractual maturity was as follows:

[0001193125-17-248796:notes:193]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 1,178 |  |  | $ | 1,178 |  |
| Due in 1 to 5 years |  | — |  |  | — |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | — |  |  | — |  |
| Total |  | $ | 1,178 |  |  | $ | 1,178 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001193125-17-248796:notes:194]
Legal, Environmental and Other Contingencies

[0001193125-17-248796:notes:195]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001193125-17-248796:notes:196]
Intellectual Property Litigation

[0001193125-17-248796:notes:197]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al.-On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “'635 patent”) and U.S. Patent No. 5,638,267 (the “'267 patent”), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe U.S. Patent No. 6,314,473 (the “'473 patent”). The district court ruled in 2010 that the '267 patent was out of the case.

[0001193125-17-248796:notes:198]
On August 16, 2011, the district court granted in part and denied in part the Company’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the '473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the '473 patent; 2) affirmed the district court’s summary judgment of non-infringement by

[0001193125-17-248796:notes:199]
Compaq’s products as to claims 1, 3, and 5 of the '473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the '473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the '473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-17-248796:notes:200]
Alexander Shukh v. Seagate Technology-On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination and wrongful failure to name him as an inventor on certain Seagate patents. On March 31, 2014, the district court granted Seagate’s summary judgment motion. Mr. Shukh filed a notice of appeal on April 7, 2014. On October 2, 2015, the U.S. Court of Appeals for the Federal Circuit vacated and remanded the district court’s grant of summary judgment on Mr. Shukh’s claim for correction of inventorship and affirmed the district court’s grant of summary judgment as to all other claims. On October 29, 2015, Mr. Shukh filed a petition for rehearing en banc with the court of appeals; the petition was denied on December 17, 2015. On March 16, 2016, Shukh filed a petition for writ of certiorari to the U.S. Supreme Court; the petition was denied on June 27, 2016. On March 30, 2017, the parties entered into a confidential settlement to resolve this matter.  This settlement did not have a material impact on the Company’s consolidated financial statements.

[0001193125-17-248796:notes:201]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation (“Enova”) filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995 (the “'995 patent”), “Cryptographic Device,” and U.S. Patent No. 7,900,057 (the “'057 patent”), “Cryptographic Serial ATA Apparatus and Method.” The Company believes the claims are without merit and intends to vigorously defend this case. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the '995 and '057 patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the '995 patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the '057 patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the '057 patent are held unpatentable. Enova has appealed PTAB’s decisions on the '995 patent and the '057 patent to the U.S. Court of Appeals for the Federal Circuit. Oral argument for the appeal from PTAB’s decision on the '995 patent was held on March 13, 2017, at the court of appeals. On March 20, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the '995 patent.  Oral argument before the court of appeals for the appeal from PTAB’s decision on the '057 patent is scheduled for August 11, 2017. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-17-248796:notes:202]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al.-On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-17-248796:notes:203]
Environmental Matters

[0001193125-17-248796:notes:204]
The Company's operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company's operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001193125-17-248796:notes:205]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001193125-17-248796:notes:206]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the "Superfund" law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001193125-17-248796:notes:207]
While the Company's ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001193125-17-248796:notes:208]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union ("EU") enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern ("SVHCs") in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.

[0001193125-17-248796:notes:209]
Other Matters

[0001193125-17-248796:notes:210]
The Company is involved in a number of other judicial and administrative proceedings incidental to its business, and the Company may be involved in various legal proceedings arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-17-248796:notes:211]
In May 2014, August 2015, April 2016, May 2016 and December 2016, the Financial Accounting Standards Board ("FASB") issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, ASU 2016-12 (ASC Topic 606) Revenue from Contracts with Customers, Narrow-Scope Improvements and Practical Expedients, and ASU 2016-20 (ASC Topic 606) Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company is required to adopt the guidance in the first quarter of fiscal 2019. This standard may be applied retrospectively to all prior periods presented, or retrospectively with a cumulative adjustment to retained earnings in the year of adoption ("modified retrospective transition approach"). Based on its assessment, the Company plans to adopt the new revenue standard in the first quarter of fiscal 2019, utilizing the modified retrospective method of transition.

[0001193125-17-248796:notes:212]
While management has not yet completed its assessment of the impact of adopting this new standard on the Company's consolidated financial statements, the Company expects the adoption of the new standard will result in the recognition of revenues generally upon shipment (sell-in basis) for sales of products to certain direct retail customers and customers in certain indirect retail channels which are currently being recognized on a sell-through basis. Accordingly, the Company will need to estimate variable consideration (e.g. rebates) related to customer incentives on these arrangements. These changes are not expected to have a material impact on the Company's consolidated financial statements.

[0001193125-17-248796:notes:213]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. The Company is required and intends to adopt the guidance in the first quarter of fiscal 2018. The Company does not expect the adoption of this ASU to have a material impact on its consolidated financial statements.

[0001193125-17-248796:notes:214]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments - Overall Recognition and Measurement of Financial Assets and Financial Liabilities. The amendments in this ASU require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted for only certain portions of the ASU. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

[0001193125-17-248796:notes:215]
In February 2016, the FASB issued ASU 2016-02 (ASC Topic 842), Leases. The ASU amends a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The Company is required to adopt the guidance in the first quarter of fiscal 2020. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

[0001193125-17-248796:notes:216]
In March 2016, the FASB issued ASU 2016-09 (ASC Topic 718), Stock Compensation - Improvements to Employee Share-Based Payment Accounting. The amendments in this ASU are intended to simplify several areas of accounting for share-based compensation arrangements, including the income tax consequences, classification on the consolidated statement of cash flows and treatment of forfeitures. The Company is required and intends to adopt the guidance in the first quarter of fiscal 2018. Upon adoption, the Company anticipates that this ASU will result in an increase in deferred tax assets relating to net operating losses of approximately $0.5 billion, offset by an equivalent increase in the valuation allowance. This guidance, however, is not expected to have a material impact on the Company's Consolidated balance sheets, statements of operations or cash flows.

[0001193125-17-248796:notes:217]
In October 2016, the FASB issued ASU 2016-16 (ASC Topic 740), Income Taxes: Intra-Entity Transfers of Assets Other Than Inventory. The amendments in this ASU require the recognition of the income tax consequences for intra-entity transfers of assets other than inventory when the transfer occurs. Under current GAAP, current and deferred income taxes for intra-entity asset transfers are not recognized until the asset has been sold to an outside party. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

[0001193125-17-248796:notes:218]
In January 2017, the FASB issued ASU 2017-01 (ASC Topic 805), Business Combination: Clarifying the Definition of a Business. The amendments in this ASU change the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

[0001193125-17-248796:notes:219]
In May 2017, the FASB issued ASU 2017-09 (ASC Topic 718), Stock Compensation: Scope of Modification Accounting. The amendments in this ASU provide guidance about which changes to the terms or conditions of a share-based payment  award require an entity to apply modification accounting. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

[0001193125-17-248796:notes:220]
Recently Adopted Accounting Pronouncements

[0001193125-17-248796:notes:221]
In April 2015 and August 2015, the FASB issued ASU 2015-03 (ASC Subtopic 835-30), Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs and ASU 2015-15 (ASC Subtopic 835-30), Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements- Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting, respectively. The ASUs require that debt issuance costs related to a recognized debt liability, with the exception of those related to line-of-credit arrangements, be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability.  ASU 2015-03 became effective and was adopted by the Company in the September 2016 quarter on a retrospective basis. The adoption of this guidance resulted in a reduction to Other assets, net and Long-term debt by $39 million, within the Consolidated Balance Sheet as of July 1, 2016. ASU 2015-15 became effective and was adopted by the Company in the September 2016 quarter on a retrospective basis with no material impact on the Company’s consolidated financial statements and disclosures.

[0001193125-17-248796:notes:222]
In September 2015, the FASB issued ASU 2015-16 (ASC Topic 805), Business Combinations Simplifying the Accounting for Measurement-Period Adjustments. The amendments in this update require that an acquirer recognize measurement period adjustments in the period in which the adjustments are determined. The income effects of such measurement period adjustments are to be recorded in the same period’s financial statements but calculated as if the accounting had been completed as of the acquisition date. The impact of measurement period adjustments to earnings that relate to prior period financial statements are to be presented separately on the income statement or disclosed by line item. The amendments in this update are for fiscal years, including interim periods within those fiscal years, beginning after December 15, 2015. This ASU became effective and was adopted by the Company in the September 2016 quarter on a prospective basis with no material impact on the Company’s consolidated financial statements and disclosures.

[0001193125-17-248796:notes:223]
In November 2016, the FASB issued ASU 2016-18 (ASC Topic 230), Statement of Cash Flows: Restricted Cash. The amendments in this update provide guidance on the classification and presentation of changes in restricted cash on the statement of cash flows. The ASU requires amounts generally described as restricted cash and restricted cash equivalents to be included with cash and cash equivalents when reconciling the total beginning and ending balances for the periods presented on the statement of cash flows. The amendments in this update are for fiscal years, including interim periods within those fiscal years, beginning after December 15, 2017. The Company elected to adopt this ASU in the December 2016 quarter on a retrospective basis with no material impact on the Company's consolidated financial statements and disclosures. The Company classifies restricted cash within Other current assets in the consolidated balance sheets.

[0001193125-17-248796:notes:224]
In January 2017, the FASB issued ASU 2017-04 (ASC Topic 350), Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment. The amendments in this ASU eliminate Step 2 from the goodwill impairment test, which requires entities to calculate the implied fair value of goodwill to measure a goodwill impairment charge. Instead, entities will record an impairment charge based on the excess of a reporting unit's carrying amount over its fair value, determined in step 1. The Company elected to adopt this ASU in the March 2017 quarter on a prospective basis with no material impact on the Company's consolidated financial statements and disclosures.

[0001193125-17-248796:notes:225]
In August 2016, the FASB issued ASU 2016-15 (ASC Topic 230), Statement of Cash Flows - Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU are intended to clarify how certain cash receipts and cash payment are presented and classified in the statement of cash flows. The Company elected to adopt this ASU in the June 2017 quarter on a retrospective basis. The adoption of this guidance had no material impact on the Company's consolidated financial statements and disclosures.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001193125-17-248796:notes:226]
Basis of Presentation and Summary of Significant Accounting Policies

[0001193125-17-248796:notes:227]
Organization

[0001193125-17-248796:notes:228]
Seagate Technology plc (the "Company") is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives ("SSD") and their related controllers, solid state hybrid drives ("SSHD") and storage subsystems.

[0001193125-17-248796:notes:229]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and most SSDs use NAND-based flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed data.

[0001193125-17-248796:notes:230]
The Company's products are designed for mission critical and nearline applications in enterprise servers and storage systems; client compute applications, where its products are designed primarily for desktop and mobile computing; and client non-compute applications, where its products are designed for a wide variety of end user devices such as portable external storage systems, surveillance systems, network-attached storage ("NAS"), digital video recorders ("DVRs") and gaming consoles.

[0001193125-17-248796:notes:231]
The Company's cloud systems and solutions extend innovation from the device into the information infrastructure, onsite and in the cloud. Its portfolio includes modular original equipment manufacturers ("OEM") storage systems and scale-out storage servers.

[0001193125-17-248796:notes:232]
Basis of Presentation and Consolidation

[0001193125-17-248796:notes:233]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Accordingly, fiscal years 2017 and 2016 were comprised of 52 weeks and ended on June 30, 2017 and July 1, 2016, respectively. Fiscal year 2015 was comprised of 53 weeks and ended on July 3, 2015. All references to years in these Notes to Consolidated Financial Statements represent fiscal years unless otherwise noted. Fiscal year 2018 will be 52 weeks and will end on June 29, 2018.

[0001193125-17-248796:notes:234]
Summary of Significant Accounting Policies

[0001193125-17-248796:notes:235]
Allowances for Doubtful Accounts.    The Company maintains an allowance for uncollectible accounts receivable based upon expected collectability. This reserve is established based upon historical trends, global macroeconomic conditions and an analysis of specific exposures. The provision for doubtful accounts is recorded as a charge to Marketing and administrative expense on the Company's Consolidated Statements of Operations.

[0001193125-17-248796:notes:236]
Property, Equipment and Leasehold Improvements.    Property, equipment and leasehold improvements are stated at cost. Equipment and buildings are depreciated using the straight-line method over the estimated useful lives of the assets. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated life of the asset or the remaining term of the lease. The costs of additions and substantial improvements to property, equipment and leasehold improvements, which extend the economic life of the underlying assets, are capitalized. The cost of maintenance and repairs to property, equipment and leasehold improvements are expensed as incurred.

[0001193125-17-248796:notes:237]
Derivative Financial Instruments.    The Company applies the requirements of ASC Topic 815 ("ASC 815"), Derivatives and Hedging. ASC 815 requires that all derivatives be recorded on the balance sheet at fair value and establishes criteria for designation and effectiveness of hedging relationships.

[0001193125-17-248796:notes:238]
Establishment of Warranty Accruals.    The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company's warranty provision considers estimated product failure rates and trends (including the timing of product returns during the warranty periods), and estimated repair or replacement costs related to product quality issues, if any. The Company also exercises judgment in estimating its ability to sell certain repaired products. Should actual experience in any future period differ significantly from its estimates, the Company's future results of operations could be materially affected.

[0001193125-17-248796:notes:239]
Revenue Recognition, Sales Returns and Allowances, and Sales Incentive Programs.    The Company's revenue recognition policy complies with ASC Topic 605 ("ASC 605"), Revenue Recognition. Revenue from sales of products, including sales to distribution customers, is generally recognized when title and risk of loss has passed to the buyer, which typically occurs upon shipment from the Company or third party's warehouse facilities, persuasive evidence of an arrangement exists, including a fixed or determinable price to the buyer, and when collectability is reasonably assured. Revenue from sales of products to certain direct retail customers and to customers in certain indirect retail channels is recognized on a sell-through basis.

[0001193125-17-248796:notes:240]
The Company records estimated product returns at the time of shipment. The Company also estimates reductions to revenue for sales incentive programs, such as price protection, and volume incentives, and records such reductions when revenue is recorded. The Company establishes certain distributor and OEM sales programs aimed at increasing customer demand. For OEM sales, rebates are typically based on an OEM customer's volume of purchases from Seagate or other agreed upon rebate programs. For the distribution channel, these programs typically involve rebates related to a distributor's level of sales, order size, advertising or point of sale activity and price protection adjustments. The Company provides for these obligations at the time that revenue is recorded based on estimated requirements. Marketing development programs are recorded as a reduction to revenue.

[0001193125-17-248796:notes:241]
Shipping and Handling.    The Company includes costs related to shipping and handling in Cost of revenue in the Consolidated Statements of Operations for all periods presented.

[0001193125-17-248796:notes:242]
Share-Based Compensation.    The Company accounts for share-based compensation under the provisions of ASC Topic 718 (ASC 718), Compensation-Stock Compensation. The Company has elected to apply the with-and-without method to assess the realization of related excess tax benefits.

[0001193125-17-248796:notes:243]
Concentrations

[0001193125-17-248796:notes:244]
Concentration of Credit Risk.    The Company's customer base for disk drive products is concentrated with a small number of OEMs and distributors. The Company does not generally require collateral or other security to support accounts receivable. To reduce credit risk, the Company performs ongoing credit evaluations on its customers' financial condition. The Company establishes an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information. Dell Inc. accounted for more than 10% of the Company's accounts receivable as of June 30, 2017.

[0001193125-17-248796:notes:245]
Financial instruments that potentially subject the Company to concentrations of credit risk consist primarily of cash equivalents, short-term investments and foreign currency forward exchange contracts. The Company further mitigates concentrations of credit risk in its investments through diversification, by limiting its investments in the debt securities of a single issuer, and investing in highly-rated securities.

[0001193125-17-248796:notes:246]
In entering into foreign currency forward exchange contracts, the Company assumes the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and the Company has not incurred and does not expect any losses as a result of counterparty defaults.

[0001193125-17-248796:notes:247]
Supplier Concentration.    Certain of the raw materials, components and equipment used by the Company in the manufacture of its products are available from single-sourced vendors. Shortages could occur in these essential materials and components due to an interruption of supply or increased demand in the industry. If the Company were unable to procure certain materials, components or equipment at acceptable prices, it would be required to reduce its manufacturing operations, which could have a material adverse effect on its results of operations. In addition, the Company may make prepayments to certain suppliers or enter into minimum volume commitment agreements. Should these suppliers be unable to deliver on their obligations or experience financial difficulty, the Company may not be able to recover these prepayments.

[0001193125-17-248796:notes:248]
Recently Issued Accounting Pronouncements


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-17-248796:notes:249]
Guarantees

[0001193125-17-248796:notes:250]
Indemnifications to Officers and Directors

[0001193125-17-248796:notes:251]
On May 4, 2009,  Seagate Technology, an exempted company incorporated with limited liability under the laws of the Cayman Islands (“Seagate-Cayman”), then the parent company, entered into a new form of indemnification agreement (the “Revised Indemnification Agreement”) with its officers and directors of Seagate-Cayman and its subsidiaries (each, an “Indemnitee”). The Revised Indemnification Agreement provides indemnification in addition to any of Indemnitee's indemnification rights under Seagate-Cayman's Articles of Association, applicable law or otherwise, and indemnifies an Indemnitee for certain expenses (including attorneys' fees), judgments, fines and settlement amounts actually and reasonably incurred by him or her in any action or proceeding, including any action by or in the right of Seagate-Cayman or any of its subsidiaries, arising out of his or her service as a director, officer, employee or agent of Seagate-Cayman or any of its subsidiaries or of any other entity to which he or she provides services at Seagate-Cayman's request. However, an Indemnitee shall not be indemnified under the Revised Indemnification Agreement for (i) any fraud or dishonesty in the performance of Indemnitee's duty to Seagate-Cayman or the applicable subsidiary of Seagate-Cayman or (ii) Indemnitee's conscious, intentional or willful failure to act honestly, lawfully and in good faith with a view to the best interests of Seagate-Cayman or the applicable subsidiary of Seagate-Cayman. In addition, the Revised Indemnification Agreement provides that Seagate-Cayman will advance expenses incurred by an Indemnitee in connection with enforcement of the Revised Indemnification Agreement or with the investigation, settlement or appeal of any action or proceeding against him or her as to which he or she could be indemnified.

[0001193125-17-248796:notes:252]
On July 3, 2010, pursuant to a corporate reorganization, the common shareholders of Seagate-Cayman became ordinary shareholders of Seagate Technology plc (the "Company") and Seagate-Cayman became a wholly owned subsidiary of the Company, as described more fully in the Current Report on Form 8-K filed by the Company on July 6, 2010 (the “Redomestication”). On July 27, 2010, in connection with the Redomestication, the Company, as sole shareholder of Seagate-Cayman, approved a form of deed of indemnity (the “Deed of Indemnity”), which provides for the indemnification by Seagate-Cayman of any director, officer, employee or agent of the Company, Seagate-Cayman or any subsidiary of the Company (each, a “Deed Indemnitee”), in addition to any of a Deed Indemnitee's indemnification rights under the Company's Articles of Association, applicable law or otherwise, with a similar scope to the Revised Indemnification Agreement. Seagate-Cayman entered into the Deed of Indemnity with certain Deed Indemnitees effective as of July 3, 2010 and continues to enter into the Deed of Indemnity with additional Deed Indemnitees from time to time.

[0001193125-17-248796:notes:253]
The nature of these indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay on behalf of its officers and directors. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the accompanying consolidated financial statements with respect to these indemnification obligations.

[0001193125-17-248796:notes:254]
Intellectual Property Indemnification Obligations

[0001193125-17-248796:notes:255]
The Company has entered into agreements with customers and suppliers that include limited intellectual property indemnification obligations that are customary in the industry. These guarantees generally require the Company to compensate the other party for certain damages and costs incurred as a result of third party intellectual property claims arising from these transactions. The nature of the intellectual property indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay to its customers and suppliers. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the accompanying consolidated financial statements with respect to these indemnification obligations.

[0001193125-17-248796:notes:256]
Product Warranty

[0001193125-17-248796:notes:257]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation.  Changes in the Company's product warranty liability during the fiscal years ended June 30, 2017, July 1, 2016 and July 3, 2015 were as follows:

[0001193125-17-248796:notes:258]
|  |  | Fiscal Years Ended |
| (In millions) |  | June 30, 2017 |  | July 1, 2016 |  | July 3, 2015 |
| Balance, beginning of period |  | $ | 206 |  |  | $ | 248 |  |  | $ | 273 |  |
| Warranties issued |  | 131 |  |  | 125 |  |  | 147 |  |
| Repairs and replacements |  | (114 | ) |  | (152 | ) |  | (187 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | 10 |  |  | (17 | ) |  | 7 |  |
| Warranty liability assumed from acquisitions |  | — |  |  | 2 |  |  | 8 |  |
| Balance, end of period |  | $ | 233 |  |  | $ | 206 |  |  | $ | 248 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-17-248796:notes:259]
The components of property, equipment and leasehold improvements, net were as follows:

[0001193125-17-248796:notes:260]
| (Dollars in millions) |  | Useful Lifein Years |  | June 30, 2017 |  | July 1, 2016 |
| Land and land improvements |  |  |  | $ | 54 |  |  | $ | 69 |  |
| Equipment |  | 3 – 5 |  | 7,536 |  |  | 7,681 |  |
| Buildings and leasehold improvements |  | Up to 30 |  | 1,899 |  |  | 1,900 |  |
| Construction in progress |  |  |  | 144 |  |  | 234 |  |
|  |  |  |  | 9,633 |  |  | 9,884 |  |
| Less: accumulated depreciation and amortization |  |  |  | (7,758 | ) |  | (7,724 | ) |
|  |  |  |  | $ | 1,875 |  |  | $ | 2,160 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-17-248796:notes:261]
Restructuring and Exit Costs

[0001193125-17-248796:notes:262]
During fiscal years 2017, 2016 and 2015, the Company recorded restructuring charges of $178 million, $175 million and $32 million, respectively, comprised primarily of charges related to workforce reduction costs and facility exit costs associated with restructuring of its workforce during each fiscal year. The Company's significant restructuring plans are described below.  All restructuring charges are reported in Restructuring and other, net on the Consolidated Statements of Operations.

[0001193125-17-248796:notes:263]
March 2017 Plan - On March 9, 2017, the Company committed to an additional restructuring plan (the “March 2017 Plan”) in connection with the continued consolidation of its global footprint. The Company closed its design center in Korea, resulted in the reduction of the Company’s headcount by approximately 300 employees. The March 2017 Plan was largely completed by the end of fiscal year 2017. In addition, the Company committed to sell its land and building in Korea as part of the plan. This land and building met the criteria to be classified as assets held for sale and were included in Other current assets on the Consolidated Balance Sheet as of  June 30, 2017. The Company recorded an impairment charge of $26 million as part of the fair value measurement to reduce the carrying amount of its land and building to its estimated fair value less costs to sell, which is included in Operating expenses on the Consolidated Statements of Operations.

[0001193125-17-248796:notes:264]
July 2016 Plan - On July 11, 2016, the Company committed to a restructuring plan (the “July 2016 Plan”) for continued consolidation of its global footprint across Asia, EMEA and the Americas. The July 2016 Plan included reducing worldwide headcount by approximately 6,500 employees. The July 2016 Plan, was largely completed by the end of fiscal year 2017.

[0001193125-17-248796:notes:265]
June 2016 Plan - On June 27, 2016, the Company committed to a restructuring plan (the “June 2016 Plan”) as part of the Company's efforts to reduce its cost structure to align with the then current macroeconomic conditions. The June 2016 Plan included reducing worldwide headcount by approximately 1,600 employees. The June 2016 Plan was largely completed by the fiscal quarter ended December 30, 2016 with no material future costs expected to be incurred.

[0001193125-17-248796:notes:266]
The following table summarizes the Company's restructuring activities under all of the Company’s active restructuring plans for fiscal years 2017, 2016 and 2015:

[0001193125-17-248796:notes:267]
|  |  | March 2017 Plan |  | July 2016 Plan |  | June 2016 Plan |  | Other Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| All Restructuring Activities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrual balances at June 27, 2014 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 12 |  |  | $ | 14 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 23 |  |  | 7 |  |  | 30 |  |
| Cash payments |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (17 | ) |  | (10 | ) |  | (27 | ) |
| Adjustments |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | (1 | ) |  | 2 |  |
| Accrual balances at July 3, 2015 |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |  | 8 |  |  | 19 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | — |  |  | 69 |  |  | — |  |  | 82 |  |  | 24 |  |  | 175 |  |
| Cash payments |  | — |  |  | — |  |  | — |  |  | — |  |  | (24 | ) |  | — |  |  | (89 | ) |  | (18 | ) |  | (131 | ) |
| Adjustments |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | (1 | ) |  | — |  |
| Accrual balances at July 1, 2016 |  | — |  |  | — |  |  | — |  |  | — |  |  | 45 |  |  | — |  |  | 5 |  |  | 13 |  |  | 63 |  |
| Restructuring charges |  | 28 |  |  | 3 |  |  | 72 |  |  | 20 |  |  | — |  |  | 1 |  |  | 31 |  |  | 12 |  |  | 167 |  |
| Cash payments |  | (29 | ) |  | (3 | ) |  | (57 | ) |  | (18 | ) |  | (41 | ) |  | (1 | ) |  | (33 | ) |  | (16 | ) |  | (198 | ) |
| Adjustments |  | 1 |  |  | — |  |  | 7 |  |  | — |  |  | (1 | ) |  | — |  |  | — |  |  | 4 |  |  | 11 |  |
| Accrual balances at June 30, 2017 |  | $ | — |  |  | $ | — |  |  | $ | 22 |  |  | $ | 2 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 13 |  |  | $ | 43 |  |
| Total costs incurred to date as of June 30, 2017 |  | $ | 29 |  |  | $ | 3 |  |  | $ | 79 |  |  | $ | 20 |  |  | $ | 68 |  |  | $ | 1 |  |  | $ | 158 |  |  | $ | 49 |  |  | $ | 407 |  |
| Total expected costs to be incurred as of June 30, 2017 |  | $ | 1 |  |  | $ | 3 |  |  | $ | 1 |  |  | $ | 13 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | 21 |  |

[0001193125-17-248796:notes:268]
Of the accrued restructuring balance of $43 million at June 30, 2017, $38 million is included in Accrued expenses and $5 million is included in Other non-current liabilities in the Company's Consolidated Balance Sheet. Of the accrued restructuring balance of approximately $63 million at July 1, 2016, $61 million is included in Accrued expenses and $2 million is included in Other non-current liabilities in the Company's Consolidated Balance Sheet.


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001193125-17-248796:notes:269]
| (Dollars in millions) |  | June 30, 2017 |  | July 1, 2016 |
| Accounts receivable |  | $ | 1,204 |  |  | $ | 1,327 |  |
| Allowance for doubtful accounts |  | (5 | ) |  | (9 | ) |
|  |  | $ | 1,199 |  |  | $ | 1,318 |  |


## us-gaap:ScheduleOfAccountsPayableAndAccruedLiabilitiesTableTextBlock

[0001193125-17-248796:notes:270]
The following table provides details of the accrued expenses balance sheet item:

[0001193125-17-248796:notes:271]
| (Dollars in millions) |  | June 30, 2017 |  | July 1, 2016 |
| Dividends payable |  | $ | 184 |  |  | $ | — |  |
| Other accrued expenses |  | 466 |  |  | 444 |  |
| Total |  | $ | 650 |  |  | $ | 444 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-17-248796:notes:272]
The components of AOCI, net of tax, were as follows:

[0001193125-17-248796:notes:273]
| (Dollars in millions) |  | UnrealizedGains (Losses)on Cash FlowHedges |  | UnrealizedGains (Losses)on MarketableSecurities (a) |  | UnrealizedGains (Losses)on Post-Retirement Plans |  | ForeignCurrencyTranslationAdjustments |  | Total |
| Balance at July 3, 2015 |  | $ | 1 |  |  | $ | — |  |  | $ | (15 | ) |  | $ | (16 | ) |  | $ | (30 | ) |
| Other comprehensive income (loss) before reclassifications |  | (4 | ) |  | — |  |  | 8 |  |  | (1 | ) |  | 3 |  |
| Amounts reclassified from AOCI |  | 2 |  |  | — |  |  | — |  |  | — |  |  | 2 |  |
| Other comprehensive income (loss) |  | (2 | ) |  | — |  |  | 8 |  |  | (1 | ) |  | 5 |  |
| Balance at July 1, 2016 |  | (1 | ) |  | — |  |  | (7 | ) |  | (17 | ) |  | (25 | ) |
| Other comprehensive income (loss) before reclassifications |  | (3 | ) |  | — |  |  | — |  |  | 5 |  |  | 2 |  |
| Amounts reclassified from AOCI |  | 4 |  |  | — |  |  | 2 |  |  | — |  |  | 6 |  |
| Other comprehensive income (loss) |  | 1 |  |  | — |  |  | 2 |  |  | 5 |  |  | 8 |  |
| Balance at June 30, 2017 |  | $ | — |  |  | $ | — |  |  | $ | (5 | ) |  | $ | (12 | ) |  | $ | (17 | ) |

[0001193125-17-248796:notes:274]
___________________________________________

[0001193125-17-248796:notes:275]
| (a) | The cost of a security sold or the amount reclassified out of AOCI into earnings was determined using the specific identification method. |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001193125-17-248796:notes:276]
July 1, 2016:

[0001193125-17-248796:notes:277]
June 30, 2017:


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-17-248796:notes:278]
| (Dollars in millions) |  | June 30, 2017 |  | July 1, 2016 |
| Raw materials and components |  | $ | 350 |  |  | $ | 307 |  |
| Work-in-process |  | 257 |  |  | 297 |  |
| Finished goods |  | 375 |  |  | 264 |  |
|  |  | $ | 982 |  |  | $ | 868 |  |


## us-gaap:ScheduleOfRestrictedCashAndCashEquivalentsTextBlock

[0001193125-17-248796:notes:279]
| (Dollars in millions) |  | June 30, 2017 |  | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |
| Cash and cash equivalents |  | $ | 2,539 |  |  | $ | 1,125 |  |  | $ | 2,479 |  |  | $ | 2,634 |  |
| Restricted cash included in Other current assets |  | 4 |  |  | 7 |  |  | 7 |  |  | 4 |  |
| Total cash, cash equivalents, and restricted cash shown in the Statements of Cash Flows |  | $ | 2,543 |  |  | $ | 1,132 |  |  | $ | 2,486 |  |  | $ | 2,638 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-17-248796:notes:280]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 30, 2017 |  | July 1, 2016 |  | July 3, 2015 |
| Revenue from external customers (a): |  |  |  |  |  |  |
| Singapore |  | $ | 5,070 |  |  | $ | 5,354 |  |  | $ | 6,844 |  |
| United States |  | 3,535 |  |  | 3,376 |  |  | 3,929 |  |
| The Netherlands |  | 1,501 |  |  | 1,813 |  |  | 2,291 |  |
| Other |  | 665 |  |  | 617 |  |  | 675 |  |
| Consolidated |  | $ | 10,771 |  |  | $ | 11,160 |  |  | $ | 13,739 |  |
| Long-lived assets: |  |  |  |  |  |  |
| United States |  | $ | 920 |  |  | $ | 1,029 |  |  | $ | 725 |  |
| Singapore |  | 683 |  |  | 726 |  |  | 900 |  |
| Thailand |  | 414 |  |  | 349 |  |  | 328 |  |
| Malaysia |  | 100 |  |  | 201 |  |  | 248 |  |
| China |  | 61 |  |  | 115 |  |  | 138 |  |
| Other |  | 202 |  |  | 444 |  |  | 568 |  |
| Consolidated |  | $ | 2,380 |  |  | $ | 2,864 |  |  | $ | 2,907 |  |

[0001193125-17-248796:notes:281]
| (a) | Revenue is attributed to countries based on the shipping location. |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001193125-17-248796:notes:282]
Activity in the allowance for doubtful accounts is as follows:

[0001193125-17-248796:notes:283]
| (Dollars in millions) |  | Balance atBeginning ofPeriod |  | Charges(Credit) toOperations |  | Deductions (a) |  | Balance atEnd ofPeriod |
| Fiscal year ended July 3, 2015 |  | $ | 12 |  |  | — |  |  | (3 | ) |  | $ | 9 |  |
| Fiscal year ended July 1, 2016 |  | $ | 9 |  |  | 1 |  |  | (1 | ) |  | $ | 9 |  |
| Fiscal year ended June 30, 2017 |  | $ | 9 |  |  | (4 | ) |  | — |  |  | $ | 5 |  |

[0001193125-17-248796:notes:284]
| (a) | Uncollectible accounts written off, net of recoveries. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-17-248796:notes:285]
Business Segment and Geographic Information

[0001193125-17-248796:notes:286]
The Company has concluded that its manufacture and distribution of storage solutions constitutes one reporting segment. The Company's manufacturing operations are based on technology platforms that are used to produce various storage and systems solutions that serve multiple applications and markets. The Company's main technology platforms are primarily focused around areal density of media and read/write head technologies. In addition, the Company also invests in certain other technology platforms including motors, servo formatting read/write channels, solid state and other technologies.  The Company has determined that its Chief Executive Officer is the Company's chief operating decision maker ("CODM") as he is responsible for reviewing and approving investments in the Company's technology platforms and manufacturing infrastructure.

[0001193125-17-248796:notes:287]
In fiscal years 2017, 2016 and 2015, Dell Inc. accounted for approximately 10%, 12% and 14% of consolidated revenue, respectively. In fiscal year 2015, Hewlett-Packard Company accounted for approximately 12% of consolidated revenue. In fiscal year 2016, HP Inc., formerly known as Hewlett-Packard Company, completed its separation with Hewlett Packard Enterprise Company, and each company accounted for less than 10% of our consolidated revenue in both fiscal year 2016 and 2017. No other customer accounted for more than 10% of consolidated revenue in any year presented.

[0001193125-17-248796:notes:288]
Other long-lived assets consist of property, equipment and leasehold improvements, other intangible assets, capital leases, equity investments and other non-current assets as recorded by the Company's operations in each area.

[0001193125-17-248796:notes:289]
The following table summarizes the Company's operations by geographic area:


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-17-248796:notes:290]
Shareholders' Equity

[0001193125-17-248796:notes:291]
Share Capital

[0001193125-17-248796:notes:292]
The Company's authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 291,799,561 shares were outstanding as of June 30, 2017, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of June 30, 2017.

[0001193125-17-248796:notes:293]
Ordinary shares - Holders of ordinary shares are entitled to receive dividends when and as declared by the Company's board of directors (the "Board of Directors"). Upon any liquidation, dissolution, or winding up of the Company, after required payments are made to holders of preferred shares, any remaining assets of the Company will be distributed ratably to holders of the preferred and ordinary shares. Holders of shares are entitled to one vote per share on all matters upon which the ordinary shares are entitled to vote, including the election of directors.

[0001193125-17-248796:notes:294]
Preferred shares - The Company may issue preferred shares in one or more series, up to the authorized amount, without shareholder approval. The Board of Directors is authorized to establish from time to time the number of shares to be included in each series, and to fix the rights, preferences and privileges of the shares of each wholly unissued series and any of its qualifications, limitations or restrictions. The Board of Directors can also increase or decrease the number of shares of a series, but not below the number of shares of that series then outstanding, without any further vote or action by the shareholders.

[0001193125-17-248796:notes:295]
The Board of Directors may authorize the issuance of preferred shares with voting or conversion rights that could harm the voting power or other rights of the holders of the ordinary shares. The issuance of preferred shares, while providing flexibility in connection with possible acquisitions and other corporate purposes, could, among other things, have the effect of delaying, deferring or preventing a change in control of the Company and might harm the market price of its ordinary shares and the voting and other rights of the holders of ordinary shares.

[0001193125-17-248796:notes:296]
Repurchases of Equity Securities

[0001193125-17-248796:notes:297]
On April 22, 2015, the Board of Directors authorized the Company to repurchase an additional $2.5 billion of its outstanding ordinary shares.

[0001193125-17-248796:notes:298]
All repurchases are effected as redemptions in accordance with the Company's Articles of Association.

[0001193125-17-248796:notes:299]
As of June 30, 2017, $1.3 billion remained available for repurchase under the existing repurchase authorization limit.

[0001193125-17-248796:notes:300]
The following table sets forth information with respect to repurchases of the Company's ordinary shares during fiscal years 2017, 2016 and 2015:

[0001193125-17-248796:notes:301]
_______________________________

[0001193125-17-248796:notes:302]
| (a) | For fiscal years 2017 and 2016, including net share settlement of $27 million and $56 million, for 1 million and 1 million shares in connection with tax withholding related to vesting of restricted stock units, respectively. |


## us-gaap:SubsequentEventsTextBlock

[0001193125-17-248796:notes:303]
Subsequent Events

[0001193125-17-248796:notes:304]
July 2017 Restructuring Plan

[0001193125-17-248796:notes:305]
On July 25, 2017, the Company committed to an additional restructuring plan (the “July 2017 Plan”) to reduce its cost structure. The July 2017 Plan included reducing the Company's global headcount by approximately 600 employees. The July 2017 Plan, which the Company expects to be substantially completed by the end of the first quarter of fiscal year 2018, is expected to result in total pre-tax charges of approximately $50 million, primarily in the first quarter of fiscal year 2018. These charges are expected to be comprised of cash expenditures on severance and employee-related costs.

[0001193125-17-248796:notes:306]
Planned Leadership Transition

[0001193125-17-248796:notes:307]
On July 25, 2017 the Company’s Board of Directors appointed William D. Mosley to serve as Chief Executive Officer, of the Company effective October 1, 2017. The Board of Directors also appointed Mr. Mosley to serve as a director of the Company, effective July 25, 2017. Mr. Mosley will serve as a director until the Company’s next annual general meeting of shareholders when he is expected to stand for election by a vote of the Company’s shareholders. On July 25, 2017, the Company also announced that Stephen J. Luczo will step down from his position as Chief Executive Officer, effective October 1, 2017. Mr. Luczo will remain with the Company in the role of Executive Chairman effective October 1, 2017 and will continue to serve as Chairman of the Board of Directors.

[0001193125-17-248796:notes:308]
As previously announced on June 2, 2017, Philip G. Brace, President of Cloud Systems and Silicon group, will be leaving the Company. On July 20, 2017, the Company and Mr. Brace agreed that the effective date of his departure will be October 2, 2017.

[0001193125-17-248796:notes:309]
Dividend Declared

[0001193125-17-248796:notes:310]
On July 25, 2017, the Company's Board of Directors approved and declared a quarterly cash dividend of $0.63 per share, which will be payable on October 4, 2017 to shareholders of record as of the close of business on September 20, 2017.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-17-248796:notes:311]
Balance Sheet Information

[0001193125-17-248796:notes:312]
Investments

[0001193125-17-248796:notes:313]
As of June 30, 2017, the Company's Other current assets included $4 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001193125-17-248796:notes:314]
As of June 30, 2017, the Company had no material available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months.  The Company determined no available-for-sale securities were other-than-temporarily impaired as of June 30, 2017.

[0001193125-17-248796:notes:315]
Equity securities which do not have a contractual maturity date are not included in the above table.

[0001193125-17-248796:notes:316]
As of July 1, 2016, the Company's Other current assets included $7 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001193125-17-248796:notes:317]
As of July 1, 2016, the Company had no available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months.  The Company determined no available-for-sale securities were other-than-temporarily impaired as of July 1, 2016.

[0001193125-17-248796:notes:318]
Cash, Cash Equivalents, and Restricted Cash

[0001193125-17-248796:notes:319]
The following table provides a summary of cash, cash equivalents, and restricted cash reported within the Consolidated Balance Sheets that reconciles to the corresponding amount in the Consolidated Statements of Cash Flows:

[0001193125-17-248796:notes:320]
Accounts Receivable, net

[0001193125-17-248796:notes:321]
The following table provides details of the accounts receivable, net balance sheet item:

[0001193125-17-248796:notes:322]
Inventories

[0001193125-17-248796:notes:323]
The following table provides details of the inventory balance sheet item:

[0001193125-17-248796:notes:324]
Property, Equipment and Leasehold Improvements, net

[0001193125-17-248796:notes:325]
Depreciation expense, which includes amortization of leasehold improvements, was $581 million, $641 million and $689 million for fiscal years 2017, 2016 and 2015, respectively. Interest on borrowings related to eligible capital expenditures is capitalized as part of the cost of the qualified assets and amortized over the estimated useful lives of the assets. During fiscal years 2017, 2016 and 2015, the Company capitalized interest of $4 million, $13 million and $15 million, respectively.

[0001193125-17-248796:notes:326]
In fiscal years 2017 and 2016, the Company determined it would discontinue the use of certain manufacturing property and equipment in the short-term, and that certain other buildings, land and manufacturing property and equipment were permanently impaired. As a result, the company recognized charges of $72 million and $53 million in fiscal years 2017 and 2016, respectively, from the write-off and accelerated depreciation of these fixed assets, included $35 million impairment on land and buildings in fiscal year 2017, classified as held for sale under Other current assets in the Consolidated Balance Sheet. Please refer to Note 9. Fair Value for more details. In fiscal year 2017, total charges of $35 million, $35 million and $2 million was recorded to Cost of revenue, Product development and Marketing and administrative, respectively, in the Consolidated Statement of Operations. In fiscal year 2016, the entire amount was recorded in Cost of revenue in the Consolidated Statement of Operations. The Company did not record any material impairment in fiscal year 2015.

[0001193125-17-248796:notes:327]
Accrued Expenses

[0001193125-17-248796:notes:328]
Accumulated Other Comprehensive Income (Loss) (“AOCI”)
