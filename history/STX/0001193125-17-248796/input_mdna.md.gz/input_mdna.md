# STX MD&A — 0001193125-17-248796


## mdna

[0001193125-17-248796:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001193125-17-248796:mdna:2]
The following is a discussion of the Company’s financial condition, changes in financial condition and results of operations for the
fiscal years ended June 30, 2017, July 1, 2016 and July 3, 2015.

[0001193125-17-248796:mdna:3]
You should read this discussion in conjunction
with “Item 6. Selected Financial Data” and “Item 8. Financial Statements and Supplementary Data” included elsewhere in this Annual Report on Form 10-K. Except as noted, references
to any fiscal year mean the twelve-month period ending on the Friday closest to June 30 of that year. Accordingly, fiscal year 2017 comprised 52 weeks and ended on June 30, 2017. Fiscal year 2016 comprised 52 weeks and ended on
July 1, 2016. Fiscal year 2015 comprised 53 weeks and ended on July 3, 2015. Fiscal year 2018 will be 52 weeks and will end on June 29, 2018.

[0001193125-17-248796:mdna:4]
Our Management’s Discussion and
Analysis of Financial Condition and Results of Operations (“MD&A”) is provided in addition to the accompanying consolidated financial statements and notes to assist readers in understanding our results of operations, financial
condition, and cash flows. MD&A is organized as follows:

[0001193125-17-248796:mdna:5]
|  | • |  | Our Company. Discussion of our business. |

[0001193125-17-248796:mdna:6]
|  | • |  | Business Overview. Discussion of industry trends and their impact on our business. |

[0001193125-17-248796:mdna:7]
|  | • |  | Fiscal Year 2017 Summary. Overview of financial and other highlights affecting us for fiscal year 2017. |

[0001193125-17-248796:mdna:8]
|  | • |  | Results of Operations. Analysis of our financial results comparing fiscal years 2017 to 2016 and comparing fiscal years 2016 to 2015. |

[0001193125-17-248796:mdna:9]
|  | • |  | Liquidity and Capital Resources. An analysis of changes in our balance sheets and cash flows, and discussion of our financial condition including the credit quality of our investment portfolio and potential sources of liquidity. |

[0001193125-17-248796:mdna:10]
|  | • |  | Contractual Obligations and Off-Balance Sheet Arrangements. Overview of contractual obligations and contingent liabilities and commitments outstanding as of June 30, 2017 and an explanation of off-balance sheet arrangements. |

[0001193125-17-248796:mdna:11]
|  | • |  | Critical Accounting Estimates. Accounting estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results. |

[0001193125-17-248796:mdna:12]
Our Company

[0001193125-17-248796:mdna:13]
We are a leading provider of data storage technology and solutions. Our principal products are hard disk drives, commonly referred to as disk
drives, hard drives or HDDs. In addition to HDDs, we produce a broad range of data storage products including solid state drives (“SSD”) and their related controllers, solid state hybrid drives (“SSHD”) and storage subsystems.

[0001193125-17-248796:mdna:14]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to
be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to
store data, and most SSDs use NAND-based flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed
data.

[0001193125-17-248796:mdna:15]
Our products are designed for mission critical and nearline applications in enterprise servers and storage systems; client compute
applications, where our products are designed primarily for desktop and mobile computing; and client non-compute applications, where our products are designed for a wide variety of end user devices such as
portable external storage systems, surveillance systems, network-attached storage (“NAS”), digital video recorders (“DVRs”) and gaming consoles.

[0001193125-17-248796:mdna:16]
Our cloud systems and solutions extend innovation from the device into the information infrastructure, onsite and in the cloud. Our portfolio
includes modular original equipment manufacturer (“OEM”) storage systems and scale-out storage servers.

[0001193125-17-248796:mdna:17]
Business Overview

[0001193125-17-248796:mdna:18]
Our industry is
characterized by several trends and factors that have a material impact on our strategic planning, financial condition and results of operations.

[0001193125-17-248796:mdna:19]
Demand for Data Storage

[0001193125-17-248796:mdna:20]
The continued advancement of the cloud, the proliferation of a variety of mobile devices globally, development of the Internet of Things
(“IoT”), increasingly pervasive use of video surveillance, evolution of consumer electronic devices, and enterprise use of big data analytics are driving the growth of digital content. Factors contributing to the growth of digital content
include:

[0001193125-17-248796:mdna:21]
|  | • |  | Creation, sharing, and consumption of media-rich digital content, such as high-resolution photos, high definition video, and digital music through smart phones, tablets, digital cameras, personal video cameras, DVRs, gaming consoles or other digital devices; |

[0001193125-17-248796:mdna:22]
|  | • |  | Creation, aggregation and distribution of digital content through services and other offerings such as Facebook®, Instagram®, iTunes®, Netflix®, Google® and YouTube®; |

[0001193125-17-248796:mdna:23]
|  | • |  | New surveillance systems which feature higher resolution digital cameras and thus require larger data storage capacities; |

[0001193125-17-248796:mdna:24]
|  | • |  | Creation and collection of data through the evolution of the IoT ecosystem, big data analytics and new technology trends such as self-driving cars and drones; |

[0001193125-17-248796:mdna:25]
|  | • |  | Build out of large numbers of cloud data centers by cloud service providers and private companies transitioning on-site data centers into the cloud; and |

[0001193125-17-248796:mdna:26]
|  | • |  | Protection of increased digital content through redundant storage on backup devices and externally provided storage services. |

[0001193125-17-248796:mdna:27]
As a result of these factors, the nature and volume of content being created requires greater storage, which is more efficiently and
economically facilitated by higher capacity storage devices in order to store, manage, distribute, analyze and backup such content. We expect this to support the growth in demand for data storage solutions in developed and emerging economies well
into the future.

[0001193125-17-248796:mdna:28]
The amount of data created as well as where and how data is stored continues to evolve with the proliferation of mobile
devices, the growth of cloud computing, and the evolving IoT. In addition, the economics of storage infrastructure are also evolving with the utilization of public and private hyper-scale storage and open-source solutions reducing the total cost of
ownership of storage while increasing the speed and efficiency with which customers can leverage massive computing and storage devices. Accordingly, we expect these trends will continue to create significant demand for data storage solutions going
forward.

[0001193125-17-248796:mdna:29]
Demand Trends for Disk Drives

[0001193125-17-248796:mdna:30]
We believe that continued growth in digital content requires increasingly higher storage capacity in order to store, aggregate, host,
distribute, analyze, manage, backup and use such content. We also believe that as architectures evolve to serve the growing commercial and consumer user base throughout the world, the manner in which hard drives are delivered to market and utilized
by our customers will evolve as well.

[0001193125-17-248796:mdna:31]
We believe that in the foreseeable future the traditional enterprise and client compute
markets that require high-capacity storage solutions, and the data intensive client non-compute markets will continue to be best served by hard disk drives due to the industry’s ability to deliver the
most cost effective, reliable and energy efficient mass storage devices although the advance of solid state technology in the above markets is expected to increase as well. Furthermore, the increased use of client
non-compute devices that both consume media-rich digital content streamed from the cloud and create rich digital content that is stored in the cloud, increases the demand for high capacity hard disk drives in
enterprise nearline applications.

[0001193125-17-248796:mdna:32]
We also believe that as hard disk drive capacities continue to increase, unit demand does not reflect
the increase in exabytes demand. In recent years, this trend has resulted in demand for fewer units, but with higher average capacity per drive.

[0001193125-17-248796:mdna:33]
Industry Supply Balance

[0001193125-17-248796:mdna:34]
From time to time the HDD industry has experienced periods of imbalance between supply and demand. To the extent that the disk drive industry
builds or maintains capacity based on expectations of demand that do not materialize, price erosion may become more pronounced. Conversely, during periods where demand exceeds supply, price erosion is generally muted.

[0001193125-17-248796:mdna:35]
Price Erosion

[0001193125-17-248796:mdna:36]
Historically, our industry has been characterized by price declines for disk drive products with comparable capacity, performance and feature
sets (“like-for-like products”). Price declines for like-for-like products
(“price erosion”) tend to be more pronounced during periods of:

[0001193125-17-248796:mdna:37]
|  | • |  | economic contraction in which competitors may use discounted pricing to attempt to maintain or gain market share; |

[0001193125-17-248796:mdna:38]
|  | • |  | few new product introductions when competitors have comparable or alternative product offerings; and |

[0001193125-17-248796:mdna:39]
|  | • |  | industry supply exceeding demand. |

[0001193125-17-248796:mdna:40]
Disk drive manufacturers typically attempt to offset price
erosion with an improved mix of disk drive products characterized by higher capacity, better performance and additional feature sets and product cost reductions.

[0001193125-17-248796:mdna:41]
We believe the HDD industry experienced modest price erosion in fiscal years 2015, 2016 and 2017.

[0001193125-17-248796:mdna:42]
Product Life Cycles and Changing Technology

[0001193125-17-248796:mdna:43]
Success in our industry has been dependent to a large extent on the ability to balance the introduction and transition of new products with time-to-volume, performance, capacity and quality metrics at a competitive price, level of service and support that our customers expect. Generally, the drive manufacturer
that introduces a new product first benefits from improved product mix, favorable profit margins and less pricing pressure until comparable products are introduced. Changing technology also necessitates
on-going investments in research and development, which may be difficult to recover due to rapid product life cycles and economic declines. Further, there is a continued need to successfully execute product
transitions and new product introductions, as factors such as quality, reliability and manufacturing yields continue to be of significant competitive importance.

[0001193125-17-248796:mdna:44]
Seasonality

[0001193125-17-248796:mdna:45]
The disk
drive industry traditionally experiences seasonal variability in demand with higher levels of demand in the second half of the calendar year. This seasonality is driven by consumer spending in the back-to-school season from late summer to fall and the traditional holiday shopping season from fall to winter. We believe fiscal year 2015 reflected seasonality consistent with historical patterns. In fiscal
year 2016, beyond traditional seasonality, variability of sales was a reflection of more cyclical demand from CSPs based on the timing of large systems installations and the shift of the underlying technology. We believe fiscal year 2017 reflected
seasonality consistent with historical patterns.

[0001193125-17-248796:mdna:46]
Fiscal Year 2017 Summary

[0001193125-17-248796:mdna:47]
During the fiscal year 2017, we shipped 263 exabytes, generating revenue of $10.8 billion and gross margins of 29%. Our operating cash
flow was $1.9 billion. We repurchased approximately 12 million of our ordinary shares during the year for approximately $460 million. We issued $750 million of 4.25% Senior Notes due 2022 and $500 million of 4.875% Senior
Notes due 2024 and paid $316 million for the redemption and repurchase of our outstanding debt, as well as paid $561 million in dividends in fiscal year 2017.

[0001193125-17-248796:mdna:48]
Results of Operations

[0001193125-17-248796:mdna:49]
We list in the tables below summarized information from our Consolidated Statements of Operations by dollars and as a percentage of revenue:

[0001193125-17-248796:mdna:50]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 30,2017 |  |  | July 1,2016 |  |  | July 3,2015 |  |
| Revenue |  | $ | 10,771 |  |  | $ | 11,160 |  |  | $ | 13,739 |  |
| Cost of revenue |  |  | 7,597 |  |  |  | 8,545 |  |  |  | 9,930 |  |
| Gross margin |  |  | 3,174 |  |  |  | 2,615 |  |  |  | 3,809 |  |
| Product development |  |  | 1,232 |  |  |  | 1,237 |  |  |  | 1,353 |  |
| Marketing and administrative |  |  | 606 |  |  |  | 635 |  |  |  | 857 |  |
| Amortization of intangibles |  |  | 104 |  |  |  | 123 |  |  |  | 129 |  |
| Restructuring and other, net |  |  | 178 |  |  |  | 175 |  |  |  | 32 |  |
| Gain on arbitration award, net |  |  | — |  |  |  | — |  |  |  | (620 | ) |
| Income from operations |  |  | 1,054 |  |  |  | 445 |  |  |  | 2,058 |  |
| Other expense, net |  |  | (239 | ) |  |  | (171 | ) |  |  | (88 | ) |
| Income before income taxes |  |  | 815 |  |  |  | 274 |  |  |  | 1,970 |  |
| Provision for income taxes |  |  | 43 |  |  |  | 26 |  |  |  | 228 |  |
| Net income |  | $ | 772 |  |  | $ | 248 |  |  | $ | 1,742 |  |

[0001193125-17-248796:mdna:51]
|  |  | Fiscal Years Ended |  |
|  |  | June 30,2017 |  |  | July 1,2016 |  |  | July 3,2015 |  |
| Revenue |  |  | 100% |  |  |  | 100% |  |  |  | 100% |  |
| Cost of revenue |  |  | 71 |  |  |  | 77 |  |  |  | 72 |  |
| Gross margin |  |  | 29 |  |  |  | 23 |  |  |  | 28 |  |
| Product development |  |  | 11 |  |  |  | 11 |  |  |  | 10 |  |
| Marketing and administrative |  |  | 5 |  |  |  | 6 |  |  |  | 7 |  |
| Amortization of intangibles |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |
| Restructuring and other, net |  |  | 2 |  |  |  | 2 |  |  |  | — |  |
| Gain on arbitration award, net |  |  | — |  |  |  | — |  |  |  | (5) |  |
| Income from operations |  |  | 10 |  |  |  | 4 |  |  |  | 15 |  |
| Other expense, net |  |  | (2) |  |  |  | (2) |  |  |  | (1) |  |
| Income before income taxes |  |  | 8 |  |  |  | 2 |  |  |  | 14 |  |
| Provision for income taxes |  |  | 1 |  |  |  | — |  |  |  | 2 |  |
| Net income |  |  | 7% |  |  |  | 2% |  |  |  | 12% |  |

[0001193125-17-248796:mdna:52]
37

[0001193125-17-248796:mdna:53]
The following table summarizes HDD information regarding average drive selling prices
(“ASPs”), exabytes shipped, and revenues by channel and geography:

[0001193125-17-248796:mdna:54]
|  |  | Fiscal Years Ended |  |
|  |  | June 30,2017 |  |  | July 1,2016 |  |  | July 3,2015 |  |
| ASPs (per unit) |  | $ | 66 |  |  | $ | 61 |  |  | $ | 61 |  |
| Exabytes Shipped |  |  | 263 |  |  |  | 233 |  |  |  | 228 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  |  | 67 | % |  |  | 69 | % |  |  | 71% |  |
| Distributors |  |  | 18 | % |  |  | 17 | % |  |  | 18% |  |
| Retailers |  |  | 15 | % |  |  | 14 | % |  |  | 11% |  |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  |  | 31 | % |  |  | 29 | % |  |  | 27% |  |
| EMEA |  |  | 17 | % |  |  | 17 | % |  |  | 16% |  |
| Asia Pacific |  |  | 52 | % |  |  | 54 | % |  |  | 57% |  |

[0001193125-17-248796:mdna:55]
Fiscal Year 2017 Compared to Fiscal Year 2016

[0001193125-17-248796:mdna:56]
Revenue

[0001193125-17-248796:mdna:57]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 30,2017 |  |  | July 1,2016 |  |  | Change |  |  | %Change |  |
| Revenue |  | $ | 10,771 |  |  | $ | 11,160 |  |  | $ | (389 | ) |  |  | (3)% |  |

[0001193125-17-248796:mdna:58]
Revenue in fiscal year 2017 decreased approximately 3% or $0.4 billion, from fiscal year 2016, as a
result of price erosion partially offset by an increase in exabytes shipped.

[0001193125-17-248796:mdna:59]
Cost of Revenue and Gross Margin

[0001193125-17-248796:mdna:60]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 30,2017 |  |  | July 1,2016 |  |  | Change |  |  | %Change |  |
| Cost of revenue |  | $ | 7,597 |  |  | $ | 8,545 |  |  | $ | (948 | ) |  |  | (11)% |  |
| Gross margin |  | $ | 3,174 |  |  | $ | 2,615 |  |  | $ | 559 |  |  |  | 21% |  |
| Gross margin percentage |  |  | 29 | % |  |  | 23 | % |  |  |  |  |  |  |  |  |

[0001193125-17-248796:mdna:61]
For fiscal year 2017, gross margin as a percentage of revenue increased by 600 basis points compared to the
prior fiscal year due to a favorable product mix and improved factory utilization resulting from cost savings due to our ongoing workforce reductions and manufacturing consolidation activities, partially offset by price erosion.

[0001193125-17-248796:mdna:62]
Operating Expenses

[0001193125-17-248796:mdna:63]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 30,2017 |  |  | July 1,2016 |  |  | Change |  |  | %Change |  |
| Product development |  | $ | 1,232 |  |  | $ | 1,237 |  |  | $ | (5 | ) |  |  | — % |  |
| Marketing and administrative |  |  | 606 |  |  |  | 635 |  |  |  | (29 | ) |  |  | (5)% |  |
| Amortization of intangibles |  |  | 104 |  |  |  | 123 |  |  |  | (19 | ) |  |  | (15)% |  |
| Restructuring and other, net |  |  | 178 |  |  |  | 175 |  |  |  | 3 |  |  |  | 2% |  |
| Operating expenses |  | $ | 2,120 |  |  | $ | 2,170 |  |  | $ | (50 | ) |  |  |  |  |

[0001193125-17-248796:mdna:64]
Product Development Expense. Product development expenses for fiscal year
2017 decreased from fiscal year 2016 primarily due to a $102 million decrease in salaries and related benefits as a result of an increase in operational efficiencies in our business and the restructuring of our workforce in the prior periods,
offset by a $71 million increase in variable compensation and share-based compensation driven by better financial performance and a $26 million increase in impairment charges related to the closure of our Korea design center.

[0001193125-17-248796:mdna:65]
Marketing and Administrative Expense. Marketing and administrative expenses for fiscal year 2017 decreased from fiscal year
2016 primarily due to a decrease in salaries and related benefits of $52 million as a result of the restructuring of our workforce in prior periods, a $28 million cost reduction resulting from an increase in operational efficiencies in our
business and the completion of certain promotional and branding activities in fiscal year 2016, partially offset by a $51 million increase in variable compensation and share-based compensation driven by better financial performance.

[0001193125-17-248796:mdna:66]
Amortization of Intangibles. Amortization of intangibles for fiscal year 2017 decreased by $19 million, as compared to
fiscal year 2016, due to certain intangible assets reaching the end of their useful life.

[0001193125-17-248796:mdna:67]
Restructuring and Other,
net. Restructuring and other, net for fiscal year 2017 was comprised primarily of restructuring charges recorded during the September 2016 quarter and March 2017 quarter to reduce our workforce by approximately 6,800 employees, as we
continue to consolidate our global footprint across Asia, EMEA and the Americas.

[0001193125-17-248796:mdna:68]
Restructuring and other, net for fiscal year 2016
comprised of restructuring charges recorded during the September 2015 quarter, March 2016 quarter and June 2016 quarter, to reduce our workforce by approximately 4,600 employees and align our manufacturing footprint with current macroeconomic
conditions.

[0001193125-17-248796:mdna:69]
Other expense, net

[0001193125-17-248796:mdna:70]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 30,2017 |  |  | July 1,2016 |  |  | Change |  |  | %Change |  |
| Other expense, net |  | $ | (239 | ) |  | $ | (171 | ) |  | $ | (68 | ) |  |  | 40% |  |

[0001193125-17-248796:mdna:71]
Other expense, net for fiscal year 2017 increased by $68 million, as compared to fiscal year 2016
primarily due to the $33 million of other income associated with the final payment of unpaid interest on the arbitration award amount in the Company’s case against Western Digital in fiscal year 2016 which did not recur in fiscal year
2017, a $12 million increase from impairment of certain strategic investments and $24 million interest expense on the issuance of $750 million of 4.25% Senior Notes due 2022 and $500 million of 4.875% Senior Notes due 2024.

[0001193125-17-248796:mdna:72]
Income Taxes

[0001193125-17-248796:mdna:73]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 30,2017 |  |  | July 1,2016 |  |  | Change |  |  | %Change |  |
| Provision for income taxes |  | $ | 43 |  |  | $ | 26 |  |  | $ | 17 |  |  |  | 65% |  |

[0001193125-17-248796:mdna:74]
We recorded an income tax provision of $43 million for fiscal year 2017 compared to an income tax
provision of $26 million for fiscal year 2016. Our fiscal year 2017 income tax provision included approximately $2 million of net tax expense associated with various non-recurring items. Our fiscal
year 2016 income tax provision included approximately $22 million of income tax benefits primarily associated with the release of tax reserves due to the expiration of certain statutes of limitation.

[0001193125-17-248796:mdna:75]
Our Irish tax resident parent holding company owns various U.S. and non-U.S. subsidiaries that operate
in multiple non-Irish income tax jurisdictions. Our worldwide operating income is either subject to varying rates of income tax or is exempt from income tax due to tax holiday programs we operate under in
Malaysia, Singapore and Thailand. These tax holidays are scheduled to expire in whole or in part at various dates through 2024.

[0001193125-17-248796:mdna:76]
Our
income tax provision recorded for fiscal year 2017 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits
related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) a decrease in
valuation allowance for certain deferred tax assets, and (iii) permanent differences. Our income tax provision recorded for fiscal year 2016 differed from the provision for income taxes that would be derived by applying the Irish statutory rate
of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs
and are considered indefinitely reinvested outside of Ireland, (ii) tax benefits associated with the reversal of previously recorded taxes, and (iii) a decrease in valuation allowance for certain deferred tax assets. The acquisition of Dot
Hill System Corporation did not have a material impact on our effective tax rate.

[0001193125-17-248796:mdna:77]
Based on our non-U.S. ownership structure and
subject to (i) potential future increases in our valuation allowance for deferred tax assets; and (ii) a future change in our intention to indefinitely reinvest earnings from our subsidiaries outside of Ireland, we anticipate that our
effective tax rate in future periods will generally be less than the Irish statutory rate.

[0001193125-17-248796:mdna:78]
At June 30, 2017, our deferred tax asset
valuation allowance was approximately $966 million.

[0001193125-17-248796:mdna:79]
At June 30, 2017, we had net deferred tax assets of $602 million,
excluding $2 million of deferred taxes on intra-entity transactions. The realization of most of these deferred tax assets is primarily dependent on our ability to generate sufficient U.S. and certain
non-U.S. taxable income in future periods. Although realization is not assured, we believe that it is more likely than not that these deferred tax assets will be realized. The amount of deferred tax assets
considered realizable, however, may increase or decrease in subsequent periods when we re-evaluate the underlying basis for our estimates of future U.S. and certain
non-U.S. taxable income.

[0001193125-17-248796:mdna:80]
As of June 30, 2017, approximately $560 million and
$101 million of our total U.S. net operating loss and tax credit carryforwards, respectively, are subject to annual limitations from $1 million to $45 million pursuant to U.S. tax law.

[0001193125-17-248796:mdna:81]
We are required to file U.S. federal, U.S. state, and non-U.S income tax returns. We are no
longer subject to tax examination of U.S. federal income tax returns for years prior to fiscal year 2014. With respect to U.S. state and non-U.S. income tax returns, we are generally no longer subject to tax
examination for years ending prior to fiscal year 2006.

[0001193125-17-248796:mdna:82]
Fiscal Year 2016 Compared to Fiscal Year 2015

[0001193125-17-248796:mdna:83]
Revenue

[0001193125-17-248796:mdna:84]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 1,2016 |  |  | July 3,2015 |  |  | Change |  |  | %Change |  |
| Revenue |  | $ | 11,160 |  |  | $ | 13,739 |  |  | $ | (2,579 | ) |  |  | (19)% |  |

[0001193125-17-248796:mdna:85]
Revenue in fiscal year 2016 decreased approximately 19% or $2.6 billion, from fiscal year 2015, as a
result of price erosion, and a decrease in exabytes shipped in the client compute market.

[0001193125-17-248796:mdna:86]
Cost of Revenue and Gross Margin

[0001193125-17-248796:mdna:87]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 1,2016 |  |  | July 3,2015 |  |  | Change |  |  | %Change |  |
| Cost of revenue |  | $ | 8,545 |  |  | $ | 9,930 |  |  | $ | (1,385 | ) |  |  | (14)% |  |
| Gross margin |  | $ | 2,615 |  |  | $ | 3,809 |  |  | $ | (1,194 | ) |  |  | (31)% |  |
| Gross margin percentage |  |  | 23 | % |  |  | 28 | % |  |  |  |  |  |  |  |  |

[0001193125-17-248796:mdna:88]
For fiscal year 2016, gross margin as a percentage of revenue decreased by 500 basis points compared to the
prior fiscal year due to price erosion and reduced demand in legacy hard drives resulting in underutilization of certain factories, partially offset by improved product mix in the second half of fiscal year 2016.

[0001193125-17-248796:mdna:89]
Operating Expenses

[0001193125-17-248796:mdna:90]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 1,2016 |  |  | July 3,2015 |  |  | Change |  |  | %Change |  |
| Product development |  | $ | 1,237 |  |  | $ | 1,353 |  |  | $ | (116 | ) |  |  | (9)% |  |
| Marketing and administrative |  |  | 635 |  |  |  | 857 |  |  |  | (222 | ) |  |  | (26)% |  |
| Amortization of intangibles |  |  | 123 |  |  |  | 129 |  |  |  | (6 | ) |  |  | (5)% |  |
| Restructuring and other, net |  |  | 175 |  |  |  | 32 |  |  |  | 143 |  |  |  | 447% |  |
| Gain on arbitration award, net |  |  | — |  |  |  | (620 | ) |  |  | 620 |  |  |  | (100)% |  |
| Operating expenses |  | $ | 2,170 |  |  | $ | 1,751 |  |  | $ | 419 |  |  |  |  |  |

[0001193125-17-248796:mdna:91]
Product Development Expense. Product development expenses for fiscal year 2016 decreased
from fiscal year 2015 due to a decrease in salaries and other employee benefits of $63 million as a result of the restructuring of our workforce beginning in the second half of fiscal year 2015, a $29 million decrease in variable
compensation, and other cost reduction efforts, partially offset by the consolidation of Dot Hill in fiscal year 2016 and LSI’s Flash Business in fiscal year 2015.

[0001193125-17-248796:mdna:92]
Marketing and Administrative Expense. Marketing and administrative expenses for fiscal year 2016 decreased from fiscal year
2015 primarily due to a decrease in salaries and other employee benefits of $82 million as a result of a restructuring of our workforce beginning in the second half of fiscal year 2015, a $45 million decrease in variable compensation and
share-based compensation, a $33 million reduction in advertising due to the completion of certain promotional and branding activities in fiscal year 2016, and increased operational efficiencies in our business.

[0001193125-17-248796:mdna:93]
Amortization of Intangibles. Amortization of intangibles for fiscal year 2016 decreased by $6 million, as compared to fiscal
year 2015, as a result of certain intangible assets reaching the end of their useful lives, partially offset by the amortization of intangibles acquired from the Dot Hill acquisition in fiscal 2016.

[0001193125-17-248796:mdna:94]
Restructuring and Other, net. Restructuring and other, net for fiscal year 2016 was comprised of restructuring charges recorded
during the September 2015 quarter, March 2016 quarter and June 2016 quarter, to reduce our workforce by approximately 4,600 employees and align our manufacturing footprint with current macroeconomic conditions. Restructuring and other, net for
fiscal year 2015 was due to charges to reduce our workforce as a result of our ongoing focus on cost efficiencies in all areas of our business.

[0001193125-17-248796:mdna:95]
Gain on arbitration award, net. Gain on arbitration award, net for fiscal year 2015 was related to the final award amount of
$630 million, less litigation and other related costs of $10 million, in the Company’s case against Western Digital for the misappropriation of the Company’s trade secrets.

[0001193125-17-248796:mdna:96]
Other expense, net

[0001193125-17-248796:mdna:97]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 1,2016 |  |  | July 3,2015 |  |  | Change |  |  | %Change |  |
| Other expense, net |  | $ | (171 | ) |  | $ | (88 | ) |  | $ | (83 | ) |  |  | 94% |  |

[0001193125-17-248796:mdna:98]
Other expense, net for fiscal year 2016 increased by $83 million, as compared to fiscal year 2015
primarily due to the absence of partial receipt of $143 million for interest accrued on the final arbitration award amount in the Company’s case against Western Digital in fiscal year 2015 compared to $33 million in fiscal year 2016,
and a $33 million change in foreign currency remeasurement related to net gains and losses from changes in foreign exchange rates, which were more pronounced in the prior year, partially offset by $74 million of losses from the early
redemptions and repurchases of debt in fiscal year 2015 compared to a $3 million gain from the early redemptions and repurchases of debt in fiscal year 2016.

[0001193125-17-248796:mdna:99]
Income Taxes

[0001193125-17-248796:mdna:100]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 1,2016 |  |  | July 3,2015 |  |  | Change |  |  | %Change |  |
| Provision for income taxes |  | $ | 26 |  |  | $ | 228 |  |  | $ | (202 | ) |  |  | (89)% |  |

[0001193125-17-248796:mdna:101]
We recorded an income tax provision of $26 million for fiscal year 2016 compared to an
income tax provision of $228 million for fiscal year 2015. Our fiscal year 2016 income tax provision included approximately $22 million of income tax benefits primarily associated with the release of tax reserves due to the expiration of
certain statutes of limitation. Our fiscal year 2015 income tax provision included approximately $193 million of net income tax expense due to the final audit assessment received from the Jiangsu Province State Tax Bureau of the People’s
Republic of China (China assessment) for calendar years 2007 through 2013.

[0001193125-17-248796:mdna:102]
Our income tax provision recorded for fiscal year 2016
differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to
non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) tax benefits associated with the
reversal of previously recorded taxes, and (iii) a decrease in valuation allowance for certain deferred tax assets. The acquisition of Dot Hill System Corporation did not have a material impact on our effective tax rate. Our income tax
provision recorded for fiscal year 2015 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to
non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) tax expense associated with the
China assessment recorded during the December 2014 quarter, and (iii) an increase in valuation allowance for certain deferred tax assets. The acquisition of LSI’s Flash Business did not have a material impact on our effective tax rate.

[0001193125-17-248796:mdna:103]
On December 18, 2015, the Protecting Americans from Tax Hikes (“PATH”) Act of 2015 was enacted. Among other provisions,
the PATH Act retroactively reinstated and permanently extended the federal Research and Development (“R&D”) tax credit from December 31, 2014. The permanent extension of the R&D credit had no immediate impact on our income tax
provision due to valuation allowances on our U.S. deferred tax assets. None of the other PATH Act changes had a material impact on our income tax provision.

[0001193125-17-248796:mdna:104]
Liquidity and Capital Resources

[0001193125-17-248796:mdna:105]
The
following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days
or less at the time of purchase. Our short-term investments consist primarily of money market funds, time deposits and certificates of deposit. The principal objectives of our investment policy are the preservation of principal and maintenance of
liquidity. We believe our cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we
believe our sources of cash have been and will continue to be sufficient to meet our cash needs for the next 12 months. We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents
or short-term investments and we do not believe the fair value of our short-term investments has significantly changed from the values reported as of June 30, 2017.

[0001193125-17-248796:mdna:106]
Cash and Cash Equivalents and Short-term Investments

[0001193125-17-248796:mdna:107]
|  |  | As of |  |
| (Dollars in millions) |  | June 30,2017 |  |  | July 1,2016 |  |  | Change |  |
| Cash and cash equivalents |  | $ | 2,539 |  |  | $ | 1,125 |  |  | $ | 1,414 |  |
| Short-term investments |  |  | — |  |  |  | 6 |  |  |  | (6 | ) |
| Total |  | $ | 2,539 |  |  | $ | 1,131 |  |  | $ | 1,408 |  |

[0001193125-17-248796:mdna:108]
Our cash and cash equivalents and short-term investments increased by $1,408 million
from July 1, 2016 as a result of net cash provided by operating activities and the proceeds from the issuance of $750 million of 4.25% Senior Notes due 2022 and $500 million of 4.875% Senior Notes due 2024. These cash inflows were
partially offset by net cash outflows for capital expenditures of $434 million, dividends paid to our shareholders of $561 million, repurchase of our ordinary shares of $460 million and early redemption and repurchase of debt of
$316 million. The following table summarizes results from the statement of cash flows for the periods indicated:

[0001193125-17-248796:mdna:109]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 30,2017 |  |  | July 1,2016 |  |  | July 3,2015 |  |
| Net cash flow provided by (used in): |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating activities |  | $ | 1,916 |  |  | $ | 1,680 |  |  | $ | 2,650 |  |
| Investing activities |  |  | (459 | ) |  |  | (1,211 | ) |  |  | (1,287 | ) |
| Financing activities |  |  | (46 | ) |  |  | (1,820 | ) |  |  | (1,495 | ) |
| Effect of foreign currency exchange rates |  |  | — |  |  |  | (3 | ) |  |  | (20 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 1,411 |  |  | $ | (1,354 | ) |  | $ | (152 | ) |

[0001193125-17-248796:mdna:110]
Cash Provided by Operating Activities

[0001193125-17-248796:mdna:111]
Cash provided by operating activities for fiscal year 2017 was approximately $1.9 billion and includes the effects of net income adjusted
for non-cash items including depreciation and amortization, share-based compensation, and:

[0001193125-17-248796:mdna:112]
|  | • |  | a decrease of $122 million in accounts receivable, primarily due to a decrease in revenue and improved collections; and |

[0001193125-17-248796:mdna:113]
|  | • |  | an increase of $121 million in accounts payable, primarily due to timing of payments of material purchases; offset by |

[0001193125-17-248796:mdna:114]
|  | • |  | an increase of $114 million in inventory, primarily due to an increase in units built in connection with our manufacturing footprint consolidating activities. |

[0001193125-17-248796:mdna:115]
Cash provided by operating activities for fiscal year 2016 was approximately $1.7 billion and includes the effects of net income adjusted
for non-cash items including depreciation and amortization, share-based compensation, and:

[0001193125-17-248796:mdna:116]
|  | • |  | a decrease in revenue accelerated by a reduction in the cash conversion cycle, leading to a decrease in working capital. |

[0001193125-17-248796:mdna:117]
Cash provided by operating activities for fiscal year 2015 was approximately $2.7 billion and includes the effects of net income adjusted
for non-cash items including depreciation and amortization, share-based compensation, and:

[0001193125-17-248796:mdna:118]
|  | • |  | a partial payment of $773 million for the arbitration award and related accrued interest received from Western Digital; and |

[0001193125-17-248796:mdna:119]
|  | • |  | a $225 million payment related to the final audit assessment received from the Jiangsu Province State Tax Bureau of the People’s Republic of China for tax and interest associated with changes to our tax filings for the calendar years 2007 through 2013. |

[0001193125-17-248796:mdna:120]
Cash Used in Investing Activities

[0001193125-17-248796:mdna:121]
In fiscal year 2017, we used $459 million for net cash investing activities, which was primarily due to payments for the purchase of
property, equipment and leasehold improvements of approximately $434 million.

[0001193125-17-248796:mdna:122]
In fiscal year 2016, we used $1.2 billion for net
cash investing activities, which was primarily due to payments for the purchase of property, equipment and leasehold improvements of approximately $587 million and the acquisition of Dot Hill, net of cash acquired for $634 million.

[0001193125-17-248796:mdna:123]
In fiscal year 2015, we used $1.3 billion or net cash investing activities, which was primarily due to payments for the purchase of
property, equipment and leasehold improvements of approximately $747 million and the acquisition of LSI’s Flash Business for $450 million.

[0001193125-17-248796:mdna:124]
Cash Used in Financing Activities

[0001193125-17-248796:mdna:125]
Net cash used in financing activities of $46 million for fiscal year 2017 was primarily attributable to the following activities:

[0001193125-17-248796:mdna:126]
|  | • |  | net proceeds of $1.2 billion received from issuance of $750 million of 4.25% Senior Notes due 2022 and $500 million of 4.875% Senior Notes due 2024; |

[0001193125-17-248796:mdna:127]
|  | • |  | $86 million in proceeds from the issuance of ordinary shares under employee stock plans, offset by |

[0001193125-17-248796:mdna:128]
43

[0001193125-17-248796:mdna:129]
|  | • |  | $561 million in dividend payments; |

[0001193125-17-248796:mdna:130]
|  | • |  | $460 million paid to repurchase 12 million of our ordinary shares; |

[0001193125-17-248796:mdna:131]
|  | • |  | $316 million of redemption and repurchase of long-term debt; and |

[0001193125-17-248796:mdna:132]
|  | • |  | $27 million paid for taxes related to net share settlement of equity awards. |

[0001193125-17-248796:mdna:133]
Net cash
used in financing activities of $1.8 billion for fiscal year 2016 was primarily attributable to the following activities:

[0001193125-17-248796:mdna:134]
|  | • |  | $1.1 billion paid to repurchase 24 million of our ordinary shares; and |

[0001193125-17-248796:mdna:135]
|  | • |  | $0.7 billion in dividends paid to our shareholders. |

[0001193125-17-248796:mdna:136]
Net cash used in financing
activities of $1.5 billion for fiscal year 2015 was primarily attributable to the following activities:

[0001193125-17-248796:mdna:137]
|  | • |  | $1.1 billion paid to repurchase 19 million of our ordinary shares; |

[0001193125-17-248796:mdna:138]
|  | • |  | $1.0 billion for the repurchase and redemption of long-term debt; |

[0001193125-17-248796:mdna:139]
|  | • |  | $0.7 billion in dividends paid to our shareholders; partially offset by |

[0001193125-17-248796:mdna:140]
|  | • |  | proceeds of $1.2 billion from aggregate cash generated from the issuance of our 5.75% Senior Notes due 2034 and 4.875% Senior Notes due 2027. |

[0001193125-17-248796:mdna:141]
Liquidity Sources

[0001193125-17-248796:mdna:142]
Our
primary sources of liquidity as of June 30, 2017, consisted of: (1) approximately $2.5 billion in cash and cash equivalents, (2) a $700 million senior revolving credit facility and (3) cash we expect to generate from
operations.

[0001193125-17-248796:mdna:143]
As of June 30, 2017, no borrowings had been drawn under the revolving credit facility or had been utilized for letters
of credit issued under this credit facility. The line of credit is available for borrowings through January 15, 2020, subject to compliance with financial covenants, other customary conditions to borrowing and investment grade ratings. If the
Company does not have investment grade ratings (as defined in the revolving credit facility) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied.

[0001193125-17-248796:mdna:144]
The credit agreement that governs our revolving credit facility, as amended, contains certain covenants that we must satisfy in order to
remain in compliance with the credit agreement, as amended. The agreement includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage
ratio. On April 28, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to adjust for our current financial liquidity position. We were in compliance with the modified covenants as of
June 30, 2017 and expect to be in compliance for the next 12 months.

[0001193125-17-248796:mdna:145]
As of June 30, 2017, cash and cash equivalents held by non-Irish subsidiaries was $2.5 billion. This amount is potentially subject to taxation in Ireland upon repatriation by means of a dividend into our Irish parent. However, it is our intent to indefinitely
reinvest earnings of non-Irish subsidiaries outside of Ireland and our current plans do not demonstrate a need to repatriate such earnings by means of a taxable Irish dividend. Should funds be needed in
the Irish parent company and should we be unable to fund parent company activities through means other than a taxable Irish dividend, we would be required to accrue and pay Irish taxes on such dividend.

[0001193125-17-248796:mdna:146]
We believe that our sources of cash will be sufficient to fund our operations and meet our cash requirements for at least the next
12 months.

[0001193125-17-248796:mdna:147]
Cash Requirements and Commitments

[0001193125-17-248796:mdna:148]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled
payments of principal and interest on our indebtedness, and to fund our quarterly dividend. Our ability to fund these requirements will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to
prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001193125-17-248796:mdna:149]
On
July 25, 2017, our Board of Directors declared a quarterly cash dividend of $0.63 per share, which will be payable on October 4, 2017 to shareholders of record as of the close of business on September 20, 2017.

[0001193125-17-248796:mdna:150]
As of June 30, 2017, we were in compliance with all of the covenants under our debt agreements. Based on our current outlook, we expect
to be in compliance with the covenants of our debt agreements over the next 12 months.

[0001193125-17-248796:mdna:151]
The carrying value of our long-term debt as of June 30, 2017 and July 1, 2016 was
5.0 billion and $4.1 billion, respectively. The table below presents the principal amounts of our outstanding long-term debt:

[0001193125-17-248796:mdna:152]
|  |  | As of |  |
| (Dollars in millions) |  | June 30,2017 |  |  | July 1,2016 |  |  | Change |  |
| 3.75% Senior Notes due November 2018 |  | $ | 710 |  |  | $ | 800 |  |  | $ | (90 | ) |
| 7.00% Senior Notes due November 2021 |  |  | — |  |  |  | 158 |  |  |  | (158 | ) |
| 4.250% Senior Notes due March 2022 |  |  | 750 |  |  |  | — |  |  |  | 750 |  |
| 4.75% Senior Notes due June 2023 |  |  | 951 |  |  |  | 990 |  |  |  | (39 | ) |
| 4.875% Senior Notes due March 2024 |  |  | 500 |  |  |  | — |  |  |  | 500 |  |
| 4.75% Senior Notes due January 2025 |  |  | 975 |  |  |  | 995 |  |  |  | (20 | ) |
| 4.875% Senior Notes due June 2027 |  |  | 697 |  |  |  | 700 |  |  |  | (3 | ) |
| 5.75% Senior Notes due December 2034 |  |  | 490 |  |  |  | 490 |  |  |  | — |  |
|  |  | $ | 5,073 |  |  | $ | 4,133 |  |  | $ | 940 |  |

[0001193125-17-248796:mdna:153]
From time to time we may repurchase any of our outstanding ordinary shares through private, open market,
tender offers, broker assisted purchases or other means. During fiscal year 2017, we repurchased approximately 13 million of our ordinary shares including statutory tax withholdings related to vesting of employee equity awards. See
“Item 5. Market for Registrant’s Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities-Repurchases of Our Equity Securities.” As of June 30, 2017, $1.3 billion remained available for
repurchase under our existing repurchase authorization limit. All repurchases are effected as redemptions in accordance with the Company’s Articles of Association.

[0001193125-17-248796:mdna:154]
For fiscal year 2018, we expect capital expenditures to be less than 5% of revenue. We require substantial amounts of cash to fund any
increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We will continue to evaluate and manage the retirement and replacement of existing debt
and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers
or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions and investments, which may require additional capital.

[0001193125-17-248796:mdna:155]
Contractual Obligations and Commitments

[0001193125-17-248796:mdna:156]
Our contractual cash obligations and commitments as of June 30, 2017, have been summarized in the table below:

[0001193125-17-248796:mdna:157]
|  |  |  |  |  | Fiscal Year(s) |  |
| (Dollars in millions) |  | Total |  |  | 2018 |  |  | 2019-2020 |  |  | 2021-2022 |  |  | Thereafter |  |
| Contractual Cash Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | $ | 5,073 |  |  | $ | — |  |  | $ | 710 |  |  | $ | 750 |  |  | $ | 3,613 |  |
| Interest payments on debt |  |  | 1,848 |  |  |  | 241 |  |  |  | 433 |  |  |  | 420 |  |  |  | 754 |  |
| Purchase obligations (1) |  |  | 1,484 |  |  |  | 959 |  |  |  | 525 |  |  |  | — |  |  |  | — |  |
| Operating leases (2) |  |  | 135 |  |  |  | 19 |  |  |  | 26 |  |  |  | 15 |  |  |  | 75 |  |
| Capital expenditures |  |  | 107 |  |  |  | 107 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other funding requirements (3) |  |  | 30 |  |  |  | 12 |  |  |  | 18 |  |  |  | — |  |  |  | — |  |
| Subtotal |  |  | 8,677 |  |  |  | 1,338 |  |  |  | 1,712 |  |  |  | 1,185 |  |  |  | 4,442 |  |
| Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit or bank guarantees |  |  | 106 |  |  |  | 106 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 8,783 |  |  | $ | 1,444 |  |  | $ | 1,712 |  |  | $ | 1,185 |  |  | $ | 4,442 |  |

[0001193125-17-248796:mdna:158]
| (1) | Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. |

[0001193125-17-248796:mdna:159]
| (2) | Includes total future minimum rent expense under non-cancelable leases for both occupied and vacated facilities (rent expense is shown net of sublease income). |

[0001193125-17-248796:mdna:160]
| (3) | Consists of funding requirements related to strategic commitments. |

[0001193125-17-248796:mdna:161]
45

[0001193125-17-248796:mdna:162]
As of June 30, 2017, we had a liability for unrecognized tax benefits and an accrual
for the payment of related interest totaling $15 million, none of which is expected to be settled within one year. Outside of one year, we are unable to make a reasonably reliable estimate of when cash settlement with a taxing authority will
occur.

[0001193125-17-248796:mdna:163]
Off-Balance Sheet Arrangements

[0001193125-17-248796:mdna:164]
As of June 30, 2017, we did not have any material off-balance sheet arrangements (as defined in
Item 303(a)(4)(ii) of Regulation S-K).

[0001193125-17-248796:mdna:165]
Accounting Policies

[0001193125-17-248796:mdna:166]
The methods, estimates and judgments we use in applying our most critical accounting policies have a significant impact on the results we
report in our consolidated financial statements. The SEC has defined the most critical accounting policies as the ones that are most important to the portrayal of our financial condition and operating results, and require us to make our most
difficult and subjective judgments, often as a result of the need to make estimates of matters that are highly uncertain at the time of estimation. Based on this definition, our most critical policies include: establishment of sales program
accruals, establishment of warranty accruals, accounting for income taxes, and the accounting for goodwill and other long-lived assets. Below, we discuss these policies further, as well as the estimates and judgments involved. We also have other
accounting policies and accounting estimates relating to uncollectible customer accounts, valuation of inventory, valuation of share-based payments and restructuring. We believe that these other accounting policies and accounting estimates either do
not generally require us to make estimates and judgments that are as difficult or as subjective, or it is less likely that they would have a material impact on our reported results of operations for a given period.

[0001193125-17-248796:mdna:167]
Establishment of Sales Program Accruals. We establish certain distributor and OEM sales programs aimed at increasing customer
demand. For OEM sales, rebates are typically based on an OEM customer’s volume of purchases or other agreed upon rebate programs. For the distribution channel, these programs typically involve rebates related to a distributor’s level of
sales, order size, advertising or point of sale activity and price protection adjustments. We provide for these obligations at the time that revenue is recorded based on estimated requirements. We estimate these contra-revenue rebates and
adjustments based on various factors, including price reductions during the period reported, estimated future price erosion, customer orders, distributor sell-through and inventory levels, program participation, customer claim submittals and sales
returns. Our estimates reflect contractual arrangements but also our judgment relating to variables such as customer claim rates and attainment of program goals, and inventory and sell-through levels reported by our distribution customers.
Currently, our distributors’ inventories are within the historical range.

[0001193125-17-248796:mdna:168]
While we believe we have sufficient experience and
knowledge of the market and customer buying patterns to reasonably estimate such rebates and adjustments, actual market conditions or customer behavior could differ from our expectations. As a result, actual payments under these programs, which may
spread over several months after the related sale, may vary from the amount accrued. Accordingly, revenues and margins in the period in which the adjustment occurs may be affected.

[0001193125-17-248796:mdna:169]
Significant actual variations in any of the factors upon which we base our contra-revenue estimates could have a material effect on our
operating results. In fiscal year 2017, sales programs were approximately 11% of gross revenue. For fiscal years 2016 and 2015, total sales programs of gross revenues were 13% and 10%, respectively. Adjustments to revenues due to under or over
accruals for sales programs related to revenues reported in prior quarterly periods were less than 1% of gross revenue in fiscal years 2017, 2016 and 2015. Any future shifts in the industry supply-demand balance as well as other factors may result
in a more competitive pricing environment and may cause sales programs as a percentage of gross revenue to increase from the current or historical levels. If such rebates and incentives trend upwards, revenues and margins may be reduced.

[0001193125-17-248796:mdna:170]
Establishment of Warranty Accruals. We estimate probable product warranty costs at the time revenue is recognized. We generally
warrant our products for a period of 1 to 5 years. Our warranty provision considers estimated product failure rates and trends (including the timing of product returns during the warranty periods), and estimated repair or replacement costs related
to product quality issues, if any. We also exercise judgment in estimating our ability to sell certain repaired products. Should actual experience in any future period differ significantly from our estimates, our future results of operations could
be materially affected. Our judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited experience with those products upon which to base our warranty estimates.

[0001193125-17-248796:mdna:171]
The actual results with regard to warranty expenditures could have an adverse or favorable
effect on our results of operations if the actual rate of unit failure, the cost to repair a unit, or the actual cost required to satisfy customer claims differs from those estimates we used in determining the warranty accrual. Since we typically
outsource our warranty repairs, our repair cost is subject to periodic negotiations with vendors and may vary from our estimates. We also exercise judgment in estimating our ability to sell certain repaired products. To the extent such sales fall
below our forecast, warranty cost will be adversely impacted.

[0001193125-17-248796:mdna:172]
We review our warranty accrual quarterly for products shipped in prior
periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in adjustments that impact the current period gross margins and net income. In fiscal years 2017, 2016 and 2015 net changes in estimates of
prior warranty accruals as a percentage of revenue were immaterial. Our total warranty cost was 1.3%, 1.0% and 1.1% of revenue during fiscal years 2017, 2016 and 2015, respectively, while warranty cost related to new shipments (exclusive of the
impact of re-estimates of pre-existing liabilities) were 1.2%, 1.1% and 1.1% respectively, for the same periods. Changes in anticipated failure rates of specific
products and significant changes in repair or replacement costs have historically been the major reasons for significant changes in prior estimates. Any future changes in failure rates of certain products, as well as changes in repair costs or
the cost of replacement parts, may result in increased or decreased warranty accruals.

[0001193125-17-248796:mdna:173]
Accounting for Income Taxes. We
account for income taxes pursuant to Accounting Standards Codification (“ASC”) Topic 740 (“ASC 740”), Income Taxes. In applying, ASC 740, we make certain estimates and judgments in determining income tax expense for
financial statement purposes. These estimates and judgments occur in the calculation of tax credits, recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of
recognition of revenue and expense for tax and financial statement purposes, as well as tax liabilities associated with uncertain tax positions. The calculation of tax liabilities involves uncertainties in the application of complex tax rules and
the potential for future adjustment of our uncertain tax positions by the Internal Revenue Service or other tax jurisdictions. If estimates of these tax liabilities are greater or less than actual results, an additional tax benefit or provision will
result. The deferred tax assets we record each period depend primarily on our ability to generate future taxable income in the United States and certain non-U.S. jurisdictions. Each period, we evaluate the
need for a valuation allowance for our deferred tax assets and, if necessary, we adjust the valuation allowance so that net deferred tax assets are recorded only to the extent we conclude it is more likely than not that these deferred tax assets
will be realized. If our outlook for future taxable income changes significantly, our assessment of the need for a valuation allowance may also change.

[0001193125-17-248796:mdna:174]
Assessing Goodwill and Other Long-lived Assets for Impairment. We account for goodwill in accordance with ASC Topic
350, Intangibles—Goodwill and Other. As permitted by ASC 350, we perform a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or
circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount. Based on the
qualitative assessment, if it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, then the Company is not required to perform the quantitative goodwill impairment test. If it is determined in the
qualitative assessment that the fair value of a reporting unit is more likely than not below its carrying amount, including goodwill, then we perform a quantitative impairment test. The quantitative goodwill impairment test is performed by comparing
the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit’s goodwill over its fair value is recognized as an impairment loss, limited to the total amount of goodwill allocated to that
reporting unit.

[0001193125-17-248796:mdna:175]
In accordance with ASC 360-05-4,
Impairment or Disposal of Long-lived Assets, we test other long-lived assets, including property, equipment and leasehold improvements and other intangible assets subject to amortization, for recoverability whenever events or changes in
circumstances indicate that the carrying values of those assets may not be recoverable. We assess the recoverability of an asset group by determining if the carrying value of the asset group exceeds the sum of the projected undiscounted cash flows
expected to result from the use and eventual disposition of the assets over the remaining economic life of the primary asset in the asset group. If the recoverability test indicates that the carrying value of the asset group is not recoverable, we
will estimate the fair value of the asset group and compare it to its carrying value. The excess of the carrying value over the fair value is allocated pro rata to derive the adjusted carrying value of each asset in the asset group. The adjusted
carrying value of each asset in the asset group is not reduced below its fair value.

[0001193125-17-248796:mdna:176]
47

[0001193125-17-248796:mdna:177]
Recent Accounting Pronouncements

[0001193125-17-248796:mdna:178]
See “Item 8. Financial Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of Significant Accounting
Policies” for information regarding the effect of new accounting pronouncements on our financial statements.
