# STX notes — 0001137789-22-000055


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001137789-22-000055:notes:1]
Portions of the definitive proxy statement to be filed with the Securities and Exchange Commission pursuant to Regulation 14A relating to the registrant’s Annual General Meeting of Shareholders, to be held on October 24, 2022, will be incorporated by reference in this Form 10-K in response to Items 10, 11, 12, 13 and 14 of Part III. The definitive proxy statement will be filed with the SEC no later than 120 days after the registrant's fiscal year ended July 1, 2022.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001137789-22-000055:notes:2]
Basis of Presentation and Summary of Significant Accounting Policies
Organization

[0001137789-22-000055:notes:3]
Seagate Technology Holdings plc (“STX”) and its subsidiaries (collectively, unless the context otherwise indicates, the “Company”) is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”), solid state hybrid drives (“SSHDs”), storage subsystem, as well as a scalable edge-to-cloud mass data platform that includes data transfer shuttles and a storage-as-a-service cloud.

[0001137789-22-000055:notes:4]
On May 18, 2021, Seagate Technology plc, now known as Seagate Technology Unlimited Company (“STUC”), and STX completed a scheme of arrangement pursuant to which STUC’s ordinary shares were acquired by STX and the ordinary shareholders of STUC received, on a one-for-one basis, new ordinary shares of STX (the “Scheme”). As a result of the Scheme, STUC is now a direct, wholly-owned subsidiary of STX, which is the successor issuer to STUC. In connection with the Scheme, STX assumed STUC’s existing obligations in connection with awards granted under STUC’s incentive plans and other similar employee awards and amended such plans and awards as necessary to provide for the issuance of STX’s registered shares rather than the ordinary shares of STUC upon the exercise or vesting of awards.

[0001137789-22-000055:notes:5]
Basis of Presentation and Consolidation

[0001137789-22-000055:notes:6]
The Company’s consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

[0001137789-22-000055:notes:7]
The preparation of financial statements in accordance with the United States (“U.S.”) generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated financial statements and accompanying notes. These estimates and assumptions include the impact of the COVID-19 pandemic. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its consolidated financial statements.

[0001137789-22-000055:notes:8]
Fiscal Year

[0001137789-22-000055:notes:9]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Accordingly, fiscal years 2022 and 2021 both comprised of 52 weeks and ended on July 1, 2022 and July 2, 2021, respectively. Fiscal year 2020 was comprised of 53 weeks and ended on July 3, 2020. All references to years in these Notes to Consolidated Financial Statements represent fiscal years unless otherwise noted. Fiscal year 2026 will also be comprised of 53 weeks and will end on July 3, 2026.

[0001137789-22-000055:notes:10]
Summary of Significant Accounting Policies

[0001137789-22-000055:notes:11]
Cash and Cash Equivalents. The Company considers all highly liquid investments with a remaining maturity of 90 days or less at the time of purchase to be cash equivalents. The Company’s highly liquid investments are primarily comprised of money market funds, time deposits and certificates of deposits. The Company has classified its marketable debt securities as available-for-sale and they are stated at fair value with unrealized gains and losses included in Accumulated other comprehensive income, which is a component of Shareholders’ Equity. The Company evaluates the available-for-sale debt securities in an unrealized loss position for other-than-temporary impairment. Realized gains and losses are included in Other, net on the Company’s Consolidated Statements of Operations. The cost of securities sold is based on the specific identification method. Other cash equivalents are carried at cost, which approximates fair value.

[0001137789-22-000055:notes:12]
Restricted Cash and Cash Equivalents. Restricted cash and cash equivalents represent cash and cash equivalents that are restricted as to withdrawal or use for other than current operations.

[0001137789-22-000055:notes:13]
Allowance for expected credit loss. The Company maintains an allowance for expected credit loss relating to its accounts receivable based upon expected collectability. This reserve is established based upon historical trends, global macroeconomic conditions, reasonable and supportable forecasts of future conditions and an analysis of specific exposures. The provision for expected credit loss is recorded as a charge to Marketing and administrative expense on the Company’s Consolidated Statements of Operations.

[0001137789-22-000055:notes:14]
Inventories. Inventories are valued at the lower of cost (using the first-in, first-out method) and net realizable value. Net realizable value is based upon the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. Adjustments to reduce cost of inventories to its net realizable value are made, if required, for estimated excess or obsolescence determined primarily by future demand forecasts.

[0001137789-22-000055:notes:15]
Property, Equipment and Leasehold Improvements. Property, equipment and leasehold improvements are stated at cost less accumulated depreciation and amortization. Equipment and buildings are depreciated using the straight-line method over the estimated useful lives of the assets. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated life of the asset or the remaining term of the lease. The costs of additions and substantial improvements to property, equipment and leasehold improvements, which extend the economic life of the underlying assets, are capitalized. The cost of maintenance and repairs to property, equipment and leasehold improvements is expensed as incurred.

[0001137789-22-000055:notes:16]
Goodwill. The Company performs a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. If it is determined in the qualitative assessment that the fair value of a reporting unit is more likely than not below its carrying amount, including goodwill, then the Company will perform a quantitative impairment test. The quantitative goodwill impairment test is performed by comparing the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit over its fair value is recognized as an impairment loss, limited to the total amount of goodwill allocated to that reporting unit.

[0001137789-22-000055:notes:17]
Other Long-lived Assets. The Company tests other long-lived assets, including property, equipment and leasehold improvements and other intangible assets subject to amortization, for recoverability whenever events or changes in circumstances indicate that the carrying value of those assets may not be recoverable. The Company performs a recoverability test to assess the recoverability of an asset group. If the recoverability test indicates that the carrying value of the asset group is not recoverable, the Company will estimate the fair value of the asset group and the excess of the carrying value over the fair value is allocated pro rata to derive the adjusted carrying value of assets in the asset group. The adjusted carrying value of each asset in the asset group is not reduced below its fair value.

[0001137789-22-000055:notes:18]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. This review indicated that the actual lives of certain manufacturing equipment at its manufacturing facilities were longer than the estimated useful lives used for depreciation purposes in the Company’s consolidated financial statements. As a result, effective June 29, 2019, the Company changed its estimate of the useful lives of its manufacturing equipment from a range of three to five years to a range of three to seven years. The effect of this change in estimate increased the net income by $134 million for the fiscal year ended July 3, 2020 and increased the diluted earnings per share by $0.51 for the fiscal year ended July 3, 2020.

[0001137789-22-000055:notes:19]
The Company tests other intangible assets not subject to amortization whenever events occur or circumstances change, such as declining financial performance, deterioration in the environment in which the entity operates or deteriorating macroeconomic conditions that have a negative effect on future expected earnings and cash flows that could affect significant inputs used to determine the fair value of the indefinite-lived intangible asset.

[0001137789-22-000055:notes:20]
Assets Held for Sale. The Company classifies its long-lived assets to be sold as held for sale in the period (i) it has approved and committed to a plan to sell the asset, (ii) the asset is available for immediate sale in its present condition, (iii) an active program to locate a buyer and other actions required to sell the asset have been initiated, (iv) the sale of the asset is probable, (v) the asset is being actively marketed for sale at a price that is reasonable in relation to its current fair value and (vi) it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn. The Company initially measures a long-lived asset that is classified as held for sale at the lower of its carrying value or fair value less any costs to sell. Any loss resulting from this measurement is recognized in the period in which the held for sale criteria are met. Conversely, gains are not recognized on the sale of a long-lived asset until the date of sale. Upon designation as an asset held for sale, the Company stops recording depreciation expense on the asset. The Company assesses the fair value of a long-lived asset less any costs to sell at each reporting period and until the asset is no longer classified as held for sale.

[0001137789-22-000055:notes:21]
Leases. The Company determines if an arrangement is a lease or contains a lease at inception. Right-of-use (“ROU”) assets are included in Other assets, net and lease liabilities are included in Accrued expenses and Other non-current liabilities on the Company’s Consolidated Balance Sheets. ROU assets represent the Company’s right to use an underlying asset for the lease term and the corresponding lease liabilities represent its obligation to make lease payments arising from the lease. The Company combines lease and non-lease components for facility leases and does not recognize ROU assets and lease liabilities for leases with an initial term of 12 months or less on the consolidated balance sheets.

[0001137789-22-000055:notes:22]
Lease liabilities are measured at the present value of the remaining lease payments and ROU assets are based on the lease liability, adjusted for lease prepayments, lease incentives received and the lessee’s initial direct costs. For the Company’s leases that do not provide an implicit rate, the net present value of future minimum lease payments is determined using the Company’s estimated incremental borrowing rate based on the information available at the lease commencement date. Additionally, the

[0001137789-22-000055:notes:23]
Company’s lease term may include options to extend or terminate the lease. These options are reflected in the ROU asset and lease liability when it is reasonably certain that the Company will exercise the option. The Company’s lease agreements do not contain any material residual value guarantees.

[0001137789-22-000055:notes:24]
The Company recognizes lease expense on a straight-line basis over the lease term. Variable lease payments not dependent on an index or a rate primarily consist of common area maintenance charges, are expensed as incurred, and are not included in the ROU asset and lease liability calculation. The total operating and variable lease costs were included in operating expenses in the Company’s Consolidated Statements of Operations.

[0001137789-22-000055:notes:25]
Derivative Financial Instruments. The Company records all derivatives on the balance sheet at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company excludes the change in forward points from the assessment of hedge effectiveness and recognizes the excluded component in Other, net in the Consolidated Statements of Operations. Foreign currency forward exchange contracts not designated as hedge instruments are used to economically hedge the foreign currency exposure on forecasted expenditures in currencies other than U.S. dollar. The Company recognizes the unrealized gains and losses due to the changes in the fair value of these contracts, as well as the related costs in Other, net in the Consolidated Statements of Operations.

[0001137789-22-000055:notes:26]
Warranty. The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally provides warranty on its products for a period of 1 to 5 years. The Company's warranty provision considers estimated product failure rates, trends (including the timing of product returns during the warranty periods), and estimated repair or replacement costs related to product quality issues, if any. The Company also exercises judgement in estimating its ability to sell refurbished products.

[0001137789-22-000055:notes:27]
Revenue Recognition and Sales Incentive Programs. The Company determines revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, the Company satisfies a performance obligation.

[0001137789-22-000055:notes:28]
Revenue from sales of products is generally recognized upon transfer of control to customers in an amount that reflects the consideration the Company expects to receive in exchange for those products, net of sales taxes. This typically occurs upon shipment from the Company. When applicable, the Company includes shipping charges billed to customers in Revenue and includes the related shipping costs in Cost of revenue on the Company's Consolidated Statements of Operations.

[0001137789-22-000055:notes:29]
The Company records estimated variable consideration at the time of revenue recognition as a reduction to revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For original equipment manufacturers (“OEMs”) sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer’s volume of purchases from the Company or other agreed upon rebate programs. For the distribution and retail channel, these programs typically involve estimating the most likely amount of rebates related to a customer’s level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Marketing development program costs are accrued and recorded as a reduction to revenue at the same time that the related revenue is recognized.

[0001137789-22-000055:notes:30]
The Company expenses sales commissions as incurred because the amortization period would have been one year or less. These costs are recorded as Marketing and administrative on the Company’s Consolidated Statements of Operations.

[0001137789-22-000055:notes:31]
Restructuring Costs. The timing of recognition for severance costs depends on whether employees are required to render service until they are terminated in order to receive the termination benefits. If employees are required to render service until they are terminated in order to receive the termination benefits, a liability is recognized ratably over the future service period. Otherwise, a liability is recognized when management has committed to a restructuring plan and has communicated those actions to employees. Employee termination benefit costs covered by existing benefit arrangements are recognized when management has committed to a restructuring plan and the severance costs are probable and estimable.

[0001137789-22-000055:notes:32]
Advertising Expense. The cost of advertising is expensed as incurred. Advertising costs were approximately $34 million, $29 million and $19 million in fiscal years 2022, 2021 and 2020, respectively.

[0001137789-22-000055:notes:33]
Share-Based Compensation. The Company accounts for share-based compensation net of estimated forfeitures. Refer to Note 11. Share-Based Compensation for details.

[0001137789-22-000055:notes:34]
Accounting for Income Taxes. The Company records a provision or benefit for income taxes for the anticipated tax consequences of the reported results of operations using the asset and liability method. Deferred income tax expense or benefit is recognized by applying enacted statutory tax rates applicable to future years to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases as well as net operating loss and tax credit carryforwards. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that

[0001137789-22-000055:notes:35]
includes the enactment date. The measurement of deferred tax assets is reduced, if necessary, by a valuation allowance for any tax benefits for which future realization is uncertain.

[0001137789-22-000055:notes:36]
The Company recognizes a tax benefit only if it is more likely than not the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon settlement.

[0001137789-22-000055:notes:37]
Equity Investments. From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives, which are accounted for either under equity method or the measurement alternative. These investments are included in Other assets, net in the Company's Consolidated Balance Sheets and are adjusted through Other, net in the Consolidated Statement of Operations.

[0001137789-22-000055:notes:38]
Investments are accounted for under the equity method if the Company has the ability to exercise significant influence, but does not have a controlling financial interest. These investments are measured at cost, less any impairment plus the Company's portion of investee’s income or loss. The Company uses the financial statements of investees to determine any adjustments, which are received on a one-quarter lag.

[0001137789-22-000055:notes:39]
For equity investments where the Company does not have the ability to exercise significant influence and there are no readily determinable fair values, the Company has elected to apply the measurement alternative, under which investments are measured at cost, less impairment, and adjusted for qualifying observable price changes on a prospective basis.

[0001137789-22-000055:notes:40]
The Company’s strategic investments are periodically analyzed to determine whether or not there are indicators of impairment by assessing factors such as deterioration of earnings, adverse change in market/industry conditions, the ability to operate as a going concern, and other factors which indicate that the carrying amount of the investment might not be recoverable. In such a case, the decrease in value is recognized in the period the impairment occurs in the Consolidated Statements of Operations.

[0001137789-22-000055:notes:41]
Comprehensive Income. The Company presents comprehensive income in a separate statement. Comprehensive income is comprised of net income and other gains and losses affecting equity that are excluded from net income.

[0001137789-22-000055:notes:42]
Foreign Currency Remeasurement and Translation. The U.S. dollar is the functional currency for the majority of the Company's foreign operations. Monetary assets and liabilities denominated in foreign currencies are remeasured into the functional currency of the subsidiary at the balance sheet date. The gains and losses from the remeasurement of foreign currency denominated balances into the functional currency of the subsidiary are included in Other, net on the Company's Consolidated Statements of Operations. The Company’s subsidiaries that use the U.S. dollar as their functional currency remeasure monetary assets and liabilities at exchange rates in effect at the end of each period, and nonmonetary assets and liabilities at historical rates.

[0001137789-22-000055:notes:43]
The Company translates the assets and liabilities of its non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recognized in foreign currency translation included in Accumulated other comprehensive income, which is a component of Shareholders’ Equity.

[0001137789-22-000055:notes:44]
Concentrations

[0001137789-22-000055:notes:45]
Concentration of Credit Risk. The Company’s customer base is concentrated with a small number of customers. The Company does not generally require collateral or other security to support accounts receivable. To reduce credit risk, the Company performs ongoing credit evaluations on its customers’ financial condition. The Company establishes allowances for expected credit losses based upon factors surrounding the credit risk of customers, global macroeconomic conditions and an analysis of specific exposures. One customer accounted for 20% and 11% of the Company’s accounts receivable as of July 1, 2022 and July 2, 2021, respectively.

[0001137789-22-000055:notes:46]
Financial instruments that potentially subject the Company to concentrations of credit risk consist primarily of cash equivalents, investments and foreign currency forward exchange contracts. The Company mitigates concentrations of credit risk in its financial instruments through diversification, by investing in highly-rated securities and/or major multinational companies.

[0001137789-22-000055:notes:47]
In entering into foreign currency forward exchange contracts, the Company assumes the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial and investment banks, and the Company has not incurred and does not expect any losses as a result of counterparty defaults.

[0001137789-22-000055:notes:48]
Supplier Concentration. Certain of the raw materials, components and equipment used by the Company in the manufacture of its products are available from single-sourced direct and indirect vendors. Shortages could occur in these essential materials and components due to an interruption of supply or increased demand in the industry. If the Company were unable to procure certain materials, components or equipment at all or acceptable prices, it would be required to reduce its manufacturing operations, which could have a material adverse effect on its results of operations. In addition, the Company may make prepayments to certain suppliers or enter into minimum volume commitment agreements. Should these suppliers be unable to deliver on their obligations or experience financial difficulty, the Company may not be able to recover these prepayments.

[0001137789-22-000055:notes:49]
Recently Issued Accounting Pronouncements

[0001137789-22-000055:notes:50]
In March 2020, the FASB issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. Adoption of the expedients and exceptions is permitted upon issuance of this update through December 31, 2022. The Company does not expect the adoption of this ASU to have a material impact on its consolidated financial statements.

[0001137789-22-000055:notes:51]
In November 2021, the FASB issued ASU 2021-10 (ASC Topic 832), Disclosures by Business Entities about Government Assistance. This ASU requires annual disclosures that increase the transparency of transactions involving government grants, including (1) the type of transactions, (2) the accounting for those transactions and (3) the effect of those transactions on an entity’s financial statements. The Company will adopt this new guidance beginning first quarter of fiscal year 2023 on a prospective basis and plans to disclose the aforementioned requirements in consolidated financial statements for the fiscal year ended June 30, 2023.

[0001137789-22-000055:notes:52]
In June 2022, the FASB issued ASU 2022-03 (ASC Topic 820), Fair Value Measurement of Equity Securities Subject to Contractual Sale Restrictions. This ASU clarifies that a contractual restriction on the sale of equity security is not considered when measuring its fair value and requires new disclosures for equity securities subject to contractual sale restriction. The Company is required to adopt this guidance in the first quarter of fiscal year 2025. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

[0001137789-22-000055:notes:53]
Recently Adopted Accounting Pronouncements

[0001137789-22-000055:notes:54]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued ASU 2019-12 (ASC Topic 740), Simplifying the Accounting for Income Taxes. This ASU simplifies accounting for income taxes by removing certain exceptions to the general principles and amending existing guidance to improve consistent application. This ASU became effective and the Company adopted the guidance in the quarter ended October 1, 2021. The adoption of this ASU did not have an impact on the Company’s consolidated financial statements.

[0001137789-22-000055:notes:55]
In July 2021, the FASB issued ASU 2021-05 (ASC Topic 842), Lessors—Certain Leases with Variable Lease Payments. This ASU requires lessors to classify and account for a lease with variable lease payments that do not depend on a reference index or a rate as an operating lease if the lease would have been classified as a sales-type lease or a direct financing lease and the lessor would have otherwise recognized a day-one loss. The Company adopted the guidance in the quarter ended October 1, 2021 on a prospective basis. The adoption of this ASU did not have an impact on the Company’s consolidated financial statements.


## us-gaap:DerivativesPolicyTextBlock

[0001137789-22-000055:notes:56]
Derivative Financial Instruments. The Company records all derivatives on the balance sheet at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company excludes the change in forward points from the assessment of hedge effectiveness and recognizes the excluded component in Other, net in the Consolidated Statements of Operations. Foreign currency forward exchange contracts not designated as hedge instruments are used to economically hedge the foreign currency exposure on forecasted expenditures in currencies other than U.S. dollar. The Company recognizes the unrealized gains and losses due to the changes in the fair value of these contracts, as well as the related costs in Other, net in the Consolidated Statements of Operations.
The Company is exposed to foreign currency exchange rate, interest rate and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies.

[0001137789-22-000055:notes:57]
The Company has entered into certain interest rate swap agreements to convert the variable interest rate on its Term Loans to fixed interest rates. The objective of the interest rate swap agreements is to eliminate the variability of interest payment cash flows associated with the variable interest rate under the Term Loans. The Company designated the interest rate swaps as cash flow hedges. As of July 1, 2022, the aggregate notional amount of the Company’s interest-rate swap contracts was $1.2 billion, of which $600 million will mature in September 2025 and $600 million will mature in July 2027.

[0001137789-22-000055:notes:58]
The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives on its Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in Accumulated other comprehensive income until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The amount of net unrealized gain on cash flow hedges was $51 million and net unrealized loss was $18 million as of July 1, 2022 and as of July 2, 2021, respectively. As of July 1, 2022, the amount of existing net gains related to cash flow hedges recorded in Accumulated other comprehensive income included a net gain of $8 million that is expected to be reclassified to earnings within twelve months.
The Company de-designates its cash flow hedges when the forecasted hedged transactions affect earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive income on the Company’s Consolidated Balance Sheets are reclassified into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001137789-22-000055:notes:59]
Balance Sheet Information
Available-for-sale Debt Securities

[0001137789-22-000055:notes:60]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of July 1, 2022 and July 2, 2021:

[0001137789-22-000055:notes:61]
|  |  | July 1,2022 |  | July 2,2021 |
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |  | $ | 552 |  |  | $ | — |  |  | $ | 552 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 23 |  |  | — |  |  | 23 |  |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |  | $ | 571 |  |  | $ | — |  |  | $ | 571 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 59 |  |  |  |  |  |  | $ | 551 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 23 |  |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 84 |  |  |  |  |  |  | $ | 571 |  |

[0001137789-22-000055:notes:62]
As of July 1, 2022 and July 2, 2021, the Company’s Other current assets included $2 million in restricted cash equivalents held as collateral at banks for various performance obligations.

[0001137789-22-000055:notes:63]
As of July 1, 2022 and July 2, 2021, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. During fiscal year 2022, the Company recorded a $13 million impairment loss relating to available-for-sale debt securities. The Company determined no impairment related to credit losses for available-for-sale debt securities as of July 2, 2021.

[0001137789-22-000055:notes:64]
The fair value and amortized cost of the Company’s investments classified as available-for-sale debt securities at July 1, 2022 by remaining contractual maturity were as follows:

[0001137789-22-000055:notes:65]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 61 |  |  | $ | 61 |  |
| Due in 1 to 5 years |  | 15 |  |  | 15 |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | 8 |  |  | 8 |  |
| Total |  | $ | 84 |  |  | $ | 84 |  |

[0001137789-22-000055:notes:66]
Cash, Cash Equivalents and Restricted Cash

[0001137789-22-000055:notes:67]
The following table provides a summary of cash, cash equivalents and restricted cash reported within the Consolidated Balance Sheets that reconciles to the corresponding amount in the Consolidated Statements of Cash Flows:

[0001137789-22-000055:notes:68]
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |  | July 3,2020 |  | June 28,2019 |
| Cash and cash equivalents |  | $ | 615 |  |  | $ | 1,209 |  |  | $ | 1,722 |  |  | $ | 2,220 |  |
| Restricted cash included in Other current assets |  | 2 |  |  | 2 |  |  | 2 |  |  | 31 |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  | $ | 617 |  |  | $ | 1,211 |  |  | $ | 1,724 |  |  | $ | 2,251 |  |

[0001137789-22-000055:notes:69]
As of June 28, 2019, the Company’s Other current assets included $31 million in restricted cash and cash equivalents in an escrow account for the sale of certain properties and cash equivalents held as collateral at banks for various performance obligations.

[0001137789-22-000055:notes:70]
Accounts Receivable, net

[0001137789-22-000055:notes:71]
The following table provides details of the accounts receivable, net balance sheet item:

[0001137789-22-000055:notes:72]
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |
| Accounts receivable |  | $ | 1,536 |  |  | $ | 1,162 |  |
| Allowances for expected credit losses |  | (4) |  |  | (4) |  |
| Account receivable, net |  | $ | 1,532 |  |  | $ | 1,158 |  |

[0001137789-22-000055:notes:73]
Activity in the expected credit losses accounts is as follows:

[0001137789-22-000055:notes:74]
| (Dollars in millions) |  | Balance at Beginning of Period |  | Charges (Credit) to Operations |  | Deductions (1) |  | Balance at End of Period |
| Fiscal year ended July 3, 2020 |  | $ | 4 |  |  | 1 |  |  | — |  |  | $ | 5 |  |
| Fiscal year ended July 2, 2021 |  | $ | 5 |  |  | — |  |  | (1) |  |  | $ | 4 |  |
| Fiscal year ended July 1, 2022 |  | $ | 4 |  |  | — |  |  | — |  |  | $ | 4 |  |

[0001137789-22-000055:notes:75]
______________________________________________

[0001137789-22-000055:notes:76]
(1)    Uncollectible accounts written off, net of recoveries.

[0001137789-22-000055:notes:77]
In connection with an existing factoring agreement, the Company sells trade receivables to a third party for cash proceeds less a discount. During fiscal year 2022, the Company sold trade receivables without recourse for cash proceeds of $275 million, of which $200 million remained subject to servicing by the Company as of July 1, 2022. During fiscal year 2021, the Company sold trade receivables without recourse for cash proceeds of $183 million, of which none remained subject to servicing by the Company as of July 2, 2021. The discounts on trade receivables sold were not material for fiscal years 2022 and 2021.

[0001137789-22-000055:notes:78]
Inventories

[0001137789-22-000055:notes:79]
The following table provides details of the inventory balance sheet item:

[0001137789-22-000055:notes:80]
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |
| Raw materials and components |  | $ | 601 |  |  | $ | 375 |  |
| Work-in-process |  | 414 |  |  | 443 |  |
| Finished goods |  | 550 |  |  | 386 |  |
| Total inventories |  | $ | 1,565 |  |  | $ | 1,204 |  |

[0001137789-22-000055:notes:81]
Property, Equipment and Leasehold Improvements, net

[0001137789-22-000055:notes:82]
The components of property, equipment and leasehold improvements, net were as follows:

[0001137789-22-000055:notes:83]
| (Dollars in millions) |  | Useful Life in Years |  | July 1,2022 |  | July 2,2021 |
| Land and land improvements |  |  |  | $ | 47 |  |  | $ | 47 |  |
| Equipment |  | 3 – 7 |  | 8,473 |  |  | 8,250 |  |
| Buildings and leasehold improvements |  | Up to 30 |  | 1,893 |  |  | 1,881 |  |
| Construction in progress |  |  |  | 246 |  |  | 200 |  |
|  |  |  |  | 10,659 |  |  | 10,378 |  |
| Less: accumulated depreciation and amortization |  |  |  | (8,420) |  |  | (8,197) |  |
| Property, equipment and leasehold improvements, net |  |  |  | $ | 2,239 |  |  | $ | 2,181 |  |

[0001137789-22-000055:notes:84]
Depreciation expense, which includes amortization of leasehold improvements, was $431 million, $368 million and $325 million for fiscal years 2022, 2021 and 2020, respectively. Interest on borrowings related to eligible capital expenditures is capitalized as part of the cost of the qualified assets and amortized over the estimated useful lives of the assets. During fiscal years 2022, 2021 and 2020, the Company capitalized interest of $3 million, $5 million and $6 million, respectively.

[0001137789-22-000055:notes:85]
Accrued Expenses

[0001137789-22-000055:notes:86]
The following table provides details of the accrued expenses balance sheet item:

[0001137789-22-000055:notes:87]
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |
| Dividends payable |  | $ | 147 |  |  | $ | 153 |  |
| Other accrued expenses |  | 449 |  |  | 455 |  |
| Total |  | $ | 596 |  |  | $ | 608 |  |

[0001137789-22-000055:notes:88]
Accumulated Other Comprehensive Income (Loss) (“AOCI”)

[0001137789-22-000055:notes:89]
The components of AOCI, net of tax, were as follows:

[0001137789-22-000055:notes:90]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at July 3, 2020 |  | $ | (24) |  |  |  | $ | (26) |  |  | $ | (16) |  |  | $ | (66) |  |
| Other comprehensive income before reclassifications |  | 15 |  |  |  | 1 |  |  | 15 |  |  | 31 |  |
| Amounts reclassified from AOCI |  | (9) |  |  |  | 3 |  |  | — |  |  | (6) |  |
| Other comprehensive income |  | 6 |  |  |  | 4 |  |  | 15 |  |  | 25 |  |
| Balance at July 2, 2021 |  | (18) |  |  |  | (22) |  |  | (1) |  |  | (41) |  |
| Other comprehensive income before reclassifications |  | 48 |  |  |  | 6 |  |  | — |  |  | 54 |  |
| Amounts reclassified from AOCI |  | 21 |  |  |  | 2 |  |  | — |  |  | 23 |  |
| Other comprehensive income |  | 69 |  |  |  | 8 |  |  | — |  |  | 77 |  |
| Balance at July 1, 2022 |  | $ | 51 |  |  |  | $ | (14) |  |  | $ | (1) |  |  | $ | 36 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001137789-22-000055:notes:91]
Goodwill and Other Intangible Assets
Goodwill

[0001137789-22-000055:notes:92]
The carrying amount of goodwill was $1,237 million as of July 1, 2022 and July 2, 2021. There were no additions to, disposals of, impairments of or translation adjustments to goodwill in fiscal years 2022, 2021 and 2020.

[0001137789-22-000055:notes:93]
Other Intangible Assets

[0001137789-22-000055:notes:94]
Other intangible assets consist primarily of existing technology, customer relationships and trade names acquired in business combinations. Intangibles are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization is charged to Operating expenses in the Consolidated Statements of Operations.

[0001137789-22-000055:notes:95]
In fiscal years 2022, 2021 and 2020, amortization expense for other intangible assets was $20 million, $29 million and $53 million, respectively.

[0001137789-22-000055:notes:96]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of July 1, 2022, is set forth in the following table:

[0001137789-22-000055:notes:97]
| (Dollars in millions) |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life |
| Existing technology |  | $ | 29 |  |  | $ | (24) |  |  | $ | 5 |  |  | 1.0 Year |
| Customer relationships |  | 71 |  |  | (68) |  |  | 3 |  |  | 0.2 Year |
| Other intangible assets |  | 8 |  |  | (7) |  |  | 1 |  |  | 0.8 Year |
| Total amortizable other intangible assets |  | $ | 108 |  |  | $ | (99) |  |  | $ | 9 |  |  | 0.8 Year |

[0001137789-22-000055:notes:98]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of July 2, 2021 is set forth in the following table:

[0001137789-22-000055:notes:99]
| (Dollars in millions) |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life |
| Existing technology |  | $ | 43 |  |  | $ | (30) |  |  | $ | 13 |  |  | 1.8 Years |
| Customer relationships |  | 71 |  |  | (58) |  |  | 13 |  |  | 1.2 Years |
| Other intangible assets |  | 9 |  |  | (6) |  |  | 3 |  |  | 1.7 Years |
| Total amortizable other intangible assets |  | $ | 123 |  |  | $ | (94) |  |  | $ | 29 |  |  | 1.5 Years |

[0001137789-22-000055:notes:100]
As of July 1, 2022, expected amortization expense for other intangible assets for fiscal year 2023 is $9 million.


## us-gaap:DebtDisclosureTextBlock

[0001137789-22-000055:notes:101]
Debt
The following table provides details of the Company’s debt as of July 1, 2022 and July 2, 2021:

[0001137789-22-000055:notes:102]
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $750 issued on February 3, 2017 at 4.25% due March 1, 2022 (the “2022 Notes”), interest payable semi-annually on March 1 and September 1 of each year, fully repaid on February 1, 2022. |  | $ | — |  |  | $ | 220 |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 540 |  |  | 541 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 466 |  |  | 461 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 499 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loan |  |  |  |  |
| $600 borrowed on October 14, 2021 at London Interbank Offered Rate (“LIBOR”) plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 600 |  |  | — |  |
| $600 borrowed on October 14, 2021 at LIBOR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | — |  |
| $500 borrowed on September 17, 2019 at LIBOR, (the “September 2019 Term Loan”), repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with a final maturity date of September 16, 2025, fully repaid on October 14, 2021. |  | — |  |  | 481 |  |
|  |  | 5,677 |  |  | 5,173 |  |
| Less: unamortized debt issuance costs |  | (31) |  |  | (34) |  |
| Debt, net of debt issuance costs |  | 5,646 |  |  | 5,139 |  |
| Less: current portion of long-term debt |  | (584) |  |  | (245) |  |
| Long-term debt, less current portion |  | $ | 5,062 |  |  | $ | 4,894 |  |

[0001137789-22-000055:notes:103]
(1) All unsecured senior notes are issued by Seagate HDD Cayman, and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and, pursuant to a supplemental indenture dated as of May 18, 2021, STX.

[0001137789-22-000055:notes:104]
Unsecured Senior Notes

[0001137789-22-000055:notes:105]
2022 Notes. On February 1, 2022, the entire outstanding principal amount of $220 million was repaid at par, plus accrued and unpaid interest. During fiscal year 2021, $9 million aggregate principal amount of the 2022 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. During fiscal year 2020, $521 million aggregate principal amount of the 2022 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest, $250 million and $248 million principal amount of which were repurchased pursuant to cash tender offers for certain senior notes on September 18, 2019 and June 18, 2020, respectively. The Company recorded a loss of $29 million on repurchases during fiscal year 2020, which is included in Other, net in the Company’s Consolidated Statements of Operations.

[0001137789-22-000055:notes:106]
2023 Notes. During fiscal year 2021, $5 million aggregate principal amount of the 2023 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. During fiscal year 2020, $395 million aggregate principal amount of the 2023 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest, $200 million and $178 million principal amount of which was repurchased pursuant to the cash tender offers on September 18, 2019 and June 18, 2020, respectively. The Company recorded a loss of $1 million and $20 million for fiscal years 2021 and 2020, which is included in Other, net in the Company’s Consolidated Statement of Operations.

[0001137789-22-000055:notes:107]
2025 Notes. On September 18, 2019, $170 million principal amount of the 2025 Notes was repurchased at a premium pursuant to the cash tender offers. For fiscal year 2020, the Company recorded a loss of $8 million on repurchase, which is included in Other, net in the Company’s Consolidated Statements of Operations. On June 18, 2020, Seagate HDD Cayman completed an exchange offer in which the principal amount of $271 million of the 2025 Notes was exchanged for the principal amount of $297 million of the July 2029 Notes. The exchange was accounted for as a debt modification with no gain or loss recognized.

[0001137789-22-000055:notes:108]
2027 Notes. On June 18, 2020, Seagate HDD Cayman completed an exchange offer in which the principal amount of $185 million of the 2027 Notes was exchanged for the principal amount of $203 million of the July 2029 Notes. The exchange was accounted for as a debt modification with no gain or loss recognized.

[0001137789-22-000055:notes:109]
Credit Agreement

[0001137789-22-000055:notes:110]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement on February 20, 2019, which was amended on May 28, 2019, September 16, 2019, January 13, 2021, May 18, 2021 and October 14, 2021 (the “Credit Agreement”).

[0001137789-22-000055:notes:111]
Prior to the October 14, 2021 amendment, the Credit Agreement provided a term loan facility in an aggregate principal amount of $500 million and a $1.725 billion senior unsecured revolving credit facility (“Revolving Credit Facility”). The September 2019 Term Loan had a final maturity date of September 16, 2025 and the Revolving Credit Facility had a final maturity of February 20, 2024. On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the September 2019 Term Loan.

[0001137789-22-000055:notes:112]
On October 14, 2021, STX and Seagate HDD Cayman entered into an amendment to the Credit Agreement (“Fifth Amendment”), which provides for a new term loan facility in the aggregate principal amount of $1.2 billion that was extended in two tranches of $600 million each (“Term Loan A1” and “Term Loan A2” and together the “Term Loans”). Term Loan A1 and Term Loan A2 were each drawn in full on the closing date for the Fifth Amendment. Term Loan A1 bears interest at a rate of LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company. Term Loan A1 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of September 16, 2025. Term Loan A2 bears interest at a rate of LIBOR plus a variable margin ranging from 1.25% to 2.5% that will be determined based on the corporate credit rating of the Company. Term Loan A2 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of July 30, 2027. The proceeds of the Terms Loans may be used for, among other things, general corporate purposes.

[0001137789-22-000055:notes:113]
In addition, pursuant to the Fifth Amendment, the maturity date for the revolving loan commitments under the Revolving Credit Facility was extended until October 14, 2026, the revolving commitments were increased to $1.75 billion and the interest rate margins for the revolving loans were amended to LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company.

[0001137789-22-000055:notes:114]
STX and certain of its material subsidiaries, including STUC, fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loans.

[0001137789-22-000055:notes:115]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of July 1, 2022 and expects to be in compliance for the next 12 months. As of July 1, 2022, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility.

[0001137789-22-000055:notes:116]
Future Principal Payments on Long-term Debt

[0001137789-22-000055:notes:117]
At July 1, 2022, future principal payments on long-term debt were as follows (in millions):

[0001137789-22-000055:notes:118]
| Fiscal Year |  | Amount |
| 2023 |  | $ | 585 |  |
| 2024 |  | 560 |  |
| 2025 |  | 562 |  |
| 2026 |  | 563 |  |
| 2027 |  | 565 |  |
| Thereafter |  | 2,880 |  |
| Total |  | $ | 5,715 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001137789-22-000055:notes:119]
Income Taxes
Income before income taxes consisted of the following:

[0001137789-22-000055:notes:120]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |  | July 3,2020 |
| U.S. |  | $ | 145 |  |  | $ | 191 |  |  | $ | 121 |  |
| Non-U.S. |  | 1,534 |  |  | 1,157 |  |  | 911 |  |
|  |  | $ | 1,679 |  |  | $ | 1,348 |  |  | $ | 1,032 |  |

[0001137789-22-000055:notes:121]
The provision for income taxes consisted of the following:

[0001137789-22-000055:notes:122]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |  | July 3,2020 |
| Current income tax expense: |  |  |  |  |  |  |
| U.S. |  | $ | 4 |  |  | $ | — |  |  | $ | — |  |
| Non-U.S. |  | 35 |  |  | 38 |  |  | 36 |  |
| Total Current |  | 39 |  |  | 38 |  |  | 36 |  |
| Deferred income tax expense/(benefit): |  |  |  |  |  |  |
| U.S. |  | 3 |  |  | 8 |  |  | (18) |  |
| Non-U.S. |  | (12) |  |  | (12) |  |  | 10 |  |
| Total Deferred |  | (9) |  |  | (4) |  |  | (8) |  |
| Provision for income taxes |  | $ | 30 |  |  | $ | 34 |  |  | $ | 28 |  |

[0001137789-22-000055:notes:123]
The significant components of the Company’s deferred tax assets and liabilities were as follows:

[0001137789-22-000055:notes:124]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |
| Deferred tax assets |  |  |  |  |
| Accrued warranty |  | $ | 34 |  |  | $ | 31 |  |
| Inventory carrying value adjustments |  | 43 |  |  | 39 |  |
| Receivable allowances |  | 20 |  |  | 15 |  |
| Accrued compensation and benefits |  | 73 |  |  | 66 |  |
| Depreciation |  | 45 |  |  | 47 |  |
| Other accruals and deferred items |  | 24 |  |  | 25 |  |
| Net operating losses |  | 671 |  |  | 698 |  |
| Tax credit carryforwards |  | 650 |  |  | 628 |  |
| Other assets |  | 1 |  |  | 2 |  |
| Gross: Deferred tax assets |  | 1,561 |  |  | 1,551 |  |
| Less: Valuation allowance |  | (434) |  |  | (429) |  |
| Net: Deferred tax assets |  | 1,127 |  |  | 1,122 |  |
| Deferred tax liabilities |  |  |  |  |
| Unremitted earnings of certain non-U.S. entities |  | (5) |  |  | (5) |  |
| Acquisition-related Items |  | (2) |  |  | (5) |  |
| Other liabilities |  | (5) |  |  | (9) |  |
| Net: Deferred tax liabilities |  | (12) |  |  | (19) |  |
| Total net deferred tax assets |  | $ | 1,115 |  |  | $ | 1,103 |  |

[0001137789-22-000055:notes:125]
At July 1, 2022, the Company recorded $1.1 billion of net deferred tax assets. The realization of most of these deferred tax assets is primarily dependent on the Company’s ability to generate sufficient U.S. and certain non-Irish taxable income in future periods. Although realization is not assured, the Company’s management believes it is more likely than not that these deferred tax assets will be realized. The amount of deferred tax assets considered realizable, however, may increase or decrease in subsequent periods when the Company re-evaluates the underlying basis for its estimates of future U.S. and certain non-Irish taxable income.

[0001137789-22-000055:notes:126]
The deferred tax asset valuation allowance increased by $5 million in fiscal year 2022.

[0001137789-22-000055:notes:127]
At July 1, 2022, the Company had U.S. and non-U.S. tax net operating loss carryforwards of approximately $4.3 billion and $120 million, respectively, which will expire at various dates beginning in fiscal year 2023, if not utilized. Net operating loss carryforwards of approximately $26 million are scheduled to expire in fiscal year 2023. At July 1, 2022, the Company had U.S. tax credit carryforwards of $743 million which will expire at various dates beginning in fiscal year 2023 if not utilized.

[0001137789-22-000055:notes:128]
As of July 1, 2022, approximately $190 million and $88 million of the Company’s total U.S. net operating loss and tax credit carryforwards, respectively, are subject to annual limitations ranging from $1 million to $45 million pursuant to U.S. tax law.

[0001137789-22-000055:notes:129]
For purposes of the reconciliation between the provision for income taxes at the statutory rate and the effective tax rate, the Irish statutory rate of 25% was applied as follows:

[0001137789-22-000055:notes:130]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |  | July 3,2020 |
| Provision at statutory rate |  | $ | 420 |  |  | $ | 337 |  |  | $ | 258 |  |
| Permanent differences |  | 5 |  |  | 8 |  |  | (1) |  |
| Valuation allowance |  | 7 |  |  | (2) |  |  | (16) |  |
| Earnings taxed at less than statutory rate |  | (371) |  |  | (287) |  |  | (193) |  |
| Research credit |  | (26) |  |  | (27) |  |  | (27) |  |
| Other individually immaterial items |  | (5) |  |  | 5 |  |  | 7 |  |
| Provision for income taxes |  | $ | 30 |  |  | $ | 34 |  |  | $ | 28 |  |

[0001137789-22-000055:notes:131]
A substantial portion of the Company's operations in Singapore and Thailand operate under various tax incentive programs, which expire in whole or in part at various dates through 2033. Certain tax incentives may be extended if specific conditions are met. The net impact of these tax incentive programs was to increase the Company's net income by approximately $290 million in fiscal year 2022 ($1.29 per share, diluted), to increase the Company's net income by approximately $226 million in fiscal year 2021 ($0.92 per share, diluted) and to increase the Company’s net income by approximately $206 million in fiscal year 2020 ($0.78 per share, diluted).

[0001137789-22-000055:notes:132]
The Company analyzes the potential for deferred tax liabilities with respect to the accumulated earnings of foreign subsidiaries on an annual basis. The analysis focuses on the outside basis differences in the stock of the foreign subsidiaries as well as the withholding tax obligations those subsidiaries may have with respect to any distribution. The undistributed earnings for which taxes are not provided are permanently reinvested or can be repatriated without incremental tax liability.

[0001137789-22-000055:notes:133]
As of July 1, 2022 and July 2, 2021, the Company had approximately $114 million and $108 million, respectively, of unrecognized tax benefits excluding interest and penalties. These amounts, if recognized, would impact the effective tax rate subject to certain future valuation allowance offsets.

[0001137789-22-000055:notes:134]
The following table summarizes the activities related to the Company’s gross unrecognized tax benefits:

[0001137789-22-000055:notes:135]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |  | July 3,2020 |
| Balance of unrecognized tax benefits at the beginning of the year |  | $ | 108 |  |  | $ | 89 |  |  | $ | 83 |  |
| Gross increase for tax positions of prior years |  | 1 |  |  | 7 |  |  | — |  |
| Gross decrease for tax positions of prior years |  | (1) |  |  | (1) |  |  | (1) |  |
| Gross increase for tax positions of current year |  | 6 |  |  | 15 |  |  | 8 |  |
| Gross decrease for tax positions of current year |  | — |  |  | — |  |  | — |  |
| Settlements |  | — |  |  | (1) |  |  | (1) |  |
| Lapse of statutes of limitation |  | — |  |  | (1) |  |  | — |  |
| Balance of unrecognized tax benefits at the end of the year |  | $ | 114 |  |  | $ | 108 |  |  | $ | 89 |  |

[0001137789-22-000055:notes:136]
It is the Company’s policy to include interest and penalties related to unrecognized tax benefits in the provision for income taxes on the Consolidated Statements of Operations. Interest and penalties recorded were not material to any periods presented in the Consolidated Statement of Operations. As of July 1, 2022, accrued interest and penalties related to unrecognized tax benefits did not materially change compared to fiscal year 2021.

[0001137789-22-000055:notes:137]
During the 12 months beginning July 2, 2022, the Company does not expect a material change to its unrecognized tax benefits as a result of the expiration of certain statutes of limitation.
The Company is required to file U.S. and non-U.S. income tax returns. The Company is no longer subject to examination of its U.S. income tax returns for years prior to fiscal year 2018 and prior to fiscal year 2011 for non-U.S. income tax returns.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001137789-22-000055:notes:138]
LeasesThe Company is a lessee in several operating leases related to real estate facilities for warehouse and office space. 
The Company’s lease arrangements comprise operating leases with various expiration dates through 2068. The lease term includes the non-cancelable period of the lease, adjusted for options to extend or terminate the lease when it is reasonably certain that an option will be exercised.

[0001137789-22-000055:notes:139]
Operating lease costs include short-term lease costs and are shown net of immaterial sublease income. The components of lease costs and other information related to leases were as follows:

[0001137789-22-000055:notes:140]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |
| Operating lease cost |  | $ | 16 |  |  | $ | 15 |  |
| Variable lease cost |  | 4 |  |  | 4 |
| Total lease cost |  | $ | 20 |  |  | $ | 19 |  |
| Operating cash outflows from operating leases |  | $ | 20 |  |  | $ | 19 |  |

[0001137789-22-000055:notes:141]
|  |  | July 1,2022 |  | July 2,2021 |
| Weighted-average remaining lease term |  | 9.3 years |  | 7.2 years |
| Weighted-average discount rate |  | 6.40 | % |  | 6.02 | % |

[0001137789-22-000055:notes:142]
ROU assets and lease liabilities are included on the Company’s Consolidated Balance Sheet as follows:

[0001137789-22-000055:notes:143]
| (Dollars in millions) |  | Balance Sheet Location |  | July 1,2022 |  | July 2,2021 |
| ROU assets |  | Other assets, net |  | $ | 94 |  |  | $ | 97 |  |
| Current lease liabilities |  | Accrued expenses |  | 14 |  |  | 15 |
| Non-current lease liabilities |  | Other non-current liabilities |  | 36 |  |  | 39 |

[0001137789-22-000055:notes:144]
At July 1, 2022, future lease payments included in the measurement of lease liabilities were as follows (in millions):

[0001137789-22-000055:notes:145]
| Fiscal Year |  | Amount |
| 2023 |  | $ | 14 |  |
| 2024 |  | 10 |  |
| 2025 |  | 8 |  |
| 2026 |  | 6 |  |
| 2027 |  | 4 |  |
| Thereafter |  | 16 |  |
| Total lease payments |  | 58 |  |
| Less: imputed interest |  | (8) |  |
| Present value of lease liabilities |  | $ | 50 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001137789-22-000055:notes:146]
Restructuring and Exit Costs
During fiscal years 2022, 2021 and 2020, the Company recorded restructuring charges of $3 million, $8 million and $82 million, respectively, comprised primarily of charges related to workforce reduction costs and facilities and other exit costs associated with the restructuring of its workforce. The Company’s significant restructuring plans are described below. All restructuring charges are reported in Restructuring and other, net on the Consolidated Statements of Operations.

[0001137789-22-000055:notes:147]
June 2020 Plan - On June 1, 2020, the Company committed to a restructuring plan (the “June 2020 Plan”) consistent with its long-term strategy to drive operational efficiencies, reduce its cost structure and invest in future opportunities. The June 2020 Plan included reducing its headcount worldwide by approximately 500 employees. The June 2020 Plan was substantially completed during the first quarter of fiscal year 2021.

[0001137789-22-000055:notes:148]
The following table summarizes the Company’s restructuring activities under all of the Company’s active restructuring plans for fiscal years 2022, 2021 and 2020:

[0001137789-22-000055:notes:149]
|  |  | June 2020 Plan |  | Other Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at June 28, 2019 |  | $ | — |  |  | $ | — |  |  | $ | 13 |  |  | $ | 17 |  |  | $ | 30 |  |
| Lease adoption adjustment |  | — |  |  | — |  |  | — |  |  | (11) |  |  | (11) |  |
| Restructuring charges |  | 56 |  |  | 2 |  |  | 26 |  |  | 2 |  |  | 86 |  |
| Cash payments |  | (18) |  |  | — |  |  | (30) |  |  | (5) |  |  | (53) |  |
| Adjustments |  | — |  |  | — |  |  | (4) |  |  | — |  |  | (4) |  |
| Accrual balances at July 3, 2020 |  | 38 |  |  | 2 |  |  | 5 |  |  | 3 |  |  | 48 |  |
| Restructuring charges |  | — |  |  | — |  |  | 6 |  |  | 8 |  |  | 14 |  |
| Cash payments |  | (37) |  |  | (1) |  |  | (10) |  |  | (5) |  |  | (53) |  |
| Adjustments |  | — |  |  | — |  |  | — |  |  | (1) |  |  | (1) |  |
| Accrual balances at July 2, 2021 |  | 1 |  |  | 1 |  |  | 1 |  |  | 5 |  |  | 8 |  |
| Restructuring charges |  | — |  |  | — |  |  | 2 |  |  | 1 |  |  | 3 |  |
| Cash payments |  | (1) |  |  | (1) |  |  | (3) |  |  | (1) |  |  | (6) |  |
| Adjustments |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Accrual balances at July 1, 2022 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |
| Total costs incurred to date as of July 1, 2022 |  | $ | 56 |  |  | $ | 2 |  |  | $ | 140 |  |  | $ | 76 |  |  | $ | 274 |  |
| Total expected costs to be incurred as of July 1, 2022 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |

[0001137789-22-000055:notes:150]
The accrued restructuring balance of $5 million at July 1, 2022 is included in Accrued expenses in the Company’s Consolidated Balance Sheet.

[0001137789-22-000055:notes:151]
During fiscal year 2021, the Company recognized a gain of $3 million from the sale of a certain property and a gain of $2 million from termination of an operating lease, which are reported in Restructuring and other, net on the Company’s Consolidated Statements of Operations.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001137789-22-000055:notes:152]
Derivative Financial Instruments 
The Company is exposed to foreign currency exchange rate, interest rate and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies.

[0001137789-22-000055:notes:153]
The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives on its Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in Accumulated other comprehensive income until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The amount of net unrealized gain on cash flow hedges was $51 million and net unrealized loss was $18 million as of July 1, 2022 and as of July 2, 2021, respectively. As of July 1, 2022, the amount of existing net gains related to cash flow hedges recorded in Accumulated other comprehensive income included a net gain of $8 million that is expected to be reclassified to earnings within twelve months.

[0001137789-22-000055:notes:154]
The Company de-designates its cash flow hedges when the forecasted hedged transactions affect earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive income on the Company’s Consolidated Balance Sheets are reclassified into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings.

[0001137789-22-000055:notes:155]
The Company recognized a net loss of $11 million and $10 million in Cost of revenue and Interest expense, respectively related to the loss of hedge designation on discontinued cash flow hedges during fiscal year 2022. The Company recognized a net gain of $14 million in Cost of revenue and a net loss of $7 million in Interest expense related to the loss of hedge designation on discontinued cash flow hedges during fiscal year 2021. The Company recognized a net loss of $3 million in Other expense, net related to the loss of hedge designation on discontinued cash flow hedges during the fiscal year 2020.

[0001137789-22-000055:notes:156]
Other derivatives not designated as hedging instruments consist of foreign currency forward exchange contracts that the Company uses to hedge the foreign currency exposure on forecasted expenditures denominated in currencies other than the U.S. dollar. The Company recognizes gains and losses on these contracts, as well as the related costs in Other, net on its Consolidated Statements of Operations.

[0001137789-22-000055:notes:157]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of July 1, 2022 and July 2, 2021. All of the foreign currency forward exchange contracts mature within 12 months.

[0001137789-22-000055:notes:158]
|  |  | As of July 1, 2022 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Singapore Dollar |  | $ | 178 |  |  | $ | 52 |  |
| Thai Baht |  | 133 |  |  | 35 |  |
| Chinese Renminbi |  | 92 |  |  | 24 |  |
| British Pound Sterling |  | 64 |  |  | 15 |  |
|  |  | $ | 467 |  |  | $ | 126 |  |

[0001137789-22-000055:notes:159]
|  |  | As of July 2, 2021 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Singapore Dollar |  | $ | 172 |  |  | $ | 43 |  |
| Thai Baht |  | 131 |  |  | 46 |  |
| Chinese Renminbi |  | 73 |  |  | 21 |  |
| British Pound Sterling |  | 54 |  |  | 16 |  |
|  |  | $ | 430 |  |  | $ | 126 |  |

[0001137789-22-000055:notes:160]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its non-qualified deferred compensation plan: the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP’s liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP’s liabilities due to changes in the value of the investment options made by employees. As of July 1, 2022, the notional investments underlying the TRS amounted to $104 million. The contract term of the TRS is through January 2023 and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP’s liabilities.

[0001137789-22-000055:notes:161]
The following tables show the Company’s derivative instruments measured at gross fair value as reflected in the Consolidated Balance Sheets as of July 1, 2022 and July 2, 2021:

[0001137789-22-000055:notes:162]
|  |  | As of July 1, 2022 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (14) |  |
| Interest rate swap |  | Other current assets |  | 65 |  |  | Accrued expenses |  | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | — |  |  | Accrued expenses |  | (5) |  |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | (4) |  |
| Total derivatives |  |  |  | $ | 65 |  |  |  |  | $ | (23) |  |

[0001137789-22-000055:notes:163]
|  |  | As of July 2, 2021 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 1 |  |  | Accrued expenses |  | $ | (5) |  |
| Interest rate swap |  | Other current assets |  | — |  |  | Accrued expenses |  | (14) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 1 |  |  | Accrued expenses |  | (2) |  |
| Total return swap |  | Other current assets |  | 2 |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 4 |  |  |  |  | $ | (21) |  |

[0001137789-22-000055:notes:164]
The following tables show the effect of the Company’s derivative instruments on the Consolidated Statement of Comprehensive Income and Consolidated Statement of Operations for the fiscal year ended July 1, 2022:

[0001137789-22-000055:notes:165]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized inIncome on Derivatives |  | Amount of Gain/(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (9) |  |
| Total return swap |  | Operating expenses |  | (18) |  |

[0001137789-22-000055:notes:166]
| (Dollars in millions) Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
| Foreign currency forward exchange contracts |  | $ | (22) |  |  | Cost of revenue |  | $ | (11) |  |  | Other, net |  | $ | 1 |  |
| Interest rate swap |  | 70 |  |  | Interest expense |  | (10) |  |  | Interest expense |  | — |  |

[0001137789-22-000055:notes:167]
The following tables show the effect of the Company’s derivative instruments on the Consolidated Statement of Comprehensive Income and Consolidated Statement of Operations for the fiscal year ended July 2, 2021:

[0001137789-22-000055:notes:168]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized inIncome on Derivatives |  | Amount of Gain/(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 10 |  |
| Total return swap |  | Operating expenses |  | 30 |  |

[0001137789-22-000055:notes:169]
| (Dollars in millions) Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
| Foreign currency forward exchange contracts |  | $ | 7 |  |  | Cost of revenue |  | $ | 14 |  |  | Other, net |  | $ | 1 |  |
| Interest rate swap |  | 8 |  |  | Interest expense |  | (7) |  |  | Interest expense |  | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001137789-22-000055:notes:170]
Fair Value
Measurement of Fair Value

[0001137789-22-000055:notes:171]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact and it considers assumptions that market participants would use when pricing the asset or liability.

[0001137789-22-000055:notes:172]
Fair Value Hierarchy

[0001137789-22-000055:notes:173]
A fair value hierarchy is based on whether the market participant assumptions used in determining fair value are obtained from independent sources (observable inputs) or reflect the Company's own assumptions of market participant valuation (unobservable inputs). A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The three levels of inputs that may be used to measure fair value are:

[0001137789-22-000055:notes:174]
Level 1 - Quoted prices in active markets that are unadjusted and accessible at the measurement date for identical, unrestricted assets or liabilities;

[0001137789-22-000055:notes:175]
Level 2 - Quoted prices for identical assets and liabilities in markets that are inactive; quoted prices for similar assets and liabilities in active markets or financial instruments for which significant inputs are observable, either directly or indirectly; or

[0001137789-22-000055:notes:176]
Level 3 - Prices or valuations that require inputs that are both unobservable and significant to the fair value measurement.

[0001137789-22-000055:notes:177]
The Company considers an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis and views an inactive market as one in which there are few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, the Company’s or the counterparty’s non-performance risk is considered in determining the fair values of liabilities and assets, respectively.

[0001137789-22-000055:notes:178]
Items Measured at Fair Value on a Recurring Basis

[0001137789-22-000055:notes:179]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of:

[0001137789-22-000055:notes:180]
|  |  | July 1, 2022 |  | July 2, 2021 |
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (US Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 59 |  |  | $ | — |  |  | $ | — |  |  | $ | 59 |  |  | $ | 551 |  |  | $ | — |  |  | $ | — |  |  | $ | 551 |  |
| Total cash equivalents |  | 59 |  |  | — |  |  | — |  |  | 59 |  |  | 551 |  |  | — |  |  | — |  |  | 551 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | — |  |  | — |  |  | 23 |  |  | 23 |  |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Derivative assets |  | — |  |  | 65 |  |  | — |  |  | 65 |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total assets |  | $ | 60 |  |  | $ | 66 |  |  | $ | 23 |  |  | $ | 149 |  |  | $ | 552 |  |  | $ | 5 |  |  | $ | 18 |  |  | $ | 575 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |
| Total liabilities |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |

[0001137789-22-000055:notes:181]
|  |  | July 1, 2022 |  | July 2, 2021 |
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (US Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 59 |  |  | $ | — |  |  | $ | — |  |  | $ | 59 |  |  | $ | 551 |  |  | $ | — |  |  | $ | — |  |  | $ | 551 |  |
| Other current assets |  | 1 |  |  | 66 |  |  | — |  |  | 67 |  |  | 1 |  |  | 5 |  |  | — |  |  | 6 |  |
| Other assets, net |  | — |  |  | — |  |  | 23 |  |  | 23 |  |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Total assets |  | $ | 60 |  |  | $ | 66 |  |  | $ | 23 |  |  | $ | 149 |  |  | $ | 552 |  |  | $ | 5 |  |  | $ | 18 |  |  | $ | 575 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |
| Total liabilities |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |

[0001137789-22-000055:notes:182]
The Company classifies items in Level 1 if the financial assets consist of securities for which quoted prices are available in an active market.

[0001137789-22-000055:notes:183]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair value of all of its cash equivalents. For the cash equivalents in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry standard data providers or other third-party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of July 1, 2022, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts, interest rate swaps and the TRS. The Company recognizes derivative financial instruments in its consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001137789-22-000055:notes:184]
Items Measured at Fair Value on a Non-Recurring Basis

[0001137789-22-000055:notes:185]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives, which are accounted for either under the equity method or the measurement alternative. If measured at fair value in the Consolidated Balance Sheets, these investments would generally be classified in Level 3 of the fair value hierarchy.

[0001137789-22-000055:notes:186]
For the investments that are accounted for under the equity method, the Company recorded a net gain of $8 million and $48 million in fiscal years 2022 and 2021, respectively and a net loss of $2 million in fiscal year 2020. The adjusted carrying value of the investments accounted under the equity method amounted to $61 million and $78 million as of July 1, 2022 and July 2, 2021 respectively.

[0001137789-22-000055:notes:187]
For the investments that are accounted under the measurement alternative, the Company recorded $4 million of net gains in fiscal year 2022. For the investments that are accounted for under the measurement alternative, Company recorded $51 million of net gains in fiscal year 2021, of which $27 million was unrealized as of July 2, 2021 related to upward adjustments due to observable price changes. For fiscal year 2021, the Company recorded downward adjustment of $12 million to write down the carrying amount of certain investments to their fair value. As of July 1, 2022 and July 2, 2021, the carrying value of the Company’s strategic investments under the measurement alternative was $88 million and $117 million, respectively.

[0001137789-22-000055:notes:188]
The Company’s debt is carried at amortized cost. The estimated fair value of the Company’s debt is derived using the closing price of the same debt instruments as of the date of valuation, which takes into account the yield curve, interest rates and other observable inputs. Accordingly, these fair value measurements are categorized as Level 2. The following table presents the fair value and amortized cost of the Company’s debt in order of maturity:

[0001137789-22-000055:notes:189]
|  |  | July 1, 2022 |  | July 2, 2021 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 4.250% Senior Notes due March 2022 |  | $ | — |  |  | $ | — |  |  | $ | 220 |  |  | $ | 224 |  |
| 4.750% Senior Notes due June 2023 |  | 540 |  |  | 538 |  |  | 541 |  |  | 578 |  |
| 4.875% Senior Notes due March 2024 |  | 499 |  |  | 494 |  |  | 499 |  |  | 544 |  |
| 4.750% Senior Notes due January 2025 |  | 479 |  |  | 471 |  |  | 479 |  |  | 529 |  |
| 4.875% Senior Notes due June 2027 |  | 504 |  |  | 483 |  |  | 504 |  |  | 561 |  |
| 4.091% Senior Notes due June 2029 |  | 466 |  |  | 427 |  |  | 461 |  |  | 519 |  |
| 3.125% Senior Notes due July 2029 |  | 500 |  |  | 396 |  |  | 500 |  |  | 488 |  |
| 4.125% Senior Notes due January 2031 |  | 500 |  |  | 410 |  |  | 499 |  |  | 513 |  |
| 3.375% Senior Notes due July 2031 |  | 500 |  |  | 393 |  |  | 500 |  |  | 487 |  |
| 5.750% Senior Notes due December 2034 |  | 489 |  |  | 433 |  |  | 489 |  |  | 566 |  |
| LIBOR Based Term Loan A1 due September 2025 |  | 600 |  |  | 588 |  |  | — |  |  | — |  |
| LIBOR Based Term Loan A2 due July 2027 |  | 600 |  |  | 586 |  |  | — |  |  | — |  |
| LIBOR Based Term Loan due September 2025 |  | — |  |  | — |  |  | 481 |  |  | 478 |  |
|  |  | $ | 5,677 |  |  | $ | 5,219 |  |  | $ | 5,173 |  |  | $ | 5,487 |  |
| Less: debt issuance costs |  | (31) |  |  | — |  |  | (34) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 5,646 |  |  | $ | 5,219 |  |  | $ | 5,139 |  |  | $ | 5,487 |  |
| Less: current portion of debt, net of debt issuance costs |  | (584) |  |  | (582) |  |  | (245) |  |  | (249) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,062 |  |  | $ | 4,637 |  |  | $ | 4,894 |  |  | $ | 5,238 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001137789-22-000055:notes:190]
Shareholders’ Equity
Share Capital

[0001137789-22-000055:notes:191]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 209,850,169 shares were outstanding as of July 1, 2022, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of July 1, 2022.

[0001137789-22-000055:notes:192]
On May 18, 2021, in connection with a corporate reorganization, a new Irish public limited company, STX, began serving as the publicly traded parent company, and pursuant to a scheme of arrangement under Irish law, each STUC ordinary shareholder received one ordinary share, par value $0.00001, of STX on a one-for-one basis. As of May 18, 2021, there were 227,340,817 ordinary shares of $0.00001 par value per share exchanged in connection with the reorganization.

[0001137789-22-000055:notes:193]
Ordinary shares - Holders of ordinary shares are entitled to receive dividends when and as declared by the Company’s board of directors (the “Board of Directors”). Upon any liquidation, dissolution, or winding up of the Company, after required payments are made to holders of preferred shares, any remaining assets of the Company will be distributed ratably to holders of the preferred and ordinary shares. Holders of shares are entitled to one vote per share on all matters upon which the ordinary shares are entitled to vote, including the election of directors.

[0001137789-22-000055:notes:194]
Preferred shares - The Company may issue preferred shares in one or more series, up to the authorized amount, without shareholder approval. The Board of Directors is authorized to establish from time to time the number of shares to be included in each series, and to fix the rights, preferences and privileges of the shares of each wholly unissued series and any of its qualifications, limitations or restrictions. The Board of Directors can also increase or decrease the number of shares of a series, but not below the number of shares of that series then outstanding, without any further vote or action by the shareholders.

[0001137789-22-000055:notes:195]
The Board of Directors may authorize the issuance of preferred shares with voting or conversion rights that could harm the voting power or other rights of the holders of the ordinary shares. The issuance of preferred shares, while providing flexibility in connection with possible acquisitions and other corporate purposes, could, among other things, have the effect of delaying, deferring or preventing a change in control of the Company and might harm the market price of its ordinary shares and the voting and other rights of the holders of ordinary shares.

[0001137789-22-000055:notes:196]
Repurchases of Equity Securities

[0001137789-22-000055:notes:197]
All repurchases are effected as redemptions in accordance with the Company’s Constitution.

[0001137789-22-000055:notes:198]
The Company’s Board of Directors increased the authorization for the repurchase of its outstanding ordinary shares by $3.0 billion on October 21, 2020, and $2.0 billion on February 22, 2021. As of July 1, 2022, $2.4 billion remained available for repurchase under the existing repurchase authorization limit.

[0001137789-22-000055:notes:199]
The following table sets forth information with respect to repurchases of the Company’s ordinary shares during fiscal years 2022, 2021 and 2020:

[0001137789-22-000055:notes:200]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Cumulative repurchased through June 28, 2019 |  | 374 |  |  | $ | 11,499 |  |
| Repurchased in fiscal year 2020(1) |  | 18 |  |  | 887 |  |
| Cumulative repurchased through July 3, 2020 |  | 392 |  |  | 12,386 |  |
| Repurchased in fiscal year 2021(1) |  | 34 |  |  | 2,081 |  |
| Cumulative repurchased through July 2, 2021 |  | 426 |  |  | 14,467 |  |
| Repurchased in fiscal year 2022(1) |  | 21 |  |  | 1,857 |  |
| Cumulative repurchased through July 1, 2022 |  | 447 |  |  | $ | 16,324 |  |

[0001137789-22-000055:notes:201]
___________________________________________________

[0001137789-22-000055:notes:202]
(1)     For fiscal years 2022, 2021 and 2020, includes net share settlements of $51 million, $33 million and $40 million for 1 million, 1 million and 1 million shares, respectively, in connection with tax withholding related to vesting of restricted share units.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001137789-22-000055:notes:203]
Share-Based Compensation
Share-Based Compensation Plans

[0001137789-22-000055:notes:204]
The Company’s share-based compensation plans have been established to promote the Company’s long-term growth and financial success by providing incentives to its employees, directors and consultants through grants of share-based awards. The provisions of the Company's share-based benefit plans, which allow for the grant of various types of equity-based awards, are also intended to provide greater flexibility to maintain the Company's competitive ability to attract, retain and motivate participants for the benefit of the Company and its shareholders.

[0001137789-22-000055:notes:205]
Seagate Technology Holdings plc 2022 Equity Incentive Plan (the “2022 EIP”): On October 20, 2021, (the “Approval Date”), shareholders of the Company approved the adoption of the 2022 EIP in replacement of Seagate Technology Holdings plc 2012 Equity Inventive Plan (the “2012 EIP”), which was retired as of the Approval Date. The 2022 EIP provides for the grant of various types of awards including restricted share units (“RSUs”), options, performance-based share units (“PSUs”) and share appreciation rights. The maximum number of shares that may be delivered to the participants under the 2022 EIP shall not exceed (i) 14.1 million ordinary shares, plus (ii) any shares subject to any outstanding share awards granted under the 2012 EIP that, on or after the Approval Date expire, are cancelled or otherwise terminate, in whole or in part, without having been exercised or redeemed in full, or are settled in cash ((i) and (ii) together being the “Share Reserve”). The maximum aggregate number of shares that may be issued pursuant to RSUs or PSUs (collectively, “Full-Value Share Awards”) shall not exceed 12.3 million ordinary shares. Any shares that are subject to the 2022 EIP will be counted against the Share Reserve as one share for every one share granted. As of July 1, 2022, there were 12.0 million ordinary shares available for issuance of Full-Value Share Awards under the 2022 EIP.

[0001137789-22-000055:notes:206]
Dot Hill Systems 2009 Equity Incentive Plan (the “DHEIP”). Effective May 18, 2021, Seagate Technology Holdings plc assumed the Dot Hill Systems 2009 Equity Incentive Plan, which was acquired by STUC effective October 6, 2015. The Company assumed the remaining authorized but unused share reserve of approximately 2.0 million shares, based on the conversion ratio, from the DHEIP on the acquisition date. Effective April 24, 2019, the Company terminated the DHEIP and thus, no further grants will be made under the DHEIP. Outstanding awards granted under the DHEIP will remain subject to the terms of the DHEIP.

[0001137789-22-000055:notes:207]
Seagate Technology Holdings plc Employee Stock Purchase Plan (the “ESPP”). There are 60.0 million ordinary shares authorized to be issued under the ESPP. The ESPP consists of a six-month offering period with a maximum issuance of 1.5 million ordinary shares per offering period. The ESPP permits eligible employees to purchase ordinary shares through payroll deductions generally at 85% of the fair market value of the ordinary shares. As of July 1, 2022, there were approximately 7.5 million ordinary shares available for issuance under the ESPP.

[0001137789-22-000055:notes:208]
Equity Awards

[0001137789-22-000055:notes:209]
RSUs generally vest over a period of four years, with cliff vesting of a portion of each award occurring annually, subject to continuous employment with the Company through the vesting date. Options generally vest as follows: 25% of the options will vest on the first anniversary of the vesting commencement date and the remaining 75% will vest ratably each month thereafter over the next 36 months. Options granted under the 2022 EIP and 2012 EIP have an exercise price equal to the fair market value of the Company’s ordinary shares on the grant date. Fair market value is defined as the closing price of the Company's ordinary shares on NASDAQ on the grant date.

[0001137789-22-000055:notes:210]
The Company granted PSUs to its senior executive officers under the 2022 EIP and 2012 EIP where vesting is subject to both the continued employment of the participant by the Company and the achievement of certain financial and operational performance goals established by the Compensation Committee of the Company’s Board of Directors (the “Compensation Committee”). A single PSU represents the right to receive a single ordinary share of the Company. During fiscal years 2022, 2021 and 2020, the Company granted 0.3 million, 0.3 million and 0.3 million PSUs, respectively, where performance is measured based on a three-year average return on invested capital (“ROIC”) goal and a relative total shareholder return (“TSR”) goal, which is based on the Company’s ordinary shares measured against a benchmark TSR of a peer group over the same three-year period (the “TSR/ROIC” awards). For fiscal year 2022, the PSUs granted to certain executive officers contain two ESG modifiers that will increase or decrease the PSU achievement level based on the Company’s performance against both a social goal of gender diversity and an environmental goal of greenhouse gas reduction. These awards vest after the end of the performance period of three years from the grant date. A percentage of these units may vest only if at least the minimum ROIC goal is met regardless of whether the TSR goal is met. The number of share units to vest will range from 0% to 200% of the targeted units. In evaluating the fair value of these units, the Company used a Monte Carlo simulation on the grant date, taking the market-based TSR goal into consideration. Compensation expense related to these units is only recorded in a period if it is probable that the ROIC goal will be met, and it is to be recorded at the expected level of achievement.

[0001137789-22-000055:notes:211]
The Company also granted 0.1 million and 0.1 million PSUs during fiscal years 2021 and 2020, respectively, to certain of its executive officers which are subject to a performance goal related to the Company's adjusted earnings per share (“AEPS”). These awards have a maximum seven-year vesting period, with 25% annual vesting starting on the first anniversary of the grant date. If the AEPS goal is not achieved, vesting is delayed to a following year in which the AEPS goal is achieved. Any unvested awards from prior years may vest cumulatively in a future year within the seven-year vesting period if the annual AEPS goal is achieved during a subsequent year. If the AEPS goal has not been met by the end of the seven-year period, any unvested shares will be forfeited.

[0001137789-22-000055:notes:212]
Determining Fair Value of Seagate Technology Share Plans

[0001137789-22-000055:notes:213]
Valuation and amortization method - The Company estimates the fair value of granted share options, RSUs and PSUs subject to an AEPS condition granted using the Black-Scholes-Merton valuation model and a single share award approach. This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period or the remaining service (vesting) period.

[0001137789-22-000055:notes:214]
Expected Term - Expected term represents the period that the Company’s share-based awards are expected to be outstanding and was determined based on historical experience of similar awards, giving consideration to the contractual terms of the share-based awards, vesting schedules and expectations of future employee behavior as influenced by changes to the terms of its share-based awards.

[0001137789-22-000055:notes:215]
Expected Volatility - The Company uses a combination of the implied volatility of its traded options and historical volatility of its share price.

[0001137789-22-000055:notes:216]
Expected Dividend - The Black-Scholes-Merton valuation model calls for a single expected dividend yield as an input. The dividend yield is determined by dividing the expected per share dividend during the coming year by the grant date share price. The expected dividend assumption is based on the Company’s current expectations about its anticipated dividend policy. Also, because the expected dividend yield should reflect marketplace participants’ expectations, the Company does not incorporate changes in dividends anticipated by management unless those changes have been communicated to or otherwise are anticipated by marketplace participants.

[0001137789-22-000055:notes:217]
Risk-Free Interest Rate - The Company bases the risk-free interest rate used in the Black-Scholes-Merton valuation model on the implied yield currently available on U.S. Treasury zero-coupon issues with an equivalent remaining term. Where the expected term of the Company's share-based awards do not correspond with the terms for which interest rates are quoted, the Company performed a straight-line interpolation to determine the rate from the available term maturities.

[0001137789-22-000055:notes:218]
The fair value of the Company’s shares related to options and RSUs granted to employees, shares issued from the ESPP and PSUs subject to TSR/ROIC or AEPS conditions for fiscal years 2022, 2021 and 2020 were estimated using the following assumptions:

[0001137789-22-000055:notes:219]
|  | Fiscal Years |
|  | 2022 |  | 2021 |  | 2020 |
| Options |  |  |  |  |  |
| Expected term (in years) | 4.2 |  | 4.2 |  | 4.2 |
| Volatility | 38 % |  | 37 - 38 % |  | 39 % |
| Weighted-average volatility | 38 | % |  | 38 | % |  | 39 | % |
| Expected dividend rate | 2.8 % |  | 3.2 - 5.2 % |  | 4.2 % |
| Weighted-average expected dividend rate | 2.8 | % |  | 4.7 | % |  | 4.2 | % |
| Risk-free interest rate | 0.6 % |  | 0.2 - 0.7 % |  | 1.4 % |
| Weighted-average fair value | $ | 21.02 |  |  | $ | 10.77 |  |  | $ | 12.41 |  |
| RSUs |  |  |  |  |  |
| Expected term (in years) | 1 - 2.5 |  | 1 - 2.5 |  | 1 - 2.5 |
| Expected dividend rate | 2.4 - 3.4 % |  | 2.5 - 5.4 % |  | 3.9 - 5.8 % |
| Weighted-average expected dividend rate | 2.8 | % |  | 4.6 | % |  | 4.3 | % |
| Weighted-average fair value | $ | 82.40 |  |  | $ | 50.64 |  |  | $ | 49.49 |  |
| ESPP |  |  |  |  |  |
| Expected term (in years) | 0.5 |  | 0.5 |  | 0.5 |
| Volatility | 36 - 39 % |  | 39 - 44 % |  | 32 - 35 % |
| Weighted-average volatility | 37 | % |  | 42 | % |  | 33 | % |
| Expected dividend rate | 2.6 - 3.0 % |  | 4.0 - 5.8 % |  | 4.3 - 5.4 % |
| Weighted-average expected dividend rate | 2.8 | % |  | 5.1 | % |  | 4.9 | % |
| Risk-free interest rate | 0.1 - 0.5 % |  | 0.1 % |  | 1.6 - 2.0 % |
| Weighted-average fair value | $ | 24.38 |  |  | $ | 13.77 |  |  | $ | 12.23 |  |
| PSUs subject to TSR/ROIC conditions |  |  |  |  |  |
| Expected term (in years) | 3.0 |  | 3.0 |  | 3.0 |
| Volatility | 39 | % |  | 38 | % |  | 37 | % |
| Weighted-average volatility | 39 | % |  | 38 | % |  | 37 | % |
| Expected dividend rate | 3.1 | % |  | 5.6 | % |  | 4.6 | % |
| Weighted-average expected dividend rate | 3.1 | % |  | 5.6 | % |  | 4.6 | % |
| Risk-free interest rate | 0.4 | % |  | 0.2 | % |  | 1.5 | % |
| Weighted-average fair value | $ | 86.01 |  |  | $ | 43.20 |  |  | $ | 52.39 |  |
| PSUs subject to an AEPS condition |  |  |  |  |  |
| Expected term (in years) | — |  |  | 2.5 |  | 2.5 |
| Expected dividend rate | — |  |  | 3.2 - 5.2 % |  | 4.2 % |
| Weighted-average expected dividend rate | — |  |  | 4.9 | % |  | 4.2 | % |
| Weighted-average fair value | — |  |  | $ | 45.50 |  |  | $ | 49.27 |  |

[0001137789-22-000055:notes:220]
Share-Based Compensation Expense

[0001137789-22-000055:notes:221]
The Company recorded $145 million, $112 million and $109 million of share-based compensation during fiscal years 2022, 2021 and 2020, respectively. Management has made an estimate of expected forfeitures and is recognizing compensation costs only for those equity awards expected to vest. When estimating forfeitures, the Company considers voluntary termination behavior as well as the historical analysis of actual forfeited awards.

[0001137789-22-000055:notes:222]
Share Option Activity

[0001137789-22-000055:notes:223]
The Company issues new ordinary shares upon exercise of share options. The following is a summary of option activities:

[0001137789-22-000055:notes:224]
| Options |  | Number of Shares(In millions) |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term(In years) |  | Aggregate Intrinsic Value(Dollars in millions) |
| Outstanding at July 2, 2021 |  | 1.6 |  |  | $ | 44.24 |  |  | 4.0 |  | $ | 69 |  |
| Granted |  | 0.2 |  |  | $ | 87.34 |  |  |  |  |  |
| Exercised |  | (0.2) |  |  | $ | 45.48 |  |  |  |  |  |
| Outstanding at July 1, 2022 |  | 1.6 |  |  | $ | 49.26 |  |  | 3.6 |  | $ | 36 |  |
| Vested and expected to vest at July 1, 2022 |  | 1.6 |  |  | $ | 49.01 |  |  | 3.5 |  | $ | 36 |  |
| Exercisable at July 1, 2022 |  | 1.1 |  |  | $ | 41.53 |  |  | 2.8 |  | $ | 31 |  |

[0001137789-22-000055:notes:225]
The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company’s ordinary shares for the options that were in-the-money at July 1, 2022. During fiscal years 2022, 2021 and 2020, the aggregate intrinsic value of options exercised under the Company’s share option plans was $11 million, $31 million and $22 million, respectively, determined as of the date of option exercise. The aggregate fair value of options vested during fiscal years 2022, 2021 and 2020 was approximately $4 million, $4 million and $6 million, respectively.

[0001137789-22-000055:notes:226]
At July 1, 2022, the total compensation cost related to options granted to employees but not yet recognized was approximately $6 million, net of an immaterial amount of estimated forfeitures. This cost is being amortized on a straight-line basis over a weighted-average remaining term of approximately 2.4 years and will be adjusted for subsequent changes in estimated forfeitures.

[0001137789-22-000055:notes:227]
Unvested Awards Activity

[0001137789-22-000055:notes:228]
The following is a summary of unvested award activities which do not contain a performance condition:

[0001137789-22-000055:notes:229]
| Unvested Awards |  | Number of Shares(In millions) |  | Weighted-Average Grant-Date Fair Value |
| Unvested at July 2, 2021 |  | 5.9 |  |  | $ | 47.81 |  |
| Granted |  | 1.4 |  |  | $ | 82.40 |  |
| Forfeited |  | (0.3) |  |  | $ | 56.51 |  |
| Vested |  | (2.2) |  |  | $ | 44.45 |  |
| Unvested at July 1, 2022 |  | 4.8 |  |  | $ | 58.86 |  |

[0001137789-22-000055:notes:230]
At July 1, 2022, the total compensation cost related to unvested awards granted to employees but not yet recognized was approximately $199 million, net of estimated forfeitures of approximately $16 million. This cost is being amortized on a straight-line basis over a weighted-average remaining term of 2.2 years and will be adjusted for subsequent changes in estimated forfeitures. The aggregate fair value of unvested awards vested during fiscal years 2022, 2021 and 2020 were approximately $96 million, $75 million and $71 million, respectively.

[0001137789-22-000055:notes:231]
Performance Awards

[0001137789-22-000055:notes:232]
The following is a summary of unvested award activities which contain a performance condition:

[0001137789-22-000055:notes:233]
| Performance Awards |  | Number of Shares(In millions) |  | Weighted-Average Grant-Date Fair Value |
| Performance units at July 2, 2021 |  | 1.0 |  |  | $ | 46.56 |  |
| Granted |  | 0.3 |  |  | $ | 89.69 |  |
| Forfeited |  | (0.3) |  |  | $ | 47.35 |  |
| Vested |  | (0.1) |  |  | $ | 41.71 |  |
| Performance units at July 1, 2022 |  | 0.9 |  |  | $ | 59.72 |  |

[0001137789-22-000055:notes:234]
At July 1, 2022, the total compensation cost related to performance awards granted to employees but not yet recognized was approximately $30 million, net of estimated forfeitures of approximately $4 million. This cost is being amortized on a straight-line basis over a weighted-average remaining term of 1.3 years. The aggregate fair value of performance awards vested during fiscal years 2022, 2021 and 2020 were approximately $4 million, $8 million and $12 million, respectively.

[0001137789-22-000055:notes:235]
ESPP

[0001137789-22-000055:notes:236]
During fiscal years 2022, 2021 and 2020, the aggregate intrinsic value of shares purchased under the Company's ESPP was approximately $29 million, $27 million and $19 million, respectively. At July 1, 2022, the total compensation cost related to options to purchase the Company's ordinary shares under the ESPP but not yet recognized was approximately $1.6 million. This cost will be amortized on a straight-line basis over a weighted-average period of approximately one month. During fiscal year 2022, the Company issued 0.9 million ordinary shares with a weighted-average exercise price of $64.85 per share.

[0001137789-22-000055:notes:237]
Tax-Deferred Savings Plan

[0001137789-22-000055:notes:238]
The Company has a tax-deferred savings plan, the Seagate 401(k) Plan (the "401(k) plan"), for the benefit of qualified employees. The 401(k) plan is designed to provide employees with an accumulation of funds at retirement. Qualified employees may elect to make contributions to the 401(k) plan on a bi-weekly basis. Pursuant to the 401(k) plan, the Company matches 50% of employee contributions, up to 6% of compensation, subject to maximum annual contributions of $6,000 per participating employee. During fiscal years 2022, 2021 and 2020, the Company made matching contributions of $15 million, $15 million and $15 million, respectively.

[0001137789-22-000055:notes:239]
Deferred Compensation Plan

[0001137789-22-000055:notes:240]
The Company has adopted the SDCP for the benefit of eligible employees. The plan is designed to permit certain discretionary employer contributions, in excess of the tax limits applicable to the 401(k) plan, and to permit employee deferrals in excess of certain tax limits. During fiscal year 2014, the Company entered into a TRS in order to manage the equity market risks associated with the SDCP liabilities. See Note 8. Derivative Financial Instruments contained in this report for additional information about the TRS.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001137789-22-000055:notes:241]
Guarantees
Indemnifications of Officers and Directors

[0001137789-22-000055:notes:242]
Seagate Technology, an exempted company incorporated with limited liability under the laws of the Cayman Islands (“Seagate-Cayman”) and wholly-owned subsidiary of STX, from time to time enters into indemnification agreements with the directors, officers, employees and agents of STX or any of its subsidiaries (each, an “Indemnitee”). The indemnification agreements provide indemnification in addition to any of Indemnitee’s indemnification rights under any relevant Articles of Association (or similar constitutional document), applicable law or otherwise, and indemnifies an Indemnitee for certain expenses (including attorneys’ fees), judgments, fines and settlement amounts actually and reasonably incurred by him or her in any action or proceeding, including any action by or in the right of STX or any of its subsidiaries, arising out of his or her service as a director, officer, employee or agent of STX or any of its subsidiaries or of any other entity to which he or she provides services at the Company’s request. However, Indemnitees are not indemnified under the indemnification agreements for (i) any fraud or dishonesty in the performance of Indemnitee’s duty to STX or the applicable subsidiary or (ii) Indemnitee’s conscious, intentional or willful failure to act honestly, lawfully and in good faith with a view to the best interests of the Company. In addition, the indemnification agreements provide that Seagate-Cayman will advance expenses incurred by an Indemnitee in connection with enforcement of the indemnification agreement or with the investigation, settlement or appeal of any action or proceeding against him or her as to which he or she could be indemnified.

[0001137789-22-000055:notes:243]
The nature of these indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay on behalf of its officers and directors. Historically, the Company has not made any significant indemnification payments under such indemnification agreements and no amount has been accrued in the Company’s consolidated financial statements with respect to these indemnification obligations.

[0001137789-22-000055:notes:244]
Indemnification Obligations

[0001137789-22-000055:notes:245]
The Company from time to time enters into agreements with customers, suppliers, partners and others in the ordinary course of business that provide indemnification for certain matters including, but not limited to, intellectual property infringement claims, environmental claims and breach of agreement claims. The nature of the Company’s indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the Company’s consolidated financial statements with respect to these indemnification obligations.

[0001137789-22-000055:notes:246]
Product Warranty

[0001137789-22-000055:notes:247]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product warranty return rates in order to determine its warranty obligation. As of July 1, 2022, the Company’s reserve for product warranty was $148 million compared to $136 million as of July 2, 2021. The increase of $12 million was primarily driven by an increase in the Company’s warranty return rate as compared to prior year and higher cost of repair, partially offset by continued decline in total number of units under warranty.

[0001137789-22-000055:notes:248]
Changes in the Company’s product warranty liability during the fiscal years ended July 1, 2022, July 2, 2021 and July 3, 2020 were as follows:

[0001137789-22-000055:notes:249]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |  | July 3,2020 |
| Balance, beginning of period |  | $ | 136 |  |  | $ | 151 |  |  | $ | 195 |  |
| Warranties issued |  | 79 |  |  | 76 |  |  | 86 |  |
| Repairs and replacements |  | (88) |  |  | (81) |  |  | (85) |  |
| Changes in liability for pre-existing warranties, including expirations |  | 21 |  |  | (10) |  |  | (45) |  |
| Balance, end of period |  | $ | 148 |  |  | $ | 136 |  |  | $ | 151 |  |


## us-gaap:EarningsPerShareTextBlock

[0001137789-22-000055:notes:250]
Earnings Per Share
Basic earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period. Diluted earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period and the number of additional shares that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding options, unvested RSUs and PSUs and shares to be purchased under the ESPP. The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in fair market value of the Company’s share price can result in a greater dilutive effect from potentially dilutive securities. The following table sets forth the computation of basic and diluted net income per share attributable to the shareholders of the Company:

[0001137789-22-000055:notes:251]
|  |  | Fiscal Years Ended |
| (In millions, except per share data) |  | July 1,2022 |  | July 2,2021 |  | July 3,2020 |
| Numerator: |  |  |  |  |  |  |
| Net income |  | $ | 1,649 |  |  | $ | 1,314 |  |  | $ | 1,004 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 220 |  |  | 242 |  |  | 262 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |
| Employee equity award plans |  | 4 |  |  | 3 |  |  | 3 |  |
| Total shares for purposes of calculating diluted net income per share |  | 224 |  |  | 245 |  |  | 265 |  |
| Net income per share |  |  |  |  |  |  |
| Basic |  | $ | 7.50 |  |  | $ | 5.43 |  |  | $ | 3.83 |  |
| Diluted |  | 7.36 |  |  | 5.36 |  |  | 3.79 |  |

[0001137789-22-000055:notes:252]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share were not material for the fiscal years ended July 1, 2022, July 2, 2021 and July 3, 2020.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001137789-22-000055:notes:253]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001137789-22-000055:notes:254]
Litigation

[0001137789-22-000055:notes:255]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods”. The complaint seeks damages as well as additional relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial began on April 4, 2022. On April 14, 2022, the jury returned a verdict of non-infringement for Seagate finding that Seagate had not infringed any of the asserted claims. The district court entered judgement in favor of Seagate on April 19, 2022. The parties filed post-trial motions with the district court in May 2022.

[0001137789-22-000055:notes:256]
Seagate Technology LLC, et al. v. NHK Spring Co. Ltd. and TDK Corporation, et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the United States District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc., and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and

[0001137789-22-000055:notes:257]
their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, as well as additional relief permitted by law. On March 22, 2022, Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) and the Seagate Entities entered into a commercial arrangement and release of claims (“TDK Agreement”) to fully resolve the global disputes between the Seagate Entities and TDK relating to the antitrust law claims, breach of contract claim, and other matters described in the complaint. On April 1, 2022, the Seagate Entities and TDK filed a Stipulation for Dismissal with Prejudice to dismiss with prejudice all claims against TDK.

[0001137789-22-000055:notes:258]
Environmental Matters

[0001137789-22-000055:notes:259]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001137789-22-000055:notes:260]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001137789-22-000055:notes:261]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001137789-22-000055:notes:262]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001137789-22-000055:notes:263]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the U.S., Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001137789-22-000055:notes:264]
Other Matters 
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:CommitmentsDisclosureTextBlock

[0001137789-22-000055:notes:265]
CommitmentsUnconditional Long-Term Purchase Obligations. As of July 1, 2022, the Company had unconditional long-term purchase obligations of approximately $3.0 billion, primarily related to purchases of inventory components. The Company expects the commitment to total $657 million, $589 million, $660 million, $745 million and $393 million for fiscal years 2024, 2025, 2026, 2027 and thereafter, respectively.Unconditional Long-Term Capital Expenditures. As of July 1, 2022, the Company had unconditional long-term commitment of approximately $140 million, primarily related to purchases of equipment. The Company expects the capital expenditures to total $132 million, $5 million and $3 million for fiscal years 2024, 2025 and 2026, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001137789-22-000055:notes:266]
Business Segment and Geographic Information
 The Company’s manufacturing operations are based on technology platforms that are used to produce various data storage and systems solutions that serve multiple applications and markets. The Company has determined that its Chief Operating Decision Maker, the Chief Executive Officer, evaluates performance of the Company and makes decisions regarding investments in the Company’s technology platforms and manufacturing infrastructure based on the Company’s consolidated results. As a result, the Company has concluded that its manufacture and distribution of storage solutions constitutes one reporting segment.

[0001137789-22-000055:notes:267]
In fiscal years 2022 and 2021, one customer accounted for approximately 10% and 11% of consolidated revenue, respectively. In fiscal year 2020, no customer accounted for more than 10% of consolidated revenue.

[0001137789-22-000055:notes:268]
The following table summarizes the Company’s operations by country:

[0001137789-22-000055:notes:269]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |  | July 3,2020 |
| Revenue from external customers (1): |  |  |  |  |  |  |
| Singapore |  | $ | 5,322 |  |  | $ | 5,180 |  |  | $ | 5,032 |  |
| United States |  | 4,694 |  |  | 3,656 |  |  | 3,583 |  |
| The Netherlands |  | 1,627 |  |  | 1,825 |  |  | 1,572 |  |
| Other |  | 18 |  |  | 20 |  |  | 322 |  |
| Consolidated |  | $ | 11,661 |  |  | $ | 10,681 |  |  | $ | 10,509 |  |
| Long-lived assets: |  |  |  |  |  |  |
| Thailand |  | $ | 679 |  |  | $ | 682 |  |  | $ | 681 |  |
| United States |  | 670 |  |  | 612 |  |  | 567 |  |
| Singapore |  | 557 |  |  | 570 |  |  | 601 |  |
| Other |  | 426 |  |  | 411 |  |  | 376 |  |
| Consolidated |  | $ | 2,332 |  |  | $ | 2,275 |  |  | $ | 2,225 |  |

[0001137789-22-000055:notes:270]
___________________________________ 
(1) Revenue is attributed to countries based on the bill from location.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001137789-22-000055:notes:271]
Revenue
The following table provides information about disaggregated revenue by sales channel and geographical region for the Company’s single reportable segment:

[0001137789-22-000055:notes:272]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |  | July 3,2020 |
| Revenues by Channel |  |  |  |  |  |  |
| OEMs |  | $ | 8,742 |  |  | $ | 7,403 |  |  | $ | 7,504 |  |
| Distributors |  | 1,676 |  |  | 1,854 |  |  | 1,738 |  |
| Retailers |  | 1,243 |  |  | 1,424 |  |  | 1,267 |  |
| Total |  | $ | 11,661 |  |  | $ | 10,681 |  |  | $ | 10,509 |  |
| Revenues by Geography(1) |  |  |  |  |  |  |
| Asia Pacific |  | $ | 5,340 |  |  | $ | 5,198 |  |  | $ | 5,060 |  |
| Americas |  | 4,694 |  |  | 3,656 |  |  | 3,583 |  |
| EMEA |  | 1,627 |  |  | 1,827 |  |  | 1,866 |  |
| Total |  | $ | 11,661 |  |  | $ | 10,681 |  |  | $ | 10,509 |  |

[0001137789-22-000055:notes:273]
____________________________________________________
(1) Revenue is attributed to countries based on bill from locations.


## us-gaap:SubsequentEventsTextBlock

[0001137789-22-000055:notes:274]
Subsequent Events
Dividend Declared

[0001137789-22-000055:notes:275]
On July 21, 2022, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on October 5, 2022 to shareholders of record as of the close of business on September 21, 2022.
