# STX MD&A — 0001137789-22-000055


## mdna

[0001137789-22-000055:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001137789-22-000055:mdna:2]
The following is a discussion of the Company’s financial condition, changes in financial condition and results of operations for the fiscal years ended July 1, 2022 and July 2, 2021. Discussions of year-to-year comparisons between fiscal years 2021 and 2020 are not included in this Annual Report on Form 10-K and can be found in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended July 2, 2021, which was filed with the SEC on August 6, 2021.

[0001137789-22-000055:mdna:3]
You should read this discussion in conjunction with “Item 8. Financial Statements and Supplementary Data” included elsewhere in this Annual Report on Form 10-K. Except as noted, references to any fiscal year mean the twelve-month period ending on the Friday closest to June 30 of that year. Accordingly, fiscal year 2022 and 2021 both comprised of 52 weeks and ended on July 1, 2022 and July 2, 2021, respectively. Fiscal year 2026 will be comprised of 53 weeks and will end on July 3, 2026.

[0001137789-22-000055:mdna:4]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is provided in addition to the accompanying consolidated financial statements and notes to assist readers in understanding our results of operations, financial condition and cash flows. Our MD&A is organized as follows:

[0001137789-22-000055:mdna:5]
•Fiscal Year 2022 Summary. Overview of financial and other highlights affecting us in fiscal year 2022.

[0001137789-22-000055:mdna:6]
•Results of Operations. Analysis of our financial results comparing fiscal years 2022 and 2021.

[0001137789-22-000055:mdna:7]
•Liquidity and Capital Resources. Analysis of changes in our balance sheets and cash flows, discussion of our financial condition including potential sources of liquidity, and material cash requirements and their general purpose.

[0001137789-22-000055:mdna:8]
•Critical Accounting Estimates. Accounting estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001137789-22-000055:mdna:9]
•For an overview of our business, see “Part I - Item 1. Business—Overview.”

[0001137789-22-000055:mdna:10]
38

[0001137789-22-000055:mdna:11]
Fiscal Year 2022 Summary

[0001137789-22-000055:mdna:12]
During fiscal year 2022, we shipped 631 exabytes of HDD storage capacity. We generated revenue of approximately $11.7 billion with a gross margin of 30%, net income of $1.6 billion, diluted EPS of $7.36 and our operating cash flow was $1.7 billion. We increased our unsecured revolving credit facility (“Revolving Credit Facility”) to $1.75 billion, borrowed $1.2 billion under our new term loan facility and repaid $701 million of our long-term debt. We repurchased approximately 20 million of our ordinary shares for $1.8 billion and paid $610 million in dividends.

[0001137789-22-000055:mdna:13]
Impact of COVID-19 Pandemic

[0001137789-22-000055:mdna:14]
The pandemic continues to impact our business and results of operations. During fiscal year 2022, we experienced the ongoing impacts of supply chain disruptions, higher logistics, materials and operational costs globally, as well as other inflationary and macroeconomic pressures. Additionally, constraints from certain component shortages impacted our ability to fulfill demand primarily for our non-HDD business. Our customers also continued to experience certain supply chain and demand disruptions, resulting in demand variations across certain of our end markets, including impacts from periodic governmental lockdown measures. We expect these factors will continue to impact our business and results of operations over the near term.

[0001137789-22-000055:mdna:15]
We continue to actively monitor the effects and potential impacts of the pandemic, inflation and other macroeconomic factors on all aspects of our business, supply chain, liquidity and capital resources including governmental policies that could periodically shut down an entire city where we, our suppliers or our customers operate. We are also actively working on opportunities to lower our cost structure, drive further operational efficiencies and maintain supply chain discipline including adjusting our manufacturing production plans in response to these business conditions. We are complying with governmental rules and guidelines across all of our sites. Although we are unable to predict the future impact of the pandemic on our business, results of operations, liquidity or capital resources at this time, we expect we will continue to be negatively affected if the pandemic and related public and private health measures result in substantial manufacturing or supply chain challenges, substantial reductions or delays in demand due to disruptions in the operations of our customers or partners, disruptions in local and global economies, volatility in the global financial markets, sustained reductions or volatility in overall demand trends, restrictions on the export or shipment of our products or our customer’s products, or other unexpected ramifications from the pandemic. For a further discussion of the uncertainties and business risks associated with the COVID-19 pandemic, see the section entitled “Risk Factors” in Part I, Item 1A of our Annual Report.

[0001137789-22-000055:mdna:16]
Results of Operations

[0001137789-22-000055:mdna:17]
We list in the tables below summarized information from our Consolidated Statements of Operations by dollar amounts and as a percentage of revenue:

[0001137789-22-000055:mdna:18]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |
| Revenue |  | $ | 11,661 |  |  | $ | 10,681 |  |
| Cost of revenue |  | 8,192 |  |  | 7,764 |  |
| Gross profit |  | 3,469 |  |  | 2,917 |  |
| Product development |  | 941 |  |  | 903 |  |
| Marketing and administrative |  | 559 |  |  | 502 |  |
| Amortization of intangibles |  | 11 |  |  | 12 |  |
| Restructuring and other, net |  | 3 |  |  | 8 |  |
| Income from operations |  | 1,955 |  |  | 1,492 |  |
| Other expense, net |  | (276) |  |  | (144) |  |
| Income before income taxes |  | 1,679 |  |  | 1,348 |  |
| Provision for income taxes |  | 30 |  |  | 34 |  |
| Net income |  | $ | 1,649 |  |  | $ | 1,314 |  |

[0001137789-22-000055:mdna:19]
|  |  | Fiscal Years Ended |
|  |  | July 1,2022 |  | July 2,2021 |
| Revenue |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 70 |  |  | 73 |  |
| Gross margin |  | 30 |  |  | 27 |  |
| Product development |  | 8 |  |  | 8 |  |
| Marketing and administrative |  | 5 |  |  | 5 |  |
| Amortization of intangibles |  | — |  |  | — |  |
| Restructuring and other, net |  | — |  |  | — |  |
| Operating margin |  | 17 |  |  | 14 |  |
| Other expense, net |  | (3) |  |  | (2) |  |
| Income before income taxes |  | 14 |  |  | 12 |  |
| Provision for income taxes |  | — |  |  | — |  |
| Net income |  | 14 | % |  | 12 | % |

[0001137789-22-000055:mdna:20]
The following table summarizes information regarding consolidated revenues by channel, geography, and market and HDD exabytes shipped by market and price per terabyte:

[0001137789-22-000055:mdna:21]
|  |  | Fiscal Years Ended |
|  |  | July 1,2022 |  | July 2,2021 |
| Revenues by Channel (%) |  |  |  |  |
| OEMs |  | 75 | % |  | 69 | % |
| Distributors |  | 14 | % |  | 18 | % |
| Retailers |  | 11 | % |  | 13 | % |
| Revenues by Geography (%) (1) |  |  |  |  |
| Asia Pacific |  | 46 | % |  | 49 | % |
| Americas |  | 40 | % |  | 34 | % |
| EMEA |  | 14 | % |  | 17 | % |
| Revenues by Market (%) |  |  |  |  |
| Mass capacity |  | 68 | % |  | 60 | % |
| Legacy |  | 23 | % |  | 32 | % |
| Other |  | 9 | % |  | 8 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |
| Mass capacity |  | 541 |  |  | 417 |  |
| Legacy |  | 90 |  |  | 118 |  |
| Total |  | 631 |  |  | 535 |  |
| HDD Price per Terabyte |  | $ | 17 |  |  | $ | 18 |  |

[0001137789-22-000055:mdna:22]
____________________________________________________________

[0001137789-22-000055:mdna:23]
(1) Revenue is attributed to geography based on the bill from location.

[0001137789-22-000055:mdna:24]
Revenue

[0001137789-22-000055:mdna:25]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |  | Change |  | %Change |
| Revenue |  | $ | 11,661 |  |  | $ | 10,681 |  |  | $ | 980 |  |  | 9 | % |

[0001137789-22-000055:mdna:26]
40

[0001137789-22-000055:mdna:27]
Revenue in fiscal year 2022 increased approximately 9%, or $980 million, from fiscal year 2021, primarily due to an increase in mass capacity exabytes shipped, partially offset by a decrease in legacy exabytes shipped. The mass capacity storage markets continued to increase as a percentage of our total revenue and exabytes shipped in fiscal year 2022. We expect this transition from legacy to mass capacity storage markets will continue, resulting in mass capacity continuing to increase as a percentage of our total revenue and total exabytes shipped in fiscal year 2023 and beyond. The long-term outlook for legacy markets is for a decrease in exabyte demand.

[0001137789-22-000055:mdna:28]
Cost of Revenue and Gross Margin

[0001137789-22-000055:mdna:29]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |  | Change |  | %Change |
| Cost of revenue |  | $ | 8,192 |  |  | $ | 7,764 |  |  | $ | 428 |  |  | 6 | % |
| Gross profit |  | 3,469 |  |  | 2,917 |  |  | 552 |  |  | 19 | % |
| Gross margin |  | 30 | % |  | 27 | % |  |  |  |  |

[0001137789-22-000055:mdna:30]
For fiscal year 2022, gross margin increased compared to the prior fiscal year primarily due to an increase in mass capacity exabytes shipped and improved product mix shift towards higher capacity HDDs, partially offset by higher component and logistics costs resulting from the pandemic and global inflationary pressures.

[0001137789-22-000055:mdna:31]
Operating Expenses

[0001137789-22-000055:mdna:32]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |  | Change |  | %Change |
| Product development |  | $ | 941 |  |  | $ | 903 |  |  | $ | 38 |  |  | 4 | % |
| Marketing and administrative |  | 559 |  |  | 502 |  |  | 57 |  |  | 11 | % |
| Amortization of intangibles |  | 11 |  |  | 12 |  |  | (1) |  |  | (8) | % |
| Restructuring and other, net |  | 3 |  |  | 8 |  |  | (5) |  |  | (63) | % |
| Operating expenses |  | $ | 1,514 |  |  | $ | 1,425 |  |  | $ | 89 |  |  |  |

[0001137789-22-000055:mdna:33]
Product Development Expense. Product development expenses for fiscal year 2022 increased by $38 million from fiscal year 2021 primarily due to a $25 million increase in materials expense, a $17 million increase in depreciation expenses, an $8 million increase in compensation and other employee benefits as a result of increase in share-based compensation and a $3 million increase in equipment expense, partially offset by a $12 million decrease in outside services expense and a $9 million decrease in variable compensation expense.

[0001137789-22-000055:mdna:34]
Marketing and Administrative Expense. Marketing and administrative expenses for fiscal year 2022 increased by $57 million from fiscal year 2021 primarily due to a $17 million increase in compensation and other employee benefits as a result of an increase in share-based compensation, a $16 million increase in outside services expense, a $6 million increase in travel expenses as a result of the easing of pandemic-related travel restrictions, a $5 million increase in advertising costs and a $3 million increase in information technology costs.

[0001137789-22-000055:mdna:35]
Amortization of Intangibles. Amortization of intangibles for fiscal year 2022 decreased by $1 million, as compared to fiscal year 2021, due to certain intangible assets that reached the end of their useful lives.

[0001137789-22-000055:mdna:36]
Restructuring and Other, net. Restructuring and other, net for fiscal year 2022 was not material.

[0001137789-22-000055:mdna:37]
Restructuring and other, net for fiscal year 2021 was $8 million, primarily comprised of workforce reduction costs and supplier transition costs, partially offset by a gain from the sale of a certain property and a gain upon termination of an operating lease.

[0001137789-22-000055:mdna:38]
Other Expense, net

[0001137789-22-000055:mdna:39]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |  | Change |  | %Change |
| Other expense, net |  | $ | (276) |  |  | $ | (144) |  |  | $ | (132) |  |  | 92 | % |

[0001137789-22-000055:mdna:40]
Other expense, net for fiscal year 2022 increased by $132 million compared to fiscal year 2021 primarily due to a net $97 million higher non-recurring gain from our strategic investments in the prior-year period, a $29 million increase in interest expense from the issuance of long-term debt and a $21 million increase in losses on de-designated cash flow hedges. These changes were partially offset by a $16 million decrease in foreign exchange remeasurement expense.

[0001137789-22-000055:mdna:41]
Income Taxes

[0001137789-22-000055:mdna:42]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |  | Change |  | %Change |
| Provision for income taxes |  | $ | 30 |  |  | $ | 34 |  |  | $ | (4) |  |  | (12) | % |

[0001137789-22-000055:mdna:43]
We recorded an income tax provision of $30 million for fiscal year 2022 compared to an income tax provision of $34 million for fiscal year 2021. Our fiscal year 2022 income tax provision included net tax benefits of approximately $15 million related to share-based compensation, $6 million resulting from recognition of deferred tax assets and $5 million associated with change in the applicable tax rate within our non-U.S. operations. Our fiscal year 2021 income tax provision included net tax benefits of approximately $8 million primarily associated with share-based compensation and $13 million related to the United Kingdom tax rate changes enacted in June 2021.

[0001137789-22-000055:mdna:44]
Our Irish tax resident parent holding company owns various U.S. and non-Irish subsidiaries that operate in multiple non-Irish income tax jurisdictions. Our worldwide operating income is either subject to varying rates of income tax or is exempt from income tax due to tax incentive programs we operate under in Singapore and Thailand. These tax incentives are scheduled to expire in whole or in part at various dates through 2033. Certain tax incentives may be extended if specific conditions are met.

[0001137789-22-000055:mdna:45]
Our income tax provision recorded for fiscal years 2022 and 2021 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland; and (ii) current year generation of research credits.

[0001137789-22-000055:mdna:46]
We anticipate that our effective tax rate in future periods will generally be less than the Irish statutory rate based on our ownership structure, our intention to indefinitely reinvest earnings from our subsidiaries outside of Ireland and the potential future increases in our valuation allowance for deferred tax assets.

[0001137789-22-000055:mdna:47]
Liquidity and Capital Resources

[0001137789-22-000055:mdna:48]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash will continue to be sufficient to fund our operations and meet our cash requirements for the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs, will allow us to manage the ongoing impacts of the pandemic on our business operations for the foreseeable future. However, some challenges posed by the pandemic to our industry and to our business continue to remain uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to the pandemic.

[0001137789-22-000055:mdna:49]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of July 1, 2022.

[0001137789-22-000055:mdna:50]
Cash and Cash Equivalents

[0001137789-22-000055:mdna:51]
|  |  | As of |  |  |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |  | Change |
| Cash and cash equivalents |  | $ | 615 |  |  | $ | 1,209 |  |  | $ | (594) |  |

[0001137789-22-000055:mdna:52]
Our cash and cash equivalents decreased by $594 million from July 2, 2021 primarily as a result of repurchases of our ordinary shares of $1.8 billion, repayment of long-term debt of $701 million, payment of dividends to our shareholders of $610 million and payments for capital expenditures of $381 million, partially offset by net cash of $1.7 billion provided by operating activities and net proceeds of $1.2 billion from issuance of long-term debt. The following table summarizes results from the Consolidated Statement of Cash Flows for the periods indicated:

[0001137789-22-000055:mdna:53]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 1,2022 |  | July 2,2021 |
| Net cash flow provided by (used in): |  |  |  |  |
| Operating activities |  | $ | 1,657 |  |  | $ | 1,626 |  |
| Investing activities |  | (352) |  |  | (466) |  |
| Financing activities |  | (1,899) |  |  | (1,673) |  |
| Net decrease in cash, cash equivalents and restricted cash |  | $ | (594) |  |  | $ | (513) |  |

[0001137789-22-000055:mdna:54]
Cash Provided by Operating Activities

[0001137789-22-000055:mdna:55]
Cash provided by operating activities for fiscal year 2022 was approximately $1.7 billion and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-22-000055:mdna:56]
•an increase of $228 million in accounts payable, primarily due to timing of payments and an increase in materials purchased; partially offset by

[0001137789-22-000055:mdna:57]
•an increase of $374 million in accounts receivable, primarily due to linearity of sales; and

[0001137789-22-000055:mdna:58]
•an increase of $361 million in inventories, primarily due to timing of shipments, and an increase in materials purchased for production of higher capacity drives and to mitigate supply chain disruptions.

[0001137789-22-000055:mdna:59]
Cash provided by operating activities for fiscal year 2021 was approximately $1.6 billion and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-22-000055:mdna:60]
•an increase of $58 million in accrued employee compensation, primarily due to an increase in our variable compensation expense; partially offset by

[0001137789-22-000055:mdna:61]
•an increase of $64 million in inventories, primarily due to an increase in materials purchased for increased production of higher capacity drives and to mitigate supply chain disruptions; and

[0001137789-22-000055:mdna:62]
•an increase of $42 million in accounts receivable, primarily due to an increase in revenue.

[0001137789-22-000055:mdna:63]
Cash Used in Investing Activities

[0001137789-22-000055:mdna:64]
In fiscal year 2022, we used $352 million for net cash investing activities, which was primarily due to payments for the purchase of property, equipment and leasehold improvements of $381 million and payments for the purchase of investments of $18 million, partially offset by proceeds from the sale of investments of $47 million.

[0001137789-22-000055:mdna:65]
In fiscal year 2021, we used $466 million for net cash investing activities, which was primarily due to payments for the purchase of property, equipment and leasehold improvements of approximately $498 million, partially offset by proceeds from the sale of investments of $29 million

[0001137789-22-000055:mdna:66]
Cash Used in Financing Activities

[0001137789-22-000055:mdna:67]
Net cash used in financing activities of $1.9 billion for fiscal year 2022 was primarily attributable to the following activities:

[0001137789-22-000055:mdna:68]
•$1.8 billion in payments for repurchases of our ordinary shares;

[0001137789-22-000055:mdna:69]
•$701 million net repurchases of long-term debt; and

[0001137789-22-000055:mdna:70]
•$610 million in dividend payments; partially offset by

[0001137789-22-000055:mdna:71]
•$1.2 billion from the issuance of long-term debt; and

[0001137789-22-000055:mdna:72]
•$68 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-22-000055:mdna:73]
Net cash used in financing activities of $1.7 billion for fiscal year 2021 was primarily attributable to the following activities:

[0001137789-22-000055:mdna:74]
•$2.0 billion in payments for repurchases of our ordinary shares; and

[0001137789-22-000055:mdna:75]
•$649 million in dividend payments; partially offset by

[0001137789-22-000055:mdna:76]
•$986 million from the issuance of Senior Notes; and

[0001137789-22-000055:mdna:77]
•$108 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-22-000055:mdna:78]
Liquidity Sources

[0001137789-22-000055:mdna:79]
Our primary sources of liquidity as of July 1, 2022, consist of: (1) approximately $615 million in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.75 billion available for borrowing under our senior unsecured revolving credit facility (“Revolving Credit Facility”), which is part of our credit agreement (the “Credit Agreement”).

[0001137789-22-000055:mdna:80]
As of July 1, 2022, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-22-000055:mdna:81]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The term of the Revolving Credit Facility is through October 14, 2026. As of July 1, 2022, we were in compliance with all of the covenants under our debt agreements. Based on our current outlook and the information we currently have available to us, we expect to be in compliance with the covenants in our debt agreements over the next 12 months.

[0001137789-22-000055:mdna:82]
As of July 1, 2022, cash and cash equivalents held by non-Irish subsidiaries was $614 million. This amount is potentially subject to taxation in Ireland upon repatriation by means of a dividend into our Irish parent. However, it is our intent to indefinitely reinvest earnings of non-Irish subsidiaries outside of Ireland and our current plans do not demonstrate a need to repatriate such earnings by means of a taxable Irish dividend. Should funds be needed in the Irish parent company and should we be unable to fund parent company activities through means other than a taxable Irish dividend, we would be required to accrue and pay Irish taxes on such dividend.

[0001137789-22-000055:mdna:83]
We believe that our sources of cash will be sufficient to fund our operations and meet our cash requirements for at least the next 12 months. Our ability to fund liquidity requirements beyond 12 months will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. For additional information on factors that could impact our ability to fund our operations and meet our cash requirements, including the COVID-19 pandemic, see the section entitled “Risk Factors” in Part I, Item 1A of this Annual Report.

[0001137789-22-000055:mdna:84]
Cash Requirements and Commitments

[0001137789-22-000055:mdna:85]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend and any future strategic investments.

[0001137789-22-000055:mdna:86]
Purchase obligations

[0001137789-22-000055:mdna:87]
Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. From time to time, we enter into long-term, non-cancelable purchase commitments or make large up-front investments with certain suppliers in order to secure certain components or technologies for the production of our products or to supplement our internal manufacturing capacity for certain components. As of July 1, 2022, we had unconditional purchase obligations of approximately $4.5 billion, primarily related to purchases of inventory components with our suppliers. We expect $1.5 billion of these commitments to be paid within one year.

[0001137789-22-000055:mdna:88]
Capital expenditures

[0001137789-22-000055:mdna:89]
We incur material capital expenditures to design and manufacture our products that depend on advanced technologies and manufacturing techniques. As of July 1, 2022, we had unconditional commitment of $307 million primarily related to purchases of equipment, of which approximately $167 million is expected to be paid within one year. For fiscal year 2023, we expect capital expenditures to be aligned to our long-term targeted range of 4% to 6% of revenue.

[0001137789-22-000055:mdna:90]
Operating leases

[0001137789-22-000055:mdna:91]
We are a lessee in several operating leases related to real estate facilities for warehouse and office space. As of July 1, 2022, the amount of future minimum rent expense for both occupied and vacated facilities net of sublease income under non-cancelable operating lease contracts was $58 million, of which $14 million is expected to be paid within one year. Refer to “Item 8. Financial Statements and Supplementary Data—Note 6. Leases” for details.

[0001137789-22-000055:mdna:92]
Long-term debt and interest payments on debt

[0001137789-22-000055:mdna:93]
As of July 1, 2022, the future principal payment obligation on our long-term debt was $5.7 billion, of which $585 million will mature within one year. As of July 1, 2022, future interest payments on these outstanding debt is estimated to be approximately $1.3 billion, of which $223 million is expected to be paid within one year. From time to time, we may repurchase any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 8. Financial Statements and Supplementary Data—Note 4. Debt” for more details.

[0001137789-22-000055:mdna:94]
Income Tax

[0001137789-22-000055:mdna:95]
As of July 1, 2022, we had a liability for unrecognized tax benefits and an accrual for the payment of related interest totaling $3 million, none of which is expected to be settled within one year. Outside of one year, we are unable to make a reasonably reliable estimate of when cash settlement with a taxing authority will occur.

[0001137789-22-000055:mdna:96]
Dividends

[0001137789-22-000055:mdna:97]
On July 21, 2022, our Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on October 5, 2022 to shareholders of record as of the close of business on September 21, 2022. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-22-000055:mdna:98]
Share repurchases

[0001137789-22-000055:mdna:99]
From time to time, at the Company’s discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means, including through the use of derivative transactions. Our Board of Directors increased the authorization for the repurchase of our outstanding ordinary shares by $3.0 billion on October 21, 2020, and $2.0 billion on February 22, 2021. During fiscal year 2022, we repurchased approximately 21 million of our ordinary shares including shares withheld for statutory tax withholdings related to vesting of employee equity awards. See “Item 5. Market for Registrant’s Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities-Repurchases of Our Equity Securities.” As of July 1, 2022, $2.4 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-22-000055:mdna:100]
We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated

[0001137789-22-000055:mdna:101]
transactions, open market purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-22-000055:mdna:102]
Critical Accounting Policies and Estimates

[0001137789-22-000055:mdna:103]
The Company’s accounting policies are more fully described in “Item 8. Financial Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of Significant Accounting Policies ”. The methods, estimates and judgments we use in applying our most critical accounting policies have a significant impact on the results we report in our consolidated financial statements. Critical accounting estimates are those estimates that involve a significant level of estimation uncertainty and have had or are reasonably likely to have a material impact on our financial condition or results of operations. Based on this definition, our most critical accounting policies include: Revenue - Sales Program Accruals, Warranty and Income Taxes. Below, we discuss these policies further, as well as the estimates and judgments involved. We also have other accounting policies and accounting estimates relating to uncollectible customer accounts, valuation of inventories, assessing goodwill and other long-lived assets for impairment, valuation of share-based payments and restructuring. We believe that these other accounting policies and accounting estimates either do not generally require us to make estimates and judgments that are as difficult or as subjective, or it is less likely that they would have a material impact on our reported results of operations for a given period.

[0001137789-22-000055:mdna:104]
Revenue - Sales Program Accruals. We record estimated variable consideration at the time of revenue recognition as a reduction to revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer's volume of purchases from us or other agreed upon rebate programs. For the distribution and retail channel, these sales incentive programs typically involve estimating the most likely amount of rebates related to a customer's level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Total sales programs were 14% and 14% of gross revenue in fiscal years 2022 and 2021, respectively. Adjustments to revenues due to under or over accruals for sales programs related to revenues reported in prior quarterly periods were less than 1% of gross revenue in fiscal years 2022 and 2021.

[0001137789-22-000055:mdna:105]
Warranty. We estimate probable product warranty costs at the time revenue is recognized. Our warranty provision considers estimated product failure rates, trends (including the timing of product returns during the warranty periods), and estimated repair or replacement costs related to product quality issues, if any. Unforeseen component failures or exceptional component performance can result in changes to warranty costs. We also exercise judgment in estimating our ability to sell refurbished products based on historical experience. Our judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited experience with those products upon which to base our warranty estimates. If actual warranty costs differ substantially from our estimates, revisions to the estimated warranty liability would be required, which could have a material adverse effect on our results of operations.

[0001137789-22-000055:mdna:106]
Income Taxes. We make certain estimates and judgments in determining income tax expense for financial statement purposes. These estimates and judgments occur in the calculation of tax credits, recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for income tax and financial statement purposes, as well as tax liabilities associated with uncertain tax positions.

[0001137789-22-000055:mdna:107]
The deferred tax assets we record each period depend primarily on our ability to generate future taxable income in the United States and certain non-U.S. jurisdictions. Each period, we evaluate the need for a valuation allowance for our deferred tax assets and, if necessary, adjust the valuation allowance so that net deferred tax assets are recorded only to the extent we conclude it is more likely than not that these deferred tax assets will be realized.

[0001137789-22-000055:mdna:108]
In evaluating our ability to recover our deferred tax assets, in full or in part, we consider all available positive and negative evidence, including our past operating results, and our forecast of future earnings, future taxable income and prudent and feasible tax planning strategies. The assumptions utilized in determining future taxable income require significant judgment and are consistent with the plans and estimates we are using to manage the underlying businesses. Actual operating results in future years could differ from our current assumptions, judgments, and estimates. If our outlook for future taxable income changes significantly, our assessment of the need for, and the amount of, a valuation allowance may also change resulting in an additional tax provision or benefit.

[0001137789-22-000055:mdna:109]
Recent Accounting Pronouncements

[0001137789-22-000055:mdna:110]
See “Item 8. Financial Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.

[0001137789-22-000055:mdna:111]
46
