# STX note change history — 0001137789-22-000014 → 0001137789-22-000031


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-04-28):
[0001137789-22-000031:note_history:1]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.
  (was, 2022-01-27, similarity 0.9798):
[0001137789-22-000014:note_history:1]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

- changed (2022-04-28):
[0001137789-22-000031:note_history:2]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods”. The complaint seeks damages as well as additional relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial began on April 4, 2022. On April 14, 2022, the jury returned a verdict of non-infringement for Seagate finding that Seagate had not infringed any of the asserted claims. The district court entered judgment in favor of Seagate on April 19, 2022.
  (was, 2022-01-27, similarity 0.7755):
[0001137789-22-000014:note_history:2]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The complaint seeks damages as well as additional relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial is scheduled to begin on April 4, 2022. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.

- added (2022-04-28):
[0001137789-22-000031:note_history:3]
Seagate Technology LLC, et al. v. NHK Spring Co. Ltd. and TDK Corporation, et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the United States District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc., and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, as well as additional relief permitted by law. On March 22, 2022, Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) and the Seagate Entities entered into a commercial arrangement and release of claims (“TDK Agreement”) to fully resolve the global disputes between the Seagate Entities and TDK relating to the antitrust law claims, breach of contract claim, and other matters described in the complaint. On April 1, 2022, the Seagate Entities and TDK filed a Stipulation for Dismissal with Prejudice to dismiss with prejudice all claims against TDK.

- removed (2022-04-28):
[0001137789-22-000014:note_history:4]
Seagate Technology LLC, et al. v. NHK Spring Co. Ltd. and TDK Corporation, et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology International filed a complaint in the United States District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc., and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Company had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Company paid artificially high prices on its purchases of suspension assemblies. The Company seeks to recover the overcharges it paid for suspension assemblies, as well as additional relief permitted by law.

- removed (2022-04-28):
[0001137789-22-000014:note_history:5]
Nidec Corporation v. Seagate Technology LLC, et al. On January 18, 2021, Nidec Corporation (“Nidec”) filed a complaint against Seagate Technology LLC, Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology (Netherlands) B.V. in the United States District Court for the District of Delaware, alleging infringement of the following patents: U.S. Patent No. 8,737,017, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,742,239, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,935,528, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 10,407,775, titled “Base Plate, Hard Disk Drive, and Method of Manufacturing Base Plate,” and U.S. Patent No. 10,460,767, titled “Base Member Including Information Mark and Insulating Coating Layer, and Disk Drive Apparatus Including the Same.” (the “Delaware Action”). On March 22, 2021, Seagate initiated JAMS arbitration against Nidec under the arbitration clause of the covenant agreement between Seagate and Nidec. On July 20, 2021, the court stayed the Delaware Action pending the result of arbitration between the parties. On November 9, 2021, following a five-day arbitration hearing, the JAMS arbitration panel decided in favor of Seagate on all issues and directed Nidec to dismiss the Delaware Action. On November 15, 2021, Nidec dismissed its complaint in the Delaware Action with prejudice.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-04-28):
[0001137789-22-000031:note_history:6]
The Company’s consolidated financial statements for the fiscal year ended July 2, 2021 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 6, 2021. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 2, 2021, and the notes thereto, are adequate to make the information presented not misleading. The results of operations and the cash flows for the three and nine months ended April 1, 2022 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending July 1, 2022.
  (was, 2022-01-27, similarity 0.9671):
[0001137789-22-000014:note_history:6]
The Company’s consolidated financial statements for the fiscal year ended July 2, 2021 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 6, 2021. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 2, 2021, and the notes thereto, are adequate to make the information presented not misleading. The results of operations and the cash flows for the three and six months ended December 31, 2021 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending July 1, 2022.

- changed (2022-04-28):
[0001137789-22-000031:note_history:7]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and nine months ended April 1, 2022 and the three and nine months ended April 2, 2021 consisted of 13 and 39 weeks, respectively. Fiscal year 2022, which ends on July 1, 2022 and fiscal year 2021, which ended on July 2, 2021, are both comprised of 52 weeks. The fiscal quarters ended April 1, 2022, December 31, 2021 and April 2, 2021, are also referred to herein as the “March 2022 quarter”, the “December 2021 quarter” and the “March 2021 quarter”, respectively.
  (was, 2022-01-27, similarity 0.7007):
[0001137789-22-000014:note_history:7]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three and six months ended December 31, 2021 consisted of 13 and 26 weeks, respectively, and the three and six months ended January 1, 2021 consisted of 13 and 26 weeks, respectively. Fiscal year 2022, which ends on July 1, 2022, is comprised of 52 weeks and fiscal year 2021, which ended on July 2, 2021, was comprised of 52 weeks. The fiscal quarters ended December 31, 2021, October 1, 2021 and January 1, 2021, are also referred to herein as the “December 2021 quarter”, the “September 2021 quarter” and the “December 2020 quarter”, respectively.

- changed (2022-04-28):
[0001137789-22-000031:note_history:8]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued ASU 2019-12 (ASC Topic 740), Simplifying the Accounting for Income Taxes. This ASU simplifies accounting for income taxes by removing certain exceptions to the general principles and amending existing guidance to improve consistent application. This ASU became effective and the Company adopted the guidance in the quarter ended October 1, 2021. The adoption of this ASU did not have an impact on the Company’s condensed consolidated financial statements.
  (was, 2022-01-27, similarity 0.9698):
[0001137789-22-000014:note_history:8]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued ASU 2019-12 (ASC Topic 740), Simplifying the Accounting for Income Taxes. This ASU simplifies accounting for income taxes by removing certain exceptions to the general principles and amending existing guidance to improve consistent application. This ASU became effective and the Company adopted the guidance in the September 2021 quarter. The adoption of this ASU did not have an impact on the Company’s condensed consolidated financial statements.

- changed (2022-04-28):
[0001137789-22-000031:note_history:9]
In July 2021, the FASB issued ASU 2021-05 (ASC Topic 842), Lessors—Certain Leases with Variable Lease Payments. This ASU requires lessors to classify and account for a lease with variable lease payments that do not depend on a reference index or a rate as an operating lease if the lease would have been classified as a sales-type lease or a direct financing lease and the lessor would have otherwise recognized a day-one loss. The Company adopted the guidance in the quarter ended October 1, 2021 on a prospective basis. The adoption of this ASU did not have an impact on the Company’s condensed consolidated financial statements.
  (was, 2022-01-27, similarity 0.7687):
[0001137789-22-000014:note_history:9]
In July 2021, the FASB issued ASU 2021-05 (ASC Topic 842), Lessors—Certain Leases with Variable Lease Payments. This ASU requires lessors to classify and account for a lease with variable lease payments that do not depend on a reference index or a rate as an operating lease if the lease would have been classified as a sales-type lease or a direct financing lease and the lessor would have otherwise recognized a day-one loss. The Company adopted the guidance in the September 2021 quarter on a prospective basis. The adoption of this ASU did not have an impact on the Company’s condensed consolidated financial statements.

- added (2022-04-28):
[0001137789-22-000031:note_history:10]
In March 2020, the FASB issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. Adoption of the expedients and exceptions is permitted upon issuance of this update through December 31, 2022. The Company does not expect the adoption of this ASU to have a material impact on its condensed consolidated financial statements.

- added (2022-04-28):
[0001137789-22-000031:note_history:11]
In November 2021, the FASB issued ASU 2021-10 (ASC Topic 832), Disclosures by Business Entities about Government Assistance. This ASU requires annual disclosures that increase the transparency of transactions involving government grants, including (1) the type of transactions, (2) the accounting for those transactions and (3) the effect of those transactions on an entity’s financial statements. The Company is required to adopt this new accounting pronouncement in the first quarter of fiscal year 2023. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-04-28):
[0001137789-22-000031:note_history:12]
Debt
The following table provides details of the Company’s debt as of April 1, 2022 and July 2, 2021:

- added (2022-04-28):
[0001137789-22-000031:note_history:13]
| (Dollars in millions) |  | April 1,2022 |  | July 2,2021 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $750 issued on February 3, 2017 at 4.25% due on March 1, 2022 (the “2022 Notes”), interest payable semi-annually on March 1 and September 1 of each year, fully repaid on February 1, 2022. |  | $ | — |  |  | $ | 220 |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 541 |  |  | 541 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 464 |  |  | 461 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 499 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loan |  |  |  |  |
| $600 borrowed on October 14, 2021 at London Interbank Offered Rate (“LIBOR”) plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 600 |  |  | — |  |
| $600 borrowed on October 14, 2021 at LIBOR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | — |  |
| $500 borrowed on September 17, 2019 at LIBOR, (the “September 2019 Term Loan”), repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with a final maturity date of September 16, 2025, fully repaid on October 14, 2021. |  | — |  |  | 481 |  |
|  |  | 5,676 |  |  | 5,173 |  |
| Less: unamortized debt issuance costs |  | (32) |  |  | (34) |  |
| Debt, net of debt issuance costs |  | 5,644 |  |  | 5,139 |  |
| Less: current portion of long-term debt |  | (30) |  |  | (245) |  |
| Long-term debt, less current portion |  | $ | 5,614 |  |  | $ | 4,894 |  |

- added (2022-04-28):
[0001137789-22-000031:note_history:14]
______________________________

- added (2022-04-28):
[0001137789-22-000031:note_history:15]
(1) All unsecured senior notes are issued by Seagate HDD Cayman, and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and, pursuant to a supplemental indenture dated as of May 18, 2021, STX.

- added (2022-04-28):
[0001137789-22-000031:note_history:16]
Unsecured Senior Notes

- added (2022-04-28):
[0001137789-22-000031:note_history:17]
2022 Notes. On February 1, 2022, the entire outstanding principal amount of $220 million was repaid at par, plus accrued and unpaid interest. During the nine months ended April 2, 2021, $9 million aggregate principal amount of the 2022 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest.

- changed (2022-04-28):
[0001137789-22-000031:note_history:18]
2023 Notes. During the nine months ended April 2, 2021, $5 million aggregate principal amount of the 2023 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss of $1 million on repurchases during the nine months ended April 2, 2021, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2022-01-27, similarity 0.6714):
[0001137789-22-000014:note_history:18]
During the six months ended January 1, 2021, $9 million aggregate principal amount of the 2022 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. 
2023 Notes. During the six months ended January 1, 2021, $5 million aggregate principal amount of the 2023 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss of $1 million on repurchases during the six months ended January 1, 2021, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- changed (2022-04-28):
[0001137789-22-000031:note_history:19]
On October 14, 2021, STX and Seagate HDD Cayman entered into an amendment to the Credit Agreement (“Fifth Amendment”), which provides for a new term loan facility in the aggregate principal amount of $1.2 billion that was extended in two tranches of $600 million each (“Term Loan A1” and “Term Loan A2” and together the “Term Loans”). Term Loan A1 and Term Loan A2 were each drawn in full on the closing date for the Fifth Amendment. Term Loan A1 bears interest at a rate of LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company. Term Loan A1 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of September 16, 2025. Term Loan A2 bears interest at a rate of LIBOR plus a variable margin ranging from 1.25% to 2.5% that will be determined based on the corporate credit rating of the Company. Term Loan A2 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of July 30, 2027. The proceeds of the Terms Loans may be used for, among other things, general corporate purposes.
  (was, 2022-01-27, similarity 0.8262):
[0001137789-22-000014:note_history:19]
On October 14, 2021, STX and Seagate HDD Cayman entered into an amendment to the Credit Agreement (“Fifth Amendment”), which provides for a new term loan facility in the aggregate principal amount of $1.2 billion that was extended in two tranches of $600 million each (“Term Loan A1” and “Term Loan A2” and together the “Term Loans”). Term Loan A1 and Term Loan A2 were each drawn in full on the closing date for the Fifth Amendment. The proceeds of the Term Loans may be used for general corporate purposes, to refinance or repay the September 2019 Term Loan and to refinance or repay the 2022 Notes. Term Loan A1 bears interest at a rate of LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company. Term Loan A1 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of September 16, 2025. Term Loan A2 bears interest at a rate of LIBOR plus a variable margin ranging from 1.25% to 2.5% that will be determined based on the corporate credit rating of the Company. Term Loan A2 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of July 30, 2027. On October 14, 2021, Seagate HDD Cayman utilized part of the proceeds of Term Loan A1 to fully repay the $475 million principal amount outstanding of the September 2019 Term Loan.

- changed (2022-04-28):
[0001137789-22-000031:note_history:20]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of April 1, 2022 and expects to be in compliance for the next 12 months. As of April 1, 2022, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility.
  (was, 2022-01-27, similarity 0.9707):
[0001137789-22-000014:note_history:20]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of December 31, 2021 and expects to be in compliance for the next 12 months. As of December 31, 2021, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility.

- added (2022-04-28):
[0001137789-22-000031:note_history:21]
Future Principal Payments on Long-term Debt

- added (2022-04-28):
[0001137789-22-000031:note_history:22]
At April 1, 2022, future principal payments on long-term debt were as follows (in millions):

- added (2022-04-28):
[0001137789-22-000031:note_history:23]
| Fiscal Year |  | Amount |
| Remainder of 2022 |  | $ | — |  |
| 2023 |  | 585 |  |
| 2024 |  | 560 |  |
| 2025 |  | 562 |  |
| 2026 |  | 563 |  |
| Thereafter |  | 3,445 |  |
| Total |  | $ | 5,715 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-04-28):
[0001137789-22-000031:note_history:24]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of April 1, 2022 and July 2, 2021:
  (was, 2022-01-27, similarity 0.9666):
[0001137789-22-000014:note_history:24]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of December 31, 2021 and July 2, 2021:

- changed (2022-04-28):
[0001137789-22-000031:note_history:25]
|  |  | April 1,2022 |  | July 2,2021 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 176 |  |  | $ | — |  |  | $ | 176 |  |  | $ | 552 |  |  | $ | — |  |  | $ | 552 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 36 |  |  | (13) |  |  | 23 |  |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 213 |  |  | $ | (13) |  |  | $ | 200 |  |  | $ | 571 |  |  | $ | — |  |  | $ | 571 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 176 |  |  |  |  |  |  | $ | 551 |  |
| Included in Other current assets |  |  |  |  |  | 1 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 23 |  |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 200 |  |  |  |  |  |  | $ | 571 |  |
  (was, 2022-01-27, similarity 0.8928):
[0001137789-22-000014:note_history:25]
|  |  | December 31,2021 |  | July 2,2021 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 435 |  |  | $ | — |  |  | $ | 435 |  |  | $ | 552 |  |  | $ | — |  |  | $ | 552 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 36 |  |  | — |  |  | 36 |  |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 472 |  |  | $ | — |  |  | $ | 472 |  |  | $ | 571 |  |  | $ | — |  |  | $ | 571 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 434 |  |  |  |  |  |  | $ | 551 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 36 |  |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 472 |  |  |  |  |  |  | $ | 571 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2022-04-28):
[0001137789-22-000031:note_history:26]
The following table provides details of the Company’s debt as of April 1, 2022 and July 2, 2021:

- added (2022-04-28):
[0001137789-22-000031:note_history:27]
| (Dollars in millions) |  | April 1,2022 |  | July 2,2021 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $750 issued on February 3, 2017 at 4.25% due on March 1, 2022 (the “2022 Notes”), interest payable semi-annually on March 1 and September 1 of each year, fully repaid on February 1, 2022. |  | $ | — |  |  | $ | 220 |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 541 |  |  | 541 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 464 |  |  | 461 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 499 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loan |  |  |  |  |
| $600 borrowed on October 14, 2021 at London Interbank Offered Rate (“LIBOR”) plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 600 |  |  | — |  |
| $600 borrowed on October 14, 2021 at LIBOR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | — |  |
| $500 borrowed on September 17, 2019 at LIBOR, (the “September 2019 Term Loan”), repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with a final maturity date of September 16, 2025, fully repaid on October 14, 2021. |  | — |  |  | 481 |  |
|  |  | 5,676 |  |  | 5,173 |  |
| Less: unamortized debt issuance costs |  | (32) |  |  | (34) |  |
| Debt, net of debt issuance costs |  | 5,644 |  |  | 5,139 |  |
| Less: current portion of long-term debt |  | (30) |  |  | (245) |  |
| Long-term debt, less current portion |  | $ | 5,614 |  |  | $ | 4,894 |  |

- added (2022-04-28):
[0001137789-22-000031:note_history:28]
______________________________

- added (2022-04-28):
[0001137789-22-000031:note_history:29]
(1) All unsecured senior notes are issued by Seagate HDD Cayman, and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and, pursuant to a supplemental indenture dated as of May 18, 2021, STX.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-04-28):
[0001137789-22-000031:note_history:30]
At April 1, 2022, future principal payments on long-term debt were as follows (in millions):
  (was, 2022-01-27, similarity 0.9379):
[0001137789-22-000014:note_history:30]
At December 31, 2021, future principal payments on long-term debt were as follows (in millions):

- changed (2022-04-28):
[0001137789-22-000031:note_history:31]
| Fiscal Year |  | Amount |
| Remainder of 2022 |  | $ | — |  |
| 2023 |  | 585 |  |
| 2024 |  | 560 |  |
| 2025 |  | 562 |  |
| 2026 |  | 563 |  |
| Thereafter |  | 3,445 |  |
| Total |  | $ | 5,715 |  |
  (was, 2022-01-27, similarity 0.9937):
[0001137789-22-000014:note_history:31]
| Fiscal Year |  | Amount |
| Remainder of 2022 |  | $ | 220 |  |
| 2023 |  | 585 |  |
| 2024 |  | 560 |  |
| 2025 |  | 562 |  |
| 2026 |  | 563 |  |
| Thereafter |  | 3,445 |  |
| Total |  | $ | 5,935 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-04-28):
[0001137789-22-000031:note_history:32]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 2,149 |  |  | $ | 1,950 |  |  | $ | 6,615 |  |  | $ | 5,299 |  |
| Distributors |  | 349 |  |  | 455 |  |  | 1,418 |  |  | 1,297 |  |
| Retailers |  | 304 |  |  | 326 |  |  | 1,000 |  |  | 1,072 |  |
| Total |  | $ | 2,802 |  |  | $ | 2,731 |  |  | $ | 9,033 |  |  | $ | 7,668 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,292 |  |  | $ | 1,268 |  |  | $ | 4,308 |  |  | $ | 3,680 |  |
| Americas |  | 1,171 |  |  | 939 |  |  | 3,436 |  |  | 2,582 |  |
| EMEA |  | 339 |  |  | 524 |  |  | 1,289 |  |  | 1,406 |  |
| Total |  | $ | 2,802 |  |  | $ | 2,731 |  |  | $ | 9,033 |  |  | $ | 7,668 |  |
  (was, 2022-01-27, similarity 0.901):
[0001137789-22-000014:note_history:32]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,178 |  |  | $ | 1,741 |  |  | $ | 4,465 |  |  | $ | 3,349 |  |
| Distributors |  | 562 |  |  | 475 |  |  | 1,069 |  |  | 842 |  |
| Retailers |  | 376 |  |  | 407 |  |  | 697 |  |  | 746 |  |
| Total |  | $ | 3,116 |  |  | $ | 2,623 |  |  | $ | 6,231 |  |  | $ | 4,937 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,433 |  |  | $ | 1,306 |  |  | $ | 3,016 |  |  | $ | 2,412 |  |
| Americas |  | 1,186 |  |  | 838 |  |  | 2,265 |  |  | 1,643 |  |
| EMEA |  | 497 |  |  | 479 |  |  | 950 |  |  | 882 |  |
| Total |  | $ | 3,116 |  |  | $ | 2,623 |  |  | $ | 6,231 |  |  | $ | 4,937 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-04-28):
[0001137789-22-000031:note_history:33]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 2,149 |  |  | $ | 1,950 |  |  | $ | 6,615 |  |  | $ | 5,299 |  |
| Distributors |  | 349 |  |  | 455 |  |  | 1,418 |  |  | 1,297 |  |
| Retailers |  | 304 |  |  | 326 |  |  | 1,000 |  |  | 1,072 |  |
| Total |  | $ | 2,802 |  |  | $ | 2,731 |  |  | $ | 9,033 |  |  | $ | 7,668 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,292 |  |  | $ | 1,268 |  |  | $ | 4,308 |  |  | $ | 3,680 |  |
| Americas |  | 1,171 |  |  | 939 |  |  | 3,436 |  |  | 2,582 |  |
| EMEA |  | 339 |  |  | 524 |  |  | 1,289 |  |  | 1,406 |  |
| Total |  | $ | 2,802 |  |  | $ | 2,731 |  |  | $ | 9,033 |  |  | $ | 7,668 |  |
  (was, 2022-01-27, similarity 0.901):
[0001137789-22-000014:note_history:33]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,178 |  |  | $ | 1,741 |  |  | $ | 4,465 |  |  | $ | 3,349 |  |
| Distributors |  | 562 |  |  | 475 |  |  | 1,069 |  |  | 842 |  |
| Retailers |  | 376 |  |  | 407 |  |  | 697 |  |  | 746 |  |
| Total |  | $ | 3,116 |  |  | $ | 2,623 |  |  | $ | 6,231 |  |  | $ | 4,937 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,433 |  |  | $ | 1,306 |  |  | $ | 3,016 |  |  | $ | 2,412 |  |
| Americas |  | 1,186 |  |  | 838 |  |  | 2,265 |  |  | 1,643 |  |
| EMEA |  | 497 |  |  | 479 |  |  | 950 |  |  | 882 |  |
| Total |  | $ | 3,116 |  |  | $ | 2,623 |  |  | $ | 6,231 |  |  | $ | 4,937 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2022-04-28):
[0001137789-22-000031:note_history:34]
Subsequent Events
Dividend Declared
  (was, 2022-01-27, similarity 0.6538):
[0001137789-22-000014:note_history:34]
Dividend Declared

- added (2022-04-28):
[0001137789-22-000031:note_history:35]
On April 27, 2022, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on July 7, 2022 to shareholders of record as of the close of business on June 24, 2022.

- removed (2022-04-28):
[0001137789-22-000014:note_history:36]
On January 26, 2022, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on April 6, 2022 to shareholders of record as of the close of business on March 22, 2022.
