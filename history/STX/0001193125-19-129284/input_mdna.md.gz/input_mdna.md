# STX MD&A — 0001193125-19-129284


## mdna

[0001193125-19-129284:mdna:1]
[same as prior period, unchanged from 0001193125-19-027007:mdna:1]

[0001193125-19-129284:mdna:2]
The following is a discussion of the financial condition, changes in financial condition, and results of operations for our fiscal
quarters ended March 29, 2019, December 28, 2018 and March 30, 2018, referred to herein as the “March 2019 quarter,” the “December 2018 quarter,” and the “March 2018 quarter,” respectively. We
operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The March 2019, December 2018 and March 2018 quarters were all 13 weeks.

[0001193125-19-129284:mdna:3]
[same as prior period, unchanged from 0001193125-19-027007:mdna:3]

[0001193125-19-129284:mdna:4]
[same as prior period, unchanged from 0001193125-19-027007:mdna:4]

[0001193125-19-129284:mdna:5]
[same as prior period, unchanged from 0001193125-19-027007:mdna:5]

[0001193125-19-129284:mdna:6]
[same as prior period, unchanged from 0001193125-19-027007:mdna:6]

[0001193125-19-129284:mdna:7]
[same as prior period, unchanged from 0001193125-19-027007:mdna:7]

[0001193125-19-129284:mdna:8]
[same as prior period, unchanged from 0001193125-19-027007:mdna:8]

[0001193125-19-129284:mdna:9]
|  | • |  | the Company’s ability to effectively manage its debt obligations and comply with certain covenants in its credit facilities with respect to financial ratios and financial condition tests and maintain a favorable cash liquidity position; |

[0001193125-19-129284:mdna:10]
[same as prior period, unchanged from 0001193125-19-027007:mdna:10]

[0001193125-19-129284:mdna:11]
[same as prior period, unchanged from 0001193125-19-027007:mdna:11]

[0001193125-19-129284:mdna:12]
[same as prior period, unchanged from 0001193125-19-027007:mdna:12]

[0001193125-19-129284:mdna:13]
[same as prior period, unchanged from 0001193125-19-027007:mdna:13]

[0001193125-19-129284:mdna:14]
[same as prior period, unchanged from 0001193125-19-027007:mdna:14]

[0001193125-19-129284:mdna:15]
[same as prior period, unchanged from 0001193125-19-027007:mdna:15]

[0001193125-19-129284:mdna:16]
[same as prior period, unchanged from 0001193125-19-027007:mdna:16]

[0001193125-19-129284:mdna:17]
[same as prior period, unchanged from 0001193125-19-027007:mdna:17]

[0001193125-19-129284:mdna:18]
[same as prior period, unchanged from 0001193125-19-027007:mdna:18]

[0001193125-19-129284:mdna:19]
[same as prior period, unchanged from 0001193125-19-027007:mdna:19]

[0001193125-19-129284:mdna:20]
Our Management’s Discussion and Analysis of
Financial Condition and Results of Operations (“MD&A”) is provided in addition to the accompanying condensed consolidated financial statements and notes to assist readers in understanding our results of operations, financial condition,
and cash flows. MD&A is organized as follows:

[0001193125-19-129284:mdna:21]
[same as prior period, unchanged from 0001193125-19-027007:mdna:22]

[0001193125-19-129284:mdna:22]
|  | • |  | Overview of the March 2019 quarter. Highlights of events in the March 2019 quarter that impacted our financial position. |

[0001193125-19-129284:mdna:23]
|  | • |  | Results of Operations. An analysis of our financial results comparing the March 2019 quarter to the December 2018 quarter and the March 2018 quarter. |

[0001193125-19-129284:mdna:24]
[same as prior period, unchanged from 0001193125-19-027007:mdna:25]

[0001193125-19-129284:mdna:25]
|  | • |  | Contractual Obligations and Commitments. Overview of contractual obligations and contingent liabilities and commitments outstanding as of March 29, 2019. |

[0001193125-19-129284:mdna:26]
[same as prior period, unchanged from 0001193125-19-027007:mdna:27]

[0001193125-19-129284:mdna:27]
[same as prior period, unchanged from 0001193125-19-027007:mdna:28]

[0001193125-19-129284:mdna:28]
[same as prior period, unchanged from 0001193125-19-027007:mdna:29]

[0001193125-19-129284:mdna:29]
[same as prior period, unchanged from 0001193125-19-027007:mdna:30]

[0001193125-19-129284:mdna:30]
[same as prior period, unchanged from 0001193125-19-027007:mdna:31]

[0001193125-19-129284:mdna:31]
[same as prior period, unchanged from 0001193125-19-027007:mdna:32]

[0001193125-19-129284:mdna:32]
Overview of the March
2019 quarter

[0001193125-19-129284:mdna:33]
During the March 2019 quarter, we shipped 77 exabytes of HDD storage capacity. We generated revenue of approximately
$2.3 billion, gross margin of 26% and our operating cash flow was $438 million. We repurchased approximately 7 million of our ordinary shares for $327 million and paid $178 million in dividends. We entered into a new senior
unsecured revolving credit facility (the “2019 Revolving Credit Facility”) and borrowed $200 million from the 2019 Revolving Credit Facility.

[0001193125-19-129284:mdna:34]
[same as prior period, unchanged from 0001193125-19-027007:mdna:36]

[0001193125-19-129284:mdna:35]
[same as prior period, unchanged from 0001193125-19-027007:mdna:37]

[0001193125-19-129284:mdna:36]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | March 29,2019 |  |  | December 28,2018 |  |  | March 30,2018 |  |  | March 29,2019 |  |  | March 30,2018 |  |
| Revenue |  | $ | 2,313 |  |  | $ | 2,715 |  |  | $ | 2,803 |  |  | $ | 8,019 |  |  | $ | 8,349 |  |
| Cost of revenue |  |  | 1,712 |  |  |  | 1,921 |  |  |  | 1,956 |  |  |  | 5,711 |  |  |  | 5,889 |  |
| Gross margin |  |  | 601 |  |  |  | 794 |  |  |  | 847 |  |  |  | 2,308 |  |  |  | 2,460 |  |
| Product development |  |  | 238 |  |  |  | 246 |  |  |  | 254 |  |  |  | 750 |  |  |  | 767 |  |
| Marketing and administrative |  |  | 110 |  |  |  | 120 |  |  |  | 135 |  |  |  | 345 |  |  |  | 422 |  |
| Amortization of intangibles |  |  | 6 |  |  |  | 5 |  |  |  | 6 |  |  |  | 17 |  |  |  | 47 |  |
| Restructuring and other, net |  |  | 11 |  |  |  | 7 |  |  |  | 11 |  |  |  | 41 |  |  |  | 95 |  |
| Income from operations |  |  | 236 |  |  |  | 416 |  |  |  | 441 |  |  |  | 1,155 |  |  |  | 1,129 |  |
| Other expense, net |  |  | (21 | ) |  |  | (18 | ) |  |  | (48 | ) |  |  | (74 | ) |  |  | (177 | ) |
| Income before income taxes |  |  | 215 |  |  |  | 398 |  |  |  | 393 |  |  |  | 1,081 |  |  |  | 952 |  |
| Provision for income taxes |  |  | 20 |  |  |  | 14 |  |  |  | 12 |  |  |  | 52 |  |  |  | 231 |  |
| Net income |  | $ | 195 |  |  | $ | 384 |  |  | $ | 381 |  |  | $ | 1,029 |  |  | $ | 721 |  |
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
|  |  | March 29,2019 |  |  | December 28,2018 |  |  | March 30,2018 |  |  | March 29,2019 |  |  | March 30,2018 |  |
| Revenue |  |  | 100% |  |  |  | 100% |  |  |  | 100% |  |  |  | 100% |  |  |  | 100% |  |
| Cost of revenue |  |  | 74 |  |  |  | 71 |  |  |  | 70 |  |  |  | 71 |  |  |  | 71 |  |
| Gross margin |  |  | 26 |  |  |  | 29 |  |  |  | 30 |  |  |  | 29 |  |  |  | 29 |  |
| Product development |  |  | 10 |  |  |  | 9 |  |  |  | 9 |  |  |  | 9 |  |  |  | 9 |  |
| Marketing and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |  | 4 |  |  |  | 5 |  |
| Amortization of intangibles |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1 |  |
| Restructuring and other, net |  |  | 1 |  |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | 1 |  |
| Income from operations |  |  | 10 |  |  |  | 15 |  |  |  | 16 |  |  |  | 15 |  |  |  | 13 |  |
| Other expense, net |  |  | (1) |  |  |  | (1) |  |  |  | (2) |  |  |  | (1) |  |  |  | (2) |  |
| Income before income taxes |  |  | 9 |  |  |  | 14 |  |  |  | 14 |  |  |  | 14 |  |  |  | 11 |  |
| Provision for income taxes |  |  | 1 |  |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | 2 |  |
| Net income |  |  | 8% |  |  |  | 14% |  |  |  | 14% |  |  |  | 13% |  |  |  | 9% |  |

[0001193125-19-129284:mdna:37]
35

[0001193125-19-129284:mdna:38]
[same as prior period, unchanged from 0001193125-19-027007:mdna:40]

[0001193125-19-129284:mdna:39]
[same as prior period, unchanged from 0001193125-19-027007:mdna:41]

[0001193125-19-129284:mdna:40]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
|  |  | March 29,2019 |  |  | December 28,2018 |  |  | March 30,2018 |  |  | March 29,2019 |  |  | March 30,2018 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  |  | 68 | % |  |  | 69 | % |  |  | 70 | % |  |  | 70 | % |  |  | 69 | % |
| Distributors |  |  | 18 | % |  |  | 16 | % |  |  | 17 | % |  |  | 17 | % |  |  | 17 | % |
| Retailers |  |  | 14 | % |  |  | 15 | % |  |  | 13 | % |  |  | 13 | % |  |  | 14 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  |  | 35 | % |  |  | 27 | % |  |  | 32 | % |  |  | 32 | % |  |  | 32 | % |
| EMEA |  |  | 19 | % |  |  | 22 | % |  |  | 19 | % |  |  | 19 | % |  |  | 19 | % |
| Asia Pacific |  |  | 46 | % |  |  | 51 | % |  |  | 49 | % |  |  | 49 | % |  |  | 49 | % |
| HDD ASPs (per unit) |  | $ | 68 |  |  | $ | 68 |  |  | $ | 70 |  |  | $ | 69 |  |  | $ | 67 |  |
| HDD Exabytes Shipped |  |  | 77 |  |  |  | 87 |  |  |  | 87 |  |  |  | 263 |  |  |  | 245 |  |

[0001193125-19-129284:mdna:41]
Revenue in the March 2019 quarter decreased by $402 million from the December 2018 quarter primarily
due to the decrease in exabytes shipped as a result of lower demand for our products, seasonality declines and price erosion.

[0001193125-19-129284:mdna:42]
Revenue in the March 2019 quarter decreased by $490 million from the March 2018 quarter primarily due to the decrease in exabytes
shipped as a result of less favorable market conditions and price erosion.

[0001193125-19-129284:mdna:43]
Revenue for the nine months ended March 29, 2019
decreased by $330 million from the nine months ended March 30, 2018 primarily due to price erosion, partially offset by an increase in exabytes shipped.

[0001193125-19-129284:mdna:44]
We maintain various sales incentive programs such as channel rebates and price masking. Sales incentive programs were approximately 13%,
13% and 12% of gross drive revenue for the March 2019, December 2018 and March 2018 quarters, respectively. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods
were less than 1% of quarterly gross revenue in all periods presented.

[0001193125-19-129284:mdna:45]
[same as prior period, unchanged from 0001193125-19-027007:mdna:47]

[0001193125-19-129284:mdna:46]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 29,2019 |  | December 28,2018 |  | March 30,2018 |  | March 29,2019 |  | March 30,2018 |
| Cost of revenue |  | $ | 1,712 |  |  | $ | 1,921 |  |  | $ | 1,956 |  |  | $ | 5,711 |  |  | $ | 5,889 |  |
| Gross margin |  |  | 601 |  |  |  | 794 |  |  |  | 847 |  |  |  | 2,308 |  |  |  | 2,460 |  |
| Gross margin percentage |  |  | 26 | % |  |  | 29 | % |  |  | 30 | % |  |  | 29 | % |  |  | 29 | % |

[0001193125-19-129284:mdna:47]
Gross margin as a percentage of revenue for the March 2019 quarter decreased from the December 2018
quarter primarily driven by factory underutilization and price erosion.

[0001193125-19-129284:mdna:48]
Compared to the March 2018 quarter, gross margin as a
percentage of revenue for the March 2019 quarter decreased primarily driven by price erosion and factory underutilization.

[0001193125-19-129284:mdna:49]
Compared
to the nine months ended March 29, 2019, gross margin as a percentage of revenue for the nine months ended March 30, 2018 remained flat primarily driven by favorable product mix offset by price erosion.

[0001193125-19-129284:mdna:50]
In the March 2019 quarter, total warranty cost was 0.6% of revenue and included a favorable change in estimates of prior warranty
accruals of 0.5% of revenue due to improvements in return rates on newer generation products. Warranty cost related to new shipments was 1.1%, 1.1% and 1.3% of revenue for the March 2019, December 2018 and March 2018 quarters, respectively.

[0001193125-19-129284:mdna:51]
[same as prior period, unchanged from 0001193125-19-027007:mdna:54]

[0001193125-19-129284:mdna:52]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | March 29,2019 |  |  | December 28,2018 |  |  | March 30,2018 |  |  | March 29,2019 |  |  | March 30,2018 |  |
| Product development |  | $ | 238 |  |  | $ | 246 |  |  | $ | 254 |  |  | $ | 750 |  |  | $ | 767 |  |
| Marketing and administrative |  |  | 110 |  |  |  | 120 |  |  |  | 135 |  |  |  | 345 |  |  |  | 422 |  |
| Amortization of intangibles |  |  | 6 |  |  |  | 5 |  |  |  | 6 |  |  |  | 17 |  |  |  | 47 |  |
| Restructuring and other, net |  |  | 11 |  |  |  | 7 |  |  |  | 11 |  |  |  | 41 |  |  |  | 95 |  |
| Operating expenses |  | $ | 365 |  |  | $ | 378 |  |  | $ | 406 |  |  | $ | 1,153 |  |  | $ | 1,331 |  |

[0001193125-19-129284:mdna:53]
Product development expense. Product development expense for the March 2019 quarter decreased
by $8 million compared to the December 2018 quarter due to a $7 million decrease in other general expenses mainly as a result of timing of materials purchases, a $4 million decrease in variable compensation expense, offset by a
$2 million increase in share-based compensation expense.

[0001193125-19-129284:mdna:54]
Compared to the March 2018 quarter, Product development expense for
the March 2019 quarter decreased by $16 million primarily due to a $10 million decrease in variable compensation expense and an $8 million decrease in other general expenses due to operational efficiencies.

[0001193125-19-129284:mdna:55]
Compared to the corresponding nine months ended March 30, 2018, Product development expense for the nine months ended March 29,
2019 decreased by $17 million primarily due to an $18 million decrease in variable compensation expense and a $5 million decrease in salaries and employee benefits primarily due to the voluntary early exit program and restructuring of
our workforce in prior periods, partially offset by a $9 million increase in share-based compensation expense.

[0001193125-19-129284:mdna:56]
Marketing and
administrative expense. Marketing and administrative expense for the March 2019 quarter decreased by $10 million from the December 2018 quarter, primarily due to a decrease in other general expenses.

[0001193125-19-129284:mdna:57]
Compared to the March 2018 quarter, Marketing and administrative expense for the March 2019 quarter decreased by $25 million,
primarily due to a $4 million decrease in salaries and employee benefits as a result of the restructuring of our workforce in prior periods, a $13 million decrease in other general expenses and a $7 million decrease in variable
compensation expense.

[0001193125-19-129284:mdna:58]
Compared to the corresponding nine months ended March 30, 2018, Marketing and administrative expense for
the nine months ended March 29, 2019 decreased by $77 million, primarily due to a $31 million decrease in salaries and employee benefits as a result of the restructuring of our workforce in prior periods, a $30 million decrease
in other general expenses due to related operational efficiencies and a $15 million decrease in variable compensation expense.

[0001193125-19-129284:mdna:59]
Amortization of intangibles. Amortization of intangibles for the March 2019 quarter remained flat compared to the December
2018 quarter and March 2018 quarter. Amortization of intangibles for the nine months ended March 29, 2019 decreased by $30 million from the nine months ended March 30, 2018 due to certain intangible assets reaching the end of their
useful lives.

[0001193125-19-129284:mdna:60]
Restructuring and other, net. Restructuring and other, net for nine months ended March 29, 2019 was
comprised of charges primarily related to a voluntary early exit program. There was no new restructuring plan in the March 2019 quarter.

[0001193125-19-129284:mdna:61]
Restructuring and other, net for nine months ended March 30, 2018 was comprised of restructuring charges to reduce our global
workforce by 1,100 employees.

[0001193125-19-129284:mdna:62]
[same as prior period, unchanged from 0001193125-19-027007:mdna:65]

[0001193125-19-129284:mdna:63]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | March 29,2019 |  |  | December 28,2018 |  |  | March 30,2018 |  |  | March 29,2019 |  |  | March 30,2018 |  |
| Other expense, net |  | $ | (21 | ) |  | $ | (18 | ) |  | $ | (48 | ) |  | $ | (74 | ) |  | $ | (177 | ) |

[0001193125-19-129284:mdna:64]
Other expense, net. Other expense, net for the March 2019 quarter remained flat
compared to the December 2018 quarter.

[0001193125-19-129284:mdna:65]
Compared to the March 2018 quarter, Other expense, net for the March 2019 quarter decreased
by $27 million primarily due to a $16 million increase in interest income on our investment in a debt security, a $9 million net increase in gains due to favorable changes in foreign currency exchange rates, a $6 million decrease
in interest expense due to the repayment of certain senior notes, a $3 million decrease due to impairment charge of a strategic investment that did not recur in fiscal year 2019, offset by a $5 million decrease in interest income primarily
due to lower average invested balances.

[0001193125-19-129284:mdna:66]
Other expense, net for the nine months ended March 29, 2019 decreased by
$103 million from the corresponding period in the prior year, primarily due to a $47 million increase in interest income on our investment in a debt security, a $43 million net increase in gains due to favorable changes in foreign
currency exchange rates and a $14 million decrease in interest expense due to the repayment of certain senior notes.

[0001193125-19-129284:mdna:67]
[same as prior period, unchanged from 0001193125-19-027007:mdna:71]

[0001193125-19-129284:mdna:68]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | March 29,2019 |  |  | December 28,2018 |  |  | March 30,2018 |  |  | March 29,2019 |  |  | March 30,2018 |  |
| Provision for income taxes |  | $ | 20 |  |  | $ | 14 |  |  | $ | 12 |  |  | $ | 52 |  |  | $ | 231 |  |

[0001193125-19-129284:mdna:69]
38

[0001193125-19-129284:mdna:70]
We recorded income tax provisions of $20 million and $52 million in the three
and nine months ended March 29, 2019, respectively. The income tax provision for the three and nine months ended March 29, 2019 included approximately $9 million and $5 million of net discrete tax expense, respectively, primarily
associated with a deferred withholding tax liability resulting from a change in indefinite reinvestment assertion for a foreign subsidiary. This was partially offset by the recognition of previously unrecognized tax benefits related to the
expiration of certain statutes of limitation.

[0001193125-19-129284:mdna:71]
Our income tax provision recorded for the three and nine months ended March 29,
2019 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to
non-U.S. earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain
deferred tax assets.

[0001193125-19-129284:mdna:72]
During the nine months ended March 29, 2019, our unrecognized tax benefits excluding interest and
penalties decreased by approximately $19 million to $41 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $41 million at March 29, 2019, subject to certain future valuation
allowance reversals. During the 12 months beginning March 30, 2019, we expect that our unrecognized tax benefits could be reduced by approximately $6 million, primarily as a result of the expiration of certain statutes of limitation.

[0001193125-19-129284:mdna:73]
Our income tax provision was $12 million and $231 million in the three and nine months ended March 30, 2018, respectively.
The income tax provision for the three and nine months ended March 30, 2018 included approximately $2 million of net discrete tax benefit and approximately $195 million of net discrete tax expense, respectively. The discrete items for
the nine months ended March 30, 2018 are primarily associated with the revaluation of U.S. deferred tax assets as a result of the enactment of the Tax Act on December 22, 2017, partially offset by the recognition of previously unrecognized
tax benefits associated with the expiration of certain statutes of limitation.

[0001193125-19-129284:mdna:74]
Our income tax provision recorded for the nine months
ended March 30, 2018 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance
for certain deferred tax assets.

[0001193125-19-129284:mdna:75]
On December 22, 2017, the Tax Act was enacted into law in the United States. The Tax Act
significantly revises U.S. corporate income tax law by, among other things, lowering U.S. corporate income tax rates from 35% to 21%, implementing a territorial tax system, and imposing a one-time transition
tax on deemed repatriated earnings of non-U.S. subsidiaries.

[0001193125-19-129284:mdna:76]
The U.S. tax law changes,
including limitations on various business deductions such as executive compensation under Internal Revenue Code §162(m), will not impact our tax expense in the short-term due to our large net operating loss and tax credit carryovers and
associated valuation allowance. The Tax Act’s new international rules, including Global Intangible Low-Taxed Income (“GILTI”), Foreign Derived Intangible Income (“FDII”), and Base
Erosion Anti-Avoidance Tax (“BEAT”) are effective beginning in fiscal year 2019. For fiscal year 2019, we have included these effects of the Tax Act in our financial statements and concluded the impact will not be material.

[0001193125-19-129284:mdna:77]
As of the quarter ended September 28, 2018, pursuant to SEC Staff Accounting Bulletin (“SAB”) 118 (regarding the application of
ASC 740 associated with the enactment of the Tax Act), we had considered SAB 118 and believed our accounting under ASC 740 for the provisions of the Tax Act was complete.

[0001193125-19-129284:mdna:78]
[same as prior period, unchanged from 0001193125-19-027007:mdna:81]

[0001193125-19-129284:mdna:79]
The following
sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at
the time of purchase. Our short-term investments consist primarily of money market funds, time deposits and certificates of deposit. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We
believe our cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources
of cash have been and will continue to be sufficient to meet our cash needs for the next 12 months. We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term
investments and we do not believe the fair value of our short-term investments has significantly changed from the values reported as of March 29, 2019.

[0001193125-19-129284:mdna:80]
[same as prior period, unchanged from 0001193125-19-027007:mdna:83]

[0001193125-19-129284:mdna:81]
| (Dollars in millions) |  | March 29,2019 |  |  | June 29, 2018 |  |  | Change |  |
| Cash and cash equivalents |  | $ | 1,388 |  |  | $ | 1,853 |  |  | $ | (465 | ) |

[0001193125-19-129284:mdna:82]
Our cash and cash equivalents as of March 29, 2019 decreased by $465 million from June 29,
2018 primarily as a result of repurchases of our ordinary shares of $613 million, dividends to our shareholders of $539 million, repayment of our 2018 Senior Notes of $499 million, and payments for capital expenditures of
$451 million, partially offset by net proceeds from the borrowing on the 2019 Revolving Credit Facility of $196 million and net cash provided by operating activities.

[0001193125-19-129284:mdna:83]
[same as prior period, unchanged from 0001193125-19-027007:mdna:86]

[0001193125-19-129284:mdna:84]
Cash
provided by operating activities for the nine months ended March 29, 2019 was $1,313 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization,
share-based compensation and:

[0001193125-19-129284:mdna:85]
|  | • |  | a decrease of $296 million in accounts receivable, primarily due to a decrease in revenue and improved collections; |

[0001193125-19-129284:mdna:86]
|  | • |  | partially offset by a decrease of $366 million in accounts payable, primarily due to lower material purchases and timing of payments; and |

[0001193125-19-129284:mdna:87]
|  | • |  | a decrease of $108 million in accrued employee compensation primarily due to cash paid to our employees as part of our variable compensation plans. |

[0001193125-19-129284:mdna:88]
[same as prior period, unchanged from 0001193125-19-027007:mdna:90]

[0001193125-19-129284:mdna:89]
Cash used in investing activities for the nine months ended March 29, 2019 was $359 million, primarily attributable to the
payments for the purchase of property, equipment and leasehold improvements of $451 million, offset by the proceeds from the settlement of foreign currency forward exchange contracts of $66 million and the proceeds from the sale of
properties previously classified as held for sale of $27 million.

[0001193125-19-129284:mdna:90]
[same as prior period, unchanged from 0001193125-19-027007:mdna:92]

[0001193125-19-129284:mdna:91]
Cash used in financing activities of $1,417 million for the nine months ended March 29, 2019 was primarily attributable to the
following activities:

[0001193125-19-129284:mdna:92]
|  | • |  | $613 million in payments for repurchase of our ordinary shares; |

[0001193125-19-129284:mdna:93]
|  | • |  | $539 million in dividend payments; |

[0001193125-19-129284:mdna:94]
|  | • |  | $499 million in repayment of our 2018 Senior Notes; and |

[0001193125-19-129284:mdna:95]
[same as prior period, unchanged from 0001193125-19-027007:mdna:97]

[0001193125-19-129284:mdna:96]
|  | • |  | partially offset by $196 million in net proceeds from the borrowing on the 2019 revolving credit facility; and |

[0001193125-19-129284:mdna:97]
|  | • |  | $68 million in proceeds from the issuance of ordinary shares under employee stock plans. |

[0001193125-19-129284:mdna:98]
[same as prior period, unchanged from 0001193125-19-027007:mdna:99]

[0001193125-19-129284:mdna:99]
Our primary sources of liquidity as of March 29, 2019 consisted of: (1) approximately $1.4 billion in cash and cash
equivalents, (2) cash we expect to generate from operations, and (3) $1.1 billion available for borrowing from our 2019 Revolving Credit Facility.

[0001193125-19-129284:mdna:100]
On February 20, 2019, we terminated our senior unsecured revolving credit facility
scheduled to expire on January 15, 2020, under which we were able to draw up to $700 million. Upon termination, we and our subsidiary Seagate HDD Cayman entered into a new credit agreement which provides us with a $1.3 billion senior
unsecured revolving credit facility and an option to increase the facility by up to an aggregate of $300 million provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at
least $25 million, and (iii) the existing commitments under the facility receive 0.50% most favored nation protection.

[0001193125-19-129284:mdna:101]
As
of March 29, 2019, approximately $200 million in borrowings had been drawn and no borrowings had been utilized for letters of credit or swing line loans issued under the 2019 Revolving Credit Facility. The 2019 Revolving Credit Facility is
available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001193125-19-129284:mdna:102]
The 2019
Revolving Credit Facility includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The term of the 2019 Revolving Credit Facility is through February 20, 2024.
We were in compliance with the covenants as of March 29, 2019 and expect to be in compliance for the next 12 months.

[0001193125-19-129284:mdna:103]
Our
liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend and any future
strategic investments. Our ability to fund these requirements will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business
and other factors, some of which are beyond our control.

[0001193125-19-129284:mdna:104]
For fiscal year 2019, we expect capital expenditures to remain within our
long-term targeted range of 6% to 8% of revenue.

[0001193125-19-129284:mdna:105]
From time to time we may repurchase any of our outstanding notes in open market or
privately negotiated purchases or otherwise, or we may repurchase outstanding notes pursuant to the terms of the applicable indenture.

[0001193125-19-129284:mdna:106]
Dividends declared in the March 2019 quarter of $174 million were subsequently paid on April 3, 2019. Our Board of Directors
declared a quarterly cash dividend of $0.63 per share on April 30, 2019, which is payable on July 3, 2019 to shareholders of record at the close of business on June 19, 2019.

[0001193125-19-129284:mdna:107]
From time to time we may repurchase any of our outstanding ordinary shares through private, open market, tender offers broker-assisted
purchases or other means. On October 29, 2018, our Board of Directors authorized the repurchase of an additional $2.3 billion of its outstanding ordinary shares. As of March 29, 2019, $2.5 billion remained available for
repurchase under our existing repurchase authorization limit. All repurchases are effected as redemptions in accordance with our Articles of Association.

[0001193125-19-129284:mdna:108]
41

[0001193125-19-129284:mdna:109]
[same as prior period, unchanged from 0001193125-19-027007:mdna:109]

[0001193125-19-129284:mdna:110]
Our contractual cash obligations and commitments as of March 29, 2019, have been summarized in the table below:

[0001193125-19-129284:mdna:111]
|  |  |  |  |  | Fiscal Year(s) |  |
| (Dollars in millions) |  | Total |  |  | Remainderof 2019 |  |  | 2020-2021 |  |  | 2022-2023 |  |  | Thereafter |  |
| Contractual Cash Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt, including current portion |  | $ | 4,563 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,701 |  |  | $ | 2,862 |  |
| Interest payments on debt |  |  | 1,440 |  |  |  | 55 |  |  |  | 420 |  |  |  | 388 |  |  |  | 577 |  |
| Purchase obligations (1) |  |  | 1,207 |  |  |  | 924 |  |  |  | 102 |  |  |  | 8 |  |  |  | 173 |  |
| Operating leases (2) |  |  | 111 |  |  |  | 4 |  |  |  | 20 |  |  |  | 16 |  |  |  | 71 |  |
| Capital expenditures |  |  | 385 |  |  |  | 113 |  |  |  | 272 |  |  |  | — |  |  |  | — |  |
| Other funding requirements (3) |  |  | 13 |  |  |  | 2 |  |  |  | 11 |  |  |  | — |  |  |  | — |  |
| Subtotal |  |  | 7,719 |  |  |  | 1,098 |  |  |  | 825 |  |  |  | 2,113 |  |  |  | 3,683 |  |
| Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit or bank guarantees |  |  | 105 |  |  |  | 13 |  |  |  | 92 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 7,824 |  |  | $ | 1,111 |  |  | $ | 917 |  |  | $ | 2,113 |  |  | $ | 3,683 |  |

[0001193125-19-129284:mdna:112]
[same as prior period, unchanged from 0001193125-19-027007:mdna:112]

[0001193125-19-129284:mdna:113]
[same as prior period, unchanged from 0001193125-19-027007:mdna:113]

[0001193125-19-129284:mdna:114]
[same as prior period, unchanged from 0001193125-19-027007:mdna:114]

[0001193125-19-129284:mdna:115]
As of March 29, 2019, we had a liability of $41 million for unrecognized tax benefits excluding interest and penalties, of
which $3 million and an additional $1 million of interest and penalties could result in potential cash payments, none of which is expected to be settled within one year. Outside of one year, we are unable to make a reasonably reliable
estimate of when cash settlement with a taxing authority will occur.

[0001193125-19-129284:mdna:116]
[same as prior period, unchanged from 0001193125-19-027007:mdna:116]

[0001193125-19-129284:mdna:117]
[same as prior period, unchanged from 0001193125-19-027007:mdna:117]

[0001193125-19-129284:mdna:118]
Other than as described in “Part I, Item 1. Financial
Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies”, there have been no other material changes in our critical accounting policies and estimates. Refer to “Management’s Discussion and
Analysis of Financial Condition and Results of Operations” contained in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended June 29, 2018, as filed with
the SEC on August 3, 2018, for a discussion of our critical accounting policies and estimates.

[0001193125-19-129284:mdna:119]
[same as prior period, unchanged from 0001193125-19-027007:mdna:119]

[0001193125-19-129284:mdna:120]
See “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant
Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.
