# STX notes — 0001193125-19-129284


## stx:ScheduleOfShareRepurchasesTableTextBlock

[0001193125-19-129284:notes:1]
The following table sets forth information with respect to repurchases of the Company’s shares during the nine months ended March 29, 2019:

[0001193125-19-129284:notes:2]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Repurchases of ordinary shares |  | 13 |  |  | $ | 613 |  |
| Tax withholding related to vesting of equity awards |  | 1 |  |  | 30 |  |
| Total |  | 14 |  |  | $ | 643 |  |


## us-gaap:CommitmentsDisclosureTextBlock

[0001193125-19-129284:notes:3]
[same as prior period, unchanged from 0001193125-19-027007:notes:3]

[0001193125-19-129284:notes:4]
[same as prior period, unchanged from 0001193125-19-027007:notes:4]

[0001193125-19-129284:notes:5]
As of March 29, 2019, the Company had unconditional long-term purchase obligations of approximately $196 million, primarily related to purchase minimum quarterly amounts of inventory components at fixed contractual prices. The Company expects the commitment to total $2 million, $13 million, $8 million, $50 million, $48 million and $75 million for fiscal years 2020, 2021, 2022, 2024, 2025 and thereafter, respectively.

[0001193125-19-129284:notes:6]
[same as prior period, unchanged from 0001193125-19-027007:notes:6]

[0001193125-19-129284:notes:7]
As of March 29, 2019, the Company had $16 million of unconditional long-term commitment primarily related to purchases of equipment.


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-19-129284:notes:8]
[same as prior period, unchanged from 0001193125-19-027007:notes:8]

[0001193125-19-129284:notes:9]
[same as prior period, unchanged from 0001193125-19-027007:notes:9]

[0001193125-19-129284:notes:10]
[same as prior period, unchanged from 0001193125-19-027007:notes:10]


## us-gaap:DebtDisclosureTextBlock

[0001193125-19-129284:notes:11]
Debt

[0001193125-19-129284:notes:12]
Revolving Credit Facility

[0001193125-19-129284:notes:13]
On February 20, 2019, the Company terminated its senior unsecured revolving credit facility scheduled to expire on January 15, 2020, under which the Company was able to draw up to $700 million. Upon termination, the Company and its subsidiary Seagate HDD Cayman entered into a new credit agreement (the "2019 Revolving Credit Facility") which provides the Company with a $1.3 billion senior unsecured revolving credit facility. The term of the 2019 Revolving Credit Facility is through February 20, 2024. The loans made under the 2019 Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain other material subsidiaries of the Company fully and unconditionally guarantee the revolving credit facility. The 2019 Revolving Credit Facility also allows the Company to increase the facility by up to an aggregate of $300 million, provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at least $25 million, and (iii) the existing commitments under the facility receive 0.50% most favored nation protection. An aggregate amount of up to $75 million of the facility is available for the issuance of letters of credit, and an aggregate amount of up to $50 million of the facility is also available for swing line loans.

[0001193125-19-129284:notes:14]
The 2019 Revolving Credit Facility includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of March 29, 2019 and expects to be in compliance for the next 12 months.

[0001193125-19-129284:notes:15]
As of March 29, 2019, $200 million had been drawn and no letters of credit or swing line loans had been utilized under the 2019 Revolving Credit Facility.

[0001193125-19-129284:notes:16]
Long-Term Debt

[0001193125-19-129284:notes:17]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The Company recorded a loss of approximately $1 million and $3 million on repurchases during the three and nine months ended March 30, 2018, respectively, which is included in Other, net on the Company's Condensed Consolidated Statements of Operations. On November 15, 2018, the 2018 Notes matured and the Company repaid the entire outstanding principal amount of $499 million, plus accrued and unpaid interest.

[0001193125-19-129284:notes:18]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-19-129284:notes:19]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-19-129284:notes:20]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”).The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-19-129284:notes:21]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-19-129284:notes:22]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-19-129284:notes:23]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-19-129284:notes:24]
At March 29, 2019, future principal payments on long-term debt were as follows (in millions):

[0001193125-19-129284:notes:25]
| Fiscal Year |  | Amount |
| Remainder of 2019 |  | $ | — |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| 2022 |  | 750 |  |
| 2023 |  | 951 |  |
| Thereafter |  | 2,862 |  |
| Total |  | $ | 4,563 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0001193125-19-129284:notes:26]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of March 29, 2019:

[0001193125-19-129284:notes:27]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 239 |  |  | $ | — |  |  | $ | 239 |  |
| Time deposits and certificates of deposit |  | 300 |  |  | — |  |  | 300 |  |
| Total |  | $ | 539 |  |  | $ | — |  |  | $ | 539 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 536 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 3 |  |
| Total |  |  |  |  |  |  |  | $ | 539 |  |

[0001193125-19-129284:notes:28]
[same as prior period, unchanged from 0001193125-19-027007:notes:28]

[0001193125-19-129284:notes:29]
[same as prior period, unchanged from 0001193125-19-027007:notes:29]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-19-129284:notes:30]
[same as prior period, unchanged from 0001193125-19-027007:notes:30]

[0001193125-19-129284:notes:31]
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies. The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives in its Condensed Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The amount of net unrealized loss on cash flow hedges was less than $1 million as of March 29, 2019 and the amount of net unrealized gain on cash flow hedges was less than $1 million as of June 29, 2018.

[0001193125-19-129284:notes:32]
The Company de-designates its cash flow hedges when the forecasted hedged transactions affect earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss on the Company's Condensed Consolidated Balance Sheets are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company recognized a net loss of $1 million and net gain of $1 million in Other expense, net related to the loss of hedge designation on discontinued cash flow hedges during the three and nine months ended March 29, 2019, respectively. The Company did not recognize any net gains or losses related to the loss of hedge designation on discontinued cash flow hedges during the three and nine months ended March 30, 2018.

[0001193125-19-129284:notes:33]
[same as prior period, unchanged from 0001193125-19-027007:notes:33]

[0001193125-19-129284:notes:34]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of March 29, 2019 and June 29, 2018. All these foreign currency forward exchange contracts mature within 12 months:

[0001193125-19-129284:notes:35]
|  |  | As of March 29, 2019 |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| Thai Baht |  | $ | — |  |  | $ | 19 |  |
| Singapore Dollar |  | — |  |  | 25 |  |
| Chinese Renminbi |  | 10 |  |  | — |  |
| British Pound Sterling |  | 20 |  |  | 18 |  |
| Japanese Yen |  | 39 |  |  | 1,314 |  |
|  |  | $ | 69 |  |  | $ | 1,376 |  |

[0001193125-19-129284:notes:36]
[same as prior period, unchanged from 0001193125-19-027007:notes:36]

[0001193125-19-129284:notes:37]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plan—the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees. As of March 29, 2019, the notional investments underlying the TRS amounted to $114 million. The contract term of the TRS is through January 2020 and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company does not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001193125-19-129284:notes:38]
The following tables show the Company's derivative instruments measured at gross fair value as reflected in its Condensed Consolidated Balance Sheets as of March 29, 2019 and June 29, 2018:

[0001193125-19-129284:notes:39]
|  |  | As of March 29, 2019 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 1 |  |  | Accrued expenses |  | $ | (1 | ) |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 1 |  |  | Accrued expenses |  | (21 | ) |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 2 |  |  |  |  | $ | (22 | ) |

[0001193125-19-129284:notes:40]
[same as prior period, unchanged from 0001193125-19-027007:notes:40]

[0001193125-19-129284:notes:41]
The following tables show the effect of the Company’s derivative instruments on its Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three and nine months ended March 29, 2019:

[0001193125-19-129284:notes:42]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized inIncome on Derivatives |  | Amount of Gain/(Loss) Recognized inIncome on Derivatives |
|  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 10 |  |  | $ | 38 |  |
| Total return swap |  | Operating expenses |  | $ | 11 |  |  | $ | — |  |

[0001193125-19-129284:notes:43]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount ofGain/(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain/(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain/(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain/(Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGain/(Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) |
|  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | $ | 1 |  |  | $ | — |  |  | Other expense, net |  | $ | (1 | ) |  | $ | 1 |  |  | Other expense, net |  | $ | — |  |  | $ | 1 |  |

[0001193125-19-129284:notes:44]
As of March 30, 2018, the Company had no outstanding foreign currency forward exchange contracts and the gross fair value of the TRS reflected in the Condensed Consolidated Balance Sheet was immaterial.

[0001193125-19-129284:notes:45]
The following table shows the effect of the Company’s derivative instruments on its Condensed Consolidated Statement of Comprehensive Income and its Condensed Consolidated Statement of Operations for the three and nine months ended March 30, 2018:

[0001193125-19-129284:notes:46]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized inIncome on Derivatives |  | Amount of Gain/(Loss) Recognized inIncome on Derivatives |
|  |  | For the Three Months | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | — |  | $ | — |  |
| Total return swap |  | Operating expenses |  | $ | (2 | ) | $ | 5 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001193125-19-129284:notes:47]
[same as prior period, unchanged from 0001193125-19-027007:notes:48]

[0001193125-19-129284:notes:48]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in million) |  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,568 |  |  | $ | 1,971 |  |  | $ | 5,571 |  |  | $ | 5,801 |  |
| Distributors |  | 411 |  |  | 477 |  |  | 1,388 |  |  | 1,406 |  |
| Retailers |  | 334 |  |  | 355 |  |  | 1,060 |  |  | 1,142 |  |
| Total |  | $ | 2,313 |  |  | $ | 2,803 |  |  | $ | 8,019 |  |  | $ | 8,349 |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |
| Americas |  | $ | 796 |  |  | $ | 912 |  |  | $ | 2,533 |  |  | $ | 2,700 |  |
| EMEA |  | 448 |  |  | 522 |  |  | 1,563 |  |  | 1,561 |  |
| Asia Pacific |  | 1,069 |  |  | 1,369 |  |  | 3,923 |  |  | 4,088 |  |
| Total |  | $ | 2,313 |  |  | $ | 2,803 |  |  | $ | 8,019 |  |  | $ | 8,349 |  |

[0001193125-19-129284:notes:49]
[same as prior period, unchanged from 0001193125-19-027007:notes:50]

[0001193125-19-129284:notes:50]
[same as prior period, unchanged from 0001193125-19-027007:notes:51]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-19-129284:notes:51]
[same as prior period, unchanged from 0001193125-19-027007:notes:52]

[0001193125-19-129284:notes:52]
The Company recorded approximately $28 million and $73 million of share-based compensation expense during the three and nine months ended March 29, 2019, respectively. The Company recorded approximately $26 million and $85 million of share-based compensation expense during the three and nine months ended March 30, 2018, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001193125-19-129284:notes:53]
[same as prior period, unchanged from 0001193125-19-027007:notes:54]

[0001193125-19-129284:notes:54]
[same as prior period, unchanged from 0001193125-19-027007:notes:55]

[0001193125-19-129284:notes:55]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (In millions, except per share data) |  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
| Numerator: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 195 |  |  | $ | 381 |  |  | $ | 1,029 |  |  | $ | 721 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 281 |  |  | 286 |  |  | 284 |  |  | 288 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | 3 |  |  | 5 |  |  | 4 |  |  | 3 |  |
| Total shares for purpose of calculating diluted net income per share |  | 284 |  |  | 291 |  |  | 288 |  |  | 291 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.69 |  |  | $ | 1.33 |  |  | $ | 3.62 |  |  | $ | 2.50 |  |
| Diluted |  | $ | 0.69 |  |  | $ | 1.31 |  |  | $ | 3.57 |  |  | $ | 2.48 |  |

[0001193125-19-129284:notes:56]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share were less than 1 million for the three and nine months ended March 29, 2019, and approximately 1 million for the three and nine months ended March 30, 2018.


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001193125-19-129284:notes:57]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 238 |  |  | $ | 298 |  |  | $ | — |  |  | $ | 536 |  |
| Other current assets |  | 1 |  |  | 4 |  |  | — |  |  | 5 |  |
| Total assets |  | $ | 239 |  |  | $ | 302 |  |  | $ | — |  |  | $ | 541 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 22 |  |
| Total liabilities |  | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 22 |  |

[0001193125-19-129284:notes:58]
[same as prior period, unchanged from 0001193125-19-027007:notes:59]


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-19-129284:notes:59]
[same as prior period, unchanged from 0001193125-19-027007:notes:60]

[0001193125-19-129284:notes:60]
[same as prior period, unchanged from 0001193125-19-027007:notes:61]

[0001193125-19-129284:notes:61]
[same as prior period, unchanged from 0001193125-19-027007:notes:62]

[0001193125-19-129284:notes:62]
[same as prior period, unchanged from 0001193125-19-027007:notes:63]

[0001193125-19-129284:notes:63]
A fair value hierarchy is based on whether the market participant assumptions used in determining fair value are obtained from independent sources (observable inputs) or reflect the Company’s own assumptions of market participant valuation (unobservable inputs). A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The three levels of inputs that may be used to measure fair value are:

[0001193125-19-129284:notes:64]
[same as prior period, unchanged from 0001193125-19-027007:notes:65]

[0001193125-19-129284:notes:65]
[same as prior period, unchanged from 0001193125-19-027007:notes:66]

[0001193125-19-129284:notes:66]
[same as prior period, unchanged from 0001193125-19-027007:notes:67]

[0001193125-19-129284:notes:67]
[same as prior period, unchanged from 0001193125-19-027007:notes:68]

[0001193125-19-129284:notes:68]
[same as prior period, unchanged from 0001193125-19-027007:notes:69]

[0001193125-19-129284:notes:69]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of March 29, 2019:

[0001193125-19-129284:notes:70]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 238 |  |  | $ | — |  |  | $ | — |  |  | $ | 238 |  |
| Time deposits and certificates of deposit |  | — |  |  | 298 |  |  | — |  |  | 298 |  |
| Total cash equivalents |  | 238 |  |  | 298 |  |  | — |  |  | 536 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Derivative Assets |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Total assets |  | $ | 239 |  |  | $ | 302 |  |  | $ | — |  |  | $ | 541 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 22 |  |
| Total liabilities |  | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 22 |  |

[0001193125-19-129284:notes:71]
[same as prior period, unchanged from 0001193125-19-027007:notes:72]

[0001193125-19-129284:notes:72]
[same as prior period, unchanged from 0001193125-19-027007:notes:73]

[0001193125-19-129284:notes:73]
[same as prior period, unchanged from 0001193125-19-027007:notes:74]

[0001193125-19-129284:notes:74]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair value of all of its cash equivalents and short-term investments. For the cash equivalents and short-term investments in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry standard data providers or other third party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of March 29, 2019, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts and the TRS. The Company recognizes derivative financial instruments in its condensed consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001193125-19-129284:notes:75]
As of March 29, 2019 and June 29, 2018, the Company had no Level 3 assets or liabilities measured at fair value on a recurring basis.

[0001193125-19-129284:notes:76]
[same as prior period, unchanged from 0001193125-19-027007:notes:77]

[0001193125-19-129284:notes:77]
[same as prior period, unchanged from 0001193125-19-027007:notes:78]

[0001193125-19-129284:notes:78]
Prior to fiscal year 2019, the Company’s strategic investments in privately-held companies without readily determinable fair values were accounted for under the cost method and were recorded at historical cost at the time of investment, with adjustments to the balance only in the event of impairment. Effective June 30, 2018, the Company adopted ASU 2016-01, Financial Instruments, which changed the way the Company accounts for equity investments, excluding investments that qualify for the equity method of accounting. The Company's equity investments in privately-held companies without readily determinable fair values are now measured using the measurement alternative, defined by ASC 321, Investments - Equity Securities, as cost, less impairments, and adjusted up or down based on observable price changes in orderly transactions for identical or similar investments of the same issuer. Any adjustments resulting from impairments and/or observable price changes are recorded as Other, net in the Company's Condensed Consolidated Statements of Operations.

[0001193125-19-129284:notes:79]
As of March 29, 2019 and June 29, 2018, the carrying value of the Company’s strategic investments were $118 million. For the three and nine months ended March 30, 2018, the Company determined that a certain equity investment accounted for under the cost method was other-than-temporarily impaired and recorded a charge of $3 million in order to write down the carrying value of the investment to its fair value.  For the three and nine months ended March 29, 2019, there were no upward or downward adjustments on equity investments as a result of adoption of the measurement alternative during the September 2018 quarter.

[0001193125-19-129284:notes:80]
As of March 29, 2019 and June 29, 2018, the Company had $52 million and $26 million, respectively, of held for sale land and building (collectively, the "properties") included in Other current assets on its Condensed Consolidated Balance Sheets. Of the balance as of March 29, 2019, $24 million and $28 million are located in Asia and in the Americas, respectively. Depreciation related to the properties ceased as of the date these were determined to be held for sale. During the September 2018 quarter, the Company accepted an offer to sell the property in Asia to a third party and thereafter, recorded an impairment charge of approximately $2 million for the nine months ended March 29, 2019. The impairment charge was recorded in Restructuring and other, net in the Company's Condensed Consolidated Statement of Operations. No impairment was identified for the three months ended March 29, 2019 and for the three and nine months ended March 30, 2018. The sale of the properties are expected to be completed by the end of fiscal year 2019, subject to customary closing conditions for both properties and government approval for the sale of the property in Asia.

[0001193125-19-129284:notes:81]
[same as prior period, unchanged from 0001193125-19-027007:notes:82]

[0001193125-19-129284:notes:82]
The Company’s investment in a debt security, classified as held-to-maturity, represents shares of non-convertible preferred stock of TMC. This debt security has a maturity date of six years starting from May 31, 2018 and is classified as Investment in debt security on the Company’s Condensed Consolidated Balance Sheets. The debt security is recorded at amortized cost and its fair value approximated the carrying value at June 29, 2018. As of March 29, 2019, the fair value of this investment was $1,322 million with an unrealized gain of $4 million on the carrying value of $1,318 million. There was no other-than-temporary impairment identified for the three and nine months ended March 29, 2019. The fair value was determined utilizing Level 2 inputs such as discount rates and yield terms of similar types of securities issued by comparable companies.

[0001193125-19-129284:notes:83]
The Company’s debt is carried at amortized cost. The estimated fair value of the Company’s debt is derived using the closing price of the same debt instruments as of the date of valuation, which takes into account the yield curve, interest rates and other observable inputs. Accordingly, these fair value measurements are categorized as Level 2. The following table presents the fair value and amortized cost of the Company’s debt:

[0001193125-19-129284:notes:84]
|  |  | March 29, 2019 |  | June 29, 2018 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | — |  |  | $ | — |  |  | $ | 499 |  |  | $ | 501 |  |
| 4.25% Senior Notes due March 2022 |  | 749 |  |  | 755 |  |  | 749 |  |  | 743 |  |
| 4.75% Senior Notes due June 2023 |  | 951 |  |  | 962 |  |  | 951 |  |  | 942 |  |
| 4.875% Senior Notes due March 2024 |  | 498 |  |  | 501 |  |  | 497 |  |  | 489 |  |
| 4.75% Senior Notes due January 2025 |  | 975 |  |  | 949 |  |  | 975 |  |  | 936 |  |
| 4.875% Senior Notes due June 2027 |  | 695 |  |  | 668 |  |  | 695 |  |  | 650 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 450 |  |  | 489 |  |  | 441 |  |
| LIBOR based 2019 Revolving Credit Facility due February 2024 |  | 200 |  |  | 200 |  |  | — |  |  | — |  |
|  |  | $ | 4,557 |  |  | $ | 4,485 |  |  | $ | 4,855 |  |  | $ | 4,702 |  |
| Less: debt issuance costs |  | (35 | ) |  | — |  |  | (36 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 4,522 |  |  | $ | 4,485 |  |  | $ | 4,819 |  |  | $ | 4,702 |  |
| Less: current portion of long-term debt, net of debt issuance costs |  | — |  |  | — |  |  | (499 | ) |  | (501 | ) |
| Long-term debt, less current portion |  | $ | 4,522 |  |  | $ | 4,485 |  |  | $ | 4,320 |  |  | $ | 4,201 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-19-129284:notes:85]
[same as prior period, unchanged from 0001193125-19-027007:notes:86]

[0001193125-19-129284:notes:86]
[same as prior period, unchanged from 0001193125-19-027007:notes:87]

[0001193125-19-129284:notes:87]
The changes in the carrying amount of goodwill for the nine months ended March 29, 2019, were as follows:

[0001193125-19-129284:notes:88]
| (Dollars in millions) |  | Amount |
| Balance at June 29, 2018 |  | $ | 1,237 |  |
| Goodwill acquired |  | — |  |
| Goodwill disposed |  | — |  |
| Foreign currency translation effect |  | — |  |
| Balance at March 29, 2019 |  | $ | 1,237 |  |

[0001193125-19-129284:notes:89]
[same as prior period, unchanged from 0001193125-19-027007:notes:90]

[0001193125-19-129284:notes:90]
[same as prior period, unchanged from 0001193125-19-027007:notes:91]

[0001193125-19-129284:notes:91]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of March 29, 2019, is set forth in the following table:

[0001193125-19-129284:notes:92]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted-AverageRemaining Useful Life |
| Existing technology |  | $ | 237 |  |  | $ | (167 | ) |  | $ | 70 |  |  | 2.0 years |
| Customer relationships |  | 90 |  |  | (53 | ) |  | 37 |  |  | 3.4 years |
| Trade name |  | 17 |  |  | (16 | ) |  | 1 |  |  | 0.8 years |
| Other intangible assets |  | 41 |  |  | (20 | ) |  | 21 |  |  | 2.9 years |
| Total amortizable other intangible assets |  | $ | 385 |  |  | $ | (256 | ) |  | $ | 129 |  |  | 2.5 years |

[0001193125-19-129284:notes:93]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of June 29, 2018, is set forth in the following table:

[0001193125-19-129284:notes:94]
[same as prior period, unchanged from 0001193125-19-027007:notes:95]

[0001193125-19-129284:notes:95]
For the three and nine months ended March 29, 2019, the amortization expense of other intangible assets was $20 million and $59 million, respectively. For the three and nine months ended March 30, 2018, the amortization expense of other intangible assets was $21 million and $90 million, respectively. As of March 29, 2019, expected amortization expense for other intangible assets for each of the next five fiscal years and thereafter was as follows:

[0001193125-19-129284:notes:96]
| (Dollars in millions) |  | Amount |
| Remainder of 2019 |  | $ | 18 |  |
| 2020 |  | 57 |  |
| 2021 |  | 29 |  |
| 2022 |  | 20 |  |
| 2023 |  | 5 |  |
| Thereafter |  | — |  |
| Total |  | $ | 129 |  |


## us-gaap:HeldToMaturitySecuritiesTextBlock

[0001193125-19-129284:notes:97]
As of March 29, 2019 and June 29, 2018, the Company had approximately $1.3 billion investment in non-convertible preferred stock of Toshiba Memory Corporation ("TMC", formerly known as "K.K. Pangea"). The Company has the positive intent and ability to hold the investment until maturity. As such, the investment, with a contractual maturity of six years starting from May 31, 2018, is accounted for as a held-to-maturity debt security, carried at cost and adjusted for amortization of transaction costs into interest income. Additionally, the debt security has a contractual payment-in-kind ("PIK") income which will be paid in cash upon redemption of the investment. PIK income computed at the contractual rate is accrued into Interest income in the Company's Condensed Consolidated Statements of Operations and added to the carrying value of the Investment in debt security on its Condensed Consolidated Balance Sheets. For the three and nine months ended March 29, 2019, the PIK income earned was $16 million and $47 million, respectively. There was no other-than-temporary impairment identified for the three and nine months ended March 29, 2019. Please refer to Note 8 - Fair Value for more details.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-19-129284:notes:98]
[same as prior period, unchanged from 0001193125-19-027007:notes:99]

[0001193125-19-129284:notes:99]
The Company recorded income tax provisions of $20 million and $52 million in the three and nine months ended March 29, 2019, respectively. The income tax provision for the three and nine months ended March 29, 2019 included approximately $9 million and $5 million of net discrete tax expense, respectively, primarily associated with a deferred withholding tax liability resulting from a change in indefinite reinvestment assertion for a foreign subsidiary. This was partially offset by the recognition of previously unrecognized tax benefits related to the expiration of certain statutes of limitation.

[0001193125-19-129284:notes:100]
The Company's income tax provision recorded for the three and nine months ended March 29, 2019 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25%  to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.

[0001193125-19-129284:notes:101]
During the nine months ended March 29, 2019, the Company’s unrecognized tax benefits excluding interest and penalties decreased by approximately $19 million to $41 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $41 million at March 29, 2019, subject to certain future valuation allowance reversals. During the twelve months beginning March 30, 2019, the Company expects that its unrecognized tax benefits could be reduced by approximately $6 million, primarily as a result of the expiration of certain statutes of limitation.

[0001193125-19-129284:notes:102]
The  Company recorded income tax provisions of $12 million and $231 million in the three and nine months ended March 30, 2018, respectively. The income tax provision for the three and nine months ended March 30, 2018 included approximately $2 million of net discrete tax benefit and approximately $195 million of net discrete expense, respectively. The discrete items for the nine months ended March 30, 2018 are primarily associated with the revaluation of U.S. deferred tax assets as a result of the enactment of the Tax Act on December 22, 2017, partially offset by the recognition of previously unrecognized tax benefits associated with the expiration of certain statutes of limitation.

[0001193125-19-129284:notes:103]
The Company’s income tax provision recorded for the three and nine months ended March 30, 2018 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a reduction in the net U.S. deferred tax assets associated with revaluation to a lower U.S. tax rate.

[0001193125-19-129284:notes:104]
[same as prior period, unchanged from 0001193125-19-027007:notes:105]

[0001193125-19-129284:notes:105]
[same as prior period, unchanged from 0001193125-19-027007:notes:106]

[0001193125-19-129284:notes:106]
As of the fiscal quarter ended September 28, 2018, pursuant to SEC Staff Accounting Bulletin (“SAB”) 118 (regarding the application of ASC 740, Income Taxes (“ASC 740”) associated with the enactment of the Tax Act), the Company had considered SAB 118 and believed its accounting under ASC 740 for the provisions of the Tax Act was complete.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-19-129284:notes:107]
The fair value and amortized cost of the Company’s debt securities investments classified as available-for-sale as of March 29, 2019, by remaining contractual maturity were as follows:

[0001193125-19-129284:notes:108]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 539 |  |  | $ | 539 |  |
| Due in 1 to 5 years |  | — |  |  | — |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | — |  |  | — |  |
| Total |  | $ | 539 |  |  | $ | 539 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001193125-19-129284:notes:109]
Legal, Environmental and Other Contingencies

[0001193125-19-129284:notes:110]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001193125-19-129284:notes:111]
Intellectual Property Litigation

[0001193125-19-129284:notes:112]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al.  On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “‘635 patent”) and U.S. Patent No. 5,638,267 (the “‘267 patent”), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants were infringing U.S. Patent No. 6,314,473 (the “‘473 patent”). The district court ruled in 2010 that the ‘267 patent was out of the case.

[0001193125-19-129284:notes:113]
On August 16, 2011, the district court granted in part and denied in part the Company’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-19-129284:notes:114]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. No trial date has been set. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.

[0001193125-19-129284:notes:115]
Environmental Matters

[0001193125-19-129284:notes:116]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001193125-19-129284:notes:117]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001193125-19-129284:notes:118]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001193125-19-129284:notes:119]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001193125-19-129284:notes:120]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001193125-19-129284:notes:121]
Other Matters

[0001193125-19-129284:notes:122]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-19-129284:notes:123]
Recently Issued Accounting Pronouncements

[0001193125-19-129284:notes:124]
In February 2016 and July 2018, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") 2016-02 (ASC Topic 842), Leases ASU 2018-10, Codification Improvements to Topic 842, and Leases, ASU 2018-11, Leases (ASC Topic 842), Target Improvements, respectively. These ASUs amend a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The Company plans to adopt this guidance in the first quarter of fiscal year 2020. The Company is in the process of assessing the impact of these ASUs on its condensed consolidated financial statements.

[0001193125-19-129284:notes:125]
In June 2016, the FASB issued ASU 2016-13 (ASC Topic 326), Financial Instruments - Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held. The Company is required to adopt this guidance in the first quarter of fiscal year 2021. Early adoption is permitted in the first quarter of fiscal year 2020. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-19-129284:notes:126]
In February 2018, the FASB issued ASU 2018-02 (ASC Topic 220), Income Statement—Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 (the "Tax Act") and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. The Company is required to adopt this guidance in the first quarter of fiscal year 2020. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-19-129284:notes:127]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles - Goodwill and Other - Internal-Use Software - Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company is required to adopt the guidance in the first quarter of fiscal year 2021. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-19-129284:notes:128]
Recently Adopted Accounting Pronouncements

[0001193125-19-129284:notes:129]
In May 2014, the FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, and FASB also issued certain interpretive clarifications on this new guidance which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes the revenue recognition guidance under ASC 605. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. This ASU became effective and was adopted by the Company in the September 2018 quarter retrospectively with a cumulative adjustment to accumulated deficit at the date of adoption ("modified retrospective transition approach"). The Company has completed the adoption and implemented policies, processes and controls to support the new standard’s measurement and disclosure requirements.

[0001193125-19-129284:notes:130]
The Company applied the ASC 606 using a modified retrospective transition approach to all contracts that were not completed as of June 29, 2018. Results for reporting periods beginning June 30, 2018 are presented under ASC 606, while prior period amounts were not adjusted and continue to be reported under the historical accounting standard. As a result of the adoption, the Company identified a change in revenue recognition timing on its product sales made to certain retail customers and started to recognize revenue when the Company transfers control to the applicable customers rather than deferring recognition until those customers sell the products. In addition, the Company established accruals for the variable consideration related to customer incentives on these arrangements. On the date of initial adoption, the Company removed the related deferred income on the product sales made to these customers and recorded estimates of the accrual for variable consideration through a cumulative adjustment to accumulated deficit. The cumulative effect of the change to the Company's Condensed Consolidated Balance Sheet from the adoption of ASC 606 was as follows:

[0001193125-19-129284:notes:131]
| (Dollars in millions) |  | As of June 29, 2018 |  | Effect of adoption of ASC 606 |  | As of June 30, 2018 |
| Accounts receivable, net |  | $ | 1,184 |  |  | $ | 9 |  |  | $ | 1,193 |  |
| Inventory |  | $ | 1,053 |  |  | $ | (9 | ) |  | $ | 1,044 |  |
| Accrued expenses |  | $ | 598 |  |  | $ | (34 | ) |  | $ | 564 |  |
| Accumulated deficit |  | $ | (4,696 | ) |  | $ | 34 |  |  | $ | (4,662 | ) |

[0001193125-19-129284:notes:132]
The impact of applying the new accounting standard on the Company's condensed consolidated financial statements for the three and nine months ended March 29, 2019 was not material.

[0001193125-19-129284:notes:133]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments—Overall Recognition and Measurement of Financial Assets and Financial Liabilities, as amended by ASU 2018-03, Financial Instruments—Overall: Technical Correction and Improvements, issued in February 2018. The amendments in these ASUs require entities to measure all equity investments at fair value with changes recognized through net income. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. These ASUs became effective and were adopted by the Company in the September 2018 quarter. For equity investments without readily determinable fair value, the Company elected the measurement alternative for measurement of equity investments, defined as cost, less impairments, if any, plus or minus changes resulting from observable price changes in orderly transactions for an identical or similar investment in the same issuer until the equity investments' fair value becomes readily determinable. The adoption of this guidance had no impact on the Company's condensed consolidated financial statements and disclosures.

[0001193125-19-129284:notes:134]
In January 2017, the FASB issued ASU 2017-01 (ASC Topic 805), Business Combination: Clarifying the Definition of a Business. The amendments in this ASU change the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company adopted the guidance in the September 2018 quarter. The adoption of this guidance had no impact on the Company's condensed consolidated financial statements and disclosures.

[0001193125-19-129284:notes:135]
In May 2017, the FASB issued ASU 2017-09 (ASC Topic 718), Stock Compensation: Scope of Modification Accounting. The amendments in this ASU provide guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting. The Company adopted the guidance in the September 2018 quarter. The adoption of this guidance had no impact on its condensed consolidated financial statements and disclosures.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001193125-19-129284:notes:136]
[same as prior period, unchanged from 0001193125-19-027007:notes:137]

[0001193125-19-129284:notes:137]
[same as prior period, unchanged from 0001193125-19-027007:notes:138]

[0001193125-19-129284:notes:138]
[same as prior period, unchanged from 0001193125-19-027007:notes:139]

[0001193125-19-129284:notes:139]
[same as prior period, unchanged from 0001193125-19-027007:notes:140]

[0001193125-19-129284:notes:140]
[same as prior period, unchanged from 0001193125-19-027007:notes:141]

[0001193125-19-129284:notes:141]
[same as prior period, unchanged from 0001193125-19-027007:notes:142]

[0001193125-19-129284:notes:142]
[same as prior period, unchanged from 0001193125-19-027007:notes:143]

[0001193125-19-129284:notes:143]
The results of operations for the three and nine months ended March 29, 2019 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending June 28, 2019. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three and nine months ended March 29, 2019 and March 30, 2018 consisted of 13 weeks and 39 weeks, respectively. Fiscal year 2019, which ends on June 28, 2019, and fiscal year 2018, which ended on June 29, 2018, are both comprised of 52 weeks. The fiscal quarters ended March 29, 2019, December 28, 2018, September 28, 2018 and March 30, 2018, are also referred to herein as the “March 2019 quarter”, the “December 2018 quarter”, the "September 2018 quarter" and the “March 2018 quarter”, respectively.

[0001193125-19-129284:notes:144]
[same as prior period, unchanged from 0001193125-19-027007:notes:145]

[0001193125-19-129284:notes:145]
[same as prior period, unchanged from 0001193125-19-027007:notes:146]

[0001193125-19-129284:notes:146]
[same as prior period, unchanged from 0001193125-19-027007:notes:147]

[0001193125-19-129284:notes:147]
Effective June 30, 2018, the Company adopted a new revenue recognition policy in accordance with Accounting Standard Codification ("ASC") 606, Revenue from Contracts with Customers, using the modified retrospective transition approach as discussed in the section titled Recently Adopted Accounting Pronouncements in this Note 1. Prior to fiscal year 2019, the revenue recognition policy was based on ASC 605, Revenue Recognition. Under ASC 606, the Company determines revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, the Company satisfies a performance obligation.

[0001193125-19-129284:notes:148]
[same as prior period, unchanged from 0001193125-19-027007:notes:149]

[0001193125-19-129284:notes:149]
The Company records estimated variable consideration at the time of revenue recognition as a reduction to net revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer’s volume of purchases from Seagate or other agreed upon rebate programs. For the distribution and retailing channel, these sales incentive programs typically involve estimating the most likely amount of rebates related to a customer’s level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Marketing development program costs are accrued and recorded as a reduction to revenue at the same time that the related revenue is recognized.

[0001193125-19-129284:notes:150]
[same as prior period, unchanged from 0001193125-19-027007:notes:152]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-19-129284:notes:151]
[same as prior period, unchanged from 0001193125-19-027007:notes:153]

[0001193125-19-129284:notes:152]
[same as prior period, unchanged from 0001193125-19-027007:notes:154]

[0001193125-19-129284:notes:153]
[same as prior period, unchanged from 0001193125-19-027007:notes:155]

[0001193125-19-129284:notes:154]
[same as prior period, unchanged from 0001193125-19-027007:notes:156]

[0001193125-19-129284:notes:155]
[same as prior period, unchanged from 0001193125-19-027007:notes:157]

[0001193125-19-129284:notes:156]
[same as prior period, unchanged from 0001193125-19-027007:notes:158]

[0001193125-19-129284:notes:157]
[same as prior period, unchanged from 0001193125-19-027007:notes:159]

[0001193125-19-129284:notes:158]
[same as prior period, unchanged from 0001193125-19-027007:notes:160]

[0001193125-19-129284:notes:159]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the three and nine months ended March 29, 2019 and March 30, 2018 were as follows:

[0001193125-19-129284:notes:160]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
| Balance, beginning of period |  | $ | 222 |  |  | $ | 236 |  |  | $ | 237 |  |  | $ | 233 |  |
| Warranties issued |  | 24 |  |  | 36 |  |  | 89 |  |  | 111 |  |
| Repairs and replacements |  | (23 | ) |  | (26 | ) |  | (75 | ) |  | (80 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | (11 | ) |  | (11 | ) |  | (39 | ) |  | (29 | ) |
| Balance, end of period |  | $ | 212 |  |  | $ | 235 |  |  | $ | 212 |  |  | $ | 235 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-19-129284:notes:161]
[same as prior period, unchanged from 0001193125-19-027007:notes:163]

[0001193125-19-129284:notes:162]
| (Dollars in millions) |  | March 29, 2019 |  | June 29, 2018 |
| Property, equipment and leasehold improvements |  | $ | 9,736 |  |  | $ | 9,525 |  |
| Accumulated depreciation and amortization |  | (7,914 | ) |  | (7,733 | ) |
| Property, equipment and leasehold improvements, net |  | $ | 1,822 |  |  | $ | 1,792 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-19-129284:notes:163]
[same as prior period, unchanged from 0001193125-19-027007:notes:165]

[0001193125-19-129284:notes:164]
For the three and nine months ended March 29, 2019, the Company recorded restructuring charges of approximately $11 million and $39 million, respectively, comprised primarily of charges related to workforce reduction costs and facilities and other exit costs associated with the restructuring of its workforce. The Company's significant restructuring plans are described below. All restructuring charges are reported in Restructuring and other, net on the Company's Condensed Consolidated Statements of Operations.

[0001193125-19-129284:notes:165]
[same as prior period, unchanged from 0001193125-19-027007:notes:167]

[0001193125-19-129284:notes:166]
[same as prior period, unchanged from 0001193125-19-027007:notes:168]

[0001193125-19-129284:notes:167]
[same as prior period, unchanged from 0001193125-19-027007:notes:169]

[0001193125-19-129284:notes:168]
[same as prior period, unchanged from 0001193125-19-027007:notes:170]

[0001193125-19-129284:notes:169]
The following table summarizes the Company’s restructuring activities under all of the Company’s active restructuring plans for the nine months ended March 29, 2019:

[0001193125-19-129284:notes:170]
|  |  | December 2017 Plan |  | July 2017 Plan |  | March 2017 Plan |  | July 2016 Plan |  | Other Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at June 29, 2018 |  | $ | 5 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 11 |  |  | $ | 18 |  |  | $ | 42 |  |
| Restructuring charges |  | — |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | 29 |  |  | 4 |  |  | 40 |  |
| Cash payments |  | (5 | ) |  | (4 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (1 | ) |  | (4 | ) |  | (36 | ) |  | (6 | ) |  | (56 | ) |
| Adjustments |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | (1 | ) |
| Accrual balances at March 29, 2019 |  | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 5 |  |  | $ | 16 |  |  | $ | 25 |  |
| Total costs incurred to date as of March 29, 2019 |  | $ | 26 |  |  | $ | 8 |  |  | $ | 37 |  |  | $ | 3 |  |  | $ | 31 |  |  | $ | 3 |  |  | $ | 82 |  |  | $ | 38 |  |  | $ | 270 |  |  | $ | 63 |  |  | $ | 561 |  |
| Total expected charges to be incurred as of March 29, 2019 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |

[0001193125-19-129284:notes:171]
Additionally, the Company recorded an impairment charge of $2 million on its held for sale land and building for the nine months ended March 29, 2019, which is included in Restructuring and other, net in the Company's Condensed Consolidated Statements of Operations. The Company did not record any impairment charge for the three months ended March 29, 2019. Please refer to Note 8 - Fair Value for more details.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-19-129284:notes:172]
[same as prior period, unchanged from 0001193125-19-027007:notes:174]


## us-gaap:ScheduleOfAccountsPayableAndAccruedLiabilitiesTableTextBlock

[0001193125-19-129284:notes:173]
[same as prior period, unchanged from 0001193125-19-027007:notes:175]

[0001193125-19-129284:notes:174]
| (Dollars in millions) |  | March 29, 2019 |  | June 29, 2018 |
| Dividends payable |  | $ | 174 |  |  | $ | 181 |  |
| Other accrued expenses |  | 417 |  |  | 417 |  |
| Total accrued expenses |  | $ | 591 |  |  | $ | 598 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-19-129284:notes:175]
[same as prior period, unchanged from 0001193125-19-027007:notes:177]

[0001193125-19-129284:notes:176]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  | Unrealized Gains/(Losses) on Available-for-Sale Debt Securities |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at June 29, 2018 |  | $ | — |  |  | $ | — |  |  | $ | (4 | ) |  | $ | (12 | ) |  | $ | (16 | ) |
| Other comprehensive income (loss) before reclassifications |  | — |  |  | — |  |  | — |  |  | (4 | ) |  | (4 | ) |
| Amounts reclassified from AOCI |  | (1 | ) |  | — |  |  | — |  |  | — |  |  | (1 | ) |
| Other comprehensive income (loss) |  | (1 | ) |  | — |  |  | — |  |  | (4 | ) |  | (5 | ) |
| Balance at March 29, 2019 |  | $ | (1 | ) |  | $ | — |  |  | $ | (4 | ) |  | $ | (16 | ) |  | $ | (21 | ) |
| Balance at June 30, 2017 |  | $ | — |  |  | $ | — |  |  | $ | (5 | ) |  | $ | (12 | ) |  | $ | (17 | ) |
| Other comprehensive income (loss) before reclassifications |  | — |  |  | — |  |  | — |  |  | 9 |  |  | 9 |  |
| Amounts reclassified from AOCI |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) |  | — |  |  | — |  |  | — |  |  | 9 |  |  | 9 |  |
| Balance at March 30, 2018 |  | $ | — |  |  | $ | — |  |  | $ | (5 | ) |  | $ | (3 | ) |  | $ | (8 | ) |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-19-129284:notes:177]
[same as prior period, unchanged from 0001193125-19-027007:notes:179]

[0001193125-19-129284:notes:178]
| (Dollars in millions) |  | March 29, 2019 |  | June 29, 2018 |
| Raw materials and components |  | $ | 330 |  |  | $ | 329 |  |
| Work-in-process |  | 260 |  |  | 347 |  |
| Finished goods |  | 411 |  |  | 377 |  |
| Total inventories |  | $ | 1,001 |  |  | $ | 1,053 |  |


## us-gaap:ScheduleOfRestrictedCashAndCashEquivalentsTextBlock

[0001193125-19-129284:notes:179]
[same as prior period, unchanged from 0001193125-19-027007:notes:181]

[0001193125-19-129284:notes:180]
| (Dollars in millions) |  | March 29, 2019 |  | June 29, 2018 |  | March 30, 2018 |  | June 30, 2017 |
| Cash and cash equivalents |  | $ | 1,388 |  |  | $ | 1,853 |  |  | $ | 2,926 |  |  | $ | 2,539 |  |
| Restricted cash included in Other current assets |  | 3 |  |  | 4 |  |  | 4 |  |  | 4 |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  | $ | 1,391 |  |  | $ | 1,857 |  |  | $ | 2,930 |  |  | $ | 2,543 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-19-129284:notes:181]
[same as prior period, unchanged from 0001193125-19-027007:notes:183]

[0001193125-19-129284:notes:182]
[same as prior period, unchanged from 0001193125-19-027007:notes:184]

[0001193125-19-129284:notes:183]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 276,834,237 shares were outstanding as of March 29, 2019, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of March 29, 2019.

[0001193125-19-129284:notes:184]
[same as prior period, unchanged from 0001193125-19-027007:notes:186]

[0001193125-19-129284:notes:185]
[same as prior period, unchanged from 0001193125-19-027007:notes:187]

[0001193125-19-129284:notes:186]
[same as prior period, unchanged from 0001193125-19-027007:notes:188]

[0001193125-19-129284:notes:187]
[same as prior period, unchanged from 0001193125-19-027007:notes:189]

[0001193125-19-129284:notes:188]
[same as prior period, unchanged from 0001193125-19-027007:notes:190]

[0001193125-19-129284:notes:189]
On October 29, 2018, the Company’s Board of Directors authorized the repurchase of an additional $2.3 billion of its outstanding ordinary shares. As of March 29, 2019, $2.5 billion remained available for repurchase under the existing repurchase authorization limit.


## us-gaap:SubsequentEventsTextBlock

[0001193125-19-129284:notes:190]
Subsequent Events

[0001193125-19-129284:notes:191]
Dividend Declared

[0001193125-19-129284:notes:192]
On April 30, 2019, the Company’s Board of Directors declared a quarterly cash dividend of $0.63 per share, which will be payable on July 3, 2019 to shareholders of record as of the close of business on June 19, 2019.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-19-129284:notes:193]
[same as prior period, unchanged from 0001193125-19-027007:notes:196]

[0001193125-19-129284:notes:194]
[same as prior period, unchanged from 0001193125-19-027007:notes:197]

[0001193125-19-129284:notes:195]
As of March 29, 2019, the Company’s Other current assets included $3 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001193125-19-129284:notes:196]
As of March 29, 2019, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale debt securities were other-than-temporarily impaired as of March 29, 2019.

[0001193125-19-129284:notes:197]
[same as prior period, unchanged from 0001193125-19-027007:notes:200]

[0001193125-19-129284:notes:198]
[same as prior period, unchanged from 0001193125-19-027007:notes:201]

[0001193125-19-129284:notes:199]
[same as prior period, unchanged from 0001193125-19-027007:notes:202]

[0001193125-19-129284:notes:200]
[same as prior period, unchanged from 0001193125-19-027007:notes:203]

[0001193125-19-129284:notes:201]
[same as prior period, unchanged from 0001193125-19-027007:notes:204]

[0001193125-19-129284:notes:202]
[same as prior period, unchanged from 0001193125-19-027007:notes:205]

[0001193125-19-129284:notes:203]
[same as prior period, unchanged from 0001193125-19-027007:notes:206]

[0001193125-19-129284:notes:204]
[same as prior period, unchanged from 0001193125-19-027007:notes:207]
