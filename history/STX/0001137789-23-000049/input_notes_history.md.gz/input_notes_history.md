# STX note change history — 0001137789-23-000010 → 0001137789-23-000029


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001137789-23-000029:note_history:1]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.
  (was, 2023-01-25, similarity 0.9798):
[0001137789-23-000010:note_history:1]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

- changed (2023-04-26):
[0001137789-23-000029:note_history:2]
Lambeth Magnetic Structures LLC, v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgement in favor of Seagate on April 19, 2022. The parties filed post-trial motions with the district court in May 2022. On November 22, 2022, the court denied all pending post-trial motions. Lambeth Magnetic Structures LLC filed a notice of appeal to the Federal Circuit on December 20, 2022. A hearing date has not been set. The Company believes the asserted claims are without merit and intends to vigorously defend this case.
  (was, 2023-01-25, similarity 0.8665):
[0001137789-23-000010:note_history:2]
Lambeth Magnetic Structures LLC, v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgement in favor of Seagate on April 19, 2022. The parties filed post-trial motions with the district court in May 2022. On November 22, 2022, the court denied all pending post-trial motions. Lambeth Magnetic Structures LLC filed a notice of appeal to the Federal Circuit on December 20, 2022. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

- changed (2023-04-26):
[0001137789-23-000029:note_history:3]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the U.S. District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, as well as additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 8, 2022, the court entered an Amended Stipulation and Order of Dismissal with Prejudice to dismiss all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment Regarding Foreign Commerce and on October 14, 2022, Seagate Entities’ filed their corresponding opposition. A trial date has not been set.
  (was, 2023-01-25, similarity 0.9641):
[0001137789-23-000010:note_history:3]
Seagate Technology LLC, et al. v. Headway Technologies, Inc, et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the United States District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, as well as additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 1, 2022, the Seagate Entities and TDK filed a Stipulation for Dismissal with Prejudice to dismiss with prejudice all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment Regarding Foreign Commerce and on October 14, 2022, Seagate Entities’ filed its corresponding opposition. A trial date has not been set.

- added (2023-04-26):
[0001137789-23-000029:note_history:4]
BIS Settlement

- added (2023-04-26):
[0001137789-23-000029:note_history:5]
On April 18, 2023, the Company’s subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd (collectively, “Seagate”), entered into a settlement agreement (the “Settlement Agreement”) with the U.S. Department of Commerce’s  Bureau of Industry and Security (“BIS”) that resolves BIS’ allegations regarding Seagate’s sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, Seagate has agreed to pay $300 million to the BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. Seagate has also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the U.S. Export Administration Regulations (“EAR”), including one audit by an unaffiliated third-party consultant chosen by Seagate with expertise in U.S. export control laws and two internal audits. The Settlement Agreement also includes a denial order that is suspended and will be waived five years after the date of the order issued under the Settlement Agreement, provided that Seagate has made full and timely payments under the Settlement Agreement and timely completed the audit requirements. While Seagate is in compliance with and upon successful compliance in full with the terms of the Settlement Agreement, BIS has agreed it will not initiate any further administrative proceedings against Seagate in connection with any violation of the EAR arising out of the transactions detailed in the Settlement Agreement.

- added (2023-04-26):
[0001137789-23-000029:note_history:6]
While Seagate believed that it complied with all relevant export control laws at the time it made the hard disk drive sales at issue, Seagate determined that engaging with BIS and settling this matter was in the best interest of the Company, its customers and its shareholders. In determining to engage with BIS and resolve this matter through a settlement agreement, the Company considered a number of factors, including the risks and cost of protracted litigation involving the U.S. government, as well as the size of the potential penalty and the Company’s desire to focus on current business challenges and long-term business strategy. The Settlement Agreement includes a finding that the Company incorrectly interpreted the regulation at issue to require evaluation of only the last stage of Seagate’s hard disk drive manufacturing process rather than the entire process. As part of this settlement, Seagate has agreed not to contest BIS’ determination that the sales in question did not comply with the U.S. EAR.

- added (2023-04-26):
[0001137789-23-000029:note_history:7]
The Company accrued a charge of $300 million for the March 2023 quarter, which is reflected under BIS settlement penalty on its Condensed Consolidated Statements of Operations. As of March 31, 2023, $30 million and $270 million were included in Accrued expense and Other non-current liabilities, respectively, on its Condensed Consolidated Balance Sheet.

- added (2023-04-26):
[0001137789-23-000029:note_history:8]
From time to time, arising in the normal course of business, the Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company expects to be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.

- removed (2023-04-26):
[0001137789-23-000010:note_history:9]
On August 29, 2022, the Company received a proposed charging letter (“PCL”) from the U.S. Commerce Department’s Bureau of Industry and Security (“BIS”), alleging violations of the U.S. Export Administration Regulations (“EAR”). The PCL alleges the Company acted in violation of the EAR by providing its HDDs to a customer and its affiliates listed on the BIS Entity List between August 2020 and September 2021. The Company believes these allegations are without merit. The Company has responded to the PCL, setting forth its position that it did not engage in prohibited conduct as alleged by BIS, because, among other reasons, Seagate’s HDDs are not subject to the EAR.

- removed (2023-04-26):
[0001137789-23-000010:note_history:10]
The matters raised by the PCL remain unresolved at this time, and there can be no assurance as to the timing or terms of any final outcome. The Company is unable at this time to estimate the range of loss and/or penalty, if any, although it is possible that the outcome could have a material impact on its business, results of operations, financial condition, and cash flows. The Company has committed to compliance through its global team of international trade compliance and legal professionals and by maintaining robust trade controls, compliance policies and procedures. The Company has been cooperating with BIS and engaging in discussions with BIS to seek a resolution of this matter. If the Company is not able to reach a resolution, the Company believes that this matter will result in litigation between the Company and BIS. The Company believes that it has complied with all relevant export control laws and regulations and will defend itself vigorously.

- removed (2023-04-26):
[0001137789-23-000010:note_history:11]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001137789-23-000029:note_history:12]
The Company’s consolidated financial statements for the fiscal year ended July 1, 2022 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 5, 2022. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 1, 2022, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and nine months ended March 31, 2023 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 30, 2023.
  (was, 2023-01-25, similarity 0.9662):
[0001137789-23-000010:note_history:12]
The Company’s consolidated financial statements for the fiscal year ended July 1, 2022 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 5, 2022. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 1, 2022, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and six months ended December 30, 2022 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 30, 2023.

- changed (2023-04-26):
[0001137789-23-000029:note_history:13]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and nine months ended March 31, 2023 and the three and nine months ended April 1, 2022 consisted of 13 and 39 weeks, respectively. Fiscal years 2023 and 2022 both comprise of 52 weeks and end on June 30, 2023 and July 1, 2022, respectively. The fiscal quarters ended March 31, 2023, December 30, 2022 and April 1, 2022, are also referred to herein as the “March 2023 quarter”, the “December 2022 quarter” and the “March 2022 quarter”, respectively.
  (was, 2023-01-25, similarity 0.8142):
[0001137789-23-000010:note_history:13]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and six months ended December 30, 2022 and the three and six months ended December 31, 2021 consisted of 13 and 26 weeks, respectively. Fiscal years 2023 and 2022 both comprise of 52 weeks and end on June 30, 2023 and July 1, 2022, respectively. The fiscal quarters ended December 30, 2022, September 30, 2022 and December 31, 2021, are also referred to herein as the “December 2022 quarter”, the “September 2022 quarter” and the “December 2021 quarter”, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001137789-23-000029:note_history:14]
Debt
The following table provides details of the Company’s debt as of March 31, 2023 and July 1, 2022:
  (was, 2023-01-25, similarity 0.9524):
[0001137789-23-000010:note_history:14]
Debt
The following table provides details of the Company’s debt as of December 30, 2022 and July 1, 2022:

- changed (2023-04-26):
[0001137789-23-000029:note_history:15]
| (Dollars in millions) |  | March 31,2023 |  | July 1,2022 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | $ | 540 |  |  | $ | 540 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 500 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 465 |  |  | 466 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 500 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | — |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 585 |  |  | 600 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 585 |  |  | 600 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 585 |  |  | — |  |
|  |  | 5,992 |  |  | 5,677 |  |
| Less: unamortized debt issuance costs |  | (34) |  |  | (31) |  |
| Debt, net of debt issuance costs |  | 5,958 |  |  | 5,646 |  |
| Less: current portion of long-term debt |  | (1,118) |  |  | (584) |  |
| Long-term debt, less current portion |  | $ | 4,840 |  |  | $ | 5,062 |  |
  (was, 2023-01-25, similarity 0.9975):
[0001137789-23-000010:note_history:15]
| (Dollars in millions) |  | December 30,2022 |  | July 1,2022 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | $ | 540 |  |  | $ | 540 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 469 |  |  | 466 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 164 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 295 |  |  | 500 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 77 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | — |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 600 |  |  | 600 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | 600 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | — |  |
|  |  | 6,066 |  |  | 5,677 |  |
| Less: unamortized debt issuance costs |  | (37) |  |  | (31) |  |
| Debt, net of debt issuance costs |  | 6,029 |  |  | 5,646 |  |
| Less: current portion of long-term debt |  | (636) |  |  | (584) |  |
| Long-term debt, less current portion |  | $ | 5,393 |  |  | $ | 5,062 |  |

- added (2023-04-26):
[0001137789-23-000029:note_history:16]
| (Dollars in millions) |  |  |  |  |  |  |  |  |
| Existing Notes |  | Principal Amount Outstanding as of July 1, 2022 |  | Principal Amount Exchanged |  |  |  |  |
| July 2031 Notes |  | $ | 500 |  |  | $ | 423 |  |  |  |  |  |
| July 2029 Notes |  | 500 |  |  | 336 |  |  |  |  |  |
| January 2031 Notes |  | 500 |  |  | 205 |  |  |  |  |  |
| Total |  | $ | 1,500 |  |  | $ | 964 |  |  |  |  |  |

- changed (2023-04-26):
[0001137789-23-000029:note_history:17]
The exchange was accounted for as a debt extinguishment and the Company recorded a net gain of $204 million, which was included in Net gain recognized from early redemption of debt in the Company’s Condensed Consolidated Statements of Operations for the nine months ended March 31, 2023.
  (was, 2023-01-25, similarity 0.7583):
[0001137789-23-000010:note_history:17]
The exchange was accounted for as a debt extinguishment and the Company recorded a net gain of $204 million, in the Company’s Condensed Consolidated Statements of Operations.

- added (2023-04-26):
[0001137789-23-000029:note_history:18]
Debt Repurchases

- added (2023-04-26):
[0001137789-23-000029:note_history:19]
During the March 2023 quarter, $20 million principal amount of the January 2031 Notes, $5 million principal amount of the June 2029 Notes, and $5 million principal amount of the July 2031 Notes were repurchased for cash at a discount to their principal amounts, plus accrued and unpaid interest. The Company recorded a gain of $3 million on these repurchases during the March 2023 quarter, which was included in Net gain recognized from early redemption of debt in the Company’s Condensed Consolidated Statements of Operations.

- changed (2023-04-26):
[0001137789-23-000029:note_history:20]
The Credit Agreement provides a term loan facility in an aggregate principal amount of $1.8 billion that is extended in three tranches of $600 million each for Term Loans A1, A2 and A3 (the “Term Loans”), and a $1.75 billion senior unsecured revolving credit facility (“Revolving Credit Facility”). During the March 2023 quarter the Company repaid $45 million principal amount of the Term Loans. As of March 31, 2023, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. STX and certain of its material subsidiaries, including STUC, fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loans. The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of March 31, 2023.
  (was, 2023-01-25, similarity 0.892):
[0001137789-23-000010:note_history:20]
The Credit Agreement provides a term loan facility in an aggregate principal amount of $1.8 billion that is extended in three tranches of $600 million each for Term Loans A1, A2 and A3, and a $1.75 billion senior unsecured revolving credit facility (“Revolving Credit Facility”). As of December 30, 2022, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. STX and certain of its material subsidiaries, including STUC, fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loans A1, A2 and A3 (the “Term Loans”). The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of December 30, 2022.

- changed (2023-04-26):
[0001137789-23-000029:note_history:21]
At March 31, 2023, future principal payments on long-term debt were as follows (in millions):
  (was, 2023-01-25, similarity 0.9492):
[0001137789-23-000010:note_history:21]
At December 30, 2022, future principal payments on long-term debt were as follows (in millions):

- removed (2023-04-26):
[0001137789-23-000010:note_history:22]
| (Dollars in millions) |  |  |  |  |  |  |  |  |
| Existing Notes |  | Principal Amount Outstanding as of September 30, 2022 |  | Principal Amount Exchanged |  | Remaining Principal Amount as of December 30, 2022 |  | Net Gain Recognized From Early Redemption |
| July 2031 Notes |  | $ | 500 |  |  | $ | 423 |  |  | $ | 77 |  |  | $ | 95 |  |
| July 2029 Notes |  | 500 |  | 336 |  |  | 164 |  |  | 70 |  |
| January 2031 Notes |  | 500 |  | 205 |  |  | 295 |  |  | 39 |  |
| Total |  | $ | 1,500 |  |  | $ | 964 |  |  | $ | 536 |  |  | $ | 204 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001137789-23-000029:note_history:23]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of March 31, 2023 and July 1, 2022:
  (was, 2023-01-25, similarity 0.9726):
[0001137789-23-000010:note_history:23]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of December 30, 2022 and July 1, 2022:

- changed (2023-04-26):
[0001137789-23-000029:note_history:24]
|  |  | March 31,2023 |  | July 1,2022 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 235 |  |  | $ | — |  |  | $ | 235 |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 16 |  |  | — |  |  | 16 |  |  | 23 |  |  | — |  |  | 23 |  |
| Total |  | $ | 252 |  |  | $ | — |  |  | $ | 252 |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 234 |  |  |  |  |  |  | $ | 59 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 16 |  |  |  |  |  |  | 23 |  |
| Total |  |  |  |  |  | $ | 252 |  |  |  |  |  |  | $ | 84 |  |
  (was, 2023-01-25, similarity 0.9935):
[0001137789-23-000010:note_history:24]
|  |  | December 30,2022 |  | July 1,2022 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 173 |  |  | $ | — |  |  | $ | 173 |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 16 |  |  | — |  |  | 16 |  |  | 23 |  |  | — |  |  | 23 |  |
| Total |  | $ | 190 |  |  | $ | — |  |  | $ | 190 |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 172 |  |  |  |  |  |  | $ | 59 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 16 |  |  |  |  |  |  | 23 |  |
| Total |  |  |  |  |  | $ | 190 |  |  |  |  |  |  | $ | 84 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001137789-23-000029:note_history:25]
| (Dollars in millions) |  | March 31,2023 |  | July 1,2022 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | $ | 540 |  |  | $ | 540 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 500 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 465 |  |  | 466 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 500 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | — |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 585 |  |  | 600 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 585 |  |  | 600 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 585 |  |  | — |  |
|  |  | 5,992 |  |  | 5,677 |  |
| Less: unamortized debt issuance costs |  | (34) |  |  | (31) |  |
| Debt, net of debt issuance costs |  | 5,958 |  |  | 5,646 |  |
| Less: current portion of long-term debt |  | (1,118) |  |  | (584) |  |
| Long-term debt, less current portion |  | $ | 4,840 |  |  | $ | 5,062 |  |
  (was, 2023-01-25, similarity 0.9975):
[0001137789-23-000010:note_history:25]
| (Dollars in millions) |  | December 30,2022 |  | July 1,2022 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | $ | 540 |  |  | $ | 540 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 469 |  |  | 466 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 164 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 295 |  |  | 500 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 77 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | — |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 600 |  |  | 600 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | 600 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | — |  |
|  |  | 6,066 |  |  | 5,677 |  |
| Less: unamortized debt issuance costs |  | (37) |  |  | (31) |  |
| Debt, net of debt issuance costs |  | 6,029 |  |  | 5,646 |  |
| Less: current portion of long-term debt |  | (636) |  |  | (584) |  |
| Long-term debt, less current portion |  | $ | 5,393 |  |  | $ | 5,062 |  |


## us-gaap:ScheduleOfExtinguishmentOfDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-04-26):
[0001137789-23-000029:note_history:26]
| (Dollars in millions) |  |  |  |  |  |  |  |  |
| Existing Notes |  | Principal Amount Outstanding as of July 1, 2022 |  | Principal Amount Exchanged |  |  |  |  |
| July 2031 Notes |  | $ | 500 |  |  | $ | 423 |  |  |  |  |  |
| July 2029 Notes |  | 500 |  |  | 336 |  |  |  |  |  |
| January 2031 Notes |  | 500 |  |  | 205 |  |  |  |  |  |
| Total |  | $ | 1,500 |  |  | $ | 964 |  |  |  |  |  |

- removed (2023-04-26):
[0001137789-23-000010:note_history:27]
| (Dollars in millions) |  |  |  |  |  |  |  |  |
| Existing Notes |  | Principal Amount Outstanding as of September 30, 2022 |  | Principal Amount Exchanged |  | Remaining Principal Amount as of December 30, 2022 |  | Net Gain Recognized From Early Redemption |
| July 2031 Notes |  | $ | 500 |  |  | $ | 423 |  |  | $ | 77 |  |  | $ | 95 |  |
| July 2029 Notes |  | 500 |  | 336 |  |  | 164 |  |  | 70 |  |
| January 2031 Notes |  | 500 |  | 205 |  |  | 295 |  |  | 39 |  |
| Total |  | $ | 1,500 |  |  | $ | 964 |  |  | $ | 536 |  |  | $ | 204 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001137789-23-000029:note_history:28]
At March 31, 2023, future principal payments on long-term debt were as follows (in millions):
  (was, 2023-01-25, similarity 0.9492):
[0001137789-23-000010:note_history:28]
At December 30, 2022, future principal payments on long-term debt were as follows (in millions):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001137789-23-000029:note_history:29]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,358 |  |  | $ | 2,149 |  |  | $ | 4,268 |  |  | $ | 6,615 |  |
| Distributors |  | 294 |  |  | 349 |  |  | 890 |  |  | 1,418 |  |
| Retailers |  | 208 |  |  | 304 |  |  | 624 |  |  | 1,000 |  |
| Total |  | $ | 1,860 |  |  | $ | 2,802 |  |  | $ | 5,782 |  |  | $ | 9,033 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 774 |  |  | $ | 1,292 |  |  | $ | 2,335 |  |  | $ | 4,308 |  |
| Americas |  | 799 |  |  | 1,171 |  |  | 2,588 |  |  | 3,436 |  |
| EMEA |  | 287 |  |  | 339 |  |  | 859 |  |  | 1,289 |  |
| Total |  | $ | 1,860 |  |  | $ | 2,802 |  |  | $ | 5,782 |  |  | $ | 9,033 |  |
  (was, 2023-01-25, similarity 0.9221):
[0001137789-23-000010:note_history:29]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,365 |  |  | $ | 2,178 |  |  | $ | 2,910 |  |  | $ | 4,465 |  |
| Distributors |  | 297 |  |  | 562 |  |  | 596 |  |  | 1,069 |  |
| Retailers |  | 225 |  |  | 376 |  |  | 416 |  |  | 697 |  |
| Total |  | $ | 1,887 |  |  | $ | 3,116 |  |  | $ | 3,922 |  |  | $ | 6,231 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 760 |  |  | $ | 1,433 |  |  | $ | 1,561 |  |  | $ | 3,016 |  |
| Americas |  | 853 |  |  | 1,186 |  |  | 1,789 |  |  | 2,265 |  |
| EMEA |  | 274 |  |  | 497 |  |  | 572 |  |  | 950 |  |
| Total |  | $ | 1,887 |  |  | $ | 3,116 |  |  | $ | 3,922 |  |  | $ | 6,231 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001137789-23-000029:note_history:30]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,358 |  |  | $ | 2,149 |  |  | $ | 4,268 |  |  | $ | 6,615 |  |
| Distributors |  | 294 |  |  | 349 |  |  | 890 |  |  | 1,418 |  |
| Retailers |  | 208 |  |  | 304 |  |  | 624 |  |  | 1,000 |  |
| Total |  | $ | 1,860 |  |  | $ | 2,802 |  |  | $ | 5,782 |  |  | $ | 9,033 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 774 |  |  | $ | 1,292 |  |  | $ | 2,335 |  |  | $ | 4,308 |  |
| Americas |  | 799 |  |  | 1,171 |  |  | 2,588 |  |  | 3,436 |  |
| EMEA |  | 287 |  |  | 339 |  |  | 859 |  |  | 1,289 |  |
| Total |  | $ | 1,860 |  |  | $ | 2,802 |  |  | $ | 5,782 |  |  | $ | 9,033 |  |
  (was, 2023-01-25, similarity 0.9221):
[0001137789-23-000010:note_history:30]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,365 |  |  | $ | 2,178 |  |  | $ | 2,910 |  |  | $ | 4,465 |  |
| Distributors |  | 297 |  |  | 562 |  |  | 596 |  |  | 1,069 |  |
| Retailers |  | 225 |  |  | 376 |  |  | 416 |  |  | 697 |  |
| Total |  | $ | 1,887 |  |  | $ | 3,116 |  |  | $ | 3,922 |  |  | $ | 6,231 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 760 |  |  | $ | 1,433 |  |  | $ | 1,561 |  |  | $ | 3,016 |  |
| Americas |  | 853 |  |  | 1,186 |  |  | 1,789 |  |  | 2,265 |  |
| EMEA |  | 274 |  |  | 497 |  |  | 572 |  |  | 950 |  |
| Total |  | $ | 1,887 |  |  | $ | 3,116 |  |  | $ | 3,922 |  |  | $ | 6,231 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001137789-23-000029:note_history:31]
Subsequent Events
Dividend Declared
  (was, 2023-01-25, similarity 0.6538):
[0001137789-23-000010:note_history:31]
Dividend Declared

- added (2023-04-26):
[0001137789-23-000029:note_history:32]
On April 20, 2023, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on July 5, 2023 to shareholders of record as of the close of business on June 21, 2023.

- added (2023-04-26):
[0001137789-23-000029:note_history:33]
Restructuring Plan

- added (2023-04-26):
[0001137789-23-000029:note_history:34]
On April 20, 2023, the Company committed to the April 2023 plan to further reduce its cost structure in response to changes in macroeconomic and business conditions. See “Note 5. Restructuring and Exit Costs” for more information.

- added (2023-04-26):
[0001137789-23-000029:note_history:35]
Subsequent Regulatory Settlement
On April 18, 2023, the Company entered into the Settlement Agreement with BIS that resolves BIS’ allegations regarding its sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. See “Note 12. Legal, Environmental and Other Contingencies” for more information.

- removed (2023-04-26):
[0001137789-23-000010:note_history:36]
On January 25, 2023, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on April 6, 2023 to shareholders of record as of the close of business on March 22, 2023.
