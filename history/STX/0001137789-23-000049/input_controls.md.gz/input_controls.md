# STX 10-K controls and the auditor's report


## auditors_report

[0001137789-23-000049:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001137789-23-000049:auditors_report:2]
To the Shareholders and the Board of Directors of Seagate Technology Holdings public limited company

[0001137789-23-000049:auditors_report:3]
Opinion on the Financial Statements

[0001137789-23-000049:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Seagate Technology Holdings public limited company (the Company) as of June 30, 2023 and July 1, 2022, the related consolidated statements of operations, comprehensive (loss) income, shareholders’ (deficit) equity and cash flows for each of the three years in the period ended June 30, 2023, and the related notes (collectively referred to as the “consolidated financial statements”). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company at June 30, 2023 and July 1, 2022, and the results of its operations and its cash flows for each of the three years in the period ended June 30, 2023, in conformity with U.S. generally accepted accounting principles.

[0001137789-23-000049:auditors_report:5]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of June 30, 2023, based on criteria established in Internal Control - Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework) and our report dated August 4, 2023 expressed an unqualified opinion thereon.

[0001137789-23-000049:auditors_report:6]
Basis for Opinion

[0001137789-23-000049:auditors_report:7]
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company’s financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001137789-23-000049:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001137789-23-000049:auditors_report:9]
Critical Audit Matters

[0001137789-23-000049:auditors_report:10]
The critical audit matters communicated below are matters arising from the current period audit of the financial statements that were communicated or required to be communicated to the audit committee and that: (1) relate to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001137789-23-000049:auditors_report:11]
|  | Revenue recognition—Sales incentive program rebates and discounts |
| Description of the Matter | The Company sells its products to original equipment manufacturers, distributors and retailers (collectively, “customers”). As explained in Note 1 to the consolidated financial statements, the Company reduces revenue for estimated future reductions to the final selling prices for shipped products including sales incentive programs, such as price protection and volume incentives. |
|  | Auditing management’s estimates of future reductions to the final selling prices is complex as it requires management to make subjective assumptions including the amount of price adjustments on products as well as the timing of its channel sales of products through to end customers. |

[0001137789-23-000049:auditors_report:12]
88

[0001137789-23-000049:auditors_report:13]
| How We Addressed the Matter in Our Audit | We obtained an understanding, evaluated the design and tested the operating effectiveness of controls over the completeness of sales incentive programs, the accuracy and completeness of the underlying data used in the calculations and management’s assumptions of the amount of future reductions to the final selling prices as well as the timing of its channel sales of products through to end customers. |
|  | To test the estimated sales incentive programs, our audit procedures included, among others, testing the completeness of sales incentive programs as well as the accuracy and completeness of the underlying data used in the calculations and evaluating the significant assumptions used by management to estimate its reserves related to remaining channel inventory. To test the completeness of the sales incentive programs, we inspected significant new sales contracts and agreements that include the contractual rights to discounts and rebates to validate they are being properly considered in the incentives reserve calculations and examined credit memos issued after year end. We also directly confirmed terms and conditions of agreements with a sample of the Company’s customers as well as inquired of sales representatives and other members of management to assess whether all contractual terms were provided to the Finance Department. To test the underlying data used in the sales incentive program reserve calculations, we confirmed ending on hand inventory at a sample of distributors and retailers. To test management’s assumptions of the amount of future reductions to the final selling prices as well as the timing of its distributors’ sales of products through to end customers we inquired with operations management and compared estimates with industry and analysts’ forecasts. In addition, we performed a retrospective review comparing prior period assumptions to the actual results in subsequent periods and performed sensitivity analyses to evaluate the potential effect of changes in the Company's significant assumptions. |
|  | Realizability of deferred income taxes |
| Description of the Matter | At June 30, 2023, the Company had gross deferred tax assets of $1,543 million, partially offset by a valuation allowance of $370 million. As discussed in Note 5 to the consolidated financial statements, the Company recognizes a valuation allowance to reduce the carrying value of its deferred tax assets to the amount that management believes is more likely than not to be realized. |
|  | Auditing the realizability of the deferred tax assets was complex as the assessment process includes forecasting future sources of taxable income and scheduling the use of the applicable deferred tax assets which includes subjective management assumptions, and the amounts involved are material to the financial statements as a whole. |
| How We Addressed the Matter in Our Audit | We obtained an understanding, evaluated the design and tested the operating effectiveness of controls that address the risks of material misstatement relating to the realizability of deferred tax assets. This included controls over management’s determination of sources and amount of future taxable income including income from operations and scheduling of the future reversal of existing taxable temporary differences. |
|  | Among other audit procedures performed, we evaluated the assumptions used by the Company to develop projections of future taxable income by jurisdiction and tested the completeness and accuracy of the underlying data used in its projections. For example, we compared the projections of future taxable income with the actual results of prior periods, as well as management’s consideration of current industry and economic trends. We also assessed the historical accuracy of management’s projections and compared the projections of future taxable income with other forecasted financial information prepared by the Company. In addition, we tested the Company’s scheduling of the reversal of existing temporary taxable differences. |

[0001137789-23-000049:auditors_report:14]
/s/ Ernst & Young LLP

[0001137789-23-000049:auditors_report:15]
We have served as the Company’s auditor since 1980.

[0001137789-23-000049:auditors_report:16]
San Jose, California

[0001137789-23-000049:auditors_report:17]
August 4, 2023

[0001137789-23-000049:auditors_report:18]
89

[0001137789-23-000049:auditors_report:19]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001137789-23-000049:auditors_report:20]
To the shareholders and the Board of Directors of Seagate Technology Holdings public limited company

[0001137789-23-000049:auditors_report:21]
Opinion on Internal Control Over Financial Reporting

[0001137789-23-000049:auditors_report:22]
We have audited Seagate Technology Holdings public limited company’s internal control over financial reporting as of June 30, 2023, based on criteria established in Internal Control - Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework) (the COSO criteria). In our opinion, Seagate Technology Holdings public limited company (the Company) maintained, in all material respects, effective internal control over financial reporting as of June 30, 2023, based on the COSO criteria.

[0001137789-23-000049:auditors_report:23]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated balance sheets of the Company as of June 30, 2023 and July 1, 2022, and the related consolidated statements of operations, comprehensive income, shareholders’ equity and cash flows for each of the three years in the period ended June 30, 2023 and the related notes and our report dated August 4, 2023 expressed an unqualified opinion thereon.

[0001137789-23-000049:auditors_report:24]
Basis for Opinion

[0001137789-23-000049:auditors_report:25]
The Company's management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001137789-23-000049:auditors_report:26]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects.

[0001137789-23-000049:auditors_report:27]
Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001137789-23-000049:auditors_report:28]
Definition and Limitations of Internal Control Over Financial Reporting

[0001137789-23-000049:auditors_report:29]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001137789-23-000049:auditors_report:30]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001137789-23-000049:auditors_report:31]
/s/ Ernst & Young LLP

[0001137789-23-000049:auditors_report:32]
San Jose, California

[0001137789-23-000049:auditors_report:33]
August 4, 2023

[0001137789-23-000049:auditors_report:34]
90


## item_9a

[0001137789-23-000049:item_9a:1]
ITEM 9A.CONTROLS AND PROCEDURES

[0001137789-23-000049:item_9a:2]
Conclusions Regarding Disclosure Controls and Procedures

[0001137789-23-000049:item_9a:3]
Our chief executive officer and our chief financial officer have concluded, based on the evaluation of the effectiveness of our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) of the Securities Exchange Act of 1934, as amended) by our management, with the participation of our chief executive officer and our chief financial officer, that our disclosure controls and procedures were effective as of June 30, 2023.

[0001137789-23-000049:item_9a:4]
Management’s Report on Internal Control over Financial Reporting

[0001137789-23-000049:item_9a:5]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Securities Exchange Act of 1934, as amended). Under the supervision and with the participation of our management, including our chief executive officer and chief financial officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting based on the framework in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission, or COSO.

[0001137789-23-000049:item_9a:6]
Based on our evaluation under the 2013 framework in Internal Control—Integrated Framework, our management has concluded that our internal control over financial reporting was effective as of June 30, 2023. The effectiveness of our internal control over financial reporting as of June 30, 2023 has been audited by Ernst & Young LLP, the independent registered public accounting firm that audited our financial statements included in this Annual Report on Form 10-K, as stated in their report that is included herein.

[0001137789-23-000049:item_9a:7]
Changes in Internal Control over Financial Reporting

[0001137789-23-000049:item_9a:8]
There were no changes in our internal control over financial reporting during our fourth fiscal quarter that have materially affected, or were reasonably likely to materially affect, our internal control over financial reporting.

[0001137789-23-000049:item_9a:9]
Limitations on the Effectiveness of Controls

[0001137789-23-000049:item_9a:10]
Our management, including our chief executive officer and chief financial officer, does not expect that our disclosure controls and procedures or our internal controls will prevent all errors and all fraud. A control system, no matter how well conceived and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system are met. Further, the design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Our disclosure controls and procedures and our internal controls have been designed to provide reasonable assurance of achieving their objectives. Because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within Seagate have been detected. An evaluation was performed under the supervision and with the participation of our management, including our chief executive officer and chief financial officer, of the effectiveness of the design and operation of our disclosure controls and procedures as of June 30, 2023. Based on that evaluation, our management, including our chief executive officer and chief financial officer, concluded that our disclosure controls and procedures were effective at the reasonable assurance level.
