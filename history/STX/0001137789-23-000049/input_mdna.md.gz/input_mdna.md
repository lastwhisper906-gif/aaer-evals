# STX MD&A — 0001137789-23-000049


## mdna

[0001137789-23-000049:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001137789-23-000049:mdna:2]
The following is a discussion of the Company’s financial condition, changes in financial condition and results of operations for the fiscal years ended June 30, 2023 and July 1, 2022. Discussions of year-to-year comparisons between fiscal years 2022 and 2021 are not included in this Annual Report on Form 10-K and can be found in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended July 1, 2022, which was filed with the SEC on August 5, 2022.

[0001137789-23-000049:mdna:3]
You should read this discussion in conjunction with “Item 8. Financial Statements and Supplementary Data” included elsewhere in this Annual Report on Form 10-K. Except as noted, references to any fiscal year mean the twelve-month period ending on the Friday closest to June 30 of that year. Accordingly, fiscal year 2023 and 2022 both comprised of 52 weeks and ended on June 30, 2023 and July 1, 2022, respectively. Fiscal year 2026 will be comprised of 53 weeks and will end on July 3, 2026.

[0001137789-23-000049:mdna:4]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is provided in addition to the accompanying consolidated financial statements and notes to assist readers in understanding our results of operations, financial condition and cash flows. Our MD&A is organized as follows:

[0001137789-23-000049:mdna:5]
•Overview of Fiscal Year 2023. Highlights of events in fiscal year 2023 that impacted our financial position.

[0001137789-23-000049:mdna:6]
•Results of Operations. Analysis of our financial results comparing fiscal years 2023 and 2022.

[0001137789-23-000049:mdna:7]
•Liquidity and Capital Resources. Analysis of changes in our balance sheets and cash flows and discussion of our financial condition, including potential sources of liquidity, material cash requirements and their general purpose.

[0001137789-23-000049:mdna:8]
•Critical Accounting Policies and Estimates. Accounting policies and estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001137789-23-000049:mdna:9]
For an overview of our business, see “Part I, Item 1. Business.”

[0001137789-23-000049:mdna:10]
Overview of Fiscal Year 2023

[0001137789-23-000049:mdna:11]
During fiscal year 2023, we shipped 441 exabytes of HDD storage capacity. We generated revenue of approximately $7.4 billion with a gross margin of 18%. Our operating cash flow was $942 million. We repurchased approximately 5 million of our ordinary shares for $408 million and paid $582 million in dividends.

[0001137789-23-000049:mdna:12]
We reduced our outstanding debt by $195 million through exchange and repurchase of certain senior notes and Term Loans facility with longer duration senior notes and recorded a net gain of $190 million as a result of debt extinguishment. Additionally, we entered into a settlement agreement related to BIS’ allegations regarding violations of the U.S. EAR and recorded a settlement penalty of $300 million.

[0001137789-23-000049:mdna:13]
Recent Developments, Economic Conditions and Challenges

[0001137789-23-000049:mdna:14]
During fiscal year 2023, the data storage industry and our business continued to be impacted by macroeconomic uncertainties and customer inventory adjustments, which led to a significant slowdown in demand for our products, particularly in the mass capacity markets. In response to changes in market demand, we undertook actions to lower our cost structure and reduced manufacturing production plans, which resulted in factory underutilization charges. We expect these market conditions will continue to impact our business and results of operations over the near term. Under these conditions, we are continuing to actively manage costs, drive operational efficiencies and maintain supply discipline.

[0001137789-23-000049:mdna:15]
In light of the deterioration of economic conditions, we undertook the October 2022, April 2023 and other restructuring plans to reduce our cost in response to change in macroeconomic and business conditions during fiscal year 2023. These restructuring plans were substantially completed by the end of fiscal year 2023 with total charges of approximately $269 million, mainly consisting of employee severance cost and other one-time termination benefits. Refer to “ Item 8. Financial Statements and Supplementary Data—Note 7. Restructuring and Exit Costs” for more details.

[0001137789-23-000049:mdna:16]
We continue to actively monitor the effects and potential impacts of inflation, other macroeconomic factors and the pandemic on all aspects of our business, supply chain, liquidity and capital resources including governmental policies that could periodically shut down an entire city where we, our suppliers or our customers operate. We are complying with governmental rules and guidelines across all of our sites. Although we are unable to predict the future impact on our business, results of operations, liquidity or capital resources at this time, we expect we will continue to be negatively affected if the inflation, other macroeconomic factors and the pandemic and related public and private health measures result in substantial manufacturing or supply chain challenges, substantial reductions or delays in demand due to disruptions in the operations of our customers or partners, disruptions in local and global economies, volatility in the global financial markets, sustained reductions or volatility in overall demand trends, restrictions on the export or shipment of our products or our customer’s products, or other unexpected ramifications. For a further discussion of the uncertainties and business risks associated with the COVID-19 pandemic, see “Part I, Item 1A. Risk Factors” of our Annual Report.

[0001137789-23-000049:mdna:17]
Regulatory settlement

[0001137789-23-000049:mdna:18]
On April 18, 2023, our subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd entered into the Settlement Agreement with the BIS that resolves BIS’ allegations regarding our sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, we agreed to pay $300 million to the BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. We have also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the EAR, including one audit by an unaffiliated third-party consultant chosen by us with expertise in U.S. export control laws and two internal audits. The Settlement Agreement also includes a denial order that is currently suspended and will be waived five years after the date of the order issued under the Settlement Agreement, provided that we have made full and timely payments under the Settlement Agreement and timely completed the audit requirements. While we are in compliance with and upon successful compliance in full with the terms of the Settlement Agreement, BIS has agreed it will not initiate any further administrative proceedings against us in connection with any violation of the EAR arising out of the transactions detailed in the Settlement Agreement.

[0001137789-23-000049:mdna:19]
While we believed that we complied with all relevant export control laws at the time we made the hard disk drive sales at issue, we determined that engaging with BIS and settling this matter was in the best interest of Seagate, our customers and our shareholders. In determining to engage with BIS and resolve this matter through a settlement agreement, we considered a number of factors, including the risks and cost of protracted litigation involving the U.S. government, as well as the size of the potential penalty and our desire to focus on current business challenges and long-term business strategy. The Settlement Agreement includes a finding that we incorrectly interpreted the regulation at issue to require evaluation of only the last stage of our hard disk drive manufacturing process rather than the entire process. As part of this settlement, we have agreed not to contest BIS’ determination that the sales in question did not comply with the U.S. EAR. Refer to “Item 8. Financial Statements and Supplementary Data—Note 14. Legal, Environmental and Other Contingencies” for more details.

[0001137789-23-000049:mdna:20]
Results of Operations

[0001137789-23-000049:mdna:21]
We list in the tables below summarized information from our Consolidated Statements of Operations by dollar amounts and as a percentage of revenue:

[0001137789-23-000049:mdna:22]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 30,2023 |  | July 1,2022 |
| Revenue |  | $ | 7,384 |  |  | $ | 11,661 |  |
| Cost of revenue |  | 6,033 |  |  | 8,192 |  |
| Gross profit |  | 1,351 |  |  | 3,469 |  |
| Product development |  | 797 |  |  | 941 |  |
| Marketing and administrative |  | 491 |  |  | 559 |  |
| Amortization of intangibles |  | 3 |  |  | 11 |  |
| BIS settlement penalty |  | 300 |  |  | — |  |
| Restructuring and other, net |  | 102 |  |  | 3 |  |
| (Loss) income from operations |  | (342) |  |  | 1,955 |  |
| Other expense, net |  | (154) |  |  | (276) |  |
| (Loss) income before income taxes |  | (496) |  |  | 1,679 |  |
| Provision for income taxes |  | 33 |  |  | 30 |  |
| Net (loss) income |  | $ | (529) |  |  | $ | 1,649 |  |

[0001137789-23-000049:mdna:23]
|  |  | Fiscal Years Ended |
|  |  | June 30,2023 |  | July 1,2022 |
| Revenue |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 82 |  |  | 70 |  |
| Gross margin |  | 18 |  |  | 30 |  |
| Product development |  | 11 |  |  | 8 |  |
| Marketing and administrative |  | 7 |  |  | 5 |  |
| Amortization of intangibles |  | — |  |  | — |  |
| BIS settlement penalty |  | 4 |  |  | — |  |
| Restructuring and other, net |  | 1 |  |  | — |  |
| Operating margin |  | (5) |  |  | 17 |  |
| Other expense, net |  | (2) |  |  | (3) |  |
| (Loss) income before income taxes |  | (7) |  |  | 14 |  |
| Provision for income taxes |  | — |  |  | — |  |
| Net (loss) income |  | (7) | % |  | 14 | % |

[0001137789-23-000049:mdna:24]
37

[0001137789-23-000049:mdna:25]
Revenue

[0001137789-23-000049:mdna:26]
The following table summarizes information regarding consolidated revenues by channel, geography, and market and HDD exabytes shipped by market and price per terabyte:

[0001137789-23-000049:mdna:27]
|  |  | Fiscal Years Ended |
|  |  | June 30,2023 |  | July 1,2022 |
| Revenues by Channel (%) |  |  |  |  |
| OEMs |  | 74 | % |  | 75 | % |
| Distributors |  | 15 | % |  | 14 | % |
| Retailers |  | 11 | % |  | 11 | % |
| Revenues by Geography (%) (1) |  |  |  |  |
| Asia Pacific |  | 45 | % |  | 46 | % |
| Americas |  | 41 | % |  | 40 | % |
| EMEA |  | 14 | % |  | 14 | % |
| Revenues by Market (%) |  |  |  |  |
| Mass capacity |  | 66 | % |  | 68 | % |
| Legacy |  | 21 | % |  | 23 | % |
| Other |  | 13 | % |  | 9 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |
| Mass capacity |  | 380 |  |  | 541 |  |
| Legacy |  | 61 |  |  | 90 |  |
| Total |  | 441 |  |  | 631 |  |
| HDD Price per Terabyte |  | $ | 15 |  |  | $ | 17 |  |

[0001137789-23-000049:mdna:28]
____________________________________________________________

[0001137789-23-000049:mdna:29]
(1) Revenue is attributed to geography based on the bill from location.

[0001137789-23-000049:mdna:30]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | June 30,2023 |  | July 1,2022 |  | Change |  | %Change |
| Revenue |  | $ | 7,384 |  |  | $ | 11,661 |  |  | $ | (4,277) |  |  | (37) | % |

[0001137789-23-000049:mdna:31]
Revenue in fiscal year 2023 decreased approximately 37%, or $4.3 billion, from fiscal year 2022, primarily due to a decrease in exabytes shipped and to a lesser extend price erosion, as a result of lower demand in mass capacity and legacy markets that were impacted by macroeconomic conditions and pandemic-related headwinds. We expect the current market conditions will continue to persist at least through the first half of fiscal year 2024.

[0001137789-23-000049:mdna:32]
Cost of Revenue and Gross Margin

[0001137789-23-000049:mdna:33]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | June 30,2023 |  | July 1,2022 |  | Change |  | %Change |
| Cost of revenue |  | $ | 6,033 |  |  | $ | 8,192 |  |  | $ | (2,159) |  |  | (26) | % |
| Gross profit |  | 1,351 |  |  | 3,469 |  |  | (2,118) |  |  | (61) | % |
| Gross margin |  | 18 | % |  | 30 | % |  |  |  |  |

[0001137789-23-000049:mdna:34]
For fiscal year 2023, gross margin decreased compared to the prior fiscal year primarily driven by factory underutilization charges of $250 million associated with lower production levels and pandemic-related lockdown in one of our factories, order cancellation fees of $108 million, lower demand in mass capacity and legacy markets with less favorable product mix, price erosion, and accelerated depreciation expense for certain capital equipment.

[0001137789-23-000049:mdna:35]
Operating Expenses

[0001137789-23-000049:mdna:36]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | June 30,2023 |  | July 1,2022 |  | Change |  | %Change |
| Product development |  | $ | 797 |  |  | $ | 941 |  |  | $ | (144) |  |  | (15) | % |
| Marketing and administrative |  | 491 |  |  | 559 |  |  | (68) |  |  | (12) | % |
| Amortization of intangibles |  | 3 |  |  | 11 |  |  | (8) |  |  | (73) | % |
| BIS settlement penalty |  | 300 |  |  | — |  |  | 300 |  |  | * |
| Restructuring and other, net |  | 102 |  |  | 3 |  |  | 99 |  |  | 3,300 | % |
| Operating expenses |  | $ | 1,693 |  |  | $ | 1,514 |  |  | $ | 179 |  |  |  |

[0001137789-23-000049:mdna:37]
______________________________

[0001137789-23-000049:mdna:38]
*Not a meaningful figure

[0001137789-23-000049:mdna:39]
Product Development Expense. Product development expenses for fiscal year 2023 decreased by $144 million from fiscal year 2022 primarily due to a $70 million decrease in variable compensation and related benefit expenses, a $51 million decrease in compensation and other employee benefits primarily from the reduction in headcount as a result of our October 2022 and April 2023 restructuring plans and a temporary salary reduction program, a $14 million decrease in material expense and a $6 million decrease in equipment expense.

[0001137789-23-000049:mdna:40]
Marketing and Administrative Expense. Marketing and administrative expenses for fiscal year 2023 decreased by $68 million from fiscal year 2022 primarily due to a $41 million decrease in variable compensation and related benefit expenses, a $24 million decrease in compensation and other employee benefits primarily from the reduction in headcount as a result of our October 2022 and April 2023 restructuring plans and a temporary salary reduction program and a $7 million recovery of an accounts receivable previously written-off in prior years, partially offset by a $2 million increase in travel expense as a result of the easing of pandemic-related travel restrictions.

[0001137789-23-000049:mdna:41]
Amortization of Intangibles. Amortization of intangibles for fiscal year 2023 decreased by $8 million, as compared to fiscal year 2022, due to certain intangible assets that reached the end of their useful lives.

[0001137789-23-000049:mdna:42]
BIS settlement penalty. The BIS settlement penalty for fiscal year 2023 was $300 million, related to BIS’ allegations of violations of the EAR, which were resolved by the Settlement Agreement in April 2023. Refer to “Item 8. Financial Statements and Supplementary Data—Note 14. Legal, Environmental and Other Contingencies” for more details.

[0001137789-23-000049:mdna:43]
Restructuring and Other, net. Restructuring and other, net for fiscal year 2023 was $102 million, primarily comprised of workforce reduction costs and other exit costs under our October 2022 and April 2023 restructuring plans, partially offset by gains from the sale of certain properties and assets of $167 million.

[0001137789-23-000049:mdna:44]
Restructuring and other, net for fiscal year 2022 was not material.

[0001137789-23-000049:mdna:45]
Other Expense, net

[0001137789-23-000049:mdna:46]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | June 30,2023 |  | July 1,2022 |  | Change |  | %Change |
| Other expense, net |  | $ | (154) |  |  | $ | (276) |  |  | $ | 122 |  |  | (44) | % |

[0001137789-23-000049:mdna:47]
Other expense, net for fiscal year 2023 decreased by $122 million compared to fiscal year 2022 primarily due to a $190 million net gain recognized from early redemption and extinguishment of certain senior notes, partially offset by a $64 million net increase in interest expense from the exchange and issuance of long-term debt.

[0001137789-23-000049:mdna:48]
Income Taxes

[0001137789-23-000049:mdna:49]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | June 30,2023 |  | July 1,2022 |  | Change |  | %Change |
| Provision for income taxes |  | $ | 33 |  |  | $ | 30 |  |  | $ | 3 |  |  | 10 | % |

[0001137789-23-000049:mdna:50]
We recorded an income tax provision of $33 million for fiscal year 2023 compared to an income tax provision of $30 million for fiscal year 2022. Despite a consolidated loss on a worldwide basis, we still have taxes payable on a global basis due to guaranteed earnings reported in certain jurisdictions as compared to fiscal year 2022.

[0001137789-23-000049:mdna:51]
On August 16, 2022, the Inflation Reduction Act of 2022 (the “IRA”) was enacted into U.S. law. The legislation includes a new corporate alternative minimum tax (the “CAMT”) of 15% on the adjusted financial statement income (“AFSI”) of corporations with average AFSI exceeding $1.0 billion over a three-year period. Although CAMT is effective for us beginning in fiscal year 2024, Seagate does not meet the criteria to be subject to CAMT for fiscal year 2024.

[0001137789-23-000049:mdna:52]
Our Irish tax resident parent holding company owns various U.S. and non-Irish subsidiaries that operate in multiple non-Irish income tax jurisdictions. Our worldwide operating income is either subject to varying rates of income tax or is exempt from income tax due to tax incentive programs we operate under in Singapore and Thailand. These tax incentives are scheduled to expire in whole or in part at various dates through 2033. Certain tax incentives may be extended if specific conditions are met.

[0001137789-23-000049:mdna:53]
Our income tax provision recorded for fiscal years 2023 and 2022 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland; and (ii) current year generation of research credits.

[0001137789-23-000049:mdna:54]
We anticipate that our effective tax rate in future periods will generally be less than the Irish statutory rate based on our ownership structure, our intention to indefinitely reinvest earnings from our subsidiaries outside of Ireland and the potential future changes in our valuation allowance for deferred tax assets.

[0001137789-23-000049:mdna:55]
Liquidity and Capital Resources

[0001137789-23-000049:mdna:56]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash will continue to be sufficient to fund our operations and meet our cash requirements for the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs and capital expenditures, will allow us to manage the ongoing impacts of macroeconomic and other headwinds including higher inflationary pressures, inventory adjustments by our customers and the overall market demand disruptions on our business operations for the foreseeable future. However, some challenges to our industry and to our business continue to remain uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to the global economic factors.

[0001137789-23-000049:mdna:57]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of June 30, 2023. For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, including the pandemic, among others, see “Part I, Item 1A. Risk Factors” of our Annual Report.

[0001137789-23-000049:mdna:58]
Cash and Cash Equivalents

[0001137789-23-000049:mdna:59]
|  |  | As of |  |  |
| (Dollars in millions) |  | June 30,2023 |  | July 1,2022 |  | Change |
| Cash and cash equivalents |  | $ | 786 |  |  | $ | 615 |  |  | $ | 171 |  |

[0001137789-23-000049:mdna:60]
Our cash and cash equivalents increased by $171 million from July 1, 2022 primarily as a result of net cash of $942 million provided by operating activities, net proceeds of $1.6 billion from issuance of long-term debt and proceeds from the sale of assets of $534 million, partially offset by repayment of long-term debt of $1.6 billion, payment of dividends to our shareholders of $582 million, repurchases of our ordinary shares of $408 million, and payments for capital expenditures of $316 million. The following table summarizes results from the Consolidated Statement of Cash Flows for the periods indicated:

[0001137789-23-000049:mdna:61]
40

[0001137789-23-000049:mdna:62]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 30,2023 |  | July 1,2022 |
| Net cash flow provided by (used in): |  |  |  |  |
| Operating activities |  | $ | 942 |  |  | $ | 1,657 |  |
| Investing activities |  | 217 |  |  | (352) |  |
| Financing activities |  | (988) |  |  | (1,899) |  |
| Net increase/(decrease) in cash, cash equivalents and restricted cash |  | $ | 171 |  |  | $ | (594) |  |

[0001137789-23-000049:mdna:63]
Cash Provided by Operating Activities

[0001137789-23-000049:mdna:64]
Cash provided by operating activities for fiscal year 2023 was $942 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-23-000049:mdna:65]
•a decrease of $911 million in accounts receivable, primarily due to lower revenue and timing of collections;

[0001137789-23-000049:mdna:66]
•a decrease of $425 million in inventories, primarily due to a decrease in units built to align with the prevailing demand environment; and

[0001137789-23-000049:mdna:67]
•an increase of $110 million cash proceeds received from the settlement of certain interest rate swap agreements; partially offset by

[0001137789-23-000049:mdna:68]
•a decrease of $421 million in accounts payable, primarily due to a decrease in materials purchased; and

[0001137789-23-000049:mdna:69]
•a decrease of $152 million in accrued employee compensation, primarily due to cash paid to our employees as part of our variable compensation plans and a decrease in our variable compensation expense.

[0001137789-23-000049:mdna:70]
Cash provided by operating activities for fiscal year 2022 was approximately $1.7 billion and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-23-000049:mdna:71]
•an increase of $228 million in accounts payable, primarily due to timing of payments and an increase in materials purchased; partially offset by

[0001137789-23-000049:mdna:72]
•an increase of $374 million in accounts receivable, primarily due to linearity of sales; and

[0001137789-23-000049:mdna:73]
•an increase of $361 million in inventories, primarily due to timing of shipments, and an increase in materials purchased for production of higher capacity drives and to mitigate supply chain disruptions.

[0001137789-23-000049:mdna:74]
Cash Used in Investing Activities

[0001137789-23-000049:mdna:75]
In fiscal year 2023, we received $217 million for net cash investing activities, which was primarily due to proceeds of $534 million from the sale of assets, offset by payments for the purchase of property, equipment and leasehold improvements of $316 million.

[0001137789-23-000049:mdna:76]
In fiscal year 2022, we used $352 million for net cash investing activities, which was primarily due to payments for the purchase of property, equipment and leasehold improvements of $381 million and payments for the purchase of investments of $18 million, partially offset by proceeds from the sale of investments of $47 million.

[0001137789-23-000049:mdna:77]
Cash Used in Financing Activities

[0001137789-23-000049:mdna:78]
Net cash used in financing activities of $988 million for fiscal year 2023 was primarily attributable to the following activities:

[0001137789-23-000049:mdna:79]
•$1.6 billion repurchases of long-term debt;

[0001137789-23-000049:mdna:80]
•$582 million in dividend payments; and

[0001137789-23-000049:mdna:81]
•$408 million in payments for repurchases of our ordinary shares; partially offset by

[0001137789-23-000049:mdna:82]
•$1.6 billion in proceeds from the issuance of long-term debt; and

[0001137789-23-000049:mdna:83]
•$68 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-23-000049:mdna:84]
41

[0001137789-23-000049:mdna:85]
Net cash used in financing activities of $1.9 billion for fiscal year 2022 was primarily attributable to the following activities:

[0001137789-23-000049:mdna:86]
•$1.8 billion in payments for repurchases of our ordinary shares;

[0001137789-23-000049:mdna:87]
•$701 million net purchases of long-term debt; and

[0001137789-23-000049:mdna:88]
•$610 million in dividend payments; partially offset by

[0001137789-23-000049:mdna:89]
•$1.2 billion from the issuance of long-term debt; and

[0001137789-23-000049:mdna:90]
•$68 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-23-000049:mdna:91]
Liquidity Sources

[0001137789-23-000049:mdna:92]
Our primary sources of liquidity as of June 30, 2023, consist of: (1) approximately $786 million in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.5 billion available for borrowing under our senior unsecured revolving credit facility (“Revolving Credit Facility”), which is part of our credit agreement (the “Credit Agreement”).

[0001137789-23-000049:mdna:93]
As of June 30, 2023, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-23-000049:mdna:94]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) leverage ratio and (3) a minimum liquidity amount. On May 19, 2023, we entered into the Eighth Amendment to our Credit Agreement to increase the maximum permitted total net leverage ratio and reduce the minimum interest coverage ration during the covenant relief period. The maximum total net leverage ratio is 6.75 to 1.00 beginning with the fiscal quarter ending June 30, 2023, with periodic step downs during the covenant relief period, shifting to a maximum total leverage ratio of 4.00 to 1.00 for any fiscal quarter ending at any time other than during the covenant relief period. The minimum interest coverage ratio is 2.50 to 1.00 beginning with the fiscal quarter ending June 30, 2023, with periodic step downs and step ups during the covenant relief period, returning to a minimum interest coverage ratio of 3.25 to 1.00 for any fiscal quarter ending after June 28, 2024, and for any fiscal quarter ending at any time other than during the covenant relief period. The covenant relief period terminates on June 27, 2025. As part of this Amendment, the aggregate revolving loan commitments were reduced from $1.75 billion to $1.5 billion. We continue to evaluate our debt portfolio and structure to comply with our financial debt covenants. As of June 30, 2023, we were in compliance with all of the covenants under our debt agreements. Refer to “Item 8. Financial Statements and Supplementary Data—Note 4. Debt” for more details.

[0001137789-23-000049:mdna:95]
As of June 30, 2023, cash and cash equivalents held by non-Irish subsidiaries was $638 million. This amount is potentially subject to taxation in Ireland upon repatriation by means of a dividend into our Irish parent. However, it is our intent to indefinitely reinvest earnings of non-Irish subsidiaries outside of Ireland and our current plans do not demonstrate a need to repatriate such earnings by means of a taxable Irish dividend. Should funds be needed in the Irish parent company and should we be unable to fund parent company activities through means other than a taxable Irish dividend, we would be required to accrue and pay Irish taxes on such dividend.

[0001137789-23-000049:mdna:96]
We believe that our sources of cash will be sufficient to fund our operations and meet our cash requirements for at least the next 12 months. Our ability to fund liquidity requirements beyond 12 months will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, among others, see “Part I, Item 1A. Risk Factors” of this Annual Report.

[0001137789-23-000049:mdna:97]
Cash Requirements and Commitments

[0001137789-23-000049:mdna:98]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend and any future strategic investments.

[0001137789-23-000049:mdna:99]
Purchase obligations

[0001137789-23-000049:mdna:100]
Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. From time to time, we enter into long-term, non-cancelable purchase commitments or make large up-front investments with certain suppliers in order to secure certain components or technologies for the production of our products or to supplement our internal manufacturing capacity for certain components. As of June 30, 2023, we had unconditional purchase obligations of approximately $3.7 billion, primarily related to purchases of inventory components with our suppliers. We expect $919 million of these commitments to be paid within one year.

[0001137789-23-000049:mdna:101]
Capital expenditures

[0001137789-23-000049:mdna:102]
We incur material capital expenditures to design and manufacture our products that depend on advanced technologies and manufacturing techniques. As of June 30, 2023, we had unconditional commitment of $238 million primarily related to purchases of equipment, of which approximately $137 million is expected to be paid within one year. For fiscal year 2024, we expect capital expenditures to be lower than fiscal year 2023.

[0001137789-23-000049:mdna:103]
Operating leases

[0001137789-23-000049:mdna:104]
We are a lessee in several operating leases related to real estate facilities for warehouse, office and lab space. As of June 30, 2023, the amount of future minimum rent expense for both occupied and vacated facilities net of sublease income under non-cancelable operating lease contracts was $564 million, of which $53 million is expected to be paid within one year. Refer to “Item 8. Financial Statements and Supplementary Data—Note 6. Leases” for details.

[0001137789-23-000049:mdna:105]
Long-term debt and interest payments on debt

[0001137789-23-000049:mdna:106]
As of June 30, 2023, the future principal payment obligation on our long-term debt was $5.5 billion, of which $63 million will mature within one year. As of June 30, 2023, future interest payments on this outstanding debt is estimated to be approximately $2.2 billion, of which $324 million is expected to be paid within one year. From time to time, we may repurchase, redeem or otherwise extinguish any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase or redeem outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 8. Financial Statements and Supplementary Data—Note 4. Debt” for more details.

[0001137789-23-000049:mdna:107]
BIS settlement penalty

[0001137789-23-000049:mdna:108]
We accrued a settlement penalty of $300 million for fiscal year 2023, related to BIS’ allegations of violations of the U.S. EAR, which were subsequently resolved by the Settlement Agreement in April 2023. As part of the Settlement Agreement with BIS, quarterly payments of $15 million will be made over the course of five years beginning October 31, 2023, of which $45 million is expected to be paid within one year and $255 million thereafter. Refer to “Item 8. Financial Statements and Supplementary Data—Note 14. Legal, Environmental and Other Contingencies” for more details.

[0001137789-23-000049:mdna:109]
Restructuring

[0001137789-23-000049:mdna:110]
On October 24, 2022, we committed to an October 2022 plan (the “October 2022 Plan”) to reduce our cost structure to better align our operational needs to current economic conditions while continuing to support the long-term business strategy. On March 29, 2023, in light of further deteriorating economic conditions, we committed to an expansion of the October 2022 Plan to further reduce the global headcount by approximately 480 employees to a total reduction of approximately 3,480 employees. The expanded plan includes aligning our business plan to near-term market conditions, along with other cost saving measures. On April 20, 2023, the Company committed to an April 2023 restructuring plan (the “April 2023 Plan”) to further reduce its cost structure in response to changes in macroeconomic and business conditions. The April 2023 Plan was intended to align the Company’s operational needs with the near-term demand environment while continuing to support the long-term business strategy. Both the October 2022 Plan and the April 2023 Plan were substantially completed by the end of the fiscal year 2023.

[0001137789-23-000049:mdna:111]
During fiscal year 2023, we recorded restructuring and other, net of $102 million, primarily related to the workforce reduction costs under the October 2022 Plan and the April 2023 Plan, partially offset by gains from the sale of certain properties and assets. We made cash payments of $155 million for all active restructuring plans. As of June 30, 2023, the future cash payments related to our remaining active restructuring plans were $119 million, of which $117 million is expected to be paid within one year.

[0001137789-23-000049:mdna:112]
Income Tax

[0001137789-23-000049:mdna:113]
As of June 30, 2023, we had a liability for unrecognized tax benefits and an accrual for the payment of related interest totaling $4 million, none of which is expected to be settled within one year. Outside of one year, we are unable to make a reasonably reliable estimate of when cash settlement with a taxing authority will occur.

[0001137789-23-000049:mdna:114]
Dividends

[0001137789-23-000049:mdna:115]
On July 26, 2023, our Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on October 10, 2023 to shareholders of record as of the close of business on September 26, 2023. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-23-000049:mdna:116]
Share repurchases

[0001137789-23-000049:mdna:117]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means, including through the use of derivative transactions. During fiscal year 2023, we repurchased approximately 6 million of our ordinary shares including shares withheld for statutory tax withholdings related to vesting of employee equity awards. See “Item 5. Market for Registrant’s Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities-Repurchases of Our Equity Securities.” As of June 30, 2023, $1.9 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-23-000049:mdna:118]
We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-23-000049:mdna:119]
Critical Accounting Policies and Estimates

[0001137789-23-000049:mdna:120]
The Company’s accounting policies are more fully described in “Item 8. Financial Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of Significant Accounting Policies”. The methods, estimates and judgments we use in applying our most critical accounting policies have a significant impact on the results we report in our consolidated financial statements. Critical accounting estimates are those estimates that involve a significant level of estimation uncertainty and have had or are reasonably likely to have a material impact on our financial condition or results of operations. Based on this definition, our most critical accounting policies include: Revenue - Sales Program Accruals, Warranty and Income Taxes. Below, we discuss these policies further, as well as the estimates and judgments involved. We also have other accounting policies and accounting estimates relating to uncollectible customer accounts, valuation of inventories, assessing goodwill and other long-lived assets for impairment, valuation of share-based payments and restructuring. We believe that these other accounting policies and accounting estimates either do not generally require us to make estimates and judgments that are as difficult or as subjective, or it is less likely that they would have a material impact on our reported results of operations for a given period.

[0001137789-23-000049:mdna:121]
Revenue - Sales Program Accruals. We record estimated variable consideration at the time of revenue recognition as a reduction to revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer's volume of purchases from us or other agreed upon rebate programs. For the distribution and retail channel, these sales incentive programs typically involve estimating the most likely amount of rebates related to a customer's level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Total sales programs were 17% and 14% of gross revenue in fiscal years 2023 and 2022, respectively. Adjustments to revenues due to under or over accruals for sales programs related to revenues reported in prior quarterly periods were approximately 1% and less than 1% of gross revenue in fiscal years 2023 and 2022, respectively.

[0001137789-23-000049:mdna:122]
Warranty. We estimate probable product warranty costs at the time revenue is recognized. Our warranty provision considers estimated product failure rates, trends (including the timing of product returns during the warranty periods), and estimated repair or replacement costs related to product quality issues, if any. Unforeseen component failures or exceptional component performance can result in changes to warranty costs. We also exercise judgment in estimating our ability to sell refurbished products based on historical experience. Our judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited experience with those products upon which to base our warranty estimates. If actual warranty costs differ substantially from our estimates, revisions to the estimated warranty liability would be required, which could have a material adverse effect on our results of operations.

[0001137789-23-000049:mdna:123]
Income Taxes. We make certain estimates and judgments in determining income tax expense for financial statement purposes. These estimates and judgments occur in the calculation of tax credits, recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for income tax and financial statement purposes, as well as tax liabilities associated with uncertain tax positions.

[0001137789-23-000049:mdna:124]
The deferred tax assets we record each period depend primarily on our ability to generate future taxable income in the United States and certain non-U.S. jurisdictions. Each period, we evaluate the need for a valuation allowance for our deferred tax assets and, if necessary, adjust the valuation allowance so that net deferred tax assets are recorded only to the extent we conclude it is more likely than not that these deferred tax assets will be realized.

[0001137789-23-000049:mdna:125]
In evaluating our ability to recover our deferred tax assets, in full or in part, we consider all available positive and negative evidence, including our past operating results, and our forecast of future earnings, future taxable income and prudent and feasible tax planning strategies. The assumptions utilized in determining future taxable income require significant judgment and are consistent with the plans and estimates we are using to manage the underlying businesses. Actual operating results in future years could differ from our current assumptions, judgments, and estimates. If our outlook for future taxable income changes significantly, our assessment of the need for, and the amount of, a valuation allowance may also change resulting in an additional tax provision or benefit.

[0001137789-23-000049:mdna:126]
Recent Accounting Pronouncements

[0001137789-23-000049:mdna:127]
See “Item 8. Financial Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.
