# STX MD&A — 0001137789-21-000006


## mdna

[0001137789-21-000006:mdna:1]
[same as prior period, unchanged from 0001137789-20-000117:mdna:1]

[0001137789-21-000006:mdna:2]
The following is a discussion of the financial condition, changes in financial condition and results of operations for our fiscal quarters ended January 1, 2021, October 2, 2020 and January 3, 2020, referred to herein as the “December 2020 quarter,” the “September 2020 quarter,” and the “December 2019 quarter,” respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The December 2020 quarter, the September 2020 quarter and the December 2019 quarter were each 13 weeks.

[0001137789-21-000006:mdna:3]
[same as prior period, unchanged from 0001137789-20-000117:mdna:3]

[0001137789-21-000006:mdna:4]
[same as prior period, unchanged from 0001137789-20-000117:mdna:4]

[0001137789-21-000006:mdna:5]
[same as prior period, unchanged from 0001137789-20-000117:mdna:5]

[0001137789-21-000006:mdna:6]
[same as prior period, unchanged from 0001137789-20-000117:mdna:6]

[0001137789-21-000006:mdna:7]
[same as prior period, unchanged from 0001137789-20-000117:mdna:7]

[0001137789-21-000006:mdna:8]
[same as prior period, unchanged from 0001137789-20-000117:mdna:8]

[0001137789-21-000006:mdna:9]
•the Company’s ability to effectively manage its debt obligations and comply with certain covenants in its credit facilities with respect to financial ratios and financial condition tests and its ability to maintain a favorable cash liquidity position;

[0001137789-21-000006:mdna:10]
[same as prior period, unchanged from 0001137789-20-000117:mdna:10]

[0001137789-21-000006:mdna:11]
[same as prior period, unchanged from 0001137789-20-000117:mdna:11]

[0001137789-21-000006:mdna:12]
[same as prior period, unchanged from 0001137789-20-000117:mdna:12]

[0001137789-21-000006:mdna:13]
[same as prior period, unchanged from 0001137789-20-000117:mdna:13]

[0001137789-21-000006:mdna:14]
[same as prior period, unchanged from 0001137789-20-000117:mdna:14]

[0001137789-21-000006:mdna:15]
[same as prior period, unchanged from 0001137789-20-000117:mdna:15]

[0001137789-21-000006:mdna:16]
[same as prior period, unchanged from 0001137789-20-000117:mdna:16]

[0001137789-21-000006:mdna:17]
[same as prior period, unchanged from 0001137789-20-000117:mdna:57]

[0001137789-21-000006:mdna:18]
[same as prior period, unchanged from 0001137789-20-000117:mdna:18]

[0001137789-21-000006:mdna:19]
•Overview of the December 2020 quarter. Highlights of events in the December 2020 quarter that impacted our financial position.

[0001137789-21-000006:mdna:20]
•Results of Operations. Analysis of our financial results comparing the December 2020 quarter to the September 2020 quarter and the December 2019 quarter.

[0001137789-21-000006:mdna:21]
[same as prior period, unchanged from 0001137789-20-000117:mdna:21]

[0001137789-21-000006:mdna:22]
[same as prior period, unchanged from 0001137789-20-000117:mdna:22]

[0001137789-21-000006:mdna:23]
[same as prior period, unchanged from 0001137789-20-000117:mdna:23]

[0001137789-21-000006:mdna:24]
Overview of the December 2020 quarter

[0001137789-21-000006:mdna:25]
During the December 2020 quarter, we shipped 129 exabytes of HDD storage capacity. We generated revenue of approximately $2.6 billion and gross margin of 27% and our operating cash flow was $473 million. We issued $1 billion of new senior notes, repurchased approximately 18 million of our ordinary shares for $1 billion and paid $167 million in dividends.

[0001137789-21-000006:mdna:26]
[same as prior period, unchanged from 0001137789-20-000117:mdna:26]

[0001137789-21-000006:mdna:27]
The COVID-19 pandemic has resulted in a widespread health crisis and numerous disease control measures are being taken to limit its spread, the effects of which began during our quarter ended April 3, 2020. We continued to incur certain supply chain and demand disruptions during the December 2020 quarter, as well as higher logistics and operational costs, factory under-utilization and softer demand across certain markets due to the COVID-19 pandemic, which we expect to continue during fiscal year 2021. Our customers also continued to experience certain supply chain and demand disruptions during the December 2020 quarter, which we anticipate will continue during fiscal year 2021. We are continuing to actively monitor the effects and potential impacts of the COVID-19 pandemic on all aspects of our business, liquidity and capital resources. We are complying with governmental rules and guidelines across all of our sites and are actively working on opportunities to lower our cost structure and drive further operational efficiencies. Although we are unable to predict the impact of COVID-19 on our business, results of operations, liquidity or capital resources at this time, we expect we will be negatively affected if the pandemic and related public and private health measures result in substantial manufacturing or supply chain problems, substantial reductions in demand due to disruptions in the operations of our customers or partners, disruptions in local and global economies, volatility in the global financial markets, sustained reductions or volatility in overall demand trends, restrictions on the export or shipment of our products, or other ramifications from the COVID-19 pandemic. For a further discussion of the uncertainties and business risks associated with the COVID-19 pandemic, see the section entitled “Item 1A. Risk Factors” in our Annual Report on Form 10-K for the fiscal year ended July 3, 2020.

[0001137789-21-000006:mdna:28]
33

[0001137789-21-000006:mdna:29]
[same as prior period, unchanged from 0001137789-20-000117:mdna:28]

[0001137789-21-000006:mdna:30]
[same as prior period, unchanged from 0001137789-20-000117:mdna:29]

[0001137789-21-000006:mdna:31]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | January 1,2021 |  | October 2,2020 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |
| Revenue |  | $ | 2,623 |  |  | $ | 2,314 |  |  | $ | 2,696 |  |  | $ | 4,937 |  |  | $ | 5,274 |  |
| Cost of revenue |  | 1,927 |  |  | 1,718 |  |  | 1,938 |  |  | 3,645 |  |  | 3,845 |  |
| Gross profit |  | 696 |  |  | 596 |  |  | 758 |  |  | 1,292 |  |  | 1,429 |  |
| Product development |  | 221 |  |  | 223 |  |  | 250 |  |  | 444 |  |  | 505 |  |
| Marketing and administrative |  | 122 |  |  | 118 |  |  | 120 |  |  | 240 |  |  | 242 |  |
| Amortization of intangibles |  | 3 |  |  | 3 |  |  | 4 |  |  | 6 |  |  | 8 |  |
| Restructuring and other, net |  | 2 |  |  | 1 |  |  | — |  |  | 3 |  |  | 17 |  |
| Income from operations |  | 348 |  |  | 251 |  |  | 384 |  |  | 599 |  |  | 657 |  |
| Other expense, net |  | (57) |  |  | (30) |  |  | (48) |  |  | (87) |  |  | (123) |  |
| Income before income taxes |  | 291 |  |  | 221 |  |  | 336 |  |  | 512 |  |  | 534 |  |
| Provision (benefit) for income taxes |  | 11 |  |  | (2) |  |  | 18 |  |  | 9 |  |  | 16 |  |
| Net income |  | $ | 280 |  |  | $ | 223 |  |  | $ | 318 |  |  | $ | 503 |  |  | $ | 518 |  |

[0001137789-21-000006:mdna:32]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
|  |  | January 1,2021 |  | October 2,2020 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 73 |  |  | 74 |  |  | 72 |  |  | 74 |  |  | 73 |  |
| Gross profit |  | 27 |  |  | 26 |  |  | 28 |  |  | 26 |  |  | 27 |  |
| Product development |  | 9 |  |  | 10 |  |  | 9 |  |  | 9 |  |  | 10 |  |
| Marketing and administrative |  | 5 |  |  | 5 |  |  | 4 |  |  | 5 |  |  | 5 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Restructuring and other, net |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income from operations |  | 13 |  |  | 11 |  |  | 15 |  |  | 12 |  |  | 12 |  |
| Other expense, net |  | (2) |  |  | (1) |  |  | (2) |  |  | (2) |  |  | (2) |  |
| Income before income taxes |  | 11 |  |  | 10 |  |  | 13 |  |  | 10 |  |  | 10 |  |
| Provision (benefit) for income taxes |  | — |  |  | — |  |  | 1 |  |  | — |  |  | — |  |
| Net income |  | 11 | % |  | 10 | % |  | 12 | % |  | 10 | % |  | 10 | % |

[0001137789-21-000006:mdna:33]
[same as prior period, unchanged from 0001137789-20-000117:mdna:96]

[0001137789-21-000006:mdna:34]
[same as prior period, unchanged from 0001137789-20-000117:mdna:33]

[0001137789-21-000006:mdna:35]
The following table summarizes information regarding consolidated revenues by channel, geography and market, HDD exabytes shipped by market and HDD price per terabyte:

[0001137789-21-000006:mdna:36]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
|  |  | January 1,2021 |  | October 2,2020 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | 66 | % |  | 69 | % |  | 68 | % |  | 68 | % |  | 69 | % |
| Distributors |  | 18 | % |  | 16 | % |  | 17 | % |  | 17 | % |  | 18 | % |
| Retailers |  | 16 | % |  | 15 | % |  | 15 | % |  | 15 | % |  | 13 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 50 | % |  | 48 | % |  | 51 | % |  | 49 | % |  | 50 | % |
| Americas |  | 32 | % |  | 35 | % |  | 28 | % |  | 33 | % |  | 30 | % |
| EMEA |  | 18 | % |  | 17 | % |  | 21 | % |  | 18 | % |  | 20 | % |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 58 | % |  | 58 | % |  | 49 | % |  | 58 | % |  | 48 | % |
| Legacy |  | 35 | % |  | 34 | % |  | 43 | % |  | 34 | % |  | 44 | % |
| Other |  | 7 | % |  | 8 | % |  | 8 | % |  | 8 | % |  | 8 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 97 |  |  | 86 |  |  | 71 |  |  | 183 |  |  | 135 |  |
| Legacy |  | 32 |  |  | 28 |  |  | 36 |  |  | 60 |  |  | 70 |  |
| Total |  | 129 |  |  | 114 |  |  | 107 |  |  | 243 |  |  | 205 |  |
| HDD Price per Terabyte |  | $ | 19 |  |  | $ | 19 |  |  | $ | 23 |  |  | $ | 19 |  |  | $ | 24 |  |

[0001137789-21-000006:mdna:37]
Revenue in the December 2020 quarter increased by $309 million from the September 2020 quarter primarily due to an increase in exabytes shipped, driven by improved market conditions and seasonality.

[0001137789-21-000006:mdna:38]
Revenue in the December 2020 quarter decreased by $73 million from the December 2019 quarter primarily due to price erosion, a decrease in legacy market exabytes shipped and lower demand as a result of the COVID-19 pandemic, partially offset by an increase in mass capacity storage exabytes shipped.

[0001137789-21-000006:mdna:39]
Revenue for the six months ended January 1, 2021 decreased by $337 million from the six months ended January 3, 2020 primarily as a result of price erosion, a decrease in legacy market exabytes shipped and lower demand as a result of the COVID-19 pandemic, partially offset by an increase in mass capacity storage exabytes shipped.

[0001137789-21-000006:mdna:40]
We maintain various sales incentive programs such as channel and original equipment manufacturers rebates. Sales incentive programs were approximately 15% of gross revenue for the December 2020 quarter, 15% for the September 2020 quarter and 12% for the December 2019 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-21-000006:mdna:41]
[same as prior period, unchanged from 0001137789-20-000117:mdna:39]

[0001137789-21-000006:mdna:42]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | January 1,2021 |  | October 2,2020 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |
| Cost of revenue |  | $ | 1,927 |  |  | $ | 1,718 |  |  | $ | 1,938 |  |  | $ | 3,645 |  |  | $ | 3,845 |  |
| Gross profit |  | 696 |  |  | 596 |  |  | 758 |  |  | 1,292 |  |  | 1,429 |  |
| Gross margin |  | 27 | % |  | 26 | % |  | 28 | % |  | 26 | % |  | 27 | % |

[0001137789-21-000006:mdna:43]
Gross margin for the December 2020 quarter increased compared to the September 2020 quarter primarily due to improved product mix.

[0001137789-21-000006:mdna:44]
35

[0001137789-21-000006:mdna:45]
Gross margin for the December 2020 quarter decreased compared to the December 2019 quarter primarily driven by price erosion and higher logistics costs as a result of the COVID-19 pandemic, partially offset by improved product mix.

[0001137789-21-000006:mdna:46]
Gross margin for the six months ended January 1, 2021 decreased compared to the six months ended January 3, 2020 primarily driven by price erosion and higher logistics costs as a result of the COVID-19 pandemic, partially offset by improved product mix.

[0001137789-21-000006:mdna:47]
In the December 2020 quarter, total warranty cost was 0.6% of revenue and included a favorable change in estimates of prior warranty accruals of 0.1% of revenue primarily due to lower repair costs and a decrease in the number of drives under warranty. Warranty cost related to new shipments was 0.7%, 0.8% and 0.8% of revenue for the December 2020 quarter, September 2020 quarter and December 2019 quarter, respectively.

[0001137789-21-000006:mdna:48]
[same as prior period, unchanged from 0001137789-20-000117:mdna:43]

[0001137789-21-000006:mdna:49]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | January 1,2021 |  | October 2,2020 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |
| Product development |  | $ | 221 |  |  | $ | 223 |  |  | $ | 250 |  |  | $ | 444 |  |  | $ | 505 |  |
| Marketing and administrative |  | 122 |  |  | 118 |  |  | 120 |  |  | 240 |  |  | 242 |  |
| Amortization of intangibles |  | 3 |  |  | 3 |  |  | 4 |  |  | 6 |  |  | 8 |  |
| Restructuring and other, net |  | 2 |  |  | 1 |  |  | — |  |  | 3 |  |  | 17 |  |
| Operating expenses |  | $ | 348 |  |  | $ | 345 |  |  | $ | 374 |  |  | $ | 693 |  |  | $ | 772 |  |

[0001137789-21-000006:mdna:50]
Product development expense. Product development expense for the December 2020 quarter decreased by $2 million  compared to the September 2020 quarter primarily due to a $5 million decrease in compensation and other employee benefits, partially offset by a $4 million increase in variable compensation expense.

[0001137789-21-000006:mdna:51]
Product development expense decreased by $29 million in the December 2020 quarter compared to the December 2019 quarter primarily due to an $18 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our June 2020 restructuring plan, a $4 million decrease in travel expenses mainly as a result of disruptions related to COVID-19, and a $3 million decrease in materials expense, partially offset by a $4 million increase in variable compensation expense.

[0001137789-21-000006:mdna:52]
Product development expense decreased by $61 million for the six months ended January 1, 2021 compared to the six months ended January 3, 2020 primarily due to a $36 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our June 2020 restructuring plan and the additional fourteenth week in the quarter ended October 4, 2019, a $7 million decrease in travel expenses mainly as a result of the disruptions related to COVID-19, a $6 million decrease in information technology costs, a $3 million decrease in equipment expense, a $3 million decrease in materials expense, and a $2 million decrease in software expense, partially offset by a $6 million increase in variable compensation expense.

[0001137789-21-000006:mdna:53]
Marketing and administrative expense. Marketing and administrative expense increased by $4 million for the December 2020 quarter compared to the September 2020 quarter primarily due to a $3 million increase in outside services expense and a $2 million increase in variable compensation expense.

[0001137789-21-000006:mdna:54]
Marketing and administrative expense increased by $2 million in the December 2020 quarter compared to the December 2019 quarter primarily due to a $13 million increase in information technology costs, partially offset by a $4 million decrease in equipment expense, a $4 million decrease in compensation and other employee benefits and a $3 million decrease in travel expenses mainly as a result of disruptions related to COVID-19.

[0001137789-21-000006:mdna:55]
Marketing and administrative expense decreased by $2 million for the six months ended January 1, 2021 compared to the six months ended January 3, 2020 primarily due to a $9 million decrease in travel expenses mainly as a result of disruptions related to COVID-19, a $7 million decrease in compensation and other employee benefits from the additional fourteenth week in the quarter ended October 4, 2019, a $7 million decrease in equipment expense, and a $6 million decrease in depreciation expense, primarily offset by a $23 million increase in information technology costs and a $4 million increase in variable compensation expense.

[0001137789-21-000006:mdna:56]
Amortization of intangibles. Amortization of intangibles for the December 2020 quarter remained flat compared to the September 2020 quarter.

[0001137789-21-000006:mdna:57]
36

[0001137789-21-000006:mdna:58]
Amortization of intangibles for the three and six months ended January 1, 2021 decreased by $1 million and $2 million, respectively, compared to the three and six months ended January 3, 2020, due to certain intangible assets that reached the end of their useful lives.

[0001137789-21-000006:mdna:59]
Restructuring and other, net. Restructuring and other, net for the three and six months ended January 1, 2021 was not material.

[0001137789-21-000006:mdna:60]
Restructuring and other, net for the six months ended January 3, 2020 was comprised of charges primarily related to a voluntary early exit program.

[0001137789-21-000006:mdna:61]
[same as prior period, unchanged from 0001137789-20-000117:mdna:54]

[0001137789-21-000006:mdna:62]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | January 1,2021 |  | October 2,2020 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |
| Other expense, net |  | $ | (57) |  |  | $ | (30) |  |  | $ | (48) |  |  | $ | (87) |  |  | $ | (123) |  |

[0001137789-21-000006:mdna:63]
Other expense, net. Other expense, net for the December 2020 quarter increased by $27 million from the September 2020 quarter primarily due to $31 million of strategic investment gains in the September 2020 quarter, of which $23 million is an upward adjustment and $8 million is a gain upon sale of an investment and a $7 million impairment charge in the December 2020 quarter, partially offset by an $11 million decrease in foreign exchange remeasurement expense in the December 2020 quarter.

[0001137789-21-000006:mdna:64]
Other expense, net for the December 2020 quarter increased by $9 million compared to the December 2019 quarter primarily due to a $14 million increase in interest expense from the issuance of long-term debt in the December 2020 quarter and the September 2020 quarter and a $7 million impairment charge in the December 2020 quarter, partially offset by an $11 million decrease in interest expense due to the repurchase of certain long-term debt.

[0001137789-21-000006:mdna:65]
Other expense, net for the six months ended January 1, 2021 decreased by $36 million compared to the six months ended January 3, 2020 primarily due to $31 million of strategic investment gains in the September 2020 quarter, of which $23 million is an upward adjustment and $8 million is a gain upon sale of an investment, a $31 million decrease in interest expense due to the repurchase of certain long-term debt, a $28 million non-recurring loss from the repurchase and exchange of certain long-term debt in the quarter ended October 4, 2019 and a $12 million increase in gains on de-designated cash flow hedges. The decrease was partially offset by a $26 million increase in interest expense from the issuance of long-term debt in the December 2020 quarter and the September 2020 quarter, a $14 million increase in foreign exchange remeasurement expense, a $13 million decrease in interest income primarily due to a decline in interest rates and a $7 million impairment charge in the December 2020 quarter.

[0001137789-21-000006:mdna:66]
[same as prior period, unchanged from 0001137789-20-000117:mdna:59]

[0001137789-21-000006:mdna:67]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | January 1,2021 |  | October 2,2020 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |
| Provision (benefit) for income taxes |  | $ | 11 |  |  | $ | (2) |  |  | $ | 18 |  |  | $ | 9 |  |  | $ | 16 |  |

[0001137789-21-000006:mdna:68]
We recorded income tax provisions of $11 million and $9 million in the three and six months ended January 1, 2021, respectively. The discrete items in the income tax provision were not material for the three months ended January 1, 2021. The income tax provision for the six months ended January 1, 2021 included approximately $11 million of net discrete tax benefits, primarily associated with net excess tax benefits related to share-based compensation expense and postponement of the previously enacted United Kingdom (“U.K.”) tax rate change in the September 2020 quarter.

[0001137789-21-000006:mdna:69]
Our income tax provision recorded for the three and six months ended January 1, 2021 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-21-000006:mdna:70]
During the six months ended January 1, 2021, our unrecognized tax benefits excluding interest and penalties increased by approximately $1 million to $90 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. During the twelve months beginning January 2, 2021, we expect that our unrecognized tax benefits could be reduced by an immaterial amount, as a result of the expiration of certain statutes of limitation.

[0001137789-21-000006:mdna:71]
We recorded income tax provisions of $18 million and $16 million in the three and six months ended January 3, 2020. The discrete items in the income tax provision were not material for the three months ended January 3, 2020. The income tax provision for the six months ended January 3, 2020 included approximately $10 million of net discrete tax benefits, primarily associated with net excess tax benefits related to share-based compensation expense.

[0001137789-21-000006:mdna:72]
Our income tax provision recorded for the three and six months ended January 3, 2020 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-21-000006:mdna:73]
[same as prior period, unchanged from 0001137789-20-000117:mdna:66]

[0001137789-21-000006:mdna:74]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash will continue to be sufficient to meet our cash needs for the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs, will allow us to manage the potential impacts of the COVID-19 pandemic on our business operations for the foreseeable future. However, the challenges posed by the COVID-19 pandemic to our industry and to our business are evolving rapidly, are highly uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to the COVID-19 pandemic.

[0001137789-21-000006:mdna:75]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of January 1, 2021.

[0001137789-21-000006:mdna:76]
[same as prior period, unchanged from 0001137789-20-000117:mdna:69]

[0001137789-21-000006:mdna:77]
| (Dollars in millions) |  | January 1,2021 |  | July 3,2020 |  | Change |
| Cash and cash equivalents |  | $ | 1,799 |  |  | $ | 1,722 |  |  | $ | 77 |  |

[0001137789-21-000006:mdna:78]
Our cash and cash equivalents as of January 1, 2021 increased by $77 million from July 3, 2020 primarily as a result of net proceeds of $986 million from the issuance of long-term debt and net cash of $770 million provided by operating activities, partially offset by the repurchases of our ordinary shares of $1 billion, dividends paid to our shareholders of $334 million, and payments for capital expenditures of $270 million.

[0001137789-21-000006:mdna:79]
[same as prior period, unchanged from 0001137789-20-000117:mdna:72]

[0001137789-21-000006:mdna:80]
Cash provided by operating activities for the six months ended January 1, 2021 was $770 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-21-000006:mdna:81]
•a decrease of $315 million in accounts receivable, primarily due to linearity of sales in the December 2020 quarter and a decrease in revenue;

[0001137789-21-000006:mdna:82]
•partially offset by an increase of $176 million in inventories, primarily due to timing of shipments and an increase in materials purchased, including strategic purchases;

[0001137789-21-000006:mdna:83]
•a decrease of $75 million in accounts payable, primarily due to lower operating expenses and timing of payments; and

[0001137789-21-000006:mdna:84]
•a decrease of $40 million in accrued restructuring, primarily due to severance payments to impacted employees.

[0001137789-21-000006:mdna:85]
[same as prior period, unchanged from 0001137789-20-000117:mdna:79]

[0001137789-21-000006:mdna:86]
Cash used in investing activities for the six months ended January 1, 2021 was $263 million, primarily attributable to the following activities:

[0001137789-21-000006:mdna:87]
•payments for the purchase of property, equipment and leasehold improvements of $270 million; and

[0001137789-21-000006:mdna:88]
[same as prior period, unchanged from 0001137789-20-000117:mdna:82]

[0001137789-21-000006:mdna:89]
[same as prior period, unchanged from 0001137789-20-000117:mdna:83]

[0001137789-21-000006:mdna:90]
[same as prior period, unchanged from 0001137789-20-000117:mdna:84]

[0001137789-21-000006:mdna:91]
Cash used in financing activities of $430 million for the six months ended January 1, 2021 was primarily attributable to the following activities:

[0001137789-21-000006:mdna:92]
•payments for the repurchase of our ordinary shares of $1 billion;

[0001137789-21-000006:mdna:93]
•payments for dividends of $334 million;

[0001137789-21-000006:mdna:94]
•payments for taxes related to net share settlement of equity awards of $32 million; and

[0001137789-21-000006:mdna:95]
•payments for the repurchase of long-term debt of $21 million;

[0001137789-21-000006:mdna:96]
•partially offset by net proceeds from the issuance of long-term debt of $986 million; and

[0001137789-21-000006:mdna:97]
•proceeds from the issuance of ordinary shares under employee share plans of $40 million.

[0001137789-21-000006:mdna:98]
[same as prior period, unchanged from 0001137789-20-000117:mdna:91]

[0001137789-21-000006:mdna:99]
Our primary sources of liquidity as of January 1, 2021 consisted of: (1) approximately $1.8 billion in cash and cash equivalents, (2) cash we expect to generate from operations, and (3) subject to compliance with certain requirements under our control, up to $1.5 billion available for borrowing under our Revolving Credit Facility. On January 13, 2021, we entered into an amendment to the Revolving Credit Facility which increased the amount available for borrowing to $1.725 billion.

[0001137789-21-000006:mdna:100]
As of January 1, 2021, no borrowings had been drawn and no borrowings had been utilized for letters of credit or swing line loans issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-21-000006:mdna:101]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The term of the Revolving Credit Facility is through February 20, 2024, and the maturity date of the Term Loan is September 16, 2025. We were in compliance with the covenants as of January 1, 2021 and expect to be in compliance for the next 12 months.

[0001137789-21-000006:mdna:102]
[same as prior period, unchanged from 0001137789-20-000117:mdna:95]

[0001137789-21-000006:mdna:103]
[same as prior period, unchanged from 0001137789-20-000117:mdna:97]

[0001137789-21-000006:mdna:104]
From time to time, we may repurchase any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase outstanding senior notes pursuant to the terms of the applicable indenture.

[0001137789-21-000006:mdna:105]
During the December 2020 quarter, our Board of Directors declared dividends of $0.67 per share, totaling $161 million, which were paid on January 6, 2021. On January 21, 2021, our Board of Directors declared a quarterly cash dividend of $0.67 per share, payable on April 7, 2021 to shareholders of record at the close of business on March 24, 2021.

[0001137789-21-000006:mdna:106]
From time to time, at the Company’s discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means, including through the use of derivative transactions. On October 21, 2020, our Board of Directors increased the authorization for the repurchase of our outstanding ordinary shares by $3.0 billion. As of January 1, 2021, $3.2 billion remained available for repurchases under our existing repurchase authorization. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-21-000006:mdna:107]
[same as prior period, unchanged from 0001137789-20-000117:mdna:101]

[0001137789-21-000006:mdna:108]
[same as prior period, unchanged from 0001137789-20-000117:mdna:102]

[0001137789-21-000006:mdna:109]
[same as prior period, unchanged from 0001137789-20-000117:mdna:103]

[0001137789-21-000006:mdna:110]
[same as prior period, unchanged from 0001137789-20-000117:mdna:104]

[0001137789-21-000006:mdna:111]
[same as prior period, unchanged from 0001137789-20-000117:mdna:105]
