# STX note change history — 0001137789-20-000117 → 0001137789-21-000006


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2021-01-28):
[0001137789-21-000006:note_history:1]
Nidec Corporation v. Seagate Technology LLC, et al. On January 18, 2021, Nidec Corporation filed a complaint against Seagate Technology LLC, Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology (Netherlands) B.V. in the United States District Court for the District of Delaware, alleging infringement of the following patents: U.S. Patent No. 8,737,017, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,742,239, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,935,528, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 10,407,775, titled “Base Plate, Hard Disk Drive, and Method of Manufacturing Base Plate,” and U.S. Patent No. 10,460,767, titled “Base Member Including Information Mark and Insulating Coating Layer, and Disk Drive Apparatus Including the Same.”  The complaint seeks unspecified compensatory damages and other relief.  The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-01-28):
[0001137789-21-000006:note_history:2]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three and six months ended January 1, 2021 consisted of 13 and 26 weeks, respectively, and the three and six months ended January 3, 2020 consisted of 13 and 27 weeks, respectively. Fiscal year 2021, which ends on July 2, 2021, is comprised of 52 weeks and fiscal year 2020, which ended on July 3, 2020, was comprised of 53 weeks. The fiscal quarters ended January 1, 2021, October 2, 2020 and January 3, 2020, are also referred to herein as the “December 2020 quarter”, the “September 2020 quarter” and the “December 2019 quarter”, respectively. The results of operations for the three and six months ended January 1, 2021 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending July 2, 2021.

- changed (2021-01-28):
[0001137789-21-000006:note_history:3]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles—Goodwill and Other—Internal-Use Software—Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company adopted this new accounting pronouncement in the September 2020 quarter. The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.
  (was, 2020-10-29, similarity 0.9969):
[0001137789-20-000117:note_history:3]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles—Goodwill and Other - Internal-Use Software—Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company adopted this new accounting pronouncement in the September 2020 quarter. The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.

- removed (2021-01-28):
[0001137789-20-000117:note_history:4]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three months ended October 2, 2020 consisted of 13 weeks and the three months ended October 4, 2019 consisted of 14 weeks. Fiscal year 2021, which ends on July 2, 2021, is comprised of 52 weeks and fiscal year 2020, which ended on July 3, 2020, was comprised of 53 weeks. The fiscal quarters ended October 2, 2020, July 3, 2020 and October 4, 2019, are also referred to herein as the “September 2020 quarter”, the “June 2020 quarter” and the “September 2019 quarter”, respectively. The results of operations for the three months ended October 2, 2020 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending July 2, 2021.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-01-28):
[0001137789-21-000006:note_history:5]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement (the “Credit Agreement”) on February 20, 2019. As of January 1, 2021, the Credit Agreement provided an up to $1.5 billion senior unsecured revolving credit facility (“Revolving Credit Facility”) and a term loan facility in an aggregate principal amount of $500 million (“Term Loan”). The Revolving Credit Facility has a final maturity of February 20, 2024 and the Term Loan has a final maturity date of September 16, 2025. The loans made under the Revolving Credit Facility and the Term Loan will bear interest at a rate of the London Interbank Offered Rate (“LIBOR”) plus a variable margin for each facility that will be determined based on the corporate credit rating of the Company. As of January 1, 2021, STX and certain of its material subsidiaries fully and unconditionally guaranteed both the Revolving Credit Facility and the Term Loan. As of January 1, 2021, the Revolving Credit Facility also allowed such facility to increase by an additional $100 million, provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at least $25 million, and (iii) the existing commitments under such facility receive 0.50% most favored nation protection. An aggregate amount of up to $75 million of the Revolving Credit Facility is available for the issuance of letters of credit, and an aggregate amount of up to $50 million of such facility is also available for swing line loans. On January 13, 2021, the Company and Seagate HDD Cayman entered into an amendment to the Credit Agreement which increased the size of the Revolving Credit Facility to $1.725 billion and allows such facility to increase by an additional $275 million, subject to the same terms and conditions as stated above. The amendment also reduced the indebtedness guaranteed by certain of Seagate HDD Cayman’s material subsidiaries to an amount $100 million less than the amount that would give rise to a guarantee requirement by such subsidiaries in respect of any series of senior notes.
  (was, 2020-10-29, similarity 0.8103):
[0001137789-20-000117:note_history:5]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement (the “Credit Agreement”) on February 20, 2019, which was most recently amended on September 16, 2019. The Credit Agreement provides an up to $1.5 billion senior unsecured revolving credit facility (“Revolving Credit Facility”) and a term loan facility in an aggregate principal amount of $500 million (“Term Loan”). The Revolving Credit Facility has a final maturity of February 20, 2024 and the Term Loan has a final maturity date of September 16, 2025. The loans made under the Revolving Credit Facility and the Term Loan will bear interest at a rate of the London Interbank Offered Rate (“LIBOR”) plus a variable margin for each facility that will be determined based on the corporate credit rating of the Company. STX and certain of its material subsidiaries fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loan. The Revolving Credit Facility also allows such facility to increase by an additional $100 million, provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at least $25 million, and (iii) the existing commitments under such facility receive 0.50% most favored nation protection. An aggregate amount of up to $75 million of the Revolving Credit Facility is available for the issuance of letters of credit, and an aggregate amount of up to $50 million of such facility is also available for swing line loans.

- changed (2021-01-28):
[0001137789-21-000006:note_history:6]
On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the Term Loan and the proceeds were used to repurchase a portion of its outstanding senior notes. The Term Loan is repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with the remaining balance payable upon maturity. The Company repaid $6 million principal amount of the Term Loan during the three and six months ended January 1, 2021.
  (was, 2020-10-29, similarity 0.8593):
[0001137789-20-000117:note_history:6]
On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the Term Loan and the proceeds were used to repurchase a portion of its outstanding senior notes. The Term Loan is repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with the remaining balance payable upon maturity.

- changed (2021-01-28):
[0001137789-21-000006:note_history:7]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of January 1, 2021 and expects to be in compliance for the next 12 months.
  (was, 2020-10-29, similarity 0.9721):
[0001137789-20-000117:note_history:7]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of October 2, 2020 and expects to be in compliance for the next 12 months.

- changed (2021-01-28):
[0001137789-21-000006:note_history:8]
As of January 1, 2021, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the Revolving Credit Facility.
  (was, 2020-10-29, similarity 0.9577):
[0001137789-20-000117:note_history:8]
As of October 2, 2020, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the Revolving Credit Facility.

- changed (2021-01-28):
[0001137789-21-000006:note_history:9]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March, 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the six months ended January 1, 2021, $9 million aggregate principal amount of the 2022 Notes was repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. During the six months ended January 3, 2020, $250 million aggregate principal amount was repurchased pursuant to cash tender offers for certain senior notes (“the Tender Offers”). The Company recorded an immaterial loss and a loss of $10 million, respectively, on repurchases during the six months ended January 1, 2021 and January 3, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2020-10-29, similarity 0.9033):
[0001137789-20-000117:note_history:9]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March, 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the three months ended October 2, 2020, $9 million aggregate principal amount of the 2022 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. During the three months ended October 4, 2019, $250 million aggregate principal amount was repurchased pursuant to cash tender offers for certain senior notes (“the Tender Offers”). The Company recorded an immaterial loss and a loss of $10 million, respectively, on repurchases during the three months ended October 2, 2020 and October 4, 2019, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- changed (2021-01-28):
[0001137789-21-000006:note_history:10]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June, 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the six months ended January 1, 2021, $5 million aggregate principal amount of the 2023 Notes was repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. During the six months ended January 3, 2020, $200 million aggregate principal amount was repurchased pursuant to the Tender Offers. The Company recorded a loss of $1 million and $10 million, respectively, on repurchases during the six months ended January 1, 2021 and January 3, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2020-10-29, similarity 0.8558):
[0001137789-20-000117:note_history:10]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June, 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the three months ended October 2, 2020, $5 million aggregate principal amount of the 2023 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest, of which $2 million remained unsettled as of October 2, 2020. During the three months ended October 4, 2019, $200 million aggregate principal amount was repurchased pursuant to the Tender Offers. The Company recorded a loss of $1 million and $10 million, respectively, on repurchases during the three months ended October 2, 2020 and October 4, 2019, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- changed (2021-01-28):
[0001137789-21-000006:note_history:11]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January, 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the six months ended January 3, 2020, $170 million aggregate principal amount was repurchased pursuant to the Tender Offers. The Company recorded a loss of $8 million on repurchases during the six months ended January 3, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2020-10-29, similarity 0.9254):
[0001137789-20-000117:note_history:11]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January, 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the three months ended October 4, 2019, $170 million aggregate principal amount was repurchased pursuant to the Tender Offers. The Company recorded a loss of $8 million on repurchases during the three months ended October 4, 2019, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- changed (2021-01-28):
[0001137789-21-000006:note_history:12]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June, 2027 (the “2027 Notes”). The interest on the 2027 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.
  (was, 2020-10-29, similarity 0.9971):
[0001137789-20-000117:note_history:12]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June, 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

- changed (2021-01-28):
[0001137789-21-000006:note_history:13]
$500 million Aggregate Principal Amount of 4.091% Senior Notes due June, 2029 (the “June 2029 Notes”). The interest on the June 2029 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the June 2029 Notes is Seagate HDD Cayman, and the obligations under the June 2029 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.
  (was, 2020-10-29, similarity 0.8732):
[0001137789-20-000117:note_history:13]
$500 million Aggregate Principal Amount of 4.091% Senior Notes due June, 2029 (the “2029 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2029 Notes is Seagate HDD Cayman, and the obligations under the 2029 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

- added (2021-01-28):
[0001137789-21-000006:note_history:14]
$500 million Aggregate Principal Amount of 3.125% Senior Notes due July, 2029 (the “July 2029 Notes”). On December 8, 2020, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of the July 2029 Notes, which will mature on July 15, 2029. The obligations under the July 2029 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. The interest on the July 2029 Notes is payable semi-annually on January 15 and July 15 of each year, commencing on July 15, 2021. At any time before January 15, 2024, Seagate HDD Cayman may redeem some or all of the July 2029 Notes at a “make-whole” redemption price. The “make-whole” redemption price will be equal to (1) 100% of the principal amount of the July 2029 Notes redeemed, plus (2) the greater of (a) 1.0% of the principal amount of the July 2029 Notes and (b) the excess, if any, of (i) the present value at such redemption date of (x) the applicable redemption price of such July 2029 Notes that would apply if such July 2029 Notes were redeemed on January 15, 2024, plus (y) all remaining scheduled payments of interest due on such July 2029 Notes to and including January 15, 2024, computed using a discount rate equal to the applicable Treasury Rate as of such redemption date plus 50 basis points; over (ii) the sum of accrued and unpaid interest, if any, to, but excluding, the redemption date, plus the principal amount of such July 2029 Notes, plus (3) accrued and unpaid interest, if any, to, but excluding, the redemption date. At any time on or after January 15, 2024, Seagate HDD Cayman may redeem some or all of such July 2029 Notes at a price of 101.563%, 100.781% and 100.000%, after January 15, 2024, January 15, 2025 and January 15, 2026, respectively, plus accrued and unpaid interest thereon, if any, to, but excluding, the redemption date. In addition, Seagate HDD Cayman may redeem with the net cash proceeds from one or more equity offerings up to 40% of the July 2029 Notes before January 15, 2024, at a redemption price of 103.125%, plus accrued and unpaid interest to, but excluding, the redemption date.

- changed (2021-01-28):
[0001137789-21-000006:note_history:15]
$500 million Aggregate Principal Amount of 4.125% Senior Notes due January, 2031 (the “January 2031 Notes”). The interest on the January 2031 Notes is payable semi-annually on January 15 and July 15 of each year. The issuer under the January 2031 Notes is Seagate HDD Cayman, and the obligations under the January 2031 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.
  (was, 2020-10-29, similarity 0.789):
[0001137789-20-000117:note_history:15]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December, 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

- added (2021-01-28):
[0001137789-21-000006:note_history:16]
$500 million Aggregate Principal Amount of 3.375% Senior Notes due July, 2031 (the “July 2031 Notes”). On December 8, 2020, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of the July 2031 Notes, which will mature on July 15, 2031. The obligations under the July 2031 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. The interest on the July 2031 Notes is payable semi-annually on January 15 and July 15 of each year, commencing on July 15, 2021. At any time before January 15, 2026, Seagate HDD Cayman may redeem some or all of the July 2031 Notes at a “make-whole” redemption price. The “make-whole” redemption price will be equal to (1) 100% of the principal amount of the July 2031 Notes redeemed, plus (2) the greater of (a) 1.0% of the principal amount of the July 2031 Notes and (b) the excess, if any, of (i) the present value at such redemption date of (x) the applicable redemption price of such July 2031 Notes that would apply if such July 2031 Notes were redeemed on January 15, 2026, plus (y) all remaining scheduled payments of interest due on such July 2031 Notes to and including January 15, 2026, computed using a discount rate equal to the Treasury Rate as of such redemption date plus 50 basis points; over (ii) the sum of accrued and unpaid interest, if any, to, but excluding, the redemption date, plus the principal amount of such July 2031 Notes, plus (3) accrued and unpaid interest, if any, to, but excluding, the redemption date. At any time on or after January 15, 2026, Seagate HDD Cayman may redeem some or all of such July 2031 Notes at a price of 101.688%, 101.125%, 100.563% and 100.000%, after January 15, 2026, January 15, 2027, January 15, 2028 and January 15, 2029, respectively, plus accrued and unpaid interest thereon, if any, to, but excluding, the redemption date. In addition, Seagate HDD Cayman may redeem with the net cash proceeds from one or more equity offerings up to 40% of the July 2031 Notes before January 15, 2024, a redemption price of 103.375%, accrued and unpaid interest to, but excluding, the redemption date.
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December, 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

- removed (2021-01-28):
[0001137789-20-000117:note_history:17]
$500 million Aggregate Principal Amount of 4.125% Senior Notes due January, 2031 (the “2031 Notes”). The interest on the Notes is payable semi-annually on January 15 and July 15 of each year. The issuer under the 2031 Notes is Seagate HDD Cayman, and the obligations under the 2031 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

- removed (2021-01-28):
[0001137789-20-000117:note_history:18]
At October 2, 2020, future principal payments on long-term debt were as follows (in millions):

- removed (2021-01-28):
[0001137789-20-000117:note_history:19]
| Fiscal Year |  | Amount |
| Remainder of 2021 |  | $ | 19 |  |
| 2022 |  | 245 |  |
| 2023 |  | 566 |  |
| 2024 |  | 525 |  |
| 2025 |  | 504 |  |
| Thereafter |  | 2,376 |  |
| Total |  | $ | 4,235 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-01-28):
[0001137789-21-000006:note_history:20]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of January 1, 2021:
  (was, 2020-10-29, similarity 0.9531):
[0001137789-20-000117:note_history:20]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of October 2, 2020:


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-01-28):
[0001137789-21-000006:note_history:21]
At January 1, 2021, future principal payments on long-term debt were as follows (in millions):
  (was, 2020-10-29, similarity 0.9326):
[0001137789-20-000117:note_history:21]
At October 2, 2020, future principal payments on long-term debt were as follows (in millions):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-01-28):
[0001137789-21-000006:note_history:22]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | January 1,2021 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 1,741 |  |  | $ | 1,843 |  |  | $ | 3,349 |  |  | $ | 3,663 |  |
| Distributors |  | 475 |  |  | 463 |  |  | 842 |  |  | 924 |  |
| Retailers |  | 407 |  |  | 390 |  |  | 746 |  |  | 687 |  |
| Total |  | $ | 2,623 |  |  | $ | 2,696 |  |  | $ | 4,937 |  |  | $ | 5,274 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,306 |  |  | $ | 1,377 |  |  | $ | 2,412 |  |  | $ | 2,655 |  |
| Americas |  | 838 |  |  | 761 |  |  | 1,643 |  |  | 1,596 |  |
| EMEA |  | 479 |  |  | 558 |  |  | 882 |  |  | 1,023 |  |
| Total |  | $ | 2,623 |  |  | $ | 2,696 |  |  | $ | 4,937 |  |  | $ | 5,274 |  |
  (was, 2020-10-29, similarity 0.6173):
[0001137789-20-000117:note_history:22]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | October 2,2020 |  | October 4,2019 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 1,608 |  |  | $ | 1,820 |  |  |  |  |  |
| Distributors |  | 367 |  |  | 461 |  |  |  |  |  |
| Retailers |  | 339 |  |  | 297 |  |  |  |  |  |
| Total |  | $ | 2,314 |  |  | $ | 2,578 |  |  |  |  |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,106 |  |  | $ | 1,278 |  |  |  |  |  |
| Americas |  | 805 |  |  | 835 |  |  |  |  |  |
| EMEA |  | 403 |  |  | 465 |  |  |  |  |  |
| Total |  | $ | 2,314 |  |  | $ | 2,578 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-01-28):
[0001137789-21-000006:note_history:23]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | January 1,2021 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 1,741 |  |  | $ | 1,843 |  |  | $ | 3,349 |  |  | $ | 3,663 |  |
| Distributors |  | 475 |  |  | 463 |  |  | 842 |  |  | 924 |  |
| Retailers |  | 407 |  |  | 390 |  |  | 746 |  |  | 687 |  |
| Total |  | $ | 2,623 |  |  | $ | 2,696 |  |  | $ | 4,937 |  |  | $ | 5,274 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,306 |  |  | $ | 1,377 |  |  | $ | 2,412 |  |  | $ | 2,655 |  |
| Americas |  | 838 |  |  | 761 |  |  | 1,643 |  |  | 1,596 |  |
| EMEA |  | 479 |  |  | 558 |  |  | 882 |  |  | 1,023 |  |
| Total |  | $ | 2,623 |  |  | $ | 2,696 |  |  | $ | 4,937 |  |  | $ | 5,274 |  |
  (was, 2020-10-29, similarity 0.6173):
[0001137789-20-000117:note_history:23]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | October 2,2020 |  | October 4,2019 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 1,608 |  |  | $ | 1,820 |  |  |  |  |  |
| Distributors |  | 367 |  |  | 461 |  |  |  |  |  |
| Retailers |  | 339 |  |  | 297 |  |  |  |  |  |
| Total |  | $ | 2,314 |  |  | $ | 2,578 |  |  |  |  |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,106 |  |  | $ | 1,278 |  |  |  |  |  |
| Americas |  | 805 |  |  | 835 |  |  |  |  |  |
| EMEA |  | 403 |  |  | 465 |  |  |  |  |  |
| Total |  | $ | 2,314 |  |  | $ | 2,578 |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2021-01-28):
[0001137789-21-000006:note_history:24]
On January 21, 2021, the Company’s Board of Directors declared a quarterly cash dividend of $0.67 per share, which will be payable on April 7, 2021 to shareholders of record as of the close of business on March 24, 2021.

- removed (2021-01-28):
[0001137789-20-000117:note_history:25]
On October 22, 2020, the Company’s Board of Directors declared a quarterly cash dividend of $0.67 per share, which will be payable on January 6, 2021 to shareholders of record as of the close of business on December 23, 2020.
