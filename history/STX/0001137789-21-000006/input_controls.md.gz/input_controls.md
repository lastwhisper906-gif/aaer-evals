# STX 10-Q controls and the auditor's report


## item_4_controls

[0001137789-21-000006:item_4_controls:1]
ITEM 4.CONTROLS AND PROCEDURES

[0001137789-21-000006:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001137789-21-000006:item_4_controls:3]
As required by the Exchange Act Rule 13a-15, we carried out an evaluation under the supervision and with the participation of our management, including our chief executive officer and chief financial officer, of the effectiveness of the design and operation of our disclosure controls and procedures as of the end of the period covered by this Quarterly Report. Based on the evaluation, our management, including our chief executive officer and chief financial officer, concluded that our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) are effective as of January 1, 2021.

[0001137789-21-000006:item_4_controls:4]
Changes in Internal Control over Financial Reporting

[0001137789-21-000006:item_4_controls:5]
During the quarter ended January 1, 2021, there were no changes in our internal control over financial reporting that have materially affected, or were reasonably likely to materially affect, our internal control over financial reporting.
