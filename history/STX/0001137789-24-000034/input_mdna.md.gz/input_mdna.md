# STX MD&A — 0001137789-24-000034


## mdna

[0001137789-24-000034:mdna:1]
[same as prior period, unchanged from 0001137789-24-000010:mdna:1]

[0001137789-24-000034:mdna:2]
The following is a discussion of the financial condition, changes in financial condition and results of operations for our fiscal quarters ended March 29, 2024, December 29, 2023 and March 31, 2023, referred to herein as the “March 2024 quarter”, the “December 2023 quarter” and the “March 2023 quarter”, respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The March 2024 quarter, December 2023 quarter and March 2023 quarter were each 13 weeks.

[0001137789-24-000034:mdna:3]
[same as prior period, unchanged from 0001137789-24-000010:mdna:3]

[0001137789-24-000034:mdna:4]
[same as prior period, unchanged from 0001137789-24-000010:mdna:4]

[0001137789-24-000034:mdna:5]
•Overview of the March 2024 quarter. Highlights of events in the March 2024 quarter that impacted our financial position.

[0001137789-24-000034:mdna:6]
•Results of Operations. Analysis of our financial results comparing the March 2024 quarter to the December 2023 quarter and the March 2023 quarter.

[0001137789-24-000034:mdna:7]
[same as prior period, unchanged from 0001137789-24-000010:mdna:7]

[0001137789-24-000034:mdna:8]
•Critical Accounting Estimates. Accounting policies and estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001137789-24-000034:mdna:9]
[same as prior period, unchanged from 0001137789-24-000010:mdna:9]

[0001137789-24-000034:mdna:10]
Overview of the March 2024 quarter

[0001137789-24-000034:mdna:11]
During the March 2024 quarter, we shipped 99 exabytes of HDD storage capacity. We generated revenue of approximately $1.7 billion with a gross margin of 26%. Our operating cash flow was $188 million and we paid $147 million in dividends.

[0001137789-24-000034:mdna:12]
[same as prior period, unchanged from 0001137789-24-000010:mdna:12]

[0001137789-24-000034:mdna:13]
During the March 2024 quarter, we experienced ongoing recovery within the cloud market, reflecting continued progress in customer inventory adjustments which we believe are now mostly complete, along with an improvement in end-market demand. We continued to execute cost discipline and implement pricing actions to improve operational efficiency and profitability. We believe that we are in the early stage of an industry-wide demand recovery, however we expect the macroeconomic environment to remain dynamic and continue to impact our business and results of operations.

[0001137789-24-000034:mdna:14]
As described in “Part I, Item 1. Financial Statements — Note 14. Subsequent Events”, on April 23, 2024, we sold certain intellectual property, equipment and other assets related to the design, development and manufacture of our System-on-Chip products to Avago Technologies International Sales Pte. Limited, a subsidiary of Broadcom Inc., for $600 million.

[0001137789-24-000034:mdna:15]
[same as prior period, unchanged from 0001137789-24-000010:mdna:14]

[0001137789-24-000034:mdna:16]
[same as prior period, unchanged from 0001137789-24-000010:mdna:15]

[0001137789-24-000034:mdna:17]
[same as prior period, unchanged from 0001137789-24-000010:mdna:16]

[0001137789-24-000034:mdna:18]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 29, 2024 |  | December 29, 2023 |  | March 31, 2023 |  | March 29,2024 |  | March 31,2023 |
| Revenue |  | $ | 1,655 |  |  | $ | 1,555 |  |  | $ | 1,860 |  |  | $ | 4,664 |  |  | $ | 5,782 |  |
| Cost of revenue |  | 1,230 |  |  | 1,193 |  |  | 1,541 |  |  | 3,728 |  |  | 4,735 |  |
| Gross profit |  | 425 |  |  | 362 |  |  | 319 |  |  | 936 |  |  | 1,047 |  |
| Product development |  | 164 |  |  | 161 |  |  | 191 |  |  | 496 |  |  | 625 |  |
| Marketing and administrative |  | 116 |  |  | 108 |  |  | 123 |  |  | 329 |  |  | 377 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |
| BIS settlement penalty |  | — |  |  | — |  |  | 300 |  |  | — |  |  | 300 |  |
| Restructuring and other, net |  | 2 |  |  | (31) |  |  | 20 |  |  | (27) |  |  | 110 |  |
| Income (loss) from operations |  | 143 |  |  | 124 |  |  | (315) |  |  | 138 |  |  | (368) |  |
| Other expense, net |  | (85) |  |  | (128) |  |  | (85) |  |  | (231) |  |  | (43) |  |
| Income (loss) before income taxes |  | 58 |  |  | (4) |  |  | (400) |  |  | (93) |  |  | (411) |  |
| Provision for income taxes |  | 33 |  |  | 15 |  |  | 33 |  |  | 85 |  |  | 26 |  |
| Net Income (loss) |  | $ | 25 |  |  | $ | (19) |  |  | $ | (433) |  |  | $ | (178) |  |  | $ | (437) |  |

[0001137789-24-000034:mdna:19]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
|  |  | March 29, 2024 |  | December 29, 2023 |  | March 31, 2023 |  | March 29,2024 |  | March 31,2023 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 74 |  |  | 77 |  |  | 83 |  |  | 80 |  |  | 82 |  |
| Gross margin |  | 26 |  |  | 23 |  |  | 17 |  |  | 20 |  |  | 18 |  |
| Product development |  | 10 |  |  | 10 |  |  | 10 |  |  | 11 |  |  | 11 |  |
| Marketing and administrative |  | 7 |  |  | 7 |  |  | 7 |  |  | 7 |  |  | 7 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| BIS settlement penalty |  | — |  |  | — |  |  | 16 |  |  | — |  |  | 5 |  |
| Restructuring and other, net |  | — |  |  | (2) |  |  | 1 |  |  | (1) |  |  | 1 |  |
| Operating margin |  | 9 |  |  | 8 |  |  | (17) |  |  | 3 |  |  | (6) |  |
| Other (expense) income, net |  | (5) |  |  | (8) |  |  | (4) |  |  | (5) |  |  | (1) |  |
| Loss before income taxes |  | 4 |  |  | — |  |  | (21) |  |  | (2) |  |  | (7) |  |
| Provision for income taxes |  | 2 |  |  | 1 |  |  | 2 |  |  | 2 |  |  | 1 |  |
| Net Income (loss) |  | 2 | % |  | (1 | %) |  | (23 | %) |  | (4 | %) |  | (8 | %) |

[0001137789-24-000034:mdna:20]
[same as prior period, unchanged from 0001137789-24-000010:mdna:20]

[0001137789-24-000034:mdna:21]
[same as prior period, unchanged from 0001137789-24-000010:mdna:21]

[0001137789-24-000034:mdna:22]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
|  |  | March 29, 2024 |  | December 29, 2023 |  | March 31, 2023 |  | March 29,2024 |  | March 31,2023 |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 75 | % |  | 73 | % |  | 73 | % |  | 73 | % |  | 74 | % |
| Distributors |  | 15 | % |  | 14 | % |  | 16 | % |  | 16 | % |  | 15 | % |
| Retailers |  | 10 | % |  | 13 | % |  | 11 | % |  | 11 | % |  | 11 | % |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 51 | % |  | 50 | % |  | 42 | % |  | 52 | % |  | 40 | % |
| Americas |  | 37 | % |  | 35 | % |  | 43 | % |  | 35 | % |  | 45 | % |
| EMEA |  | 12 | % |  | 15 | % |  | 15 | % |  | 13 | % |  | 15 | % |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 71 | % |  | 68 | % |  | 66 | % |  | 70 | % |  | 67 | % |
| Legacy |  | 18 | % |  | 21 | % |  | 20 | % |  | 19 | % |  | 20 | % |
| Other |  | 11 | % |  | 11 | % |  | 14 | % |  | 11 | % |  | 13 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 88 |  |  | 83 |  |  | 104 |  |  | 250 |  |  | 305 |  |
| Legacy |  | 11 |  |  | 12 |  |  | 15 |  |  | 34 |  |  | 45 |  |
| Total |  | 99 |  |  | 95 |  |  | 119 |  |  | 284 |  |  | 350 |  |
| HDD Price per Terabyte |  | $ | 15 |  |  | $ | 14 |  |  | $ | 14 |  |  | $ | 15 |  |  | $ | 14 |  |

[0001137789-24-000034:mdna:23]
| (1) Revenue is attributed to geography based on bill from locations. |

[0001137789-24-000034:mdna:24]
Revenue in the March 2024 quarter increased by $100 million compared to the December 2023 quarter, primarily due to an increase in mass capacity exabytes shipped, as we experienced ongoing recovery within the cloud market and favorable pricing actions undertaken by the Company, partially offset by seasonal decreases in legacy market exabytes shipped.

[0001137789-24-000034:mdna:25]
[same as prior period, unchanged from 0001137789-24-000010:mdna:30]

[0001137789-24-000034:mdna:26]
Revenue for the three and nine months ended March 29, 2024 decreased by $205 million and $1.1 billion from the three and nine months ended March 31, 2023, respectively, primarily due to a decrease in exabytes shipped due to lower broad-based market demand, slightly offset by an increase in revenue as a result of favorable pricing actions.

[0001137789-24-000034:mdna:27]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 15% of gross revenue for the March 2024 quarter, 18% for the December 2023 quarter and 16% for the March 2023 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-24-000034:mdna:28]
[same as prior period, unchanged from 0001137789-24-000010:mdna:28]

[0001137789-24-000034:mdna:29]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 29, 2024 |  | December 29, 2023 |  | March 31, 2023 |  | March 29,2024 |  | March 31,2023 |
| Cost of revenue |  | $ | 1,230 |  |  | $ | 1,193 |  |  | $ | 1,541 |  |  | $ | 3,728 |  |  | $ | 4,735 |  |
| Gross profit |  | 425 |  |  | 362 |  |  | 319 |  |  | 936 |  |  | 1,047 |  |
| Gross margin |  | 26 | % |  | 23 | % |  | 17 | % |  | 20 | % |  | 18 | % |

[0001137789-24-000034:mdna:30]
Gross margin for the March 2024 quarter increased compared to the December 2023 quarter, primarily driven by favorable pricing actions undertaken by the Company and, to a lesser extent, favorable product mix, partially offset by a $7 million increase in factory underutilization charges due to the transition of some production lines to new products.

[0001137789-24-000034:mdna:31]
Gross margin for the March 2024 quarter increased compared to the March 2023 quarter, primarily driven by favorable pricing actions undertaken by the Company, a $30 million decrease in depreciation expense due to the extension of useful lives of certain manufacturing equipment, which was partially reflected in the reduction in factory underutilization charges, and $18 million of accelerated depreciation expense for certain capital equipment in March 2023 quarter that did not recur.

[0001137789-24-000034:mdna:32]
Gross margin for the nine months ended March 29, 2024 increased compared to the nine months ended March 31, 2023 primarily driven by favorable pricing actions undertaken by the Company, a $72 million reduction in factory underutilization charges which included the decrease in depreciation expense due to the extension of useful lives of certain manufacturing equipment, a decrease of $44 million in accelerated depreciation expense for certain capital equipment, and pandemic-related lockdown in one of our factories in fiscal year 2023 that did not recur, partially offset by an increase of $5 million in order cancellation fees and less favorable product mix.

[0001137789-24-000034:mdna:33]
In the March 2024 quarter, total warranty cost was 0.5% of revenue and included a favorable change in estimates of prior warranty accruals of 0.2% of revenue primarily due to decreases to our estimated future product return rates. Warranty cost related to new shipments was 0.8%, 0.9% and 0.8% of revenue for the March 2024 quarter, December 2023 quarter and March 2023 quarter, respectively.

[0001137789-24-000034:mdna:34]
[same as prior period, unchanged from 0001137789-24-000010:mdna:35]

[0001137789-24-000034:mdna:35]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 29, 2024 |  | December 29, 2023 |  | March 31, 2023 |  | March 29,2024 |  | March 31,2023 |
| Product development |  | 164 |  |  | $ | 161 |  |  | $ | 191 |  |  | $ | 496 |  |  | $ | 625 |  |
| Marketing and administrative |  | 116 |  |  | 108 |  |  | 123 |  |  | 329 |  |  | 377 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |
| BIS settlement penalty |  | — |  |  | — |  |  | 300 |  |  | — |  |  | 300 |  |
| Restructuring and other, net |  | 2 |  |  | (31) |  |  | 20 |  |  | (27) |  |  | 110 |  |
| Operating expenses |  | $ | 282 |  |  | $ | 238 |  |  | $ | 634 |  |  | $ | 798 |  |  | $ | 1,415 |  |

[0001137789-24-000034:mdna:36]
Product development expense. Product development expenses increased by $3 million in the March 2024 quarter compared to the December 2023 quarter, primarily due to a $6 million increase in compensation and other employee benefits as a result of completion of temporary salary reductions and a $2 million increase in lease expense as we sold and leased back certain properties, partially offset by a $5 million decrease in materials expense.

[0001137789-24-000034:mdna:37]
Product development expenses decreased by $27 million in the March 2024 quarter compared to the March 2023 quarter, primarily due to a $23 million decrease in compensation and other employee benefits as a result of workforce reductions, a $9 million decrease in depreciation expense, and a $2 million decrease in materials expense, partially offset by a $7 million increase in lease expense as we sold and leased back certain properties.

[0001137789-24-000034:mdna:38]
Product development expenses decreased by $129 million for the nine months ended March 29, 2024 compared to the nine months ended March 31, 2023, primarily due to a $98 million decrease in compensation and other employee benefits as a result of workforce and temporary salary reductions, a $46 million decrease in depreciation expense and a $4 million decrease in materials expense, partially offset by a $19 million increase in lease expense as we sold and leased back certain properties.

[0001137789-24-000034:mdna:39]
Marketing and administrative expense. Marketing and administrative expenses increased by $8 million in the March 2024 quarter compared to the December 2023 quarter primarily due to a $5 million increase in compensation and other employee benefits due to the completion of the temporary salary reduction and a $3 million increase in legal costs.

[0001137789-24-000034:mdna:40]
Marketing and administrative expenses decreased by $7 million in the March 2024 quarter compared to the March 2023 quarter primarily due to a $5 million decrease in compensation and other employee benefits as a result of workforce reductions, a $3 million decrease in advertising costs, a $2 million decrease in travel expenses and a $2 million decrease in outside services expense, partially offset by a $5 million increase in legal cost.

[0001137789-24-000034:mdna:41]
Marketing and administrative expenses decreased by $48 million for the nine months ended March 29, 2024 compared to the nine months ended March 31, 2023 primarily due to a $31 million decrease in compensation and other employee benefits as a result of workforce and temporary salary reductions, a $12 million decrease in advertising costs, a $6 million decrease in travel expenses, a $6 million decrease in outside services expense and a $2 million increase in tax credit, partially offset by a $7 million recovery in the December 2022 quarter of an accounts receivable previously written off in prior years and a $2 million increase in depreciation expenses.

[0001137789-24-000034:mdna:42]
BIS Settlement Penalty. BIS settlement penalty for the three and nine months ended March 31, 2023 was $300 million related to BIS allegations of violations of the U.S. EAR, which were subsequently resolved by the Settlement Agreement in April 2023.

[0001137789-24-000034:mdna:43]
Restructuring and other, net. Restructuring and other, net for the March 2024 quarter was $2 million. For the nine months ended March 29, 2024, we recorded a benefit of $27 million primarily related to the net gain of $30 million from the sale and leaseback transaction during the December 2023 quarter.

[0001137789-24-000034:mdna:44]
[same as prior period, unchanged from 0001137789-24-000010:mdna:44]

[0001137789-24-000034:mdna:45]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 29, 2024 |  | December 29, 2023 |  | March 31, 2023 |  | March 29, 2024 |  | March 31, 2023 |
| Other Expense, net |  | $ | (85) |  |  | $ | (128) |  |  | $ | (85) |  |  | $ | (231) |  |  | $ | (43) |  |

[0001137789-24-000034:mdna:46]
Other expense, net. Other expense decreased by $43 million for the March 2024 quarter compared to the December 2023 quarter primarily due to $43 million of net loss from equity investments in the December 2023 quarter that did not recur.

[0001137789-24-000034:mdna:47]
Other expense increased by $188 million for the nine months ended March 29, 2024 compared to the nine months ended March 31, 2023 primarily due to $207 million of net gain recognized from the early redemption of debt in the nine months ended March 31, 2023, a $43 million net loss from equity investments, a $29 million net loss recognized from early redemption of debt and a $17 million net increase in interest expense in the nine months ended March 29, 2024. The increase is partially offset by $104 million of net gain recognized from the termination of interest rate swaps associated with the repayment of term loans in the nine months ended March 29, 2024.

[0001137789-24-000034:mdna:48]
[same as prior period, unchanged from 0001137789-24-000010:mdna:49]

[0001137789-24-000034:mdna:49]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 29, 2024 |  | December 29, 2023 |  | March 31, 2023 |  | March 29,2024 |  | March 31,2023 |
| Provision for income taxes |  | $ | 33 |  |  | $ | 15 |  |  | $ | 33 |  |  | $ | 85 |  |  | $ | 26 |  |

[0001137789-24-000034:mdna:50]
[same as prior period, unchanged from 0001137789-24-000010:mdna:54]

[0001137789-24-000034:mdna:51]
We recorded income tax provisions of $33 million and $85 million for the three and nine months ended March 29, 2024, respectively. The discrete items in the income tax provision were not material for the three months ended March 29, 2024. The income tax provision for the nine months ended March 29, 2024 included approximately $42 million of net discrete expense, primarily associated with an increase in our valuation allowance to account for the impacts of new tax guidance which clarifies the treatment of specified research and experimental expenditures issued by the U.S. Treasury Department under Internal Revenue Code Section 174 during the September 2023 quarter, partially offset by net excess tax benefits related to share-based compensation expense. Additional guidance issued by the U.S. Treasury Department in December 2023 did not result in any impacts. We will have income taxes payable based on profits generated in various jurisdictions.

[0001137789-24-000034:mdna:52]
During the nine months ended March 29, 2024, our unrecognized tax benefits, excluding interest and penalties decreased by approximately $6 million to $110 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. We do not expect material changes to our unrecognized tax benefits in the next twelve months beginning March 30, 2024.

[0001137789-24-000034:mdna:53]
We recorded income tax provisions of $33 million and $26 million for the three and nine months ended March 31, 2023, respectively. The discrete items in the income tax provisions were not material for the three and nine months ended March 31, 2023.

[0001137789-24-000034:mdna:54]
During the third quarter of fiscal year 2024, we established Singapore as our principal executive offices. Our income tax provisions recorded for the three and nine months ended March 29, 2024 differed from the provisions for income taxes that would be derived by applying the Singaporean statutory rate of 17% to income before income taxes, primarily due to the net effect of (i) earnings generated in jurisdictions that are subject to tax incentive programs, (ii) non-Singaporean earnings taxed at different rates, and (iii) changes in valuation allowance.

[0001137789-24-000034:mdna:55]
Our income tax provisions recorded for the three and nine months ended March 31, 2023 differed from the provisions for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-24-000034:mdna:56]
[same as prior period, unchanged from 0001137789-24-000010:mdna:56]

[0001137789-24-000034:mdna:57]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash will continue to be sufficient to fund our operations and meet our cash requirements for the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs and capital expenditures, will allow us to manage the ongoing impacts of macroeconomic headwinds including higher inflationary pressures, inventory adjustments by our customers and the overall market demand disruptions on our business operations for the foreseeable future. However, some challenges to our industry and to our business continue to remain uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to the global economic factors.

[0001137789-24-000034:mdna:58]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of March 29, 2024. For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, see “Part II, Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q.

[0001137789-24-000034:mdna:59]
[same as prior period, unchanged from 0001137789-24-000010:mdna:59]

[0001137789-24-000034:mdna:60]
| (Dollars in millions) |  | March 29, 2024 |  | June 30, 2023 |  | Change |
| Cash and cash equivalents |  | $ | 795 |  |  | $ | 786 |  |  | $ | 9 |  |

[0001137789-24-000034:mdna:61]
Our cash and cash equivalents as of March 29, 2024 increased by $9 million from June 30, 2023 primarily as a result of net cash of $484 million provided by operating activities and net proceeds of $1.5 billion from the issuance of exchangeable senior notes, partially offset by $1.3 billion redemption of term loans, $438 million dividends paid to our shareholders, $128 million debt fees relating to issuance of long-term exchangeable debt and capped call transaction and $200 million payments for capital expenditures.

[0001137789-24-000034:mdna:62]
34

[0001137789-24-000034:mdna:63]
[same as prior period, unchanged from 0001137789-24-000010:mdna:62]

[0001137789-24-000034:mdna:64]
Cash provided by operating activities for the nine months ended March 29, 2024 was $484 million and includes the effects of net loss adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-24-000034:mdna:65]
•a decrease of $289 million in accounts receivable, primarily due to lower revenue and higher accounts receivable factoring;

[0001137789-24-000034:mdna:66]
•an increase of $108 million in accounts payable, primarily due to timing of payments; and

[0001137789-24-000034:mdna:67]
[same as prior period, unchanged from 0001137789-24-000010:mdna:67]

[0001137789-24-000034:mdna:68]
•an increase of $51 million in inventories, net, primarily due to an increase in raw materials;

[0001137789-24-000034:mdna:69]
•a decrease of $50 million in accrued expenses primarily due to restructuring activities and BIS settlement penalty payment; and

[0001137789-24-000034:mdna:70]
•a decrease of $25 million in accrued employee compensation, primarily due to timing of payments.

[0001137789-24-000034:mdna:71]
[same as prior period, unchanged from 0001137789-24-000010:mdna:70]

[0001137789-24-000034:mdna:72]
Net cash used in investing activities for the nine months ended March 29, 2024 was $157 million, primarily attributable to payments of $200 million for the purchase of property, equipment and leasehold improvements, partially offset by proceeds of $38 million from the sale of assets which primarily included $34 million from the sale and leaseback transaction during the December 2023 quarter, as well as proceeds of $5 million from the sale of investments in the March 2024 quarter.

[0001137789-24-000034:mdna:73]
[same as prior period, unchanged from 0001137789-24-000010:mdna:72]

[0001137789-24-000034:mdna:74]
Net cash used in financing activities of $319 million for the nine months ended March 29, 2024 was primarily attributable to the following activities:

[0001137789-24-000034:mdna:75]
[same as prior period, unchanged from 0001137789-24-000010:mdna:74]

[0001137789-24-000034:mdna:76]
•$438 million in dividend payments;

[0001137789-24-000034:mdna:77]
[same as prior period, unchanged from 0001137789-24-000010:mdna:76]

[0001137789-24-000034:mdna:78]
•$31 million taxes paid related to net share settlement of equity awards; partially offset by

[0001137789-24-000034:mdna:79]
[same as prior period, unchanged from 0001137789-24-000010:mdna:78]

[0001137789-24-000034:mdna:80]
•$66 million proceeds from the issuance of ordinary shares under employee stock purchase plans.

[0001137789-24-000034:mdna:81]
[same as prior period, unchanged from 0001137789-24-000010:mdna:80]

[0001137789-24-000034:mdna:82]
Our primary sources of liquidity as of March 29, 2024 consist of: (1) approximately $795 million in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.5 billion available for borrowing under the revolving credit facility of the Credit Agreement (the “Revolving Credit Facility”).

[0001137789-24-000034:mdna:83]
As of March 29, 2024, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-24-000034:mdna:84]
As of March 29, 2024, the existing Credit Agreement includes two financial covenants: (1) interest coverage ratio and (2) total net leverage ratio. The interest coverage ratio and total net leverage ratio covenants did not apply for the fiscal quarter ended March 29, 2024. Refer to “Part I, Item 1. Financial Statements—Note 3. Debt” for details of the financial covenants which will apply for the fiscal quarter ending June 28, 2024 and thereafter.

[0001137789-24-000034:mdna:85]
In addition, as described in “Part I, Item 1. Financial Statements—Note 14. Subsequent Events”, on April 23, 2024, we sold certain intellectual property, equipment and other assets related to the design, development and manufacture of our SoC products for $600 million.

[0001137789-24-000034:mdna:86]
We believe that our sources of cash will be sufficient to fund our operations and meet our cash requirements for at least the next 12 months. Our ability to fund liquidity requirements beyond 12 months will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001137789-24-000034:mdna:87]
For information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, see “Part II, Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q.

[0001137789-24-000034:mdna:88]
[same as prior period, unchanged from 0001137789-24-000010:mdna:90]

[0001137789-24-000034:mdna:89]
[same as prior period, unchanged from 0001137789-24-000010:mdna:85]

[0001137789-24-000034:mdna:90]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness and to fund our quarterly dividend and any future strategic investments. As of March 29, 2024, our contractual cash requirements have not changed materially since our Annual Report on Form 10-K for the fiscal year ended June 30, 2023, except for the purchase obligations and long-term debt obligations.

[0001137789-24-000034:mdna:91]
[same as prior period, unchanged from 0001137789-24-000010:mdna:87]

[0001137789-24-000034:mdna:92]
Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. From time to time, we enter into long-term, non-cancelable purchase commitments or make large up-front investments with certain suppliers in order to secure certain components or technologies for the production of our products or to supplement our internal manufacturing capacity for certain components. As of March 29, 2024, we had unconditional purchase obligations of approximately $3.4 billion primarily related to purchases of inventory components with our suppliers. We expect $926 million of these short-term commitments to be paid within one year and expect $2.5 billion of these long-term commitments to be paid thereafter.

[0001137789-24-000034:mdna:93]
We recorded order cancellation fees to terminate certain purchase commitments related to the purchase of inventory components and equipment. As of March 29, 2024, cumulative unpaid order cancellation fees on the Condensed Consolidated Balance Sheets were $134 million, with $121 million in Accrued expenses and $13 million in Accounts payable, all of which is expected to be paid within one year In certain instances, our unpaid order cancellation fees may change based on the expected timing or ongoing negotiations with our suppliers.

[0001137789-24-000034:mdna:94]
[same as prior period, unchanged from 0001137789-24-000010:mdna:91]

[0001137789-24-000034:mdna:95]
On September 13, 2023, we issued the 2028 Notes of $1.5 billion and repaid Term Loans A1, A2 and A3 of $1.3 billion.

[0001137789-24-000034:mdna:96]
As of March 29, 2024, the future principal payment obligation on our long-term debt was $5.7 billion, of which $479 million will mature within one year. As of March 29, 2024, future interest payments on this outstanding debt are estimated to be approximately $2.1 billion, of which $323 million is expected to be paid within one year. From time to time, we may repurchase any of our outstanding senior notes in open market or privately negotiated purchases or we may repurchase outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 1. Financial Statements—Note 3. Debt” for more details.

[0001137789-24-000034:mdna:97]
[same as prior period, unchanged from 0001137789-24-000010:mdna:94]

[0001137789-24-000034:mdna:98]
We accrued a settlement penalty of $300 million in the quarter ended March 31, 2023, related to BIS’ allegations of violations of the U.S. EAR, which were subsequently resolved by the Settlement Agreement in April 2023. As part of the Settlement Agreement with BIS, quarterly payments of $15 million are made over the course of five years beginning October 31, 2023, of which $60 million is expected to be paid within one year and $210 million thereafter. Refer to “Item 1. Financial Statements—Note 12. Legal, Environmental and Other Contingencies” for more details.

[0001137789-24-000034:mdna:99]
[same as prior period, unchanged from 0001137789-24-000010:mdna:96]

[0001137789-24-000034:mdna:100]
During the nine months ended March 29, 2024, we made cash payments of $115 million related to the workforce reduction costs under the restructuring plans.

[0001137789-24-000034:mdna:101]
As of March 29, 2024, the future cash payments related to our remaining active restructuring plans were $7 million, which is expected to be paid within one year.

[0001137789-24-000034:mdna:102]
[same as prior period, unchanged from 0001137789-24-000010:mdna:99]

[0001137789-24-000034:mdna:103]
During the March 2024 quarter, we declared dividends of $0.70 per share, totaling $147 million, which was paid on April 4, 2024. On April 23, 2024, we declared a quarterly cash dividend of $0.70 per share, payable on July 5, 2024 to shareholders of record at the close of business on June 20, 2024. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-24-000034:mdna:104]
[same as prior period, unchanged from 0001137789-24-000010:mdna:101]

[0001137789-24-000034:mdna:105]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker-assisted purchases, tender offers, or other means, including through the use of derivative transactions. As of March 29, 2024, $1.9 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-24-000034:mdna:106]
[same as prior period, unchanged from 0001137789-24-000010:mdna:103]

[0001137789-24-000034:mdna:107]
[same as prior period, unchanged from 0001137789-24-000010:mdna:104]

[0001137789-24-000034:mdna:108]
Critical Accounting Estimates

[0001137789-24-000034:mdna:109]
Our discussion and analysis of financial condition and results of operations are based upon our Condensed Consolidated Financial Statements, which have been prepared in accordance with U.S. GAAP. The preparation of such statements requires us to make estimates and assumptions that affect the reported amounts of revenues and expenses during the reporting period and the reported amounts of assets and liabilities as of the date of the financial statements. Our estimates are based on historical experience and other assumptions that we consider to be appropriate in the circumstances. However, actual future results may vary from our estimates.

[0001137789-24-000034:mdna:110]
[same as prior period, unchanged from 0001137789-24-000010:mdna:107]

[0001137789-24-000034:mdna:111]
[same as prior period, unchanged from 0001137789-24-000010:mdna:108]

[0001137789-24-000034:mdna:112]
[same as prior period, unchanged from 0001137789-24-000010:mdna:109]
