# STX note change history — 0001137789-24-000010 → 0001137789-24-000034


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-04-26):
[0001137789-24-000034:note_history:1]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the U.S. District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendant misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies and additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 8, 2022, the court entered an Amended Stipulation and Order of Dismissal with Prejudice to dismiss all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment under the Foreign Trade Antitrust Improvement Act (“FTAIA Motion”) against Seagate’s antitrust claims, and on October 14, 2022, the Seagate Entities filed their corresponding opposition. On May 15, 2023, the Court issued a ruling that Seagate’s antitrust claims can proceed as to suspension assemblies that enter the United States but not as to suspension assembles that do not enter the United States. On July 28, 2023, the District Court initiated a reconsideration of this ruling and requested further briefing. On November 17, 2023, the Court granted NHK’s FTAIA Motion and denied Seagate’s Motion for Leave to Amend the Complaint. Seagate plans to appeal the Court’s ruling on NHK’s FTAIA Motion to the Ninth Circuit and filed a motion on December 15, 2023 for the Court to certify the ruling for interlocutory appeal. On April 22, 2024, the District Court granted in part and denied in part Seagate’s motion to certify for interlocutory appeal the Court’s ruling on NHK’s FTAIA Motion.
  (was, 2024-01-26, similarity 0.6831):
[0001137789-24-000010:note_history:1]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the U.S. District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendant misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies and additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 8, 2022, the court entered an Amended Stipulation and Order of Dismissal with Prejudice to dismiss all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment Regarding Foreign Commerce and on October 14, 2022, the Seagate Entities filed their corresponding opposition. On May 15, 2023, the court issued a ruling that Seagate’s antitrust claims can proceed as to suspension assemblies that enter the United States but not as to suspension assembles that do not enter the United States. On July 28, 2023, the judge initiated a reconsideration of this ruling and requested further briefing. On November 17, 2023, the Court granted NHK’s Motion for Partial Summary Judgment regarding the Foreign Trade Antitrust Improvements Act (“FTAIA”) and denied Seagate’s Motion for Leave to Amend the Complaint. Seagate plans to appeal the Court’s ruling and filed a motion on December 15, 2023 for the Court to certify interlocutory review of its ruling. A trial date has not been set.

- changed (2024-04-26):
[0001137789-24-000034:note_history:2]
In re Seagate Technology Holdings plc Securities Litigation. A putative class action lawsuit alleging violations of the federal securities laws, UA Local 38 Defined Contribution Pension Plan, et al. v. Seagate Technology Holdings PLC, et al., was filed on July 10, 2023, in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The complaint alleged that it was a securities class action on behalf of all purchasers of Seagate common stock between September 15, 2020 and October 25, 2022, inclusive, and asserted claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b5-1. The complaint sought unspecified monetary damages and other relief. A second action, Public Employees’ Retirement System of Mississippi v. Seagate Technology Holdings plc, William David Mosley, and Gianluca Romano, was filed on July 26, 2023, asserting similar claims. The cases were consolidated on September 25, 2023. On October 19, 2023, plaintiffs filed an amended complaint asserting similar claims with a putative class period of September 14, 2020 through April 19, 2023. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint, which is currently pending before the court. A hearing regarding Seagate’s motion to dismiss occurred on March 26, 2024. The Company believes that the asserted claims are without merit and intends to vigorously defend the case.
  (was, 2024-01-26, similarity 0.9751):
[0001137789-24-000010:note_history:2]
In re Seagate Technology Holdings plc Securities Litigation. A putative class action lawsuit alleging violations of the federal securities laws, UA Local 38 Defined Contribution Pension Plan, et al. v. Seagate Technology Holdings PLC, et al., was filed on July 10, 2023, in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The complaint alleged that it was a securities class action on behalf of all purchasers of Seagate common stock between September 15, 2020 and October 25, 2022, inclusive, and asserted claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b5-1. The complaint sought unspecified monetary damages and other relief. A second action, Public Employees’ Retirement System of Mississippi v. Seagate Technology Holdings plc, William David Mosley, and Gianluca Romano, was filed on July 26, 2023, asserting similar claims. The cases were consolidated on September 25, 2023.  On October 19, 2023, plaintiffs filed an amended complaint asserting similar claims with a putative class period of September 14, 2020 through April 19, 2023. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint, which is currently pending before the court. The Company believes that the asserted claims are without merit and intends to vigorously defend the case.

- added (2024-04-26):
[0001137789-24-000034:note_history:3]
Godo Kaisha IP Bridge 1 v. Seagate Technology LLC, Seagate Technology (US) Holding, Inc., Seagate Technology (Thailand) Limited, Seagate Singapore International Headquarters Ltd., Seagate Technology (Netherlands) B.V. On March 15, 2024, a patent infringement action was filed by Godo Kaisha IP Bridge 1 (“IP Bridge”) against Seagate in United States District Court for the District of Delaware. The complaint alleges patent infringement by Seagate of US Patent Nos. 7,884,403 (entitled, “Magnetic tunnel junction device and memory device including the same”), 8,319,263 (entitled, “Magnetic tunnel junction device”), and 11,737,372 (entitled, “Method of manufacturing a magnetoresistive random access memory (MRAM)”). IP Bridge is seeking damages as well as additional relief. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

- changed (2024-04-26):
[0001137789-24-000034:note_history:4]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $210 million were included in Accrued expense and Other non-current liabilities, respectively, on its Condensed Consolidated Balance Sheets as of March 29, 2024. For the nine months ended March 29, 2024, $30 million was paid and reported as an outflow from operating activities on its Condensed Consolidated Statements of Cash Flows.
  (was, 2024-01-26, similarity 0.8914):
[0001137789-24-000010:note_history:4]
The Company accrued a charge of $300 million during fiscal year 2023, of which  $60 million and $225 million were included in Accrued expense and Other non-current liabilities, respectively, on its Condensed Consolidated Balance Sheets as of December 29, 2023. During the December 2023 quarter, $15 million was paid and reported as an outflow from operating activities on its Condensed Consolidated Statements of Cash Flows.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-04-26):
[0001137789-24-000034:note_history:5]
The Company’s Consolidated Financial Statements for the fiscal year ended June 30, 2023 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 4, 2023. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 30, 2023, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and nine months ended March 29, 2024 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 28, 2024.
  (was, 2024-01-26, similarity 0.9662):
[0001137789-24-000010:note_history:5]
The Company’s Consolidated Financial Statements for the fiscal year ended June 30, 2023 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 4, 2023. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 30, 2023, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and six months ended December 29, 2023 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 28, 2024.

- changed (2024-04-26):
[0001137789-24-000034:note_history:6]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and nine months ended March 29, 2024 and March 31, 2023 consisted of 13 and 39 weeks, respectively. Fiscal years 2024 and 2023 both comprise 52 weeks and end on June 28, 2024 and June 30, 2023, respectively. The fiscal quarters ended March 29, 2024, December 29, 2023 and March 31, 2023, are also referred to herein as the “March 2024 quarter”, the “December 2023 quarter” and the “March 2023 quarter”, respectively.
  (was, 2024-01-26, similarity 0.8542):
[0001137789-24-000010:note_history:6]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and six months ended December 29, 2023 and December 30, 2022 consisted of 13 and 26 weeks, respectively. Fiscal years 2024 and 2023 both comprise 52 weeks and end on June 28, 2024 and June 30, 2023, respectively. The fiscal quarters ended December 29, 2023, September 29, 2023 and December 30, 2022, are also referred to herein as the “December 2023 quarter”, the “September 2023 quarter” and the “December 2022 quarter”, respectively.

- changed (2024-04-26):
[0001137789-24-000034:note_history:7]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. Effective from the first quarter of fiscal year 2024, the Company changed the useful lives of certain manufacturing equipment from a range of three to seven years to a range of three to ten years based on its review of technology product roadmap. The effect of this change in estimate increased the net income by approximately $30 million and $70 million for three and nine months ended March 29, 2024, respectively. Earnings per share for the three months ended March 29, 2024 increased by $0.14 and loss per share for the nine months ended March 29, 2024 decreased by $0.33.
  (was, 2024-01-26, similarity 0.8081):
[0001137789-24-000010:note_history:7]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. Effective from the first quarter of fiscal year 2024, the Company changed the useful lives of certain manufacturing equipment from a range of three to seven years to a range of three to ten years based on its review of technology product roadmap. The effect of this change in estimate increased the net income by approximately $30 million and $40 million for three and six months ended December 29, 2023, respectively. Loss per share decreased by $0.14 and $0.19 for three and six months ended December 29, 2023, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-04-26):
[0001137789-24-000034:note_history:8]
Debt
The following table provides details of the Company’s debt as of March 29, 2024 and June 30, 2023:
  (was, 2024-01-26, similarity 0.9524):
[0001137789-24-000010:note_history:8]
Debt
The following table provides details of the Company’s debt as of December 29, 2023 and June 30, 2023:

- changed (2024-04-26):
[0001137789-24-000034:note_history:9]
| (Dollars in millions) |  | March 29, 2024 |  | June 30, 2023 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | $ | 479 |  |  | $ | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 469 |  |  | 465 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | — |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | — |  |  | 430 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
|  |  | 5,702 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (31) |  |  | (36) |  |
| Debt, net of debt issuance costs |  | 5,671 |  |  | 5,451 |  |
| Less: current portion of long-term debt |  | (479) |  |  | (63) |  |
| Long-term debt, less current portion |  | $ | 5,192 |  |  | $ | 5,388 |  |
  (was, 2024-01-26, similarity 0.997):
[0001137789-24-000010:note_history:9]
| (Dollars in millions) |  | December 29, 2023 |  | June 30, 2023 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | $ | 479 |  |  | $ | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 469 |  |  | 465 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | — |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | — |  |  | 430 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
|  |  | 5,701 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (32) |  |  | (36) |  |
| Debt, net of debt issuance costs |  | 5,669 |  |  | 5,451 |  |
| Less: current portion of long-term debt |  | — |  |  | (63) |  |
| Long-term debt, less current portion |  | $ | 5,669 |  |  | $ | 5,388 |  |

- changed (2024-04-26):
[0001137789-24-000034:note_history:10]
| (1) All unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX. |
  (was, 2024-01-26, similarity 0.9928):
[0001137789-24-000010:note_history:10]
(1) All unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX.

- changed (2024-04-26):
[0001137789-24-000034:note_history:11]
The entire outstanding principal amount of Term Loans A1, A2 and A3 were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in the Net gain (loss) recognized from early redemption of debt in the Company’s Condensed Consolidated Statements of Operations for the nine months ended March 29, 2024. In connection with the repayment of Term Loans, the Company terminated its interest rate swap agreements. Refer to “Note 6. Derivative Financial Instruments” for more details.
  (was, 2024-01-26, similarity 0.9461):
[0001137789-24-000010:note_history:11]
The entire outstanding principal amount of Term Loans A1, A2 and A3 were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in the Net loss recognized from early redemption of debt in the Company’s Condensed Consolidated Statements of Operations for the six months ended December 29, 2023. In connection with the repayment of Term Loans, the Company terminated its interest rate swap agreements. Refer to “Note 6. Derivative Financial Instruments” for more details.

- added (2024-04-26):
[0001137789-24-000034:note_history:12]
As of March 29, 2024, the 2028 Notes were not exchangeable and the aggregate if-converted value of the 2028 Notes exceeded their aggregate principal amount by approximately $100 million. Refer to “Note 11. Net Income (Loss) Per Share” for the potential dilutive impact of the 2028 Notes.

- changed (2024-04-26):
[0001137789-24-000034:note_history:13]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The cap price of the capped call transactions will initially be $107.848 per share. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets.
  (was, 2024-01-26, similarity 0.7854):
[0001137789-24-000010:note_history:13]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The cap price of the capped call transactions will initially be $107.848 per share, which represents a premium of approximately 70% over the last reported sale price of the ordinary shares of $63.44 per share on the Nasdaq Global Market on September 7, 2023. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets.

- changed (2024-04-26):
[0001137789-24-000034:note_history:14]
The credit agreement dated as of February 20, 2019, by and among, Seagate Technology Holdings plc, Seagate HDD, The Bank of Nova Scotia, as administrative agent, and the lenders party thereto (as amended from time to time, the “Credit Agreement”) includes two financial covenants: (1) interest coverage ratio and (2) total net leverage ratio. The maximum permitted total net leverage ratio did not apply for the fiscal quarter ended March 29, 2024. For the fiscal quarters ending June 28, 2024 until the end of the covenant relief period, which terminates on June 27, 2025, the maximum permitted total net leverage ratio is 6.75 to 1.00, and applies only to the extent that the aggregate outstanding amount of revolving loans, swing line loans and the aggregate face amount of certain letters of credit exceeds 25% of the then outstanding revolving commitments in effect (the “Testing Condition”) as of the last day of the fiscal quarter. The maximum permitted total leverage ratio for each fiscal quarter ending after June 27, 2025 is 4.00 to 1.00.
  (was, 2024-01-26, similarity 0.9701):
[0001137789-24-000010:note_history:14]
The credit agreement dated as of February 20, 2019, by and among, Seagate Technology Holdings plc, Seagate HDD, The Bank of Nova Scotia, as administrative agent, and the lenders party thereto (as amended from time to time, the “Credit Agreement”) includes two financial covenants: (1) interest coverage ratio and (2) total net leverage ratio. The maximum permitted total net leverage ratio did not apply for the fiscal quarter ended December 29, 2023 and will not apply for the fiscal quarter ending March 29, 2024. For the fiscal quarters ending June 28, 2024 until the end of the covenant relief period, which terminates on June 27, 2025, the maximum permitted total net leverage ratio is 6.75 to 1.00, and applies only to the extent that the aggregate outstanding amount of revolving loans, swing line loans and the aggregate face amount of certain letters of credit exceeds 25% of the then outstanding revolving commitments in effect (the “Testing Condition”) as of the last day of the fiscal quarter. The maximum permitted total leverage ratio for each fiscal quarter ending after June 27, 2025 is 4.00 to 1.00.

- changed (2024-04-26):
[0001137789-24-000034:note_history:15]
The minimum interest coverage ratio did not apply for the fiscal quarter ended March 29, 2024. For the fiscal quarters ending June 28, 2024 until June 27, 2025, the minimum interest coverage ratio is 2.25 to 1.00, and applies only to the extent that the Testing Condition is satisfied as of the last day of the fiscal quarter. The minimum interest coverage ratio is 3.25 to 1.00 for each fiscal quarter ending after June 27, 2025.
  (was, 2024-01-26, similarity 0.9059):
[0001137789-24-000010:note_history:15]
The minimum interest coverage ratio did not apply for the fiscal quarter ended December 29, 2023 and will not apply for the fiscal quarter ending March 29, 2024. For the fiscal quarters ending June 28, 2024 until June 27, 2025, the minimum interest coverage ratio is 2.25 to 1.00, and applies only to the extent that the Testing Condition is satisfied as of the last day of the fiscal quarter. The minimum interest coverage ratio is 3.25 to 1.00 for each fiscal quarter ending after June 27, 2025.

- changed (2024-04-26):
[0001137789-24-000034:note_history:16]
At March 29, 2024, future principal payments on long-term debt were as follows (in millions):
  (was, 2024-01-26, similarity 0.9492):
[0001137789-24-000010:note_history:16]
At December 29, 2023, future principal payments on long-term debt were as follows (in millions):

- removed (2024-04-26):
[0001137789-24-000010:note_history:17]
_____________________________


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-04-26):
[0001137789-24-000034:note_history:18]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of March 29, 2024 and June 30, 2023:
  (was, 2024-01-26, similarity 0.9726):
[0001137789-24-000010:note_history:18]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of December 29, 2023 and June 30, 2023:

- changed (2024-04-26):
[0001137789-24-000034:note_history:19]
|  |  | March 29, 2024 |  | June 30, 2023 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 172 |  |  | $ | — |  |  | $ | 172 |  |  | $ | 73 |  |  | $ | — |  |  | $ | 73 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 15 |  |  | — |  |  | 15 |  |  | 16 |  |  | — |  |  | 16 |  |
| Total |  | $ | 188 |  |  | $ | — |  |  | $ | 188 |  |  | $ | 90 |  |  | $ | — |  |  | $ | 90 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 171 |  |  |  |  |  |  | $ | 72 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 15 |  |  |  |  |  |  | 16 |  |
| Total |  |  |  |  |  | $ | 188 |  |  |  |  |  |  | $ | 90 |  |
  (was, 2024-01-26, similarity 0.9936):
[0001137789-24-000010:note_history:19]
|  |  | December 29, 2023 |  | June 30, 2023 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 90 |  |  | $ | — |  |  | $ | 90 |  |  | $ | 73 |  |  | $ | — |  |  | $ | 73 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 15 |  |  | — |  |  | 15 |  |  | 16 |  |  | — |  |  | 16 |  |
| Total |  | $ | 106 |  |  | $ | — |  |  | $ | 106 |  |  | $ | 90 |  |  | $ | — |  |  | $ | 90 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 89 |  |  |  |  |  |  | $ | 72 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 15 |  |  |  |  |  |  | 16 |  |
| Total |  |  |  |  |  | $ | 106 |  |  |  |  |  |  | $ | 90 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-04-26):
[0001137789-24-000034:note_history:20]
The following table provides details of the Company’s debt as of March 29, 2024 and June 30, 2023:
  (was, 2024-01-26, similarity 0.9497):
[0001137789-24-000010:note_history:20]
The following table provides details of the Company’s debt as of December 29, 2023 and June 30, 2023:

- changed (2024-04-26):
[0001137789-24-000034:note_history:21]
| (Dollars in millions) |  | March 29, 2024 |  | June 30, 2023 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | $ | 479 |  |  | $ | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 469 |  |  | 465 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | — |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | — |  |  | 430 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
|  |  | 5,702 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (31) |  |  | (36) |  |
| Debt, net of debt issuance costs |  | 5,671 |  |  | 5,451 |  |
| Less: current portion of long-term debt |  | (479) |  |  | (63) |  |
| Long-term debt, less current portion |  | $ | 5,192 |  |  | $ | 5,388 |  |
  (was, 2024-01-26, similarity 0.997):
[0001137789-24-000010:note_history:21]
| (Dollars in millions) |  | December 29, 2023 |  | June 30, 2023 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | $ | 479 |  |  | $ | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 469 |  |  | 465 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | — |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | — |  |  | 430 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
|  |  | 5,701 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (32) |  |  | (36) |  |
| Debt, net of debt issuance costs |  | 5,669 |  |  | 5,451 |  |
| Less: current portion of long-term debt |  | — |  |  | (63) |  |
| Long-term debt, less current portion |  | $ | 5,669 |  |  | $ | 5,388 |  |

- changed (2024-04-26):
[0001137789-24-000034:note_history:22]
| (1) All unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX. |
  (was, 2024-01-26, similarity 0.9928):
[0001137789-24-000010:note_history:22]
(1) All unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX.

- removed (2024-04-26):
[0001137789-24-000010:note_history:23]
_____________________________


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-04-26):
[0001137789-24-000034:note_history:24]
At March 29, 2024, future principal payments on long-term debt were as follows (in millions):
  (was, 2024-01-26, similarity 0.9492):
[0001137789-24-000010:note_history:24]
At December 29, 2023, future principal payments on long-term debt were as follows (in millions):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-04-26):
[0001137789-24-000034:note_history:25]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |  |
| (Dollars in millions) |  | March 29, 2024 |  | March 31, 2023 |  | March 29, 2024 |  | March 31, 2023 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,236 |  |  | $ | 1,358 |  |  | $ | 3,408 |  |  | $ | 4,268 |  |  |  |  |  |
| Distributors |  | 252 |  |  | 294 |  |  | 736 |  |  | 890 |  |  |  |  |  |
| Retailers |  | 167 |  |  | 208 |  |  | 520 |  |  | 624 |  |  |  |  |  |
| Total |  | $ | 1,655 |  |  | $ | 1,860 |  |  | $ | 4,664 |  |  | $ | 5,782 |  |  |  |  |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 837 |  |  | $ | 774 |  |  | $ | 2,425 |  |  | $ | 2,335 |  |  |  |  |  |
| Americas |  | 618 |  |  | 799 |  |  | 1,617 |  |  | 2,588 |  |  |  |  |  |
| EMEA |  | 200 |  |  | 287 |  |  | 622 |  |  | 859 |  |  |  |  |  |
| Total |  | $ | 1,655 |  |  | $ | 1,860 |  |  | $ | 4,664 |  |  | $ | 5,782 |  |  |  |  |  |
  (was, 2024-01-26, similarity 0.9298):
[0001137789-24-000010:note_history:25]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | December 29, 2023 |  | December 30, 2022 |  | December 29, 2023 |  | December 30, 2022 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,140 |  |  | $ | 1,365 |  |  | $ | 2,172 |  |  | $ | 2,910 |  |  |  |  |  |
| Distributors |  | 218 |  |  | 297 |  |  | 484 |  |  | 596 |  |  |  |  |  |
| Retailers |  | 197 |  |  | 225 |  |  | 353 |  |  | 416 |  |  |  |  |  |
| Total |  | $ | 1,555 |  |  | $ | 1,887 |  |  | $ | 3,009 |  |  | $ | 3,922 |  |  |  |  |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 777 |  |  | $ | 760 |  |  | $ | 1,588 |  |  | $ | 1,561 |  |  |  |  |  |
| Americas |  | 544 |  |  | 853 |  |  | 999 |  |  | 1,789 |  |  |  |  |  |
| EMEA |  | 234 |  |  | 274 |  |  | 422 |  |  | 572 |  |  |  |  |  |
| Total |  | $ | 1,555 |  |  | $ | 1,887 |  |  | $ | 3,009 |  |  | $ | 3,922 |  |  |  |  |  |

- removed (2024-04-26):
[0001137789-24-000010:note_history:26]
_____________________________

- removed (2024-04-26):
[0001137789-24-000010:note_history:27]
(1) Revenue is attributed to geography based on bill from locations.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-04-26):
[0001137789-24-000034:note_history:28]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |  |
| (Dollars in millions) |  | March 29, 2024 |  | March 31, 2023 |  | March 29, 2024 |  | March 31, 2023 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,236 |  |  | $ | 1,358 |  |  | $ | 3,408 |  |  | $ | 4,268 |  |  |  |  |  |
| Distributors |  | 252 |  |  | 294 |  |  | 736 |  |  | 890 |  |  |  |  |  |
| Retailers |  | 167 |  |  | 208 |  |  | 520 |  |  | 624 |  |  |  |  |  |
| Total |  | $ | 1,655 |  |  | $ | 1,860 |  |  | $ | 4,664 |  |  | $ | 5,782 |  |  |  |  |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 837 |  |  | $ | 774 |  |  | $ | 2,425 |  |  | $ | 2,335 |  |  |  |  |  |
| Americas |  | 618 |  |  | 799 |  |  | 1,617 |  |  | 2,588 |  |  |  |  |  |
| EMEA |  | 200 |  |  | 287 |  |  | 622 |  |  | 859 |  |  |  |  |  |
| Total |  | $ | 1,655 |  |  | $ | 1,860 |  |  | $ | 4,664 |  |  | $ | 5,782 |  |  |  |  |  |
  (was, 2024-01-26, similarity 0.9298):
[0001137789-24-000010:note_history:28]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | December 29, 2023 |  | December 30, 2022 |  | December 29, 2023 |  | December 30, 2022 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,140 |  |  | $ | 1,365 |  |  | $ | 2,172 |  |  | $ | 2,910 |  |  |  |  |  |
| Distributors |  | 218 |  |  | 297 |  |  | 484 |  |  | 596 |  |  |  |  |  |
| Retailers |  | 197 |  |  | 225 |  |  | 353 |  |  | 416 |  |  |  |  |  |
| Total |  | $ | 1,555 |  |  | $ | 1,887 |  |  | $ | 3,009 |  |  | $ | 3,922 |  |  |  |  |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 777 |  |  | $ | 760 |  |  | $ | 1,588 |  |  | $ | 1,561 |  |  |  |  |  |
| Americas |  | 544 |  |  | 853 |  |  | 999 |  |  | 1,789 |  |  |  |  |  |
| EMEA |  | 234 |  |  | 274 |  |  | 422 |  |  | 572 |  |  |  |  |  |
| Total |  | $ | 1,555 |  |  | $ | 1,887 |  |  | $ | 3,009 |  |  | $ | 3,922 |  |  |  |  |  |

- removed (2024-04-26):
[0001137789-24-000010:note_history:29]
_____________________________

- removed (2024-04-26):
[0001137789-24-000010:note_history:30]
(1) Revenue is attributed to geography based on bill from locations.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2024-04-26):
[0001137789-24-000034:note_history:31]
On April 23, 2024, the Board of Directors of the Company declared a quarterly cash dividend of $0.70 per share, which will be payable on July 5, 2024 to shareholders of record as of the close of business on June 20, 2024.
  (was, 2024-01-26, similarity 0.6078):
[0001137789-24-000010:note_history:31]
On January 24, 2024, the Board of Directors of the Company declared a quarterly cash dividend of $0.70 per share, which will be payable on April 4, 2024 to shareholders of record as of the close of business on March 21, 2024.

- added (2024-04-26):
[0001137789-24-000034:note_history:32]
Sale of System-on-Chip (“SoC”) Operations

- added (2024-04-26):
[0001137789-24-000034:note_history:33]
On April 23, 2024, the Company entered into an Asset Purchase Agreement with Avago Technologies International Sales Pte. Limited (“Purchaser”), a subsidiary of Broadcom Inc., to sell certain intellectual property, equipment and other assets related to the design, development and manufacture of its SoC products to Purchaser for $600 million. Purchaser and its affiliates have agreed to offer employment to certain of the Company’s employees engaged in the SoC Operations. In connection with this transaction, the Company and Purchaser have also restructured an existing purchasing agreement.
