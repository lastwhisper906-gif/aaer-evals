# STX notes — 0001137789-24-000034


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001137789-24-000034:notes:1]
[same as prior period, unchanged from 0001137789-24-000010:notes:1]

[0001137789-24-000034:notes:2]
[same as prior period, unchanged from 0001137789-24-000010:notes:2]

[0001137789-24-000034:notes:3]
[same as prior period, unchanged from 0001137789-24-000010:notes:3]

[0001137789-24-000034:notes:4]
[same as prior period, unchanged from 0001137789-24-000010:notes:4]

[0001137789-24-000034:notes:5]
[same as prior period, unchanged from 0001137789-24-000010:notes:5]

[0001137789-24-000034:notes:6]
[same as prior period, unchanged from 0001137789-24-000010:notes:6]

[0001137789-24-000034:notes:7]
[same as prior period, unchanged from 0001137789-24-000010:notes:7]

[0001137789-24-000034:notes:8]
[same as prior period, unchanged from 0001137789-24-000010:notes:8]

[0001137789-24-000034:notes:9]
[same as prior period, unchanged from 0001137789-24-000010:notes:9]

[0001137789-24-000034:notes:10]
[same as prior period, unchanged from 0001137789-24-000010:notes:10]

[0001137789-24-000034:notes:11]
The Company’s Consolidated Financial Statements for the fiscal year ended June 30, 2023 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 4, 2023. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 30, 2023, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and nine months ended March 29, 2024 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 28, 2024.

[0001137789-24-000034:notes:12]
[same as prior period, unchanged from 0001137789-24-000010:notes:12]

[0001137789-24-000034:notes:13]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and nine months ended March 29, 2024 and March 31, 2023 consisted of 13 and 39 weeks, respectively. Fiscal years 2024 and 2023 both comprise 52 weeks and end on June 28, 2024 and June 30, 2023, respectively. The fiscal quarters ended March 29, 2024, December 29, 2023 and March 31, 2023, are also referred to herein as the “March 2024 quarter”, the “December 2023 quarter” and the “March 2023 quarter”, respectively.

[0001137789-24-000034:notes:14]
[same as prior period, unchanged from 0001137789-24-000010:notes:14]

[0001137789-24-000034:notes:15]
[same as prior period, unchanged from 0001137789-24-000010:notes:15]

[0001137789-24-000034:notes:16]
[same as prior period, unchanged from 0001137789-24-000010:notes:16]

[0001137789-24-000034:notes:17]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. Effective from the first quarter of fiscal year 2024, the Company changed the useful lives of certain manufacturing equipment from a range of three to seven years to a range of three to ten years based on its review of technology product roadmap. The effect of this change in estimate increased the net income by approximately $30 million and $70 million for three and nine months ended March 29, 2024, respectively. Earnings per share for the three months ended March 29, 2024 increased by $0.14 and loss per share for the nine months ended March 29, 2024 decreased by $0.33.

[0001137789-24-000034:notes:18]
Recently Adopted Accounting Pronouncements

[0001137789-24-000034:notes:19]
In September 2022, the Financial Accounting Standards Board (FASB) issued ASU 2022-04 (ASC Subtopic 405-50), Disclosure of Supplier Finance Program Obligations. This ASU requires disclosure of key terms of the outstanding supplier finance programs and a roll forward of the related obligations. The Company adopted this guidance in the quarter ended September 29, 2023. The adoption of this ASU did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0001137789-24-000034:notes:20]
Recently Issued Accounting Pronouncements

[0001137789-24-000034:notes:21]
In November 2023, the FASB issued ASU 2023-07 (ASC Topic 280), Improvements to Reportable Segment Disclosures. This ASU improves reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The Company is required to adopt this guidance for its annual reporting in fiscal year 2025 and for interim period reporting beginning the first quarter of fiscal year 2026 on a retrospective basis. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have impact on its Condensed Consolidated Financial Statements.

[0001137789-24-000034:notes:22]
In December 2023, the FASB issued ASU 2023-09 (ASC Topic 740), Improvements to Income Tax Disclosures. This ASU requires disaggregated income tax disclosures on the rate reconciliation and income taxes paid. The Company is required to adopt this guidance in the first quarter of the fiscal year 2026. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have impact on its Condensed Consolidated Financial Statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001137789-24-000034:notes:23]
[same as prior period, unchanged from 0001137789-24-000010:notes:23]

[0001137789-24-000034:notes:24]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of March 29, 2024 and June 30, 2023:

[0001137789-24-000034:notes:25]
|  |  | March 29, 2024 |  | June 30, 2023 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 172 |  |  | $ | — |  |  | $ | 172 |  |  | $ | 73 |  |  | $ | — |  |  | $ | 73 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 15 |  |  | — |  |  | 15 |  |  | 16 |  |  | — |  |  | 16 |  |
| Total |  | $ | 188 |  |  | $ | — |  |  | $ | 188 |  |  | $ | 90 |  |  | $ | — |  |  | $ | 90 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 171 |  |  |  |  |  |  | $ | 72 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 15 |  |  |  |  |  |  | 16 |  |
| Total |  |  |  |  |  | $ | 188 |  |  |  |  |  |  | $ | 90 |  |

[0001137789-24-000034:notes:26]
As of March 29, 2024 and June 30, 2023, the Company’s Other current assets included $2 million in restricted cash equivalents held as collateral at banks for various performance obligations.

[0001137789-24-000034:notes:27]
As of March 29, 2024 and June 30, 2023, the Company had no available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no impairment related to credit losses for available-for-sale debt securities as of March 29, 2024.

[0001137789-24-000034:notes:28]
The fair value and amortized cost of the Company’s investments classified as available-for-sale debt securities as of March 29, 2024, by remaining contractual maturity were as follows:

[0001137789-24-000034:notes:29]
| (Dollars in millions) |  | Amortized Cost |  | Fair Value |
| Due in less than 1 year |  | $ | 173 |  |  | $ | 173 |  |
| Due in 1 to 5 years |  | 15 |  |  | 15 |  |
| Total |  | $ | 188 |  |  | $ | 188 |  |

[0001137789-24-000034:notes:30]
[same as prior period, unchanged from 0001137789-24-000010:notes:30]

[0001137789-24-000034:notes:31]
[same as prior period, unchanged from 0001137789-24-000010:notes:31]

[0001137789-24-000034:notes:32]
| (Dollars in millions) |  | March 29, 2024 |  | June 30, 2023 |  | March 31, 2023 |  | July 1, 2022 |
| Cash and cash equivalents |  | $ | 795 |  |  | $ | 786 |  |  | $ | 766 |  |  | $ | 615 |  |
| Restricted cash included in Other current assets |  | 2 |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  | $ | 797 |  |  | $ | 788 |  |  | $ | 768 |  |  | $ | 617 |  |

[0001137789-24-000034:notes:33]
[same as prior period, unchanged from 0001137789-24-000010:notes:33]

[0001137789-24-000034:notes:34]
[same as prior period, unchanged from 0001137789-24-000010:notes:34]

[0001137789-24-000034:notes:35]
During the three and nine months ended March 29, 2024, the Company sold trade receivables without recourse for cash proceeds of $291 million and $873 million, respectively. As of March 29, 2024, the total amount that remained subject to servicing by the Company was $291 million. During the three and nine months ended March 31, 2023, the Company sold trade receivables without recourse for cash proceeds of $261 million and $672 million, respectively.

[0001137789-24-000034:notes:36]
The discounts on the sale of trade receivables were not material for the three and nine months ended March 29, 2024 and March 31, 2023, respectively.

[0001137789-24-000034:notes:37]
Inventories, net

[0001137789-24-000034:notes:38]
The details of the inventories, net were as follows:

[0001137789-24-000034:notes:39]
| (Dollars in millions) |  | March 29, 2024 |  | June 30, 2023 |
| Raw materials and components |  | $ | 313 |  |  | $ | 241 |  |
| Work-in-process |  | 701 |  |  | 682 |  |
| Finished goods |  | 177 |  |  | 217 |  |
| Total inventories, net |  | $ | 1,191 |  |  | $ | 1,140 |  |

[0001137789-24-000034:notes:40]
[same as prior period, unchanged from 0001137789-24-000010:notes:40]

[0001137789-24-000034:notes:41]
[same as prior period, unchanged from 0001137789-24-000010:notes:41]

[0001137789-24-000034:notes:42]
| (Dollars in millions) |  | March 29, 2024 |  | June 30, 2023 |
| Vendor receivables |  | $ | 125 |  |  | $ | 167 |  |
| Other current assets |  | 172 |  |  | 191 |  |
| Total |  | $ | 297 |  |  | $ | 358 |  |

[0001137789-24-000034:notes:43]
[same as prior period, unchanged from 0001137789-24-000010:notes:43]

[0001137789-24-000034:notes:44]
[same as prior period, unchanged from 0001137789-24-000010:notes:44]

[0001137789-24-000034:notes:45]
| (Dollars in millions) |  | March 29, 2024 |  | June 30, 2023 |
| Property, equipment and leasehold improvements |  | $ | 10,297 |  |  | $ | 10,267 |  |
| Accumulated depreciation and amortization |  | (8,658) |  |  | (8,561) |  |
| Property, equipment and leasehold improvements, net |  | $ | 1,639 |  |  | $ | 1,706 |  |

[0001137789-24-000034:notes:46]
During the three months ended March 29, 2024, the Company did not record any accelerated depreciation expense. During the nine months ended March 29, 2024, the Company recognized a charge of $13 million for the accelerated depreciation of certain fixed assets, which was recorded to Cost of revenue in the Condensed Consolidated Statements of Operations.

[0001137789-24-000034:notes:47]
During the three and nine months ended March 31, 2023, the Company recognized a charge of $21 million and $82 million for the accelerated depreciation of certain fixed assets, respectively, which was recorded to Cost of revenue and Product development in the Condensed Consolidated Statements of Operations.

[0001137789-24-000034:notes:48]
[same as prior period, unchanged from 0001137789-24-000010:notes:48]

[0001137789-24-000034:notes:49]
[same as prior period, unchanged from 0001137789-24-000010:notes:49]

[0001137789-24-000034:notes:50]
| (Dollars in millions) |  | March 29, 2024 |  | June 30, 2023 |
| Dividends payable |  | $ | 147 |  |  | $ | 145 |  |
| Other accrued expenses |  | 611 |  |  | 603 |  |
| Total |  | $ | 758 |  |  | $ | 748 |  |

[0001137789-24-000034:notes:51]
Accumulated Other Comprehensive Income (Loss) (“AOCI”)

[0001137789-24-000034:notes:52]
[same as prior period, unchanged from 0001137789-24-000010:notes:52]

[0001137789-24-000034:notes:53]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  |  |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at June 30, 2023 |  | $ | 103 |  |  |  |  | $ | (4) |  |  | $ | (1) |  |  | $ | 98 |  |
| Other comprehensive (loss) income before reclassifications |  | (13) |  |  |  |  | — |  |  | 1 |  |  | (12) |  |
| Amounts reclassified from AOCI |  | (90) |  |  |  |  | 1 |  |  | — |  |  | (89) |  |
| Other comprehensive (loss) income |  | (103) |  |  |  |  | 1 |  |  | 1 |  |  | (101) |  |
| Balance at March 29, 2024 |  | $ | — |  |  |  |  | $ | (3) |  |  | $ | — |  |  | $ | (3) |  |
| Balance at July 1, 2022 |  | $ | 51 |  |  |  |  | $ | (14) |  |  | $ | (1) |  |  | $ | 36 |  |
| Other comprehensive income before reclassifications |  | 45 |  |  |  |  | — |  |  | — |  |  | 45 |  |
| Amounts reclassified from AOCI |  | 2 |  |  |  |  | 1 |  |  | — |  |  | 3 |  |
| Other comprehensive income |  | 47 |  |  |  |  | 1 |  |  | — |  |  | 48 |  |
| Balance at March 31, 2023 |  | $ | 98 |  |  |  |  | $ | (13) |  |  | $ | (1) |  |  | $ | 84 |  |


## us-gaap:DebtDisclosureTextBlock

[0001137789-24-000034:notes:54]
Debt
The following table provides details of the Company’s debt as of March 29, 2024 and June 30, 2023:

[0001137789-24-000034:notes:55]
| (Dollars in millions) |  | March 29, 2024 |  | June 30, 2023 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | $ | 479 |  |  | $ | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 469 |  |  | 465 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | — |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | — |  |  | 430 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
|  |  | 5,702 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (31) |  |  | (36) |  |
| Debt, net of debt issuance costs |  | 5,671 |  |  | 5,451 |  |
| Less: current portion of long-term debt |  | (479) |  |  | (63) |  |
| Long-term debt, less current portion |  | $ | 5,192 |  |  | $ | 5,388 |  |

[0001137789-24-000034:notes:56]
| (1) All unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX. |

[0001137789-24-000034:notes:57]
2028 Exchangeable Senior Notes and related Capped Call Transactions

[0001137789-24-000034:notes:58]
2028 Notes. On September 13, 2023, Seagate HDD, in a private placement, issued $1.5 billion in aggregate principal amount of 3.50% exchangeable Senior Notes due 2028 (the “2028 Notes”), which includes $200 million aggregate principal amount pursuant to the over-allotment option of the initial purchasers to purchase additional notes. The 2028 Notes will mature on June 1, 2028, with interest payable semi-annually on March 1 and September 1 of each year, commencing March 1, 2024.

[0001137789-24-000034:notes:59]
The entire outstanding principal amount of Term Loans A1, A2 and A3 were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in the Net gain (loss) recognized from early redemption of debt in the Company’s Condensed Consolidated Statements of Operations for the nine months ended March 29, 2024. In connection with the repayment of Term Loans, the Company terminated its interest rate swap agreements. Refer to “Note 6. Derivative Financial Instruments” for more details.

[0001137789-24-000034:notes:60]
Prior to March 1, 2028, the 2028 Notes are exchangeable at the option of the holders only under certain circumstances as set forth in the indenture with respect to the 2028 Notes. On or after March 1, 2028, the 2028 Notes are exchangeable at any time at the option of the holders until the close of business on the second scheduled trading day immediately preceding the maturity date, unless the 2028 Notes have been previously redeemed or repurchased by Seagate HDD. Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The initial exchange rate for the 2028 Notes is 12.1253 ordinary shares per $1,000 principal amount of 2028 Notes.

[0001137789-24-000034:notes:61]
Seagate HDD may redeem the 2028 Notes at its option, in whole but not in part, if Seagate HDD or the Guarantors have, or on the next interest payment date would, become obligated to pay to the holder of any Note additional amounts as a result of certain tax-related events at a redemption price equal to 100% of the principal amount plus accrued and unpaid interest, including additional interest, if any, to, but excluding, the redemption date; provided that Seagate HDD may only redeem the Notes if: (x) Seagate HDD or the relevant Guarantor cannot avoid these obligations by taking commercially reasonable measures available to Seagate HDD or such Guarantor; and (y) Seagate HDD delivers to the Trustee an opinion of outside legal counsel of recognized standing in the relevant taxing jurisdiction attesting to such tax-related event and obligation to pay additional amounts.

[0001137789-24-000034:notes:62]
Seagate HDD also may redeem the 2028 Notes at its option on or after September 8, 2026, in whole or in part, if the last reported sale price of ordinary shares of the Company has been at least 130% of the exchange price then in effect for at least 20 trading days (whether or not consecutive), including the trading day immediately preceding the date on which Seagate HDD provides notice of redemption, during any 30 consecutive trading day period ending on, and including, the trading day immediately preceding the date on which Seagate HDD provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If Seagate HDD redeems less than all the outstanding 2028 Notes, at least $150 million aggregate principal amount of 2028 Notes must be outstanding and not subject to redemption as of the relevant notice of redemption date.

[0001137789-24-000034:notes:63]
As of March 29, 2024, the 2028 Notes were not exchangeable and the aggregate if-converted value of the 2028 Notes exceeded their aggregate principal amount by approximately $100 million. Refer to “Note 11. Net Income (Loss) Per Share” for the potential dilutive impact of the 2028 Notes.

[0001137789-24-000034:notes:64]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The cap price of the capped call transactions will initially be $107.848 per share. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets.

[0001137789-24-000034:notes:65]
Credit Agreement

[0001137789-24-000034:notes:66]
The credit agreement dated as of February 20, 2019, by and among, Seagate Technology Holdings plc, Seagate HDD, The Bank of Nova Scotia, as administrative agent, and the lenders party thereto (as amended from time to time, the “Credit Agreement”) includes two financial covenants: (1) interest coverage ratio and (2) total net leverage ratio. The maximum permitted total net leverage ratio did not apply for the fiscal quarter ended March 29, 2024. For the fiscal quarters ending June 28, 2024 until the end of the covenant relief period, which terminates on June 27, 2025, the maximum permitted total net leverage ratio is 6.75 to 1.00, and applies only to the extent that the aggregate outstanding amount of revolving loans, swing line loans and the aggregate face amount of certain letters of credit exceeds 25% of the then outstanding revolving commitments in effect (the “Testing Condition”) as of the last day of the fiscal quarter. The maximum permitted total leverage ratio for each fiscal quarter ending after June 27, 2025 is 4.00 to 1.00.

[0001137789-24-000034:notes:67]
The minimum interest coverage ratio did not apply for the fiscal quarter ended March 29, 2024. For the fiscal quarters ending June 28, 2024 until June 27, 2025, the minimum interest coverage ratio is 2.25 to 1.00, and applies only to the extent that the Testing Condition is satisfied as of the last day of the fiscal quarter. The minimum interest coverage ratio is 3.25 to 1.00 for each fiscal quarter ending after June 27, 2025.

[0001137789-24-000034:notes:68]
Future Principal Payments on Long-term Debt

[0001137789-24-000034:notes:69]
At March 29, 2024, future principal payments on long-term debt were as follows (in millions):

[0001137789-24-000034:notes:70]
| Fiscal Year |  | Principal Amount |
| Remainder of 2024 |  | $ | — |  |
| 2025 |  | 479 |  |
| 2026 |  | — |  |
| 2027 |  | 505 |  |
| 2028 |  | 1,500 |  |
| Thereafter |  | 3,245 |  |
| Total |  | $ | 5,729 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001137789-24-000034:notes:71]
Income Taxes
The Company recorded income tax provisions of $33 million and $85 million for the three and nine months ended March 29, 2024, respectively. The discrete items in the income tax provision were not material for the three months ended March 29, 2024. The income tax provision for the nine months ended March 29, 2024 included approximately $42 million of net discrete expense, primarily associated with an increase in the Company’s valuation allowance to account for the impacts of new tax guidance which clarifies the treatment of specified research and experimental expenditures issued by the U.S. Treasury Department under Internal Revenue Code Section 174 during the September 2023 quarter, partially offset by net excess tax benefits related to share-based compensation expense. Additional guidance issued by the Treasury department in December 2023 did not result in any impacts. The Company will have income taxes payable based on profits generated in various jurisdictions.

[0001137789-24-000034:notes:72]
During the nine months ended March 29, 2024, the Company’s unrecognized tax benefits excluding interest and penalties decreased by approximately $6 million to $110 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. The Company is not expecting material changes to its unrecognized tax benefits in the next twelve months beginning March 30, 2024.

[0001137789-24-000034:notes:73]
The Company recorded income tax provisions of $33 million and $26 million for the three and nine months ended March 31, 2023, respectively. The discrete items in the income tax provisions were not material for the three and nine months ended March 31, 2023.

[0001137789-24-000034:notes:74]
During the third quarter of fiscal year 2024, the Company established Singapore as its principal executive offices. The Company’s income tax provisions recorded for the three and nine months ended March 29, 2024 differed from the provisions for income taxes that would be derived by applying the Singaporean statutory rate of 17% to income before income taxes, primarily due to the net effect of (i) earnings generated in jurisdictions that are subject to tax incentive programs, (ii) non-Singaporean earnings taxed at different rates, and (iii) changes in valuation allowance.

[0001137789-24-000034:notes:75]
The Company’s income tax provisions recorded for the three and nine months ended March 31, 2023 differed from the provisions for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001137789-24-000034:notes:76]
Restructuring and Other, net
The Company recorded restructuring and other, net charge of $2 million and benefit of $27 million for the three and nine months ended March 29, 2024, respectively. The net benefit for the nine months ended March 29, 2024 was primarily due to the net gain of $30 million from the sale and leaseback of certain property during the December 2023 quarter. The net proceeds of $34 million from this transaction were recorded as an investing inflow on the Company’s Condensed Statements of Cash Flows for the nine months ended March 29, 2024.

[0001137789-24-000034:notes:77]
For the three and nine months ended March 31, 2023, the Company recorded restructuring and other, net of $20 million and $110 million, respectively, on the Company’s Condensed Consolidated Statements of Operations. The Company’s restructuring plans are comprised primarily of charges related to workforce reduction costs, including severance and other one-time termination benefits, facilities and other exit costs.

[0001137789-24-000034:notes:78]
[same as prior period, unchanged from 0001137789-24-000010:notes:76]

[0001137789-24-000034:notes:79]
[same as prior period, unchanged from 0001137789-24-000010:notes:77]

[0001137789-24-000034:notes:80]
[same as prior period, unchanged from 0001137789-24-000010:notes:78]

[0001137789-24-000034:notes:81]
[same as prior period, unchanged from 0001137789-24-000010:notes:79]

[0001137789-24-000034:notes:82]
|  |  | April 2023 Plan |  | October 2022 Plan |  | Other Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at June 30, 2023 |  | $ | 108 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 5 |  |  | $ | 1 |  |  | $ | 4 |  |  | $ | 119 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | 1 |  |  | 5 |  |
| Cash payments |  | (106) |  |  | — |  |  | (1) |  |  | (3) |  |  | (4) |  |  | (1) |  |  | (115) |  |
| Adjustments |  | (1) |  |  | — |  |  | — |  |  | (1) |  |  | — |  |  | — |  |  | (2) |  |
| Accrual balances at March 29, 2024 |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 4 |  |  | $ | 7 |  |
| Total costs incurred inception to date as of March 29, 2024 |  | $ | 144 |  |  | $ | 3 |  |  | $ | 104 |  |  | $ | 5 |  |  | $ | 67 |  |  | $ | 14 |  |  | $ | 337 |  |
| Total expected charges to be incurred as of March 29, 2024 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001137789-24-000034:notes:83]
The accrued restructuring balance of $7 million at March 29, 2024 was included in Accrued expenses in the Company’s Condensed Consolidated Balance Sheets. Of the accrued restructuring balance of $119 million at June 30, 2023, $117 million was included in Accrued expenses and $2 million was included in Other non-current liabilities in the Company’s Condensed Consolidated Balance Sheets.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001137789-24-000034:notes:84]
[same as prior period, unchanged from 0001137789-24-000010:notes:82]

[0001137789-24-000034:notes:85]
The Company entered into certain interest rate swap agreements to convert the variable interest rate on its Term Loans to fixed interest rates. The objective of the interest rate swap agreements was to eliminate the variability of interest payment cash flows associated with the variable interest rate under the Term Loans. The Company designated the interest rate swaps as cash flow hedges. On September 13, 2023, the Company terminated its then existing interest rate swap agreements as a result of the repayment of Term Loans A1, A2 and A3 and received cash proceeds of $25 million from the counterparty. The cash proceeds are reported within Net cash provided by operating activities in the Company’s Condensed Consolidated Statements of Cash Flows during the nine months ended March 29, 2024. The Company discontinued the related hedge accounting prospectively and realized a net gain of $104 million in Net gain recognized from termination of interest rate swap in the Condensed Consolidated Statements of Operations during the nine months ended March 29, 2024. Additionally, $6 million of the gains were amortized to Interest expense prior to the termination of interest rate swap in the Company’s Condensed Consolidated Statements of Operations. Refer to “Note 3. Debt” for more details.

[0001137789-24-000034:notes:86]
As of March 29, 2024, the Company does not have any interest rate swap contracts.

[0001137789-24-000034:notes:87]
The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives on its Condensed Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in AOCI until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The net unrealized loss on cash flow hedges was $3 million as of March 29, 2024, all of which is expected to be reclassified to earnings within twelve months. The net unrealized gain on cash flow hedges was $12 million as of June 30, 2023.

[0001137789-24-000034:notes:88]
[same as prior period, unchanged from 0001137789-24-000010:notes:86]

[0001137789-24-000034:notes:89]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income (Loss) and the Condensed Consolidated Statements of Operations for the three and nine months ended March 29, 2024:

[0001137789-24-000034:notes:90]
|  |  |  |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (5) |  |  | $ | (5) |  |
| Total return swap |  | Operating expenses |  | 6 |  |  | 9 |  |

[0001137789-24-000034:notes:91]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing(1) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
|  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | $ | (4) |  |  | $ | 2 |  |  | Cost of revenue |  | $ | 3 |  |  | $ | (3) |  |  | Other, net |  | $ | 1 |  |  | $ | 2 |  |
| Interest rate swap |  | — |  |  | (15) |  |  | Interest expense |  | — |  |  | 11 |  |  | Net gain recognized from termination of interest rate swap |  | — |  |  | 104 |  |

[0001137789-24-000034:notes:92]
| (1)The net gain recognized into earnings as a result of the discontinuance of interest rate swap during the nine months ended March 29, 2024. |

[0001137789-24-000034:notes:93]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income (Loss) and the Condensed Consolidated Statements of Operations for the three and nine months ended March 31, 2023:

[0001137789-24-000034:notes:94]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |
|  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | — |  |  | $ | (6) |  |
| Total return swap |  | Operating expenses |  | 8 |  |  | — |  |

[0001137789-24-000034:notes:95]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  |
|  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |  |
| Foreign currency forward exchange contracts |  | $ | 5 |  |  | $ | 4 |  |  | Cost of revenue |  | $ | (1) |  |  | $ | (20) |  |  | Other, net |  | $ | (2) |  |  | $ | (3) |  |  |
| Interest rate swap |  | (11) |  |  | 41 |  |  | Interest expense |  | 10 |  |  | 18 |  |  | Interest expense |  | — |  |  | — |  |  |

[0001137789-24-000034:notes:96]
[same as prior period, unchanged from 0001137789-24-000010:notes:94]

[0001137789-24-000034:notes:97]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of March 29, 2024 and June 30, 2023. All of the foreign currency forward exchange contracts mature within 12 months:

[0001137789-24-000034:notes:98]
|  |  | As of March 29, 2024 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Singapore Dollar |  | $ | 50 |  |  | $ | 115 |  |
| Thai Baht |  | 47 |  |  | 39 |  |
| Chinese Renminbi |  | 16 |  |  | 19 |  |
| British Pound Sterling |  | 16 |  |  | 11 |  |
| Total |  | $ | 129 |  |  | $ | 184 |  |

[0001137789-24-000034:notes:99]
[same as prior period, unchanged from 0001137789-24-000010:notes:97]

[0001137789-24-000034:notes:100]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its non-qualified deferred compensation plan: the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP’s liabilities. The Company pays a floating rate, based on SOFR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP’s liabilities due to changes in the value of the investment options made by employees. As of March 29, 2024, the notional investments underlying the TRS amounted to $109 million. This contract, which settles monthly and effectively mitigates counterparty risk, will mature in May 2024. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP’s liabilities.

[0001137789-24-000034:notes:101]
The following tables show the Company’s derivative instruments measured at gross fair value as reflected in the Condensed Consolidated Balance Sheets as of March 29, 2024 and June 30, 2023:

[0001137789-24-000034:notes:102]
|  |  | As of March 29, 2024 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance Sheet Location |  | Fair Value |  | Balance Sheet Location |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (3) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 1 |  |  | Accrued expenses |  | (1) |  |
| Total derivatives |  |  |  | $ | 1 |  |  |  |  | $ | (4) |  |

[0001137789-24-000034:notes:103]
[same as prior period, unchanged from 0001137789-24-000010:notes:101]


## us-gaap:FairValueDisclosuresTextBlock

[0001137789-24-000034:notes:104]
[same as prior period, unchanged from 0001137789-24-000010:notes:102]

[0001137789-24-000034:notes:105]
[same as prior period, unchanged from 0001137789-24-000010:notes:103]

[0001137789-24-000034:notes:106]
[same as prior period, unchanged from 0001137789-24-000010:notes:104]

[0001137789-24-000034:notes:107]
[same as prior period, unchanged from 0001137789-24-000010:notes:105]

[0001137789-24-000034:notes:108]
[same as prior period, unchanged from 0001137789-24-000010:notes:106]

[0001137789-24-000034:notes:109]
[same as prior period, unchanged from 0001137789-24-000010:notes:107]

[0001137789-24-000034:notes:110]
[same as prior period, unchanged from 0001137789-24-000010:notes:108]

[0001137789-24-000034:notes:111]
[same as prior period, unchanged from 0001137789-24-000010:notes:109]

[0001137789-24-000034:notes:112]
[same as prior period, unchanged from 0001137789-24-000010:notes:110]

[0001137789-24-000034:notes:113]
[same as prior period, unchanged from 0001137789-24-000010:notes:111]

[0001137789-24-000034:notes:114]
|  |  | March 29, 2024 |  | June 30, 2023 |
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 171 |  |  | $ | — |  |  | $ | — |  |  | $ | 171 |  |  | $ | 72 |  |  | $ | — |  |  | $ | — |  |  | $ | 72 |  |
| Total cash equivalents |  | 171 |  |  | — |  |  | — |  |  | 171 |  |  | 72 |  |  | — |  |  | — |  |  | 72 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | — |  |  | — |  |  | 15 |  |  | 15 |  |  | — |  |  | — |  |  | 16 |  |  | 16 |  |
| Derivative assets |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Total assets |  | $ | 172 |  |  | $ | 2 |  |  | $ | 15 |  |  | $ | 189 |  |  | $ | 73 |  |  | $ | 24 |  |  | $ | 16 |  |  | $ | 113 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | (4) |  |  | $ | — |  |  | $ | (4) |  |  | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 11 |  |
| Total liabilities |  | $ | — |  |  | $ | (4) |  |  | $ | — |  |  | $ | (4) |  |  | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 11 |  |

[0001137789-24-000034:notes:115]
|  |  | March 29, 2024 |  | June 30, 2023 |
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 171 |  |  | $ | — |  |  | $ | — |  |  | $ | 171 |  |  | $ | 72 |  |  | $ | — |  |  | $ | — |  |  | $ | 72 |  |
| Other current assets |  | 1 |  |  | 2 |  |  | — |  |  | 3 |  |  | 1 |  |  | 24 |  |  | — |  |  | 25 |  |
| Other assets, net |  | — |  |  | — |  |  | 15 |  |  | 15 |  |  | — |  |  | — |  |  | 16 |  |  | 16 |  |
| Total assets |  | $ | 172 |  |  | $ | 2 |  |  | $ | 15 |  |  | $ | 189 |  |  | $ | 73 |  |  | $ | 24 |  |  | $ | 16 |  |  | $ | 113 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | (4) |  |  | $ | — |  |  | $ | (4) |  |  | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 11 |  |
| Total liabilities |  | $ | — |  |  | $ | (4) |  |  | $ | — |  |  | $ | (4) |  |  | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 11 |  |

[0001137789-24-000034:notes:116]
[same as prior period, unchanged from 0001137789-24-000010:notes:114]

[0001137789-24-000034:notes:117]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair value of all of its cash equivalents. For the cash equivalents in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry-standard data providers or other third-party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of March 29, 2024, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts and the TRS. The Company recognizes derivative financial instruments in its Condensed Consolidated Financial Statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001137789-24-000034:notes:118]
[same as prior period, unchanged from 0001137789-24-000010:notes:116]

[0001137789-24-000034:notes:119]
[same as prior period, unchanged from 0001137789-24-000010:notes:117]

[0001137789-24-000034:notes:120]
For the investments that are accounted for under the equity method, the Company sold certain investments for $5 million and recorded immaterial loss for the three months ended March 29, 2024. The Company recorded a net loss of $29 million for the nine months ended March 29, 2024, which included $25 million related to downward adjustments to write down the carrying amount of certain investments to their fair value. The Company recorded a net loss of $1 million and $4 million for the three and nine months ended March 31, 2023, respectively. The adjusted carrying value of the investments accounted for under the equity method amounted to $21 million and $55 million as of March 29, 2024 and June 30, 2023, respectively.

[0001137789-24-000034:notes:121]
For the investments that are accounted for under the measurement alternative, the Company recorded a net loss of $14 million for the nine months ended March 29, 2024, related to downward adjustments to write down the carrying amount of certain investments to their fair value. The Company recorded a net gain of $3 million for the nine months ended March 31, 2023, related to upward adjustments due to observable price changes. As of March 29, 2024 and June 30, 2023, the carrying value of the Company’s strategic investments under the measurement alternative was $75 million and $88 million, respectively.

[0001137789-24-000034:notes:122]
[same as prior period, unchanged from 0001137789-24-000010:notes:120]

[0001137789-24-000034:notes:123]
[same as prior period, unchanged from 0001137789-24-000010:notes:121]

[0001137789-24-000034:notes:124]
|  |  | March 29, 2024 |  | June 30, 2023 |
| (Dollars in millions) |  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 4.75% Senior Notes due January 2025 |  | $ | 479 |  |  | $ | 475 |  |  | $ | 479 |  |  | $ | 472 |  |
| 4.875% Senior Notes due June 2027 |  | 505 |  |  | 492 |  |  | 504 |  |  | 484 |  |
| 3.50% Exchangeable Senior Notes due June 2028 |  | 1,500 |  |  | 1,908 |  |  | — |  |  | — |  |
| 4.091% Senior Notes due June 2029 |  | 469 |  |  | 457 |  |  | 465 |  |  | 436 |  |
| 3.125% Senior Notes due July 2029 |  | 163 |  |  | 138 |  |  | 163 |  |  | 126 |  |
| 8.25% Senior Notes due December 2029 |  | 500 |  |  | 538 |  |  | 500 |  |  | 522 |  |
| 4.125% Senior Notes due January 2031 |  | 275 |  |  | 242 |  |  | 275 |  |  | 227 |  |
| 3.375% Senior Notes due July 2031 |  | 72 |  |  | 57 |  |  | 72 |  |  | 53 |  |
| 8.50% Senior Notes due July 2031 |  | 500 |  |  | 542 |  |  | 500 |  |  | 524 |  |
| 9.625% Senior Notes due December 2032 |  | 750 |  |  | 856 |  |  | 750 |  |  | 830 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 480 |  |  | 489 |  |  | 438 |  |
| SOFR Based Term Loan A1 due September 2025 |  | — |  |  | — |  |  | 430 |  |  | 426 |  |
| SOFR Based Term Loan A2 due July 2027 |  | — |  |  | — |  |  | 430 |  |  | 420 |  |
| SOFR Based Term Loan A3 due July 2027 |  | — |  |  | — |  |  | 430 |  |  | 413 |  |
|  |  | $ | 5,702 |  |  | $ | 6,185 |  |  | $ | 5,487 |  |  | $ | 5,371 |  |
| Less: unamortized debt issuance costs |  | (31) |  |  | — |  |  | (36) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 5,671 |  |  | $ | 6,185 |  |  | $ | 5,451 |  |  | $ | 5,371 |  |
| Less: current portion of debt, net of debt issuance costs |  | (479) |  |  | (475) |  |  | (63) |  |  | (62) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,192 |  |  | $ | 5,710 |  |  | $ | 5,388 |  |  | $ | 5,309 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001137789-24-000034:notes:125]
Shareholders’ Deficit
Share Capital

[0001137789-24-000034:notes:126]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 209,982,166 shares were outstanding as of March 29, 2024, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of March 29, 2024.

[0001137789-24-000034:notes:127]
[same as prior period, unchanged from 0001137789-24-000010:notes:125]

[0001137789-24-000034:notes:128]
[same as prior period, unchanged from 0001137789-24-000010:notes:126]

[0001137789-24-000034:notes:129]
[same as prior period, unchanged from 0001137789-24-000010:notes:127]

[0001137789-24-000034:notes:130]
[same as prior period, unchanged from 0001137789-24-000010:notes:128]

[0001137789-24-000034:notes:131]
[same as prior period, unchanged from 0001137789-24-000010:notes:129]

[0001137789-24-000034:notes:132]
As of March 29, 2024, $1.9 billion remained available for repurchase under the existing repurchase authorization limit approved by the Board of Directors. The following table sets forth information with respect to repurchases of the Company’s ordinary shares during the nine months ended March 29, 2024:

[0001137789-24-000034:notes:133]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Tax withholding related to vesting of equity awards |  | — |  |  | $ | 31 |  |
| Total |  | — |  |  | $ | 31 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001137789-24-000034:notes:134]
[same as prior period, unchanged from 0001137789-24-000010:notes:132]

[0001137789-24-000034:notes:135]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |  |
| (Dollars in millions) |  | March 29, 2024 |  | March 31, 2023 |  | March 29, 2024 |  | March 31, 2023 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,236 |  |  | $ | 1,358 |  |  | $ | 3,408 |  |  | $ | 4,268 |  |  |  |  |  |
| Distributors |  | 252 |  |  | 294 |  |  | 736 |  |  | 890 |  |  |  |  |  |
| Retailers |  | 167 |  |  | 208 |  |  | 520 |  |  | 624 |  |  |  |  |  |
| Total |  | $ | 1,655 |  |  | $ | 1,860 |  |  | $ | 4,664 |  |  | $ | 5,782 |  |  |  |  |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 837 |  |  | $ | 774 |  |  | $ | 2,425 |  |  | $ | 2,335 |  |  |  |  |  |
| Americas |  | 618 |  |  | 799 |  |  | 1,617 |  |  | 2,588 |  |  |  |  |  |
| EMEA |  | 200 |  |  | 287 |  |  | 622 |  |  | 859 |  |  |  |  |  |
| Total |  | $ | 1,655 |  |  | $ | 1,860 |  |  | $ | 4,664 |  |  | $ | 5,782 |  |  |  |  |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001137789-24-000034:notes:136]
[same as prior period, unchanged from 0001137789-24-000010:notes:135]

[0001137789-24-000034:notes:137]
[same as prior period, unchanged from 0001137789-24-000010:notes:136]

[0001137789-24-000034:notes:138]
[same as prior period, unchanged from 0001137789-24-000010:notes:137]

[0001137789-24-000034:notes:139]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product warranty return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the nine months ended March 29, 2024 and March 31, 2023 were as follows:

[0001137789-24-000034:notes:140]
|  |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | March 29, 2024 |  | March 31, 2023 |  |
| Balance, beginning of period |  | $ | 168 |  |  | $ | 148 |  |  |
| Warranties issued |  | 40 |  |  | 42 |  |  |
| Repairs and replacements |  | (60) |  |  | (71) |  |  |
| Changes in liability for pre-existing warranties, including expirations |  | 8 |  |  | 42 |  |  |
| Balance, end of period |  | $ | 156 |  |  | $ | 161 |  |  |


## us-gaap:EarningsPerShareTextBlock

[0001137789-24-000034:notes:141]
Net Income (Loss) Per Share
Basic income (loss) earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period. Diluted earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period and the number of additional shares that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding options, unvested restricted share units and performance-based share units and shares to be purchased under the Employee Stock Purchase Plan using the treasury stock method, as well as shares issuable in connection with the Company’s exchangeable senior notes using the “if-converted” method.

[0001137789-24-000034:notes:142]
Under the treasury stock method, the dilutive effect of potentially dilutive securities is reflected in diluted net earnings per share and an increase in fair market value of the Company’s share price can result in a greater dilutive effect from potentially dilutive securities. Under the “if-converted” method, diluted earnings per share is calculated assuming that the excess value above the principal of the exchangeable notes were converted solely into shares of common stock at the beginning of the reporting period, unless the result would be anti-dilutive, which could adversely affect our diluted earnings per share.

[0001137789-24-000034:notes:143]
The following table sets forth the computation of basic and diluted net loss per share attributable to the shareholders of the Company:

[0001137789-24-000034:notes:144]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (In millions, except per share data) |  | March 29, 2024 |  | March 31, 2023 |  | March 29, 2024 |  | March 31, 2023 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 25 |  |  | $ | (433) |  |  | $ | (178) |  |  | $ | (437) |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income (loss) per share |  | 210 |  |  | 207 |  |  | 209 |  |  | 207 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | 2 |  |  | — |  |  | — |  |  | — |  |
| 2028 Notes if-converted shares |  | 1 |  |  | — |  |  | — |  |  | — |  |
| Total shares for purposes of calculating diluted net income (loss) per share |  | 213 |  |  | 207 |  |  | 209 |  |  | 207 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.12 |  |  | $ | (2.09) |  |  | $ | (0.85) |  |  | $ | (2.11) |  |
| Diluted |  | $ | 0.12 |  |  | $ | (2.09) |  |  | $ | (0.85) |  |  | $ | (2.11) |  |

[0001137789-24-000034:notes:145]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share was not material for the three months ended March 29, 2024. All potentially dilutive securities have been excluded for the periods that the Company was in a loss position, as including them would be anti-dilutive. The weighted average anti-dilutive shares that were excluded from the computation of diluted net loss per share were 7 million for the nine months ended March 29, 2024, and 7 million for both the three and nine months ended March 31, 2023, respectively.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001137789-24-000034:notes:146]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001137789-24-000034:notes:147]
Litigation

[0001137789-24-000034:notes:148]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgement in favor of Seagate on April 19, 2022, following a jury trial. The parties filed post-trial motions with the district court, which were denied. An appeal to the Federal Circuit is pending. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

[0001137789-24-000034:notes:149]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the U.S. District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendant misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies and additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 8, 2022, the court entered an Amended Stipulation and Order of Dismissal with Prejudice to dismiss all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment under the Foreign Trade Antitrust Improvement Act (“FTAIA Motion”) against Seagate’s antitrust claims, and on October 14, 2022, the Seagate Entities filed their corresponding opposition. On May 15, 2023, the Court issued a ruling that Seagate’s antitrust claims can proceed as to suspension assemblies that enter the United States but not as to suspension assembles that do not enter the United States. On July 28, 2023, the District Court initiated a reconsideration of this ruling and requested further briefing. On November 17, 2023, the Court granted NHK’s FTAIA Motion and denied Seagate’s Motion for Leave to Amend the Complaint. Seagate plans to appeal the Court’s ruling on NHK’s FTAIA Motion to the Ninth Circuit and filed a motion on December 15, 2023 for the Court to certify the ruling for interlocutory appeal. On April 22, 2024, the District Court granted in part and denied in part Seagate’s motion to certify for interlocutory appeal the Court’s ruling on NHK’s FTAIA Motion.

[0001137789-24-000034:notes:150]
In re Seagate Technology Holdings plc Securities Litigation. A putative class action lawsuit alleging violations of the federal securities laws, UA Local 38 Defined Contribution Pension Plan, et al. v. Seagate Technology Holdings PLC, et al., was filed on July 10, 2023, in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The complaint alleged that it was a securities class action on behalf of all purchasers of Seagate common stock between September 15, 2020 and October 25, 2022, inclusive, and asserted claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b5-1. The complaint sought unspecified monetary damages and other relief. A second action, Public Employees’ Retirement System of Mississippi v. Seagate Technology Holdings plc, William David Mosley, and Gianluca Romano, was filed on July 26, 2023, asserting similar claims. The cases were consolidated on September 25, 2023. On October 19, 2023, plaintiffs filed an amended complaint asserting similar claims with a putative class period of September 14, 2020 through April 19, 2023. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint, which is currently pending before the court. A hearing regarding Seagate’s motion to dismiss occurred on March 26, 2024. The Company believes that the asserted claims are without merit and intends to vigorously defend the case.

[0001137789-24-000034:notes:151]
Godo Kaisha IP Bridge 1 v. Seagate Technology LLC, Seagate Technology (US) Holding, Inc., Seagate Technology (Thailand) Limited, Seagate Singapore International Headquarters Ltd., Seagate Technology (Netherlands) B.V. On March 15, 2024, a patent infringement action was filed by Godo Kaisha IP Bridge 1 (“IP Bridge”) against Seagate in United States District Court for the District of Delaware. The complaint alleges patent infringement by Seagate of US Patent Nos. 7,884,403 (entitled, “Magnetic tunnel junction device and memory device including the same”), 8,319,263 (entitled, “Magnetic tunnel junction device”), and 11,737,372 (entitled, “Method of manufacturing a magnetoresistive random access memory (MRAM)”). IP Bridge is seeking damages as well as additional relief. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

[0001137789-24-000034:notes:152]
Environmental Matters

[0001137789-24-000034:notes:153]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001137789-24-000034:notes:154]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001137789-24-000034:notes:155]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001137789-24-000034:notes:156]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001137789-24-000034:notes:157]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fail to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001137789-24-000034:notes:158]
BIS Settlement

[0001137789-24-000034:notes:159]
On April 18, 2023, the Company’s subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd (collectively, “Seagate”), entered into a settlement agreement (the “Settlement Agreement”) with the U.S. Department of Commerce’s Bureau of Industry and Security (“BIS”) that resolves BIS’ allegations regarding Seagate’s sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, Seagate has agreed to pay $300 million to BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. Seagate has also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the U.S. Export Administration Regulations (“EAR”), including one audit by an unaffiliated third-party consultant chosen by Seagate with expertise in U.S. export control laws and two internal audits. The Settlement Agreement also includes a denial order that is suspended and will be waived five years after the date of the order issued under the Settlement Agreement, provided that Seagate has made full and timely payments under the Settlement Agreement and timely completed the audit requirements. While Seagate is in compliance with and upon successful compliance in full with the terms of the Settlement Agreement, BIS has agreed it will not initiate any further administrative proceedings against Seagate in connection with any violation of the EAR arising out of the transactions detailed in the Settlement Agreement.

[0001137789-24-000034:notes:160]
While Seagate believed that it complied with all relevant export control laws at the time it made the hard disk drive sales at issue, Seagate determined that engaging with BIS and settling this matter was in the best interest of the Company, its customers, and its shareholders. In determining to engage with BIS and resolve this matter through a settlement agreement, the Company considered a number of factors, including the risks and cost of protracted litigation involving the U.S. government, and the size of the potential penalty and the Company’s desire to focus on current business challenges and long-term business strategy. The Settlement Agreement includes a finding that the Company incorrectly interpreted the regulation at issue to require evaluation of only the last stage of Seagate’s hard disk drive manufacturing process rather than the entire process. As part of this settlement, Seagate has agreed not to contest BIS’ determination that the sales in question did not comply with the U.S. EAR.

[0001137789-24-000034:notes:161]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $210 million were included in Accrued expense and Other non-current liabilities, respectively, on its Condensed Consolidated Balance Sheets as of March 29, 2024. For the nine months ended March 29, 2024, $30 million was paid and reported as an outflow from operating activities on its Condensed Consolidated Statements of Cash Flows.

[0001137789-24-000034:notes:162]
Other Matters

[0001137789-24-000034:notes:163]
From time to time, arising in the normal course of business, the Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company expects to be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:CommitmentsDisclosureTextBlock

[0001137789-24-000034:notes:164]
Commitments 
Unconditional Long-Term Purchase Obligations. As of March 29, 2024, the Company had unconditional long-term purchase obligations of approximately $2.5 billion, primarily related to purchases of inventory components. The Company expects the commitment to total $79 million, $234 million, $1.5 billion and $718 million for fiscal years 2025, 2026, 2027 and 2028, respectively.

[0001137789-24-000034:notes:165]
The Company recorded order cancellation fees to terminate certain purchase commitments related to the purchase of inventory components and equipment. During the three and nine months ended March 29, 2024, the Company recorded $1 million credits to order cancellation fees and $113 million order cancellation fees, respectively, which were recorded in Cost of revenue on its Condensed Consolidated Statements of Operations. As of March 29, 2024, cumulative unpaid order cancellation fees on the Condensed Consolidated Balance Sheets were $134 million, with $121 million in Accrued expenses and $13 million in Accounts payable, all of which is expected to be paid within one year.


## us-gaap:SubsequentEventsTextBlock

[0001137789-24-000034:notes:166]
Subsequent Events
Dividend Declared

[0001137789-24-000034:notes:167]
On April 23, 2024, the Board of Directors of the Company declared a quarterly cash dividend of $0.70 per share, which will be payable on July 5, 2024 to shareholders of record as of the close of business on June 20, 2024.

[0001137789-24-000034:notes:168]
Sale of System-on-Chip (“SoC”) Operations

[0001137789-24-000034:notes:169]
On April 23, 2024, the Company entered into an Asset Purchase Agreement with Avago Technologies International Sales Pte. Limited (“Purchaser”), a subsidiary of Broadcom Inc., to sell certain intellectual property, equipment and other assets related to the design, development and manufacture of its SoC products to Purchaser for $600 million. Purchaser and its affiliates have agreed to offer employment to certain of the Company’s employees engaged in the SoC Operations. In connection with this transaction, the Company and Purchaser have also restructured an existing purchasing agreement.
