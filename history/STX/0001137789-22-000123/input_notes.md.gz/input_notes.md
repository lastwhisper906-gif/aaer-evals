# STX notes — 0001137789-22-000123


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001137789-22-000123:notes:1]
[same as prior period, unchanged from 0001137789-22-000031:notes:1]

[0001137789-22-000123:notes:2]
Seagate Technology Holdings plc (“STX”) and its subsidiaries (collectively, unless the context otherwise indicates, the “Company”) is a leading provider of data storage technology and infrastructure solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”), solid state hybrid drives (“SSHDs”), storage subsystems, as well as a scalable edge-to-cloud mass data platform that includes data transfer shuttles and a storage-as-a-service cloud.

[0001137789-22-000123:notes:3]
HDDs are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. HDDs continue to be the primary medium of mass data storage due to their performance attributes, reliability, high capacities, superior quality and cost effectiveness. Complementing existing storage architectures, SSDs use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory. In contrast to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high-capacity HDD and a smaller SSD acting as a cache to improve performance.

[0001137789-22-000123:notes:4]
The Company’s HDD products are designed for mass capacity storage and legacy markets. Mass capacity storage involves well-established use cases—such as hyperscale data centers and public clouds as well as emerging use cases. Legacy markets include markets the Company continues to sell to but that it does not plan to invest in significantly. The Company’s HDD and SSD product portfolio includes Serial Advanced Technology Attachment, Serial Attached SCSI and Non-Volatile Memory Express based designs to support a wide variety of mass capacity and legacy applications.

[0001137789-22-000123:notes:5]
The Company’s systems portfolio includes storage subsystems for enterprises, cloud service providers, scale-out storage servers and original equipment manufacturers (“OEMs”). Engineered for modularity, mobility, capacity and performance, these solutions include the Company’s enterprise HDDs and SSDs, enabling customers to integrate powerful, scalable storage within existing environments or create new ecosystems from the ground up in a secure, cost-effective manner.

[0001137789-22-000123:notes:6]
The Company’s Lyve portfolio provides a simple, cost-efficient and secure way to manage massive volumes of data across the distributed enterprise. The Lyve platform includes a shuttle solution that enables enterprises to transfer massive amounts of data from endpoints to the core cloud, a storage-as-a-service cloud offering that provides frictionless mass capacity storage at the metro edge.

[0001137789-22-000123:notes:7]
[same as prior period, unchanged from 0001137789-22-000031:notes:7]

[0001137789-22-000123:notes:8]
[same as prior period, unchanged from 0001137789-22-000031:notes:8]

[0001137789-22-000123:notes:9]
[same as prior period, unchanged from 0001137789-22-000031:notes:9]

[0001137789-22-000123:notes:10]
The Company’s consolidated financial statements for the fiscal year ended July 1, 2022 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 5, 2022. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 1, 2022, and the notes thereto, are adequate to make the information presented not misleading. The results of operations and the cash flows for the three months ended September 30, 2022 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 30, 2023.

[0001137789-22-000123:notes:11]
[same as prior period, unchanged from 0001137789-22-000031:notes:11]

[0001137789-22-000123:notes:12]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three months ended September 30, 2022 and October 1, 2021 consisted of 13 weeks. Fiscal years 2023 and 2022 both comprise of 52 weeks and end on June 30, 2023 and July 1, 2022, respectively. The fiscal quarters ended September 30, 2022, July 1, 2022 and October 1, 2021, are also referred to herein as the “September 2022 quarter”, the “June 2022 quarter” and the “September 2021 quarter”, respectively.

[0001137789-22-000123:notes:13]
[same as prior period, unchanged from 0001137789-22-000031:notes:13]

[0001137789-22-000123:notes:14]
There have been no material changes to the Company’s significant accounting policies disclosed in Note 1. Basis of Presentation and Summary of Significant Accounting Policies of “Financial Statements and Supplementary Data” contained in Part II, Item 8. of the Company’s Annual Report on Form 10-K for the fiscal year ended July 1, 2022, as filed with the SEC on August 5, 2022.

[0001137789-22-000123:notes:15]
Recently Adopted Accounting Pronouncements

[0001137789-22-000123:notes:16]
In March 2020, the Financial Accounting Standards Board (“FASB”) issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. The Company adopted the guidance in the quarter ended September 30, 2022 on a prospective basis and is transitioning from an interest rate based on London Interbank Offered Rate (“LIBOR”) to Secured Overnight Financing Rate (“SOFR”). The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.

[0001137789-22-000123:notes:17]
In November 2021, the FASB issued ASU 2021-10 (ASC Topic 832), Disclosures by Business Entities about Government Assistance. This ASU requires annual disclosures that increase the transparency of transactions involving government grants, including (1) the type of transactions, (2) the accounting for those transactions and (3) the effect of those transactions on an entity’s financial statements. The Company adopted the guidance in the quarter ended September 30, 2022.

[0001137789-22-000123:notes:18]
Recently Issued Accounting Pronouncements

[0001137789-22-000123:notes:19]
In September 2022, the FASB issued ASU 2022-04 (ASC Subtopic 405-50), Disclosure of Supplier Finance Program Obligations. This ASU requires disclosure of key terms of the outstanding supplier finance programs and a rollforward of the related obligations. The Company is required to adopt this guidance in the first quarter of fiscal year 2024. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001137789-22-000123:notes:20]
In June 2022, the FASB issued ASU 2022-03 (ASC Topic 820), Fair Value Measurement of Equity Securities Subject to Contractual Sale Restrictions. This ASU clarifies that a contractual restriction on the sale of equity security is not considered when measuring its fair value and requires new disclosures for equity securities subject to contractual sale restriction. The Company is required to adopt this guidance in the first quarter of fiscal year 2025. The Company does not expect the adoption of this ASU to have a material impact on its condensed consolidated financial statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001137789-22-000123:notes:21]
[same as prior period, unchanged from 0001137789-22-000031:notes:21]

[0001137789-22-000123:notes:22]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of September 30, 2022 and July 1, 2022:

[0001137789-22-000123:notes:23]
|  |  | September 30,2022 |  | July 1,2022 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 159 |  |  | $ | — |  |  | $ | 159 |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 16 |  |  | — |  |  | 16 |  |  | 23 |  |  | — |  |  | 23 |  |
| Total |  | $ | 176 |  |  | $ | — |  |  | $ | 176 |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 158 |  |  |  |  |  |  | $ | 59 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 16 |  |  |  |  |  |  | 23 |  |
| Total |  |  |  |  |  | $ | 176 |  |  |  |  |  |  | $ | 84 |  |

[0001137789-22-000123:notes:24]
As of September 30, 2022 and July 1, 2022, the Company’s Other current assets included $2 million in restricted cash equivalents held as collateral at banks for various performance obligations.

[0001137789-22-000123:notes:25]
As of September 30, 2022 and July 1, 2022, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no impairment related to credit losses for available-for-sale debt securities as of September 30, 2022.

[0001137789-22-000123:notes:26]
The fair value and amortized cost of the Company’s investments classified as available-for-sale debt securities as of September 30, 2022, by remaining contractual maturity were as follows:

[0001137789-22-000123:notes:27]
| (Dollars in millions) |  | Amortized Cost |  | Fair Value |
| Due in less than 1 year |  | $ | 160 |  |  | $ | 160 |  |
| Due in 1 to 5 years |  | 15 |  |  | 15 |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | 1 |  |  | 1 |  |
| Total |  | $ | 176 |  |  | $ | 176 |  |

[0001137789-22-000123:notes:28]
[same as prior period, unchanged from 0001137789-22-000031:notes:28]

[0001137789-22-000123:notes:29]
[same as prior period, unchanged from 0001137789-22-000031:notes:29]

[0001137789-22-000123:notes:30]
| (Dollars in millions) |  | September 30,2022 |  |  |  | July 1,2022 |  | October 1,2021 |  |  |  | July 2,2021 |
| Cash and cash equivalents |  | $ | 761 |  |  |  |  | $ | 615 |  |  | $ | 991 |  |  |  |  | $ | 1,209 |  |
| Restricted cash included in Other current assets |  | 2 |  |  |  |  | 2 |  |  | 2 |  |  |  |  | 2 |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  | $ | 763 |  |  |  |  | $ | 617 |  |  | $ | 993 |  |  |  |  | $ | 1,211 |  |

[0001137789-22-000123:notes:31]
Accounts receivable, net

[0001137789-22-000123:notes:32]
In connection with an existing factoring agreement, from time to time the Company sells trade receivables to a third party for cash proceeds less a discount. During the three months ended September 30, 2022, the Company sold trade receivables without recourse for cash proceeds of $200 million. As of September 30, 2022, the total amount that remained subject to servicing by the Company was $237 million. The discounts on receivables sold were not material for the three months ended September 30, 2022. During the three months ended October 1, 2021, the Company did not sell any trade receivables to a third party.

[0001137789-22-000123:notes:33]
[same as prior period, unchanged from 0001137789-22-000031:notes:33]

[0001137789-22-000123:notes:34]
[same as prior period, unchanged from 0001137789-22-000031:notes:34]

[0001137789-22-000123:notes:35]
| (Dollars in millions) |  | September 30,2022 |  | July 1,2022 |
| Raw materials and components |  | $ | 648 |  |  | $ | 601 |  |
| Work-in-process |  | 402 |  |  | 414 |  |
| Finished goods |  | 556 |  |  | 550 |  |
| Total inventories |  | $ | 1,606 |  |  | $ | 1,565 |  |

[0001137789-22-000123:notes:36]
[same as prior period, unchanged from 0001137789-22-000031:notes:36]

[0001137789-22-000123:notes:37]
[same as prior period, unchanged from 0001137789-22-000031:notes:37]

[0001137789-22-000123:notes:38]
| (Dollars in millions) |  | September 30,2022 |  | July 1,2022 |
| Property, equipment and leasehold improvements |  | $ | 10,699 |  |  | $ | 10,659 |  |
| Accumulated depreciation and amortization |  | (8,503) |  |  | (8,420) |  |
| Property, equipment and leasehold improvements, net |  | $ | 2,196 |  |  | $ | 2,239 |  |

[0001137789-22-000123:notes:39]
[same as prior period, unchanged from 0001137789-22-000031:notes:39]

[0001137789-22-000123:notes:40]
[same as prior period, unchanged from 0001137789-22-000031:notes:40]

[0001137789-22-000123:notes:41]
| (Dollars in millions) |  | September 30,2022 |  | July 1,2022 |
| Dividends payable |  | $ | 145 |  |  | $ | 147 |  |
| Other accrued expenses |  | 473 |  |  | 449 |  |
| Total |  | $ | 618 |  |  | $ | 596 |  |

[0001137789-22-000123:notes:42]
[same as prior period, unchanged from 0001137789-22-000031:notes:42]

[0001137789-22-000123:notes:43]
[same as prior period, unchanged from 0001137789-22-000031:notes:43]

[0001137789-22-000123:notes:44]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  |  |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at July 1, 2022 |  | $ | 51 |  |  |  |  | $ | (14) |  |  | $ | (1) |  |  | $ | 36 |  |
| Other comprehensive income before reclassifications |  | 32 |  |  |  |  | 1 |  |  | — |  |  | 33 |  |
| Amounts reclassified from AOCI |  | 5 |  |  |  |  | — |  |  | (1) |  |  | 4 |  |
| Other comprehensive income |  | 37 |  |  |  |  | 1 |  |  | (1) |  |  | 37 |  |
| Balance at September 30, 2022 |  | $ | 88 |  |  |  |  | $ | (13) |  |  | $ | (2) |  |  | $ | 73 |  |
| Balance at July 2, 2021 |  | $ | (18) |  |  |  |  | $ | (22) |  |  | $ | (1) |  |  | $ | (41) |  |
| Other comprehensive (loss) income before reclassifications |  | (9) |  |  |  |  | 1 |  |  | — |  |  | (8) |  |
| Amounts reclassified from AOCI |  | 3 |  |  |  |  | 1 |  |  | — |  |  | 4 |  |
| Other comprehensive loss |  | (6) |  |  |  |  | 2 |  |  | — |  |  | (4) |  |
| Balance at October 1, 2021 |  | $ | (24) |  |  |  |  | $ | (20) |  |  | $ | (1) |  |  | $ | (45) |  |


## us-gaap:DebtDisclosureTextBlock

[0001137789-22-000123:notes:45]
Debt
The following table provides details of the Company’s debt as of September 30, 2022 and July 1, 2022:

[0001137789-22-000123:notes:46]
| (Dollars in millions) |  | September 30,2022 |  | July 1,2022 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | $ | 540 |  |  | $ | 540 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 468 |  |  | 466 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 600 |  |  | 600 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | 600 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | — |  |
|  |  | 6,279 |  |  | 5,677 |  |
| Less: unamortized debt issuance costs |  | (30) |  |  | (31) |  |
| Debt, net of debt issuance costs |  | 6,249 |  |  | 5,646 |  |
| Less: current portion of long-term debt |  | (636) |  |  | (584) |  |
| Long-term debt, less current portion |  | $ | 5,613 |  |  | $ | 5,062 |  |

[0001137789-22-000123:notes:47]
__________________________________

[0001137789-22-000123:notes:48]
(1) All unsecured senior notes are issued by Seagate HDD Cayman, and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and, pursuant to a supplemental indenture dated as of May 18, 2021, STX.

[0001137789-22-000123:notes:49]
Credit Agreement

[0001137789-22-000123:notes:50]
The Company’s subsidiary, Seagate HDD Cayman, has a credit agreement, which was most recently amended on August 18, 2022 (the “Credit Agreement”).

[0001137789-22-000123:notes:51]
Prior to the August 18, 2022 amendment, the Credit Agreement provided a term loan facility in an aggregate principal amount of $1.2 billion that was extended in two tranches of $600 million each for Term Loans A1 and A2 and a $1.75 billion senior unsecured revolving credit facility (“Revolving Credit Facility”). Term Loans A1 and A2 were drawn in full on October 14, 2021.

[0001137789-22-000123:notes:52]
On August 18, 2022, Seagate Technology Holdings plc and Seagate HDD Cayman (the “Borrower”) entered into an amendment to the Credit Agreement (the “Sixth Amendment”), which provides for a new term loan facility in the aggregate principal amount of $600 million (“Term Loan A3”). Term Loan A3 was borrowed in full at the closing of the Sixth Amendment. Term Loan A3 bears interest at a rate of SOFR plus a variable margin of 1.25% to 2.5%, in each case with such margin being determined based on the corporate credit rating of the Borrower or one of its parent entities. Term Loan A3 is repayable in quarterly installments beginning on December 31, 2022 and is scheduled to mature on July 30, 2027.

[0001137789-22-000123:notes:53]
The Sixth Amendment to the Credit Agreement also replaced the LIBOR interest rates plus variable margin for the Term Loans A1 and A2 with the SOFR interest rates plus a variable margin that will be determined based on the corporate credit rating of the Borrower or one of its parent entities. The Sixth Amendment also permits the Borrower to increase the revolving loan commitments or obtain new term loans of up to $100 million in aggregate, subject to the satisfaction of certain terms and conditions.

[0001137789-22-000123:notes:54]
STX and certain of its material subsidiaries, including STUC, fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loans A1, A2 and A3 (the “Term Loans”).

[0001137789-22-000123:notes:55]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of September 30, 2022. As of September 30, 2022, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility.

[0001137789-22-000123:notes:56]
Future Principal Payments on Long-term Debt

[0001137789-22-000123:notes:57]
At September 30, 2022, future principal payments on long-term debt were as follows (in millions):

[0001137789-22-000123:notes:58]
| Fiscal Year |  | Amount |
| Remainder of 2023 |  | $ | 608 |  |
| 2024 |  | 614 |  |
| 2025 |  | 627 |  |
| 2026 |  | 629 |  |
| 2027 |  | 649 |  |
| Thereafter |  | 3,188 |  |
| Total |  | $ | 6,315 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001137789-22-000123:notes:59]
Income Taxes
The Company recorded an income tax benefit of $2 million for the three months ended September 30, 2022. The income tax benefit included approximately $7 million of net discrete tax benefit, primarily associated with the excess tax benefits related to share-based compensation expense.

[0001137789-22-000123:notes:60]
During the three months ended September 30, 2022, the Company’s unrecognized tax benefits excluding interest and penalties increased by approximately $1 million to $115 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. The Company is not expecting material changes to its unrecognized tax benefits in the next twelve months beginning October 1, 2022.

[0001137789-22-000123:notes:61]
The Company’s income tax provision of $7 million for the three months ended October 1, 2021 included approximately $10 million of net discrete tax benefit, primarily associated with net excess tax benefits related to share-based compensation expense.

[0001137789-22-000123:notes:62]
The Company’s income tax provision recorded for the three months ended September 30, 2022 and October 1, 2021 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001137789-22-000123:notes:63]
Restructuring and Exit Costs
 The Company recorded restructuring charges of $9 million and $1 million, for the three months ended September 30, 2022 and October 1, 2021 respectively. The Company’s restructuring plans are comprised primarily of charges related to workforce reduction costs and facilities and other exit costs. All restructuring charges are reported in Restructuring and other, net on the Company’s Condensed Consolidated Statements of Operations.

[0001137789-22-000123:notes:64]
[same as prior period, unchanged from 0001137789-22-000031:notes:67]

[0001137789-22-000123:notes:65]
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at July 1, 2022 |  | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |
| Restructuring charges |  | 9 |  |  | — |  |  | 9 |  |
| Cash payments |  | (3) |  |  | (1) |  |  | (4) |  |
| Accrual balances at September 30, 2022 |  | $ | 6 |  |  | $ | 4 |  |  | $ | 10 |  |
| Total costs incurred inception to date as of September 30, 2022 |  | $ | 72 |  |  | $ | 24 |  |  | $ | 96 |  |
| Total expected charges to be incurred as of September 30, 2022 |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |

[0001137789-22-000123:notes:66]
On October 24, 2022, the Company’s Board of Directors approved and committed to an October 2022 restructuring plan (the “October 2022 Plan”) to reduce its cost structure to better align the Company’s operational needs to current economic conditions while continuing to support the long-term business strategy. The October 2022 Plan includes reducing its worldwide headcount by approximately 3,000 employees, or 8% of the global workforce, along with other cost saving measures.

[0001137789-22-000123:notes:67]
The October 2022 Plan, which the Company expects to be substantially completed by the end of the fiscal second quarter 2023, is expected to result in total pre-tax charges between $60 million and $70 million. These charges are expected to be primarily cash-based and consist of employee severance and other one-time termination benefits.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001137789-22-000123:notes:68]
Derivative Financial InstrumentsThe Company is exposed to foreign currency exchange rate, interest rate and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies.
The Company enters into certain interest rate swap agreements to convert the variable interest rate on its Term Loans to fixed interest rates. The objective of the interest rate swap agreements is to eliminate the variability of interest payment cash flows associated with the variable interest rate under the Term Loans. The Company designates the interest rate swaps as cash flow hedges. On September 26, 2022, the Company terminated its then existing interest rate swap agreements related to Term Loans A1 and A2 and received cash proceeds of $110 million from the counterparty. The cash proceeds are reported within Net cash provided by operating activities in the Company’s Condensed Consolidated Statement of Cash Flows. The Company discontinued the related hedge accounting prospectively and as a result the realized gain of $110 million continues to be reported in AOCI and is amortized to Interest expense in the Condensed Consolidated Statement of Operations over the remaining period of the Term Loans A1 and A2.

[0001137789-22-000123:notes:69]
During the quarter ended September 30, 2022, the Company entered into new interest rate swap agreements with a notional amount of $1.6 billion, to convert the variable interest rate on certain principal amounts of the Term Loans drawn under its Credit Agreement, of which $600 million will mature in September 2025 and $1.0 billion will mature in July 2027.

[0001137789-22-000123:notes:70]
The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives on its Condensed Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in AOCI until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The amount of net unrealized loss on cash flow hedges was $23 million and net unrealized gain was $51 million as of September 30, 2022 and as of July 1, 2022, respectively. As of September 30, 2022, the amount of existing net gains related to cash flow hedges recorded in AOCI included a net loss of $3 million that is expected to be reclassified to earnings within twelve months.

[0001137789-22-000123:notes:71]
The Company de-designates its cash flow hedges when the forecasted hedged transactions affect earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in AOCI on the Company’s Condensed Consolidated Balance Sheets are reclassified into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company recognized a net loss of $7 million and gain of $2 million in Cost of revenue and Interest expense, respectively, related to the gain and loss of hedge designation on discontinued cash flow hedges during the three months ended September 30, 2022. The Company recognized a net loss of $2 million and $1 million in Cost of revenue and Interest expense, respectively, related to the loss of hedge designation on discontinued cash flow hedges during the three months ended October 1, 2021.

[0001137789-22-000123:notes:72]
Other derivatives not designated as hedging instruments consist of foreign currency forward exchange contracts that the Company uses to hedge the foreign currency exposure on forecasted expenditures denominated in currencies other than the U.S. dollar. The Company also enters into foreign currency forward contracts with contractual maturities of less than one month, which are designed to mitigate the effect of changes in foreign exchange rates on monetary assets and liabilities. The Company recognizes gains and losses on these contracts, as well as the related costs in Other, net on its Condensed Consolidated Statements of Operations.

[0001137789-22-000123:notes:73]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of September 30, 2022 and July 1, 2022. All of the foreign currency forward exchange contracts mature within 12 months.

[0001137789-22-000123:notes:74]
|  |  | As of September 30, 2022 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Singapore Dollar |  | $ | 171 |  |  | $ | 72 |  |
| Thai Baht |  | 132 |  |  | 47 |  |
| Chinese Renminbi |  | 89 |  |  | 30 |  |
| British Pound Sterling |  | 61 |  |  | 24 |  |
| Total |  | $ | 453 |  |  | $ | 173 |  |

[0001137789-22-000123:notes:75]
|  |  | As of July 1, 2022 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Singapore Dollar |  | $ | 178 |  |  | $ | 52 |  |
| Thai Baht |  | 133 |  |  | 35 |  |
| Chinese Renminbi |  | 92 |  |  | 24 |  |
| British Pound Sterling |  | 64 |  |  | 15 |  |
| Total |  | $ | 467 |  |  | $ | 126 |  |

[0001137789-22-000123:notes:76]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its non-qualified deferred compensation plan: the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP’s liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP’s liabilities due to changes in the value of the investment options made by employees. As of September 30, 2022, the notional investments underlying the TRS amounted to $98 million and the contract term is through January 2023, settled on a monthly basis, limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP’s liabilities.

[0001137789-22-000123:notes:77]
The following tables show the Company’s derivative instruments measured at gross fair value as reflected in the Condensed Consolidated Balance Sheets as of September 30, 2022 and July 1, 2022:

[0001137789-22-000123:notes:78]
|  |  | As of September 30, 2022 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance Sheet Location |  | Fair Value |  | Balance Sheet Location |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (29) |  |
| Interest rate swap |  | Other current assets |  | 9 |  |  | Accrued expenses |  | (3) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | — |  |  | Accrued expenses |  | (11) |  |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | (11) |  |
| Total derivatives |  |  |  | $ | 9 |  |  |  |  | $ | (54) |  |

[0001137789-22-000123:notes:79]
|  |  | As of July 1, 2022 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance Sheet Location |  | Fair Value |  | Balance Sheet Location |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (14) |  |
| Interest rate swap |  | Other current assets |  | 65 |  |  | Accrued expenses |  | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | — |  |  | Accrued expenses |  | (5) |  |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | (4) |  |
| Total derivatives |  |  |  | $ | 65 |  |  |  |  | $ | (23) |  |

[0001137789-22-000123:notes:80]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three months ended September 30, 2022:

[0001137789-22-000123:notes:81]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |  |  |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (10) |  |  |  |
| Total return swap |  | Operating expenses |  | (8) |  |  |  |

[0001137789-22-000123:notes:82]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  |  |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  |  |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  |  |
| Foreign currency forward exchange contracts |  | $ | (20) |  |  |  |  | Cost of revenue |  | $ | (7) |  |  |  |  | Other, net |  | $ | (1) |  |  |  |
| Interest rate swap |  | 52 |  |  |  |  | Interest expense |  | 2 |  |  |  |  | Interest expense |  | — |  |  |  |

[0001137789-22-000123:notes:83]
The following table shows the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three months ended October 1, 2021:

[0001137789-22-000123:notes:84]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |  |  |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (4) |  |  |  |
| Total return swap |  | Operating expenses |  | (1) |  |  |  |

[0001137789-22-000123:notes:85]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  |  |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  |  |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
| Foreign currency forward exchange contracts |  | $ | (9) |  |  |  |  | Cost of revenue |  | $ | (2) |  |  |  |  | Other, net |  | $ | 1 |  |
| Interest rate swap |  | — |  |  |  |  | Interest expense |  | (1) |  |  |  |  | Interest expense |  | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001137789-22-000123:notes:86]
[same as prior period, unchanged from 0001137789-22-000031:notes:87]

[0001137789-22-000123:notes:87]
[same as prior period, unchanged from 0001137789-22-000031:notes:88]

[0001137789-22-000123:notes:88]
[same as prior period, unchanged from 0001137789-22-000031:notes:89]

[0001137789-22-000123:notes:89]
[same as prior period, unchanged from 0001137789-22-000031:notes:90]

[0001137789-22-000123:notes:90]
Level 1 - Quoted prices in active markets that are unadjusted and accessible at the measurement date for identical, unrestricted assets or liabilities;

[0001137789-22-000123:notes:91]
Level 2 - Quoted prices for identical assets and liabilities in markets that are inactive; quoted prices for similar assets and liabilities in active markets or financial instruments for which significant inputs are observable, either directly or indirectly; or

[0001137789-22-000123:notes:92]
Level 3 - Prices or valuations that require inputs that are both unobservable and significant to the fair value measurement.

[0001137789-22-000123:notes:93]
[same as prior period, unchanged from 0001137789-22-000031:notes:94]

[0001137789-22-000123:notes:94]
[same as prior period, unchanged from 0001137789-22-000031:notes:95]

[0001137789-22-000123:notes:95]
[same as prior period, unchanged from 0001137789-22-000031:notes:96]

[0001137789-22-000123:notes:96]
|  |  | September 30, 2022 |  | July 1, 2022 |
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 158 |  |  | $ | — |  |  | $ | — |  |  | $ | 158 |  |  | $ | 59 |  |  | $ | — |  |  | $ | — |  |  | $ | 59 |  |
| Total cash equivalents |  | 158 |  |  | — |  |  | — |  |  | 158 |  |  | 59 |  |  | — |  |  | — |  |  | 59 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | — |  |  | — |  |  | 16 |  |  | 16 |  |  | — |  |  | — |  |  | 23 |  |  | 23 |  |
| Derivative assets |  | — |  |  | 9 |  |  | — |  |  | 9 |  |  | — |  |  | 65 |  |  | — |  |  | 65 |  |
| Total assets |  | $ | 159 |  |  | $ | 10 |  |  | $ | 16 |  |  | $ | 185 |  |  | $ | 60 |  |  | $ | 66 |  |  | $ | 23 |  |  | $ | 149 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |
| Total liabilities |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |

[0001137789-22-000123:notes:97]
|  |  | September 30, 2022 |  | July 1, 2022 |
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 158 |  |  | $ | — |  |  | $ | — |  |  | $ | 158 |  |  | $ | 59 |  |  | $ | — |  |  | $ | — |  |  | $ | 59 |  |
| Other current assets |  | 1 |  |  | 10 |  |  | — |  |  | 11 |  |  | 1 |  |  | 66 |  |  | — |  |  | 67 |  |
| Other assets, net |  | — |  |  | — |  |  | 16 |  |  | 16 |  |  | — |  |  | — |  |  | 23 |  |  | 23 |  |
| Total assets |  | $ | 159 |  |  | $ | 10 |  |  | $ | 16 |  |  | $ | 185 |  |  | $ | 60 |  |  | $ | 66 |  |  | $ | 23 |  |  | $ | 149 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |
| Total liabilities |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |

[0001137789-22-000123:notes:98]
[same as prior period, unchanged from 0001137789-22-000031:notes:99]

[0001137789-22-000123:notes:99]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair value of all of its cash equivalents. For the cash equivalents in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry-standard data providers or other third-party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of September 30, 2022, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts, interest rate swaps and the TRS. The Company recognizes derivative financial instruments in its condensed consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001137789-22-000123:notes:100]
[same as prior period, unchanged from 0001137789-22-000031:notes:101]

[0001137789-22-000123:notes:101]
[same as prior period, unchanged from 0001137789-22-000031:notes:102]

[0001137789-22-000123:notes:102]
For the investments that are accounted for under the equity method, the Company recorded a net loss of $3 million and gain of $3 million for the three months ended September 30, 2022 and October 1, 2021, respectively. The adjusted carrying value of the investments accounted for under the equity method amounted to $58 million and $61 million as of September 30, 2022 and July 1, 2022, respectively.

[0001137789-22-000123:notes:103]
For the investments that are accounted for under the measurement alternative, the Company recorded $3 million of net gains, which remains unrealized, for the three months ended September 30, 2022, related to upward adjustments due to observable price changes. The Company recorded a net gain of $6 million for the three months ended October 1, 2021, of which $5 million is unrealized as of October 1, 2021, related to upward adjustments due to observable price changes. As of September 30, 2022 and July 1, 2022, the carrying value of the Company’s strategic investments under the measurement alternative was $99 million and $88 million, respectively.

[0001137789-22-000123:notes:104]
[same as prior period, unchanged from 0001137789-22-000031:notes:105]

[0001137789-22-000123:notes:105]
[same as prior period, unchanged from 0001137789-22-000031:notes:106]

[0001137789-22-000123:notes:106]
|  |  | September 30, 2022 |  | July 1, 2022 |
| (Dollars in millions) |  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 4.750% Senior Notes due June 2023 |  | $ | 540 |  |  | $ | 537 |  |  | $ | 540 |  |  | $ | 538 |  |
| 4.875% Senior Notes due March 2024 |  | 499 |  |  | 489 |  |  | 499 |  |  | 494 |  |
| 4.750% Senior Notes due January 2025 |  | 479 |  |  | 457 |  |  | 479 |  |  | 471 |  |
| 4.875% Senior Notes due June 2027 |  | 504 |  |  | 457 |  |  | 504 |  |  | 483 |  |
| 4.091% Senior Notes due June 2029 |  | 468 |  |  | 396 |  |  | 466 |  |  | 427 |  |
| 3.125% Senior Notes due July 2029 |  | 500 |  |  | 368 |  |  | 500 |  |  | 396 |  |
| 4.125% Senior Notes due January 2031 |  | 500 |  |  | 375 |  |  | 500 |  |  | 410 |  |
| 3.375% Senior Notes due July 2031 |  | 500 |  |  | 350 |  |  | 500 |  |  | 393 |  |
| 5.750% Senior Notes due December 2034 |  | 489 |  |  | 386 |  |  | 489 |  |  | 433 |  |
| SOFR Based Term Loan A1 due September 2025 (1) |  | 600 |  |  | 589 |  |  | 600 |  |  | 588 |  |
| SOFR Based Term Loan A2 due July 2027 (1) |  | 600 |  |  | 581 |  |  | 600 |  |  | 586 |  |
| SOFR Based Term Loan A3 due July 2027 |  | 600 |  |  | 584 |  |  | — |  |  | — |  |
|  |  | $ | 6,279 |  |  | $ | 5,569 |  |  | $ | 5,677 |  |  | $ | 5,219 |  |
| Less: unamortized debt issuance costs |  | (30) |  |  | — |  |  | (31) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 6,249 |  |  | $ | 5,569 |  |  | $ | 5,646 |  |  | $ | 5,219 |  |
| Less: current portion of debt, net of debt issuance costs |  | (636) |  |  | (630) |  |  | (584) |  |  | (582) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,613 |  |  | $ | 4,939 |  |  | $ | 5,062 |  |  | $ | 4,637 |  |

[0001137789-22-000123:notes:107]
_________________________________

[0001137789-22-000123:notes:108]
(1) On August 18, 2022, the Sixth Amendment to the Credit Agreement replaced the LIBOR interest rates plus variable margin of Term Loans A1 and A2 with the SOFR interest rates plus a variable margin. Refer to “Note 3. Debt” for more details.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001137789-22-000123:notes:109]
Shareholders’ Deficit
Share Capital

[0001137789-22-000123:notes:110]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 206,434,139 shares were outstanding as of September 30, 2022, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of September 30, 2022.

[0001137789-22-000123:notes:111]
Ordinary shares - Holders of ordinary shares are entitled to receive dividends when and as declared by the Company’s board of directors (the “Board of Directors”). Upon any liquidation, dissolution, or winding up of the Company, after required payments are made to holders of preferred shares, any remaining assets of the Company will be distributed ratably to holders of the preferred and ordinary shares. Holders of shares are entitled to one vote per share on all matters upon which the ordinary shares are entitled to vote, including the election of directors.

[0001137789-22-000123:notes:112]
Preferred shares - The Company may issue preferred shares in one or more series, up to the authorized amount, without shareholder approval. The Board of Directors is authorized to establish from time to time the number of shares to be included in each series, and to fix the rights, preferences and privileges of the shares of each wholly unissued series and any of its qualifications, limitations or restrictions. The Board of Directors can also increase or decrease the number of shares of a series, but not below the number of shares of that series then outstanding, without any further vote or action by the shareholders.

[0001137789-22-000123:notes:113]
[same as prior period, unchanged from 0001137789-22-000031:notes:112]

[0001137789-22-000123:notes:114]
[same as prior period, unchanged from 0001137789-22-000031:notes:113]

[0001137789-22-000123:notes:115]
[same as prior period, unchanged from 0001137789-22-000031:notes:114]

[0001137789-22-000123:notes:116]
As of September 30, 2022, $1.9 billion remained available for repurchase under the existing repurchase authorization limit.

[0001137789-22-000123:notes:117]
The following table sets forth information with respect to repurchases of the Company’s ordinary shares during the three months ended September 30, 2022:

[0001137789-22-000123:notes:118]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Repurchases of ordinary shares (1) |  | 5 |  |  | $ | 400 |  |
| Tax withholding related to vesting of equity awards |  | 1 |  |  | 39 |  |
| Total |  | 6 |  |  | $ | 439 |  |

[0001137789-22-000123:notes:119]
[same as prior period, unchanged from 0001137789-22-000031:notes:118]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001137789-22-000123:notes:120]
[same as prior period, unchanged from 0001137789-22-000031:notes:119]

[0001137789-22-000123:notes:121]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 30,2022 |  | October 1,2021 |
| Revenues by Channel |  |  |  |  |
| OEMs |  | $ | 1,545 |  |  | $ | 2,288 |  |
| Distributors |  | 299 |  |  | 507 |  |
| Retailers |  | 191 |  |  | 320 |  |
| Total |  | $ | 2,035 |  |  | $ | 3,115 |  |
| Revenues by Geography (1) |  |  |  |  |
| Asia Pacific |  | $ | 801 |  |  | $ | 1,583 |  |
| Americas |  | 936 |  |  | 1,079 |  |
| EMEA |  | 298 |  |  | 453 |  |
| Total |  | $ | 2,035 |  |  | $ | 3,115 |  |

[0001137789-22-000123:notes:122]
[same as prior period, unchanged from 0001137789-22-000031:notes:121]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001137789-22-000123:notes:123]
[same as prior period, unchanged from 0001137789-22-000031:notes:122]

[0001137789-22-000123:notes:124]
[same as prior period, unchanged from 0001137789-22-000031:notes:123]

[0001137789-22-000123:notes:125]
[same as prior period, unchanged from 0001137789-22-000031:notes:124]

[0001137789-22-000123:notes:126]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product warranty return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the three months ended September 30, 2022 and October 1, 2021 were as follows:

[0001137789-22-000123:notes:127]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 30,2022 |  | October 1,2021 |
| Balance, beginning of period |  | $ | 148 |  |  | $ | 136 |  |
| Warranties issued |  | 13 |  |  | 21 |  |
| Repairs and replacements |  | (24) |  |  | (23) |  |
| Changes in liability for pre-existing warranties, including expirations |  | 12 |  |  | 6 |  |
| Balance, end of period |  | $ | 149 |  |  | $ | 140 |  |


## us-gaap:EarningsPerShareTextBlock

[0001137789-22-000123:notes:128]
Earnings Per Share
Basic earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period. Diluted earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period and the number of additional shares that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding options, unvested restricted share units and performance-based share units and shares to be purchased under the Employee Stock Purchase Plan. The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in fair market value of the Company’s share price can result in a greater dilutive effect from potentially dilutive securities. The following table sets forth the computation of basic and diluted net income per share attributable to the shareholders of the Company:

[0001137789-22-000123:notes:129]
|  |  | For the Three Months Ended |  |  |
| (In millions, except per share data) |  | September 30,2022 |  | October 1,2021 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 29 |  |  | $ | 526 |  |  |  |  |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 208 |  |  | 226 |  |  |  |  |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | 2 |  |  | 5 |  |  |  |  |  |
| Total shares for purposes of calculating diluted net income per share |  | 210 |  |  | 231 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.14 |  |  | $ | 2.33 |  |  |  |  |  |
| Diluted |  | $ | 0.14 |  |  | $ | 2.28 |  |  |  |  |  |

[0001137789-22-000123:notes:130]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share were not material for the three months ended September 30, 2022 and October 1, 2021.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001137789-22-000123:notes:131]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001137789-22-000123:notes:132]
Litigation

[0001137789-22-000123:notes:133]
Lambeth Magnetic Structures LLC, v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods”. The complaint seeks damages as well as additional relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial began on April 4, 2022. On April 14, 2022, the jury returned a verdict of non-infringement for Seagate finding that Seagate had not infringed any of the asserted claims. The district court entered judgement in favor of Seagate on April 19, 2022. The parties filed post-trial motions with the district court in May 2022. The court has not yet set a hearing date for these motions.

[0001137789-22-000123:notes:134]
Seagate Technology LLC, et al. v. Headway Technologies, Inc, et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the United States District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, as well as additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 1, 2022, the Seagate Entities and TDK filed a Stipulation for Dismissal with Prejudice to dismiss with prejudice all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment Regarding Foreign Commerce and on October 14, 2022, Seagate Entities’ filed its corresponding opposition. A trial date has not been set.

[0001137789-22-000123:notes:135]
Environmental Matters

[0001137789-22-000123:notes:136]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001137789-22-000123:notes:137]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001137789-22-000123:notes:138]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001137789-22-000123:notes:139]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001137789-22-000123:notes:140]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the U.S., Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001137789-22-000123:notes:141]
Other Matters

[0001137789-22-000123:notes:142]
On August 29, 2022, the Company received a proposed charging letter (“PCL”) from the U.S. Commerce Department’s Bureau of Industry and Security (“BIS”), alleging violations of the U.S. Export Administration Regulations (“EAR”). The PCL alleges the Company acted in violation of the EAR by providing its HDDs to a customer and its affiliates listed on the BIS Entity List between August 2020 and September 2021. The Company believes these allegations are without merit and will defend itself vigorously. The Company has responded to the PCL, setting forth its position that it did not engage in prohibited conduct as alleged by BIS, because, among other reasons, Seagate’s HDDs are not subject to the EAR.

[0001137789-22-000123:notes:143]
The matters raised by the PCL remain unresolved at this time, and there can be no assurance as to the timing or terms of any final outcome. The Company is unable at this time to estimate the range of loss and/or penalty, if any, although it is possible that the outcome could have a material impact on its business, results of operations, financial condition, and cash flows. The Company believes that it has complied with all relevant export control laws and regulations. The Company has committed to compliance through its global team of international trade compliance and legal professionals and by maintaining robust trade controls, compliance policies and procedures. The Company has been cooperating with BIS and intends to continue to engage with BIS to seek a resolution of this matter.

[0001137789-22-000123:notes:144]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:SubsequentEventsTextBlock

[0001137789-22-000123:notes:145]
Subsequent Events
Dividend Declared

[0001137789-22-000123:notes:146]
On October 26, 2022, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on January 5, 2023 to shareholders of record as of the close of business on December 21, 2022.

[0001137789-22-000123:notes:147]
Restructuring Plan

[0001137789-22-000123:notes:148]
On October 24, 2022, the Company’s Board of Directors approved and committed to a plan to reduce its cost structure to better align the Company’s operational needs to current economic conditions while continuing to support the long-term business strategy. See “Note 5. Restructuring and Exit Costs” for more information.
