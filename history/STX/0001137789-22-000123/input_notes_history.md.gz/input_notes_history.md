# STX note change history — 0001137789-22-000031 → 0001137789-22-000123


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2022-10-27):
[0001137789-22-000123:note_history:1]
Lambeth Magnetic Structures LLC, v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods”. The complaint seeks damages as well as additional relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial began on April 4, 2022. On April 14, 2022, the jury returned a verdict of non-infringement for Seagate finding that Seagate had not infringed any of the asserted claims. The district court entered judgement in favor of Seagate on April 19, 2022. The parties filed post-trial motions with the district court in May 2022. The court has not yet set a hearing date for these motions.

- changed (2022-10-27):
[0001137789-22-000123:note_history:2]
Seagate Technology LLC, et al. v. Headway Technologies, Inc, et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the United States District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, as well as additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 1, 2022, the Seagate Entities and TDK filed a Stipulation for Dismissal with Prejudice to dismiss with prejudice all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment Regarding Foreign Commerce and on October 14, 2022, Seagate Entities’ filed its corresponding opposition. A trial date has not been set.
  (was, 2022-04-28, similarity 0.8401):
[0001137789-22-000031:note_history:2]
Seagate Technology LLC, et al. v. NHK Spring Co. Ltd. and TDK Corporation, et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the United States District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc., and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, as well as additional relief permitted by law. On March 22, 2022, Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) and the Seagate Entities entered into a commercial arrangement and release of claims (“TDK Agreement”) to fully resolve the global disputes between the Seagate Entities and TDK relating to the antitrust law claims, breach of contract claim, and other matters described in the complaint. On April 1, 2022, the Seagate Entities and TDK filed a Stipulation for Dismissal with Prejudice to dismiss with prejudice all claims against TDK.

- changed (2022-10-27):
[0001137789-22-000123:note_history:3]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the U.S., Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.
  (was, 2022-04-28, similarity 0.9995):
[0001137789-22-000031:note_history:3]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the U.S., Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

- added (2022-10-27):
[0001137789-22-000123:note_history:4]
On August 29, 2022, the Company received a proposed charging letter (“PCL”) from the U.S. Commerce Department’s Bureau of Industry and Security (“BIS”), alleging violations of the U.S. Export Administration Regulations (“EAR”). The PCL alleges the Company acted in violation of the EAR by providing its HDDs to a customer and its affiliates listed on the BIS Entity List between August 2020 and September 2021. The Company believes these allegations are without merit and will defend itself vigorously. The Company has responded to the PCL, setting forth its position that it did not engage in prohibited conduct as alleged by BIS, because, among other reasons, Seagate’s HDDs are not subject to the EAR.

- added (2022-10-27):
[0001137789-22-000123:note_history:5]
The matters raised by the PCL remain unresolved at this time, and there can be no assurance as to the timing or terms of any final outcome. The Company is unable at this time to estimate the range of loss and/or penalty, if any, although it is possible that the outcome could have a material impact on its business, results of operations, financial condition, and cash flows. The Company believes that it has complied with all relevant export control laws and regulations. The Company has committed to compliance through its global team of international trade compliance and legal professionals and by maintaining robust trade controls, compliance policies and procedures. The Company has been cooperating with BIS and intends to continue to engage with BIS to seek a resolution of this matter.

- removed (2022-10-27):
[0001137789-22-000031:note_history:6]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods”. The complaint seeks damages as well as additional relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial began on April 4, 2022. On April 14, 2022, the jury returned a verdict of non-infringement for Seagate finding that Seagate had not infringed any of the asserted claims. The district court entered judgment in favor of Seagate on April 19, 2022.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001137789-22-000123:note_history:7]
Seagate Technology Holdings plc (“STX”) and its subsidiaries (collectively, unless the context otherwise indicates, the “Company”) is a leading provider of data storage technology and infrastructure solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”), solid state hybrid drives (“SSHDs”), storage subsystems, as well as a scalable edge-to-cloud mass data platform that includes data transfer shuttles and a storage-as-a-service cloud.
  (was, 2022-04-28, similarity 0.9877):
[0001137789-22-000031:note_history:7]
Seagate Technology Holdings plc (“STX”) and its subsidiaries (collectively, unless the context otherwise indicates, the “Company”) is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”), solid state hybrid drives (“SSHDs”), storage subsystems, as well as a scalable edge-to-cloud mass data platform that includes data transfer shuttles and a storage-as-a-service cloud.

- changed (2022-10-27):
[0001137789-22-000123:note_history:8]
HDDs are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. HDDs continue to be the primary medium of mass data storage due to their performance attributes, reliability, high capacities, superior quality and cost effectiveness. Complementing existing storage architectures, SSDs use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory. In contrast to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high-capacity HDD and a smaller SSD acting as a cache to improve performance.
  (was, 2022-04-28, similarity 0.9771):
[0001137789-22-000031:note_history:8]
HDDs are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. HDDs continue to be the primary medium of mass data storage due to their performance attributes, reliability, high capacities, superior quality and cost effectiveness. Complementing existing storage architectures, SSDs use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory. In contrast to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high-capacity HDD and a smaller SSD acting as a cache to improve performance of frequently accessed data.

- changed (2022-10-27):
[0001137789-22-000123:note_history:9]
The Company’s HDD products are designed for mass capacity storage and legacy markets. Mass capacity storage involves well-established use cases—such as hyperscale data centers and public clouds as well as emerging use cases. Legacy markets include markets the Company continues to sell to but that it does not plan to invest in significantly. The Company’s HDD and SSD product portfolio includes Serial Advanced Technology Attachment, Serial Attached SCSI and Non-Volatile Memory Express based designs to support a wide variety of mass capacity and legacy applications.
  (was, 2022-04-28, similarity 0.9912):
[0001137789-22-000031:note_history:9]
The Company’s HDD products are designed for mass capacity storage and legacy markets. Mass capacity storage involves well-established use cases—such as hyperscale data centers and public clouds as well as emerging use cases. Legacy markets include markets the Company continues to service but that it does not plan to invest in significantly. The Company’s HDD and SSD product portfolio includes Serial Advanced Technology Attachment, Serial Attached SCSI and Non-Volatile Memory Express based designs to support a wide variety of mass capacity and legacy applications.

- changed (2022-10-27):
[0001137789-22-000123:note_history:10]
The Company’s systems portfolio includes storage subsystems for enterprises, cloud service providers, scale-out storage servers and original equipment manufacturers (“OEMs”). Engineered for modularity, mobility, capacity and performance, these solutions include the Company’s enterprise HDDs and SSDs, enabling customers to integrate powerful, scalable storage within existing environments or create new ecosystems from the ground up in a secure, cost-effective manner.
  (was, 2022-04-28, similarity 0.9722):
[0001137789-22-000031:note_history:10]
The Company’s system portfolio includes storage subsystems for enterprises, cloud service providers, scale-out storage servers and original equipment manufacturers (“OEMs”). Engineered for modularity, mobility, capacity and performance, these solutions include the Company’s enterprise HDDs and SSDs, enabling customers to integrate powerful, scalable storage within legacy environments or build new ecosystems from the ground up in a secure, cost-effective manner.

- changed (2022-10-27):
[0001137789-22-000123:note_history:11]
The Company’s Lyve portfolio provides a simple, cost-efficient and secure way to manage massive volumes of data across the distributed enterprise. The Lyve platform includes a shuttle solution that enables enterprises to transfer massive amounts of data from endpoints to the core cloud, a storage-as-a-service cloud offering that provides frictionless mass capacity storage at the metro edge.
  (was, 2022-04-28, similarity 0.7781):
[0001137789-22-000031:note_history:11]
The Company’s Lyve portfolio provides a simple, cost-efficient and secure way to manage massive volumes of data across the distributed enterprise. The Lyve platform includes a shuttle solution that enables enterprises to transfer massive amounts of data from endpoints to the core cloud, a storage-as-a-service cloud that provides frictionless mass capacity storage at the metro edge, a converged object storage solution enabling efficient capture and consolidation of massive data sets and Cortx, an open-source object storage software optimized for mass capacity and data intensive workloads.

- changed (2022-10-27):
[0001137789-22-000123:note_history:12]
The Company’s consolidated financial statements for the fiscal year ended July 1, 2022 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 5, 2022. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 1, 2022, and the notes thereto, are adequate to make the information presented not misleading. The results of operations and the cash flows for the three months ended September 30, 2022 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 30, 2023.
  (was, 2022-04-28, similarity 0.856):
[0001137789-22-000031:note_history:12]
The Company’s consolidated financial statements for the fiscal year ended July 2, 2021 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 6, 2021. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 2, 2021, and the notes thereto, are adequate to make the information presented not misleading. The results of operations and the cash flows for the three and nine months ended April 1, 2022 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending July 1, 2022.

- added (2022-10-27):
[0001137789-22-000123:note_history:13]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three months ended September 30, 2022 and October 1, 2021 consisted of 13 weeks. Fiscal years 2023 and 2022 both comprise of 52 weeks and end on June 30, 2023 and July 1, 2022, respectively. The fiscal quarters ended September 30, 2022, July 1, 2022 and October 1, 2021, are also referred to herein as the “September 2022 quarter”, the “June 2022 quarter” and the “September 2021 quarter”, respectively.

- added (2022-10-27):
[0001137789-22-000123:note_history:14]
In March 2020, the Financial Accounting Standards Board (“FASB”) issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. The Company adopted the guidance in the quarter ended September 30, 2022 on a prospective basis and is transitioning from an interest rate based on London Interbank Offered Rate (“LIBOR”) to Secured Overnight Financing Rate (“SOFR”). The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.

- changed (2022-10-27):
[0001137789-22-000123:note_history:15]
In November 2021, the FASB issued ASU 2021-10 (ASC Topic 832), Disclosures by Business Entities about Government Assistance. This ASU requires annual disclosures that increase the transparency of transactions involving government grants, including (1) the type of transactions, (2) the accounting for those transactions and (3) the effect of those transactions on an entity’s financial statements. The Company adopted the guidance in the quarter ended September 30, 2022.
  (was, 2022-04-28, similarity 0.7349):
[0001137789-22-000031:note_history:15]
In November 2021, the FASB issued ASU 2021-10 (ASC Topic 832), Disclosures by Business Entities about Government Assistance. This ASU requires annual disclosures that increase the transparency of transactions involving government grants, including (1) the type of transactions, (2) the accounting for those transactions and (3) the effect of those transactions on an entity’s financial statements. The Company is required to adopt this new accounting pronouncement in the first quarter of fiscal year 2023. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- added (2022-10-27):
[0001137789-22-000123:note_history:16]
In September 2022, the FASB issued ASU 2022-04 (ASC Subtopic 405-50), Disclosure of Supplier Finance Program Obligations. This ASU requires disclosure of key terms of the outstanding supplier finance programs and a rollforward of the related obligations. The Company is required to adopt this guidance in the first quarter of fiscal year 2024. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- added (2022-10-27):
[0001137789-22-000123:note_history:17]
In June 2022, the FASB issued ASU 2022-03 (ASC Topic 820), Fair Value Measurement of Equity Securities Subject to Contractual Sale Restrictions. This ASU clarifies that a contractual restriction on the sale of equity security is not considered when measuring its fair value and requires new disclosures for equity securities subject to contractual sale restriction. The Company is required to adopt this guidance in the first quarter of fiscal year 2025. The Company does not expect the adoption of this ASU to have a material impact on its condensed consolidated financial statements.

- removed (2022-10-27):
[0001137789-22-000031:note_history:18]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and nine months ended April 1, 2022 and the three and nine months ended April 2, 2021 consisted of 13 and 39 weeks, respectively. Fiscal year 2022, which ends on July 1, 2022 and fiscal year 2021, which ended on July 2, 2021, are both comprised of 52 weeks. The fiscal quarters ended April 1, 2022, December 31, 2021 and April 2, 2021, are also referred to herein as the “March 2022 quarter”, the “December 2021 quarter” and the “March 2021 quarter”, respectively.

- removed (2022-10-27):
[0001137789-22-000031:note_history:19]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued ASU 2019-12 (ASC Topic 740), Simplifying the Accounting for Income Taxes. This ASU simplifies accounting for income taxes by removing certain exceptions to the general principles and amending existing guidance to improve consistent application. This ASU became effective and the Company adopted the guidance in the quarter ended October 1, 2021. The adoption of this ASU did not have an impact on the Company’s condensed consolidated financial statements.

- removed (2022-10-27):
[0001137789-22-000031:note_history:20]
In July 2021, the FASB issued ASU 2021-05 (ASC Topic 842), Lessors—Certain Leases with Variable Lease Payments. This ASU requires lessors to classify and account for a lease with variable lease payments that do not depend on a reference index or a rate as an operating lease if the lease would have been classified as a sales-type lease or a direct financing lease and the lessor would have otherwise recognized a day-one loss. The Company adopted the guidance in the quarter ended October 1, 2021 on a prospective basis. The adoption of this ASU did not have an impact on the Company’s condensed consolidated financial statements.

- removed (2022-10-27):
[0001137789-22-000031:note_history:21]
In March 2020, the FASB issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. Adoption of the expedients and exceptions is permitted upon issuance of this update through December 31, 2022. The Company does not expect the adoption of this ASU to have a material impact on its condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001137789-22-000123:note_history:22]
Debt
The following table provides details of the Company’s debt as of September 30, 2022 and July 1, 2022:
  (was, 2022-04-28, similarity 0.9474):
[0001137789-22-000031:note_history:22]
Debt
The following table provides details of the Company’s debt as of April 1, 2022 and July 2, 2021:

- changed (2022-10-27):
[0001137789-22-000123:note_history:23]
| (Dollars in millions) |  | September 30,2022 |  | July 1,2022 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | $ | 540 |  |  | $ | 540 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 468 |  |  | 466 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 600 |  |  | 600 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | 600 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | — |  |
|  |  | 6,279 |  |  | 5,677 |  |
| Less: unamortized debt issuance costs |  | (30) |  |  | (31) |  |
| Debt, net of debt issuance costs |  | 6,249 |  |  | 5,646 |  |
| Less: current portion of long-term debt |  | (636) |  |  | (584) |  |
| Long-term debt, less current portion |  | $ | 5,613 |  |  | $ | 5,062 |  |
  (was, 2022-04-28, similarity 0.6712):
[0001137789-22-000031:note_history:23]
| (Dollars in millions) |  | April 1,2022 |  | July 2,2021 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $750 issued on February 3, 2017 at 4.25% due on March 1, 2022 (the “2022 Notes”), interest payable semi-annually on March 1 and September 1 of each year, fully repaid on February 1, 2022. |  | $ | — |  |  | $ | 220 |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 541 |  |  | 541 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 464 |  |  | 461 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 499 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loan |  |  |  |  |
| $600 borrowed on October 14, 2021 at London Interbank Offered Rate (“LIBOR”) plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 600 |  |  | — |  |
| $600 borrowed on October 14, 2021 at LIBOR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | — |  |
| $500 borrowed on September 17, 2019 at LIBOR, (the “September 2019 Term Loan”), repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with a final maturity date of September 16, 2025, fully repaid on October 14, 2021. |  | — |  |  | 481 |  |
|  |  | 5,676 |  |  | 5,173 |  |
| Less: unamortized debt issuance costs |  | (32) |  |  | (34) |  |
| Debt, net of debt issuance costs |  | 5,644 |  |  | 5,139 |  |
| Less: current portion of long-term debt |  | (30) |  |  | (245) |  |
| Long-term debt, less current portion |  | $ | 5,614 |  |  | $ | 4,894 |  |

- changed (2022-10-27):
[0001137789-22-000123:note_history:24]
__________________________________
  (was, 2022-04-28, similarity 0.9375):
[0001137789-22-000031:note_history:24]
______________________________

- changed (2022-10-27):
[0001137789-22-000123:note_history:25]
The Company’s subsidiary, Seagate HDD Cayman, has a credit agreement, which was most recently amended on August 18, 2022 (the “Credit Agreement”).
  (was, 2022-04-28, similarity 0.7251):
[0001137789-22-000031:note_history:25]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement on February 20, 2019, which was amended on September 16, 2019, January 13, 2021, May 18, 2021 and October 14, 2021 (the “Credit Agreement”).

- added (2022-10-27):
[0001137789-22-000123:note_history:26]
Prior to the August 18, 2022 amendment, the Credit Agreement provided a term loan facility in an aggregate principal amount of $1.2 billion that was extended in two tranches of $600 million each for Term Loans A1 and A2 and a $1.75 billion senior unsecured revolving credit facility (“Revolving Credit Facility”). Term Loans A1 and A2 were drawn in full on October 14, 2021.

- added (2022-10-27):
[0001137789-22-000123:note_history:27]
On August 18, 2022, Seagate Technology Holdings plc and Seagate HDD Cayman (the “Borrower”) entered into an amendment to the Credit Agreement (the “Sixth Amendment”), which provides for a new term loan facility in the aggregate principal amount of $600 million (“Term Loan A3”). Term Loan A3 was borrowed in full at the closing of the Sixth Amendment. Term Loan A3 bears interest at a rate of SOFR plus a variable margin of 1.25% to 2.5%, in each case with such margin being determined based on the corporate credit rating of the Borrower or one of its parent entities. Term Loan A3 is repayable in quarterly installments beginning on December 31, 2022 and is scheduled to mature on July 30, 2027.

- added (2022-10-27):
[0001137789-22-000123:note_history:28]
The Sixth Amendment to the Credit Agreement also replaced the LIBOR interest rates plus variable margin for the Term Loans A1 and A2 with the SOFR interest rates plus a variable margin that will be determined based on the corporate credit rating of the Borrower or one of its parent entities. The Sixth Amendment also permits the Borrower to increase the revolving loan commitments or obtain new term loans of up to $100 million in aggregate, subject to the satisfaction of certain terms and conditions.

- changed (2022-10-27):
[0001137789-22-000123:note_history:29]
STX and certain of its material subsidiaries, including STUC, fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loans A1, A2 and A3 (the “Term Loans”).
  (was, 2022-04-28, similarity 0.9048):
[0001137789-22-000031:note_history:29]
STX and certain of its material subsidiaries, including STUC, fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loans.

- changed (2022-10-27):
[0001137789-22-000123:note_history:30]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of September 30, 2022. As of September 30, 2022, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility.
  (was, 2022-04-28, similarity 0.8788):
[0001137789-22-000031:note_history:30]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of April 1, 2022 and expects to be in compliance for the next 12 months. As of April 1, 2022, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility.

- changed (2022-10-27):
[0001137789-22-000123:note_history:31]
At September 30, 2022, future principal payments on long-term debt were as follows (in millions):
  (was, 2022-04-28, similarity 0.9438):
[0001137789-22-000031:note_history:31]
At April 1, 2022, future principal payments on long-term debt were as follows (in millions):

- changed (2022-10-27):
[0001137789-22-000123:note_history:32]
| Fiscal Year |  | Amount |
| Remainder of 2023 |  | $ | 608 |  |
| 2024 |  | 614 |  |
| 2025 |  | 627 |  |
| 2026 |  | 629 |  |
| 2027 |  | 649 |  |
| Thereafter |  | 3,188 |  |
| Total |  | $ | 6,315 |  |
  (was, 2022-04-28, similarity 0.9937):
[0001137789-22-000031:note_history:32]
| Fiscal Year |  | Amount |
| Remainder of 2022 |  | $ | — |  |
| 2023 |  | 585 |  |
| 2024 |  | 560 |  |
| 2025 |  | 562 |  |
| 2026 |  | 563 |  |
| Thereafter |  | 3,445 |  |
| Total |  | $ | 5,715 |  |

- removed (2022-10-27):
[0001137789-22-000031:note_history:33]
Unsecured Senior Notes

- removed (2022-10-27):
[0001137789-22-000031:note_history:34]
2022 Notes. On February 1, 2022, the entire outstanding principal amount of $220 million was repaid at par, plus accrued and unpaid interest. During the nine months ended April 2, 2021, $9 million aggregate principal amount of the 2022 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest.

- removed (2022-10-27):
[0001137789-22-000031:note_history:35]
2023 Notes. During the nine months ended April 2, 2021, $5 million aggregate principal amount of the 2023 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss of $1 million on repurchases during the nine months ended April 2, 2021, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- removed (2022-10-27):
[0001137789-22-000031:note_history:36]
Prior to the October 14, 2021 amendment, the Credit Agreement provided a term loan facility in an aggregate principal amount of $500 million and a $1.725 billion senior unsecured revolving credit facility (“Revolving Credit Facility”). The September 2019 Term Loan had a final maturity date of September 16, 2025 and the Revolving Credit Facility had a final maturity of February 20, 2024. On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the September 2019 Term Loan.

- removed (2022-10-27):
[0001137789-22-000031:note_history:37]
On October 14, 2021, STX and Seagate HDD Cayman entered into an amendment to the Credit Agreement (“Fifth Amendment”), which provides for a new term loan facility in the aggregate principal amount of $1.2 billion that was extended in two tranches of $600 million each (“Term Loan A1” and “Term Loan A2” and together the “Term Loans”). Term Loan A1 and Term Loan A2 were each drawn in full on the closing date for the Fifth Amendment. Term Loan A1 bears interest at a rate of LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company. Term Loan A1 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of September 16, 2025. Term Loan A2 bears interest at a rate of LIBOR plus a variable margin ranging from 1.25% to 2.5% that will be determined based on the corporate credit rating of the Company. Term Loan A2 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of July 30, 2027. The proceeds of the Terms Loans may be used for, among other things, general corporate purposes.

- removed (2022-10-27):
[0001137789-22-000031:note_history:38]
In addition, pursuant to the Fifth Amendment, the maturity date for the revolving loan commitments under the Revolving Credit Facility was extended until October 14, 2026, the revolving commitments were increased to $1.75 billion and the interest rate margins for the revolving loans were amended to LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001137789-22-000123:note_history:39]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of September 30, 2022 and July 1, 2022:
  (was, 2022-04-28, similarity 0.9697):
[0001137789-22-000031:note_history:39]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of April 1, 2022 and July 2, 2021:

- changed (2022-10-27):
[0001137789-22-000123:note_history:40]
|  |  | September 30,2022 |  | July 1,2022 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 159 |  |  | $ | — |  |  | $ | 159 |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 16 |  |  | — |  |  | 16 |  |  | 23 |  |  | — |  |  | 23 |  |
| Total |  | $ | 176 |  |  | $ | — |  |  | $ | 176 |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 158 |  |  |  |  |  |  | $ | 59 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 16 |  |  |  |  |  |  | 23 |  |
| Total |  |  |  |  |  | $ | 176 |  |  |  |  |  |  | $ | 84 |  |
  (was, 2022-04-28, similarity 0.8934):
[0001137789-22-000031:note_history:40]
|  |  | April 1,2022 |  | July 2,2021 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 176 |  |  | $ | — |  |  | $ | 176 |  |  | $ | 552 |  |  | $ | — |  |  | $ | 552 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 36 |  |  | (13) |  |  | 23 |  |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 213 |  |  | $ | (13) |  |  | $ | 200 |  |  | $ | 571 |  |  | $ | — |  |  | $ | 571 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 176 |  |  |  |  |  |  | $ | 551 |  |
| Included in Other current assets |  |  |  |  |  | 1 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 23 |  |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 200 |  |  |  |  |  |  | $ | 571 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2022-10-27):
[0001137789-22-000123:note_history:41]
The following table presents the fair value and amortized cost of the Company’s debt in order of maturity:

- added (2022-10-27):
[0001137789-22-000123:note_history:42]
|  |  | September 30, 2022 |  | July 1, 2022 |
| (Dollars in millions) |  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 4.750% Senior Notes due June 2023 |  | $ | 540 |  |  | $ | 537 |  |  | $ | 540 |  |  | $ | 538 |  |
| 4.875% Senior Notes due March 2024 |  | 499 |  |  | 489 |  |  | 499 |  |  | 494 |  |
| 4.750% Senior Notes due January 2025 |  | 479 |  |  | 457 |  |  | 479 |  |  | 471 |  |
| 4.875% Senior Notes due June 2027 |  | 504 |  |  | 457 |  |  | 504 |  |  | 483 |  |
| 4.091% Senior Notes due June 2029 |  | 468 |  |  | 396 |  |  | 466 |  |  | 427 |  |
| 3.125% Senior Notes due July 2029 |  | 500 |  |  | 368 |  |  | 500 |  |  | 396 |  |
| 4.125% Senior Notes due January 2031 |  | 500 |  |  | 375 |  |  | 500 |  |  | 410 |  |
| 3.375% Senior Notes due July 2031 |  | 500 |  |  | 350 |  |  | 500 |  |  | 393 |  |
| 5.750% Senior Notes due December 2034 |  | 489 |  |  | 386 |  |  | 489 |  |  | 433 |  |
| SOFR Based Term Loan A1 due September 2025 (1) |  | 600 |  |  | 589 |  |  | 600 |  |  | 588 |  |
| SOFR Based Term Loan A2 due July 2027 (1) |  | 600 |  |  | 581 |  |  | 600 |  |  | 586 |  |
| SOFR Based Term Loan A3 due July 2027 |  | 600 |  |  | 584 |  |  | — |  |  | — |  |
|  |  | $ | 6,279 |  |  | $ | 5,569 |  |  | $ | 5,677 |  |  | $ | 5,219 |  |
| Less: unamortized debt issuance costs |  | (30) |  |  | — |  |  | (31) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 6,249 |  |  | $ | 5,569 |  |  | $ | 5,646 |  |  | $ | 5,219 |  |
| Less: current portion of debt, net of debt issuance costs |  | (636) |  |  | (630) |  |  | (584) |  |  | (582) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,613 |  |  | $ | 4,939 |  |  | $ | 5,062 |  |  | $ | 4,637 |  |

- added (2022-10-27):
[0001137789-22-000123:note_history:43]
_________________________________

- added (2022-10-27):
[0001137789-22-000123:note_history:44]
(1) On August 18, 2022, the Sixth Amendment to the Credit Agreement replaced the LIBOR interest rates plus variable margin of Term Loans A1 and A2 with the SOFR interest rates plus a variable margin. Refer to “Note 3. Debt” for more details.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001137789-22-000123:note_history:45]
The following table provides details of the Company’s debt as of September 30, 2022 and July 1, 2022:
  (was, 2022-04-28, similarity 0.9444):
[0001137789-22-000031:note_history:45]
The following table provides details of the Company’s debt as of April 1, 2022 and July 2, 2021:

- changed (2022-10-27):
[0001137789-22-000123:note_history:46]
| (Dollars in millions) |  | September 30,2022 |  | July 1,2022 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | $ | 540 |  |  | $ | 540 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 468 |  |  | 466 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 600 |  |  | 600 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | 600 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | — |  |
|  |  | 6,279 |  |  | 5,677 |  |
| Less: unamortized debt issuance costs |  | (30) |  |  | (31) |  |
| Debt, net of debt issuance costs |  | 6,249 |  |  | 5,646 |  |
| Less: current portion of long-term debt |  | (636) |  |  | (584) |  |
| Long-term debt, less current portion |  | $ | 5,613 |  |  | $ | 5,062 |  |
  (was, 2022-04-28, similarity 0.6712):
[0001137789-22-000031:note_history:46]
| (Dollars in millions) |  | April 1,2022 |  | July 2,2021 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $750 issued on February 3, 2017 at 4.25% due on March 1, 2022 (the “2022 Notes”), interest payable semi-annually on March 1 and September 1 of each year, fully repaid on February 1, 2022. |  | $ | — |  |  | $ | 220 |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 541 |  |  | 541 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 464 |  |  | 461 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 499 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loan |  |  |  |  |
| $600 borrowed on October 14, 2021 at London Interbank Offered Rate (“LIBOR”) plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 600 |  |  | — |  |
| $600 borrowed on October 14, 2021 at LIBOR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | — |  |
| $500 borrowed on September 17, 2019 at LIBOR, (the “September 2019 Term Loan”), repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with a final maturity date of September 16, 2025, fully repaid on October 14, 2021. |  | — |  |  | 481 |  |
|  |  | 5,676 |  |  | 5,173 |  |
| Less: unamortized debt issuance costs |  | (32) |  |  | (34) |  |
| Debt, net of debt issuance costs |  | 5,644 |  |  | 5,139 |  |
| Less: current portion of long-term debt |  | (30) |  |  | (245) |  |
| Long-term debt, less current portion |  | $ | 5,614 |  |  | $ | 4,894 |  |

- changed (2022-10-27):
[0001137789-22-000123:note_history:47]
__________________________________
  (was, 2022-04-28, similarity 0.9375):
[0001137789-22-000031:note_history:47]
______________________________


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001137789-22-000123:note_history:48]
At September 30, 2022, future principal payments on long-term debt were as follows (in millions):
  (was, 2022-04-28, similarity 0.9438):
[0001137789-22-000031:note_history:48]
At April 1, 2022, future principal payments on long-term debt were as follows (in millions):

- changed (2022-10-27):
[0001137789-22-000123:note_history:49]
| Fiscal Year |  | Amount |
| Remainder of 2023 |  | $ | 608 |  |
| 2024 |  | 614 |  |
| 2025 |  | 627 |  |
| 2026 |  | 629 |  |
| 2027 |  | 649 |  |
| Thereafter |  | 3,188 |  |
| Total |  | $ | 6,315 |  |
  (was, 2022-04-28, similarity 0.9937):
[0001137789-22-000031:note_history:49]
| Fiscal Year |  | Amount |
| Remainder of 2022 |  | $ | — |  |
| 2023 |  | 585 |  |
| 2024 |  | 560 |  |
| 2025 |  | 562 |  |
| 2026 |  | 563 |  |
| Thereafter |  | 3,445 |  |
| Total |  | $ | 5,715 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001137789-22-000123:note_history:50]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 30,2022 |  | October 1,2021 |
| Revenues by Channel |  |  |  |  |
| OEMs |  | $ | 1,545 |  |  | $ | 2,288 |  |
| Distributors |  | 299 |  |  | 507 |  |
| Retailers |  | 191 |  |  | 320 |  |
| Total |  | $ | 2,035 |  |  | $ | 3,115 |  |
| Revenues by Geography (1) |  |  |  |  |
| Asia Pacific |  | $ | 801 |  |  | $ | 1,583 |  |
| Americas |  | 936 |  |  | 1,079 |  |
| EMEA |  | 298 |  |  | 453 |  |
| Total |  | $ | 2,035 |  |  | $ | 3,115 |  |
  (was, 2022-04-28, similarity 0.6018):
[0001137789-22-000031:note_history:50]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 2,149 |  |  | $ | 1,950 |  |  | $ | 6,615 |  |  | $ | 5,299 |  |
| Distributors |  | 349 |  |  | 455 |  |  | 1,418 |  |  | 1,297 |  |
| Retailers |  | 304 |  |  | 326 |  |  | 1,000 |  |  | 1,072 |  |
| Total |  | $ | 2,802 |  |  | $ | 2,731 |  |  | $ | 9,033 |  |  | $ | 7,668 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,292 |  |  | $ | 1,268 |  |  | $ | 4,308 |  |  | $ | 3,680 |  |
| Americas |  | 1,171 |  |  | 939 |  |  | 3,436 |  |  | 2,582 |  |
| EMEA |  | 339 |  |  | 524 |  |  | 1,289 |  |  | 1,406 |  |
| Total |  | $ | 2,802 |  |  | $ | 2,731 |  |  | $ | 9,033 |  |  | $ | 7,668 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001137789-22-000123:note_history:51]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 30,2022 |  | October 1,2021 |
| Revenues by Channel |  |  |  |  |
| OEMs |  | $ | 1,545 |  |  | $ | 2,288 |  |
| Distributors |  | 299 |  |  | 507 |  |
| Retailers |  | 191 |  |  | 320 |  |
| Total |  | $ | 2,035 |  |  | $ | 3,115 |  |
| Revenues by Geography (1) |  |  |  |  |
| Asia Pacific |  | $ | 801 |  |  | $ | 1,583 |  |
| Americas |  | 936 |  |  | 1,079 |  |
| EMEA |  | 298 |  |  | 453 |  |
| Total |  | $ | 2,035 |  |  | $ | 3,115 |  |
  (was, 2022-04-28, similarity 0.6018):
[0001137789-22-000031:note_history:51]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 2,149 |  |  | $ | 1,950 |  |  | $ | 6,615 |  |  | $ | 5,299 |  |
| Distributors |  | 349 |  |  | 455 |  |  | 1,418 |  |  | 1,297 |  |
| Retailers |  | 304 |  |  | 326 |  |  | 1,000 |  |  | 1,072 |  |
| Total |  | $ | 2,802 |  |  | $ | 2,731 |  |  | $ | 9,033 |  |  | $ | 7,668 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,292 |  |  | $ | 1,268 |  |  | $ | 4,308 |  |  | $ | 3,680 |  |
| Americas |  | 1,171 |  |  | 939 |  |  | 3,436 |  |  | 2,582 |  |
| EMEA |  | 339 |  |  | 524 |  |  | 1,289 |  |  | 1,406 |  |
| Total |  | $ | 2,802 |  |  | $ | 2,731 |  |  | $ | 9,033 |  |  | $ | 7,668 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001137789-22-000123:note_history:52]
On October 26, 2022, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on January 5, 2023 to shareholders of record as of the close of business on December 21, 2022.
  (was, 2022-04-28, similarity 0.938):
[0001137789-22-000031:note_history:52]
On April 27, 2022, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on July 7, 2022 to shareholders of record as of the close of business on June 24, 2022.

- added (2022-10-27):
[0001137789-22-000123:note_history:53]
Restructuring Plan

- added (2022-10-27):
[0001137789-22-000123:note_history:54]
On October 24, 2022, the Company’s Board of Directors approved and committed to a plan to reduce its cost structure to better align the Company’s operational needs to current economic conditions while continuing to support the long-term business strategy. See “Note 5. Restructuring and Exit Costs” for more information.
