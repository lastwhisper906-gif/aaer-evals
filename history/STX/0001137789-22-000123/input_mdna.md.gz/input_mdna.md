# STX MD&A — 0001137789-22-000123


## mdna

[0001137789-22-000123:mdna:1]
[same as prior period, unchanged from 0001137789-22-000031:mdna:1]

[0001137789-22-000123:mdna:2]
The following is a discussion of the financial condition, changes in financial condition and results of operations for our fiscal quarters ended September 30, 2022, July 1, 2022 and October 1, 2021, referred to herein as the “September 2022 quarter,” the “June 2022 quarter,” and the “September 2021 quarter,” respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The September 2022 quarter, June 2022 quarter and the September 2021 quarter were each 13 weeks.

[0001137789-22-000123:mdna:3]
[same as prior period, unchanged from 0001137789-22-000031:mdna:3]

[0001137789-22-000123:mdna:4]
•the uncertainty in the global economy including higher inflationary pressures, increase in interest rates and other adverse changes in the level of economic activity in the major regions in which we do business;

[0001137789-22-000123:mdna:5]
•changes in or adverse outcomes in the Company’s legal proceedings, including regulatory inquires and investigations and related matters;

[0001137789-22-000123:mdna:6]
•the timing of development and introduction of products based on new technologies and expansion into new data storage markets and market acceptance of new products;

[0001137789-22-000123:mdna:7]
[same as prior period, unchanged from 0001137789-22-000031:mdna:6]

[0001137789-22-000123:mdna:8]
[same as prior period, unchanged from 0001137789-22-000031:mdna:7]

[0001137789-22-000123:mdna:9]
•the effects of the COVID-19 pandemic and related individual, business and government responses on the global economy and their impact on the Company's business, operations and financial results, including impacts to the Company's supply chain resulting from governments' policies and approaches to containing COVID-19;

[0001137789-22-000123:mdna:10]
•the Company’s ability to effectively manage its debt obligations and comply with certain covenants in its credit facilities with respect to financial ratios and financial condition tests and its ability to maintain a favorable cash liquidity position;

[0001137789-22-000123:mdna:11]
[same as prior period, unchanged from 0001137789-22-000031:mdna:10]

[0001137789-22-000123:mdna:12]
[same as prior period, unchanged from 0001137789-22-000031:mdna:11]

[0001137789-22-000123:mdna:13]
•disruptions to the Company’s supply chain or production capabilities, including ongoing shortages of certain materials, any electricity restrictions and increases in logistical, materials and operation costs;

[0001137789-22-000123:mdna:14]
[same as prior period, unchanged from 0001137789-22-000031:mdna:13]

[0001137789-22-000123:mdna:15]
[same as prior period, unchanged from 0001137789-22-000031:mdna:14]

[0001137789-22-000123:mdna:16]
•the effect of geopolitical uncertainties, such as international conflicts, on international commerce, the global economy and/or our business;

[0001137789-22-000123:mdna:17]
•the difficulties in implementing a new global enterprise resource planning system; and

[0001137789-22-000123:mdna:18]
[same as prior period, unchanged from 0001137789-22-000031:mdna:16]

[0001137789-22-000123:mdna:19]
[same as prior period, unchanged from 0001137789-22-000031:mdna:18]

[0001137789-22-000123:mdna:20]
•Overview of the September 2022 quarter. Highlights of events in the September 2022 quarter that impacted our financial position.

[0001137789-22-000123:mdna:21]
•Results of Operations. Analysis of our financial results comparing the September 2022 quarter to the June 2022 quarter and the September 2021 quarter.

[0001137789-22-000123:mdna:22]
•Liquidity and Capital Resources. Analysis of changes in our balance sheets and cash flows, discussion of our financial condition including potential sources of liquidity and material cash requirements and their general purpose.

[0001137789-22-000123:mdna:23]
•Critical Accounting Estimates. Accounting estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001137789-22-000123:mdna:24]
For an overview of our business, see “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies—Organization.”

[0001137789-22-000123:mdna:25]
Overview of the September 2022 quarter

[0001137789-22-000123:mdna:26]
During the September 2022 quarter, we shipped 118 exabytes of HDD storage capacity. We generated revenue of approximately $2.0 billion with a gross margin of 24% and our operating cash flow was $245 million. We amended our credit agreement and borrowed an additional $600 million term loan facility. We repurchased approximately 5 million of our ordinary shares for $408 million and paid $147 million in dividends.

[0001137789-22-000123:mdna:27]
Recent Development, Economic Conditions and Challenges

[0001137789-22-000123:mdna:28]
During the September 2022 quarter, the data storage industry and our business were impacted by intensified macroeconomic headwinds. We experienced broad-based delay in customers’ purchase plans, particularly in mass capacity market, given overall macroeconomic slowdowns and supply chain shortages for other non-HDD electronic components. The ongoing economic slowdown in China due to the pandemic-related governmental lockdown measures, as well as the negative impact from the higher inflationary pressures in the consumer markets continued to impact our business during the September 2022 quarter. Additionally, our customers continued to experience demand disruptions, resulting in demand variations across certain of our end markets. These recent reductions in demand have required us to reduce manufacturing production plans and incur manufacturing underutilization charges, which may continue.

[0001137789-22-000123:mdna:29]
We continue to actively monitor the effects and potential impacts of the macroeconomic conditions, pandemic and other factors on all aspects of our business, supply chain, liquidity and capital resources. We are also actively working on opportunities to lower our cost structure, drive further operational efficiencies and maintain supply chain discipline including adjusting our manufacturing production plans, annual capital expenditure plans and other meaningful cost savings measures in response to these business conditions. We are complying with governmental rules and guidelines across all of our sites. We expect these factors will continue to impact our business and results of operations over the near-term. For a further discussion of the uncertainties and risks associated with macroeconomic conditions and the COVID-19 pandemic, among others, see “Part II, Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q.

[0001137789-22-000123:mdna:30]
[same as prior period, unchanged from 0001137789-22-000031:mdna:33]

[0001137789-22-000123:mdna:31]
[same as prior period, unchanged from 0001137789-22-000031:mdna:29]

[0001137789-22-000123:mdna:32]
[same as prior period, unchanged from 0001137789-22-000031:mdna:30]

[0001137789-22-000123:mdna:33]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 30,2022 |  | July 1,2022 |  | October 1,2021 |
| Revenue |  | $ | 2,035 |  |  | $ | 2,628 |  |  | $ | 3,115 |  |
| Cost of revenue |  | 1,553 |  |  | 1,869 |  |  | 2,159 |  |
| Gross profit |  | 482 |  |  | 759 |  |  | 956 |  |
| Product development |  | 234 |  |  | 247 |  |  | 233 |  |
| Marketing and administrative |  | 129 |  |  | 149 |  |  | 133 |  |
| Amortization of intangibles |  | 3 |  |  | 2 |  |  | 3 |  |
| Restructuring and other, net |  | 9 |  |  | 1 |  |  | 1 |  |
| Income from operations |  | 107 |  |  | 360 |  |  | 586 |  |
| Other expense, net |  | (80) |  |  | (79) |  |  | (53) |  |
| Income before income taxes |  | 27 |  |  | 281 |  |  | 533 |  |
| (Benefit from) provision for income taxes |  | (2) |  |  | 5 |  |  | 7 |  |
| Net income |  | $ | 29 |  |  | $ | 276 |  |  | $ | 526 |  |

[0001137789-22-000123:mdna:34]
|  |  | For the Three Months Ended |
|  |  | September 30,2022 |  | July 1,2022 |  | October 1,2021 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 76 |  |  | 71 |  |  | 69 |  |
| Gross margin |  | 24 |  |  | 29 |  |  | 31 |  |
| Product development |  | 12 |  |  | 9 |  |  | 8 |  |
| Marketing and administrative |  | 7 |  |  | 6 |  |  | 4 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |
| Restructuring and other, net |  | — |  |  | — |  |  | — |  |
| Operating margin |  | 5 |  |  | 14 |  |  | 19 |  |
| Other expense, net |  | (4) |  |  | (3) |  |  | (2) |  |
| Income before income taxes |  | 1 |  |  | 11 |  |  | 17 |  |
| (Benefit from) provision for income taxes |  | — |  |  | — |  |  | — |  |
| Net income |  | 1 | % |  | 11 | % |  | 17 | % |

[0001137789-22-000123:mdna:35]
[same as prior period, unchanged from 0001137789-22-000031:mdna:45]

[0001137789-22-000123:mdna:36]
[same as prior period, unchanged from 0001137789-22-000031:mdna:34]

[0001137789-22-000123:mdna:37]
[same as prior period, unchanged from 0001137789-22-000031:mdna:35]

[0001137789-22-000123:mdna:38]
|  |  | For the Three Months Ended |  |  |
|  |  | September 30,2022 |  | July 1,2022 |  | October 1,2021 |  |  |  |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 76 | % |  | 81 | % |  | 74 | % |  |  |  |  |
| Distributors |  | 15 | % |  | 10 | % |  | 16 | % |  |  |  |  |
| Retailers |  | 9 | % |  | 9 | % |  | 10 | % |  |  |  |  |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 39 | % |  | 39 | % |  | 51 | % |  |  |  |  |
| Americas |  | 46 | % |  | 48 | % |  | 35 | % |  |  |  |  |
| EMEA |  | 15 | % |  | 13 | % |  | 14 | % |  |  |  |  |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 68 | % |  | 73 | % |  | 65 | % |  |  |  |  |
| Legacy |  | 19 | % |  | 19 | % |  | 27 | % |  |  |  |  |
| Other |  | 13 | % |  | 8 | % |  | 8 | % |  |  |  |  |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 104 |  |  | 139 |  |  | 132 |  |  |  |  |  |
| Legacy |  | 14 |  |  | 16 |  |  | 27 |  |  |  |  |  |
| Total |  | 118 |  |  | 155 |  |  | 159 |  |  |  |  |  |
| HDD Price per Terabyte |  | $ | 15 |  |  | $ | 16 |  |  | $ | 18 |  |  |  |  |  |

[0001137789-22-000123:mdna:39]
[same as prior period, unchanged from 0001137789-22-000031:mdna:37]

[0001137789-22-000123:mdna:40]
[same as prior period, unchanged from 0001137789-22-000031:mdna:38]

[0001137789-22-000123:mdna:41]
Revenue in the September 2022 quarter decreased by $593 million from the June 2022 quarter and decreased by $1.1 billion from the September 2021 quarter primarily due to the decrease in exabytes shipped as a result of lower market demand in mass capacity and legacy markets that were impacted by macroeconomic and pandemic-related headwinds. We expect the challenge from the demand environment including the macroeconomic conditions and the pandemic-related impacts will continue to persist in the second quarter of fiscal year 2023.

[0001137789-22-000123:mdna:42]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 18% of gross revenue for the September 2022 quarter, 15% for the June 2022 quarter and 13% for the September 2021 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-22-000123:mdna:43]
[same as prior period, unchanged from 0001137789-22-000031:mdna:43]

[0001137789-22-000123:mdna:44]
|  |  | For the Three Months Ended |  |  |  |  |
| (Dollars in millions) |  | September 30,2022 |  | July 1,2022 |  | October 1,2021 |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,553 |  |  | $ | 1,869 |  |  | $ | 2,159 |  |  |  |  |  |  |  |  |  |
| Gross profit |  | 482 |  |  | 759 |  |  | 956 |  |  |  |  |  |  |  |  |  |
| Gross margin |  | 24 | % |  | 29 | % |  | 31 | % |  |  |  |  |  |  |  |  |

[0001137789-22-000123:mdna:45]
Gross margin for the September 2022 quarter decreased compared to both the June 2022 quarter and the September 2021 quarter primarily driven by approximately $60 million of factory under-utilization cost associated with lower production levels and pandemic-related lockdown in one of our factories, price erosion and unfavorable product mix as the higher margin mass capacity market declined faster than the legacy markets.

[0001137789-22-000123:mdna:46]
31

[0001137789-22-000123:mdna:47]
In the September 2022 quarter, total warranty cost was 1.2% of revenue and included an unfavorable change in estimates of prior warranty accruals of 0.6% of revenue primarily due to changes to our estimated future product return rates. Warranty cost related to new shipments was 0.6% and 0.7% of revenue for the September 2022 quarter and September 2021 quarter, respectively.

[0001137789-22-000123:mdna:48]
[same as prior period, unchanged from 0001137789-22-000031:mdna:50]

[0001137789-22-000123:mdna:49]
|  |  | For the Three Months Ended |  |  |  |  |
| (Dollars in millions) |  | September 30,2022 |  | July 1,2022 |  | October 1,2021 |  |  |  |  |  |  |  |  |
| Product development |  | $ | 234 |  |  | $ | 247 |  |  | $ | 233 |  |  |  |  |  |  |  |  |  |
| Marketing and administrative |  | 129 |  |  | 149 |  |  | 133 |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  | 3 |  |  | 2 |  |  | 3 |  |  |  |  |  |  |  |  |  |
| Restructuring and other, net |  | 9 |  |  | 1 |  |  | 1 |  |  |  |  |  |  |  |  |  |
| Operating expenses |  | $ | 375 |  |  | $ | 399 |  |  | $ | 370 |  |  |  |  |  |  |  |  |  |

[0001137789-22-000123:mdna:50]
Product development expense. Product development expenses decreased by $13 million in the September 2022 quarter compared to the June 2022 quarter primarily due to a $14 million decrease in variable compensation and related benefit expense and a $4 million decrease in materials, partially offset by an $8 million increase in depreciation expenses.

[0001137789-22-000123:mdna:51]
Product development expenses increased by $1 million in the September 2022 quarter compared to the September 2021 quarter primarily due to a $23 million increase in depreciation expenses and a $3 million increase in materials expense, partially offset by a $22 million decrease in variable compensation and related benefit expense.

[0001137789-22-000123:mdna:52]
Marketing and administrative expense. Marketing and administrative expenses decreased by $20 million for the September 2022 quarter compared to the June 2022 quarter primarily due to a $9 million decrease in variable compensation and related benefit expense, an $8 million decrease in compensation and other employee benefits as a result of a decrease in share-based compensation and a $4 million decrease in outside services expense.

[0001137789-22-000123:mdna:53]
Marketing and administrative expenses decreased by $4 million in the September 2022 quarter compared to the September 2021 quarter primarily due to a $15 million decrease in variable compensation expense and a $3 million decrease in compensation and other employee benefits due to a decrease in share-based compensation, partially offset by a $5 million increase in travel expenses as a result of the easing of pandemic-related travel restrictions, a $2 million increase in outside services expense and a $2 million increase in advertising costs.

[0001137789-22-000123:mdna:54]
Amortization of intangibles. Amortization of intangibles for the September 2022 quarter remained relatively flat compared to the June 2022 quarter and the September 2021 quarter.

[0001137789-22-000123:mdna:55]
Restructuring and other, net. Restructuring and other, net was $9 million in the September 2022 quarter primarily related to cost incurred as part of restructuring of our workforce.

[0001137789-22-000123:mdna:56]
[same as prior period, unchanged from 0001137789-22-000031:mdna:61]

[0001137789-22-000123:mdna:57]
|  |  | For the Three Months Ended |  |  |  |  |
| (Dollars in millions) |  | September 30,2022 |  | July 1,2022 |  | October 1,2021 |  |  |  |  |  |  |  |  |
| Other expense, net |  | $ | (80) |  |  | $ | (79) |  |  | $ | (53) |  |  |  |  |  |  |  |  |  |

[0001137789-22-000123:mdna:58]
Other expense, net. Other expense, net increased by $1 million for the September 2022 quarter compared to the June 2022 quarter primarily due to a $5 million increase in interest expense and a $2 million increase in foreign exchange remeasurement expense partially offset by a net $6 million higher non-recurring loss from our strategic investments in the June 2022 quarter.

[0001137789-22-000123:mdna:59]
Other expense, net increased by $27 million for the September 2022 quarter compared to the September 2021 quarter primarily due to a $12 million increase in interest expense, a net $10 million higher non-recurring gain from our strategic investments in the September 2021 quarter and a $4 million increase in foreign exchange remeasurement expense.

[0001137789-22-000123:mdna:60]
[same as prior period, unchanged from 0001137789-22-000031:mdna:66]

[0001137789-22-000123:mdna:61]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 30,2022 |  | July 1,2022 |  | October 1,2021 |
| (Benefit from) provision for income taxes |  | $ | (2) |  |  | $ | 5 |  |  | $ | 7 |  |

[0001137789-22-000123:mdna:62]
We recorded an income tax benefit of $2 million for the three months ended September 30, 2022. The income tax benefit for the three months ended September 30, 2022 included approximately $7 million of net discrete tax benefit, primarily associated with the excess tax benefits related to share-based compensation expense.

[0001137789-22-000123:mdna:63]
On August 16, 2022, the Inflation Reduction Act of 2022 (the “IRA”) was enacted into U.S. law. The legislation includes a new corporate alternative minimum tax (the “CAMT”) of 15% on the adjusted financial statement income (“AFSI”) of corporations with average AFSI exceeding $1.0 billion over a three-year period. The CAMT is effective for us beginning in fiscal year 2024. We assessed the potential impact of the CAMT and do not expect to have a material impact to our financial statements or results of operations.

[0001137789-22-000123:mdna:64]
During the three months ended September 30, 2022, our unrecognized tax benefits excluding interest and penalties increased by approximately $1 million to $115 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. We do not expect material changes to our unrecognized tax benefits in the next twelve months beginning October 1, 2022.

[0001137789-22-000123:mdna:65]
We recorded an income tax provision of $7 million for the three months ended October 1, 2021. The income tax provision for the three months ended October 1, 2021 included approximately $10 million of net discrete tax benefit, primarily associated with net excess tax benefits related to share-based compensation expense.

[0001137789-22-000123:mdna:66]
Our income tax provision recorded for the three months ended September 30, 2022 and October 1, 2021 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-22-000123:mdna:67]
[same as prior period, unchanged from 0001137789-22-000031:mdna:73]

[0001137789-22-000123:mdna:68]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash will continue to be sufficient to fund our operations and meet our cash requirements for the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs, capital expenditures and share repurchase levels, will allow us to manage the ongoing impacts of macroeconomic and pandemic-related headwinds including higher inflationary pressures, inventory adjustments by our customers and the overall market demand disruptions on our business operations for the foreseeable future. However, some challenges to our industry and to our business continue to remain uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to the global economic factors and the pandemic.

[0001137789-22-000123:mdna:69]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of September 30, 2022.

[0001137789-22-000123:mdna:70]
[same as prior period, unchanged from 0001137789-22-000031:mdna:76]

[0001137789-22-000123:mdna:71]
| (Dollars in millions) |  | September 30,2022 |  | July 1,2022 |  | Change |
| Cash and cash equivalents |  | $ | 761 |  |  | $ | 615 |  |  | $ | 146 |  |

[0001137789-22-000123:mdna:72]
Our cash and cash equivalents as of September 30, 2022 increased by $146 million from July 1, 2022 primarily as a result of net proceeds of $600 million from the issuance of long-term debt and net cash of $245 million provided by operating activities partially offset by the repurchases of our ordinary shares of $408 million, dividends paid to our shareholders of $147 million and payments for capital expenditures of $133 million.

[0001137789-22-000123:mdna:73]
[same as prior period, unchanged from 0001137789-22-000031:mdna:79]

[0001137789-22-000123:mdna:74]
Cash provided by operating activities for the three months ended September 30, 2022 was $245 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-22-000123:mdna:75]
•a decrease of $434 million in accounts receivable, primarily due to timing of collections; and

[0001137789-22-000123:mdna:76]
•an increase of $110 million cash proceeds received from the settlement of certain interest rate swap agreements; partially offset by

[0001137789-22-000123:mdna:77]
•a decrease of $300 million in accounts payable, primarily due to a decrease in materials purchased;

[0001137789-22-000123:mdna:78]
•a decrease of $146 million in accrued employee compensation, primarily due to cash paid to our employees as part of our discretionary spending plans; and

[0001137789-22-000123:mdna:79]
•an increase of $41 million in inventories, primarily due to an increase in materials purchased.

[0001137789-22-000123:mdna:80]
[same as prior period, unchanged from 0001137789-22-000031:mdna:85]

[0001137789-22-000123:mdna:81]
Cash used in investing activities for the three months ended September 30, 2022 was $133 million, primarily attributable to payments for the purchase of property, equipment and leasehold improvements.

[0001137789-22-000123:mdna:82]
Cash Provided by Financing Activities

[0001137789-22-000123:mdna:83]
Net cash provided by financing activities of $34 million for the three months ended September 30, 2022 was primarily attributable to the following activities:

[0001137789-22-000123:mdna:84]
•$600 million in net proceeds from the issuance of Term Loan A3; and

[0001137789-22-000123:mdna:85]
•$29 million in proceeds from the issuance of ordinary shares under employee stock plans; partially offset by

[0001137789-22-000123:mdna:86]
•$408 million in payments for repurchases of our ordinary shares;

[0001137789-22-000123:mdna:87]
•$147 million in dividend payments; and

[0001137789-22-000123:mdna:88]
•$39 million in payments for taxes related to net share settlement of equity awards.

[0001137789-22-000123:mdna:89]
Liquidity Sources

[0001137789-22-000123:mdna:90]
Our primary sources of liquidity as of September 30, 2022, consist of: (1) approximately $761 million in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.75 billion available for borrowing under our Revolving Credit Facility, which is part of the Credit Agreement. On August 18, 2022, we entered into the Sixth Amendment to the Credit Agreement which permits us to increase the revolving loan commitments or obtain new term loans of up to $100 million in aggregate, subject to the satisfaction of certain terms and conditions.

[0001137789-22-000123:mdna:91]
As of September 30, 2022, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-22-000123:mdna:92]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The term of the Revolving Credit Facility is through October 14, 2026. As of September 30, 2022, we were in compliance with all of the covenants under our debt agreements. We continue to evaluate our debt portfolio and structure to ensure we are able to comply with our financial debt covenants.

[0001137789-22-000123:mdna:93]
We believe that our sources of cash will be sufficient to fund our operations and meet our cash requirements for at least the next 12 months. Our ability to fund liquidity requirements beyond 12 months will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, including the pandemic, among others, see “Part II, Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q.

[0001137789-22-000123:mdna:94]
Cash Requirements and Commitments

[0001137789-22-000123:mdna:95]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness and to fund our quarterly dividend and any future strategic investments. As of September 30, 2022, our contractual cash requirements have not changed materially since our Annual Report on Form 10-K for the fiscal year ended July 1, 2022, except for long-term debt obligations.

[0001137789-22-000123:mdna:96]
Long-term debt and interest payments on debt

[0001137789-22-000123:mdna:97]
The Sixth Amendment to the Credit Agreement provides for a new Term Loan A3 in the aggregate principal amount of $600 million. Term Loan A3 was borrowed in full at the closing of the Sixth Amendment. Term Loan A3 bears interest at a rate of SOFR plus a variable margin of 1.25% to 2.5%, in each case with such margin being determined based on the corporate credit rating of the Borrower or one of its parent entities. Term Loan A3 is repayable in quarterly installments beginning on December 31, 2022 and is scheduled to mature on July 30, 2027. The Sixth Amendment to the Credit Agreement also replaced the LIBOR interest rates plus variable margin of Term Loans A1 and A2 with the SOFR interest rates plus a variable margin that will be determined based on the corporate credit rating of the Borrower or one of its parent entities.

[0001137789-22-000123:mdna:98]
As of September 30, 2022, the future principal payment obligation on our long-term debt was $6.3 billion, of which $636 million will mature within one year. As of September 30, 2022, future interest payments on these outstanding debt is estimated to be approximately $1.5 billion, of which $293 million is expected to be paid within one year. From time to time, we may repurchase any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 1. Financial Statements—Note 3. Debt” for more details.

[0001137789-22-000123:mdna:99]
Dividends

[0001137789-22-000123:mdna:100]
During the September 2022 quarter, our Board of Directors declared dividends of $0.70 per share, totaling $145 million, which was paid on October 5, 2022. On October 26, 2022, our Board of Directors declared a quarterly cash dividend of $0.70 per share, payable on January 5, 2023 to shareholders of record at the close of business on December 21, 2022. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-22-000123:mdna:101]
Share repurchases

[0001137789-22-000123:mdna:102]
From time to time, at the Company’s discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker-assisted purchases, tender offers, or other means, including through the use of derivative transactions. During the September 2022 quarter, we repurchased approximately 6 million of our ordinary shares including shares withheld for statutory tax withholdings related to vesting of employee equity awards. As of September 30, 2022, $1.9 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-22-000123:mdna:103]
Other

[0001137789-22-000123:mdna:104]
For fiscal year 2023, we expect capital expenditures to be below our long-term targeted range of 4% to 6% of revenue. We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-22-000123:mdna:105]
Subsequent event

[0001137789-22-000123:mdna:106]
On October 24, 2022, our Board of Directors approved and committed to the October 2022 Plan to reduce its cost structure to better align our operational needs to current economic conditions while continuing to support the long-term business strategy. The October 2022 Plan includes reducing our worldwide headcount by approximately 3,000 employees, or 8% of the global workforce, along with other cost saving measures.

[0001137789-22-000123:mdna:107]
The October 2022 Plan, which we expect to be substantially completed by the end of the fiscal second quarter 2023, is expected to result in total pre-tax charges between $60 million and $70 million. These charges are expected to be primarily cash-based and consist of employee severance and other one-time termination benefits.

[0001137789-22-000123:mdna:108]
[same as prior period, unchanged from 0001137789-22-000031:mdna:117]

[0001137789-22-000123:mdna:109]
[same as prior period, unchanged from 0001137789-22-000031:mdna:118]

[0001137789-22-000123:mdna:110]
35

[0001137789-22-000123:mdna:111]
Other than as described in “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies”, there have been no other material changes in our critical accounting policies and estimates. Refer to “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended July 1, 2022, as filed with the SEC on August 5, 2022, for a discussion of our critical accounting policies and estimates.

[0001137789-22-000123:mdna:112]
[same as prior period, unchanged from 0001137789-22-000031:mdna:120]

[0001137789-22-000123:mdna:113]
[same as prior period, unchanged from 0001137789-22-000031:mdna:121]
