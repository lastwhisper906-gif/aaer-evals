# STX MD&A — 0001137789-21-000028


## mdna

[0001137789-21-000028:mdna:1]
[same as prior period, unchanged from 0001137789-21-000006:mdna:1]

[0001137789-21-000028:mdna:2]
The following is a discussion of the financial condition, changes in financial condition and results of operations for our fiscal quarters ended April 2, 2021, January 1, 2021 and April 3, 2020, referred to herein as the “March 2021 quarter,” the “December 2020 quarter,” and the “March 2020 quarter,” respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The March 2021 quarter, the December 2020 quarter and the March 2020 quarter were each 13 weeks.

[0001137789-21-000028:mdna:3]
[same as prior period, unchanged from 0001137789-21-000006:mdna:3]

[0001137789-21-000028:mdna:4]
[same as prior period, unchanged from 0001137789-21-000006:mdna:4]

[0001137789-21-000028:mdna:5]
[same as prior period, unchanged from 0001137789-21-000006:mdna:5]

[0001137789-21-000028:mdna:6]
[same as prior period, unchanged from 0001137789-21-000006:mdna:6]

[0001137789-21-000028:mdna:7]
[same as prior period, unchanged from 0001137789-21-000006:mdna:7]

[0001137789-21-000028:mdna:8]
[same as prior period, unchanged from 0001137789-21-000006:mdna:8]

[0001137789-21-000028:mdna:9]
•the Company’s ability to effectively manage its debt obligations and comply with certain covenants in its credit facilities with respect to financial ratios and financial condition tests and its ability to maintain a favorable cash liquidity position;

[0001137789-21-000028:mdna:10]
[same as prior period, unchanged from 0001137789-21-000006:mdna:10]

[0001137789-21-000028:mdna:11]
[same as prior period, unchanged from 0001137789-21-000006:mdna:11]

[0001137789-21-000028:mdna:12]
[same as prior period, unchanged from 0001137789-21-000006:mdna:12]

[0001137789-21-000028:mdna:13]
[same as prior period, unchanged from 0001137789-21-000006:mdna:13]

[0001137789-21-000028:mdna:14]
[same as prior period, unchanged from 0001137789-21-000006:mdna:14]

[0001137789-21-000028:mdna:15]
[same as prior period, unchanged from 0001137789-21-000006:mdna:15]

[0001137789-21-000028:mdna:16]
[same as prior period, unchanged from 0001137789-21-000006:mdna:16]

[0001137789-21-000028:mdna:17]
[same as prior period, unchanged from 0001137789-21-000006:mdna:18]

[0001137789-21-000028:mdna:18]
•Overview of the March 2021 quarter. Highlights of events in the March 2021 quarter that impacted our financial position.

[0001137789-21-000028:mdna:19]
•Results of Operations. Analysis of our financial results comparing the March 2021 quarter to the December 2020 quarter and the March 2020 quarter.

[0001137789-21-000028:mdna:20]
[same as prior period, unchanged from 0001137789-21-000006:mdna:21]

[0001137789-21-000028:mdna:21]
[same as prior period, unchanged from 0001137789-21-000006:mdna:22]

[0001137789-21-000028:mdna:22]
[same as prior period, unchanged from 0001137789-21-000006:mdna:23]

[0001137789-21-000028:mdna:23]
Overview of the March 2021 quarter

[0001137789-21-000028:mdna:24]
During the March 2021 quarter, we shipped 140 exabytes of HDD storage capacity. We generated revenue of approximately $2.7 billion and gross margin of 27% and our operating cash flow was $378 million. We repurchased approximately 11 million of our ordinary shares for $751 million and paid $161 million in dividends.

[0001137789-21-000028:mdna:25]
[same as prior period, unchanged from 0001137789-21-000006:mdna:26]

[0001137789-21-000028:mdna:26]
The COVID-19 pandemic has resulted in a widespread health crisis and numerous disease control measures are being taken to limit its spread, the effects of which began during the March 2020 quarter. We continued to incur certain supply chain and demand disruptions during the March 2021 quarter, as well as higher logistics and operational costs and softer demand across certain markets due to the COVID-19 pandemic, which we expect to continue during fiscal year 2021. Our customers also continued to experience certain supply chain and demand disruptions during the March 2021 quarter, which we anticipate will continue during fiscal year 2021. We are continuing to actively monitor the effects and potential impacts of the COVID-19 pandemic on all aspects of our business, liquidity and capital resources. We are complying with governmental rules and guidelines across all of our sites and are actively working on opportunities to lower our cost structure and drive further operational efficiencies. Although we are unable to predict the impact of COVID-19 on our business, results of operations, liquidity or capital resources at this time, we expect we will be negatively affected if the pandemic and related public and private health measures result in substantial manufacturing or supply chain problems, substantial reductions in demand due to disruptions in the operations of our customers or partners, disruptions in local and global economies, volatility in the global financial markets, sustained reductions or volatility in overall demand trends, restrictions on the export or shipment of our products, or other ramifications from the COVID-19 pandemic. For a further discussion of the uncertainties and business risks associated with the COVID-19 pandemic, see the section entitled “Item 1A. Risk Factors” in our Annual Report on Form 10-K for the fiscal year ended July 3, 2020.

[0001137789-21-000028:mdna:27]
Corporate Reorganization

[0001137789-21-000028:mdna:28]
As previously disclosed in the proxy statement filed by the Company with the SEC on March 3, 2021 (the “Proxy Statement”), we have decided to effect a corporate reorganization whereby a new Irish public limited company, Seagate Technology Holdings plc (“Holdings”), will serve as the publicly traded parent company of Seagate. The reorganization will be carried out pursuant to a scheme of arrangement (the “Scheme”) under Irish law, which will result in the exchange of ordinary shares of Holdings for ordinary shares in the Company on a one-for-one basis. The purpose of the transaction is to allow us to maintain our ability to make future distributions to our shareholders, including making dividend payments and effecting share redemptions and repurchases. On April 14, 2021, Seagate held a special Irish High Court-convened meeting of shareholders and an extraordinary general meeting of shareholders, each as described in the Proxy Statement, where the shareholders approved the Scheme and the related proposals. The Irish High Court hearing to approve the Scheme will be held on May 18, 2021 and we expect to complete the transaction in the fiscal quarter ending October 1, 2021.

[0001137789-21-000028:mdna:29]
[same as prior period, unchanged from 0001137789-21-000006:mdna:17]

[0001137789-21-000028:mdna:30]
[same as prior period, unchanged from 0001137789-21-000006:mdna:29]

[0001137789-21-000028:mdna:31]
[same as prior period, unchanged from 0001137789-21-000006:mdna:30]

[0001137789-21-000028:mdna:32]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 2,2021 |  | January 1,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
| Revenue |  | $ | 2,731 |  |  | $ | 2,623 |  |  | $ | 2,718 |  |  | $ | 7,668 |  |  | $ | 7,992 |  |
| Cost of revenue |  | 1,991 |  |  | 1,927 |  |  | 1,972 |  |  | 5,636 |  |  | 5,817 |  |
| Gross profit |  | 740 |  |  | 696 |  |  | 746 |  |  | 2,032 |  |  | 2,175 |  |
| Product development |  | 227 |  |  | 221 |  |  | 246 |  |  | 671 |  |  | 751 |  |
| Marketing and administrative |  | 126 |  |  | 122 |  |  | 119 |  |  | 366 |  |  | 361 |  |
| Amortization of intangibles |  | 3 |  |  | 3 |  |  | 3 |  |  | 9 |  |  | 11 |  |
| Restructuring and other, net |  | (2) |  |  | 2 |  |  | 2 |  |  | 1 |  |  | 19 |  |
| Income from operations |  | 386 |  |  | 348 |  |  | 376 |  |  | 985 |  |  | 1,033 |  |
| Other expense, net |  | (47) |  |  | (57) |  |  | (38) |  |  | (134) |  |  | (161) |  |
| Income before income taxes |  | 339 |  |  | 291 |  |  | 338 |  |  | 851 |  |  | 872 |  |
| Provision for income taxes |  | 10 |  |  | 11 |  |  | 18 |  |  | 19 |  |  | 34 |  |
| Net income |  | $ | 329 |  |  | $ | 280 |  |  | $ | 320 |  |  | $ | 832 |  |  | $ | 838 |  |

[0001137789-21-000028:mdna:33]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
|  |  | April 2,2021 |  | January 1,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 73 |  |  | 73 |  |  | 73 |  |  | 73 |  |  | 73 |  |
| Gross margin |  | 27 |  |  | 27 |  |  | 27 |  |  | 27 |  |  | 27 |  |
| Product development |  | 8 |  |  | 9 |  |  | 9 |  |  | 9 |  |  | 9 |  |
| Marketing and administrative |  | 5 |  |  | 5 |  |  | 4 |  |  | 5 |  |  | 5 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Restructuring and other, net |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating margin |  | 14 |  |  | 13 |  |  | 14 |  |  | 13 |  |  | 13 |  |
| Other expense, net |  | (2) |  |  | (2) |  |  | (1) |  |  | (2) |  |  | (2) |  |
| Income before income taxes |  | 12 |  |  | 11 |  |  | 13 |  |  | 11 |  |  | 11 |  |
| Provision for income taxes |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net income |  | 12 | % |  | 11 | % |  | 12 | % |  | 11 | % |  | 10 | % |

[0001137789-21-000028:mdna:34]
[same as prior period, unchanged from 0001137789-21-000006:mdna:28]

[0001137789-21-000028:mdna:35]
[same as prior period, unchanged from 0001137789-21-000006:mdna:34]

[0001137789-21-000028:mdna:36]
[same as prior period, unchanged from 0001137789-21-000006:mdna:35]

[0001137789-21-000028:mdna:37]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
|  |  | April 2,2021 |  | January 1,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | 71 | % |  | 66 | % |  | 73 | % |  | 69 | % |  | 71 | % |
| Distributors |  | 17 | % |  | 18 | % |  | 17 | % |  | 17 | % |  | 17 | % |
| Retailers |  | 12 | % |  | 16 | % |  | 10 | % |  | 14 | % |  | 12 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 47 | % |  | 50 | % |  | 46 | % |  | 48 | % |  | 49 | % |
| Americas |  | 34 | % |  | 32 | % |  | 35 | % |  | 34 | % |  | 32 | % |
| EMEA |  | 19 | % |  | 18 | % |  | 19 | % |  | 18 | % |  | 19 | % |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 60 | % |  | 58 | % |  | 57 | % |  | 59 | % |  | 51 | % |
| Legacy |  | 32 | % |  | 35 | % |  | 36 | % |  | 33 | % |  | 42 | % |
| Other |  | 8 | % |  | 7 | % |  | 7 | % |  | 8 | % |  | 7 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 111 |  |  | 97 |  |  | 91 |  |  | 294 |  |  | 226 |  |
| Legacy |  | 29 |  |  | 32 |  |  | 29 |  |  | 89 |  |  | 99 |  |
| Total |  | 140 |  |  | 129 |  |  | 120 |  |  | 383 |  |  | 325 |  |
| HDD Price per Terabyte |  | $ | 18 |  |  | $ | 19 |  |  | $ | 21 |  |  | $ | 18 |  |  | $ | 23 |  |

[0001137789-21-000028:mdna:38]
Revenue in the March 2021 quarter increased by $108 million from the December 2020 quarter primarily due to an increase in mass capacity storage exabytes shipped, partially offset by a decrease in legacy market exabytes shipped.

[0001137789-21-000028:mdna:39]
Revenue in the March 2021 quarter increased by $13 million from the March 2020 quarter primarily due to an increase in mass capacity storage exabytes shipped and favorable product mix, partially offset by price erosion.

[0001137789-21-000028:mdna:40]
Revenue for the nine months ended April 2, 2021 decreased by $324 million from the nine months ended April 3, 2020 primarily as a result of price erosion, a decrease in legacy market exabytes shipped and lower demand as a result of the COVID-19 pandemic, partially offset by an increase in mass capacity storage exabytes shipped.

[0001137789-21-000028:mdna:41]
We maintain various sales incentive programs such as channel and original equipment manufacturers rebates. Sales incentive programs were approximately 14% of gross revenue for the March 2021 quarter, 15% for the December 2020 quarter and 11% for the March 2020 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-21-000028:mdna:42]
[same as prior period, unchanged from 0001137789-21-000006:mdna:41]

[0001137789-21-000028:mdna:43]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 2,2021 |  | January 1,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
| Cost of revenue |  | $ | 1,991 |  |  | $ | 1,927 |  |  | $ | 1,972 |  |  | $ | 5,636 |  |  | $ | 5,817 |  |
| Gross profit |  | 740 |  |  | 696 |  |  | 746 |  |  | 2,032 |  |  | 2,175 |  |
| Gross margin |  | 27 | % |  | 27 | % |  | 27 | % |  | 27 | % |  | 27 | % |

[0001137789-21-000028:mdna:44]
Gross margin for the March 2021 quarter remained flat compared to the December 2020 quarter and March 2020 quarter.

[0001137789-21-000028:mdna:45]
Gross margin for the nine months ended April 2, 2021 remained flat compared to the nine months ended April 3, 2020.

[0001137789-21-000028:mdna:46]
[same as prior period, unchanged from 0001137789-21-000006:mdna:33]

[0001137789-21-000028:mdna:47]
In the March 2021 quarter, total warranty cost was 0.6% of revenue and included a favorable change in estimates of prior warranty accruals of 0.1% of revenue primarily due to a decrease in the number of drives under warranty. Warranty cost related to new shipments was 0.7%, 0.7% and 0.8% of revenue for the March 2021 quarter, December 2020 quarter and March 2020 quarter, respectively.

[0001137789-21-000028:mdna:48]
[same as prior period, unchanged from 0001137789-21-000006:mdna:48]

[0001137789-21-000028:mdna:49]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 2,2021 |  | January 1,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
| Product development |  | $ | 227 |  |  | $ | 221 |  |  | $ | 246 |  |  | $ | 671 |  |  | $ | 751 |  |
| Marketing and administrative |  | 126 |  |  | 122 |  |  | 119 |  |  | 366 |  |  | 361 |  |
| Amortization of intangibles |  | 3 |  |  | 3 |  |  | 3 |  |  | 9 |  |  | 11 |  |
| Restructuring and other, net |  | (2) |  |  | 2 |  |  | 2 |  |  | 1 |  |  | 19 |  |
| Operating expenses |  | $ | 354 |  |  | $ | 348 |  |  | $ | 370 |  |  | $ | 1,047 |  |  | $ | 1,142 |  |

[0001137789-21-000028:mdna:50]
Product development expense. Product development expense for the March 2021 quarter increased by $6 million compared to the December 2020 quarter primarily due to a $4 million increase in compensation and other employee benefits and a $3 million increase in materials and tooling costs.

[0001137789-21-000028:mdna:51]
Product development expense decreased by $19 million in the March 2021 quarter compared to the March 2020 quarter primarily due to a $10 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our June 2020 restructuring plan, a $5 million decrease in materials expense, a $5 million decrease in information technology and software costs and a $4 million decrease in outside services partially offset by a $6 million increase related to timing of grants received.

[0001137789-21-000028:mdna:52]
Product development expense decreased by $80 million for the nine months ended April 2, 2021 compared to the nine months ended April 3, 2020 primarily due to a $46 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our June 2020 restructuring plan and the additional fourteenth week in the quarter ended October 4, 2019, a $14 million decrease in information technology and software costs, a $9 million decrease in travel and entertainment expenses mainly as a result of the disruptions related to COVID-19, a $7 million decrease in materials expense, a $4 million decrease in outside services and a $3 million decrease in equipment expense, partially offset by a $9 million increase in variable compensation expense.

[0001137789-21-000028:mdna:53]
Marketing and administrative expense. Marketing and administrative expense increased by $4 million for the March 2021 quarter compared to the December 2020 quarter primarily due to a $5 million increase in outside services expense.

[0001137789-21-000028:mdna:54]
Marketing and administrative expense increased by $7 million in the March 2021 quarter compared to the March 2020 quarter primarily due to an $10 million increase in information technology and software costs, partially offset by a $3 million decrease in depreciation expense and a $2 million decrease in travel and entertainment expenses mainly as a result of disruptions related to COVID-19.

[0001137789-21-000028:mdna:55]
Marketing and administrative expense increased by $5 million for the nine months ended April 2, 2021 compared to the nine months ended April 3, 2020 primarily due to a $31 million increase in information technology and software costs and a $6 million increase in variable compensation expense, partially offset by an $13 million decrease in travel expenses mainly as a result of disruptions related to COVID-19, a $9 million decrease in depreciation expense and an $8 million decrease in compensation and other employee benefits from the additional fourteenth week in the quarter ended October 4, 2019.

[0001137789-21-000028:mdna:56]
Amortization of intangibles. Amortization of intangibles for the March 2021 quarter remained flat compared to the December 2020 quarter.

[0001137789-21-000028:mdna:57]
Amortization of intangibles for the three and nine months ended April 2, 2021 remained flat and decreased by $2 million, respectively, compared to the three and nine months ended April 3, 2020, due to certain intangible assets that reached the end of their useful lives.

[0001137789-21-000028:mdna:58]
Restructuring and other, net. Restructuring and other, net for the three and nine months ended April 2, 2021 and three months ended April 3, 2020 were not material.

[0001137789-21-000028:mdna:59]
Restructuring and other, net for the nine months ended April 3, 2020 was comprised of charges primarily related to a voluntary early exit program.

[0001137789-21-000028:mdna:60]
[same as prior period, unchanged from 0001137789-21-000006:mdna:44]

[0001137789-21-000028:mdna:61]
[same as prior period, unchanged from 0001137789-21-000006:mdna:61]

[0001137789-21-000028:mdna:62]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 2,2021 |  | January 1,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
| Other expense, net |  | $ | (47) |  |  | $ | (57) |  |  | $ | (38) |  |  | $ | (134) |  |  | $ | (161) |  |

[0001137789-21-000028:mdna:63]
Other expense, net. Other expense, net for the March 2021 quarter decreased by $10 million from the December 2020 quarter primarily due to a $10 million strategic investment upward adjustment in the March 2021 quarter and a $7 million impairment charge in the December 2020 quarter, partially offset by a $6 million increase in interest expense from the issuance of long-term debt in the December 2020 quarter.

[0001137789-21-000028:mdna:64]
Other expense, net for the March 2021 quarter increased by $9 million compared to the March 2020 quarter primarily due to a $20 million increase in interest expense from the issuance of long-term debt during the nine months ended April 2, 2021 and a $12 million increase in foreign exchange remeasurement expense, partially offset by an $11 million decrease in interest expense due to the repurchase of certain long-term debt and a $10 million strategic investment upward adjustment in the March 2021 quarter.

[0001137789-21-000028:mdna:65]
Other expense, net for the nine months ended April 2, 2021 decreased by $27 million compared to the nine months ended April 3, 2020 primarily due to $41 million of strategic investment gains in the nine months ended April 2, 2021, of which $33 million is upward adjustments and $8 million is a gain upon sale of an investment, a $37 million decrease in interest expense due to the repurchase of certain long-term debt, a $28 million non-recurring loss from the repurchase and exchange of certain long-term debt in the quarter ended October 4, 2019 and a $15 million increase in gains on de-designated cash flow hedges. The decrease was partially offset by a $46 million increase in interest expense from the issuance of long-term debt in the nine months ended April 2, 2021, a $28 million increase in foreign exchange remeasurement expense, a $16 million decrease in interest income primarily due to a decline in interest rates and $7 million strategic investment impairment charges in the December 2020 quarter.

[0001137789-21-000028:mdna:66]
[same as prior period, unchanged from 0001137789-21-000006:mdna:66]

[0001137789-21-000028:mdna:67]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 2,2021 |  | January 1,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
| Provision for income taxes |  | $ | 10 |  |  | $ | 11 |  |  | $ | 18 |  |  | $ | 19 |  |  | $ | 34 |  |

[0001137789-21-000028:mdna:68]
We recorded income tax provisions of $10 million and $19 million in the three and nine months ended April 2, 2021, respectively. The income tax provision for the three months ended April 2, 2021 included approximately $4 million of net discrete tax benefit, primarily associated with filing of tax returns in various jurisdictions. The income tax provision for the nine months ended April 2, 2021 included approximately $15 million of net discrete tax benefits, primarily associated with net excess tax benefits related to share-based compensation expense, filing of tax returns in various jurisdictions, and postponement of the previously enacted United Kingdom tax rate change in the quarter ended October 2, 2020.

[0001137789-21-000028:mdna:69]
During the nine months ended April 2, 2021, our unrecognized tax benefits excluding interest and penalties increased by approximately $18 million to $107 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. During the twelve months beginning April 3, 2021, we expect that our unrecognized tax benefits could be reduced by an immaterial amount, as a result of the expiration of certain statutes of limitation.

[0001137789-21-000028:mdna:70]
We recorded income tax provisions of $18 million and $34 million in the three and nine months ended April 3, 2020, respectively. The discrete items in the income tax provision were not material for the three months ended April 3, 2020. The income tax provision for the nine months ended April 3, 2020 included approximately $13 million of net discrete tax benefits, primarily associated with net excess tax benefits related to share-based compensation expense.

[0001137789-21-000028:mdna:71]
Our income tax provision recorded for the three and nine months ended April 2, 2021 and April 3, 2020 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-21-000028:mdna:72]
[same as prior period, unchanged from 0001137789-21-000006:mdna:57]

[0001137789-21-000028:mdna:73]
[same as prior period, unchanged from 0001137789-21-000006:mdna:73]

[0001137789-21-000028:mdna:74]
[same as prior period, unchanged from 0001137789-21-000006:mdna:74]

[0001137789-21-000028:mdna:75]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of April 2, 2021.

[0001137789-21-000028:mdna:76]
[same as prior period, unchanged from 0001137789-21-000006:mdna:76]

[0001137789-21-000028:mdna:77]
| (Dollars in millions) |  | April 2,2021 |  | July 3,2020 |  | Change |
| Cash and cash equivalents |  | $ | 1,212 |  |  | $ | 1,722 |  |  | $ | (510) |  |

[0001137789-21-000028:mdna:78]
Our cash and cash equivalents as of April 2, 2021 decreased by $510 million from July 3, 2020 primarily as a result the repurchases of our ordinary shares of $1,819 million, dividends paid to our shareholders of $495 million and payments for capital expenditures of $374 million, partially offset by the net proceeds of $986 million from the issuance of long-term debt and net cash of $1,148 million provided by operating activities.

[0001137789-21-000028:mdna:79]
[same as prior period, unchanged from 0001137789-21-000006:mdna:79]

[0001137789-21-000028:mdna:80]
Cash provided by operating activities for the nine months ended April 2, 2021 was $1,148 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-21-000028:mdna:81]
•a decrease of $138 million in accounts receivable, primarily due to linearity of sales in the March 2021 quarter;

[0001137789-21-000028:mdna:82]
•an increase of $60 million in accounts payable, primarily due to an increase in materials purchased and greater operating expenses;

[0001137789-21-000028:mdna:83]
•partially offset by an increase of $141 million in inventories, primarily due to timing of shipments and an increase in materials purchased; and

[0001137789-21-000028:mdna:84]
•a decrease of $43 million in accrued restructuring, primarily due to severance payments to impacted employees.

[0001137789-21-000028:mdna:85]
[same as prior period, unchanged from 0001137789-21-000006:mdna:85]

[0001137789-21-000028:mdna:86]
Cash used in investing activities for the nine months ended April 2, 2021 was $360 million, primarily attributable to the following activities:

[0001137789-21-000028:mdna:87]
•payments for the purchase of property, equipment and leasehold improvements of $374 million;

[0001137789-21-000028:mdna:88]
[same as prior period, unchanged from 0001137789-21-000006:mdna:88]

[0001137789-21-000028:mdna:89]
•offset by proceeds from the sale of investments of $11 million;

[0001137789-21-000028:mdna:90]
•proceeds from the sale of assets of $4 million; and

[0001137789-21-000028:mdna:91]
•proceeds from the maturities of short-term investments of $3 million.

[0001137789-21-000028:mdna:92]
[same as prior period, unchanged from 0001137789-21-000006:mdna:90]

[0001137789-21-000028:mdna:93]
Cash used in financing activities of $1,298 million for the nine months ended April 2, 2021 was primarily attributable to the following activities:

[0001137789-21-000028:mdna:94]
•payments for the repurchase of our ordinary shares of $1,819 million;

[0001137789-21-000028:mdna:95]
•payments for dividends of $495 million;

[0001137789-21-000028:mdna:96]
•payments for taxes related to net share settlement of equity awards of $33 million;

[0001137789-21-000028:mdna:97]
•payments for the repurchase of long-term debt of $27 million;

[0001137789-21-000028:mdna:98]
•payments for the fees related to the amendment of the Credit Agreement of $4 million;

[0001137789-21-000028:mdna:99]
[same as prior period, unchanged from 0001137789-21-000006:mdna:96]

[0001137789-21-000028:mdna:100]
•proceeds from the issuance of ordinary shares under employee share plans of $95 million.

[0001137789-21-000028:mdna:101]
[same as prior period, unchanged from 0001137789-21-000006:mdna:98]

[0001137789-21-000028:mdna:102]
Our primary sources of liquidity as of April 2, 2021 consisted of: (1) approximately $1.2 billion in cash and cash equivalents, (2) cash we expect to generate from operations, and (3) $1.725 billion available for borrowing under our Revolving Credit Facility.

[0001137789-21-000028:mdna:103]
As of April 2, 2021, no borrowings had been drawn and no borrowings had been utilized for letters of credit or swing line loans issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-21-000028:mdna:104]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The term of the Revolving Credit Facility is through February 20, 2024, and the maturity date of the Term Loan is September 16, 2025. We were in compliance with the covenants as of April 2, 2021 and expect to be in compliance for the next 12 months.

[0001137789-21-000028:mdna:105]
[same as prior period, unchanged from 0001137789-21-000006:mdna:102]

[0001137789-21-000028:mdna:106]
For fiscal year 2021, we expect capital expenditures to be aligned to our updated long-term targeted range of 4% to 6% of revenue. We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We may raise additional capital from time to time and will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-21-000028:mdna:107]
From time to time, we may repurchase any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase outstanding senior notes pursuant to the terms of the applicable indenture.

[0001137789-21-000028:mdna:108]
During the March 2021 quarter, our Board of Directors declared a dividend of $0.67 per share, totaling $154 million, which was paid on April 7, 2021. On April 22, 2021, our Board of Directors declared a quarterly cash dividend of $0.67 per share, payable on July 7, 2021 to shareholders of record at the close of business on May 12, 2021.

[0001137789-21-000028:mdna:109]
From time to time, at the Company’s discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means, including through the use of derivative transactions. Our Board of Directors increased the authorization for the repurchase of our outstanding ordinary shares by $3.0 billion on October 21, 2020, and $2.0 billion on February 22, 2021. As of April 2, 2021, $4.4 billion remained available for repurchases under our existing repurchase authorization. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-21-000028:mdna:110]
[same as prior period, unchanged from 0001137789-21-000006:mdna:107]

[0001137789-21-000028:mdna:111]
[same as prior period, unchanged from 0001137789-21-000006:mdna:108]

[0001137789-21-000028:mdna:112]
[same as prior period, unchanged from 0001137789-21-000006:mdna:109]

[0001137789-21-000028:mdna:113]
[same as prior period, unchanged from 0001137789-21-000006:mdna:110]

[0001137789-21-000028:mdna:114]
[same as prior period, unchanged from 0001137789-21-000006:mdna:111]
