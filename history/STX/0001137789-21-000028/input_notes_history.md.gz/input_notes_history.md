# STX note change history — 0001137789-21-000006 → 0001137789-21-000028


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0001137789-21-000028:note_history:1]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial is scheduled to begin on February 7, 2022. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.
  (was, 2021-01-28, similarity 0.7898):
[0001137789-21-000006:note_history:1]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial is scheduled to begin on June 21, 2021. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0001137789-21-000028:note_history:2]
The Company’s enterprise data solutions portfolio includes storage subsystems and mass capacity optimized private cloud storage solutions for enterprises and cloud and managed service providers. Engineered for modularity, mobility, mass capacity and performance, these solutions include the Company’s enterprise HDDs and SSDs, enabling customers to integrate powerful, scalable storage within legacy enterprise IT environments or build new on premises private storage clouds from the ground up in a secure, cost-effective manner. The Company’s other solutions include an edge-to-cloud mass storage platform, which is designed to reduce the cost and complexity associated with storing, moving and activating data at scale.
  (was, 2021-01-28, similarity 0.8464):
[0001137789-21-000006:note_history:2]
The Company’s enterprise data solutions portfolio includes storage subsystems and mass capacity optimized private cloud storage solutions for enterprises and cloud and managed service providers. Engineered for modularity, mobility, mass capacity and performance, these solutions include the Company’s enterprise HDDs and SSDs, enabling customers to integrate powerful, scalable storage within legacy enterprise IT environments or build new on premises private storage clouds from the ground up in a secure, cost-effective manner.

- changed (2021-04-29):
[0001137789-21-000028:note_history:3]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three and nine months ended April 2, 2021 consisted of 13 and 39 weeks, respectively, and the three and nine months ended April 3, 2020 consisted of 13 and 40 weeks, respectively. Fiscal year 2021, which ends on July 2, 2021, is comprised of 52 weeks and fiscal year 2020, which ended on July 3, 2020, was comprised of 53 weeks. The fiscal quarters ended April 2, 2021, January 1, 2021 and April 3, 2020, are also referred to herein as the “March 2021 quarter”, the “December 2020 quarter” and the “March 2020 quarter”, respectively. The results of operations for the three and nine months ended April 2, 2021 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending July 2, 2021.
  (was, 2021-01-28, similarity 0.8877):
[0001137789-21-000006:note_history:3]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three and six months ended January 1, 2021 consisted of 13 and 26 weeks, respectively, and the three and six months ended January 3, 2020 consisted of 13 and 27 weeks, respectively. Fiscal year 2021, which ends on July 2, 2021, is comprised of 52 weeks and fiscal year 2020, which ended on July 3, 2020, was comprised of 53 weeks. The fiscal quarters ended January 1, 2021, October 2, 2020 and January 3, 2020, are also referred to herein as the “December 2020 quarter”, the “September 2020 quarter” and the “December 2019 quarter”, respectively. The results of operations for the three and six months ended January 1, 2021 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending July 2, 2021.

- changed (2021-04-29):
[0001137789-21-000028:note_history:4]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13 (ASC Topic 326), Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held to include future conditions in its estimate of expected credit losses. The Company adopted this new accounting pronouncement in the quarter ended October 2, 2020. The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.
  (was, 2021-01-28, similarity 0.9744):
[0001137789-21-000006:note_history:4]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13 (ASC Topic 326), Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held to include future conditions in its estimate of expected credit losses. The Company adopted this new accounting pronouncement in the September 2020 quarter. The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.

- changed (2021-04-29):
[0001137789-21-000028:note_history:5]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles—Goodwill and Other—Internal-Use Software—Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company adopted this new accounting pronouncement in the quarter ended October 2, 2020. The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.
  (was, 2021-01-28, similarity 0.9764):
[0001137789-21-000006:note_history:5]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles—Goodwill and Other—Internal-Use Software—Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company adopted this new accounting pronouncement in the September 2020 quarter. The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0001137789-21-000028:note_history:6]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement on February 20, 2019, which was most recently amended on January 13, 2021 (the “Credit Agreement”), increasing the size of the senior unsecured revolving credit facility (“Revolving Credit Facility”) and capping the indebtedness guaranteed by certain of Seagate HDD Cayman’s material subsidiaries to an amount $100 million less than the amount that would give rise to a guarantee requirement by such subsidiaries in respect of any series of senior notes. The Credit Agreement provides a $1.725 billion Revolving Credit Facility and a term loan facility in an aggregate principal amount of $500 million (“Term Loan”). The Revolving Credit Facility has a final maturity of February 20, 2024 and the Term Loan has a final maturity date of September 16, 2025. The loans made under the Revolving Credit Facility and the Term Loan will bear interest at a rate of the London Interbank Offered Rate (“LIBOR”) plus a variable margin for each facility that will be determined based on the corporate credit rating of the Company. The Revolving Credit Facility also allows such facility to increase by an additional $275 million, provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at least $25 million, and (iii) the existing commitments under such facility receive 0.50% most favored nation protection. An aggregate amount of up to $75 million of the Revolving Credit Facility is available for the issuance of letters of credit, and an aggregate amount of up to $50 million of such facility is also available for swing line loans.
  (was, 2021-01-28, similarity 0.6621):
[0001137789-21-000006:note_history:6]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement (the “Credit Agreement”) on February 20, 2019. As of January 1, 2021, the Credit Agreement provided an up to $1.5 billion senior unsecured revolving credit facility (“Revolving Credit Facility”) and a term loan facility in an aggregate principal amount of $500 million (“Term Loan”). The Revolving Credit Facility has a final maturity of February 20, 2024 and the Term Loan has a final maturity date of September 16, 2025. The loans made under the Revolving Credit Facility and the Term Loan will bear interest at a rate of the London Interbank Offered Rate (“LIBOR”) plus a variable margin for each facility that will be determined based on the corporate credit rating of the Company. As of January 1, 2021, STX and certain of its material subsidiaries fully and unconditionally guaranteed both the Revolving Credit Facility and the Term Loan. As of January 1, 2021, the Revolving Credit Facility also allowed such facility to increase by an additional $100 million, provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at least $25 million, and (iii) the existing commitments under such facility receive 0.50% most favored nation protection. An aggregate amount of up to $75 million of the Revolving Credit Facility is available for the issuance of letters of credit, and an aggregate amount of up to $50 million of such facility is also available for swing line loans. On January 13, 2021, the Company and Seagate HDD Cayman entered into an amendment to the Credit Agreement which increased the size of the Revolving Credit Facility to $1.725 billion and allows such facility to increase by an additional $275 million, subject to the same terms and conditions as stated above. The amendment also reduced the indebtedness guaranteed by certain of Seagate HDD Cayman’s material subsidiaries to an amount $100 million less than the amount that would give rise to a guarantee requirement by such subsidiaries in respect of any series of senior notes.

- changed (2021-04-29):
[0001137789-21-000028:note_history:7]
On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the Term Loan and the proceeds were used to repurchase a portion of its outstanding senior notes. The Term Loan is repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with the remaining balance payable upon maturity. The Company repaid $6 million and $12 million principal amount of the Term Loan during the three and nine months ended April 2, 2021, respectively.
  (was, 2021-01-28, similarity 0.9118):
[0001137789-21-000006:note_history:7]
On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the Term Loan and the proceeds were used to repurchase a portion of its outstanding senior notes. The Term Loan is repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with the remaining balance payable upon maturity. The Company repaid $6 million principal amount of the Term Loan during the three and six months ended January 1, 2021.

- changed (2021-04-29):
[0001137789-21-000028:note_history:8]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of April 2, 2021 and expects to be in compliance for the next 12 months.
  (was, 2021-01-28, similarity 0.9775):
[0001137789-21-000006:note_history:8]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of January 1, 2021 and expects to be in compliance for the next 12 months.

- changed (2021-04-29):
[0001137789-21-000028:note_history:9]
As of April 2, 2021, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the Revolving Credit Facility.
  (was, 2021-01-28, similarity 0.9716):
[0001137789-21-000006:note_history:9]
As of January 1, 2021, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the Revolving Credit Facility.

- changed (2021-04-29):
[0001137789-21-000028:note_history:10]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March, 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the nine months ended April 2, 2021, $9 million aggregate principal amount of the 2022 Notes was repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. During the three and nine months ended April 3, 2020, the Company repurchased $23 million and $273 million aggregate principal amount of the 2022 Notes, respectively, for cash at a premium to their principal amount, plus accrued and unpaid interest, $250 million principal amount of which was repurchased pursuant to cash tender offers for certain senior notes on September 18, 2019 (the “Tender Offers”). The Company recorded an immaterial loss and a loss of $10 million, respectively, on repurchases during the nine months ended April 2, 2021 and April 3, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2021-01-28, similarity 0.7225):
[0001137789-21-000006:note_history:10]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March, 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the six months ended January 1, 2021, $9 million aggregate principal amount of the 2022 Notes was repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. During the six months ended January 3, 2020, $250 million aggregate principal amount was repurchased pursuant to cash tender offers for certain senior notes (“the Tender Offers”). The Company recorded an immaterial loss and a loss of $10 million, respectively, on repurchases during the six months ended January 1, 2021 and January 3, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- changed (2021-04-29):
[0001137789-21-000028:note_history:11]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June, 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the nine months ended April 2, 2021, $5 million aggregate principal amount of the 2023 Notes was repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. During the three and nine months ended April 3, 2020, the Company repurchased $17 million and $217 million aggregate principal amount of the 2023 Notes for cash at a discount or at a premium to their principal amount, plus accrued and unpaid interest, respectively, $200 million principal amount of which was repurchased pursuant to the Tender Offers. The Company recorded a loss of $1 million and $10 million, respectively, on repurchases during the nine months ended April 2, 2021 and April 3, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2021-01-28, similarity 0.78):
[0001137789-21-000006:note_history:11]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June, 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the six months ended January 1, 2021, $5 million aggregate principal amount of the 2023 Notes was repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. During the six months ended January 3, 2020, $200 million aggregate principal amount was repurchased pursuant to the Tender Offers. The Company recorded a loss of $1 million and $10 million, respectively, on repurchases during the six months ended January 1, 2021 and January 3, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- changed (2021-04-29):
[0001137789-21-000028:note_history:12]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January, 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the nine months ended April 3, 2020, $170 million aggregate principal amount was repurchased pursuant to the Tender Offers. The Company recorded a loss of $8 million on repurchases during the nine months ended April 3, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2021-01-28, similarity 0.9295):
[0001137789-21-000006:note_history:12]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January, 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the six months ended January 3, 2020, $170 million aggregate principal amount was repurchased pursuant to the Tender Offers. The Company recorded a loss of $8 million on repurchases during the six months ended January 3, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0001137789-21-000028:note_history:13]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of April 2, 2021:
  (was, 2021-01-28, similarity 0.9685):
[0001137789-21-000006:note_history:13]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of January 1, 2021:


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0001137789-21-000028:note_history:14]
At April 2, 2021, future principal payments on long-term debt were as follows (in millions):
  (was, 2021-01-28, similarity 0.9545):
[0001137789-21-000006:note_history:14]
At January 1, 2021, future principal payments on long-term debt were as follows (in millions):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0001137789-21-000028:note_history:15]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 1,950 |  |  | $ | 1,970 |  |  | $ | 5,299 |  |  | $ | 5,633 |  |
| Distributors |  | 455 |  |  | 465 |  |  | 1,297 |  |  | 1,389 |  |
| Retailers |  | 326 |  |  | 283 |  |  | 1,072 |  |  | 970 |  |
| Total |  | $ | 2,731 |  |  | $ | 2,718 |  |  | $ | 7,668 |  |  | $ | 7,992 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,268 |  |  | $ | 1,257 |  |  | $ | 3,680 |  |  | $ | 3,912 |  |
| Americas |  | 939 |  |  | 938 |  |  | 2,582 |  |  | 2,534 |  |
| EMEA |  | 524 |  |  | 523 |  |  | 1,406 |  |  | 1,546 |  |
| Total |  | $ | 2,731 |  |  | $ | 2,718 |  |  | $ | 7,668 |  |  | $ | 7,992 |  |
  (was, 2021-01-28, similarity 0.9281):
[0001137789-21-000006:note_history:15]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | January 1,2021 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 1,741 |  |  | $ | 1,843 |  |  | $ | 3,349 |  |  | $ | 3,663 |  |
| Distributors |  | 475 |  |  | 463 |  |  | 842 |  |  | 924 |  |
| Retailers |  | 407 |  |  | 390 |  |  | 746 |  |  | 687 |  |
| Total |  | $ | 2,623 |  |  | $ | 2,696 |  |  | $ | 4,937 |  |  | $ | 5,274 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,306 |  |  | $ | 1,377 |  |  | $ | 2,412 |  |  | $ | 2,655 |  |
| Americas |  | 838 |  |  | 761 |  |  | 1,643 |  |  | 1,596 |  |
| EMEA |  | 479 |  |  | 558 |  |  | 882 |  |  | 1,023 |  |
| Total |  | $ | 2,623 |  |  | $ | 2,696 |  |  | $ | 4,937 |  |  | $ | 5,274 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0001137789-21-000028:note_history:16]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 1,950 |  |  | $ | 1,970 |  |  | $ | 5,299 |  |  | $ | 5,633 |  |
| Distributors |  | 455 |  |  | 465 |  |  | 1,297 |  |  | 1,389 |  |
| Retailers |  | 326 |  |  | 283 |  |  | 1,072 |  |  | 970 |  |
| Total |  | $ | 2,731 |  |  | $ | 2,718 |  |  | $ | 7,668 |  |  | $ | 7,992 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,268 |  |  | $ | 1,257 |  |  | $ | 3,680 |  |  | $ | 3,912 |  |
| Americas |  | 939 |  |  | 938 |  |  | 2,582 |  |  | 2,534 |  |
| EMEA |  | 524 |  |  | 523 |  |  | 1,406 |  |  | 1,546 |  |
| Total |  | $ | 2,731 |  |  | $ | 2,718 |  |  | $ | 7,668 |  |  | $ | 7,992 |  |
  (was, 2021-01-28, similarity 0.9281):
[0001137789-21-000006:note_history:16]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | January 1,2021 |  | January 3,2020 |  | January 1,2021 |  | January 3,2020 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 1,741 |  |  | $ | 1,843 |  |  | $ | 3,349 |  |  | $ | 3,663 |  |
| Distributors |  | 475 |  |  | 463 |  |  | 842 |  |  | 924 |  |
| Retailers |  | 407 |  |  | 390 |  |  | 746 |  |  | 687 |  |
| Total |  | $ | 2,623 |  |  | $ | 2,696 |  |  | $ | 4,937 |  |  | $ | 5,274 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,306 |  |  | $ | 1,377 |  |  | $ | 2,412 |  |  | $ | 2,655 |  |
| Americas |  | 838 |  |  | 761 |  |  | 1,643 |  |  | 1,596 |  |
| EMEA |  | 479 |  |  | 558 |  |  | 882 |  |  | 1,023 |  |
| Total |  | $ | 2,623 |  |  | $ | 2,696 |  |  | $ | 4,937 |  |  | $ | 5,274 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0001137789-21-000028:note_history:17]
On April 22, 2021, the Company’s Board of Directors declared a quarterly cash dividend of $0.67 per share, which will be payable on July 7, 2021 to shareholders of record as of the close of business on May 12, 2021.
  (was, 2021-01-28, similarity 0.6599):
[0001137789-21-000006:note_history:17]
On January 21, 2021, the Company’s Board of Directors declared a quarterly cash dividend of $0.67 per share, which will be payable on April 7, 2021 to shareholders of record as of the close of business on March 24, 2021.
