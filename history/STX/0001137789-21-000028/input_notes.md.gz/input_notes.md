# STX notes — 0001137789-21-000028


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001137789-21-000028:notes:1]
[same as prior period, unchanged from 0001137789-21-000006:notes:1]

[0001137789-21-000028:notes:2]
[same as prior period, unchanged from 0001137789-21-000006:notes:2]

[0001137789-21-000028:notes:3]
[same as prior period, unchanged from 0001137789-21-000006:notes:3]

[0001137789-21-000028:notes:4]
[same as prior period, unchanged from 0001137789-21-000006:notes:4]

[0001137789-21-000028:notes:5]
The Company’s enterprise data solutions portfolio includes storage subsystems and mass capacity optimized private cloud storage solutions for enterprises and cloud and managed service providers. Engineered for modularity, mobility, mass capacity and performance, these solutions include the Company’s enterprise HDDs and SSDs, enabling customers to integrate powerful, scalable storage within legacy enterprise IT environments or build new on premises private storage clouds from the ground up in a secure, cost-effective manner. The Company’s other solutions include an edge-to-cloud mass storage platform, which is designed to reduce the cost and complexity associated with storing, moving and activating data at scale.

[0001137789-21-000028:notes:6]
[same as prior period, unchanged from 0001137789-21-000006:notes:6]

[0001137789-21-000028:notes:7]
[same as prior period, unchanged from 0001137789-21-000006:notes:7]

[0001137789-21-000028:notes:8]
[same as prior period, unchanged from 0001137789-21-000006:notes:8]

[0001137789-21-000028:notes:9]
[same as prior period, unchanged from 0001137789-21-000006:notes:9]

[0001137789-21-000028:notes:10]
[same as prior period, unchanged from 0001137789-21-000006:notes:10]

[0001137789-21-000028:notes:11]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three and nine months ended April 2, 2021 consisted of 13 and 39 weeks, respectively, and the three and nine months ended April 3, 2020 consisted of 13 and 40 weeks, respectively. Fiscal year 2021, which ends on July 2, 2021, is comprised of 52 weeks and fiscal year 2020, which ended on July 3, 2020, was comprised of 53 weeks. The fiscal quarters ended April 2, 2021, January 1, 2021 and April 3, 2020, are also referred to herein as the “March 2021 quarter”, the “December 2020 quarter” and the “March 2020 quarter”, respectively. The results of operations for the three and nine months ended April 2, 2021 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending July 2, 2021.

[0001137789-21-000028:notes:12]
[same as prior period, unchanged from 0001137789-21-000006:notes:12]

[0001137789-21-000028:notes:13]
[same as prior period, unchanged from 0001137789-21-000006:notes:13]

[0001137789-21-000028:notes:14]
Recently Adopted Accounting Pronouncements

[0001137789-21-000028:notes:15]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13 (ASC Topic 326), Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held to include future conditions in its estimate of expected credit losses. The Company adopted this new accounting pronouncement in the quarter ended October 2, 2020. The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.

[0001137789-21-000028:notes:16]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles—Goodwill and Other—Internal-Use Software—Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company adopted this new accounting pronouncement in the quarter ended October 2, 2020. The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.

[0001137789-21-000028:notes:17]
Recently Issued Accounting Pronouncements

[0001137789-21-000028:notes:18]
In December 2019, the FASB issued ASU 2019-12 (ASC Topic 740), Simplifying the Accounting for Income Taxes. This ASU simplifies accounting for income taxes by removing certain exceptions to the general principles and amending existing guidance to improve consistent application. The Company is required to adopt this new accounting pronouncement in the first quarter of fiscal year 2022. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001137789-21-000028:notes:19]
In March 2020, the FASB issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. generally accepted accounting principles to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. Adoption of the expedients and exceptions is permitted upon issuance of this update through December 31, 2022. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001137789-21-000028:notes:20]
[same as prior period, unchanged from 0001137789-21-000006:notes:20]

[0001137789-21-000028:notes:21]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of April 2, 2021:

[0001137789-21-000028:notes:22]
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 531 |  |  | $ | — |  |  | $ | 531 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 550 |  |  | $ | — |  |  | $ | 550 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 530 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 550 |  |

[0001137789-21-000028:notes:23]
As of April 2, 2021, the Company’s Other current assets included $2 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001137789-21-000028:notes:24]
As of April 2, 2021, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no impairment related to credit losses for available-for-sale debt securities as of April 2, 2021.

[0001137789-21-000028:notes:25]
The fair value and amortized cost of the Company’s investments classified as available-for-sale debt securities as of April 2, 2021, by remaining contractual maturity were as follows:

[0001137789-21-000028:notes:26]
| (Dollars in millions) |  | Amortized Cost |  | Fair Value |
| Due in less than 1 year |  | $ | 532 |  |  | $ | 532 |  |
| Due in 1 to 5 years |  | 10 |  |  | 10 |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | 8 |  |  | 8 |  |
| Total |  | $ | 550 |  |  | $ | 550 |  |

[0001137789-21-000028:notes:27]
[same as prior period, unchanged from 0001137789-21-000006:notes:27]

[0001137789-21-000028:notes:28]
[same as prior period, unchanged from 0001137789-21-000006:notes:28]

[0001137789-21-000028:notes:29]
[same as prior period, unchanged from 0001137789-21-000006:notes:29]

[0001137789-21-000028:notes:30]
[same as prior period, unchanged from 0001137789-21-000006:notes:30]

[0001137789-21-000028:notes:31]
[same as prior period, unchanged from 0001137789-21-000006:notes:31]

[0001137789-21-000028:notes:32]
[same as prior period, unchanged from 0001137789-21-000006:notes:32]

[0001137789-21-000028:notes:33]
| (Dollars in millions) |  | April 2,2021 |  |  |  | July 3,2020 |  | April 3,2020 |  |  |  | June 28,2019 |
| Cash and cash equivalents |  | $ | 1,212 |  |  |  |  | $ | 1,722 |  |  | $ | 1,612 |  |  |  |  | $ | 2,220 |  |
| Restricted cash included in Other current assets |  | 2 |  |  |  |  | 2 |  |  | 2 |  |  |  |  | 31 |  |
| Total cash, cash equivalents and restricted cash presented in the Statements of Cash Flows |  | $ | 1,214 |  |  |  |  | $ | 1,724 |  |  | $ | 1,614 |  |  |  |  | $ | 2,251 |  |

[0001137789-21-000028:notes:34]
[same as prior period, unchanged from 0001137789-21-000006:notes:34]

[0001137789-21-000028:notes:35]
[same as prior period, unchanged from 0001137789-21-000006:notes:35]

[0001137789-21-000028:notes:36]
In connection with an existing factoring agreement, the Company sells trade receivables to a third party for cash proceeds less a discount. During the three and nine months ended April 2, 2021, the Company sold trade receivables without recourse for cash proceeds of $35 million and $183 million, respectively, of which $35 million remained subject to servicing by the Company as of April 2, 2021. During the three and nine months ended April 3, 2020, the Company sold trade receivables without recourse for cash proceeds of $79 million. The discounts on receivables sold were not material for the three and nine months ended April 2, 2021 and April 3, 2020.

[0001137789-21-000028:notes:37]
[same as prior period, unchanged from 0001137789-21-000006:notes:37]

[0001137789-21-000028:notes:38]
[same as prior period, unchanged from 0001137789-21-000006:notes:38]

[0001137789-21-000028:notes:39]
| (Dollars in millions) |  | April 2,2021 |  | July 3,2020 |
| Raw materials and components |  | $ | 412 |  |  | $ | 451 |  |
| Work-in-process |  | 443 |  |  | 313 |  |
| Finished goods |  | 426 |  |  | 378 |  |
| Total inventories |  | $ | 1,281 |  |  | $ | 1,142 |  |

[0001137789-21-000028:notes:40]
[same as prior period, unchanged from 0001137789-21-000006:notes:40]

[0001137789-21-000028:notes:41]
[same as prior period, unchanged from 0001137789-21-000006:notes:41]

[0001137789-21-000028:notes:42]
| (Dollars in millions) |  | April 2,2021 |  | July 3,2020 |
| Property, equipment and leasehold improvements |  | $ | 10,384 |  |  | $ | 10,212 |  |
| Accumulated depreciation and amortization |  | (8,169) |  |  | (8,083) |  |
| Property, equipment and leasehold improvements, net |  | $ | 2,215 |  |  | $ | 2,129 |  |

[0001137789-21-000028:notes:43]
[same as prior period, unchanged from 0001137789-21-000006:notes:43]

[0001137789-21-000028:notes:44]
[same as prior period, unchanged from 0001137789-21-000006:notes:44]

[0001137789-21-000028:notes:45]
| (Dollars in millions) |  | April 2,2021 |  | July 3,2020 |
| Dividends payable |  | $ | 154 |  |  | $ | 167 |  |
| Other accrued expenses |  | 495 |  |  | 435 |  |
| Total accrued expenses |  | $ | 649 |  |  | $ | 602 |  |

[0001137789-21-000028:notes:46]
[same as prior period, unchanged from 0001137789-21-000006:notes:46]

[0001137789-21-000028:notes:47]
[same as prior period, unchanged from 0001137789-21-000006:notes:47]

[0001137789-21-000028:notes:48]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  |  |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at July 3, 2020 |  | $ | (24) |  |  |  |  | $ | (26) |  |  | $ | (16) |  |  | $ | (66) |  |
| Other comprehensive income before reclassifications |  | 20 |  |  |  |  | — |  |  | — |  |  | 20 |  |
| Amounts reclassified from AOCL |  | (9) |  |  |  |  | 2 |  |  | 15 |  |  | 8 |  |
| Other comprehensive income |  | 11 |  |  |  |  | 2 |  |  | 15 |  |  | 28 |  |
| Balance at April 2, 2021 |  | $ | (13) |  |  |  |  | $ | (24) |  |  | $ | (1) |  |  | $ | (38) |  |
| Balance at June 28, 2019 |  | $ | — |  |  |  |  | $ | (20) |  |  | $ | (14) |  |  | $ | (34) |  |
| Other comprehensive (loss) income before reclassifications |  | (27) |  |  |  |  | 2 |  |  | (8) |  |  | (33) |  |
| Amounts reclassified from AOCL |  | — |  |  |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive (loss) income |  | (27) |  |  |  |  | 2 |  |  | (8) |  |  | (33) |  |
| Balance at April 3, 2020 |  | $ | (27) |  |  |  |  | $ | (18) |  |  | $ | (22) |  |  | $ | (67) |  |


## us-gaap:DebtDisclosureTextBlock

[0001137789-21-000028:notes:49]
Credit Agreement

[0001137789-21-000028:notes:50]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement on February 20, 2019, which was most recently amended on January 13, 2021 (the “Credit Agreement”), increasing the size of the senior unsecured revolving credit facility (“Revolving Credit Facility”) and capping the indebtedness guaranteed by certain of Seagate HDD Cayman’s material subsidiaries to an amount $100 million less than the amount that would give rise to a guarantee requirement by such subsidiaries in respect of any series of senior notes. The Credit Agreement provides a $1.725 billion Revolving Credit Facility and a term loan facility in an aggregate principal amount of $500 million (“Term Loan”). The Revolving Credit Facility has a final maturity of February 20, 2024 and the Term Loan has a final maturity date of September 16, 2025. The loans made under the Revolving Credit Facility and the Term Loan will bear interest at a rate of the London Interbank Offered Rate (“LIBOR”) plus a variable margin for each facility that will be determined based on the corporate credit rating of the Company. The Revolving Credit Facility also allows such facility to increase by an additional $275 million, provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at least $25 million, and (iii) the existing commitments under such facility receive 0.50% most favored nation protection. An aggregate amount of up to $75 million of the Revolving Credit Facility is available for the issuance of letters of credit, and an aggregate amount of up to $50 million of such facility is also available for swing line loans.

[0001137789-21-000028:notes:51]
On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the Term Loan and the proceeds were used to repurchase a portion of its outstanding senior notes. The Term Loan is repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with the remaining balance payable upon maturity. The Company repaid $6 million and $12 million principal amount of the Term Loan during the three and nine months ended April 2, 2021, respectively.

[0001137789-21-000028:notes:52]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of April 2, 2021 and expects to be in compliance for the next 12 months.

[0001137789-21-000028:notes:53]
As of April 2, 2021, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the Revolving Credit Facility.

[0001137789-21-000028:notes:54]
Other Long-Term Debt

[0001137789-21-000028:notes:55]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March, 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the nine months ended April 2, 2021, $9 million aggregate principal amount of the 2022 Notes was repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. During the three and nine months ended April 3, 2020, the Company repurchased $23 million and $273 million aggregate principal amount of the 2022 Notes, respectively, for cash at a premium to their principal amount, plus accrued and unpaid interest, $250 million principal amount of which was repurchased pursuant to cash tender offers for certain senior notes on September 18, 2019 (the “Tender Offers”). The Company recorded an immaterial loss and a loss of $10 million, respectively, on repurchases during the nine months ended April 2, 2021 and April 3, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

[0001137789-21-000028:notes:56]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June, 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the nine months ended April 2, 2021, $5 million aggregate principal amount of the 2023 Notes was repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. During the three and nine months ended April 3, 2020, the Company repurchased $17 million and $217 million aggregate principal amount of the 2023 Notes for cash at a discount or at a premium to their principal amount, plus accrued and unpaid interest, respectively, $200 million principal amount of which was repurchased pursuant to the Tender Offers. The Company recorded a loss of $1 million and $10 million, respectively, on repurchases during the nine months ended April 2, 2021 and April 3, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

[0001137789-21-000028:notes:57]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March, 2024 (the “2024 Notes”). The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

[0001137789-21-000028:notes:58]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January, 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the nine months ended April 3, 2020, $170 million aggregate principal amount was repurchased pursuant to the Tender Offers. The Company recorded a loss of $8 million on repurchases during the nine months ended April 3, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

[0001137789-21-000028:notes:59]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June, 2027 (the “2027 Notes”). The interest on the 2027 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

[0001137789-21-000028:notes:60]
$500 million Aggregate Principal Amount of 4.091% Senior Notes due June, 2029 (the “June 2029 Notes”). The interest on the June 2029 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the June 2029 Notes is Seagate HDD Cayman, and the obligations under the June 2029 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

[0001137789-21-000028:notes:61]
$500 million Aggregate Principal Amount of 3.125% Senior Notes due July, 2029 (the “July 2029 Notes”). On December 8, 2020, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of the July 2029 Notes, which will mature on July 15, 2029. The obligations under the July 2029 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. The interest on the July 2029 Notes is payable semi-annually on January 15 and July 15 of each year, commencing on July 15, 2021. At any time before January 15, 2024, Seagate HDD Cayman may redeem some or all of the July 2029 Notes at a “make-whole” redemption price. The “make-whole” redemption price will be equal to (1) 100% of the principal amount of the July 2029 Notes redeemed, plus (2) the greater of (a) 1.0% of the principal amount of the July 2029 Notes and (b) the excess, if any, of (i) the present value at such redemption date of (x) the applicable redemption price of such July 2029 Notes that would apply if such July 2029 Notes were redeemed on January 15, 2024, plus (y) all remaining scheduled payments of interest due on such July 2029 Notes to and including January 15, 2024, computed using a discount rate equal to the applicable Treasury Rate as of such redemption date plus 50 basis points; over (ii) the sum of accrued and unpaid interest, if any, to, but excluding, the redemption date, plus the principal amount of such July 2029 Notes, plus (3) accrued and unpaid interest, if any, to, but excluding, the redemption date. At any time on or after January 15, 2024, Seagate HDD Cayman may redeem some or all of such July 2029 Notes at a price of 101.563%, 100.781% and 100.000%, after January 15, 2024, January 15, 2025 and January 15, 2026, respectively, plus accrued and unpaid interest thereon, if any, to, but excluding, the redemption date. In addition, Seagate HDD Cayman may redeem with the net cash proceeds from one or more equity offerings up to 40% of the July 2029 Notes before January 15, 2024, at a redemption price of 103.125%, plus accrued and unpaid interest to, but excluding, the redemption date.

[0001137789-21-000028:notes:62]
$500 million Aggregate Principal Amount of 4.125% Senior Notes due January, 2031 (the “January 2031 Notes”). The interest on the January 2031 Notes is payable semi-annually on January 15 and July 15 of each year. The issuer under the January 2031 Notes is Seagate HDD Cayman, and the obligations under the January 2031 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

[0001137789-21-000028:notes:63]
$500 million Aggregate Principal Amount of 3.375% Senior Notes due July, 2031 (the “July 2031 Notes”). On December 8, 2020, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of the July 2031 Notes, which will mature on July 15, 2031. The obligations under the July 2031 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. The interest on the July 2031 Notes is payable semi-annually on January 15 and July 15 of each year, commencing on July 15, 2021. At any time before January 15, 2026, Seagate HDD Cayman may redeem some or all of the July 2031 Notes at a “make-whole” redemption price. The “make-whole” redemption price will be equal to (1) 100% of the principal amount of the July 2031 Notes redeemed, plus (2) the greater of (a) 1.0% of the principal amount of the July 2031 Notes and (b) the excess, if any, of (i) the present value at such redemption date of (x) the applicable redemption price of such July 2031 Notes that would apply if such July 2031 Notes were redeemed on January 15, 2026, plus (y) all remaining scheduled payments of interest due on such July 2031 Notes to and including January 15, 2026, computed using a discount rate equal to the Treasury Rate as of such redemption date plus 50 basis points; over (ii) the sum of accrued and unpaid interest, if any, to, but excluding, the redemption date, plus the principal amount of such July 2031 Notes, plus (3) accrued and unpaid interest, if any, to, but excluding, the redemption date. At any time on or after January 15, 2026, Seagate HDD Cayman may redeem some or all of such July 2031 Notes at a price of 101.688%, 101.125%, 100.563% and 100.000%, after January 15, 2026, January 15, 2027, January 15, 2028 and January 15, 2029, respectively, plus accrued and unpaid interest thereon, if any, to, but excluding, the redemption date. In addition, Seagate HDD Cayman may redeem with the net cash proceeds from one or more equity offerings up to 40% of the July 2031 Notes before January 15, 2024, a redemption price of 103.375%, accrued and unpaid interest to, but excluding, the redemption date.
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December, 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001137789-21-000028:notes:64]
At April 2, 2021, future principal payments on long-term debt were as follows (in millions):

[0001137789-21-000028:notes:65]
| Fiscal Year |  | Amount |
| Remainder of 2021 |  | $ | 6 |  |
| 2022 |  | 245 |  |
| 2023 |  | 566 |  |
| 2024 |  | 525 |  |
| 2025 |  | 504 |  |
| Thereafter |  | 3,376 |  |
| Total |  | $ | 5,222 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001137789-21-000028:notes:66]
Income Taxes
The Company recorded income tax provisions of $10 million and $19 million in the three and nine months ended April 2, 2021, respectively. The income tax provision for the three months ended April 2, 2021 included approximately $4 million of net discrete tax benefit, primarily associated with filing of tax returns in various jurisdictions. The income tax provision for the nine months ended April 2, 2021 included approximately $15 million of net discrete tax benefit, primarily associated with net excess tax benefits related to share-based compensation expense, filing of tax returns in various jurisdictions, and postponement of the previously enacted United Kingdom tax rate change in the quarter ended October 2, 2020.

[0001137789-21-000028:notes:67]
During the nine months ended April 2, 2021, the Company’s unrecognized tax benefits excluding interest and penalties increased by approximately $18 million to $107 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. During the twelve months beginning April 3, 2021, the Company expects that its unrecognized tax benefits could be reduced by an immaterial amount, as a result of the expiration of certain statutes of limitation.

[0001137789-21-000028:notes:68]
The Company recorded income tax provisions of $18 million and $34 million in the three and nine months ended April 3, 2020, respectively. The discrete items in the income tax provision were not material for the three months ended April 3, 2020. The income tax provision for the nine months ended April 3, 2020 included approximately $13 million of net discrete tax benefits, primarily associated with net excess tax benefits related to share-based compensation expense.

[0001137789-21-000028:notes:69]
The Company’s income tax provision recorded for the three and nine months ended April 2, 2021 and April 3, 2020 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001137789-21-000028:notes:70]
[same as prior period, unchanged from 0001137789-21-000006:notes:71]

[0001137789-21-000028:notes:71]
The Company’s lease arrangements comprise operating leases with various expiration dates through 2067. The lease term includes the non-cancelable period of the lease, adjusted for options to extend or terminate the lease when it is reasonably certain that an option will be exercised.

[0001137789-21-000028:notes:72]
[same as prior period, unchanged from 0001137789-21-000006:notes:73]

[0001137789-21-000028:notes:73]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
| Operating lease cost |  | $ | 4 |  |  | $ | 6 |  |  | $ | 11 |  |  | $ | 17 |  |
| Variable lease cost |  | 1 |  |  | 1 |  |  | 3 |  |  | 3 |  |
| Total lease cost |  | $ | 5 |  |  | $ | 7 |  |  | $ | 14 |  |  | $ | 20 |  |
| Operating cash outflows from operating leases |  | $ | 5 |  |  | $ | 4 |  |  | $ | 14 |  |  | $ | 13 |  |

[0001137789-21-000028:notes:74]
|  |  | April 2,2021 |  | July 3,2020 |
| Weighted-average remaining lease term |  | 7.1 years |  | 13.2 years |
| Weighted-average discount rate |  | 6.02 | % |  | 6.53 | % |

[0001137789-21-000028:notes:75]
[same as prior period, unchanged from 0001137789-21-000006:notes:76]

[0001137789-21-000028:notes:76]
| (Dollars in millions) |  | Balance Sheet Location |  | April 2,2021 |  | July 3,2020 |
| ROU assets |  | Other assets, net |  | $ | 102 |  |  | $ | 103 |  |
| Current lease liabilities |  | Accrued expenses |  | $ | 15 |  |  | $ | 14 |  |
| Non-current lease liabilities |  | Other non-current liabilities |  | $ | 43 |  |  | $ | 49 |  |

[0001137789-21-000028:notes:77]
At April 2, 2021, future lease payments included in the measurement of lease liabilities were as follows (in millions):

[0001137789-21-000028:notes:78]
| Fiscal Year |  | Amount |
| Remainder of 2021 |  | $ | 4 |  |
| 2022 |  | 16 |  |
| 2023 |  | 12 |  |
| 2024 |  | 7 |  |
| 2025 |  | 5 |  |
| Thereafter |  | 25 |  |
| Total lease payments |  | 69 |  |
| Less: imputed interest |  | (11) |  |
| Present value of lease liabilities |  | $ | 58 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001137789-21-000028:notes:79]
Restructuring and Exit Costs
For the three months ended April 2, 2021, the Company recorded a net gain of $2 million comprised primarily of a gain of $3 million from the sale of a property. For the nine months ended April 2, 2021, the Company recorded restructuring charges of $1 million, which are comprised primarily of charges related to workforce reduction costs and facilities and other exit costs. All restructuring charges are reported in Restructuring and other, net on the Company’s Condensed Consolidated Statements of Operations.

[0001137789-21-000028:notes:80]
June 2020 Plan - On June 1, 2020, the Company committed to a restructuring plan (the “June 2020 Plan”) consistent with its long-term strategy to drive operational efficiencies, reduce its cost structure and invest in future opportunities. The June 2020 Plan included consolidating the Company’s Minnesota facilities into one location and reducing its headcount worldwide by approximately 500 employees. The June 2020 Plan was substantially completed during the quarter ended October 2, 2020.

[0001137789-21-000028:notes:81]
[same as prior period, unchanged from 0001137789-21-000006:notes:82]

[0001137789-21-000028:notes:82]
|  |  | June 2020 Plan |  | Other Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at July 3, 2020 |  | $ | 38 |  |  | $ | 2 |  |  | $ | 5 |  |  | $ | 3 |  |  | $ | 48 |  |
| Restructuring charges |  | — |  |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Cash payments |  | (37) |  |  | (1) |  |  | (8) |  |  | (1) |  |  | (47) |  |
| Adjustments |  | — |  |  | — |  |  | — |  |  | (1) |  |  | (1) |  |
| Accrual balances at April 2, 2021 |  | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 1 |  |  | $ | 5 |  |
| Total costs incurred to date as of April 2, 2021 |  | $ | 56 |  |  | $ | 2 |  |  | $ | 21 |  |  | $ | 28 |  |  | $ | 107 |  |
| Total expected charges to be incurred as of April 2, 2021 |  | $ | — |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  | $ | 7 |  |

[0001137789-21-000028:notes:83]
|  |  | Restructuring Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at June 28, 2019 |  | $ | 13 |  |  | $ | 17 |  |  | $ | 30 |  |
| Lease adoption adjustment |  | — |  |  | (11) |  |  | (11) |  |
| Restructuring charges |  | 22 |  |  | 1 |  |  | 23 |  |
| Cash payments |  | (29) |  |  | (3) |  |  | (32) |  |
| Adjustments |  | (4) |  |  | — |  |  | (4) |  |
| Accrual balances at April 3, 2020 |  | $ | 2 |  |  | $ | 4 |  |  | $ | 6 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001137789-21-000028:notes:84]
[same as prior period, unchanged from 0001137789-21-000006:notes:85]

[0001137789-21-000028:notes:85]
In the quarter ended October 4, 2019, the Company entered into certain interest rate swap agreements with a notional amount of $500 million to convert the variable interest rate on its Term Loan to fixed interest rates. The contracts will mature on September 16, 2025. The notional amount of the interest rate swap agreements was $488 million as of April 2, 2021. The objective of the interest rate swap agreements is to eliminate the variability of interest payment cash flows associated with the variable interest rate under the Term Loan. The Company designated the interest rate swaps as cash flow hedges.

[0001137789-21-000028:notes:86]
The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives on its Condensed Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The amount of net unrealized loss on cash flow hedges was $13 million and $24 million as of April 2, 2021 and as of July 3, 2020, respectively. As of April 2, 2021, the amount of existing net losses related to cash flow hedges recorded in Accumulated other comprehensive loss included a net loss of $7 million that is expected to be reclassified to earnings within twelve months.

[0001137789-21-000028:notes:87]
The Company de-designates its cash flow hedges when the forecasted hedged transactions affect earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss on the Company’s Condensed Consolidated Balance Sheets are reclassified into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company recognized a net gain of $8 million and $12 million in Cost of revenue related to the loss of hedge designation on discontinued cash flow hedges during the three and nine months ended April 2, 2021, respectively. The Company recognized a net loss of $1 million and $5 million in Interest expense related to the loss of hedge designation on discontinued cash flow hedges during the three and nine months ended April 2, 2021, respectively. The Company recognized a net gain of $1 million and an immaterial net loss in Other expense, net related to the loss of hedge designation on discontinued cash flow hedges during the three and nine months ended April 3, 2020, respectively.

[0001137789-21-000028:notes:88]
[same as prior period, unchanged from 0001137789-21-000006:notes:89]

[0001137789-21-000028:notes:89]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of April 2, 2021 and July 3, 2020. All foreign currency forward exchange contracts mature within 12 months.

[0001137789-21-000028:notes:90]
|  |  | As of April 2, 2021 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Singapore Dollar |  | $ | 165 |  |  | $ | 53 |  |
| Thai Baht |  | 131 |  |  | 38 |  |
| Chinese Renminbi |  | 72 |  |  | 22 |  |
| British Pound Sterling |  | 56 |  |  | 14 |  |
|  |  | $ | 424 |  |  | $ | 127 |  |

[0001137789-21-000028:notes:91]
[same as prior period, unchanged from 0001137789-21-000006:notes:92]

[0001137789-21-000028:notes:92]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its non-qualified deferred compensation plan: the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP’s liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP’s liabilities due to changes in the value of the investment options made by employees. As of April 2, 2021, the notional investments underlying the TRS amounted to $120 million and the contract term is through January 2022, settled on a monthly basis, limiting counterparty performance risk. The Company did not designate the TRS as a hedge, rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP’s liabilities.

[0001137789-21-000028:notes:93]
The following tables show the Company’s derivative instruments measured at gross fair value as reflected in the Condensed Consolidated Balance Sheets as of April 2, 2021 and July 3, 2020:

[0001137789-21-000028:notes:94]
|  |  | As of April 2, 2021 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance Sheet Location |  | Fair Value |  | Balance Sheet Location |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 2 |  |  | Accrued expenses |  | $ | (2) |  |
| Interest rate swap |  | Other current assets |  | — |  |  | Accrued expenses |  | (13) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 2 |  |  | Accrued expenses |  | (1) |  |
| Total return swap |  | Other current assets |  | 2 |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 6 |  |  |  |  | $ | (16) |  |

[0001137789-21-000028:notes:95]
[same as prior period, unchanged from 0001137789-21-000006:notes:96]

[0001137789-21-000028:notes:96]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three and nine months ended April 2, 2021:

[0001137789-21-000028:notes:97]
|  |  |  |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (3) |  |  | $ | 11 |  |
| Total return swap |  | Operating expenses |  | 6 |  |  | 22 |  |

[0001137789-21-000028:notes:98]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
|  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | $ | (5) |  |  | $ | 10 |  |  | Cost of revenue |  | $ | 8 |  |  | $ | 12 |  |  | Other, net |  | $ | (1) |  |  | $ | — |  |
| Interest rate swap |  | 9 |  |  | 10 |  |  | Interest expense |  | (1) |  |  | (5) |  |  | Interest expense |  | — |  |  | — |  |

[0001137789-21-000028:notes:99]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three and nine months ended April 3, 2020:

[0001137789-21-000028:notes:100]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |
|  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (3) |  |  | $ | (5) |  |
| Total return swap |  | Operating expenses |  | $ | (23) |  |  | $ | (16) |  |

[0001137789-21-000028:notes:101]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
|  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | $ | (2) |  |  | $ | (2) |  |  | Other, net |  | $ | — |  |  | $ | (1) |  |  | Other, net |  | $ | — |  |  | $ | — |  |
| Interest rate swap |  | (27) |  |  | (25) |  |  | Interest expense |  | 1 |  |  | 1 |  |  | Interest expense |  | — |  |  | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001137789-21-000028:notes:102]
[same as prior period, unchanged from 0001137789-21-000006:notes:103]

[0001137789-21-000028:notes:103]
[same as prior period, unchanged from 0001137789-21-000006:notes:104]

[0001137789-21-000028:notes:104]
[same as prior period, unchanged from 0001137789-21-000006:notes:105]

[0001137789-21-000028:notes:105]
[same as prior period, unchanged from 0001137789-21-000006:notes:106]

[0001137789-21-000028:notes:106]
[same as prior period, unchanged from 0001137789-21-000006:notes:107]

[0001137789-21-000028:notes:107]
[same as prior period, unchanged from 0001137789-21-000006:notes:108]

[0001137789-21-000028:notes:108]
[same as prior period, unchanged from 0001137789-21-000006:notes:109]

[0001137789-21-000028:notes:109]
[same as prior period, unchanged from 0001137789-21-000006:notes:110]

[0001137789-21-000028:notes:110]
[same as prior period, unchanged from 0001137789-21-000006:notes:111]

[0001137789-21-000028:notes:111]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item, that are measured at fair value on a recurring basis, excluding accrued interest components, as of April 2, 2021:

[0001137789-21-000028:notes:112]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 530 |  |  | $ | — |  |  | $ | — |  |  | $ | 530 |  |
| Total cash equivalents |  | 530 |  |  | — |  |  | — |  |  | 530 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Derivative assets |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total assets |  | $ | 531 |  |  | $ | 7 |  |  | $ | 18 |  |  | $ | 556 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 16 |  |  | $ | — |  |  | $ | 16 |  |
| Total liabilities |  | $ | — |  |  | $ | 16 |  |  | $ | — |  |  | $ | 16 |  |

[0001137789-21-000028:notes:113]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 530 |  |  | $ | — |  |  | $ | — |  |  | $ | 530 |  |
| Other current assets |  | 1 |  |  | 7 |  |  | — |  |  | 8 |  |
| Other assets, net |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Total assets |  | $ | 531 |  |  | $ | 7 |  |  | $ | 18 |  |  | $ | 556 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | 16 |  |  | $ | — |  |  | $ | 16 |  |
| Total liabilities |  | $ | — |  |  | $ | 16 |  |  | $ | — |  |  | $ | 16 |  |

[0001137789-21-000028:notes:114]
[same as prior period, unchanged from 0001137789-21-000006:notes:115]

[0001137789-21-000028:notes:115]
[same as prior period, unchanged from 0001137789-21-000006:notes:116]

[0001137789-21-000028:notes:116]
[same as prior period, unchanged from 0001137789-21-000006:notes:117]

[0001137789-21-000028:notes:117]
[same as prior period, unchanged from 0001137789-21-000006:notes:118]

[0001137789-21-000028:notes:118]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair value of all of its cash equivalents. For the cash equivalents in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry-standard data providers or other third-party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of April 2, 2021, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts, interest rate swaps and the TRS. The Company recognizes derivative financial instruments in its condensed consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001137789-21-000028:notes:119]
[same as prior period, unchanged from 0001137789-21-000006:notes:120]

[0001137789-21-000028:notes:120]
[same as prior period, unchanged from 0001137789-21-000006:notes:121]

[0001137789-21-000028:notes:121]
As of April 2, 2021 and July 3, 2020, the carrying value of the Company’s strategic investments was $163 million and $135 million, respectively. The Company’s strategic investments are recorded at fair value only if an impairment or observable price change is recognized in the current period. If an observable price change or impairment is recognized on the Company’s strategic investments during the period, the Company classifies these assets as Level 3 within the fair value hierarchy based on the nature of the fair value inputs. For the three and nine months ended April 2, 2021, the Company recorded upward adjustments of $10 million and $33 million, respectively, due to observable price changes of strategic investments, which are included in Other, net in the Company’s Condensed Consolidated Statement of Operations. For the three months ended April 2, 2021, there were no downward adjustments on strategic investments. For the nine months ended April 2, 2021, the Company recorded downward adjustments of $7 million to write down the carrying amount of certain investments to their fair value, which are included in Other, net in the Company’s Condensed Consolidated Statement of Operations. For the three months ended April 3, 2020, there were no downward adjustments on strategic investments. For the nine months ended April 3, 2020, the Company recorded a downward adjustment of $1 million in order to write down the carrying amount of an investment to its fair value. For the three and nine months ended April 3, 2020, there were no upward adjustments for strategic investments.

[0001137789-21-000028:notes:122]
[same as prior period, unchanged from 0001137789-21-000006:notes:123]

[0001137789-21-000028:notes:123]
[same as prior period, unchanged from 0001137789-21-000006:notes:124]

[0001137789-21-000028:notes:124]
|  |  | April 2, 2021 |  | July 3, 2020 |
| (Dollars in millions) |  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 4.250% Senior Notes due March 2022 |  | $ | 220 |  |  | $ | 226 |  |  | $ | 229 |  |  | $ | 237 |  |
| 4.750% Senior Notes due June 2023 |  | 540 |  |  | 578 |  |  | 546 |  |  | 576 |  |
| 4.875% Senior Notes due March 2024 |  | 499 |  |  | 538 |  |  | 498 |  |  | 541 |  |
| 4.750% Senior Notes due January 2025 |  | 479 |  |  | 522 |  |  | 479 |  |  | 517 |  |
| 4.875% Senior Notes due June 2027 |  | 504 |  |  | 556 |  |  | 504 |  |  | 549 |  |
| 4.091% Senior Notes due June 2029 |  | 460 |  |  | 510 |  |  | 456 |  |  | 523 |  |
| 3.125% Senior Notes due July 2029 |  | 500 |  |  | 484 |  |  | — |  |  | — |  |
| 4.125% Senior Notes due January 2031 |  | 499 |  |  | 508 |  |  | 499 |  |  | 524 |  |
| 3.375% Senior Notes due July 2031 |  | 500 |  |  | 481 |  |  | — |  |  | — |  |
| 5.750% Senior Notes due December 2034 |  | 489 |  |  | 557 |  |  | 489 |  |  | 543 |  |
| LIBOR Based Term Loan due September 2025 |  | 488 |  |  | 488 |  |  | 500 |  |  | 490 |  |
|  |  | 5,178 |  |  | 5,448 |  |  | 4,200 |  |  | 4,500 |  |
| Less: debt issuance costs |  | (36) |  |  | — |  |  | (25) |  |  | — |  |
| Debt, net of debt issuance costs |  | 5,142 |  |  | 5,448 |  |  | 4,175 |  |  | 4,500 |  |
| Less: current portion of debt, net of debt issuance costs |  | (245) |  |  | (251) |  |  | (19) |  |  | (19) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 4,897 |  |  | $ | 5,197 |  |  | $ | 4,156 |  |  | $ | 4,481 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001137789-21-000028:notes:125]
[same as prior period, unchanged from 0001137789-21-000006:notes:126]

[0001137789-21-000028:notes:126]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 229,556,907 shares were outstanding as of April 2, 2021, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of April 2, 2021.

[0001137789-21-000028:notes:127]
[same as prior period, unchanged from 0001137789-21-000006:notes:128]

[0001137789-21-000028:notes:128]
[same as prior period, unchanged from 0001137789-21-000006:notes:129]

[0001137789-21-000028:notes:129]
[same as prior period, unchanged from 0001137789-21-000006:notes:130]

[0001137789-21-000028:notes:130]
[same as prior period, unchanged from 0001137789-21-000006:notes:131]

[0001137789-21-000028:notes:131]
[same as prior period, unchanged from 0001137789-21-000006:notes:132]

[0001137789-21-000028:notes:132]
The Company’s Board of Directors increased the authorization for the repurchase of its outstanding ordinary shares by $3.0 billion on October 21, 2020, and $2.0 billion on February 22, 2021. As of April 2, 2021, $4.4 billion remained available for repurchase under the existing repurchase authorization limit.

[0001137789-21-000028:notes:133]
The following table sets forth information with respect to repurchases of ordinary shares during the nine months ended April 2, 2021:

[0001137789-21-000028:notes:134]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Repurchases of ordinary shares |  | 30 |  |  | $ | 1,830 |  |
| Tax withholding related to vesting of equity awards |  | 1 |  |  | 33 |  |
| Total |  | 31 |  |  | $ | 1,863 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001137789-21-000028:notes:135]
[same as prior period, unchanged from 0001137789-21-000006:notes:136]

[0001137789-21-000028:notes:136]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 1,950 |  |  | $ | 1,970 |  |  | $ | 5,299 |  |  | $ | 5,633 |  |
| Distributors |  | 455 |  |  | 465 |  |  | 1,297 |  |  | 1,389 |  |
| Retailers |  | 326 |  |  | 283 |  |  | 1,072 |  |  | 970 |  |
| Total |  | $ | 2,731 |  |  | $ | 2,718 |  |  | $ | 7,668 |  |  | $ | 7,992 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,268 |  |  | $ | 1,257 |  |  | $ | 3,680 |  |  | $ | 3,912 |  |
| Americas |  | 939 |  |  | 938 |  |  | 2,582 |  |  | 2,534 |  |
| EMEA |  | 524 |  |  | 523 |  |  | 1,406 |  |  | 1,546 |  |
| Total |  | $ | 2,731 |  |  | $ | 2,718 |  |  | $ | 7,668 |  |  | $ | 7,992 |  |

[0001137789-21-000028:notes:137]
[same as prior period, unchanged from 0001137789-21-000006:notes:138]

[0001137789-21-000028:notes:138]
[same as prior period, unchanged from 0001137789-21-000006:notes:139]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001137789-21-000028:notes:139]
[same as prior period, unchanged from 0001137789-21-000006:notes:140]

[0001137789-21-000028:notes:140]
[same as prior period, unchanged from 0001137789-21-000006:notes:141]

[0001137789-21-000028:notes:141]
[same as prior period, unchanged from 0001137789-21-000006:notes:142]

[0001137789-21-000028:notes:142]
[same as prior period, unchanged from 0001137789-21-000006:notes:143]

[0001137789-21-000028:notes:143]
[same as prior period, unchanged from 0001137789-21-000006:notes:144]

[0001137789-21-000028:notes:144]
[same as prior period, unchanged from 0001137789-21-000006:notes:145]

[0001137789-21-000028:notes:145]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product warranty return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the nine months ended April 2, 2021 and April 3, 2020 were as follows:

[0001137789-21-000028:notes:146]
|  |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 2,2021 |  | April 3,2020 |
| Balance, beginning of period |  | $ | 151 |  |  | $ | 195 |  |
| Warranties issued |  | 56 |  |  | 67 |  |
| Repairs and replacements |  | (62) |  |  | (65) |  |
| Changes in liability for pre-existing warranties, including expirations |  | (11) |  |  | (34) |  |
| Balance, end of period |  | $ | 134 |  |  | $ | 163 |  |


## us-gaap:EarningsPerShareTextBlock

[0001137789-21-000028:notes:147]
[same as prior period, unchanged from 0001137789-21-000006:notes:148]

[0001137789-21-000028:notes:148]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (In millions, except per share data) |  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 329 |  |  | $ | 320 |  |  | $ | 832 |  |  | $ | 838 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 233 |  |  | 261 |  |  | 246 |  |  | 263 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | 4 |  |  | 2 |  |  | 3 |  |  | 3 |  |
| Total shares for purpose of calculating diluted net income per share |  | 237 |  |  | 263 |  |  | 249 |  |  | 266 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.41 |  |  | $ | 1.23 |  |  | $ | 3.38 |  |  | $ | 3.19 |  |
| Diluted |  | 1.39 |  |  | 1.22 |  |  | 3.34 |  |  | 3.15 |  |

[0001137789-21-000028:notes:149]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share were not material for the three and nine months ended April 2, 2021 and April 3, 2020.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001137789-21-000028:notes:150]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001137789-21-000028:notes:151]
Litigation

[0001137789-21-000028:notes:152]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al. On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “‘635 patent”) and U.S. Patent No. 5,638,267 (the “‘267 patent”), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants were infringing U.S. Patent No. 6,314,473 (the “‘473 patent”). The district court ruled in 2010 that the ‘267 patent was out of the case.

[0001137789-21-000028:notes:153]
On August 16, 2011, the district court granted in part and denied in part the Company’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that the Company did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by the Company because the Company’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001137789-21-000028:notes:154]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial is scheduled to begin on February 7, 2022. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.

[0001137789-21-000028:notes:155]
Seagate Technology LLC, et al. v. NHK Spring Co. Ltd. and TDK Corporation, et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology International filed a complaint in the United States District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc., and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Company had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Company paid artificially high prices on its purchases of suspension assemblies. The Company seeks to recover the overcharges it paid for suspension assemblies, as well as additional relief permitted by law.

[0001137789-21-000028:notes:156]
Nidec Corporation v. Seagate Technology LLC, et al. On January 18, 2021, Nidec Corporation filed a complaint against Seagate Technology LLC, Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology (Netherlands) B.V. in the United States District Court for the District of Delaware, alleging infringement of the following patents: U.S. Patent No. 8,737,017, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,742,239, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,935,528, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 10,407,775, titled “Base Plate, Hard Disk Drive, and Method of Manufacturing Base Plate,” and U.S. Patent No. 10,460,767, titled “Base Member Including Information Mark and Insulating Coating Layer, and Disk Drive Apparatus Including the Same.” The complaint seeks unspecified compensatory damages and other relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001137789-21-000028:notes:157]
Environmental Matters

[0001137789-21-000028:notes:158]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001137789-21-000028:notes:159]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001137789-21-000028:notes:160]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001137789-21-000028:notes:161]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001137789-21-000028:notes:162]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the U.S., Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001137789-21-000028:notes:163]
Other Matters

[0001137789-21-000028:notes:164]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:SubsequentEventsTextBlock

[0001137789-21-000028:notes:165]
Dividend Declared

[0001137789-21-000028:notes:166]
On April 22, 2021, the Company’s Board of Directors declared a quarterly cash dividend of $0.67 per share, which will be payable on July 7, 2021 to shareholders of record as of the close of business on May 12, 2021.
