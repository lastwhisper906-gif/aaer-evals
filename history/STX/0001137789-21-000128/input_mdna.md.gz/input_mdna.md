# STX MD&A — 0001137789-21-000128


## mdna

[0001137789-21-000128:mdna:1]
[same as prior period, unchanged from 0001137789-21-000028:mdna:1]

[0001137789-21-000128:mdna:2]
The following is a discussion of the financial condition, changes in financial condition and results of operations for our fiscal quarters ended October 1, 2021, July 2, 2021 and October 2, 2020, referred to herein as the “September 2021 quarter,” the “June 2021 quarter,” and the “September 2020 quarter,” respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The September 2021 quarter, June 2021 quarter and the September 2020 quarter were each 13 weeks.

[0001137789-21-000128:mdna:3]
You should read this discussion in conjunction with financial information and related notes included elsewhere in this report. Unless the context indicates otherwise, as used herein, the terms “we,” “us,” “Seagate,” the “Company” and “our” refer collectively to Seagate Technology Holdings plc, an Irish public limited company, and its subsidiaries. References to “$” or “dollars” are to United States dollars.

[0001137789-21-000128:mdna:4]
•the uncertainty in global economic and political conditions, or adverse changes in the level of economic activity in the major regions in which we do business;

[0001137789-21-000128:mdna:5]
[same as prior period, unchanged from 0001137789-21-000028:mdna:5]

[0001137789-21-000128:mdna:6]
[same as prior period, unchanged from 0001137789-21-000028:mdna:6]

[0001137789-21-000128:mdna:7]
•the impact of variable demand, including ongoing demand variation related to the COVID-19 pandemic, changes in market demand, and an adverse pricing environment for storage products;

[0001137789-21-000128:mdna:8]
•the Company’s ability to effectively manage its debt obligations and comply with certain covenants in its credit facilities with respect to financial ratios and financial condition tests and its ability to maintain a favorable cash liquidity position;

[0001137789-21-000128:mdna:9]
[same as prior period, unchanged from 0001137789-21-000028:mdna:10]

[0001137789-21-000128:mdna:10]
[same as prior period, unchanged from 0001137789-21-000028:mdna:11]

[0001137789-21-000128:mdna:11]
•the effects of the COVID-19 pandemic and related individual, business and government responses on the global economy and their impact on the Company’s business, operations and financial results;

[0001137789-21-000128:mdna:12]
•disruptions to the Company’s supply chain or production capabilities, including ongoing shortages of certain materials, any electricity restrictions and related increases in logistics and operation costs;

[0001137789-21-000128:mdna:13]
[same as prior period, unchanged from 0001137789-21-000028:mdna:14]

[0001137789-21-000128:mdna:14]
•changes in tax laws; the impact of trade barriers, such as import/export duties and restrictions, sanctions, tariffs and quotas, imposed by the U.S. or other countries in which the Company conducts business; the evolving legal and regulatory, economic, environmental and administrative climate in the international markets where the Company operates; and

[0001137789-21-000128:mdna:15]
[same as prior period, unchanged from 0001137789-21-000028:mdna:16]

[0001137789-21-000128:mdna:16]
27

[0001137789-21-000128:mdna:17]
[same as prior period, unchanged from 0001137789-21-000028:mdna:17]

[0001137789-21-000128:mdna:18]
•Overview of the September 2021 quarter. Highlights of events in the September 2021 quarter that impacted our financial position.

[0001137789-21-000128:mdna:19]
•Results of Operations. Analysis of our financial results comparing the September 2021 quarter to the June 2021 quarter and the September 2020 quarter.

[0001137789-21-000128:mdna:20]
[same as prior period, unchanged from 0001137789-21-000028:mdna:20]

[0001137789-21-000128:mdna:21]
[same as prior period, unchanged from 0001137789-21-000028:mdna:21]

[0001137789-21-000128:mdna:22]
For an overview of our business, see “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies—Organization.”

[0001137789-21-000128:mdna:23]
Overview of the September 2021 quarter

[0001137789-21-000128:mdna:24]
During the September 2021 quarter, we shipped 159 exabytes of HDD storage capacity. We generated revenue of approximately $3.1 billion and gross margin of 31% and our operating cash flow was $496 million. We repurchased approximately 5 million of our ordinary shares for $425 million and paid $153 million in dividends.

[0001137789-21-000128:mdna:25]
[same as prior period, unchanged from 0001137789-21-000028:mdna:25]

[0001137789-21-000128:mdna:26]
The COVID-19 pandemic has resulted in a widespread health crisis and numerous disease control measures being taken to limit its spread, the effects of which began during our quarter ended April 3, 2020. We continued to experience certain supply chain disruptions during the September 2021 quarter, as well as higher logistics and operational costs due to the COVID-19 pandemic and other supply chain constraints, which we expect to continue at least for the remainder of fiscal year 2022. Our customers also continued to experience certain supply chain and demand disruptions during the September 2021 quarter, resulting in demand variations across certain of our end markets, which we anticipate will continue at least for the remainder of fiscal year 2022. We are continuing to actively monitor the effects and potential impacts of the COVID-19 pandemic on all aspects of our business, liquidity and capital resources. We are also actively working on opportunities to lower our cost structure and drive further operational efficiencies. We are complying with governmental rules and guidelines across all of our sites. Although we are unable to predict the impact of COVID-19 on our business, results of operations, liquidity or capital resources at this time, we expect we will be negatively affected if the pandemic and related public and private health measures result in substantial manufacturing or supply chain problems, substantial reductions in demand due to disruptions in the operations of our customers or partners, disruptions in local and global economies, volatility in the global financial markets, sustained reductions or volatility in overall demand trends, restrictions on the export or shipment of our products, or other unexpected ramifications from the COVID-19 pandemic. For a further discussion of the uncertainties and business risks associated with the COVID-19 pandemic, see the section entitled “Risk Factors” in Part I, Item 1A of our Annual Report on Form 10-K for the fiscal year ended July 2, 2021.

[0001137789-21-000128:mdna:27]
28

[0001137789-21-000128:mdna:28]
[same as prior period, unchanged from 0001137789-21-000028:mdna:30]

[0001137789-21-000128:mdna:29]
[same as prior period, unchanged from 0001137789-21-000028:mdna:31]

[0001137789-21-000128:mdna:30]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 1,2021 |  | July 2,2021 |  | October 2,2020 |
| Revenue |  | $ | 3,115 |  |  | $ | 3,013 |  |  | $ | 2,314 |  |
| Cost of revenue |  | 2,159 |  |  | 2,128 |  |  | 1,718 |  |
| Gross profit |  | 956 |  |  | 885 |  |  | 596 |  |
| Product development |  | 233 |  |  | 232 |  |  | 223 |  |
| Marketing and administrative |  | 133 |  |  | 136 |  |  | 118 |  |
| Amortization of intangibles |  | 3 |  |  | 3 |  |  | 3 |  |
| Restructuring and other, net |  | 1 |  |  | 7 |  |  | 1 |  |
| Income from operations |  | 586 |  |  | 507 |  |  | 251 |  |
| Other expense, net |  | (53) |  |  | (10) |  |  | (30) |  |
| Income before income taxes |  | 533 |  |  | 497 |  |  | 221 |  |
| Provision (benefit) for income taxes |  | 7 |  |  | 15 |  |  | (2) |  |
| Net income |  | $ | 526 |  |  | $ | 482 |  |  | $ | 223 |  |

[0001137789-21-000128:mdna:31]
|  |  | For the Three Months Ended |
|  |  | October 1,2021 |  | July 2,2021 |  | October 2,2020 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 69 |  |  | 71 |  |  | 74 |  |
| Gross profit |  | 31 |  |  | 29 |  |  | 26 |  |
| Product development |  | 8 |  |  | 8 |  |  | 10 |  |
| Marketing and administrative |  | 4 |  |  | 4 |  |  | 5 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |
| Restructuring and other, net |  | — |  |  | — |  |  | — |  |
| Income from operations |  | 19 |  |  | 17 |  |  | 11 |  |
| Other expense, net |  | (2) |  |  | (1) |  |  | (1) |  |
| Income before income taxes |  | 17 |  |  | 16 |  |  | 10 |  |
| Provision (benefit) for income taxes |  | — |  |  | — |  |  | — |  |
| Net income |  | 17 | % |  | 16 | % |  | 10 | % |

[0001137789-21-000128:mdna:32]
29

[0001137789-21-000128:mdna:33]
[same as prior period, unchanged from 0001137789-21-000028:mdna:35]

[0001137789-21-000128:mdna:34]
The following table summarizes information regarding consolidated revenues by channel, geography and market, and HDD exabytes shipped by market and price per terabyte:

[0001137789-21-000128:mdna:35]
|  |  | For the Three Months Ended |  |  |
|  |  | October 1,2021 |  | July 2,2021 |  | October 2,2020 |  |  |  |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 74 | % |  | 70 | % |  | 69 | % |  |  |  |  |
| Distributors |  | 16 | % |  | 18 | % |  | 16 | % |  |  |  |  |
| Retailers |  | 10 | % |  | 12 | % |  | 15 | % |  |  |  |  |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 51 | % |  | 50 | % |  | 48 | % |  |  |  |  |
| Americas |  | 35 | % |  | 36 | % |  | 35 | % |  |  |  |  |
| EMEA |  | 14 | % |  | 14 | % |  | 17 | % |  |  |  |  |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 65 | % |  | 62 | % |  | 58 | % |  |  |  |  |
| Legacy |  | 27 | % |  | 29 | % |  | 34 | % |  |  |  |  |
| Other |  | 8 | % |  | 9 | % |  | 8 | % |  |  |  |  |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 132 |  |  | 123 |  |  | 86 |  |  |  |  |  |
| Legacy |  | 27 |  |  | 29 |  |  | 28 |  |  |  |  |  |
| Total |  | 159 |  |  | 152 |  |  | 114 |  |  |  |  |  |
| HDD Price per Terabyte |  | $ | 18 |  |  | $ | 18 |  |  | $ | 19 |  |  |  |  |  |

[0001137789-21-000128:mdna:36]
_________________________________

[0001137789-21-000128:mdna:37]
(1) Revenue is attributed to geography based on bill from locations.

[0001137789-21-000128:mdna:38]
Revenue in the September 2021 quarter increased by $102 million from the June 2021 quarter primarily due to an increase in mass capacity storage exabytes shipped as a result of higher demand for our mass capacity products, partially offset by a decrease in legacy market exabytes shipped.

[0001137789-21-000128:mdna:39]
Revenue in the September 2021 quarter increased by $801 million from the September 2020 quarter primarily due to an increase in mass capacity storage exabytes shipped as a result of higher demand for our mass capacity products, partially offset by a decrease in legacy market exabytes shipped.

[0001137789-21-000128:mdna:40]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 13% of gross revenue for the September 2021 quarter, 14% for the July 2021 quarter and 15% for the September 2020 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-21-000128:mdna:41]
[same as prior period, unchanged from 0001137789-21-000028:mdna:42]

[0001137789-21-000128:mdna:42]
|  |  | For the Three Months Ended |  |  |  |  |
| (Dollars in millions) |  | October 1,2021 |  | July 2,2021 |  | October 2,2020 |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 2,159 |  |  | $ | 2,128 |  |  | $ | 1,718 |  |  |  |  |  |  |  |  |  |
| Gross profit |  | 956 |  |  | 885 |  |  | 596 |  |  |  |  |  |  |  |  |  |
| Gross margin |  | 31 | % |  | 29 | % |  | 26 | % |  |  |  |  |  |  |  |  |

[0001137789-21-000128:mdna:43]
Gross margin for the September 2021 quarter increased compared to the June 2021 quarter primarily driven by improved product mix and favorable pricing conditions, partially offset by higher component and logistic costs.

[0001137789-21-000128:mdna:44]
Gross margin for the September 2021 quarter increased compared to the September 2020 quarter primarily driven by improved product mix, partially offset by higher component and logistic costs.

[0001137789-21-000128:mdna:45]
In the September 2021 quarter, total warranty cost was 0.9% of revenue and included an unfavorable change in estimates of prior warranty accruals of 0.2% of revenue primarily due to changes to our estimated future product return rates. Warranty cost related to new shipments was 0.7%, 0.7% and 0.8% of revenue for the September 2021 quarter, June 2021 quarter and September 2020 quarter, respectively.

[0001137789-21-000128:mdna:46]
[same as prior period, unchanged from 0001137789-21-000028:mdna:48]

[0001137789-21-000128:mdna:47]
|  |  | For the Three Months Ended |  |  |  |  |
| (Dollars in millions) |  | October 1,2021 |  | July 2,2021 |  | October 2,2020 |  |  |  |  |  |  |  |  |
| Product development |  | $ | 233 |  |  | $ | 232 |  |  | $ | 223 |  |  |  |  |  |  |  |  |  |
| Marketing and administrative |  | 133 |  |  | 136 |  |  | 118 |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  | 3 |  |  | 3 |  |  | 3 |  |  |  |  |  |  |  |  |  |
| Restructuring and other, net |  | 1 |  |  | 7 |  |  | 1 |  |  |  |  |  |  |  |  |  |
| Operating expenses |  | $ | 370 |  |  | $ | 378 |  |  | $ | 345 |  |  |  |  |  |  |  |  |  |

[0001137789-21-000128:mdna:48]
Product development expense. Product development expense for the September 2021 quarter compared to the June 2021 quarter remained relatively flat.

[0001137789-21-000128:mdna:49]
Product development expense increased by $10 million in the September 2021 quarter compared to the September 2020 quarter primarily due to a $9 million increase in variable compensation expense and a $3 million increase in materials expense, partially offset by a $3 million decrease in outside services expense.

[0001137789-21-000128:mdna:50]
Marketing and administrative expense. Marketing and administrative expense decreased by $3 million for the September 2021 quarter compared to the June 2021 quarter primarily due to a $4 million decrease in outside services expense.

[0001137789-21-000128:mdna:51]
Marketing and administrative expense increased by $15 million in the September 2021 quarter compared to the September 2020 quarter primarily due to a $6 million increase in variable compensation expense, a $3 million increase in outside services expense, a $2 million increase in information technology and software costs and a $2 million increase in compensation and other employee benefits.

[0001137789-21-000128:mdna:52]
Amortization of intangibles. Amortization of intangibles for the September 2021 quarter remained flat compared to the June 2021 quarter and the September 2020 quarter.

[0001137789-21-000128:mdna:53]
Restructuring and other, net. Restructuring and other, net for the September 2021 quarter and the September 2020 quarter was not material.

[0001137789-21-000128:mdna:54]
Restructuring and other, net for the June 2021 quarter was primarily comprised of workforce reduction costs and supplier transition costs, partially offset by a gain upon termination of an operating lease.

[0001137789-21-000128:mdna:55]
[same as prior period, unchanged from 0001137789-21-000028:mdna:61]

[0001137789-21-000128:mdna:56]
|  |  | For the Three Months Ended |  |  |  |  |
| (Dollars in millions) |  | October 1,2021 |  | July 2,2021 |  | October 2,2020 |  |  |  |  |  |  |  |  |
| Other expense, net |  | $ | (53) |  |  | $ | (10) |  |  | $ | (30) |  |  |  |  |  |  |  |  |  |

[0001137789-21-000128:mdna:57]
Other expense, net. Other expense, net increased by $43 million for the September 2021 quarter compared to the June 2021 quarter primarily due to a $45 million decrease in gains from our strategic investments and a $3 million increase in loss from de-designated cash flow hedges, partially offset by a $5 million strategic investment impairment charge in the June 2021 quarter.

[0001137789-21-000128:mdna:58]
Other expense, net. Other expense, net increased by $23 million for the September 2021 quarter compared to the September 2020 primarily due to a $22 million decrease in gains from our strategic investments, a $9 million increase in interest expense from the issuances of long-term debt and an $8 million increase in loss from de-designated cash flow hedges, partially offset by a $15 million decrease in foreign exchange remeasurement expense.

[0001137789-21-000128:mdna:59]
31

[0001137789-21-000128:mdna:60]
[same as prior period, unchanged from 0001137789-21-000028:mdna:66]

[0001137789-21-000128:mdna:61]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 1,2021 |  | July 2,2021 |  | October 2,2020 |
| Provision (benefit) for income taxes |  | $ | 7 |  |  | $ | 15 |  |  | $ | (2) |  |

[0001137789-21-000128:mdna:62]
Our income tax provision of $7 million for the three months ended October 1, 2021 included approximately $10 million of net discrete tax benefit primarily associated with net excess tax benefits related to share-based compensation expense.

[0001137789-21-000128:mdna:63]
During the three months ended October 1, 2021, our unrecognized tax benefits excluding interest and penalties increased by approximately $4 million to $112 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. During the twelve months beginning October 2, 2021, we expect that our unrecognized tax benefits could be reduced by an immaterial amount, as a result of the expiration of certain statutes of limitation.

[0001137789-21-000128:mdna:64]
Our income tax benefit of $2 million for the three months ended October 2, 2020 included approximately $10 million of net discrete tax benefit of which $4 million was associated with net excess tax benefits related to share-based compensation expense and $3 million was associated with the postponement of the previously enacted United Kingdom tax rate change in the quarter ended October 2, 2020.

[0001137789-21-000128:mdna:65]
Our income tax provision recorded for the three months ended October 1, 2021 and October 2, 2020 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-21-000128:mdna:66]
[same as prior period, unchanged from 0001137789-21-000028:mdna:73]

[0001137789-21-000128:mdna:67]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash will continue to be sufficient to fund our operations and meet our cash needs for the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs, will allow us to manage the potential impacts of the COVID-19 pandemic on our business operations for the foreseeable future. However, some challenges posed by the COVID-19 pandemic to our industry and to our business continue to remain uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to the COVID-19 pandemic.

[0001137789-21-000128:mdna:68]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of October 1, 2021.

[0001137789-21-000128:mdna:69]
[same as prior period, unchanged from 0001137789-21-000028:mdna:76]

[0001137789-21-000128:mdna:70]
| (Dollars in millions) |  | October 1,2021 |  | July 2,2021 |  | Change |
| Cash and cash equivalents |  | $ | 991 |  |  | $ | 1,209 |  |  | $ | (218) |  |

[0001137789-21-000128:mdna:71]
Our cash and cash equivalents as of October 1, 2021 decreased by $218 million from July 2, 2021 primarily as a result of the repurchases of our ordinary shares of $425 million, dividends paid to our shareholders of $153 million, and payments for capital expenditures of $117 million, partially offset by net cash of $496 million provided by operating activities.

[0001137789-21-000128:mdna:72]
[same as prior period, unchanged from 0001137789-21-000028:mdna:79]

[0001137789-21-000128:mdna:73]
Cash provided by operating activities for the three months ended October 1, 2021 was $496 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-21-000128:mdna:74]
•an increase of $143 million in accounts receivable, primarily due to an increase in revenue;

[0001137789-21-000128:mdna:75]
•a decrease of $92 million in accrued employee compensation, primarily due to cash paid to our employees as part of our discretionary spending plans;

[0001137789-21-000128:mdna:76]
•partially offset by an increase of $28 million in accounts payable, primarily due to an increase in direct materials purchased; and

[0001137789-21-000128:mdna:77]
•a decrease of $16 million in inventories, primarily due to increase of shipments, partially offset by an increase in materials purchased.

[0001137789-21-000128:mdna:78]
[same as prior period, unchanged from 0001137789-21-000028:mdna:85]

[0001137789-21-000128:mdna:79]
Cash used in investing activities for the three months ended October 1, 2021 was $120 million, primarily attributable to the following activities:

[0001137789-21-000128:mdna:80]
•payments for the purchase of property, equipment and leasehold improvements of $117 million; and

[0001137789-21-000128:mdna:81]
•payments for the purchase of investments of $18 million;

[0001137789-21-000128:mdna:82]
•offset by proceeds from the sale of investments of $15 million.

[0001137789-21-000128:mdna:83]
[same as prior period, unchanged from 0001137789-21-000028:mdna:92]

[0001137789-21-000128:mdna:84]
Cash used in financing activities of $594 million for the three months ended October 1, 2021 was primarily attributable to the following activities:

[0001137789-21-000128:mdna:85]
•payments for the repurchase of our ordinary shares of $425 million;

[0001137789-21-000128:mdna:86]
•payments for dividends of $153 million;

[0001137789-21-000128:mdna:87]
•payments for taxes related to net share settlement of equity awards of $43 million; and

[0001137789-21-000128:mdna:88]
•payments for the repurchase of long-term debt of $6 million;

[0001137789-21-000128:mdna:89]
•partially offset by proceeds from the issuance of ordinary shares under employee share plans of $33 million.

[0001137789-21-000128:mdna:90]
[same as prior period, unchanged from 0001137789-21-000028:mdna:101]

[0001137789-21-000128:mdna:91]
Our primary sources of liquidity as of October 1, 2021, consist of: (1) approximately $1 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.725 billion available for borrowing under our senior unsecured revolving credit facility (“Revolving Credit Facility”), which is part of our credit agreement (the “Credit Agreement”).

[0001137789-21-000128:mdna:92]
On October 14, 2021, our subsidiary Seagate HDD Cayman entered into an amendment to the Credit Agreement (“Fifth Amendment”), which provides for a new term loan facility in the aggregate principal amount of $1.2 billion that was extended in two tranches of $600 million each (“Term Loan A1” and “Term Loan A2” and together the “Term Loans”). The proceeds of the Term Loan A1 and Term Loan A2 may be used for general corporate purposes, to refinance or repay our existing term loan (“September 2019 Term Loan”) and to refinance or repay our 4.25% notes due March 1, 2022. Term Loan A1 and Term Loan A2 were each drawn in full on the closing date for the Fifth Amendment. On October 14, 2021, we utilized part of the proceeds of Term Loan A1 to fully repay the $475 million principal amount outstanding of our September 2019 Term Loan.

[0001137789-21-000128:mdna:93]
In addition, pursuant to the Amendment, the maturity date for the revolving loan commitments was extended until October 14, 2026, the revolving commitments were increased to $1.75 billion and the interest rate margins for the Revolving Credit Facility was amended to LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of our Company. See “Part I, Item 1. Financial Statements—Note 3. Debt” for information regarding our amended Credit Agreement.

[0001137789-21-000128:mdna:94]
As of October 1, 2021, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing. The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount.

[0001137789-21-000128:mdna:95]
[same as prior period, unchanged from 0001137789-21-000028:mdna:105]

[0001137789-21-000128:mdna:96]
For fiscal year 2022, we expect capital expenditures to be at the low end of our long-term targeted range of 4% to 6% of revenue. We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We may raise additional capital from time to time and will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-21-000128:mdna:97]
From time to time, we may repurchase any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase outstanding senior notes pursuant to the terms of the applicable indenture.

[0001137789-21-000128:mdna:98]
During the September 2021 quarter, our Board of Directors declared dividends of $0.67 per share, totaling $151 million, which were paid on October 6, 2021. On October 22, 2021, our Board of Directors declared a quarterly cash dividend of $0.70 per share, payable on January 5, 2022 to shareholders of record at the close of business on December 22, 2021.

[0001137789-21-000128:mdna:99]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means, including through the use of derivative transactions. As of October 1, 2021, $3.8 billion remained available for repurchases under our existing repurchase authorization. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-21-000128:mdna:100]
[same as prior period, unchanged from 0001137789-21-000028:mdna:110]

[0001137789-21-000128:mdna:101]
[same as prior period, unchanged from 0001137789-21-000028:mdna:111]

[0001137789-21-000128:mdna:102]
Other than as described in “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies”, there have been no other material changes in our critical accounting policies and estimates. Refer to “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended July 2, 2021, as filed with the SEC on August 6, 2021, for a discussion of our critical accounting policies and estimates.

[0001137789-21-000128:mdna:103]
[same as prior period, unchanged from 0001137789-21-000028:mdna:113]

[0001137789-21-000128:mdna:104]
[same as prior period, unchanged from 0001137789-21-000028:mdna:114]
