# STX note change history — 0001137789-21-000028 → 0001137789-21-000128


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-10-28):
[0001137789-21-000128:note_history:1]
Nidec Corporation v. Seagate Technology LLC, et al. On January 18, 2021, Nidec Corporation filed a complaint against Seagate Technology LLC, Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology (Netherlands) B.V. in the United States District Court for the District of Delaware, alleging infringement of the following patents: U.S. Patent No. 8,737,017, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,742,239, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,935,528, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 10,407,775, titled “Base Plate, Hard Disk Drive, and Method of Manufacturing Base Plate,” and U.S. Patent No. 10,460,767, titled “Base Member Including Information Mark and Insulating Coating Layer, and Disk Drive Apparatus Including the Same.” The complaint seeks unspecified compensatory damages and other relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. On July 20, 2021, the court stayed the case pending the result of an arbitration between the parties. The arbitration hearing commenced on October 18, 2021. The Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2021-04-29, similarity 0.822):
[0001137789-21-000028:note_history:1]
Nidec Corporation v. Seagate Technology LLC, et al. On January 18, 2021, Nidec Corporation filed a complaint against Seagate Technology LLC, Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology (Netherlands) B.V. in the United States District Court for the District of Delaware, alleging infringement of the following patents: U.S. Patent No. 8,737,017, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,742,239, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,935,528, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 10,407,775, titled “Base Plate, Hard Disk Drive, and Method of Manufacturing Base Plate,” and U.S. Patent No. 10,460,767, titled “Base Member Including Information Mark and Insulating Coating Layer, and Disk Drive Apparatus Including the Same.” The complaint seeks unspecified compensatory damages and other relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- removed (2021-10-28):
[0001137789-21-000028:note_history:2]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al. On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “‘635 patent”) and U.S. Patent No. 5,638,267 (the “‘267 patent”), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants were infringing U.S. Patent No. 6,314,473 (the “‘473 patent”). The district court ruled in 2010 that the ‘267 patent was out of the case.

- removed (2021-10-28):
[0001137789-21-000028:note_history:3]
On August 16, 2011, the district court granted in part and denied in part the Company’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that the Company did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by the Company because the Company’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-10-28):
[0001137789-21-000128:note_history:4]
Seagate Technology Holdings plc (“STX”) and its subsidiaries (collectively, unless the context otherwise indicates, the “Company”) is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”), solid state hybrid drives (“SSHDs”), storage subsystems, as well as a scalable edge-to-cloud mass data platform that includes data transfer shuttles and a storage-as-a-service cloud.
  (was, 2021-04-29, similarity 0.8689):
[0001137789-21-000028:note_history:4]
Seagate Technology plc (“STX”) and its subsidiaries (collectively, unless the context otherwise indicates, the “Company”) is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”), solid state hybrid drives (“SSHDs”) and storage subsystems.

- added (2021-10-28):
[0001137789-21-000128:note_history:5]
HDDs are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. HDDs continue to be the primary medium of mass data storage due to their performance attributes, reliability, high capacities, superior quality and cost effectiveness. Complementing existing storage architectures, SSDs use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory. In contrast to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high-capacity HDD and a smaller SSD acting as a cache to improve performance of frequently accessed data.

- added (2021-10-28):
[0001137789-21-000128:note_history:6]
The Company’s HDD products are designed for mass capacity storage and legacy markets. Mass capacity storage involves well-established use cases—such as hyperscale data centers and public clouds as well as emerging use cases. Legacy markets include markets the Company continues to service but that it does not plan to invest in significantly. The Company’s HDD and SSD product portfolio includes Serial Advanced Technology Attachment, Serial Attached SCSI and Non-Volatile Memory Express based designs to support a wide variety of mass capacity and legacy applications.

- added (2021-10-28):
[0001137789-21-000128:note_history:7]
The Company’s system portfolio includes storage subsystems for enterprises, cloud service providers, scale-out storage servers and original equipment manufacturers (“OEMs”). Engineered for modularity, mobility, capacity and performance, these solutions include the Company’s enterprise HDDs and SSDs, enabling customers to integrate powerful, scalable storage within legacy environments or build new ecosystems from the ground up in a secure, cost-effective manner.

- added (2021-10-28):
[0001137789-21-000128:note_history:8]
The Company’s Lyve portfolio provides a simple, cost-efficient and secure way to manage massive volumes of data across the distributed enterprise. The Lyve platform includes a shuttle solution that enables enterprises to transfer massive amounts of data from endpoints to the core cloud, a storage-as-a-service cloud that provides frictionless mass capacity storage at the metro edge, a converged object storage solution enabling efficient capture and consolidation of massive data sets and Cortx, an open-source object storage software optimized for mass capacity and data intensive workloads.

- added (2021-10-28):
[0001137789-21-000128:note_history:9]
The unaudited Condensed Consolidated Financial Statements of the Company were prepared in accordance with United States (“U.S.”) Generally Accepted Accounting Principles (“GAAP”). The Company’s unaudited condensed consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

- changed (2021-10-28):
[0001137789-21-000128:note_history:10]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. These estimates and assumptions include the impact of the COVID-19 pandemic. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements.
  (was, 2021-04-29, similarity 0.9454):
[0001137789-21-000028:note_history:10]
The preparation of financial statements in accordance with the United States (“U.S.”) generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. These estimates and assumptions include the impact of the COVID-19 pandemic. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements.

- changed (2021-10-28):
[0001137789-21-000128:note_history:11]
The Company’s consolidated financial statements for the fiscal year ended July 2, 2021 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 6, 2021. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 2, 2021, and the notes thereto, are adequate to make the information presented not misleading. The results of operations and the cash flows for the three months ended October 1, 2021 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending July 1, 2022.
  (was, 2021-04-29, similarity 0.8122):
[0001137789-21-000028:note_history:11]
The Company’s consolidated financial statements for the fiscal year ended July 3, 2020 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 7, 2020. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 3, 2020, and the notes thereto, are adequate to make the information presented not misleading.

- changed (2021-10-28):
[0001137789-21-000128:note_history:12]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three months ended October 1, 2021 and October 2, 2020 consisted of 13 weeks. Fiscal year 2022, which ends on July 1, 2022, is comprised of 52 weeks and fiscal year 2021, which ended on July 2, 2021, was comprised of 52 weeks. The fiscal quarters ended October 1, 2021, July 2, 2021 and October 2, 2020, are also referred to herein as the “September 2021 quarter”, the “June 2021 quarter” and the “September 2020 quarter”, respectively.
  (was, 2021-04-29, similarity 0.6683):
[0001137789-21-000028:note_history:12]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three and nine months ended April 2, 2021 consisted of 13 and 39 weeks, respectively, and the three and nine months ended April 3, 2020 consisted of 13 and 40 weeks, respectively. Fiscal year 2021, which ends on July 2, 2021, is comprised of 52 weeks and fiscal year 2020, which ended on July 3, 2020, was comprised of 53 weeks. The fiscal quarters ended April 2, 2021, January 1, 2021 and April 3, 2020, are also referred to herein as the “March 2021 quarter”, the “December 2020 quarter” and the “March 2020 quarter”, respectively. The results of operations for the three and nine months ended April 2, 2021 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending July 2, 2021.

- changed (2021-10-28):
[0001137789-21-000128:note_history:13]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued ASU 2019-12 (ASC Topic 740), Simplifying the Accounting for Income Taxes. This ASU simplifies accounting for income taxes by removing certain exceptions to the general principles and amending existing guidance to improve consistent application. This ASU became effective and the Company adopted the guidance in the September 2021 quarter. The adoption of this ASU did not have an impact on the Company’s condensed consolidated financial statements.
  (was, 2021-04-29, similarity 0.6641):
[0001137789-21-000028:note_history:13]
In December 2019, the FASB issued ASU 2019-12 (ASC Topic 740), Simplifying the Accounting for Income Taxes. This ASU simplifies accounting for income taxes by removing certain exceptions to the general principles and amending existing guidance to improve consistent application. The Company is required to adopt this new accounting pronouncement in the first quarter of fiscal year 2022. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- added (2021-10-28):
[0001137789-21-000128:note_history:14]
In July 2021, the FASB issued ASU 2021-05 (ASC Topic 842), Lessors—Certain Leases with Variable Lease Payments. This ASU requires lessors to classify and account for a lease with variable lease payments that do not depend on a reference index or a rate as an operating lease if the lease would have been classified as a sales-type lease or a direct financing lease and the lessor would have otherwise recognized a day-one loss. The Company adopted the guidance in the September 2021 quarter on a prospective basis. The adoption of this ASU did not have an impact on the Company’s condensed consolidated financial statements.

- changed (2021-10-28):
[0001137789-21-000128:note_history:15]
Recently Issued Accounting Pronouncements
In March 2020, the FASB issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. Adoption of the expedients and exceptions is permitted upon issuance of this update through December 31, 2022.
  (was, 2021-04-29, similarity 0.7865):
[0001137789-21-000028:note_history:15]
In March 2020, the FASB issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. generally accepted accounting principles to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. Adoption of the expedients and exceptions is permitted upon issuance of this update through December 31, 2022. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- removed (2021-10-28):
[0001137789-21-000028:note_history:16]
HDDs are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. HDDs continue to be the primary medium of mass data storage due to their performance attributes, reliability, high quality and cost effectiveness. Complementing existing storage architectures, SSDs use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory. In contrast to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high-capacity HDD and a smaller SSD acting as a cache to improve performance of frequently accessed data.

- removed (2021-10-28):
[0001137789-21-000028:note_history:17]
The Company’s HDD products are designed for mass capacity storage and legacy markets. Mass capacity storage supports high capacity, low-cost per terabyte storage applications, including nearline, video and image applications and network-attached storage. Legacy markets include mission critical, desktop, notebook, consumer, digital video recorders and gaming applications. These markets were previously categorized as enterprise servers and storage systems, edge non-compute applications and edge compute applications. The Company’s HDD and SSD product portfolio includes Serial Advanced Technology Attachment, Serial Attached SCSI and Non-Volatile Memory Express based designs to support a wide variety of mass capacity and legacy applications.

- removed (2021-10-28):
[0001137789-21-000028:note_history:18]
The Company’s enterprise data solutions portfolio includes storage subsystems and mass capacity optimized private cloud storage solutions for enterprises and cloud and managed service providers. Engineered for modularity, mobility, mass capacity and performance, these solutions include the Company’s enterprise HDDs and SSDs, enabling customers to integrate powerful, scalable storage within legacy enterprise IT environments or build new on premises private storage clouds from the ground up in a secure, cost-effective manner. The Company’s other solutions include an edge-to-cloud mass storage platform, which is designed to reduce the cost and complexity associated with storing, moving and activating data at scale.

- removed (2021-10-28):
[0001137789-21-000028:note_history:19]
The Company’s unaudited condensed consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

- removed (2021-10-28):
[0001137789-21-000028:note_history:20]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13 (ASC Topic 326), Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held to include future conditions in its estimate of expected credit losses. The Company adopted this new accounting pronouncement in the quarter ended October 2, 2020. The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.

- removed (2021-10-28):
[0001137789-21-000028:note_history:21]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles—Goodwill and Other—Internal-Use Software—Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company adopted this new accounting pronouncement in the quarter ended October 2, 2020. The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.

- removed (2021-10-28):
[0001137789-21-000028:note_history:22]
Recently Issued Accounting Pronouncements


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-10-28):
[0001137789-21-000128:note_history:23]
Debt
The following table provides details of the Company’s debt as of October 1, 2021 and July 2, 2021:

- added (2021-10-28):
[0001137789-21-000128:note_history:24]
| (Dollars in millions) |  | October 1,2021 |  | July 2,2021 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $750 issued on February 3, 2017 at 4.25% due March 1, 2022 (the “2022 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | $ | 220 |  |  | $ | 220 |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 541 |  |  | 541 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 462 |  |  | 461 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 499 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loan |  |  |  |  |
| $500 borrowed on September 17, 2019 at London Interbank Offered Rate (“LIBOR”), (the “September 2019 Term Loan”), repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with a final maturity date of September 16, 2025(2). |  | 475 |  |  | 481 |  |
|  |  | 5,169 |  |  | 5,173 |  |
| Less: unamortized debt issuance costs |  | (33) |  |  | (34) |  |
| Debt, net of debt issuance costs |  | 5,136 |  |  | 5,139 |  |
| Less: current portion of long-term debt |  | (245) |  |  | (245) |  |
| Long-term debt, less current portion |  | $ | 4,891 |  |  | $ | 4,894 |  |

- added (2021-10-28):
[0001137789-21-000128:note_history:25]
__________________________________

- added (2021-10-28):
[0001137789-21-000128:note_history:26]
(1) All unsecured senior notes are issued by Seagate HDD Cayman, and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and, pursuant to a supplemental indenture dated as of May 18, 2021, STX.

- added (2021-10-28):
[0001137789-21-000128:note_history:27]
(2) The Term Loan was fully repaid on October 14, 2021. See Credit Agreement (including subsequent event) below for more information.

- added (2021-10-28):
[0001137789-21-000128:note_history:28]
Unsecured Senior Notes

- added (2021-10-28):
[0001137789-21-000128:note_history:29]
2022 Notes. During the three months ended October 2, 2020, $9 million aggregate principal amount of the 2022 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest.

- added (2021-10-28):
[0001137789-21-000128:note_history:30]
2023 Notes. During the three months ended October 2, 2020, $5 million aggregate principal amount of the 2023 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest, of which $2 million remained unsettled as of October 2, 2020. The Company recorded a loss of $1 million, on repurchases during the three months ended October 2, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- added (2021-10-28):
[0001137789-21-000128:note_history:31]
Credit Agreement (including subsequent event)

- added (2021-10-28):
[0001137789-21-000128:note_history:32]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement on February 20, 2019, which was amended on September 16, 2019, January 13, 2021, May 18, 2021 and October 14, 2021 (the “Credit Agreement”).

- added (2021-10-28):
[0001137789-21-000128:note_history:33]
Prior to the October 14, 2021 amendment, the Credit Agreement provided a term loan facility in an aggregate principal amount of $500 million and a $1.725 billion senior unsecured revolving credit facility (“Revolving Credit Facility”). The September 2019 Term Loan has a final maturity date of September 16, 2025 and the Revolving Credit Facility has a final maturity of February 20, 2024. On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the September 2019 Term Loan. The Company repaid $6 million principal amount of the September 2019 Term Loan during the three months ended October 1, 2021 and had a remaining principal balance of $475 million as of October 1, 2021.

- added (2021-10-28):
[0001137789-21-000128:note_history:34]
On October 14, 2021, STX and Seagate HDD Cayman entered into an amendment to the Credit Agreement (“Fifth Amendment”), which provides for a new term loan facility in the aggregate principal amount of $1.2 billion that was extended in two tranches of $600 million each (“Term Loan A1” and “Term Loan A2” and together the “Term Loans”). The proceeds of the Term Loan A1 and Term Loan A2 may be used for general corporate purposes, to refinance or repay the September 2019 Term Loan and to refinance or repay the 2022 Notes. Term Loan A1 and Term Loan A2 were each drawn in full on the closing date for the Fifth Amendment. Term Loan A1 will bear interest at a rate of LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company. Term Loan A1 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of September 16, 2025. Term Loan A2 will bear interest at a rate of LIBOR plus a variable margin ranging from 1.25% to 2.5% that will be determined based on the corporate credit rating of the Company. Term Loan A2 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of July 30, 2027. On October 14, 2021, Seagate HDD Cayman utilized part of the proceeds of Term Loan A1 to fully repay the $475 million principal amount outstanding of the September 2019 Term Loan.

- added (2021-10-28):
[0001137789-21-000128:note_history:35]
In addition, pursuant to the Fifth Amendment, the maturity date for the revolving loan commitments was extended until October 14, 2026, the revolving commitments were increased to $1.75 billion and the interest rate margins for the revolving loans were amended to LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company.

- added (2021-10-28):
[0001137789-21-000128:note_history:36]
STX and certain of its material subsidiaries, including STUC, fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loans.

- changed (2021-10-28):
[0001137789-21-000128:note_history:37]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of October 1, 2021 and expects to be in compliance for the next 12 months. As of October 1, 2021, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility.
  (was, 2021-04-29, similarity 0.6113):
[0001137789-21-000028:note_history:37]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of April 2, 2021 and expects to be in compliance for the next 12 months.

- added (2021-10-28):
[0001137789-21-000128:note_history:38]
Future Principal Payments on Long-term Debt

- added (2021-10-28):
[0001137789-21-000128:note_history:39]
At October 1, 2021, future principal payments on long-term debt were as follows (in millions):

- added (2021-10-28):
[0001137789-21-000128:note_history:40]
| Fiscal Year |  | Amount |
| Remainder of 2022 |  | $ | 239 |  |
| 2023 |  | 566 |  |
| 2024 |  | 525 |  |
| 2025 |  | 504 |  |
| 2026 |  | 381 |  |
| Thereafter |  | 2,995 |  |
| Total |  | $ | 5,210 |  |

- removed (2021-10-28):
[0001137789-21-000028:note_history:41]
Credit Agreement

- removed (2021-10-28):
[0001137789-21-000028:note_history:42]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement on February 20, 2019, which was most recently amended on January 13, 2021 (the “Credit Agreement”), increasing the size of the senior unsecured revolving credit facility (“Revolving Credit Facility”) and capping the indebtedness guaranteed by certain of Seagate HDD Cayman’s material subsidiaries to an amount $100 million less than the amount that would give rise to a guarantee requirement by such subsidiaries in respect of any series of senior notes. The Credit Agreement provides a $1.725 billion Revolving Credit Facility and a term loan facility in an aggregate principal amount of $500 million (“Term Loan”). The Revolving Credit Facility has a final maturity of February 20, 2024 and the Term Loan has a final maturity date of September 16, 2025. The loans made under the Revolving Credit Facility and the Term Loan will bear interest at a rate of the London Interbank Offered Rate (“LIBOR”) plus a variable margin for each facility that will be determined based on the corporate credit rating of the Company. The Revolving Credit Facility also allows such facility to increase by an additional $275 million, provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at least $25 million, and (iii) the existing commitments under such facility receive 0.50% most favored nation protection. An aggregate amount of up to $75 million of the Revolving Credit Facility is available for the issuance of letters of credit, and an aggregate amount of up to $50 million of such facility is also available for swing line loans.

- removed (2021-10-28):
[0001137789-21-000028:note_history:43]
On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the Term Loan and the proceeds were used to repurchase a portion of its outstanding senior notes. The Term Loan is repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with the remaining balance payable upon maturity. The Company repaid $6 million and $12 million principal amount of the Term Loan during the three and nine months ended April 2, 2021, respectively.

- removed (2021-10-28):
[0001137789-21-000028:note_history:44]
As of April 2, 2021, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the Revolving Credit Facility.

- removed (2021-10-28):
[0001137789-21-000028:note_history:45]
Other Long-Term Debt

- removed (2021-10-28):
[0001137789-21-000028:note_history:46]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March, 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the nine months ended April 2, 2021, $9 million aggregate principal amount of the 2022 Notes was repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. During the three and nine months ended April 3, 2020, the Company repurchased $23 million and $273 million aggregate principal amount of the 2022 Notes, respectively, for cash at a premium to their principal amount, plus accrued and unpaid interest, $250 million principal amount of which was repurchased pursuant to cash tender offers for certain senior notes on September 18, 2019 (the “Tender Offers”). The Company recorded an immaterial loss and a loss of $10 million, respectively, on repurchases during the nine months ended April 2, 2021 and April 3, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- removed (2021-10-28):
[0001137789-21-000028:note_history:47]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June, 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the nine months ended April 2, 2021, $5 million aggregate principal amount of the 2023 Notes was repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. During the three and nine months ended April 3, 2020, the Company repurchased $17 million and $217 million aggregate principal amount of the 2023 Notes for cash at a discount or at a premium to their principal amount, plus accrued and unpaid interest, respectively, $200 million principal amount of which was repurchased pursuant to the Tender Offers. The Company recorded a loss of $1 million and $10 million, respectively, on repurchases during the nine months ended April 2, 2021 and April 3, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- removed (2021-10-28):
[0001137789-21-000028:note_history:48]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March, 2024 (the “2024 Notes”). The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

- removed (2021-10-28):
[0001137789-21-000028:note_history:49]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January, 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the nine months ended April 3, 2020, $170 million aggregate principal amount was repurchased pursuant to the Tender Offers. The Company recorded a loss of $8 million on repurchases during the nine months ended April 3, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- removed (2021-10-28):
[0001137789-21-000028:note_history:50]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June, 2027 (the “2027 Notes”). The interest on the 2027 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

- removed (2021-10-28):
[0001137789-21-000028:note_history:51]
$500 million Aggregate Principal Amount of 4.091% Senior Notes due June, 2029 (the “June 2029 Notes”). The interest on the June 2029 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the June 2029 Notes is Seagate HDD Cayman, and the obligations under the June 2029 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

- removed (2021-10-28):
[0001137789-21-000028:note_history:52]
$500 million Aggregate Principal Amount of 3.125% Senior Notes due July, 2029 (the “July 2029 Notes”). On December 8, 2020, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of the July 2029 Notes, which will mature on July 15, 2029. The obligations under the July 2029 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. The interest on the July 2029 Notes is payable semi-annually on January 15 and July 15 of each year, commencing on July 15, 2021. At any time before January 15, 2024, Seagate HDD Cayman may redeem some or all of the July 2029 Notes at a “make-whole” redemption price. The “make-whole” redemption price will be equal to (1) 100% of the principal amount of the July 2029 Notes redeemed, plus (2) the greater of (a) 1.0% of the principal amount of the July 2029 Notes and (b) the excess, if any, of (i) the present value at such redemption date of (x) the applicable redemption price of such July 2029 Notes that would apply if such July 2029 Notes were redeemed on January 15, 2024, plus (y) all remaining scheduled payments of interest due on such July 2029 Notes to and including January 15, 2024, computed using a discount rate equal to the applicable Treasury Rate as of such redemption date plus 50 basis points; over (ii) the sum of accrued and unpaid interest, if any, to, but excluding, the redemption date, plus the principal amount of such July 2029 Notes, plus (3) accrued and unpaid interest, if any, to, but excluding, the redemption date. At any time on or after January 15, 2024, Seagate HDD Cayman may redeem some or all of such July 2029 Notes at a price of 101.563%, 100.781% and 100.000%, after January 15, 2024, January 15, 2025 and January 15, 2026, respectively, plus accrued and unpaid interest thereon, if any, to, but excluding, the redemption date. In addition, Seagate HDD Cayman may redeem with the net cash proceeds from one or more equity offerings up to 40% of the July 2029 Notes before January 15, 2024, at a redemption price of 103.125%, plus accrued and unpaid interest to, but excluding, the redemption date.

- removed (2021-10-28):
[0001137789-21-000028:note_history:53]
$500 million Aggregate Principal Amount of 4.125% Senior Notes due January, 2031 (the “January 2031 Notes”). The interest on the January 2031 Notes is payable semi-annually on January 15 and July 15 of each year. The issuer under the January 2031 Notes is Seagate HDD Cayman, and the obligations under the January 2031 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

- removed (2021-10-28):
[0001137789-21-000028:note_history:54]
$500 million Aggregate Principal Amount of 3.375% Senior Notes due July, 2031 (the “July 2031 Notes”). On December 8, 2020, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of the July 2031 Notes, which will mature on July 15, 2031. The obligations under the July 2031 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. The interest on the July 2031 Notes is payable semi-annually on January 15 and July 15 of each year, commencing on July 15, 2021. At any time before January 15, 2026, Seagate HDD Cayman may redeem some or all of the July 2031 Notes at a “make-whole” redemption price. The “make-whole” redemption price will be equal to (1) 100% of the principal amount of the July 2031 Notes redeemed, plus (2) the greater of (a) 1.0% of the principal amount of the July 2031 Notes and (b) the excess, if any, of (i) the present value at such redemption date of (x) the applicable redemption price of such July 2031 Notes that would apply if such July 2031 Notes were redeemed on January 15, 2026, plus (y) all remaining scheduled payments of interest due on such July 2031 Notes to and including January 15, 2026, computed using a discount rate equal to the Treasury Rate as of such redemption date plus 50 basis points; over (ii) the sum of accrued and unpaid interest, if any, to, but excluding, the redemption date, plus the principal amount of such July 2031 Notes, plus (3) accrued and unpaid interest, if any, to, but excluding, the redemption date. At any time on or after January 15, 2026, Seagate HDD Cayman may redeem some or all of such July 2031 Notes at a price of 101.688%, 101.125%, 100.563% and 100.000%, after January 15, 2026, January 15, 2027, January 15, 2028 and January 15, 2029, respectively, plus accrued and unpaid interest thereon, if any, to, but excluding, the redemption date. In addition, Seagate HDD Cayman may redeem with the net cash proceeds from one or more equity offerings up to 40% of the July 2031 Notes before January 15, 2024, a redemption price of 103.375%, accrued and unpaid interest to, but excluding, the redemption date.
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December, 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-10-28):
[0001137789-21-000128:note_history:55]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of October 1, 2021 and July 2, 2021:
  (was, 2021-04-29, similarity 0.8454):
[0001137789-21-000028:note_history:55]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of April 2, 2021:

- added (2021-10-28):
[0001137789-21-000128:note_history:56]
|  |  | October 1,2021 |  | July 2,2021 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 423 |  |  | $ | — |  |  | $ | 423 |  |  | $ | 552 |  |  | $ | — |  |  | $ | 552 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 36 |  |  | — |  |  | 36 |  |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 460 |  |  | $ | — |  |  | $ | 460 |  |  | $ | 571 |  |  | $ | — |  |  | $ | 571 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 422 |  |  |  |  |  |  | $ | 551 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 36 |  |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 460 |  |  |  |  |  |  | $ | 571 |  |

- removed (2021-10-28):
[0001137789-21-000028:note_history:57]
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 531 |  |  | $ | — |  |  | $ | 531 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 550 |  |  | $ | — |  |  | $ | 550 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 530 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 550 |  |

- removed (2021-10-28):
[0001137789-21-000028:note_history:58]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of July 3, 2020:

- removed (2021-10-28):
[0001137789-21-000028:note_history:59]
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 495 |  |  | $ | — |  |  | $ | 495 |  |
| Time deposits and certificates of deposit |  | 56 |  |  | — |  |  | 56 |  |
| Other debt securities |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 569 |  |  | $ | — |  |  | $ | 569 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 549 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 569 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-10-28):
[0001137789-21-000128:note_history:60]
At October 1, 2021, future principal payments on long-term debt were as follows (in millions):
  (was, 2021-04-29, similarity 0.9432):
[0001137789-21-000028:note_history:60]
At April 2, 2021, future principal payments on long-term debt were as follows (in millions):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-10-28):
[0001137789-21-000128:note_history:61]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | October 1,2021 |  | October 2,2020 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,288 |  |  | $ | 1,608 |  |  |  |  |  |
| Distributors |  | 507 |  |  | 367 |  |  |  |  |  |
| Retailers |  | 320 |  |  | 339 |  |  |  |  |  |
| Total |  | $ | 3,115 |  |  | $ | 2,314 |  |  |  |  |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,583 |  |  | $ | 1,106 |  |  |  |  |  |
| Americas |  | 1,079 |  |  | 805 |  |  |  |  |  |
| EMEA |  | 453 |  |  | 403 |  |  |  |  |  |
| Total |  | $ | 3,115 |  |  | $ | 2,314 |  |  |  |  |  |

- changed (2021-10-28):
[0001137789-21-000128:note_history:62]
(1) Revenue is attributed to geography based on bill from locations.
  (was, 2021-04-29, similarity 0.8824):
[0001137789-21-000028:note_history:62]
(1) Revenue is attributed to countries based on bill from locations.

- removed (2021-10-28):
[0001137789-21-000028:note_history:63]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 1,950 |  |  | $ | 1,970 |  |  | $ | 5,299 |  |  | $ | 5,633 |  |
| Distributors |  | 455 |  |  | 465 |  |  | 1,297 |  |  | 1,389 |  |
| Retailers |  | 326 |  |  | 283 |  |  | 1,072 |  |  | 970 |  |
| Total |  | $ | 2,731 |  |  | $ | 2,718 |  |  | $ | 7,668 |  |  | $ | 7,992 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,268 |  |  | $ | 1,257 |  |  | $ | 3,680 |  |  | $ | 3,912 |  |
| Americas |  | 939 |  |  | 938 |  |  | 2,582 |  |  | 2,534 |  |
| EMEA |  | 524 |  |  | 523 |  |  | 1,406 |  |  | 1,546 |  |
| Total |  | $ | 2,731 |  |  | $ | 2,718 |  |  | $ | 7,668 |  |  | $ | 7,992 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-10-28):
[0001137789-21-000128:note_history:64]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | October 1,2021 |  | October 2,2020 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,288 |  |  | $ | 1,608 |  |  |  |  |  |
| Distributors |  | 507 |  |  | 367 |  |  |  |  |  |
| Retailers |  | 320 |  |  | 339 |  |  |  |  |  |
| Total |  | $ | 3,115 |  |  | $ | 2,314 |  |  |  |  |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,583 |  |  | $ | 1,106 |  |  |  |  |  |
| Americas |  | 1,079 |  |  | 805 |  |  |  |  |  |
| EMEA |  | 453 |  |  | 403 |  |  |  |  |  |
| Total |  | $ | 3,115 |  |  | $ | 2,314 |  |  |  |  |  |

- changed (2021-10-28):
[0001137789-21-000128:note_history:65]
(1) Revenue is attributed to geography based on bill from locations.
  (was, 2021-04-29, similarity 0.8824):
[0001137789-21-000028:note_history:65]
(1) Revenue is attributed to countries based on bill from locations.

- removed (2021-10-28):
[0001137789-21-000028:note_history:66]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 2,2021 |  | April 3,2020 |  | April 2,2021 |  | April 3,2020 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 1,950 |  |  | $ | 1,970 |  |  | $ | 5,299 |  |  | $ | 5,633 |  |
| Distributors |  | 455 |  |  | 465 |  |  | 1,297 |  |  | 1,389 |  |
| Retailers |  | 326 |  |  | 283 |  |  | 1,072 |  |  | 970 |  |
| Total |  | $ | 2,731 |  |  | $ | 2,718 |  |  | $ | 7,668 |  |  | $ | 7,992 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,268 |  |  | $ | 1,257 |  |  | $ | 3,680 |  |  | $ | 3,912 |  |
| Americas |  | 939 |  |  | 938 |  |  | 2,582 |  |  | 2,534 |  |
| EMEA |  | 524 |  |  | 523 |  |  | 1,406 |  |  | 1,546 |  |
| Total |  | $ | 2,731 |  |  | $ | 2,718 |  |  | $ | 7,668 |  |  | $ | 7,992 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2021-10-28):
[0001137789-21-000128:note_history:67]
On October 22, 2021, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on January 5, 2022 to shareholders of record as of the close of business on December 22, 2021.
  (was, 2021-04-29, similarity 0.9403):
[0001137789-21-000028:note_history:67]
On April 22, 2021, the Company’s Board of Directors declared a quarterly cash dividend of $0.67 per share, which will be payable on July 7, 2021 to shareholders of record as of the close of business on May 12, 2021.

- added (2021-10-28):
[0001137789-21-000128:note_history:68]
Credit Agreement

- added (2021-10-28):
[0001137789-21-000128:note_history:69]
On October 14, 2021, STX and its subsidiary Seagate HDD Cayman entered into an amendment to the Credit Agreement, dated as of February 20, 2019. See “Note 3. Debt” for information regarding the amended credit agreement. On October 19, 2021, the Company entered into an additional interest rate swap contract. See “Note 6. Derivative Financial Instruments” for more information.
