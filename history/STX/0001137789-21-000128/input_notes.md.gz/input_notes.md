# STX notes — 0001137789-21-000128


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001137789-21-000128:notes:1]
[same as prior period, unchanged from 0001137789-21-000028:notes:1]

[0001137789-21-000128:notes:2]
Seagate Technology Holdings plc (“STX”) and its subsidiaries (collectively, unless the context otherwise indicates, the “Company”) is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”), solid state hybrid drives (“SSHDs”), storage subsystems, as well as a scalable edge-to-cloud mass data platform that includes data transfer shuttles and a storage-as-a-service cloud.

[0001137789-21-000128:notes:3]
HDDs are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. HDDs continue to be the primary medium of mass data storage due to their performance attributes, reliability, high capacities, superior quality and cost effectiveness. Complementing existing storage architectures, SSDs use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory. In contrast to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high-capacity HDD and a smaller SSD acting as a cache to improve performance of frequently accessed data.

[0001137789-21-000128:notes:4]
The Company’s HDD products are designed for mass capacity storage and legacy markets. Mass capacity storage involves well-established use cases—such as hyperscale data centers and public clouds as well as emerging use cases. Legacy markets include markets the Company continues to service but that it does not plan to invest in significantly. The Company’s HDD and SSD product portfolio includes Serial Advanced Technology Attachment, Serial Attached SCSI and Non-Volatile Memory Express based designs to support a wide variety of mass capacity and legacy applications.

[0001137789-21-000128:notes:5]
The Company’s system portfolio includes storage subsystems for enterprises, cloud service providers, scale-out storage servers and original equipment manufacturers (“OEMs”). Engineered for modularity, mobility, capacity and performance, these solutions include the Company’s enterprise HDDs and SSDs, enabling customers to integrate powerful, scalable storage within legacy environments or build new ecosystems from the ground up in a secure, cost-effective manner.

[0001137789-21-000128:notes:6]
The Company’s Lyve portfolio provides a simple, cost-efficient and secure way to manage massive volumes of data across the distributed enterprise. The Lyve platform includes a shuttle solution that enables enterprises to transfer massive amounts of data from endpoints to the core cloud, a storage-as-a-service cloud that provides frictionless mass capacity storage at the metro edge, a converged object storage solution enabling efficient capture and consolidation of massive data sets and Cortx, an open-source object storage software optimized for mass capacity and data intensive workloads.

[0001137789-21-000128:notes:7]
[same as prior period, unchanged from 0001137789-21-000028:notes:6]

[0001137789-21-000128:notes:8]
The unaudited Condensed Consolidated Financial Statements of the Company were prepared in accordance with United States (“U.S.”) Generally Accepted Accounting Principles (“GAAP”). The Company’s unaudited condensed consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

[0001137789-21-000128:notes:9]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. These estimates and assumptions include the impact of the COVID-19 pandemic. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements.

[0001137789-21-000128:notes:10]
The Company’s consolidated financial statements for the fiscal year ended July 2, 2021 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 6, 2021. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 2, 2021, and the notes thereto, are adequate to make the information presented not misleading. The results of operations and the cash flows for the three months ended October 1, 2021 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending July 1, 2022.

[0001137789-21-000128:notes:11]
[same as prior period, unchanged from 0001137789-21-000028:notes:10]

[0001137789-21-000128:notes:12]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three months ended October 1, 2021 and October 2, 2020 consisted of 13 weeks. Fiscal year 2022, which ends on July 1, 2022, is comprised of 52 weeks and fiscal year 2021, which ended on July 2, 2021, was comprised of 52 weeks. The fiscal quarters ended October 1, 2021, July 2, 2021 and October 2, 2020, are also referred to herein as the “September 2021 quarter”, the “June 2021 quarter” and the “September 2020 quarter”, respectively.

[0001137789-21-000128:notes:13]
[same as prior period, unchanged from 0001137789-21-000028:notes:12]

[0001137789-21-000128:notes:14]
There have been no material changes to the Company’s significant accounting policies disclosed in Note 1. Basis of Presentation and Summary of Significant Accounting Policies of “Financial Statements and Supplementary Data” contained in Part II, Item 8. of the Company’s Annual Report on Form 10-K for the fiscal year ended July 2, 2021, as filed with the SEC on August 6, 2021.

[0001137789-21-000128:notes:15]
Recently Adopted Accounting Pronouncements

[0001137789-21-000128:notes:16]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued ASU 2019-12 (ASC Topic 740), Simplifying the Accounting for Income Taxes. This ASU simplifies accounting for income taxes by removing certain exceptions to the general principles and amending existing guidance to improve consistent application. This ASU became effective and the Company adopted the guidance in the September 2021 quarter. The adoption of this ASU did not have an impact on the Company’s condensed consolidated financial statements.

[0001137789-21-000128:notes:17]
In July 2021, the FASB issued ASU 2021-05 (ASC Topic 842), Lessors—Certain Leases with Variable Lease Payments. This ASU requires lessors to classify and account for a lease with variable lease payments that do not depend on a reference index or a rate as an operating lease if the lease would have been classified as a sales-type lease or a direct financing lease and the lessor would have otherwise recognized a day-one loss. The Company adopted the guidance in the September 2021 quarter on a prospective basis. The adoption of this ASU did not have an impact on the Company’s condensed consolidated financial statements.

[0001137789-21-000128:notes:18]
Recently Issued Accounting Pronouncements
In March 2020, the FASB issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. Adoption of the expedients and exceptions is permitted upon issuance of this update through December 31, 2022.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001137789-21-000128:notes:19]
Recently Issued Accounting Pronouncements
In March 2020, the FASB issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. Adoption of the expedients and exceptions is permitted upon issuance of this update through December 31, 2022. The Company does not expect the adoption of this ASU to have a material impact on its condensed consolidated financial statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001137789-21-000128:notes:20]
Available-for-sale Debt Securities

[0001137789-21-000128:notes:21]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of October 1, 2021 and July 2, 2021:

[0001137789-21-000128:notes:22]
|  |  | October 1,2021 |  | July 2,2021 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 423 |  |  | $ | — |  |  | $ | 423 |  |  | $ | 552 |  |  | $ | — |  |  | $ | 552 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 36 |  |  | — |  |  | 36 |  |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 460 |  |  | $ | — |  |  | $ | 460 |  |  | $ | 571 |  |  | $ | — |  |  | $ | 571 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 422 |  |  |  |  |  |  | $ | 551 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 36 |  |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 460 |  |  |  |  |  |  | $ | 571 |  |

[0001137789-21-000128:notes:23]
As of both October 1, 2021 and July 2, 2021, the Company’s Other current assets included $2 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001137789-21-000128:notes:24]
As of October 1, 2021 and July 2, 2021, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no impairment related to credit losses for available-for-sale debt securities as of October 1, 2021 and July 2, 2021.

[0001137789-21-000128:notes:25]
The fair value and amortized cost of the Company’s investments classified as available-for-sale debt securities as of October 1, 2021, by remaining contractual maturity were as follows:

[0001137789-21-000128:notes:26]
| (Dollars in millions) |  | Amortized Cost |  | Fair Value |
| Due in less than 1 year |  | $ | 424 |  |  | $ | 424 |  |
| Due in 1 to 5 years |  | 28 |  |  | 28 |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | 8 |  |  | 8 |  |
| Total |  | $ | 460 |  |  | $ | 460 |  |

[0001137789-21-000128:notes:27]
[same as prior period, unchanged from 0001137789-21-000028:notes:31]

[0001137789-21-000128:notes:28]
The following table provides a summary of cash, cash equivalents and restricted cash reported within the Company’s Condensed Consolidated Balance Sheets that reconciles to the corresponding amount in the Company’s Condensed Consolidated Statements of Cash Flows:

[0001137789-21-000128:notes:29]
| (Dollars in millions) |  | October 1,2021 |  |  |  | July 2,2021 |  | October 2,2020 |  |  |  | July 3,2020 |
| Cash and cash equivalents |  | $ | 991 |  |  |  |  | $ | 1,209 |  |  | $ | 1,664 |  |  |  |  | $ | 1,722 |  |
| Restricted cash included in Other current assets |  | 2 |  |  |  |  | 2 |  |  | 2 |  |  |  |  | 2 |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  | $ | 993 |  |  |  |  | $ | 1,211 |  |  | $ | 1,666 |  |  |  |  | $ | 1,724 |  |

[0001137789-21-000128:notes:30]
[same as prior period, unchanged from 0001137789-21-000028:notes:37]

[0001137789-21-000128:notes:31]
[same as prior period, unchanged from 0001137789-21-000028:notes:38]

[0001137789-21-000128:notes:32]
| (Dollars in millions) |  | October 1,2021 |  | July 2,2021 |
| Raw materials and components |  | $ | 424 |  |  | $ | 375 |  |
| Work-in-process |  | 459 |  |  | 443 |  |
| Finished goods |  | 305 |  |  | 386 |  |
| Total inventories |  | $ | 1,188 |  |  | $ | 1,204 |  |

[0001137789-21-000128:notes:33]
[same as prior period, unchanged from 0001137789-21-000028:notes:40]

[0001137789-21-000128:notes:34]
[same as prior period, unchanged from 0001137789-21-000028:notes:41]

[0001137789-21-000128:notes:35]
| (Dollars in millions) |  | October 1,2021 |  | July 2,2021 |
| Property, equipment and leasehold improvements |  | $ | 10,469 |  |  | $ | 10,378 |  |
| Accumulated depreciation and amortization |  | (8,256) |  |  | (8,197) |  |
| Property, equipment and leasehold improvements, net |  | $ | 2,213 |  |  | $ | 2,181 |  |

[0001137789-21-000128:notes:36]
[same as prior period, unchanged from 0001137789-21-000028:notes:43]

[0001137789-21-000128:notes:37]
[same as prior period, unchanged from 0001137789-21-000028:notes:44]

[0001137789-21-000128:notes:38]
| (Dollars in millions) |  | October 1,2021 |  | July 2,2021 |
| Dividends payable |  | $ | 151 |  |  | $ | 153 |  |
| Other accrued expenses |  | 475 |  |  | 455 |  |
| Total |  | $ | 626 |  |  | $ | 608 |  |

[0001137789-21-000128:notes:39]
[same as prior period, unchanged from 0001137789-21-000028:notes:46]

[0001137789-21-000128:notes:40]
[same as prior period, unchanged from 0001137789-21-000028:notes:47]

[0001137789-21-000128:notes:41]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  |  |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at July 2, 2021 |  | $ | (18) |  |  |  |  | $ | (22) |  |  | $ | (1) |  |  | $ | (41) |  |
| Other comprehensive (loss) income before reclassifications |  | (9) |  |  |  |  | 1 |  |  | — |  |  | (8) |  |
| Amounts reclassified from AOCL |  | 3 |  |  |  |  | 1 |  |  | — |  |  | 4 |  |
| Other comprehensive loss |  | (6) |  |  |  |  | 2 |  |  | — |  |  | (4) |  |
| Balance at October 1, 2021 |  | $ | (24) |  |  |  |  | $ | (20) |  |  | $ | (1) |  |  | $ | (45) |  |
| Balance at July 3, 2020 |  | $ | (24) |  |  |  |  | $ | (26) |  |  | $ | (16) |  |  | $ | (66) |  |
| Other comprehensive income before reclassifications |  | 4 |  |  |  |  | — |  |  | — |  |  | 4 |  |
| Amounts reclassified from AOCL |  | — |  |  |  |  | 1 |  |  | 15 |  |  | 16 |  |
| Other comprehensive income |  | 4 |  |  |  |  | 1 |  |  | 15 |  |  | 20 |  |
| Balance at October 2, 2020 |  | $ | (20) |  |  |  |  | $ | (25) |  |  | $ | (1) |  |  | $ | (46) |  |


## us-gaap:DebtDisclosureTextBlock

[0001137789-21-000128:notes:42]
Debt
The following table provides details of the Company’s debt as of October 1, 2021 and July 2, 2021:

[0001137789-21-000128:notes:43]
| (Dollars in millions) |  | October 1,2021 |  | July 2,2021 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $750 issued on February 3, 2017 at 4.25% due March 1, 2022 (the “2022 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | $ | 220 |  |  | $ | 220 |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 541 |  |  | 541 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 462 |  |  | 461 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 499 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loan |  |  |  |  |
| $500 borrowed on September 17, 2019 at London Interbank Offered Rate (“LIBOR”), (the “September 2019 Term Loan”), repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with a final maturity date of September 16, 2025(2). |  | 475 |  |  | 481 |  |
|  |  | 5,169 |  |  | 5,173 |  |
| Less: unamortized debt issuance costs |  | (33) |  |  | (34) |  |
| Debt, net of debt issuance costs |  | 5,136 |  |  | 5,139 |  |
| Less: current portion of long-term debt |  | (245) |  |  | (245) |  |
| Long-term debt, less current portion |  | $ | 4,891 |  |  | $ | 4,894 |  |

[0001137789-21-000128:notes:44]
__________________________________

[0001137789-21-000128:notes:45]
(1) All unsecured senior notes are issued by Seagate HDD Cayman, and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and, pursuant to a supplemental indenture dated as of May 18, 2021, STX.

[0001137789-21-000128:notes:46]
(2) The Term Loan was fully repaid on October 14, 2021. See Credit Agreement (including subsequent event) below for more information.

[0001137789-21-000128:notes:47]
Unsecured Senior Notes

[0001137789-21-000128:notes:48]
2022 Notes. During the three months ended October 2, 2020, $9 million aggregate principal amount of the 2022 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest.

[0001137789-21-000128:notes:49]
2023 Notes. During the three months ended October 2, 2020, $5 million aggregate principal amount of the 2023 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest, of which $2 million remained unsettled as of October 2, 2020. The Company recorded a loss of $1 million, on repurchases during the three months ended October 2, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

[0001137789-21-000128:notes:50]
Credit Agreement (including subsequent event)

[0001137789-21-000128:notes:51]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement on February 20, 2019, which was amended on September 16, 2019, January 13, 2021, May 18, 2021 and October 14, 2021 (the “Credit Agreement”).

[0001137789-21-000128:notes:52]
Prior to the October 14, 2021 amendment, the Credit Agreement provided a term loan facility in an aggregate principal amount of $500 million and a $1.725 billion senior unsecured revolving credit facility (“Revolving Credit Facility”). The September 2019 Term Loan has a final maturity date of September 16, 2025 and the Revolving Credit Facility has a final maturity of February 20, 2024. On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the September 2019 Term Loan. The Company repaid $6 million principal amount of the September 2019 Term Loan during the three months ended October 1, 2021 and had a remaining principal balance of $475 million as of October 1, 2021.

[0001137789-21-000128:notes:53]
On October 14, 2021, STX and Seagate HDD Cayman entered into an amendment to the Credit Agreement (“Fifth Amendment”), which provides for a new term loan facility in the aggregate principal amount of $1.2 billion that was extended in two tranches of $600 million each (“Term Loan A1” and “Term Loan A2” and together the “Term Loans”). The proceeds of the Term Loan A1 and Term Loan A2 may be used for general corporate purposes, to refinance or repay the September 2019 Term Loan and to refinance or repay the 2022 Notes. Term Loan A1 and Term Loan A2 were each drawn in full on the closing date for the Fifth Amendment. Term Loan A1 will bear interest at a rate of LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company. Term Loan A1 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of September 16, 2025. Term Loan A2 will bear interest at a rate of LIBOR plus a variable margin ranging from 1.25% to 2.5% that will be determined based on the corporate credit rating of the Company. Term Loan A2 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of July 30, 2027. On October 14, 2021, Seagate HDD Cayman utilized part of the proceeds of Term Loan A1 to fully repay the $475 million principal amount outstanding of the September 2019 Term Loan.

[0001137789-21-000128:notes:54]
In addition, pursuant to the Fifth Amendment, the maturity date for the revolving loan commitments was extended until October 14, 2026, the revolving commitments were increased to $1.75 billion and the interest rate margins for the revolving loans were amended to LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company.

[0001137789-21-000128:notes:55]
STX and certain of its material subsidiaries, including STUC, fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loans.

[0001137789-21-000128:notes:56]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of October 1, 2021 and expects to be in compliance for the next 12 months. As of October 1, 2021, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility.

[0001137789-21-000128:notes:57]
Future Principal Payments on Long-term Debt

[0001137789-21-000128:notes:58]
At October 1, 2021, future principal payments on long-term debt were as follows (in millions):

[0001137789-21-000128:notes:59]
| Fiscal Year |  | Amount |
| Remainder of 2022 |  | $ | 239 |  |
| 2023 |  | 566 |  |
| 2024 |  | 525 |  |
| 2025 |  | 504 |  |
| 2026 |  | 381 |  |
| Thereafter |  | 2,995 |  |
| Total |  | $ | 5,210 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001137789-21-000128:notes:60]
Income Taxes
The Company’s income tax provision of $7 million for the three months ended October 1, 2021 included approximately $10 million of net discrete tax benefit, primarily associated with net excess tax benefits related to share-based compensation expense.

[0001137789-21-000128:notes:61]
During the three months ended October 1, 2021, the Company’s unrecognized tax benefits excluding interest and penalties increased by approximately $4 million to $112 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. During the twelve months beginning October 2, 2021, the Company expects that its unrecognized tax benefits could be reduced by an immaterial amount, as a result of the expiration of certain statutes of limitation.

[0001137789-21-000128:notes:62]
The Company’s income tax benefit of $2 million for the three months ended October 2, 2020 included approximately $10 million of net discrete tax benefit of which $4 million was associated with net excess tax benefits related to share-based compensation expense and $3 million was associated with the postponement of the previously enacted United Kingdom tax rate change in the quarter ended October 2, 2020.

[0001137789-21-000128:notes:63]
The Company’s income tax provision recorded for the three months ended October 1, 2021 and October 2, 2020 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001137789-21-000128:notes:64]
The Company recorded restructuring charges of $1 million for each of the three months ended October 1, 2021 and October 2, 2020. The Company’s restructuring plans are comprised primarily of charges related to workforce reduction costs and facilities and other exit costs. All restructuring charges are reported in Restructuring and other, net on the Company’s Condensed Consolidated Statements of Operations.

[0001137789-21-000128:notes:65]
The following tables summarize the Company’s restructuring activities under the Company’s active restructuring plans:

[0001137789-21-000128:notes:66]
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at July 2, 2021 |  | $ | 2 |  |  | $ | 6 |  |  | $ | 8 |  |
| Restructuring charges |  | 1 |  |  | — |  |  | 1 |  |
| Cash payments |  | (1) |  |  | (1) |  |  | (2) |  |
| Accrual balances at October 1, 2021 |  | $ | 2 |  |  | $ | 5 |  |  | $ | 7 |  |
| Total costs incurred inception to date as of October 1, 2021 |  | $ | 64 |  |  | $ | 23 |  |  | $ | 87 |  |
| Total expected charges to be incurred as of October 1, 2021 |  | $ | — |  |  | $ | 7 |  |  | $ | 7 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001137789-21-000128:notes:67]
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies.

[0001137789-21-000128:notes:68]
In the quarter ended October 4, 2019, the Company entered into certain interest rate swap agreements with a notional amount of $500 million to convert the variable interest rate on its term loan to fixed interest rates. The contracts will mature on September 16, 2025. The notional amount of the interest rate swap agreements was $475 million as of October 1, 2021. On October 19, 2021, the Company entered into additional interest rate swap agreements with a notional amount of $600 million to convert the variable interest rate on certain principal amounts of the Term Loans drawn on October 14, 2021 in connection with the closing of the Fifth Amendment. The contracts will mature on July 15, 2027. The objective of the interest rate swap agreements is to eliminate the variability of interest payment cash flows associated with the variable interest rate under the Term Loans. The Company designated the interest rate swaps as cash flow hedges.

[0001137789-21-000128:notes:69]
The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives on its Condensed Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The amount of net unrealized loss on cash flow hedges was $24 million and $18 million as of October 1, 2021 and as of July 2, 2021, respectively. As of October 1, 2021, the amount of existing net losses related to cash flow hedges recorded in Accumulated other comprehensive loss included $19 million that is expected to be reclassified to earnings within twelve months.

[0001137789-21-000128:notes:70]
The Company de-designates its cash flow hedges when the forecasted hedged transactions affect earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss on the Company’s Condensed Consolidated Balance Sheets are reclassified into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company recognized a net loss of $2 million and $1 million in Cost of revenue and Interest expense, respectively, related to the loss of hedge designation on discontinued cash flow hedges during the three months ended October 1, 2021. The Company did not recognize any material amounts related to the loss of hedge designation on discontinued cash flow hedges during the three months ended October 2, 2020.

[0001137789-21-000128:notes:71]
[same as prior period, unchanged from 0001137789-21-000028:notes:88]

[0001137789-21-000128:notes:72]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of October 1, 2021 and July 2, 2021. All of the foreign currency forward exchange contracts mature within 12 months.

[0001137789-21-000128:notes:73]
|  |  | As of October 1, 2021 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Singapore Dollar |  | $ | 170 |  |  | $ | 48 |  |
| Thai Baht |  | 161 |  |  | 38 |  |
| Chinese Renminbi |  | 78 |  |  | 22 |  |
| British Pound Sterling |  | 63 |  |  | 19 |  |
|  |  | $ | 472 |  |  | $ | 127 |  |

[0001137789-21-000128:notes:74]
|  |  | As of July 2, 2021 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Singapore Dollar |  | $ | 172 |  |  | $ | 43 |  |
| Thai Baht |  | 131 |  |  | 46 |  |
| Chinese Renminbi |  | 73 |  |  | 21 |  |
| British Pound Sterling |  | 54 |  |  | 16 |  |
|  |  | $ | 430 |  |  | $ | 126 |  |

[0001137789-21-000128:notes:75]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its non-qualified deferred compensation plan: the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP’s liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP’s liabilities due to changes in the value of the investment options made by employees. As of October 1, 2021, the notional investments underlying the TRS amounted to $126 million. The contract term of the TRS is through January 2022 and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP’s liabilities.

[0001137789-21-000128:notes:76]
The following tables show the Company’s derivative instruments measured at gross fair value as reflected in the Condensed Consolidated Balance Sheets as of October 1, 2021 and July 2, 2021:

[0001137789-21-000128:notes:77]
|  |  | As of October 1, 2021 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance Sheet Location |  | Fair Value |  | Balance Sheet Location |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (12) |  |
| Interest rate swap |  | Other current assets |  | — |  |  | Accrued expenses |  | (12) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 1 |  |  | Accrued expenses |  | (4) |  |
| Total derivatives |  |  |  | $ | 1 |  |  |  |  | $ | (28) |  |

[0001137789-21-000128:notes:78]
|  |  | As of July 2, 2021 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance Sheet Location |  | Fair Value |  | Balance Sheet Location |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 1 |  |  | Accrued expenses |  | $ | (5) |  |
| Interest rate swap |  | Other current assets |  | — |  |  | Accrued expenses |  | (14) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 1 |  |  | Accrued expenses |  | (2) |  |
| Total return swap |  | Other current assets |  | 2 |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 4 |  |  |  |  | $ | (21) |  |

[0001137789-21-000128:notes:79]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three months ended October 1, 2021:

[0001137789-21-000128:notes:80]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |  |  |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (4) |  |  |  |
| Total return swap |  | Operating expenses |  | (1) |  |  |  |

[0001137789-21-000128:notes:81]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  |  |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  |  |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  |  |
| Foreign currency forward exchange contracts |  | $ | (9) |  |  |  |  | Cost of revenue |  | $ | (2) |  |  |  |  | Other, net |  | $ | 1 |  |  |  |
| Interest rate swap |  | — |  |  |  |  | Interest expense |  | (1) |  |  |  |  | Interest expense |  | — |  |  |  |

[0001137789-21-000128:notes:82]
The following table shows the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three months ended October 2, 2020:

[0001137789-21-000128:notes:83]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |  |  |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 6 |  |  |  |
| Total return swap |  | Operating expenses |  | $ | 5 |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001137789-21-000128:notes:84]
[same as prior period, unchanged from 0001137789-21-000028:notes:102]

[0001137789-21-000128:notes:85]
[same as prior period, unchanged from 0001137789-21-000028:notes:103]

[0001137789-21-000128:notes:86]
[same as prior period, unchanged from 0001137789-21-000028:notes:104]

[0001137789-21-000128:notes:87]
[same as prior period, unchanged from 0001137789-21-000028:notes:105]

[0001137789-21-000128:notes:88]
[same as prior period, unchanged from 0001137789-21-000028:notes:106]

[0001137789-21-000128:notes:89]
[same as prior period, unchanged from 0001137789-21-000028:notes:107]

[0001137789-21-000128:notes:90]
[same as prior period, unchanged from 0001137789-21-000028:notes:108]

[0001137789-21-000128:notes:91]
[same as prior period, unchanged from 0001137789-21-000028:notes:109]

[0001137789-21-000128:notes:92]
[same as prior period, unchanged from 0001137789-21-000028:notes:110]

[0001137789-21-000128:notes:93]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item, that are measured at fair value on a recurring basis, excluding accrued interest components, as of:

[0001137789-21-000128:notes:94]
|  |  | October 1, 2021 |  | July 2, 2021 |
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 422 |  |  | $ | — |  |  | $ | — |  |  | $ | 422 |  |  | $ | 551 |  |  | $ | — |  |  | $ | — |  |  | $ | 551 |  |
| Time deposits and certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total cash equivalents |  | 422 |  |  | — |  |  | — |  |  | 422 |  |  | 551 |  |  | — |  |  | — |  |  | 551 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | — |  |  | — |  |  | 36 |  |  | 36 |  |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Derivative assets |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total assets |  | $ | 423 |  |  | $ | 2 |  |  | $ | 36 |  |  | $ | 461 |  |  | $ | 552 |  |  | $ | 5 |  |  | $ | 18 |  |  | $ | 575 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |
| Total liabilities |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |

[0001137789-21-000128:notes:95]
|  |  | October 1, 2021 |  | July 2, 2021 |
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 422 |  |  | $ | — |  |  | $ | — |  |  | $ | 422 |  |  | $ | 551 |  |  | $ | — |  |  | $ | — |  |  | $ | 551 |  |
| Other current assets |  | 1 |  |  | 2 |  |  | — |  |  | 3 |  |  | 1 |  |  | 5 |  |  | — |  |  | 6 |  |
| Other assets, net |  | — |  |  | — |  |  | 36 |  |  | 36 |  |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Total assets |  | $ | 423 |  |  | $ | 2 |  |  | $ | 36 |  |  | $ | 461 |  |  | $ | 552 |  |  | $ | 5 |  |  | $ | 18 |  |  | $ | 575 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |
| Total liabilities |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |

[0001137789-21-000128:notes:96]
[same as prior period, unchanged from 0001137789-21-000028:notes:117]

[0001137789-21-000128:notes:97]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair value of all of its cash equivalents. For the cash equivalents in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry-standard data providers or other third-party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of October 1, 2021, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts, interest rate swaps and the TRS. The Company recognizes derivative financial instruments in its condensed consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001137789-21-000128:notes:98]
[same as prior period, unchanged from 0001137789-21-000028:notes:119]

[0001137789-21-000128:notes:99]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives, which are accounted for either under the equity method or the measurement alternative. If measured at fair value in the Condensed Consolidated Balance Sheets, these investments would generally be classified in Level 3 of the fair value hierarchy.

[0001137789-21-000128:notes:100]
For the investments that are accounted for under the equity method, the Company recorded a net gain of $3 million and an immaterial loss for the three months ended October 1, 2021 and October 2, 2020, respectively. The adjusted carrying value of the investments accounted for under the equity method amounted to $81 million and $78 million as of October 1, 2021 and July 2, 2021, respectively.

[0001137789-21-000128:notes:101]
For the investments that are accounted for under the measurement alternative, the Company recorded $6 million of net gains for the three months ended October 1, 2021, of which $5 million is unrealized as of October 1, 2021, related to upward adjustments due to observable price changes. For the three months ended October 2, 2020, the Company recorded net gains of $31 million, of which $23 million was unrealized as of October 2, 2020, related to upward adjustments due to observable price changes. As of October 1, 2021 and July 2, 2021, the carrying value of the Company’s strategic investments under the measurement alternative was $109 million and $117 million, respectively.

[0001137789-21-000128:notes:102]
[same as prior period, unchanged from 0001137789-21-000028:notes:122]

[0001137789-21-000128:notes:103]
[same as prior period, unchanged from 0001137789-21-000028:notes:123]

[0001137789-21-000128:notes:104]
|  |  | October 1, 2021 |  | July 2, 2021 |
| (Dollars in millions) |  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 4.25% Senior Notes due March 2022 |  | $ | 220 |  |  | $ | 222 |  |  | $ | 220 |  |  | $ | 224 |  |
| 4.75% Senior Notes due June 2023 |  | 541 |  |  | 572 |  |  | 541 |  |  | 578 |  |
| 4.875% Senior Notes due March 2024 |  | 499 |  |  | 537 |  |  | 499 |  |  | 544 |  |
| 4.75% Senior Notes due January 2025 |  | 479 |  |  | 525 |  |  | 479 |  |  | 529 |  |
| 4.875% Senior Notes due June 2027 |  | 504 |  |  | 568 |  |  | 504 |  |  | 561 |  |
| 4.091% Senior Notes due June 2029 |  | 462 |  |  | 529 |  |  | 461 |  |  | 519 |  |
| 3.125% Senior Notes due July 2029 |  | 500 |  |  | 486 |  |  | 500 |  |  | 488 |  |
| 4.125% Senior Notes due January 2031 |  | 500 |  |  | 520 |  |  | 499 |  |  | 513 |  |
| 3.375% Senior Notes due July 2031 |  | 500 |  |  | 488 |  |  | 500 |  |  | 487 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 573 |  |  | 489 |  |  | 566 |  |
| LIBOR Based Term Loan due September 2025(1) |  | 475 |  |  | 471 |  |  | 481 |  |  | 478 |  |
|  |  | 5,169 |  |  | 5,491 |  |  | 5,173 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (33) |  |  | — |  |  | (34) |  |  | — |  |
| Debt, net of debt issuance costs |  | 5,136 |  |  | 5,491 |  |  | 5,139 |  |  | 5,487 |  |
| Less: current portion of debt |  | (245) |  |  | (247) |  |  | (245) |  |  | (249) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 4,891 |  |  | $ | 5,244 |  |  | $ | 4,894 |  |  | $ | 5,238 |  |

[0001137789-21-000128:notes:105]
(1) The September 2019 Term Loan was fully repaid on October 14, 2021. See “Note 3. Debt” for information regarding the amended credit agreement.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001137789-21-000128:notes:106]
Share Capital

[0001137789-21-000128:notes:107]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 224,504,643 shares were outstanding as of October 1, 2021, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of October 1, 2021.

[0001137789-21-000128:notes:108]
[same as prior period, unchanged from 0001137789-21-000028:notes:127]

[0001137789-21-000128:notes:109]
[same as prior period, unchanged from 0001137789-21-000028:notes:128]

[0001137789-21-000128:notes:110]
[same as prior period, unchanged from 0001137789-21-000028:notes:129]

[0001137789-21-000128:notes:111]
[same as prior period, unchanged from 0001137789-21-000028:notes:130]

[0001137789-21-000128:notes:112]
[same as prior period, unchanged from 0001137789-21-000028:notes:131]

[0001137789-21-000128:notes:113]
On May 14, 2021, STX’s Board of Directors resolved to adopt and continue the STUC Share Repurchase Program as its own and that the STX Board of Directors be authorized to effect the repurchase of STX ordinary shares in an amount equal to the remaining STUC Share Repurchase Program amount as of the effective time of the scheme of arrangement. As of October 1, 2021, $3.8 billion remained available for repurchase under the existing repurchase authorization limit. The following table sets forth information with respect to repurchases of ordinary shares during the three months ended October 1, 2021:

[0001137789-21-000128:notes:114]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Repurchases of ordinary shares |  | 5 |  |  | $ | 425 |  |
| Tax withholding related to vesting of equity awards |  | — |  |  | 43 |  |
| Total |  | 5 |  |  | $ | 468 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001137789-21-000128:notes:115]
[same as prior period, unchanged from 0001137789-21-000028:notes:135]

[0001137789-21-000128:notes:116]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | October 1,2021 |  | October 2,2020 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,288 |  |  | $ | 1,608 |  |  |  |  |  |
| Distributors |  | 507 |  |  | 367 |  |  |  |  |  |
| Retailers |  | 320 |  |  | 339 |  |  |  |  |  |
| Total |  | $ | 3,115 |  |  | $ | 2,314 |  |  |  |  |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,583 |  |  | $ | 1,106 |  |  |  |  |  |
| Americas |  | 1,079 |  |  | 805 |  |  |  |  |  |
| EMEA |  | 453 |  |  | 403 |  |  |  |  |  |
| Total |  | $ | 3,115 |  |  | $ | 2,314 |  |  |  |  |  |

[0001137789-21-000128:notes:117]
[same as prior period, unchanged from 0001137789-21-000028:notes:137]

[0001137789-21-000128:notes:118]
(1) Revenue is attributed to geography based on bill from locations.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001137789-21-000128:notes:119]
[same as prior period, unchanged from 0001137789-21-000028:notes:142]

[0001137789-21-000128:notes:120]
[same as prior period, unchanged from 0001137789-21-000028:notes:143]

[0001137789-21-000128:notes:121]
[same as prior period, unchanged from 0001137789-21-000028:notes:144]

[0001137789-21-000128:notes:122]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product warranty return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the three months ended October 1, 2021 and October 2, 2020 were as follows:

[0001137789-21-000128:notes:123]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 1,2021 |  | October 2,2020 |
| Balance, beginning of period |  | $ | 136 |  |  | $ | 151 |  |
| Warranties issued |  | 21 |  |  | 18 |  |
| Repairs and replacements |  | (23) |  |  | (21) |  |
| Changes in liability for pre-existing warranties, including expirations |  | 6 |  |  | (6) |  |
| Balance, end of period |  | $ | 140 |  |  | $ | 142 |  |


## us-gaap:EarningsPerShareTextBlock

[0001137789-21-000128:notes:124]
[same as prior period, unchanged from 0001137789-21-000028:notes:147]

[0001137789-21-000128:notes:125]
|  |  | For the Three Months Ended |  |  |
| (In millions, except per share data) |  | October 1,2021 |  | October 2,2020 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 526 |  |  | $ | 223 |  |  |  |  |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 226 |  |  | 257 |  |  |  |  |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | 5 |  |  | 2 |  |  |  |  |  |
| Total shares for purpose of calculating diluted net income per share |  | 231 |  |  | 259 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.33 |  |  | $ | 0.87 |  |  |  |  |  |
| Diluted |  | 2.28 |  |  | 0.86 |  |  |  |  |  |

[0001137789-21-000128:notes:126]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share were not material for the three months ended October 1, 2021 and October 2, 2020.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001137789-21-000128:notes:127]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001137789-21-000128:notes:128]
Litigation

[0001137789-21-000128:notes:129]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial is scheduled to begin on February 7, 2022. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.

[0001137789-21-000128:notes:130]
Seagate Technology LLC, et al. v. NHK Spring Co. Ltd. and TDK Corporation, et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology International filed a complaint in the United States District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc., and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Company had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Company paid artificially high prices on its purchases of suspension assemblies. The Company seeks to recover the overcharges it paid for suspension assemblies, as well as additional relief permitted by law.

[0001137789-21-000128:notes:131]
Nidec Corporation v. Seagate Technology LLC, et al. On January 18, 2021, Nidec Corporation filed a complaint against Seagate Technology LLC, Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology (Netherlands) B.V. in the United States District Court for the District of Delaware, alleging infringement of the following patents: U.S. Patent No. 8,737,017, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,742,239, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,935,528, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 10,407,775, titled “Base Plate, Hard Disk Drive, and Method of Manufacturing Base Plate,” and U.S. Patent No. 10,460,767, titled “Base Member Including Information Mark and Insulating Coating Layer, and Disk Drive Apparatus Including the Same.” The complaint seeks unspecified compensatory damages and other relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. On July 20, 2021, the court stayed the case pending the result of an arbitration between the parties. The arbitration hearing commenced on October 18, 2021. The Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001137789-21-000128:notes:132]
Environmental Matters

[0001137789-21-000128:notes:133]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001137789-21-000128:notes:134]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001137789-21-000128:notes:135]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001137789-21-000128:notes:136]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001137789-21-000128:notes:137]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the U.S., Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001137789-21-000128:notes:138]
Other Matters

[0001137789-21-000128:notes:139]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:SubsequentEventsTextBlock

[0001137789-21-000128:notes:140]
Dividend Declared

[0001137789-21-000128:notes:141]
On October 22, 2021, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on January 5, 2022 to shareholders of record as of the close of business on December 22, 2021.

[0001137789-21-000128:notes:142]
Credit Agreement

[0001137789-21-000128:notes:143]
On October 14, 2021, STX and its subsidiary Seagate HDD Cayman entered into an amendment to the Credit Agreement, dated as of February 20, 2019. See “Note 3. Debt” for information regarding the amended credit agreement. On October 19, 2021, the Company entered into an additional interest rate swap contract. See “Note 6. Derivative Financial Instruments” for more information.
