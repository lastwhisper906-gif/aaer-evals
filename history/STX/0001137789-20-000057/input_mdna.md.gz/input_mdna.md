# STX MD&A — 0001137789-20-000057


## mdna

[0001137789-20-000057:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001137789-20-000057:mdna:2]
The following is a discussion of the Company’s financial condition, changes in financial condition and results of operations for the fiscal years ended July 3, 2020, June 28, 2019 and June 29, 2018.

[0001137789-20-000057:mdna:3]
You should read this discussion in conjunction with “Item 6. Selected Financial Data” and “Item 8. Financial Statements and Supplementary Data” included elsewhere in this Annual Report on Form 10-K. Except as noted, references to any fiscal year mean the twelve-month period ending on the Friday closest to June 30 of that year. Accordingly, fiscal year 2020 comprised 53 weeks and ended on July 3, 2020. Fiscal year 2019 comprised 52 weeks and ended on June 28, 2019. Fiscal year 2018 comprised 52 weeks and ended on June 29, 2018. Fiscal year 2026 will also be comprised of 53 weeks and will end on July 3, 2026.

[0001137789-20-000057:mdna:4]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is provided in addition to the accompanying consolidated financial statements and notes to assist readers in understanding our results of operations, financial condition and cash flows. Our MD&A is organized as follows:

[0001137789-20-000057:mdna:5]
•Fiscal Year 2020 Summary. Overview of financial and other highlights affecting us in fiscal year 2020.

[0001137789-20-000057:mdna:6]
•Results of Operations. Analysis of our financial results comparing fiscal years 2020 and 2019 to the prior-year periods.

[0001137789-20-000057:mdna:7]
•Liquidity and Capital Resources. Analysis of changes in our balance sheets and cash flows, and discussion of our financial condition including potential sources of liquidity.

[0001137789-20-000057:mdna:8]
•Contractual Obligations and Off-Balance Sheet Arrangements. Overview of contractual obligations and contingent liabilities and commitments outstanding as of July 3, 2020 and an explanation of off-balance sheet arrangements.

[0001137789-20-000057:mdna:9]
•Critical Accounting Estimates. Accounting estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001137789-20-000057:mdna:10]
•For an overview of our business, see “Part I - Item 1. Business—Overview.”

[0001137789-20-000057:mdna:11]
Fiscal Year 2020 Summary

[0001137789-20-000057:mdna:12]
During fiscal year 2020, we shipped 442 exabytes of HDD storage capacity. We generated revenue of $10.5 billion and gross margins of 27% and our operating cash flow was $1.7 billion. We repurchased $1,137 million of certain outstanding senior notes, exchanged $456 million of certain senior notes to longer duration notes, borrowed $500 million under our term loan facility (“Term Loan”) and issued $500 million of new senior notes. We repurchased approximately 17 million of our ordinary shares for $850 million and paid $673 million in dividends. Additionally, we changed our estimate of the useful lives of our manufacturing equipment from a range of three to five years to a range of three to seven years. The effect of this change in estimate increased the fiscal year 2020 net income by $134 million.

[0001137789-20-000057:mdna:13]
Impact of COVID-19

[0001137789-20-000057:mdna:14]
The COVID-19 pandemic has resulted in a widespread health crisis and numerous disease control measures being taken to limit its spread, the effects of which began during our quarter ended April 3, 2020. We incurred certain supply chain and demand disruptions during the fiscal year 2020, as well as factory under-utilization and higher logistics and operational costs and softer demand across our markets due to the COVID-19 pandemic, which we expect to continue into our fiscal year 2021. Our customers also experienced certain supply chain and demand disruptions in our fourth fiscal quarter 2020, which we anticipate will continue into fiscal year 2021. We are continuing to actively monitor the effects and potential impacts of the COVID-19 pandemic on all aspects of our business, liquidity and capital resources. We are complying with governmental rules and guidelines across all of our sites and are actively working on opportunities to lower our cost structure and drive further operational efficiencies. Although we are unable to predict the impact of COVID-19 on our business, results of operations, liquidity or capital resources at this time, we expect we will be negatively affected if the pandemic and related public and private health measures result in substantial manufacturing or supply chain problems, substantial reductions in demand due to disruptions in the operations of our customers or partners, disruptions in local and global economies, volatility in the global financial markets, sustained reductions or volatility in overall demand trends, restrictions on the export or shipment of our products, or other ramifications from the COVID-19 pandemic. For a further discussion of the uncertainties and business risks associated with the COVID-19 pandemic, see the section entitled “Risk Factors” in Part I, Item 1A of this Annual Report.

[0001137789-20-000057:mdna:15]
Results of Operations

[0001137789-20-000057:mdna:16]
We list in the tables below summarized information from our Consolidated Statements of Operations by dollar amounts and as a percentage of revenue:

[0001137789-20-000057:mdna:17]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 3,2020 |  | June 28,2019 |  | June 29,2018 |
| Revenue |  | $ | 10,509 |  |  | $ | 10,390 |  |  | $ | 11,184 |  |
| Cost of revenue |  | 7,667 |  |  | 7,458 |  |  | 7,820 |  |
| Gross profit |  | 2,842 |  |  | 2,932 |  |  | 3,364 |  |
| Product development |  | 973 |  |  | 991 |  |  | 1,026 |  |
| Marketing and administrative |  | 473 |  |  | 453 |  |  | 562 |  |
| Amortization of intangibles |  | 14 |  |  | 23 |  |  | 53 |  |
| Restructuring and other, net |  | 82 |  |  | (22) |  |  | 89 |  |
| Income from operations |  | 1,300 |  |  | 1,487 |  |  | 1,634 |  |
| Other expense, net |  | (268) |  |  | (115) |  |  | (216) |  |
| Income before income taxes |  | 1,032 |  |  | 1,372 |  |  | 1,418 |  |
| Provision (Benefit) for income taxes |  | 28 |  |  | (640) |  |  | 236 |  |
| Net income |  | $ | 1,004 |  |  | $ | 2,012 |  |  | $ | 1,182 |  |

[0001137789-20-000057:mdna:18]
|  |  | Fiscal Years Ended |  |  |  |  |
|  |  | July 3,2020 |  | June 28,2019 |  | June 29,2018 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 73 |  |  | 72 |  |  | 70 |  |
| Gross margin |  | 27 |  |  | 28 |  |  | 30 |  |
| Product development |  | 9 |  |  | 10 |  |  | 9 |  |
| Marketing and administrative |  | 5 |  |  | 4 |  |  | 5 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |
| Restructuring and other, net |  | 1 |  |  | — |  |  | 1 |  |
| Income from operations |  | 12 |  |  | 14 |  |  | 15 |  |
| Other expense, net |  | (2) |  |  | (1) |  |  | (2) |  |
| Income before income taxes |  | 10 |  |  | 13 |  |  | 13 |  |
| (Benefit) provision for income taxes |  | — |  |  | (6) |  |  | 2 |  |
| Net income |  | 10 | % |  | 19 | % |  | 11 | % |

[0001137789-20-000057:mdna:19]
39

[0001137789-20-000057:mdna:20]
The following table summarizes information regarding consolidated revenues by channel, geography, and market and HDD exabytes shipped by market and price per terabyte:

[0001137789-20-000057:mdna:21]
|  |  | Fiscal Years Ended |  |  |  |  |
|  |  | July 3,2020 |  | June 28,2019 |  | June 29,2018 |
| Revenues by Channel (%) |  |  |  |  |  |  |
| OEMs |  | 71 | % |  | 70 | % |  | 70 | % |
| Distributors |  | 17 | % |  | 17 | % |  | 17 | % |
| Retailers |  | 12 | % |  | 13 | % |  | 13 | % |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |
| Asia Pacific |  | 48 | % |  | 49 | % |  | 49 | % |
| Americas |  | 34 | % |  | 32 | % |  | 33 | % |
| EMEA |  | 18 | % |  | 19 | % |  | 18 | % |
| Revenues by Market (%) |  |  |  |  |  |  |
| Mass capacity |  | 53 | % |  | 43 | % |  | 42 | % |
| Legacy |  | 39 | % |  | 50 | % |  | 51 | % |
| Other |  | 8 | % |  | 7 | % |  | 7 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |
| Mass capacity |  | 317 |  |  | 202 |  |  | 193 |  |
| Legacy |  | 125 |  |  | 145 |  |  | 145 |  |
| Total |  | 442 |  |  | 347 |  |  | 338 |  |
| HDD Price per Terabyte |  | $ | 22 |  |  | $ | 28 |  |  | $ | 31 |  |

[0001137789-20-000057:mdna:22]
____________________________________________________________

[0001137789-20-000057:mdna:23]
(1) Revenue is attributed to countries based on the bill from location.

[0001137789-20-000057:mdna:24]
Fiscal Year 2020 Compared to Fiscal Year 2019

[0001137789-20-000057:mdna:25]
Revenue

[0001137789-20-000057:mdna:26]
|  |  | Fiscal Years Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | July 3,2020 |  | June 28,2019 |  | Change |  | %Change |
| Revenue |  | $ | 10,509 |  |  | $ | 10,390 |  |  | $ | 119 |  |  | 1 | % |

[0001137789-20-000057:mdna:27]
Revenue in fiscal year 2020 increased approximately 1%, or $119 million, from fiscal year 2019, primarily due to an increase in mass capacity storage exabytes shipped, partially offset by price erosion and a decrease in legacy exabytes shipped.

[0001137789-20-000057:mdna:28]
Cost of Revenue and Gross Margin

[0001137789-20-000057:mdna:29]
|  |  | Fiscal Years Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | July 3,2020 |  | June 28,2019 |  | Change |  | %Change |
| Cost of revenue |  | $ | 7,667 |  |  | $ | 7,458 |  |  | $ | 209 |  |  | 3 | % |
| Gross profit |  | 2,842 |  |  | 2,932 |  |  | (90) |  |  | (3) | % |
| Gross margin |  | 27 | % |  | 28 | % |  |  |  |  |

[0001137789-20-000057:mdna:30]
For fiscal year 2020, gross margin as a percentage of revenue decreased compared to the prior fiscal year due to price erosion and higher logistics costs and factory under-utilization due to COVID-19-related disruptions, partially offset by improved product mix and lower depreciation expense due to the change in useful lives of our manufacturing equipment in the quarter ended October 4, 2019.

[0001137789-20-000057:mdna:31]
Operating Expenses

[0001137789-20-000057:mdna:32]
|  |  | Fiscal Years Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | July 3,2020 |  | June 28,2019 |  | Change |  | %Change |
| Product development |  | $ | 973 |  |  | $ | 991 |  |  | $ | (18) |  |  | (2) | % |
| Marketing and administrative |  | 473 |  |  | 453 |  |  | 20 |  |  | 4 | % |
| Amortization of intangibles |  | 14 |  |  | 23 |  |  | (9) |  |  | (39) | % |
| Restructuring and other, net |  | 82 |  |  | (22) |  |  | 104 |  |  | (473) | % |
| Operating expenses |  | $ | 1,542 |  |  | $ | 1,445 |  |  | $ | 97 |  |  |  |

[0001137789-20-000057:mdna:33]
Product Development Expense. Product development expenses for fiscal year 2020 decreased by $18 million from fiscal year 2019 primarily due to a $21 million decrease in depreciation expense and an $18 million decrease in materials expense, partially offset by a $13 million increase in outside services expense, an $8 million increase in variable compensation expense and a $7 million increase in compensation and other employee benefits.

[0001137789-20-000057:mdna:34]
Marketing and Administrative Expense. Marketing and administrative expenses for fiscal year 2020 increased by $20 million from fiscal year 2019 primarily due to a $13 million increase in other general expenses, an $11 million increase in outside services expense, a $6 million increase in share-based compensation expense and a $5 million increase in variable compensation expense, partially offset by a $5 million decrease in compensation and other employee benefits and a $4 million decrease in depreciation expense.

[0001137789-20-000057:mdna:35]
Amortization of Intangibles. Amortization of intangibles for fiscal year 2020 decreased by $9 million, as compared to fiscal year 2019, due to certain intangible assets that reached the end of their useful lives.

[0001137789-20-000057:mdna:36]
Restructuring and Other, net. Restructuring and other, net for fiscal year 2020 was $82 million, primarily comprised of restructuring charges related to the restructuring plan the Company committed to on June 1, 2020 to reduce our workforce by approximately 500 employees and charges related to a voluntary early exit program and other restructuring plans.

[0001137789-20-000057:mdna:37]
Restructuring and other, net for fiscal year 2019 was comprised of a $75 million net gain from the sale of a certain property partially offset by charges related to a voluntary early exit program.

[0001137789-20-000057:mdna:38]
Other Expense, net

[0001137789-20-000057:mdna:39]
|  |  | Fiscal Years Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | July 3,2020 |  | June 28,2019 |  | Change |  | %Change |
| Other expense, net |  | $ | (268) |  |  | $ | (115) |  |  | $ | (153) |  |  | 133 | % |

[0001137789-20-000057:mdna:40]
Other expense, net for fiscal year 2020 increased by $153 million compared to fiscal year 2019 mainly due to $80 million of non-recurring income, net in fiscal year 2019 related to our previous investment in Toshiba Memory Holdings Corporation (“TMHC”), now known as Kioxia, which was redeemed in fiscal year 2019, a $62 million loss resulting from the repurchase of certain long-term debt, an $18 million strategic investment impairment and an $11 million net increase in losses due to unfavorable changes in foreign currency exchange rates, partially offset by a $20 million decrease in interest expense related to the repurchase of certain long-term debt.

[0001137789-20-000057:mdna:41]
Income Taxes

[0001137789-20-000057:mdna:42]
|  |  | Fiscal Years Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | July 3,2020 |  | June 28,2019 |  | Change |  | %Change |
| Provision (benefit) for income taxes |  | $ | 28 |  |  | $ | (640) |  |  | $ | 668 |  |  | (104) | % |

[0001137789-20-000057:mdna:43]
We recorded an income tax provision of $28 million for fiscal year 2020 compared to an income tax benefit of $640 million for fiscal year 2019. Our fiscal year 2020 income tax provision included net tax benefits of approximately $12 million associated with share-based compensation expense and $16 million associated with the release of valuation allowance on deferred tax assets driven by our profitability outlook in the U.S. Our fiscal year 2019 income tax benefit included a net tax benefit of $761 million primarily associated with the release of valuation allowance on deferred tax assets driven by improvements in our profitability outlook in the U.S., including our efforts to structurally and operationally align our EDS business with the rest of the Company.

[0001137789-20-000057:mdna:44]
Our Irish tax resident parent holding company owns various U.S. and non-Irish subsidiaries that operate in multiple non-Irish income tax jurisdictions. Our worldwide operating income is either subject to varying rates of income tax or is exempt from income tax due to tax incentive programs we operate under in Malaysia, Singapore and Thailand. These tax incentives are scheduled to expire in whole or in part at various dates through 2025. Certain tax incentives may be extended if specific conditions are met.

[0001137789-20-000057:mdna:45]
Our income tax provision recorded for fiscal year 2020 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. and non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland; and (ii) tax benefits related to research credits. Our income tax benefit recorded for fiscal year 2019 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) a decrease in valuation allowance for certain deferred tax assets, primarily driven by improvements in our profitability outlook in the U.S.; and (ii) tax benefits related to non-U.S. and non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland.

[0001137789-20-000057:mdna:46]
Based on our non-Irish ownership structure and subject to (i) potential future increases in our valuation allowance for deferred tax assets; and (ii) a future change in our intention to indefinitely reinvest earnings from our subsidiaries outside of Ireland, we anticipate that our effective tax rate in future periods will generally be less than the Irish statutory rate.

[0001137789-20-000057:mdna:47]
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (“CARES Act”) was signed into law in the U.S. We have concluded the tax provisions of the CARES Act did not have a material impact to our consolidated financial statements for fiscal year 2020.

[0001137789-20-000057:mdna:48]
During the fiscal year ended July 3, 2020, tax legislation was enacted, which becomes effective in our fiscal years 2020 and 2021. We have concluded these tax legislation changes have no material impact to our consolidated financial statements for fiscal year 2020.

[0001137789-20-000057:mdna:49]
Fiscal Year 2019 Compared to Fiscal Year 2018

[0001137789-20-000057:mdna:50]
Revenue

[0001137789-20-000057:mdna:51]
|  |  | Fiscal Years Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | June 28,2019 |  | June 29,2018 |  | Change |  | %Change |
| Revenue |  | $ | 10,390 |  |  | $ | 11,184 |  |  | $ | (794) |  |  | (7) | % |

[0001137789-20-000057:mdna:52]
Revenue in fiscal year 2019 decreased approximately 7%, or $0.8 billion, from fiscal year 2018, primarily due to less favorable market conditions during the first half of the fiscal year and price erosion, partially offset by an increase in mass capacity storage exabytes shipped.

[0001137789-20-000057:mdna:53]
Cost of Revenue and Gross Margin

[0001137789-20-000057:mdna:54]
|  |  | Fiscal Years Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | June 28,2019 |  | June 29,2018 |  | Change |  | %Change |
| Cost of revenue |  | $ | 7,458 |  |  | $ | 7,820 |  |  | $ | (362) |  |  | (5) | % |
| Gross profit |  | 2,932 |  |  | 3,364 |  |  | (432) |  |  | (13) | % |
| Gross margin percentage |  | 28 | % |  | 30 | % |  |  |  |  |

[0001137789-20-000057:mdna:55]
42

[0001137789-20-000057:mdna:56]
For fiscal year 2019, gross margin as a percentage of revenue decreased compared to the prior fiscal year due to price erosion partially offset by improved product mix.

[0001137789-20-000057:mdna:57]
Operating Expenses

[0001137789-20-000057:mdna:58]
|  |  | Fiscal Years Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | June 28,2019 |  | June 29,2018 |  | Change |  | %Change |
| Product development |  | $ | 991 |  |  | $ | 1,026 |  |  | $ | (35) |  |  | (3) | % |
| Marketing and administrative |  | 453 |  |  | 562 |  |  | (109) |  |  | (19) | % |
| Amortization of intangibles |  | 23 |  |  | 53 |  |  | (30) |  |  | (57) | % |
| Restructuring and other, net |  | (22) |  |  | 89 |  |  | (111) |  |  | (125) | % |
| Operating expenses |  | $ | 1,445 |  |  | $ | 1,730 |  |  | $ | (285) |  |  |  |

[0001137789-20-000057:mdna:59]
Product Development Expense. Product development expenses for fiscal year 2019 decreased by $35 million from fiscal year 2018 primarily due to a $38 million decrease in variable compensation expense, partially offset by a $5 million increase in other employee benefits.

[0001137789-20-000057:mdna:60]
Marketing and Administrative Expense. Marketing and administrative expenses for fiscal year 2019 decreased by $109 million from fiscal year 2018 primarily due to a $27 million decrease in salaries and related benefits as a result of the restructuring of our workforce in prior periods, a $44 million decrease in other general expenses due to related operational efficiencies, a $24 million decrease in variable compensation expense and a $14 million decrease in share-based compensation expense.

[0001137789-20-000057:mdna:61]
Amortization of Intangibles. Amortization of intangibles for fiscal year 2019 decreased by $30 million compared to fiscal year 2018, due to certain intangible assets reaching the end of their useful lives.

[0001137789-20-000057:mdna:62]
Restructuring and Other, net. Restructuring and other, net for fiscal year 2019 was comprised of a $75 million net gain from the sale of a certain property partially offset by charges related to a voluntary early exit program.

[0001137789-20-000057:mdna:63]
Restructuring and other, net for fiscal year 2018 was comprised primarily of restructuring charges to reduce our workforce by approximately 1,100 employees. Restructuring and other, net also included a gain of $25 million from the sale of certain properties during fiscal year 2018.

[0001137789-20-000057:mdna:64]
Other Expense, net

[0001137789-20-000057:mdna:65]
|  |  | Fiscal Years Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | June 28,2019 |  | June 29,2018 |  | Change |  | %Change |
| Other expense, net |  | $ | (115) |  |  | $ | (216) |  |  | $ | 101 |  |  | (47) | % |

[0001137789-20-000057:mdna:66]
Other expense, net for fiscal year 2019 decreased by $101 million compared to fiscal year 2018 mainly due to a $56 million increase in interest income on our investment in TMHC, a $37 million net increase in gains on settlement of derivatives and a $13 million net decrease in interest expense due to the repayment of certain long-term debt.

[0001137789-20-000057:mdna:67]
Income Taxes

[0001137789-20-000057:mdna:68]
|  |  | Fiscal Years Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | June 28,2019 |  | June 29,2018 |  | Change |  | %Change |
| (Benefit) provision for income taxes |  | $ | (640) |  |  | $ | 236 |  |  | $ | (876) |  |  | (371) | % |

[0001137789-20-000057:mdna:69]
43

[0001137789-20-000057:mdna:70]
We recorded an income tax benefit of $640 million for fiscal year 2019 compared to an income tax provision of $236 million for fiscal year 2018. Our fiscal year 2019 income tax benefit included a net tax benefit of $761 million primarily associated with the release of valuation allowance on deferred tax assets driven by improvements in our profitability outlook in the U.S., including our efforts to structurally and operationally align our EDS business with the rest of the Company. Our fiscal year 2018 income tax provision included approximately $204 million of tax expense associated with the revaluation of U.S. deferred tax assets as a result of the enactment of the Tax Cuts and Jobs Act of 2017 on December 22, 2017, offset by the reversal of previously recorded unrecognized tax benefits of $7 million, and certain non-recurring items.

[0001137789-20-000057:mdna:71]
Our income tax benefit recorded for fiscal year 2019 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) a decrease in valuation allowance for certain deferred tax assets, primarily driven by improvements in our profitability outlook in the U.S.; and (ii) tax benefits related to non-U.S. and non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland. Our income tax provision recorded for fiscal year 2018 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. and non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland; and (ii) a reduction in the net U.S. deferred tax assets associated with revaluation to a lower U.S. tax rate.

[0001137789-20-000057:mdna:72]
Liquidity and Capital Resources

[0001137789-20-000057:mdna:73]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. During fiscal year 2020, we reduced and restructured our long-term debt portfolio through a combination of new issuances, repurchases and exchanges to lower annual repayment levels by extending the maturity dates of certain notes and lowering the average interest rates. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash have been and will continue to be sufficient to meet our cash needs for the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs, will allow us to manage the potential impacts of the COVID-19 pandemic on our business operations for the foreseeable future. However, the challenges posed by COVID-19 to our industry and to our business are evolving rapidly and are highly uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to COVID-19.

[0001137789-20-000057:mdna:74]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of July 3, 2020.

[0001137789-20-000057:mdna:75]
Cash and Cash Equivalents

[0001137789-20-000057:mdna:76]
|  |  | As of |  |  |  |  |
| (Dollars in millions) |  | July 3,2020 |  | June 28,2019 |  | Change |
| Cash and cash equivalents |  | $ | 1,722 |  |  | $ | 2,220 |  |  | $ | (498) |  |

[0001137789-20-000057:mdna:77]
Our cash and cash equivalents decreased by $498 million from June 28, 2019 primarily as a result of repurchases of certain long-term debt of $1,137 million, repurchases of our ordinary shares of $850 million, dividends to our shareholders of $673 million and payments for capital expenditures of $585 million, partially offset by net cash of $1,714 million provided by operating activities and net proceeds of $994 million from issuance of long-term debt. The following table summarizes results from the Consolidated Statement of Cash Flows for the periods indicated:

[0001137789-20-000057:mdna:78]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 3,2020 |  | June 28,2019 |  | June 29,2018 |
| Net cash flow provided by (used in): |  |  |  |  |  |  |
| Operating activities |  | $ | 1,714 |  |  | $ | 1,761 |  |  | $ | 2,113 |  |
| Investing activities |  | (635) |  |  | 846 |  |  | (1,588) |  |
| Financing activities |  | (1,605) |  |  | (2,212) |  |  | (1,211) |  |
| Effect of foreign currency exchange rates |  | (1) |  |  | (1) |  |  | — |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  | $ | (527) |  |  | $ | 394 |  |  | $ | (686) |  |

[0001137789-20-000057:mdna:79]
Cash Provided by Operating Activities

[0001137789-20-000057:mdna:80]
Cash provided by operating activities for fiscal year 2020 was approximately $1.7 billion and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-20-000057:mdna:81]
•an increase of $394 million in accounts payable, primarily due to timing of payments and an increase in materials purchased; partially offset by

[0001137789-20-000057:mdna:82]
•an increase of $166 million in inventories, primarily due to an increase in materials purchased for new product ramps and the potential for supply chain disruptions due to COVID-19; and

[0001137789-20-000057:mdna:83]
•an increase of $127 million in accounts receivable, primarily due to the timing of shipments.

[0001137789-20-000057:mdna:84]
Cash provided by operating activities for fiscal year 2019 was approximately $1.8 billion and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, a release of valuation allowance related to our U.S. deferred tax assets and:

[0001137789-20-000057:mdna:85]
•a decrease of $204 million in accounts receivable, primarily due to lower revenue; and

[0001137789-20-000057:mdna:86]
•a decrease of $80 million in inventories, primarily due to a decrease in units built; partially offset by

[0001137789-20-000057:mdna:87]
•a decrease of $268 million in accounts payable, primarily due to a decrease in direct material purchases; and

[0001137789-20-000057:mdna:88]
•a decrease of $84 million in accrued employee compensation, primarily due to a decrease in our variable compensation expense.

[0001137789-20-000057:mdna:89]
Cash provided by operating activities for fiscal year 2018 was approximately $2.1 billion and includes the effects of net income adjusted for non-cash items including depreciation and amortization, deferred income taxes primarily due to the remeasurement of our U.S. deferred tax assets at the lower corporate tax rate, share-based compensation and:

[0001137789-20-000057:mdna:90]
• an increase of $65 million in accounts payable, primarily due to timing of payments of capital expenditures; and

[0001137789-20-000057:mdna:91]
• a decrease of $71 million in vendor receivables, primarily due to improved collections; partially offset by

[0001137789-20-000057:mdna:92]
• an increase of $71 million in inventories, primarily due to an increase in units built.

[0001137789-20-000057:mdna:93]
Cash (Used in) Provided by Investing Activities

[0001137789-20-000057:mdna:94]
In fiscal year 2020, we used $0.6 billion for net cash investing activities, which was primarily due to payments for the purchase of property, equipment and leasehold improvements of approximately $585 million and payments for the purchase of investments of $58 million.

[0001137789-20-000057:mdna:95]
In fiscal year 2019, we received $0.8 billion for net cash investing activities, which was primarily due to proceeds of $1.3 billion from the redemption of an investment in non-convertible preferred stock of TMHC and the proceeds of $144 million primarily from the sale of certain properties, partially offset by the payments for the purchase of property, equipment and leasehold improvements of approximately $602 million.

[0001137789-20-000057:mdna:96]
In fiscal year 2018, we used $1.6 billion for net cash investing activities, which was primarily due to our investment in TMHC of $1.3 billion and the payments for the purchase of property, equipment and leasehold improvements of approximately $366 million, partially offset by the proceeds of $69 million from the sale of properties.

[0001137789-20-000057:mdna:97]
Cash Used in Financing Activities

[0001137789-20-000057:mdna:98]
Net cash used in financing activities of $1.6 billion for fiscal year 2020 was primarily attributable to the following activities:

[0001137789-20-000057:mdna:99]
•$1,137 million net repurchases of long-term debt;

[0001137789-20-000057:mdna:100]
•$850 million in payments for repurchases of our ordinary shares;

[0001137789-20-000057:mdna:101]
•$673 million in dividend payments; partially offset by

[0001137789-20-000057:mdna:102]
•$498 million in net proceeds from borrowings under the Term Loan;

[0001137789-20-000057:mdna:103]
•$496 million from the issuance of Senior Notes; and

[0001137789-20-000057:mdna:104]
•$103 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-20-000057:mdna:105]
Net cash used in financing activities of $2.2 billion for fiscal year 2019 was primarily attributable to the following activities:

[0001137789-20-000057:mdna:106]
•$963 million in payments for repurchases of our ordinary shares;

[0001137789-20-000057:mdna:107]
•$713 million in dividend payments; and

[0001137789-20-000057:mdna:108]
•$574 million net repurchases of long-term debt.

[0001137789-20-000057:mdna:109]
Net cash used in financing activities of $1.2 billion for fiscal year 2018 was primarily attributable to the following activities:

[0001137789-20-000057:mdna:110]
•$726 million in dividend payments;

[0001137789-20-000057:mdna:111]
•$361 million in payments for repurchases of ordinary shares; and

[0001137789-20-000057:mdna:112]
•$214 million of repurchases of long-term debt; offset by

[0001137789-20-000057:mdna:113]
•$113 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-20-000057:mdna:114]
Liquidity Sources

[0001137789-20-000057:mdna:115]
Our primary sources of liquidity as of July 3, 2020, consist of: (1) approximately $1.7 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) subject to compliance with certain requirements under our control, up to $1.5 billion available for borrowing under our senior unsecured revolving credit facility (“Revolving Credit Facility”), which is part of our credit agreement (the “Credit Agreement”).

[0001137789-20-000057:mdna:116]
As of July 3, 2020, no borrowings had been drawn and no borrowings had been utilized for letters of credit or swing line loans issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-20-000057:mdna:117]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The term of the Revolving Credit Facility is through February 20, 2024, and the maturity date of the Term Loan is September 16, 2025.

[0001137789-20-000057:mdna:118]
As of July 3, 2020, cash and cash equivalents held by non-Irish subsidiaries was $1.7 billion. This amount is potentially subject to taxation in Ireland upon repatriation by means of a dividend into our Irish parent. However, it is our intent to indefinitely reinvest earnings of non-Irish subsidiaries outside of Ireland and our current plans do not demonstrate a need to repatriate such earnings by means of a taxable Irish dividend. Should funds be needed in the Irish parent company and should we be unable to fund parent company activities through means other than a taxable Irish dividend, we would be required to accrue and pay Irish taxes on such dividend.

[0001137789-20-000057:mdna:119]
We believe that our sources of cash will be sufficient to fund our operations and meet our cash requirements for at least the next 12 months. For additional information on factors that could impact our ability to fund our operations and meet our cash requirements, including the COVID-19 pandemic, see the section entitled “Risk Factors” in Part I, Item 1A of this Annual Report.

[0001137789-20-000057:mdna:120]
Cash Requirements and Commitments

[0001137789-20-000057:mdna:121]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend and any future strategic investments. Our ability to fund these requirements will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001137789-20-000057:mdna:122]
On July 22, 2020, our Board of Directors declared a quarterly cash dividend of $0.65 per share, which will be payable on October 7, 2020 to shareholders of record as of the close of business on September 23, 2020.

[0001137789-20-000057:mdna:123]
As of July 3, 2020, we were in compliance with all of the covenants under our debt agreements. Based on our current outlook and the information we currently have available to us, we expect to be in compliance with the covenants in our debt agreements over the next 12 months.

[0001137789-20-000057:mdna:124]
The carrying value of our debt as of July 3, 2020 and June 28, 2019 was $4.2 billion and $4.3 billion, respectively. The table below presents the principal amounts of our outstanding debt:

[0001137789-20-000057:mdna:125]
|  |  | As of |  |  |  |  |
| (Dollars in millions) |  | July 3,2020 |  | June 28,2019 |  | Change |
| 4.250% Senior Notes due March 2022 |  | $ | 229 |  |  | $ | 750 |  |  | $ | (521) |  |
| 4.750% Senior Notes due June 2023 |  | 546 |  |  | 941 |  |  | (395) |  |
| 4.875% Senior Notes due March 2024 |  | 500 |  |  | 500 |  |  | — |  |
| 4.750% Senior Notes due January 2025 |  | 479 |  |  | 920 |  |  | (441) |  |
| 4.875% Senior Notes due June 2027 |  | 505 |  |  | 690 |  |  | (185) |  |
| 4.091% Senior Notes due June 2029 |  | 500 |  |  | — |  |  | 500 |  |
| 4.125% Senior Notes due January 2031 |  | 500 |  |  | — |  |  | 500 |  |
| 5.75% Senior Notes due December 2034 |  | 490 |  |  | 490 |  |  | — |  |
| LIBOR based Term Loan due September 2025 |  | 500 |  |  | — |  |  | 500 |  |
|  |  | $ | 4,249 |  |  | $ | 4,291 |  |  | $ | (42) |  |

[0001137789-20-000057:mdna:126]
From time to time, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means. During fiscal year 2020, we repurchased approximately 18 million of our ordinary shares including shares withheld for statutory tax withholdings related to vesting of employee equity awards. See “Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities-Repurchases of Our Equity Securities.” As of July 3, 2020, $1.3 billion remained available for repurchase under our existing repurchase authorization limit. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-20-000057:mdna:127]
For fiscal year 2021, we expect capital expenditures to be at or below our long-term targeted range of 6% to 8% of revenue. We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-20-000057:mdna:128]
Contractual Obligations and Commitments

[0001137789-20-000057:mdna:129]
Our contractual cash obligations and commitments as of July 3, 2020, are summarized in the table below:

[0001137789-20-000057:mdna:130]
|  |  |  |  | Fiscal Year(s) |  |  |  |  |  |  |
| (Dollars in millions) |  | Total |  | 2021 |  | 2022-2023 |  | 2024-2025 |  | Thereafter |
| Contractual Cash Obligations: |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | $ | 4,249 |  |  | $ | 19 |  |  | $ | 825 |  |  | $ | 1,029 |  |  | $ | 2,376 |  |
| Interest payments on debt |  | 1,352 |  |  | 183 |  |  | 360 |  |  | 283 |  |  | 526 |  |
| Purchase obligations (1) |  | 1,251 |  |  | 1,088 |  |  | 68 |  |  | 95 |  |  | — |  |
| Operating leases, including imputed interest (2) |  | 148 |  |  | 15 |  |  | 25 |  |  | 8 |  |  | 100 |  |
| Capital expenditures |  | 326 |  |  | 274 |  |  | 51 |  |  | 1 |  |  | — |  |
| Subtotal |  | 7,326 |  |  | 1,579 |  |  | 1,329 |  |  | 1,416 |  |  | 3,002 |  |
| Commitments: |  |  |  |  |  |  |  |  |  |  |
| Letters of credit or bank guarantees |  | 104 |  |  | 94 |  |  | 1 |  |  | — |  |  | 9 |  |
| Total |  | $ | 7,430 |  |  | $ | 1,673 |  |  | $ | 1,330 |  |  | $ | 1,416 |  |  | $ | 3,011 |  |

[0001137789-20-000057:mdna:131]
___________________________________

[0001137789-20-000057:mdna:132]
(1)Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms.

[0001137789-20-000057:mdna:133]
(2)Includes total future minimum rent expense under non-cancelable leases for both occupied and vacated facilities (rent expense is shown net of sublease income). Refer to “Item 8. Financial Statements and Supplementary Data—Note 6. Leases” for details.

[0001137789-20-000057:mdna:134]
As of July 3, 2020, we had a liability for unrecognized tax benefits and an accrual for the payment of related interest totaling $2 million, none of which is expected to be settled within one year. Outside of one year, we are unable to make a reasonably reliable estimate of when cash settlement with a taxing authority will occur.

[0001137789-20-000057:mdna:135]
Off-Balance Sheet Arrangements

[0001137789-20-000057:mdna:136]
As of July 3, 2020, we did not have any material off-balance sheet arrangements (as defined in Item 303(a)(4)(ii) of Regulation S-K).

[0001137789-20-000057:mdna:137]
Critical Accounting Policies and Estimates

[0001137789-20-000057:mdna:138]
The methods, estimates and judgments we use in applying our most critical accounting policies have a significant impact on the results we report in our consolidated financial statements. The SEC has defined the most critical accounting policies as the ones that are most important to the portrayal of our financial condition and operating results, and require us to make our most difficult and subjective judgments, often as a result of the need to make estimates of matters that are highly uncertain at the time of estimation. Based on this definition, our most critical accounting policies include: Revenue - Sales Program Accruals, Warranty, Income taxes and Assessing Goodwill and Other Long-lived Assets for Impairment. Below, we discuss these policies further, as well as the estimates and judgments involved. We also have other accounting policies and accounting estimates relating to uncollectible customer accounts, valuation of inventories, valuation of share-based payments and restructuring. We believe that these other accounting policies and accounting estimates either do not generally require us to make estimates and judgments that are as difficult or as subjective, or it is less likely that they would have a material impact on our reported results of operations for a given period.

[0001137789-20-000057:mdna:139]
Revenue - Sales Program Accruals. We record estimated variable consideration at the time of revenue recognition as a reduction to revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer's volume of purchases from us or other agreed upon rebate programs. For the distribution and retail channel, these sales incentive programs typically involve estimating the most likely amount of rebates related to a customer's level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Total sales programs were 12% of gross revenue in fiscal year 2020 and 11% for each of the 2019 and 2018 fiscal years. Adjustments to revenues due to under or over accruals for sales programs related to revenues reported in prior quarterly periods were less than 1% of gross revenue in fiscal years 2020, 2019 and 2018.

[0001137789-20-000057:mdna:140]
48

[0001137789-20-000057:mdna:141]
Warranty. We estimate probable product warranty costs at the time revenue is recognized. We generally provide a warranty on our products for a period of 1 to 5 years. Our warranty provision considers estimated product failure rates and trends (including the timing of product returns during the warranty periods), and estimated repair or replacement costs related to product quality issues, if any. We also exercise judgment in estimating our ability to sell refurbished products based on historical experience. Our judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited experience with those products upon which to base our warranty estimates.

[0001137789-20-000057:mdna:142]
Income Taxes. We make certain estimates and judgments in determining income tax expense for financial statement purposes. These estimates and judgments occur in the calculation of tax credits, recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for income tax and financial statement purposes, as well as tax liabilities associated with uncertain tax positions. The calculation of tax liabilities involves uncertainties in the application of complex tax rules and the potential for future adjustment of our uncertain tax positions by various taxing authorities. If estimates of these tax liabilities are greater or less than actual results, an additional tax provision or benefit will result. The deferred tax assets we record each period depend primarily on our ability to generate future taxable income in the United States and certain non-U.S. jurisdictions. Each period, we evaluate the need for a valuation allowance for our deferred tax assets and, if necessary, adjust the valuation allowance so that net deferred tax assets are recorded only to the extent we conclude it is more likely than not that these deferred tax assets will be realized. If our outlook for future taxable income changes significantly, our assessment of the need for, and the amount of, a valuation allowance may also change.

[0001137789-20-000057:mdna:143]
Assessing Goodwill and Other Long-lived Assets for Impairment. We perform a qualitative assessment in the fourth quarter of each fiscal year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount. Based on the qualitative assessment, if it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, then the Company is not required to perform the quantitative goodwill impairment test. If it is determined in the qualitative assessment that the fair value of a reporting unit is more likely than not below its carrying amount, including goodwill, then we perform a quantitative impairment test. The quantitative goodwill impairment test is performed by comparing the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit over its fair value is recognized as an impairment loss, limited to the total amount of goodwill allocated to that reporting unit.

[0001137789-20-000057:mdna:144]
We evaluate other long-lived assets, including property, equipment and leasehold improvements and other intangible assets subject to amortization, for recoverability whenever events or changes in circumstances indicate that the carrying values of those assets may not be recoverable. We assess the recoverability of an asset group by determining if the carrying value of the asset group exceeds the sum of the projected undiscounted cash flows expected to result from the use and eventual disposition of the assets over the remaining economic life of the primary asset in the asset group. If the recoverability assessment indicates that the carrying value of the asset group is not recoverable, we will estimate the fair value of the asset group and compare it to its carrying value. The excess of the carrying value over the fair value is allocated pro rata to derive the adjusted carrying value of each asset in the asset group. The adjusted carrying value of each asset in the asset group is not reduced below its fair value.

[0001137789-20-000057:mdna:145]
Recent Accounting Pronouncements

[0001137789-20-000057:mdna:146]
See “Item 8. Financial Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.
