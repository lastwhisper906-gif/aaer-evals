# STX notes — 0001104659-15-032642


## invest:InvestmentTableTextBlock

[0001104659-15-032642:notes:1]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 705 |  |  | $ | — |  |  | $ | 705 |  |
| Corporate bonds |  | 6 |  |  | — |  |  | 6 |  |
| Certificates of deposit |  | 1,485 |  |  | — |  |  | 1,485 |  |
|  |  | $ | 2,196 |  |  | $ | — |  |  | $ | 2,196 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 2,186 |  |
| Included in Short-term investments |  |  |  |  |  |  |  | 6 |  |
| Included in Restricted cash and investments |  |  |  |  |  |  |  | 4 |  |
| Total |  |  |  |  |  |  |  | $ | 2,196 |  |

[0001104659-15-032642:notes:2]
[same as prior period, unchanged from 0001104659-15-005719:notes:2]


## stx:ScheduleOfShareRepurchasesTableTextBlock

[0001104659-15-032642:notes:3]
| (In millions) | Number ofSharesRepurchased |  | Dollar Valueof SharesRepurchased |
| Repurchased during the three months ended October 3, 2014 | 3 |  |  | $ | 183 |  |
| Repurchased during the three months ended January 2, 2015 (1) | 0 |  |  | 18 |  |
| Repurchased during the three months ended April 3, 2015 | 12 |  |  | $ | 706 |  |
| Fiscal year repurchased through April 3, 2015 | 15 |  |  | $ | 907 |  |

[0001104659-15-032642:notes:4]
[same as prior period, unchanged from 0001104659-15-005719:notes:4]

[0001104659-15-032642:notes:5]
[same as prior period, unchanged from 0001104659-15-005719:notes:5]

[0001104659-15-032642:notes:6]
On April 22, 2015, the Board of Directors authorized the Company to repurchase an additional $2.5 billion of its outstanding ordinary shares.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001104659-15-032642:notes:7]
[same as prior period, unchanged from 0001104659-15-005719:notes:6]

[0001104659-15-032642:notes:8]
[same as prior period, unchanged from 0001104659-15-005719:notes:7]

[0001104659-15-032642:notes:9]
[same as prior period, unchanged from 0001104659-15-005719:notes:8]

[0001104659-15-032642:notes:10]
[same as prior period, unchanged from 0001104659-15-005719:notes:9]

[0001104659-15-032642:notes:11]
[same as prior period, unchanged from 0001104659-15-005719:notes:10]

[0001104659-15-032642:notes:12]
[same as prior period, unchanged from 0001104659-15-005719:notes:11]

[0001104659-15-032642:notes:13]
[same as prior period, unchanged from 0001104659-15-005719:notes:12]

[0001104659-15-032642:notes:14]
[same as prior period, unchanged from 0001104659-15-005719:notes:13]

[0001104659-15-032642:notes:15]
The Company incurred approximately $1 million of expenses related to the acquisition of LSI's Flash Business during the nine months ended April 3, 2015, which are included within Marketing and administrative expense on the Consolidated Statement of Operations.

[0001104659-15-032642:notes:16]
[same as prior period, unchanged from 0001104659-15-005719:notes:15]

[0001104659-15-032642:notes:17]
[same as prior period, unchanged from 0001104659-15-005719:notes:16]

[0001104659-15-032642:notes:18]
On March 31, 2014, the Company acquired all of the outstanding shares of Xyratex Ltd (“Xyratex”), a leading provider of data storage technology. The Company paid $13.25 per share, or approximately $376 million in cash for the acquisition. The acquisition of Xyratex further strengthens the Company’s vertically integrated supply and manufacturing chain for disk drives and provides access to important capital requirements, as well as expands the Company’s storage solutions portfolio.

[0001104659-15-032642:notes:19]
[same as prior period, unchanged from 0001104659-15-005719:notes:18]

[0001104659-15-032642:notes:20]
[same as prior period, unchanged from 0001104659-15-005719:notes:19]

[0001104659-15-032642:notes:21]
[same as prior period, unchanged from 0001104659-15-005719:notes:20]

[0001104659-15-032642:notes:22]
[same as prior period, unchanged from 0001104659-15-005719:notes:21]

[0001104659-15-032642:notes:23]
[same as prior period, unchanged from 0001104659-15-005719:notes:22]

[0001104659-15-032642:notes:24]
[same as prior period, unchanged from 0001104659-15-005719:notes:23]


## us-gaap:ConsolidationPolicyTextBlock

[0001104659-15-032642:notes:25]
[same as prior period, unchanged from 0001104659-15-005719:notes:24]

[0001104659-15-032642:notes:26]
[same as prior period, unchanged from 0001104659-15-005719:notes:25]

[0001104659-15-032642:notes:27]
[same as prior period, unchanged from 0001104659-15-005719:notes:26]

[0001104659-15-032642:notes:28]
[same as prior period, unchanged from 0001104659-15-005719:notes:27]


## us-gaap:DebtDisclosureTextBlock

[0001104659-15-032642:notes:29]
Debt

[0001104659-15-032642:notes:30]
Short-Term Borrowings

[0001104659-15-032642:notes:31]
On January 15, 2015, the Company and its subsidiary, Seagate HDD Cayman, entered into the Third Amendment to the 2011 Credit Agreement which increased the commitments available under the senior secured revolving credit facility (the "Revolving Credit Facility") from $500 million to $700 million and also extended the maturity date on the Credit Agreement until January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Credit Agreement) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. The loans made under the Credit Agreement will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings and for the issuance of letters of credit up to a sub-limit of $75 million. As of April 3, 2015, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

[0001104659-15-032642:notes:32]
Long-Term Debt

[0001104659-15-032642:notes:33]
$600 million Aggregate Principal Amount of 6.8% Senior Notes due October 2016 (the “2016 Notes”). The interest on the 2016 Notes was payable semi-annually on April 1 and October 1 of each year. The issuer under the 2016 Notes was Seagate HDD Cayman, and the obligations under the 2016 Notes were unconditionally guaranteed by certain of the Company’s significant subsidiaries. During the December 2014 quarter, the 2016 Notes were fully extinguished through repurchase and redemption for cash at a premium to their principal amount, plus accrued and unpaid interest.

[0001104659-15-032642:notes:34]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-15-032642:notes:35]
$600 million Aggregate Principal Amount of 6.875% Senior Notes due May 2020 (the “2020 Notes”). The interest on the 2020 Notes is payable semi-annually on May 1 and November 1 of each year. The issuer under the 2020 Notes is Seagate HDD Cayman, and the obligations under the 2020 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2015 quarter, the Company repurchased $1 million aggregate principal amount of its 2020 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. On April 7, 2015, Seagate HDD Cayman announced that it will redeem all of its remaining outstanding 2020 Notes. The Notes will be redeemed on May 7, 2015 (the “Redemption Date”) at a redemption price equal to $1,034.38 per $1,000 principal amount of the 2020 Notes redeemed plus accrued and unpaid interest from the interest payment date of May 1, 2015 to the Redemption Date. As a result, the 2020 Notes are classified as Current portion of long-term debt on the Company's Condensed Consolidated Balance Sheet at April 3, 2015.

[0001104659-15-032642:notes:36]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman, and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-15-032642:notes:37]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-15-032642:notes:38]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year, which commenced on January 1, 2015. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-15-032642:notes:39]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 1, 2034 (the “2034 Notes”). On December 2, 2014, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 5.75% Senior Notes due 2034 which mature on December 1, 2034. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on June 1, 2015. At any time before June 1, 2034, Seagate HDD Cayman may redeem some or all of the Notes at a “make-whole” redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points, minus accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date. At any time on or after June 1, 2034, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-15-032642:notes:40]
At April 3, 2015, future principal payments on long-term debt were as follows (in millions):

[0001104659-15-032642:notes:41]
| Fiscal Year | Amount |
| Remainder of 2015 | $ | 474 |  |
| 2016 | — |  |
| 2017 | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| Thereafter | 2,659 |  |
|  | $ | 3,933 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001104659-15-032642:notes:42]
[same as prior period, unchanged from 0001104659-15-005719:notes:41]

[0001104659-15-032642:notes:43]
The Company is exposed to market risks due to the volatility of interest rates, foreign currency exchange rates, and bond markets. The Company enters into foreign currency forward exchange contracts to manage the foreign currency exchange rate risk on forecasted expenses denominated in foreign currencies and to mitigate the remeasurement risk of certain foreign currency denominated liabilities. The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The changes in the fair values of the effective portions of designated cash flow hedges are recorded in Accumulated other comprehensive income (loss) until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments and the ineffective portions of cash flow hedges are adjusted to fair value through earnings. The amount of net unrealized losses on cash flow hedges was $4 million and $1 million as of April 3, 2015 and June 27, 2014, respectively.

[0001104659-15-032642:notes:44]
The Company dedesignates its cash flow hedges when the forecasted hedged transactions are realized or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive income (loss) are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company did not recognize any net gains or losses related to the loss of hedge designation on discontinued cash flow hedges during the three and nine months ended April 3, 2015. As of April 3, 2015, the Company’s existing foreign currency forward exchange contracts mature within 12 months. The deferred amount currently recorded in Accumulated other comprehensive income (loss) expected to be recognized into earnings over the next 12 months is $5 million.

[0001104659-15-032642:notes:45]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of April 3, 2015 and June 27, 2014:

[0001104659-15-032642:notes:46]
|  |  | As of April 3, 2015 |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| Thai Baht |  | $ | — |  |  | $ | 36 |  |
| Singapore Dollars |  | 80 |  |  | 41 |  |
| Chinese Renminbi |  | 31 |  |  | 16 |  |
| Euro |  | — |  |  | 11 |  |
|  |  | $ | 111 |  |  | $ | 104 |  |

[0001104659-15-032642:notes:47]
[same as prior period, unchanged from 0001104659-15-005719:notes:46]

[0001104659-15-032642:notes:48]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plan—the Seagate Deferred Compensation Plan (the “SDCP”). In the quarter ended December 27, 2013, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees. As of April 3, 2015, the notional investments underlying the TRS amounted to $98 million. The contract term of the TRS is through January 2016 and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001104659-15-032642:notes:49]
The following tables show the Company’s derivative instruments measured at fair value as reflected in the Condensed Consolidated Balance Sheet as of April 3, 2015 and June 27, 2014:

[0001104659-15-032642:notes:50]
|  |  | As of April 3, 2015 |
|  |  | Asset Derivatives |  | Liability Derivatives |
| (Dollars in millions) |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (5 | ) |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (3 | ) |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | — |  |  |  |  | $ | (8 | ) |

[0001104659-15-032642:notes:51]
[same as prior period, unchanged from 0001104659-15-005719:notes:50]

[0001104659-15-032642:notes:52]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statement of Comprehensive Income and the Condensed Consolidated Statement of Operations for the three and nine months ended April 3, 2015:

[0001104659-15-032642:notes:53]
[same as prior period, unchanged from 0001104659-15-005719:notes:52]

[0001104659-15-032642:notes:54]
| Derivatives Designated as Hedging Instruments |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  |  |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
|  |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | $ | (3 | ) |  | $ | (13 | ) |  | Cost of revenue |  | $ | (7 | ) |  | $ | (9 | ) |  | Cost of revenue |  | $ | 1 |  |  | $ | 1 |  |

[0001104659-15-032642:notes:55]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivative |  | Amount of Gain or(Loss) Recognized inIncome on Derivative |
|  |  |  |  | For the Three Months | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 1 |  | $ | (4 | ) |
| Total return swap |  | Operating expenses |  | $ | 2 |  | $ | 2 |  |

[0001104659-15-032642:notes:56]
[same as prior period, unchanged from 0001104659-15-005719:notes:55]

[0001104659-15-032642:notes:57]
| (a) | The amount of gain or (loss) recognized in income represents $0 related to the ineffective portion of the hedging relationships and $1 million related to the amount excluded from the assessment of hedge effectiveness for the three and nine months ended April 3, 2015, respectively. |

[0001104659-15-032642:notes:58]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statement of Comprehensive Income and the Condensed Consolidated Statement of Operations for the three and nine months ended March 28, 2014:

[0001104659-15-032642:notes:59]
[same as prior period, unchanged from 0001104659-15-005719:notes:58]

[0001104659-15-032642:notes:60]
| Derivatives Designated as Hedging Instruments |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
|  |  | For the Three Months |  | For the Nine Months |  |  |  | For the Three Months |  | For the Nine Months |  |  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | $ | 1 |  |  | $ | — |  |  | Cost of revenue |  | $ | — |  |  | $ | — |  |  | Cost of revenue |  | $ | — |  |  | $ | — |  |

[0001104659-15-032642:notes:61]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
|  |  |  |  | For the Three Months | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 1 |  | $ | (4 | ) |

[0001104659-15-032642:notes:62]
| (a) | The amount of gain or (loss) recognized in income represents $0 related to the ineffective portion of the hedging relationship and $0 related to the amount excluded from the assessment of hedge effectiveness for the three and nine months ended March 28, 2014. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-15-032642:notes:63]
[same as prior period, unchanged from 0001104659-15-005719:notes:62]

[0001104659-15-032642:notes:64]
The Company recorded approximately $33 million and $106 million of stock-based compensation expense during the three and nine months ended April 3, 2015, respectively. The Company recorded approximately $30 million and $87 million of stock-based compensation expense during the three and nine months ended March 28, 2014, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001104659-15-032642:notes:65]
[same as prior period, unchanged from 0001104659-15-005719:notes:64]

[0001104659-15-032642:notes:66]
[same as prior period, unchanged from 0001104659-15-005719:notes:65]

[0001104659-15-032642:notes:67]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (In millions, except per share data) |  | April 3, 2015 |  | March 28, 2014 |  | April 3, 2015 |  | March 28, 2014 |
| Numerator: |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Seagate Technology plc |  | $ | 291 |  |  | $ | 395 |  |  | $ | 1,605 |  |  | $ | 1,250 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share attributable to Seagate Technology plc |  | 323 |  |  | 327 |  |  | 326 |  |  | 340 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | 7 |  |  | 11 |  |  | 8 |  |  | 11 |  |
| Total shares for purpose of calculating diluted net income per share attributable to Seagate Technology plc |  | 330 |  |  | 338 |  |  | 334 |  |  | 351 |  |
| Net income per share attributable to Seagate Technology plc shareholders: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.90 |  |  | $ | 1.21 |  |  | $ | 4.92 |  |  | $ | 3.68 |  |
| Diluted |  | $ | 0.88 |  |  | $ | 1.17 |  |  | $ | 4.81 |  |  | $ | 3.56 |  |

[0001104659-15-032642:notes:68]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share attributable to Seagate Technology plc were immaterial for the three and nine months ended April 3, 2015 and March 28, 2014.


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001104659-15-032642:notes:69]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 705 |  |  | $ | 1,481 |  |  | $ | — |  |  | $ | 2,186 |  |
| Short-term investments | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Restricted cash and investments | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total assets | $ | 705 |  |  | $ | 1,491 |  |  | $ | — |  |  | $ | 2,196 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued expenses | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |
| Total liabilities | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |

[0001104659-15-032642:notes:70]
[same as prior period, unchanged from 0001104659-15-005719:notes:69]


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-15-032642:notes:71]
[same as prior period, unchanged from 0001104659-15-005719:notes:70]

[0001104659-15-032642:notes:72]
[same as prior period, unchanged from 0001104659-15-005719:notes:71]

[0001104659-15-032642:notes:73]
[same as prior period, unchanged from 0001104659-15-005719:notes:72]

[0001104659-15-032642:notes:74]
[same as prior period, unchanged from 0001104659-15-005719:notes:73]

[0001104659-15-032642:notes:75]
[same as prior period, unchanged from 0001104659-15-005719:notes:74]

[0001104659-15-032642:notes:76]
[same as prior period, unchanged from 0001104659-15-005719:notes:75]

[0001104659-15-032642:notes:77]
[same as prior period, unchanged from 0001104659-15-005719:notes:76]

[0001104659-15-032642:notes:78]
[same as prior period, unchanged from 0001104659-15-005719:notes:77]

[0001104659-15-032642:notes:79]
[same as prior period, unchanged from 0001104659-15-005719:notes:78]

[0001104659-15-032642:notes:80]
[same as prior period, unchanged from 0001104659-15-005719:notes:79]

[0001104659-15-032642:notes:81]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of April 3, 2015:

[0001104659-15-032642:notes:82]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 705 |  |  | $ | — |  |  | $ | — |  |  | $ | 705 |  |
| Certificates of deposit | — |  |  | 1,481 |  |  | — |  |  | 1,481 |  |
| Corporate bonds | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total cash equivalents and short-term investments | 705 |  |  | 1,487 |  |  | — |  |  | 2,192 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total assets | $ | 705 |  |  | $ | 1,491 |  |  | $ | — |  |  | $ | 2,196 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |
| Total liabilities | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |

[0001104659-15-032642:notes:83]
[same as prior period, unchanged from 0001104659-15-005719:notes:82]

[0001104659-15-032642:notes:84]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 793 |  |  | $ | — |  |  | $ | — |  |  | $ | 793 |  |
| Commercial paper | — |  |  | 1,261 |  |  | — |  |  | 1,261 |  |
| Certificates of deposit | — |  |  | 269 |  |  | — |  |  | 269 |  |
| Corporate bonds | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total cash equivalents and short-term investments | 793 |  |  | 1,536 |  |  | — |  |  | 2,329 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Derivative assets | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Total assets | $ | 793 |  |  | $ | 1,545 |  |  | $ | — |  |  | $ | 2,338 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001104659-15-032642:notes:85]
[same as prior period, unchanged from 0001104659-15-005719:notes:84]

[0001104659-15-032642:notes:86]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds and U.S. Treasuries. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair values of all of its cash equivalents and short-term investments. For the cash equivalents and short-term investments in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry standard data providers or other third party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of April 3, 2015, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts and the TRS. The Company recognizes derivative financial instruments in its condensed consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001104659-15-032642:notes:87]
The Company enters into certain strategic investments for the achievement of business and strategic objectives. Strategic investments in equity securities where the Company does not have the ability to exercise significant influence over the investees, are included in Other assets, net in the Condensed Consolidated Balance Sheets, are recorded at cost and are periodically analyzed to determine whether or not there are indicators of impairment. The carrying value of the Company’s strategic investments at April 3, 2015 and June 27, 2014 totaled $105 million and $46 million, respectively, and consisted primarily of privately held equity securities without a readily determinable fair value.

[0001104659-15-032642:notes:88]
[same as prior period, unchanged from 0001104659-15-005719:notes:87]

[0001104659-15-032642:notes:89]
[same as prior period, unchanged from 0001104659-15-005719:notes:88]

[0001104659-15-032642:notes:90]
|  |  | April 3, 2015 |  | June 27, 2014 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 6.8% Senior Notes due October 2016 |  | $ | — |  |  | $ | — |  |  | $ | 335 |  |  | $ | 374 |  |
| 3.75% Senior Notes due November 2018 |  | 800 |  |  | 832 |  |  | 800 |  |  | 820 |  |
| 6.875% Senior Notes due May 2020 |  | 474 |  |  | 492 |  |  | 534 |  |  | 578 |  |
| 7.00% Senior Notes due November 2021 |  | 159 |  |  | 172 |  |  | 251 |  |  | 284 |  |
| 4.75% Senior Notes due June 2023 |  | 1,000 |  |  | 1,052 |  |  | 1,000 |  |  | 1,009 |  |
| 4.75% Senior Notes due January 2025 |  | 1,000 |  |  | 1,040 |  |  | 1,000 |  |  | 995 |  |
| 5.75% Senior Notes due December 2034 |  | 498 |  |  | 542 |  |  | — |  |  | — |  |
| Long-term debt |  | $ | 3,931 |  |  | $ | 4,130 |  |  | $ | 3,920 |  |  | $ | 4,060 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-15-032642:notes:91]
[same as prior period, unchanged from 0001104659-15-005719:notes:90]

[0001104659-15-032642:notes:92]
[same as prior period, unchanged from 0001104659-15-005719:notes:91]

[0001104659-15-032642:notes:93]
The changes in the carrying amount of goodwill for the nine months ended April 3, 2015, are as follows:

[0001104659-15-032642:notes:94]
| (Dollars in millions) | Amount |
| Balance at June 27, 2014 | $ | 537 |  |
| Goodwill acquired | 337 |  |
| Foreign currency translation effect | (3 | ) |
| Balance at April 3, 2015 | $ | 871 |  |

[0001104659-15-032642:notes:95]
[same as prior period, unchanged from 0001104659-15-005719:notes:94]

[0001104659-15-032642:notes:96]
Other intangible assets consist primarily of existing technology, customer relationships, in-process research and development and trade names acquired in business combinations. With the exception of in-process research and development, acquired intangibles are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization is charged to Operating expenses in the Condensed Consolidated Statements of Operations. In-process research and development has been determined to have an indefinite useful life and is not amortized, but instead tested for impairment annually or more frequently if events or changes in circumstance indicate that the asset might be impaired. If the carrying amount of in-process research and development exceeds its fair value, an impairment loss is recognized in an amount equal to that excess. There were no impairment charges recognized for in-process research and development. Upon completion of the in-process research and development, the related assets will be accounted for as existing technology and will be amortized over their useful life.

[0001104659-15-032642:notes:97]
The carrying value of other intangible assets subject to amortization as of April 3, 2015, is set forth in the following table:

[0001104659-15-032642:notes:98]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 173 |  |  | $ | (55 | ) |  | $ | 118 |  |  | 3.6 years |
| Customer relationships |  | 486 |  |  | (259 | ) |  | 227 |  |  | 2.6 years |
| Trade names |  | 27 |  |  | (5 | ) |  | 22 |  |  | 3.4 years |
| Other intangible assets |  | 28 |  |  | (3 | ) |  | 25 |  |  | 4.4 years |
| Total amortizable other intangible assets |  | $ | 714 |  |  | $ | (322 | ) |  | $ | 392 |  |  | 3.1 years |

[0001104659-15-032642:notes:99]
The carrying value of in-process research and development not subject to amortization was $18 million on April 3, 2015.

[0001104659-15-032642:notes:100]
[same as prior period, unchanged from 0001104659-15-005719:notes:99]

[0001104659-15-032642:notes:101]
[same as prior period, unchanged from 0001104659-15-005719:notes:100]

[0001104659-15-032642:notes:102]
The carrying value of in-process research and development not subject to amortization was $39 million on June 27, 2014.

[0001104659-15-032642:notes:103]
For the three and nine months ended April 3, 2015, amortization expense of other intangible assets was $40 million and $112 million.  For the three and nine months ended March 28, 2014, amortization expense of other intangible assets was $26 million and $103 million.  As of April 3, 2015, expected amortization expense for other intangible assets for each of the next five fiscal years and thereafter is as follows:

[0001104659-15-032642:notes:104]
| (Dollars in millions) | Amount |
| Remainder of 2015 | $ | 40 |  |
| 2016 | 139 |  |
| 2017 | 120 |  |
| 2018 | 60 |  |
| 2019 | 22 |  |
| Thereafter | 11 |  |
|  | $ | 392 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-15-032642:notes:105]
[same as prior period, unchanged from 0001104659-15-005719:notes:104]

[0001104659-15-032642:notes:106]
The Company recorded an income tax provision of $13 million and $216 million in the three and nine months ended April 3, 2015, respectively. The income tax provision for the nine months ended April 3, 2015, included approximately $181 million of net tax expense due to the final audit assessment received from the Jiangsu Province State Tax Bureau of the People's Republic of China (China assessment) for calendar years 2007 through 2013.

[0001104659-15-032642:notes:107]
The Company's income tax provision recorded for the three and nine months ended April 3, 2015 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) tax expense associated with the China assessment recorded in the three months ending January 2, 2015, and (iii) a decrease in valuation allowance for certain U.S. deferred tax assets.

[0001104659-15-032642:notes:108]
During the nine months ended April 3, 2015, the Company’s unrecognized tax benefits excluding interest and penalties decreased by $39 million primarily due to (i) reductions associated with audit settlements of $45 million, (ii) increases in current year unrecognized tax benefits of $8 million, (iii) reductions associated with the expiration of certain statutes of limitations of $4 million, and (iv) net increases associated with changes in prior years' positions of $2 million.

[0001104659-15-032642:notes:109]
The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $76 million at April 3, 2015, subject to certain future valuation allowance reversals. During the 12 months beginning April 4, 2015, the Company expects that its unrecognized tax benefits could be reduced by approximately $3 million as a result of the expiration of certain statutes of limitation.

[0001104659-15-032642:notes:110]
The Company is subject to taxation in many jurisdictions globally and is required to file U.S. federal, U.S. state and non-U.S. income tax returns. In June 2014, the Company received the Revenue Agent’s Report and Notices of Proposed Adjustments for its U.S. federal income tax returns for fiscal years 2008, 2009 and 2010. The Company is currently contesting certain of these proposed adjustments through the IRS Appeals Office. The Company believes that the resolution of these disputed issues will not have a material impact on its financial statements. As discussed above, on December 31, 2014, the Company received the final audit assessment from the Jiangsu Province State Tax Bureau of the People’s Republic of China. The assessment was related to tax and interest associated with changes to the Company’s tax filings for calendar years 2007 through 2013.

[0001104659-15-032642:notes:111]
The Company recorded an income tax benefit and an income tax provision of $5 million and $22 million in the three and nine months ended March 28, 2014, respectively. The income tax benefit for the three months ended March 28, 2014 included $14 million of net discrete tax benefits related to releases of tax reserves due to audit settlements. The income tax provision recorded for the nine months ended March 28, 2014 included $7 million of net discrete tax benefits for the reversal of a portion of the U.S. valuation allowance recorded in prior periods and a net decrease in tax reserves related to audit settlements offset by tax reserves on non-U.S. tax positions taken in prior fiscal years.

[0001104659-15-032642:notes:112]
The Company’s income tax provision recorded for the three and nine months ended March 28, 2014 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001104659-15-032642:notes:113]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 2,190 |  |  | $ | 2,190 |  |
| Due in 1 to 5 years |  | 6 |  |  | 6 |  |
| Thereafter |  | — |  |  | — |  |
| Total |  | $ | 2,196 |  |  | $ | 2,196 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001104659-15-032642:notes:114]
Legal, Environmental and Other Contingencies

[0001104659-15-032642:notes:115]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001104659-15-032642:notes:116]
Intellectual Property Litigation

[0001104659-15-032642:notes:117]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al.—On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent Nos. 4,916,635 (the “'635 patent”) and U.S. Patent No. 5,638,267 (the “'267 patent”), misappropriation of trade secrets, breach of contract, and other claims. In the complaint, the plaintiffs requested injunctive relief, $800 million in compensatory damages and unspecified punitive damages, including for willful infringement. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe US Patent No. 6,314,473 (the “'473 patent”). The district court ruled in 2010 that the '267 patent was out of the case.

[0001104659-15-032642:notes:118]
On August 16, 2011, the district court granted in part and denied in part the Company's motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court's summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court's summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent. On July 11, 2014, the district court granted the Company’s summary judgment motion regarding Convolve’s only remaining cause of action, which alleged infringement of the ‘473 patent. The court entered judgment in favor of the Company on July 14, 2014. Convolve filed a notice of appeal on August 13, 2014. The court of appeals has not yet set a date for oral argument. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-15-032642:notes:119]
Alexander Shukh v. Seagate Technology—On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. On March 31, 2014, the district court granted Seagate’s summary judgment motion and entered judgment in favor of Seagate. Mr. Shukh filed a notice of appeal on April 7, 2014. Oral argument at the court of appeals has been scheduled for June 4, 2015. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-15-032642:notes:120]
LEAP Co., Ltd. v. Seagate Singapore International Headquarters Pte. Ltd. and Nippon Seagate Inc.—On July 4, 2012, LEAP Co., Ltd. filed a lawsuit in the Tokyo District Court of Japan against Seagate Singapore International Headquarters Pte. Ltd., Nippon Seagate Inc. and Buffalo Inc. alleging wrongful termination of purchase agreements and other claims, and seeking approximately $38 million in damages. A date for the start of trial has not yet been scheduled. The Company believes the claims are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-15-032642:notes:121]
Realtek Semiconductor Corporation ITC Investigation re Certain Integrated Circuit Chips and Products Containing the Same-On September 19, 2012, Realtek Semiconductor Corporation filed a complaint with the International Trade Commission (“ITC”) seeking an investigation pursuant to Section 337 of the Tariff Act of 1930, as amended (“Section 337”). The complaint names LSI Corporation and Seagate Technology as respondents and alleges infringement of U.S. patents relating to integrated circuit chips that include bond pad structures. Realtek seeks an order to exclude entry of infringing integrated circuit chips and products containing the infringing integrated circuit chips into the U.S. and a cease and desist order. The ITC initiated an investigation on October 18, 2012. On March 21, 2014, the Administrative Law Judge (“ALJ”) issued an Initial Determination in favor of Seagate and LSI. On July 21, 2014, the Commission gave notice that it had determined to affirm in part, reverse in part and vacate in part the ALJ’s Initial Determination; the Commission found that no violation of Section 337 by Seagate or LSI has occurred based on findings that certain of the patent claims at issue were invalid, and that Realtek failed to show the existence of an industry in the U.S. that exploits the patent. Realtek filed a notice of appeal on September 18, 2014. By agreement of the parties, Realtek’s appeal was dismissed on October 17, 2014. In view of the Commission’s July 21, 2014 decision and the October 17, 2014 dismissal of Realtek’s appeal, the Company believes that this matter will not result in any loss or other adverse result.

[0001104659-15-032642:notes:122]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995, “Cryptographic Device,” and U.S. Patent No. 7,900,057, “Cryptographic Serial ATA Apparatus and Method.” The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys' fees, and other relief. The trial is scheduled to begin July 11, 2016. On April 27, 2015, the district court ordered a stay of the case until October 15, 2015, in view of proceedings regarding the ‘995 and ‘057 Patents before the Patent Trial and Appeal Board of the U.S. Patent and Trademark Office. The Company believes the claims are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-15-032642:notes:123]
Seagate Technology LLC v. Western Digital Corp.  On October 8, 2014, the Minnesota Supreme Court ruled that the arbitration award in favor of the Company in its case against Western Digital for the misappropriation of the Company’s trade secrets should be confirmed. In the arbitration award, issued on January 23, 2012, the arbitrator determined that Western Digital and its former employee had misappropriated the Company’s trade secrets. The arbitrator awarded the Company $525 million in compensatory damages and, after adding interest, issued a final award of $630 million. Interest on the final award has been accruing at 10%. On October 14, 2014, the Company received a partial payment from Western Digital in the amount of $773 million. The amount of the final award, less litigation and other related costs, has been recorded by the Company in Gain on arbitration award, net, and the remaining amount received has been recorded in Other, net.

[0001104659-15-032642:notes:124]
Environmental Matters

[0001104659-15-032642:notes:125]
The Company's operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company's operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001104659-15-032642:notes:126]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001104659-15-032642:notes:127]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001104659-15-032642:notes:128]
While the Company's ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001104659-15-032642:notes:129]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.

[0001104659-15-032642:notes:130]
Other Matters

[0001104659-15-032642:notes:131]
The Company is involved in a number of other judicial and administrative proceedings incidental to its business, and the Company may be involved in various legal proceedings arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001104659-15-032642:notes:132]
May 2014, the FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers. The ASU outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The ASU, as currently proposed, will be effective for the Company's first quarter of fiscal year 2019. The Company is in the process of assessing the impact, if any, of ASU 2014-09 on its consolidated financial statements.

[0001104659-15-032642:notes:133]
In April 2015, the FASB issued ASU 2015-03 (ASC Subtopic 835-30), Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability. The amendments in this ASU are effective for fiscal years, and interim periods within those years, beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued. The adoption of this new guidance will not have a material impact on the Company’s consolidated financial statements and disclosures.

[0001104659-15-032642:notes:134]
8


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001104659-15-032642:notes:135]
[same as prior period, unchanged from 0001104659-15-005719:notes:133]

[0001104659-15-032642:notes:136]
[same as prior period, unchanged from 0001104659-15-005719:notes:134]

[0001104659-15-032642:notes:137]
[same as prior period, unchanged from 0001104659-15-005719:notes:135]

[0001104659-15-032642:notes:138]
[same as prior period, unchanged from 0001104659-15-005719:notes:136]

[0001104659-15-032642:notes:139]
[same as prior period, unchanged from 0001104659-15-005719:notes:137]

[0001104659-15-032642:notes:140]
[same as prior period, unchanged from 0001104659-15-005719:notes:138]

[0001104659-15-032642:notes:141]
The results of operations for the three and nine months ended April 3, 2015, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending July 3, 2015. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three and nine months ended April 3, 2015 consisted of 13 weeks and 40 weeks, respectively. The three and nine months ended March 28, 2014 consisted of 13 weeks and 39 weeks, respectively.  Fiscal year 2015 will be comprised of 53 weeks and will end on July 3, 2015. The fiscal quarters ended April 3, 2015, January 2, 2015, and March 28, 2014, are also referred to herein as the “March 2015 quarter”, the “December 2014 quarter”, and the “March 2014 quarter”, respectively.

[0001104659-15-032642:notes:142]
[same as prior period, unchanged from 0001104659-15-005719:notes:140]

[0001104659-15-032642:notes:143]
[same as prior period, unchanged from 0001104659-15-005719:notes:141]

[0001104659-15-032642:notes:144]
Recently Issued Accounting Pronouncements

[0001104659-15-032642:notes:145]
In May 2014, the FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers. The ASU outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The ASU, as currently proposed, will be effective for the Company's first quarter of fiscal year 2019. The Company is in the process of assessing the impact, if any, of ASU 2014-09 on its consolidated financial statements.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001104659-15-032642:notes:146]
[same as prior period, unchanged from 0001104659-15-005719:notes:143]

[0001104659-15-032642:notes:147]
[same as prior period, unchanged from 0001104659-15-005719:notes:144]

[0001104659-15-032642:notes:148]
[same as prior period, unchanged from 0001104659-15-005719:notes:145]

[0001104659-15-032642:notes:149]
[same as prior period, unchanged from 0001104659-15-005719:notes:146]

[0001104659-15-032642:notes:150]
[same as prior period, unchanged from 0001104659-15-005719:notes:147]

[0001104659-15-032642:notes:151]
[same as prior period, unchanged from 0001104659-15-005719:notes:148]

[0001104659-15-032642:notes:152]
[same as prior period, unchanged from 0001104659-15-005719:notes:149]

[0001104659-15-032642:notes:153]
[same as prior period, unchanged from 0001104659-15-005719:notes:150]

[0001104659-15-032642:notes:154]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the three and nine months ended April 3, 2015 and March 28, 2014 were as follows:

[0001104659-15-032642:notes:155]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 3, 2015 |  | March 28, 2014 |  | April 3, 2015 |  | March 28, 2014 |
| Balance, beginning of period |  | $ | 282 |  |  | $ | 300 |  |  | $ | 273 |  |  | $ | 320 |  |
| Warranties issued |  | 36 |  |  | 43 |  |  | 116 |  |  | 139 |  |
| Repairs and replacements |  | (45 | ) |  | (55 | ) |  | (145 | ) |  | (174 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | — |  |  | (2 | ) |  | 21 |  |  | 1 |  |
| Warranty liability assumed from business acquisitions |  | — |  |  | — |  |  | 8 |  |  | — |  |
| Balance, end of period |  | $ | 273 |  |  | $ | 286 |  |  | $ | 273 |  |  | $ | 286 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001104659-15-032642:notes:156]
| (Dollars in millions) |  | April 3, 2015 |  | June 27, 2014 |
| Property, equipment and leasehold improvements |  | $ | 9,403 |  |  | $ | 8,979 |  |
| Accumulated depreciation and amortization |  | (7,221 | ) |  | (6,843 | ) |
|  |  | $ | 2,182 |  |  | $ | 2,136 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001104659-15-032642:notes:157]
| (Dollars in millions) |  | Unrealized Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Marketable Securities (a) |  | Unrealized Gains (Losses) on post-retirements |  | Foreign currency translation adjustments |  | Total |
| Balance at June 27, 2014 |  | $ | (1 | ) |  | $ | — |  |  | $ | (10 | ) |  | $ | 9 |  |  | $ | (2 | ) |
| Other comprehensive income (loss) before reclassifications |  | (12 | ) |  | — |  |  | — |  |  | (28 | ) |  | (40 | ) |
| Amounts reclassified from AOCI |  | 9 |  |  | — |  |  | — |  |  | — |  |  | 9 |  |
| Other comprehensive income (loss) |  | (3 | ) |  | — |  |  | — |  |  | (28 | ) |  | (31 | ) |
| Balance at April 3, 2015 |  | $ | (4 | ) |  | $ | — |  |  | $ | (10 | ) |  | $ | (19 | ) |  | $ | (33 | ) |
| Balance at June 28, 2013 |  | $ | — |  |  | $ | (3 | ) |  | $ | (10 | ) |  | $ | — |  |  | $ | (13 | ) |
| Other comprehensive income (loss) before reclassifications |  | — |  |  | 1 |  |  | 1 |  |  | 9 |  |  | 11 |  |
| Amounts reclassified from AOCI |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) |  | — |  |  | 1 |  |  | 1 |  |  | 9 |  |  | 11 |  |
| Balance at March 28, 2014 |  | $ | — |  |  | $ | (2 | ) |  | $ | (9 | ) |  | $ | 9 |  |  | $ | (2 | ) |

[0001104659-15-032642:notes:158]
[same as prior period, unchanged from 0001104659-15-005719:notes:155]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001104659-15-032642:notes:159]
| (Dollars in millions) |  | April 3, 2015 |  | June 27, 2014 |
| Raw materials and components |  | $ | 366 |  |  | $ | 324 |  |
| Work-in-process |  | 288 |  |  | 267 |  |
| Finished goods |  | 429 |  |  | 394 |  |
|  |  | $ | 1,083 |  |  | $ | 985 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-15-032642:notes:160]
[same as prior period, unchanged from 0001104659-15-005719:notes:157]

[0001104659-15-032642:notes:161]
[same as prior period, unchanged from 0001104659-15-005719:notes:158]

[0001104659-15-032642:notes:162]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 318,076,549 shares were outstanding as of April 3, 2015, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of April 3, 2015.

[0001104659-15-032642:notes:163]
[same as prior period, unchanged from 0001104659-15-005719:notes:160]

[0001104659-15-032642:notes:164]
[same as prior period, unchanged from 0001104659-15-005719:notes:161]

[0001104659-15-032642:notes:165]
[same as prior period, unchanged from 0001104659-15-005719:notes:162]

[0001104659-15-032642:notes:166]
[same as prior period, unchanged from 0001104659-15-005719:notes:163]

[0001104659-15-032642:notes:167]
[same as prior period, unchanged from 0001104659-15-005719:notes:164]

[0001104659-15-032642:notes:168]
[same as prior period, unchanged from 0001104659-15-005719:notes:165]

[0001104659-15-032642:notes:169]
As of April 3, 2015, $0.6 billion remained available for repurchase under the existing repurchase authorization limit.

[0001104659-15-032642:notes:170]
The following table sets forth information with respect to repurchases of the Company’s shares during the nine months ended April 3, 2015:


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001104659-15-032642:notes:171]
[same as prior period, unchanged from 0001104659-15-005719:notes:168]

[0001104659-15-032642:notes:172]
[same as prior period, unchanged from 0001104659-15-005719:notes:169]

[0001104659-15-032642:notes:173]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of April 3, 2015:

[0001104659-15-032642:notes:174]
As of April 3, 2015, the Company’s Restricted cash and investments consisted of $4 million in cash and investments held as collateral at banks for various performance obligations.

[0001104659-15-032642:notes:175]
As of April 3, 2015, the Company had no available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined that no available-for-sale securities were other-than-temporarily impaired as of April 3, 2015.

[0001104659-15-032642:notes:176]
The fair value and amortized cost of the Company’s investments classified as available-for-sale at April 3, 2015, by remaining contractual maturity were as follows:

[0001104659-15-032642:notes:177]
[same as prior period, unchanged from 0001104659-15-005719:notes:174]

[0001104659-15-032642:notes:178]
[same as prior period, unchanged from 0001104659-15-005719:notes:175]

[0001104659-15-032642:notes:179]
[same as prior period, unchanged from 0001104659-15-005719:notes:176]

[0001104659-15-032642:notes:180]
[same as prior period, unchanged from 0001104659-15-005719:notes:177]

[0001104659-15-032642:notes:181]
[same as prior period, unchanged from 0001104659-15-005719:notes:178]

[0001104659-15-032642:notes:182]
[same as prior period, unchanged from 0001104659-15-005719:notes:179]

[0001104659-15-032642:notes:183]
[same as prior period, unchanged from 0001104659-15-005719:notes:180]

[0001104659-15-032642:notes:184]
[same as prior period, unchanged from 0001104659-15-005719:notes:181]
