# STX MD&A — 0001104659-15-032642


## mdna

[0001104659-15-032642:mdna:1]
[same as prior period, unchanged from 0001104659-15-005719:mdna:1]

[0001104659-15-032642:mdna:2]
The following is a discussion of the financial condition and results of operations for our fiscal quarters ended April 3, 2015, January 2, 2015, and March 28, 2014, referred to herein as the “March 2015 quarter”, the “December 2014 quarter”, and the “March 2014 quarter”, respectively. Unless the context indicates otherwise, as used herein, the terms “we,” “us,” “Seagate,” the “Company” and “our” refer to Seagate Technology plc, an Irish public limited company, and its subsidiaries. References to “$” are to United States dollars.

[0001104659-15-032642:mdna:3]
You should read this discussion in conjunction with financial information and related notes included elsewhere in this report. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The March 2015, December 2014, and March 2014 quarters were all 13 weeks. The nine months ended March 2015 and March 2014 were 40 and 39 weeks, respectively. Except as noted, references to any fiscal year mean the twelve-month period ending on the Friday closest to June 30 of that year.

[0001104659-15-032642:mdna:4]
[same as prior period, unchanged from 0001104659-15-005719:mdna:4]

[0001104659-15-032642:mdna:5]
[same as prior period, unchanged from 0001104659-15-005719:mdna:5]

[0001104659-15-032642:mdna:6]
·                  Overview of the March 2015 quarter. Highlights of events in the March 2015 quarter that impacted our financial position.

[0001104659-15-032642:mdna:7]
·                  Results of Operations. An analysis of our financial results comparing the March 2015 quarter to the December 2014 quarter and the March 2014 quarter, and the nine-month period ended March 2015 to the nine-month period ended March 2014.

[0001104659-15-032642:mdna:8]
[same as prior period, unchanged from 0001104659-15-005719:mdna:8]

[0001104659-15-032642:mdna:9]
[same as prior period, unchanged from 0001104659-15-005719:mdna:9]

[0001104659-15-032642:mdna:10]
27

[0001104659-15-032642:mdna:11]
[same as prior period, unchanged from 0001104659-15-005719:mdna:10]

[0001104659-15-032642:mdna:12]
We are a leading provider of electronic data storage solutions. Our principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. In addition to HDDs, we produce a broad range of electronic data storage products including solid state hybrid drives (“SSHD”) and solid state drives (“SSD”).

[0001104659-15-032642:mdna:13]
[same as prior period, unchanged from 0001104659-15-005719:mdna:14]

[0001104659-15-032642:mdna:14]
[same as prior period, unchanged from 0001104659-15-005719:mdna:15]

[0001104659-15-032642:mdna:15]
[same as prior period, unchanged from 0001104659-15-005719:mdna:16]

[0001104659-15-032642:mdna:16]
Overview of the March 2015 Quarter

[0001104659-15-032642:mdna:17]
During the March 2015 quarter, we shipped 50 million drive units totaling 55 exabytes of storage capacity, generating revenue of $3.3 billion and gross margin of 29%. Our operating cash flow was $374 million. We paid $706 million for share repurchases, $176 million for dividend payments to shareholders, and $225 million payment related to the final audit assessment received from the Jiangsu Province State Tax Bureau of the People’s Republic of China for tax and interest associated with changes to our tax filings for the calendar years 2007 through 2013.

[0001104659-15-032642:mdna:18]
[same as prior period, unchanged from 0001104659-15-005719:mdna:19]

[0001104659-15-032642:mdna:19]
[same as prior period, unchanged from 0001104659-15-005719:mdna:20]

[0001104659-15-032642:mdna:20]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | April 3, 2015 |  | January 2, 2015 |  | March 28, 2014 |  | April 3, 2015 |  | March 28, 2014 |  |
| Revenue |  | $ | 3,330 |  | $ | 3,696 |  | $ | 3,406 |  | $ | 10,811 |  | $ | 10,423 |  |
| Cost of revenue |  | 2,375 |  | 2,669 |  | 2,447 |  | 7,778 |  | 7,502 |  |
| Gross margin |  | 955 |  | 1,027 |  | 959 |  | 3,033 |  | 2,921 |  |
| Product development |  | 346 |  | 341 |  | 297 |  | 1,029 |  | 903 |  |
| Marketing and administrative |  | 219 |  | 218 |  | 190 |  | 654 |  | 561 |  |
| Amortization of intangibles |  | 33 |  | 32 |  | 26 |  | 95 |  | 71 |  |
| Restructuring and other, net |  | 14 |  | 3 |  | 2 |  | 24 |  | 20 |  |
| Gain on arbitration award, net |  | — |  | (620 | ) | — |  | (620 | ) | — |  |
| Income from operations |  | 343 |  | 1,053 |  | 444 |  | 1,851 |  | 1,366 |  |
| Other income (expense), net |  | (39 | ) | 73 |  | (54 | ) | (30 | ) | (94 | ) |
| Income before income taxes |  | 304 |  | 1,126 |  | 390 |  | 1,821 |  | 1,272 |  |
| Provision for income taxes |  | 13 |  | 193 |  | (5 | ) | 216 |  | 22 |  |
| Net income |  | $ | 291 |  | $ | 933 |  | $ | 395 |  | $ | 1,605 |  | $ | 1,250 |  |

[0001104659-15-032642:mdna:21]
28

[0001104659-15-032642:mdna:22]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |
|  |  | April 3, 2015 |  | January 2, 2015 |  | March 28, 2014 |  | April 3, 2015 |  | March 28, 2014 |  |
| Revenue |  | 100 | % | 100 | % | 100 | % | 100 | % | 100 | % |
| Cost of revenue |  | 71 |  | 72 |  | 72 |  | 72 |  | 72 |  |
| Gross margin |  | 29 |  | 28 |  | 28 |  | 28 |  | 28 |  |
| Product development |  | 10 |  | 9 |  | 9 |  | 10 |  | 9 |  |
| Marketing and administrative |  | 7 |  | 6 |  | 5 |  | 6 |  | 5 |  |
| Amortization of intangibles |  | 1 |  | 1 |  | 1 |  | 1 |  | 1 |  |
| Restructuring and other, net |  | — |  | — |  | — |  | — |  | — |  |
| Gain on arbitration award, net |  | — |  | (16 | ) | — |  | (6 | ) | — |  |
| Income from operations |  | 11 |  | 28 |  | 13 |  | 17 |  | 13 |  |
| Other income (expense), net |  | (1 | ) | 2 |  | (1 | ) | — |  | (1 | ) |
| Income before income taxes |  | 10 |  | 30 |  | 12 |  | 17 |  | 12 |  |
| Provision for income taxes |  | — |  | 5 |  | — |  | 2 |  | — |  |
| Net income |  | 10 | % | 25 | % | 12 | % | 15 | % | 12 | % |

[0001104659-15-032642:mdna:23]
[same as prior period, unchanged from 0001104659-15-005719:mdna:24]

[0001104659-15-032642:mdna:24]
[same as prior period, unchanged from 0001104659-15-005719:mdna:25]

[0001104659-15-032642:mdna:25]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |
| (In millions, except percentages, exabytes and ASPs) |  | April 3, 2015 |  | January 2, 2015 |  | March 28, 2014 |  | April 3, 2015 |  | March 28, 2014 |  |
| Unit Shipments: |  |  |  |  |  |  |  |  |  |  |  |
| Enterprise |  | 9 |  | 9 |  | 8 |  | 27 |  | 24 |  |
| Client Compute |  | 31 |  | 36 |  | 36 |  | 106 |  | 108 |  |
| Client Non-Compute |  | 10 |  | 12 |  | 11 |  | 34 |  | 36 |  |
| Total Units Shipped |  | 50 |  | 57 |  | 55 |  | 167 |  | 168 |  |
| ASPs (per unit) |  | $ | 62 |  | $ | 61 |  | $ | 61 |  | $ | 61 |  | $ | 61 |  |
| Exabytes Shipped |  | 55 |  | 61 |  | 51 |  | 176 |  | 152 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 70 | % | 69 | % | 66 | % | 70 | % | 67 | % |
| Distributors |  | 18 | % | 18 | % | 20 | % | 18 | % | 21 | % |
| Retailers |  | 12 | % | 13 | % | 14 | % | 12 | % | 12 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | 29 | % | 26 | % | 26 | % | 27 | % | 28 | % |
| EMEA |  | 16 | % | 18 | % | 20 | % | 17 | % | 19 | % |
| Asia Pacific |  | 55 | % | 56 | % | 54 | % | 56 | % | 53 | % |

[0001104659-15-032642:mdna:26]
Revenue in the March 2015 quarter decreased by $366 million and $76 million as compared to the December 2014 quarter and March 2014 quarter, respectively, primarily due to a decrease in shipments and moderate price erosion, partially offset by favorable product mix.

[0001104659-15-032642:mdna:27]
Revenue for the nine months ended March 2015 increased by $388 million, or 4%, as compared to the nine months ended March 2014 mostly due to revenue contributed from our acquisitions of Xyratex and LSI’s Flash Business and a favorable product mix, partially offset by moderate price erosion.

[0001104659-15-032642:mdna:28]
We maintain various sales programs such as point-of-sale rebates, sales price adjustments and price protection, aimed at increasing customer demand. Sales programs were approximately 10.8%, 9.4%, and 7.8% of gross drive revenue for the March 2015 quarter, December 2014 quarter and March 2014 quarter, respectively. Adjustments to revenues due to under or over accruals for sales programs related to revenues reported in prior quarterly periods have averaged 0.3% of quarterly gross revenue and were 0.7% of quarterly gross revenue in the March 2015 quarter.

[0001104659-15-032642:mdna:29]
29

[0001104659-15-032642:mdna:30]
[same as prior period, unchanged from 0001104659-15-005719:mdna:32]

[0001104659-15-032642:mdna:31]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | April 3, 2015 |  | January 2, 2015 |  | March 28, 2014 |  | April 3, 2015 |  | March 28, 2014 |  |
| Cost of revenue |  | $ | 2,375 |  | $ | 2,669 |  | $ | 2,447 |  | $ | 7,778 |  | $ | 7,502 |  |
| Gross margin |  | 955 |  | 1,027 |  | 959 |  | 3,033 |  | 2,921 |  |
| Gross margin percentage |  | 29 | % | 28 | % | 28 | % | 28 | % | 28 | % |

[0001104659-15-032642:mdna:32]
Gross margin as a percentage of revenue for the March 2015 quarter increased compared to the December 2014 quarter and March 2014 quarter due to favorable product mix, partially offset by moderate price erosion.

[0001104659-15-032642:mdna:33]
Gross margin as a percentage of revenue for the nine months ended March 2015 compared to the nine months ended March 2014, was relatively flat. These margins reflect an environment where price erosion has been modest and was offset by improved product mix and cost savings due to increases in operational efficiencies.

[0001104659-15-032642:mdna:34]
In the March 2015 quarter, total warranty cost was 1.1% of revenue and changes in estimates of prior warranty accruals of revenue were insignificant. Warranty cost related to new shipments was 1.1%, 1.1%, and 1.3% of revenue for the March 2015 quarter, December 2014 quarter and March 2014 quarter, respectively.

[0001104659-15-032642:mdna:35]
[same as prior period, unchanged from 0001104659-15-005719:mdna:36]

[0001104659-15-032642:mdna:36]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | April 3, 2015 |  | January 2, 2015 |  | March 28, 2014 |  | April 3, 2015 |  | March 28, 2014 |  |
| Product development |  | $ | 346 |  | $ | 341 |  | $ | 297 |  | $ | 1,029 |  | $ | 903 |  |
| Marketing and administrative |  | 219 |  | 218 |  | 190 |  | 654 |  | 561 |  |
| Amortization of intangibles |  | 33 |  | 32 |  | 26 |  | 95 |  | 71 |  |
| Restructuring and other, net |  | 14 |  | 3 |  | 2 |  | 24 |  | 20 |  |
| Gain on arbitration award, net |  | — |  | (620 | ) | — |  | (620 | ) | — |  |
| Operating expenses |  | $ | 612 |  | $ | (26 | ) | $ | 515 |  | $ | 1,182 |  | $ | 1,555 |  |

[0001104659-15-032642:mdna:37]
Product development expense.  Product development expense for the March 2015 quarter was relatively flat compared to the December 2014 quarter. Compared to the March 2014 quarter, product development expense increased by $49 million, or 17%, primarily due to an increase in headcount related costs of $27 million and other integration related costs attributed to the consolidation of Xyratex and LSI’s Flash Business.

[0001104659-15-032642:mdna:38]
Product development expense for the nine months ended March 2015 increased by $126 million, or 14%, as compared to the corresponding period in the prior year mostly due to an increase in headcount related costs of $71 million and other integration related costs attributed to the consolidation of Xyratex and LSI’s Flash Business as well as a 14-week September 2014 quarter.

[0001104659-15-032642:mdna:39]
Marketing and administrative expense. Marketing and administrative expense for the March 2015 quarter was flat compared to the December 2014 quarter. Compared to the March 2014 quarter, marketing and administrative expense increased by $29 million, or 15%, which was primarily due to an increase in headcount related expense attributed to the consolidation of Xyratex and LSI’s Flash Business.

[0001104659-15-032642:mdna:40]
Marketing and administrative expense for the nine months ended March 2015 increased by $93 million, or 17%, as compared to the corresponding period in the prior year mostly due to an increase in headcount related expenses attributed to the consolidation of Xyratex and LSI’s Flash Business as well as a 14-week September 2014 quarter.

[0001104659-15-032642:mdna:41]
Amortization of intangibles. Amortization of intangibles for the March 2015 quarter was relatively flat when compared to the December 2014 quarter. Compared to the March 2014 quarter, amortization of intangibles increased by $7 million, or 27%, as a result of the acquisitions of LSI’s Flash Business and Xyratex.

[0001104659-15-032642:mdna:42]
Amortization of intangibles for the nine months ended March 2015 increased as compared to the corresponding period in the prior year by $24 million, or 34%, as a result of the acquisitions of LSI’s Flash Business and Xyratex.

[0001104659-15-032642:mdna:43]
Restructuring and other, net. Restructuring and other, net for the March 2015 quarter increased by $11 million and $12 million, as compared to the December 2014 quarter and March 2014 quarter, respectively, due to a restructuring charge recorded during the March 2015 quarter to reduce work force as a result of our ongoing focus on cost efficiencies in all areas of our business.

[0001104659-15-032642:mdna:44]
[same as prior period, unchanged from 0001104659-15-005719:mdna:12]

[0001104659-15-032642:mdna:45]
Restructuring and other, net for the nine months ended March 2015 increased by $4 million, or 20%, as compared to the nine months ended March 2014 due to restructuring charges recorded during the March 2015 and September 2014 quarters to reduce work force as a result of our ongoing focus on cost efficiencies in all areas of our business.

[0001104659-15-032642:mdna:46]
Gain on arbitration award, net. Gain on arbitration award, net for the nine months ended March 2015 was related to the final award amount of $630 million, less litigation and other related costs of $10 million, in the Company’s case against Western Digital for the misappropriation of the Company’s trade secrets. Gain on arbitration award, net was recognized during the December 2014 quarter.

[0001104659-15-032642:mdna:47]
[same as prior period, unchanged from 0001104659-15-005719:mdna:47]

[0001104659-15-032642:mdna:48]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | April 3, 2015 |  | January 2, 2015 |  | March 28, 2014 |  | April 3, 2015 |  | March 28, 2014 |  |
| Other income (expense), net |  | $ | (39 | ) | $ | 73 |  | $ | (54 | ) | $ | (30 | ) | $ | (94 | ) |

[0001104659-15-032642:mdna:49]
Other income (expense), net decreased for the March 2015 quarter when compared to the December 2014 quarter by $112 million, which was due to the partial payment of $143 million for interest accrued on the final arbitration award amount in the Company’s case against Western Digital in the December 2014 quarter, partially offset by a $37 million decrease in losses from the early redemption and repurchase of debt. Compared to the March 2014 quarter, Other income (expense), net remained flat.

[0001104659-15-032642:mdna:50]
Other income (expense), net increased for the nine months ended March 2015 as compared to the corresponding period in the prior year primarily due to the partial payment of $143 million for interest accrued on the final arbitration award amount in our case against Western Digital in the December 2014 quarter, partially offset by a $44 million increase in losses from the early redemption and repurchase of debt and a gain of $32 million from the sale of one of our strategic investments in the nine months ended March 2014.

[0001104659-15-032642:mdna:51]
[same as prior period, unchanged from 0001104659-15-005719:mdna:51]

[0001104659-15-032642:mdna:52]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | April 3, 2015 |  | January 2, 2015 |  | March 28, 2014 |  | April 3, 2015 |  | March 28, 2014 |  |
| Provision for (benefit from) income taxes |  | $ | 13 |  | $ | 193 |  | $ | (5 | ) | $ | 216 |  | $ | 22 |  |

[0001104659-15-032642:mdna:53]
Our income tax provision recorded for the first nine months of fiscal year 2015 included approximately $181 million of net tax expense due to the final audit assessment received from the Jiangsu Province State Tax Bureau of the People’s Republic of China (China assessment) for calendar years 2007 through 2013.

[0001104659-15-032642:mdna:54]
Our income tax provision recorded for the March 2015 quarter and for the first nine months of fiscal year 2015 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) tax expense associated with the China assessment recorded during the December 2014 quarter, and (iii) a decrease in valuation allowance for certain U.S. deferred tax assets. The acquisition of LSI’s Flash Business is not expected to have a material impact on our effective tax rate in fiscal year 2015.

[0001104659-15-032642:mdna:55]
During the nine months ended April 3, 2015, our unrecognized tax benefits excluding interest and penalties decreased by $39 million primarily due to (i) reductions associated with audit settlements of $45 million, (ii) increases in current year unrecognized tax benefits of $8 million, iii) reductions associated with the expiration of certain statutes of limitations of $4 million, and (iv) net increases associated with changes in prior years’ positions of $2 million.

[0001104659-15-032642:mdna:56]
The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $76 million at April 3, 2015, subject to certain future valuation allowance reversals. During the 12 months beginning April 4, 2015, we expect that our unrecognized tax benefits could be reduced by approximately $3 million as a result of the expiration of certain statutes of limitation.

[0001104659-15-032642:mdna:57]
We are subject to taxation in many jurisdictions globally and are required to file U.S. federal, U.S. state, and non-U.S income tax returns. In June 2014, we received the Revenue Agent’s Report and Notices of Proposed Adjustments for our U.S. federal income tax returns for fiscal years 2008, 2009 and 2010. We are currently contesting certain of these proposed adjustments through the IRS Appeals Office. We believe that the resolution of these disputed issues will not have a material

[0001104659-15-032642:mdna:58]
[same as prior period, unchanged from 0001104659-15-005719:mdna:22]

[0001104659-15-032642:mdna:59]
impact on our financial statements. As discussed above, on December 31, 2014, we received the final audit assessment from the Jiangsu Province State Tax Bureau of the People’s Republic of China. The assessment was related to tax and interest associated with changes to our tax filings for calendar years 2007 through 2013. Resolving the audit in connection with obtaining agreement from the China tax authorities on predictable, future tax expense provides stability to our business model. Additional, future tax expense required by the agreement is not expected to have a material impact on our financial statements.

[0001104659-15-032642:mdna:60]
Our income tax benefit recorded for the March 2014 quarter included $14 million of net discrete tax benefits related to releases of tax reserves due to audit settlements. Our income tax provision recorded for the first nine months of fiscal year 2014 included $7 million of net discrete tax benefits related to the reversal of a portion of the U.S. valuation allowance recorded in prior periods and a net decrease in tax reserves related to audit settlements offset by tax reserves for non-U.S. tax positions taken in prior years.

[0001104659-15-032642:mdna:61]
Our income tax benefit for the March 2014 quarter and for the first nine months of fiscal year 2014 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.

[0001104659-15-032642:mdna:62]
[same as prior period, unchanged from 0001104659-15-005719:mdna:62]

[0001104659-15-032642:mdna:63]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist of readily marketable securities with remaining maturities of more than 90 days at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We intend to maintain a highly liquid portfolio by investing in money market funds, time deposits, interest-bearing bank accounts, and would invest only in those marketable securities that we believe have active secondary or resale markets. We believe our cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, these restrictions have not impeded our ability to conduct our business, nor do we expect them to in the next 12 months. We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term investments and accordingly, we do not believe the fair value of our short-term investments has significantly changed from the values reported as of April 3, 2015.

[0001104659-15-032642:mdna:64]
[same as prior period, unchanged from 0001104659-15-005719:mdna:64]

[0001104659-15-032642:mdna:65]
| (Dollars in millions) |  | April 3, 2015 |  | June 27, 2014 |  | Change |  |
| Cash and cash equivalents |  | $ | 2,604 |  | $ | 2,634 |  | $ | (30 | ) |
| Short-term investments |  | 6 |  | 20 |  | (14 | ) |
| Restricted cash and investments |  | 4 |  | 4 |  | — |  |
| Total |  | $ | 2,614 |  | $ | 2,658 |  | $ | (44 | ) |

[0001104659-15-032642:mdna:66]
Our cash and cash equivalents, short-term investments and restricted cash and investments decreased from June 27, 2014 as a result of net cash outflow for repurchase of our ordinary shares, early redemption and repayments of long-term debt, dividends paid to our shareholders, capital expenditures and the acquisition of LSI’s Flash Business. These cash outflows were partially offset by our cash provided by operating activities, which included an arbitration award partial payment of $773 million from Western Digital, and the proceeds from the issuance of $500 million of our 5.75% Senior Notes due 2034, as discussed below.

[0001104659-15-032642:mdna:67]
[same as prior period, unchanged from 0001104659-15-005719:mdna:67]

[0001104659-15-032642:mdna:68]
Cash provided by operating activities for the nine months ended April 3, 2015 of $2.4 billion includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation.

[0001104659-15-032642:mdna:69]
Net income includes a partial payment of $773 million for the arbitration award and related accrued interest received from Western Digital and a $225 million payment related to the final audit assessment received from the Jiangsu Province State Tax Bureau of the People’s Republic of China for tax and interest associated with changes to our tax filings for the calendar years 2007 through 2013.

[0001104659-15-032642:mdna:70]
Cash Used in Investing Activities

[0001104659-15-032642:mdna:71]
Cash used for investing activities for the nine months ended April 3, 2015 was $1,068 million which includes $546 million used for acquired property, equipment and leasehold improvements and $450 million used for the acquisition of LSI’s Flash Business.

[0001104659-15-032642:mdna:72]
[same as prior period, unchanged from 0001104659-15-005719:mdna:30]

[0001104659-15-032642:mdna:73]
[same as prior period, unchanged from 0001104659-15-005719:mdna:72]

[0001104659-15-032642:mdna:74]
Net cash used in financing activities of $1,359 million for the nine months ended April 3, 2015 was attributable to the following activities:

[0001104659-15-032642:mdna:75]
·                  $907 million paid to repurchase ordinary shares;

[0001104659-15-032642:mdna:76]
·                  $536 million of redemption and repayments of long-term debt;

[0001104659-15-032642:mdna:77]
·                  $493 million in dividend payments; partially offset by

[0001104659-15-032642:mdna:78]
·                  net proceeds of $498 million from issuance of our 5.75% Senior Notes due 2034.

[0001104659-15-032642:mdna:79]
[same as prior period, unchanged from 0001104659-15-005719:mdna:78]

[0001104659-15-032642:mdna:80]
Our primary sources of liquidity as of April 3, 2015 consisted of: (1) approximately $2.6 billion in cash, cash equivalents, and short-term investments, (2) cash we expect to generate from operations and (3) a $700 million senior revolving credit facility.

[0001104659-15-032642:mdna:81]
On January 15, 2015, the Company and Seagate HDD Cayman entered into the Third Amendment to the Credit Agreement (the “Amendment”) which increased the commitments available under the Revolving Credit Facility from $500 million to $700 million and also extended the maturity date on the Credit Agreement until January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Credit Agreement) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. As of May 1, 2015, no borrowings have been drawn or letters of credit utilized under the Revolving Credit Facility. The line of credit is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowings.

[0001104659-15-032642:mdna:82]
The credit agreement that governs our revolving credit facility, as amended, contains certain covenants that we must satisfy in order to remain in compliance with the credit agreement, as amended. The agreement also includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. As of April 3, 2015, we were in compliance with all of the covenants under our Revolving Credit Facility and debt agreements. Based on our current outlook, we expect to be in compliance with the covenants of our debt agreements over the next 12 months.

[0001104659-15-032642:mdna:83]
[same as prior period, unchanged from 0001104659-15-005719:mdna:83]

[0001104659-15-032642:mdna:84]
[same as prior period, unchanged from 0001104659-15-005719:mdna:84]

[0001104659-15-032642:mdna:85]
From time to time we may repurchase any of our outstanding notes in open market or privately negotiated purchases or otherwise, or may repurchase outstanding notes pursuant to the terms of the applicable indenture. On April 7, 2015, Seagate HDD Cayman announced the redemption of all of its 6.875% Senior Notes due 2020 with a remaining outstanding balance of $474 million. Seagate anticipates that the Notes will be redeemed on May 7, 2015 at a redemption price equal to $1,034.38 per $1,000 principal amount of the Notes redeemed plus accrued and unpaid interest from the interest payment date of May 1, 2015 to the redemption date of May 7, 2015.

[0001104659-15-032642:mdna:86]
The Company’s Board of Directors declared a quarterly cash dividend of $0.54 per share on April 17, 2015, which is payable on May 15, 2015 to shareholders of record at the close of business on May 1, 2015.

[0001104659-15-032642:mdna:87]
From time to time we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases.  As of April 3, 2015, $0.6 billion remained available for repurchase under our existing repurchase authorization limit.  All repurchases are effected as redemptions in accordance with the Company’s Articles of Association.

[0001104659-15-032642:mdna:88]
On April 22, 2015, the Board of Directors authorized the Company to repurchase up to an additional $2.5 billion of its outstanding ordinary shares.

[0001104659-15-032642:mdna:89]
[same as prior period, unchanged from 0001104659-15-005719:mdna:89]

[0001104659-15-032642:mdna:90]
[same as prior period, unchanged from 0001104659-15-005719:mdna:90]

[0001104659-15-032642:mdna:91]
[same as prior period, unchanged from 0001104659-15-005719:mdna:91]

[0001104659-15-032642:mdna:92]
33

[0001104659-15-032642:mdna:93]
[same as prior period, unchanged from 0001104659-15-005719:mdna:92]

[0001104659-15-032642:mdna:94]
[same as prior period, unchanged from 0001104659-15-005719:mdna:93]
