# STX MD&A — 0001193125-18-238271


## mdna

[0001193125-18-238271:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001193125-18-238271:mdna:2]
The following is a discussion of the Company’s financial condition, changes in financial condition and results of operations for the fiscal years
ended June 29, 2018, June 30, 2017 and July 1, 2016.

[0001193125-18-238271:mdna:3]
You should read this discussion in conjunction with “Item 6.
Selected Financial Data” and “Item 8. Financial Statements and Supplementary Data” included elsewhere in this Annual Report on Form 10-K. Except as noted, references to any fiscal year mean
the twelve-month period ending on the Friday closest to June 30 of that year. Accordingly, fiscal year 2018 comprised 52 weeks and ended on June 29, 2018. Fiscal year 2017 comprised 52 weeks and ended on June 30, 2017. Fiscal
year 2016 comprised 52 weeks and ended on July 1, 2016. Fiscal year 2019 will be comprised of 52 weeks and will end on June 28, 2019.

[0001193125-18-238271:mdna:4]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is provided in addition to the
accompanying consolidated financial statements and notes to assist readers in understanding our results of operations, financial condition and cash flows. Our MD&A is organized as follows:

[0001193125-18-238271:mdna:5]
|  | • |  | Our Company. Discussion of our business. |

[0001193125-18-238271:mdna:6]
|  | • |  | Business Overview. Discussion of industry trends and their impact on our business. |

[0001193125-18-238271:mdna:7]
|  | • |  | Fiscal Year 2018 Summary. Overview of financial and other highlights affecting us in fiscal year 2018. |

[0001193125-18-238271:mdna:8]
|  | • |  | Results of Operations. Analysis of our financial results comparing fiscal years 2018 to 2017 and comparing fiscal years 2017 to 2016. |

[0001193125-18-238271:mdna:9]
|  | • |  | Liquidity and Capital Resources. Analysis of changes in our balance sheets and cash flows, and discussion of our financial condition including the credit quality of our investment portfolio and potential sources of liquidity. |

[0001193125-18-238271:mdna:10]
|  | • |  | Contractual Obligations and Off-Balance Sheet Arrangements. Overview of contractual obligations and contingent liabilities and commitments outstanding as of June 29, 2018 and an explanation of off-balance sheet arrangements. |

[0001193125-18-238271:mdna:11]
|  | • |  | Critical Accounting Estimates. Accounting estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results. |

[0001193125-18-238271:mdna:12]
Our Company

[0001193125-18-238271:mdna:13]
We are a leading provider of data storage technology and solutions. Our principal products are hard disk drives, commonly referred to as disk drives, hard
drives or HDDs. In addition to HDDs, we produce a broad range of data storage products including solid state drives (“SSDs”), solid state hybrid drives (“SSHDs”) and storage subsystems.

[0001193125-18-238271:mdna:14]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary
medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and
most SSDs use NAND flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high capacity hard disk drive and a smaller SSD acting as a cache to improve performance of frequently accessed
data.

[0001193125-18-238271:mdna:15]
Our HDD products are designed for mission critical and nearline applications in enterprise servers and storage systems; edge compute/client
compute applications, where our products are designed primarily for desktop and mobile computing; and edge non-compute/client non-compute applications, where our
products are designed for a wide variety of end user devices such as portable external storage systems, surveillance systems, digital video recorders (“DVRs”), network-attached storage

[0001193125-18-238271:mdna:16]
(“NAS”) and gaming consoles. Our SSD products mainly include serial attached SCSI (“SAS”) and Non-Volatile Memory Express
(“NVMe”) SSDs.

[0001193125-18-238271:mdna:17]
Our cloud systems and solutions portfolio includes modular original equipment manufacturer (“OEM”) storage
systems and scale-out storage servers.

[0001193125-18-238271:mdna:18]
Business Overview

[0001193125-18-238271:mdna:19]
Our industry is characterized by several trends and factors that have a material impact on our strategic planning, financial condition and results of
operations.

[0001193125-18-238271:mdna:20]
Demand for Data Storage

[0001193125-18-238271:mdna:21]
The International
Data Corporation (“IDC”) forecasted in its 2017 Data Age 2025 study that the global datasphere will grow to 163 zettabytes by 2025. According to IDC, we are fast approaching a new era of the data age, which we expect will have a
positive impact on storage demand. We believe that the continued advancement of the cloud, the further development of edge computing, the global proliferation of mobile devices, the evolution of the Internet of Things (“IoT”), the
increasing use of video surveillance, the evolution of consumer electronic devices, and the enterprise use of big data analytics are driving the growth of digital content. Factors contributing to the growth of digital content include:

[0001193125-18-238271:mdna:22]
|  | • |  | Creation, sharing, and consumption of media-rich digital content, such as high-resolution photos, high definition videos, and digital music through smart phones, tablets, digital cameras, personal video cameras, DVRs, gaming consoles or other digital devices; |

[0001193125-18-238271:mdna:23]
|  | • |  | Creation, aggregation and distribution of digital content through services and other offerings such as Facebook®, Instagram®, iTunes®, Netflix®, Google® and YouTube®; |

[0001193125-18-238271:mdna:24]
|  | • |  | Increasing use of video surveillance and the emergence of new surveillance systems which feature higher resolution digital cameras and thus require larger data storage capacities; |

[0001193125-18-238271:mdna:25]
|  | • |  | Creation and collection of data through the development and evolution of the IoT ecosystem, big data analytics (including enterprise use of big data analytics) and new technology trends such as self-driving cars and drones; |

[0001193125-18-238271:mdna:26]
|  | • |  | Continued advancement of the cloud, including the build out of large numbers of cloud data centers by CSPs and private companies transitioning on-site data centers into the cloud; and |

[0001193125-18-238271:mdna:27]
|  | • |  | Protection of increased digital content through redundant storage on backup devices and externally provided storage services. |

[0001193125-18-238271:mdna:28]
As a result of these factors, we anticipate that the nature and volume of content being created will require greater
storage, which is more efficiently and economically facilitated by higher capacity storage devices in order to store, manage, distribute, analyze and backup such content. We expect this to support the growth in demand for data storage solutions in
developed and emerging economies.

[0001193125-18-238271:mdna:29]
In addition, the economics of storage infrastructure are also evolving with the utilization of public and private
hyper-scale storage and open-source solutions reducing the total cost of ownership of storage while increasing the speed and efficiency with which customers can leverage massive computing and storage devices. Accordingly, we expect these trends will
continue to create significant demand for data storage solutions going forward.

[0001193125-18-238271:mdna:30]
Demand Trends

[0001193125-18-238271:mdna:31]
We believe that continued growth in digital content requires increasingly higher storage capacity in order to store, aggregate, host, distribute, analyze,
manage, protect, backup and use such content. We also believe that as architectures evolve to serve the growing commercial and consumer user base throughout the world, the storage solutions will evolve as well.

[0001193125-18-238271:mdna:32]
We expect increased data creation will lead to the expansion of the need for storage in the form of both HDDs and SSDs. While the advance of solid state
technology in many end markets is expected to increase, we believe that in the foreseeable

[0001193125-18-238271:mdna:33]
future, cloud, traditional enterprise, client and consumer markets that require high-capacity storage solutions will be best served by hard disk drives due to their ability to deliver the most
cost effective, reliable and energy efficient mass storage devices. We also believe that as hard disk drive capacities continue to increase, a focus exclusively on unit demand does not reflect the increase in demand for exabytes. This has resulted
in demand for fewer units, but with higher average capacity per drive.

[0001193125-18-238271:mdna:34]
Industry Supply Balance

[0001193125-18-238271:mdna:35]
From time to time, the storage industry has experienced periods of imbalance between supply and demand. To the extent that the storage industry builds or
maintains capacity based on expectations of demand that do not materialize, price erosion may become more pronounced. Conversely, during periods where demand exceeds supply, price erosion is generally muted.

[0001193125-18-238271:mdna:36]
Price Erosion

[0001193125-18-238271:mdna:37]
Historically, our industry has been
characterized by price declines for disk drive products with comparable capacity, performance and feature sets (“like-for-like products”). Price declines for like-for-like products (“price erosion”) tend to be more pronounced during periods of:

[0001193125-18-238271:mdna:38]
|  | • |  | economic contraction in which competitors may use discounted pricing to attempt to maintain or gain market share; |

[0001193125-18-238271:mdna:39]
|  | • |  | few new product introductions when competitors have comparable or alternative product offerings; and |

[0001193125-18-238271:mdna:40]
|  | • |  | industry supply exceeding demand. |

[0001193125-18-238271:mdna:41]
Disk drive manufacturers typically attempt to offset price erosion with an improved mix of disk drive products characterized by higher capacity, better
performance and additional feature sets and product cost reductions.

[0001193125-18-238271:mdna:42]
We believe the HDD industry experienced modest price erosion in fiscal years
2016, 2017 and 2018.

[0001193125-18-238271:mdna:43]
Product Life Cycles and Changing Technology

[0001193125-18-238271:mdna:44]
Success in our industry has been dependent to a large extent on the ability to balance the introduction and transition of new products with time-to-volume, performance, capacity and quality metrics at a competitive price, level of service and support that our customers expect. Generally, the drive manufacturer
that introduces a new product first benefits from improved product mix, favorable profit margins and less pricing pressure until comparable products are introduced. Changing technology also necessitates
on-going investments in research and development, which may be difficult to recover due to rapid product life cycles and economic declines. Further, there is a continued need to successfully execute product
transitions and new product introductions, as factors such as quality, reliability and manufacturing yields continue to be of significant competitive importance.

[0001193125-18-238271:mdna:45]
Seasonality

[0001193125-18-238271:mdna:46]
The disk drive industry traditionally experiences
seasonal variability in demand with higher levels of demand in the second half of the calendar year. This seasonality is driven by consumer spending in the
back-to-school season from late summer to fall and the traditional holiday shopping season from fall to winter. Beyond traditional seasonality, variability of sales can
be related to IT spending or a reflection of more cyclical demand from CSPs based on the timing of procurement, deployment and market supply and demand balance of other components such as NAND and DRAM.

[0001193125-18-238271:mdna:47]
Fiscal Year 2018 Summary

[0001193125-18-238271:mdna:48]
During fiscal year 2018, we shipped
338 exabytes of HDD storage capacity. We generated revenue of $11.2 billion and gross margins of 30% and our operating cash flow was $2.1 billion. We invested $1.3 billion in non-convertible
preferred stock of K.K. Pangea for the acquisition of Toshiba Memory Corporation with a consortium of investors led by Bain Capital Private Equity. We paid $726 million in dividends, repurchased approximately 10 million of our ordinary
shares for $361 million and paid $214 million for the repurchase of certain of our outstanding debt.

[0001193125-18-238271:mdna:49]
Results of Operations

[0001193125-18-238271:mdna:50]
We list in the tables below summarized information from our Consolidated Statements of Operations by dollar amounts and as a percentage of revenue:

[0001193125-18-238271:mdna:51]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 29,2018 |  |  | June 30,2017 |  |  | July 1,2016 |  |
| Revenue |  | $ | 11,184 |  |  | $ | 10,771 |  |  | $ | 11,160 |  |
| Cost of revenue |  |  | 7,820 |  |  |  | 7,597 |  |  |  | 8,545 |  |
| Gross margin |  |  | 3,364 |  |  |  | 3,174 |  |  |  | 2,615 |  |
| Product development |  |  | 1,026 |  |  |  | 1,232 |  |  |  | 1,237 |  |
| Marketing and administrative |  |  | 562 |  |  |  | 606 |  |  |  | 635 |  |
| Amortization of intangibles |  |  | 53 |  |  |  | 104 |  |  |  | 123 |  |
| Restructuring and other, net |  |  | 89 |  |  |  | 178 |  |  |  | 175 |  |
| Income from operations |  |  | 1,634 |  |  |  | 1,054 |  |  |  | 445 |  |
| Other expense, net |  |  | (216 | ) |  |  | (239 | ) |  |  | (171 | ) |
| Income before income taxes |  |  | 1,418 |  |  |  | 815 |  |  |  | 274 |  |
| Provision for income taxes |  |  | 236 |  |  |  | 43 |  |  |  | 26 |  |
| Net income |  | $ | 1,182 |  |  | $ | 772 |  |  | $ | 248 |  |

[0001193125-18-238271:mdna:52]
|  |  | Fiscal Years Ended |  |
|  |  | June 29,2018 |  |  | June 30,2017 |  |  | July 1,2016 |  |
| Revenue |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |
| Cost of revenue |  |  | 70 |  |  |  | 71 |  |  |  | 77 |  |
| Gross margin |  |  | 30 |  |  |  | 29 |  |  |  | 23 |  |
| Product development |  |  | 9 |  |  |  | 11 |  |  |  | 11 |  |
| Marketing and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 6 |  |
| Amortization of intangibles |  |  | — |  |  |  | 1 |  |  |  | 1 |  |
| Restructuring and other, net |  |  | 1 |  |  |  | 2 |  |  |  | 2 |  |
| Income from operations |  |  | 15 |  |  |  | 10 |  |  |  | 4 |  |
| Other expense, net |  |  | (2 | ) |  |  | (2 | ) |  |  | (2 | ) |
| Income before income taxes |  |  | 13 |  |  |  | 8 |  |  |  | 2 |  |
| Provision for income taxes |  |  | 2 |  |  |  | 1 |  |  |  | — |  |
| Net income |  |  | 11 | % |  |  | 7 | % |  |  | 2 | % |

[0001193125-18-238271:mdna:53]
The following table summarizes HDD information regarding average drive selling prices
(“ASPs”), exabytes shipped, and revenues by channel and geography:

[0001193125-18-238271:mdna:54]
|  |  | Fiscal Years Ended |  |
|  |  | June 29,2018 |  |  | June 30,2017 |  |  | July 1,2016 |  |
| ASPs (per unit) |  | $ | 69 |  |  | $ | 66 |  |  | $ | 61 |  |
| Exabytes Shipped |  |  | 338 |  |  |  | 263 |  |  |  | 233 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  |  | 69 | % |  |  | 67 | % |  |  | 69 | % |
| Distributors |  |  | 17 | % |  |  | 18 | % |  |  | 17 | % |
| Retailers |  |  | 14 | % |  |  | 15 | % |  |  | 14 | % |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  |  | 27 | % |  |  | 31 | % |  |  | 29 | % |
| EMEA |  |  | 17 | % |  |  | 17 | % |  |  | 17 | % |
| Asia Pacific |  |  | 56 | % |  |  | 52 | % |  |  | 54 | % |

[0001193125-18-238271:mdna:55]
| (1) | Revenue is attributed to countries based on the ship to location. |  |

[0001193125-18-238271:mdna:56]
Fiscal Year 2018 Compared to Fiscal Year 2017

[0001193125-18-238271:mdna:57]
Revenue

[0001193125-18-238271:mdna:58]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 29,2018 |  |  | June 30,2017 |  |  | Change |  |  | %Change |  |
| Revenue |  | $ | 11,184 |  |  | $ | 10,771 |  |  | $ | 413 |  |  |  | 4 | % |

[0001193125-18-238271:mdna:59]
Revenue in fiscal year 2018 increased approximately 4% or $0.4 billion, from fiscal year 2017, as a result of an
increase in exabytes shipped driven primarily by higher demand for our high capacity HDD product portfolio, partially offset by price erosion.

[0001193125-18-238271:mdna:60]
Cost of Revenue
and Gross Margin

[0001193125-18-238271:mdna:61]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 29,2018 |  |  | June 30,2017 |  |  | Change |  |  | %Change |  |
| Cost of revenue |  | $ | 7,820 |  |  | $ | 7,597 |  |  | $ | 223 |  |  |  | 3 | % |
| Gross margin |  | $ | 3,364 |  |  | $ | 3,174 |  |  | $ | 190 |  |  |  | 6 | % |
| Gross margin percentage |  |  | 30 | % |  |  | 29 | % |  |  |  |  |  |  |  |  |

[0001193125-18-238271:mdna:62]
For fiscal year 2018, gross margin as a percentage of revenue increased by 100 basis points compared to the prior fiscal
year due to favorable product mix and improved factory utilization as a result of higher demand for our high capacity HDD product portfolio, partially offset by price erosion.

[0001193125-18-238271:mdna:63]
Operating Expenses

[0001193125-18-238271:mdna:64]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 29,2018 |  |  | June 30,2017 |  |  | Change |  |  | %Change |  |
| Product development |  | $ | 1,026 |  |  | $ | 1,232 |  |  | $ | (206 | ) |  |  | (17 | )% |
| Marketing and administrative |  |  | 562 |  |  |  | 606 |  |  |  | (44 | ) |  |  | (7 | )% |
| Amortization of intangibles |  |  | 53 |  |  |  | 104 |  |  |  | (51 | ) |  |  | (49 | )% |
| Restructuring and other, net |  |  | 89 |  |  |  | 178 |  |  |  | (89 | ) |  |  | (50 | )% |
| Operating expenses |  | $ | 1,730 |  |  | $ | 2,120 |  |  | $ | (390 | ) |  |  |  |  |

[0001193125-18-238271:mdna:65]
Product Development Expense. Product development expenses for fiscal year 2018 decreased by
$206 million from fiscal year 2017 primarily due to a $97 million decrease in salaries and related benefits as a result of the restructuring of our workforce in prior periods, an $83 million decrease due to related operational
efficiencies and a $26 million decrease due to impairment charges related to the closure of our Korea design center in fiscal year 2017 that did not recur in fiscal year 2018.

[0001193125-18-238271:mdna:66]
Marketing and Administrative Expense. Marketing and administrative expenses for fiscal year 2018 decreased by $44 million from fiscal
year 2017 primarily due to a $54 million decrease in salaries and related benefits as a result of the restructuring of our workforce in prior periods, partially offset by an increase in other general expenses.

[0001193125-18-238271:mdna:67]
Amortization of Intangibles. Amortization of intangibles for fiscal year 2018 decreased by $51 million, as compared to fiscal year
2017, due to certain intangible assets reaching the end of their useful life.

[0001193125-18-238271:mdna:68]
Restructuring and Other, net. Restructuring and other,
net for fiscal year 2018 was comprised primarily of restructuring charges recorded during the September 2017 quarter and December 2017 quarter to reduce our workforce by approximately 1,100 employees. Restructuring and other, net also included a
gain of $25 million from the sale of certain properties previously classified as held for sale.

[0001193125-18-238271:mdna:69]
Restructuring and other, net for fiscal
year 2017 was comprised of restructuring charges recorded during the September 2016 quarter and March 2017 quarter to reduce our workforce by approximately 6,800 employees, as we continue to consolidate our global footprint across Asia, EMEA and the
Americas.

[0001193125-18-238271:mdna:70]
Other expense, net

[0001193125-18-238271:mdna:71]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 29,2018 |  |  | June 30,2017 |  |  | Change |  |  | %Change |  |
| Other expense, net |  | $ | (216 | ) |  | $ | (239 | ) |  | $ | 23 |  |  |  | (10 | )% |

[0001193125-18-238271:mdna:72]
Other expense, net for fiscal year 2018 decreased by $23 million, as compared to fiscal year 2017 due to a
$26 million increase in interest income primarily driven by higher interest rates, a $9 million net decrease in losses related to strategic investments and a $6 million net decrease in losses due to favorable changes in foreign
currency exchange rates, partially offset by an $18 million net increase in interest expense due to the issuance of $1.25 billion of Senior Notes in fiscal year 2017 and reduced by the subsequent repurchase of certain debts.

[0001193125-18-238271:mdna:73]
Income Taxes

[0001193125-18-238271:mdna:74]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 29,2018 |  |  | June 30,2017 |  |  | Change |  |  | %Change |  |
| Provision for income taxes |  | $ | 236 |  |  | $ | 43 |  |  | $ | 193 |  |  |  | 449 | % |

[0001193125-18-238271:mdna:75]
We recorded an income tax provision of $236 million for fiscal year 2018 compared to an income tax
provision of $43 million for fiscal year 2017. Our fiscal year 2018 income tax provision included approximately $204 million of tax expense associated with the revaluation of U.S. deferred tax assets as a result of the enactment of the Tax
Act on December 22, 2017, offset by the reversal of previously recorded unrecognized tax benefits of $7 million, and certain non-recurring items. Our fiscal year 2017 income tax provision included
approximately $2 million of net tax expense associated with various non-recurring items.

[0001193125-18-238271:mdna:76]
Our Irish tax
resident parent holding company owns various U.S. and non-U.S. subsidiaries that operate in multiple non-Irish income tax jurisdictions. Our worldwide operating income
is either subject to varying rates of income tax or is exempt from income tax due to tax incentive programs we operate under in Malaysia, Singapore and Thailand. These tax incentives are scheduled to expire in whole or in part at various dates
through 2027.

[0001193125-18-238271:mdna:77]
Our income tax provision recorded for fiscal year 2018 differed from the provision for income taxes that would be derived by applying
the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax incentive
programs and are considered indefinitely reinvested outside of Ireland, and (ii) a reduction in the net U.S. deferred tax assets associated with revaluation to a lower U.S. tax rate. Our income tax provision recorded for fiscal year 2017
differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to
non-U.S. earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) a decrease in valuation allowance for certain
deferred tax assets, and (iii) permanent differences.

[0001193125-18-238271:mdna:78]
Based on our non-U.S. ownership structure and
subject to (i) potential future increases in our valuation allowance for deferred tax assets; and (ii) a future change in our intention to indefinitely reinvest earnings from our subsidiaries outside of Ireland, we anticipate that our
effective tax rate in future periods will generally be less than the Irish statutory rate.

[0001193125-18-238271:mdna:79]
At June 29, 2018, our deferred tax asset valuation
allowance was approximately $1.2 billion.

[0001193125-18-238271:mdna:80]
At June 29, 2018, we had net deferred tax assets of $410 million. The realization of most
of these deferred tax assets is primarily dependent on our ability to generate sufficient U.S. and certain non-U.S. taxable income in future periods. Although realization is not assured, we believe that it is
more likely than not that these deferred tax assets will be realized. The amount of deferred tax assets considered realizable, however, may increase or decrease in subsequent periods when we re-evaluate the
underlying basis for our estimates of future U.S. and certain non-U.S. taxable income.

[0001193125-18-238271:mdna:81]
As of June 29,
2018, approximately $501 million and $99 million of our total U.S. net operating loss and tax credit carry- forwards, respectively, are subject to annual limitations from $1 million to $45 million pursuant to U.S. tax law.

[0001193125-18-238271:mdna:82]
We are required to file U.S. federal, U.S. state, and non-U.S. income tax returns. We are no longer subject
to tax examination of U.S. federal income tax returns for years prior to fiscal year 2015. With respect to U.S. state and non-U.S. income tax returns, we are generally no longer subject to tax examination for
years ending prior to fiscal year 2007.

[0001193125-18-238271:mdna:83]
On December 22, 2017, the Tax Act was enacted into law in the United States. The Tax Act significantly
revises U.S. corporate income tax law by, among other things, lowering U.S. corporate income tax rates from 35% to 21%, implementing a territorial tax system, and imposing a one-time transition tax on deemed
repatriated earnings of non-U.S. subsidiaries.

[0001193125-18-238271:mdna:84]
Pursuant to SEC Staff Accounting Bulletin (“SAB”)
118 (regarding the application of ASC 740 associated with the enactment of the Tax Act), we recorded an adjusted tax expense of approximately $204 million for fiscal year 2018, to re-measure our net U.S.
deferred tax assets at the newly enacted 21% income tax rate. This tax expense increased our effective tax rate by approximately 14%. We also do not expect the one-time transition tax to have a material impact
on our consolidated financial statements due to an overall accumulated earnings deficit in our non-U.S. subsidiaries for which the transition tax applies. We have considered SAB 118 and believe the accounting
under ASC 740 for the change to the U.S. statutory tax rate to our deferred tax balances and the one-time transition tax under the Tax Act is complete and appropriately reflected in the financial statements
during fiscal year 2018.

[0001193125-18-238271:mdna:85]
For all other provisions relating to the Tax Act, we continue to evaluate the impact of the Tax Act’s various highly
complex domestic and international provisions. The other U.S. tax changes, including limitations on various business deductions such

[0001193125-18-238271:mdna:86]
as executive compensation under Internal Revenue Code §162(m), are not expected to impact our tax expense in the short-term due to our large net operating loss and tax credit carryovers and
associated valuation allowance. The Tax Act’s new international rules, including Global Intangible Low-Taxed Income (“GILTI”), Foreign Derived Intangible Income (“FDII”), and Base
Erosion Anti-Avoidance Tax (“BEAT”) are generally effective in tax years beginning after December 31, 2017. These provisions are not expected to have a material impact on our consolidated financial statements. However, these
preliminary assessments and analyses are provisional and are subject to change as additional interpretive guidance is issued. We will complete our analysis within fiscal year 2019, which is consistent with the guidance provided in SAB 118.

[0001193125-18-238271:mdna:87]
Fiscal Year 2017 Compared to Fiscal Year 2016

[0001193125-18-238271:mdna:88]
Revenue

[0001193125-18-238271:mdna:89]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 30,2017 |  |  | July 1,2016 |  |  | Change |  |  | %Change |  |
| Revenue |  | $ | 10,771 |  |  | $ | 11,160 |  |  | $ | (389 | ) |  |  | (3)% |  |

[0001193125-18-238271:mdna:90]
Revenue in fiscal year 2017 decreased approximately 3% or $0.4 billion, from fiscal year 2016, as a result of price
erosion partially offset by an increase in exabytes shipped.

[0001193125-18-238271:mdna:91]
Cost of Revenue and Gross Margin

[0001193125-18-238271:mdna:92]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 30,2017 |  |  | July 1,2016 |  |  | Change |  |  | %Change |  |
| Cost of revenue |  | $ | 7,597 |  |  | $ | 8,545 |  |  | $ | (948 | ) |  |  | (11)% |  |
| Gross margin |  | $ | 3,174 |  |  | $ | 2,615 |  |  | $ | 559 |  |  |  | 21% |  |
| Gross margin percentage |  |  | 29 | % |  |  | 23 | % |  |  |  |  |  |  |  |  |

[0001193125-18-238271:mdna:93]
For fiscal year 2017, gross margin as a percentage of revenue increased by 600 basis points compared to the prior fiscal
year due to a favorable product mix and improved factory utilization resulting from cost savings due to our ongoing workforce reductions and manufacturing consolidation activities, partially offset by price erosion.

[0001193125-18-238271:mdna:94]
Operating Expenses

[0001193125-18-238271:mdna:95]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 30,2017 |  |  | July 1,2016 |  |  | Change |  |  | %Change |  |
| Product development |  | $ | 1,232 |  |  | $ | 1,237 |  |  | $ | (5 | ) |  |  | — % |  |
| Marketing and administrative |  |  | 606 |  |  |  | 635 |  |  |  | (29 | ) |  |  | (5)% |  |
| Amortization of intangibles |  |  | 104 |  |  |  | 123 |  |  |  | (19 | ) |  |  | (15)% |  |
| Restructuring and other, net |  |  | 178 |  |  |  | 175 |  |  |  | 3 |  |  |  | 2% |  |
| Operating expenses |  | $ | 2,120 |  |  | $ | 2,170 |  |  | $ | (50 | ) |  |  |  |  |

[0001193125-18-238271:mdna:96]
Product Development Expense. Product development expenses for fiscal year 2017 decreased from fiscal year
2016 primarily due to a $102 million decrease in salaries and related benefits as a result of an increase in operational efficiencies in our business and the restructuring of our workforce in prior periods, offset by a $71 million increase
in variable compensation and share-based compensation driven by better financial performance of the Company and a $26 million increase in impairment charges related to the closure of our Korea design center.

[0001193125-18-238271:mdna:97]
Marketing and Administrative Expense. Marketing and administrative expenses for fiscal
year 2017 decreased from fiscal year 2016 primarily due to a decrease in salaries and related benefits of $52 million as a result of the restructuring of our workforce in prior periods, a $28 million cost reduction resulting from an
increase in operational efficiencies in our business and the completion of certain promotional and branding activities in fiscal year 2016, partially offset by a $51 million increase in variable compensation and share-based compensation driven
by better financial performance of the Company.

[0001193125-18-238271:mdna:98]
Amortization of Intangibles. Amortization of intangibles for fiscal year 2017 decreased by
$19 million, as compared to fiscal year 2016, due to certain intangible assets reaching the end of their useful life.

[0001193125-18-238271:mdna:99]
Restructuring and
Other, net. Restructuring and other, net for fiscal year 2017 was comprised primarily of restructuring charges recorded during the September 2016 quarter and March 2017 quarter to reduce our workforce by approximately 6,800 employees, to
consolidate our global footprint across Asia, EMEA and the Americas.

[0001193125-18-238271:mdna:100]
Restructuring and other, net for fiscal year 2016 comprised of restructuring
charges recorded during the September 2015 quarter, March 2016 quarter and June 2016 quarter, to reduce our workforce by approximately 4,600 employees and align our manufacturing footprint with current macroeconomic conditions.

[0001193125-18-238271:mdna:101]
Other expense, net

[0001193125-18-238271:mdna:102]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 30,2017 |  |  | July 1,2016 |  |  | Change |  |  | %Change |  |
| Other expense, net |  | $ | (239 | ) |  | $ | (171 | ) |  | $ | (68 | ) |  |  | 40 | % |

[0001193125-18-238271:mdna:103]
Other expense, net for fiscal year 2017 increased by $68 million, as compared to fiscal year 2016 primarily due to
the $33 million of other income associated with the final payment of unpaid interest on the arbitration award amount in the Company’s case against Western Digital in fiscal year 2016 which did not recur in fiscal year 2017, a
$12 million increase from impairment of certain strategic investments and $24 million interest expense on the issuance of $750 million of 4.25% Senior Notes due 2022 and $500 million of 4.875% Senior Notes due 2024.

[0001193125-18-238271:mdna:104]
Income Taxes

[0001193125-18-238271:mdna:105]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 30,2017 |  |  | July 1,2016 |  |  | Change |  |  | %Change |  |
| Provision for income taxes |  | $ | 43 |  |  | $ | 26 |  |  | $ | 17 |  |  |  | 65 | % |

[0001193125-18-238271:mdna:106]
We recorded an income tax provision of $43 million for fiscal year 2017 compared to an income tax provision of
$26 million for fiscal year 2016. Our fiscal year 2017 income tax provision included approximately $2 million of net income tax expense associated with various non-recurring items. Our
fiscal year 2016 income tax provision included approximately $22 million of net income tax benefits primarily associated with the release of tax reserves due to the expiration of certain statutes of limitation.

[0001193125-18-238271:mdna:107]
Our income tax provision recorded for fiscal year 2017 differed from the provision for income taxes that would be derived by applying the Irish statutory
rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax incentive programs
and are considered indefinitely reinvested outside of Ireland, (ii) a decrease in valuation allowance for certain deferred tax assets, and (iii) permanent differences. Our income tax provision recorded for fiscal year 2016 differed from
the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related
to non-U.S. earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) tax benefits associated with the
reversal of previously recorded taxes, and (iii) a decrease in valuation allowance for certain deferred tax assets. The acquisition of Dot Hill System Corporation did not have a material impact on our effective tax rate.

[0001193125-18-238271:mdna:108]
On December 18, 2015, the Protecting Americans from Tax Hikes (“PATH”) Act of 2015 was
enacted. Among other provisions, the PATH Act retroactively reinstated and permanently extended the federal Research and Development (R&D) tax credit from December 31, 2014. The permanent extension of the R&D credit had no immediate
impact on our income tax provision due to valuation allowances on our U.S. deferred tax assets. None of the other PATH Act changes had a material impact on our income tax provision.

[0001193125-18-238271:mdna:109]
Liquidity and Capital Resources

[0001193125-18-238271:mdna:110]
The following sections discuss
our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of
purchase. Our short-term investments consist primarily of money market funds, time deposits and certificates of deposit. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our
cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of
cash have been and will continue to be sufficient to meet our cash needs for the next 12 months. We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term
investments and we do not believe the fair value of our short-term investments has significantly changed from the values reported as of June 29, 2018.

[0001193125-18-238271:mdna:111]
Cash
and Cash Equivalents

[0001193125-18-238271:mdna:112]
|  |  | As of |  |
| (Dollars in millions) |  | June 29,2018 |  |  | June 30,2017 |  |  | Change |  |
| Cash and cash equivalents |  | $ | 1,853 |  |  | $ | 2,539 |  |  | $ | (686 | ) |

[0001193125-18-238271:mdna:113]
Our cash and cash equivalents decreased by $686 million from June 30, 2017 as a result of $1.3 billion
investment in non-convertible preferred stock of K.K. Pangea, net cash outflows for capital expenditures of $366 million, dividends paid out to shareholders of $726 million, repurchase of our
ordinary shares of $361 million and repayment of long-term debt of $214 million. These decreases were offset by net cash provided by operating activities. The following table summarizes results from the Consolidated Statement of Cash Flows
for the periods indicated:

[0001193125-18-238271:mdna:114]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 29,2018 |  |  | June 30,2017 |  |  | July 1,2016 |  |
| Net cash flow (used in) provided by: |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating activities |  | $ | 2,113 |  |  | $ | 1,916 |  |  | $ | 1,680 |  |
| Investing activities |  |  | (1,588 | ) |  |  | (459 | ) |  |  | (1,211 | ) |
| Financing activities |  |  | (1,211 | ) |  |  | (46 | ) |  |  | (1,820 | ) |
| Effect of foreign currency exchange rates |  |  | — |  |  |  | — |  |  |  | (3 | ) |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  | $ | (686 | ) |  | $ | 1,411 |  |  | $ | (1,354 | ) |

[0001193125-18-238271:mdna:115]
Cash Provided by Operating Activities

[0001193125-18-238271:mdna:116]
Cash provided by operating activities for fiscal year 2018 was approximately $2.1 billion and includes the effects of net income adjusted for non-cash items including depreciation and amortization, deferred income taxes primarily due to the remeasurement of our U.S. deferred tax assets at the lower corporate tax rate, share-based compensation, and:

[0001193125-18-238271:mdna:117]
|  | • |  | an increase of $65 million in accounts payable, primarily due to timing of payments of capital expenditures; and |

[0001193125-18-238271:mdna:118]
|  | • |  | a decrease of $71 million in vendor receivables, primarily due to improved collections; partially offset by |

[0001193125-18-238271:mdna:119]
|  | • |  | an increase of $71 million in inventory, primarily due to an increase in units built. |

[0001193125-18-238271:mdna:120]
Cash provided by operating activities for fiscal year 2017 was approximately $1.9 billion and
includes the effects of net income adjusted for non-cash items including depreciation and amortization, share-based compensation, and:

[0001193125-18-238271:mdna:121]
|  | • |  | a decrease of $122 million in accounts receivable, primarily due to a decrease in revenue and improved collections; and |

[0001193125-18-238271:mdna:122]
|  | • |  | an increase of $121 million in accounts payable, primarily due to timing of payments for material purchases; partially offset by |

[0001193125-18-238271:mdna:123]
|  | • |  | an increase of $114 million in inventory, primarily due to an increase in units built in connection with our manufacturing footprint consolidating activities. |

[0001193125-18-238271:mdna:124]
Cash provided by operating activities for fiscal year 2016 was approximately
$1.7 billion and includes the effects of net income adjusted for non-cash items including depreciation and amortization, share-based compensation and

[0001193125-18-238271:mdna:125]
|  | • |  | a decrease in revenue accelerated by a reduction in the cash conversion cycle, leading to a decrease in working capital. |

[0001193125-18-238271:mdna:126]
Cash Used in Investing Activities

[0001193125-18-238271:mdna:127]
In
fiscal year 2018, we used $1.6 billion for net cash investing activities, which was primarily due to our investment in the Pangea debt security of $1.3 billion and the payments for the purchase of property, equipment and leasehold
improvements of approximately $366 million, partially offset by the proceeds of $69 million from the sale of certain properties previously classified as held for sale.

[0001193125-18-238271:mdna:128]
In fiscal year 2017, we used $459 million for net cash investing activities, which was primarily due to payments for the purchase of property,
equipment and leasehold improvements of approximately $434 million.

[0001193125-18-238271:mdna:129]
In fiscal year 2016, we used $1.2 billion for net cash investing
activities, which was primarily due to payments for the purchase of property, equipment and leasehold improvements of approximately $587 million and the acquisition of Dot Hill, net of cash acquired for $634 million.

[0001193125-18-238271:mdna:130]
Cash Used in Financing Activities

[0001193125-18-238271:mdna:131]
Net cash used in financing
activities of $1.2 billion for fiscal year 2018 was primarily attributable to the following activities:

[0001193125-18-238271:mdna:132]
|  | • |  | $726 million in dividend payments; |

[0001193125-18-238271:mdna:133]
|  | • |  | $361 million paid to repurchase ordinary shares; |

[0001193125-18-238271:mdna:134]
|  | • |  | $214 million of repayments of long-term debt; and |

[0001193125-18-238271:mdna:135]
|  | • |  | $23 million paid for taxes related to net share settlement of equity awards; offset by |

[0001193125-18-238271:mdna:136]
|  | • |  | $113 million in proceeds from the issuance of ordinary shares under employee stock plans. |

[0001193125-18-238271:mdna:137]
Net cash used in financing activities of $46 million for fiscal year 2017 was primarily attributable to the following activities:

[0001193125-18-238271:mdna:138]
|  | • |  | net proceeds of $1.2 billion received from issuance of $750 million of 4.25% Senior Notes due 2022 and $500 million of 4.875% Senior Notes due 2024; |

[0001193125-18-238271:mdna:139]
|  | • |  | $86 million in proceeds from the issuance of ordinary shares under employee stock plans; offset by |

[0001193125-18-238271:mdna:140]
|  | • |  | $561 million in dividend payments; |

[0001193125-18-238271:mdna:141]
|  | • |  | $460 million paid to repurchase ordinary shares; |

[0001193125-18-238271:mdna:142]
|  | • |  | $316 million of redemption and repurchase of long-term debt; and |

[0001193125-18-238271:mdna:143]
|  | • |  | $27 million paid for taxes related to net share settlement of equity awards. |

[0001193125-18-238271:mdna:144]
Net cash used in financing activities of $1.8 billion for fiscal year 2016 was primarily
attributable to the following activities:

[0001193125-18-238271:mdna:145]
|  | • |  | $1.1 billion paid to repurchase ordinary shares; and |

[0001193125-18-238271:mdna:146]
|  | • |  | $0.7 billion in dividend payments. |

[0001193125-18-238271:mdna:147]
Liquidity Sources

[0001193125-18-238271:mdna:148]
Our primary sources of liquidity as of
June 29, 2018, consisted of: (1) approximately $1.9 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) a $700 million senior revolving credit facility.

[0001193125-18-238271:mdna:149]
As of June 29, 2018, no borrowings had been drawn under the revolving credit facility or had been utilized for letters of credit issued under this
credit facility. The line of credit is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001193125-18-238271:mdna:150]
The credit agreement that governs our revolving credit facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents
and marketable securities, (2) a fixed charge coverage ratio and (3) a net leverage ratio. On April 28, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to adjust for our financial
liquidity position. The term of the revolving credit facility is through January 15, 2020 provided that if we do not have Investment Grade Ratings (as defined in the revolving credit facility) on August 15, 2018, then the maturity date
will be August 16, 2018 unless certain extension conditions have been satisfied. We were in compliance with the modified covenants as of June 29, 2018 and expect to be in compliance for the next 12 months.

[0001193125-18-238271:mdna:151]
As of June 29, 2018, cash and cash equivalents held by non-Irish subsidiaries was $1.8 billion. This
amount is potentially subject to taxation in Ireland upon repatriation by means of a dividend into our Irish parent. However, it is our intent to indefinitely reinvest earnings of non-Irish subsidiaries
outside of Ireland and our current plans do not demonstrate a need to repatriate such earnings by means of a taxable Irish dividend. Should funds be needed in the Irish parent company and should we be unable to fund parent company activities through
means other than a taxable Irish dividend, we would be required to accrue and pay Irish taxes on such dividend.

[0001193125-18-238271:mdna:152]
We believe that our sources of cash
will be sufficient to fund our operations and meet our cash requirements for at least the next 12 months.

[0001193125-18-238271:mdna:153]
Cash Requirements and Commitments

[0001193125-18-238271:mdna:154]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of
principal and interest on our indebtedness, and to fund our quarterly dividend and any future strategic investments. Our ability to fund these requirements will depend on our future cash flows, which are determined by future operating performance,
and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001193125-18-238271:mdna:155]
On July 30, 2018, our Board of Directors declared a quarterly cash dividend of $0.63 per share, which will be payable on October 3, 2018 to
shareholders of record as of the close of business on September 19, 2018.

[0001193125-18-238271:mdna:156]
As of June 29, 2018, we were in compliance with all of the
covenants under our debt agreements. Based on our current outlook, we expect to be in compliance with the covenants of our debt agreements over the next 12 months.

[0001193125-18-238271:mdna:157]
The carrying value of our debt as of June 29, 2018 and June 30, 2017 was $4.8 billion
and $5.0 billion, respectively. The table below presents the principal amounts of our outstanding debt:

[0001193125-18-238271:mdna:158]
|  |  | As of |  |
| (Dollars in millions) |  | June 29,2018 |  |  | June 30,2017 |  |  | Change |  |
| 3.75% Senior Notes due November 2018 |  | $ | 499 |  |  | $ | 710 |  |  | $ | (211 | ) |
| 4.25% Senior Notes due March 2022 |  |  | 750 |  |  |  | 750 |  |  |  | — |  |
| 4.75% Senior Notes due June 2023 |  |  | 951 |  |  |  | 951 |  |  |  | — |  |
| 4.875% Senior Notes due March 2024 |  |  | 500 |  |  |  | 500 |  |  |  | — |  |
| 4.75% Senior Notes due January 2025 |  |  | 975 |  |  |  | 975 |  |  |  | — |  |
| 4.875% Senior Notes due June 2027 |  |  | 697 |  |  |  | 697 |  |  |  | — |  |
| 5.75% Senior Notes due December 2034 |  |  | 490 |  |  |  | 490 |  |  |  | — |  |
|  |  | $ | 4,862 |  |  | $ | 5,073 |  |  | $ | (211 | ) |

[0001193125-18-238271:mdna:159]
From time to time, we may repurchase any of our outstanding ordinary shares through private, open market, tender offers,
broker assisted purchases or other means. During fiscal year 2018, we repurchased approximately 11 million of our ordinary shares including statutory tax withholdings related to vesting of employee equity awards. See “Item 5. Market
for Registrant’s Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities-Repurchases of Our Equity Securities.” As of June 29, 2018, $0.9 billion remained available for repurchase under our existing
repurchase authorization limit. All repurchases are effected as redemptions in accordance with our Articles of Association.

[0001193125-18-238271:mdna:160]
For fiscal year
2019, we expect capital expenditures to remain below our long-term targeted range of 6% to 8% of revenue. We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of
principal and interest on our indebtedness and payments of dividends. We will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities,
exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic
alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001193125-18-238271:mdna:161]
Contractual Obligations and Commitments

[0001193125-18-238271:mdna:162]
Our contractual cash obligations and commitments as of June 29, 2018, have been summarized in the table below:

[0001193125-18-238271:mdna:163]
|  |  |  |  |  | Fiscal Year(s) |  |
| (Dollars in millions) |  | Total |  |  | 2019 |  |  | 2020-2021 |  |  | 2022-2023 |  |  | Thereafter |  |
| Contractual Cash Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt, including current portion |  | $ | 4,862 |  |  | $ | 499 |  |  | $ | — |  |  | $ | 1,701 |  |  | $ | 2,662 |  |
| Interest payments on debt |  |  | 1,604 |  |  |  | 219 |  |  |  | 420 |  |  |  | 388 |  |  |  | 577 |  |
| Purchase obligations (1) |  |  | 963 |  |  |  | 952 |  |  |  | 11 |  |  |  | — |  |  |  | — |  |
| Operating leases (2) |  |  | 109 |  |  |  | 13 |  |  |  | 15 |  |  |  | 11 |  |  |  | 70 |  |
| Capital expenditures |  |  | 256 |  |  |  | 249 |  |  |  | 7 |  |  |  | — |  |  |  | — |  |
| Other funding requirements (3) |  |  | 10 |  |  |  | 6 |  |  |  | 4 |  |  |  | — |  |  |  | — |  |
| Subtotal |  |  | 7,804 |  |  |  | 1,938 |  |  |  | 457 |  |  |  | 2,100 |  |  |  | 3,309 |  |
| Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit or bank guarantees |  |  | 106 |  |  |  | 103 |  |  |  | 2 |  |  |  | 1 |  |  |  | — |  |
| Total |  | $ | 7,910 |  |  | $ | 2,041 |  |  | $ | 459 |  |  | $ | 2,101 |  |  | $ | 3,309 |  |

[0001193125-18-238271:mdna:164]
| (1) | Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. |  |

[0001193125-18-238271:mdna:165]
| (2) | Includes total future minimum rent expense under non-cancelable leases for both occupied and vacated facilities (rent expense is shown net of sublease income). |  |

[0001193125-18-238271:mdna:166]
| (3) | Consists of funding requirements related to strategic commitments. |  |

[0001193125-18-238271:mdna:167]
As of June 29, 2018, we had a liability for unrecognized tax benefits and an accrual for the
payment of related interest totaling $62 million, none of which is expected to be settled within one year. Outside of one year, we are unable to make a reasonably reliable estimate of when cash settlement with a taxing authority will occur.

[0001193125-18-238271:mdna:168]
Off-Balance Sheet Arrangements

[0001193125-18-238271:mdna:169]
As of June 29, 2018, we did not have any material off-balance sheet arrangements (as defined in
Item 303(a)(4)(ii) of Regulation S-K).

[0001193125-18-238271:mdna:170]
Accounting Policies

[0001193125-18-238271:mdna:171]
The methods, estimates and judgments we use in applying our most critical accounting policies have a significant impact on the results we report in our
consolidated financial statements. The SEC has defined the most critical accounting policies as the ones that are most important to the portrayal of our financial condition and operating results, and require us to make our most difficult and
subjective judgments, often as a result of the need to make estimates of matters that are highly uncertain at the time of estimation. Based on this definition, our most critical accounting policies include: establishment of sales program accruals,
establishment of warranty accruals, accounting for income taxes, the impairment assessment for goodwill and other long-lived assets and investment in debt security. Below, we discuss these policies further, as well as the estimates and judgments
involved. We also have other accounting policies and accounting estimates relating to uncollectible customer accounts, valuation of inventory, valuation of share-based payments and restructuring. We believe that these other accounting policies and
accounting estimates either do not generally require us to make estimates and judgments that are as difficult or as subjective, or it is less likely that they would have a material impact on our reported results of operations for a given period.

[0001193125-18-238271:mdna:172]
Establishment of Sales Program Accruals. We establish certain distributor and OEM sales programs aimed at increasing customer demand. For OEM
sales, rebates are typically based on an OEM customer’s volume of purchases or other agreed upon rebate programs. For the distribution channel, these programs typically involve rebates related to a distributor’s level of sales, order size,
advertising or point of sale activity and price protection adjustments. We provide for these obligations at the time that revenue is recorded based on estimated requirements. We estimate these contra-revenue rebates and adjustments based on various
factors, including price reductions during the period reported, estimated future price erosion, customer orders, distributor sell-through and inventory levels, program participation, customer claim submittals and sales returns. Our estimates reflect
contractual arrangements but also our judgment relating to variables such as customer claim rates and attainment of program goals, and inventory and sell-through levels reported by our distribution customers. Currently, our distributors’
inventories are within the historical range.

[0001193125-18-238271:mdna:173]
While we believe we have sufficient experience and knowledge of the market and customer buying patterns
to reasonably estimate such rebates and adjustments, actual market conditions or customer behavior could differ from our expectations. As a result, actual payments under these programs, which may spread over several months after the related sale,
may vary from the amount accrued. Accordingly, revenues and margins in the period in which the adjustment occurs may be affected.

[0001193125-18-238271:mdna:174]
Significant actual
variations in any of the factors upon which we base our contra-revenue estimates could have a material effect on our operating results. In fiscal year 2018, sales programs were approximately 12% of gross revenue. For fiscal years 2017 and 2016,
total sales programs of gross revenues were 11% and 13%, respectively. Adjustments to revenues due to under or over accruals for sales programs related to revenues reported in prior quarterly periods were less than 1% of gross revenue in fiscal
years 2018, 2017 and 2016. Any future shifts in the industry supply-demand balance as well as other factors may result in a more competitive pricing environment and may cause sales programs as a percentage of gross revenue to increase from the
current or historical levels. If such rebates and incentives trend upwards, revenues and margins may be reduced.

[0001193125-18-238271:mdna:175]
Establishment of Warranty
Accruals. We estimate probable product warranty costs at the time revenue is recognized. We generally warrant our products for a period of 1 to 5 years. Our warranty provision considers estimated product failure rates and trends (including the
timing of product returns during the warranty periods), and estimated repair or replacement costs related to product quality issues, if any. We also exercise judgment in estimating our ability to sell certain repaired products. Should actual
experience in any future period differ significantly from our estimates, our future results of operations could be materially affected. Our judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of
limited experience with those products upon which to base our warranty estimates.

[0001193125-18-238271:mdna:176]
The actual results with regard to warranty expenditures could have an adverse or favorable effect on
our results of operations if the actual rate of unit failure, the cost to repair a unit, or the actual cost required to satisfy customer claims differs from those estimates we used in determining the warranty accrual. Since we typically outsource
our warranty repairs, our repair cost is subject to periodic negotiations with vendors and may vary from our estimates. To the extent such sales fall below our forecast, warranty cost will be adversely impacted.

[0001193125-18-238271:mdna:177]
We review our warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates
underlying the accrual may result in adjustments that impact the current period gross margins and net income. In fiscal years 2018, 2017 and 2016 net changes in estimates of prior warranty accruals as a percentage of revenue were immaterial. Our
total warranty cost was 1.0%, 1.3% and 1.0% of revenue during fiscal years 2018, 2017 and 2016, respectively, while warranty cost related to new shipments (exclusive of the impact of re-estimates of pre-existing liabilities) were 1.3%, 1.2% and 1.1% respectively, for the same periods. Changes in anticipated failure rates of specific products and significant changes in repair or replacement costs have
historically been the major reasons for significant changes in prior estimates. Any future changes in failure rates of certain products, as well as changes in repair costs or the cost of replacement parts, may result in increased or decreased
warranty accruals.

[0001193125-18-238271:mdna:178]
Accounting for Income Taxes. We account for income taxes pursuant to Accounting Standards Codification (“ASC”)
Topic 740 (“ASC 740”), Income Taxes. In applying ASC 740, we make certain estimates and judgments in determining income tax expense for financial statement purposes. These estimates and judgments occur in the calculation of tax
credits, recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for income tax and financial statement purposes, as well as tax
liabilities associated with uncertain tax positions. The calculation of tax liabilities involves uncertainties in the application of complex tax rules and the potential for future adjustment of our uncertain tax positions by the Internal Revenue
Service or other tax jurisdictions. If estimates of these tax liabilities are greater or less than actual results, an additional tax benefit or provision will result. The deferred tax assets we record each period depend primarily on our ability to
generate future taxable income in the United States and certain non-U.S. jurisdictions. Each period, we evaluate the need for a valuation allowance for our deferred tax assets and, if necessary, we adjust the
valuation allowance so that net deferred tax assets are recorded only to the extent we conclude it is more likely than not that these deferred tax assets will be realized. If our outlook for future taxable income changes significantly, our
assessment of the need for a valuation allowance may also change.

[0001193125-18-238271:mdna:179]
Assessing Goodwill and Other Long-lived Assets for Impairment. We account
for goodwill in accordance with ASC Topic 350, Intangibles — Goodwill and Other. As permitted by ASC 350, we perform a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential
impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit
below its carrying amount. Based on the qualitative assessment, if it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, then the Company is not required to perform the quantitative goodwill
impairment test. If it is determined in the qualitative assessment that the fair value of a reporting unit is more likely than not below its carrying amount, including goodwill, then we perform a quantitative impairment test. The quantitative
goodwill impairment test is performed by comparing the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit’s goodwill over its fair value is recognized as an impairment loss, limited to
the total amount of goodwill allocated to that reporting unit.

[0001193125-18-238271:mdna:180]
In accordance with ASC 360-05-4, Impairment or Disposal of Long-lived Assets, we test other long-lived assets, including property, equipment and leasehold improvements and other intangible assets subject to amortization, for
recoverability whenever events or changes in circumstances indicate that the carrying values of those assets may not be recoverable. We assess the recoverability of an asset group by determining if the carrying value of the asset group exceeds the
sum of the projected undiscounted cash flows expected to result from the use and eventual disposition of the assets over the remaining economic life of the primary asset in the asset group. If the recoverability test indicates that the carrying
value of the asset group is not recoverable, we will estimate the fair value of the asset group and compare it to its carrying value. The excess of the carrying value over the fair value is allocated pro rata to derive the adjusted carrying value of
each asset in the asset group. The adjusted carrying value of each asset in the asset group is not reduced below its fair value.

[0001193125-18-238271:mdna:181]
Assessing Investment in Debt Security for Impairment. Our investment in non-convertible preferred stock of K.K. Pangea, for which we have the positive intent and ability to hold until maturity is carried at the amortized cost and classified as a held-to-maturity debt security. We assess whether an other-than-temporary impairment loss on the investment, including the accrued
payment-in-kind (“PIK”) income, has occurred due to a decline in fair value or other market conditions. If the fair value of the security is below amortized
cost and it is more likely than not that we will not be able to recover its amortized cost bases before its stated maturity, we will record an other-than-temporary impairment charge to Other, net in the Consolidated Statements of Operations.

[0001193125-18-238271:mdna:182]
Recent Accounting Pronouncements

[0001193125-18-238271:mdna:183]
See “Item 8. Financial
Statements and Supplementary Data — Note 1. Basis of Presentation and Summary of Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.
