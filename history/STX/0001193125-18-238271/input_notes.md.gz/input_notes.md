# STX notes — 0001193125-18-238271


## invest:InvestmentTableTextBlock

[0001193125-18-238271:notes:1]
The following table summarizes, by major type, the fair value and amortized cost of the Company's investments as of June 30, 2017:

[0001193125-18-238271:notes:2]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 594 |  |  | $ | — |  |  | $ | 594 |  |
| Time deposits and certificates of deposits |  | 584 |  |  | — |  |  | 584 |  |
| Total |  | $ | 1,178 |  |  | $ | — |  |  | $ | 1,178 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  | $ | 1,174 |  |
| Included in Other current assets |  |  |  |  |  |  | 4 |  |
| Total |  |  |  |  |  |  | $ | 1,178 |  |

[0001193125-18-238271:notes:3]
The following table summarizes, by major type, the fair value and amortized cost of the Company's investments as of June 29, 2018:

[0001193125-18-238271:notes:4]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 621 |  |  | $ | — |  |  | $ | 621 |  |
| Time deposits and certificates of deposit |  | 395 |  |  | — |  |  | 395 |  |
| Total |  | $ | 1,016 |  |  | $ | — |  |  | $ | 1,016 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  | $ | 1,012 |  |
| Included in Other current assets |  |  |  |  |  |  | 4 |  |
| Total |  |  |  |  |  |  | $ | 1,016 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001193125-18-238271:notes:5]
Activity in the allowance for doubtful accounts is as follows:

[0001193125-18-238271:notes:6]
| (Dollars in millions) |  | Balance atBeginning ofPeriod |  | Charges(Credit) toOperations |  | Deductions (a) |  | Balance atEnd ofPeriod |
| Fiscal year ended July 1, 2016 |  | $ | 9 |  |  | 1 |  |  | (1 | ) |  | $ | 9 |  |
| Fiscal year ended June 30, 2017 |  | $ | 9 |  |  | (4 | ) |  | — |  |  | $ | 5 |  |
| Fiscal year ended June 29, 2018 |  | $ | 5 |  |  | — |  |  | (1 | ) |  | $ | 4 |  |

[0001193125-18-238271:notes:7]
___________________________________

[0001193125-18-238271:notes:8]
| (a) | Uncollectible accounts written off, net of recoveries. |


## stx:ScheduleOfShareBasedPaymentAwardStockOptionAndEmployeeStockPurchasePlanValuationAssumptionsAndFairValueDisclosuresTableTextBlock

[0001193125-18-238271:notes:9]
The fair value of the Company's shares related to options and RSU granted to employees, shares issued from the ESPP and  PSUs subject to TSR/ROIC or AEPS conditions for fiscal years 2018, 2017 and 2016 were estimated using the following assumptions:

[0001193125-18-238271:notes:10]
|  | Fiscal Years |
|  | 2018 |  | 2017 |  | 2016 |
| Options |  |  |  |  |  |  |  |  |
| Expected term (in years) | 4.2 |  |  | 4.2 |  |  | 2.1 - 4.2 |  |
| Volatility | 38 - 42% |  |  | 38 - 42% |  |  | 33 - 48% |  |
| Weighted-average volatility | 40 | % |  | 39 | % |  | 36 | % |
| Expected dividend rate | 3.8 - 7.4% |  |  | 4.9 - 6.4% |  |  | 4.6 - 11.0% |  |
| Weighted-average expected dividend rate | 6.8 | % |  | 6.3 | % |  | 5.6 | % |
| Risk-free interest rate | 1.5 - 2.7% |  |  | 1.1 - 1.8% |  |  | 0.6 - 1.5% |  |
| Weighted-average fair value | $ | 6.56 |  |  | $ | 6.83 |  |  | $ | 12.28 |  |
| RSU |  |  |  |  |  |
| Expected term (in years) | 4.2 |  |  | 4.2 |  |  | 4.2 |  |
| Expected dividend rate | 3.5 - 7.4% |  |  | 4.6 - 7.7% |  |  | 4.6 - 11.0% |  |
| Weighted-average expected dividend rate | 7.11 | % |  | 6.4 | % |  | 5.16 | % |
| Weighted-average fair value | $ | 26.7 |  |  | $ | 30.85 |  |  | $ | 41.47 |  |
| ESPP |  |  |  |  |  |  |  |  |
| Expected term (in years) | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Volatility | 37 - 38% |  |  | 36 - 49% |  |  | 28 - 46% |  |
| Weighted-average volatility | 37 | % |  | 43 | % |  | 39 | % |
| Expected dividend rate | 4.6 - 7.6% |  |  | 5.6 - 7.8% |  |  | 4.6 - 8.3% |  |
| Weighted-average expected dividend rate | 6.5 | % |  | 6.8 | % |  | 6.9 | % |
| Risk-free interest rate | 1.1 - 1.6% |  |  | 0.4 - 0.6% |  |  | 0.2 - 0.5% |  |
| Weighted-average fair value | $ | 10.10 |  |  | $ | 9.78 |  |  | $ | 9.08 |  |
| PSUs subject to market condition |  |  |  |  |  |  |  |  |
| Expected term (in years) | 3.0 |  |  | 3.0 |  |  | 3.0 |  |
| Volatility | 45 | % |  | 41 - 42% |  |  | 30 | % |
| Weighted-average volatility | 45 | % |  | 41 | % |  | 30 | % |
| Expected dividend rate | 8.1 | % |  | 6.3-7.0% |  |  | 4.3 | % |
| Weighted-average expected dividend rate | 8.1 | % |  | 7.0 | % |  | 4.3 | % |
| Risk-free interest rate | 1.4% |  |  | 0.9 - 1.3% |  |  | 1.1 | % |
| Weighted-average fair value | $ | 25.9 |  |  | $ | 32.41 |  |  | $ | 47.34 |  |
| PSUs subject to an AEPS condition |  |  |  |  |  |
| Expected term (in years) | 4.2 |  |  | 4.2 |  |  | 4.2 |  |
| Expected dividend rate | 5.8 - 7.2% |  |  | 5.9 - 6.4% |  |  | 4.6 - 7.3% |  |
| Weighted-average expected dividend rate | 7.0 | % |  | 6.2 | % |  | 5.9 | % |
| Weighted-average fair value | $ | 27.10 |  |  | $ | 31.61 |  |  | $ | 42.09 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001193125-18-238271:notes:11]
Advertising Expense.    The cost of advertising is expensed as incurred. Advertising costs were approximately $28 million, $16 million and $31 million in fiscal years 2018, 2017 and 2016, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-18-238271:notes:12]
Acquisitions

[0001193125-18-238271:notes:13]
Dot Hill Systems Corp.

[0001193125-18-238271:notes:14]
On October 6, 2015, the Company acquired all of the outstanding shares of Dot Hill Systems Corp. (“Dot Hill”), a supplier of software and hardware storage systems. The Company paid $9.75 per share, or $674 million, in cash for the acquisition. The acquisition of Dot Hill further expands the Company's OEM-focused cloud storage systems business and advances the Company's strategic efforts.

[0001193125-18-238271:notes:15]
The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the acquisition date:

[0001193125-18-238271:notes:16]
| (Dollars in millions) |  | Amount |
| Cash and cash equivalents |  | $ | 40 |  |
| Accounts receivable, net |  | 48 |  |
| Inventories |  | 21 |  |
| Other current and non-current assets |  | 7 |  |
| Property, plant and equipment |  | 10 |  |
| Intangible assets |  | 252 |  |
| Goodwill |  | 364 |  |
| Total assets |  | 742 |  |
| Accounts payable, accrued expenses and other |  | (68 | ) |
| Total liabilities |  | (68 | ) |
| Total |  | $ | 674 |  |

[0001193125-18-238271:notes:17]
The following table shows the fair value of the separately identifiable intangible assets at the time of acquisition and the period over which each intangible asset will be amortized:

[0001193125-18-238271:notes:18]
| (Dollars in millions) |  | Fair Value |  | Weighted-AverageAmortizationPeriod |
| Existing technology |  | $ | 164 |  |  | 5.0 years |
| Customer relationships |  | 71 |  |  | 7.0 years |
| Trade names |  | 3 |  |  | 5.0 years |
| Total amortizable intangible assets acquired |  | 238 |  |  | 5.5 years |
| In-process research and development |  | 14 |  |  |  |
| Total acquired identifiable intangible assets |  | $ | 252 |  |  |  |

[0001193125-18-238271:notes:19]
The recognized goodwill, which is not deductible for income tax purposes, is primarily attributable to cost synergies expected to arise after the acquisition and the benefits the Company expects to derive from enhanced market opportunities.

[0001193125-18-238271:notes:20]
The expenses related to the acquisition of Dot Hill for the fiscal year ended July 1, 2016, which are included within Marketing and administrative expense on the Consolidated Statement of Operations, are not significant.

[0001193125-18-238271:notes:21]
The amounts of revenue and earnings of Dot Hill included in the Company's Consolidated Statement of Operations from the acquisition date were not significant.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001193125-18-238271:notes:22]
Summary of Significant Accounting Policies

[0001193125-18-238271:notes:23]
Cash, Cash Equivalents and Short-Term Investments.   The Company considers all highly liquid investments with a remaining maturity of 90 days or less at the time of purchase to be cash equivalents. Cash equivalents are carried at cost, which approximates fair value. From time to time, the Company has short-term investments that are primarily comprised of money market funds, time deposits and certificates of deposits. The Company has classified its marketable securities as available-for-sale and they are stated at fair value with unrealized gains and losses included in Accumulated other comprehensive loss, which is a component of Shareholders' Equity. The Company evaluates the available-for sale securities in an unrealized loss position for other-than-temporary impairment. Realized gains and losses are included in Other, net on the Company's Consolidated Statements of Operations. The cost of securities sold is based on the specific identification method.

[0001193125-18-238271:notes:24]
Restricted Cash and Investments.    Restricted cash and investments represent cash and cash equivalents and investments that are restricted as to withdrawal or use for other than current operations.


## us-gaap:CommitmentsDisclosureTextBlock

[0001193125-18-238271:notes:25]
Commitments

[0001193125-18-238271:notes:26]
Leases. The Company leases certain property, facilities and equipment under non-cancelable lease agreements. Land and facility leases expire at various dates through 2082 and contain various provisions for rental adjustments including, in certain cases, a provision based on increases in the Consumer Price Index. In addition, certain leases provide for renewal of the lease at the Company's option at expiration of the lease. The lease term begins on the date of initial possession of the leased property for purposes of recognizing lease expense on a straight-line basis over the term of the lease. The Company does not assume renewals in its determination of the lease term unless the renewals are deemed to be reasonably assured at lease inception. All of the leases require the Company to pay property taxes, insurance and normal maintenance costs, which are expensed as incurred.

[0001193125-18-238271:notes:27]
Future minimum lease payments for operating leases (including accrued lease payments relating to restructuring plans) with initial or remaining terms of one year or more were as follows at June 29, 2018 (lease payments are shown net of sublease income):

[0001193125-18-238271:notes:28]
| Fiscal Years Ending |  | Operating Leases |
| (Dollars in millions) |  |  |
| 2019 |  | $ | 13 |  |
| 2020 |  | 9 |  |
| 2021 |  | 6 |  |
| 2022 |  | 6 |  |
| 2023 |  | 5 |  |
| Thereafter |  | 70 |  |
|  |  | $ | 109 |  |

[0001193125-18-238271:notes:29]
Total rent expense for all land, facility and equipment operating leases, net of sublease income, was $22 million, $29 million and $43 million for fiscal years 2018, 2017 and 2016, respectively. Total sublease rental income for fiscal years 2018, 2017 and 2016 was $3 million, $2 million and $3 million, respectively. The Company subleases a portion of its facilities that it considers to be in excess of current requirements. As of June 29, 2018, total future lease income to be recognized for the Company's existing subleases is approximately $17 million.

[0001193125-18-238271:notes:30]
Capital Expenditures.    The Company's non-cancelable commitments for construction of manufacturing and product development facilities and purchases of equipment approximated $256 million at June 29, 2018.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001193125-18-238271:notes:31]
Comprehensive Income.    The Company presents comprehensive income in a separate statement. Comprehensive income is comprised of net income and other gains and losses affecting equity that are excluded from net income.


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-18-238271:notes:32]
Basis of Presentation and Consolidation

[0001193125-18-238271:notes:33]
The consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

[0001193125-18-238271:notes:34]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles also requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its consolidated financial statements. Certain prior years amounts reported in the consolidated financial statements and notes thereto have been reclassified to conform to the current year’s presentation.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0001193125-18-238271:notes:35]
Restructuring Costs.     The Company records restructuring activities including costs for one-time termination benefits in accordance with ASC Topic 420 ("ASC 420"), Exit or Disposal Cost Obligations. The timing of recognition for severance costs accounted for under ASC 420 depends on whether employees are required to render service until they are terminated in order to receive the termination benefits. If employees are required to render service until they are terminated in order to receive the termination benefits, a liability is recognized ratably over the future service period. Otherwise, a liability is recognized when management has committed to a restructuring plan and has communicated those actions to employees. Employee termination benefits covered by existing benefit arrangements are recorded in accordance with ASC Topic 712, Nonretirement Postemployment Benefits. These costs are recognized when management has committed to a restructuring plan and the severance costs are probable and estimable.


## us-gaap:DebtDisclosureTextBlock

[0001193125-18-238271:notes:36]
Debt

[0001193125-18-238271:notes:37]
Short-Term Borrowings

[0001193125-18-238271:notes:38]
The credit agreement entered into by the Company and its subsidiary Seagate HDD Cayman on January 18, 2011 and subsequently amended (the "Revolving Credit Facility") provides the Company with a $700 million senior secured revolving credit facility. The term of the Revolving Credit Facility is through January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Revolving Credit Facility) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. The loans made under the Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing, and for the issuance of letters of credit up to a sub-limit of $75 million.

[0001193125-18-238271:notes:39]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities, (2) a fixed charge coverage ratio and (3) a net leverage ratio. On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to allow for higher net leverage levels. The Company was in compliance with the modified covenants as of June 29, 2018 and expects to be in compliance for the next 12 months.

[0001193125-18-238271:notes:40]
As of June 29, 2018, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

[0001193125-18-238271:notes:41]
Long-Term Debt

[0001193125-18-238271:notes:42]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”).  On November 5, 2013, Seagate HDD Cayman, issued $800 million in aggregate principal amount of 3.75% Senior Notes, which mature on November 15, 2018, in a private placement. The interest on the Notes is payable semi-annually on May 15 and November 15 of each year. The Notes are redeemable at the option of Seagate HDD Cayman in whole or in part, on not less than 30, nor more than 60 days' notice, at a “make-whole” premium redemption price. The “make-whole” premium redemption price will be equal to the greater of (1) 100% of the principal amount of the notes being redeemed, or (2) the sum of the present values of the remaining schedule payments of principal and interest on the Notes being redeemed, discounted at the redemption date on a semi-annual basis at a rate equal to the sum of the applicable Treasury rate plus 50 basis points. Accrued and unpaid interest, if any will be paid to, but excluding, the redemption date. The Notes are fully and unconditionally guaranteed by the Company on a senior unsecured basis. During fiscal years 2018 and 2017, the Company repurchased $211 million and $90 million, respectively, aggregate principal amount of the 2018 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately $4 million and $3 million, respectively, which is included in Other, net in the Company's Consolidated Statements of Operations. The remainder of the 2018 Notes are classified as Current portion of long-term debt on the Company's Consolidated Balance Sheet at June 29, 2018.

[0001193125-18-238271:notes:43]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”).  On May 18, 2011, the Company's subsidiary, Seagate HDD Cayman, completed the sale of $600 million aggregate principal amount of the 2021 Notes, in a private placement exempt from the registration requirements of the Securities Act of 1933, as amended. The obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year.  The 2021 Notes are redeemable any time prior to May 1, 2016 at the option of the Company, in whole or in part, at a redemption price of 100% of the principal amount plus an “applicable premium” and accrued and unpaid interest, if any, to the redemption date. The "applicable premium" will be equal to the greater of (1) 1% of the principal amount of the 2021 Notes, or (2) the excess, if any, of (a) the present value of the redemption price on May 1, 2016 plus interest payments due through May 1, 2016, discounted at the applicable Treasury rate as of the redemption date plus 50 basis points; over (b) the principal amount of such note. The 2021 Notes are redeemable at any time on or after May 1, 2016 at various prices expressed as a percentage of principal amount, as set forth in the indentures, plus accrued and unpaid interest, if any, to the redemption date. In addition, any time before May 1, 2014, the Company may redeem up to 35% of the principal amount with the net cash proceeds from permitted sales of the Company's stock at a redemption price of 107% of the principal amount plus accrued interest to the redemption date.  The issuer under the 2021 Notes is Seagate HDD Cayman and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.  During fiscal year 2016, the Company repurchased $1 million aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. For fiscal year 2016, the loss recorded on the repurchase was immaterial, which were included in Other, net in the Company's Consolidated Statement of Operations. During fiscal year 2017, the 2021 Notes were fully extinguished through redemption for cash at a premium to their principal amount of $158 million, plus accrued and unpaid interest. For fiscal year 2017, the Company recorded a loss on the redemption of approximately $5 million, which was included in Other, net in the Company's Consolidated Statement of Operations.

[0001193125-18-238271:notes:44]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). On February 3, 2017, Seagate HDD Cayman issued, in a private placement, $750 million in aggregate principal amount of 4.25% Senior Notes which will mature on March 1, 2022. The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year, commencing on September 1, 2017. At any time before February 1, 2022, Seagate HDD Cayman may redeem some or all of the 2022 Notes at a "make whole" redemption price, plus accrued and unpaid interest, if any. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the 2022 Notes redeemed, plus (2) the excess, if any, of (a) the sum of the present values of the remaining scheduled payments of principal and interest on the 2022 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 40 basis points, minus accrued and unpaid interest, if any, on the 2022 Notes being redeemed to, but excluding, the redemption date over (b) the principal amount of the 2022 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the 2022 Notes being redeemed to, but excluding, the redemption date. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-238271:notes:45]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). On May 22, 2013, Seagate HDD Cayman, issued $1 billion in aggregate principal amount of 4.75% Senior Notes, which mature on June 1, 2023, in a private placement. The obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year.  The 2023 Notes are redeemable at the option of the Company in whole or in part, on not less than 30, nor more than 60 days' notice, at a "make-whole" premium redemption price.  The "make-whole" redemption price will be equal to the greater of (1) 100% of the principal amount of the notes being redeemed, or (2) the sum of the present values of the remaining scheduled payments of principal and interest on the 2023 Notes being redeemed, discounted at the redemption date on a semi-annual basis at a rate equal to the sum of the applicable Treasury rate plus 50 basis points. Accrued and unpaid interest, if any, will be paid to, but excluding, the redemption date. During fiscal year 2016, the Company repurchased $10 million aggregate principal amount of its 2023 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The gain recorded on the repurchase was immaterial, which was included in Other, net in the Company's Consolidated Statement of Operations. During fiscal year 2017, the Company repurchased $39 million aggregate principal amount of its 2023 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The loss recorded on the repurchase was immaterial, which is included in Other, net in the Company's Consolidated Statement of Operations.

[0001193125-18-238271:notes:46]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”).  On February 3, 2017, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 4.875% Senior Notes which will mature on March 1, 2024. The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year, commencing on September 1, 2017. At any time before January 1, 2024, Seagate HDD Cayman may redeem some or all of the 2024 Notes at a "make whole" redemption price, plus accrued and unpaid interest, if any. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the 2024 Notes redeemed, plus (2) the excess, if any, of (a) the sum of the present values of the remaining scheduled payments of principal and interest on the 2024 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 45 basis points, minus accrued and unpaid interest, if any, on the 2024 Notes being redeemed to, but excluding, the redemption date over (b) the principal amount of the 2024 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the 2024 Notes being redeemed to, but excluding, the redemption date. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-238271:notes:47]
$1 billion Aggregate principal amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”).  On May 28, 2014, Seagate HDD Cayman issued, in a private placement, $1 billion in aggregate principal amount of 4.75% Senior Notes due 2025, which mature on January 1, 2025. The interest on the Notes will be payable in cash semiannually on January 1 and July 1 of each year, commencing on January 1, 2015. At any time, upon not less than 30 nor more than 60 days’ notice, Seagate HDD may redeem some or all of the Notes at a ‘‘make-whole’’ redemption price. The ‘‘make-whole’’ redemption price will be equal to the greater of (1) 100% of the principal amount of the Notes redeemed, and (2) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points. Accrued and unpaid interest, if any, will be paid to, but excluding, the redemption date. The Notes are fully and unconditionally guaranteed by the Company on a senior unsecured basis. During fiscal year 2016, the Company repurchased $5 million aggregate principal amount of its 2025 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The gain recorded on the repurchase was immaterial, which is included in Other, net in the Company's Consolidated Statement of Operations. During fiscal year 2017, the Company repurchased $20 million aggregate principal amount of the 2025 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded a gain on the repurchase of approximately $1 million, which is included in Other, net in the Company's Consolidated Statements of Operations.

[0001193125-18-238271:notes:48]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June, 2027 (the “2027 Notes”). On May 14, 2015, Seagate HDD Cayman issued, in a private placement, $700 million in aggregate principal amount of 4.875% Senior Notes, which mature on June 1, 2027. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on December 1, 2015. At any time before March 1, 2027, Seagate HDD Cayman may redeem some or all of the Notes at a “make-whole” redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 40 basis points, minus accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date. At any time on or after March 1, 2027, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During fiscal year 2017, the Company repurchased $4 million aggregate principal amount of the 2027 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded an immaterial gain on the repurchase, which is included in Other, net in the Company's Consolidated Statements of Operations.

[0001193125-18-238271:notes:49]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December, 2034 (the “2034 Notes”). On December 2, 2014, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 5.75% Senior Notes, which mature on December 1, 2034. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on June 1, 2015. At any time before June 1, 2034, Seagate HDD Cayman may redeem some or all of the Notes at a “make-whole” redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points, minus accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date. At any time on or after June 1, 2034, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During fiscal year 2016, the Company repurchased $10 million aggregate principal amount of its 2034 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded a gain on the repurchase of approximately $3 million, which was included in Other, net in the Company's Consolidated Statement of Operations.

[0001193125-18-238271:notes:50]
At June 29, 2018, future principal payments on long-term debt were as follows (in millions):

[0001193125-18-238271:notes:51]
| Fiscal Year |  | Amount |
| 2019 |  | $ | 499 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| 2022 |  | 750 |  |
| 2023 |  | 951 |  |
| Thereafter |  | 2,662 |  |
| Total |  | $ | 4,862 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-18-238271:notes:52]
Derivative Financial Instruments

[0001193125-18-238271:notes:53]
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk denominated in foreign currencies. The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives in the Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The amount of net unrealized gain on cash flow hedges was less than $1 million as of June 29, 2018. The Company had no outstanding cash flow hedges as of June 30, 2017.

[0001193125-18-238271:notes:54]
The Company de-designates its cash flow hedges when the forecasted hedged transactions affects earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company did not recognize any material amounts related to the loss of hedge designation on discontinued cash flow hedges during fiscal years 2018, 2017 and 2016.

[0001193125-18-238271:notes:55]
Other derivatives not designated as hedging instruments consist of foreign currency forward exchange contracts that the Company uses to hedge the foreign currency exposure on the investment in debt security denominated in currency other than the U.S. dollar. The Company recognizes gains and losses on these contracts, as well as the related costs in Other, net on the Consolidated Statement of Operations along with foreign currency gains and losses on investment in debt security.

[0001193125-18-238271:notes:56]
The following tables show the total notional value of the Company's outstanding foreign currency forward exchange contracts as of June 29, 2018. All these foreign currency forward contracts mature within 12 months.

[0001193125-18-238271:notes:57]
|  |  | As of June 29, 2018 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Japanese Yen(a) |  | $ | 66 |  |  | $ | 1,310 |  |

[0001193125-18-238271:notes:58]
(a)  Pertains to our investment in Pangea.

[0001193125-18-238271:notes:59]
The Company did not have outstanding foreign currency forward exchange contracts as of June 30, 2017

[0001193125-18-238271:notes:60]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plan—the Seagate Deferred Compensation Plan (the “SDCP”).  In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees. As of June 29, 2018, the notional investments underlying the TRS amounted to $114 million. The contract term of the TRS is through January 2019 and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001193125-18-238271:notes:61]
The following tables show the Company's derivative instruments measured at gross fair value as reflected in the Consolidated Balance Sheet as of June 29, 2018:

[0001193125-18-238271:notes:62]
|  |  | As of June 29, 2018 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 10 |  |  | Accrued expenses |  | — |  |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 10 |  |  |  |  | $ | — |  |

[0001193125-18-238271:notes:63]
As of June 30, 2017, the Company did not have outstanding foreign currency forward exchange contracts and the gross fair value of the TRS reflected in the Consolidated Balance Sheets is immaterial.

[0001193125-18-238271:notes:64]
The amount of gain or loss recognized in the Consolidated Statement of Comprehensive Income on derivatives designated as cash flow hedges was less than $1 million as of June 29, 2018. The following table shows the effect of the Company's derivative instruments on the Consolidated Statement of Operations for the fiscal year ended June 29, 2018:

[0001193125-18-238271:notes:65]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 10 |  |
| Total return swap |  | Operating expenses |  | $ | 6 |  |

[0001193125-18-238271:notes:66]
The following tables show the effect of the Company's derivative instruments on the Consolidated Statement of Comprehensive Income and the Consolidated Statement of Operations for the fiscal year ended June 30, 2017:

[0001193125-18-238271:notes:67]
| (Dollars in millions) Derivatives Designated as Cash Flow Hedges |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
| Foreign currency forward exchange contracts |  | $ | (3 | ) |  | Cost of revenue |  | $ | (4 | ) |  | Cost of revenue |  | $ | — |  |

[0001193125-18-238271:notes:68]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 1 |  |
| Total return swap |  | Operating expenses |  | $ | 10 |  |

[0001193125-18-238271:notes:69]
| (a) | The amounts of gain or (loss) recognized in income related to the ineffective portion of the hedge relationships and to the amount excluded from the assessment of hedge effectiveness were less than $1 million for the fiscal year ended June 30, 2017. |


## us-gaap:DerivativesPolicyTextBlock

[0001193125-18-238271:notes:70]
Derivative Financial Instruments. The Company applies the requirements of ASC Topic 815 ("ASC 815"), Derivatives and Hedging. ASC 815 requires that all derivatives be recorded on the balance sheet at fair value and establishes criteria for designation and effectiveness of hedging relationships. During fiscal year 2018, the Company early adopted ASU No. 2017-12, Derivatives and Hedging (ASC Topic 815) — Targeted Improvements to Accounting for Hedging Activities. The Company continues to exclude the change in forward points from the assessment of hedge effectiveness and recognizes the excluded component in Other, net in  the Consolidated Statements of Operations. Foreign currency forward exchange contracts not designated as hedge instruments are used to economically hedge the foreign currency exposure in the value of an investment denominated in currency other than U.S. dollar. The Company recognizes the unrealized gains (losses) due to the changes in the fair value of these contracts in Other, net in the Consolidated Statements of Operations along with the foreign currency gains and losses on remeasurement of such investment.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-18-238271:notes:71]
Share-based Compensation

[0001193125-18-238271:notes:72]
Share-Based Compensation Plans

[0001193125-18-238271:notes:73]
The Company's share-based compensation plans have been established to promote the Company's long-term growth and financial success by providing incentives to its employees, directors and consultants through grants of share-based awards. The provisions of the Company's share-based benefit plans, which allow for the grant of various types of equity-based awards, are also intended to provide greater flexibility to maintain the Company's competitive ability to attract, retain and motivate participants for the benefit of the Company and its shareholders.

[0001193125-18-238271:notes:74]
Seagate Technology plc 2012 Equity Incentive Plan (the “EIP”).  On October 26, 2011, the shareholders approved the EIP and authorized the issuance of up to a total of  27.0 million ordinary shares, par value $0.0001 per share, plus any shares remaining available for grant under the Seagate Technology plc 2004 Share Compensation Plan (the "SCP") as of the effective date of the EIP (which was equal to 11.0 million ordinary shares as of the effective date of the EIP and which will increase by such additional number of shares as will be returned to the share reserve in respect of awards previously granted under the SCP) (together, the “Share Reserve”). On October 22, 2014, the shareholders authorized the issuance from the EIP of an additional 25 million ordinary shares, par value $0.0001 per share. Any shares that are subject to options or share appreciation rights granted under the EIP will be counted against the Share Reserve as one share for every one share granted, and any shares that are subject to restricted share bonus awards, restricted share units, performance share bonus awards or performance share awards (collectively, “Full-Value Share Awards”) will generally be counted against the Share Reserve as two and five-tenths shares for every one share granted. On October 19, 2016, the shareholders authorized the issuance from the EIP of an additional 7.5 million ordinary shares, par value $0.0001 per share. As of June 29, 2018, there were approximately 25.7 million ordinary shares available for issuance under the EIP.

[0001193125-18-238271:notes:75]
Dot Hill Systems 2009 Equity Incentive Plan (the "DHEIP").  Seagate Technology plc acquired the Dot Hill Systems 2009 Equity Incentive Plan effective October 6, 2015. The Company assumed the remaining authorized but unused share reserve of approximately 2 million shares, based on the conversion ratio, from the DHEIP on the acquisition date. Any shares that are subject to options or share appreciation rights granted under the DHEIP will be counted against the Share Reserve as one share for every one share granted, and any shares that are subject to restricted share bonus awards, restricted share units, performance share bonus awards or performance share awards (collectively, “Full-Value Share Awards”) will generally be counted against the Share Reserve as one and five-tenths shares for every one share granted. As of June 29, 2018, there were approximately 1 million ordinary shares available for issuance under the DHEIP.

[0001193125-18-238271:notes:76]
Seagate Technology plc Employee Stock Purchase Plan (the "ESPP").  There are 60.0 million ordinary shares authorized to be issued under the ESPP. The ESPP consists of a six-month offering period with a maximum issuance of 1.5 million ordinary shares per offering period. The ESPP permits eligible employees to purchase ordinary shares through payroll deductions generally at 85% of the fair market value of the ordinary shares. As of June 29, 2018, there were approximately 12.8 million ordinary shares available for issuance under the ESPP.

[0001193125-18-238271:notes:77]
Equity Awards

[0001193125-18-238271:notes:78]
Full-Value Share Awards (e.g. restricted share units, "RSU") generally vest over a period of three to four years, with cliff vesting of a portion of each award occurring annually, subject to continuous employment with the Company through the vesting date. Options generally vest as follows:  25% of the options will vest on the first anniversary of the vesting commencement date and the remaining 75% will vest ratably each month thereafter over the next 36 months. Options granted under the EIP and SCP have an exercise price equal to the fair market value of the Company's ordinary shares on the grant date. Fair market value is defined as the closing price of the Company's ordinary shares on NASDAQ on the grant date.

[0001193125-18-238271:notes:79]
The Company granted awards of performance-based share units ("PSU") to its senior executive officers under the SCP and the EIP where vesting is subject to both the continued employment of the participant by the Company and the achievement of certain performance goals established by the Compensation Committee of the Company's Board of Directors, including market-based performance goals.  A single PSU represents the right to receive a single ordinary share of the Company. During fiscal years 2018, 2017 and 2016, the Company granted 0.4 million, 0.6 million and 0.4 million PSUs, respectively, where performance is measured based on a three-year average return on invested capital ("ROIC") goal and a relative total shareholder return ("TSR") goal, which is based on the Company's ordinary shares measured against a benchmark TSR of a peer group over the same three-year period (the "TSR/ROIC" awards). These awards vest after the end of the performance period of three years from the grant date. A percentage of these units may vest only if at least the minimum ROIC goal is met regardless of whether the TSR goal is met. The number of share units to vest will range from 0% to 200% of the targeted units. In evaluating the fair value of these units, the Company used a Monte Carlo simulation on the grant date, taking the market-based TSR goal into consideration. Compensation expense related to these units is only recorded in a period if it is probable that the ROIC goal will be met, and it is to be recorded at the expected level of achievement.

[0001193125-18-238271:notes:80]
The Company also granted 0.2 million, 0.2 million and 0.2 million PSUs during fiscal years 2018, 2017 and 2016, respectively, to its senior executive officers which are subject to a performance goal related to the Company's adjusted earnings per share (the "AEPS" awards). These awards have a maximum seven-year vesting period, with 25% annual vesting starting on the first anniversary of the grant date. If the performance goal is not achieved, vesting is delayed to a following year in which the AEPS goal is achieved. Any unvested awards from prior years may vest cumulatively in a future year within the seven-year vesting period if the annual AEPS goal is achieved during a subsequent year. If the AEPS goal has not been met by the end of the seven year period, any unvested shares will be forfeited.

[0001193125-18-238271:notes:81]
Determining Fair Value of Seagate Technology Stock Plans

[0001193125-18-238271:notes:82]
Valuation and amortization method - The Company estimates the fair value of stock options, RSU and performance awards subject to an AEPS condition granted using the Black-Scholes-Merton valuation model and a single share award approach. This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period or the remaining service (vesting) period.

[0001193125-18-238271:notes:83]
Expected Term - Expected term represents the period that the Company's share-based awards are expected to be outstanding and was determined based on historical experience of similar awards, giving consideration to the contractual terms of the share-based awards, vesting schedules and expectations of future employee behavior as influenced by changes to the terms of its share-based awards.

[0001193125-18-238271:notes:84]
Expected Volatility - The Company uses a combination of the implied volatility of its traded options and historical volatility of its share price.

[0001193125-18-238271:notes:85]
Expected Dividend - The Black-Scholes-Merton valuation model calls for a single expected dividend yield as an input. The dividend yield is determined by dividing the expected per share dividend during the coming year by the grant date share price.  The expected dividend assumption is based on the Company's current expectations about its anticipated dividend policy. Also, because the expected dividend yield should reflect marketplace participants' expectations, the Company does not incorporate changes in dividends anticipated by management unless those changes have been communicated to or otherwise are anticipated by marketplace participants.

[0001193125-18-238271:notes:86]
Risk-Free Interest Rate - The Company bases the risk-free interest rate used in the Black-Scholes-Merton valuation model on the implied yield currently available on U.S. Treasury zero-coupon issues with an equivalent remaining term. Where the expected term of the Company's share-based awards do not correspond with the terms for which interest rates are quoted, the Company performed a straight-line interpolation to determine the rate from the available term maturities.

[0001193125-18-238271:notes:87]
Share-based Compensation Expense

[0001193125-18-238271:notes:88]
The Company recorded $112 million, $137 million and $120 million of share-based compensation during fiscal years 2018, 2017 and 2016, respectively. Management has made an estimate of expected forfeitures and is recognizing compensation costs only for those equity awards expected to vest. When estimating forfeitures, the Company considers voluntary termination behavior as well as analysis of actual forfeited awards.

[0001193125-18-238271:notes:89]
Stock Option Activity

[0001193125-18-238271:notes:90]
The Company issues new ordinary shares upon exercise of stock options. The following is a summary of option activities:

[0001193125-18-238271:notes:91]
| Options |  | Number ofShares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualTerm |  | AggregateIntrinsicValue |
|  |  | (In millions) |  |  |  | (In years) |  | (Dollars in millions) |
| Outstanding at June 30, 2017 |  | 5.7 |  |  | $ | 39.24 |  |  | 5.0 |  | $22 |
| Granted |  | 1.4 |  |  | $ | 33.67 |  |  |  |  |  |
| Exercised |  | (1.8 | ) |  | $ | 32.66 |  |  |  |  |  |
| Forfeitures |  | (1.0 | ) |  | $ | 38.61 |  |  |  |  |  |
| Expirations |  | (0.3 | ) |  | $ | 54.18 |  |  |  |  |  |
| Outstanding at June 29, 2018 |  | 4.0 |  |  | $ | 39.00 |  |  | 5.0 |  | $72 |
| Vested and expected to vest at June 29, 2018 |  | 3.9 |  |  | $ | 39.10 |  |  | 5.0 |  | $70 |
| Exercisable at June 29, 2018 |  | 1.4 |  |  | $ | 44.26 |  |  | 4.0 |  | $19 |

[0001193125-18-238271:notes:92]
The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company's ordinary shares for the options that were in-the-money at June 29, 2018. During fiscal years 2018, 2017 and 2016, the aggregate intrinsic value of options exercised under the Company's stock option plans was $34 million, $29 million and $44 million, respectively, determined as of the date of option exercise. The aggregate fair value of options vested during fiscal years 2018, 2017 and 2016 were approximately $12 million, $15 million and $18 million, respectively.

[0001193125-18-238271:notes:93]
At June 29, 2018, the total compensation cost related to options granted to employees but not yet recognized was approximately $16 million, net of estimated forfeitures of approximately $1 million. This cost is being amortized on a straight-line basis over a weighted-average remaining term of approximately 2.6 years and will be adjusted for subsequent changes in estimated forfeitures.

[0001193125-18-238271:notes:94]
Nonvested Awards Activity

[0001193125-18-238271:notes:95]
The following is a summary of nonvested award activities which do not contain a performance condition:

[0001193125-18-238271:notes:96]
| Nonvested Awards |  | Number ofShares |  | Weighted-AverageGrant-DateFair Value |
|  |  | (In millions) |  |  |
| Nonvested at June 30, 2017 |  | 5.2 |  |  | $ | 35.75 |  |
| Granted |  | 2.7 |  |  | $ | 26.69 |  |
| Forfeitures |  | (0.7 | ) |  | $ | 34.69 |  |
| Vested |  | (2.0 | ) |  | $ | 36.71 |  |
| Nonvested at June 29, 2018 |  | 5.2 |  |  | $ | 30.74 |  |

[0001193125-18-238271:notes:97]
At June 29, 2018, the total compensation cost related to nonvested awards granted to employees but not yet recognized was approximately $105 million, net of estimated forfeitures of approximately $9 million.  This cost is being amortized on a straight-line basis over a weighted-average remaining term of 2.5 years and will be adjusted for subsequent changes in estimated forfeitures.  The aggregate fair value of nonvested awards vested during fiscal years 2018, 2017 and 2016 were approximately $76 million, $73 million and $102 million, respectively.

[0001193125-18-238271:notes:98]
Performance Awards

[0001193125-18-238271:notes:99]
The following is a summary of nonvested award activities which contain a performance condition:

[0001193125-18-238271:notes:100]
| Performance Awards |  | Number ofShares |  | Weighted-AverageGrant-DateFair Value |
|  |  | (In millions) |  |  |
| Performance units at June 30, 2017 |  | 1.5 |  |  | $ | 41.88 |  |
| Granted |  | 0.5 |  |  | $ | 26.28 |  |
| Forfeitures |  | (0.5 | ) |  | $ | 40.84 |  |
| Vested |  | (0.3 | ) |  | $ | 48.02 |  |
| Performance units at June 29, 2018 |  | 1.2 |  |  | $ | 33.34 |  |

[0001193125-18-238271:notes:101]
At June 29, 2018, the total compensation cost related to performance awards granted to employees but not yet recognized was approximately $23 million, net of estimated forfeitures of approximately $3 million. This cost is being amortized on a straight-line basis over a weighted-average remaining term of 1.50 years.

[0001193125-18-238271:notes:102]
ESPP

[0001193125-18-238271:notes:103]
During fiscal years 2018, 2017 and 2016, the aggregate intrinsic value of shares purchased under the Company's ESPP was approximately $31 million, $24 million and $12 million, respectively. At June 29, 2018, the total compensation cost related to options to purchase the Company's ordinary shares under the ESPP but not yet recognized was approximately $1.4 million. This cost will be amortized on a straight-line basis over a weighted-average period of approximately one month. During fiscal year 2018, the Company issued 2.0 million ordinary shares with a weighted-average exercise price of $28.19 per share.

[0001193125-18-238271:notes:104]
Tax-Deferred Savings Plan

[0001193125-18-238271:notes:105]
The Company has a tax-deferred savings plan, the Seagate 401(k) Plan (the "40l(k) plan"), for the benefit of qualified employees.  The 40l(k) plan is designed to provide employees with an accumulation of funds at retirement. Qualified employees may elect to make contributions to the 401(k) plan on a bi-weekly basis. Pursuant to the 401(k) plan, the Company matches 50% of employee contributions, up to 6% of compensation, subject to maximum annual contributions of $6,000 per participating employee. During fiscal years 2018, 2017 and 2016, the Company made matching contributions of $16 million, $18 million and $19 million, respectively.

[0001193125-18-238271:notes:106]
Deferred Compensation Plan

[0001193125-18-238271:notes:107]
On January 1, 2001, the Company adopted the SDCP for the benefit of eligible employees. This plan is designed to permit certain discretionary employer contributions, in excess of the tax limits applicable to the 401(k) plan and to permit employee deferrals in excess of certain tax limits.  During fiscal year 2014, the Company entered into a TRS in order to manage the equity market risks associated with the SDCP liabilities. See Note 8. Derivative Financial Instruments contained in this report for additional information about the TRS.


## us-gaap:EarningsPerShareTextBlock

[0001193125-18-238271:notes:108]
Earnings Per Share

[0001193125-18-238271:notes:109]
Basic earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period. Diluted earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period and the number of additional shares that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding options, unvested restricted stock units and performance-based share units and shares to be purchased under the Employee Stock Purchase Plan ("ESPP"). The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in fair market value of the Company’s share price can result in a greater dilutive effect from potentially dilutive securities. The following table sets forth the computation of basic and diluted net income per share attributable to the shareholders of the Company:

[0001193125-18-238271:notes:110]
|  |  | Fiscal Years Ended |
| (In millions, except per share data) |  | June 29, 2018 |  | June 30, 2017 |  | July 1, 2016 |
| Numerator: |  |  |  |  |  |  |
| Net income |  | $ | 1,182 |  |  | $ | 772 |  |  | $ | 248 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 288 |  |  | 296 |  |  | 299 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |
| Employee equity award plans |  | 4 |  |  | 3 |  |  | 3 |  |
| Total shares for purposes of calculating diluted net income per share |  | 292 |  |  | 299 |  |  | 302 |  |
| Net income per share |  |  |  |  |  |  |
| Basic |  | $ | 4.10 |  |  | $ | 2.61 |  |  | $ | 0.83 |  |
| Diluted |  | $ | 4.05 |  |  | $ | 2.58 |  |  | $ | 0.82 |  |

[0001193125-18-238271:notes:111]
The following potential shares were excluded from the computation of diluted net income per share as their effect would have been anti-dilutive:

[0001193125-18-238271:notes:112]
|  |  | Fiscal Years Ended |
| (In millions) |  | June 29, 2018 |  | June 30, 2017 |  | July 1, 2016 |
| Employee equity award plans |  | 1 |  |  | 1 |  |  | 3 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001193125-18-238271:notes:113]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 620 |  |  | $ | 392 |  |  | $ | — |  |  | $ | 1,012 |  |
| Other current assets |  | 1 |  |  | 13 |  |  | — |  |  | 14 |  |
| Total assets |  | $ | 621 |  |  | $ | 405 |  |  | $ | — |  |  | $ | 1,026 |  |

[0001193125-18-238271:notes:114]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 593 |  |  | $ | 581 |  |  | $ | — |  |  | $ | 1,174 |  |
| Other current assets |  | 1 |  |  | 3 |  |  | — |  |  | 4 |  |
| Total assets |  | $ | 594 |  |  | $ | 584 |  |  | $ | — |  | — |  | $ | 1,178 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-18-238271:notes:115]
Fair Value

[0001193125-18-238271:notes:116]
Measurement of Fair Value

[0001193125-18-238271:notes:117]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact and it considers assumptions that market participants would use when pricing the asset or liability.

[0001193125-18-238271:notes:118]
Fair Value Hierarchy

[0001193125-18-238271:notes:119]
A fair value hierarchy is based on whether the market participant assumptions used in determining fair value are obtained from independent sources (observable inputs) or reflects the Company's own assumptions of market participant valuation (unobservable inputs). A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The three levels of inputs that may be used to measure fair value are:

[0001193125-18-238271:notes:120]
Level 1 - Quoted prices in active markets that are unadjusted and accessible at the measurement date for identical, unrestricted assets or liabilities;

[0001193125-18-238271:notes:121]
Level 2 - Quoted prices for identical assets and liabilities in markets that are inactive; quoted prices for similar assets and liabilities in active markets or financial instruments for which significant inputs are observable, either directly or indirectly; or

[0001193125-18-238271:notes:122]
Level 3 - Prices or valuations that require inputs that are both unobservable and significant to the fair value measurement.

[0001193125-18-238271:notes:123]
The Company considers an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and views an inactive market as one in which there are few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, the Company's or the counterparty's non-performance risk is considered in determining the fair values of liabilities and assets, respectively.

[0001193125-18-238271:notes:124]
Items Measured at Fair Value on a Recurring Basis

[0001193125-18-238271:notes:125]
The following table presents the Company's assets and liabilities that are measured at fair value on a recurring basis, excluding accrued interest components, as of June 29, 2018:

[0001193125-18-238271:notes:126]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 620 |  |  | $ | — |  |  | $ | — |  |  | $ | 620 |  |
| Time deposits and certificates of deposit |  | — |  |  | 392 |  |  | — |  |  | 392 |  |
| Total cash equivalents |  | 620 |  |  | 392 |  |  | — |  |  | 1,012 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Derivative assets |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Total assets |  | $ | 621 |  |  | $ | 405 |  |  | $ | — |  |  | $ | 1,026 |  |

[0001193125-18-238271:notes:127]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of June 30, 2017:

[0001193125-18-238271:notes:128]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 593 |  |  | $ | — |  |  | $ | — |  |  | $ | 593 |  |
| Time deposits and certificates of deposit |  | — |  |  | 581 |  |  | — |  |  | 581 |  |
| Total cash equivalents |  | 593 |  |  | 581 |  |  | — |  |  | 1,174 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets |  | $ | 594 |  |  | $ | 584 |  |  | $ | — |  | — |  | $ | 1,178 |  |

[0001193125-18-238271:notes:129]
The Company classifies items in Level 1 if the financial assets consist of securities for which quoted prices are available in an active market.

[0001193125-18-238271:notes:130]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair values of all of its cash equivalents and short-term investments. For the cash equivalents and short-term investments in the Company's portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry standard data providers or other third party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of June 29, 2018, has not found it necessary to make any adjustments to the prices obtained. The Company's derivative financial instruments are also classified within Level 2. The Company's derivative financial instruments consist of foreign currency forward exchange contracts and the TRS. The Company recognizes derivative financial instruments in its consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001193125-18-238271:notes:131]
As of June 29, 2018 and June 30, 2017, the Company had no Level 3 assets or liabilities measured at fair value on a recurring basis.

[0001193125-18-238271:notes:132]
Items Measured at Fair Value on a Non-Recurring Basis

[0001193125-18-238271:notes:133]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments primarily include cost basis investments representing those where the Company does not have the ability to exercise significant influence as well as equity method investments representing those where the Company does have the ability to exercise significant influence but does not have control. These investments are included in Other assets, net in the Consolidated Balance Sheets, and are periodically analyzed to determine whether or not there are indicators of impairment. The carrying value of the Company's strategic investments at June 29, 2018 and June 30, 2017 totaled $118 million and $125 million, respectively, and consisted primarily of privately held equity securities without a readily determinable fair value.

[0001193125-18-238271:notes:134]
During the fiscal years 2018, 2017 and 2016, the Company determined that certain of its equity investments accounted for under the cost method were other-than-temporarily impaired, and recognized charges of $11 million, $25 million and $13 million, respectively, in order to write down the carrying amount of the investments to its estimated fair value. Since there was no active market for the equity securities of the investee, the Company estimated fair value of the investee by analyzing the underlying cash flows and future prospects of the investee. These amounts were recorded in Other, net in the Consolidated Statements of Operations.

[0001193125-18-238271:notes:135]
As of June 30, 2017, the Company had $77 million of held for sale land and buildings (collectively, the "Properties") primarily in Asia included in Other current assets on the Consolidated Balance Sheet. The respective Properties to be sold met the criteria to be classified as held for sale in fiscal year 2017. Depreciation related to the Properties ceased as of the date these were determined to be held for sale. During fiscal year 2017, the Company recorded impairment charges of $35 million in order to write down the carrying amount of such properties to their estimated fair values less costs to sell. The impairment charges were recorded in Operating expenses in the Consolidated Statements of Operations. During fiscal year 2018, the Company completed the sale of certain of these properties and recorded a gain of approximately $25 million, which was included in Restructuring and other, net in the Consolidated Statements of Operations. As of June 29, 2018, the Company had one Property held at $26 million, that continues to be held-for-sale and included in Other current assets on the Consolidated Balance Sheet. No impairment charge was recorded in fiscal year 2018. The fair value of the Property was measured using inputs such as comparable market data for similar land sale transactions adjusted for differences in comparable properties to derive the estimated fair value of the subject property and the cost approach valuation techniques for building as part of the analysis. The fair value measurement was categorized as Level 3 as significant unobservable inputs were used in the valuation analysis.

[0001193125-18-238271:notes:136]
Other Fair Value Disclosures

[0001193125-18-238271:notes:137]
The Company's investment in debt security, classified as held-to-maturity, represents shares of non-convertible preferred stock of K.K. Pangea for the acquisition of Toshiba Memory Corporation by a consortium of investors led by Bain Capital Private Equity. This debt security has a maturity date of six years and is classified as Investment in debt security on the Company's Consolidated Balance Sheet. The debt security is recorded at amortized cost and its fair value approximates the carrying value at June 29, 2018. The fair value was determined utilizing Level 2 inputs such as discount rates and yield terms of similar types of securities issued by comparable companies.

[0001193125-18-238271:notes:138]
The Company's debt is carried at amortized cost. The fair value of the Company's debt is derived using the closing price of the same debt instruments as of the date of valuation, which takes into account the yield curve, interest rates and other observable inputs. Accordingly, these fair value measurements are categorized as Level 2. The following table presents the fair value and amortized cost of the Company's debt in order of maturity:

[0001193125-18-238271:notes:139]
|  |  | June 29, 2018 |  | June 30, 2017 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 499 |  |  | $ | 501 |  |  | $ | 710 |  |  | $ | 726 |  |
| 4.250% Senior Notes due March 2022 |  | 749 |  |  | 743 |  |  | 748 |  |  | 765 |  |
| 4.75% Senior Notes due June 2023 |  | 951 |  |  | 942 |  |  | 951 |  |  | 987 |  |
| 4.875% Senior Notes due March 2024 |  | 497 |  |  | 489 |  |  | 497 |  |  | 511 |  |
| 4.75% Senior Notes due January 2025 |  | 975 |  |  | 936 |  |  | 975 |  |  | 984 |  |
| 4.875% Senior Notes due June 2027 |  | 695 |  |  | 650 |  |  | 695 |  |  | 698 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 441 |  |  | 489 |  |  | 488 |  |
|  |  | $ | 4,855 |  |  | $ | 4,702 |  |  | $ | 5,065 |  |  | $ | 5,159 |  |
| Less: debt issuance costs |  | (36 | ) |  | — |  |  | (44 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 4,819 |  |  | $ | 4,702 |  |  | $ | 5,021 |  |  | $ | 5,159 |  |
| Less: current portion of long-term debt, net of debt issuance costs |  | (499 | ) |  | (501 | ) |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 4,320 |  |  | $ | 4,201 |  |  | $ | 5,021 |  |  | $ | 5,159 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001193125-18-238271:notes:140]
Foreign Currency Remeasurement and Translation.    The U.S. dollar is the functional currency for the majority of the Company's foreign operations. Monetary assets and liabilities denominated in foreign currencies are remeasured into the functional currency of the subsidiary at the balance sheet date. The gains and losses from the remeasurement of foreign currency denominated balances into the functional currency of the subsidiary are included in Other, net on the Company's Consolidated Statements of Operations. The Company’s subsidiaries that use the U.S. dollar as their functional currency remeasure monetary assets and liabilities at exchange rates in effect at the end of each period, and nonmonetary assets and liabilities at historical rates.

[0001193125-18-238271:notes:141]
The Company had $3 million, $9 million and $3 million in remeasurement losses in fiscal years 2018, 2017 and 2016, respectively.

[0001193125-18-238271:notes:142]
The Company translates the assets and liabilities of its non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recognized in foreign currency translation included in Accumulated other comprehensive loss, which is a component of shareholders’ equity.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-18-238271:notes:143]
Goodwill and Other Intangible Assets

[0001193125-18-238271:notes:144]
Goodwill

[0001193125-18-238271:notes:145]
The changes in the carrying amount of goodwill are as follows:

[0001193125-18-238271:notes:146]
| (Dollars in millions) | Amount |
| As of July 1, 2016 | $ | 1,237 |  |
| Goodwill acquired | — |  |
| Goodwill disposed | — |  |
| Foreign currency translation effect | 1 |  |
| As of June 30, 2017 | $ | 1,238 |  |
| Goodwill acquired | — |  |
| Goodwill disposed | (1 | ) |
| Foreign currency translation effect | — |  |
| As of June 29, 2018 | $ | 1,237 |  |

[0001193125-18-238271:notes:147]
Other Intangible Assets

[0001193125-18-238271:notes:148]
Other intangible assets consist primarily of existing technology, customer relationships and trade names acquired in business combinations. Intangibles are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization is charged to Operating expenses in the Consolidated Statements of Operations.

[0001193125-18-238271:notes:149]
In fiscal years 2018, 2017 and 2016, amortization expense for other intangible assets was $111 million, $168 million and $174 million, respectively.

[0001193125-18-238271:notes:150]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of June 29, 2018, is set forth in the following table:

[0001193125-18-238271:notes:151]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 256 |  |  | $ | (145 | ) |  | $ | 111 |  |  | 2.5 years |
| Customer relationships |  | 89 |  |  | (42 | ) |  | 47 |  |  | 4.0 years |
| Trade name |  | 17 |  |  | (13 | ) |  | 4 |  |  | 1.3 years |
| Other intangible assets |  | 45 |  |  | (19 | ) |  | 26 |  |  | 3.0 years |
| Total amortizable other intangible assets |  | $ | 407 |  |  | $ | (219 | ) |  | $ | 188 |  |  | 2.9 years |

[0001193125-18-238271:notes:152]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of June 30, 2017 is set forth in the following table:

[0001193125-18-238271:notes:153]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 280 |  |  | $ | (112 | ) |  | $ | 168 |  |  | 3.6 years |
| Customer relationships |  | 487 |  |  | (395 | ) |  | 92 |  |  | 3.4 years |
| Trade name |  | 27 |  |  | (19 | ) |  | 8 |  |  | 2.1 years |
| Other intangible assets |  | 29 |  |  | (16 | ) |  | 13 |  |  | 2.6 years |
| Total amortizable other intangible assets |  | $ | 823 |  |  | $ | (542 | ) |  | $ | 281 |  |  | 3.4 years |

[0001193125-18-238271:notes:154]
As of June 29, 2018, expected amortization expense for other intangible assets for each of the next five years and thereafter is as follows:

[0001193125-18-238271:notes:155]
| (Dollars in millions) |  | Amount |
| 2019 |  | $ | 77 |  |
| 2020 |  | 57 |  |
| 2021 |  | 29 |  |
| 2022 |  | 20 |  |
| 2023 |  | 5 |  |
| Thereafter |  | — |  |
|  |  | $ | 188 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001193125-18-238271:notes:156]
Assessment of Goodwill and Other Long-lived Assets for Impairment.  The Company accounts for goodwill in accordance with ASC Topic 350 ("ASC 350"), Intangibles - Goodwill and Other. The Company performs a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. If it is determined in the qualitative assessment that the fair value of a reporting unit is more likely than not below its carrying amount, including goodwill, then the Company will perform a quantitative impairment test. The quantitative goodwill impairment test is performed by comparing the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit's goodwill over its fair value is recognized as an impairment loss, limited to the total amount of goodwill allocated to that reporting unit.

[0001193125-18-238271:notes:157]
The Company tests other long-lived assets, including property, equipment and leasehold improvements and other intangible assets subject to amortization, for recoverability whenever events or changes in circumstances indicate that the carrying value of those assets may not be recoverable. The Company performs a recoverability test to assess the recoverability of an asset group. If the recoverability test indicates that the carrying value of the asset group is not recoverable, the Company will estimate the fair value of the asset group and the excess of the carrying value over the fair value is allocated pro rata to derive the adjusted carrying value of assets in the asset group. The adjusted carrying value of each asset in the asset group is not reduced below its fair value.

[0001193125-18-238271:notes:158]
The Company tests other intangible assets not subject to amortization whenever events occur or circumstances change, such as declining financial performance, deterioration in the environment in which the entity operates or deteriorating macroeconomic conditions that have a negative effect on future expected earnings and cash flows that could affect significant inputs used to determine the fair value of the indefinite-lived intangible asset.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-18-238271:notes:159]
Income Taxes

[0001193125-18-238271:notes:160]
Income (loss) before income taxes consisted of the following:

[0001193125-18-238271:notes:161]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 29, 2018 |  | June 30, 2017 |  | July 1, 2016 |
| U.S. |  | $ | (29 | ) |  | $ | (22 | ) |  | $ | — |  |
| Non-U.S. |  | 1,447 |  |  | 837 |  |  | 274 |  |
|  |  | $ | 1,418 |  |  | $ | 815 |  |  | $ | 274 |  |

[0001193125-18-238271:notes:162]
The provision for income taxes consisted of the following:

[0001193125-18-238271:notes:163]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 29, 2018 |  | June 30, 2017 |  | July 1, 2016 |
| Current income tax expense: |  |  |  |  |  |  |
| U.S. Federal |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |
| U.S. State |  | 5 |  |  | 1 |  |  | 2 |  |
| Non-U.S. |  | 38 |  |  | 39 |  |  | 25 |  |
| Total Current |  | 43 |  |  | 40 |  |  | 28 |  |
| Deferred income tax expense (benefit): |  |  |  |  |  |  |
| U.S. Federal |  | 201 |  |  | (5 | ) |  | — |  |
| U.S. State |  | — |  |  | — |  |  | — |  |
| Non-U.S. |  | (8 | ) |  | 8 |  |  | (2 | ) |
| Total Deferred |  | 193 |  |  | 3 |  |  | (2 | ) |
| Provision for income taxes |  | $ | 236 |  |  | $ | 43 |  |  | $ | 26 |  |

[0001193125-18-238271:notes:164]
On December 22, 2017, the Tax Act was enacted into law in the United States. The Tax Act significantly revises U.S. corporate income tax law by, among other things, lowering U.S. corporate income tax rates from 35% to 21%, implementing a territorial tax system, and imposing a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries.

[0001193125-18-238271:notes:165]
Pursuant to SEC Staff Accounting Bulletin (“SAB”) 118 (regarding the application of ASC 740 associated with the enactment of the Tax Act), the Company recorded an adjusted tax expense of approximately $204 million during fiscal year 2018, to re-measure its net U.S. deferred tax assets at the newly enacted 21% income tax rate. This tax expense increased the Company’s effective tax rate by approximately 14%. The Company also does not expect the one-time transition tax to have a material impact on the Company’s consolidated financial statements due to an overall accumulated earnings deficit in its non-U.S. subsidiaries for which the transition tax applies. The Company has considered SAB 118 and believes the accounting under ASC 740 for the change to the U.S. statutory tax rate to its deferred tax balances and the one-time transition tax under the Tax Act is complete and appropriately reflected in the financial statements during fiscal year 2018.

[0001193125-18-238271:notes:166]
For all other provisions relating to the Tax Act, the Company continues to evaluate the impact of the Tax Act’s various highly complex domestic and international provisions. The other U.S. tax changes, including limitations on various business deductions such as executive compensation under Internal Revenue Code §162(m), are not expected to impact the Company’s tax expense in the short-term due to the Company’s large net operating loss and tax credit carryovers and associated valuation allowance. The Tax Act’s new international rules, including Global Intangible Low-Taxed Income (“GILTI”), Foreign Derived Intangible Income (“FDII”), and Base Erosion Anti-Avoidance Tax (“BEAT”) are generally effective in tax years beginning after December 31, 2017. These provisions are not expected to have a material impact on the Company’s consolidated financial statements. However, these preliminary assessments and analyses are provisional and are subject to change as additional interpretive guidance is issued. The Company will complete its analysis within fiscal year 2019 which is consistent with the guidance provided in SAB 118.

[0001193125-18-238271:notes:167]
Deferred income taxes reflect the net tax effects of temporary differences between the carrying amounts of assets and liabilities for financial reporting purposes and the amounts used for income tax purposes. The Company recorded an adjustment for its U.S. deferred income taxes as of June 29, 2018 to reflect the reduction in the U.S. statutory tax rate from 35% to 21% resulting from the Tax Act. The significant components of the Company's deferred tax assets and liabilities were as follows:

[0001193125-18-238271:notes:168]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 29, 2018 |  | June 30, 2017 |
| Deferred tax assets |  |  |  |  |
| Accrued warranty |  | $ | 55 |  |  | $ | 85 |  |
| Inventory carrying value adjustments |  | 30 |  |  | 43 |  |
| Receivable allowance |  | 13 |  |  | 19 |  |
| Accrued compensation and benefits |  | 64 |  |  | 99 |  |
| Depreciation |  | 96 |  |  | 109 |  |
| Restructuring accruals |  | 5 |  |  | (1 | ) |
| Other accruals and deferred items |  | 34 |  |  | 51 |  |
| Net operating losses and tax credit carry-forwards |  | 1,361 |  |  | 1,224 |  |
| Other assets |  | 10 |  |  | 11 |  |
| Total deferred tax assets |  | 1,668 |  |  | 1,640 |  |
| Valuation allowance |  | (1,221 | ) |  | (966 | ) |
| Net deferred tax assets |  | 447 |  |  | 674 |  |
| Deferred tax liabilities |  |  |  |  |
| Unremitted earnings of certain non-U.S. entities |  | (7 | ) |  | (7 | ) |
| Acquisition-related items |  | (30 | ) |  | (65 | ) |
| Total deferred tax liabilities |  | (37 | ) |  | (72 | ) |
| Deferred taxes on intra-entity transactions |  | — |  |  | 2 |  |
| Total net deferred tax assets |  | $ | 410 |  |  | $ | 604 |  |
| As Reported on the Balance Sheet |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 417 |  |  | $ | 609 |  |
| Other non-current liabilities |  | (7 | ) |  | (5 | ) |
| Total net deferred income taxes |  | $ | 410 |  |  | $ | 604 |  |

[0001193125-18-238271:notes:169]
During fiscal year 2018, the Company adopted two accounting pronouncements with tax implications - ASU 2016-09 (related to employee share-based payment accounting) and ASU 2016-16 (related to intra-entity transfers of assets). There was no material impact to the Company's financial statements as a result of the adoptions. The adoption of ASU 2016-09 resulted in an increase in gross deferred tax assets relating to net operating losses of approximately $0.6 billion offset by an equivalent increase in valuation allowance. For additional detail about both ASU’s, please refer to Note 1. Basis of Presentation and Summary of Significant Accounting Policies.

[0001193125-18-238271:notes:170]
The deferred tax asset valuation allowance increased by $255 million in fiscal year 2018, mainly due to the adoption of ASC 2016-09 offset by the U.S. corporate tax rate reduction as a result of the Tax Act, and decreased by $18 million in fiscal year 2017.

[0001193125-18-238271:notes:171]
At June 29, 2018, the Company recorded $410 million of net deferred tax assets. The realization of most of these deferred tax assets is primarily dependent on the Company's ability to generate sufficient U.S. and certain non-U.S. taxable income in future periods. Although realization is not assured, the Company's management believes it is more likely than not that these deferred tax assets will be realized. The amount of deferred tax assets considered realizable, however, may increase or decrease in subsequent periods when the Company re-evaluates the underlying basis for its estimates of future U.S. and certain non-U.S. taxable income.

[0001193125-18-238271:notes:172]
At June 29, 2018, the Company had U.S. federal, state and non-U.S. tax net operating loss carryforwards of approximately $3.2 billion, $1.8 billion and $54 million, respectively, which will expire at various dates beginning in fiscal year 2019, if not utilized. Net operating loss carryforwards of approximately $42 million are scheduled to expire in fiscal year 2019. At June 29, 2018, the Company had U.S. federal and state tax credit carryforwards of $485 million and $114 million, respectively, which will expire at various dates beginning in fiscal year 2019, if not utilized.

[0001193125-18-238271:notes:173]
As of June 29, 2018, approximately $501 million and $99 million of the Company's total U.S. net operating loss and tax credit carryforwards, respectively, are subject to annual limitations ranging from $1 million to $45 million pursuant to U.S. tax law.

[0001193125-18-238271:notes:174]
For purposes of the reconciliation between the provision for income taxes at the statutory rate and the effective tax rate, the Irish statutory rate of 25% was applied as follows:

[0001193125-18-238271:notes:175]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 29, 2018 |  | June 30, 2017 |  | July 1, 2016 |
| Provision at statutory rate |  | $ | 355 |  |  | $ | 204 |  |  | $ | 69 |  |
| Net U.S. federal and state income taxes |  | 5 |  |  | 1 |  |  | 3 |  |
| Permanent differences |  | (2 | ) |  | 19 |  |  | 10 |  |
| Effect of U.S. corporate tax rate change |  | 524 |  |  | — |  |  | — |  |
| Valuation allowance |  | (322 | ) |  | (11 | ) |  | (1 | ) |
| Non-U.S. losses with no tax benefits |  | — |  |  | 17 |  |  | 1 |  |
| Non-U.S. earnings taxed at other than statutory rate |  | (322 | ) |  | (186 | ) |  | (37 | ) |
| Reversal of previously recorded taxes |  | (6 | ) |  | (4 | ) |  | (19 | ) |
| Other individually immaterial items |  | 4 |  |  | 3 |  |  | — |  |
| Provision for income taxes |  | $ | 236 |  |  | $ | 43 |  |  | $ | 26 |  |

[0001193125-18-238271:notes:176]
A substantial portion of the Company's operations in Malaysia, Singapore and Thailand operate under various tax incentive programs, which expire in whole or in part at various dates through 2027. Certain tax incentives may be extended if specific conditions are met. The net impact of these tax incentive programs was to increase the Company's net income by approximately $269 million in fiscal year 2018 ($0.92 per share, diluted), to increase the Company's net income by approximately $163 million in fiscal year 2017 ($0.54 per share, diluted), and to increase the Company's net income by approximately $67 million in fiscal year 2016 ($0.22 per share, diluted).

[0001193125-18-238271:notes:177]
The Company consists of an Irish tax resident parent holding company with various U.S. and non-U.S. subsidiaries that operate in multiple non-Irish taxing jurisdictions. The amount of temporary differences (including undistributed earnings) related to outside basis differences in the stock of non-Irish resident subsidiaries considered indefinitely reinvested outside of Ireland for which Irish income taxes have not been provided as of June 29, 2018, was approximately $1.8 billion. If such amounts were remitted to Ireland as a dividend, it is likely that tax at 25%, or approximately $450 million would result.

[0001193125-18-238271:notes:178]
As of June 29, 2018 and June 30, 2017, the Company had approximately $60 million and $74 million, respectively, of unrecognized tax benefits excluding interest and penalties. The amount of unrecognized tax benefits that, if recognized, would impact the effective tax rate are $60 million and $74 million as of June 29, 2018 and June 30, 2017, respectively, subject to certain future valuation allowance offsets.

[0001193125-18-238271:notes:179]
The following table summarizes the activity related to the Company's gross unrecognized tax benefits:

[0001193125-18-238271:notes:180]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 29, 2018 |  | June 30, 2017 |  | July 1, 2016 |
| Balance of unrecognized tax benefits at the beginning of the year |  | $ | 74 |  |  | $ | 76 |  |  | $ | 89 |  |
| Gross increase for tax positions of prior years |  | 2 |  |  | 2 |  |  | 12 |  |
| Gross decrease for tax positions of prior years |  | (3 | ) |  | (7 | ) |  | (8 | ) |
| Gross increase for tax positions of current year |  | 7 |  |  | 16 |  |  | 11 |  |
| Gross decrease for tax positions of current year |  | — |  |  | — |  |  | — |  |
| Settlements |  | — |  |  | — |  |  | — |  |
| Lapse of statutes of limitation |  | (20 | ) |  | (13 | ) |  | (27 | ) |
| Non-U.S. exchange gain |  | — |  |  | — |  |  | (1 | ) |
| Balance of unrecognized tax benefits at the end of the year |  | $ | 60 |  |  | $ | 74 |  |  | $ | 76 |  |

[0001193125-18-238271:notes:181]
It is the Company's policy to include interest and penalties related to unrecognized tax benefits in the provision for income taxes on the Consolidated Statements of Operations. During fiscal year 2018, the Company recognized net income tax benefit for interest and penalties of $2 million, as compared to net income tax benefit of $1 million during fiscal year 2017, and income tax benefit of $8 million during fiscal year 2016. As of June 29, 2018, the Company had $2 million of accrued interest and penalties related to unrecognized tax benefits compared to $4 million in fiscal year 2017.

[0001193125-18-238271:notes:182]
During the 12 months beginning June 30, 2018, the Company expects that its unrecognized tax benefits could be reduced by approximately $18 million as a result of the expiration of certain statutes of limitation.

[0001193125-18-238271:notes:183]
The Company is required to file U.S. federal, U.S. state and non-U.S. income tax returns. The Company is no longer subject to examination of its U.S. federal income tax returns for years prior to fiscal year 2015. With respect to U.S. state and non-U.S. income tax returns, the Company is generally no longer subject to tax examination for years ending prior to fiscal year 2007.


## us-gaap:IncomeTaxPolicyTextBlock

[0001193125-18-238271:notes:184]
Accounting for Income Taxes. The Company accounts for income taxes pursuant to ASC Topic 740 ("ASC 740"), Income Taxes. During fiscal year 2018, the Company adopted ASU 2016-16, Income Taxes: Intra-Entity Transfers of Assets Other Than Inventory (ASC Topic 740). In applying ASC 740, the Company makes certain estimates and judgments in determining income tax expense for financial statement purposes. These estimates and judgments occur in the calculation of tax credits, recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for income tax and financial statement purposes, as well as tax liabilities associated with uncertain tax positions. The calculation of tax liabilities involves uncertainties in the application of complex tax rules and the potential for future adjustment of the Company’s uncertain tax positions by the Internal Revenue Service or other tax jurisdictions. If estimates of these tax liabilities are greater or less than actual results, an additional tax benefit or provision will result. The deferred tax assets the Company records each period depend primarily on the Company’s ability to generate future taxable income in the United States and certain non-U.S. jurisdictions. Each period, the Company evaluates the need for a valuation allowance for its deferred tax assets and, if necessary, adjusts the valuation allowance so that net deferred tax assets are recorded only to the extent the Company concludes it is more likely than not that these deferred tax assets will be realized. If the Company’s outlook for future taxable income changes significantly, the Company’s assessment of the need for, and the amount of a valuation allowance may also change.


## us-gaap:InventoryPolicyTextBlock

[0001193125-18-238271:notes:185]
Inventory.  The Company accounts for inventory in accordance with Accounting Standard Codification ("ASC") Topic 330, Inventory. During fiscal year 2018, the Company adopted Accounting Standard Update ("ASU") No. 2015-11, Inventory: Simplifying the Measurement of Inventory (ASC topic 330). Inventories are valued at the lower of cost (using the first-in, first-out method) and net realizable value. Net realizable value is based upon the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation.


## us-gaap:InvestmentPolicyTextBlock

[0001193125-18-238271:notes:186]
Investment in Debt Security and Payment-in-Kind (“PIK”) Income. The Company has debt investment in non-convertible preferred stock of K.K. Pangea. The Company determined the appropriate classification of such investment at the time of purchase and will re-evaluate such designation at each balance sheet date. The Company classified the investment as held-to-maturity as it has the positive intent and ability to hold the security until maturity. This held-to-maturity investment is carried at amortized cost and recorded as Investment in debt security on the Consolidated Balance Sheets.

[0001193125-18-238271:notes:187]
Transaction costs incurred by the Company to acquire this investment are capitalized and amortized as a reduction of interest income on the Consolidated Statements of Operations over the respective term of the investment. The investment contains a PIK income provision, which represents contractual interest that is due at maturity, and is accrued and recorded as Interest income each reporting period and added to the carrying value of the Investment in debt security.

[0001193125-18-238271:notes:188]
The Company assesses whether an other-than-temporary impairment loss on the debt security, including the accrued PIK income, has occurred due to a decline in fair value or other market conditions. If the fair value of the debt security is below amortized cost and it is more likely than not that the Company will not be able to recover the amortized cost bases before its stated maturity, the Company will record an other-than-temporary impairment charge to Other, net in the Consolidated Statements of Operations.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-18-238271:notes:189]
The fair value and amortized cost of the Company's investments classified as available-for-sale at June 29, 2018 by remaining contractual maturity were as follows:

[0001193125-18-238271:notes:190]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 1,016 |  |  | $ | 1,016 |  |
| Due in 1 to 5 years |  | — |  |  | — |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | — |  |  | — |  |
| Total |  | $ | 1,016 |  |  | $ | 1,016 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001193125-18-238271:notes:191]
Legal, Environmental and Other Contingencies

[0001193125-18-238271:notes:192]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001193125-18-238271:notes:193]
Intellectual Property Litigation

[0001193125-18-238271:notes:194]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al.-On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “‘635 patent”) and U.S. Patent No. 5,638,267 (the “‘267 patent”), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants were infringing U.S. Patent No. 6,314,473 (the “‘473 patent”). The district court ruled in 2010 that the ‘267 patent was out of the case.

[0001193125-18-238271:notes:195]
On August 16, 2011, the district court granted in part and denied in part the Company’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-18-238271:notes:196]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation (“Enova”) filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995 (the “‘995 patent”), “Cryptographic Device,” and U.S. Patent No. 7,900,057 (the “‘057 patent”), “Cryptographic Serial ATA Apparatus and Method.” The Company believes the claims are without merit and intends to vigorously defend this case. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the ‘995 and ‘057 patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office.  On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ‘057 patent are held unpatentable.  On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 patent are held unpatentable. Enova appealed PTAB’s decisions on the ‘995 patent and the ‘057 patent to the U.S. Court of Appeals for the Federal Circuit. On March 20, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the ‘995 patent. On September 6, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the ‘057 patent. On November 27, 2017, Enova filed a petition for writ of certiorari with the U.S. Supreme Court challenging the court of appeals’ decision on the ‘057 Patent. The Supreme Court denied the petition on April 30, 2018. On May 9, 2018, the district court entered a final judgment of dismissal with prejudice and on the merits on all claims asserted by Enova in its complaint, with each party to bear its own costs and attorneys’ fees. In light of the district court's final judgment of dismissal, the Company does not expect to incur a loss in this matter.

[0001193125-18-238271:notes:197]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al.-On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. No trial date has been set. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.

[0001193125-18-238271:notes:198]
Environmental Matters

[0001193125-18-238271:notes:199]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001193125-18-238271:notes:200]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001193125-18-238271:notes:201]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001193125-18-238271:notes:202]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001193125-18-238271:notes:203]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001193125-18-238271:notes:204]
Other Matters

[0001193125-18-238271:notes:205]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-18-238271:notes:206]
Recently Issued Accounting Pronouncements

[0001193125-18-238271:notes:207]
In May 2014, August 2015, April 2016, May 2016 and December 2016, the Financial Accounting Standards Board (“FASB”) issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, ASU 2016-12 (ASC Topic 606) Revenue from Contracts with Customers, Narrow-Scope Improvements and Practical Expedients, and ASU 2016-20 (ASC Topic 606) Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company is required to adopt the guidance in the first quarter of fiscal year 2019. This standard may be applied retrospectively to all prior periods presented, or retrospectively with a cumulative adjustment to retained earnings in the year of adoption (“modified retrospective transition approach”). The Company will adopt this standard in the first quarter of fiscal year 2019 utilizing the modified retrospective transition approach.

[0001193125-18-238271:notes:208]
The Company has substantially completed its evaluation and expects the adoption of the new standard will result in the recognition of revenue when the products are delivered (sell-in basis) to certain direct retail customers and customers in certain indirect retail channels which are currently being recognized on a sell-through basis. Accordingly, the Company will estimate appropriate accruals for the variable consideration (e.g. rebates) related to customer incentives on these arrangements. On the date of initial adoption, the Company will remove the deferred income that would have been subsequently recognized on a sell-through basis and record estimates of the accruals for variable consideration through a cumulative adjustment to accumulated deficit. The Company believes that these changes will not have a material impact on the Company’s consolidated financial statements and internal controls over financial reporting.

[0001193125-18-238271:notes:209]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments—Overall Recognition and Measurement of Financial Assets and Financial Liabilities, as amended by ASU 2018-03, Financial Instruments—Overall: Technical Correction and Improvements, issued in February 2018. The amendments in these ASUs require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The Company is required to adopt the guidance in the first quarter of fiscal year 2019. Early adoption is permitted for only certain portions of the ASU. The Company expects to elect the measurement alternative for measurement of equity investments, defined as cost, less impairments, if any, plus or minus changes resulting from observable price changes in orderly transactions for an identical or similar investment in the same issuer (the “Price Changes”) until the equity investments’ fair value becomes readily determinable. The amount of the impact to equity investments will depend on any Price Changes observed after adoption in the first quarter of fiscal year 2019.

[0001193125-18-238271:notes:210]
In February 2016 and July 2018, the FASB issued ASU 2016-02 (ASC Topic 842), Leases, ASU 2018-10, Codification Improvements to Topic 842, Leases, ASU 2018-11, Leases (ASC Topic 842), Targeted Improvements, respectively. ASC Topic 842 amends a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The Company is required to adopt this guidance in the first quarter of fiscal year 2020. Early adoption is permitted. The Company is in the process of assessing the impact of these ASUs on its consolidated financial statements.

[0001193125-18-238271:notes:211]
In June 2016, the FASB issued ASU 2016-13 (ASC Topic 326), Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held. The Company is required to adopt this guidance in the first quarter of fiscal year 2021. Early adoption in the first quarter of fiscal year 2020 is permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

[0001193125-18-238271:notes:212]
In January 2017, the FASB issued ASU 2017-01 (ASC Topic 805), Business Combinations: Clarifying the Definition of a Business. The amendments in this ASU change the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company plans to adopt the guidance in the first quarter of fiscal year 2019. The Company does not expect the adoption of this ASU will have a material impact on its consolidated financial statements.

[0001193125-18-238271:notes:213]
In May 2017, the FASB issued ASU 2017-09 (ASC Topic 718), Stock Compensation: Scope of Modification Accounting. The amendments in this ASU provide guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting. The Company plans to adopt the guidance in the first quarter of fiscal year 2019. The Company does not expect the adoption of this ASU will have a material impact on its consolidated financial statements.

[0001193125-18-238271:notes:214]
In February 2018, the FASB issued ASU 2018-02 (ASC Topic 220), Income Statement—Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”) and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. The Company is required to adopt the guidance in the first quarter of fiscal year 2020. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

[0001193125-18-238271:notes:215]
Recently Adopted Accounting Pronouncements

[0001193125-18-238271:notes:216]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. This ASU became effective and was adopted by the Company in the September 2017 quarter on a prospective basis. The adoption of this guidance had no material impact on the Company’s consolidated financial statements and disclosures.

[0001193125-18-238271:notes:217]
In March 2016, the FASB issued ASU 2016-09 (ASC Topic 718), Stock Compensation—Improvements to Employee Share-Based Payment Accounting. The amendments in this ASU are intended to simplify several areas of accounting for share-based compensation arrangements, including the income tax consequences, classification on the consolidated statement of cash flows and treatment of forfeitures. This ASU became effective and was prospectively adopted by the Company in the September 2017 quarter. Upon adoption, excess tax benefits or deficiencies from share-based award activity are reflected in the Consolidated Statements of Operations as a component of the provision for income taxes, whereas they previously were recognized in the Shareholders’ equity in the Consolidated Balance Sheets. The Company also elected to continue to account for share-based compensation expense net of estimated forfeitures. The adoption of this ASU resulted in an increase in deferred tax assets relating to net operating losses of approximately $0.6 billion, offset by an equivalent increase in the valuation allowance with no impact to retained earnings. The adoption of this guidance had no material impact on the Company’s consolidated financial statements and disclosures.

[0001193125-18-238271:notes:218]
In October 2016, the FASB issued ASU 2016-16 (ASC Topic 740), Income Taxes: Intra-Entity Transfers of Assets Other Than Inventory. The amendments in this ASU require the recognition of the income tax consequences for intra-entity transfers of assets other than inventory when the transfer occurs. The Company elected to early adopt this ASU in the September 2017 quarter on a modified retrospective basis with no material impact on the Company’s consolidated financial statements and disclosures.

[0001193125-18-238271:notes:219]
In August 2017, the FASB issued ASU 2017-12 (ASC Topic 815), Derivatives and Hedging, Targeted Improvements to Accounting for Hedging Activities. The amendments in this ASU simplify the application of hedge accounting guidance and more closely aligning financial reporting for hedging relationships with economic results of an entity's risk management activities. The Company early adopted this ASU in the June 2018 quarter. The adoption of this guidance had no material impact on the Company's consolidated financial statements and disclosures.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001193125-18-238271:notes:220]
Basis of Presentation and Summary of Significant Accounting Policies

[0001193125-18-238271:notes:221]
Organization

[0001193125-18-238271:notes:222]
Seagate Technology plc (the "Company") is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”), solid state hybrid drives (“SSHDs”) and storage subsystems.

[0001193125-18-238271:notes:223]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high capacity hard disk drive and a smaller SSD acting as a cache to improve performance of frequently accessed data.

[0001193125-18-238271:notes:224]
The Company's HDD products are designed for mission critical and nearline applications in enterprise servers and storage systems; edge compute/client compute applications, where its products are designed primarily for desktop and mobile computing; and edge non-compute/client non-compute applications, where its products are designed for a wide variety of end user devices such as portable external storage systems, surveillance systems, digital video recorders (“DVRs”), network-attached storage (“NAS”) and gaming consoles. The Company's SSD products mainly include serial attached SCSI ("SAS") and Non-Volatile Memory Express ("NVMe") SSDs.

[0001193125-18-238271:notes:225]
The Company's cloud systems and solutions portfolio includes modular original equipment manufacturer (“OEM”) storage systems and scale-out storage servers.

[0001193125-18-238271:notes:226]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Accordingly, fiscal years 2018, 2017 and 2016 were comprised of 52 weeks ended on June 29, 2018, June 30, 2017 and July 1, 2016, respectively. All references to years in these Notes to Consolidated Financial Statements represent fiscal years unless otherwise noted. Fiscal year 2019 will be comprised of 52 weeks and will end on June 28, 2019.

[0001193125-18-238271:notes:227]
Allowances for Doubtful Accounts.    The Company maintains an allowance for uncollectible accounts receivable based upon expected collectability. This reserve is established based upon historical trends, global macroeconomic conditions and an analysis of specific exposures. The provision for doubtful accounts is recorded as a charge to Marketing and administrative expense on the Company's Consolidated Statements of Operations.

[0001193125-18-238271:notes:228]
Property, Equipment and Leasehold Improvements.    Property, equipment and leasehold improvements are stated at cost. Equipment and buildings are depreciated using the straight-line method over the estimated useful lives of the assets. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated life of the asset or the remaining term of the lease. The costs of additions and substantial improvements to property, equipment and leasehold improvements, which extend the economic life of the underlying assets, are capitalized. The cost of maintenance and repairs to property, equipment and leasehold improvements is expensed as incurred.

[0001193125-18-238271:notes:229]
Establishment of Warranty Accruals.    The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company's warranty provision considers estimated product failure rates and trends (including the timing of product returns during the warranty periods), and estimated repair or replacement costs related to product quality issues, if any. The Company also exercises judgment in estimating its ability to sell certain repaired products. Should actual experience in any future period differ significantly from its estimates, the Company's future results of operations could be materially affected.

[0001193125-18-238271:notes:230]
Revenue Recognition, Sales Returns and Allowances, and Sales Incentive Programs.    The Company's revenue recognition policy complies with ASC Topic 605 ("ASC 605"), Revenue Recognition. Revenue from sales of products, including sales to distribution customers, is generally recognized when title and risk of loss has passed to the buyer, which typically occurs upon shipment from the Company or third party's warehouse facilities, persuasive evidence of an arrangement exists, including a fixed or determinable price to the buyer, and when collectability is reasonably assured. Revenue from sales of products to certain direct retail customers and to customers in certain indirect retail channels is recognized on a sell-through basis.

[0001193125-18-238271:notes:231]
The Company records estimated product returns at the time of shipment. The Company also estimates reductions to revenue for sales incentive programs, such as price protection, and volume incentives, and records such reductions when revenue is recorded. The Company establishes certain distributor and OEM sales programs aimed at increasing customer demand. For OEM sales, rebates are typically based on an OEM customer's volume of purchases from Seagate or other agreed upon rebate programs. For the distribution channel, these programs typically involve rebates related to a distributor's level of sales, order size, advertising or point of sale activity and price protection adjustments. The Company provides for these obligations at the time that revenue is recorded based on estimated requirements. Marketing development programs are recorded as a reduction to revenue.

[0001193125-18-238271:notes:232]
Shipping and Handling.    The Company includes costs related to shipping and handling in Cost of revenue in the Consolidated Statements of Operations for all periods presented.

[0001193125-18-238271:notes:233]
Share-Based Compensation.    The Company accounts for share-based compensation under the provisions of ASC Topic 718 (ASC 718), Compensation-Stock Compensation. During fiscal year 2018, the Company adopted ASU 2016-09, Stock Compensation—Improvements to Employee Share-Based Payment Accounting (ASC Topic 718). The Company has elected to apply the with-and-without method to assess the realization of related excess tax benefits. The Company also elected to continue to account for share-based compensation expense net of estimated forfeitures.

[0001193125-18-238271:notes:234]
Concentrations

[0001193125-18-238271:notes:235]
Concentration of Credit Risk.    The Company's customer base for disk drive products is concentrated with a small number of customers. The Company does not generally require collateral or other security to support accounts receivable. To reduce credit risk, the Company performs ongoing credit evaluations on its customers' financial condition. The Company establishes an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information. Dell Inc. accounted for more than 10% of the Company's accounts receivable as of June 29, 2018 and June 30, 2017.

[0001193125-18-238271:notes:236]
Financial instruments that potentially subject the Company to concentrations of credit risk consist primarily of cash equivalents, investments and foreign currency forward exchange contracts. The Company mitigates concentrations of credit risk in its investments through diversifications, by investing in highly-rated securities or major multinational companies.

[0001193125-18-238271:notes:237]
In entering into foreign currency forward exchange contracts, the Company assumes the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and the Company has not incurred and does not expect any losses as a result of counterparty defaults.

[0001193125-18-238271:notes:238]
Supplier Concentration.    Certain of the raw materials, components and equipment used by the Company in the manufacture of its products are available from single-sourced vendors. Shortages could occur in these essential materials and components due to an interruption of supply or increased demand in the industry. If the Company were unable to procure certain materials, components or equipment at acceptable prices, it would be required to reduce its manufacturing operations, which could have a material adverse effect on its results of operations. In addition, the Company may make prepayments to certain suppliers or enter into minimum volume commitment agreements. Should these suppliers be unable to deliver on their obligations or experience financial difficulty, the Company may not be able to recover these prepayments.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-18-238271:notes:239]
Guarantees

[0001193125-18-238271:notes:240]
Indemnifications of Officers and Directors

[0001193125-18-238271:notes:241]
On May 4, 2009,  Seagate Technology, an exempted company incorporated with limited liability under the laws of the Cayman Islands (“Seagate-Cayman”), then the parent company, entered into a new form of indemnification agreement (the “Revised Indemnification Agreement”) with its officers and directors of Seagate-Cayman and its subsidiaries (each, an “Indemnitee”). The Revised Indemnification Agreement provides indemnification in addition to any of Indemnitee's indemnification rights under Seagate-Cayman's Articles of Association, applicable law or otherwise, and indemnifies an Indemnitee for certain expenses (including attorneys' fees), judgments, fines and settlement amounts actually and reasonably incurred by him or her in any action or proceeding, including any action by or in the right of Seagate-Cayman or any of its subsidiaries, arising out of his or her service as a director, officer, employee or agent of Seagate-Cayman or any of its subsidiaries or of any other entity to which he or she provides services at Seagate-Cayman's request. However, an Indemnitee shall not be indemnified under the Revised Indemnification Agreement for (i) any fraud or dishonesty in the performance of Indemnitee's duty to Seagate-Cayman or the applicable subsidiary of Seagate-Cayman or (ii) Indemnitee's conscious, intentional or willful failure to act honestly, lawfully and in good faith with a view to the best interests of Seagate-Cayman or the applicable subsidiary of Seagate-Cayman. In addition, the Revised Indemnification Agreement provides that Seagate-Cayman will advance expenses incurred by an Indemnitee in connection with enforcement of the Revised Indemnification Agreement or with the investigation, settlement or appeal of any action or proceeding against him or her as to which he or she could be indemnified.

[0001193125-18-238271:notes:242]
On July 3, 2010, pursuant to a corporate reorganization, the common shareholders of Seagate-Cayman became ordinary shareholders of Seagate Technology plc (the "Company") and Seagate-Cayman became a wholly owned subsidiary of the Company, as described more fully in the Current Report on Form 8-K filed by the Company on July 6, 2010 (the “Redomestication”). On July 27, 2010, in connection with the Redomestication, the Company, as sole shareholder of Seagate-Cayman, approved a form of deed of indemnity (the “Deed of Indemnity”), which provides for the indemnification by Seagate-Cayman of any director, officer, employee or agent of the Company, Seagate-Cayman or any subsidiary of the Company (each, a “Deed Indemnitee”), in addition to any indemnification rights of a Deed Indemnitee under the Company's Articles of Association, applicable law or otherwise, with a similar scope to the Revised Indemnification Agreement. Seagate-Cayman entered into Deeds of Indemnity with certain Deed Indemnitees effective as of July 3, 2010 and continues to enter into Deeds of Indemnity with additional Deed Indemnitees from time to time.

[0001193125-18-238271:notes:243]
The nature of these indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay on behalf of its officers and directors. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the Company's consolidated financial statements with respect to these indemnification obligations.

[0001193125-18-238271:notes:244]
Intellectual Property Indemnification Obligations

[0001193125-18-238271:notes:245]
The Company has entered into agreements with customers and suppliers that include limited intellectual property indemnification obligations that are customary in the industry. These guarantees generally require the Company to compensate the other party for certain damages and costs incurred as a result of third party intellectual property claims arising from these transactions. The nature of the intellectual property indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay to its customers and suppliers. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the Company's consolidated financial statements with respect to these indemnification obligations.

[0001193125-18-238271:notes:246]
Product Warranty

[0001193125-18-238271:notes:247]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation.  Changes in the Company's product warranty liability during the fiscal years ended June 29, 2018, June 30, 2017 and July 1, 2016 were as follows:

[0001193125-18-238271:notes:248]
|  |  | Fiscal Years Ended |
| (In millions) |  | June 29, 2018 |  | June 30, 2017 |  | July 1, 2016 |
| Balance, beginning of period |  | $ | 233 |  |  | $ | 206 |  |  | $ | 248 |  |
| Warranties issued |  | 147 |  |  | 131 |  |  | 125 |  |
| Repairs and replacements |  | (106 | ) |  | (114 | ) |  | (152 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | (37 | ) |  | 10 |  |  | (17 | ) |
| Warranty liability assumed from acquisitions |  | — |  |  | — |  |  | 2 |  |
| Balance, end of period |  | $ | 237 |  |  | $ | 233 |  |  | $ | 206 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-18-238271:notes:249]
The components of property, equipment and leasehold improvements, net were as follows:

[0001193125-18-238271:notes:250]
| (Dollars in millions) |  | Useful Lifein Years |  | June 29, 2018 |  | June 30, 2017 |
| Land and land improvements |  |  |  | $ | 55 |  |  | $ | 54 |  |
| Equipment |  | 3 – 5 |  | 7,472 |  |  | 7,536 |  |
| Buildings and leasehold improvements |  | Up to 30 |  | 1,805 |  |  | 1,899 |  |
| Construction in progress |  |  |  | 193 |  |  | 144 |  |
|  |  |  |  | 9,525 |  |  | 9,633 |  |
| Less: accumulated depreciation and amortization |  |  |  | (7,733 | ) |  | (7,758 | ) |
| Property, equipment and leasehold improvements, net |  |  |  | $ | 1,792 |  |  | $ | 1,875 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-18-238271:notes:251]
Restructuring and Exit Costs

[0001193125-18-238271:notes:252]
During fiscal years 2018, 2017 and 2016, the Company recorded restructuring charges of $89 million, $178 million and $175 million, respectively, comprised primarily of charges related to workforce reduction costs and facilities and other exit costs associated with the restructuring of its workforce. The Company’s significant restructuring plans are described below. All restructuring charges are reported in Restructuring and other, net on the Consolidated Statements of Operations.

[0001193125-18-238271:notes:253]
December 2017 Plan - On December 8, 2017, the Company committed to a restructuring plan (the “December 2017 Plan”) to reduce its cost structure. The December 2017 Plan included reducing the Company's global headcount by approximately 500 employees. The December 2017 Plan was substantially completed by the end of fiscal year 2018.

[0001193125-18-238271:notes:254]
July 2017 Plan - On July 25, 2017, the Company committed to a restructuring plan (the “July 2017 Plan”) to reduce its cost structure. The July 2017 Plan included reducing the Company’s global headcount by approximately 600 employees. The July 2017 Plan was substantially completed during fiscal year 2018.

[0001193125-18-238271:notes:255]
March 2017 Plan - On March 9, 2017, the Company committed to a restructuring plan (the “March 2017 Plan”) in connection with the continued consolidation of its global footprint. The Company closed its design center in Korea, resulting in the reduction of the Company’s headcount by approximately 300 employees. The March 2017 Plan was substantially completed by the end of fiscal year 2017.

[0001193125-18-238271:notes:256]
July 2016 Plan - On July 11, 2016, the Company committed to a restructuring plan (the “July 2016 Plan”) for continued consolidation of its global footprint across Asia, EMEA and the Americas. The July 2016 Plan included reducing worldwide headcount by approximately 6,500 employees. The July 2016 Plan was substantially completed during fiscal year 2018.

[0001193125-18-238271:notes:257]
The following table summarizes the Company's restructuring activities under all of the Company’s active restructuring plans for fiscal years 2018, 2017 and 2016:

[0001193125-18-238271:notes:258]
|  |  | December 2017 Plan |  | July 2017 Plan |  | March 2017 Plan |  | July 2016 Plan |  | Other Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at July 3, 2015 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 11 |  |  | $ | 8 |  |  | $ | 19 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 151 |  |  | 24 |  |  | 175 |  |
| Cash payments |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (113 | ) |  | (18 | ) |  | (131 | ) |
| Adjustments |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | (1 | ) |  | — |  |
| Accrual balances at July 1, 2016 |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 50 |  |  | 13 |  |  | 63 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | — |  |  | 28 |  |  | 3 |  |  | 72 |  |  | 20 |  |  | 31 |  |  | 13 |  |  | 167 |  |
| Cash payments |  | — |  |  | — |  |  | — |  |  | — |  |  | (29 | ) |  | (3 | ) |  | (57 | ) |  | (18 | ) |  | (74 | ) |  | (17 | ) |  | (198 | ) |
| Adjustments |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 7 |  |  | — |  |  | (1 | ) |  | 4 |  |  | 11 |  |
| Accrual balances at June 30, 2017 |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 22 |  |  | 2 |  |  | 6 |  |  | 13 |  |  | 43 |  |
| Restructuring charges |  | 28 |  |  | 6 |  |  | 38 |  |  | 4 |  |  | — |  |  | — |  |  | 1 |  |  | 15 |  |  | 13 |  |  | — |  |  | 105 |  |
| Cash payments |  | (21 | ) |  | (2 | ) |  | (37 | ) |  | (3 | ) |  | (1 | ) |  | — |  |  | (23 | ) |  | (16 | ) |  | (9 | ) |  | (3 | ) |  | (115 | ) |
| Adjustments |  | (2 | ) |  | — |  |  | (1 | ) |  | — |  |  | 2 |  |  | — |  |  | 2 |  |  | (1 | ) |  | 1 |  |  | 8 |  |  | 9 |  |
| Accrual balances at June 29, 2018 |  | 5 |  |  | 4 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 2 |  |  | — |  |  | 11 |  |  | 18 |  |  | 42 |  |
| Total costs incurred to date as of June 29, 2018 |  | $ | 26 |  |  | $ | 6 |  |  | $ | 37 |  |  | $ | 4 |  |  | $ | 31 |  |  | $ | 3 |  |  | $ | 82 |  |  | $ | 34 |  |  | $ | 240 |  |  | $ | 59 |  |  | $ | 522 |  |
| Total expected costs to be incurred as of June 29, 2018 |  | $ | 1 |  |  | $ | 2 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 5 |  |

[0001193125-18-238271:notes:259]
Of the accrued restructuring balance of $42 million at June 29, 2018, $26 million is included in Accrued expenses and $16 million is included in Other non-current liabilities in the Company's Consolidated Balance Sheet. Of the accrued restructuring balance of $43 million at June 30, 2017, $38 million is included in Accrued expenses and $5 million is included in Other non-current liabilities in the Company's Consolidated Balance Sheet.

[0001193125-18-238271:notes:260]
In addition to charges above, during fiscal year 2017, the Company committed to sell certain land and buildings primarily in Asia as part of the March 2017 and July 2016 plans, which accordingly met the criteria to be classified as assets held for sale and were reclassified to Other current assets on the Consolidated Balance Sheets at that time. During fiscal year 2018, the Company sold certain of these properties, which were previously classified as assets held for sale and recognized a gain of approximately $25 million, which was included in Restructuring and other, net in the Consolidated Statements of Operations. Please refer to Note 9. Fair Value for additional information.


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001193125-18-238271:notes:261]
The following table provides details of the accounts receivable, net balance sheet item:

[0001193125-18-238271:notes:262]
| (Dollars in millions) |  | June 29, 2018 |  | June 30, 2017 |
| Accounts receivable |  | $ | 1,188 |  |  | $ | 1,204 |  |
| Allowance for doubtful accounts |  | (4 | ) |  | (5 | ) |
| Account receivable, net |  | $ | 1,184 |  |  | $ | 1,199 |  |


## us-gaap:ScheduleOfAccountsPayableAndAccruedLiabilitiesTableTextBlock

[0001193125-18-238271:notes:263]
The following table provides details of the accrued expenses balance sheet item:

[0001193125-18-238271:notes:264]
| (Dollars in millions) |  | June 29, 2018 |  | June 30, 2017 |
| Dividends payable |  | $ | 181 |  |  | $ | 184 |  |
| Other accrued expenses |  | 417 |  |  | 466 |  |
| Total |  | $ | 598 |  |  | $ | 650 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-18-238271:notes:265]
The components of AOCI, net of tax, were as follows:

[0001193125-18-238271:notes:266]
| (Dollars in millions) |  | UnrealizedGains (Losses)on Cash FlowHedges |  | UnrealizedGains (Losses)on MarketableSecurities |  | UnrealizedGains (Losses)on Post-Retirement Plans |  | ForeignCurrencyTranslationAdjustments |  | Total |
| Balance at July 1, 2016 |  | $ | (1 | ) |  | $ | — |  |  | $ | (7 | ) |  | $ | (17 | ) |  | $ | (25 | ) |
| Other comprehensive income (loss) before reclassifications |  | (3 | ) |  | — |  |  | — |  |  | 5 |  |  | 2 |  |
| Amounts reclassified from AOCI |  | 4 |  |  | — |  |  | 2 |  |  | — |  |  | 6 |  |
| Other comprehensive income (loss) |  | 1 |  |  | — |  |  | 2 |  |  | 5 |  |  | 8 |  |
| Balance at June 30, 2017 |  | — |  |  | — |  |  | (5 | ) |  | (12 | ) |  | (17 | ) |
| Other comprehensive income (loss) before reclassifications |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Amounts reclassified from AOCI |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Balance at June 29, 2018 |  | $ | — |  |  | $ | — |  |  | $ | (4 | ) |  | $ | (12 | ) |  | $ | (16 | ) |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-18-238271:notes:267]
The following table provides details of the inventory balance sheet item:

[0001193125-18-238271:notes:268]
| (Dollars in millions) |  | June 29, 2018 |  | June 30, 2017 |
| Raw materials and components |  | $ | 329 |  |  | $ | 350 |  |
| Work-in-process |  | 347 |  |  | 257 |  |
| Finished goods |  | 377 |  |  | 375 |  |
| Total inventories |  | $ | 1,053 |  |  | $ | 982 |  |


## us-gaap:ScheduleOfRestrictedCashAndCashEquivalentsTextBlock

[0001193125-18-238271:notes:269]
The following table provides a summary of cash, cash equivalents and restricted cash reported within the Consolidated Balance Sheets that reconciles to the corresponding amount in the Consolidated Statements of Cash Flows:

[0001193125-18-238271:notes:270]
| (Dollars in millions) |  | June 29, 2018 |  | June 30, 2017 |  | July 1, 2016 |  | June 3, 2015 |
| Cash and cash equivalents |  | $ | 1,853 |  |  | $ | 2,539 |  |  | $ | 1,125 |  |  | $ | 2,479 |  |
| Restricted cash included in Other current assets |  | 4 |  |  | 4 |  |  | 7 |  |  | 7 |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  | $ | 1,857 |  |  | $ | 2,543 |  |  | $ | 1,132 |  |  | $ | 2,486 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-18-238271:notes:271]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 29, 2018 |  | June 30, 2017 |  | July 1, 2016 |
| Revenue from external customers (a): |  |  |  |  |  |  |
| Singapore |  | $ | 5,445 |  |  | $ | 5,070 |  |  | $ | 5,354 |  |
| United States |  | 3,719 |  |  | 3,535 |  |  | 3,376 |  |
| The Netherlands |  | 1,598 |  |  | 1,501 |  |  | 1,813 |  |
| Other |  | 422 |  |  | 665 |  |  | 617 |  |
| Consolidated |  | $ | 11,184 |  |  | $ | 10,771 |  |  | $ | 11,160 |  |
| Long-lived assets(b): |  |  |  |  |  |  |
| United States |  | $ | 565 |  |  | $ | 643 |  |  | $ | 743 |  |
| Singapore |  | 600 |  |  | 570 |  |  | 580 |  |
| Thailand |  | 426 |  |  | 414 |  |  | 349 |  |
| Malaysia |  | 82 |  |  | 100 |  |  | 195 |  |
| China |  | 45 |  |  | 58 |  |  | 110 |  |
| Other |  | 130 |  |  | 148 |  |  | 244 |  |
| Consolidated |  | $ | 1,848 |  |  | $ | 1,933 |  |  | $ | 2,221 |  |

[0001193125-18-238271:notes:272]
| (a) | Revenue is attributed to countries based on the bill from location. |

[0001193125-18-238271:notes:273]
| (b) | Long-lived assets exclude intangible assets, goodwill, investment in debt security and deferred income taxes. Prior year amounts have been adjusted to conform to the current year presentation. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-18-238271:notes:274]
Business Segment and Geographic Information

[0001193125-18-238271:notes:275]
The Company has concluded that its manufacture and distribution of storage solutions constitutes one reporting segment. The Company's manufacturing operations are based on technology platforms that are used to produce various storage and systems solutions that serve multiple applications and markets. The Company's main technology platforms are primarily focused around areal density of media and read/write head technologies. In addition, the Company also invests in certain other technology platforms including motors, servo formatting read/write channels, solid state and other technologies. The Company has determined that its Chief Executive Officer is the Company's chief operating decision maker ("CODM") as he is responsible for reviewing and approving investments in the Company's technology platforms and manufacturing infrastructure.

[0001193125-18-238271:notes:276]
In fiscal year 2018, no customer accounted for more than 10% of consolidated revenue. In fiscal years 2017 and 2016, Dell Inc. accounted for approximately 10% and 12% of consolidated revenue, respectively. No other customer accounted for more than 10% of consolidated revenue in any year presented.

[0001193125-18-238271:notes:277]
The following table summarizes the Company's operations by geographic area:


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-18-238271:notes:278]
Shareholders' Equity

[0001193125-18-238271:notes:279]
Share Capital

[0001193125-18-238271:notes:280]
The Company's authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 287,170,363 shares were outstanding as of June 29, 2018, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of June 29, 2018.

[0001193125-18-238271:notes:281]
Ordinary shares - Holders of ordinary shares are entitled to receive dividends when and as declared by the Company's board of directors (the "Board of Directors"). Upon any liquidation, dissolution, or winding up of the Company, after required payments are made to holders of preferred shares, any remaining assets of the Company will be distributed ratably to holders of the preferred and ordinary shares. Holders of shares are entitled to one vote per share on all matters upon which the ordinary shares are entitled to vote, including the election of directors.

[0001193125-18-238271:notes:282]
Preferred shares - The Company may issue preferred shares in one or more series, up to the authorized amount, without shareholder approval. The Board of Directors is authorized to establish from time to time the number of shares to be included in each series, and to fix the rights, preferences and privileges of the shares of each wholly unissued series and any of its qualifications, limitations or restrictions. The Board of Directors can also increase or decrease the number of shares of a series, but not below the number of shares of that series then outstanding, without any further vote or action by the shareholders.

[0001193125-18-238271:notes:283]
The Board of Directors may authorize the issuance of preferred shares with voting or conversion rights that could harm the voting power or other rights of the holders of the ordinary shares. The issuance of preferred shares, while providing flexibility in connection with possible acquisitions and other corporate purposes, could, among other things, have the effect of delaying, deferring or preventing a change in control of the Company and might harm the market price of its ordinary shares and the voting and other rights of the holders of ordinary shares.

[0001193125-18-238271:notes:284]
Repurchases of Equity Securities

[0001193125-18-238271:notes:285]
All repurchases are effected as redemptions in accordance with the Company's Articles of Association.

[0001193125-18-238271:notes:286]
As of June 29, 2018, $0.9 billion remained available for repurchase under the existing repurchase authorization limit.

[0001193125-18-238271:notes:287]
The following table sets forth information with respect to repurchases of the Company's ordinary shares during fiscal years 2018, 2017 and 2016:

[0001193125-18-238271:notes:288]
| (In millions) |  | Number ofSharesRepurchased |  | Dollar Valueof SharesRepurchased |
| Cumulative repurchased through July 3, 2015 |  | 304 |  |  | $ | 8,485 |  |
| Repurchased in fiscal year 2016 |  | 24 |  |  | 1,146 |  |
| Cumulative repurchased through July 1, 2016 |  | 328 |  |  | 9,631 |  |
| Repurchased in fiscal year 2017(a) |  | 13 |  |  | 487 |  |
| Cumulative repurchased through June 30, 2017 |  | 341 |  |  | 10,118 |  |
| Repurchased in fiscal year 2018(a) |  | 11 |  |  | 384 |  |
| Cumulative repurchased through June 29, 2018 |  | 352 |  |  | $ | 10,502 |  |

[0001193125-18-238271:notes:289]
_______________________________

[0001193125-18-238271:notes:290]
(a)	For fiscal years 2018 and 2017, includes net share settlements of $23 million and $27 million, for 1 million and 1 million shares in connection with tax withholding related to vesting of restricted stock units, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001193125-18-238271:notes:291]
Subsequent Events

[0001193125-18-238271:notes:292]
Planned Leadership Transition

[0001193125-18-238271:notes:293]
As previously announced on July 30, 2018, David H. Morton, Jr., Executive Vice President and Chief Financial Officer, will leave the Company on August 3, 2018. The Company will be initiating a search for a successor CFO and, following Mr. Morton's departure, Kathryn R. Scolnick, the Company's Senior Vice President of Finance, Corporate Communications and Treasury, will serve as Interim Chief Financial Officer and Geraldine Hottier-Fayon, the Company's Vice President, Finance and Corporate Controller, will serve as Interim Principal Accounting Officer.

[0001193125-18-238271:notes:294]
Dividend Declared

[0001193125-18-238271:notes:295]
On July 30, 2018, the Company's Board of Directors declared a quarterly cash dividend of $0.63 per share, which will be payable on October 3, 2018 to shareholders of record as of the close of business on September 19, 2018.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-18-238271:notes:296]
Balance Sheet Information

[0001193125-18-238271:notes:297]
Available-for-sale Securities

[0001193125-18-238271:notes:298]
As of June 29, 2018, the Company's Other current assets included $4 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001193125-18-238271:notes:299]
As of June 29, 2018, the Company had no material available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months.  The Company determined no available-for-sale securities were other-than-temporarily impaired as of June 29, 2018.

[0001193125-18-238271:notes:300]
As of June 30, 2017, the Company's Other current assets included $4 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001193125-18-238271:notes:301]
As of June 30, 2017, the Company had no available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months.  The Company determined no available-for-sale securities were other-than-temporarily impaired as of June 30, 2017.

[0001193125-18-238271:notes:302]
Cash, Cash Equivalents and Restricted Cash

[0001193125-18-238271:notes:303]
Accounts Receivable, net

[0001193125-18-238271:notes:304]
Inventories

[0001193125-18-238271:notes:305]
Property, Equipment and Leasehold Improvements, net

[0001193125-18-238271:notes:306]
Depreciation expense, which includes amortization of leasehold improvements, was $487 million, $581 million and $641 million for fiscal years 2018, 2017 and 2016, respectively. Interest on borrowings related to eligible capital expenditures is capitalized as part of the cost of the qualified assets and amortized over the estimated useful lives of the assets. During fiscal years 2018, 2017 and 2016, the Company capitalized interest of $1 million, $4 million and $13 million, respectively.

[0001193125-18-238271:notes:307]
In fiscal years 2017 and 2016, the Company determined it would discontinue the use of certain manufacturing property and equipment in the short-term, and that certain other buildings, land and manufacturing property and equipment were permanently impaired. As a result, the Company recognized charges of $72 million and $53 million in fiscal years 2017 and 2016, respectively, from the write-off and accelerated depreciation of these fixed assets, including $35 million impairment on land and buildings in fiscal year 2017, classified as held for sale under Other current assets in the Consolidated Balance Sheet. Please refer to Note 9. Fair Value for more details. In fiscal year 2017, total charges of $35 million, $35 million and $2 million was recorded to Cost of revenue, Product development and Marketing and administrative, respectively, in the Consolidated Statement of Operations. In fiscal year 2016, the entire amount of $53 million was recorded in Cost of revenue in the Consolidated Statement of Operations. In fiscal year 2018, the Company recognized a charge of $7 million from the write-off and accelerated depreciation of certain fixed assets, of which $1 million, $4 million and $2 million was recorded to Cost of revenue, Product development and Marketing and administrative, respectively, in the Consolidated Statement of Operations.

[0001193125-18-238271:notes:308]
Investment in Debt Security

[0001193125-18-238271:notes:309]
On May 31, 2018, the Company invested approximately $1.3 billion in non-convertible preferred stock of K.K. Pangea for the acquisition of Toshiba Memory Corporation with a consortium of investors led by Bain Capital Private Equity. The investment, with a contractual maturity of six years, is accounted for as a held-to-maturity debt security, carried at cost and adjusted for amortization of transaction costs into interest income. Additionally, the debt security has a contractual PIK income which will be paid in cash upon redemption of the investment. PIK income computed at the contractual rate is accrued into Interest income in the Consolidated Statement of Operations and added to the carrying value of the Investment in debt security on the Consolidated Balance Sheet. In  fiscal year 2018, the PIK income earned was $5 million. As of June 29, 2018, no impairment was identified and the fair value of the investment was determined to approximate its carrying value at amortized cost.

[0001193125-18-238271:notes:310]
Accrued Expenses

[0001193125-18-238271:notes:311]
Accumulated Other Comprehensive Income (Loss) (“AOCI”)
