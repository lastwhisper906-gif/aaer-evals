# STX notes — 0001137789-25-000075


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001137789-25-000075:notes:1]
[same as prior period, unchanged from 0001137789-25-000020:notes:1]

[0001137789-25-000075:notes:2]
[same as prior period, unchanged from 0001137789-25-000020:notes:2]

[0001137789-25-000075:notes:3]
[same as prior period, unchanged from 0001137789-25-000020:notes:3]

[0001137789-25-000075:notes:4]
[same as prior period, unchanged from 0001137789-25-000020:notes:4]

[0001137789-25-000075:notes:5]
[same as prior period, unchanged from 0001137789-25-000020:notes:5]

[0001137789-25-000075:notes:6]
[same as prior period, unchanged from 0001137789-25-000020:notes:6]

[0001137789-25-000075:notes:7]
[same as prior period, unchanged from 0001137789-25-000020:notes:7]

[0001137789-25-000075:notes:8]
[same as prior period, unchanged from 0001137789-25-000020:notes:8]

[0001137789-25-000075:notes:9]
[same as prior period, unchanged from 0001137789-25-000020:notes:9]

[0001137789-25-000075:notes:10]
The Company’s Consolidated Financial Statements for the fiscal year ended June 28, 2024 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 2, 2024. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 28, 2024, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and nine months ended March 28, 2025 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 27, 2025.

[0001137789-25-000075:notes:11]
[same as prior period, unchanged from 0001137789-25-000020:notes:11]

[0001137789-25-000075:notes:12]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and nine months ended March 28, 2025 and March 29, 2024 consisted of 13 and 39 weeks, respectively. Fiscal years 2025 and 2024 both comprise 52 weeks and end on June 27, 2025 and June 28, 2024, respectively. The fiscal quarters ended March 28, 2025, December 27, 2024 and March 29, 2024, are also referred to herein as the “March 2025 quarter”, the “December 2024 quarter” and the “March 2024 quarter”, respectively.

[0001137789-25-000075:notes:13]
[same as prior period, unchanged from 0001137789-25-000020:notes:13]

[0001137789-25-000075:notes:14]
[same as prior period, unchanged from 0001137789-25-000020:notes:14]

[0001137789-25-000075:notes:15]
Recently Adopted Accounting Pronouncements

[0001137789-25-000075:notes:16]
In September 2022, the Financial Accounting Standards Board (FASB) issued ASU 2022-04 (ASC Subtopic 405-50), Disclosure of Supplier Finance Program Obligations. This ASU requires disclosure of key terms of the outstanding supplier finance programs and a rollforward of the related obligations. The Company adopted the disclosure requirement on rollforward information in the quarter ended September 27, 2024. Refer to “Note 2. Balance Sheet Information” for more details.

[0001137789-25-000075:notes:17]
Recently Issued Accounting Pronouncements

[0001137789-25-000075:notes:18]
In November 2023, the FASB issued ASU 2023-07 (ASC Topic 280), Improvements to Reportable Segment Disclosures. This ASU improves reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The Company is required to adopt this guidance for its annual reporting in fiscal year 2025 and for interim period reporting beginning the first quarter of fiscal year 2026 on a retrospective basis. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have an impact on its Condensed Consolidated Financial Statements.

[0001137789-25-000075:notes:19]
In December 2023, the FASB issued ASU 2023-09 (ASC Topic 740), Improvements to Income Tax Disclosures. This ASU requires disaggregated income tax disclosures on the rate reconciliation and income taxes paid. The Company is required to adopt this guidance for its annual reporting in fiscal year 2026 on a prospective basis but has the option to apply it retrospectively. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have an impact on its Condensed Consolidated Financial Statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001137789-25-000075:notes:20]
[same as prior period, unchanged from 0001137789-25-000020:notes:20]

[0001137789-25-000075:notes:21]
[same as prior period, unchanged from 0001137789-25-000020:notes:21]

[0001137789-25-000075:notes:22]
| (Dollars in millions) |  | March 28, 2025 |  | June 28, 2024 |  |  |  |  |
| Cash and cash equivalents |  | $ | 814 |  |  | $ | 1,358 |  |  |  |  |  |
| Restricted cash included in Other current assets |  | 2 |  |  | 2 |  |  |  |  |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  | $ | 816 |  |  | $ | 1,360 |  |  |  |  |  |

[0001137789-25-000075:notes:23]
[same as prior period, unchanged from 0001137789-25-000020:notes:23]

[0001137789-25-000075:notes:24]
[same as prior period, unchanged from 0001137789-25-000020:notes:24]

[0001137789-25-000075:notes:25]
During the three and nine months ended March 28, 2025, the Company sold accounts receivables without recourse for cash proceeds of $122 million and $692 million, respectively. As of March 28, 2025, the total amount that remained subject to servicing by the Company was $122 million. During the three and nine months ended March 29, 2024, the Company sold accounts receivables without recourse for cash proceeds of $291 million and $873 million, respectively. As of March 29, 2024, the total amount that remained subject to servicing by the Company was $291 million.

[0001137789-25-000075:notes:26]
The discounts on accounts receivables sold were not material for the three and nine months ended March 28, 2025, and March 29, 2024, respectively.

[0001137789-25-000075:notes:27]
[same as prior period, unchanged from 0001137789-25-000020:notes:27]

[0001137789-25-000075:notes:28]
[same as prior period, unchanged from 0001137789-25-000020:notes:28]

[0001137789-25-000075:notes:29]
| (Dollars in millions) |  | March 28, 2025 |  | June 28, 2024 |
| Raw materials and components |  | $ | 474 |  |  | $ | 270 |  |
| Work-in-process |  | 813 |  |  | 831 |  |
| Finished goods |  | 185 |  |  | 138 |  |
| Total inventories, net |  | $ | 1,472 |  |  | $ | 1,239 |  |

[0001137789-25-000075:notes:30]
[same as prior period, unchanged from 0001137789-25-000020:notes:30]

[0001137789-25-000075:notes:31]
[same as prior period, unchanged from 0001137789-25-000020:notes:31]

[0001137789-25-000075:notes:32]
| (Dollars in millions) |  | March 28, 2025 |  | June 28, 2024 |
| Vendor receivables |  | $ | 134 |  |  | $ | 110 |  |
| Other current assets |  | 240 |  |  | 196 |  |
| Total |  | $ | 374 |  |  | $ | 306 |  |

[0001137789-25-000075:notes:33]
[same as prior period, unchanged from 0001137789-25-000020:notes:33]

[0001137789-25-000075:notes:34]
[same as prior period, unchanged from 0001137789-25-000020:notes:34]

[0001137789-25-000075:notes:35]
| (Dollars in millions) |  | March 28, 2025 |  | June 28, 2024 |
| Gross property, equipment and leasehold improvements |  | $ | 10,308 |  |  | $ | 10,260 |  |
| Less: accumulated depreciation and amortization |  | (8,695) |  |  | (8,646) |  |
| Property, equipment and leasehold improvements, net |  | $ | 1,613 |  |  | $ | 1,614 |  |

[0001137789-25-000075:notes:36]
During the three and nine months ended March 28, 2025, the accelerated depreciation expense recognized was immaterial.

[0001137789-25-000075:notes:37]
During the three months ended March 29, 2024, the Company did not record accelerated depreciation expense. During the nine months ended March 29, 2024, the Company recognized a charge of $13 million for the accelerated depreciation of certain fixed assets, which was recorded to Cost of revenue in the Condensed Consolidated Statements of Operations.

[0001137789-25-000075:notes:38]
[same as prior period, unchanged from 0001137789-25-000020:notes:38]

[0001137789-25-000075:notes:39]
[same as prior period, unchanged from 0001137789-25-000020:notes:39]

[0001137789-25-000075:notes:40]
| (Dollars in millions) |  | March 28, 2025 |  | June 28, 2024 |
| Dividends payable |  | $ | 153 |  |  | $ | 147 |  |
| Other accrued expenses |  | 489 |  |  | 507 |  |
| Total |  | $ | 642 |  |  | $ | 654 |  |

[0001137789-25-000075:notes:41]
[same as prior period, unchanged from 0001137789-25-000020:notes:41]

[0001137789-25-000075:notes:42]
[same as prior period, unchanged from 0001137789-25-000020:notes:42]

[0001137789-25-000075:notes:43]
[same as prior period, unchanged from 0001137789-25-000020:notes:43]

[0001137789-25-000075:notes:44]
[same as prior period, unchanged from 0001137789-25-000020:notes:44]

[0001137789-25-000075:notes:45]
|  |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 28, 2025 |  | March 29, 2024 |
| Outstanding at the beginning of the period |  | $ | 50 |  |  | $ | 51 |  |
| Added to the program during the period |  | 1,021 |  |  | 610 |  |
| Settled during the period |  | (1,063) |  |  | (593) |  |
| Outstanding at the ending of the period |  | $ | 8 |  |  | $ | 68 |  |

[0001137789-25-000075:notes:46]
[same as prior period, unchanged from 0001137789-25-000020:notes:46]

[0001137789-25-000075:notes:47]
[same as prior period, unchanged from 0001137789-25-000020:notes:47]

[0001137789-25-000075:notes:48]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at June 28, 2024 |  | $ | — |  |  |  | $ | (2) |  |  | $ | — |  |  | $ | (2) |  |
| Other comprehensive income before reclassifications |  | — |  |  |  | — |  |  | — |  |  | — |  |
| Amounts reclassified from AOCI |  | — |  |  |  | 1 |  |  | — |  |  | 1 |  |
| Other comprehensive income |  | — |  |  |  | 1 |  |  | — |  |  | 1 |  |
| Balance at March 28, 2025 |  | — |  |  |  | (1) |  |  | — |  |  | (1) |  |
| Balance at June 30, 2023 |  | 103 |  |  |  | (4) |  |  | (1) |  |  | 98 |  |
| Other comprehensive (loss) income before reclassifications |  | (13) |  |  |  | — |  |  | 1 |  |  | (12) |  |
| Amounts reclassified from AOCI |  | (90) |  |  |  | 1 |  |  | — |  |  | (89) |  |
| Other comprehensive (loss) income |  | (103) |  |  |  | 1 |  |  | 1 |  |  | (101) |  |
| Balance at March 29, 2024 |  | $ | — |  |  |  | $ | (3) |  |  | $ | — |  |  | $ | (3) |  |


## us-gaap:DebtDisclosureTextBlock

[0001137789-25-000075:notes:49]
Debt
The following table provides details of the Company’s debt as of March 28, 2025 and June 28, 2024:

[0001137789-25-000075:notes:50]
| (Dollars in millions) |  | March 28, 2025 |  | June 28, 2024 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | — |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 505 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 461 |  |  | 471 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 144 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 252 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 71 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,172 |  |  | 5,704 |  |
| Less: unamortized debt issuance costs |  | (26) |  |  | (30) |  |
| Debt, net of debt issuance costs |  | 5,146 |  |  | 5,674 |  |
| Less: current portion of long-term debt |  | — |  |  | (479) |  |
| Long-term debt, less current portion |  | $ | 5,146 |  |  | $ | 5,195 |  |

[0001137789-25-000075:notes:51]
___________________________________

[0001137789-25-000075:notes:52]
(1) All unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and Seagate Technology Holdings plc.

[0001137789-25-000075:notes:53]
2028 Exchangeable Senior Notes and related Capped Call Transactions

[0001137789-25-000075:notes:54]
2028 Notes. On September 13, 2023, Seagate HDD, in a private placement, issued $1.5 billion in aggregate principal amount of 3.50% Exchangeable Senior Notes due 2028 (the “2028 Notes”), which includes $200 million aggregate principal amount pursuant to the over-allotment option of the initial purchasers to purchase additional notes. The 2028 Notes will mature on June 1, 2028, with interest payable semi-annually on March 1 and September 1 of each year, commencing March 1, 2024.

[0001137789-25-000075:notes:55]
For the three and nine months ended March 28, 2025, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $13 million and $39 million, respectively, and immaterial amortization of debt issuance costs. For the three and nine months ended March 29, 2024, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $13 million and $29 million, respectively, and immaterial amortization of debt issuance costs.

[0001137789-25-000075:notes:56]
The entire outstanding principal amount of Term Loans A1, A2 and A3 were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in Net loss from debt transactions in the Company’s Condensed Consolidated Statements of Operations for the nine months ended March 29, 2024. In connection with the repayment of Term Loans, the Company terminated certain interest rate swap agreements. Refer to “Note 5. Derivative Financial Instruments” for more details.

[0001137789-25-000075:notes:57]
Prior to March 1, 2028, the 2028 Notes are exchangeable at the option of the holders only under the following circumstances:

[0001137789-25-000075:notes:58]
•during any calendar quarter commencing after the calendar quarter ending on December 31, 2023 (and only during such calendar quarter), if the last reported sale price of the ordinary Shares for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter is greater than or equal to 130% of the exchange price in effect on each applicable trading day;

[0001137789-25-000075:notes:59]
•during the five business day period after any ten consecutive trading day period in which the trading price per $1,000 principal amount of 2028 Notes for each trading day period was less than 98% of the product of the last reported sale price of the ordinary shares and the applicable exchange rate on such trading day; or

[0001137789-25-000075:notes:60]
•upon the occurrence of specified corporate events described in the indenture with respect to the 2028 Notes.

[0001137789-25-000075:notes:61]
On or after March 1, 2028, the 2028 Notes are exchangeable at any time at the option of the holders until the close of business on the second scheduled trading day immediately preceding the maturity date, unless the 2028 Notes have been previously redeemed or repurchased by Seagate HDD.

[0001137789-25-000075:notes:62]
Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The current exchange rate for the 2028 Notes is 12.1306 ordinary shares per $1,000 principal amount of 2028 Notes, which is equivalent to an exchange price of approximately $82.44 per share as of March 28, 2025. The exchange rate was adjusted from 12.1278 ordinary shares per $1,000 principal amount of 2028 Notes on March 19, 2025, and is subject to further adjustment pursuant to the terms of the Exchangeable Notes indenture.

[0001137789-25-000075:notes:63]
Seagate HDD may redeem the 2028 Notes at its option, in whole but not in part, if Seagate HDD or the Guarantors have, or on the next interest payment date would, become obligated to pay to the holder of any Note additional amounts as a result of certain tax-related events at a redemption price equal to 100% of the principal amount plus accrued and unpaid interest, including additional interest, if any, to, but excluding, the redemption date; provided that Seagate HDD may only redeem the 2028 Notes if: (x) Seagate HDD or the relevant Guarantor cannot avoid these obligations by taking commercially reasonable measures available to Seagate HDD or such Guarantor; and (y) Seagate HDD delivers to the Trustee an opinion of outside legal counsel of recognized standing in the relevant taxing jurisdiction attesting to such tax-related event and obligation to pay additional amounts.

[0001137789-25-000075:notes:64]
Seagate HDD also may redeem the 2028 Notes at its option on or after September 8, 2026, in whole or in part, if the last reported sale price of ordinary shares of the Company has been at least 130% of the exchange price then in effect for at least 20 trading days (whether or not consecutive), including the trading day immediately preceding the date on which Seagate HDD provides notice of redemption, during any 30 consecutive trading day period ending on, and including, the trading day immediately preceding the date on which Seagate HDD provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If Seagate HDD redeems less than all the outstanding 2028 Notes, at least $150 million aggregate principal amount of 2028 Notes must be outstanding and not subject to redemption as of the relevant notice of redemption date.

[0001137789-25-000075:notes:65]
As of March 28, 2025, the 2028 Notes were not exchangeable. Refer to “Note 10. Earnings (Loss) Per Share” for the potential dilutive impact of the 2028 Notes.

[0001137789-25-000075:notes:66]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The current cap price of the capped call transactions, which was adjusted on March 19, 2025 in accordance with the applicable capped call confirmations, is $107.801 per share. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets.

[0001137789-25-000075:notes:67]
2025 Notes

[0001137789-25-000075:notes:68]
On January 2, 2025, the entire outstanding principal amount of $479 million was repaid at par, plus accrued and unpaid interest.

[0001137789-25-000075:notes:69]
Credit Agreement

[0001137789-25-000075:notes:70]
On January 30, 2025, the Company and its subsidiary Seagate HDD Cayman (the “Borrower”), the Bank of Nova Scotia, as administrative agent, and the lenders thereto entered into a Credit Agreement (the “New Credit Agreement”) and terminated their then-existing Credit Agreement, dated as of February 20, 2019 (the “Old Credit Agreement”). As a result of terminating the Old Credit Agreement, the Company recorded an $8 million non-cash loss related to the accelerated amortization of debt issuance costs, which was included in Net loss from debt transactions in the Company’s Condensed Consolidated Statements of Operations.

[0001137789-25-000075:notes:71]
The New Credit Agreement provides for a $1.3 billion senior unsecured revolving credit facility (“Revolving Credit Facility”), the term of which is through January 30, 2030. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing. An aggregate amount of up to $150 million of the facility shall also be available for the issuance of letters of credit, and an aggregate amount of up to $50 million of the facility shall also be available for swing line loans. On March 28, 2025, no borrowings were outstanding under the New Credit Agreement.

[0001137789-25-000075:notes:72]
The loans made under the New Credit Agreement will bear interest at an Applicable Rate based on the secured overnight financing rate, or SOFR, plus a variable margin that will be determined based on the corporate credit rating of the Company. The Borrower’s obligations under the New Credit Agreement are guaranteed by the Company and certain material subsidiaries of the Company.

[0001137789-25-000075:notes:73]
The New Credit Agreement also contains a financial covenant that requires the Company to maintain a total net leverage ratio of less than or equal to 6.75 to 1.00, commencing with the fiscal quarter ending June 27, 2025 and declining over time so that the maximum permitted net leverage ratio for each fiscal quarter ending after July 2, 2027 is 4.25 to 1.00, in accordance with the terms of the New Credit Agreement. For each fiscal quarter until January 2, 2026, this net leverage ratio covenant applies only to the extent that there is any amount of revolving loans, swing line loans, or letters of credit outstanding as of the last day of the relevant fiscal quarter.

[0001137789-25-000075:notes:74]
Debt Repurchases

[0001137789-25-000075:notes:75]
During the March 2025 quarter, $14 million principal amount of the June 2029 Notes, $19 million principal amount of the July 2029 Notes, $23 million principal amount of the January 2031 Notes and $1 million principal amount of the July 2031 Notes were repurchased for cash at a discount to their principal amounts, plus accrued and unpaid interest. The Company recorded a net gain of $4 million on these repurchases during the March 2025 quarter, which was included in Net loss from debt transactions in the Company’s Condensed Consolidated Statements of Operations.

[0001137789-25-000075:notes:76]
Future Principal Payments on Long-term Debt

[0001137789-25-000075:notes:77]
At March 28, 2025, future principal payments on long-term debt were as follows (in millions):

[0001137789-25-000075:notes:78]
| Fiscal Year |  | Amount |
| Remainder of 2025 |  | $ | — |  |
| 2026 |  | — |  |
| 2027 |  | 505 |  |
| 2028 |  | 1,500 |  |
| 2029 |  | 481 |  |
| Thereafter |  | 2,707 |  |
| Total |  | $ | 5,193 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001137789-25-000075:notes:79]
[same as prior period, unchanged from 0001137789-25-000020:notes:75]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001137789-25-000075:notes:80]
[same as prior period, unchanged from 0001137789-25-000020:notes:76]

[0001137789-25-000075:notes:81]
The Company entered into certain interest rate swap agreements to convert the variable interest rate on its Term Loans to fixed interest rates. The objective of the interest rate swap agreements was to eliminate the variability of interest payment cash flows associated with the variable interest rate under the Term Loans. The Company designated the interest rate swaps as cash flow hedges. On September 13, 2023, the Company terminated its then existing interest rate swap agreements as a result of the repayment of Term Loans A1, A2 and A3 and received cash proceeds of $25 million from the counterparty. The cash proceeds are reported within Net cash provided by operating activities in the Company’s Condensed Consolidated Statements of Cash Flows as of March 29, 2024. The Company discontinued the related hedge accounting prospectively and realized a net gain of $104 million in Net gain from termination of interest rate swap in the Condensed Consolidated Statements of Operations as of March 29, 2024. Additionally, $6 million of the gains were amortized to Interest expense prior to the termination of interest rate swap in the Company’s Condensed Consolidated Statements of Operations as of March 29, 2024.

[0001137789-25-000075:notes:82]
As of March 28, 2025, the Company does not have any interest rate swap contracts.

[0001137789-25-000075:notes:83]
The Company did not record any net unrealized gain or loss on cash flow hedges as of March 28, 2025 and the net unrealized loss as of June 28, 2024 was immaterial.

[0001137789-25-000075:notes:84]
[same as prior period, unchanged from 0001137789-25-000020:notes:80]

[0001137789-25-000075:notes:85]
The following tables show the effect of the Company’s derivative instruments in the Condensed Consolidated Statements of Comprehensive Income (Loss) and the Condensed Consolidated Statements of Operations for the three and nine months ended March 28, 2025.

[0001137789-25-000075:notes:86]
|  |  |  |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | — |  |  | $ | (8) |  |
| Total return swap |  | Operating expenses |  | (5) |  |  | (1) |  |

[0001137789-25-000075:notes:87]
|  |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | $ | — |  |  | $ | — |  |  | Cost of revenue |  | $ | — |  |  | $ | — |  |  | Other, net |  | $ | — |  |  | $ | 1 |  |

[0001137789-25-000075:notes:88]
The following tables show the effect of the Company’s derivative instruments in the Condensed Consolidated Statements of Comprehensive Income (Loss) and the Condensed Consolidated Statements of Operations for the three and nine months ended March 29, 2024.

[0001137789-25-000075:notes:89]
|  |  |  |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (5) |  |  | $ | (5) |  |
| Total return swap |  | Operating expenses |  | 6 |  |  | 9 |  |

[0001137789-25-000075:notes:90]
|  |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | $ | (4) |  |  | $ | 2 |  |  | Cost of revenue |  | $ | 3 |  |  | $ | (3) |  |  | Other, net |  | $ | 1 |  |  | $ | 2 |  |
| Interest rate swap |  | — |  |  | (15) |  |  | Interest expense |  | — |  |  | (11) |  |  | Net gain from termination of interest rate swap1 |  | — |  |  | 104 |  |

[0001137789-25-000075:notes:91]
1The net gain recognized into earnings as a result of the discontinuance of interest rate swap during the nine months ended March 29, 2024.

[0001137789-25-000075:notes:92]
The gross notional and fair value of derivative instruments in the Condensed Consolidated Balance Sheets as of March 28, 2025 and June 28, 2024 were as follows:

[0001137789-25-000075:notes:93]
|  |  |  |  | As of March 28, 2025 |
|  |  |  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Outstanding Gross Notional |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | $ | 247 |  |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | — |  |
| Total return swap |  | 101 |  |  | Other current assets |  | — |  |  | Accrued expenses |  | (4) |  |
| Total derivatives |  | $ | 348 |  |  |  |  | $ | — |  |  |  |  | $ | (4) |  |

[0001137789-25-000075:notes:94]
[same as prior period, unchanged from 0001137789-25-000020:notes:90]


## us-gaap:FairValueDisclosuresTextBlock

[0001137789-25-000075:notes:95]
[same as prior period, unchanged from 0001137789-25-000020:notes:91]

[0001137789-25-000075:notes:96]
[same as prior period, unchanged from 0001137789-25-000020:notes:92]

[0001137789-25-000075:notes:97]
[same as prior period, unchanged from 0001137789-25-000020:notes:93]

[0001137789-25-000075:notes:98]
[same as prior period, unchanged from 0001137789-25-000020:notes:94]

[0001137789-25-000075:notes:99]
[same as prior period, unchanged from 0001137789-25-000020:notes:95]

[0001137789-25-000075:notes:100]
[same as prior period, unchanged from 0001137789-25-000020:notes:96]

[0001137789-25-000075:notes:101]
[same as prior period, unchanged from 0001137789-25-000020:notes:97]

[0001137789-25-000075:notes:102]
[same as prior period, unchanged from 0001137789-25-000020:notes:98]

[0001137789-25-000075:notes:103]
[same as prior period, unchanged from 0001137789-25-000020:notes:99]

[0001137789-25-000075:notes:104]
[same as prior period, unchanged from 0001137789-25-000020:notes:100]

[0001137789-25-000075:notes:105]
|  |  |  |  | March 28, 2025 |  | June 28, 2024 |
|  |  |  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Balance SheetLocation |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | Cash and cash equivalents |  | $ | 169 |  |  | $ | — |  |  | $ | — |  |  | $ | 169 |  |  | $ | 386 |  |  | $ | — |  |  | $ | — |  |  | $ | 386 |  |
| Total cash equivalents |  | 169 |  |  | — |  |  | — |  |  | 169 |  |  | 386 |  |  | — |  |  | — |  |  | 386 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | Other current assets |  | 1 |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | Other current assets |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | Other assets, net |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 15 |  |  | 15 |  |
| Derivative assets |  | Other current assets |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total assets |  |  |  | $ | 170 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 171 |  |  | $ | 387 |  |  | $ | 2 |  |  | $ | 15 |  |  | $ | 404 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | Accrued expenses |  | $ | — |  |  | $ | (4) |  |  | $ | — |  |  | $ | (4) |  |  | $ | — |  |  | $ | (1) |  |  | $ | — |  |  | $ | (1) |  |
| Total liabilities |  |  |  | $ | — |  |  | $ | (4) |  |  | $ | — |  |  | $ | (4) |  |  | $ | — |  |  | $ | (1) |  |  | $ | — |  |  | $ | (1) |  |

[0001137789-25-000075:notes:106]
As of March 28, 2025 and June 28, 2024, the Company’s Other current assets included $2 million of restricted cash equivalents held as collateral at banks for various performance obligations.

[0001137789-25-000075:notes:107]
As of March 28, 2025 and June 28, 2024, the Company had no material available-for-sale investments that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no impairment related to credit losses for available-for-sale investments for the three months ended March 28, 2025. The Company recorded a net loss of $15 million on available-for-sale investments for the nine months ended March 28, 2025, related to downward adjustments to write down the carrying amount of certain investments to their fair value.

[0001137789-25-000075:notes:108]
The fair value and amortized cost of the Company’s available-for-sale investments as of March 28, 2025 was immaterial. The fair value and amortized cost of the Company’s available-for-sale investments as of June 28, 2024 was $15 million due in 2 years.

[0001137789-25-000075:notes:109]
[same as prior period, unchanged from 0001137789-25-000020:notes:105]

[0001137789-25-000075:notes:110]
[same as prior period, unchanged from 0001137789-25-000020:notes:106]

[0001137789-25-000075:notes:111]
For the investments that are accounted for under the equity method, the Company sold certain investments for $9 million and recorded an immaterial gain for the three and nine months ended March 28, 2025. The Company sold certain investments for $5 million and recorded immaterial loss for the three months ended March 29, 2024. The Company recorded a net loss of $29 million for the nine months ended March 29, 2024, which included $25 million related to downward adjustments to write down the carrying amount of certain investments to their fair value. The adjusted carrying value of the investments accounted under the equity method amounted to $3 million and $12 million as of March 28, 2025 and June 28, 2024, respectively.

[0001137789-25-000075:notes:112]
For the investments that are accounted under the measurement alternative, the Company recorded no adjustment and a net loss of $39 million for the three and nine months ended March 28, 2025, respectively, related to downward adjustments to write down the carrying amount of certain investments to their fair value. The Company recorded no adjustment and a net loss of $14 million for the three and nine months ended March 29, 2024, respectively, related to downward adjustments to write down the carrying amount of certain investments to their fair value. As of March 28, 2025 and June 28, 2024, the carrying value of the Company’s strategic investments under the measurement alternative was $26 million and $65 million, respectively.

[0001137789-25-000075:notes:113]
[same as prior period, unchanged from 0001137789-25-000020:notes:109]

[0001137789-25-000075:notes:114]
[same as prior period, unchanged from 0001137789-25-000020:notes:110]

[0001137789-25-000075:notes:115]
|  |  | March 28, 2025 |  | June 28, 2024 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 4.75% Senior Notes due January 2025 |  | — |  |  | — |  |  | 479 |  |  | 476 |  |
| 4.875% Senior Notes due June 2027 |  | 505 |  |  | 499 |  |  | 505 |  |  | 493 |  |
| 3.50% Exchangeable Senior Notes due June 2028 |  | 1,500 |  |  | 1,833 |  |  | 1,500 |  |  | 2,070 |  |
| 4.091% Senior Notes due June 2029 |  | 461 |  |  | 455 |  |  | 471 |  |  | 459 |  |
| 3.125% Senior Notes due July 2029 |  | 144 |  |  | 129 |  |  | 163 |  |  | 139 |  |
| 8.25% Senior Notes due December 2029 |  | 500 |  |  | 532 |  |  | 500 |  |  | 537 |  |
| 4.125% Senior Notes due January 2031 |  | 252 |  |  | 231 |  |  | 275 |  |  | 245 |  |
| 3.375% Senior Notes due July 2031 |  | 71 |  |  | 61 |  |  | 72 |  |  | 58 |  |
| 8.50% Senior Notes due July 2031 |  | 500 |  |  | 532 |  |  | 500 |  |  | 538 |  |
| 9.625% Senior Notes due December 2032 |  | 750 |  |  | 847 |  |  | 750 |  |  | 855 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 477 |  |  | 489 |  |  | 472 |  |
|  |  | $ | 5,172 |  |  | $ | 5,596 |  |  | $ | 5,704 |  |  | $ | 6,342 |  |
| Less: unamortized debt issuance costs |  | (26) |  |  | — |  |  | (30) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 5,146 |  |  | $ | 5,596 |  |  | $ | 5,674 |  |  | $ | 6,342 |  |
| Less: current portion of debt, net of debt issuance costs |  | — |  |  | — |  |  | (479) |  |  | (476) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,146 |  |  | $ | 5,596 |  |  | $ | 5,195 |  |  | $ | 5,866 |  |

[0001137789-25-000075:notes:116]
[same as prior period, unchanged from 0001137789-25-000020:notes:112]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001137789-25-000075:notes:117]
[same as prior period, unchanged from 0001137789-25-000020:notes:113]

[0001137789-25-000075:notes:118]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 212,212,241 shares were outstanding as of March 28, 2025, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of March 28, 2025.

[0001137789-25-000075:notes:119]
[same as prior period, unchanged from 0001137789-25-000020:notes:115]

[0001137789-25-000075:notes:120]
All repurchases are effected as redemptions in accordance with the Company’s Constitution.
As of March 28, 2025, $1.8 billion remained available for repurchase under the existing repurchase authorization limit approved by the Board of Directors. The number of ordinary shares repurchased for tax withholding related to the vesting of equity awards was 0.4 million and the dollar value of shares repurchased was $44 million for the nine months ended March 28, 2025


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001137789-25-000075:notes:121]
[same as prior period, unchanged from 0001137789-25-000020:notes:117]

[0001137789-25-000075:notes:122]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |  |
| (Dollars in millions) |  | March 28, 2025 |  | March 29, 2024 |  | March 28, 2025 |  | March 29, 2024 |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,711 |  |  | $ | 1,236 |  |  | $ | 5,301 |  |  | $ | 3,408 |  |  |  |
| Distributors |  | 264 |  |  | 252 |  |  | 791 |  |  | 736 |  |  |  |
| Retailers |  | 185 |  |  | 167 |  |  | 561 |  |  | 520 |  |  |  |
| Total |  | $ | 2,160 |  |  | $ | 1,655 |  |  | $ | 6,653 |  |  | $ | 4,664 |  |  |  |

[0001137789-25-000075:notes:123]
| Revenue by Country (1): |  |  |  |  |  |  |  |  |  |  |
| Singapore |  | $ | 847 |  |  | $ | 834 |  |  | $ | 2,741 |  |  | $ | 2,417 |  |  |  |
| United States |  | 1,090 |  |  | 618 |  |  | 3,246 |  |  | 1,617 |  |  |  |
| The Netherlands |  | 222 |  |  | 200 |  |  | 663 |  |  | 622 |  |  |  |
| Other |  | 1 |  |  | 3 |  |  | 3 |  |  | 8 |  |  |  |
| Total |  | $ | 2,160 |  |  | $ | 1,655 |  |  | $ | 6,653 |  |  | $ | 4,664 |  |  |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001137789-25-000075:notes:124]
[same as prior period, unchanged from 0001137789-25-000020:notes:120]

[0001137789-25-000075:notes:125]
[same as prior period, unchanged from 0001137789-25-000020:notes:121]

[0001137789-25-000075:notes:126]
[same as prior period, unchanged from 0001137789-25-000020:notes:122]

[0001137789-25-000075:notes:127]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product warranty return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the nine months ended March 28, 2025 and March 29, 2024 were as follows:

[0001137789-25-000075:notes:128]
|  |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 28, 2025 |  | March 29, 2024 |
| Balance, beginning of period |  | $ | 149 |  |  | $ | 168 |  |
| Warranties issued |  | 49 |  |  | 40 |  |
| Repairs and replacements |  | (68) |  |  | (60) |  |
| Changes in liability for pre-existing warranties, including expirations |  | 4 |  |  | 8 |  |
| Balance, end of period |  | $ | 134 |  |  | $ | 156 |  |


## us-gaap:EarningsPerShareTextBlock

[0001137789-25-000075:notes:129]
[same as prior period, unchanged from 0001137789-25-000020:notes:125]

[0001137789-25-000075:notes:130]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (In millions, except per share data) |  | March 28, 2025 |  | March 29, 2024 |  | March 28, 2025 |  | March 29, 2024 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 340 |  |  | $ | 25 |  |  | $ | 981 |  |  | $ | (178) |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income (loss) per share |  | 212 |  |  | 210 |  |  | 211 |  |  | 209 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | 2 |  |  | 2 |  |  | 3 |  |  | — |  |
| 2028 Notes if-converted shares |  | 2 |  |  | 1 |  |  | 3 |  |  | — |  |
| Total shares for purposes of calculating diluted net income (loss) per share |  | 216 |  |  | 213 |  |  | 217 |  |  | 209 |  |
| Net income (loss) per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.60 |  |  | $ | 0.12 |  |  | $ | 4.65 |  |  | $ | (0.85) |  |
| Diluted |  | 1.57 |  |  | 0.12 |  |  | 4.52 |  |  | (0.85) |  |

[0001137789-25-000075:notes:131]
All potentially dilutive securities that could have an anti-dilutive effect on the calculation of the earnings per share have been excluded for the periods presented. The weighted average anti-dilutive shares that were excluded from the computation of diluted net income per share were not material for the three and nine months ended March 28, 2025, as well as for the three months ended March 29, 2024. The weighted average anti-dilutive shares that were excluded from the computation of diluted net loss per share were 7 million for the nine months ended March 29, 2024


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001137789-25-000075:notes:132]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001137789-25-000075:notes:133]
Litigation

[0001137789-25-000075:notes:134]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgment in favor of Seagate on April 19, 2022, following a jury trial. The parties filed post-trial motions with the district court, which were denied. An appeal to the Federal Circuit is pending. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

[0001137789-25-000075:notes:135]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the U.S. District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendant misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, and additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 8, 2022, the court entered an Amended Stipulation and Order of Dismissal with Prejudice to dismiss all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment under the Foreign Trade Antitrust Improvement Act (“FTAIA Motion”) against Seagate’s antitrust claims, and on October 14, 2022, the Seagate Entities filed their corresponding opposition. On May 15, 2023, the court issued a ruling that Seagate’s antitrust claims can proceed as to suspension assemblies that enter the United States but not as to suspension assembles that do not enter the United States. On July 28, 2023, the District Court initiated a reconsideration of this ruling and requested further briefing. On November 17, 2023, the Court granted NHK’s FTAIA Motion and denied Seagate’s Motion for Leave to Amend the Complaint. Seagate filed a motion on December 15, 2023 for the Court to certify the ruling for interlocutory appeal. On April 22, 2024, the District Court granted in part and denied in part Seagate’s motion to certify for interlocutory appeal the Court’s ruling on NHK’s FTAIA Motion. On May 2, 2024, Seagate filed a Petition for Permission to Appeal to the Ninth Circuit. On July 18, 2024, the United States Court of Appeals for the Ninth Circuit issued an order granting Seagate’s Petition for Permission to Appeal. The FTAIA issue is now on appeal with the Ninth Circuit.

[0001137789-25-000075:notes:136]
In re Seagate Technology Holdings plc Securities Litigation. A putative class action lawsuit alleging violations of the federal securities laws, UA Local 38 Defined Contribution Pension Plan, et al. v. Seagate Technology Holdings PLC, et al., was filed on July 10, 2023, in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The complaint alleged that it was a securities class action on behalf of all purchasers of Seagate common stock between September 15, 2020 and October 25, 2022, inclusive, and asserted claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b5-1. The complaint sought unspecified monetary damages and other relief. A second action, Public Employees’ Retirement System of Mississippi v. Seagate Technology Holdings plc, William David Mosley, and Gianluca Romano, was filed on July 26, 2023, asserting similar claims. The cases were consolidated on September 25, 2023. On October 19, 2023, plaintiffs filed an amended complaint asserting similar claims with a putative class period of September 14, 2020 through April 19, 2023. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint. On August 8, 2024, the Court granted the Company’s motion to dismiss, with leave to amend. On September 12, 2024, the Plaintiffs filed an amended complaint. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint. The Company believes that the asserted claims are without merit and intends to vigorously defend the case.

[0001137789-25-000075:notes:137]
Godo Kaisha IP Bridge 1 v. Seagate Technology LLC, Seagate Technology (US) Holding, Inc., Seagate Technology (Thailand) Limited, Seagate Singapore International Headquarters Ltd., Seagate Technology (Netherlands) B.V. On March 15, 2024, a patent infringement action was filed by Godo Kaisha IP Bridge 1 (“IP Bridge”) against Seagate in U.S. District Court for the District of Delaware. The complaint alleges patent infringement by Seagate of three U.S. patents. On June 7, 2024, Seagate filed a motion to transfer venue to Minnesota. On July 8, 2024, IP Bridge filed a First Amended Complaint alleging patent infringement by Seagate of six additional patents. IP Bridge is seeking damages as well as additional relief. On September 4, 2024, the court granted Seagate’s motion to transfer the case to the District Court of Minnesota. On October 16, 2024, Seagate filed its answer to the First Amended Complaint. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

[0001137789-25-000075:notes:138]
Environmental Matters

[0001137789-25-000075:notes:139]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air, soil and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001137789-25-000075:notes:140]
The Company has established an environmental management system and continually reviews and updates environmental policies and standard operating procedures for operations worldwide as needed. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001137789-25-000075:notes:141]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001137789-25-000075:notes:142]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001137789-25-000075:notes:143]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fail to comply with the substance restrictions, recycle content requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001137789-25-000075:notes:144]
BIS Settlement

[0001137789-25-000075:notes:145]
On April 18, 2023, the Company’s subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd (collectively, “Seagate”), entered into a settlement agreement (the “Settlement Agreement”) with the U.S. Department of Commerce’s Bureau of Industry and Security (“BIS”) that resolved BIS’ allegations regarding Seagate’s sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, Seagate agreed to pay $300 million to BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. Seagate also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the U.S. Export Administration Regulations (“EAR”), including one audit by an unaffiliated third-party consultant chosen by Seagate with expertise in U.S. export control laws, which has been completed, and two internal audits. The Settlement Agreement also included a denial order that is suspended and will be waived five years after the date of the order issued under the Settlement Agreement, provided that Seagate has made full and timely payments under the Settlement Agreement and timely completed the audit requirements. While Seagate is in compliance with and upon successful compliance in full with the terms of the Settlement Agreement, BIS agreed it will not initiate any further administrative proceedings against Seagate in connection with any violation of the EAR arising out of the transactions detailed in the Settlement Agreement.

[0001137789-25-000075:notes:146]
While Seagate believed that it complied with all relevant export control laws at the time it made the hard disk drive sales at issue, Seagate determined that engaging with BIS and settling this matter was in the best interest of the Company, its customers, and its shareholders. In determining to engage with BIS and resolve this matter through a settlement agreement, the Company considered a number of factors, including the risks and cost of protracted litigation involving the U.S. government, and the size of the potential penalty and the Company’s desire to focus on current business challenges and long-term business strategy. The Settlement Agreement includes a finding that the Company incorrectly interpreted the regulation at issue to require evaluation of only the last stage of Seagate’s hard disk drive manufacturing process rather than the entire process. As part of this settlement, Seagate has agreed not to contest BIS’ determination that the sales in question did not comply with the U.S. EAR.

[0001137789-25-000075:notes:147]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $150 million were included in Accrued expense and Other non-current liabilities, respectively, on the Condensed Consolidated Balance Sheets as of March 28, 2025. For the nine months ended March 28, 2025, $45 million was paid and reported as an outflow from operating activities in its Condensed Consolidated Statements of Cash Flows.

[0001137789-25-000075:notes:148]
Other Matters 
From time to time, arising in the normal course of business, the Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company expects to be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:CommitmentsDisclosureTextBlock

[0001137789-25-000075:notes:149]
Commitments
Unconditional Long-Term Purchase Obligations. As of March 28, 2025, the Company had unconditional long-term purchase obligations of approximately $110 million. The Company expects the commitment to be paid to total $28 million, $24 million, $12 million, $13 million and $33 million for fiscal years 2026, 2027, 2028, 2029 and thereafter respectively. In addition, the Company also had certain long-term market share based inventory purchase commitments as of March 28, 2025.


## us-gaap:SubsequentEventsTextBlock

[0001137789-25-000075:notes:150]
Subsequent Events
Acquisition

[0001137789-25-000075:notes:151]
On March 31, 2025, the Company completed the acquisition of Intevac, Inc., a supplier of thin-film processing systems, in an all-cash transaction for $4.00 per share, with cash consideration of approximately $118 million. This acquisition aligns with the Company’s strategy to integrate important components and manufacturing processes.

[0001137789-25-000075:notes:152]
Dividend Declared

[0001137789-25-000075:notes:153]
On April 29, 2025, the Board of Directors of the Company declared a quarterly cash dividend of $0.72 per share, which will be payable on July 8, 2025 to shareholders of record as of the close of business on June 25, 2025.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001137789-25-000075:notes:154]
The table below summarizes the material terms of trading arrangements adopted by any of our executive officers or directors during the March 2025 quarter. All of the trading arrangements listed below are intended to satisfy the affirmative defense of Rule 10b5-1(c).

[0001137789-25-000075:notes:155]
| Name | Title | Date of Adoption | End Date¹ | Aggregate number of ordinary shares to be sold pursuant to the trading agreement |
| James C. Lee | Senior Vice President, Chief Legal Officer and Corporate Secretary | January 24, 2025 | September 30, 2025 | 6,930 |
| David Mosley | Chief Executive Officer | February 20, 2025 | April 30, 2026 | 394,347 |
| Gianluca Romano | Executive Vice President and Chief Financial Officer | January 27, 2025 | August 29, 2025 | 51,834 |

[0001137789-25-000075:notes:156]
[same as prior period, unchanged from 0001137789-25-000020:notes:150]
