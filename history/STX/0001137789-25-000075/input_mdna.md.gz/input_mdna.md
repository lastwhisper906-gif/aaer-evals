# STX MD&A — 0001137789-25-000075


## mdna

[0001137789-25-000075:mdna:1]
[same as prior period, unchanged from 0001137789-25-000020:mdna:1]

[0001137789-25-000075:mdna:2]
The following is a discussion of the Company’s financial condition, changes in financial condition and results of operations for the fiscal quarters ended March 28, 2025, December 27, 2024 and March 29, 2024, referred to herein as the “March 2025 quarter”, the “December 2024 quarter” and the “March 2024 quarter”, respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The March 2025 quarter, December 2024 quarter and March 2024 quarter were each 13 weeks.

[0001137789-25-000075:mdna:3]
[same as prior period, unchanged from 0001137789-25-000020:mdna:3]

[0001137789-25-000075:mdna:4]
[same as prior period, unchanged from 0001137789-25-000020:mdna:4]

[0001137789-25-000075:mdna:5]
•Overview of the March 2025 quarter. Highlights of events in the March 2025 quarter that impacted our financial position.

[0001137789-25-000075:mdna:6]
•Results of Operations. Analysis of our financial results comparing the March 2025 quarter to the December 2024 quarter and the March 2024 quarter.

[0001137789-25-000075:mdna:7]
[same as prior period, unchanged from 0001137789-25-000020:mdna:7]

[0001137789-25-000075:mdna:8]
[same as prior period, unchanged from 0001137789-25-000020:mdna:8]

[0001137789-25-000075:mdna:9]
[same as prior period, unchanged from 0001137789-25-000020:mdna:9]

[0001137789-25-000075:mdna:10]
Overview of the March 2025 quarter

[0001137789-25-000075:mdna:11]
During the March 2025 quarter, we shipped 144 exabytes of HDD storage capacity. We generated revenue of approximately $2.2 billion with a gross margin of 35.2%. Our operating cash flow was $259 million and we paid $152 million in dividends. We reduced our outstanding debt by $536 million through repayment of the 2025 Notes and partial repurchase of certain senior notes.

[0001137789-25-000075:mdna:12]
[same as prior period, unchanged from 0001137789-25-000020:mdna:12]

[0001137789-25-000075:mdna:13]
During the March 2025 quarter, we experienced increased demand for our high capacity nearline drives primarily from cloud customers, offset by the typical seasonal slowdown in certain of our other end markets. Temporary supply constraints impacted our ability to fully address customer demand during the quarter. These supply constraints were due to production related challenges that were resolved during the quarter. We continue to operate in a dynamic macroeconomic environment marked by rapid shifts in trade policies that began during the March 2025 quarter and increasing geopolitical tensions. These factors may impact our business and results of operations. We will continue to monitor the situation and assess plans to mitigate future risk to the business. Over the long-term we expect our hard drive storage business to benefit from further growth in data demand, including potential demand driven by the adoption of Generative AI applications.

[0001137789-25-000075:mdna:14]
[same as prior period, unchanged from 0001137789-25-000020:mdna:14]

[0001137789-25-000075:mdna:15]
[same as prior period, unchanged from 0001137789-25-000020:mdna:15]

[0001137789-25-000075:mdna:16]
[same as prior period, unchanged from 0001137789-25-000020:mdna:16]

[0001137789-25-000075:mdna:17]
|  |  | For the Three Months Ended | For the Nine Months Ended |
| (Dollars in millions) |  | March 28, 2025 |  | December 27, 2024 |  | March 29, 2024 |  | March 28, 2025 |  | March 29, 2024 |
| Revenue |  | $ | 2,160 |  |  | $ | 2,325 |  |  | $ | 1,655 |  |  | $ | 6,653 |  |  | $ | 4,664 |  |
| Cost of revenue |  | 1,400 |  |  | 1,513 |  |  | 1,230 |  |  | 4,367 |  |  | 3,728 |  |
| Gross profit |  | 760 |  |  | 812 |  |  | 425 |  |  | 2,286 |  |  | 936 |  |
| Product development |  | 180 |  |  | 184 |  |  | 164 |  |  | 545 |  |  | 496 |  |
| Marketing and administrative |  | 139 |  |  | 139 |  |  | 116 |  |  | 407 |  |  | 329 |  |
| Restructuring and other, net |  | 10 |  |  | 1 |  |  | 2 |  |  | 12 |  |  | (27) |  |
| Income from operations |  | 431 |  |  | 488 |  |  | 143 |  |  | 1,322 |  |  | 138 |  |
| Other expense, net |  | (76) |  |  | (138) |  |  | (85) |  |  | (301) |  |  | (231) |  |
| Income (loss) before income taxes |  | 355 |  |  | 350 |  |  | 58 |  |  | 1,021 |  |  | (93) |  |
| Provision for income taxes |  | 15 |  |  | 14 |  |  | 33 |  |  | 40 |  |  | 85 |  |
| Net Income (loss) |  | $ | 340 |  |  | $ | 336 |  |  | $ | 25 |  |  | $ | 981 |  |  | $ | (178) |  |

[0001137789-25-000075:mdna:18]
|  |  | For the Three Months Ended | For the Nine Months Ended |
|  |  | March 28, 2025 |  | December 27, 2024 |  | March 29, 2024 |  | March 28, 2025 |  | March 29, 2024 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 65 |  |  | 65 |  |  | 74 |  |  | 66 |  |  | 80 |  |
| Gross margin |  | 35 |  |  | 35 |  |  | 26 |  |  | 34 |  |  | 20 |  |
| Product development |  | 8 |  |  | 8 |  |  | 10 |  |  | 8 |  |  | 11 |  |
| Marketing and administrative |  | 6 |  |  | 6 |  |  | 7 |  |  | 6 |  |  | 7 |  |
| Restructuring and other, net |  | — |  |  | — |  |  | — |  |  | — |  |  | (1) |  |
| Operating margin |  | 21 |  |  | 21 |  |  | 9 |  |  | 20 |  |  | 3 |  |
| Other expense, net |  | (4) |  |  | (6) |  |  | (5) |  |  | (4) |  |  | (5) |  |
| Income (loss) before income taxes |  | 17 |  |  | 15 |  |  | 4 |  |  | 16 |  |  | (2) |  |
| Provision for income taxes |  | 1 |  |  | 1 |  |  | 2 |  |  | 1 |  |  | 2 |  |
| Net Income (loss) |  | 16 | % |  | 14 | % |  | 2 | % |  | 15 | % |  | (4) | % |

[0001137789-25-000075:mdna:19]
[same as prior period, unchanged from 0001137789-25-000020:mdna:19]

[0001137789-25-000075:mdna:20]
[same as prior period, unchanged from 0001137789-25-000020:mdna:20]

[0001137789-25-000075:mdna:21]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
|  |  | March 28, 2025 |  | December 27, 2024 |  | March 29, 2024 |  | March 28, 2025 |  | March 29, 2024 |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 79 | % |  | 79 | % |  | 75 | % |  | 80 | % |  | 73 | % |
| Distributors |  | 12 | % |  | 12 | % |  | 15 | % |  | 12 | % |  | 16 | % |
| Retailers |  | 9 | % |  | 9 | % |  | 10 | % |  | 8 | % |  | 11 | % |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 39 | % |  | 45 | % |  | 51 | % |  | 41 | % |  | 52 | % |
| Americas |  | 51 | % |  | 45 | % |  | 37 | % |  | 49 | % |  | 35 | % |
| EMEA |  | 10 | % |  | 10 | % |  | 12 | % |  | 10 | % |  | 13 | % |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 81 | % |  | 81 | % |  | 71 | % |  | 81 | % |  | 70 | % |
| Legacy |  | 12 | % |  | 12 | % |  | 18 | % |  | 12 | % |  | 19 | % |
| Other |  | 7 | % |  | 7 | % |  | 11 | % |  | 7 | % |  | 11 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 133 |  |  | 140 |  |  | 88 |  |  | 401 |  |  | 250 |  |
| Legacy |  | 11 |  |  | 11 |  |  | 11 |  |  | 32 |  |  | 34 |  |
| Total |  | 144 |  |  | 151 |  |  | 99 |  |  | 433 |  |  | 284 |  |
| HDD Price per Terabyte |  | $ | 14 |  |  | $ | 14 |  |  | $ | 15 |  |  | $ | 14 |  |  | $ | 15 |  |

[0001137789-25-000075:mdna:22]
[same as prior period, unchanged from 0001137789-25-000020:mdna:22]

[0001137789-25-000075:mdna:23]
[same as prior period, unchanged from 0001137789-25-000020:mdna:23]

[0001137789-25-000075:mdna:24]
Revenue in the March 2025 quarter decreased by $165 million compared to the December 2024 quarter, primarily due to a decrease in mass capacity exabytes shipped as we experienced temporary supply constraints and typical seasonality in certain of our markets.

[0001137789-25-000075:mdna:25]
Revenue for the three and nine months ended March 28, 2025 increased by $505 million and $2 billion from the three and nine months ended March 29, 2024, respectively, primarily due to an increase in mass capacity exabytes shipped as we experienced higher demand primarily for our nearline cloud products and favorable pricing actions undertaken by the Company.

[0001137789-25-000075:mdna:26]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 14% of gross revenue for the March 2025 quarter, 14% for the December 2024 quarter and 15% for the March 2024 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-25-000075:mdna:27]
[same as prior period, unchanged from 0001137789-25-000020:mdna:27]

[0001137789-25-000075:mdna:28]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |  |  |
| (Dollars in millions) |  | March 28, 2025 |  | December 27, 2024 |  | March 29, 2024 |  | March 28, 2025 |  | March 29, 2024 |  |  |  |
| Cost of revenue |  | $ | 1,400 |  |  | $ | 1,513 |  |  | $ | 1,230 |  |  | $ | 4,367 |  |  | $ | 3,728 |  |  |  |  |
| Gross profit |  | 760 |  |  | 812 |  |  | 425 |  |  | 2,286 |  |  | 936 |  |  |  |  |
| Gross margin |  | 35 | % |  | 35 | % |  | 26 | % |  | 34 | % |  | 20 | % |  |  |  |

[0001137789-25-000075:mdna:29]
Gross margin for the March 2025 quarter remained flat compared to the December 2024 quarter.

[0001137789-25-000075:mdna:30]
Gross margin for the March 2025 quarter increased by 9 percentage points compared to the March 2024 quarter, primarily driven by favorable product mix and pricing actions undertaken by the Company, and $43 million of factory underutilization charges in the March 2024 quarter that did not recur, partially offset by $10 million of restructuring costs related to an inventory write down due to a discontinued product line in the March 2025 quarter.

[0001137789-25-000075:mdna:31]
Gross margin for the nine months ended March 28, 2025 increased by 14 percentage points compared to the nine months ended March 29, 2024, primarily driven by favorable product mix and pricing actions undertaken by the Company, a decrease of $117 million of supply related purchase order cancellation fees, as well as $138 million of factory underutilization charges and $13 million of accelerated depreciation expense for certain capital equipment in the nine months ended March 29, 2024 that did not recur, partially offset by $10 million of restructuring costs related to an inventory write down due to a discontinued product line in the nine months ended March 28, 2025.

[0001137789-25-000075:mdna:32]
Warranty cost related to new shipments was 0.7%, 0.7% and 0.8% of revenue for the March 2025 quarter, December 2024 quarter and March 2024 quarter, respectively.

[0001137789-25-000075:mdna:33]
[same as prior period, unchanged from 0001137789-25-000020:mdna:33]

[0001137789-25-000075:mdna:34]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |  |  |  |
| (Dollars in millions) |  | March 28, 2025 |  | December 27, 2024 |  | March 29, 2024 |  | March 28, 2025 |  | March 29, 2024 |  |  |  |  |
| Product development |  | $ | 180 |  |  | $ | 184 |  |  | $ | 164 |  |  | $ | 545 |  |  | $ | 496 |  |  |  |  |  |
| Marketing and administrative |  | 139 |  |  | 139 |  |  | 116 |  |  | 407 |  |  | 329 |  |  |  |  |  |
| Restructuring and other, net |  | 10 |  |  | 1 |  |  | 2 |  |  | 12 |  |  | (27) |  |  |  |  |  |
| Operating expenses |  | $ | 329 |  |  | $ | 324 |  |  | $ | 282 |  |  | $ | 964 |  |  | $ | 798 |  |  |  |  |  |

[0001137789-25-000075:mdna:35]
Product Development Expense. Product development expenses decreased by $4 million in the March 2025 quarter compared to the December 2024 quarter primarily due to a $2 million decrease in compensation and other employee benefits, and a $2 million decrease in facility costs.

[0001137789-25-000075:mdna:36]
Product development expenses increased by $16 million in the March 2025 quarter compared to the March 2024 quarter primarily due to a $17 million increase in compensation and other employee benefits as a result of the variable compensation expense recognized in the March 2025 quarter, partially offset by a $2 million decrease in materials costs.

[0001137789-25-000075:mdna:37]
Product development expenses increased by $49 million in the nine months ended March 28, 2025 compared to the nine months ended March 29, 2024, primarily due to a $52 million increase in compensation and other employee benefits as a result of the variable compensation expense recognized in the nine months ended March 28, 2025 and temporary salary reductions in the nine months ended March 29, 2024, a $6 million increase in facility costs, a $4 million increase in equipment expense and a $2 million increase in travel expense, partially offset by a $15 million reduction in materials costs.

[0001137789-25-000075:mdna:38]
Marketing and Administrative Expense. Marketing and administrative expenses remained flat in the March 2025 quarter compared to the December 2024 quarter.

[0001137789-25-000075:mdna:39]
Marketing and administrative expenses increased by $23 million in the March 2025 quarter compared to the March 2024 quarter primarily due to a $22 million increase in compensation and other employee benefits as a result of the variable compensation expense recognized in the March 2025 quarter.

[0001137789-25-000075:mdna:40]
Marketing and administrative expenses increased by $78 million in the nine months ended March 28, 2025 compared to the nine months ended March 29, 2024, primarily due to a $68 million increase in compensation and other employee benefits as a result of the variable compensation expense recognized in the nine months ended March 28, 2025 and temporary salary reductions in the nine months ended March 29, 2024, a $5 million increase in travel expense, and a $3 million increase in outside services expense.

[0001137789-25-000075:mdna:41]
Restructuring and other, net. We recorded $20 million of restructuring charges in the March 2025 quarter, of which $10 million was recorded to Cost of revenue and $10 million recorded to Restructuring and other, net, respectively, primarily related to an inventory write down due to a discontinued product line and employee related termination benefits.

[0001137789-25-000075:mdna:42]
Restructuring and other, net for the nine months ended March 28, 2025 was $12 million, primarily related to employee related termination benefits.

[0001137789-25-000075:mdna:43]
[same as prior period, unchanged from 0001137789-25-000020:mdna:42]

[0001137789-25-000075:mdna:44]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 28, 2025 |  | December 27, 2024 |  | March 29, 2024 |  | March 28, 2025 |  | March 29, 2024 |
| Other expense, net |  | $ | (76) |  |  | $ | (138) |  |  | $ | (85) |  |  | $ | (301) |  |  | $ | (231) |  |

[0001137789-25-000075:mdna:45]
Other expense, net. Other expense, net decreased by $62 million in the March 2025 quarter compared to the December 2024 quarter primarily due to a $52 million net loss from certain investments in the December 2024 quarter that did not recur, $8 million net gain from the sale of certain service business in the March 2025 quarter, and a $7 million decrease in interest expense, partially offset by a $4 million net loss from debt transactions in the March 2025 quarter and a $4 million decrease in interest income.

[0001137789-25-000075:mdna:46]
Other expense, net decreased by $9 million in the March 2025 quarter compared to the March 2024 quarter primarily due to $8 million net gain from the sale of certain service business in the March 2025 quarter and a $5 million decrease in interest expense, partially offset by a $4 million increase in net loss from debt transactions in the March 2025 quarter.

[0001137789-25-000075:mdna:47]
Other expense, net increased by $70 million in the nine months ended March 28, 2025 compared to the nine months ended March 29, 2024, primarily due to a $104 million net gain from termination of interest rate swap that did not recur and a $10 million increase in net loss from certain investments, partially offset by a $25 million decrease in net loss from debt transactions and an $11 million increase in interest income.

[0001137789-25-000075:mdna:48]
[same as prior period, unchanged from 0001137789-25-000020:mdna:47]

[0001137789-25-000075:mdna:49]
For the three months ended March 28, 2025, December 27, 2024, and March 29, 2024, we recorded income tax expense of $15 million, $14 million, and $33 million, respectively. For the nine months ended March 28, 2025 and March 29, 2024, we recorded income tax expense of $40 million and $85 million, respectively. For further discussion, refer to “Part I, Item 1. Financial Statements—Note 4. Income Taxes”.

[0001137789-25-000075:mdna:50]
[same as prior period, unchanged from 0001137789-25-000020:mdna:49]

[0001137789-25-000075:mdna:51]
[same as prior period, unchanged from 0001137789-25-000020:mdna:50]

[0001137789-25-000075:mdna:52]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of March 28, 2025. For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, see “Part II, Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q.

[0001137789-25-000075:mdna:53]
[same as prior period, unchanged from 0001137789-25-000020:mdna:52]

[0001137789-25-000075:mdna:54]
|  |  | As of |  |  |
| (Dollars in millions) |  | March 28, 2025 |  | June 28, 2024 |  | Change |
| Cash and cash equivalents |  | $ | 814 |  |  | $ | 1,358 |  |  | $ | (544) |  |

[0001137789-25-000075:mdna:55]
Our cash and cash equivalents as of March 28, 2025 decreased by $544 million from June 28, 2024 primarily as a result of $531 million repayment of the 2025 Notes and repurchase of debt, $447 million dividends paid to our shareholders and $182 million payments for capital expenditures, partially offset by net cash of $575 million provided by operating activities.

[0001137789-25-000075:mdna:56]
[same as prior period, unchanged from 0001137789-25-000020:mdna:55]

[0001137789-25-000075:mdna:57]
Cash provided by operating activities for the nine months ended March 28, 2025 was $575 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, and the following major working capital related movements:

[0001137789-25-000075:mdna:58]
•an increase of $116 million in accrued employee compensation, primarily due to an increase in our variable compensation expense; partially offset by

[0001137789-25-000075:mdna:59]
•a decrease of $331 million in accounts payable, primarily due to timing of payments;

[0001137789-25-000075:mdna:60]
•an increase of $233 million in inventories, primarily due to an increase in purchased materials; and

[0001137789-25-000075:mdna:61]
•an increase of $193 million in accounts receivable, primarily due to increased revenue.

[0001137789-25-000075:mdna:62]
[same as prior period, unchanged from 0001137789-25-000020:mdna:61]

[0001137789-25-000075:mdna:63]
Net cash used in investing activities for the nine months ended March 28, 2025 was $146 million, primarily attributable to payments of $182 million for the purchase of property, equipment and leasehold improvements, partially offset by proceeds of $25 million from our business divestiture from the sale of System-on-Chip Operations during fiscal year 2024, as well as proceeds of $10 million from the sale of certain investments.

[0001137789-25-000075:mdna:64]
[same as prior period, unchanged from 0001137789-25-000020:mdna:63]

[0001137789-25-000075:mdna:65]
Net cash used in financing activities of $973 million for the nine months ended March 28, 2025 was primarily attributable to the following activities:

[0001137789-25-000075:mdna:66]
•$531 million redemption and repurchase of debt;

[0001137789-25-000075:mdna:67]
•$447 million in dividends paid to our shareholders; and

[0001137789-25-000075:mdna:68]
•$44 million taxes paid related to net share settlement of equity awards; partially offset by

[0001137789-25-000075:mdna:69]
•$56 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-25-000075:mdna:70]
[same as prior period, unchanged from 0001137789-25-000020:mdna:68]

[0001137789-25-000075:mdna:71]
Our primary sources of liquidity as of March 28, 2025, consist of: (1) approximately $0.8 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.3 billion available for borrowing under our senior unsecured revolving credit facility (“Revolving Credit Facility”), which is part of our New Credit Agreement (as defined below).

[0001137789-25-000075:mdna:72]
As of March 28, 2025, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with a financial covenant and other customary conditions to borrowing.

[0001137789-25-000075:mdna:73]
As of March 28, 2025, the New Credit Agreement includes one financial covenant, net leverage ratio. We continue to evaluate our debt portfolio and structure to comply with our financial debt covenant. As of March 28, 2025, we were in compliance with all of the covenants under our debt agreements. Refer to “Part I, Item 1. Financial Statements—Note 3. Debt” for more details.

[0001137789-25-000075:mdna:74]
As of March 28, 2025, cash and cash equivalents held by our subsidiaries was $698 million. This amount is potentially subject to taxation in Singapore upon repatriation by means of an intercompany dividend into our parent company, unless certain exemption is given, or a special approval is granted by the Ministry of Finance in Singapore. However, it is our intent to indefinitely reinvest earnings of subsidiaries in excess of the amount paid as dividends to shareholders. Our current plans do not demonstrate a need to repatriate such excess earnings. Should funds be needed in the parent company and should we be unable to fund parent company activities through means other than a taxable repatriation, we would be required to accrue and pay taxes on such dividend.

[0001137789-25-000075:mdna:75]
[same as prior period, unchanged from 0001137789-25-000020:mdna:73]

[0001137789-25-000075:mdna:76]
[same as prior period, unchanged from 0001137789-25-000020:mdna:74]

[0001137789-25-000075:mdna:77]
32

[0001137789-25-000075:mdna:78]
[same as prior period, unchanged from 0001137789-25-000020:mdna:75]

[0001137789-25-000075:mdna:79]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend and any future strategic investments. As of March 28, 2025, our contractual cash requirements have not changed materially outside of the normal course of business since our fiscal year ended June 28, 2024.

[0001137789-25-000075:mdna:80]
[same as prior period, unchanged from 0001137789-25-000020:mdna:77]

[0001137789-25-000075:mdna:81]
Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. From time to time, we enter into long-term, non-cancelable purchase commitments or make large up-front investments with certain suppliers in order to secure certain components or technologies for the production of our products or to supplement our internal manufacturing capacity for certain components. As of March 28, 2025, we had unconditional purchase obligations of approximately $1.2 billion, primarily related to purchases of inventory components with our suppliers. We expect $1.1 billion of these commitments to be paid within one year. In addition, we also had certain long-term, market share-based, non-cancellable inventory purchase commitments as of March 28, 2025.

[0001137789-25-000075:mdna:82]
[same as prior period, unchanged from 0001137789-25-000020:mdna:80]

[0001137789-25-000075:mdna:83]
As of March 28, 2025, the future principal payment obligation on our long-term debt was $5.2 billion, which will mature in more than one year. As of March 28, 2025, future interest payments on this outstanding debt is estimated to be approximately $1.8 billion, of which $299 million is expected to be paid within one year. From time to time, we may refinance, repurchase, redeem or otherwise extinguish any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase or redeem outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 1. Financial Statements—Note 3. Debt” for more details.

[0001137789-25-000075:mdna:84]
[same as prior period, unchanged from 0001137789-25-000020:mdna:82]

[0001137789-25-000075:mdna:85]
We accrued a settlement penalty of $300 million for fiscal year 2023, related to BIS’ allegations of violations of the U.S. EAR, which were subsequently resolved by the Settlement Agreement in April 2023. As part of the Settlement Agreement with BIS, quarterly payments of $15 million are made over the course of five years beginning October 31, 2023, of which $60 million is expected to be paid within one year and $150 million thereafter. Refer to “Item 1. Financial Statements—Note 11. Legal, Environmental and Other Contingencies” for more details.

[0001137789-25-000075:mdna:86]
[same as prior period, unchanged from 0001137789-25-000020:mdna:84]

[0001137789-25-000075:mdna:87]
On April 29, 2025, our Board of Directors declared a quarterly cash dividend of $0.72 per share, which will be payable on July 8, 2025 to shareholders of record as of the close of business on June 25, 2025. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-25-000075:mdna:88]
[same as prior period, unchanged from 0001137789-25-000020:mdna:86]

[0001137789-25-000075:mdna:89]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means, including through the use of derivative transactions. As of March 28, 2025, $1.8 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-25-000075:mdna:90]
[same as prior period, unchanged from 0001137789-25-000020:mdna:89]

[0001137789-25-000075:mdna:91]
[same as prior period, unchanged from 0001137789-25-000020:mdna:90]

[0001137789-25-000075:mdna:92]
[same as prior period, unchanged from 0001137789-25-000020:mdna:88]

[0001137789-25-000075:mdna:93]
[same as prior period, unchanged from 0001137789-25-000020:mdna:91]

[0001137789-25-000075:mdna:94]
[same as prior period, unchanged from 0001137789-25-000020:mdna:92]

[0001137789-25-000075:mdna:95]
[same as prior period, unchanged from 0001137789-25-000020:mdna:93]

[0001137789-25-000075:mdna:96]
[same as prior period, unchanged from 0001137789-25-000020:mdna:94]

[0001137789-25-000075:mdna:97]
[same as prior period, unchanged from 0001137789-25-000020:mdna:95]
