# STX note change history — 0001137789-25-000020 → 0001137789-25-000075


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-02):
[0001137789-25-000075:note_history:1]
In re Seagate Technology Holdings plc Securities Litigation. A putative class action lawsuit alleging violations of the federal securities laws, UA Local 38 Defined Contribution Pension Plan, et al. v. Seagate Technology Holdings PLC, et al., was filed on July 10, 2023, in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The complaint alleged that it was a securities class action on behalf of all purchasers of Seagate common stock between September 15, 2020 and October 25, 2022, inclusive, and asserted claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b5-1. The complaint sought unspecified monetary damages and other relief. A second action, Public Employees’ Retirement System of Mississippi v. Seagate Technology Holdings plc, William David Mosley, and Gianluca Romano, was filed on July 26, 2023, asserting similar claims. The cases were consolidated on September 25, 2023. On October 19, 2023, plaintiffs filed an amended complaint asserting similar claims with a putative class period of September 14, 2020 through April 19, 2023. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint. On August 8, 2024, the Court granted the Company’s motion to dismiss, with leave to amend. On September 12, 2024, the Plaintiffs filed an amended complaint. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint. The Company believes that the asserted claims are without merit and intends to vigorously defend the case.
  (was, 2025-01-24, similarity 0.9839):
[0001137789-25-000020:note_history:1]
In re Seagate Technology Holdings plc Securities Litigation. A putative class action lawsuit alleging violations of the federal securities laws, UA Local 38 Defined Contribution Pension Plan, et al. v. Seagate Technology Holdings PLC, et al., was filed on July 10, 2023, in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The complaint alleged that it was a securities class action on behalf of all purchasers of Seagate common stock between September 15, 2020 and October 25, 2022, inclusive, and asserted claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b5-1. The complaint sought unspecified monetary damages and other relief. A second action, Public Employees’ Retirement System of Mississippi v. Seagate Technology Holdings plc, William David Mosley, and Gianluca Romano, was filed on July 26, 2023, asserting similar claims. The cases were consolidated on September 25, 2023. On October 19, 2023, plaintiffs filed an amended complaint asserting similar claims with a putative class period of September 14, 2020 through April 19, 2023. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint. On August 8, 2024, the Court granted the Company’s motion to dismiss, with leave to amend. On September 12, 2024, the Plaintiffs filed an amended complaint. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint. A hearing on the motion is scheduled for March 4, 2025. The Company believes that the asserted claims are without merit and intends to vigorously defend the case.

- changed (2025-05-02):
[0001137789-25-000075:note_history:2]
Godo Kaisha IP Bridge 1 v. Seagate Technology LLC, Seagate Technology (US) Holding, Inc., Seagate Technology (Thailand) Limited, Seagate Singapore International Headquarters Ltd., Seagate Technology (Netherlands) B.V. On March 15, 2024, a patent infringement action was filed by Godo Kaisha IP Bridge 1 (“IP Bridge”) against Seagate in U.S. District Court for the District of Delaware. The complaint alleges patent infringement by Seagate of three U.S. patents. On June 7, 2024, Seagate filed a motion to transfer venue to Minnesota. On July 8, 2024, IP Bridge filed a First Amended Complaint alleging patent infringement by Seagate of six additional patents. IP Bridge is seeking damages as well as additional relief. On September 4, 2024, the court granted Seagate’s motion to transfer the case to the District Court of Minnesota. On October 16, 2024, Seagate filed its answer to the First Amended Complaint. The Company believes the asserted claims are without merit and intends to vigorously defend this case.
  (was, 2025-01-24, similarity 0.998):
[0001137789-25-000020:note_history:2]
Godo Kaisha IP Bridge 1 v. Seagate Technology LLC, Seagate Technology (US) Holding, Inc., Seagate Technology (Thailand) Limited, Seagate Singapore International Headquarters Ltd., Seagate Technology (Netherlands) B.V. On March 15, 2024, a patent infringement action was filed by Godo Kaisha IP Bridge 1 (“IP Bridge”) against Seagate in U.S. District Court for the District of Delaware. The complaint alleges patent infringement by Seagate of three U.S. patents. On June 7, 2024, Seagate filed a motion to transfer venue to Minnesota. On July 8, 2024, IP Bridge filed a First Amended Complaint alleging patent infringement by Seagate of six additional patents. IP Bridge is seeking damages as well as additional relief. On September 4, 2024, the court granted Seagate’s motion to transfer the case to the District Court in Minnesota. On October 16, 2024, Seagate filed its answer to the First Amended Complaint. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

- changed (2025-05-02):
[0001137789-25-000075:note_history:3]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $150 million were included in Accrued expense and Other non-current liabilities, respectively, on the Condensed Consolidated Balance Sheets as of March 28, 2025. For the nine months ended March 28, 2025, $45 million was paid and reported as an outflow from operating activities in its Condensed Consolidated Statements of Cash Flows.
  (was, 2025-01-24, similarity 0.8935):
[0001137789-25-000020:note_history:3]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $165 million were included in Accrued expense and Other non-current liabilities, respectively, on the Condensed Consolidated Balance Sheets as of December 27, 2024. For the six months ended December 27, 2024, $30 million was paid and reported as an outflow from operating activities in its Condensed Consolidated Statements of Cash Flows.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-02):
[0001137789-25-000075:note_history:4]
The Company’s Consolidated Financial Statements for the fiscal year ended June 28, 2024 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 2, 2024. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 28, 2024, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and nine months ended March 28, 2025 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 27, 2025.
  (was, 2025-01-24, similarity 0.9662):
[0001137789-25-000020:note_history:4]
The Company’s Consolidated Financial Statements for the fiscal year ended June 28, 2024 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 2, 2024. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 28, 2024, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and six months ended December 27, 2024 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 27, 2025.

- changed (2025-05-02):
[0001137789-25-000075:note_history:5]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and nine months ended March 28, 2025 and March 29, 2024 consisted of 13 and 39 weeks, respectively. Fiscal years 2025 and 2024 both comprise 52 weeks and end on June 27, 2025 and June 28, 2024, respectively. The fiscal quarters ended March 28, 2025, December 27, 2024 and March 29, 2024, are also referred to herein as the “March 2025 quarter”, the “December 2024 quarter” and the “March 2024 quarter”, respectively.
  (was, 2025-01-24, similarity 0.8542):
[0001137789-25-000020:note_history:5]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and six months ended December 27, 2024 and December 29, 2023 consisted of 13 and 26 weeks, respectively. Fiscal years 2025 and 2024 both comprise 52 weeks and end on June 27, 2025 and June 28, 2024, respectively. The fiscal quarters ended December 27, 2024, September 27, 2024 and December 29, 2023, are also referred to herein as the “December 2024 quarter”, the “September 2024 quarter” and the “December 2023 quarter”, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-02):
[0001137789-25-000075:note_history:6]
Debt
The following table provides details of the Company’s debt as of March 28, 2025 and June 28, 2024:
  (was, 2025-01-24, similarity 0.9524):
[0001137789-25-000020:note_history:6]
Debt
The following table provides details of the Company’s debt as of December 27, 2024 and June 28, 2024:

- changed (2025-05-02):
[0001137789-25-000075:note_history:7]
| (Dollars in millions) |  | March 28, 2025 |  | June 28, 2024 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | — |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 505 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 461 |  |  | 471 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 144 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 252 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 71 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,172 |  |  | 5,704 |  |
| Less: unamortized debt issuance costs |  | (26) |  |  | (30) |  |
| Debt, net of debt issuance costs |  | 5,146 |  |  | 5,674 |  |
| Less: current portion of long-term debt |  | — |  |  | (479) |  |
| Long-term debt, less current portion |  | $ | 5,146 |  |  | $ | 5,195 |  |
  (was, 2025-01-24, similarity 0.9955):
[0001137789-25-000020:note_history:7]
| (Dollars in millions) |  | December 27, 2024 |  | June 28, 2024 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 505 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 473 |  |  | 471 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,706 |  |  | 5,704 |  |
| Less: unamortized debt issuance costs |  | (27) |  |  | (30) |  |
| Debt, net of debt issuance costs |  | 5,679 |  |  | 5,674 |  |
| Less: current portion of long-term debt |  | (479) |  |  | (479) |  |
| Long-term debt, less current portion |  | $ | 5,200 |  |  | $ | 5,195 |  |

- changed (2025-05-02):
[0001137789-25-000075:note_history:8]
For the three and nine months ended March 28, 2025, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $13 million and $39 million, respectively, and immaterial amortization of debt issuance costs. For the three and nine months ended March 29, 2024, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $13 million and $29 million, respectively, and immaterial amortization of debt issuance costs.
  (was, 2025-01-24, similarity 0.895):
[0001137789-25-000020:note_history:8]
For the three and six months ended December 27, 2024, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $13 million and $26 million, respectively, and immaterial amortization of debt issuance costs. For the three and six months ended December 29, 2023, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $13 million and $15 million, respectively, and immaterial amortization of debt issuance costs.

- changed (2025-05-02):
[0001137789-25-000075:note_history:9]
The entire outstanding principal amount of Term Loans A1, A2 and A3 were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in Net loss from debt transactions in the Company’s Condensed Consolidated Statements of Operations for the nine months ended March 29, 2024. In connection with the repayment of Term Loans, the Company terminated certain interest rate swap agreements. Refer to “Note 5. Derivative Financial Instruments” for more details.
  (was, 2025-01-24, similarity 0.9126):
[0001137789-25-000020:note_history:9]
The entire outstanding principal amount of Term Loans A1, A2 and A3 were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in Net loss recognized from early redemption of debt in the Company’s Condensed Consolidated Statements of Operations for the six months ended December 29, 2023. In connection with the repayment of Term Loans, the Company terminated certain interest rate swap agreements. Refer to “Note 5. Derivative Financial Instruments” for more details.

- changed (2025-05-02):
[0001137789-25-000075:note_history:10]
Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The current exchange rate for the 2028 Notes is 12.1306 ordinary shares per $1,000 principal amount of 2028 Notes, which is equivalent to an exchange price of approximately $82.44 per share as of March 28, 2025. The exchange rate was adjusted from 12.1278 ordinary shares per $1,000 principal amount of 2028 Notes on March 19, 2025, and is subject to further adjustment pursuant to the terms of the Exchangeable Notes indenture.
  (was, 2025-01-24, similarity 0.9834):
[0001137789-25-000020:note_history:10]
Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The current exchange rate for the 2028 Notes is 12.1278 ordinary shares per $1,000 principal amount of 2028 Notes, which is equivalent to an exchange price of approximately $82.46 per share as of December 27, 2024. The exchange rate was adjusted from 12.1253 ordinary shares per $1,000 principal amount of 2028 Notes on December 13, 2024, and is subject to further adjustment pursuant to the terms of the Exchangeable Notes indenture.

- changed (2025-05-02):
[0001137789-25-000075:note_history:11]
As of March 28, 2025, the 2028 Notes were not exchangeable. Refer to “Note 10. Earnings (Loss) Per Share” for the potential dilutive impact of the 2028 Notes.
  (was, 2025-01-24, similarity 0.9691):
[0001137789-25-000020:note_history:11]
As of December 27, 2024, the 2028 Notes were not exchangeable. Refer to “Note 10. Earnings (Loss) Per Share” for the potential dilutive impact of the 2028 Notes.

- changed (2025-05-02):
[0001137789-25-000075:note_history:12]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The current cap price of the capped call transactions, which was adjusted on March 19, 2025 in accordance with the applicable capped call confirmations, is $107.801 per share. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets.
  (was, 2025-01-24, similarity 0.9908):
[0001137789-25-000020:note_history:12]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The current cap price of the capped call transactions, which was adjusted on December 13, 2024 in accordance with the applicable capped call confirmations, is $107.826 per share. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets.

- changed (2025-05-02):
[0001137789-25-000075:note_history:13]
2025 Notes
  (was, 2025-01-24, similarity 0.6667):
[0001137789-25-000020:note_history:13]
2025 Senior Notes

- added (2025-05-02):
[0001137789-25-000075:note_history:14]
On January 30, 2025, the Company and its subsidiary Seagate HDD Cayman (the “Borrower”), the Bank of Nova Scotia, as administrative agent, and the lenders thereto entered into a Credit Agreement (the “New Credit Agreement”) and terminated their then-existing Credit Agreement, dated as of February 20, 2019 (the “Old Credit Agreement”). As a result of terminating the Old Credit Agreement, the Company recorded an $8 million non-cash loss related to the accelerated amortization of debt issuance costs, which was included in Net loss from debt transactions in the Company’s Condensed Consolidated Statements of Operations.

- added (2025-05-02):
[0001137789-25-000075:note_history:15]
The New Credit Agreement provides for a $1.3 billion senior unsecured revolving credit facility (“Revolving Credit Facility”), the term of which is through January 30, 2030. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing. An aggregate amount of up to $150 million of the facility shall also be available for the issuance of letters of credit, and an aggregate amount of up to $50 million of the facility shall also be available for swing line loans. On March 28, 2025, no borrowings were outstanding under the New Credit Agreement.

- added (2025-05-02):
[0001137789-25-000075:note_history:16]
The loans made under the New Credit Agreement will bear interest at an Applicable Rate based on the secured overnight financing rate, or SOFR, plus a variable margin that will be determined based on the corporate credit rating of the Company. The Borrower’s obligations under the New Credit Agreement are guaranteed by the Company and certain material subsidiaries of the Company.

- added (2025-05-02):
[0001137789-25-000075:note_history:17]
The New Credit Agreement also contains a financial covenant that requires the Company to maintain a total net leverage ratio of less than or equal to 6.75 to 1.00, commencing with the fiscal quarter ending June 27, 2025 and declining over time so that the maximum permitted net leverage ratio for each fiscal quarter ending after July 2, 2027 is 4.25 to 1.00, in accordance with the terms of the New Credit Agreement. For each fiscal quarter until January 2, 2026, this net leverage ratio covenant applies only to the extent that there is any amount of revolving loans, swing line loans, or letters of credit outstanding as of the last day of the relevant fiscal quarter.

- added (2025-05-02):
[0001137789-25-000075:note_history:18]
Debt Repurchases

- added (2025-05-02):
[0001137789-25-000075:note_history:19]
During the March 2025 quarter, $14 million principal amount of the June 2029 Notes, $19 million principal amount of the July 2029 Notes, $23 million principal amount of the January 2031 Notes and $1 million principal amount of the July 2031 Notes were repurchased for cash at a discount to their principal amounts, plus accrued and unpaid interest. The Company recorded a net gain of $4 million on these repurchases during the March 2025 quarter, which was included in Net loss from debt transactions in the Company’s Condensed Consolidated Statements of Operations.

- changed (2025-05-02):
[0001137789-25-000075:note_history:20]
At March 28, 2025, future principal payments on long-term debt were as follows (in millions):
  (was, 2025-01-24, similarity 0.9492):
[0001137789-25-000020:note_history:20]
At December 27, 2024, future principal payments on long-term debt were as follows (in millions):

- changed (2025-05-02):
[0001137789-25-000075:note_history:21]
| Fiscal Year |  | Amount |
| Remainder of 2025 |  | $ | — |  |
| 2026 |  | — |  |
| 2027 |  | 505 |  |
| 2028 |  | 1,500 |  |
| 2029 |  | 481 |  |
| Thereafter |  | 2,707 |  |
| Total |  | $ | 5,193 |  |
  (was, 2025-01-24, similarity 0.9937):
[0001137789-25-000020:note_history:21]
| Fiscal Year |  | Amount |
| Remainder of 2025 |  | $ | 479 |  |
| 2026 |  | — |  |
| 2027 |  | 505 |  |
| 2028 |  | 1,500 |  |
| 2029 |  | 495 |  |
| Thereafter |  | 2,750 |  |
| Total |  | $ | 5,729 |  |

- removed (2025-05-02):
[0001137789-25-000020:note_history:22]
The credit agreement dated as of February 20, 2019, by and among, Seagate Technology Holdings plc, Seagate HDD, The Bank of Nova Scotia, as administrative agent, and the lenders party thereto (as amended from time to time, the “Credit Agreement”) includes two financial covenants: (1) interest coverage ratio and (2) total net leverage ratio. For the fiscal quarter ended December 27, 2024, and for each fiscal quarter until the end of the covenant relief period, which terminates on June 27, 2025, the maximum permitted total net leverage ratio is 6.75 to 1.00, and applies only to the extent that the aggregate outstanding amount of revolving loans, swing line loans and the aggregate face amount of certain letters of credit exceeds 25% of the then outstanding revolving commitments in effect (the “Testing Condition”) as of the last day of the relevant fiscal quarter. The maximum permitted total leverage ratio for each fiscal quarter ending after June 27, 2025 is 4.00 to 1.00.

- removed (2025-05-02):
[0001137789-25-000020:note_history:23]
For the fiscal quarter ended December 27, 2024, and for each fiscal quarter until the end of the covenant relief period, which terminates on June 27, 2025, the minimum interest coverage ratio is 2.25 to 1.00, and applies only to the extent that the Testing Condition is satisfied as of the last day of the relevant fiscal quarter. The minimum interest coverage ratio for each fiscal quarter ending after June 27, 2025 is 3.25 to 1.00.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-02):
[0001137789-25-000075:note_history:24]
|  |  | March 28, 2025 |  | June 28, 2024 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 4.75% Senior Notes due January 2025 |  | — |  |  | — |  |  | 479 |  |  | 476 |  |
| 4.875% Senior Notes due June 2027 |  | 505 |  |  | 499 |  |  | 505 |  |  | 493 |  |
| 3.50% Exchangeable Senior Notes due June 2028 |  | 1,500 |  |  | 1,833 |  |  | 1,500 |  |  | 2,070 |  |
| 4.091% Senior Notes due June 2029 |  | 461 |  |  | 455 |  |  | 471 |  |  | 459 |  |
| 3.125% Senior Notes due July 2029 |  | 144 |  |  | 129 |  |  | 163 |  |  | 139 |  |
| 8.25% Senior Notes due December 2029 |  | 500 |  |  | 532 |  |  | 500 |  |  | 537 |  |
| 4.125% Senior Notes due January 2031 |  | 252 |  |  | 231 |  |  | 275 |  |  | 245 |  |
| 3.375% Senior Notes due July 2031 |  | 71 |  |  | 61 |  |  | 72 |  |  | 58 |  |
| 8.50% Senior Notes due July 2031 |  | 500 |  |  | 532 |  |  | 500 |  |  | 538 |  |
| 9.625% Senior Notes due December 2032 |  | 750 |  |  | 847 |  |  | 750 |  |  | 855 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 477 |  |  | 489 |  |  | 472 |  |
|  |  | $ | 5,172 |  |  | $ | 5,596 |  |  | $ | 5,704 |  |  | $ | 6,342 |  |
| Less: unamortized debt issuance costs |  | (26) |  |  | — |  |  | (30) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 5,146 |  |  | $ | 5,596 |  |  | $ | 5,674 |  |  | $ | 6,342 |  |
| Less: current portion of debt, net of debt issuance costs |  | — |  |  | — |  |  | (479) |  |  | (476) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,146 |  |  | $ | 5,596 |  |  | $ | 5,195 |  |  | $ | 5,866 |  |
  (was, 2025-01-24, similarity 0.9804):
[0001137789-25-000020:note_history:24]
|  |  | December 27, 2024 |  | June 28, 2024 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 4.75% Senior Notes due January 2025 |  | 479 |  |  | 479 |  |  | 479 |  |  | 476 |  |
| 4.875% Senior Notes due June 2027 |  | 505 |  |  | 498 |  |  | 505 |  |  | 493 |  |
| 3.50% Exchangeable Senior Notes due June 2028 |  | 1,500 |  |  | 1,840 |  |  | 1,500 |  |  | 2,070 |  |
| 4.091% Senior Notes due June 2029 |  | 473 |  |  | 459 |  |  | 471 |  |  | 459 |  |
| 3.125% Senior Notes due July 2029 |  | 163 |  |  | 147 |  |  | 163 |  |  | 139 |  |
| 8.25% Senior Notes due December 2029 |  | 500 |  |  | 533 |  |  | 500 |  |  | 537 |  |
| 4.125% Senior Notes due January 2031 |  | 275 |  |  | 248 |  |  | 275 |  |  | 245 |  |
| 3.375% Senior Notes due July 2031 |  | 72 |  |  | 58 |  |  | 72 |  |  | 58 |  |
| 8.50% Senior Notes due July 2031 |  | 500 |  |  | 534 |  |  | 500 |  |  | 538 |  |
| 9.625% Senior Notes due December 2032 |  | 750 |  |  | 847 |  |  | 750 |  |  | 855 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 473 |  |  | 489 |  |  | 472 |  |
|  |  | $ | 5,706 |  |  | $ | 6,116 |  |  | $ | 5,704 |  |  | $ | 6,342 |  |
| Less: unamortized debt issuance costs |  | (27) |  |  | — |  |  | (30) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 5,679 |  |  | $ | 6,116 |  |  | $ | 5,674 |  |  | $ | 6,342 |  |
| Less: current portion of debt, net of debt issuance costs |  | (479) |  |  | (479) |  |  | (479) |  |  | (476) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,200 |  |  | $ | 5,637 |  |  | $ | 5,195 |  |  | $ | 5,866 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-02):
[0001137789-25-000075:note_history:25]
The following table provides details of the Company’s debt as of March 28, 2025 and June 28, 2024:
  (was, 2025-01-24, similarity 0.9497):
[0001137789-25-000020:note_history:25]
The following table provides details of the Company’s debt as of December 27, 2024 and June 28, 2024:

- changed (2025-05-02):
[0001137789-25-000075:note_history:26]
| (Dollars in millions) |  | March 28, 2025 |  | June 28, 2024 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | — |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 505 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 461 |  |  | 471 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 144 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 252 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 71 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,172 |  |  | 5,704 |  |
| Less: unamortized debt issuance costs |  | (26) |  |  | (30) |  |
| Debt, net of debt issuance costs |  | 5,146 |  |  | 5,674 |  |
| Less: current portion of long-term debt |  | — |  |  | (479) |  |
| Long-term debt, less current portion |  | $ | 5,146 |  |  | $ | 5,195 |  |
  (was, 2025-01-24, similarity 0.9955):
[0001137789-25-000020:note_history:26]
| (Dollars in millions) |  | December 27, 2024 |  | June 28, 2024 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 505 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 473 |  |  | 471 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,706 |  |  | 5,704 |  |
| Less: unamortized debt issuance costs |  | (27) |  |  | (30) |  |
| Debt, net of debt issuance costs |  | 5,679 |  |  | 5,674 |  |
| Less: current portion of long-term debt |  | (479) |  |  | (479) |  |
| Long-term debt, less current portion |  | $ | 5,200 |  |  | $ | 5,195 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-02):
[0001137789-25-000075:note_history:27]
At March 28, 2025, future principal payments on long-term debt were as follows (in millions):
  (was, 2025-01-24, similarity 0.9492):
[0001137789-25-000020:note_history:27]
At December 27, 2024, future principal payments on long-term debt were as follows (in millions):

- changed (2025-05-02):
[0001137789-25-000075:note_history:28]
| Fiscal Year |  | Amount |
| Remainder of 2025 |  | $ | — |  |
| 2026 |  | — |  |
| 2027 |  | 505 |  |
| 2028 |  | 1,500 |  |
| 2029 |  | 481 |  |
| Thereafter |  | 2,707 |  |
| Total |  | $ | 5,193 |  |
  (was, 2025-01-24, similarity 0.9937):
[0001137789-25-000020:note_history:28]
| Fiscal Year |  | Amount |
| Remainder of 2025 |  | $ | 479 |  |
| 2026 |  | — |  |
| 2027 |  | 505 |  |
| 2028 |  | 1,500 |  |
| 2029 |  | 495 |  |
| Thereafter |  | 2,750 |  |
| Total |  | $ | 5,729 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-05-02):
[0001137789-25-000075:note_history:29]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |  |
| (Dollars in millions) |  | March 28, 2025 |  | March 29, 2024 |  | March 28, 2025 |  | March 29, 2024 |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,711 |  |  | $ | 1,236 |  |  | $ | 5,301 |  |  | $ | 3,408 |  |  |  |
| Distributors |  | 264 |  |  | 252 |  |  | 791 |  |  | 736 |  |  |  |
| Retailers |  | 185 |  |  | 167 |  |  | 561 |  |  | 520 |  |  |  |
| Total |  | $ | 2,160 |  |  | $ | 1,655 |  |  | $ | 6,653 |  |  | $ | 4,664 |  |  |  |

- removed (2025-05-02):
[0001137789-25-000020:note_history:30]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | December 27, 2024 |  | December 29, 2023 |  | December 27, 2024 |  | December 29, 2023 |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,841 |  |  | $ | 1,140 |  |  | $ | 3,590 |  |  | $ | 2,172 |  |  |  |
| Distributors |  | 278 |  |  | 218 |  |  | 527 |  |  | 484 |  |  |  |
| Retailers |  | 206 |  |  | 197 |  |  | 376 |  |  | 353 |  |  |  |
| Total |  | $ | 2,325 |  |  | $ | 1,555 |  |  | $ | 4,493 |  |  | $ | 3,009 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-05-02):
[0001137789-25-000075:note_history:31]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |  |
| (Dollars in millions) |  | March 28, 2025 |  | March 29, 2024 |  | March 28, 2025 |  | March 29, 2024 |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,711 |  |  | $ | 1,236 |  |  | $ | 5,301 |  |  | $ | 3,408 |  |  |  |
| Distributors |  | 264 |  |  | 252 |  |  | 791 |  |  | 736 |  |  |  |
| Retailers |  | 185 |  |  | 167 |  |  | 561 |  |  | 520 |  |  |  |
| Total |  | $ | 2,160 |  |  | $ | 1,655 |  |  | $ | 6,653 |  |  | $ | 4,664 |  |  |  |

- removed (2025-05-02):
[0001137789-25-000020:note_history:32]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | December 27, 2024 |  | December 29, 2023 |  | December 27, 2024 |  | December 29, 2023 |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,841 |  |  | $ | 1,140 |  |  | $ | 3,590 |  |  | $ | 2,172 |  |  |  |
| Distributors |  | 278 |  |  | 218 |  |  | 527 |  |  | 484 |  |  |  |
| Retailers |  | 206 |  |  | 197 |  |  | 376 |  |  | 353 |  |  |  |
| Total |  | $ | 2,325 |  |  | $ | 1,555 |  |  | $ | 4,493 |  |  | $ | 3,009 |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2025-05-02):
[0001137789-25-000075:note_history:33]
Subsequent Events
Acquisition
  (was, 2025-01-24, similarity 0.7111):
[0001137789-25-000020:note_history:33]
Subsequent Event

- added (2025-05-02):
[0001137789-25-000075:note_history:34]
On March 31, 2025, the Company completed the acquisition of Intevac, Inc., a supplier of thin-film processing systems, in an all-cash transaction for $4.00 per share, with cash consideration of approximately $118 million. This acquisition aligns with the Company’s strategy to integrate important components and manufacturing processes.

- added (2025-05-02):
[0001137789-25-000075:note_history:35]
Dividend Declared

- added (2025-05-02):
[0001137789-25-000075:note_history:36]
On April 29, 2025, the Board of Directors of the Company declared a quarterly cash dividend of $0.72 per share, which will be payable on July 8, 2025 to shareholders of record as of the close of business on June 25, 2025.
