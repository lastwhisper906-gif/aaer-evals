# STX note change history — 0001137789-25-000075 → 0001137789-25-000317


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0001137789-25-000317:note_history:1]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, seeking damages as well as additional relief. The district court entered judgment in favor of Seagate on April 19, 2022. On September 17, 2025, the Court of Appeals for the Federal Circuit vacated the District Court’s judgment and remanded for a new trial on infringement and enablement. The Company believes the asserted claims are without merit and intends to vigorously defend this case.
  (was, 2025-05-02, similarity 0.6192):
[0001137789-25-000075:note_history:1]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgment in favor of Seagate on April 19, 2022, following a jury trial. The parties filed post-trial motions with the district court, which were denied. An appeal to the Federal Circuit is pending. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

- added (2025-10-31):
[0001137789-25-000317:note_history:2]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC and certain of its affiliates, (collectively, the “Seagate Entities”) filed a complaint alleging violations of federal and state antitrust laws as well as breach of contract in the U.S. District Court for the Northern District of California against suppliers of HDD suspension assemblies, including NHK Spring Co. Ltd., TDK Corporation (“TDK”) and Hutchinson Technology Inc (“HTI”). The Seagate Entities seek to recover damages suffered as a result of the suspension assembly suppliers’ conduct, and additional relief permitted by law. On April 8, 2022, the court dismissed with prejudice all claims against TDK and HTI after the Seagate Entities settled with those defendants. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment under the Foreign Trade Antitrust Improvement Act (“FTAIA Motion”). On November 17, 2023, the Court granted NHK’s FTAIA Motion on reconsideration, denying the majority of Seagate’s antitrust claims. The Court’s FTAIA decision is now on appeal with the Ninth Circuit.

- added (2025-10-31):
[0001137789-25-000317:note_history:3]
In re Seagate Technology Holdings plc Securities Litigation. On July 10, 2023 and July 26, 2023, two securities class action lawsuits were filed in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The cases were consolidated on September 25, 2023. On September 12, 2024, the plaintiffs filed the currently operative complaint, asserting claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and SEC Rule 10b-5, and a class period between September 14, 2020 and April 19, 2023, inclusive. The operative complaint seeks unspecified monetary damages and other relief. On May 12, 2025, the Court granted in part and denied in part the defendants’ motion to dismiss the operative complaint. The Company believes that the asserted claims are without merit and intends to vigorously defend the case.

- added (2025-10-31):
[0001137789-25-000317:note_history:4]
Godo Kaisha IP Bridge 1 v. Seagate Technology LLC, Seagate Technology (US) Holding, Inc., Seagate Technology (Thailand) Limited, Seagate Singapore International Headquarters Ltd., Seagate Technology (Netherlands) B.V. On March 15, 2024, a patent infringement action was filed by Godo Kaisha IP Bridge 1 (“IP Bridge”) against Seagate in U.S. District Court for the District of Delaware. The case was subsequently transferred to the District Court of Minnesota on September 4, 2024. The complaint alleges patent infringement by Seagate of nine U.S. patents. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

- changed (2025-10-31):
[0001137789-25-000317:note_history:5]
On April 18, 2023, the Company’s subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd (collectively, “Seagate”), entered into a settlement agreement (the “Settlement Agreement”) with the U.S. Department of Commerce’s Bureau of Industry and Security (“BIS”) that resolves BIS’ allegations regarding Seagate’s sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, Seagate has agreed to pay $300 million to BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. Seagate has also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the U.S. Export Administration Regulations (“EAR”), including one audit by an unaffiliated third-party consultant chosen by Seagate with expertise in U.S. export control laws and two internal audits.
  (was, 2025-05-02, similarity 0.7274):
[0001137789-25-000075:note_history:5]
On April 18, 2023, the Company’s subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd (collectively, “Seagate”), entered into a settlement agreement (the “Settlement Agreement”) with the U.S. Department of Commerce’s Bureau of Industry and Security (“BIS”) that resolved BIS’ allegations regarding Seagate’s sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, Seagate agreed to pay $300 million to BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. Seagate also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the U.S. Export Administration Regulations (“EAR”), including one audit by an unaffiliated third-party consultant chosen by Seagate with expertise in U.S. export control laws, which has been completed, and two internal audits. The Settlement Agreement also included a denial order that is suspended and will be waived five years after the date of the order issued under the Settlement Agreement, provided that Seagate has made full and timely payments under the Settlement Agreement and timely completed the audit requirements. While Seagate is in compliance with and upon successful compliance in full with the terms of the Settlement Agreement, BIS agreed it will not initiate any further administrative proceedings against Seagate in connection with any violation of the EAR arising out of the transactions detailed in the Settlement Agreement.

- changed (2025-10-31):
[0001137789-25-000317:note_history:6]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $120 million were included in Accrued expense and Other non-current liabilities, respectively, on the Condensed Consolidated Balance Sheets as of October 3, 2025. For the three months ended October 3, 2025, $15 million was paid and reported as an outflow from operating activities in its Condensed Consolidated Statements of Cash Flows.
  (was, 2025-05-02, similarity 0.8935):
[0001137789-25-000075:note_history:6]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $150 million were included in Accrued expense and Other non-current liabilities, respectively, on the Condensed Consolidated Balance Sheets as of March 28, 2025. For the nine months ended March 28, 2025, $45 million was paid and reported as an outflow from operating activities in its Condensed Consolidated Statements of Cash Flows.

- changed (2025-10-31):
[0001137789-25-000317:note_history:7]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.
  (was, 2025-05-02, similarity 0.9942):
[0001137789-25-000075:note_history:7]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air, soil and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

- removed (2025-10-31):
[0001137789-25-000075:note_history:8]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the U.S. District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendant misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, and additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 8, 2022, the court entered an Amended Stipulation and Order of Dismissal with Prejudice to dismiss all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment under the Foreign Trade Antitrust Improvement Act (“FTAIA Motion”) against Seagate’s antitrust claims, and on October 14, 2022, the Seagate Entities filed their corresponding opposition. On May 15, 2023, the court issued a ruling that Seagate’s antitrust claims can proceed as to suspension assemblies that enter the United States but not as to suspension assembles that do not enter the United States. On July 28, 2023, the District Court initiated a reconsideration of this ruling and requested further briefing. On November 17, 2023, the Court granted NHK’s FTAIA Motion and denied Seagate’s Motion for Leave to Amend the Complaint. Seagate filed a motion on December 15, 2023 for the Court to certify the ruling for interlocutory appeal. On April 22, 2024, the District Court granted in part and denied in part Seagate’s motion to certify for interlocutory appeal the Court’s ruling on NHK’s FTAIA Motion. On May 2, 2024, Seagate filed a Petition for Permission to Appeal to the Ninth Circuit. On July 18, 2024, the United States Court of Appeals for the Ninth Circuit issued an order granting Seagate’s Petition for Permission to Appeal. The FTAIA issue is now on appeal with the Ninth Circuit.

- removed (2025-10-31):
[0001137789-25-000075:note_history:9]
In re Seagate Technology Holdings plc Securities Litigation. A putative class action lawsuit alleging violations of the federal securities laws, UA Local 38 Defined Contribution Pension Plan, et al. v. Seagate Technology Holdings PLC, et al., was filed on July 10, 2023, in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The complaint alleged that it was a securities class action on behalf of all purchasers of Seagate common stock between September 15, 2020 and October 25, 2022, inclusive, and asserted claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b5-1. The complaint sought unspecified monetary damages and other relief. A second action, Public Employees’ Retirement System of Mississippi v. Seagate Technology Holdings plc, William David Mosley, and Gianluca Romano, was filed on July 26, 2023, asserting similar claims. The cases were consolidated on September 25, 2023. On October 19, 2023, plaintiffs filed an amended complaint asserting similar claims with a putative class period of September 14, 2020 through April 19, 2023. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint. On August 8, 2024, the Court granted the Company’s motion to dismiss, with leave to amend. On September 12, 2024, the Plaintiffs filed an amended complaint. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint. The Company believes that the asserted claims are without merit and intends to vigorously defend the case.

- removed (2025-10-31):
[0001137789-25-000075:note_history:10]
Godo Kaisha IP Bridge 1 v. Seagate Technology LLC, Seagate Technology (US) Holding, Inc., Seagate Technology (Thailand) Limited, Seagate Singapore International Headquarters Ltd., Seagate Technology (Netherlands) B.V. On March 15, 2024, a patent infringement action was filed by Godo Kaisha IP Bridge 1 (“IP Bridge”) against Seagate in U.S. District Court for the District of Delaware. The complaint alleges patent infringement by Seagate of three U.S. patents. On June 7, 2024, Seagate filed a motion to transfer venue to Minnesota. On July 8, 2024, IP Bridge filed a First Amended Complaint alleging patent infringement by Seagate of six additional patents. IP Bridge is seeking damages as well as additional relief. On September 4, 2024, the court granted Seagate’s motion to transfer the case to the District Court of Minnesota. On October 16, 2024, Seagate filed its answer to the First Amended Complaint. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

- removed (2025-10-31):
[0001137789-25-000075:note_history:11]
The Company has established an environmental management system and continually reviews and updates environmental policies and standard operating procedures for operations worldwide as needed. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

- removed (2025-10-31):
[0001137789-25-000075:note_history:12]
While Seagate believed that it complied with all relevant export control laws at the time it made the hard disk drive sales at issue, Seagate determined that engaging with BIS and settling this matter was in the best interest of the Company, its customers, and its shareholders. In determining to engage with BIS and resolve this matter through a settlement agreement, the Company considered a number of factors, including the risks and cost of protracted litigation involving the U.S. government, and the size of the potential penalty and the Company’s desire to focus on current business challenges and long-term business strategy. The Settlement Agreement includes a finding that the Company incorrectly interpreted the regulation at issue to require evaluation of only the last stage of Seagate’s hard disk drive manufacturing process rather than the entire process. As part of this settlement, Seagate has agreed not to contest BIS’ determination that the sales in question did not comply with the U.S. EAR.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0001137789-25-000317:note_history:13]
HDDs are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. HDDs continue to be the primary medium of mass data storage due to their performance attributes, reliability, high capacities, superior quality and cost effectiveness.
  (was, 2025-05-02, similarity 0.8259):
[0001137789-25-000075:note_history:13]
HDDs are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. HDDs continue to be the primary medium of mass data storage due to their performance attributes, reliability, high capacities, superior quality and cost effectiveness. Complementing HDD storage architectures, SSDs use NAND flash memory integrated circuit assemblies to store data.

- added (2025-10-31):
[0001137789-25-000317:note_history:14]
Beginning in fiscal year 2026, the Company changed its presentation of principal data storage markets to better reflect current demand drivers and the growing impact of Artificial Intelligence (“AI”)-driven applications. The Company now presents its products and services under two end markets: Data center and Edge Internet of Things (“Edge IoT”). Data center comprises the majority of the Company’s business and primarily includes high-capacity nearline products for mass capacity data storage and systems sold to cloud and enterprise customers, as well as cloud-based video and image applications. Edge IoT primarily includes consumer and client-centric markets along with network-attached storage, mission critical and SSD.

- changed (2025-10-31):
[0001137789-25-000317:note_history:15]
The Company’s Consolidated Financial Statements for the fiscal year ended June 27, 2025 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 1, 2025. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 27, 2025, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three months ended October 3, 2025 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending July 3, 2026.
  (was, 2025-05-02, similarity 0.9582):
[0001137789-25-000075:note_history:15]
The Company’s Consolidated Financial Statements for the fiscal year ended June 28, 2024 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 2, 2024. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 28, 2024, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and nine months ended March 28, 2025 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 27, 2025.

- changed (2025-10-31):
[0001137789-25-000317:note_history:16]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three months ended October 3, 2025 consisted of 14 weeks and the three months ended September 27, 2024 consisted of 13 weeks, respectively. Fiscal years 2026 and 2025 comprise 53 and 52 weeks and end on July 3, 2026 and June 27, 2025, respectively. The fiscal quarters ended October 3, 2025, June 27, 2025 and September 27, 2024, are also referred to herein as the “September 2025 quarter”, the “June 2025 quarter” and the “September 2024 quarter”, respectively.
  (was, 2025-05-02, similarity 0.6551):
[0001137789-25-000075:note_history:16]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and nine months ended March 28, 2025 and March 29, 2024 consisted of 13 and 39 weeks, respectively. Fiscal years 2025 and 2024 both comprise 52 weeks and end on June 27, 2025 and June 28, 2024, respectively. The fiscal quarters ended March 28, 2025, December 27, 2024 and March 29, 2024, are also referred to herein as the “March 2025 quarter”, the “December 2024 quarter” and the “March 2024 quarter”, respectively.

- changed (2025-10-31):
[0001137789-25-000317:note_history:17]
In November 2023, the FASB issued ASU 2023-07 (ASC Topic 280), Improvements to Reportable Segment Disclosures. This ASU improves reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The Company adopted the disclosure requirement for its annual reporting in fiscal year 2025 and adopted the guidance for interim period reporting beginning the first quarter of fiscal year 2026 on a retrospective basis. Refer to “Note 7. Business Segment”.
  (was, 2025-05-02, similarity 0.7459):
[0001137789-25-000075:note_history:17]
In November 2023, the FASB issued ASU 2023-07 (ASC Topic 280), Improvements to Reportable Segment Disclosures. This ASU improves reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The Company is required to adopt this guidance for its annual reporting in fiscal year 2025 and for interim period reporting beginning the first quarter of fiscal year 2026 on a retrospective basis. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have an impact on its Condensed Consolidated Financial Statements.

- changed (2025-10-31):
[0001137789-25-000317:note_history:18]
In December 2023, the FASB issued ASU 2023-09 (ASC Topic 740), Improvements to Income Tax Disclosures. This ASU requires disaggregated income tax disclosures on the rate reconciliation and income taxes paid. The Company is required to adopt this guidance for its annual reporting in fiscal year 2026 on a prospective basis but has the option to apply it retrospectively. This standard is expected to impact the Company’s disclosures and will not have an impact on its Consolidated Financial Statements.
  (was, 2025-05-02, similarity 0.9617):
[0001137789-25-000075:note_history:18]
In December 2023, the FASB issued ASU 2023-09 (ASC Topic 740), Improvements to Income Tax Disclosures. This ASU requires disaggregated income tax disclosures on the rate reconciliation and income taxes paid. The Company is required to adopt this guidance for its annual reporting in fiscal year 2026 on a prospective basis but has the option to apply it retrospectively. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have an impact on its Condensed Consolidated Financial Statements.

- removed (2025-10-31):
[0001137789-25-000075:note_history:19]
The Company’s HDD products are designed for mass capacity storage and legacy markets. Mass capacity storage involves well-established use cases, such as hyperscale data centers and public clouds as well as emerging use cases. Legacy markets are those that the Company continues to sell to but does not plan to invest in significantly. The Company’s HDD and SSD product portfolio includes Serial Advanced Technology Attachment (“SATA”), Serial Attached SCSI (“SAS”) and Non-Volatile Memory Express (“NVMe”) based designs to support a wide variety of mass capacity and legacy applications.

- removed (2025-10-31):
[0001137789-25-000075:note_history:20]
The Company’s systems portfolio includes storage subsystems for enterprises, cloud service providers (“CSPs”), scale-out storage servers and original equipment manufacturers (“OEMs”). Engineered for modularity, mobility, capacity and performance, these solutions include the Company’s enterprise HDDs and SSDs, enabling customers to integrate powerful, scalable storage within existing environments or create new ecosystems from the ground up in a secure, cost-effective manner.

- removed (2025-10-31):
[0001137789-25-000075:note_history:21]
The Company’s Lyve portfolio provides a simple, cost-efficient and secure way to manage massive volumes of data across the distributed enterprise. The Lyve platform includes a shuttle solution that enables enterprises to transfer massive amounts of data from endpoints to the core cloud and a storage-as-a-service cloud offering that provides frictionless mass capacity storage at the metro edge.

- removed (2025-10-31):
[0001137789-25-000075:note_history:22]
In September 2022, the Financial Accounting Standards Board (FASB) issued ASU 2022-04 (ASC Subtopic 405-50), Disclosure of Supplier Finance Program Obligations. This ASU requires disclosure of key terms of the outstanding supplier finance programs and a rollforward of the related obligations. The Company adopted the disclosure requirement on rollforward information in the quarter ended September 27, 2024. Refer to “Note 2. Balance Sheet Information” for more details.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0001137789-25-000317:note_history:23]
Debt
The following table provides details of the Company’s debt as of October 3, 2025 and June 27, 2025:
  (was, 2025-05-02, similarity 0.9468):
[0001137789-25-000075:note_history:23]
Debt
The following table provides details of the Company’s debt as of March 28, 2025 and June 28, 2024:

- added (2025-10-31):
[0001137789-25-000317:note_history:24]
| (Dollars in millions) |  | October 3, 2025 |  | June 27, 2025 |
| Unsecured Senior Notes issued by Seagate HDD Cayman (1) |  |  |  |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “Old June 2029 Notes”) (3) |  | 38 |  |  | 452 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “Old July 2029 Notes”) (4) |  | 38 |  |  | 138 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “Old December 2029 Notes”) (5) |  | 8 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “Old January 2031 Notes”) (4) |  | 23 |  |  | 237 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “Old July 2031 Notes”) (4) |  | 16 |  |  | 61 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “Old 8.50% July 2031 Notes”) (4) |  | 29 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “Old 2032 Notes”) (3) |  | 19 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “Old 2034 Notes”) (3) |  | 162 |  |  | 489 |  |
| Unsecured Senior Notes issued by Seagate Data Storage Technology Pte. Ltd. (2) |  |  |  |  |
| $400 issued on May 27, 2025 at 5.875% due July 15, 2030 (the “2030 Notes”) (4) |  | 400 |  |  | 400 |  |
| $431 issued on June 30, 2025 at 4.091% due June 1, 2029 (the “New June 2029 Notes”) (3) |  | 415 |  |  | — |  |
| $100 issued on June 30, 2025 at 3.125% due July 15, 2029 (the “New July 2029 Notes”) (4) |  | 100 |  |  | — |  |
| $492 issued on June 30, 2025 at 8.25% due December 15, 2029 (the “New December 2029 Notes”) (5) |  | 492 |  |  | — |  |
| $213 issued on June 30, 2025 at 4.125% due January 15, 2031 (the “New January 2031 Notes”) (4) |  | 213 |  |  | — |  |
| $45 issued on June 30, 2025 at 3.375% due July 15, 2031 (the “New July 2031 Notes”) (4) |  | 45 |  |  | — |  |
| $471 issued on June 30, 2025 at 8.50% due July 15, 2031 (the “New 8.50% July 2031 Notes”) (4) |  | 471 |  |  | — |  |
| $731 issued on June 30, 2025 at 9.625% due December 1, 2032 (the “New 2032 Notes”) (3) |  | 731 |  |  | — |  |
| $328 issued on June 30, 2025 at 5.75% due December 1, 2034 (the “New 2034 Notes”) (3) |  | 327 |  |  | — |  |
| Exchangeable Senior Notes (1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”) (6) |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,027 |  |  | 5,027 |  |
| Less: unamortized debt issuance costs |  | (33) |  |  | (32) |  |
| Debt, net of debt issuance costs |  | 4,994 |  |  | 4,995 |  |
| Less: current portion of long-term debt, net of debt issuance costs |  | (1,496) |  |  | — |  |
| Long-term debt, less current portion |  | $ | 3,498 |  |  | $ | 4,995 |  |

- added (2025-10-31):
[0001137789-25-000317:note_history:25]
(1) Notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes were fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and Seagate Technology Holdings plc (“STH PLC”). Supplemental indentures for each series of Old Notes (as defined below) became operative on June 30, 2025 and gave effect to certain amendments which, among other things, released STUC and STH PLC from their respective guarantee obligations with respect to each series of Old Notes.

- added (2025-10-31):
[0001137789-25-000317:note_history:26]
(2) Notes are issued by Seagate Data Storage Technology Pte. Ltd. (“SDST”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STUC, Seagate HDD and STH PLC.

- added (2025-10-31):
[0001137789-25-000317:note_history:27]
(3) Interest payable semi-annually on June 1 and December 1 of each year.

- added (2025-10-31):
[0001137789-25-000317:note_history:28]
(4) Interest payable semi-annually on January 15 and July 15 of each year.

- added (2025-10-31):
[0001137789-25-000317:note_history:29]
(5) Interest payable semi-annually on June 15 and December 15 of each year.

- added (2025-10-31):
[0001137789-25-000317:note_history:30]
(6) Interest payable semi-annually on March 1 and September 1 of each year.

- added (2025-10-31):
[0001137789-25-000317:note_history:31]
Obligor Exchange

- added (2025-10-31):
[0001137789-25-000317:note_history:32]
On June 27, 2025, the Company completed offers to exchange (collectively, the “Exchange Offers”) any and all outstanding notes of eight series issued by Seagate HDD (the “Old Notes”) for new notes to be issued by SDST (the “New Notes”), and related consent solicitations.

- added (2025-10-31):
[0001137789-25-000317:note_history:33]
In accordance with the terms of the Exchange Offers and consent solicitations, the Company accepted for exchange all Old Notes validly tendered. The Exchange Offers and the consent solicitations were settled on June 30, 2025. No gain or loss was recorded as the Exchange Offers were accounted for as a debt modification. The Company incurred immaterial third party fees for the Exchange Offers during the September 2025 quarter.

- added (2025-10-31):
[0001137789-25-000317:note_history:34]
Other than the identity of SDST as the issuer and as an obligor, the terms of the New Notes are identical to the Old Notes with respect to their interest rate, interest payment dates, optional redemption prices and maturity. The New Notes were guaranteed by the same guarantors as the Old Notes, in addition to Seagate HDD (which is the issuer of the Old Notes). The New Notes have substantially the same covenants as the Old Notes and are subject to the same business and financial risks.

- changed (2025-10-31):
[0001137789-25-000317:note_history:35]
For the three months ended October 3, 2025, the effective interest rate for the 3.50% Exchangeable Senior Notes due 2028 (the “2028 Notes”) was 3.94%, with contractual interest expense of $14 million and immaterial amortization of debt issuance costs. For the three months ended September 27, 2024, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $13 million and immaterial amortization of debt issuance costs.
  (was, 2025-05-02, similarity 0.7605):
[0001137789-25-000075:note_history:35]
For the three and nine months ended March 28, 2025, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $13 million and $39 million, respectively, and immaterial amortization of debt issuance costs. For the three and nine months ended March 29, 2024, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $13 million and $29 million, respectively, and immaterial amortization of debt issuance costs.

- added (2025-10-31):
[0001137789-25-000317:note_history:36]
Prior to March 1, 2028, the 2028 Notes are exchangeable at the option of the holders only under certain circumstances as set out in the indenture for the 2028 Notes. As of the calendar quarter ended September 30, 2025, the sale price conditional conversion option of the 2028 Notes was triggered. Accordingly, the 2028 Notes are exchangeable through December 31, 2025. The Company has classified the total balance of the 2028 Notes as the Current portion of long-term debt within Current liabilities in the Company’s Condensed Consolidated Balance Sheets as of October 3, 2025.

- changed (2025-10-31):
[0001137789-25-000317:note_history:37]
Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The exchange rate for the 2028 Notes as of October 3, 2025 is 12.1335 ordinary shares per $1,000 principal amount of 2028 Notes, which is equivalent to an exchange price of approximately $82.42 per share as of October 3, 2025. The exchange rate was adjusted from 12.1324 ordinary shares per $1,000 principal amount of 2028 Notes on September 30, 2025, and is subject to further adjustment pursuant to the terms of the Exchangeable Notes indenture.
  (was, 2025-05-02, similarity 0.93):
[0001137789-25-000075:note_history:37]
Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The current exchange rate for the 2028 Notes is 12.1306 ordinary shares per $1,000 principal amount of 2028 Notes, which is equivalent to an exchange price of approximately $82.44 per share as of March 28, 2025. The exchange rate was adjusted from 12.1278 ordinary shares per $1,000 principal amount of 2028 Notes on March 19, 2025, and is subject to further adjustment pursuant to the terms of the Exchangeable Notes indenture.

- added (2025-10-31):
[0001137789-25-000317:note_history:38]
Seagate HDD may redeem the 2028 Notes at its option:

- added (2025-10-31):
[0001137789-25-000317:note_history:39]
(i) at any time, in whole but not in part, if Seagate HDD or the Guarantors have, or on the next interest payment date would, become obligated to pay to the holder of any 2028 Note additional amounts as a result of certain tax-related events which cannot be avoided by taking commercially reasonable measures and which have been confirmed by an opinion of outside legal counsel (a “Tax Redemption”); and/or

- changed (2025-10-31):
[0001137789-25-000317:note_history:40]
(ii) on or after September 8, 2026, in whole or in part. if the last reported sale price of ordinary shares of the Company has been at least 130% of the exchange price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (a “Provisional Redemption”) at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If Seagate HDD redeems less than all the outstanding 2028 Notes, at least $150 million aggregate principal amount of 2028 Notes must be outstanding and not subject to redemption as of the relevant notice of redemption date.
  (was, 2025-05-02, similarity 0.7948):
[0001137789-25-000075:note_history:40]
Seagate HDD also may redeem the 2028 Notes at its option on or after September 8, 2026, in whole or in part, if the last reported sale price of ordinary shares of the Company has been at least 130% of the exchange price then in effect for at least 20 trading days (whether or not consecutive), including the trading day immediately preceding the date on which Seagate HDD provides notice of redemption, during any 30 consecutive trading day period ending on, and including, the trading day immediately preceding the date on which Seagate HDD provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If Seagate HDD redeems less than all the outstanding 2028 Notes, at least $150 million aggregate principal amount of 2028 Notes must be outstanding and not subject to redemption as of the relevant notice of redemption date.

- added (2025-10-31):
[0001137789-25-000317:note_history:41]
If Seagate HDD elects to redeem any of the 2028 Notes pursuant to a Tax Redemption or a Provisional Redemption, then a holder of any such called 2028 Notes (the “Redemption Called Notes”) may exchange such Redemption Called Notes at any time prior to the close of business on the second scheduled trading day preceding the relevant redemption date, or if later, until the relevant redemption price is paid.

- added (2025-10-31):
[0001137789-25-000317:note_history:42]
If a holder elects to exchange any Redemption Called Notes, Seagate HDD shall, under certain circumstances, increase the exchange rate for such Redemption Called Notes as set out in the indenture for the 2028 Notes.

- changed (2025-10-31):
[0001137789-25-000317:note_history:43]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The current cap price of the capped call transactions, which was adjusted on September 30, 2025 in accordance with the applicable capped call confirmations, is $107.775 per share. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets.
  (was, 2025-05-02, similarity 0.9899):
[0001137789-25-000075:note_history:43]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The current cap price of the capped call transactions, which was adjusted on March 19, 2025 in accordance with the applicable capped call confirmations, is $107.801 per share. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets.

- changed (2025-10-31):
[0001137789-25-000317:note_history:44]
On January 30, 2025, the Company and its subsidiary Seagate HDD Cayman (the “Borrower”), the Bank of Nova Scotia, as administrative agent, and the lenders thereto entered into a Credit Agreement (the “Credit Agreement”) which provides for a $1.3 billion senior unsecured revolving credit facility (“Revolving Credit Facility”), the term of which is through January 30, 2030. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing. An aggregate amount of up to $150 million of the facility shall also be available for the issuance of letters of credit, and an aggregate amount of up to $50 million of the facility shall also be available for swing line loans. On October 3, 2025, no borrowings were outstanding under the Credit Agreement.
  (was, 2025-05-02, similarity 0.8193):
[0001137789-25-000075:note_history:44]
The New Credit Agreement provides for a $1.3 billion senior unsecured revolving credit facility (“Revolving Credit Facility”), the term of which is through January 30, 2030. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing. An aggregate amount of up to $150 million of the facility shall also be available for the issuance of letters of credit, and an aggregate amount of up to $50 million of the facility shall also be available for swing line loans. On March 28, 2025, no borrowings were outstanding under the New Credit Agreement.

- changed (2025-10-31):
[0001137789-25-000317:note_history:45]
The loans made under the Credit Agreement will bear interest at an Applicable Rate based on the secured overnight financing rate, or SOFR, plus a variable margin that will be determined based on the corporate credit rating of the Company. The Borrower’s obligations under the Credit Agreement are guaranteed by the Company and certain material subsidiaries of the Company.
  (was, 2025-05-02, similarity 0.9894):
[0001137789-25-000075:note_history:45]
The loans made under the New Credit Agreement will bear interest at an Applicable Rate based on the secured overnight financing rate, or SOFR, plus a variable margin that will be determined based on the corporate credit rating of the Company. The Borrower’s obligations under the New Credit Agreement are guaranteed by the Company and certain material subsidiaries of the Company.

- changed (2025-10-31):
[0001137789-25-000317:note_history:46]
The Credit Agreement also contains a financial covenant that requires the Company to maintain a total net leverage ratio of less than or equal to 6.75 to 1.00, commencing with the fiscal quarter ended June 27, 2025 and declining over time so that the maximum permitted net leverage ratio for each fiscal quarter ending after July 2, 2027 is 4.25 to 1.00, in accordance with the terms of the Credit Agreement. For each fiscal quarter until January 2, 2026, this net leverage ratio covenant applies only to the extent that there is any amount of revolving loans, swing line loans, or letters of credit outstanding as of the last day of the relevant fiscal quarter.
  (was, 2025-05-02, similarity 0.9898):
[0001137789-25-000075:note_history:46]
The New Credit Agreement also contains a financial covenant that requires the Company to maintain a total net leverage ratio of less than or equal to 6.75 to 1.00, commencing with the fiscal quarter ending June 27, 2025 and declining over time so that the maximum permitted net leverage ratio for each fiscal quarter ending after July 2, 2027 is 4.25 to 1.00, in accordance with the terms of the New Credit Agreement. For each fiscal quarter until January 2, 2026, this net leverage ratio covenant applies only to the extent that there is any amount of revolving loans, swing line loans, or letters of credit outstanding as of the last day of the relevant fiscal quarter.

- changed (2025-10-31):
[0001137789-25-000317:note_history:47]
At October 3, 2025, future principal payments on long-term debt were as follows (in millions):
  (was, 2025-05-02, similarity 0.9432):
[0001137789-25-000075:note_history:47]
At March 28, 2025, future principal payments on long-term debt were as follows (in millions):

- changed (2025-10-31):
[0001137789-25-000317:note_history:48]
| Fiscal Year |  | Amount |
| Remainder of 2026 |  | — |  |
| 2027 |  | — |  |
| 2028 |  | 1,500 |  |
| 2029 |  | 470 |  |
| 2030 |  | 638 |  |
| Thereafter |  | 2,438 |  |
| Total |  | $ | 5,046 |  |
  (was, 2025-05-02, similarity 0.9872):
[0001137789-25-000075:note_history:48]
| Fiscal Year |  | Amount |
| Remainder of 2025 |  | $ | — |  |
| 2026 |  | — |  |
| 2027 |  | 505 |  |
| 2028 |  | 1,500 |  |
| 2029 |  | 481 |  |
| Thereafter |  | 2,707 |  |
| Total |  | $ | 5,193 |  |

- removed (2025-10-31):
[0001137789-25-000075:note_history:49]
| (Dollars in millions) |  | March 28, 2025 |  | June 28, 2024 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | — |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 505 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 461 |  |  | 471 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 144 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 252 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 71 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,172 |  |  | 5,704 |  |
| Less: unamortized debt issuance costs |  | (26) |  |  | (30) |  |
| Debt, net of debt issuance costs |  | 5,146 |  |  | 5,674 |  |
| Less: current portion of long-term debt |  | — |  |  | (479) |  |
| Long-term debt, less current portion |  | $ | 5,146 |  |  | $ | 5,195 |  |

- removed (2025-10-31):
[0001137789-25-000075:note_history:50]
(1) All unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and Seagate Technology Holdings plc.

- removed (2025-10-31):
[0001137789-25-000075:note_history:51]
2028 Notes. On September 13, 2023, Seagate HDD, in a private placement, issued $1.5 billion in aggregate principal amount of 3.50% Exchangeable Senior Notes due 2028 (the “2028 Notes”), which includes $200 million aggregate principal amount pursuant to the over-allotment option of the initial purchasers to purchase additional notes. The 2028 Notes will mature on June 1, 2028, with interest payable semi-annually on March 1 and September 1 of each year, commencing March 1, 2024.

- removed (2025-10-31):
[0001137789-25-000075:note_history:52]
The entire outstanding principal amount of Term Loans A1, A2 and A3 were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in Net loss from debt transactions in the Company’s Condensed Consolidated Statements of Operations for the nine months ended March 29, 2024. In connection with the repayment of Term Loans, the Company terminated certain interest rate swap agreements. Refer to “Note 5. Derivative Financial Instruments” for more details.

- removed (2025-10-31):
[0001137789-25-000075:note_history:53]
Prior to March 1, 2028, the 2028 Notes are exchangeable at the option of the holders only under the following circumstances:

- removed (2025-10-31):
[0001137789-25-000075:note_history:54]
•during any calendar quarter commencing after the calendar quarter ending on December 31, 2023 (and only during such calendar quarter), if the last reported sale price of the ordinary Shares for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter is greater than or equal to 130% of the exchange price in effect on each applicable trading day;

- removed (2025-10-31):
[0001137789-25-000075:note_history:55]
•during the five business day period after any ten consecutive trading day period in which the trading price per $1,000 principal amount of 2028 Notes for each trading day period was less than 98% of the product of the last reported sale price of the ordinary shares and the applicable exchange rate on such trading day; or

- removed (2025-10-31):
[0001137789-25-000075:note_history:56]
•upon the occurrence of specified corporate events described in the indenture with respect to the 2028 Notes.

- removed (2025-10-31):
[0001137789-25-000075:note_history:57]
Seagate HDD may redeem the 2028 Notes at its option, in whole but not in part, if Seagate HDD or the Guarantors have, or on the next interest payment date would, become obligated to pay to the holder of any Note additional amounts as a result of certain tax-related events at a redemption price equal to 100% of the principal amount plus accrued and unpaid interest, including additional interest, if any, to, but excluding, the redemption date; provided that Seagate HDD may only redeem the 2028 Notes if: (x) Seagate HDD or the relevant Guarantor cannot avoid these obligations by taking commercially reasonable measures available to Seagate HDD or such Guarantor; and (y) Seagate HDD delivers to the Trustee an opinion of outside legal counsel of recognized standing in the relevant taxing jurisdiction attesting to such tax-related event and obligation to pay additional amounts.

- removed (2025-10-31):
[0001137789-25-000075:note_history:58]
As of March 28, 2025, the 2028 Notes were not exchangeable. Refer to “Note 10. Earnings (Loss) Per Share” for the potential dilutive impact of the 2028 Notes.

- removed (2025-10-31):
[0001137789-25-000075:note_history:59]
2025 Notes

- removed (2025-10-31):
[0001137789-25-000075:note_history:60]
On January 2, 2025, the entire outstanding principal amount of $479 million was repaid at par, plus accrued and unpaid interest.

- removed (2025-10-31):
[0001137789-25-000075:note_history:61]
On January 30, 2025, the Company and its subsidiary Seagate HDD Cayman (the “Borrower”), the Bank of Nova Scotia, as administrative agent, and the lenders thereto entered into a Credit Agreement (the “New Credit Agreement”) and terminated their then-existing Credit Agreement, dated as of February 20, 2019 (the “Old Credit Agreement”). As a result of terminating the Old Credit Agreement, the Company recorded an $8 million non-cash loss related to the accelerated amortization of debt issuance costs, which was included in Net loss from debt transactions in the Company’s Condensed Consolidated Statements of Operations.

- removed (2025-10-31):
[0001137789-25-000075:note_history:62]
Debt Repurchases

- removed (2025-10-31):
[0001137789-25-000075:note_history:63]
During the March 2025 quarter, $14 million principal amount of the June 2029 Notes, $19 million principal amount of the July 2029 Notes, $23 million principal amount of the January 2031 Notes and $1 million principal amount of the July 2031 Notes were repurchased for cash at a discount to their principal amounts, plus accrued and unpaid interest. The Company recorded a net gain of $4 million on these repurchases during the March 2025 quarter, which was included in Net loss from debt transactions in the Company’s Condensed Consolidated Statements of Operations.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-10-31):
[0001137789-25-000317:note_history:64]
The Company’s debt is carried at amortized cost. The estimated fair value of the Company’s debt is derived using the closing price of the same debt instruments as of the date of valuation, which takes into account the trading price of ordinary shares, yield curve, interest rates and other observable inputs. Accordingly, these fair value measurements are categorized as Level 2. The following table presents the fair value and amortized cost of the Company’s debt by class of note, in order of maturity:

- added (2025-10-31):
[0001137789-25-000317:note_history:65]
|  |  | October 3, 2025 |  | June 27, 2025 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| Exchangeable Senior Notes |  |  |  |  |  |  |  |  |
| 3.50% Exchangeable Senior Notes due June 2028 |  | 1,500 |  |  | 4,739 |  |  | 1,500 |  |  | 2,654 |  |
| Unsecured Senior Notes Issued by Seagate HDD Cayman |  |  |  |  |  |  |  |  |
| 4.091% Senior Notes due June 2029 |  | 38 |  |  | 38 |  |  | 452 |  |  | 453 |  |
| 3.125% Senior Notes due July 2029 |  | 38 |  |  | 33 |  |  | 138 |  |  | 125 |  |
| 8.25% Senior Notes due December 2029 |  | 8 |  |  | 8 |  |  | 500 |  |  | 535 |  |
| 4.125% Senior Notes due January 2031 |  | 23 |  |  | 22 |  |  | 237 |  |  | 218 |  |
| 3.375% Senior Notes due July 2031 |  | 16 |  |  | 14 |  |  | 61 |  |  | 52 |  |
| 8.50% Senior Notes due July 2031 |  | 29 |  |  | 31 |  |  | 500 |  |  | 538 |  |
| 9.625% Senior Notes due December 2032 |  | 19 |  |  | 22 |  |  | 750 |  |  | 854 |  |
| 5.75% Senior Notes due December 2034 |  | 162 |  |  | 163 |  |  | 489 |  |  | 482 |  |
| Unsecured Senior Notes issued by Seagate Data Storage Technology Pte. Ltd. |  |  |  |  |  |  |  |  |
| 4.091% Senior Notes due June 2029 |  | 415 |  |  | 419 |  |  | — |  |  | — |  |
| 3.125% Senior Notes due July 2029 |  | 100 |  |  | 86 |  |  | — |  |  | — |  |
| 8.25% Senior Notes due December 2029 |  | 492 |  |  | 522 |  |  | — |  |  | — |  |
| 5.875% Senior Notes due July 2030 |  | 400 |  |  | 409 |  |  | 400 |  |  | 407 |  |
| 4.125% Senior Notes due January 2031 |  | 213 |  |  | 199 |  |  | — |  |  | — |  |
| 3.375% Senior Notes due July 2031 |  | 45 |  |  | 38 |  |  | — |  |  | — |  |
| 8.50% Senior Notes due July 2031 |  | 471 |  |  | 501 |  |  | — |  |  | — |  |
| 9.625% Senior Notes due December 2032 |  | 731 |  |  | 830 |  |  | — |  |  | — |  |
| 5.75% Senior Notes due December 2034 |  | 327 |  |  | 329 |  |  | — |  |  | — |  |
|  |  | $ | 5,027 |  |  | $ | 8,403 |  |  | $ | 5,027 |  |  | $ | 6,318 |  |
| Less: unamortized debt issuance costs |  | (33) |  |  | — |  |  | (32) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 4,994 |  |  | $ | 8,403 |  |  | $ | 4,995 |  |  | $ | 6,318 |  |
| Less: current portion of debt, net of debt issuance costs |  | (1,496) |  |  | — |  |  | — |  |  | — |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 3,498 |  |  | $ | 8,403 |  |  | $ | 4,995 |  |  | $ | 6,318 |  |

- removed (2025-10-31):
[0001137789-25-000075:note_history:66]
The Company’s debt is carried at amortized cost. The estimated fair value of the Company’s debt is derived using the closing price of the same debt instruments as of the date of valuation, which takes into account the yield curve, interest rates and other observable inputs. Accordingly, these fair value measurements are categorized as Level 2. The following table presents the fair value and amortized cost of the Company’s debt in order of maturity:

- removed (2025-10-31):
[0001137789-25-000075:note_history:67]
|  |  | March 28, 2025 |  | June 28, 2024 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 4.75% Senior Notes due January 2025 |  | — |  |  | — |  |  | 479 |  |  | 476 |  |
| 4.875% Senior Notes due June 2027 |  | 505 |  |  | 499 |  |  | 505 |  |  | 493 |  |
| 3.50% Exchangeable Senior Notes due June 2028 |  | 1,500 |  |  | 1,833 |  |  | 1,500 |  |  | 2,070 |  |
| 4.091% Senior Notes due June 2029 |  | 461 |  |  | 455 |  |  | 471 |  |  | 459 |  |
| 3.125% Senior Notes due July 2029 |  | 144 |  |  | 129 |  |  | 163 |  |  | 139 |  |
| 8.25% Senior Notes due December 2029 |  | 500 |  |  | 532 |  |  | 500 |  |  | 537 |  |
| 4.125% Senior Notes due January 2031 |  | 252 |  |  | 231 |  |  | 275 |  |  | 245 |  |
| 3.375% Senior Notes due July 2031 |  | 71 |  |  | 61 |  |  | 72 |  |  | 58 |  |
| 8.50% Senior Notes due July 2031 |  | 500 |  |  | 532 |  |  | 500 |  |  | 538 |  |
| 9.625% Senior Notes due December 2032 |  | 750 |  |  | 847 |  |  | 750 |  |  | 855 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 477 |  |  | 489 |  |  | 472 |  |
|  |  | $ | 5,172 |  |  | $ | 5,596 |  |  | $ | 5,704 |  |  | $ | 6,342 |  |
| Less: unamortized debt issuance costs |  | (26) |  |  | — |  |  | (30) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 5,146 |  |  | $ | 5,596 |  |  | $ | 5,674 |  |  | $ | 6,342 |  |
| Less: current portion of debt, net of debt issuance costs |  | — |  |  | — |  |  | (479) |  |  | (476) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,146 |  |  | $ | 5,596 |  |  | $ | 5,195 |  |  | $ | 5,866 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0001137789-25-000317:note_history:68]
The following table provides details of the Company’s debt as of October 3, 2025 and June 27, 2025:
  (was, 2025-05-02, similarity 0.9438):
[0001137789-25-000075:note_history:68]
The following table provides details of the Company’s debt as of March 28, 2025 and June 28, 2024:

- added (2025-10-31):
[0001137789-25-000317:note_history:69]
| (Dollars in millions) |  | October 3, 2025 |  | June 27, 2025 |
| Unsecured Senior Notes issued by Seagate HDD Cayman (1) |  |  |  |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “Old June 2029 Notes”) (3) |  | 38 |  |  | 452 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “Old July 2029 Notes”) (4) |  | 38 |  |  | 138 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “Old December 2029 Notes”) (5) |  | 8 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “Old January 2031 Notes”) (4) |  | 23 |  |  | 237 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “Old July 2031 Notes”) (4) |  | 16 |  |  | 61 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “Old 8.50% July 2031 Notes”) (4) |  | 29 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “Old 2032 Notes”) (3) |  | 19 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “Old 2034 Notes”) (3) |  | 162 |  |  | 489 |  |
| Unsecured Senior Notes issued by Seagate Data Storage Technology Pte. Ltd. (2) |  |  |  |  |
| $400 issued on May 27, 2025 at 5.875% due July 15, 2030 (the “2030 Notes”) (4) |  | 400 |  |  | 400 |  |
| $431 issued on June 30, 2025 at 4.091% due June 1, 2029 (the “New June 2029 Notes”) (3) |  | 415 |  |  | — |  |
| $100 issued on June 30, 2025 at 3.125% due July 15, 2029 (the “New July 2029 Notes”) (4) |  | 100 |  |  | — |  |
| $492 issued on June 30, 2025 at 8.25% due December 15, 2029 (the “New December 2029 Notes”) (5) |  | 492 |  |  | — |  |
| $213 issued on June 30, 2025 at 4.125% due January 15, 2031 (the “New January 2031 Notes”) (4) |  | 213 |  |  | — |  |
| $45 issued on June 30, 2025 at 3.375% due July 15, 2031 (the “New July 2031 Notes”) (4) |  | 45 |  |  | — |  |
| $471 issued on June 30, 2025 at 8.50% due July 15, 2031 (the “New 8.50% July 2031 Notes”) (4) |  | 471 |  |  | — |  |
| $731 issued on June 30, 2025 at 9.625% due December 1, 2032 (the “New 2032 Notes”) (3) |  | 731 |  |  | — |  |
| $328 issued on June 30, 2025 at 5.75% due December 1, 2034 (the “New 2034 Notes”) (3) |  | 327 |  |  | — |  |
| Exchangeable Senior Notes (1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”) (6) |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,027 |  |  | 5,027 |  |
| Less: unamortized debt issuance costs |  | (33) |  |  | (32) |  |
| Debt, net of debt issuance costs |  | 4,994 |  |  | 4,995 |  |
| Less: current portion of long-term debt, net of debt issuance costs |  | (1,496) |  |  | — |  |
| Long-term debt, less current portion |  | $ | 3,498 |  |  | $ | 4,995 |  |

- added (2025-10-31):
[0001137789-25-000317:note_history:70]
(1) Notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes were fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and Seagate Technology Holdings plc (“STH PLC”). Supplemental indentures for each series of Old Notes (as defined below) became operative on June 30, 2025 and gave effect to certain amendments which, among other things, released STUC and STH PLC from their respective guarantee obligations with respect to each series of Old Notes.

- added (2025-10-31):
[0001137789-25-000317:note_history:71]
(2) Notes are issued by Seagate Data Storage Technology Pte. Ltd. (“SDST”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STUC, Seagate HDD and STH PLC.

- added (2025-10-31):
[0001137789-25-000317:note_history:72]
(3) Interest payable semi-annually on June 1 and December 1 of each year.

- added (2025-10-31):
[0001137789-25-000317:note_history:73]
(4) Interest payable semi-annually on January 15 and July 15 of each year.

- added (2025-10-31):
[0001137789-25-000317:note_history:74]
(5) Interest payable semi-annually on June 15 and December 15 of each year.

- added (2025-10-31):
[0001137789-25-000317:note_history:75]
(6) Interest payable semi-annually on March 1 and September 1 of each year.

- removed (2025-10-31):
[0001137789-25-000075:note_history:76]
| (Dollars in millions) |  | March 28, 2025 |  | June 28, 2024 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | — |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 505 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 461 |  |  | 471 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 144 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 252 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 71 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,172 |  |  | 5,704 |  |
| Less: unamortized debt issuance costs |  | (26) |  |  | (30) |  |
| Debt, net of debt issuance costs |  | 5,146 |  |  | 5,674 |  |
| Less: current portion of long-term debt |  | — |  |  | (479) |  |
| Long-term debt, less current portion |  | $ | 5,146 |  |  | $ | 5,195 |  |

- removed (2025-10-31):
[0001137789-25-000075:note_history:77]
(1) All unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and Seagate Technology Holdings plc.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0001137789-25-000317:note_history:78]
At October 3, 2025, future principal payments on long-term debt were as follows (in millions):
  (was, 2025-05-02, similarity 0.9432):
[0001137789-25-000075:note_history:78]
At March 28, 2025, future principal payments on long-term debt were as follows (in millions):

- changed (2025-10-31):
[0001137789-25-000317:note_history:79]
| Fiscal Year |  | Amount |
| Remainder of 2026 |  | — |  |
| 2027 |  | — |  |
| 2028 |  | 1,500 |  |
| 2029 |  | 470 |  |
| 2030 |  | 638 |  |
| Thereafter |  | 2,438 |  |
| Total |  | $ | 5,046 |  |
  (was, 2025-05-02, similarity 0.9872):
[0001137789-25-000075:note_history:79]
| Fiscal Year |  | Amount |
| Remainder of 2025 |  | $ | — |  |
| 2026 |  | — |  |
| 2027 |  | 505 |  |
| 2028 |  | 1,500 |  |
| 2029 |  | 481 |  |
| Thereafter |  | 2,707 |  |
| Total |  | $ | 5,193 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-10-31):
[0001137789-25-000317:note_history:80]
|  |  | For the Three Months Ended |  |  |  |  |
| (Dollars in millions) |  | October 3, 2025 |  | September 27, 2024 |  |  |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,180 |  |  | $ | 1,749 |  |  |  |  |  |  |  |
| Distributors |  | 279 |  |  | 248 |  |  |  |  |  |  |  |
| Retailers |  | 170 |  |  | 171 |  |  |  |  |  |  |  |
| Total |  | $ | 2,629 |  |  | $ | 2,168 |  |  |  |  |  |  |  |

- changed (2025-10-31):
[0001137789-25-000317:note_history:81]
| Revenue by Country (1): |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 1,380 |  |  | $ | 1,097 |  |  |  |  |  |  |  |
| Singapore |  | 1,037 |  |  | 860 |  |  |  |  |  |  |  |
| The Netherlands |  | 211 |  |  | 210 |  |  |  |  |  |  |  |
| Other |  | 1 |  |  | 1 |  |  |  |  |  |  |  |
| Total |  | $ | 2,629 |  |  | $ | 2,168 |  |  |  |  |  |  |  |
  (was, 2025-05-02, similarity 0.637):
[0001137789-25-000075:note_history:81]
| Revenue by Country (1): |  |  |  |  |  |  |  |  |  |  |
| Singapore |  | $ | 847 |  |  | $ | 834 |  |  | $ | 2,741 |  |  | $ | 2,417 |  |  |  |
| United States |  | 1,090 |  |  | 618 |  |  | 3,246 |  |  | 1,617 |  |  |  |
| The Netherlands |  | 222 |  |  | 200 |  |  | 663 |  |  | 622 |  |  |  |
| Other |  | 1 |  |  | 3 |  |  | 3 |  |  | 8 |  |  |  |
| Total |  | $ | 2,160 |  |  | $ | 1,655 |  |  | $ | 6,653 |  |  | $ | 4,664 |  |  |  |

- removed (2025-10-31):
[0001137789-25-000075:note_history:82]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |  |
| (Dollars in millions) |  | March 28, 2025 |  | March 29, 2024 |  | March 28, 2025 |  | March 29, 2024 |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,711 |  |  | $ | 1,236 |  |  | $ | 5,301 |  |  | $ | 3,408 |  |  |  |
| Distributors |  | 264 |  |  | 252 |  |  | 791 |  |  | 736 |  |  |  |
| Retailers |  | 185 |  |  | 167 |  |  | 561 |  |  | 520 |  |  |  |
| Total |  | $ | 2,160 |  |  | $ | 1,655 |  |  | $ | 6,653 |  |  | $ | 4,664 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-10-31):
[0001137789-25-000317:note_history:83]
|  |  | For the Three Months Ended |  |  |  |  |
| (Dollars in millions) |  | October 3, 2025 |  | September 27, 2024 |  |  |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,180 |  |  | $ | 1,749 |  |  |  |  |  |  |  |
| Distributors |  | 279 |  |  | 248 |  |  |  |  |  |  |  |
| Retailers |  | 170 |  |  | 171 |  |  |  |  |  |  |  |
| Total |  | $ | 2,629 |  |  | $ | 2,168 |  |  |  |  |  |  |  |

- changed (2025-10-31):
[0001137789-25-000317:note_history:84]
| Revenue by Country (1): |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 1,380 |  |  | $ | 1,097 |  |  |  |  |  |  |  |
| Singapore |  | 1,037 |  |  | 860 |  |  |  |  |  |  |  |
| The Netherlands |  | 211 |  |  | 210 |  |  |  |  |  |  |  |
| Other |  | 1 |  |  | 1 |  |  |  |  |  |  |  |
| Total |  | $ | 2,629 |  |  | $ | 2,168 |  |  |  |  |  |  |  |
  (was, 2025-05-02, similarity 0.637):
[0001137789-25-000075:note_history:84]
| Revenue by Country (1): |  |  |  |  |  |  |  |  |  |  |
| Singapore |  | $ | 847 |  |  | $ | 834 |  |  | $ | 2,741 |  |  | $ | 2,417 |  |  |  |
| United States |  | 1,090 |  |  | 618 |  |  | 3,246 |  |  | 1,617 |  |  |  |
| The Netherlands |  | 222 |  |  | 200 |  |  | 663 |  |  | 622 |  |  |  |
| Other |  | 1 |  |  | 3 |  |  | 3 |  |  | 8 |  |  |  |
| Total |  | $ | 2,160 |  |  | $ | 1,655 |  |  | $ | 6,653 |  |  | $ | 4,664 |  |  |  |

- removed (2025-10-31):
[0001137789-25-000075:note_history:85]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |  |
| (Dollars in millions) |  | March 28, 2025 |  | March 29, 2024 |  | March 28, 2025 |  | March 29, 2024 |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,711 |  |  | $ | 1,236 |  |  | $ | 5,301 |  |  | $ | 3,408 |  |  |  |
| Distributors |  | 264 |  |  | 252 |  |  | 791 |  |  | 736 |  |  |  |
| Retailers |  | 185 |  |  | 167 |  |  | 561 |  |  | 520 |  |  |  |
| Total |  | $ | 2,160 |  |  | $ | 1,655 |  |  | $ | 6,653 |  |  | $ | 4,664 |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2025-10-31):
[0001137789-25-000317:note_history:86]
Subsequent Events
Dividend Declared
  (was, 2025-05-02, similarity 0.6562):
[0001137789-25-000075:note_history:86]
Subsequent Events
Acquisition

- changed (2025-10-31):
[0001137789-25-000317:note_history:87]
On October 28, 2025, the Board of Directors of the Company declared a quarterly cash dividend of $0.74 per share, which will be payable on January 9, 2026 to shareholders of record as of the close of business on December 24, 2025.
  (was, 2025-05-02, similarity 0.6005):
[0001137789-25-000075:note_history:87]
On April 29, 2025, the Board of Directors of the Company declared a quarterly cash dividend of $0.72 per share, which will be payable on July 8, 2025 to shareholders of record as of the close of business on June 25, 2025.

- removed (2025-10-31):
[0001137789-25-000075:note_history:88]
On March 31, 2025, the Company completed the acquisition of Intevac, Inc., a supplier of thin-film processing systems, in an all-cash transaction for $4.00 per share, with cash consideration of approximately $118 million. This acquisition aligns with the Company’s strategy to integrate important components and manufacturing processes.

- removed (2025-10-31):
[0001137789-25-000075:note_history:89]
Dividend Declared
