# STX 8-K — 0001137789-25-000283 filed 2025-10-28

## item codes, every 8-K on or before 2025-10-31

- 2025-10-28 0001137789-25-000287 — 5.02, 5.07, 9.01
- 2025-10-28 0001137789-25-000283 — 2.02, 7.01, 9.01
- 2025-08-26 0001137789-25-000191 — 5.02, 9.01
- 2025-07-30 0001137789-25-000150 — 2.02, 7.01, 9.01
- 2025-07-29 0001137789-25-000148 — 2.02, 7.01, 9.01
- 2025-07-28 0001137789-25-000145 — 8.01, 9.01
- 2025-06-30 0001193125-25-152915 — 1.01, 2.03, 7.01, 9.01
- 2025-06-16 0001193125-25-141454 — 1.02, 2.04, 8.01, 9.01
- 2025-05-28 0001193125-25-129583 — 1.01, 2.03, 8.01, 9.01
- 2025-05-22 0001137789-25-000084 — 8.01
- 2025-05-13 0001193125-25-118923 — 1.01, 8.01, 9.01
- 2025-05-12 0001193125-25-117310 — 8.01, 9.01
- 2025-05-08 0001137789-25-000078 — 5.02
- 2025-04-29 0001137789-25-000070 — 2.02, 7.01, 9.01
- 2025-02-03 0001137789-25-000023 — 1.01, 1.02, 2.03, 9.01
- 2025-01-21 0001137789-25-000006 — 2.02, 7.01, 9.01
- 2024-12-03 0001137789-24-000194 — 7.01
- 2024-10-22 0001137789-24-000141 — 2.02, 7.01, 9.01
- 2024-10-22 0001137789-24-000138 — 5.07
- 2024-08-29 0001137789-24-000074 — 5.02
- 2024-07-23 0001137789-24-000061 — 2.02, 7.01, 9.01
- 2024-04-25 0001193125-24-114027 — 5.02, 9.01
- 2024-04-23 0001193125-24-107068 — 1.01
- 2024-04-23 0001137789-24-000030 — 2.02, 7.01, 9.01
- 2024-04-16 0001193125-24-097742 — 7.01
- 2024-01-24 0001137789-24-000004 — 2.02, 7.01, 9.01
- 2024-01-02 0001193125-24-000688 — 5.02
- 2023-10-26 0001137789-23-000125 — 2.02, 7.01, 9.01
- 2023-10-25 0001137789-23-000098 — 5.07, 9.01
- 2023-09-27 0001137789-23-000096 — 1.01
- 2023-09-13 0001193125-23-234372 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2023-09-08 0001193125-23-231165 — 1.01, 8.01, 9.01
- 2023-07-26 0001137789-23-000045 — 2.02, 7.01, 9.01
- 2023-07-24 0001193125-23-192237 — 5.02
- 2023-05-30 0001137789-23-000039 — 1.01, 2.03, 9.01
- 2023-05-25 0001137789-23-000035 — 1.01, 8.01, 9.01
- 2023-05-22 0001137789-23-000032 — 1.01, 2.03
- 2023-04-20 0001137789-23-000025 — 2.02, 2.05, 5.02, 7.01, 9.01
- 2023-04-19 0001193125-23-106624 — 1.01, 2.02, 9.01
- 2023-03-29 0001137789-23-000021 — 2.05, 5.02
- 2023-01-25 0001137789-23-000007 — 2.02, 7.01, 9.01
- 2022-11-30 0001193125-22-295386 — 1.01, 2.03, 8.01, 9.01
- 2022-11-15 0001137789-22-000137 — 8.01
- 2022-11-09 0001137789-22-000129 — 5.02, 9.01
- 2022-11-08 0001193125-22-280194 — 1.01, 2.03
- 2022-10-26 0001137789-22-000118 — 8.01, 9.01
- 2022-10-26 0001137789-22-000116 — 2.02, 2.05, 7.01, 9.01
- 2022-10-25 0001193125-22-268425 — 5.02, 9.01 — amendment of 0001193125-22-228640
- 2022-10-25 0001193125-22-268417 — 5.07, 9.01
- 2022-08-31 0001137789-22-000062 — 7.01, 9.01
- 2022-08-24 0001193125-22-228640 — 5.02, 9.01
- 2022-08-19 0001193125-22-225260 — 1.01, 2.03
- 2022-07-21 0001137789-22-000039 — 2.02, 7.01, 9.01
- 2022-04-27 0001137789-22-000028 — 2.02, 7.01, 9.01
- 2022-03-30 0001193125-22-089760 — 5.02
- 2022-02-24 0001193125-22-052046 — 5.02
- 2022-01-26 0001137789-22-000008 — 2.02, 7.01, 9.01
- 2022-01-25 0001193125-22-017071 — 5.02, 9.01
- 2021-10-26 0001193125-21-307931 — 5.07
- 2021-10-22 0001137789-21-000105 — 2.02, 7.01, 9.01
- 2021-10-15 0001193125-21-299005 — 1.01, 2.03
- 2021-07-21 0001137789-21-000041 — 2.02, 7.01, 9.01
- 2021-06-08 0001137789-21-000033 — 7.01, 9.01
- 2021-05-19 0001193125-21-165970 — 1.01, 2.03, 3.01, 3.03, 5.02, 5.03, 8.01, 9.01
- 2021-04-22 0001137789-21-000023 — 2.02, 7.01, 9.01
- 2021-04-16 0001193125-21-119304 — 5.07
- 2021-03-22 0001193125-21-089557 — 5.02, 9.01
- 2021-01-21 0001137789-21-000003 — 2.02, 7.01, 9.01
- 2021-01-13 0001193125-21-008148 — 1.01, 2.03
- 2020-12-28 0001193125-20-327026 — 5.02, 9.01
- 2020-12-09 0001193125-20-313800 — 1.01, 2.03, 9.01
- 2020-12-04 0001193125-20-310713 — 1.01, 8.01, 9.01
- 2020-10-28 0001193125-20-279868 — 5.07
- 2020-10-22 0001137789-20-000098 — 2.02, 7.01, 9.01
- 2020-07-28 0001137789-20-000055 — 2.02, 7.01, 9.01
- 2020-07-02 0001193125-20-186902 — 8.01, 9.01
- 2020-06-18 0001193125-20-172622 — 1.01, 2.03, 8.01, 9.01
- 2020-06-11 0001193125-20-166696 — 1.01, 2.03, 9.01
- 2020-06-04 0001193125-20-160796 — 1.01, 8.01, 9.01
- 2020-06-03 0001193125-20-159172 — 7.01, 8.01, 9.01
- 2020-06-02 0001193125-20-157932 — 2.05
- 2020-05-11 0001193125-20-139025 — 8.01
- 2020-04-22 0001137789-20-000028 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001137789-20-000013 — 2.02, 7.01, 9.01
- 2019-11-04 0001193125-19-283563 — 5.02, 5.07, 9.01
- 2019-11-01 0001628280-19-013012 — 2.02, 7.01, 9.01
- 2019-09-19 0001193125-19-248970 — 1.01, 2.03, 8.01, 9.01
- 2019-09-18 0001193125-19-247385 — 7.01, 9.01
- 2019-09-04 0001193125-19-237150 — 8.01, 9.01
- 2019-08-02 0001193125-19-211505 — 2.02, 7.01, 9.01
- 2019-06-26 0001193125-19-182712 — 5.02
- 2019-06-18 0001193125-19-175303 — 8.01
- 2019-04-30 0001193125-19-129480 — 5.07
- 2019-04-30 0001193125-19-127378 — 2.02, 7.01, 9.01
- 2019-02-20 0001193125-19-045470 — 1.01, 2.03
- 2019-02-04 0001193125-19-027004 — 2.02, 7.01, 9.01
- 2018-12-21 0001193125-18-356446 — 5.02, 9.01
- 2018-11-02 0001193125-18-316430 — 5.07, 8.01, 9.01
- 2018-11-02 0001193125-18-316418 — 2.02, 7.01, 9.01
- 2018-09-07 0001193125-18-268679 — 5.02 — amendment of 0001193125-18-230467
- 2018-07-30 0001193125-18-230467 — 5.02, 9.01
- 2018-07-30 0001193125-18-230452 — 2.02, 7.01, 9.01
- 2018-07-26 0001193125-18-226626 — 5.02
- 2018-06-01 0001193125-18-181093 — 8.01, 9.01
- 2018-05-01 0001193125-18-145112 — 2.02, 7.01, 9.01
- 2018-01-29 0001193125-18-022528 — 2.02, 7.01, 9.01
- 2018-01-25 0001193125-18-019820 — 5.02, 9.01
- 2018-01-09 0001137789-18-000009 — 2.02, 7.01, 9.01
- 2018-01-08 0001137789-18-000004 — 2.02, 7.01, 9.01
- 2017-12-11 0001137789-17-000101 — 2.05
- 2017-10-23 0001193125-17-316068 — 2.02, 7.01, 9.01
- 2017-10-18 0001137789-17-000068 — 5.02, 5.07, 9.01
- 2017-09-28 0001137789-17-000060 — 1.01
- 2017-07-28 0001137789-17-000046 — 5.02
- 2017-07-25 0001193125-17-234440 — 2.02, 2.05, 5.02, 7.01, 9.01
- 2017-06-02 0001193125-17-192960 — 5.02
- 2017-04-26 0001193125-17-138005 — 2.02, 7.01, 9.01
- 2017-03-10 0001193125-17-077510 — 2.05
- 2017-02-03 0001104659-17-006357 — 1.01, 2.03, 9.01
- 2017-01-31 0001104659-17-005357 — 8.01, 9.01
- 2017-01-31 0001104659-17-005173 — 8.01, 9.01
- 2017-01-27 0001104659-17-004448 — 8.01
- 2017-01-24 0001193125-17-016690 — 2.02, 7.01, 9.01
- 2017-01-20 0001193125-17-013685 — 5.02, 9.01
- 2016-10-24 0001104659-16-151422 — 5.02, 5.03, 5.07, 9.01
- 2016-10-19 0001193125-16-741277 — 2.02, 7.01, 9.01
- 2016-10-11 0001193125-16-734835 — 2.02, 9.01
- 2016-10-04 0001104659-16-148575 — 5.02
- 2016-09-27 0001104659-16-146813 — 5.02
- 2016-08-02 0001104659-16-135908 — 2.02, 7.01, 9.01
- 2016-07-28 0001104659-16-135046 — 5.02
- 2016-07-11 0001104659-16-131996 — 2.02, 2.05, 9.01
- 2016-07-08 0001104659-16-131749 — 5.02
- 2016-06-29 0001104659-16-130122 — 2.05
- 2016-06-27 0001104659-16-129505 — 5.02
- 2016-04-29 0001104659-16-115593 — 2.02, 7.01, 9.01
- 2016-04-13 0001104659-16-111266 — 2.02, 9.01
- 2016-01-29 0001104659-16-092323 — 2.02, 7.01, 9.01
- 2016-01-04 0001104659-16-087730 — 5.02, 9.01
- 2015-10-30 0001104659-15-074350 — 2.02, 7.01, 9.01
- 2015-10-21 0001104659-15-071908 — 5.02, 9.01
- 2015-10-21 0001104659-15-071906 — 5.07, 7.01, 9.01
- 2015-10-15 0001104659-15-070776 — 2.02, 9.01
- 2015-09-21 0001104659-15-066273 — 5.02
- 2015-09-10 0001104659-15-064389 — 2.05
- 2015-08-06 0001104659-15-057159 — 5.02
- 2015-07-31 0001104659-15-055040 — 2.02, 7.01, 9.01
- 2015-07-22 0001104659-15-052507 — 5.02, 9.01
- 2015-07-13 0001104659-15-050755 — 2.02, 9.01
- 2015-05-14 0001104659-15-038166 — 1.01, 2.03, 9.01
- 2015-05-12 0001104659-15-036968 — 8.01, 9.01
- 2015-05-11 0001104659-15-036533 — 8.01, 9.01
- 2015-05-01 0001104659-15-033202 — 5.02
- 2015-04-23 0001104659-15-029483 — 8.01, 9.01
- 2015-04-17 0001104659-15-028152 — 2.02, 7.01, 9.01
- 2015-04-07 0001104659-15-026148 — 7.01
- 2015-01-26 0001104659-15-004316 — 2.02, 7.01, 9.01
- 2015-01-16 0001104659-15-002732 — 1.01, 9.01
- 2015-01-02 0001104659-15-000147 — 8.01
- 2014-12-02 0001104659-14-084370 — 1.01, 2.03, 9.01
- 2014-11-25 0001104659-14-083066 — 8.01, 9.01
- 2014-11-24 0001104659-14-082837 — 8.01, 9.01
- 2014-10-27 0001104659-14-073832 — 2.02, 7.01, 9.01
- 2014-10-24 0001104659-14-073609 — 5.02, 5.07, 9.01
- 2014-10-22 0001104659-14-073104 — 7.01, 9.01
- 2014-10-08 0001104659-14-070767 — 8.01
- 2014-09-12 0001104659-14-066107 — 5.02
- 2014-09-12 0001104659-14-066101 — 7.01
- 2014-07-23 0001104659-14-052995 — 5.02
- 2014-07-17 0001104659-14-052019 — 2.02, 7.01, 9.01
- 2014-06-18 0001104659-14-046714 — 8.01, 9.01
- 2014-06-09 0001104659-14-044575 — 7.01
- 2014-06-04 0001104659-14-043897 — 8.01
- 2014-05-28 0001104659-14-041862 — 1.01, 2.03, 8.01, 9.01
- 2014-05-20 0001104659-14-040454 — 8.01, 9.01
- 2014-05-20 0001104659-14-040220 — 8.01, 9.01
- 2014-04-29 0001104659-14-031916 — 2.02, 7.01, 9.01
- 2014-04-22 0001104659-14-029197 — 5.02
- 2014-02-24 0001104659-14-012465 — 5.02, 7.01, 9.01
- 2014-01-27 0001104659-14-004298 — 2.02, 7.01, 9.01
- 2014-01-23 0001104659-14-003803 — 5.02
- 2013-12-23 0001104659-13-091738 — 1.01, 8.01, 9.01
- 2013-11-05 0001104659-13-081194 — 1.01, 2.03, 9.01
- 2013-11-04 0001104659-13-080161 — 5.02, 5.03, 5.07, 9.01
- 2013-10-31 0001104659-13-079635 — 8.01, 9.01
- 2013-10-31 0001104659-13-079438 — 8.01, 9.01
- 2013-10-28 0001104659-13-078341 — 2.02, 7.01, 9.01
- 2013-10-28 0001104659-13-078316 — 5.02, 7.01, 9.01
- 2013-10-08 0001104659-13-074454 — 1.01, 1.02, 9.01
- 2013-09-20 0001104659-13-071413 — 5.02
- 2013-07-24 0001104659-13-056053 — 5.02, 7.01
- 2013-07-24 0001104659-13-056052 — 2.02, 7.01, 9.01
- 2013-06-14 0001104659-13-049436 — 8.01, 9.01
- 2013-05-31 0001104659-13-045928 — 8.01, 9.01
- 2013-05-22 0001104659-13-043876 — 1.01, 2.03, 9.01
- 2013-05-16 0001104659-13-042180 — 7.01, 9.01
- 2013-05-15 0001104659-13-042028 — 8.01, 9.01
- 2013-05-15 0001104659-13-041695 — 8.01, 9.01
- 2013-05-07 0001104659-13-038226 — 5.02
- 2013-05-01 0001104659-13-036004 — 2.02, 9.01
- 2013-03-15 0001104659-13-021156 — 7.01
- 2013-01-28 0001104659-13-005180 — 2.02, 9.01
- 2013-01-08 0001104659-13-001291 — 2.02, 9.01
- 2012-11-29 0001104659-12-080911 — 8.01, 9.01
- 2012-10-31 0001104659-12-072476 — 2.02, 9.01
- 2012-10-25 0001104659-12-071208 — 5.07
- 2012-10-16 0001104659-12-069238 — 7.01
- 2012-09-28 0001104659-12-066105 — 7.01
- 2012-09-21 0001104659-12-064869 — 7.01
- 2012-08-02 0001104659-12-053775 — 5.02
- 2012-07-30 0001104659-12-052298 — 2.02, 5.02, 8.01, 9.01
- 2012-07-05 0001104659-12-047737 — 2.02, 9.01
- 2012-04-26 0001104659-12-029099 — 5.02, 8.01, 9.01
- 2012-04-17 0001104659-12-025931 — 2.02, 9.01
- 2012-01-31 0001104659-12-005522 — 2.02, 9.01
- 2012-01-27 0001104659-12-004299 — 8.01, 9.01
- 2012-01-04 0001104659-12-000411 — 2.02, 9.01
- 2011-12-20 0001104659-11-070207 — 2.01, 3.02, 9.01
- 2011-12-12 0001104659-11-069005 — 8.01
- 2011-12-05 0001104659-11-067679 — 5.02, 9.01
- 2011-11-29 0001104659-11-066436 — 7.01, 9.01
- 2011-11-22 0001104659-11-065589 — 7.01, 9.01
- 2011-11-03 0001104659-11-060307 — 7.01
- 2011-10-21 0001104659-11-056997 — 2.02, 8.01, 9.01
- 2011-10-12 0001104659-11-055849 — 7.01, 9.01
- 2011-07-29 0001104659-11-041897 — 5.02
- 2011-07-20 0001104659-11-039922 — 2.02, 9.01
- 2011-06-01 0001104659-11-032473 — 8.01
- 2011-05-23 0001104659-11-030867 — 8.01
- 2011-05-18 0001104659-11-029869 — 1.01, 2.03, 9.01
- 2011-05-04 0001104659-11-025801 — 8.01, 9.01
- 2011-05-04 0001104659-11-025462 — 8.01, 9.01
- 2011-04-19 0001104659-11-020787 — 1.01, 2.02, 3.02, 9.01
- 2011-04-08 0001104659-11-019316 — 5.02, 9.01
- 2011-04-07 0001104659-11-019141 — 2.02, 8.01, 9.01
- 2011-03-09 0001104659-11-013084 — 5.02
- 2011-02-18 0001104659-11-008419 — 8.01
- 2011-02-01 0001104659-11-004106 — 5.02, 9.01
- 2011-01-19 0001104659-11-002037 — 1.01, 2.02, 2.03, 5.07, 9.01
- 2010-12-14 0001104659-10-062647 — 1.01, 2.03, 9.01
- 2010-12-08 0001104659-10-061747 — 8.01, 9.01
- 2010-12-08 0001104659-10-061643 — 7.01, 8.01, 9.01
- 2010-11-29 0001104659-10-060338 — 7.01, 9.01
- 2010-10-20 0001104659-10-052966 — 2.02, 9.01
- 2010-10-15 0001104659-10-052362 — 8.01, 9.01
- 2010-09-13 0001104659-10-048317 — 5.02, 9.01
- 2010-08-16 0001104659-10-044431 — 5.02
- 2010-07-29 0001104659-10-040519 — 5.02, 9.01
- 2010-07-20 0001104659-10-038670 — 2.02, 9.01
- 2010-07-06 0001104659-10-036996 — 1.01, 2.03, 3.01, 3.03, 5.01, 5.02, 8.01, 9.01
- 2010-06-25 0001104659-10-035630 — 8.01, 9.01
- 2010-05-26 0001104659-10-030931 — 5.02
- 2010-05-14 0001104659-10-028664 — 1.01, 2.03, 9.01
- 2010-04-30 0001104659-10-023493 — 8.01, 9.01
- 2010-04-29 0001104659-10-022773 — 1.02, 8.01, 9.01
- 2010-04-20 0001104659-10-020750 — 2.02, 9.01
- 2010-04-16 0001104659-10-020113 — 5.07
- 2010-03-22 0001104659-10-015668 — 1.01, 9.01
- 2010-03-03 0001104659-10-011870 — 1.01, 2.03, 9.01
- 2010-01-20 0001104659-10-002269 — 2.02, 9.01
- 2009-10-29 0001104659-09-060949 — 5.02, 7.01
- 2009-10-20 0001104659-09-059594 — 2.02, 9.01
- 2009-10-01 0001104659-09-057311 — 1.01, 2.03, 2.06, 9.01
- 2009-09-22 0001104659-09-055716 — 7.01, 9.01
- 2009-08-04 0001193125-09-163032 — 2.05
- 2009-07-31 0001193125-09-160678 — 5.02, 9.01
- 2009-07-21 0001193125-09-152269 — 2.02, 9.01
- 2009-07-09 0001193125-09-146452 — 5.02
- 2009-06-24 0001193125-09-136674 — 7.01, 9.01
- 2009-06-01 0001193125-09-122549 — 1.01, 2.03, 9.01
- 2009-05-14 0001193125-09-110016 — 8.01, 9.01
- 2009-05-13 0001193125-09-109216 — 2.05, 7.01, 9.01
- 2009-05-05 0001193125-09-099861 — 1.01, 2.03, 9.01
- 2009-04-21 0001193125-09-083544 — 2.02, 9.01
- 2009-04-17 0001193125-09-081018 — 8.01, 9.01
- 2009-04-13 0001193125-09-077471 — 2.02, 9.01
- 2009-04-13 0001193125-09-077470 — 8.01, 9.01
- 2009-04-06 0001193125-09-073113 — 1.01, 2.03, 9.01
- 2009-03-09 0001193125-09-048538 — 5.02
- 2009-03-04 0001193125-09-044916 — 5.02, 8.01
- 2009-02-06 0001193125-09-021262 — 5.02
- 2009-02-04 0001193125-09-018804 — 5.02, 8.01
- 2009-02-02 0001193125-09-016478 — 2.06 — amendment, the index does not say of what
- 2009-01-27 0001193125-09-012058 — 5.02
- 2009-01-21 0001193125-09-009019 — 2.02, 5.02, 9.01
- 2009-01-14 0001193125-09-005721 — 2.05, 7.01
- 2009-01-12 0001193125-09-004420 — 5.02, 7.01, 9.01
- 2008-12-24 0001193125-08-259972 — 2.06
- 2008-12-12 0001193125-08-252765 — 2.03
- 2008-12-10 0001193125-08-250840 — 7.01
- 2008-11-12 0001193125-08-233906 — 5.02
- 2008-10-22 0001193125-08-214482 — 2.02, 9.01
- 2008-09-19 0001193125-08-198664 — 2.05
- 2008-09-12 0001193125-08-195206 — 1.01
- 2008-08-27 0001193125-08-185448 — 1.02, 3.01, 5.02, 9.01
- 2008-07-15 0001193125-08-151292 — 2.02, 9.01
- 2008-07-11 0001193125-08-149749 — 2.05
- 2008-07-03 0001193125-08-146791 — 5.02
- 2008-04-29 0001193125-08-094835 — 5.02, 9.01
- 2008-04-15 0001193125-08-081743 — 2.02, 9.01
- 2008-03-12 0001193125-08-054331 — 8.01, 9.01
- 2008-03-04 0001193125-08-045657 — 7.01
- 2008-02-04 0001193125-08-019262 — 8.01, 9.01
- 2008-01-18 0001193125-08-008849 — 8.01, 9.01
- 2008-01-17 0001193125-08-008120 — 2.02, 9.01
- 2007-12-21 0001193125-07-269469 — 2.05
- 2007-12-05 0001193125-07-259675 — 5.02
- 2007-10-17 0001193125-07-220376 — 8.01, 9.01
- 2007-10-16 0001193125-07-219386 — 2.02, 9.01
- 2007-09-18 0000950134-07-020112 — 5.02, 9.01
- 2007-08-29 0000950134-07-019145 — 1.01, 2.02, 9.01
- 2007-07-20 0001193125-07-159001 — 8.01, 9.01
- 2007-07-19 0001193125-07-158214 — 2.02, 9.01
- 2007-04-18 0001193125-07-083845 — 8.01, 9.01
- 2007-04-17 0001193125-07-082824 — 2.02, 9.01
- 2007-04-10 0001193125-07-077251 — 2.02, 9.01
- 2007-02-27 0001193125-07-040081 — 5.02, 7.01
- 2007-01-24 0001193125-07-011834 — 8.01, 9.01
- 2007-01-23 0001193125-07-010955 — 2.02, 9.01
- 2006-12-21 0001193125-06-257603 — 8.01, 9.01
- 2006-12-07 0001193125-06-247897 — 5.02
- 2006-11-07 0001193125-06-225545 — 2.02, 7.01, 8.01, 9.01
- 2006-11-01 0001193125-06-220706 — 1.01, 9.01
- 2006-10-25 0001193125-06-214798 — 8.01, 9.01
- 2006-10-24 0001193125-06-213813 — 2.02, 9.01
- 2006-10-11 0001193125-06-206304 — 5.02
- 2006-10-03 0001193125-06-201845 — 5.02, 9.01
- 2006-09-21 0001193125-06-194878 — 1.01, 1.02, 2.03, 2.04, 8.01, 9.01
- 2006-09-19 0001193125-06-192726 — 8.01, 9.01
- 2006-09-12 0001193125-06-189437 — 5.02, 8.01, 9.01
- 2006-08-24 0001193125-06-179258 — 1.01
- 2006-08-09 0001193125-06-167961 — 8.01, 9.01
- 2006-08-08 0001193125-06-165853 — 2.02, 9.01
- 2006-06-01 0001193125-06-122124 — 7.01, 9.01
- 2006-05-25 0001193125-06-119646 — 1.01, 2.01, 2.03, 5.02, 9.01
- 2006-05-17 0001193125-06-114760 — 8.01, 9.01
- 2006-05-04 0001193125-06-099262 — 8.01, 9.01
- 2006-05-03 0001193125-06-098229 — 5.05, 9.01
- 2006-04-27 0001193125-06-090749 — 8.01
- 2006-04-20 0001193125-06-084566 — 8.01, 9.01
- 2006-04-18 0001193125-06-082414 — 2.02, 9.01
- 2006-04-13 0001193125-06-079690 — 8.01
- 2006-04-03 0001193125-06-071956 — 8.01
- 2006-03-13 0001193125-06-051798 — 8.01
- 2006-02-14 0001193125-06-030829 — 8.01, 9.01
- 2006-01-26 0001193125-06-012909 — 8.01, 9.01
- 2006-01-25 0001193125-06-011608 — 8.01, 9.01
- 2006-01-19 0001193125-06-008770 — 8.01, 9.01
- 2006-01-18 0001193125-06-007939 — 2.02, 9.01
- 2005-12-22 0001193125-05-247782 — 1.01, 5.02, 9.01
- 2005-12-22 0001193125-05-247766 — 1.01, 9.01
- 2005-12-21 0001193125-05-246701 — 8.01, 9.01
- 2005-12-01 0001193125-05-234733 — 7.01
- 2005-11-23 0001193125-05-231674 — 1.01, 1.02, 7.01, 9.01
- 2005-10-19 0001193125-05-203955 — 2.02, 9.01
- 2005-10-18 0001193125-05-203356 — 2.02, 7.01, 9.01
- 2005-09-08 0001193125-05-181893 — 7.01, 9.01
- 2005-09-07 0001193125-05-181605 — 1.01
- 2005-08-04 0001193125-05-157913 — 8.01, 9.01
- 2005-08-03 0001193125-05-156407 — 1.01, 8.01, 9.01
- 2005-07-19 0001193125-05-144591 — 2.02, 9.01
- 2005-06-08 0001193125-05-121880 — 7.01
- 2005-05-17 0001193125-05-109518 — 7.01
- 2005-04-19 0001193125-05-079453 — 2.02, 9.01
- 2005-03-22 0001193125-05-057519 — 1.01
- 2005-03-16 0001193125-05-052560 — 7.01
- 2005-03-07 0001193125-05-043752 — 7.01, 9.01
- 2005-02-08 0001193125-05-022340 — 1.01, 7.01
- 2005-01-18 0001193125-05-007666 — 2.02, 9.01
- 2004-12-13 0001193125-04-211590 — 7.01, 8.01, 9.01
- 2004-12-07 0001193125-04-208768 — 7.01, 9.01
- 2004-10-29 0001193125-04-181463 — 1.01, 5.02, 9.01
- 2004-10-19 0001193125-04-173795 — 2.02, 9.01
- 2004-09-23 0001193125-04-160889 — 8.01, 9.01
- 2004-09-21 0001193125-04-159593 — 8.01, 9.01
- 2004-09-07 0001193125-04-152868 — 7.01, 9.01
- 2004-07-28 0001193125-04-126152 — 5, 7
- 2004-07-20 0001193125-04-121017 — 12, 7
- 2004-06-02 0001193125-04-097697 — 7, 9
- 2004-04-30 0001193125-04-075386 — 5, 7
- 2004-04-20 0001193125-04-065621 — 12, 7
- 2004-04-06 0001193125-04-057855 — 12, 7
- 2004-03-16 0001193125-04-042542 — 5
- 2004-03-03 0001193125-04-033653 — 7, 9
- 2004-01-21 0001193125-04-006388 — 12, 5, 7
- 2003-10-31 0001193125-03-070294 — 5, 7
- 2003-10-27 0001193125-03-067685 — 5, 7
- 2003-10-22 0001193125-03-065398 — 12, 5, 7
- 2003-07-16 0001193125-03-019880 — 7, 9
- 2003-07-10 0001193125-03-018043 — 5
- 2003-07-07 0001193125-03-016864 — 5
- 2003-06-27 0001193125-03-014262 — 5, 7
- 2003-04-16 0001012870-03-001799 — 7, 9

## late-filing notifications on or before 2025-10-31

- none on or before 2025-10-31

## item 2.02 — earnings release, exhibit 99.1

[0001137789-25-000283:8k_2_02:1]
EX-99.1
2
stxq12026pressreleasefinan.htm
EX-99.1

[0001137789-25-000283:8k_2_02:2]
Document

[0001137789-25-000283:8k_2_02:3]
Exhibit 99.1

[0001137789-25-000283:8k_2_02:4]
Investor Relations Contact:

[0001137789-25-000283:8k_2_02:5]
Shanye Hudson, (510) 661-1600

[0001137789-25-000283:8k_2_02:6]
shanye.hudson@seagate.com

[0001137789-25-000283:8k_2_02:7]
Media Contact:

[0001137789-25-000283:8k_2_02:8]
Karin Taylor, (408) 772-8279

[0001137789-25-000283:8k_2_02:9]
karin.h.taylor@seagate.com

[0001137789-25-000283:8k_2_02:10]
SEAGATE TECHNOLOGY REPORTS FISCAL FIRST QUARTER 2026 FINANCIAL RESULTS

[0001137789-25-000283:8k_2_02:11]
Fiscal Q1 2026 Highlights

[0001137789-25-000283:8k_2_02:12]
▪Revenue of $2.63 billion

[0001137789-25-000283:8k_2_02:13]
▪GAAP gross margin of 39.4%;  non-GAAP gross margin of 40.1%, both at record levels

[0001137789-25-000283:8k_2_02:14]
▪GAAP diluted earnings per share (EPS) of $2.43; non-GAAP diluted EPS of $2.61

[0001137789-25-000283:8k_2_02:15]
▪Cash flow from operations of $532 million and free cash flow of $427 million

[0001137789-25-000283:8k_2_02:16]
▪Returned $182 million to shareholders through dividends and the repurchase of ordinary shares; increased quarterly cash dividend by approximately 3% to $0.74 per share

[0001137789-25-000283:8k_2_02:17]
Singapore – October 29, 2025 - Seagate Technology Holdings plc (NASDAQ: STX) (the “Company” or “Seagate”), a leading innovator of mass-capacity data storage, today reported financial results for its fiscal first quarter ended October 3, 2025.

[0001137789-25-000283:8k_2_02:18]
"Seagate delivered strong September quarter results, with revenue growth of 21% year-over-year and non-GAAP EPS exceeding the high end of our guided range. Our performance underscores the team’s strong execution and robust customer demand for our high-capacity storage products," said Dave Mosley, Seagate’s chair and chief executive officer.

[0001137789-25-000283:8k_2_02:19]
"With clear visibility into sustained demand strength, we are ramping shipments of our areal density-leading Mozaic HAMR products, which are now qualified with five of the world’s largest cloud customers. These products address customers’ performance, durability and TCO needs at scale to continue supporting demand for existing use cases such as social media video platforms as well as growth driven by new AI applications. AI is transforming how content is being consumed and generated, increasing the value of data and storage and Seagate is well positioned for continued profitable growth," Mosley concluded.

[0001137789-25-000283:8k_2_02:20]
Quarterly Financial Results

[0001137789-25-000283:8k_2_02:21]
|  | GAAP |  | Non-GAAP |
|  | FQ1 2026 |  | FQ1 2025 |  | FQ1 2026 |  | FQ1 2025 |
| Revenue ($M) | $ | 2,629 |  | $ | 2,168 |  | $ | 2,629 |  | $ | 2,168 |
| Gross Margin | 39.4% |  | 32.9% |  | 40.1% |  | 33.3% |
| Operating Margin | 26.4% |  | 18.6% |  | 29.0% |  | 20.4% |
| Net Income ($M) | $ | 549 |  | $ | 305 |  | $ | 583 |  | $ | 337 |
| Diluted Earnings Per Share | $ | 2.43 |  | $ | 1.41 |  | $ | 2.61 |  | $ | 1.58 |

[0001137789-25-000283:8k_2_02:22]
For definitions and a detailed reconciliation of GAAP to non-GAAP results, see accompanying financial tables.

[0001137789-25-000283:8k_2_02:23]
During the fiscal first quarter, the Company generated $532 million in cash flow from operations and $427 million in free cash flow. Seagate’s balance sheet remains healthy, and during the fiscal first quarter, the Company paid cash dividends of $153 million  and repurchased 153 thousand ordinary shares for $29 million. As of the end of the quarter, cash and cash equivalents totaled $1.1 billion, and there were 214 million ordinary shares issued and outstanding.

[0001137789-25-000283:8k_2_02:24]
Seagate has issued a Supplemental Financial Information document, which is available on Seagate’s Investor Relations website at investors.seagate.com.

[0001137789-25-000283:8k_2_02:25]
Quarterly Cash Dividend

[0001137789-25-000283:8k_2_02:26]
The Board of Directors of the Company (the “Board”) declared a quarterly cash dividend of $0.74 per share, which will be payable on January 9, 2026 to shareholders of record as of the close of business on December 24, 2025. The payment of any future quarterly dividends will be at the discretion of the Board and will be dependent upon Seagate’s financial position, results of operations, available cash, cash flow, capital requirements and other factors deemed relevant by the Board.

[0001137789-25-000283:8k_2_02:27]
Business Outlook

[0001137789-25-000283:8k_2_02:28]
The Company is providing the following guidance for its fiscal second quarter 2026:

[0001137789-25-000283:8k_2_02:29]
•Revenue of $2.70 billion, plus or minus $100 million

[0001137789-25-000283:8k_2_02:30]
•Non-GAAP diluted EPS of $2.75, plus or minus $0.20

[0001137789-25-000283:8k_2_02:31]
Our fiscal second quarter guidance includes:

[0001137789-25-000283:8k_2_02:32]
•The estimated impact from the Pillar Two framework for the global minimal tax that is effective starting fiscal year 2026 in major jurisdictions in which the Company operates;

[0001137789-25-000283:8k_2_02:33]
•The estimated net dilutive impact from the Exchangeable Senior Notes due 2028; and

[0001137789-25-000283:8k_2_02:34]
•Minimal expected impact from global tariff policies announced as of the date of this release.

[0001137789-25-000283:8k_2_02:35]
Guidance regarding non-GAAP diluted EPS excludes known pre-tax charges related to estimated share-based compensation expenses of $0.24 per share.

[0001137789-25-000283:8k_2_02:36]
We have not reconciled our non-GAAP diluted EPS guidance for fiscal second quarter 2026 to the most directly comparable GAAP measure, other than estimated share-based compensation expenses, because material items that may impact these measures are out of our control and/or cannot be reasonably predicted, including, but not limited to, net (gain) loss from debt transactions, strategic investment losses (gains) or impairment charges, income tax adjustments on these measures, and other charges or benefits that may arise. The amounts of these measures are not currently available but may be material to future results. A reconciliation of our historical non-GAAP financial measures to their nearest GAAP equivalent is contained in this release.

[0001137789-25-000283:8k_2_02:37]
Investor Communications

[0001137789-25-000283:8k_2_02:38]
Seagate management will hold a public webcast at 2:00 PM PT / 5:00 PM ET on October 28, 2025 that can be accessed on its Investor Relations website at investors.seagate.com.

[0001137789-25-000283:8k_2_02:39]
An archived audio webcast of this event will be available on Seagate’s Investor Relations website at investors.seagate.com shortly following the event conclusion.

[0001137789-25-000283:8k_2_02:40]
About Seagate

[0001137789-25-000283:8k_2_02:41]
Seagate Technology is a leading innovator of mass-capacity data storage. We create breakthrough technology so you can confidently store your data and easily unlock its value. Founded over 45 years ago, Seagate has shipped over four billion terabytes of data capacity and offers a full portfolio of storage devices, systems, and services from edge to cloud. To learn more about how Seagate leads storage innovation, visit www.seagate.com and our blog, or follow us on X, Facebook, LinkedIn, and YouTube.

[0001137789-25-000283:8k_2_02:42]
© 2025 Seagate Technology LLC. All rights reserved. Seagate, Seagate Technology, and the Spiral logo are registered trademarks of Seagate Technology LLC in the United States and/or other countries.

[0001137789-25-000283:8k_2_02:43]
Cautionary Note Regarding Forward-Looking Statements

[0001137789-25-000283:8k_2_02:44]
The inclusion of Seagate’s website addresses in this press release are provided for convenience only. The information contained in, or that can be accessed through, Seagate’s websites and social media channels are not part of this press release.

[0001137789-25-000283:8k_2_02:45]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-25-000283:8k_2_02:46]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001137789-25-000283:8k_2_02:47]
(In millions)

[0001137789-25-000283:8k_2_02:48]
|  | October 3, 2025 |  | June 27, 2025 |
|  | (unaudited) |  |  |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,112 |  |  | $ | 891 |  |
| Accounts receivable, net | 1,073 |  |  | 959 |  |
| Inventories, net | 1,496 |  |  | 1,440 |  |
| Other current assets | 351 |  |  | 363 |  |
| Total current assets | 4,032 |  |  | 3,653 |  |
| Property, equipment and leasehold improvements, net | 1,688 |  |  | 1,657 |  |
| Goodwill | 1,221 |  |  | 1,221 |  |
| Deferred income taxes | 1,091 |  |  | 1,066 |  |
| Other assets, net | 410 |  |  | 426 |  |
| Total Assets | $ | 8,442 |  |  | $ | 8,023 |  |
| LIABILITIES AND SHAREHOLDERS’ DEFICIT |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 1,673 |  |  | $ | 1,604 |  |
| Accrued employee compensation | 212 |  |  | 352 |  |
| Accrued warranty | 63 |  |  | 60 |  |
| Current portion of long-term debt | 1,496 |  |  | — |  |
| Accrued expenses | 673 |  |  | 632 |  |
| Total current liabilities | 4,117 |  |  | 2,648 |  |
| Long-term accrued warranty | 83 |  |  | 77 |  |
| Other non-current liabilities | 807 |  |  | 756 |  |
| Long-term debt, less current portion | 3,498 |  |  | 4,995 |  |
| Total Liabilities | 8,505 |  |  | 8,476 |  |
| Total Shareholders’ Deficit | (63) |  |  | (453) |  |
| Total Liabilities and Shareholders’ Deficit | $ | 8,442 |  |  | $ | 8,023 |  |

[0001137789-25-000283:8k_2_02:49]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-25-000283:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001137789-25-000283:8k_2_02:51]
(In millions, except per share data)

[0001137789-25-000283:8k_2_02:52]
(Unaudited)

[0001137789-25-000283:8k_2_02:53]
|  | For the Three Months Ended |  |  |  |  |
|  | October 3, 2025 |  | September 27, 2024 |  |  |  |  |  |  |  |  |
| Revenue | $ | 2,629 |  |  | $ | 2,168 |  |  |  |  |  |  |  |  |  |
| Cost of revenue | 1,592 |  |  | 1,454 |  |  |  |  |  |  |  |  |  |
| Product development | 186 |  |  | 181 |  |  |  |  |  |  |  |  |  |
| Marketing and administrative | 144 |  |  | 129 |  |  |  |  |  |  |  |  |  |
| Restructuring and other, net | 13 |  |  | 1 |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 1,935 |  |  | 1,765 |  |  |  |  |  |  |  |  |  |
| Income from operations | 694 |  |  | 403 |  |  |  |  |  |  |  |  |  |
| Interest income | 7 |  |  | 7 |  |  |  |  |  |  |  |  |  |
| Interest expense | (80) |  |  | (85) |  |  |  |  |  |  |  |  |  |
| Other, net | (7) |  |  | (9) |  |  |  |  |  |  |  |  |  |
| Other expense, net | (80) |  |  | (87) |  |  |  |  |  |  |  |  |  |
| Income before income taxes | 614 |  |  | 316 |  |  |  |  |  |  |  |  |  |
| Provision for income taxes | 65 |  |  | 11 |  |  |  |  |  |  |  |  |  |
| Net income | $ | 549 |  |  | $ | 305 |  |  |  |  |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 2.58 |  |  | $ | 1.45 |  |  |  |  |  |  |  |  |  |
| Diluted | $ | 2.43 |  |  | $ | 1.41 |  |  |  |  |  |  |  |  |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 213 |  |  | 211 |  |  |  |  |  |  |  |  |  |
| Diluted | 226 |  |  | 216 |  |  |  |  |  |  |  |  |  |
| Cash dividends declared per ordinary share | $ | 0.72 |  |  | $ | 0.70 |  |  |  |  |  |  |  |  |  |

[0001137789-25-000283:8k_2_02:54]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-25-000283:8k_2_02:55]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001137789-25-000283:8k_2_02:56]
(In millions)

[0001137789-25-000283:8k_2_02:57]
(Unaudited)

[0001137789-25-000283:8k_2_02:58]
|  | For the Three Months Ended |
|  | October 3, 2025 |  | September 27, 2024 |
| OPERATING ACTIVITIES |  |  |  |
| Net income | $ | 549 |  |  | $ | 305 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 72 |  |  | 64 |  |
| Share-based compensation | 52 |  |  | 38 |  |
| Deferred income taxes | (25) |  |  | (3) |  |
| Other non-cash operating activities, net | 15 |  |  | 23 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (114) |  |  | (199) |  |
| Inventories, net | (56) |  |  | (144) |  |
| Accounts payable | 84 |  |  | 10 |  |
| Accrued employee compensation | (140) |  |  | 37 |  |
| BIS settlement penalty | (15) |  |  | (15) |  |
| Accrued expenses, income taxes and warranty | 119 |  |  | 16 |  |
| Other assets and liabilities | (9) |  |  | (37) |  |
| Net cash provided by operating activities | 532 |  |  | 95 |  |
| INVESTING ACTIVITIES |  |  |  |
| Acquisition of property, equipment and leasehold improvements | (105) |  |  | (68) |  |
| Proceeds from business divestiture | 15 |  |  | — |  |
| Net cash used in investing activities | (90) |  |  | (68) |  |
| FINANCING ACTIVITIES |  |  |  |
| Dividends to shareholders | (153) |  |  | (147) |  |
| Taxes paid related to net share settlement of equity awards | (50) |  |  | (28) |  |
| Repurchases of ordinary shares | (29) |  |  | — |  |
| Proceeds from issuance of ordinary shares under employee stock plans | 22 |  |  | 29 |  |
| Other financing activities, net | (11) |  |  | — |  |
| Net cash used in financing activities | (221) |  |  | (146) |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | 221 |  |  | (119) |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 893 |  |  | 1,360 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 1,114 |  |  | $ | 1,241 |  |

[0001137789-25-000283:8k_2_02:59]
Use of non-GAAP financial information

[0001137789-25-000283:8k_2_02:60]
The Company uses non-GAAP measures of gross profit, gross margin, operating expenses, income from operations, operating margin, net income, diluted EPS, free cash flow, EBITDA, adjusted EBITDA and last twelve months adjusted EBITDA, which are adjusted from results based on GAAP to exclude certain benefits, expenses, gains and losses. These non-GAAP financial measures are used by management to evaluate the business and provided to enhance the user’s overall understanding of the Company’s current financial performance and its prospects for the future. Specifically, the Company believes non-GAAP results provide useful information to investors as these non-GAAP results exclude certain benefits, expenses, gains and losses that the Company believes are not part of the Company's ongoing operations and not indicative of its core operating results.

[0001137789-25-000283:8k_2_02:61]
These non-GAAP financial measures are some of the measurements management uses to assess the Company’s performance, allocate resources and plan for future periods. Reported non-GAAP results should only be considered as supplemental to results prepared in accordance with GAAP, and not considered as a substitute or replacement for, or superior to, GAAP results. These non-GAAP measures may differ from the non-GAAP measures reported by other companies in its industry.

[0001137789-25-000283:8k_2_02:62]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-25-000283:8k_2_02:63]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001137789-25-000283:8k_2_02:64]
(In millions, except per share amounts, gross margin and operating margin)

[0001137789-25-000283:8k_2_02:65]
(Unaudited)

[0001137789-25-000283:8k_2_02:66]
|  | For the Three Months Ended |  |  |  |
|  | October 3, 2025 |  | September 27, 2024 |  |  |  |  |  |  |  |  |
| GAAP Gross Profit | $ | 1,037 |  |  | $ | 714 |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets | 3 |  |  | — |  |  |  |  |  |  |  |  |  |
| Purchase order cancellation fees | — |  |  | (1) |  |  |  |  |  |  |  |  |  |
| Share-based compensation | 14 |  |  | 10 |  |  |  |  |  |  |  |  |  |
| Non-GAAP Gross Profit | $ | 1,054 |  |  | $ | 723 |  |  |  |  |  |  |  |  |  |
| GAAP Gross Margin | 39.4% |  | 32.9% |  |  |  |  |  |  |  |  |
| Non-GAAP Gross Margin | 40.1% |  | 33.3% |  |  |  |  |  |  |  |  |
| GAAP Operating Expenses | $ | 343 |  |  | $ | 311 |  |  |  |  |  |  |  |  |  |
| Acquisition-related charges | (1) |  |  | — |  |  |  |  |  |  |  |  |  |
| Restructuring and other, net | (13) |  |  | (1) |  |  |  |  |  |  |  |  |  |
| Share-based compensation | (38) |  |  | (28) |  |  |  |  |  |  |  |  |  |
| Other charges | — |  |  | (1) |  |  |  |  |  |  |  |  |  |
| Non-GAAP Operating Expenses | $ | 291 |  |  | $ | 281 |  |  |  |  |  |  |  |  |  |
| GAAP Income From Operations | $ | 694 |  |  | $ | 403 |  |  |  |  |  |  |  |  |  |
| Acquisition-related charges | 1 |  |  | — |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets | 3 |  |  | — |  |  |  |  |  |  |  |  |  |
| Purchase order cancellation fees | — |  |  | (1) |  |  |  |  |  |  |  |  |  |
| Restructuring and other, net | 13 |  |  | 1 |  |  |  |  |  |  |  |  |  |
| Share-based compensation | 52 |  |  | 38 |  |  |  |  |  |  |  |  |  |
| Other charges | — |  |  | 1 |  |  |  |  |  |  |  |  |  |
| Non-GAAP Income From Operations | $ | 763 |  |  | $ | 442 |  |  |  |  |  |  |  |  |  |
| GAAP Operating Margin | 26.4% |  | 18.6% |  |  |  |  |  |  |  |  |
| Non-GAAP Operating Margin | 29.0% |  | 20.4% |  |  |  |  |  |  |  |  |

[0001137789-25-000283:8k_2_02:67]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-25-000283:8k_2_02:68]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001137789-25-000283:8k_2_02:69]
(In millions, except per share amounts, gross margin and operating margin)

[0001137789-25-000283:8k_2_02:70]
(Unaudited)

[0001137789-25-000283:8k_2_02:71]
|  | For the Three Months Ended |  |  |  |  |
|  | October 3, 2025 |  | September 27, 2024 |  |  |  |  |  |  |  |  |
| GAAP Net Income | $ | 549 |  |  | $ | 305 |  |  |  |  |  |  |  |  |  |
| Acquisition-related charges | 1 |  |  | — |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets | 3 |  |  | — |  |  |  |  |  |  |  |  |  |
| Net loss from debt transactions | 6 |  |  | — |  |  |  |  |  |  |  |  |  |
| Purchase order cancellation fees | — |  |  | (1) |  |  |  |  |  |  |  |  |  |
| Restructuring and other, net | 13 |  |  | 1 |  |  |  |  |  |  |  |  |  |
| Share-based compensation | 52 |  |  | 38 |  |  |  |  |  |  |  |  |  |
| Strategic investment losses or impairment charges | — |  |  | 1 |  |  |  |  |  |  |  |  |  |
| Other charges | — |  |  | 1 |  |  |  |  |  |  |  |  |  |
| Income tax adjustments | (41) |  |  | (8) |  |  |  |  |  |  |  |  |  |
| Non-GAAP Net Income | $ | 583 |  |  | $ | 337 |  |  |  |  |  |  |  |  |  |

[0001137789-25-000283:8k_2_02:72]
| GAAP Diluted Net Income Per Share | $ | 2.43 |  |  | $ | 1.41 |  |  |  |  |  |  |  |  |  |
| Acquisition-related charges | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets | 0.01 |  |  | — |  |  |  |  |  |  |  |  |  |
| Net loss from debt transactions | 0.03 |  |  | — |  |  |  |  |  |  |  |  |  |
| Purchase order cancellation fees | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Restructuring and other, net | 0.06 |  |  | — |  |  |  |  |  |  |  |  |  |
| Share-based compensation | 0.23 |  |  | 0.18 |  |  |  |  |  |  |  |  |  |
| Strategic investment losses or impairment charges | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Other charges | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Income tax adjustments | (0.18) |  |  | (0.04) |  |  |  |  |  |  |  |  |  |
| Non-GAAP diluted share count adjustments1 | 0.03 |  |  | 0.03 |  |  |  |  |  |  |  |  |  |
| Non-GAAP Diluted Net Income Per Share1 | $ | 2.61 |  |  | $ | 1.58 |  |  |  |  |  |  |  |  |  |
| Shares Used In Diluted Net Income Per Share Calculation |  |  |  |  |  |  |  |  |  |  |
| GAAP | 226 |  |  | 216 |  |  |  |  |  |  |  |  |  |
| Non-GAAP diluted share count adjustments1 | (3) |  |  | (3) |  |  |  |  |  |  |  |  |  |
| Non-GAAP | 223 |  |  | 213 |  |  |  |  |  |  |  |  |  |
| GAAP Net Cash Provided by Operating Activities | $ | 532 |  |  | $ | 95 |  |  |  |  |  |  |  |  |  |
| Acquisition of property, equipment and leasehold improvements | (105) |  |  | (68) |  |  |  |  |  |  |  |  |  |
| Free Cash Flow | $ | 427 |  |  | $ | 27 |  |  |  |  |  |  |  |  |  |

[0001137789-25-000283:8k_2_02:73]
1 For the three months ended October 3, 2025 and September 27, 2024, using the if-converted method, approximately 10 million and 3 million shares, respectively, are issuable upon conversion of our 2028 exchangeable senior notes. These dilutive effects are expected to be offset partially or in full by the capped call transactions and are excluded from non-GAAP shares used in diluted net income per share calculation.

[0001137789-25-000283:8k_2_02:74]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-25-000283:8k_2_02:75]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001137789-25-000283:8k_2_02:76]
(In millions)

[0001137789-25-000283:8k_2_02:77]
(Unaudited)

[0001137789-25-000283:8k_2_02:78]
|  | For the Three Months Ended |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | October 3, 2025 |  | June 27,2025 |  | March 28,2025 |  | December 27,2024 |  | Last Twelve Months |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP Net Income | $ | 549 |  |  | $ | 488 |  |  | $ | 340 |  |  | $ | 336 |  |  | $ | 1,713 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization | 72 |  |  | 61 |  |  | 63 |  |  | 63 |  |  | 259 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | 80 |  |  | 75 |  |  | 77 |  |  | 84 |  |  | 316 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income | (7) |  |  | (6) |  |  | (4) |  |  | (8) |  |  | (25) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | 65 |  |  | 4 |  |  | 15 |  |  | 14 |  |  | 98 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP EBITDA | 759 |  |  | 622 |  |  | 491 |  |  | 489 |  |  | 2,361 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related charges | 1 |  |  | 2 |  |  | 5 |  |  | — |  |  | 8 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net gain from business divestiture | — |  |  | — |  |  | (8) |  |  | — |  |  | (8) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss from debt transactions | 6 |  |  | 3 |  |  | 4 |  |  | — |  |  | 13 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase order cancellation fees | — |  |  | (5) |  |  | (3) |  |  | — |  |  | (8) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other, net | 13 |  |  | 16 |  |  | 20 |  |  | 1 |  |  | 50 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation | 52 |  |  | 59 |  |  | 54 |  |  | 49 |  |  | 214 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Strategic investment losses or impairment charges | — |  |  | — |  |  | — |  |  | 52 |  |  | 52 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP Adjusted EBITDA | $ | 831 |  |  | $ | 697 |  |  | $ | 563 |  |  | $ | 591 |  |  | $ | 2,682 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001137789-25-000283:8k_2_02:79]
The Company’s Non-GAAP measures are adjusted for the following items:

[0001137789-25-000283:8k_2_02:80]
Acquisition-related charges

[0001137789-25-000283:8k_2_02:81]
Acquisition-related charges are primarily related to transaction and integration costs. These expenses are excluded in the non-GAAP measures due to the inconsistency in amount and frequency, and they are not normal operating expenses or indicative of the Company's operating performance. Exclusion of these amounts provides a supplemental view of the Company's operating performance to investors to enable them to evaluate the Company's current operating performance compared to the past periods' operating performance.

[0001137789-25-000283:8k_2_02:82]
Amortization of acquired intangible assets

[0001137789-25-000283:8k_2_02:83]
The Company records expense from amortization of intangible assets that were acquired in connection with its business combinations over their estimated useful lives. Such charges are inconsistent in size and are significantly impacted by the timing and magnitude of the Company’s acquisitions. Consequently, the Company excludes these amounts to provide a supplemental view to investors to evaluate the Company's current operating performance compared to the past periods' operating performance.

[0001137789-25-000283:8k_2_02:84]
Net gain from business divestiture

[0001137789-25-000283:8k_2_02:85]
From time to time, the Company records net gains from the sale of businesses. These net gains are excluded in the non-GAAP measures because they are not indicative of the Company's operating performance. The Company excludes these amounts to provide a supplemental view to investors to evaluate the Company's current operating performance compared to the past periods' operating performance.

[0001137789-25-000283:8k_2_02:86]
Net gain/loss from debt transactions

[0001137789-25-000283:8k_2_02:87]
From time to time, the Company incurs gains, losses and fees from the early redemption and repurchase of certain long-term debt instruments and termination of related interest rate swap agreements. The amount of these charges may be inconsistent in size and varies depending on the timing of the early redemption of debt and/or termination of interest rate swap. The Company does not believe these are part of its normal operating performance. Exclusion of these amounts provides a supplemental view of the Company's operating performance to investors to enable them to evaluate the Company's current operating performance compared to the past periods' operating performance.

[0001137789-25-000283:8k_2_02:88]
Purchase order cancellation fees

[0001137789-25-000283:8k_2_02:89]
Purchase order cancellation fees are the costs incurred to cancel certain purchase commitments made with the Company's suppliers for component and equipment purchases that will not be received due to change in forecasted demand. These charges and subsequent credits received are inconsistent in amount and frequency. The Company does not believe these are part of its normal operating expenses. Exclusion of these amounts provides a supplemental view to investors to evaluate the Company's current operating performance compared to the past periods’ operating performance.

[0001137789-25-000283:8k_2_02:90]
Restructuring and other, net

[0001137789-25-000283:8k_2_02:91]
Restructuring and other, net are costs associated with restructuring plans that are primarily related to costs associated with reduction in the Company’s workforce, exiting certain facilities, inventory write down related to discontinued product lines and other related costs, as well as charges or gains from sale of properties. These costs or benefits do not reflect the Company’s normal or ongoing operating performance and consequently the Company excludes these expenses to provide a supplemental view to investors to evaluate the Company's current operating performance compared to the past periods’ operating performance.

[0001137789-25-000283:8k_2_02:92]
Share-based compensation

[0001137789-25-000283:8k_2_02:93]
These expenses consist primarily of expenses for employee share-based compensation. Given the variety of equity awards used by companies, the varying methodologies for determining share-based compensation expense, the subjective assumptions involved in those determinations, and the volatility in valuations that can be driven by market conditions outside the Company’s control, the Company believes excluding share-based compensation expense enhances the ability of management and investors to understand and assess the underlying performance of its business over time and compare it against the Company’s peers, a majority of whom also exclude share-based compensation expense from their non-GAAP results.

[0001137789-25-000283:8k_2_02:94]
Strategic investment gains, losses and impairment charges

[0001137789-25-000283:8k_2_02:95]
From time to time, the Company incurs gains, losses or impairment charges from strategic investments that are measured and accounted at fair value, under the equity method of accounting, as available-for-sale debt securities or adjust for downward or upward adjustments to the carrying value under the measurement alternative if an impairment or observable price adjustment is recognized in the current period that are not considered normal operating expenses or gains. The resulting expense, gain or impairment loss is inconsistent in amount and frequency and the Company excludes these amounts to provide a supplemental view to investors to evaluate the Company's current operating performance compared to the past periods’ operating performance.

[0001137789-25-000283:8k_2_02:96]
Other charges

[0001137789-25-000283:8k_2_02:97]
The other charges primarily include IT transformation costs. These charges are inconsistent in amount and frequency and are excluded to provide a supplemental view to investors to evaluate the Company's current operating performance compared to past periods’ operating performance.

[0001137789-25-000283:8k_2_02:98]
Income tax adjustments

[0001137789-25-000283:8k_2_02:99]
Seagate utilizes a projected annual non-GAAP income tax rate to determine its non-GAAP income taxes. The annual non-GAAP tax rate is based on considerations such as its current tax structure, projected tax positions and impacts from key legislation implemented in various jurisdictions but excludes the tax effects of pre-tax non-GAAP adjustments and other significant non-recurring income tax items. The Company believes applying the non-GAAP tax rate provides consistency across the interim reporting periods and reduces the effects of items not directly related to its operating structure that can vary in size and frequency. The non-GAAP income tax rate could be subject to change for a variety of reasons, including significant changes in tax laws. The Company will re-evaluate periodically its non-GAAP tax rate and may adjust as appropriate. For fiscal year 2026, the Company uses a projected non-GAAP income tax rate of 15.5%.

[0001137789-25-000283:8k_2_02:100]
Non-GAAP diluted share count adjustments

[0001137789-25-000283:8k_2_02:101]
Using the if-converted method, diluted net income per share is calculated assuming that the excess value above the principal of the 2028 exchangeable notes were converted solely into shares of common stock at the beginning of the reporting period, unless the result would be anti-dilutive. Non-GAAP shares used in diluted net income per share calculation excluded certain dilutive shares, which are expected to be offset partially or in full by the capped call transactions entered by the Company in conjunction with our 2028 exchangeable senior notes in order to reduce the potential dilution to the Company’s ordinary shares

[0001137789-25-000283:8k_2_02:102]
upon the conversion.

[0001137789-25-000283:8k_2_02:103]
Free cash flow

[0001137789-25-000283:8k_2_02:104]
Free cash flow is a non-GAAP measure defined as net cash provided by operating activities less acquisition of property, equipment and leasehold improvements. Free cash flow does not reflect non-cash items, net cash used or provided by financing activities and net cash used or provided by investing activities, other than acquisition of property, equipment and leasehold improvements. This non-GAAP financial measure is used by management to assess the Company's sources of liquidity, capital structure and operating performance.

[0001137789-25-000283:8k_2_02:105]
EBITDA, adjusted EBITDA and last twelve months (LTM) adjusted EBITDA

[0001137789-25-000283:8k_2_02:106]
EBITDA is defined as net income (loss) before income tax expense, interest expense, interest income, depreciation and amortization. Adjusted EBITDA excludes certain expenses, gains and losses that the Company believes are not indicative of its core operating results. These adjustments primarily include impairment and other charges related to cost saving efforts, net loss (gain) from debt transactions, net gain from termination of interest rate swap, net gain from business divestiture, purchase order cancellation fees, restructuring and other, net, share-based compensation, strategic investment losses or impairment charges, other extraordinary charges such as factory underutilization charges. LTM adjusted EBITDA is defined as the total of last twelve months adjusted EBITDA. These non-GAAP financial measures are used by management to evaluate the Company’s debt portfolio and structure to comply with its financial debt covenants.
