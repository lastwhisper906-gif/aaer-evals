# STX MD&A — 0001137789-25-000317


## mdna

[0001137789-25-000317:mdna:1]
[same as prior period, unchanged from 0001137789-25-000075:mdna:1]

[0001137789-25-000317:mdna:2]
The following is a discussion of the Company’s financial condition, changes in financial condition and results of operations for the fiscal quarters ended October 3, 2025, June 27, 2025 and September 27, 2024, referred to herein as the “September 2025 quarter”, the “June 2025 quarter” and the “September 2024 quarter”, respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The September 2025 quarter was 14 weeks, while the June 2025 quarter and September 2024 quarter were each 13 weeks.

[0001137789-25-000317:mdna:3]
You should read this discussion in conjunction with financial information and related notes included in this Quarterly Report on Form 10-Q, as well as our Annual Report on Form 10-K for the fiscal year ended June 27, 2025. Unless the context indicates otherwise, as used herein, the terms “we,” “us,” “Seagate,” the “Company” and “our” refer collectively to Seagate Technology Holdings plc, an Irish public limited company, and its subsidiaries. References to “$” or “dollars” are to United States dollars.

[0001137789-25-000317:mdna:4]
[same as prior period, unchanged from 0001137789-25-000075:mdna:4]

[0001137789-25-000317:mdna:5]
•Overview of the September 2025 quarter. Highlights of events in the September 2025 quarter that impacted our financial position.

[0001137789-25-000317:mdna:6]
•Results of Operations. Analysis of our financial results comparing the September 2025 quarter to the June 2025 quarter and the September 2024 quarter.

[0001137789-25-000317:mdna:7]
[same as prior period, unchanged from 0001137789-25-000075:mdna:7]

[0001137789-25-000317:mdna:8]
[same as prior period, unchanged from 0001137789-25-000075:mdna:8]

[0001137789-25-000317:mdna:9]
[same as prior period, unchanged from 0001137789-25-000075:mdna:9]

[0001137789-25-000317:mdna:10]
22

[0001137789-25-000317:mdna:11]
Overview of the September 2025 quarter

[0001137789-25-000317:mdna:12]
During the September 2025 quarter, we shipped 182 exabytes of HDD storage capacity. We generated revenue of approximately $2.6 billion with a gross margin of 39.4% and net income of $549 million. Our operating cash flow was $532 million, we paid $153 million in dividends and we repurchased approximately 0.2 million of our ordinary shares for $29 million.

[0001137789-25-000317:mdna:13]
Beginning in fiscal year 2026, we changed our presentation of principal data storage markets to better reflect current demand drivers and the growing impact of AI-driven applications. We now present our products and services under two end markets: Data center and Edge IoT. Data center comprises the majority of the Company’s business and primarily includes high-capacity nearline products for mass capacity data storage and systems sold to cloud and enterprise customers, as well as cloud-based video and image applications. Edge IoT primarily includes consumer and client-centric markets along with network-attached storage, mission critical and SSD.

[0001137789-25-000317:mdna:14]
We reflected these changes to our revenue and HDD exabytes shipped by end market retrospectively to the earliest period presented. The change had no impact on our previously reported consolidated net revenue.

[0001137789-25-000317:mdna:15]
[same as prior period, unchanged from 0001137789-25-000075:mdna:12]

[0001137789-25-000317:mdna:16]
In the September 2025 quarter, the Data Center markets contributed 80% of total company revenue supported by ongoing demand for our high-capacity nearline drives. Demand growth was led by global cloud customers to support their data storage requirements for applications including AI inferencing and training. At the same time, we continue to operate in a dynamic macroeconomic environment marked by rapid shifts in trade policies and increasing geopolitical tensions. These factors may impact our business and results of operations. We will continue to monitor the situation and assess plans to mitigate future risk to the business. Over the long-term we expect our hard drive storage business to benefit from future growth in data demand and data value, including from the ongoing adoption of Generative AI applications.

[0001137789-25-000317:mdna:17]
[same as prior period, unchanged from 0001137789-25-000075:mdna:14]

[0001137789-25-000317:mdna:18]
[same as prior period, unchanged from 0001137789-25-000075:mdna:15]

[0001137789-25-000317:mdna:19]
[same as prior period, unchanged from 0001137789-25-000075:mdna:16]

[0001137789-25-000317:mdna:20]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | October 3, 2025 |  | June 27, 2025 |  | September 27, 2024 |  |  |  |  |
| Revenue |  | $ | 2,629 |  |  | $ | 2,444 |  |  | $ | 2,168 |  |  |  |  |  |
| Cost of revenue |  | 1,592 |  |  | 1,530 |  |  | 1,454 |  |  |  |  |  |
| Gross profit |  | 1,037 |  |  | 914 |  |  | 714 |  |  |  |  |  |
| Product development |  | 186 |  |  | 179 |  |  | 181 |  |  |  |  |  |
| Marketing and administrative |  | 144 |  |  | 154 |  |  | 129 |  |  |  |  |  |
| Restructuring and other, net |  | 13 |  |  | 13 |  |  | 1 |  |  |  |  |  |
| Income from operations |  | 694 |  |  | 568 |  |  | 403 |  |  |  |  |  |
| Other expense, net |  | (80) |  |  | (76) |  |  | (87) |  |  |  |  |  |
| Income before income taxes |  | 614 |  |  | 492 |  |  | 316 |  |  |  |  |  |
| Provision for income taxes |  | 65 |  |  | 4 |  |  | 11 |  |  |  |  |  |
| Net income |  | $ | 549 |  |  | $ | 488 |  |  | $ | 305 |  |  |  |  |  |

[0001137789-25-000317:mdna:21]
23

[0001137789-25-000317:mdna:22]
|  |  | For the Three Months Ended |  |
| (As a percentage of Revenue) |  | October 3, 2025 |  | June 27, 2025 |  | September 27, 2024 |  |  |  |  |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  |  |  |  |
| Cost of revenue |  | 61 |  |  | 63 |  |  | 67 |  |  |  |  |  |
| Gross margin |  | 39 |  |  | 37 |  |  | 33 |  |  |  |  |  |
| Product development |  | 7 |  |  | 7 |  |  | 8 |  |  |  |  |  |
| Marketing and administrative |  | 5 |  |  | 6 |  |  | 6 |  |  |  |  |  |
| Restructuring and other, net |  | — |  |  | 1 |  |  | — |  |  |  |  |  |
| Operating margin |  | 27 |  |  | 23 |  |  | 19 |  |  |  |  |  |
| Other expense, net |  | (3) |  |  | (3) |  |  | (4) |  |  |  |  |  |
| Income before income taxes |  | 24 |  |  | 20 |  |  | 15 |  |  |  |  |  |
| Provision for income taxes |  | 2 |  |  | — |  |  | 1 |  |  |  |  |  |
| Net income |  | 22 | % |  | 20 | % |  | 14 | % |  |  |  |  |

[0001137789-25-000317:mdna:23]
[same as prior period, unchanged from 0001137789-25-000075:mdna:19]

[0001137789-25-000317:mdna:24]
[same as prior period, unchanged from 0001137789-25-000075:mdna:20]

[0001137789-25-000317:mdna:25]
|  |  | For the Three Months Ended |  |  |
|  |  | October 3, 2025 |  | June 27, 2025 |  | September 27, 2024 |  |  |  |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 83 | % |  | 81 | % |  | 81 | % |  |  |  |  |
| Distributors |  | 11 | % |  | 11 | % |  | 11 | % |  |  |  |  |
| Retailers |  | 6 | % |  | 8 | % |  | 8 | % |  |  |  |  |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |  |  |  |
| Americas |  | 53 | % |  | 47 | % |  | 50 | % |  |  |  |  |
| Asia Pacific |  | 39 | % |  | 42 | % |  | 40 | % |  |  |  |  |
| EMEA |  | 8 | % |  | 11 | % |  | 10 | % |  |  |  |  |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Data Center |  | 80 | % |  | 76 | % |  | 73 | % |  |  |  |  |
| Edge IoT |  | 20 | % |  | 24 | % |  | 27 | % |  |  |  |  |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Nearline |  | 159.3 |  |  | 136.6 |  |  | 114.4 |  |  |  |  |  |
| Non-nearline |  | 22.2 |  |  | 25.8 |  |  | 23.1 |  |  |  |  |  |
| Total |  | 181.5 |  |  | 162.4 |  |  | 137.5 |  |  |  |  |  |

[0001137789-25-000317:mdna:26]
[same as prior period, unchanged from 0001137789-25-000075:mdna:22]

[0001137789-25-000317:mdna:27]
[same as prior period, unchanged from 0001137789-25-000075:mdna:23]

[0001137789-25-000317:mdna:28]
Revenue in the September 2025 quarter increased by $185 million compared to the June 2025 quarter, primarily due to an increase in Data Center exabytes shipped reflecting higher demand for nearline cloud and enterprise products and favorable pricing actions undertaken by the Company.

[0001137789-25-000317:mdna:29]
Revenue in the September 2025 quarter increased by $461 million compared to the September 2024 quarter, primarily due to an increase in Data Center exabytes shipped reflecting higher demand for nearline cloud products and favorable pricing actions undertaken by the Company.

[0001137789-25-000317:mdna:30]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 12% of gross revenue for the September 2025 quarter, 14% for the June 2025 quarter and 13% for the September 2024 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-25-000317:mdna:31]
24

[0001137789-25-000317:mdna:32]
[same as prior period, unchanged from 0001137789-25-000075:mdna:27]

[0001137789-25-000317:mdna:33]
|  |  | For the Three Months Ended |  |  |  |  |  |
| (Dollars in millions) |  | October 3, 2025 |  | June 27, 2025 |  | September 27, 2024 |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,592 |  |  | $ | 1,530 |  |  | $ | 1,454 |  |  |  |  |  |  |  |  |
| Gross profit |  | 1,037 |  |  | 914 |  |  | 714 |  |  |  |  |  |  |  |  |
| Gross margin |  | 39 | % |  | 37 | % |  | 33 | % |  |  |  |  |  |  |  |

[0001137789-25-000317:mdna:34]
Gross margin for the September 2025 quarter increased by 2 percentage points and 6 percentage points compared to the June 2025 quarter and the September 2024 quarter, respectively, primarily driven by pricing actions undertaken by the Company and favorable product mix.

[0001137789-25-000317:mdna:35]
Warranty cost related to new shipments was 0.8%, 0.8% and 0.7% of revenue for the September 2025 quarter, June 2025 quarter and September 2024 quarter, respectively.

[0001137789-25-000317:mdna:36]
[same as prior period, unchanged from 0001137789-25-000075:mdna:33]

[0001137789-25-000317:mdna:37]
|  |  | For the Three Months Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | October 3, 2025 |  | June 27, 2025 |  | September 27, 2024 |  |  |  |  |  |  |  |  |
| Product development |  | $ | 186 |  |  | $ | 179 |  |  | $ | 181 |  |  |  |  |  |  |  |  |  |
| Marketing and administrative |  | 144 |  |  | 154 |  | 129 |  |  |  |  |  |  |  |  |  |
| Restructuring and other, net |  | 13 |  |  | 13 |  |  | 1 |  |  |  |  |  |  |  |  |  |
| Operating expenses |  | $ | 343 |  |  | $ | 346 |  |  | $ | 311 |  |  |  |  |  |  |  |  |  |

[0001137789-25-000317:mdna:38]
Product Development Expense. Product development expenses increased by $7 million in the September 2025 quarter compared to the June 2025 quarter primarily due to a $5 million increase in compensation and other employee benefits and a $2 million increase in facility costs.

[0001137789-25-000317:mdna:39]
Product development expenses increased by $5 million in the September 2025 quarter compared to the September 2024 quarter primarily due to a $3 million increase in facility costs and a $2 million increase in outside services costs.

[0001137789-25-000317:mdna:40]
Marketing and Administrative Expense. Marketing and administrative expenses decreased by $10 million in the September 2025 quarter compared to the June 2025 quarter, primarily due to a $7 million decrease in outside services costs and a $5 million decrease in share-based compensation expense.

[0001137789-25-000317:mdna:41]
Marketing and administrative expenses increased by $15 million in the September 2025 quarter compared to the September 2024 quarter primarily due to a $7 million increase in share-based compensation expense, a $5 million increase in outside services costs and a $3 million increase in facility costs.

[0001137789-25-000317:mdna:42]
Restructuring and other, net. We recorded $13 million of restructuring charges in the September 2025 quarter, primarily related to employee related termination benefits.

[0001137789-25-000317:mdna:43]
[same as prior period, unchanged from 0001137789-25-000075:mdna:43]

[0001137789-25-000317:mdna:44]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | October 3, 2025 |  | June 27, 2025 |  | September 27, 2024 |  |  |  |  |
| Other expense, net |  | $ | (80) |  |  | $ | (76) |  |  | $ | (87) |  |  |  |  |  |

[0001137789-25-000317:mdna:45]
Other expense, net. Other expense, net for the September 2025 quarter primarily related to $80 million of interest expense and $6 million net loss from debt transactions, partially offset by $7 million of interest income.

[0001137789-25-000317:mdna:46]
Other expense, net for the June 2025 quarter primarily related to $75 million of interest expense, $3 million net loss from debt transactions and $3 million of foreign currency remeasurement losses, partially offset by $6 million of interest income.

[0001137789-25-000317:mdna:47]
Other expense, net for the September 2024 quarter primarily related to interest expense of $85 million, $4 million of foreign currency remeasurement losses and $2 million of factoring fees, partially offset by $7 million of interest income.

[0001137789-25-000317:mdna:48]
[same as prior period, unchanged from 0001137789-25-000075:mdna:48]

[0001137789-25-000317:mdna:49]
For the September 2025 quarter and September 2024 quarter, we recorded income tax expense of $65 million and $11 million, respectively. For further discussion, refer to “Part I, Item 1. Financial Statements—Note 4. Income Taxes”.

[0001137789-25-000317:mdna:50]
[same as prior period, unchanged from 0001137789-25-000075:mdna:50]

[0001137789-25-000317:mdna:51]
[same as prior period, unchanged from 0001137789-25-000075:mdna:51]

[0001137789-25-000317:mdna:52]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of October 3, 2025. For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, see “Part II, Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q.

[0001137789-25-000317:mdna:53]
[same as prior period, unchanged from 0001137789-25-000075:mdna:53]

[0001137789-25-000317:mdna:54]
|  |  | As of |  |  |
| (Dollars in millions) |  | October 3, 2025 |  | June 27, 2025 |  | Change |
| Cash and cash equivalents |  | $ | 1,112 |  |  | $ | 891 |  |  | $ | 221 |  |

[0001137789-25-000317:mdna:55]
Our cash and cash equivalents as of October 3, 2025 increased by $221 million from June 27, 2025 primarily as a result of net cash of $532 million provided by operating activities, partially offset by $153 million dividends paid to our shareholders, $105 million payments for capital expenditures and $50 million taxes paid related to net share settlement of equity awards.

[0001137789-25-000317:mdna:56]
[same as prior period, unchanged from 0001137789-25-000075:mdna:56]

[0001137789-25-000317:mdna:57]
Cash provided by operating activities for the three months ended October 3, 2025 was $532 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, and the following major working capital related movements:

[0001137789-25-000317:mdna:58]
•an increase of $119 million in accrued expenses, primarily due to an increase in accrued income taxes and timing of interest payments on our long-term debt; and

[0001137789-25-000317:mdna:59]
•an increase of $84 million in accounts payable, primarily due to timing of payments; partially offset by

[0001137789-25-000317:mdna:60]
•a decrease of $140 million in accrued employee compensation, primarily due to variable compensation payments;

[0001137789-25-000317:mdna:61]
•an increase of $114 million in accounts receivable, primarily due to increased revenue; and

[0001137789-25-000317:mdna:62]
•an increase of $56 million in inventories, primarily due to an increase in work in progress inventory.

[0001137789-25-000317:mdna:63]
[same as prior period, unchanged from 0001137789-25-000075:mdna:62]

[0001137789-25-000317:mdna:64]
Net cash used in investing activities for the three months ended October 3, 2025 was $90 million, primarily attributable to payments of $105 million for the purchase of property, equipment and leasehold improvements, partially offset by proceeds of $15 million from our business divestiture from the sale of System-on-Chip Operations during fiscal year 2024.

[0001137789-25-000317:mdna:65]
[same as prior period, unchanged from 0001137789-25-000075:mdna:64]

[0001137789-25-000317:mdna:66]
Net cash used in financing activities of $221 million for the three months ended October 3, 2025 was primarily attributable to the following activities:

[0001137789-25-000317:mdna:67]
•$153 million in dividends paid to our shareholders;

[0001137789-25-000317:mdna:68]
•$50 million taxes paid related to net share settlement of equity awards;

[0001137789-25-000317:mdna:69]
•$29 million in payments for repurchases of our ordinary shares; and

[0001137789-25-000317:mdna:70]
•$11 million debt fees primarily relating to the Obligor Exchange; partially offset by

[0001137789-25-000317:mdna:71]
•$22 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-25-000317:mdna:72]
[same as prior period, unchanged from 0001137789-25-000075:mdna:70]

[0001137789-25-000317:mdna:73]
Our primary sources of liquidity as of October 3, 2025, consist of: (1) approximately $1.1 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.3 billion available for borrowing under our senior unsecured revolving credit facility (“Revolving Credit Facility”), which is part of our Credit Agreement (as defined within “Part I, Item 1. Financial Statements—Note 3. Debt”).

[0001137789-25-000317:mdna:74]
As of October 3, 2025, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with a financial covenant and other customary conditions to borrowing.

[0001137789-25-000317:mdna:75]
As of October 3, 2025, the Credit Agreement includes one financial covenant, net leverage ratio of less than or equal to 6.75 to 1.00, commencing with the fiscal quarter ended June 27, 2025 and declining over time so that the maximum permitted net leverage ratio for each fiscal quarter ending after July 2, 2027 is 4.25 to 1.00. As of October 3, 2025, we were in compliance with all of the covenants under our debt agreements. Refer to “Part I, Item 1. Financial Statements—Note 3. Debt” for more details. We continue to evaluate our debt portfolio and structure to comply with our financial debt covenant.

[0001137789-25-000317:mdna:76]
[same as prior period, unchanged from 0001137789-25-000075:mdna:75]

[0001137789-25-000317:mdna:77]
[same as prior period, unchanged from 0001137789-25-000075:mdna:76]

[0001137789-25-000317:mdna:78]
[same as prior period, unchanged from 0001137789-25-000075:mdna:78]

[0001137789-25-000317:mdna:79]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, quarterly dividend, share repurchase program and any future strategic investments.

[0001137789-25-000317:mdna:80]
[same as prior period, unchanged from 0001137789-25-000075:mdna:80]

[0001137789-25-000317:mdna:81]
Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. From time to time, we enter into long-term, non-cancelable purchase commitments or make large up-front investments with certain suppliers in order to secure certain components or technologies for the production of our products or to supplement our internal manufacturing capacity for certain components. As of October 3, 2025, we had unconditional purchase obligations of approximately $1.3 billion, primarily related to purchases of inventory components with our suppliers. We expect $1.2 billion of these commitments to be paid within one year. In addition, we also had certain long-term, market share-based, non-cancellable inventory purchase commitments as of October 3, 2025.

[0001137789-25-000317:mdna:82]
27

[0001137789-25-000317:mdna:83]
[same as prior period, unchanged from 0001137789-25-000075:mdna:82]

[0001137789-25-000317:mdna:84]
As of October 3, 2025, the future principal payment obligation on our long-term debt was $5.0 billion, which will mature in more than one year. As of October 3, 2025, future interest payments on this outstanding debt is estimated to be approximately $1.7 billion, of which $299 million is expected to be paid within one year. As of the calendar quarter ended September 30, 2025, the conditional conversion option of the 2028 Notes was triggered in accordance with the terms of the 2028 Notes indenture. Accordingly, the 2028 Notes are exchangeable through December 31, 2025. As a result, we have classified the 2028 Notes within Current liabilities in our Condensed Consolidated Balance Sheets as of October 3, 2025. From time to time, we may refinance, repurchase, redeem or otherwise extinguish any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase or redeem outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 1. Financial Statements—Note 3. Debt” for more details.

[0001137789-25-000317:mdna:85]
[same as prior period, unchanged from 0001137789-25-000075:mdna:84]

[0001137789-25-000317:mdna:86]
We accrued a settlement penalty of $300 million for fiscal year 2023, related to BIS’ allegations of violations of the U.S. EAR, which were subsequently resolved by the Settlement Agreement in April 2023. As part of the Settlement Agreement with BIS, quarterly payments of $15 million are made over the course of five years beginning October 31, 2023, of which $60 million is expected to be paid within one year and $120 million thereafter. Refer to “Item 1. Financial Statements—Note 11. Legal, Environmental and Other Contingencies” for more details.

[0001137789-25-000317:mdna:87]
[same as prior period, unchanged from 0001137789-25-000075:mdna:86]

[0001137789-25-000317:mdna:88]
On October 28, 2025, our Board of Directors declared a quarterly cash dividend of $0.74 per share, which will be payable on January 9, 2026 to shareholders of record as of the close of business on December 24, 2025. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-25-000317:mdna:89]
[same as prior period, unchanged from 0001137789-25-000075:mdna:88]

[0001137789-25-000317:mdna:90]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means, including through the use of derivative transactions. During the three months ended October 3, 2025, we repurchased approximately 0.5 million of our ordinary shares including approximately 0.3 million shares withheld for statutory tax withholdings related to vesting of employee equity awards. As of October 3, 2025, $5.0 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-25-000317:mdna:91]
[same as prior period, unchanged from 0001137789-25-000075:mdna:90]

[0001137789-25-000317:mdna:92]
For fiscal year 2026, we expect capital expenditures to be higher than fiscal year 2025. We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-25-000317:mdna:93]
[same as prior period, unchanged from 0001137789-25-000075:mdna:93]

[0001137789-25-000317:mdna:94]
[same as prior period, unchanged from 0001137789-25-000075:mdna:94]

[0001137789-25-000317:mdna:95]
Other than as described in “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies”, there have been no material changes in our critical accounting policies and estimates. Refer to “Part II, Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended June 27, 2025, as filed with the SEC on August 1, 2025, for a discussion of our critical accounting policies and estimates.

[0001137789-25-000317:mdna:96]
[same as prior period, unchanged from 0001137789-25-000075:mdna:96]

[0001137789-25-000317:mdna:97]
See “Item 1. Financial Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.
