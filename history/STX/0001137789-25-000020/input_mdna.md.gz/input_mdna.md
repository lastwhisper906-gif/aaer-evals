# STX MD&A — 0001137789-25-000020


## mdna

[0001137789-25-000020:mdna:1]
[same as prior period, unchanged from 0001137789-24-000182:mdna:1]

[0001137789-25-000020:mdna:2]
The following is a discussion of the Company’s financial condition, changes in financial condition and results of operations for the fiscal quarters ended December 27, 2024, September 27, 2024 and December 29, 2023, referred to herein as the “December 2024 quarter”, the “September 2024 quarter” and the “December 2023 quarter”, respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The December 2024 quarter, September 2024 quarter and December 2023 quarter were each 13 weeks.

[0001137789-25-000020:mdna:3]
[same as prior period, unchanged from 0001137789-24-000182:mdna:3]

[0001137789-25-000020:mdna:4]
[same as prior period, unchanged from 0001137789-24-000182:mdna:4]

[0001137789-25-000020:mdna:5]
•Overview of the December 2024 quarter. Highlights of events in the December 2024 quarter that impacted our financial position.

[0001137789-25-000020:mdna:6]
•Results of Operations. Analysis of our financial results comparing the December 2024 quarter to the September 2024 quarter and the December 2023 quarter.

[0001137789-25-000020:mdna:7]
[same as prior period, unchanged from 0001137789-24-000182:mdna:7]

[0001137789-25-000020:mdna:8]
[same as prior period, unchanged from 0001137789-24-000182:mdna:8]

[0001137789-25-000020:mdna:9]
[same as prior period, unchanged from 0001137789-24-000182:mdna:9]

[0001137789-25-000020:mdna:10]
Overview of the December 2024 quarter

[0001137789-25-000020:mdna:11]
During the December 2024 quarter, we shipped 151 exabytes of HDD storage capacity. We generated revenue of approximately $2.3 billion with a gross margin of 34.9%. Our operating cash flow was $221 million and we paid $148 million in dividends.

[0001137789-25-000020:mdna:12]
[same as prior period, unchanged from 0001137789-24-000182:mdna:12]

[0001137789-25-000020:mdna:13]
During the December 2024 quarter, revenue growth was driven by continued improvement in demand for our high capacity nearline drives from both cloud and enterprise/OEM customers along with seasonal uplift from certain other markets. We remain focused on improving operational efficiency and enhancing profitability, supported by expected increasing demand for our higher capacity nearline products alongside ongoing cost management and pricing actions. We have been increasing our factory production levels in light of higher demand. Temporary supply constraints are anticipated to impact our ability to fully respond to customer demand in the March quarter. These constraints are due to production related challenges that have now been resolved. We continue to operate in a dynamic macroeconomic environment, which may impact our business and results of operations. However, we expect our HDD storage business to benefit from further growth in data demand, including potential demand driven by the adoption of Generative AI applications.

[0001137789-25-000020:mdna:14]
[same as prior period, unchanged from 0001137789-24-000182:mdna:14]

[0001137789-25-000020:mdna:15]
[same as prior period, unchanged from 0001137789-24-000182:mdna:15]

[0001137789-25-000020:mdna:16]
[same as prior period, unchanged from 0001137789-24-000182:mdna:16]

[0001137789-25-000020:mdna:17]
|  |  | For the Three Months Ended | For the Six Months Ended |
| (Dollars in millions) |  | December 27, 2024 |  | September 27, 2024 |  | December 29, 2023 |  | December 27, 2024 |  | December 29, 2023 |
| Revenue |  | $ | 2,325 |  |  | $ | 2,168 |  |  | $ | 1,555 |  |  | $ | 4,493 |  |  | $ | 3,009 |  |
| Cost of revenue |  | 1,513 |  |  | 1,454 |  |  | 1,193 |  |  | 2,967 |  |  | 2,498 |  |
| Gross profit |  | 812 |  |  | 714 |  |  | 362 |  |  | 1,526 |  |  | 511 |  |
| Product development |  | 184 |  |  | 181 |  |  | 161 |  |  | 365 |  |  | 332 |  |
| Marketing and administrative |  | 139 |  |  | 129 |  |  | 108 |  |  | 268 |  |  | 213 |  |
| Restructuring and other, net |  | 1 |  |  | 1 |  |  | (31) |  |  | 2 |  |  | (29) |  |
| Income (loss) from operations |  | 488 |  |  | 403 |  |  | 124 |  |  | 891 |  |  | (5) |  |
| Other expense, net |  | (138) |  |  | (87) |  |  | (128) |  |  | (225) |  |  | (146) |  |
| Income (loss) before income taxes |  | 350 |  |  | 316 |  |  | (4) |  |  | 666 |  |  | (151) |  |
| Provision for income taxes |  | 14 |  |  | 11 |  |  | 15 |  |  | 25 |  |  | 52 |  |
| Net Income (loss) |  | $ | 336 |  |  | $ | 305 |  |  | $ | (19) |  |  | $ | 641 |  |  | $ | (203) |  |

[0001137789-25-000020:mdna:18]
|  |  | For the Three Months Ended | For the Six Months Ended |
|  |  | December 27, 2024 |  | September 27, 2024 |  | December 29, 2023 |  | December 27, 2024 |  | December 29, 2023 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 65 |  |  | 67 |  |  | 77 |  |  | 66 |  |  | 83 |  |
| Gross margin |  | 35 |  |  | 33 |  |  | 23 |  |  | 34 |  |  | 17 |  |
| Product development |  | 8 |  |  | 8 |  |  | 10 |  |  | 8 |  |  | 11 |  |
| Marketing and administrative |  | 6 |  |  | 6 |  |  | 7 |  |  | 6 |  |  | 7 |  |
| Restructuring and other, net |  | — |  |  | — |  |  | (2) |  |  | — |  |  | (1) |  |
| Operating margin |  | 21 |  |  | 19 |  |  | 8 |  |  | 20 |  |  | — |  |
| Other expense, net |  | (6) |  |  | (4) |  |  | (8) |  |  | (5) |  |  | (5) |  |
| Income (loss) before income taxes |  | 15 |  |  | 15 |  |  | — |  |  | 15 |  |  | (5) |  |
| Provision for income taxes |  | 1 |  |  | 1 |  |  | 1 |  |  | 1 |  |  | 2 |  |
| Net Income (loss) |  | 14 | % |  | 14 | % |  | (1) | % |  | 14 | % |  | (7) | % |

[0001137789-25-000020:mdna:19]
[same as prior period, unchanged from 0001137789-24-000182:mdna:19]

[0001137789-25-000020:mdna:20]
[same as prior period, unchanged from 0001137789-24-000182:mdna:20]

[0001137789-25-000020:mdna:21]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
|  |  | December 27, 2024 |  | September 27, 2024 |  | December 29, 2023 |  | December 27, 2024 |  | December 29, 2023 |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 79 | % |  | 81 | % |  | 73 | % |  | 80 | % |  | 72 | % |
| Distributors |  | 12 | % |  | 11 | % |  | 14 | % |  | 12 | % |  | 16 | % |
| Retailers |  | 9 | % |  | 8 | % |  | 13 | % |  | 8 | % |  | 12 | % |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 45 | % |  | 40 | % |  | 50 | % |  | 42 | % |  | 53 | % |
| Americas |  | 45 | % |  | 50 | % |  | 35 | % |  | 48 | % |  | 33 | % |
| EMEA |  | 10 | % |  | 10 | % |  | 15 | % |  | 10 | % |  | 14 | % |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 81 | % |  | 80 | % |  | 68 | % |  | 81 | % |  | 69 | % |
| Legacy |  | 12 | % |  | 12 | % |  | 21 | % |  | 12 | % |  | 20 | % |
| Other |  | 7 | % |  | 8 | % |  | 11 | % |  | 7 | % |  | 11 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 140 |  |  | 128 |  |  | 83 |  |  | 268 |  |  | 162 |  |
| Legacy |  | 11 |  |  | 10 |  |  | 12 |  |  | 21 |  |  | 23 |  |
| Total |  | 151 |  |  | 138 |  |  | 95 |  |  | 289 |  |  | 185 |  |
| HDD Price per Terabyte |  | $ | 14 |  |  | $ | 15 |  |  | $ | 14 |  |  | $ | 14 |  |  | $ | 14 |  |

[0001137789-25-000020:mdna:22]
[same as prior period, unchanged from 0001137789-24-000182:mdna:22]

[0001137789-25-000020:mdna:23]
[same as prior period, unchanged from 0001137789-24-000182:mdna:23]

[0001137789-25-000020:mdna:24]
Revenue in the December 2024 quarter increased by $157 million compared to the September 2024 quarter, primarily due to an increase in mass capacity exabytes shipped as we experienced higher demand primarily for our nearline products and favorable pricing actions undertaken by the Company.

[0001137789-25-000020:mdna:25]
Revenue for the three and six months ended December 27, 2024 increased by $770 million and $1.5 billion from the three and six months ended December 29, 2023, respectively, primarily due to an increase in mass capacity exabytes shipped as we experienced higher demand primarily for our nearline products and favorable pricing actions undertaken by the Company.

[0001137789-25-000020:mdna:26]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 14% of gross revenue for the December 2024 quarter, 13% for the September 2024 quarter and 18% for the December 2023 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 2% of quarterly gross revenue in all periods presented.

[0001137789-25-000020:mdna:27]
[same as prior period, unchanged from 0001137789-24-000182:mdna:27]

[0001137789-25-000020:mdna:28]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |  |  |
| (Dollars in millions) |  | December 27, 2024 |  | September 27, 2024 |  | December 29, 2023 |  | December 27, 2024 |  | December 29, 2023 |  |  |  |
| Cost of revenue |  | $ | 1,513 |  |  | $ | 1,454 |  |  | $ | 1,193 |  |  | $ | 2,967 |  |  | $ | 2,498 |  |  |  |  |
| Gross profit |  | 812 |  |  | 714 |  |  | 362 |  |  | 1,526 |  |  | 511 |  |  |  |  |
| Gross margin |  | 35 | % |  | 33 | % |  | 23 | % |  | 34 | % |  | 17 | % |  |  |  |

[0001137789-25-000020:mdna:29]
Gross margin for the December 2024 quarter increased by 2 percentage points compared to the September 2024 quarter, primarily driven by favorable product mix, an improved pricing environment and ongoing cost efficiencies.

[0001137789-25-000020:mdna:30]
Gross margin for the December 2024 quarter increased by 12 percentage points compared to the December 2023 quarter, primarily driven by favorable product mix and pricing actions undertaken by the Company, as well as $36 million of factory underutilization charges that did not recur.

[0001137789-25-000020:mdna:31]
Gross margin for the six months ended December 27, 2024 increased by 17 percentage points compared to the six months ended December 29, 2023, primarily driven by favorable product mix and pricing actions undertaken by the Company, as well as $115 million of cancellation fees, $95 million of factory underutilization charges, and $13 million of accelerated depreciation expense for certain capital equipment in the six months ended December 29, 2023 that did not recur.

[0001137789-25-000020:mdna:32]
Warranty cost related to new shipments was 0.7%, 0.7% and 0.9% of revenue for the December 2024 quarter, September 2024 quarter and December 2023 quarter, respectively.

[0001137789-25-000020:mdna:33]
[same as prior period, unchanged from 0001137789-24-000182:mdna:33]

[0001137789-25-000020:mdna:34]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |  |  |  |
| (Dollars in millions) |  | December 27, 2024 |  | September 27, 2024 |  | December 29, 2023 |  | December 27, 2024 |  | December 29, 2023 |  |  |  |  |
| Product development |  | $ | 184 |  |  | $ | 181 |  |  | $ | 161 |  |  | $ | 365 |  |  | $ | 332 |  |  |  |  |  |
| Marketing and administrative |  | 139 |  |  | 129 |  |  | 108 |  |  | 268 |  |  | 213 |  |  |  |  |  |
| Restructuring and other, net |  | 1 |  |  | 1 |  |  | (31) |  |  | 2 |  |  | (29) |  |  |  |  |  |
| Operating expenses |  | $ | 324 |  |  | $ | 311 |  |  | $ | 238 |  |  | $ | 635 |  |  | $ | 516 |  |  |  |  |  |

[0001137789-25-000020:mdna:35]
Product Development Expense. Product development expenses increased by $3 million in the December 2024 quarter compared to the September 2024 quarter primarily due to a $4 million increase in compensation and other employee benefits, partially offset by a $2 million decrease in materials expense.

[0001137789-25-000020:mdna:36]
Product development expenses increased by $23 million in the December 2024 quarter compared to the December 2023 quarter primarily due to a $24 million increase in compensation and other employee benefits as a result of the variable compensation expense recognized in the December 2024 quarter and temporary salary reductions in the December 2023 quarter, a $4 million increase in facilities costs, and a $2 million increase in equipment expense, partially offset by an $8 million decrease in materials expense.

[0001137789-25-000020:mdna:37]
Product development expenses increased by $33 million in the six months ended December 27, 2024 compared to the six months ended December 29, 2023, primarily due to a $35 million increase in compensation and other employee benefits as a result of the variable compensation expense recognized in the six months ended December 27, 2024 and temporary salary reductions in the six months ended December 29, 2023, a $6 million increase in facilities costs, a $3 million increase in equipment expense, and a $2 million increase in lease expense, partially offset by a $13 million decrease in materials expense.

[0001137789-25-000020:mdna:38]
Marketing and Administrative Expense. Marketing and administrative expenses increased by $10 million in the December 2024 quarter compared to the September 2024 quarter primarily due to a $7 million increase in compensation and other employee benefits and a $3 million increase in outside services expense.

[0001137789-25-000020:mdna:39]
Marketing and administrative expenses increased by $31 million in the December 2024 quarter compared to the December 2023 quarter primarily due to a $26 million increase in compensation and other employee benefits as a result of the variable compensation expense in the December 2024 quarter and temporary salary reductions in the December 2023 quarter, a $3 million increase in outside services expense and a $2 million increase in travel expense.

[0001137789-25-000020:mdna:40]
Marketing and administrative expenses increased by $55 million in the six months ended December 27, 2024 compared to the six months ended December 29, 2023, primarily due to a $46 million increase in compensation and other employee benefits as a result of the variable compensation expense in the six months ended December 27, 2024 and temporary salary reductions in the six months ended December 29, 2023, a $4 million increase in outside services expense and a $4 million increase in travel expense.

[0001137789-25-000020:mdna:41]
Restructuring and other, net. Restructuring and other, net for the three and six months ended December 27, 2024 was not material. Restructuring and other, net for the three and six months ended December 29, 2023 was a $31 million benefit and a $29 million benefit, respectively, primarily due to the net gain of $30 million from the sale and leaseback transaction during the December 2023 quarter.

[0001137789-25-000020:mdna:42]
Other Expense, net

[0001137789-25-000020:mdna:43]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 27, 2024 |  | September 27, 2024 |  | December 29, 2023 |  | December 27, 2024 |  | December 29, 2023 |
| Other expense, net |  | $ | (138) |  |  | $ | (87) |  |  | $ | (128) |  |  | $ | (225) |  |  | $ | (146) |  |

[0001137789-25-000020:mdna:44]
Other expense, net. Other expense, net increased by $51 million in the December 2024 quarter compared to the September 2024 quarter primarily due to a $50 million increase in net loss from certain investments and a $3 million increase in net loss from foreign currency exchange transactions.

[0001137789-25-000020:mdna:45]
Other expense, net increased by $10 million in the December 2024 quarter compared to the December 2023 quarter primarily due to a $9 million increase in net loss from certain investments and an $8 million increase in net loss from foreign currency exchange transactions, partially offset by a $5 million increase in interest income.

[0001137789-25-000020:mdna:46]
Other expense, net increased by $79 million in the six months ended December 27, 2024 compared to the six months ended December 29, 2023, primarily due to a $75 million net gain recognized from the early redemption of debt and the termination of interest rate swaps associated with the repayment of term loans that did not recur, a $10 million increase in net loss from certain investments, and a $6 million increase in net loss from foreign currency exchange transactions, partially offset by a $10 million increase in interest income and a $3 million decrease in factoring expense.

[0001137789-25-000020:mdna:47]
[same as prior period, unchanged from 0001137789-24-000182:mdna:43]

[0001137789-25-000020:mdna:48]
For the three months ended December 27, 2024, September 27, 2024, and December 29, 2023, we recorded income tax expense of $14 million, $11 million and $15 million, respectively. For the six months ended December 27, 2024 and December 29, 2023, we recorded income tax expense of $25 million and $52 million, respectively. For further discussion, refer to “Part I, Item 1. Financial Statements—Note 4. Income Taxes”.

[0001137789-25-000020:mdna:49]
[same as prior period, unchanged from 0001137789-24-000182:mdna:45]

[0001137789-25-000020:mdna:50]
[same as prior period, unchanged from 0001137789-24-000182:mdna:46]

[0001137789-25-000020:mdna:51]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of December 27, 2024. For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, see “Part II, Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q.

[0001137789-25-000020:mdna:52]
[same as prior period, unchanged from 0001137789-24-000182:mdna:48]

[0001137789-25-000020:mdna:53]
|  |  | As of |  |  |
| (Dollars in millions) |  | December 27, 2024 |  | June 28, 2024 |  | Change |
| Cash and cash equivalents |  | $ | 1,238 |  |  | $ | 1,358 |  |  | $ | (120) |  |

[0001137789-25-000020:mdna:54]
Our cash and cash equivalents as of December 27, 2024 decreased by $120 million from June 28, 2024 primarily as a result of $295 million dividends paid to our shareholders and $139 million payments for capital expenditures, partially offset by net cash of $316 million provided by operating activities.

[0001137789-25-000020:mdna:55]
[same as prior period, unchanged from 0001137789-24-000182:mdna:51]

[0001137789-25-000020:mdna:56]
Cash provided by operating activities for the six months ended December 27, 2024 was $316 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, and the following major working capital related movements:

[0001137789-25-000020:mdna:57]
•an increase of $85 million in accrued employee compensation, primarily due to an increase in our variable compensation expense; partially offset by

[0001137789-25-000020:mdna:58]
•an increase of $234 million in inventories, primarily due to an increase in purchased materials;

[0001137789-25-000020:mdna:59]
•a decrease of $190 million in accounts payable, primarily due to timing of payments; and

[0001137789-25-000020:mdna:60]
•an increase of $158 million in accounts receivable, primarily due to increased revenue.

[0001137789-25-000020:mdna:61]
[same as prior period, unchanged from 0001137789-24-000182:mdna:56]

[0001137789-25-000020:mdna:62]
Net cash used in investing activities for the six months ended December 27, 2024 was $138 million, which was primarily attributable to payments for the purchase of property, equipment and leasehold improvements.

[0001137789-25-000020:mdna:63]
[same as prior period, unchanged from 0001137789-24-000182:mdna:58]

[0001137789-25-000020:mdna:64]
Net cash used in financing activities of $298 million for the six months ended December 27, 2024 was primarily attributable to the following activities:

[0001137789-25-000020:mdna:65]
•$295 million in dividends paid to our shareholders; and

[0001137789-25-000020:mdna:66]
•$35 million taxes paid related to net share settlement of equity awards; partially offset by

[0001137789-25-000020:mdna:67]
•$32 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-25-000020:mdna:68]
[same as prior period, unchanged from 0001137789-24-000182:mdna:63]

[0001137789-25-000020:mdna:69]
Our primary sources of liquidity as of December 27, 2024, consist of: (1) approximately $1.2 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.5 billion available for borrowing under our senior unsecured revolving credit facility (“Revolving Credit Facility”), which is part of our Credit Agreement (as defined below).

[0001137789-25-000020:mdna:70]
As of December 27, 2024, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-25-000020:mdna:71]
As of December 27, 2024, the Credit Agreement includes two financial covenants: (1) interest coverage ratio and (2) net leverage ratio. We continue to evaluate our debt portfolio and structure to comply with our financial debt covenants. As of December 27, 2024, we were in compliance with all of the covenants under our debt agreements. Refer to “Part I, Item 1. Financial Statements—Note 3. Debt” for more details.

[0001137789-25-000020:mdna:72]
As of December 27, 2024, cash and cash equivalents held by our subsidiaries was $1.2 billion. This amount is potentially subject to taxation in Singapore upon repatriation by means of an intercompany dividend into our parent company, unless certain exemption is given, or a special approval is granted by the Ministry of Finance in Singapore. However, it is our intent to indefinitely reinvest earnings of subsidiaries in excess of the amount paid as dividends to shareholders. Our current plans do not demonstrate a need to repatriate such excess earnings. Should funds be needed in the parent company and should we be unable to fund parent company activities through means other than a taxable repatriation, we would be required to accrue and pay taxes on such dividend.

[0001137789-25-000020:mdna:73]
[same as prior period, unchanged from 0001137789-24-000182:mdna:68]

[0001137789-25-000020:mdna:74]
[same as prior period, unchanged from 0001137789-24-000182:mdna:69]

[0001137789-25-000020:mdna:75]
[same as prior period, unchanged from 0001137789-24-000182:mdna:70]

[0001137789-25-000020:mdna:76]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend and any future strategic investments. As of December 27, 2024, our contractual cash requirements have not changed materially outside of the normal course of business since our fiscal year ended June 28, 2024.

[0001137789-25-000020:mdna:77]
[same as prior period, unchanged from 0001137789-24-000182:mdna:72]

[0001137789-25-000020:mdna:78]
Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. From time to time, we enter into long-term, non-cancelable purchase commitments or make large up-front investments with certain suppliers in order to secure certain components or technologies for the production of our products or to supplement our internal manufacturing capacity for certain components. As of December 27, 2024, we had unconditional purchase obligations of approximately $900 million, primarily related to purchases of inventory components with our suppliers. We expect $810 million of these commitments to be paid within one year. In addition, we also had certain long-term, market share-based, non-cancellable inventory purchase commitments as of December 27, 2024.

[0001137789-25-000020:mdna:79]
We recorded order cancellation fees to terminate certain purchase commitments related to the purchase of inventory components and equipment. As of December 27, 2024, the cumulative unpaid order cancellation fees on the Condensed Consolidated Balance Sheets were $31 million, with $19 million in Accounts payable and $12 million in Accrued expenses, all of which is expected to be paid within one year. In certain instances, our unpaid order cancellation fees may change based on the expected timing or ongoing negotiations with our suppliers.

[0001137789-25-000020:mdna:80]
[same as prior period, unchanged from 0001137789-24-000182:mdna:76]

[0001137789-25-000020:mdna:81]
As of December 27, 2024, the future principal payment obligation on our long-term debt was $5.7 billion, of which $479 million had a maturity within one year and was fully repaid on January 2, 2025 at maturity. As of December 27, 2024, future interest payments on this outstanding debt is estimated to be approximately $1.8 billion, of which $312 million is expected to be paid within one year. From time to time, we may repurchase, redeem or otherwise extinguish any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase or redeem outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 1. Financial Statements—Note 3. Debt” for more details.

[0001137789-25-000020:mdna:82]
[same as prior period, unchanged from 0001137789-24-000182:mdna:78]

[0001137789-25-000020:mdna:83]
We accrued a settlement penalty of $300 million for fiscal year 2023, related to BIS’ allegations of violations of the U.S. EAR, which were subsequently resolved by the Settlement Agreement in April 2023. As part of the Settlement Agreement with BIS, quarterly payments of $15 million are made over the course of five years beginning October 31, 2023, of which $60 million is expected to be paid within one year and $165 million thereafter. Refer to “Item 1. Financial Statements—Note 11. Legal, Environmental and Other Contingencies” for more details.

[0001137789-25-000020:mdna:84]
[same as prior period, unchanged from 0001137789-24-000182:mdna:80]

[0001137789-25-000020:mdna:85]
On January 21, 2025, our Board of Directors declared a quarterly cash dividend of $0.72 per share, which will be payable on April 2, 2025 to shareholders of record as of the close of business on March 19, 2025. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-25-000020:mdna:86]
[same as prior period, unchanged from 0001137789-24-000182:mdna:82]

[0001137789-25-000020:mdna:87]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means, including through the use of derivative transactions. As of December 27, 2024, $1.8 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-25-000020:mdna:88]
33

[0001137789-25-000020:mdna:89]
[same as prior period, unchanged from 0001137789-24-000182:mdna:84]

[0001137789-25-000020:mdna:90]
[same as prior period, unchanged from 0001137789-24-000182:mdna:85]

[0001137789-25-000020:mdna:91]
[same as prior period, unchanged from 0001137789-24-000182:mdna:86]

[0001137789-25-000020:mdna:92]
[same as prior period, unchanged from 0001137789-24-000182:mdna:87]

[0001137789-25-000020:mdna:93]
[same as prior period, unchanged from 0001137789-24-000182:mdna:88]

[0001137789-25-000020:mdna:94]
[same as prior period, unchanged from 0001137789-24-000182:mdna:90]

[0001137789-25-000020:mdna:95]
[same as prior period, unchanged from 0001137789-24-000182:mdna:91]
