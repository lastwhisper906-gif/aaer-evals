# STX note change history — 0001137789-24-000182 → 0001137789-25-000020


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-01-24):
[0001137789-25-000020:note_history:1]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgment in favor of Seagate on April 19, 2022, following a jury trial. The parties filed post-trial motions with the district court, which were denied. An appeal to the Federal Circuit is pending. The Company believes the asserted claims are without merit and intends to vigorously defend this case.
  (was, 2024-10-25, similarity 0.6962):
[0001137789-24-000182:note_history:1]
Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgment in favor of Seagate on April 19, 2022, following a jury trial. The parties filed post-trial motions with the district court, which were denied. An appeal to the Federal Circuit is pending. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

- changed (2025-01-24):
[0001137789-25-000020:note_history:2]
In re Seagate Technology Holdings plc Securities Litigation. A putative class action lawsuit alleging violations of the federal securities laws, UA Local 38 Defined Contribution Pension Plan, et al. v. Seagate Technology Holdings PLC, et al., was filed on July 10, 2023, in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The complaint alleged that it was a securities class action on behalf of all purchasers of Seagate common stock between September 15, 2020 and October 25, 2022, inclusive, and asserted claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b5-1. The complaint sought unspecified monetary damages and other relief. A second action, Public Employees’ Retirement System of Mississippi v. Seagate Technology Holdings plc, William David Mosley, and Gianluca Romano, was filed on July 26, 2023, asserting similar claims. The cases were consolidated on September 25, 2023. On October 19, 2023, plaintiffs filed an amended complaint asserting similar claims with a putative class period of September 14, 2020 through April 19, 2023. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint. On August 8, 2024, the Court granted the Company’s motion to dismiss, with leave to amend. On September 12, 2024, the Plaintiffs filed an amended complaint. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint. A hearing on the motion is scheduled for March 4, 2025. The Company believes that the asserted claims are without merit and intends to vigorously defend the case.
  (was, 2024-10-25, similarity 0.8955):
[0001137789-24-000182:note_history:2]
In re Seagate Technology Holdings plc Securities Litigation. A putative class action lawsuit alleging violations of the federal securities laws, UA Local 38 Defined Contribution Pension Plan, et al. v. Seagate Technology Holdings PLC, et al., was filed on July 10, 2023, in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The complaint alleged that it was a securities class action on behalf of all purchasers of Seagate common stock between September 15, 2020 and October 25, 2022, inclusive, and asserted claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b5-1. The complaint sought unspecified monetary damages and other relief. A second action, Public Employees’ Retirement System of Mississippi v. Seagate Technology Holdings plc, William David Mosley, and Gianluca Romano, was filed on July 26, 2023, asserting similar claims. The cases were consolidated on September 25, 2023. On October 19, 2023, plaintiffs filed an amended complaint asserting similar claims with a putative class period of September 14, 2020 through April 19, 2023. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint. On August 8, 2024, the Court granted the Company’s motion to dismiss, with leave to amend. On September 12, 2024, the Plaintiffs filed an amended complaint. The Company believes that the asserted claims are without merit and intends to vigorously defend the case.

- changed (2025-01-24):
[0001137789-25-000020:note_history:3]
Godo Kaisha IP Bridge 1 v. Seagate Technology LLC, Seagate Technology (US) Holding, Inc., Seagate Technology (Thailand) Limited, Seagate Singapore International Headquarters Ltd., Seagate Technology (Netherlands) B.V. On March 15, 2024, a patent infringement action was filed by Godo Kaisha IP Bridge 1 (“IP Bridge”) against Seagate in U.S. District Court for the District of Delaware. The complaint alleges patent infringement by Seagate of three U.S. patents. On June 7, 2024, Seagate filed a motion to transfer venue to Minnesota. On July 8, 2024, IP Bridge filed a First Amended Complaint alleging patent infringement by Seagate of six additional patents. IP Bridge is seeking damages as well as additional relief. On September 4, 2024, the court granted Seagate’s motion to transfer the case to the District Court in Minnesota. On October 16, 2024, Seagate filed its answer to the First Amended Complaint. The Company believes the asserted claims are without merit and intends to vigorously defend this case.
  (was, 2024-10-25, similarity 0.7878):
[0001137789-24-000182:note_history:3]
Godo Kaisha IP Bridge 1 v. Seagate Technology LLC, Seagate Technology (US) Holding, Inc., Seagate Technology (Thailand) Limited, Seagate Singapore International Headquarters Ltd., Seagate Technology (Netherlands) B.V. On March 15, 2024, a patent infringement action was filed by Godo Kaisha IP Bridge 1 (“IP Bridge”) against Seagate in U.S. District Court for the District of Delaware. The complaint alleges patent infringement by Seagate of three U.S. patents. On June 7, 2024, Seagate filed a motion to dismiss and a motion to transfer venue to Minnesota. On July 8, 2024, IP Bridge filed a First Amended Complaint alleging patent infringement by Seagate of six additional patents. IP Bridge is seeking damages as well as additional relief. On August 5, 2024, Seagate filed a motion to dismiss in part IP Bridge’s First Amended Complaint. On September 4, 2024, Seagate won its motion to transfer the case to the District Court in Minnesota. Seagate’s motion to dismiss on the remaining claims is pending. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

- changed (2025-01-24):
[0001137789-25-000020:note_history:4]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air, soil and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.
  (was, 2024-10-25, similarity 0.6101):
[0001137789-24-000182:note_history:4]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of

- added (2025-01-24):
[0001137789-25-000020:note_history:5]
On April 18, 2023, the Company’s subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd (collectively, “Seagate”), entered into a settlement agreement (the “Settlement Agreement”) with the U.S. Department of Commerce’s Bureau of Industry and Security (“BIS”) that resolved BIS’ allegations regarding Seagate’s sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, Seagate agreed to pay $300 million to BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. Seagate also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the U.S. Export Administration Regulations (“EAR”), including one audit by an unaffiliated third-party consultant chosen by Seagate with expertise in U.S. export control laws, which has been completed, and two internal audits. The Settlement Agreement also included a denial order that is suspended and will be waived five years after the date of the order issued under the Settlement Agreement, provided that Seagate has made full and timely payments under the Settlement Agreement and timely completed the audit requirements. While Seagate is in compliance with and upon successful compliance in full with the terms of the Settlement Agreement, BIS agreed it will not initiate any further administrative proceedings against Seagate in connection with any violation of the EAR arising out of the transactions detailed in the Settlement Agreement.

- changed (2025-01-24):
[0001137789-25-000020:note_history:6]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $165 million were included in Accrued expense and Other non-current liabilities, respectively, on the Condensed Consolidated Balance Sheets as of December 27, 2024. For the six months ended December 27, 2024, $30 million was paid and reported as an outflow from operating activities in its Condensed Consolidated Statements of Cash Flows.
  (was, 2024-10-25, similarity 0.9395):
[0001137789-24-000182:note_history:6]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $180 million were included in Accrued expense and Other non-current liabilities, respectively, on the Condensed Consolidated Balance Sheets as of September 27, 2024. For the three months ended September 27, 2024, $15 million was paid and reported as an outflow from operating activities in its Condensed Consolidated Statements of Cash Flows.

- removed (2025-01-24):
[0001137789-24-000182:note_history:7]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material

- removed (2025-01-24):
[0001137789-24-000182:note_history:8]
hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

- removed (2025-01-24):
[0001137789-24-000182:note_history:9]
On April 18, 2023, the Company’s subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd (collectively, “Seagate”), entered into a settlement agreement (the “Settlement Agreement”) with the U.S. Department of Commerce’s Bureau of Industry and Security (“BIS”) that resolved BIS’ allegations regarding Seagate’s sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, Seagate agreed to pay $300 million to BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. Seagate also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the U.S. Export Administration Regulations (“EAR”), including one audit by an unaffiliated third-party consultant chosen by Seagate with expertise in U.S. export control laws and two internal audits, and has completed the first audit. The Settlement Agreement also included a denial order that is suspended and will be waived five years after the date of the order issued under the Settlement Agreement, provided that Seagate has made full and timely payments under the Settlement Agreement and timely completed the audit requirements. While Seagate is in compliance with and upon successful compliance in full with the terms of the Settlement Agreement, BIS agreed it will not initiate any further administrative proceedings against Seagate in connection with any violation of the EAR arising out of the transactions detailed in the Settlement Agreement.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-01-24):
[0001137789-25-000020:note_history:10]
The Company’s Consolidated Financial Statements for the fiscal year ended June 28, 2024 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 2, 2024. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 28, 2024, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and six months ended December 27, 2024 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 27, 2025.
  (was, 2024-10-25, similarity 0.971):
[0001137789-24-000182:note_history:10]
The Company’s Consolidated Financial Statements for the fiscal year ended June 28, 2024 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 2, 2024. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 28, 2024, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three months ended September 27, 2024 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 27, 2025.

- added (2025-01-24):
[0001137789-25-000020:note_history:11]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and six months ended December 27, 2024 and December 29, 2023 consisted of 13 and 26 weeks, respectively. Fiscal years 2025 and 2024 both comprise 52 weeks and end on June 27, 2025 and June 28, 2024, respectively. The fiscal quarters ended December 27, 2024, September 27, 2024 and December 29, 2023, are also referred to herein as the “December 2024 quarter”, the “September 2024 quarter” and the “December 2023 quarter”, respectively.

- changed (2025-01-24):
[0001137789-25-000020:note_history:12]
In November 2023, the FASB issued ASU 2023-07 (ASC Topic 280), Improvements to Reportable Segment Disclosures. This ASU improves reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The Company is required to adopt this guidance for its annual reporting in fiscal year 2025 and for interim period reporting beginning the first quarter of fiscal year 2026 on a retrospective basis. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have an impact on its Condensed Consolidated Financial Statements.
  (was, 2024-10-25, similarity 0.694):
[0001137789-24-000182:note_history:12]
In November 2023, the FASB issued ASU 2023-07 (ASC Topic 280), Improvements to Reportable Segment Disclosures. This ASU improves reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The Company is required to adopt this guidance for its annual reporting in fiscal year 2025 and for interim period reporting beginning the first quarter of fiscal year 2026 on a retrospective basis. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have an impact on its Condensed Consolidated Financial Statements.
In December 2023, the FASB issued ASU 2023-09 (ASC Topic 740), Improvements to Income Tax Disclosures. This ASU requires disaggregated income tax disclosures on the rate reconciliation and income taxes paid. The Company is required to adopt this guidance for its annual reporting in fiscal year 2026 on a prospective basis but has the option to apply it retrospectively. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have an impact on its Condensed Consolidated Financial Statements.

- added (2025-01-24):
[0001137789-25-000020:note_history:13]
In December 2023, the FASB issued ASU 2023-09 (ASC Topic 740), Improvements to Income Tax Disclosures. This ASU requires disaggregated income tax disclosures on the rate reconciliation and income taxes paid. The Company is required to adopt this guidance for its annual reporting in fiscal year 2026 on a prospective basis but has the option to apply it retrospectively. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have an impact on its Condensed Consolidated Financial Statements.

- removed (2025-01-24):
[0001137789-24-000182:note_history:14]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three months ended September 27, 2024 and September 29, 2023 consisted of 13 weeks. Fiscal years 2025 and 2024 both comprise 52 weeks and end on June 27, 2025 and June 28, 2024, respectively. The fiscal quarters ended September 27, 2024, June 28, 2024 and September 29, 2023, are also referred to herein as the “September 2024 quarter”, the “June 2024 quarter” and the “September 2023 quarter”, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-01-24):
[0001137789-25-000020:note_history:15]
Debt
The following table provides details of the Company’s debt as of December 27, 2024 and June 28, 2024:
  (was, 2024-10-25, similarity 0.9741):
[0001137789-24-000182:note_history:15]
Debt
The following table provides details of the Company’s debt as of September 27, 2024 and June 28, 2024:

- changed (2025-01-24):
[0001137789-25-000020:note_history:16]
| (Dollars in millions) |  | December 27, 2024 |  | June 28, 2024 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 505 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 473 |  |  | 471 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,706 |  |  | 5,704 |  |
| Less: unamortized debt issuance costs |  | (27) |  |  | (30) |  |
| Debt, net of debt issuance costs |  | 5,679 |  |  | 5,674 |  |
| Less: current portion of long-term debt |  | (479) |  |  | (479) |  |
| Long-term debt, less current portion |  | $ | 5,200 |  |  | $ | 5,195 |  |
  (was, 2024-10-25, similarity 0.9983):
[0001137789-24-000182:note_history:16]
| (Dollars in millions) |  | September 27, 2024 |  | June 28, 2024 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 505 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 472 |  |  | 471 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,705 |  |  | 5,704 |  |
| Less: unamortized debt issuance costs |  | (29) |  |  | (30) |  |
| Debt, net of debt issuance costs |  | 5,676 |  |  | 5,674 |  |
| Less: current portion of long-term debt |  | (479) |  |  | (479) |  |
| Long-term debt, less current portion |  | $ | 5,197 |  |  | $ | 5,195 |  |

- added (2025-01-24):
[0001137789-25-000020:note_history:17]
For the three and six months ended December 27, 2024, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $13 million and $26 million, respectively, and immaterial amortization of debt issuance costs. For the three and six months ended December 29, 2023, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $13 million and $15 million, respectively, and immaterial amortization of debt issuance costs.

- changed (2025-01-24):
[0001137789-25-000020:note_history:18]
The entire outstanding principal amount of Term Loans A1, A2 and A3 were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in Net loss recognized from early redemption of debt in the Company’s Condensed Consolidated Statements of Operations for the six months ended December 29, 2023. In connection with the repayment of Term Loans, the Company terminated certain interest rate swap agreements. Refer to “Note 5. Derivative Financial Instruments” for more details.
  (was, 2024-10-25, similarity 0.6543):
[0001137789-24-000182:note_history:18]
The entire outstanding principal amount of Term Loans A1, A2 and A3 were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in the Net loss recognized from early redemption of debt in the Company’s Condensed Consolidated Statements of Operations. In connection with the repayment of Term Loans, the Company terminated certain interest rate swap agreements. Refer to “Note 5. Derivative Financial Instruments” for more details.

- changed (2025-01-24):
[0001137789-25-000020:note_history:19]
Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The current exchange rate for the 2028 Notes is 12.1278 ordinary shares per $1,000 principal amount of 2028 Notes, which is equivalent to an exchange price of approximately $82.46 per share as of December 27, 2024. The exchange rate was adjusted from 12.1253 ordinary shares per $1,000 principal amount of 2028 Notes on December 13, 2024, and is subject to further adjustment pursuant to the terms of the Exchangeable Notes indenture.
  (was, 2024-10-25, similarity 0.8273):
[0001137789-24-000182:note_history:19]
Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The initial exchange rate for the 2028 Notes is 12.1253 ordinary shares per $1,000 principal amount of 2028 Notes, which is equivalent to an exchange price of approximately $82.47 per share.

- changed (2025-01-24):
[0001137789-25-000020:note_history:20]
As of December 27, 2024, the 2028 Notes were not exchangeable. Refer to “Note 10. Earnings (Loss) Per Share” for the potential dilutive impact of the 2028 Notes.
  (was, 2024-10-25, similarity 0.9831):
[0001137789-24-000182:note_history:20]
As of September 27, 2024, the 2028 Notes were not exchangeable. Refer to “Note 10. Earnings (Loss) Per Share” for the potential dilutive impact of the 2028 Notes.

- changed (2025-01-24):
[0001137789-25-000020:note_history:21]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The current cap price of the capped call transactions, which was adjusted on December 13, 2024 in accordance with the applicable capped call confirmations, is $107.826 per share. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets.
  (was, 2024-10-25, similarity 0.8931):
[0001137789-24-000182:note_history:21]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The cap price of the capped call transactions will initially be $107.848 per share. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets.

- added (2025-01-24):
[0001137789-25-000020:note_history:22]
2025 Senior Notes

- added (2025-01-24):
[0001137789-25-000020:note_history:23]
On January 2, 2025, the entire outstanding principal amount of $479 million was repaid at par, plus accrued and unpaid interest.

- changed (2025-01-24):
[0001137789-25-000020:note_history:24]
The credit agreement dated as of February 20, 2019, by and among, Seagate Technology Holdings plc, Seagate HDD, The Bank of Nova Scotia, as administrative agent, and the lenders party thereto (as amended from time to time, the “Credit Agreement”) includes two financial covenants: (1) interest coverage ratio and (2) total net leverage ratio. For the fiscal quarter ended December 27, 2024, and for each fiscal quarter until the end of the covenant relief period, which terminates on June 27, 2025, the maximum permitted total net leverage ratio is 6.75 to 1.00, and applies only to the extent that the aggregate outstanding amount of revolving loans, swing line loans and the aggregate face amount of certain letters of credit exceeds 25% of the then outstanding revolving commitments in effect (the “Testing Condition”) as of the last day of the relevant fiscal quarter. The maximum permitted total leverage ratio for each fiscal quarter ending after June 27, 2025 is 4.00 to 1.00.
  (was, 2024-10-25, similarity 0.9963):
[0001137789-24-000182:note_history:24]
The credit agreement dated as of February 20, 2019, by and among, Seagate Technology Holdings plc, Seagate HDD, The Bank of Nova Scotia, as administrative agent, and the lenders party thereto (as amended from time to time, the “Credit Agreement”) includes two financial covenants: (1) interest coverage ratio and (2) total net leverage ratio. For the fiscal quarter ended September 27, 2024, and for each fiscal quarter until the end of the covenant relief period, which terminates on June 27, 2025, the maximum permitted total net leverage ratio is 6.75 to 1.00, and applies only to the extent that the aggregate outstanding amount of revolving loans, swing line loans and the aggregate face amount of certain letters of credit exceeds 25% of the then outstanding revolving commitments in effect (the “Testing Condition”) as of the last day of the relevant fiscal quarter. The maximum permitted total leverage ratio for each fiscal quarter ending after June 27, 2025 is 4.00 to 1.00.

- changed (2025-01-24):
[0001137789-25-000020:note_history:25]
For the fiscal quarter ended December 27, 2024, and for each fiscal quarter until the end of the covenant relief period, which terminates on June 27, 2025, the minimum interest coverage ratio is 2.25 to 1.00, and applies only to the extent that the Testing Condition is satisfied as of the last day of the relevant fiscal quarter. The minimum interest coverage ratio for each fiscal quarter ending after June 27, 2025 is 3.25 to 1.00.
  (was, 2024-10-25, similarity 0.9913):
[0001137789-24-000182:note_history:25]
For the fiscal quarter ended September 27, 2024, and for each fiscal quarter until the end of the covenant relief period, which terminates on June 27, 2025, the minimum interest coverage ratio is 2.25 to 1.00, and applies only to the extent that the Testing Condition is satisfied as of the last day of the relevant fiscal quarter. The minimum interest coverage ratio for each fiscal quarter ending after June 27, 2025 is 3.25 to 1.00.

- changed (2025-01-24):
[0001137789-25-000020:note_history:26]
At December 27, 2024, future principal payments on long-term debt were as follows (in millions):
  (was, 2024-10-25, similarity 0.9724):
[0001137789-24-000182:note_history:26]
At September 27, 2024, future principal payments on long-term debt were as follows (in millions):

- removed (2025-01-24):
[0001137789-24-000182:note_history:27]
For the three months ended September 27, 2024, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $26 million and immaterial amortization of debt issuance costs.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-01-24):
[0001137789-25-000020:note_history:28]
|  |  | December 27, 2024 |  | June 28, 2024 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 4.75% Senior Notes due January 2025 |  | 479 |  |  | 479 |  |  | 479 |  |  | 476 |  |
| 4.875% Senior Notes due June 2027 |  | 505 |  |  | 498 |  |  | 505 |  |  | 493 |  |
| 3.50% Exchangeable Senior Notes due June 2028 |  | 1,500 |  |  | 1,840 |  |  | 1,500 |  |  | 2,070 |  |
| 4.091% Senior Notes due June 2029 |  | 473 |  |  | 459 |  |  | 471 |  |  | 459 |  |
| 3.125% Senior Notes due July 2029 |  | 163 |  |  | 147 |  |  | 163 |  |  | 139 |  |
| 8.25% Senior Notes due December 2029 |  | 500 |  |  | 533 |  |  | 500 |  |  | 537 |  |
| 4.125% Senior Notes due January 2031 |  | 275 |  |  | 248 |  |  | 275 |  |  | 245 |  |
| 3.375% Senior Notes due July 2031 |  | 72 |  |  | 58 |  |  | 72 |  |  | 58 |  |
| 8.50% Senior Notes due July 2031 |  | 500 |  |  | 534 |  |  | 500 |  |  | 538 |  |
| 9.625% Senior Notes due December 2032 |  | 750 |  |  | 847 |  |  | 750 |  |  | 855 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 473 |  |  | 489 |  |  | 472 |  |
|  |  | $ | 5,706 |  |  | $ | 6,116 |  |  | $ | 5,704 |  |  | $ | 6,342 |  |
| Less: unamortized debt issuance costs |  | (27) |  |  | — |  |  | (30) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 5,679 |  |  | $ | 6,116 |  |  | $ | 5,674 |  |  | $ | 6,342 |  |
| Less: current portion of debt, net of debt issuance costs |  | (479) |  |  | (479) |  |  | (479) |  |  | (476) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,200 |  |  | $ | 5,637 |  |  | $ | 5,195 |  |  | $ | 5,866 |  |
  (was, 2024-10-25, similarity 0.9973):
[0001137789-24-000182:note_history:28]
|  |  | September 27, 2024 |  | June 28, 2024 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 4.75% Senior Notes due January 2025 |  | 479 |  |  | 478 |  |  | 479 |  |  | 476 |  |
| 4.875% Senior Notes due June 2027 |  | 505 |  |  | 504 |  |  | 505 |  |  | 493 |  |
| 3.50% Exchangeable Senior Notes due June 2028 |  | 1,500 |  |  | 2,142 |  |  | 1,500 |  |  | 2,070 |  |
| 4.091% Senior Notes due June 2029 |  | 472 |  |  | 475 |  |  | 471 |  |  | 459 |  |
| 3.125% Senior Notes due July 2029 |  | 163 |  |  | 147 |  |  | 163 |  |  | 139 |  |
| 8.25% Senior Notes due December 2029 |  | 500 |  |  | 544 |  |  | 500 |  |  | 537 |  |
| 4.125% Senior Notes due January 2031 |  | 275 |  |  | 254 |  |  | 275 |  |  | 245 |  |
| 3.375% Senior Notes due July 2031 |  | 72 |  |  | 61 |  |  | 72 |  |  | 58 |  |
| 8.50% Senior Notes due July 2031 |  | 500 |  |  | 547 |  |  | 500 |  |  | 538 |  |
| 9.625% Senior Notes due December 2032 |  | 750 |  |  | 871 |  |  | 750 |  |  | 855 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 494 |  |  | 489 |  |  | 472 |  |
|  |  | $ | 5,705 |  |  | $ | 6,517 |  |  | $ | 5,704 |  |  | $ | 6,342 |  |
| Less: unamortized debt issuance costs |  | (29) |  |  | — |  |  | (30) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 5,676 |  |  | $ | 6,517 |  |  | $ | 5,674 |  |  | $ | 6,342 |  |
| Less: current portion of debt, net of debt issuance costs |  | (479) |  |  | (478) |  |  | (479) |  |  | (476) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,197 |  |  | $ | 6,039 |  |  | $ | 5,195 |  |  | $ | 5,866 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-01-24):
[0001137789-25-000020:note_history:29]
The following table provides details of the Company’s debt as of December 27, 2024 and June 28, 2024:
  (was, 2024-10-25, similarity 0.9727):
[0001137789-24-000182:note_history:29]
The following table provides details of the Company’s debt as of September 27, 2024 and June 28, 2024:

- changed (2025-01-24):
[0001137789-25-000020:note_history:30]
| (Dollars in millions) |  | December 27, 2024 |  | June 28, 2024 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 505 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 473 |  |  | 471 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,706 |  |  | 5,704 |  |
| Less: unamortized debt issuance costs |  | (27) |  |  | (30) |  |
| Debt, net of debt issuance costs |  | 5,679 |  |  | 5,674 |  |
| Less: current portion of long-term debt |  | (479) |  |  | (479) |  |
| Long-term debt, less current portion |  | $ | 5,200 |  |  | $ | 5,195 |  |
  (was, 2024-10-25, similarity 0.9983):
[0001137789-24-000182:note_history:30]
| (Dollars in millions) |  | September 27, 2024 |  | June 28, 2024 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 505 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 472 |  |  | 471 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,705 |  |  | 5,704 |  |
| Less: unamortized debt issuance costs |  | (29) |  |  | (30) |  |
| Debt, net of debt issuance costs |  | 5,676 |  |  | 5,674 |  |
| Less: current portion of long-term debt |  | (479) |  |  | (479) |  |
| Long-term debt, less current portion |  | $ | 5,197 |  |  | $ | 5,195 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-01-24):
[0001137789-25-000020:note_history:31]
At December 27, 2024, future principal payments on long-term debt were as follows (in millions):
  (was, 2024-10-25, similarity 0.9724):
[0001137789-24-000182:note_history:31]
At September 27, 2024, future principal payments on long-term debt were as follows (in millions):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-01-24):
[0001137789-25-000020:note_history:32]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | December 27, 2024 |  | December 29, 2023 |  | December 27, 2024 |  | December 29, 2023 |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,841 |  |  | $ | 1,140 |  |  | $ | 3,590 |  |  | $ | 2,172 |  |  |  |
| Distributors |  | 278 |  |  | 218 |  |  | 527 |  |  | 484 |  |  |  |
| Retailers |  | 206 |  |  | 197 |  |  | 376 |  |  | 353 |  |  |  |
| Total |  | $ | 2,325 |  |  | $ | 1,555 |  |  | $ | 4,493 |  |  | $ | 3,009 |  |  |  |

- changed (2025-01-24):
[0001137789-25-000020:note_history:33]
| Revenue by Country (1): |  |  |  |  |  |  |  |  |  |  |
| Singapore |  | $ | 1,034 |  |  | $ | 775 |  |  | $ | 1,894 |  |  | $ | 1,583 |  |  |  |
| United States |  | 1,059 |  |  | 544 |  |  | 2,156 |  |  | 999 |  |  |  |
| The Netherlands |  | 231 |  |  | 234 |  |  | 441 |  |  | 422 |  |  |  |
| Other |  | 1 |  |  | 2 |  |  | 2 |  |  | 5 |  |  |  |
| Total |  | $ | 2,325 |  |  | $ | 1,555 |  |  | $ | 4,493 |  |  | $ | 3,009 |  |  |  |
  (was, 2024-10-25, similarity 0.81):
[0001137789-24-000182:note_history:33]
| Revenue by Country (1): |  |  |  |  |  |  |
| Singapore |  | $ | 860 |  |  | $ | 808 |  |  |  |
| United States |  | 1,097 |  |  | 455 |  |  |  |
| The Netherlands |  | 210 |  |  | 188 |  |  |  |
| Other |  | 1 |  |  | 3 |  |  |  |
| Total |  | $ | 2,168 |  |  | $ | 1,454 |  |  |  |

- removed (2025-01-24):
[0001137789-24-000182:note_history:34]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 27, 2024 |  | September 29, 2023 |  |  |
| Revenues by Channel |  |  |  |  |  |  |
| OEMs |  | $ | 1,749 |  |  | $ | 1,032 |  |  |  |
| Distributors |  | 248 |  |  | 266 |  |  |  |
| Retailers |  | 171 |  |  | 156 |  |  |  |
| Total |  | $ | 2,168 |  |  | $ | 1,454 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-01-24):
[0001137789-25-000020:note_history:35]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | December 27, 2024 |  | December 29, 2023 |  | December 27, 2024 |  | December 29, 2023 |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,841 |  |  | $ | 1,140 |  |  | $ | 3,590 |  |  | $ | 2,172 |  |  |  |
| Distributors |  | 278 |  |  | 218 |  |  | 527 |  |  | 484 |  |  |  |
| Retailers |  | 206 |  |  | 197 |  |  | 376 |  |  | 353 |  |  |  |
| Total |  | $ | 2,325 |  |  | $ | 1,555 |  |  | $ | 4,493 |  |  | $ | 3,009 |  |  |  |

- changed (2025-01-24):
[0001137789-25-000020:note_history:36]
| Revenue by Country (1): |  |  |  |  |  |  |  |  |  |  |
| Singapore |  | $ | 1,034 |  |  | $ | 775 |  |  | $ | 1,894 |  |  | $ | 1,583 |  |  |  |
| United States |  | 1,059 |  |  | 544 |  |  | 2,156 |  |  | 999 |  |  |  |
| The Netherlands |  | 231 |  |  | 234 |  |  | 441 |  |  | 422 |  |  |  |
| Other |  | 1 |  |  | 2 |  |  | 2 |  |  | 5 |  |  |  |
| Total |  | $ | 2,325 |  |  | $ | 1,555 |  |  | $ | 4,493 |  |  | $ | 3,009 |  |  |  |
  (was, 2024-10-25, similarity 0.81):
[0001137789-24-000182:note_history:36]
| Revenue by Country (1): |  |  |  |  |  |  |
| Singapore |  | $ | 860 |  |  | $ | 808 |  |  |  |
| United States |  | 1,097 |  |  | 455 |  |  |  |
| The Netherlands |  | 210 |  |  | 188 |  |  |  |
| Other |  | 1 |  |  | 3 |  |  |  |
| Total |  | $ | 2,168 |  |  | $ | 1,454 |  |  |  |

- removed (2025-01-24):
[0001137789-24-000182:note_history:37]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 27, 2024 |  | September 29, 2023 |  |  |
| Revenues by Channel |  |  |  |  |  |  |
| OEMs |  | $ | 1,749 |  |  | $ | 1,032 |  |  |  |
| Distributors |  | 248 |  |  | 266 |  |  |  |
| Retailers |  | 171 |  |  | 156 |  |  |  |
| Total |  | $ | 2,168 |  |  | $ | 1,454 |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2025-01-24):
[0001137789-25-000020:note_history:38]
Subsequent Event
  (was, 2024-10-25, similarity 0.64):
[0001137789-24-000182:note_history:38]
Subsequent Event
Dividend Declared

- removed (2025-01-24):
[0001137789-24-000182:note_history:39]
On October 22, 2024, the Board of Directors of the Company declared a quarterly cash dividend of $0.72 per share, which will be payable on January 6, 2025 to shareholders of record as of the close of business on December 15, 2024.
