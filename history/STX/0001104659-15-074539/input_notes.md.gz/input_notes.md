# STX notes — 0001104659-15-074539


## invest:InvestmentTableTextBlock

[0001104659-15-074539:notes:1]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,203 |  |  | $ | — |  |  | $ | 1,203 |  |
| Certificates of deposit |  | 867 |  |  | — |  |  | 867 |  |
| Corporate bonds |  | 6 |  |  | — |  |  | 6 |  |
| Total |  | $ | 2,076 |  |  | $ | — |  |  | $ | 2,076 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 2,063 |  |
| Included in Short-term investments |  |  |  |  |  |  |  | 6 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 7 |  |
| Total |  |  |  |  |  |  |  | $ | 2,076 |  |

[0001104659-15-074539:notes:2]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 243 |  |  | $ | — |  |  | $ | 243 |  |
| Certificates of deposit |  | 228 |  |  | — |  |  | 228 |  |
| Corporate bonds |  | 6 |  |  | — |  |  | 6 |  |
|  |  | $ | 477 |  |  | $ | — |  |  | $ | 477 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 464 |  |
| Included in Short-term investments |  |  |  |  |  |  |  | 6 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 7 |  |
| Total |  |  |  |  |  |  |  | $ | 477 |  |


## stx:ScheduleOfShareRepurchasesTableTextBlock

[0001104659-15-074539:notes:3]
| (In millions) | Number ofSharesRepurchased |  | Dollar Valueof SharesRepurchased |
| Repurchases of ordinary shares | 20 |  |  | $ | 983 |  |
| Tax Withholding Related to Vesting of Equity Awards | 1 |  |  | 53 |  |
| Fiscal year repurchased through October 2, 2015 | 21 |  |  | $ | 1,036 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001104659-15-074539:notes:4]
[same as prior period, unchanged from 0001104659-15-032642:notes:7]

[0001104659-15-074539:notes:5]
[same as prior period, unchanged from 0001104659-15-032642:notes:8]

[0001104659-15-074539:notes:6]
On September 2, 2014, the Company completed the acquisition of certain assets and liabilities of LSI Corporation's ("LSI") Accelerated Solutions Division and Flash Components Division (collectively, the "Flash Business") from Avago Technologies Limited for $450 million in cash. The transaction is intended to strengthen Seagate's strategy to deliver a full suite of storage solutions, providing Seagate with established enterprise PCIe flash and SSD controller capabilities to deliver solutions for the growing flash storage market.

[0001104659-15-074539:notes:7]
[same as prior period, unchanged from 0001104659-15-032642:notes:10]

[0001104659-15-074539:notes:8]
[same as prior period, unchanged from 0001104659-15-032642:notes:11]

[0001104659-15-074539:notes:9]
[same as prior period, unchanged from 0001104659-15-032642:notes:12]

[0001104659-15-074539:notes:10]
[same as prior period, unchanged from 0001104659-15-032642:notes:13]

[0001104659-15-074539:notes:11]
[same as prior period, unchanged from 0001104659-15-032642:notes:14]

[0001104659-15-074539:notes:12]
The Company incurred approximately $1 million of expenses related to the acquisition of LSI's Flash Business in the September 2014 quarter, which were included within Marketing and administrative expense on the Company's Condensed Consolidated Statement of Operations.

[0001104659-15-074539:notes:13]
The amounts of revenue and earnings of LSI's Flash Business included in the Company's Consolidated Statement of Operations from the acquisition date through the end of the September 2014 quarter were not significant.

[0001104659-15-074539:notes:14]
[same as prior period, unchanged from 0001104659-15-032642:notes:17]

[0001104659-15-074539:notes:15]
[same as prior period, unchanged from 0001104659-15-032642:notes:18]

[0001104659-15-074539:notes:16]
[same as prior period, unchanged from 0001104659-15-032642:notes:19]

[0001104659-15-074539:notes:17]
The following table shows the fair value of the separately identifiable intangible assets at the time of acquisition and the period over which each intangible asset will be amortized:

[0001104659-15-074539:notes:18]
[same as prior period, unchanged from 0001104659-15-032642:notes:21]

[0001104659-15-074539:notes:19]
The goodwill recognized is primarily attributable to the synergies expected to arise after the acquisition, and is not deductible for income tax purposes.


## us-gaap:ConsolidationPolicyTextBlock

[0001104659-15-074539:notes:20]
[same as prior period, unchanged from 0001104659-15-032642:notes:25]

[0001104659-15-074539:notes:21]
[same as prior period, unchanged from 0001104659-15-032642:notes:26]

[0001104659-15-074539:notes:22]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income, cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature. Certain prior period amounts in the condensed consolidated financial statements and notes to the condensed consolidated financial statements have been reclassified to conform to the current period’s presentation.

[0001104659-15-074539:notes:23]
The Company’s Consolidated Financial Statements for the fiscal year ended July 3, 2015, are included in its Annual Report on Form 10-K as filed with the United States Securities and Exchange Commission (“SEC”) on August 11, 2015. The Company believes that the disclosures included in the unaudited condensed consolidated financial statements, when read in conjunction with its Consolidated Financial Statements as of July 3, 2015, and the notes thereto, are adequate to make the information presented not misleading.


## us-gaap:DebtDisclosureTextBlock

[0001104659-15-074539:notes:24]
Debt

[0001104659-15-074539:notes:25]
Short-Term Borrowings

[0001104659-15-074539:notes:26]
The Company and its subsidiary Seagate HDD Cayman have entered into a Credit Agreement providing the Company with a $700 million senior secured revolving credit facility (the "Revolving Credit Facility"). On January 15, 2015, pursuant to the Third Amendment to the Credit Agreement, the commitments available under the Revolving Credit Facility were increased from $500 million to $700 million and the maturity date was extended until January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Credit Agreement) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. This Credit Agreement that was originally entered into by the Company and Seagate HDD Cayman on January 18, 2011 was subsequently amended with the Second Amendment to the Credit Agreement on April 30, 2013, which increased the commitments available under the Revolving Credit Facility from $350 million to $500 million. The loans made under the Credit Agreement will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings and for the issuance of letters of credit up to a sub-limit of $75 million. As of October 2, 2015, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

[0001104659-15-074539:notes:27]
Long-Term Debt

[0001104659-15-074539:notes:28]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-15-074539:notes:29]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman, and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2015 quarter, the Company repurchased $0.5 million aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The loss recorded on the repurchase was immaterial, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

[0001104659-15-074539:notes:30]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2015 quarter, the Company repurchased $10 million aggregate principal amount of its 2023 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The loss recorded on the repurchase was immaterial, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

[0001104659-15-074539:notes:31]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2015 quarter, the Company repurchased $5 million aggregate principal amount of its 2025 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The gain recorded on the repurchase was immaterial, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

[0001104659-15-074539:notes:32]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on December 1, 2015. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-15-074539:notes:33]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-15-074539:notes:34]
At October 2, 2015, future principal payments on long-term debt were as follows (in millions):

[0001104659-15-074539:notes:35]
| Fiscal Year | Amount |
| Remainder of 2016 | $ | — |  |
| 2017 | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| 2020 | — |  |
| Thereafter | 3,343 |  |
|  | $ | 4,143 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001104659-15-074539:notes:36]
[same as prior period, unchanged from 0001104659-15-032642:notes:42]

[0001104659-15-074539:notes:37]
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity price risks relating to its ongoing business operations.  The Company enters into foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses denominated in foreign currencies and to mitigate the remeasurement risk of certain foreign currency denominated liabilities.  The Company's accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments.  The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value.  The changes in the fair value of the effective portions of designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings.  Derivatives that are not designated as hedging instruments and the ineffective portions of cash flow hedges are adjusted to fair value through earnings. The amount of net unrealized loss on cash flow hedges was $1 million as of October 2, 2015. The amount of net unrealized gain on cash flow hedges was $1 million as of July 3, 2015.

[0001104659-15-074539:notes:38]
The Company de-designates its cash flow hedges when the forecasted hedged transactions are realized or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive income (loss) are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company did not recognize any net gains or losses related to the loss of hedge designation on discontinued cash flow hedges during the three months ended October 2, 2015. As of October 2, 2015, the Company’s existing foreign currency forward exchange contracts mature within 12 months. The deferred amount currently recorded in Accumulated other comprehensive income (loss) expected to be recognized into earnings over the next 12 months is $1 million.

[0001104659-15-074539:notes:39]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of October 2, 2015 and July 3, 2015:

[0001104659-15-074539:notes:40]
|  |  | As of October 2, 2015 |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| British Pound Sterling |  | $ | 22 |  |  | $ | — |  |
| Thai Baht |  | 9 |  |  | 9 |  |
| Malaysian Ringgit |  | 5 |  |  | 7 |  |
| Euro |  | — |  |  | 6 |  |
|  |  | $ | 36 |  |  | $ | 22 |  |

[0001104659-15-074539:notes:41]
|  |  | As of July 3, 2015 |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| British Pound Sterling |  | $ | 35 |  |  | $ | — |  |
| Singapore dollars |  | 23 |  |  | 42 |  |
| Thai Baht |  | 18 |  |  | 48 |  |
| Malaysian Ringgit |  | 12 |  |  | 15 |  |
| Chinese Reniminbi |  | 5 |  |  | 16 |  |
| Euro |  | — |  |  | 13 |  |
|  |  | $ | 93 |  |  | $ | 134 |  |

[0001104659-15-074539:notes:42]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plan—the Seagate Deferred Compensation Plan (the “SDCP”). In the quarter ended December 27, 2013, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees. As of October 2, 2015, the notional investments underlying the TRS amounted to $93 million. The contract term of the TRS is through January 2016, and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001104659-15-074539:notes:43]
The following tables show the Company’s derivative instruments measured at fair value as reflected in the Condensed Consolidated Balance Sheet as of October 2, 2015 and July 3, 2015:

[0001104659-15-074539:notes:44]
|  |  | As of October 2, 2015 |
|  |  | Asset Derivatives |  | Liability Derivatives |
| (Dollars in millions) |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 1 |  |  | Accrued expenses |  | $ | (2 | ) |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (2 | ) |
| Total return swap |  | Other current assets |  | 2 |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 3 |  |  |  |  | $ | (4 | ) |

[0001104659-15-074539:notes:45]
|  |  | As of July 3, 2015 |
|  |  | Asset Derivatives |  | Liability Derivatives |
| (Dollars in millions) |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 2 |  |  | Accrued expenses |  | $ | (1 | ) |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (3 | ) |
| Total return swap |  | Other current assets |  | 1 |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 3 |  |  |  |  | $ | (4 | ) |

[0001104659-15-074539:notes:46]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statement of Comprehensive Income and the Condensed Consolidated Statement of Operations for the three months ended October 2, 2015:

[0001104659-15-074539:notes:47]
[same as prior period, unchanged from 0001104659-15-032642:notes:53]

[0001104659-15-074539:notes:48]
| Derivatives Designated as Hedging Instruments |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
| Foreign currency forward exchange contracts |  | $ | (2 | ) |  | Cost of revenue |  | $ | (1 | ) |  | Cost of revenue |  | $ | — |  |

[0001104659-15-074539:notes:49]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivative |  | Amount of Gain or(Loss) Recognized inIncome on Derivative |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (5 | ) |
| Total return swap |  | Operating expenses |  | (5 | ) |

[0001104659-15-074539:notes:50]
[same as prior period, unchanged from 0001104659-15-032642:notes:56]

[0001104659-15-074539:notes:51]
| (a) | The amount of gain or (loss) recognized in income represents $0 related to the ineffective portion of the hedging relationships and $0 related to the amount excluded from the assessment of hedge effectiveness for the three months ended October 2, 2015, respectively. |

[0001104659-15-074539:notes:52]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statement of Comprehensive Income and the Condensed Consolidated Statement of Operations for the three months ended October 3, 2014:

[0001104659-15-074539:notes:53]
[same as prior period, unchanged from 0001104659-15-032642:notes:59]

[0001104659-15-074539:notes:54]
| Derivatives Designated as Hedging Instruments |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
| Foreign currency forward exchange contracts |  | $ | (3 | ) |  | Cost of revenue |  | $ | — |  |  | Cost of revenue |  | $ | 1 |  |

[0001104659-15-074539:notes:55]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (4 | ) |
| Total return swap |  | Operating expenses |  | (3 | ) |

[0001104659-15-074539:notes:56]
| (a) | The amount of gain or (loss) recognized in income represents $0 related to the ineffective portion of the hedging relationships and $1 million related to the amount excluded from the assessment of hedge effectiveness for the three months ended October 3, 2014. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-15-074539:notes:57]
[same as prior period, unchanged from 0001104659-15-032642:notes:63]

[0001104659-15-074539:notes:58]
The Company recorded approximately $33 million and $42 million of stock-based compensation expense during the three months ended October 2, 2015 and October 3, 2014, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001104659-15-074539:notes:59]
[same as prior period, unchanged from 0001104659-15-032642:notes:65]

[0001104659-15-074539:notes:60]
[same as prior period, unchanged from 0001104659-15-032642:notes:66]

[0001104659-15-074539:notes:61]
|  |  | For the Three Months Ended |
| (In millions, except per share data) |  | October 2, 2015 |  | October 3, 2014 |
| Numerator: |  |  |  |  |  |  |
| Net income attributable to Seagate Technology plc |  | $ | 34 |  |  | $ | 381 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share attributable to Seagate Technology plc |  | 302 |  |  | 327 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |
| Employee equity award plans |  | 6 |  |  | 10 |  |
| Total shares for purpose of calculating diluted net income per share attributable to Seagate Technology plc |  | 308 |  |  | 337 |  |
| Net income per share attributable to Seagate Technology plc shareholders: |  |  |  |  |  |  |
| Basic |  | $ | 0.11 |  |  | $ | 1.17 |  |
| Diluted |  | $ | 0.11 |  |  | $ | 1.13 |  |

[0001104659-15-074539:notes:62]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share attributable to Seagate Technology plc were immaterial for the three months ended October 2, 2015 and October 3, 2014.


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001104659-15-074539:notes:63]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 241 |  |  | $ | 223 |  |  | $ | — |  |  | $ | 464 |  |
| Short-term investments | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Other current assets | 2 |  |  | 8 |  |  | — |  |  | 10 |  |
| Total assets | $ | 243 |  |  | $ | 237 |  |  | $ | — |  |  | $ | 480 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued expenses | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |
| Total liabilities | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |

[0001104659-15-074539:notes:64]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1,201 |  |  | $ | 862 |  |  | $ | — |  |  | $ | 2,063 |  |
| Short-term investments | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Other current assets | 2 |  |  | 8 |  |  | — |  |  | 10 |  |
| Total assets | $ | 1,203 |  |  | $ | 876 |  |  | $ | — |  |  | $ | 2,079 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued expenses | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |
| Total liabilities | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-15-074539:notes:65]
[same as prior period, unchanged from 0001104659-15-032642:notes:71]

[0001104659-15-074539:notes:66]
[same as prior period, unchanged from 0001104659-15-032642:notes:72]

[0001104659-15-074539:notes:67]
[same as prior period, unchanged from 0001104659-15-032642:notes:73]

[0001104659-15-074539:notes:68]
[same as prior period, unchanged from 0001104659-15-032642:notes:74]

[0001104659-15-074539:notes:69]
[same as prior period, unchanged from 0001104659-15-032642:notes:75]

[0001104659-15-074539:notes:70]
[same as prior period, unchanged from 0001104659-15-032642:notes:76]

[0001104659-15-074539:notes:71]
[same as prior period, unchanged from 0001104659-15-032642:notes:77]

[0001104659-15-074539:notes:72]
[same as prior period, unchanged from 0001104659-15-032642:notes:78]

[0001104659-15-074539:notes:73]
[same as prior period, unchanged from 0001104659-15-032642:notes:79]

[0001104659-15-074539:notes:74]
[same as prior period, unchanged from 0001104659-15-032642:notes:80]

[0001104659-15-074539:notes:75]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of October 2, 2015:

[0001104659-15-074539:notes:76]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 241 |  |  | $ | — |  |  | $ | — |  |  | $ | 241 |  |
| Certificates of deposit | — |  |  | 223 |  |  | — |  |  | 223 |  |
| Corporate bonds | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total cash equivalents and short-term investments | 241 |  |  | 229 |  |  | — |  |  | 470 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |
| Money market funds | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Certificates of deposit | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Derivative assets | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets | $ | 243 |  |  | $ | 237 |  |  | $ | — |  |  | $ | 480 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |
| Total liabilities | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |

[0001104659-15-074539:notes:77]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of July 3, 2015:

[0001104659-15-074539:notes:78]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,201 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,201 |  |
| Certificates of deposit | — |  |  | 862 |  |  | — |  |  | 862 |  |
| Corporate bonds | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total cash equivalents and short-term investments | 1,201 |  |  | 868 |  |  | — |  |  | 2,069 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |
| Money market funds | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Certificates of deposit | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Derivative assets | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets | $ | 1,203 |  |  | $ | 876 |  |  | $ | — |  |  | $ | 2,079 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |
| Total liabilities | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |

[0001104659-15-074539:notes:79]
[same as prior period, unchanged from 0001104659-15-032642:notes:85]

[0001104659-15-074539:notes:80]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs.  The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities.  Level 2 assets include:  agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries and certificates of deposits. These debt investments are priced using observable inputs and valuation models which vary by asset class.  The Company uses a pricing service to assist in determining the fair values of all of its cash equivalents and short-term investments.  For the cash equivalents and short-term investments in the Company's portfolio, multiple pricing sources are generally available.  The pricing service uses inputs from multiple industry standard data providers or other third party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date.  The Company corroborates the prices obtained from the pricing service against other independent sources and, as of October 2, 2015, has not found it necessary to make any adjustments to the prices obtained.  The Company's derivative financial instruments are also classified within Level 2.  The Company's derivative financial instruments consist of foreign currency forward exchange contracts and the TRS.  The Company recognizes derivative financial instruments in its consolidated financial statements at fair value.  The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001104659-15-074539:notes:81]
As of October 2, 2015 and July 3, 2015, the Company had no Level 3 assets or liabilities measured at fair value on a recurring basis.

[0001104659-15-074539:notes:82]
Items Measured at Fair Value on a Non-Recurring Basis

[0001104659-15-074539:notes:83]
The Company enters into certain strategic investments for the achievement of business and strategic objectives. Strategic investments in equity securities where the Company does not have the ability to exercise significant influence over the investees, are included in Other assets, net in the Condensed Consolidated Balance Sheets, are recorded at cost and are periodically analyzed to determine whether or not there are indicators of impairment. The carrying value of the Company’s strategic investments at October 2, 2015 and July 3, 2015 totaled $110 million and $120 million, respectively, and consisted primarily of privately held equity securities without a readily determinable fair value.

[0001104659-15-074539:notes:84]
For the three months ended October 2, 2015, the Company determined that a certain equity investment accounted for under the cost method was other-than-temporarily impaired, and recognized a charge of $10 million in order to write down the carrying amount of the investment to zero.  This amount was recorded in Other, net in the Condensed Consolidated Statement of Operations. The Company did not record any material impairment charges in the three months ended October 3, 2014. Since there was no active market for the equity securities of the investee, the Company estimated fair value of the investee by analyzing the underlying cash flows and future prospects of the investee.

[0001104659-15-074539:notes:85]
[same as prior period, unchanged from 0001104659-15-032642:notes:88]

[0001104659-15-074539:notes:86]
[same as prior period, unchanged from 0001104659-15-032642:notes:89]

[0001104659-15-074539:notes:87]
|  |  | October 2, 2015 |  | July 3, 2015 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 800 |  |  | $ | 822 |  |  | $ | 800 |  |  | $ | 828 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 166 |  |  | 158 |  |  | 170 |  |
| 4.75% Senior Notes due June 2023 |  | 990 |  |  | 968 |  |  | 1,000 |  |  | 1,016 |  |
| 4.75% Senior Notes due January 2025 |  | 995 |  |  | 961 |  |  | 1,000 |  |  | 995 |  |
| 4.875% Senior Notes due June 2027 |  | 698 |  |  | 664 |  |  | 698 |  |  | 675 |  |
| 5.75% Senior Notes due December 2034 |  | 499 |  |  | 473 |  |  | 499 |  |  | 491 |  |
| Long-term debt |  | $ | 4,140 |  |  | $ | 4,054 |  |  | $ | 4,155 |  |  | $ | 4,175 |  |
| Less short-term borrowings and current portion of long-term debt |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 4,140 |  |  | $ | 4,054 |  |  | $ | 4,155 |  |  | $ | 4,175 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-15-074539:notes:88]
[same as prior period, unchanged from 0001104659-15-032642:notes:91]

[0001104659-15-074539:notes:89]
[same as prior period, unchanged from 0001104659-15-032642:notes:92]

[0001104659-15-074539:notes:90]
The changes in the carrying amount of goodwill for the three months ended October 2, 2015, are as follows:

[0001104659-15-074539:notes:91]
| (Dollars in millions) | Amount |
| Balance at July 3, 2015 | $ | 874 |  |
| Goodwill acquired | — |  |
| Foreign currency translation effect | — |  |
| Balance at October 2, 2015 | $ | 874 |  |

[0001104659-15-074539:notes:92]
[same as prior period, unchanged from 0001104659-15-032642:notes:95]

[0001104659-15-074539:notes:93]
Other intangible assets consist primarily of existing technology, customer relationships and trade names acquired in business combinations. Acquired intangibles are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization is charged to Operating expenses in the Condensed Consolidated Statements of Operations.

[0001104659-15-074539:notes:94]
The carrying value of other intangible assets subject to amortization as of October 2, 2015, is set forth in the following table:

[0001104659-15-074539:notes:95]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 147 |  |  | $ | (40 | ) |  | $ | 107 |  |  | 4.1 years |
| Customer relationships |  | 487 |  |  | (305 | ) |  | 182 |  |  | 2.2 years |
| Trade names |  | 27 |  |  | (9 | ) |  | 18 |  |  | 2.9 years |
| Other intangible assets |  | 28 |  |  | (6 | ) |  | 22 |  |  | 4.0 years |
| Total amortizable other intangible assets |  | $ | 689 |  |  | $ | (360 | ) |  | $ | 329 |  |  | 3.0 years |

[0001104659-15-074539:notes:96]
The carrying value of other intangible assets subject to amortization as of July 3, 2015 is set forth in the following table:

[0001104659-15-074539:notes:97]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 191 |  |  | $ | (69 | ) |  | $ | 122 |  |  | 4.1 years |
| Customer relationships |  | 487 |  |  | (282 | ) |  | 205 |  |  | 2.4 years |
| Trade names |  | 27 |  |  | (7 | ) |  | 20 |  |  | 3.2 years |
| Other intangible assets |  | 27 |  |  | (4 | ) |  | 23 |  |  | 4.2 years |
| Total amortizable other intangible assets |  | $ | 732 |  |  | $ | (362 | ) |  | $ | 370 |  |  | 3.1 years |

[0001104659-15-074539:notes:98]
For the three months ended October 2, 2015, amortization expense of other intangible assets was $41 million.  For the three months ended October 3, 2014, amortization expense of other intangible assets was $34 million.  As of October 2, 2015, expected amortization expense for other intangible assets for each of the next five fiscal years and thereafter is as follows:

[0001104659-15-074539:notes:99]
| (Dollars in millions) | Amount |
| Remainder of 2016 | $ | 100 |  |
| 2017 | 122 |  |
| 2018 | 64 |  |
| 2019 | 24 |  |
| 2020 | 7 |  |
| Thereafter | 12 |  |
|  | $ | 329 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-15-074539:notes:100]
[same as prior period, unchanged from 0001104659-15-032642:notes:105]

[0001104659-15-074539:notes:101]
The Company’s income tax benefit of $3 million in the three months ended October 2, 2015 included approximately $4 million of net discrete tax benefits primarily associated with the release of tax reserves associated with the expiration of certain statutes of limitation.

[0001104659-15-074539:notes:102]
The Company's income tax benefit recorded for the three months ended October 2, 2015 differed from the benefit from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets.

[0001104659-15-074539:notes:103]
During the three months ended October 2, 2015, the Company’s unrecognized tax benefits excluding interest and penalties decreased by approximately $4 million to $79 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $79 million at October 2, 2015, subject to certain future valuation allowance reversals. During the 12 months beginning October 3, 2015, the Company expects that its unrecognized tax benefits could be reduced by approximately $35 million primarily as a result of the expiration of certain statutes of limitation.

[0001104659-15-074539:notes:104]
The Company's income tax provision of $11 million in the three months ended October 3, 2014 included approximately $2 million net discrete tax benefits primarily associated with the release of tax reserves associated with the expiration of certain statutes of limitation.

[0001104659-15-074539:notes:105]
The Company’s income tax provision recorded for the three months ended October 3, 2014 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001104659-15-074539:notes:106]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 471 |  |  | $ | 471 |  |
| Due in 1 to 5 years |  | 6 |  |  | 6 |  |
| Thereafter |  | — |  |  | — |  |
| Total |  | $ | 477 |  |  | $ | 477 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001104659-15-074539:notes:107]
Legal, Environmental and Other Contingencies

[0001104659-15-074539:notes:108]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001104659-15-074539:notes:109]
Intellectual Property Litigation

[0001104659-15-074539:notes:110]
Convolve, Inc. ("Convolve") and Massachusetts Institute of Technology ("MIT") v. Seagate Technology LLC, et al. - On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent Nos. 4,916,635 (the "'635 patent") and U.S. Patent No. 5,638,267 (the "'267 patent"), misappropriation of trade secrets, breach of contract, and other claims. In the complaint, the plaintiffs requested injunctive relief, $800 million in compensatory damages and unspecified punitive damages, including for willful infringement. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe US Patent No. 6,314,473 (the "'473 patent"). The district court ruled in 2010 that the '267 patent was out of the case.

[0001104659-15-074539:notes:111]
On August 16, 2011, the district court granted in part and denied in part the Company's motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court's summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court's summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent. On July 11, 2014, the district court granted the Company's summary judgment motion regarding Convolve's only remaining cause of action, which alleged infringement of the '473 patent. The court entered judgment in favor of the Company on July 14, 2014. Convolve filed a notice of appeal on August 13, 2014. Oral argument at the court of appeals was held on October 6, 2015; the court has not yet issued its decision. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-15-074539:notes:112]
Alexander Shukh v. Seagate Technology - On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. On March 31, 2014, the district court granted Seagate's summary judgment motion and entered judgment in favor of Seagate. Mr. Shukh filed a notice of appeal on April 7, 2014. On October 2, 2015, the court of appeals vacated and remanded the district court’s grant of summary judgment on Mr. Shukh’s claim for correction of inventorship and affirmed the district court’s grant of summary judgment as to all other claims. On October 29, 2015, Mr. Shukh filed a petition for rehearing en banc with the court of appeals. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-15-074539:notes:113]
LEAP Co., Ltd. v. Seagate Singapore International Headquarters Pte. Ltd. and Nippon Seagate Inc. - On July 4, 2012, LEAP Co., Ltd. filed a lawsuit in the Tokyo District Court of Japan against Seagate Singapore International Headquarters Pte. Ltd., Nippon Seagate Inc. and Buffalo Inc. alleging wrongful termination of purchase agreements and other claims, and seeking approximately $38 million in damages. The Company believes the claims are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-15-074539:notes:114]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995, "Cryptographic Device," and U.S. Patent No. 7,900,057, "Cryptographic Serial ATA Apparatus and Method." The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys' fees, and other relief. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the '995 and '057 Patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. The Company believes the claims are without merit and intends to vigorously defend this case. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 Patent are held unpatentable. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-15-074539:notes:115]
Seagate Technology LLC v. Western Digital Corp.  On October 8, 2014, the Minnesota Supreme Court ruled that the arbitration award in favor of the Company in its case against Western Digital for the misappropriation of the Company’s trade secrets should be confirmed. In the arbitration award, issued on January 23, 2012, the arbitrator determined that Western Digital and its former employee had misappropriated the Company’s trade secrets. The arbitrator awarded the Company $525 million in compensatory damages and, after adding interest, issued a final award of $630 million. Interest on the final award has been accruing at 10%. On October 14, 2014, the Company received a partial payment from Western Digital in the amount of $773 million. During the quarter ended January 2, 2015, the amount of the final award, less litigation and other related costs, was recorded by the Company in Gain on arbitration award, net, and the remaining amount received was recorded in Other, net.

[0001104659-15-074539:notes:116]
Environmental Matters

[0001104659-15-074539:notes:117]
The Company's operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company's operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001104659-15-074539:notes:118]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001104659-15-074539:notes:119]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the "Superfund" law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001104659-15-074539:notes:120]
While the Company's ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001104659-15-074539:notes:121]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union ("EU") enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern ("SVHCs") in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.

[0001104659-15-074539:notes:122]
Other Matters

[0001104659-15-074539:notes:123]
The Company is involved in a number of other judicial and administrative proceedings incidental to its business, and the Company may be involved in various legal proceedings arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001104659-15-074539:notes:124]
May 2014 and August 2015, the FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers and ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, respectively. The ASU outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The amendments in this ASU are effective for fiscal years, and interim periods within those years, beginning after December 15, 2017. Early adoption is permitted for annual periods beginning after December 15, 2016. The Company is in the process of assessing the impact, if any, on its consolidated financial statements.

[0001104659-15-074539:notes:125]
In April 2015 and August 2015, the FASB issued ASU 2015-03 (ASC Subtopic 835-30), Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs and ASU 2015-15 (ASC Subtopic 835-30), Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements- Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting, respectively. The ASUs require that debt issuance costs related to a recognized debt liability, with the exception of those related to line-of-credit arrangements, be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability. The amendments in these ASUs are effective for fiscal years, and interim periods within those years, beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued. The adoption of this new guidance is not expected to have a material impact on the Company’s consolidated financial statements and disclosures.

[0001104659-15-074539:notes:126]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. The amendments in this ASU are effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company is in the process of assessing the impact, if any, on its consolidated financial statements.

[0001104659-15-074539:notes:127]
In August 2015, the FASB issued ASU 2015-13 (ASC Topic 815), Application of the Normal Purchases and Normal Sales Scope Exception to Certain Electricity Contracts within Nodal Energy Markets. ASC 815, Derivatives and Hedging, requires that a derivative contract be recognized at fair value unless the contract qualifies for a scope exception. The amendments in this update specify that electricity contracts for the use of locational marginal pricing by an independent system operator that necessitate transmission through a nodal energy market qualify for the normal purchases and normal sales scope exception. The amendments in this ASU are effective upon issuance and applied prospectively. The adoption of this new guidance is not expected to have a material impact on the Company’s consolidated financial statements and disclosures.

[0001104659-15-074539:notes:128]
In September 2015, the FASB issued ASU 2015-16 (ASC Topic 805), Business Combinations Simplifying the Accounting for Measurement-Period Adjustments. The amendments in this update require that an acquirer recognize measurement period adjustments in the period in which the adjustments are determined. The income effects of such measurement period adjustments are to be recorded in the same period’s financial statements but calculated as if the accounting had been completed as of the acquisition date. The impact of measurement period adjustments to earnings that relate to prior period financial statements are to be presented separately on the income statement or disclosed by line item. The amendments in this Update are for fiscal years, including interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted for public business entities for reporting periods for which financial statements have not yet been issued. The adoption of this new guidance is not expected to have a material impact on the Company’s consolidated financial statements and disclosures.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001104659-15-074539:notes:129]
[same as prior period, unchanged from 0001104659-15-032642:notes:135]

[0001104659-15-074539:notes:130]
[same as prior period, unchanged from 0001104659-15-032642:notes:136]

[0001104659-15-074539:notes:131]
Seagate Technology plc (the "Company") is a leading provider of electronic data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, it produces a broad range of electronic data storage products including solid state hybrid drives ("SSHD"), solid state drives ("SSD"), PCIe cards and SATA controllers. Its storage technology portfolio also includes storage subsystems, high performance computing (HPC) solutions, and data storage services.

[0001104659-15-074539:notes:132]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and most SSDs use NAND-based flash memory. In addition to HDDs and SSDs, Solid-state hybrid drives (SSHDs) combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed data.

[0001104659-15-074539:notes:133]
The Company's products are designed for enterprise servers and storage systems in mission critical and nearline applications; client compute applications, where its products are designed primarily for desktop and mobile computing; and client non-compute applications, where its products are designed for a wide variety of end user devices such as digital video recorders ("DVRs"), personal data backup systems, portable external storage systems, digital media systems and surveillance systems.

[0001104659-15-074539:notes:134]
The Company's product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and high performance computing ("HPC") data storage solutions. Its storage subsystems support a range of high-speed interconnect technologies to meet demanding cost and performance specifications. Its modular subsystem architecture allows it to support many segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.

[0001104659-15-074539:notes:135]
The Company's data storage services provide online backup, data protection and recovery solutions for small to medium-sized businesses.

[0001104659-15-074539:notes:136]
The results of operations for the three months ended October 2, 2015, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending July 1, 2016. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three months ended October 2, 2015 consisted of 13 weeks. The three months ended October 3, 2014 consisted of 14 weeks.  Fiscal year 2016 will be comprised of 52 weeks and will end on July 1, 2016. The fiscal quarters ended October 2, 2015, July 3, 2015, and October 3, 2014, are also referred to herein as the “September 2015 quarter”, the “June 2015 quarter”, and the “September 2014 quarter”, respectively.

[0001104659-15-074539:notes:137]
[same as prior period, unchanged from 0001104659-15-032642:notes:142]

[0001104659-15-074539:notes:138]
There have been no significant changes in the Company's significant accounting policies. Please refer to Note 1 of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended July 3, 2015, as filed with the SEC on August 11, 2015 for a discussion of the Company’s other significant accounting policies.

[0001104659-15-074539:notes:139]
Recently Issued Accounting Pronouncements

[0001104659-15-074539:notes:140]
In May 2014 and August 2015, the FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers and ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, respectively. The ASU outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The amendments in this ASU are effective for fiscal years, and interim periods within those years, beginning after December 15, 2017. Early adoption is permitted for annual periods beginning after December 15, 2016. The Company is in the process of assessing the impact, if any, on its consolidated financial statements.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001104659-15-074539:notes:141]
12. Guarantees

[0001104659-15-074539:notes:142]
[same as prior period, unchanged from 0001104659-15-032642:notes:147]

[0001104659-15-074539:notes:143]
[same as prior period, unchanged from 0001104659-15-032642:notes:148]

[0001104659-15-074539:notes:144]
[same as prior period, unchanged from 0001104659-15-032642:notes:149]

[0001104659-15-074539:notes:145]
[same as prior period, unchanged from 0001104659-15-032642:notes:150]

[0001104659-15-074539:notes:146]
[same as prior period, unchanged from 0001104659-15-032642:notes:151]

[0001104659-15-074539:notes:147]
[same as prior period, unchanged from 0001104659-15-032642:notes:152]

[0001104659-15-074539:notes:148]
[same as prior period, unchanged from 0001104659-15-032642:notes:153]

[0001104659-15-074539:notes:149]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5  years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the three months ended October 2, 2015 and October 3, 2014 were as follows:

[0001104659-15-074539:notes:150]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 2, 2015 |  | October 3, 2014 |
| Balance, beginning of period |  | $ | 248 |  |  | $ | 273 |  |
| Warranties issued |  | 33 |  |  | 40 |  |
| Repairs and replacements |  | (41 | ) |  | (54 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | (15 | ) |  | 6 |  |
| Warranty liability assumed from business acquisitions |  | — |  |  | 8 |  |
| Balance, end of period |  | $ | 225 |  |  | $ | 273 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001104659-15-074539:notes:151]
| (Dollars in millions) |  | October 2, 2015 |  | July 3, 2015 |
| Property, equipment and leasehold improvements |  | $ | 9,746 |  |  | $ | 9,630 |  |
| Accumulated depreciation and amortization |  | (7,499 | ) |  | (7,352 | ) |
|  |  | $ | 2,247 |  |  | $ | 2,278 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001104659-15-074539:notes:152]
7.   Restructuring and Exit Costs

[0001104659-15-074539:notes:153]
September 2015 Plan -  On September 4, 2015, the Company committed to a restructuring plan (the “September 2015 Plan”) intended to realign its cost structure with the current macroeconomic business environment. The September 2015 Plan included reducing worldwide headcount by approximately 1,000 employees. The September 2015 Plan is expected to be largely complete by the fiscal quarter ending January 1, 2016.  During the three months ended October 2, 2015, the Company recorded total restructuring charges of approximately $59 million related to employee termination costs for the September 2015 Plan.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001104659-15-074539:notes:154]
| (Dollars in millions) |  | Unrealized Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Marketable Securities (a) |  | Unrealized Gains (Losses) on post-retirement plans |  | Foreign currency translation adjustments |  | Total |
| Balance at July 3, 2015 |  | $ | 1 |  |  | $ | — |  |  | $ | (15 | ) |  | $ | (16 | ) |  | $ | (30 | ) |
| Other comprehensive income (loss) before reclassifications |  | (2 | ) |  | — |  |  | 1 |  |  | — |  |  | (1 | ) |
| Amounts reclassified from AOCI |  | 1 |  |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Other comprehensive income (loss) |  | (1 | ) |  | — |  |  | 1 |  |  | — |  |  | — |  |
| Balance at October 2, 2015 |  | $ | — |  |  | $ | — |  |  | $ | (14 | ) |  | $ | (16 | ) |  | $ | (30 | ) |
| Balance at June 27, 2014 |  | $ | (1 | ) |  | $ | — |  |  | $ | (10 | ) |  | $ | 9 |  |  | $ | (2 | ) |
| Other comprehensive income (loss) before reclassifications |  | (3 | ) |  | — |  |  | — |  |  | (10 | ) |  | (13 | ) |
| Amounts reclassified from AOCI |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) |  | (3 | ) |  | — |  |  | — |  |  | (10 | ) |  | (13 | ) |
| Balance at October 3, 2014 |  | $ | (4 | ) |  | $ | — |  |  | $ | (10 | ) |  | $ | (1 | ) |  | $ | (15 | ) |

[0001104659-15-074539:notes:155]
[same as prior period, unchanged from 0001104659-15-032642:notes:158]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001104659-15-074539:notes:156]
| (Dollars in millions) |  | October 2, 2015 |  | July 3, 2015 |
| Raw materials and components |  | $ | 318 |  |  | $ | 352 |  |
| Work-in-process |  | 315 |  |  | 239 |  |
| Finished goods |  | 465 |  |  | 402 |  |
|  |  | $ | 1,098 |  |  | $ | 993 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-15-074539:notes:157]
[same as prior period, unchanged from 0001104659-15-032642:notes:160]

[0001104659-15-074539:notes:158]
[same as prior period, unchanged from 0001104659-15-032642:notes:161]

[0001104659-15-074539:notes:159]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 298,985,219 shares were outstanding as of October 2, 2015, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of October 2, 2015.

[0001104659-15-074539:notes:160]
[same as prior period, unchanged from 0001104659-15-032642:notes:163]

[0001104659-15-074539:notes:161]
[same as prior period, unchanged from 0001104659-15-032642:notes:164]

[0001104659-15-074539:notes:162]
[same as prior period, unchanged from 0001104659-15-032642:notes:165]

[0001104659-15-074539:notes:163]
[same as prior period, unchanged from 0001104659-15-032642:notes:166]

[0001104659-15-074539:notes:164]
On July 24, 2013, the Board of Directors authorized the Company to repurchase $2.5 billion of its outstanding ordinary shares.

[0001104659-15-074539:notes:165]
On April 22, 2015, the Board of Directors authorized the Company to repurchase an additional $2.0 billion of its outstanding ordinary shares.

[0001104659-15-074539:notes:166]
[same as prior period, unchanged from 0001104659-15-032642:notes:168]

[0001104659-15-074539:notes:167]
As of October 2, 2015, $1.9 billion remained available for repurchase under the existing repurchase authorization limit.

[0001104659-15-074539:notes:168]
The following table sets forth information with respect to repurchases of the Company’s shares during the three months ended October 2, 2015:


## us-gaap:SubsequentEventsTextBlock

[0001104659-15-074539:notes:169]
Subsequent Event

[0001104659-15-074539:notes:170]
On October 6, 2015, the Company acquired all of the outstanding shares of Dot Hill Systems Corp. ("Dot Hill"), a supplier of software and hardware storage systems. The Company paid $9.75 per share or approximately $696 million in cash for the acquisition. The acquisition of Dot Hill further expands the Company's OEM-focused cloud storage systems business and advances the Company's strategic efforts. Because the initial accounting for the acquisition was incomplete at the time this Form 10-Q was filed with the Securities and Exchange Commission, certain disclosures required by ASC Topic 805 — Business Combinations have not been made herein.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001104659-15-074539:notes:171]
[same as prior period, unchanged from 0001104659-15-032642:notes:171]

[0001104659-15-074539:notes:172]
[same as prior period, unchanged from 0001104659-15-032642:notes:172]

[0001104659-15-074539:notes:173]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of October 2, 2015:

[0001104659-15-074539:notes:174]
As of October 2, 2015, the Company’s Other current assets included $7 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001104659-15-074539:notes:175]
As of October 2, 2015, the Company had no material available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined that no available-for-sale securities were other-than-temporarily impaired as of October 2, 2015.

[0001104659-15-074539:notes:176]
The fair value and amortized cost of the Company’s investments classified as available-for-sale at October 2, 2015, by remaining contractual maturity were as follows:

[0001104659-15-074539:notes:177]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of July 3, 2015:

[0001104659-15-074539:notes:178]
As of July 3, 2015, the Company’s Other current assets included $7 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001104659-15-074539:notes:179]
As of July 3, 2015, the Company had no material available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale securities were other-than-temporarily impaired as of July 3, 2015.

[0001104659-15-074539:notes:180]
[same as prior period, unchanged from 0001104659-15-032642:notes:179]

[0001104659-15-074539:notes:181]
[same as prior period, unchanged from 0001104659-15-032642:notes:180]

[0001104659-15-074539:notes:182]
[same as prior period, unchanged from 0001104659-15-032642:notes:181]

[0001104659-15-074539:notes:183]
[same as prior period, unchanged from 0001104659-15-032642:notes:182]

[0001104659-15-074539:notes:184]
[same as prior period, unchanged from 0001104659-15-032642:notes:183]

[0001104659-15-074539:notes:185]
[same as prior period, unchanged from 0001104659-15-032642:notes:184]
