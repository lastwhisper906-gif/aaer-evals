# STX note change history — 0001104659-15-032642 → 0001104659-15-074539


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-10-30):
[0001104659-15-074539:note_history:1]
Convolve, Inc. ("Convolve") and Massachusetts Institute of Technology ("MIT") v. Seagate Technology LLC, et al. - On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent Nos. 4,916,635 (the "'635 patent") and U.S. Patent No. 5,638,267 (the "'267 patent"), misappropriation of trade secrets, breach of contract, and other claims. In the complaint, the plaintiffs requested injunctive relief, $800 million in compensatory damages and unspecified punitive damages, including for willful infringement. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe US Patent No. 6,314,473 (the "'473 patent"). The district court ruled in 2010 that the '267 patent was out of the case.
  (was, 2015-04-30, similarity 0.9716):
[0001104659-15-032642:note_history:1]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al.—On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent Nos. 4,916,635 (the “'635 patent”) and U.S. Patent No. 5,638,267 (the “'267 patent”), misappropriation of trade secrets, breach of contract, and other claims. In the complaint, the plaintiffs requested injunctive relief, $800 million in compensatory damages and unspecified punitive damages, including for willful infringement. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe US Patent No. 6,314,473 (the “'473 patent”). The district court ruled in 2010 that the '267 patent was out of the case.

- changed (2015-10-30):
[0001104659-15-074539:note_history:2]
On August 16, 2011, the district court granted in part and denied in part the Company's motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court's summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court's summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent. On July 11, 2014, the district court granted the Company's summary judgment motion regarding Convolve's only remaining cause of action, which alleged infringement of the '473 patent. The court entered judgment in favor of the Company on July 14, 2014. Convolve filed a notice of appeal on August 13, 2014. Oral argument at the court of appeals was held on October 6, 2015; the court has not yet issued its decision. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2015-04-30, similarity 0.6659):
[0001104659-15-032642:note_history:2]
On August 16, 2011, the district court granted in part and denied in part the Company's motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court's summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court's summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent. On July 11, 2014, the district court granted the Company’s summary judgment motion regarding Convolve’s only remaining cause of action, which alleged infringement of the ‘473 patent. The court entered judgment in favor of the Company on July 14, 2014. Convolve filed a notice of appeal on August 13, 2014. The court of appeals has not yet set a date for oral argument. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- changed (2015-10-30):
[0001104659-15-074539:note_history:3]
Alexander Shukh v. Seagate Technology - On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. On March 31, 2014, the district court granted Seagate's summary judgment motion and entered judgment in favor of Seagate. Mr. Shukh filed a notice of appeal on April 7, 2014. On October 2, 2015, the court of appeals vacated and remanded the district court’s grant of summary judgment on Mr. Shukh’s claim for correction of inventorship and affirmed the district court’s grant of summary judgment as to all other claims. On October 29, 2015, Mr. Shukh filed a petition for rehearing en banc with the court of appeals. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2015-04-30, similarity 0.6012):
[0001104659-15-032642:note_history:3]
Alexander Shukh v. Seagate Technology—On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. On March 31, 2014, the district court granted Seagate’s summary judgment motion and entered judgment in favor of Seagate. Mr. Shukh filed a notice of appeal on April 7, 2014. Oral argument at the court of appeals has been scheduled for June 4, 2015. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- changed (2015-10-30):
[0001104659-15-074539:note_history:4]
LEAP Co., Ltd. v. Seagate Singapore International Headquarters Pte. Ltd. and Nippon Seagate Inc. - On July 4, 2012, LEAP Co., Ltd. filed a lawsuit in the Tokyo District Court of Japan against Seagate Singapore International Headquarters Pte. Ltd., Nippon Seagate Inc. and Buffalo Inc. alleging wrongful termination of purchase agreements and other claims, and seeking approximately $38 million in damages. The Company believes the claims are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2015-04-30, similarity 0.9458):
[0001104659-15-032642:note_history:4]
LEAP Co., Ltd. v. Seagate Singapore International Headquarters Pte. Ltd. and Nippon Seagate Inc.—On July 4, 2012, LEAP Co., Ltd. filed a lawsuit in the Tokyo District Court of Japan against Seagate Singapore International Headquarters Pte. Ltd., Nippon Seagate Inc. and Buffalo Inc. alleging wrongful termination of purchase agreements and other claims, and seeking approximately $38 million in damages. A date for the start of trial has not yet been scheduled. The Company believes the claims are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- changed (2015-10-30):
[0001104659-15-074539:note_history:5]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995, "Cryptographic Device," and U.S. Patent No. 7,900,057, "Cryptographic Serial ATA Apparatus and Method." The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys' fees, and other relief. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the '995 and '057 Patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. The Company believes the claims are without merit and intends to vigorously defend this case. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 Patent are held unpatentable. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2015-04-30, similarity 0.6667):
[0001104659-15-032642:note_history:5]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995, “Cryptographic Device,” and U.S. Patent No. 7,900,057, “Cryptographic Serial ATA Apparatus and Method.” The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys' fees, and other relief. The trial is scheduled to begin July 11, 2016. On April 27, 2015, the district court ordered a stay of the case until October 15, 2015, in view of proceedings regarding the ‘995 and ‘057 Patents before the Patent Trial and Appeal Board of the U.S. Patent and Trademark Office. The Company believes the claims are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- changed (2015-10-30):
[0001104659-15-074539:note_history:6]
Seagate Technology LLC v. Western Digital Corp.  On October 8, 2014, the Minnesota Supreme Court ruled that the arbitration award in favor of the Company in its case against Western Digital for the misappropriation of the Company’s trade secrets should be confirmed. In the arbitration award, issued on January 23, 2012, the arbitrator determined that Western Digital and its former employee had misappropriated the Company’s trade secrets. The arbitrator awarded the Company $525 million in compensatory damages and, after adding interest, issued a final award of $630 million. Interest on the final award has been accruing at 10%. On October 14, 2014, the Company received a partial payment from Western Digital in the amount of $773 million. During the quarter ended January 2, 2015, the amount of the final award, less litigation and other related costs, was recorded by the Company in Gain on arbitration award, net, and the remaining amount received was recorded in Other, net.
  (was, 2015-04-30, similarity 0.9686):
[0001104659-15-032642:note_history:6]
Seagate Technology LLC v. Western Digital Corp.  On October 8, 2014, the Minnesota Supreme Court ruled that the arbitration award in favor of the Company in its case against Western Digital for the misappropriation of the Company’s trade secrets should be confirmed. In the arbitration award, issued on January 23, 2012, the arbitrator determined that Western Digital and its former employee had misappropriated the Company’s trade secrets. The arbitrator awarded the Company $525 million in compensatory damages and, after adding interest, issued a final award of $630 million. Interest on the final award has been accruing at 10%. On October 14, 2014, the Company received a partial payment from Western Digital in the amount of $773 million. The amount of the final award, less litigation and other related costs, has been recorded by the Company in Gain on arbitration award, net, and the remaining amount received has been recorded in Other, net.

- changed (2015-10-30):
[0001104659-15-074539:note_history:7]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the "Superfund" law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.
  (was, 2015-04-30, similarity 0.9882):
[0001104659-15-032642:note_history:7]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

- changed (2015-10-30):
[0001104659-15-074539:note_history:8]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union ("EU") enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern ("SVHCs") in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.
  (was, 2015-04-30, similarity 0.9899):
[0001104659-15-032642:note_history:8]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.

- removed (2015-10-30):
[0001104659-15-032642:note_history:9]
Realtek Semiconductor Corporation ITC Investigation re Certain Integrated Circuit Chips and Products Containing the Same-On September 19, 2012, Realtek Semiconductor Corporation filed a complaint with the International Trade Commission (“ITC”) seeking an investigation pursuant to Section 337 of the Tariff Act of 1930, as amended (“Section 337”). The complaint names LSI Corporation and Seagate Technology as respondents and alleges infringement of U.S. patents relating to integrated circuit chips that include bond pad structures. Realtek seeks an order to exclude entry of infringing integrated circuit chips and products containing the infringing integrated circuit chips into the U.S. and a cease and desist order. The ITC initiated an investigation on October 18, 2012. On March 21, 2014, the Administrative Law Judge (“ALJ”) issued an Initial Determination in favor of Seagate and LSI. On July 21, 2014, the Commission gave notice that it had determined to affirm in part, reverse in part and vacate in part the ALJ’s Initial Determination; the Commission found that no violation of Section 337 by Seagate or LSI has occurred based on findings that certain of the patent claims at issue were invalid, and that Realtek failed to show the existence of an industry in the U.S. that exploits the patent. Realtek filed a notice of appeal on September 18, 2014. By agreement of the parties, Realtek’s appeal was dismissed on October 17, 2014. In view of the Commission’s July 21, 2014 decision and the October 17, 2014 dismissal of Realtek’s appeal, the Company believes that this matter will not result in any loss or other adverse result.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2015-10-30):
[0001104659-15-074539:note_history:10]
Seagate Technology plc (the "Company") is a leading provider of electronic data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, it produces a broad range of electronic data storage products including solid state hybrid drives ("SSHD"), solid state drives ("SSD"), PCIe cards and SATA controllers. Its storage technology portfolio also includes storage subsystems, high performance computing (HPC) solutions, and data storage services.

- added (2015-10-30):
[0001104659-15-074539:note_history:11]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and most SSDs use NAND-based flash memory. In addition to HDDs and SSDs, Solid-state hybrid drives (SSHDs) combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed data.

- changed (2015-10-30):
[0001104659-15-074539:note_history:12]
The Company's products are designed for enterprise servers and storage systems in mission critical and nearline applications; client compute applications, where its products are designed primarily for desktop and mobile computing; and client non-compute applications, where its products are designed for a wide variety of end user devices such as digital video recorders ("DVRs"), personal data backup systems, portable external storage systems, digital media systems and surveillance systems.
  (was, 2015-04-30, similarity 0.9357):
[0001104659-15-032642:note_history:12]
The Company's products are designed for enterprise servers and storage systems in mission critical and nearline applications; client compute applications, where its products are designed primarily for desktop and mobile computing; and client non-compute applications, where its products are designed for a wide variety of end user devices such as digital video recorders (“DVRs”), personal data backup systems, portable external storage systems and digital media systems.

- changed (2015-10-30):
[0001104659-15-074539:note_history:13]
The Company's product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and high performance computing ("HPC") data storage solutions. Its storage subsystems support a range of high-speed interconnect technologies to meet demanding cost and performance specifications. Its modular subsystem architecture allows it to support many segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.
  (was, 2015-04-30, similarity 0.838):
[0001104659-15-032642:note_history:13]
The Company continues to make strategic investments in order to expand its storage solutions, enter new market adjacencies, and expand its technical expertise. As a result of recent acquisitions, the Company's product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and high performance computing ("HPC") data storage solutions. The Company's storage subsystems supports a range of high-speed interconnect technologies to meet demanding cost and performance specifications. The Company's modular subsystem architecture allows it to support many segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.

- added (2015-10-30):
[0001104659-15-074539:note_history:14]
The Company's data storage services provide online backup, data protection and recovery solutions for small to medium-sized businesses.

- changed (2015-10-30):
[0001104659-15-074539:note_history:15]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income, cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature. Certain prior period amounts in the condensed consolidated financial statements and notes to the condensed consolidated financial statements have been reclassified to conform to the current period’s presentation.
  (was, 2015-04-30, similarity 0.8946):
[0001104659-15-032642:note_history:15]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income, cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature.

- changed (2015-10-30):
[0001104659-15-074539:note_history:16]
The Company’s Consolidated Financial Statements for the fiscal year ended July 3, 2015, are included in its Annual Report on Form 10-K as filed with the United States Securities and Exchange Commission (“SEC”) on August 11, 2015. The Company believes that the disclosures included in the unaudited condensed consolidated financial statements, when read in conjunction with its Consolidated Financial Statements as of July 3, 2015, and the notes thereto, are adequate to make the information presented not misleading.
  (was, 2015-04-30, similarity 0.992):
[0001104659-15-032642:note_history:16]
The Company’s Consolidated Financial Statements for the fiscal year ended June 27, 2014, are included in its Annual Report on Form 10-K as filed with the United States Securities and Exchange Commission (“SEC”) on August 7, 2014. The Company believes that the disclosures included in the unaudited condensed consolidated financial statements, when read in conjunction with its Consolidated Financial Statements as of June 27, 2014, and the notes thereto, are adequate to make the information presented not misleading.

- added (2015-10-30):
[0001104659-15-074539:note_history:17]
The results of operations for the three months ended October 2, 2015, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending July 1, 2016. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three months ended October 2, 2015 consisted of 13 weeks. The three months ended October 3, 2014 consisted of 14 weeks.  Fiscal year 2016 will be comprised of 52 weeks and will end on July 1, 2016. The fiscal quarters ended October 2, 2015, July 3, 2015, and October 3, 2014, are also referred to herein as the “September 2015 quarter”, the “June 2015 quarter”, and the “September 2014 quarter”, respectively.

- changed (2015-10-30):
[0001104659-15-074539:note_history:18]
There have been no significant changes in the Company's significant accounting policies. Please refer to Note 1 of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended July 3, 2015, as filed with the SEC on August 11, 2015 for a discussion of the Company’s other significant accounting policies.
  (was, 2015-04-30, similarity 0.973):
[0001104659-15-032642:note_history:18]
There have been no significant changes in our significant accounting policies. Please refer to Note 1 of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended June 27, 2014, as filed with the SEC on August 7, 2014 for a discussion of the Company’s other significant accounting policies.

- added (2015-10-30):
[0001104659-15-074539:note_history:19]
In May 2014 and August 2015, the FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers and ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, respectively. The ASU outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The amendments in this ASU are effective for fiscal years, and interim periods within those years, beginning after December 15, 2017. Early adoption is permitted for annual periods beginning after December 15, 2016. The Company is in the process of assessing the impact, if any, on its consolidated financial statements.

- added (2015-10-30):
[0001104659-15-074539:note_history:20]
In April 2015 and August 2015, the FASB issued ASU 2015-03 (ASC Subtopic 835-30), Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs and ASU 2015-15 (ASC Subtopic 835-30), Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements- Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting, respectively. The ASUs require that debt issuance costs related to a recognized debt liability, with the exception of those related to line-of-credit arrangements, be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability. The amendments in these ASUs are effective for fiscal years, and interim periods within those years, beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued. The adoption of this new guidance is not expected to have a material impact on the Company’s consolidated financial statements and disclosures.

- added (2015-10-30):
[0001104659-15-074539:note_history:21]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. The amendments in this ASU are effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company is in the process of assessing the impact, if any, on its consolidated financial statements.

- added (2015-10-30):
[0001104659-15-074539:note_history:22]
In August 2015, the FASB issued ASU 2015-13 (ASC Topic 815), Application of the Normal Purchases and Normal Sales Scope Exception to Certain Electricity Contracts within Nodal Energy Markets. ASC 815, Derivatives and Hedging, requires that a derivative contract be recognized at fair value unless the contract qualifies for a scope exception. The amendments in this update specify that electricity contracts for the use of locational marginal pricing by an independent system operator that necessitate transmission through a nodal energy market qualify for the normal purchases and normal sales scope exception. The amendments in this ASU are effective upon issuance and applied prospectively. The adoption of this new guidance is not expected to have a material impact on the Company’s consolidated financial statements and disclosures.

- added (2015-10-30):
[0001104659-15-074539:note_history:23]
In September 2015, the FASB issued ASU 2015-16 (ASC Topic 805), Business Combinations Simplifying the Accounting for Measurement-Period Adjustments. The amendments in this update require that an acquirer recognize measurement period adjustments in the period in which the adjustments are determined. The income effects of such measurement period adjustments are to be recorded in the same period’s financial statements but calculated as if the accounting had been completed as of the acquisition date. The impact of measurement period adjustments to earnings that relate to prior period financial statements are to be presented separately on the income statement or disclosed by line item. The amendments in this Update are for fiscal years, including interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted for public business entities for reporting periods for which financial statements have not yet been issued. The adoption of this new guidance is not expected to have a material impact on the Company’s consolidated financial statements and disclosures.

- removed (2015-10-30):
[0001104659-15-032642:note_history:24]
The Company is a leading provider of electronic data storage solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives are used as the primary medium for storing electronic data. In addition to HDDs, we produce a broad range of electronic data storage products including solid state hybrid drives (“SSHD”) and solid state drives (“SSD”).

- removed (2015-10-30):
[0001104659-15-032642:note_history:25]
In addition to manufacturing and selling data storage products, the Company provides data storage services for small to medium-sized businesses, including online backup, data protection and recovery solutions.

- removed (2015-10-30):
[0001104659-15-032642:note_history:26]
The results of operations for the three and nine months ended April 3, 2015, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending July 3, 2015. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three and nine months ended April 3, 2015 consisted of 13 weeks and 40 weeks, respectively. The three and nine months ended March 28, 2014 consisted of 13 weeks and 39 weeks, respectively.  Fiscal year 2015 will be comprised of 53 weeks and will end on July 3, 2015. The fiscal quarters ended April 3, 2015, January 2, 2015, and March 28, 2014, are also referred to herein as the “March 2015 quarter”, the “December 2014 quarter”, and the “March 2014 quarter”, respectively.

- removed (2015-10-30):
[0001104659-15-032642:note_history:27]
In May 2014, the FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers. The ASU outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The ASU, as currently proposed, will be effective for the Company's first quarter of fiscal year 2019. The Company is in the process of assessing the impact, if any, of ASU 2014-09 on its consolidated financial statements.

- removed (2015-10-30):
[0001104659-15-032642:note_history:28]
In April 2015, the FASB issued ASU 2015-03 (ASC Subtopic 835-30), Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs. The amendments in this ASU require that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability. The amendments in this ASU are effective for fiscal years, and interim periods within those years, beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued. The adoption of this new guidance will not have a material impact on the Company’s consolidated financial statements and disclosures.

- removed (2015-10-30):
[0001104659-15-032642:note_history:29]
8


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-10-30):
[0001104659-15-074539:note_history:30]
The Company and its subsidiary Seagate HDD Cayman have entered into a Credit Agreement providing the Company with a $700 million senior secured revolving credit facility (the "Revolving Credit Facility"). On January 15, 2015, pursuant to the Third Amendment to the Credit Agreement, the commitments available under the Revolving Credit Facility were increased from $500 million to $700 million and the maturity date was extended until January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Credit Agreement) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. This Credit Agreement that was originally entered into by the Company and Seagate HDD Cayman on January 18, 2011 was subsequently amended with the Second Amendment to the Credit Agreement on April 30, 2013, which increased the commitments available under the Revolving Credit Facility from $350 million to $500 million. The loans made under the Credit Agreement will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings and for the issuance of letters of credit up to a sub-limit of $75 million. As of October 2, 2015, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

- changed (2015-10-30):
[0001104659-15-074539:note_history:31]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman, and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2015 quarter, the Company repurchased $0.5 million aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The loss recorded on the repurchase was immaterial, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.
  (was, 2015-04-30, similarity 0.6762):
[0001104659-15-032642:note_history:31]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman, and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2015-10-30):
[0001104659-15-074539:note_history:32]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2015 quarter, the Company repurchased $10 million aggregate principal amount of its 2023 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The loss recorded on the repurchase was immaterial, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.
  (was, 2015-04-30, similarity 0.6737):
[0001104659-15-032642:note_history:32]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- added (2015-10-30):
[0001104659-15-074539:note_history:33]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2015 quarter, the Company repurchased $5 million aggregate principal amount of its 2025 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The gain recorded on the repurchase was immaterial, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

- changed (2015-10-30):
[0001104659-15-074539:note_history:34]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on December 1, 2015. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2015-04-30, similarity 0.8743):
[0001104659-15-032642:note_history:34]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year, which commenced on January 1, 2015. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- added (2015-10-30):
[0001104659-15-074539:note_history:35]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2015-10-30):
[0001104659-15-074539:note_history:36]
At October 2, 2015, future principal payments on long-term debt were as follows (in millions):
  (was, 2015-04-30, similarity 0.9432):
[0001104659-15-032642:note_history:36]
At April 3, 2015, future principal payments on long-term debt were as follows (in millions):

- changed (2015-10-30):
[0001104659-15-074539:note_history:37]
| Fiscal Year | Amount |
| Remainder of 2016 | $ | — |  |
| 2017 | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| 2020 | — |  |
| Thereafter | 3,343 |  |
|  | $ | 4,143 |  |
  (was, 2015-04-30, similarity 0.9118):
[0001104659-15-032642:note_history:37]
| Fiscal Year | Amount |
| Remainder of 2015 | $ | 474 |  |
| 2016 | — |  |
| 2017 | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| Thereafter | 2,659 |  |
|  | $ | 3,933 |  |

- removed (2015-10-30):
[0001104659-15-032642:note_history:38]
On January 15, 2015, the Company and its subsidiary, Seagate HDD Cayman, entered into the Third Amendment to the 2011 Credit Agreement which increased the commitments available under the senior secured revolving credit facility (the "Revolving Credit Facility") from $500 million to $700 million and also extended the maturity date on the Credit Agreement until January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Credit Agreement) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. The loans made under the Credit Agreement will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings and for the issuance of letters of credit up to a sub-limit of $75 million. As of April 3, 2015, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

- removed (2015-10-30):
[0001104659-15-032642:note_history:39]
$600 million Aggregate Principal Amount of 6.8% Senior Notes due October 2016 (the “2016 Notes”). The interest on the 2016 Notes was payable semi-annually on April 1 and October 1 of each year. The issuer under the 2016 Notes was Seagate HDD Cayman, and the obligations under the 2016 Notes were unconditionally guaranteed by certain of the Company’s significant subsidiaries. During the December 2014 quarter, the 2016 Notes were fully extinguished through repurchase and redemption for cash at a premium to their principal amount, plus accrued and unpaid interest.

- removed (2015-10-30):
[0001104659-15-032642:note_history:40]
$600 million Aggregate Principal Amount of 6.875% Senior Notes due May 2020 (the “2020 Notes”). The interest on the 2020 Notes is payable semi-annually on May 1 and November 1 of each year. The issuer under the 2020 Notes is Seagate HDD Cayman, and the obligations under the 2020 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2015 quarter, the Company repurchased $1 million aggregate principal amount of its 2020 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. On April 7, 2015, Seagate HDD Cayman announced that it will redeem all of its remaining outstanding 2020 Notes. The Notes will be redeemed on May 7, 2015 (the “Redemption Date”) at a redemption price equal to $1,034.38 per $1,000 principal amount of the 2020 Notes redeemed plus accrued and unpaid interest from the interest payment date of May 1, 2015 to the Redemption Date. As a result, the 2020 Notes are classified as Current portion of long-term debt on the Company's Condensed Consolidated Balance Sheet at April 3, 2015.

- removed (2015-10-30):
[0001104659-15-032642:note_history:41]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 1, 2034 (the “2034 Notes”). On December 2, 2014, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 5.75% Senior Notes due 2034 which mature on December 1, 2034. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on June 1, 2015. At any time before June 1, 2034, Seagate HDD Cayman may redeem some or all of the Notes at a “make-whole” redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points, minus accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date. At any time on or after June 1, 2034, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-10-30):
[0001104659-15-074539:note_history:42]
|  |  | October 2, 2015 |  | July 3, 2015 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 800 |  |  | $ | 822 |  |  | $ | 800 |  |  | $ | 828 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 166 |  |  | 158 |  |  | 170 |  |
| 4.75% Senior Notes due June 2023 |  | 990 |  |  | 968 |  |  | 1,000 |  |  | 1,016 |  |
| 4.75% Senior Notes due January 2025 |  | 995 |  |  | 961 |  |  | 1,000 |  |  | 995 |  |
| 4.875% Senior Notes due June 2027 |  | 698 |  |  | 664 |  |  | 698 |  |  | 675 |  |
| 5.75% Senior Notes due December 2034 |  | 499 |  |  | 473 |  |  | 499 |  |  | 491 |  |
| Long-term debt |  | $ | 4,140 |  |  | $ | 4,054 |  |  | $ | 4,155 |  |  | $ | 4,175 |  |
| Less short-term borrowings and current portion of long-term debt |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 4,140 |  |  | $ | 4,054 |  |  | $ | 4,155 |  |  | $ | 4,175 |  |

- removed (2015-10-30):
[0001104659-15-032642:note_history:43]
|  |  | April 3, 2015 |  | June 27, 2014 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 6.8% Senior Notes due October 2016 |  | $ | — |  |  | $ | — |  |  | $ | 335 |  |  | $ | 374 |  |
| 3.75% Senior Notes due November 2018 |  | 800 |  |  | 832 |  |  | 800 |  |  | 820 |  |
| 6.875% Senior Notes due May 2020 |  | 474 |  |  | 492 |  |  | 534 |  |  | 578 |  |
| 7.00% Senior Notes due November 2021 |  | 159 |  |  | 172 |  |  | 251 |  |  | 284 |  |
| 4.75% Senior Notes due June 2023 |  | 1,000 |  |  | 1,052 |  |  | 1,000 |  |  | 1,009 |  |
| 4.75% Senior Notes due January 2025 |  | 1,000 |  |  | 1,040 |  |  | 1,000 |  |  | 995 |  |
| 5.75% Senior Notes due December 2034 |  | 498 |  |  | 542 |  |  | — |  |  | — |  |
| Long-term debt |  | $ | 3,931 |  |  | $ | 4,130 |  |  | $ | 3,920 |  |  | $ | 4,060 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-10-30):
[0001104659-15-074539:note_history:44]
| Fiscal Year | Amount |
| Remainder of 2016 | $ | — |  |
| 2017 | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| 2020 | — |  |
| Thereafter | 3,343 |  |
|  | $ | 4,143 |  |
  (was, 2015-04-30, similarity 0.9118):
[0001104659-15-032642:note_history:44]
| Fiscal Year | Amount |
| Remainder of 2015 | $ | 474 |  |
| 2016 | — |  |
| 2017 | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| Thereafter | 2,659 |  |
|  | $ | 3,933 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2015-10-30):
[0001104659-15-074539:note_history:45]
Subsequent Event

- added (2015-10-30):
[0001104659-15-074539:note_history:46]
On October 6, 2015, the Company acquired all of the outstanding shares of Dot Hill Systems Corp. ("Dot Hill"), a supplier of software and hardware storage systems. The Company paid $9.75 per share or approximately $696 million in cash for the acquisition. The acquisition of Dot Hill further expands the Company's OEM-focused cloud storage systems business and advances the Company's strategic efforts. Because the initial accounting for the acquisition was incomplete at the time this Form 10-Q was filed with the Securities and Exchange Commission, certain disclosures required by ASC Topic 805 — Business Combinations have not been made herein.
