# STX MD&A — 0001104659-15-074539


## mdna

[0001104659-15-074539:mdna:1]
[same as prior period, unchanged from 0001104659-15-032642:mdna:1]

[0001104659-15-074539:mdna:2]
The following is a discussion of the financial condition, changes in financial condition, and results of operations for our fiscal quarters ended October 2, 2015, July 3, 2015, and October 3, 2014, referred to herein as the  “September 2015 quarter”, the “June 2015 quarter”, and the “September 2014 quarter”, respectively. Unless the context indicates otherwise, as used herein, the terms “we,” “us,” “Seagate,” the “Company” and “our” refer to Seagate Technology plc, an Irish public limited company, and its subsidiaries. References to “$” are to United States dollars.

[0001104659-15-074539:mdna:3]
You should read this discussion in conjunction with financial information and related notes included elsewhere in this report. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The September 2015 and June 2015 quarters were both 13 weeks and the September 2014 quarter was 14 weeks.

[0001104659-15-074539:mdna:4]
[same as prior period, unchanged from 0001104659-15-032642:mdna:4]

[0001104659-15-074539:mdna:5]
[same as prior period, unchanged from 0001104659-15-032642:mdna:5]

[0001104659-15-074539:mdna:6]
·                  Overview of the September 2015 quarter. Highlights of events in the September 2015 quarter that impacted our financial position.

[0001104659-15-074539:mdna:7]
·                  Results of Operations. An analysis of our financial results comparing the September 2015 quarter to the June 2015 quarter and the September 2014 quarter

[0001104659-15-074539:mdna:8]
[same as prior period, unchanged from 0001104659-15-032642:mdna:8]

[0001104659-15-074539:mdna:9]
[same as prior period, unchanged from 0001104659-15-032642:mdna:9]

[0001104659-15-074539:mdna:10]
[same as prior period, unchanged from 0001104659-15-032642:mdna:11]

[0001104659-15-074539:mdna:11]
We are a leading provider of electronic data storage technology and solutions. Our principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, we produce a broad range of electronic data storage products including solid state hybrid drives (“SSHD”), solid state drives (“SSD”), PCIe cards and SATA controllers. Our storage technology portfolio also includes storage subsystems, high performance computing (HPC) solutions, and data storage services.

[0001104659-15-074539:mdna:12]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and most SSDs use NAND-based flash memory. In addition to HDDs and SSDs, Solid-state hybrid drives (SSHDs)

[0001104659-15-074539:mdna:13]
[same as prior period, unchanged from 0001104659-15-032642:mdna:29]

[0001104659-15-074539:mdna:14]
combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed data.

[0001104659-15-074539:mdna:15]
Our products are designed for enterprise servers and storage systems in mission critical and nearline applications; client compute applications, where our products are designed primarily for desktop and mobile computing; and client non-compute applications, where our products are designed for a wide variety of end user devices such as digital video recorders (“DVRs”), personal data backup systems, portable external storage systems, digital media systems and surveillance systems.

[0001104659-15-074539:mdna:16]
Our product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and high performance computing (“HPC”) data storage solutions. Our storage subsystems support a range of high-speed interconnect technologies to meet demanding cost and performance specifications. Our modular subsystem architecture allows us to support many segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.

[0001104659-15-074539:mdna:17]
Our data storage services provide online backup, data protection and recovery solutions for small to medium-sized businesses.

[0001104659-15-074539:mdna:18]
Overview of the September 2015 Quarter

[0001104659-15-074539:mdna:19]
During the September 2015 quarter, we shipped 47 million drive units totaling 56 exabytes of storage capacity, generating revenue of $2.9 billion and gross margin of 24%. Our operating cash flow was $824 million. We paid $983 million for repurchases of ordinary shares and $163 million for dividends to shareholders.

[0001104659-15-074539:mdna:20]
[same as prior period, unchanged from 0001104659-15-032642:mdna:18]

[0001104659-15-074539:mdna:21]
[same as prior period, unchanged from 0001104659-15-032642:mdna:19]

[0001104659-15-074539:mdna:22]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | October 2, 2015 |  | July 3, 2015 |  | October 3, 2014 |  |
| Revenue |  | $ | 2,925 |  | $ | 2,927 |  | $ | 3,785 |  |
| Cost of revenue |  | 2,236 |  | 2,151 |  | 2,734 |  |
| Gross margin |  | 689 |  | 776 |  | 1,051 |  |
| Product development |  | 328 |  | 324 |  | 342 |  |
| Marketing and administrative |  | 182 |  | 203 |  | 216 |  |
| Amortization of intangibles |  | 34 |  | 34 |  | 31 |  |
| Restructuring and other, net |  | 59 |  | 9 |  | 6 |  |
| Income from operations |  | 86 |  | 206 |  | 456 |  |
| Other income (expense), net |  | (55 | ) | (57 | ) | (64 | ) |
| Income before income taxes |  | 31 |  | 149 |  | 392 |  |
| (Benefit from) provision for income taxes |  | (3 | ) | 12 |  | 11 |  |
| Net income |  | $ | 34 |  | $ | 137 |  | $ | 381 |  |

[0001104659-15-074539:mdna:23]
|  |  | For the Three Months Ended |  |
|  |  | October 2, 2015 |  | July 3, 2015 |  | October 3, 2014 |  |
| Revenue |  | 100 | % | 100 | % | 100 | % |
| Cost of revenue |  | 76 |  | 73 |  | 72 |  |
| Gross margin |  | 24 |  | 27 |  | 28 |  |
| Product development |  | 11 |  | 11 |  | 9 |  |
| Marketing and administrative |  | 7 |  | 7 |  | 6 |  |
| Amortization of intangibles |  | 1 |  | 1 |  | 1 |  |
| Restructuring and other, net |  | 2 |  | 1 |  | — |  |
| Income from operations |  | 3 |  | 7 |  | 12 |  |
| Other income (expense), net |  | (2 | ) | (2 | ) | (2 | ) |
| Income before income taxes |  | 1 |  | 5 |  | 10 |  |
| (Benefit from) provision for income taxes |  | — |  | — |  | — |  |
| Net income |  | 1 | % | 5 | % | 10 | % |

[0001104659-15-074539:mdna:24]
[same as prior period, unchanged from 0001104659-15-032642:mdna:23]

[0001104659-15-074539:mdna:25]
The following table summarizes information regarding average drive selling prices (“ASPs”), drive volume unit shipments, exabytes shipped, and revenues by channel and geography:

[0001104659-15-074539:mdna:26]
|  |  | For the Three Months Ended |  |
| (In millions, except percentages, exabytes and ASPs) |  | October 2, 2015 |  | July 3, 2015 |  | October 3, 2014 |  |
| Unit Shipments: |  |  |  |  |  |  |  |
| Enterprise |  | 8 |  | 8 |  | 9 |  |
| Client Compute |  | 28 |  | 25 |  | 39 |  |
| Client Non-Compute |  | 11 |  | 12 |  | 12 |  |
| Total Units Shipped |  | 47 |  | 45 |  | 60 |  |
| ASPs (per unit) |  | $ | 58 |  | $ | 60 |  | $ | 60 |  |
| Exabytes Shipped |  | 56 |  | 52 |  | 60 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |
| OEMs |  | 70 | % | 73 | % | 70 | % |
| Distributors |  | 18 | % | 15 | % | 18 | % |
| Retailers |  | 12 | % | 12 | % | 12 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |
| Americas |  | 28 | % | 29 | % | 27 | % |
| EMEA |  | 17 | % | 16 | % | 17 | % |
| Asia Pacific |  | 55 | % | 55 | % | 56 | % |

[0001104659-15-074539:mdna:27]
Revenue in the September 2015 quarter remained flat from the June 2015 quarter as a result of an increase in unit shipments offset by price erosion. Compared to the September 2014 quarter, revenue decreased by $860 million as a result of a decrease in unit shipments and price erosion.

[0001104659-15-074539:mdna:28]
We maintain various sales programs such as point-of-sale rebates, sales price adjustments and price protection, aimed at increasing customer demand. Sales programs were approximately 13.0%, 12.4%, and 9.2% of gross drive revenue for the September 2015 quarter, June 2015 quarter and September 2014 quarter, respectively. Adjustments to revenues due to under or over accruals for sales programs related to revenues reported in prior quarterly periods were 0.1% of quarterly gross revenue in the September 2015 quarter.

[0001104659-15-074539:mdna:29]
[same as prior period, unchanged from 0001104659-15-032642:mdna:58]

[0001104659-15-074539:mdna:30]
[same as prior period, unchanged from 0001104659-15-032642:mdna:30]

[0001104659-15-074539:mdna:31]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | October 2, 2015 |  | July 3, 2015 |  | October 3, 2014 |  |
| Cost of revenue |  | $ | 2,236 |  | $ | 2,151 |  | $ | 2,734 |  |
| Gross margin |  | 689 |  | 776 |  | 1,051 |  |
| Gross margin percentage |  | 24 | % | 27 | % | 28 | % |

[0001104659-15-074539:mdna:32]
Gross margin as a percentage of revenue for the September 2015 quarter decreased by approximately 300 basis points to 24% compared to the June 2015 quarter due to price erosion and an unfavorable product mix. Compared to the September 2014 quarter, gross margin decreased by approximately 400 basis points to 24%, as a result of price erosion, partially offset by cost savings due to increased operational efficiencies.

[0001104659-15-074539:mdna:33]
In the September 2015 quarter, total warranty cost was 0.6% of revenue and included favorable changes in estimates of prior warranty accruals of approximately 0.5% of revenue. Warranty cost related to new unit shipments was 1.1% of revenue for each of the September 2015, June 2015 and September 2014 quarters, respectively.

[0001104659-15-074539:mdna:34]
[same as prior period, unchanged from 0001104659-15-032642:mdna:35]

[0001104659-15-074539:mdna:35]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | October 2, 2015 |  | July 3, 2015 |  | October 3, 2014 |  |
| Product development |  | $ | 328 |  | $ | 324 |  | $ | 342 |  |
| Marketing and administrative |  | 182 |  | 203 |  | 216 |  |
| Amortization of intangibles |  | 34 |  | 34 |  | 31 |  |
| Restructuring and other, net |  | 59 |  | 9 |  | 6 |  |
| Operating expenses |  | $ | 603 |  | $ | 570 |  | $ | 595 |  |

[0001104659-15-074539:mdna:36]
Product development expense.  Product development expense for the September 2015 quarter remained relatively flat from the June 2015 quarter. Compared to the September 2014 quarter, product development expense decreased by $14 million as a result of a decrease in variable compensation, an increase in operational efficiencies in our business, and additional expenses experienced in the 14-week September 2014 quarter.

[0001104659-15-074539:mdna:37]
Marketing and administrative expense. Marketing and administrative expense for the September 2015 quarter decreased by $21 million compared to the June 2015 quarter, due to an $8 million decrease in salaries and other employee benefits from the restructuring of our work force in the September 2015 quarter, and increased operational efficiencies in our business. Compared to the September 2014 quarter, marketing and administrative expense decreased by $34 million mainly due to decreases in variable compensation and stock based compensation, a decrease in salaries and other employee benefits from the restructuring of our work force in the September 2015 quarter, increased operational efficiencies in our business, and additional expenses experienced in the 14-week September 2014 quarter.

[0001104659-15-074539:mdna:38]
Amortization of intangibles. Amortization of intangibles for the September 2015 quarter remained flat from the June 2015 quarter. Compared to the September 2014 quarter, amortization of intangibles increased by $3 million as a result of the acquisition of LSI’s Flash Business offset by additional expenses experienced in the 14-week September 2014 quarter.

[0001104659-15-074539:mdna:39]
Restructuring and other, net. Restructuring and other, net for the September 2015 quarter increased by $50 million and $53 million, as compared to the June 2015 quarter and September 2014 quarter, respectively, due to a restructuring charge recorded during the September 2015 quarter to reduce work force by approximately 1,000 employees as a result of our ongoing focus on cost efficiencies in all areas of our business.

[0001104659-15-074539:mdna:40]
[same as prior period, unchanged from 0001104659-15-032642:mdna:47]

[0001104659-15-074539:mdna:41]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | October 2, 2015 |  | July 3, 2015 |  | October 3, 2014 |  |
| Other income (expense), net |  | $ | (55 | ) | $ | (56 | ) | $ | (64 | ) |

[0001104659-15-074539:mdna:42]
Other income (expense), net remained flat from the June 2015 quarter due to a $16 million loss from the early redemption and repurchase of debt, offset by a $5 million gain related to a disposition of a strategic investment in the June 2015 quarter, compared to

[0001104659-15-074539:mdna:43]
a $10 million loss related to the impairment of a strategic investment in the September 2015 quarter. Compared to the September 2014 quarter, other income (expense), net decreased by $9 million due to a $14 million loss from the early redemption and repurchase of debt in the September 2014 quarter, compared to a $10 million loss related to the impairment of a strategic investment and lower interest expense in the September 2015 quarter.

[0001104659-15-074539:mdna:44]
[same as prior period, unchanged from 0001104659-15-032642:mdna:51]

[0001104659-15-074539:mdna:45]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | October 2, 2015 |  | July 3, 2015 |  | October 3, 2014 |  |
| (Benefit from) provision for income taxes |  | $ | (3 | ) | $ | 12 |  | $ | 11 |  |

[0001104659-15-074539:mdna:46]
Our income tax benefit recorded for the September 2015 quarter included approximately $4 million of net discrete tax benefits primarily associated with the release of tax reserves associated with the expiration of certain statutes of limitation.

[0001104659-15-074539:mdna:47]
Our income tax benefit recorded for the September 2015 quarter differed from the benefit from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets.

[0001104659-15-074539:mdna:48]
During the three months ended October 2, 2015, our unrecognized tax benefits excluding interest and penalties decreased by approximately $4 million to $79 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $79 million at October 2, 2015, subject to certain future valuation allowance reversals. During the 12 months beginning October 3, 2015, we expect that our unrecognized tax benefits could be reduced by approximately $35 million primarily as a result of the expiration of certain statutes of limitation.

[0001104659-15-074539:mdna:49]
Our income tax provision recorded for the September 2014 quarter included approximately $2 million net discrete tax benefits primarily associated with the release of tax reserves associated with the expiration of certain statutes of limitation.

[0001104659-15-074539:mdna:50]
Our income tax provision recorded for the September 2014 quarter differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets. The acquisition of LSI’s Flash Business did not have a material impact on our effective tax rate in fiscal year 2015.

[0001104659-15-074539:mdna:51]
[same as prior period, unchanged from 0001104659-15-032642:mdna:62]

[0001104659-15-074539:mdna:52]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist primarily of money market funds, certificates of deposits, and other interest-bearing bank deposits. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, these restrictions have not impeded our ability to conduct our business, nor do we expect them to in the next 12 months. We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term investments and we do not believe the fair value of our short-term investments has significantly changed from the values reported as of October 2, 2015.

[0001104659-15-074539:mdna:53]
Cash and Cash Equivalents and Short-term Investments

[0001104659-15-074539:mdna:54]
| (Dollars in millions) |  | October 2, 2015 |  | July 3, 2015 |  | Change |  |
| Cash and cash equivalents |  | $ | 1,915 |  | $ | 2,479 |  | $ | (564 | ) |
| Short-term investments |  | 6 |  | 6 |  | — |  |
| Total |  | $ | 1,921 |  | $ | 2,485 |  | $ | (564 | ) |

[0001104659-15-074539:mdna:55]
Our cash and cash equivalents and short-term investments decreased from July 3, 2015 as a result of net cash outflows for the repurchase of our ordinary shares, early redemption and repayments of long-term debt, dividends paid to our shareholders, and capital expenditures. These cash outflows were partially offset by our net cash provided by operating activities.

[0001104659-15-074539:mdna:56]
[same as prior period, unchanged from 0001104659-15-032642:mdna:67]

[0001104659-15-074539:mdna:57]
Cash provided by operating activities for the three months ended October 2, 2015 of $824 million includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, and:

[0001104659-15-074539:mdna:58]
·      a decrease of $213 million in accounts receivable, primarily due to a favorable change in channel mix and improved linearity; and

[0001104659-15-074539:mdna:59]
·      an increase of $426 million in accounts payable, primarily due to the timing of payments on material purchases and improved payment terms with certain of our vendors.

[0001104659-15-074539:mdna:60]
[same as prior period, unchanged from 0001104659-15-032642:mdna:70]

[0001104659-15-074539:mdna:61]
Cash used for investing activities for the three months ended October 2, 2015 was $209 million which was used for acquired property, equipment and leasehold improvements.

[0001104659-15-074539:mdna:62]
[same as prior period, unchanged from 0001104659-15-032642:mdna:73]

[0001104659-15-074539:mdna:63]
Cash used in financing activities of $1,178 million for the three months ended October 2, 2015 was primarily attributable to the following activities:

[0001104659-15-074539:mdna:64]
·      $983 million paid to repurchase ordinary shares; and

[0001104659-15-074539:mdna:65]
·      $163 million in dividend payments.

[0001104659-15-074539:mdna:66]
[same as prior period, unchanged from 0001104659-15-032642:mdna:79]

[0001104659-15-074539:mdna:67]
Our primary sources of liquidity as of October 2, 2015 consisted of: (1) approximately $1.9 billion in cash, cash equivalents, and short-term investments, (2) cash we expect to generate from operations and (3) a $700 million senior revolving credit facility.

[0001104659-15-074539:mdna:68]
As of October 2, 2015, no borrowings have been drawn under the revolving credit facility or had been utilized for letters of credit issued under this credit facility. The line of credit is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001104659-15-074539:mdna:69]
The credit agreement that governs our revolving credit facility, as amended, contains certain covenants that we must satisfy in order to remain in compliance with the credit agreement, as amended. The agreement also includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. As of October 2, 2015, we were in compliance with all of the covenants under our Revolving Credit Facility and debt agreements. Based on our current outlook, we expect to be in compliance with the covenants of our debt agreements over the next 12 months.

[0001104659-15-074539:mdna:70]
[same as prior period, unchanged from 0001104659-15-032642:mdna:83]

[0001104659-15-074539:mdna:71]
For fiscal year 2016, we expect capital expenditures to be at or below our long-term targeted range of 6% to 8% of revenue.

[0001104659-15-074539:mdna:72]
From time to time we may repurchase any of our outstanding notes in open market or privately negotiated purchases or otherwise, or may repurchase outstanding notes pursuant to the terms of the applicable indenture.

[0001104659-15-074539:mdna:73]
The Company’s Board of Directors approved a quarterly cash dividend of $0.63 per share on October 21, 2015, which is payable on November 20, 2015 to shareholders of record at the close of business on November 6, 2015.

[0001104659-15-074539:mdna:74]
From time to time we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases. As of October 2, 2015, $1.9 billion remained available for repurchase under our existing repurchase authorization limit.  All repurchases are effected as redemptions in accordance with the Company’s Articles of Association.

[0001104659-15-074539:mdna:75]
34

[0001104659-15-074539:mdna:76]
[same as prior period, unchanged from 0001104659-15-032642:mdna:89]

[0001104659-15-074539:mdna:77]
[same as prior period, unchanged from 0001104659-15-032642:mdna:90]

[0001104659-15-074539:mdna:78]
Since our fiscal year ended July 3, 2015, there have been no material changes in our critical accounting policies and estimates.  Refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended July 3, 2015, as filed with the SEC on August 11, 2015, for a discussion of our critical accounting policies and estimates.

[0001104659-15-074539:mdna:79]
[same as prior period, unchanged from 0001104659-15-032642:mdna:93]

[0001104659-15-074539:mdna:80]
[same as prior period, unchanged from 0001104659-15-032642:mdna:94]
