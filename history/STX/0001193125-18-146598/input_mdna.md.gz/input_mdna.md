# STX MD&A — 0001193125-18-146598


## mdna

[0001193125-18-146598:mdna:1]
[same as prior period, unchanged from 0001193125-18-023592:mdna:1]

[0001193125-18-146598:mdna:2]
The following is a discussion of the financial condition, changes in financial condition, and results of operations for our fiscal quarters
ended March 30, 2018, December 29, 2017 and March 31, 2017, referred to herein as the “March 2018 quarter,” the “December 2017 quarter,” and the “March 2017 quarter,” respectively. We operate and
report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The March 2018, December 2017 and March 2017 quarters were all 13 weeks.

[0001193125-18-146598:mdna:3]
[same as prior period, unchanged from 0001193125-18-023592:mdna:3]

[0001193125-18-146598:mdna:4]
[same as prior period, unchanged from 0001193125-18-023592:mdna:16]

[0001193125-18-146598:mdna:5]
[same as prior period, unchanged from 0001193125-18-023592:mdna:4]

[0001193125-18-146598:mdna:6]
[same as prior period, unchanged from 0001193125-18-023592:mdna:5]

[0001193125-18-146598:mdna:7]
|  | • |  | Overview of the March 2018 Quarter. Highlights of events in the March 2018 quarter that impacted our financial position. |

[0001193125-18-146598:mdna:8]
|  | • |  | Results of Operations. An analysis of our financial results comparing the March 2018 quarter to the December 2017 quarter and the March 2017 quarter. |

[0001193125-18-146598:mdna:9]
[same as prior period, unchanged from 0001193125-18-023592:mdna:8]

[0001193125-18-146598:mdna:10]
|  | • |  | Contractual Obligations and Commitments. Overview of contractual obligations and contingent liabilities and commitments outstanding as of March 30, 2018. |

[0001193125-18-146598:mdna:11]
[same as prior period, unchanged from 0001193125-18-023592:mdna:10]

[0001193125-18-146598:mdna:12]
[same as prior period, unchanged from 0001193125-18-023592:mdna:11]

[0001193125-18-146598:mdna:13]
[same as prior period, unchanged from 0001193125-18-023592:mdna:12]

[0001193125-18-146598:mdna:14]
[same as prior period, unchanged from 0001193125-18-023592:mdna:22]

[0001193125-18-146598:mdna:15]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with
magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use
integrated circuit assemblies as memory to store data with most SSDs using NAND-based flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to
improve performance of frequently accessed data.

[0001193125-18-146598:mdna:16]
Our products are designed for mission critical and nearline applications in enterprise
servers and storage systems; edge compute / client compute applications, where our products are designed primarily for desktop and mobile computing; and edge non-compute /
client non-compute applications, where our products are designed for a wide variety of end user devices such as portable external storage systems, surveillance systems, network-attached storage
(“NAS”), digital video recorders (“DVRs”) and gaming consoles.

[0001193125-18-146598:mdna:17]
Our cloud systems and solutions extend innovation from
the device into the information infrastructure, onsite and in the cloud. Our portfolio includes modular original equipment manufacturer (“OEM”) storage systems and scale-out storage
servers.

[0001193125-18-146598:mdna:18]
Overview of the March 2018 Quarter

[0001193125-18-146598:mdna:19]
During the March 2018 quarter, we shipped 87 exabytes of HDD storage capacity. We generated revenue of approximately $2.8 billion, gross
margin of 30% and our operating cash flow was $558 million. We paid $179 million in dividends and $57 million for the repurchase of certain of our outstanding debt.

[0001193125-18-146598:mdna:20]
[same as prior period, unchanged from 0001193125-18-023592:mdna:19]

[0001193125-18-146598:mdna:21]
We list in the
tables below summarized information from our Condensed Consolidated Statements of Operations by dollars and as a percentage of revenue:

[0001193125-18-146598:mdna:22]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 30,2018 |  | December 29,2017 |  | March 31,2017 |  | March 30,2018 |  | March 31,2017 |
| Revenue |  | $ | 2,803 |  |  | $ | 2,914 |  |  | $ | 2,674 |  |  | $ | 8,349 |  |  | $ | 8,365 |  |
| Cost of revenue |  |  | 1,956 |  |  |  | 2,037 |  |  |  | 1,858 |  |  |  | 5,889 |  |  |  | 5,857 |  |
| Gross margin |  |  | 847 |  |  |  | 877 |  |  |  | 816 |  |  |  | 2,460 |  |  |  | 2,508 |  |
| Product development |  |  | 254 |  |  |  | 250 |  |  |  | 324 |  |  |  | 767 |  |  |  | 944 |  |
| Marketing and administrative |  |  | 135 |  |  |  | 142 |  |  |  | 150 |  |  |  | 422 |  |  |  | 457 |  |
| Amortization of intangibles |  |  | 6 |  |  |  | 19 |  |  |  | 28 |  |  |  | 47 |  |  |  | 85 |  |
| Restructuring and other, net |  |  | 11 |  |  |  | 33 |  |  |  | 48 |  |  |  | 95 |  |  |  | 164 |  |
| Income from operations |  |  | 441 |  |  |  | 433 |  |  |  | 266 |  |  |  | 1,129 |  |  |  | 858 |  |
| Other expense, net |  |  | (48 | ) |  |  | (62 | ) |  |  | (54 | ) |  |  | (177 | ) |  |  | (163 | ) |
| Income before income taxes |  |  | 393 |  |  |  | 371 |  |  |  | 212 |  |  |  | 952 |  |  |  | 695 |  |
| Provision for income taxes |  |  | 12 |  |  |  | 212 |  |  |  | 18 |  |  |  | 231 |  |  |  | 37 |  |
| Net income |  | $ | 381 |  |  | $ | 159 |  |  | $ | 194 |  |  | $ | 721 |  |  | $ | 658 |  |
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
|  |  | March 30,2018 |  | December 29,2017 |  | March 31,2017 |  | March 30,2018 |  | March 31,2017 |
| Revenue |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |
| Cost of revenue |  |  | 70 |  |  |  | 70 |  |  |  | 69 |  |  |  | 71 |  |  |  | 70 |  |
| Gross margin |  |  | 30 |  |  |  | 30 |  |  |  | 31 |  |  |  | 29 |  |  |  | 30 |  |
| Product development |  |  | 9 |  |  |  | 9 |  |  |  | 12 |  |  |  | 9 |  |  |  | 11 |  |
| Marketing and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 6 |  |  |  | 5 |  |  |  | 6 |  |
| Amortization of intangibles |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |
| Restructuring and other, net |  |  | — |  |  |  | 1 |  |  |  | 2 |  |  |  | 1 |  |  |  | 2 |  |
| Income from operations |  |  | 16 |  |  |  | 15 |  |  |  | 10 |  |  |  | 13 |  |  |  | 10 |  |
| Other expense, net |  |  | (2 | ) |  |  | (3 | ) |  |  | (2 | ) |  |  | (2 | ) |  |  | (2 | ) |
| Income before income taxes |  |  | 14 |  |  |  | 12 |  |  |  | 8 |  |  |  | 11 |  |  |  | 8 |  |
| Provision for income taxes |  |  | — |  |  |  | 7 |  |  |  | 1 |  |  |  | 2 |  |  |  | — |  |
| Net income |  |  | 14 | % |  |  | 5 | % |  |  | 7 | % |  |  | 9 | % |  |  | 8 | % |

[0001193125-18-146598:mdna:23]
[same as prior period, unchanged from 0001193125-18-023592:mdna:35]

[0001193125-18-146598:mdna:24]
[same as prior period, unchanged from 0001193125-18-023592:mdna:23]

[0001193125-18-146598:mdna:25]
[same as prior period, unchanged from 0001193125-18-023592:mdna:24]

[0001193125-18-146598:mdna:26]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
|  |  | March 30,2018 |  | December 29,2017 |  | March 31,2017 |  | March 30,2018 |  | March 31,2017 |
| ASPs (per unit) |  | $ | 70 |  |  | $ | 68 |  |  | $ | 67 |  |  | $ | 67 |  |  | $ | 67 |  |
| Exabytes Shipped |  |  | 87 |  |  |  | 88 |  |  |  | 65 |  |  |  | 245 |  |  |  | 200 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  |  | 69 | % |  |  | 67 | % |  |  | 66 | % |  |  | 67 | % |  |  | 67 | % |
| Distributors |  |  | 17 | % |  |  | 17 | % |  |  | 19 | % |  |  | 17 | % |  |  | 18 | % |
| Retailers |  |  | 14 | % |  |  | 16 | % |  |  | 15 | % |  |  | 16 | % |  |  | 15 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  |  | 29 | % |  |  | 26 | % |  |  | 30 | % |  |  | 27 | % |  |  | 31 | % |
| EMEA |  |  | 17 | % |  |  | 19 | % |  |  | 17 | % |  |  | 18 | % |  |  | 17 | % |
| Asia Pacific |  |  | 54 | % |  |  | 55 | % |  |  | 53 | % |  |  | 55 | % |  |  | 52 | % |

[0001193125-18-146598:mdna:27]
Revenue in the March 2018 quarter decreased by $111 million from the December 2017 quarter as a result of
lower seasonal demand in the consumer and client markets and price erosion, partially offset by higher exabytes shipped in the enterprise market.

[0001193125-18-146598:mdna:28]
Compared to the March 2017 quarter, revenue in the March 2018 quarter increased by $129 million as a result of an increase in exabytes
shipped primarily in the enterprise market, partially offset by price erosion.

[0001193125-18-146598:mdna:29]
Revenue for the nine months ended March 2018 quarter
decreased modestly from the nine months ended March 2017 quarter as a result of price erosion, partially offset by an increase in exabytes shipped.

[0001193125-18-146598:mdna:30]
We maintain various sales programs such as channel rebates and price masking. Sales programs were approximately 12%, 12% and 11% of gross
drive revenue for the March 2018 quarter, December 2017 quarter and March 2017 quarter, respectively. Adjustments to revenues due to under or over accruals for sales programs related to revenues reported in prior quarterly periods were less than 1%
of quarterly gross revenue in all periods presented.

[0001193125-18-146598:mdna:31]
[same as prior period, unchanged from 0001193125-18-023592:mdna:30]

[0001193125-18-146598:mdna:32]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 30,2018 |  | December 29,2017 |  | March 31,2017 |  | March 30,2018 |  | March 31,2017 |
| Cost of revenue |  | $ | 1,956 |  |  | $ | 2,037 |  |  | $ | 1,858 |  |  | $ | 5,889 |  |  | $ | 5,857 |  |
| Gross margin |  |  | 847 |  |  |  | 877 |  |  |  | 816 |  |  |  | 2,460 |  |  |  | 2,508 |  |
| Gross margin percentage |  |  | 30 | % |  |  | 30 | % |  |  | 31 | % |  |  | 29 | % |  |  | 30 | % |

[0001193125-18-146598:mdna:33]
Gross margin as a percentage of revenue for the March 2018 quarter remained flat from the December 2017
quarter.

[0001193125-18-146598:mdna:34]
Compared to the corresponding three and nine months ended March 2017 quarter, gross margin as a percentage of revenue for the
three and nine months ended March 2018 quarter decreased by 100 basis points in both periods, primarily driven by price erosion, partially offset by favorable product mix and cost containment efforts.

[0001193125-18-146598:mdna:35]
In the March 2018 quarter, total warranty cost was 0.9% of revenue and included a favorable change in estimates of prior warranty accruals of
less than 0.4% of revenue primarily due to improvements in return rates on newer generation products. Warranty cost related to new shipments was 1.3%, 1.4% and 1.2% of revenue for each of the March 2018, December 2017 and March 2017 quarters,
respectively.

[0001193125-18-146598:mdna:36]
[same as prior period, unchanged from 0001193125-18-023592:mdna:51]

[0001193125-18-146598:mdna:37]
[same as prior period, unchanged from 0001193125-18-023592:mdna:36]

[0001193125-18-146598:mdna:38]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | March 30,2018 |  |  | December 29,2017 |  |  | March 31,2017 |  |  | March 30,2018 |  |  | March 31,2017 |  |
| Product development |  | $ | 254 |  |  | $ | 250 |  |  | $ | 324 |  |  | $ | 767 |  |  | $ | 944 |  |
| Marketing and administrative |  |  | 135 |  |  |  | 142 |  |  |  | 150 |  |  |  | 422 |  |  |  | 457 |  |
| Amortization of intangibles |  |  | 6 |  |  |  | 19 |  |  |  | 28 |  |  |  | 47 |  |  |  | 85 |  |
| Restructuring and other, net |  |  | 11 |  |  |  | 33 |  |  |  | 48 |  |  |  | 95 |  |  |  | 164 |  |
| Operating expenses |  | $ | 406 |  |  | $ | 444 |  |  | $ | 550 |  |  | $ | 1,331 |  |  | $ | 1,650 |  |

[0001193125-18-146598:mdna:39]
Product development expense. Product development expense for the March 2018 quarter remained
essentially flat from the December 2017 quarter.

[0001193125-18-146598:mdna:40]
Compared to the March 2017 quarter, product development expense in the March 2018
quarter decreased by $70 million due to a $31 million decrease in salaries and employee benefits as a result of the restructuring of our workforce in prior periods, a $32 million decrease due to related operational efficiencies and a
$7 million decrease in variable compensation and share-based compensation expenses.

[0001193125-18-146598:mdna:41]
Compared to the corresponding nine months ended
March 2017 quarter, product development expense for the nine months ended March 2018 quarter decreased by $177 million due to a $68 million decrease in salaries and employee benefits as a result of the restructuring of our workforce in
prior periods, a $78 million decrease due to related operational efficiencies and a $31 million decrease in variable compensation and share-based compensation expenses.

[0001193125-18-146598:mdna:42]
Marketing and administrative expense. Marketing and administrative expense for the March 2018 quarter decreased by $7 million
from the December 2017 quarter primarily due to a $4 million decrease due to operational efficiencies and a $2 million decrease in variable compensation expense.

[0001193125-18-146598:mdna:43]
Compared to the March 2017 quarter, Marketing and administrative expense in the March 2018 quarter decreased by $15 million due to a
$17 million decrease in salaries and employee benefits as a result of the restructuring of our workforce in prior periods, a $6 million decrease in variable compensation and share-based compensation expenses, partially offset by an
increase in other general expenses.

[0001193125-18-146598:mdna:44]
Compared to the corresponding nine months ended March 2017 quarter, Marketing and administrative
expense for the nine months ended March 2018 quarter decreased by $35 million due to a $30 million decrease in salaries and employee benefits as a result of the restructuring of our workforce in prior periods, a $17 million decrease
in variable compensation and share-based compensation expenses, partially offset by a $12 million increase in other general expenses.

[0001193125-18-146598:mdna:45]
Amortization of intangibles. Amortization of intangibles for the three and nine months ended March 2018 quarter decreased by
$13 million, $22 million and $38 million as compared to the three months ended December 2017 quarter and the three and nine months ended March 2017 quarter, respectively, due to certain intangible assets reaching the end of their
useful life.

[0001193125-18-146598:mdna:46]
Restructuring and other, net. Restructuring and other, net for the nine months ended March 2018 quarter was comprised
primarily of restructuring charges to reduce our global workforce by 1,100 employees. There was no new restructuring plan in the March 2018 quarter.

[0001193125-18-146598:mdna:47]
Restructuring and other, net for the three and nine months ended March 2017 quarter was primarily comprised of restructuring charges to reduce
our global workforce by 300 and 6,800 employees, respectively. Each of these restructuring activities have reduced our workforce as we consolidated our global footprint across Asia, EMEA and the Americas. See “Part I, Item 1.
Financial Statements—Note 7. Restructuring and Exit Costs” for more details.

[0001193125-18-146598:mdna:48]
[same as prior period, unchanged from 0001193125-18-023592:mdna:47]

[0001193125-18-146598:mdna:49]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | March 30,2018 |  |  | December 29,2017 |  |  | March 31,2017 |  |  | March 30,2018 |  |  | March 31,2017 |  |
| Other expense, net |  | $ | (48 | ) |  | $ | (62 | ) |  | $ | (54 | ) |  | $ | (177 | ) |  | $ | (163 | ) |

[0001193125-18-146598:mdna:50]
Other expense, net decreased by $14 million from the December 2017 quarter primarily due to a
$9 million gain from net favorable changes in foreign currency exchange rates, a $3 million increase in interest income, a $2 million decrease in loss on repurchase of debt, partially offset by a $3 million charge related to the
impairment of a strategic investment.

[0001193125-18-146598:mdna:51]
Compared to March 2017 quarter, Other expense, net decreased by $6 million in the March 2018
quarter primarily due to a $9 million gain from net favorable changes in foreign currency exchange rates and a $4 million increase in interest income, partially offset by a $6 million net increase in losses related to strategic
investments.

[0001193125-18-146598:mdna:52]
Other expense, net for the nine months ended March 2018 quarter increased by $14 million from the corresponding period
in the prior year, primarily due to a $22 million net increase in interest expense on the issuance of $1.25 billion Senior Notes in the March 2017 quarter offset by repurchase of certain debts, a $17 million loss from net unfavorable
changes in foreign currency exchange rates, a $3 million loss on repurchase of debts, partially offset by a $16 million increase in interest income and a $16 million net decrease in losses related to strategic investments.

[0001193125-18-146598:mdna:53]
[same as prior period, unchanged from 0001193125-18-023592:mdna:53]

[0001193125-18-146598:mdna:54]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | March 30,2018 |  |  | December 29,2017 |  |  | March 31,2017 |  |  | March 30,2018 |  |  | March 31,2017 |  |
| Provision for income taxes |  | $ | 12 |  |  | $ | 212 |  |  | $ | 18 |  |  | $ | 231 |  |  | $ | 37 |  |

[0001193125-18-146598:mdna:55]
We recorded income tax provisions of $12 million and $231 million in the three and nine months ended
March 2018 quarter, respectively. The income tax provision for the three and nine months ended March 2018 quarter included approximately $2 million of net discrete tax benefit and approximately $195 million of net discrete expense,
respectively. The discrete items for the nine months ended March 2018 quarter are primarily associated with the revaluation of U.S. deferred tax assets as a result of the enactment of the U.S. Tax Cuts and Jobs Act (the “Act”) on
December 22, 2017, partially offset by the recognition of previously unrecognized tax benefits associated with the expiration of certain statutes of limitation.

[0001193125-18-146598:mdna:56]
Our income tax provision recorded for the three and nine months ended March 2018 quarter differed from the provision for income taxes that
would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that
are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a reduction in the net U.S. deferred tax assets associated with revaluation to a lower U.S. tax rate.

[0001193125-18-146598:mdna:57]
During the nine months ended March 2018 quarter, our unrecognized tax benefits excluding interest and penalties decreased by approximately
$15 million to $59 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $59 million at March 30, 2018, subject to certain future changes in valuation allowance. During the twelve
months beginning March 31, 2018, we expect that our unrecognized tax benefits could be reduced by approximately $19 million, primarily as a result of the expiration of certain statutes of limitation.

[0001193125-18-146598:mdna:58]
Our income tax provision recorded for the nine months ended March 2017 quarter included approximately $3 million of net discrete tax
expense, primarily associated with changes in valuation allowances offset by the release of tax reserves due to the expiration of certain statutes of limitation, and prior year tax adjustments.

[0001193125-18-146598:mdna:59]
Our income tax provision recorded for the three and nine months ended March 2017 quarter differed from the provision from income taxes that
would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that
are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) restructuring expenses with no associated tax benefits, and (iii) a net decrease in valuation allowance for certain deferred tax
assets.

[0001193125-18-146598:mdna:60]
[same as prior period, unchanged from 0001193125-18-023592:mdna:87]

[0001193125-18-146598:mdna:61]
The Act significantly revised U.S. corporate income tax law by, among other things, lowering
corporate income tax rates from 35% to 21%, implementing a territorial tax system and imposing a tax on deemed repatriated earnings of non-U.S. subsidiaries. The Act’s new international rules, including
the Global Intangible Low-Taxed Income, the Foreign Derived Intangible Income and the Base Erosion Anti-Avoidance Tax, are not expected to have a material impact on our financial statements. However, these
assessments are based on preliminary review and analysis of the Act and are subject to change as we continue to evaluate these highly complex rules as additional interpretive guidance is issued.

[0001193125-18-146598:mdna:62]
Pursuant to SEC Staff Accounting Bulletin (“SAB”) 118 (regarding the application of ASC 740 associated with the enactment
of the Act), we recorded an adjusted provisional tax expense of approximately $4 million and $212 million for the three and nine months ended March 30, 2018, respectively, to re-measure our U.S.
deferred tax assets at the newly enacted 21% tax rate. The tax expense remains provisional because we continue to evaluate the impact of various domestic and international provisions of the Act as well as the impact of additional guidance that may
be provided. This provisional tax expense increased our effective tax rate for the three and nine months ended March 30, 2018 to approximately 3% and 24%, respectively. The other U.S. tax changes are not expected to impact our tax expense in
the short-term due our large net operating loss and tax credit carryovers.

[0001193125-18-146598:mdna:63]
[same as prior period, unchanged from 0001193125-18-023592:mdna:63]

[0001193125-18-146598:mdna:64]
[same as prior period, unchanged from 0001193125-18-023592:mdna:64]

[0001193125-18-146598:mdna:65]
Cash and Cash
Equivalents

[0001193125-18-146598:mdna:66]
| (Dollars in millions) |  | March 30,2018 |  |  | June 30,2017 |  |  | Change |  |
| Cash and cash equivalents |  | $ | 2,926 |  |  | $ | 2,539 |  |  | $ | 387 |  |

[0001193125-18-146598:mdna:67]
[same as prior period, unchanged from 0001193125-18-023592:mdna:67]

[0001193125-18-146598:mdna:68]
[same as prior period, unchanged from 0001193125-18-023592:mdna:68]

[0001193125-18-146598:mdna:69]
Cash provided by operating activities for the nine months ended March 30, 2018 of $1,645 million includes the effects of net income
adjusted for non-cash items including depreciation, amortization, deferred income taxes primarily due to the remeasurement of our U.S. deferred tax assets at the lower corporate tax rate, share-based
compensation and:

[0001193125-18-146598:mdna:70]
|  | • |  | a decrease of $124 million in accounts receivable, primarily due to improved in-quarter linearity of shipments; |

[0001193125-18-146598:mdna:71]
|  | • |  | an increase of $74 million in accounts payable, primarily due to timing of material purchases; and |

[0001193125-18-146598:mdna:72]
|  | • |  | a decrease of $54 million in vendor receivables, primarily due to timing of receipt of vendor payments; |

[0001193125-18-146598:mdna:73]
|  | • |  | partially offset by a decrease of $49 million in accrued employee compensation, primarily due to cash paid to our employees as part of our variable compensation plans. |

[0001193125-18-146598:mdna:74]
[same as prior period, unchanged from 0001193125-18-023592:mdna:75]

[0001193125-18-146598:mdna:75]
Cash used in investing activities for the nine months ended March 30, 2018 was $239 million, which was primarily attributable to the
payments for the purchase of property, equipment and leasehold improvements of $270 million, partially offset by the proceeds of $43 million from the sale of certain properties previously classified as held for sale.

[0001193125-18-146598:mdna:76]
Cash Used in Financing Activities

[0001193125-18-146598:mdna:77]
Cash used in financing activities of $1,027 million for the nine months ended March 30, 2018 was primarily attributable to the
following activities:

[0001193125-18-146598:mdna:78]
|  | • |  | $545 million in dividend payments; |

[0001193125-18-146598:mdna:79]
[same as prior period, unchanged from 0001193125-18-023592:mdna:80]

[0001193125-18-146598:mdna:80]
|  | • |  | $209 million of repayments of long-term debt; and |

[0001193125-18-146598:mdna:81]
|  | • |  | $22 million paid for taxes related to net share settlement of equity awards; |

[0001193125-18-146598:mdna:82]
|  | • |  | partially offset by $110 million in proceeds from the issuance of ordinary shares under employee stock plans. |

[0001193125-18-146598:mdna:83]
Liquidity Sources, Cash Requirements and Commitments

[0001193125-18-146598:mdna:84]
Our primary sources of liquidity as of March 30, 2018 consisted of: (1) approximately $2.9 billion in cash and cash equivalents,
(2) cash we expect to generate from operations and (3) a $700 million senior revolving credit facility.

[0001193125-18-146598:mdna:85]
As of
March 30, 2018, no borrowings had been drawn under the revolving credit facility or had been utilized for letters of credit issued under this credit facility. The line of credit is available for borrowings, subject to compliance with financial
covenants and other customary conditions to borrowing.

[0001193125-18-146598:mdna:86]
The credit agreement that governs our revolving credit facility, as amended,
includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. On April 28, 2016, the Revolving Credit Agreement was amended in
order to increase the allowable net leverage ratio to adjust for our financial liquidity position. The term of the revolving credit facility is through January 15, 2020 provided that if we do not have Investment Grade Ratings (as defined in the
revolving credit facility) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. We were in compliance with the modified covenants as of March 30, 2018 and expect
to be in compliance for the next 12 months.

[0001193125-18-146598:mdna:87]
Our liquidity requirements are primarily to meet our working capital, product development and
capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend and any future strategic investments. Our ability to fund these requirements will depend on our future cash
flows, which are determined by future operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001193125-18-146598:mdna:88]
[same as prior period, unchanged from 0001193125-18-023592:mdna:90]

[0001193125-18-146598:mdna:89]
From time to time we may repurchase any of our outstanding notes in open market or privately negotiated purchases or otherwise, or we may
repurchase outstanding notes pursuant to the terms of the applicable indenture.

[0001193125-18-146598:mdna:90]
Dividends declared in the March 2018 quarter of
$181 million were subsequently paid on April 4, 2018. The Company’s Board of Directors declared a quarterly cash dividend of $0.63 per share on May 1, 2018, which is payable on July 5, 2018 to shareholders of record at the
close of business on June 20, 2018.

[0001193125-18-146598:mdna:91]
From time to time we may repurchase any of our outstanding ordinary shares through private, open
market, or broker-assisted purchases. As of March 30, 2018, $0.9 billion remained available for repurchase under our existing repurchase authorization limit. All repurchases are effected as redemptions in accordance with the
Company’s Articles of Association.

[0001193125-18-146598:mdna:92]
[same as prior period, unchanged from 0001193125-18-023592:mdna:94]

[0001193125-18-146598:mdna:93]
Our contractual cash obligations and commitments as of March 30, 2018, have been summarized in the table below:

[0001193125-18-146598:mdna:94]
|  |  |  |  |  | Fiscal Year(s) |  |
| (Dollars in millions) |  | Total |  |  | Remainder of2018 |  |  | 2019-2020 |  |  | 2021-2022 |  |  | Thereafter |  |
| Contractual Cash Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | $ | 4,867 |  |  | $ | — |  |  | $ | 504 |  |  | $ | 750 |  |  | $ | 3,613 |  |
| Interest payments on debt |  |  | 1,667 |  |  |  | 62 |  |  |  | 430 |  |  |  | 420 |  |  |  | 755 |  |
| Purchase obligations (1) |  |  | 827 |  |  |  | 713 |  |  |  | 114 |  |  |  | — |  |  |  | — |  |
| Operating leases (2) |  |  | 118 |  |  |  | 5 |  |  |  | 25 |  |  |  | 13 |  |  |  | 75 |  |
| Capital expenditures |  |  | 238 |  |  |  | 120 |  |  |  | 118 |  |  |  | — |  |  |  | — |  |
| Other funding requirements (3) |  |  | 26 |  |  |  | 7 |  |  |  | 19 |  |  |  | — |  |  |  | — |  |
| Subtotal |  |  | 7,743 |  |  |  | 907 |  |  |  | 1,210 |  |  |  | 1,183 |  |  |  | 4,443 |  |
| Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit or bank guarantees |  |  | 103 |  |  |  | 11 |  |  |  | 91 |  |  |  | 1 |  |  |  | — |  |
| Total |  | $ | 7,846 |  |  | $ | 918 |  |  | $ | 1,301 |  |  | $ | 1,184 |  |  | $ | 4,443 |  |

[0001193125-18-146598:mdna:95]
| (1) | Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. |

[0001193125-18-146598:mdna:96]
| (2) | Includes total future minimum rent expense under non-cancelable leases for both occupied and vacated facilities (rent expense is shown net of sublease income). |

[0001193125-18-146598:mdna:97]
[same as prior period, unchanged from 0001193125-18-023592:mdna:99]

[0001193125-18-146598:mdna:98]
On September 28,
2017, we entered into an Equity Commitment Letter (“ECL”) with a consortium of investors led by Bain Capital Private Equity for the acquisition of Toshiba Memory Corporation (“TMC”). The ECL contemplates that, upon the closing of
the acquisition, we or one of our subsidiaries would purchase up to JPY 139.5 billion (approximately USD 1.31 billion based on an exchange rate as of March 30, 2018), of a newly issued
non-convertible preferred stock of a newly formed company, K. K. Pangea, for the purpose of acquiring TMC. The closing of the acquisition is subject to regulatory approvals and other closing conditions.

[0001193125-18-146598:mdna:99]
As of March 30, 2018, we had a liability for unrecognized tax benefits and an accrual for the payment of related interest totaling
$8 million, none of which is expected to be settled within one year. Outside of one year, we are unable to make a reasonably reliable estimate of when cash settlement with a taxing authority will occur.

[0001193125-18-146598:mdna:100]
[same as prior period, unchanged from 0001193125-18-023592:mdna:102]

[0001193125-18-146598:mdna:101]
Our
discussion and analysis of financial condition and results of operations are based upon our condensed consolidated financial statements, which have been prepared in accordance with U.S. generally accepted accounting principles. The preparation of
such statements requires us to make estimates and assumptions that affect the reported amounts of revenues and expenses during the reporting period and the reported amounts of assets and liabilities as of the date of the financial statements. Our
estimates are based on historical experience and other assumptions that we consider to be appropriate in the circumstances. However, actual future results may vary from our estimates.

[0001193125-18-146598:mdna:102]
[same as prior period, unchanged from 0001193125-18-023592:mdna:104]

[0001193125-18-146598:mdna:103]
[same as prior period, unchanged from 0001193125-18-023592:mdna:105]

[0001193125-18-146598:mdna:104]
[same as prior period, unchanged from 0001193125-18-023592:mdna:106]
