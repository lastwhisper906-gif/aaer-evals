# STX notes — 0001193125-18-146598


## invest:InvestmentTableTextBlock

[0001193125-18-146598:notes:1]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of March 30, 2018:

[0001193125-18-146598:notes:2]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,261 |  |  | $ | — |  |  | $ | 1,261 |  |
| Time deposits and certificates of deposit |  | 292 |  |  | — |  |  | 292 |  |
| Total |  | $ | 1,553 |  |  | $ | — |  |  | $ | 1,553 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 1,549 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 4 |  |
| Total |  |  |  |  |  |  |  | $ | 1,553 |  |

[0001193125-18-146598:notes:3]
[same as prior period, unchanged from 0001193125-18-023592:notes:3]

[0001193125-18-146598:notes:4]
[same as prior period, unchanged from 0001193125-18-023592:notes:4]


## stx:ScheduleOfShareRepurchasesTableTextBlock

[0001193125-18-146598:notes:5]
The following table sets forth information with respect to repurchases of the Company’s shares during the nine months ended March 30, 2018:

[0001193125-18-146598:notes:6]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Repurchases of ordinary shares |  | 10 |  |  | $ | 361 |  |
| Tax withholding related to vesting of equity awards |  | 1 |  |  | 22 |  |
| Total |  | 11 |  |  | $ | 383 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-18-146598:notes:7]
[same as prior period, unchanged from 0001193125-18-023592:notes:7]

[0001193125-18-146598:notes:8]
[same as prior period, unchanged from 0001193125-18-023592:notes:8]

[0001193125-18-146598:notes:9]
[same as prior period, unchanged from 0001193125-18-023592:notes:9]

[0001193125-18-146598:notes:10]
[same as prior period, unchanged from 0001193125-18-023592:notes:10]

[0001193125-18-146598:notes:11]
[same as prior period, unchanged from 0001193125-18-023592:notes:11]

[0001193125-18-146598:notes:12]
[same as prior period, unchanged from 0001193125-18-023592:notes:12]

[0001193125-18-146598:notes:13]
[same as prior period, unchanged from 0001193125-18-023592:notes:13]

[0001193125-18-146598:notes:14]
[same as prior period, unchanged from 0001193125-18-023592:notes:14]


## us-gaap:CommitmentsDisclosureTextBlock

[0001193125-18-146598:notes:15]
[same as prior period, unchanged from 0001193125-18-023592:notes:15]

[0001193125-18-146598:notes:16]
Investment commitment to acquire interest in preferred stock. On September 28, 2017, the Company entered into an Equity Commitment Letter (“ECL”) with a consortium of investors led by Bain Capital Private Equity for the acquisition of Toshiba Memory Corporation (“TMC”). The ECL contemplates that, upon the closing of the acquisition, the Company or one of its subsidiaries would purchase up to JPY 139.5 billion (approximately USD 1.31 billion based on an exchange rate as of March 30, 2018), of a newly issued non-convertible preferred stock of a newly formed company, K. K. Pangea, for the purpose of acquiring TMC. The closing of the acquisition is subject to regulatory approvals and other closing conditions.


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-18-146598:notes:17]
[same as prior period, unchanged from 0001193125-18-023592:notes:17]

[0001193125-18-146598:notes:18]
[same as prior period, unchanged from 0001193125-18-023592:notes:18]

[0001193125-18-146598:notes:19]
The Company’s consolidated financial statements for the fiscal year ended June 30, 2017, are included in its Annual Report on Form 10-K as filed with the United States Securities and Exchange Commission (“SEC”) on August 4, 2017. The Company believes that the disclosures included in the unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of June 30, 2017, and the notes thereto, are adequate to make the information presented not misleading.


## us-gaap:DebtDisclosureTextBlock

[0001193125-18-146598:notes:20]
Debt

[0001193125-18-146598:notes:21]
Short-Term Borrowings

[0001193125-18-146598:notes:22]
The credit agreement entered into by the Company and its subsidiary Seagate HDD Cayman on January 18, 2011 and subsequently amended (the "Revolving Credit Facility") provides the Company with a $700 million senior secured revolving credit facility. The term of the Revolving Credit Facility is through January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Revolving Credit Facility) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. The loans made under the Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing, and for the issuance of letters of credit up to a sub-limit of $75 million.

[0001193125-18-146598:notes:23]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to allow for higher net leverage levels. The Company was in compliance with the modified covenants as of March 30, 2018 and expects to be in compliance for the next 12 months.

[0001193125-18-146598:notes:24]
As of March 30, 2018, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

[0001193125-18-146598:notes:25]
Long-Term Debt

[0001193125-18-146598:notes:26]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the three and nine months ended March 30, 2018, the Company repurchased $56 million and $206 million aggregate principal amount of the 2018 Notes, respectively, for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss of approximately $1 million and $3 million on repurchases during the three and nine months ended March 30, 2018, respectively, which is included in Other, net on the Condensed Consolidated Statements of Operations. The remainder of the 2018 Notes are classified as Current portion of long-term debt on the Company's Condensed Consolidated Balance Sheet at March 30, 2018.

[0001193125-18-146598:notes:27]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-146598:notes:28]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-146598:notes:29]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”). The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-146598:notes:30]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-146598:notes:31]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-146598:notes:32]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-146598:notes:33]
At March 30, 2018, future principal payments on long-term debt were as follows (in millions):

[0001193125-18-146598:notes:34]
| Fiscal Year |  | Amount |
| Remainder of 2018 |  | $ | — |  |
| 2019 |  | 504 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| 2022 |  | 750 |  |
| Thereafter |  | 3,613 |  |
| Total |  | $ | 4,867 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-18-146598:notes:35]
Derivative Financial Instruments

[0001193125-18-146598:notes:36]
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses denominated in foreign currencies. The Company's accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The changes in the fair value of the effective portions of designated cash flow hedges are recorded in Accumulated other comprehensive loss on the Condensed Consolidated Balance Sheets until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments and the ineffective portions of cash flow hedges are adjusted to fair value through earnings.

[0001193125-18-146598:notes:37]
The Company de-designates its cash flow hedges when the forecasted hedged transactions are realized or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss on the Condensed Consolidated Balance Sheets are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company did not recognize any net gains or losses related to the loss of hedge designation on discontinued cash flow hedges during the three and nine months ended March 30, 2018.

[0001193125-18-146598:notes:38]
As of March 30, 2018 and June 30, 2017, the Company had no outstanding foreign currency forward exchange contracts.

[0001193125-18-146598:notes:39]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plan—the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees. As of March 30, 2018, the notional investments underlying the TRS amounted to $113 million. The contract term of the TRS is through January 2019 and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001193125-18-146598:notes:40]
As of March 30, 2018 and June 30, 2017, the Company had no outstanding foreign currency forward exchange contracts and the gross fair value of the TRS reflected in the condensed consolidated balance sheets was immaterial.

[0001193125-18-146598:notes:41]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three and nine months ended March 30, 2018:

[0001193125-18-146598:notes:42]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain(Loss) Recognized inIncome on Derivatives |  | Amount of Gain(Loss) Recognized inIncome on Derivatives |
|  |  | For the Three Months | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | — |  | $ | — |  |
| Total return swap |  | Operating expenses |  | (2 | ) | 5 |  |

[0001193125-18-146598:notes:43]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three and nine months ended March 31, 2017:

[0001193125-18-146598:notes:44]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount ofGain (Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGain (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
|  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | $ | 1 |  |  | $ | (2 | ) |  | Cost of revenue |  | $ | (1 | ) |  | $ | (2 | ) |  | Cost of revenue |  | $ | — |  |  | $ | — |  |

[0001193125-18-146598:notes:45]
|  |  | Location of Gain (Loss) Recognized inIncome on Derivatives |  | Amount of Gain (Loss) Recognized inIncome on Derivatives |
| Derivatives Not Designated as Hedging Instruments |  |  | For the Three Months | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 4 |  | $ | 1 |  |
| Total return swap |  | Operating expenses |  | 4 |  | 8 |  |

[0001193125-18-146598:notes:46]
[same as prior period, unchanged from 0001193125-18-023592:notes:45]

[0001193125-18-146598:notes:47]
| (a) | The amount of gain (loss) recognized in income related to the ineffective portion of the hedging relationships and the amount excluded from the assessment of hedge effectiveness were less than $1 million for the three and nine months ended March 31, 2017, respectively. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-18-146598:notes:48]
[same as prior period, unchanged from 0001193125-18-023592:notes:47]

[0001193125-18-146598:notes:49]
The Company recorded approximately $26 million and $85 million of share-based compensation expense during the three and nine months ended March 30, 2018, respectively. The Company recorded approximately $37 million and $110 million of share-based compensation expense during the three and nine months ended March 31, 2017, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001193125-18-146598:notes:50]
[same as prior period, unchanged from 0001193125-18-023592:notes:49]

[0001193125-18-146598:notes:51]
Basic earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period. Diluted earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period and the number of additional shares that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding options, unvested restricted stock units and performance-based share units and shares to be purchased under the Employee Stock Purchase Plan ("ESPP"). The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in fair market value of the Company’s share price can result in a greater dilutive effect from potentially dilutive securities. The following table sets forth the computation of basic and diluted net income per share attributable to the shareholders of the Company:

[0001193125-18-146598:notes:52]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (In millions, except per share data) |  | March 30, 2018 |  | March 31, 2017 |  | March 30, 2018 |  | March 31, 2017 |
| Numerator: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 381 |  |  | $ | 194 |  |  | $ | 721 |  |  | $ | 658 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 286 |  |  | 296 |  |  | 288 |  |  | 297 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | 5 |  |  | 4 |  |  | 3 |  |  | 2 |  |
| Total shares for purpose of calculating diluted net income per share |  | 291 |  |  | 300 |  |  | 291 |  |  | 299 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.33 |  |  | $ | 0.66 |  |  | $ | 2.50 |  |  | $ | 2.22 |  |
| Diluted |  | $ | 1.31 |  |  | $ | 0.65 |  |  | $ | 2.48 |  |  | $ | 2.20 |  |

[0001193125-18-146598:notes:53]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share were approximately 1 million for the three and nine months ended March 30, 2018, and approximately 1 million and 2 million for the three and nine months ended March 31, 2017, respectively.


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001193125-18-146598:notes:54]
[same as prior period, unchanged from 0001193125-18-023592:notes:53]

[0001193125-18-146598:notes:55]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,260 |  |  | $ | 289 |  |  | $ | — |  |  | $ | 1,549 |  |
| Other current assets |  | 1 |  |  | 3 |  |  | — |  |  | 4 |  |
| Total assets |  | $ | 1,261 |  |  | $ | 292 |  |  | $ | — |  |  | $ | 1,553 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-18-146598:notes:56]
[same as prior period, unchanged from 0001193125-18-023592:notes:55]

[0001193125-18-146598:notes:57]
[same as prior period, unchanged from 0001193125-18-023592:notes:56]

[0001193125-18-146598:notes:58]
[same as prior period, unchanged from 0001193125-18-023592:notes:57]

[0001193125-18-146598:notes:59]
[same as prior period, unchanged from 0001193125-18-023592:notes:58]

[0001193125-18-146598:notes:60]
[same as prior period, unchanged from 0001193125-18-023592:notes:59]

[0001193125-18-146598:notes:61]
[same as prior period, unchanged from 0001193125-18-023592:notes:60]

[0001193125-18-146598:notes:62]
[same as prior period, unchanged from 0001193125-18-023592:notes:61]

[0001193125-18-146598:notes:63]
[same as prior period, unchanged from 0001193125-18-023592:notes:62]

[0001193125-18-146598:notes:64]
[same as prior period, unchanged from 0001193125-18-023592:notes:63]

[0001193125-18-146598:notes:65]
[same as prior period, unchanged from 0001193125-18-023592:notes:64]

[0001193125-18-146598:notes:66]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of March 30, 2018:

[0001193125-18-146598:notes:67]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,260 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,260 |  |
| Time deposits and certificates of deposit |  | — |  |  | 289 |  |  | — |  |  | 289 |  |
| Total cash equivalents |  | 1,260 |  |  | 289 |  |  | — |  |  | 1,549 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets |  | $ | 1,261 |  |  | $ | 292 |  |  | $ | — |  |  | $ | 1,553 |  |

[0001193125-18-146598:notes:68]
[same as prior period, unchanged from 0001193125-18-023592:notes:67]

[0001193125-18-146598:notes:69]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 593 |  |  | $ | — |  |  | $ | — |  |  | $ | 593 |  |
| Time deposits and certificates of deposit |  | — |  |  | 581 |  |  | — |  |  | 581 |  |
| Total cash equivalents |  | 593 |  |  | 581 |  |  | — |  |  | 1,174 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets |  | $ | 594 |  |  | $ | 584 |  |  | $ | — |  |  | $ | 1,178 |  |

[0001193125-18-146598:notes:70]
[same as prior period, unchanged from 0001193125-18-023592:notes:69]

[0001193125-18-146598:notes:71]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair value of all of its cash equivalents. For the cash equivalents and short-term investments in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry standard data providers or other third party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of March 30, 2018, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts and the TRS. The Company recognizes derivative financial instruments in its consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001193125-18-146598:notes:72]
As of March 30, 2018 and June 30, 2017, the Company had no Level 3 assets or liabilities measured at fair value on a recurring basis.

[0001193125-18-146598:notes:73]
[same as prior period, unchanged from 0001193125-18-023592:notes:72]

[0001193125-18-146598:notes:74]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments primarily include cost basis investments representing those where the Company does not have the ability to exercise significant influence as well as equity method investments representing those where the Company does have the ability to exercise significant influence but does not have control. These investments are included in Other assets, net in the Condensed Consolidated Balance Sheet, and are periodically analyzed to determine whether or not there are indicators of impairment. The carrying value of the Company’s strategic investments at March 30, 2018 and June 30, 2017 was $125 million at both dates, and consisted primarily of privately held equity securities without a readily determinable fair value.

[0001193125-18-146598:notes:75]
For the three and nine months ended March 30, 2018, the Company determined that a certain equity investment accounted for under the cost method was other-than-temporarily impaired and recorded a charge of $3 million in order to write down the carrying amount of the investment to its fair value. For the nine months ended March 31, 2017, the Company recognized an impairment charge of $25 million on a strategic investment. For the three months ended March 31, 2017, the Company did not record any impairment charges. Since there was no active market for the equity securities of the investee, the Company estimated fair value of the investee by analyzing the underlying cash flows and future prospects of the investee. These amounts were recorded in Other, net in the Condensed Consolidated Statements of Operations.

[0001193125-18-146598:notes:76]
As of June 30, 2017, the Company had $77 million of held for sale land and buildings (collectively, the "properties") primarily in Asia included in Other current assets on the Condensed Consolidated Balance Sheet. The respective properties to be sold met the criteria to be classified as held for sale during the quarters ended March 31, 2017 and June 30, 2017. Depreciation related to the properties ceased as of the date these were determined to be held for sale. During the fiscal year 2017, the Company recorded impairment charges of $35 million in order to write down the carrying amount of such properties to their estimated fair values less costs to sell. The impairment charges were recorded in Operating expenses in the Condensed Consolidated Statements of Operations. No additional impairment charges related to these properties were recorded during the three and nine months ended March 30, 2018. The fair values were measured with the assistance of third-party valuation models which used inputs such as comparable market data for similar land sale transactions adjusted for differences in comparable properties to derive the estimated fair value of the subject properties and the cost approach valuation techniques for buildings as part of the analysis. The fair value measurement was categorized as Level 3 as significant unobservable inputs were used in the valuation analysis. In the quarter ended March 30, 2018, the Company completed the sale of certain of these properties and recorded a gain of approximately $1 million, which was included in Restructuring and other, net in the Condensed Consolidated Statements of Operations. As of March 30, 2018, the Company had $36 million of properties that continued to be included in Other current assets on the Condensed Consolidated Balance Sheet.

[0001193125-18-146598:notes:77]
[same as prior period, unchanged from 0001193125-18-023592:notes:76]

[0001193125-18-146598:notes:78]
[same as prior period, unchanged from 0001193125-18-023592:notes:77]

[0001193125-18-146598:notes:79]
|  |  | March 30, 2018 |  | June 30, 2017 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 504 |  |  | $ | 507 |  |  | $ | 710 |  |  | $ | 726 |  |
| 4.25% Senior Notes due March 2022 |  | 749 |  |  | 741 |  |  | 748 |  |  | 765 |  |
| 4.75% Senior Notes due June 2023 |  | 951 |  |  | 954 |  |  | 951 |  |  | 987 |  |
| 4.875% Senior Notes due March 2024 |  | 497 |  |  | 498 |  |  | 497 |  |  | 511 |  |
| 4.75% Senior Notes due January 2025 |  | 975 |  |  | 953 |  |  | 975 |  |  | 984 |  |
| 4.875% Senior Notes due June 2027 |  | 695 |  |  | 660 |  |  | 695 |  |  | 698 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 467 |  |  | 489 |  |  | 488 |  |
|  |  | $ | 4,860 |  |  | $ | 4,780 |  |  | $ | 5,065 |  |  | $ | 5,159 |  |
| Less: debt issuance costs |  | (38 | ) |  | — |  |  | (44 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 4,822 |  |  | $ | 4,780 |  |  | $ | 5,021 |  |  | $ | 5,159 |  |
| Less: current portion of long-term debt, net of debt issuance costs of $1 million |  | (503 | ) |  | (507 | ) |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 4,319 |  |  | $ | 4,273 |  |  | $ | 5,021 |  |  | $ | 5,159 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-18-146598:notes:80]
Goodwill and Other Intangible Assets

[0001193125-18-146598:notes:81]
Goodwill

[0001193125-18-146598:notes:82]
The changes in the carrying amount of goodwill for the nine months ended March 30, 2018, are as follows:

[0001193125-18-146598:notes:83]
| (Dollars in millions) |  | Amount |
| Balance at June 30, 2017 |  | $ | 1,238 |  |
| Goodwill acquired |  | — |  |
| Goodwill disposed |  | (1 | ) |
| Foreign currency translation effect |  | 1 |  |
| Balance at March 30, 2018 |  | $ | 1,238 |  |

[0001193125-18-146598:notes:84]
[same as prior period, unchanged from 0001193125-18-023592:notes:82]

[0001193125-18-146598:notes:85]
[same as prior period, unchanged from 0001193125-18-023592:notes:83]

[0001193125-18-146598:notes:86]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of March 30, 2018, is set forth in the following table:

[0001193125-18-146598:notes:87]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted-AverageRemaining Useful Life |
| Existing technology |  | $ | 279 |  |  | $ | (153 | ) |  | $ | 126 |  |  | 2.7 years |
| Customer relationships |  | 89 |  |  | (39 | ) |  | 50 |  |  | 4.2 years |
| Trade name |  | 17 |  |  | (12 | ) |  | 5 |  |  | 1.5 years |
| Other intangible assets |  | 40 |  |  | (17 | ) |  | 23 |  |  | 2.5 years |
| Total amortizable other intangible assets |  | $ | 425 |  |  | $ | (221 | ) |  | $ | 204 |  |  | 3.0 years |

[0001193125-18-146598:notes:88]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of June 30, 2017, is set forth in the following table:

[0001193125-18-146598:notes:89]
[same as prior period, unchanged from 0001193125-18-023592:notes:87]

[0001193125-18-146598:notes:90]
For the three and nine months ended March 30, 2018, the amortization expense of other intangible assets were $21 million and $90 million, respectively. For the three and nine months ended March 31, 2017, the amortization expense of other intangible assets was $42 million and $126 million, respectively. As of March 30, 2018, expected amortization expense for other intangible assets for each of the next five fiscal years and thereafter is as follows:

[0001193125-18-146598:notes:91]
| (Dollars in millions) |  | Amount |
| Remainder of 2018 |  | $ | 21 |  |
| 2019 |  | 76 |  |
| 2020 |  | 52 |  |
| 2021 |  | 24 |  |
| 2022 |  | 16 |  |
| Thereafter |  | 15 |  |
| Total |  | $ | 204 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-18-146598:notes:92]
[same as prior period, unchanged from 0001193125-18-023592:notes:90]

[0001193125-18-146598:notes:93]
The Company recorded income tax provisions of $12 million and $231 million in the three and nine months ended March 30, 2018, respectively. The income tax provision for the three and nine months ended March 30, 2018 included approximately $2 million of net discrete tax benefit and approximately $195 million of net discrete expense, respectively. The discrete items for the nine months ended March 30, 2018 are primarily associated with the revaluation of U.S. deferred tax assets as a result of the enactment of the Act on December 22, 2017, partially offset by the recognition of previously unrecognized tax benefits associated with the expiration of certain statutes of limitation.

[0001193125-18-146598:notes:94]
The Company's income tax provision recorded for the three and nine months ended March 30, 2018 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a reduction in the net U.S. deferred tax assets associated with revaluation to a lower U.S. tax rate.

[0001193125-18-146598:notes:95]
During the nine months ended March 30, 2018, the Company’s unrecognized tax benefits excluding interest and penalties decreased by approximately $15 million to $59 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $59 million at March 30, 2018, subject to certain future changes in valuation allowance. During the twelve months beginning March 31, 2018, the Company expects that its unrecognized tax benefits could be reduced by approximately $19 million, primarily as a result of the expiration of certain statutes of limitation.

[0001193125-18-146598:notes:96]
The Company recorded an income tax provision of $18 million and $37 million in the three and nine months ended March 31, 2017, respectively. The income tax provision for the three and nine months ended March 31, 2017 included approximately $8 million of net discrete tax expense and approximately $3 million of net discrete tax expense, respectively. The discrete items are primarily associated with changes in valuation allowances offset by release of tax reserves due to the expiration of certain statutes of limitation and prior year tax adjustments.

[0001193125-18-146598:notes:97]
The Company’s income tax provision recorded for the three and nine months ended March 31, 2017 differed from the provision from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) restructuring expenses with no associated tax benefits, and (iii) a net decrease in valuation allowance for certain deferred tax assets.

[0001193125-18-146598:notes:98]
The Act significantly revised U.S. corporate income tax law by, among other things, lowering U.S. corporate income tax rates from 35% to 21%, implementing a territorial tax system and imposing a tax on deemed repatriated earnings of non-U.S. subsidiaries. The Act’s new international rules, including the Global Intangible Low-Taxed Income, the Foreign Derived Intangible Income and the Base Erosion Anti-Avoidance Tax, are not expected to have a material impact on the Company’s financial statements.  However, these assessments are based on preliminary review and analysis of the Act and are subject to change as the Company continues to evaluate these highly complex rules as additional interpretive guidance is issued.

[0001193125-18-146598:notes:99]
Pursuant to SEC Staff Accounting Bulletin (SAB) 118 (regarding the application of ASC 740 associated with the enactment of the Act), the Company recorded an adjusted provisional tax expense of approximately $4 million and $212 million for the three and nine months ended March 30, 2018, respectively, to re-measure its U.S. deferred tax assets at the newly enacted 21% tax rate. The tax expense remains provisional because the Company continues to evaluate the impact of various domestic and international provisions of the Act as well as the impact of additional guidance that may be provided. This provisional tax expense increased the Company’s effective tax rate for the three and nine months ended March 30, 2018 to approximately 3% and 24%, respectively. The other U.S. tax changes are not expected to impact the Company’s tax expense in the short-term due the Company’s large net operating loss and tax credit carryovers.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-18-146598:notes:100]
The fair value and amortized cost of the Company’s investments classified as available-for-sale as of March 30, 2018, by remaining contractual maturity were as follows:

[0001193125-18-146598:notes:101]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 1,553 |  |  | $ | 1,553 |  |
| Due in 1 to 5 years |  | — |  |  | — |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | — |  |  | — |  |
| Total |  | $ | 1,553 |  |  | $ | 1,553 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001193125-18-146598:notes:102]
Legal, Environmental and Other Contingencies

[0001193125-18-146598:notes:103]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001193125-18-146598:notes:104]
Intellectual Property Litigation

[0001193125-18-146598:notes:105]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al. On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “‘635 patent”) and U.S. Patent No. 5,638,267 (the “‘267 patent”), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe U.S. Patent No. 6,314,473 (the “‘473 patent”). The district court ruled in 2010 that the ‘267 patent was out of the case.

[0001193125-18-146598:notes:106]
On August 16, 2011, the district court granted in part and denied in part the Company’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-18-146598:notes:107]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al. On June 5, 2013, Enova Technology Corporation (“Enova”) filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995 (the “‘995 patent”), “Cryptographic Device,” and U.S. Patent No. 7,900,057 (the “‘057 patent”), “Cryptographic Serial ATA Apparatus and Method.” The Company believes the claims are without merit and intends to vigorously defend this case. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the ‘995 and ‘057 patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ‘057 patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 patent are held unpatentable. Enova appealed PTAB’s decisions on the ‘995 patent and the ‘057 patent to the U.S. Court of Appeals for the Federal Circuit. On March 20, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the ‘995 patent. On September 6, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the ‘057 patent. On November 27, 2017, Enova filed a petition for writ of certiorari with the U.S. Supreme Court challenging the court of appeals’ decision on the ‘057 Patent. The Supreme Court denied the petition on April 30, 2018. The district court case remains stayed. In light of the Supreme Court’s denial of the petition, the Company does not expect to incur a loss in this matter.

[0001193125-18-146598:notes:108]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017.  No trial date has been set. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-18-146598:notes:109]
Environmental Matters

[0001193125-18-146598:notes:110]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001193125-18-146598:notes:111]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001193125-18-146598:notes:112]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001193125-18-146598:notes:113]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001193125-18-146598:notes:114]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001193125-18-146598:notes:115]
Other Matters

[0001193125-18-146598:notes:116]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-18-146598:notes:117]
Recently Issued Accounting Pronouncements

[0001193125-18-146598:notes:118]
In May 2014, August 2015, April 2016, May 2016 and December 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update ("ASU") 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, ASU 2016-12 (ASC Topic 606) Revenue from Contracts with Customers, Narrow-Scope Improvements and Practical Expedients, and ASU 2016-20 (ASC Topic 606) Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company is required to adopt the guidance in the first quarter of fiscal year 2019. This standard may be applied retrospectively to all prior periods presented, or retrospectively with a cumulative adjustment to retained earnings in the year of adoption (“modified retrospective transition approach”). Based on its assessment, the Company plans to adopt the new revenue standard in the first quarter of fiscal year 2019, utilizing the modified retrospective method of transition. While management has not yet completed its assessment of the impact of adopting this new standard on the Company’s consolidated financial statements, the Company expects the adoption of the new standard will result in the recognition of revenue generally upon shipment (sell-in basis) for sales of products to certain direct retail customers and customers in certain indirect retail channels which are currently being recognized on a sell-through basis. Accordingly, the Company will need to estimate variable consideration (e.g. rebates) related to customer incentives on these arrangements. These changes are not expected to have a material impact on the Company’s condensed consolidated financial statements.

[0001193125-18-146598:notes:119]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments—Overall Recognition and Measurement of Financial Assets and Financial Liabilities, as amended by ASU 2018-03, Financial Instruments—Overall: Technical Correction and Improvements, issued in February 2018. The amendments in these ASUs require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The Company is required to adopt the guidance in the first quarter of fiscal year 2019. Early adoption is permitted for only certain portions of the ASU. The Company expects to elect the measurement alternative for measurement of equity investments, defined as cost, less impairments, if any, plus or minus changes resulting from observable price changes in orderly transactions for an identical or similar investment in the same issuer (the "Price Changes") until the equity investments' fair value becomes readily determinable. The amount of the impact to equity investments will depend on any Price Changes observed after adoption in the first quarter of fiscal year 2019.

[0001193125-18-146598:notes:120]
In February 2016, the FASB issued ASU 2016-02 (ASC Topic 842), Leases. This ASU amends a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The Company is required to adopt this guidance in the first quarter of fiscal year 2020. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-18-146598:notes:121]
In June 2016, the FASB issued ASU 2016-13 (ASC Topic 326), Financial Instruments - Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held. The Company is required to adopt this guidance in the first quarter of fiscal year 2021. Early adoption in the first quarter of fiscal year 2020 is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-18-146598:notes:122]
In January 2017, the FASB issued ASU 2017-01 (ASC Topic 805), Business Combination: Clarifying the Definition of a Business. The amendments in this ASU change the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company plans to adopt the guidance in the first quarter of fiscal year 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-18-146598:notes:123]
In May 2017, the FASB issued ASU 2017-09 (ASC Topic 718), Stock Compensation: Scope of Modification Accounting. The amendments in this ASU provide guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting. The Company plans to adopt the guidance in the first quarter of fiscal year 2019. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-18-146598:notes:124]
In August 2017, the FASB issued ASU 2017-12 (ASC Topic 815), Derivatives and Hedging: Targeted Improvements to Accounting for Hedging Activities. The amendments in this ASU were issued to simplify existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. The amended guidance will eliminate the separate measurement and presentation of hedge ineffectiveness. The Company is required to adopt the guidance in the first quarter of fiscal year 2020. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-18-146598:notes:125]
In February 2018, the FASB issued ASU 2018-02 (ASC Topic 220), Income Statement—Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 (the "Act") and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Act. The Company is required to adopt the guidance in the first quarter of fiscal year 2020.  Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-18-146598:notes:126]
Recently Adopted Accounting Pronouncements

[0001193125-18-146598:notes:127]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. This ASU became effective and was adopted by the Company in the September 2017 quarter on a prospective basis. The adoption of this guidance had no material impact on the Company’s condensed consolidated financial statements and disclosures.

[0001193125-18-146598:notes:128]
In March 2016, the FASB issued ASU 2016-09 (ASC Topic 718), Stock Compensation—Improvements to Employee Share-Based Payment Accounting. The amendments in this ASU are intended to simplify several areas of accounting for share-based compensation arrangements, including the income tax consequences, classification on the consolidated statement of cash flows and treatment of forfeitures. This ASU became effective and was adopted by the Company in the September 2017 quarter. Upon adoption, excess tax benefits or deficiencies from share-based award activity are reflected in the condensed consolidated statements of operations as a component of the provision for income taxes, whereas they previously were recognized in the Shareholder's equity in the condensed consolidated balance sheets. The Company also elected to continue to account for share-based compensation expense net of estimated forfeitures. The adoption of this ASU resulted in an increase in deferred tax assets relating to net operating losses of approximately $0.6 billion, offset by an equivalent increase in the valuation allowance with no impact to retained earnings. The adoption of this guidance had no material impact on the Company’s condensed consolidated financial statements and disclosures.

[0001193125-18-146598:notes:129]
In October 2016, the FASB issued ASU 2016-16 (ASC Topic 740), Income Taxes: Intra-Entity Transfers of Assets Other Than Inventory. The amendments in this ASU require the recognition of the income tax consequences for intra-entity transfers of assets other than inventory when the transfer occurs. The Company elected to adopt this ASU in the September 2017 quarter on a modified retrospective basis with no material impact on the Company's condensed consolidated financial statements and disclosures.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001193125-18-146598:notes:130]
[same as prior period, unchanged from 0001193125-18-023592:notes:125]

[0001193125-18-146598:notes:131]
[same as prior period, unchanged from 0001193125-18-023592:notes:126]

[0001193125-18-146598:notes:132]
[same as prior period, unchanged from 0001193125-18-023592:notes:127]

[0001193125-18-146598:notes:133]
[same as prior period, unchanged from 0001193125-18-023592:notes:128]

[0001193125-18-146598:notes:134]
[same as prior period, unchanged from 0001193125-18-023592:notes:129]

[0001193125-18-146598:notes:135]
[same as prior period, unchanged from 0001193125-18-023592:notes:130]

[0001193125-18-146598:notes:136]
[same as prior period, unchanged from 0001193125-18-023592:notes:131]

[0001193125-18-146598:notes:137]
The results of operations for the three and nine months ended March 30, 2018 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending June 29, 2018. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three and nine months ended March 30, 2018 and the three and nine months ended March 31, 2017 consisted of 13 weeks and 39 weeks, respectively. Fiscal year 2018, which ends on June 29, 2018, and fiscal year 2017, which ended on June 30, 2017, are both comprised of 52 weeks. The fiscal quarters ended March 30, 2018, December 29, 2017, and March 31, 2017, are also referred to herein as the “March 2018 quarter”, the “December 2017 quarter”, and the “March 2017 quarter”, respectively.

[0001193125-18-146598:notes:138]
[same as prior period, unchanged from 0001193125-18-023592:notes:133]

[0001193125-18-146598:notes:139]
There have been no significant changes in the Company's significant accounting policies. Please refer to Note 1 of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2017, as filed with the SEC on August 4, 2017 for a discussion of the Company’s significant accounting policies.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-18-146598:notes:140]
[same as prior period, unchanged from 0001193125-18-023592:notes:135]

[0001193125-18-146598:notes:141]
[same as prior period, unchanged from 0001193125-18-023592:notes:136]

[0001193125-18-146598:notes:142]
[same as prior period, unchanged from 0001193125-18-023592:notes:137]

[0001193125-18-146598:notes:143]
[same as prior period, unchanged from 0001193125-18-023592:notes:138]

[0001193125-18-146598:notes:144]
[same as prior period, unchanged from 0001193125-18-023592:notes:139]

[0001193125-18-146598:notes:145]
[same as prior period, unchanged from 0001193125-18-023592:notes:140]

[0001193125-18-146598:notes:146]
[same as prior period, unchanged from 0001193125-18-023592:notes:141]

[0001193125-18-146598:notes:147]
[same as prior period, unchanged from 0001193125-18-023592:notes:142]

[0001193125-18-146598:notes:148]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the three and nine months ended March 30, 2018 and March 31, 2017 were as follows:

[0001193125-18-146598:notes:149]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 30, 2018 |  | March 31, 2017 |  | March 30, 2018 |  | March 31, 2017 |
| Balance, beginning of period |  | $ | 236 |  |  | $ | 222 |  |  | $ | 233 |  |  | $ | 206 |  |
| Warranties issued |  | 36 |  |  | 32 |  |  | 111 |  |  | 97 |  |
| Repairs and replacements |  | (26 | ) |  | (28 | ) |  | (80 | ) |  | (87 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | (11 | ) |  | (3 | ) |  | (29 | ) |  | 7 |  |
| Balance, end of period |  | $ | 235 |  |  | $ | 223 |  |  | $ | 235 |  |  | $ | 223 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-18-146598:notes:150]
[same as prior period, unchanged from 0001193125-18-023592:notes:145]

[0001193125-18-146598:notes:151]
| (Dollars in millions) |  | March 30, 2018 |  | June 30, 2017 |
| Property, equipment and leasehold improvements |  | $ | 9,436 |  |  | $ | 9,633 |  |
| Accumulated depreciation and amortization |  | (7,716 | ) |  | (7,758 | ) |
| Property, equipment and leasehold improvements, net |  | $ | 1,720 |  |  | $ | 1,875 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-18-146598:notes:152]
[same as prior period, unchanged from 0001193125-18-023592:notes:147]

[0001193125-18-146598:notes:153]
For the three and nine months ended March 30, 2018, the Company recorded restructuring charges of approximately $11 million and $95 million, respectively, comprised primarily of charges related to workforce reduction costs and facilities and other exit costs associated with the restructuring of its workforce during the fiscal year. The Company's significant restructuring plans are described below. All restructuring charges are reported in Restructuring and other, net on the Condensed Consolidated Statements of Operations.

[0001193125-18-146598:notes:154]
[same as prior period, unchanged from 0001193125-18-023592:notes:149]

[0001193125-18-146598:notes:155]
[same as prior period, unchanged from 0001193125-18-023592:notes:150]

[0001193125-18-146598:notes:156]
[same as prior period, unchanged from 0001193125-18-023592:notes:151]

[0001193125-18-146598:notes:157]
[same as prior period, unchanged from 0001193125-18-023592:notes:152]

[0001193125-18-146598:notes:158]
In addition, during fiscal year 2017, the Company committed to sell certain land and buildings primarily in Asia as part of the March 2017 and July 2016 plans, which accordingly met the criteria to be classified as assets held for sale and were reclassified to Other current assets on the Condensed Consolidated Balance Sheets at that time. During the quarter ended March 30, 2018, the Company sold certain of these properties, which were previously classified as assets held for sale and recognized a gain of approximately $1 million, which was included in Restructuring and other, net in the Condensed Consolidated Statements of Operations. See Note 9. Fair Value for additional information.

[0001193125-18-146598:notes:159]
The Company’s restructuring activity for the three and nine months ended March 30, 2018 is summarized as follows:

[0001193125-18-146598:notes:160]
|  |  | December 2017 Plan |  | July 2017 Plan |  | March 2017 Plan |  | July 2016 Plan |  | Other Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at June 30, 2017 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 22 |  |  | $ | 2 |  |  | $ | 6 |  |  | $ | 13 |  |  | $ | 43 |  |
| Restructuring charges |  | 27 |  |  | 4 |  |  | 38 |  |  | 4 |  |  | — |  |  | — |  |  | 1 |  |  | 12 |  |  | 2 |  |  | — |  |  | 88 |  |
| Cash payments |  | (18 | ) |  | (1 | ) |  | (37 | ) |  | (3 | ) |  | (1 | ) |  | — |  |  | (21 | ) |  | (13 | ) |  | (8 | ) |  | (2 | ) |  | (104 | ) |
| Adjustments |  | (2 | ) |  | — |  |  | (1 | ) |  | — |  |  | 2 |  |  | — |  |  | 2 |  |  | (1 | ) |  | — |  |  | 7 |  |  | 7 |  |
| Accrual balances at March 30, 2018 |  | $ | 7 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | — |  |  | $ | 18 |  |  | $ | 34 |  |
| Total costs incurred to date as of March 30, 2018 |  | $ | 25 |  |  | $ | 4 |  |  | $ | 37 |  |  | $ | 4 |  |  | $ | 31 |  |  | $ | 3 |  |  | $ | 82 |  |  | $ | 31 |  |  | $ | 228 |  |  | $ | 58 |  |  | $ | 503 |  |
| Total expected charges to be incurred as of March 30, 2018 |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 4 |  |
| Restructuring charges for the three months ended March 30, 2018 |  | $ | (2 | ) |  | $ | 4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 7 |  |  | $ | 11 |  |


## us-gaap:ScheduleOfAccountsPayableAndAccruedLiabilitiesTableTextBlock

[0001193125-18-146598:notes:161]
[same as prior period, unchanged from 0001193125-18-023592:notes:155]

[0001193125-18-146598:notes:162]
| (Dollars in millions) |  | March 30, 2018 |  | June 30, 2017 |
| Dividends payable |  | $ | 181 |  |  | $ | 184 |  |
| Other accrued expenses |  | 428 |  |  | 466 |  |
| Total accrued expenses |  | $ | 609 |  |  | $ | 650 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-18-146598:notes:163]
[same as prior period, unchanged from 0001193125-18-023592:notes:157]

[0001193125-18-146598:notes:164]
| (Dollars in millions) |  | Unrealized Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Marketable Securities |  | Unrealized Gains (Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at June 30, 2017 |  | $ | — |  |  | $ | — |  |  | $ | (5 | ) |  | $ | (12 | ) |  | $ | (17 | ) |
| Other comprehensive income (loss) before reclassifications |  | — |  |  | — |  |  | — |  |  | 9 |  |  | 9 |  |
| Amounts reclassified from AOCI |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) |  | — |  |  | — |  |  | — |  |  | 9 |  |  | 9 |  |
| Balance at March 30, 2018 |  | $ | — |  |  | $ | — |  |  | $ | (5 | ) |  | $ | (3 | ) |  | $ | (8 | ) |
| Balance at July 1, 2016 |  | $ | (1 | ) |  | $ | — |  |  | $ | (7 | ) |  | $ | (17 | ) |  | $ | (25 | ) |
| Other comprehensive income (loss) before reclassifications |  | (2 | ) |  | — |  |  | — |  |  | (3 | ) |  | (5 | ) |
| Amounts reclassified from AOCI |  | 2 |  |  | — |  |  | 1 |  |  | — |  |  | 3 |  |
| Other comprehensive income (loss) |  | — |  |  | — |  |  | 1 |  |  | (3 | ) |  | (2 | ) |
| Balance at March 31, 2017 |  | $ | (1 | ) |  | $ | — |  |  | $ | (6 | ) |  | $ | (20 | ) |  | $ | (27 | ) |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-18-146598:notes:165]
[same as prior period, unchanged from 0001193125-18-023592:notes:159]

[0001193125-18-146598:notes:166]
| (Dollars in millions) |  | March 30, 2018 |  | June 30, 2017 |
| Raw materials and components |  | $ | 308 |  |  | $ | 350 |  |
| Work-in-process |  | 322 |  |  | 257 |  |
| Finished goods |  | 372 |  |  | 375 |  |
| Total inventories |  | $ | 1,002 |  |  | $ | 982 |  |


## us-gaap:ScheduleOfRestrictedCashAndCashEquivalentsTextBlock

[0001193125-18-146598:notes:167]
[same as prior period, unchanged from 0001193125-18-023592:notes:161]

[0001193125-18-146598:notes:168]
| (Dollars in millions) |  | March 30, 2018 |  | June 30, 2017 |  | March 31, 2017 |  | July 1, 2016 |
| Cash and cash equivalents |  | $ | 2,926 |  |  | $ | 2,539 |  |  | $ | 3,026 |  |  | $ | 1,125 |  |
| Restricted cash included in Other current assets |  | 4 |  |  | 4 |  |  | 5 |  |  | 7 |  |
| Total cash, cash equivalents, and restricted cash shown in the Statements of Cash Flows |  | $ | 2,930 |  |  | $ | 2,543 |  |  | $ | 3,031 |  |  | $ | 1,132 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-18-146598:notes:169]
[same as prior period, unchanged from 0001193125-18-023592:notes:163]

[0001193125-18-146598:notes:170]
[same as prior period, unchanged from 0001193125-18-023592:notes:164]

[0001193125-18-146598:notes:171]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 287,026,396 shares were outstanding as of March 30, 2018, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of March 30, 2018.

[0001193125-18-146598:notes:172]
[same as prior period, unchanged from 0001193125-18-023592:notes:166]

[0001193125-18-146598:notes:173]
[same as prior period, unchanged from 0001193125-18-023592:notes:167]

[0001193125-18-146598:notes:174]
[same as prior period, unchanged from 0001193125-18-023592:notes:168]

[0001193125-18-146598:notes:175]
[same as prior period, unchanged from 0001193125-18-023592:notes:169]

[0001193125-18-146598:notes:176]
[same as prior period, unchanged from 0001193125-18-023592:notes:170]

[0001193125-18-146598:notes:177]
[same as prior period, unchanged from 0001193125-18-023592:notes:171]

[0001193125-18-146598:notes:178]
As of March 30, 2018, $0.9 billion remained available for repurchase under the existing repurchase authorization limit.


## us-gaap:SubsequentEventsTextBlock

[0001193125-18-146598:notes:179]
Subsequent Events

[0001193125-18-146598:notes:180]
Dividend Declared

[0001193125-18-146598:notes:181]
On May 1, 2018, the Company’s Board of Directors declared a quarterly cash dividend of $0.63 per share, which will be payable on July 5, 2018 to shareholders of record as of the close of business on June 20, 2018.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-18-146598:notes:182]
[same as prior period, unchanged from 0001193125-18-023592:notes:176]

[0001193125-18-146598:notes:183]
[same as prior period, unchanged from 0001193125-18-023592:notes:177]

[0001193125-18-146598:notes:184]
As of March 30, 2018, the Company’s Other current assets included $4 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001193125-18-146598:notes:185]
As of March 30, 2018, the Company had no material available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale securities were other-than-temporarily impaired as of March 30, 2018.

[0001193125-18-146598:notes:186]
[same as prior period, unchanged from 0001193125-18-023592:notes:180]

[0001193125-18-146598:notes:187]
[same as prior period, unchanged from 0001193125-18-023592:notes:181]

[0001193125-18-146598:notes:188]
[same as prior period, unchanged from 0001193125-18-023592:notes:182]

[0001193125-18-146598:notes:189]
[same as prior period, unchanged from 0001193125-18-023592:notes:183]

[0001193125-18-146598:notes:190]
[same as prior period, unchanged from 0001193125-18-023592:notes:184]

[0001193125-18-146598:notes:191]
[same as prior period, unchanged from 0001193125-18-023592:notes:185]

[0001193125-18-146598:notes:192]
[same as prior period, unchanged from 0001193125-18-023592:notes:186]
