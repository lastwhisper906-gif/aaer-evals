# STX 8-K — 0001193125-18-145112 filed 2018-05-01

## item codes, every 8-K on or before 2018-05-01

- 2018-05-01 0001193125-18-145112 — 2.02, 7.01, 9.01
- 2018-01-29 0001193125-18-022528 — 2.02, 7.01, 9.01
- 2018-01-25 0001193125-18-019820 — 5.02, 9.01
- 2018-01-09 0001137789-18-000009 — 2.02, 7.01, 9.01
- 2018-01-08 0001137789-18-000004 — 2.02, 7.01, 9.01
- 2017-12-11 0001137789-17-000101 — 2.05
- 2017-10-23 0001193125-17-316068 — 2.02, 7.01, 9.01
- 2017-10-18 0001137789-17-000068 — 5.02, 5.07, 9.01
- 2017-09-28 0001137789-17-000060 — 1.01
- 2017-07-28 0001137789-17-000046 — 5.02
- 2017-07-25 0001193125-17-234440 — 2.02, 2.05, 5.02, 7.01, 9.01
- 2017-06-02 0001193125-17-192960 — 5.02
- 2017-04-26 0001193125-17-138005 — 2.02, 7.01, 9.01
- 2017-03-10 0001193125-17-077510 — 2.05
- 2017-02-03 0001104659-17-006357 — 1.01, 2.03, 9.01
- 2017-01-31 0001104659-17-005357 — 8.01, 9.01
- 2017-01-31 0001104659-17-005173 — 8.01, 9.01
- 2017-01-27 0001104659-17-004448 — 8.01
- 2017-01-24 0001193125-17-016690 — 2.02, 7.01, 9.01
- 2017-01-20 0001193125-17-013685 — 5.02, 9.01
- 2016-10-24 0001104659-16-151422 — 5.02, 5.03, 5.07, 9.01
- 2016-10-19 0001193125-16-741277 — 2.02, 7.01, 9.01
- 2016-10-11 0001193125-16-734835 — 2.02, 9.01
- 2016-10-04 0001104659-16-148575 — 5.02
- 2016-09-27 0001104659-16-146813 — 5.02
- 2016-08-02 0001104659-16-135908 — 2.02, 7.01, 9.01
- 2016-07-28 0001104659-16-135046 — 5.02
- 2016-07-11 0001104659-16-131996 — 2.02, 2.05, 9.01
- 2016-07-08 0001104659-16-131749 — 5.02
- 2016-06-29 0001104659-16-130122 — 2.05
- 2016-06-27 0001104659-16-129505 — 5.02
- 2016-04-29 0001104659-16-115593 — 2.02, 7.01, 9.01
- 2016-04-13 0001104659-16-111266 — 2.02, 9.01
- 2016-01-29 0001104659-16-092323 — 2.02, 7.01, 9.01
- 2016-01-04 0001104659-16-087730 — 5.02, 9.01
- 2015-10-30 0001104659-15-074350 — 2.02, 7.01, 9.01
- 2015-10-21 0001104659-15-071908 — 5.02, 9.01
- 2015-10-21 0001104659-15-071906 — 5.07, 7.01, 9.01
- 2015-10-15 0001104659-15-070776 — 2.02, 9.01
- 2015-09-21 0001104659-15-066273 — 5.02
- 2015-09-10 0001104659-15-064389 — 2.05
- 2015-08-06 0001104659-15-057159 — 5.02
- 2015-07-31 0001104659-15-055040 — 2.02, 7.01, 9.01
- 2015-07-22 0001104659-15-052507 — 5.02, 9.01
- 2015-07-13 0001104659-15-050755 — 2.02, 9.01
- 2015-05-14 0001104659-15-038166 — 1.01, 2.03, 9.01
- 2015-05-12 0001104659-15-036968 — 8.01, 9.01
- 2015-05-11 0001104659-15-036533 — 8.01, 9.01
- 2015-05-01 0001104659-15-033202 — 5.02
- 2015-04-23 0001104659-15-029483 — 8.01, 9.01
- 2015-04-17 0001104659-15-028152 — 2.02, 7.01, 9.01
- 2015-04-07 0001104659-15-026148 — 7.01
- 2015-01-26 0001104659-15-004316 — 2.02, 7.01, 9.01
- 2015-01-16 0001104659-15-002732 — 1.01, 9.01
- 2015-01-02 0001104659-15-000147 — 8.01
- 2014-12-02 0001104659-14-084370 — 1.01, 2.03, 9.01
- 2014-11-25 0001104659-14-083066 — 8.01, 9.01
- 2014-11-24 0001104659-14-082837 — 8.01, 9.01
- 2014-10-27 0001104659-14-073832 — 2.02, 7.01, 9.01
- 2014-10-24 0001104659-14-073609 — 5.02, 5.07, 9.01
- 2014-10-22 0001104659-14-073104 — 7.01, 9.01
- 2014-10-08 0001104659-14-070767 — 8.01
- 2014-09-12 0001104659-14-066107 — 5.02
- 2014-09-12 0001104659-14-066101 — 7.01
- 2014-07-23 0001104659-14-052995 — 5.02
- 2014-07-17 0001104659-14-052019 — 2.02, 7.01, 9.01
- 2014-06-18 0001104659-14-046714 — 8.01, 9.01
- 2014-06-09 0001104659-14-044575 — 7.01
- 2014-06-04 0001104659-14-043897 — 8.01
- 2014-05-28 0001104659-14-041862 — 1.01, 2.03, 8.01, 9.01
- 2014-05-20 0001104659-14-040454 — 8.01, 9.01
- 2014-05-20 0001104659-14-040220 — 8.01, 9.01
- 2014-04-29 0001104659-14-031916 — 2.02, 7.01, 9.01
- 2014-04-22 0001104659-14-029197 — 5.02
- 2014-02-24 0001104659-14-012465 — 5.02, 7.01, 9.01
- 2014-01-27 0001104659-14-004298 — 2.02, 7.01, 9.01
- 2014-01-23 0001104659-14-003803 — 5.02
- 2013-12-23 0001104659-13-091738 — 1.01, 8.01, 9.01
- 2013-11-05 0001104659-13-081194 — 1.01, 2.03, 9.01
- 2013-11-04 0001104659-13-080161 — 5.02, 5.03, 5.07, 9.01
- 2013-10-31 0001104659-13-079635 — 8.01, 9.01
- 2013-10-31 0001104659-13-079438 — 8.01, 9.01
- 2013-10-28 0001104659-13-078341 — 2.02, 7.01, 9.01
- 2013-10-28 0001104659-13-078316 — 5.02, 7.01, 9.01
- 2013-10-08 0001104659-13-074454 — 1.01, 1.02, 9.01
- 2013-09-20 0001104659-13-071413 — 5.02
- 2013-07-24 0001104659-13-056053 — 5.02, 7.01
- 2013-07-24 0001104659-13-056052 — 2.02, 7.01, 9.01
- 2013-06-14 0001104659-13-049436 — 8.01, 9.01
- 2013-05-31 0001104659-13-045928 — 8.01, 9.01
- 2013-05-22 0001104659-13-043876 — 1.01, 2.03, 9.01
- 2013-05-16 0001104659-13-042180 — 7.01, 9.01
- 2013-05-15 0001104659-13-042028 — 8.01, 9.01
- 2013-05-15 0001104659-13-041695 — 8.01, 9.01
- 2013-05-07 0001104659-13-038226 — 5.02
- 2013-05-01 0001104659-13-036004 — 2.02, 9.01
- 2013-03-15 0001104659-13-021156 — 7.01
- 2013-01-28 0001104659-13-005180 — 2.02, 9.01
- 2013-01-08 0001104659-13-001291 — 2.02, 9.01
- 2012-11-29 0001104659-12-080911 — 8.01, 9.01
- 2012-10-31 0001104659-12-072476 — 2.02, 9.01
- 2012-10-25 0001104659-12-071208 — 5.07
- 2012-10-16 0001104659-12-069238 — 7.01
- 2012-09-28 0001104659-12-066105 — 7.01
- 2012-09-21 0001104659-12-064869 — 7.01
- 2012-08-02 0001104659-12-053775 — 5.02
- 2012-07-30 0001104659-12-052298 — 2.02, 5.02, 8.01, 9.01
- 2012-07-05 0001104659-12-047737 — 2.02, 9.01
- 2012-04-26 0001104659-12-029099 — 5.02, 8.01, 9.01
- 2012-04-17 0001104659-12-025931 — 2.02, 9.01
- 2012-01-31 0001104659-12-005522 — 2.02, 9.01
- 2012-01-27 0001104659-12-004299 — 8.01, 9.01
- 2012-01-04 0001104659-12-000411 — 2.02, 9.01
- 2011-12-20 0001104659-11-070207 — 2.01, 3.02, 9.01
- 2011-12-12 0001104659-11-069005 — 8.01
- 2011-12-05 0001104659-11-067679 — 5.02, 9.01
- 2011-11-29 0001104659-11-066436 — 7.01, 9.01
- 2011-11-22 0001104659-11-065589 — 7.01, 9.01
- 2011-11-03 0001104659-11-060307 — 7.01
- 2011-10-21 0001104659-11-056997 — 2.02, 8.01, 9.01
- 2011-10-12 0001104659-11-055849 — 7.01, 9.01
- 2011-07-29 0001104659-11-041897 — 5.02
- 2011-07-20 0001104659-11-039922 — 2.02, 9.01
- 2011-06-01 0001104659-11-032473 — 8.01
- 2011-05-23 0001104659-11-030867 — 8.01
- 2011-05-18 0001104659-11-029869 — 1.01, 2.03, 9.01
- 2011-05-04 0001104659-11-025801 — 8.01, 9.01
- 2011-05-04 0001104659-11-025462 — 8.01, 9.01
- 2011-04-19 0001104659-11-020787 — 1.01, 2.02, 3.02, 9.01
- 2011-04-08 0001104659-11-019316 — 5.02, 9.01
- 2011-04-07 0001104659-11-019141 — 2.02, 8.01, 9.01
- 2011-03-09 0001104659-11-013084 — 5.02
- 2011-02-18 0001104659-11-008419 — 8.01
- 2011-02-01 0001104659-11-004106 — 5.02, 9.01
- 2011-01-19 0001104659-11-002037 — 1.01, 2.02, 2.03, 5.07, 9.01
- 2010-12-14 0001104659-10-062647 — 1.01, 2.03, 9.01
- 2010-12-08 0001104659-10-061747 — 8.01, 9.01
- 2010-12-08 0001104659-10-061643 — 7.01, 8.01, 9.01
- 2010-11-29 0001104659-10-060338 — 7.01, 9.01
- 2010-10-20 0001104659-10-052966 — 2.02, 9.01
- 2010-10-15 0001104659-10-052362 — 8.01, 9.01
- 2010-09-13 0001104659-10-048317 — 5.02, 9.01
- 2010-08-16 0001104659-10-044431 — 5.02
- 2010-07-29 0001104659-10-040519 — 5.02, 9.01
- 2010-07-20 0001104659-10-038670 — 2.02, 9.01
- 2010-07-06 0001104659-10-036996 — 1.01, 2.03, 3.01, 3.03, 5.01, 5.02, 8.01, 9.01
- 2010-06-25 0001104659-10-035630 — 8.01, 9.01
- 2010-05-26 0001104659-10-030931 — 5.02
- 2010-05-14 0001104659-10-028664 — 1.01, 2.03, 9.01
- 2010-04-30 0001104659-10-023493 — 8.01, 9.01
- 2010-04-29 0001104659-10-022773 — 1.02, 8.01, 9.01
- 2010-04-20 0001104659-10-020750 — 2.02, 9.01
- 2010-04-16 0001104659-10-020113 — 5.07
- 2010-03-22 0001104659-10-015668 — 1.01, 9.01
- 2010-03-03 0001104659-10-011870 — 1.01, 2.03, 9.01
- 2010-01-20 0001104659-10-002269 — 2.02, 9.01
- 2009-10-29 0001104659-09-060949 — 5.02, 7.01
- 2009-10-20 0001104659-09-059594 — 2.02, 9.01
- 2009-10-01 0001104659-09-057311 — 1.01, 2.03, 2.06, 9.01
- 2009-09-22 0001104659-09-055716 — 7.01, 9.01
- 2009-08-04 0001193125-09-163032 — 2.05
- 2009-07-31 0001193125-09-160678 — 5.02, 9.01
- 2009-07-21 0001193125-09-152269 — 2.02, 9.01
- 2009-07-09 0001193125-09-146452 — 5.02
- 2009-06-24 0001193125-09-136674 — 7.01, 9.01
- 2009-06-01 0001193125-09-122549 — 1.01, 2.03, 9.01
- 2009-05-14 0001193125-09-110016 — 8.01, 9.01
- 2009-05-13 0001193125-09-109216 — 2.05, 7.01, 9.01
- 2009-05-05 0001193125-09-099861 — 1.01, 2.03, 9.01
- 2009-04-21 0001193125-09-083544 — 2.02, 9.01
- 2009-04-17 0001193125-09-081018 — 8.01, 9.01
- 2009-04-13 0001193125-09-077471 — 2.02, 9.01
- 2009-04-13 0001193125-09-077470 — 8.01, 9.01
- 2009-04-06 0001193125-09-073113 — 1.01, 2.03, 9.01
- 2009-03-09 0001193125-09-048538 — 5.02
- 2009-03-04 0001193125-09-044916 — 5.02, 8.01
- 2009-02-06 0001193125-09-021262 — 5.02
- 2009-02-04 0001193125-09-018804 — 5.02, 8.01
- 2009-02-02 0001193125-09-016478 — 2.06 — amendment, the index does not say of what
- 2009-01-27 0001193125-09-012058 — 5.02
- 2009-01-21 0001193125-09-009019 — 2.02, 5.02, 9.01
- 2009-01-14 0001193125-09-005721 — 2.05, 7.01
- 2009-01-12 0001193125-09-004420 — 5.02, 7.01, 9.01
- 2008-12-24 0001193125-08-259972 — 2.06
- 2008-12-12 0001193125-08-252765 — 2.03
- 2008-12-10 0001193125-08-250840 — 7.01
- 2008-11-12 0001193125-08-233906 — 5.02
- 2008-10-22 0001193125-08-214482 — 2.02, 9.01
- 2008-09-19 0001193125-08-198664 — 2.05
- 2008-09-12 0001193125-08-195206 — 1.01
- 2008-08-27 0001193125-08-185448 — 1.02, 3.01, 5.02, 9.01
- 2008-07-15 0001193125-08-151292 — 2.02, 9.01
- 2008-07-11 0001193125-08-149749 — 2.05
- 2008-07-03 0001193125-08-146791 — 5.02
- 2008-04-29 0001193125-08-094835 — 5.02, 9.01
- 2008-04-15 0001193125-08-081743 — 2.02, 9.01
- 2008-03-12 0001193125-08-054331 — 8.01, 9.01
- 2008-03-04 0001193125-08-045657 — 7.01
- 2008-02-04 0001193125-08-019262 — 8.01, 9.01
- 2008-01-18 0001193125-08-008849 — 8.01, 9.01
- 2008-01-17 0001193125-08-008120 — 2.02, 9.01
- 2007-12-21 0001193125-07-269469 — 2.05
- 2007-12-05 0001193125-07-259675 — 5.02
- 2007-10-17 0001193125-07-220376 — 8.01, 9.01
- 2007-10-16 0001193125-07-219386 — 2.02, 9.01
- 2007-09-18 0000950134-07-020112 — 5.02, 9.01
- 2007-08-29 0000950134-07-019145 — 1.01, 2.02, 9.01
- 2007-07-20 0001193125-07-159001 — 8.01, 9.01
- 2007-07-19 0001193125-07-158214 — 2.02, 9.01
- 2007-04-18 0001193125-07-083845 — 8.01, 9.01
- 2007-04-17 0001193125-07-082824 — 2.02, 9.01
- 2007-04-10 0001193125-07-077251 — 2.02, 9.01
- 2007-02-27 0001193125-07-040081 — 5.02, 7.01
- 2007-01-24 0001193125-07-011834 — 8.01, 9.01
- 2007-01-23 0001193125-07-010955 — 2.02, 9.01
- 2006-12-21 0001193125-06-257603 — 8.01, 9.01
- 2006-12-07 0001193125-06-247897 — 5.02
- 2006-11-07 0001193125-06-225545 — 2.02, 7.01, 8.01, 9.01
- 2006-11-01 0001193125-06-220706 — 1.01, 9.01
- 2006-10-25 0001193125-06-214798 — 8.01, 9.01
- 2006-10-24 0001193125-06-213813 — 2.02, 9.01
- 2006-10-11 0001193125-06-206304 — 5.02
- 2006-10-03 0001193125-06-201845 — 5.02, 9.01
- 2006-09-21 0001193125-06-194878 — 1.01, 1.02, 2.03, 2.04, 8.01, 9.01
- 2006-09-19 0001193125-06-192726 — 8.01, 9.01
- 2006-09-12 0001193125-06-189437 — 5.02, 8.01, 9.01
- 2006-08-24 0001193125-06-179258 — 1.01
- 2006-08-09 0001193125-06-167961 — 8.01, 9.01
- 2006-08-08 0001193125-06-165853 — 2.02, 9.01
- 2006-06-01 0001193125-06-122124 — 7.01, 9.01
- 2006-05-25 0001193125-06-119646 — 1.01, 2.01, 2.03, 5.02, 9.01
- 2006-05-17 0001193125-06-114760 — 8.01, 9.01
- 2006-05-04 0001193125-06-099262 — 8.01, 9.01
- 2006-05-03 0001193125-06-098229 — 5.05, 9.01
- 2006-04-27 0001193125-06-090749 — 8.01
- 2006-04-20 0001193125-06-084566 — 8.01, 9.01
- 2006-04-18 0001193125-06-082414 — 2.02, 9.01
- 2006-04-13 0001193125-06-079690 — 8.01
- 2006-04-03 0001193125-06-071956 — 8.01
- 2006-03-13 0001193125-06-051798 — 8.01
- 2006-02-14 0001193125-06-030829 — 8.01, 9.01
- 2006-01-26 0001193125-06-012909 — 8.01, 9.01
- 2006-01-25 0001193125-06-011608 — 8.01, 9.01
- 2006-01-19 0001193125-06-008770 — 8.01, 9.01
- 2006-01-18 0001193125-06-007939 — 2.02, 9.01
- 2005-12-22 0001193125-05-247782 — 1.01, 5.02, 9.01
- 2005-12-22 0001193125-05-247766 — 1.01, 9.01
- 2005-12-21 0001193125-05-246701 — 8.01, 9.01
- 2005-12-01 0001193125-05-234733 — 7.01
- 2005-11-23 0001193125-05-231674 — 1.01, 1.02, 7.01, 9.01
- 2005-10-19 0001193125-05-203955 — 2.02, 9.01
- 2005-10-18 0001193125-05-203356 — 2.02, 7.01, 9.01
- 2005-09-08 0001193125-05-181893 — 7.01, 9.01
- 2005-09-07 0001193125-05-181605 — 1.01
- 2005-08-04 0001193125-05-157913 — 8.01, 9.01
- 2005-08-03 0001193125-05-156407 — 1.01, 8.01, 9.01
- 2005-07-19 0001193125-05-144591 — 2.02, 9.01
- 2005-06-08 0001193125-05-121880 — 7.01
- 2005-05-17 0001193125-05-109518 — 7.01
- 2005-04-19 0001193125-05-079453 — 2.02, 9.01
- 2005-03-22 0001193125-05-057519 — 1.01
- 2005-03-16 0001193125-05-052560 — 7.01
- 2005-03-07 0001193125-05-043752 — 7.01, 9.01
- 2005-02-08 0001193125-05-022340 — 1.01, 7.01
- 2005-01-18 0001193125-05-007666 — 2.02, 9.01
- 2004-12-13 0001193125-04-211590 — 7.01, 8.01, 9.01
- 2004-12-07 0001193125-04-208768 — 7.01, 9.01
- 2004-10-29 0001193125-04-181463 — 1.01, 5.02, 9.01
- 2004-10-19 0001193125-04-173795 — 2.02, 9.01
- 2004-09-23 0001193125-04-160889 — 8.01, 9.01
- 2004-09-21 0001193125-04-159593 — 8.01, 9.01
- 2004-09-07 0001193125-04-152868 — 7.01, 9.01
- 2004-07-28 0001193125-04-126152 — 5, 7
- 2004-07-20 0001193125-04-121017 — 12, 7
- 2004-06-02 0001193125-04-097697 — 7, 9
- 2004-04-30 0001193125-04-075386 — 5, 7
- 2004-04-20 0001193125-04-065621 — 12, 7
- 2004-04-06 0001193125-04-057855 — 12, 7
- 2004-03-16 0001193125-04-042542 — 5
- 2004-03-03 0001193125-04-033653 — 7, 9
- 2004-01-21 0001193125-04-006388 — 12, 5, 7
- 2003-10-31 0001193125-03-070294 — 5, 7
- 2003-10-27 0001193125-03-067685 — 5, 7
- 2003-10-22 0001193125-03-065398 — 12, 5, 7
- 2003-07-16 0001193125-03-019880 — 7, 9
- 2003-07-10 0001193125-03-018043 — 5
- 2003-07-07 0001193125-03-016864 — 5
- 2003-06-27 0001193125-03-014262 — 5, 7
- 2003-04-16 0001012870-03-001799 — 7, 9

## late-filing notifications on or before 2018-05-01

- none on or before 2018-05-01

## item 2.02 — earnings release, exhibit 99.1

[0001193125-18-145112:8k_2_02:1]
EX-99.1
2
d540531dex991.htm
EX-99.1

[0001193125-18-145112:8k_2_02:2]
EX-99.1

[0001193125-18-145112:8k_2_02:3]
Exhibit 99.1

[0001193125-18-145112:8k_2_02:4]
|  |  | Media Contact: Andrew Larg, (408) 658-1059 andrew.larg@seagate.com |

[0001193125-18-145112:8k_2_02:5]
SEAGATE TECHNOLOGY REPORTS FISCAL THIRD QUARTER 2018 FINANCIAL RESULTS

[0001193125-18-145112:8k_2_02:6]
|  |  | - Revenue up 5% year-over-year - Exabyte shipment up 34% year-over-year |  |  |

[0001193125-18-145112:8k_2_02:7]
CUPERTINO, CA – May 1, 2018 – Seagate Technology plc (NASDAQ: STX) (the “Company” or
“Seagate”) today reported financial results for the quarter ended March 30, 2018. For the third quarter, the Company reported revenue of $2.8 billion, gross margin of 30.2%, net income of $381 million and diluted earnings
per share of $1.31. On a non-GAAP basis, which excludes the net impact of certain items, Seagate reported gross margin of 30.8%, net income of $424 million and diluted earnings per share of $1.46.

[0001193125-18-145112:8k_2_02:8]
During the third quarter, the Company generated $558 million in cash flow from operations and $489 million in free cash flow. Year to date, the
Company has generated approximately $1.6 billion in cash flow from operations and approximately $1.4 billion in free cash flow. Cash and cash equivalents totaled approximately $2.9 billion at the end of the quarter. There were
287 million ordinary shares issued and outstanding as of the end of the quarter.

[0001193125-18-145112:8k_2_02:9]
“Seagate achieved our second consecutive quarter of
year-over-year revenue growth and exceeded our financial performance expectations for the March quarter, through solid execution and strong demand for our mass storage products. Looking ahead, the growing Data Age demand on storage, combined with
consistent investment in our leading storage technology platforms and efficient operational capabilities, will continue to drive economic value for customers and returns for shareholders,” said Dave Mosley, Seagate’s chief executive
officer.

[0001193125-18-145112:8k_2_02:10]
For a detailed reconciliation of GAAP to non-GAAP results, see accompanying financial tables.

[0001193125-18-145112:8k_2_02:11]
Seagate has issued a Supplemental Financial Information document, which is available on Seagate’s Investors Relations website at
www.seagate.com/investors.

[0001193125-18-145112:8k_2_02:12]
Quarterly Cash Dividend

[0001193125-18-145112:8k_2_02:13]
The Board of Directors of the Company (the “Board”) has approved a quarterly cash dividend of $0.63 per share, which will be payable on July 5,
2018 to shareholders of record as of the close of business on June 20, 2018. The payment of any future quarterly dividends will be at the discretion of the Board and will be dependent upon Seagate’s financial position, results of
operations, available cash, cash flow, capital requirements and other factors deemed relevant by the Board.

[0001193125-18-145112:8k_2_02:14]
Investor Communications

[0001193125-18-145112:8k_2_02:15]
Seagate management will hold a public webcast today at 6:00 a.m. Pacific Time that can be accessed on its Investor Relations website at
www.seagate.com/investors. During today’s webcast, the Company will provide an outlook for its fourth fiscal quarter of 2018, including key underlying assumptions.

[0001193125-18-145112:8k_2_02:16]
An archived audio webcast of this event will be available on Seagate’s Investors Relations website at www.seagate.com/investors shortly following the
event conclusion.

[0001193125-18-145112:8k_2_02:17]
About Seagate

[0001193125-18-145112:8k_2_02:18]
To learn more about the Company’s products and services, visit www.seagate.com and follow us on Twitter, Facebook, LinkedIn, Spiceworks, YouTube and
subscribe to our blog. The contents of our website and social media channels are not a part of this release.

[0001193125-18-145112:8k_2_02:19]
Cautionary Note Regarding
Forward-Looking Statements

[0001193125-18-145112:8k_2_02:20]
The inclusion of Seagate’s website address in this press release is intended to be an inactive textual reference only and not an active hyperlink. The
information contained in, or that can be accessed through, Seagate’s website and social media channels are not part of this press release.

[0001193125-18-145112:8k_2_02:21]
SEAGATE TECHNOLOGY PLC

[0001193125-18-145112:8k_2_02:22]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-18-145112:8k_2_02:23]
(In millions)

[0001193125-18-145112:8k_2_02:24]
(Unaudited)

[0001193125-18-145112:8k_2_02:25]
|  |  | March 30,2018 |  |  | June 30,2017 (a) |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,926 |  |  | $ | 2,539 |  |
| Accounts receivable, net |  |  | 1,076 |  |  |  | 1,199 |  |
| Inventories |  |  | 1,002 |  |  |  | 982 |  |
| Other current assets |  |  | 243 |  |  |  | 321 |  |
| Total current assets |  |  | 5,247 |  |  |  | 5,041 |  |
| Property, equipment and leasehold improvements, net |  |  | 1,720 |  |  |  | 1,875 |  |
| Goodwill |  |  | 1,238 |  |  |  | 1,238 |  |
| Other intangible assets, net |  |  | 204 |  |  |  | 281 |  |
| Deferred income taxes |  |  | 398 |  |  |  | 609 |  |
| Other assets, net |  |  | 205 |  |  |  | 224 |  |
| Total Assets |  | $ | 9,012 |  |  | $ | 9,268 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 1,645 |  |  | $ | 1,626 |  |
| Accrued employee compensation |  |  | 188 |  |  |  | 237 |  |
| Accrued warranty |  |  | 110 |  |  |  | 113 |  |
| Current portion of long-term debt |  |  | 503 |  |  |  | — |  |
| Accrued expenses |  |  | 609 |  |  |  | 650 |  |
| Total current liabilities |  |  | 3,055 |  |  |  | 2,626 |  |
| Long-term accrued warranty |  |  | 125 |  |  |  | 120 |  |
| Long-term accrued income taxes |  |  | 10 |  |  |  | 15 |  |
| Other non-current liabilities |  |  | 139 |  |  |  | 122 |  |
| Long-term debt, less current portion |  |  | 4,319 |  |  |  | 5,021 |  |
| Total Liabilities |  |  | 7,648 |  |  |  | 7,904 |  |
| Total Equity |  |  | 1,364 |  |  |  | 1,364 |  |
| Total Liabilities and Equity |  | $ | 9,012 |  |  | $ | 9,268 |  |

[0001193125-18-145112:8k_2_02:26]
| (a) | The information in this column was derived from the Company’s audited Consolidated Balance Sheet as of June 30, 2017. |

[0001193125-18-145112:8k_2_02:27]
SEAGATE TECHNOLOGY PLC

[0001193125-18-145112:8k_2_02:28]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-18-145112:8k_2_02:29]
(In millions, except per share data)

[0001193125-18-145112:8k_2_02:30]
(Unaudited)

[0001193125-18-145112:8k_2_02:31]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
|  |  | March 30,2018 |  |  | March 31,2017 |  |  | March 30,2018 |  |  | March 31,2017 |  |
| Revenue |  | $ | 2,803 |  |  | $ | 2,674 |  |  | $ | 8,349 |  |  | $ | 8,365 |  |
| Cost of revenue |  |  | 1,956 |  |  |  | 1,858 |  |  |  | 5,889 |  |  |  | 5,857 |  |
| Product development |  |  | 254 |  |  |  | 324 |  |  |  | 767 |  |  |  | 944 |  |
| Marketing and administrative |  |  | 135 |  |  |  | 150 |  |  |  | 422 |  |  |  | 457 |  |
| Amortization of intangibles |  |  | 6 |  |  |  | 28 |  |  |  | 47 |  |  |  | 85 |  |
| Restructuring and other, net |  |  | 11 |  |  |  | 48 |  |  |  | 95 |  |  |  | 164 |  |
| Total operating expenses |  |  | 2,362 |  |  |  | 2,408 |  |  |  | 7,220 |  |  |  | 7,507 |  |
| Income from operations |  |  | 441 |  |  |  | 266 |  |  |  | 1,129 |  |  |  | 858 |  |
| Interest income |  |  | 10 |  |  |  | 5 |  |  |  | 23 |  |  |  | 7 |  |
| Interest expense |  |  | (60 | ) |  |  | (60 | ) |  |  | (182 | ) |  |  | (160 | ) |
| Other, net |  |  | 2 |  |  |  | 1 |  |  |  | (18 | ) |  |  | (10 | ) |
| Other expense, net |  |  | (48 | ) |  |  | (54 | ) |  |  | (177 | ) |  |  | (163 | ) |
| Income before income taxes |  |  | 393 |  |  |  | 212 |  |  |  | 952 |  |  |  | 695 |  |
| Provision for income taxes |  |  | 12 |  |  |  | 18 |  |  |  | 231 |  |  |  | 37 |  |
| Net income |  | $ | 381 |  |  | $ | 194 |  |  | $ | 721 |  |  | $ | 658 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.33 |  |  | $ | 0.66 |  |  | $ | 2.50 |  |  | $ | 2.22 |  |
| Diluted |  |  | 1.31 |  |  |  | 0.65 |  |  |  | 2.48 |  |  |  | 2.20 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 286 |  |  |  | 296 |  |  |  | 288 |  |  |  | 297 |  |
| Diluted |  |  | 291 |  |  |  | 300 |  |  |  | 291 |  |  |  | 299 |  |
| Cash dividends declared per ordinary share |  | $ | 0.63 |  |  | $ | 0.63 |  |  | $ | 1.89 |  |  | $ | 1.89 |  |

[0001193125-18-145112:8k_2_02:32]
SEAGATE TECHNOLOGY PLC

[0001193125-18-145112:8k_2_02:33]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-18-145112:8k_2_02:34]
(In millions)

[0001193125-18-145112:8k_2_02:35]
(Unaudited)

[0001193125-18-145112:8k_2_02:36]
|  |  | For the Nine Months Ended |  |
|  |  | March 30,2018 |  |  | March 31,2017 |  |
| OPERATING ACTIVITIES |  |  |  |  |  |  |  |  |
| Net income |  | $ | 721 |  |  | $ | 658 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 461 |  |  |  | 573 |  |
| Share-based compensation |  |  | 85 |  |  |  | 110 |  |
| Impairment of long-lived assets |  |  | — |  |  |  | 35 |  |
| Deferred income taxes |  |  | 209 |  |  |  | 12 |  |
| Other non-cash operating activities, net |  |  | 9 |  |  |  | 17 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 124 |  |  |  | 165 |  |
| Vendor receivables |  |  | 54 |  |  |  | 32 |  |
| Inventories |  |  | (20 | ) |  |  | (170 | ) |
| Accounts payable |  |  | 74 |  |  |  | 124 |  |
| Accrued employee compensation |  |  | (49 | ) |  |  | 61 |  |
| Accrued expenses, income taxes and warranty |  |  | (24 | ) |  |  | 69 |  |
| Other assets and liabilities |  |  | 1 |  |  |  | (13 | ) |
| Net cash provided by operating activities |  |  | 1,645 |  |  |  | 1,673 |  |
| INVESTING ACTIVITIES |  |  |  |  |  |  |  |  |
| Acquisition of property, equipment and leasehold improvements |  |  | (270 | ) |  |  | (330 | ) |
| Proceeds from the sale of fixed assets |  |  | 2 |  |  |  | — |  |
| Proceeds from sale of properties previously classified as held for sale |  |  | 43 |  |  |  | — |  |
| Maturities of short-term investments |  |  | — |  |  |  | 6 |  |
| Other investing activities, net |  |  | (14 | ) |  |  | (13 | ) |
| Net cash used in investing activities |  |  | (239 | ) |  |  | (337 | ) |
| FINANCING ACTIVITIES |  |  |  |  |  |  |  |  |
| Redemption and repurchase of debt |  |  | (209 | ) |  |  | (97 | ) |
| Net proceeds from issuance of long-term debt |  |  | — |  |  |  | 1,232 |  |
| Taxes paid related to net share settlement of equity awards |  |  | (22 | ) |  |  | (25 | ) |
| Repurchases of ordinary shares |  |  | (361 | ) |  |  | (248 | ) |
| Dividends to shareholders |  |  | (545 | ) |  |  | (374 | ) |
| Proceeds from issuance of ordinary shares under employee stock plans |  |  | 110 |  |  |  | 83 |  |
| Net cash (used in) provided by financing activities |  |  | (1,027 | ) |  |  | 571 |  |
| Effect of foreign currency exchange rate changes on cash, cash equivalents, and restricted cash |  |  | 8 |  |  |  | (8 | ) |
| Increase in cash, cash equivalents, and restricted cash |  |  | 387 |  |  |  | 1,899 |  |
| Cash, cash equivalents, and restricted cash at the beginning of the period |  |  | 2,543 |  |  |  | 1,132 |  |
| Cash, cash equivalents, and restricted cash at the end of the period |  | $ | 2,930 |  |  | $ | 3,031 |  |

[0001193125-18-145112:8k_2_02:37]
Use of non-GAAP financial information

[0001193125-18-145112:8k_2_02:38]
The Company uses non-GAAP measures of adjusted revenue, gross margin, net income, diluted earnings per share and
operating expenses which are adjusted from results based on GAAP to exclude certain expenses, gains and losses. These non-GAAP financial measures may be provided to enhance the user’s overall
understanding of the Company’s current financial performance and its prospects for the future. Specifically, the Company believes non-GAAP results provide useful information to both management and
investors as these non-GAAP results exclude certain expenses, gains and losses that it believes are not indicative of its core operating results and because it is similar to the approach used in connection
with the financial models and estimates published by financial analysts who follow the Company.

[0001193125-18-145112:8k_2_02:39]
These non-GAAP
results are some of the primary measurements management uses to assess the Company’s performance, allocate resources and plan for future periods. Reported non-GAAP results should only be considered as
supplemental to results prepared in accordance with GAAP, and not considered as a substitute for, or superior to, GAAP results. These non-GAAP measures may differ from the
non-GAAP measures reported by other companies in its industry.

[0001193125-18-145112:8k_2_02:40]
SEAGATE TECHNOLOGY PLC

[0001193125-18-145112:8k_2_02:41]
ADJUSTMENTS TO GAAP NET INCOME AND DILUTED NET INCOME PER SHARE

[0001193125-18-145112:8k_2_02:42]
(In millions, except per share amounts)

[0001193125-18-145112:8k_2_02:43]
(Unaudited)

[0001193125-18-145112:8k_2_02:44]
|  |  |  |  |  | For the Three MonthsEnded March 30, 2018 |  |  | For the Nine MonthsEnded March 30, 2018 |  |
| Reconciliation of GAAP Net Income: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP Net income |  |  |  |  |  | $ | 381 |  |  | $ | 721 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue |  |  | A |  |  |  | — |  |  |  | (6 | ) |
| Cost of revenue |  |  | B |  |  |  | 16 |  |  |  | 56 |  |
| Product development |  |  | C |  |  |  | 5 |  |  |  | 8 |  |
| Marketing and administrative |  |  | D |  |  |  | 1 |  |  |  | 2 |  |
| Amortization of intangibles |  |  | E |  |  |  | 4 |  |  |  | 43 |  |
| Restructuring and other, net |  |  | F |  |  |  | 11 |  |  |  | 95 |  |
| Other expense, net |  |  | G |  |  |  | 5 |  |  |  | 7 |  |
| Provision for income taxes |  |  | H |  |  |  | 1 |  |  |  | 208 |  |
| Non-GAAP net income |  |  |  |  |  | $ | 424 |  |  | $ | 1,134 |  |
| Reconciliation of GAAP Diluted Net Income Per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  |  |  |  |  | $ | 1.31 |  |  | $ | 2.48 |  |
| Non-GAAP |  |  |  |  |  | $ | 1.46 |  |  | $ | 3.90 |  |
| Shares used in diluted net income per share calculation |  |  |  |  |  |  | 291 |  |  |  | 291 |  |

[0001193125-18-145112:8k_2_02:45]
| A | For the nine months ended March 30, 2018, Revenue has been adjusted on a non-GAAP basis to exclude the favorable adjustments for sales of certain discontinued products. |

[0001193125-18-145112:8k_2_02:46]
| B | For the three and nine months ended March 30, 2018, Cost of revenue has been adjusted on a non-GAAP basis to exclude amortization of intangibles associated with acquisitions, write off of certain inventory and other charges related to restructuring. |

[0001193125-18-145112:8k_2_02:47]
| C | For the three and nine months ended March 30, 2018, Product development expenses have been adjusted on a non-GAAP basis to exclude the impact of write off of certain fixed assets and other charges related to restructuring. |

[0001193125-18-145112:8k_2_02:48]
| D | For the three and nine months ended March 30, 2018, Marketing and administrative expenses have been adjusted on a non-GAAP basis to exclude the write off of certain fixed assets related to restructuring. |

[0001193125-18-145112:8k_2_02:49]
| E | For the three and nine months ended March 30, 2018, Amortization of intangibles related to our acquisitions has been excluded on a non-GAAP basis. |

[0001193125-18-145112:8k_2_02:50]
| F | For the three and nine months ended March 30, 2018, Restructuring and other net, has been adjusted on a non-GAAP basis primarily related to reductions in our workforce and other exit costs as a result of our ongoing focus on cost efficiencies in all areas of our business. |

[0001193125-18-145112:8k_2_02:51]
| G | For the three and nine months ended March 30, 2018, Other expense, net has been adjusted on a non-GAAP basis to exclude the impact of impairment of a strategic investment, net impact of losses recognized on the early redemption and repurchase of debt and impact of our disposed data service business. |

[0001193125-18-145112:8k_2_02:52]
| H | For the three and nine months ended March 30, 2018, Provision for income taxes represents the tax effects of non-GAAP adjustments determined using a hybrid with and without method and effective tax rate for the applicable adjustment and jurisdiction and a provisional tax expense of $4 million and $212 million, respectively for the re-measurement of our U.S. deferred tax assets at the lower 21% tax rate resulting from the U.S. Tax Cuts and Jobs Act enacted on December 22, 2017. |
