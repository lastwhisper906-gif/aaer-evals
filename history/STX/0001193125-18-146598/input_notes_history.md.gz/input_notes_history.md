# STX note change history — 0001193125-18-023592 → 0001193125-18-146598


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-01):
[0001193125-18-146598:note_history:1]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al. On June 5, 2013, Enova Technology Corporation (“Enova”) filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995 (the “‘995 patent”), “Cryptographic Device,” and U.S. Patent No. 7,900,057 (the “‘057 patent”), “Cryptographic Serial ATA Apparatus and Method.” The Company believes the claims are without merit and intends to vigorously defend this case. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the ‘995 and ‘057 patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ‘057 patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 patent are held unpatentable. Enova appealed PTAB’s decisions on the ‘995 patent and the ‘057 patent to the U.S. Court of Appeals for the Federal Circuit. On March 20, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the ‘995 patent. On September 6, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the ‘057 patent. On November 27, 2017, Enova filed a petition for writ of certiorari with the U.S. Supreme Court challenging the court of appeals’ decision on the ‘057 Patent. The Supreme Court denied the petition on April 30, 2018. The district court case remains stayed. In light of the Supreme Court’s denial of the petition, the Company does not expect to incur a loss in this matter.
  (was, 2018-01-29, similarity 0.8637):
[0001193125-18-023592:note_history:1]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al. On June 5, 2013, Enova Technology Corporation (“Enova”) filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995 (the “‘995 patent”), “Cryptographic Device,” and U.S. Patent No. 7,900,057 (the “‘057 patent”), “Cryptographic Serial ATA Apparatus and Method.” The Company believes the claims are without merit and intends to vigorously defend this case. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the ‘995 and ‘057 patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ‘057 patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 patent are held unpatentable. Enova appealed PTAB’s decisions on the ‘995 patent and the ‘057 patent to the U.S. Court of Appeals for the Federal Circuit. On March 20, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the ‘995 patent. On September 6, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the ‘057 patent. On November 27, 2017, Enova filed a petition for writ of certiorari with the U.S. Supreme Court challenging the court of appeals’ decision on the ‘057 Patent. The Supreme Court has not yet ruled on this petition. The district court case remains stayed. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-05-01):
[0001193125-18-146598:note_history:2]
The results of operations for the three and nine months ended March 30, 2018 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending June 29, 2018. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three and nine months ended March 30, 2018 and the three and nine months ended March 31, 2017 consisted of 13 weeks and 39 weeks, respectively. Fiscal year 2018, which ends on June 29, 2018, and fiscal year 2017, which ended on June 30, 2017, are both comprised of 52 weeks. The fiscal quarters ended March 30, 2018, December 29, 2017, and March 31, 2017, are also referred to herein as the “March 2018 quarter”, the “December 2017 quarter”, and the “March 2017 quarter”, respectively.
  (was, 2018-01-29, similarity 0.7261):
[0001193125-18-023592:note_history:2]
The results of operations for the three and six months ended December 29, 2017, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending June 29, 2018. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three and six months ended December 29, 2017 and the three and six months ended December 30, 2016 consisted of 13 weeks and 26 weeks, respectively. Fiscal year 2018 will be comprised of 52 weeks and will end on June 29, 2018. The fiscal quarters ended December 29, 2017, September 29, 2017, and December 30, 2016, are also referred to herein as the “December 2017 quarter”, the “September 2017 quarter”, and the “December 2016 quarter”, respectively.

- changed (2018-05-01):
[0001193125-18-146598:note_history:3]
There have been no significant changes in the Company's significant accounting policies. Please refer to Note 1 of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2017, as filed with the SEC on August 4, 2017 for a discussion of the Company’s significant accounting policies.
  (was, 2018-01-29, similarity 0.992):
[0001193125-18-023592:note_history:3]
There have been no significant changes in the Company's significant accounting policies. Please refer to Note 1 of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2017, as filed with the SEC on August 4, 2017 for a discussion of the Company’s other significant accounting policies.

- changed (2018-05-01):
[0001193125-18-146598:note_history:4]
In May 2014, August 2015, April 2016, May 2016 and December 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update ("ASU") 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, ASU 2016-12 (ASC Topic 606) Revenue from Contracts with Customers, Narrow-Scope Improvements and Practical Expedients, and ASU 2016-20 (ASC Topic 606) Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company is required to adopt the guidance in the first quarter of fiscal year 2019. This standard may be applied retrospectively to all prior periods presented, or retrospectively with a cumulative adjustment to retained earnings in the year of adoption (“modified retrospective transition approach”). Based on its assessment, the Company plans to adopt the new revenue standard in the first quarter of fiscal year 2019, utilizing the modified retrospective method of transition. While management has not yet completed its assessment of the impact of adopting this new standard on the Company’s consolidated financial statements, the Company expects the adoption of the new standard will result in the recognition of revenue generally upon shipment (sell-in basis) for sales of products to certain direct retail customers and customers in certain indirect retail channels which are currently being recognized on a sell-through basis. Accordingly, the Company will need to estimate variable consideration (e.g. rebates) related to customer incentives on these arrangements. These changes are not expected to have a material impact on the Company’s condensed consolidated financial statements.
  (was, 2018-01-29, similarity 0.9899):
[0001193125-18-023592:note_history:4]
In May 2014, August 2015, April 2016, May 2016 and December 2016, the Financial Accounting Standards Board (“FASB”) issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, ASU 2016-12 (ASC Topic 606) Revenue from Contracts with Customers, Narrow-Scope Improvements and Practical Expedients, and ASU 2016-20 (ASC Topic 606) Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company is required to adopt the guidance in the first quarter of fiscal 2019. This standard may be applied retrospectively to all prior periods presented, or retrospectively with a cumulative adjustment to retained earnings in the year of adoption (“modified retrospective transition approach”). Based on its assessment, the Company plans to adopt the new revenue standard in the first quarter of fiscal 2019, utilizing the modified retrospective method of transition. While management has not yet completed its assessment of the impact of adopting this new standard on the Company’s consolidated financial statements, the Company expects the adoption of the new standard will result in the recognition of revenues generally upon shipment (sell-in basis) for sales of products to certain direct retail customers and customers in certain indirect retail channels which are currently being recognized on a sell-through basis. Accordingly, the Company will need to estimate variable consideration (e.g. rebates) related to customer incentives on these arrangements. These changes are not expected to have a material impact on the Company’s condensed consolidated financial statements.

- changed (2018-05-01):
[0001193125-18-146598:note_history:5]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments—Overall Recognition and Measurement of Financial Assets and Financial Liabilities, as amended by ASU 2018-03, Financial Instruments—Overall: Technical Correction and Improvements, issued in February 2018. The amendments in these ASUs require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The Company is required to adopt the guidance in the first quarter of fiscal year 2019. Early adoption is permitted for only certain portions of the ASU. The Company expects to elect the measurement alternative for measurement of equity investments, defined as cost, less impairments, if any, plus or minus changes resulting from observable price changes in orderly transactions for an identical or similar investment in the same issuer (the "Price Changes") until the equity investments' fair value becomes readily determinable. The amount of the impact to equity investments will depend on any Price Changes observed after adoption in the first quarter of fiscal year 2019.
  (was, 2018-01-29, similarity 0.9398):
[0001193125-18-023592:note_history:5]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments—Overall Recognition and Measurement of Financial Assets and Financial Liabilities. The amendments in this ASU require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted for only certain portions of the ASU. The Company expects to elect the measurement alternative for measurement of equity investments, defined as cost, less impairments, if any, plus or minus changes resulting from observable price changes in orderly transactions for an identical or similar investment in the same issuer (the "Price Changes") until the equity investments' fair value becomes readily determinable. The amount of the impact to equity investments will depend on any Price Changes observed after adoption in the first quarter of fiscal 2019.

- changed (2018-05-01):
[0001193125-18-146598:note_history:6]
In February 2016, the FASB issued ASU 2016-02 (ASC Topic 842), Leases. This ASU amends a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The Company is required to adopt this guidance in the first quarter of fiscal year 2020. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.
  (was, 2018-01-29, similarity 0.9904):
[0001193125-18-023592:note_history:6]
In February 2016, the FASB issued ASU 2016-02 (ASC Topic 842), Leases. The ASU amends a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The Company is required to adopt the guidance in the first quarter of fiscal 2020. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- added (2018-05-01):
[0001193125-18-146598:note_history:7]
In June 2016, the FASB issued ASU 2016-13 (ASC Topic 326), Financial Instruments - Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held. The Company is required to adopt this guidance in the first quarter of fiscal year 2021. Early adoption in the first quarter of fiscal year 2020 is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- changed (2018-05-01):
[0001193125-18-146598:note_history:8]
In January 2017, the FASB issued ASU 2017-01 (ASC Topic 805), Business Combination: Clarifying the Definition of a Business. The amendments in this ASU change the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company plans to adopt the guidance in the first quarter of fiscal year 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.
  (was, 2018-01-29, similarity 0.7001):
[0001193125-18-023592:note_history:8]
In January 2017, the FASB issued ASU 2017-01 (ASC Topic 805), Business Combination: Clarifying the Definition of a Business. The amendments in this ASU change the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company plans to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- changed (2018-05-01):
[0001193125-18-146598:note_history:9]
In May 2017, the FASB issued ASU 2017-09 (ASC Topic 718), Stock Compensation: Scope of Modification Accounting. The amendments in this ASU provide guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting. The Company plans to adopt the guidance in the first quarter of fiscal year 2019. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.
  (was, 2018-01-29, similarity 0.7246):
[0001193125-18-023592:note_history:9]
In May 2017, the FASB issued ASU 2017-09 (ASC Topic 718), Stock Compensation: Scope of Modification Accounting. The amendments in this ASU provide guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting. The Company plans to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- added (2018-05-01):
[0001193125-18-146598:note_history:10]
In August 2017, the FASB issued ASU 2017-12 (ASC Topic 815), Derivatives and Hedging: Targeted Improvements to Accounting for Hedging Activities. The amendments in this ASU were issued to simplify existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. The amended guidance will eliminate the separate measurement and presentation of hedge ineffectiveness. The Company is required to adopt the guidance in the first quarter of fiscal year 2020. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- added (2018-05-01):
[0001193125-18-146598:note_history:11]
In February 2018, the FASB issued ASU 2018-02 (ASC Topic 220), Income Statement—Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 (the "Act") and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Act. The Company is required to adopt the guidance in the first quarter of fiscal year 2020.  Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-01):
[0001193125-18-146598:note_history:12]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to allow for higher net leverage levels. The Company was in compliance with the modified covenants as of March 30, 2018 and expects to be in compliance for the next 12 months.
  (was, 2018-01-29, similarity 0.9866):
[0001193125-18-023592:note_history:12]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to allow for higher net leverage levels. The Company was in compliance with the modified covenants as of December 29, 2017 and expects to be in compliance for the next 12 months.

- changed (2018-05-01):
[0001193125-18-146598:note_history:13]
As of March 30, 2018, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.
  (was, 2018-01-29, similarity 0.96):
[0001193125-18-023592:note_history:13]
As of December 29, 2017, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

- changed (2018-05-01):
[0001193125-18-146598:note_history:14]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the three and nine months ended March 30, 2018, the Company repurchased $56 million and $206 million aggregate principal amount of the 2018 Notes, respectively, for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss of approximately $1 million and $3 million on repurchases during the three and nine months ended March 30, 2018, respectively, which is included in Other, net on the Condensed Consolidated Statements of Operations. The remainder of the 2018 Notes are classified as Current portion of long-term debt on the Company's Condensed Consolidated Balance Sheet at March 30, 2018.
  (was, 2018-01-29, similarity 0.8555):
[0001193125-18-023592:note_history:14]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the three and six months ended December 29, 2017, the Company repurchased $128 million and $150 million aggregate principal amount of the 2018 Notes, respectively, for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss of approximately $2 million on repurchases during the three and six months ended December 29, 2017 which is included in Other, net on the Condensed Consolidated Statements of Operations. The remainder of the 2018 Notes are classified as Current portion of long-term debt on the Company's Condensed Consolidated Balance Sheet at December 29, 2017.

- changed (2018-05-01):
[0001193125-18-146598:note_history:15]
At March 30, 2018, future principal payments on long-term debt were as follows (in millions):
  (was, 2018-01-29, similarity 0.9492):
[0001193125-18-023592:note_history:15]
At December 29, 2017, future principal payments on long-term debt were as follows (in millions):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-01):
[0001193125-18-146598:note_history:16]
|  |  | March 30, 2018 |  | June 30, 2017 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 504 |  |  | $ | 507 |  |  | $ | 710 |  |  | $ | 726 |  |
| 4.25% Senior Notes due March 2022 |  | 749 |  |  | 741 |  |  | 748 |  |  | 765 |  |
| 4.75% Senior Notes due June 2023 |  | 951 |  |  | 954 |  |  | 951 |  |  | 987 |  |
| 4.875% Senior Notes due March 2024 |  | 497 |  |  | 498 |  |  | 497 |  |  | 511 |  |
| 4.75% Senior Notes due January 2025 |  | 975 |  |  | 953 |  |  | 975 |  |  | 984 |  |
| 4.875% Senior Notes due June 2027 |  | 695 |  |  | 660 |  |  | 695 |  |  | 698 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 467 |  |  | 489 |  |  | 488 |  |
|  |  | $ | 4,860 |  |  | $ | 4,780 |  |  | $ | 5,065 |  |  | $ | 5,159 |  |
| Less: debt issuance costs |  | (38 | ) |  | — |  |  | (44 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 4,822 |  |  | $ | 4,780 |  |  | $ | 5,021 |  |  | $ | 5,159 |  |
| Less: current portion of long-term debt, net of debt issuance costs of $1 million |  | (503 | ) |  | (507 | ) |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 4,319 |  |  | $ | 4,273 |  |  | $ | 5,021 |  |  | $ | 5,159 |  |
  (was, 2018-01-29, similarity 0.9731):
[0001193125-18-023592:note_history:16]
|  |  | December 29, 2017 |  | June 30, 2017 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 560 |  |  | $ | 567 |  |  | $ | 710 |  |  | $ | 726 |  |
| 4.25% Senior Notes due March 2022 |  | 748 |  |  | 758 |  |  | 748 |  |  | 765 |  |
| 4.75% Senior Notes due June 2023 |  | 951 |  |  | 972 |  |  | 951 |  |  | 987 |  |
| 4.875% Senior Notes due March 2024 |  | 497 |  |  | 504 |  |  | 497 |  |  | 511 |  |
| 4.75% Senior Notes due January 2025 |  | 975 |  |  | 961 |  |  | 975 |  |  | 984 |  |
| 4.875% Senior Notes due June 2027 |  | 695 |  |  | 668 |  |  | 695 |  |  | 698 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 473 |  |  | 489 |  |  | 488 |  |
|  |  | $ | 4,915 |  |  | $ | 4,903 |  |  | $ | 5,065 |  |  | $ | 5,159 |  |
| Less: debt issuance costs |  | (39 | ) |  | — |  |  | (44 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 4,876 |  |  | $ | 4,903 |  |  | $ | 5,021 |  |  | $ | 5,159 |  |
| Less: current portion of long-term debt |  | (560 | ) |  | (567 | ) |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 4,316 |  |  | $ | 4,336 |  |  | $ | 5,021 |  |  | $ | 5,159 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-01):
[0001193125-18-146598:note_history:17]
At March 30, 2018, future principal payments on long-term debt were as follows (in millions):
  (was, 2018-01-29, similarity 0.9492):
[0001193125-18-023592:note_history:17]
At December 29, 2017, future principal payments on long-term debt were as follows (in millions):


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2018-05-01):
[0001193125-18-146598:note_history:18]
On May 1, 2018, the Company’s Board of Directors declared a quarterly cash dividend of $0.63 per share, which will be payable on July 5, 2018 to shareholders of record as of the close of business on June 20, 2018.

- removed (2018-05-01):
[0001193125-18-023592:note_history:19]
On January 29, 2018, the Company’s Board of Directors announced a quarterly cash dividend of $0.63 per share, which will be payable on April 4, 2018 to shareholders of record as of the close of business on March 21, 2018.
