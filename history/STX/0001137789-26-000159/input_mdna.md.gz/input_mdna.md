# STX MD&A — 0001137789-26-000159


## mdna

[0001137789-26-000159:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001137789-26-000159:mdna:2]
The following is a discussion of the Company’s financial condition, changes in financial condition and results of operations for the fiscal years ended July 3, 2026 and June 27, 2025. Discussions of year-to-year comparisons between fiscal years 2025 and 2024 are not included in this Annual Report on Form 10-K and can be found in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended June 27, 2025, which was filed with the SEC on August 1, 2025.

[0001137789-26-000159:mdna:3]
You should read this discussion in conjunction with “Item 8. Financial Statements and Supplementary Data” included elsewhere in this Annual Report on Form 10-K. Except as noted, references to any fiscal year mean the twelve-month period ending on the Friday closest to June 30 of that year. Accordingly, fiscal year 2026 comprised of 53 weeks and ended on July 3, 2026. Fiscal year 2025 comprised of 52 weeks and ended on June 27, 2025. Fiscal year 2032 will be comprised of 53 weeks and will end on July 2, 2032.

[0001137789-26-000159:mdna:4]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is provided in addition to the accompanying Consolidated Financial Statements and notes to assist readers in understanding our results of operations, financial condition and cash flows. Our MD&A is organized as follows:

[0001137789-26-000159:mdna:5]
•Overview of Fiscal Year 2026. Highlights of events in fiscal year 2026 that impacted our financial position.

[0001137789-26-000159:mdna:6]
•Results of Operations. Analysis of our financial results comparing fiscal years 2026 and 2025.

[0001137789-26-000159:mdna:7]
•Liquidity and Capital Resources. Analysis of changes in our balance sheets and cash flows and discussion of our financial condition, including potential sources of liquidity, material cash requirements and their general purpose.

[0001137789-26-000159:mdna:8]
•Critical Accounting Policies and Estimates. Accounting policies and estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001137789-26-000159:mdna:9]
35

[0001137789-26-000159:mdna:10]
For an overview of our business, see “Part I, Item 1. Business”.

[0001137789-26-000159:mdna:11]
Overview of Fiscal Year 2026

[0001137789-26-000159:mdna:12]
During fiscal year 2026, we shipped 789 exabytes of HDD storage capacity. We generated revenue of approximately $12.2 billion with a gross margin of 46% and net income of $3.2 billion. Our operating cash flow was $3.7 billion and we paid $634 million in dividends and repurchased $176 million of our ordinary shares.

[0001137789-26-000159:mdna:13]
We reduced our outstanding debt by $1.4 billion through exchanges of our 2028 Notes for total consideration of $1.3 billion cash and approximately 12.6 million of our ordinary shares as well as repurchases of Senior Notes.

[0001137789-26-000159:mdna:14]
Recent Developments, Economic Conditions and Challenges

[0001137789-26-000159:mdna:15]
During fiscal year 2026, demand for our data storage solutions strengthened. Growth was led by data center end markets in which we experienced sustained demand for our high capacity nearline drives across global cloud customers, as well as increasing sales for enterprise edge deployments. Customers continue to invest in data center infrastructure to serve both traditional data intensive workloads along with growing AI related applications. The ongoing adoption of these applications increases the volume of data being generated, retained and reused, which we believe supports demand growth for scalable, cost-efficient and reliable storage solutions.

[0001137789-26-000159:mdna:16]
At the same time, the macroeconomic environment remains dynamic, marked by heightened geopolitical uncertainty and evolving trade policies. These factors may impact our business and results of operations. We will continue to monitor the situation and assess plans to mitigate future risk to the business. However, we believe the structural changes that we have made to the business, including executing our pricing strategy and maintaining supply discipline, together with the long-term customer engagements we have in place provide greater visibility into future demand trends. We believe our hard drive storage business will continue to benefit from growing demand for data creation, retention and utilization supported by the increasing value organizations derive from their data.

[0001137789-26-000159:mdna:17]
For a further discussion of the uncertainties and business risks, see “Part I, Item 1A. Risk Factors” of our Annual Report.

[0001137789-26-000159:mdna:18]
Results of Operations

[0001137789-26-000159:mdna:19]
We list in the tables below summarized information from our Consolidated Statements of Operations and Comprehensive Income by dollar amounts and as a percentage of revenue:

[0001137789-26-000159:mdna:20]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 3,2026 |  | June 27,2025 |
| Revenue |  | $ | 12,195 |  |  | $ | 9,097 |  |
| Cost of revenue |  | 6,637 |  |  | 5,897 |  |
| Gross profit |  | 5,558 |  |  | 3,200 |  |
| Product development |  | 755 |  |  | 724 |  |
| Marketing and administrative |  | 577 |  |  | 561 |  |
| Legal settlement |  | 105 |  |  | — |  |
| Restructuring and other, net |  | 27 |  |  | 25 |  |
| Income from operations |  | 4,094 |  |  | 1,890 |  |
| Other expense, net |  | (404) |  |  | (377) |  |
| Income before income taxes |  | 3,690 |  |  | 1,513 |  |
| Provision for income taxes |  | 506 |  |  | 44 |  |
| Net income |  | $ | 3,184 |  |  | $ | 1,469 |  |

[0001137789-26-000159:mdna:21]
|  |  | Fiscal Years Ended |
| (As a percentage of Revenue) |  | July 3,2026 |  | June 27,2025 |
| Revenue |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 54 |  |  | 65 |  |
| Gross margin |  | 46 |  |  | 35 |  |
| Product development |  | 6 |  |  | 8 |  |
| Marketing and administrative |  | 5 |  |  | 6 |  |
| Legal settlement |  | 1 |  |  | — |  |
| Restructuring and other, net |  | — |  |  | — |  |
| Operating margin |  | 34 |  |  | 21 |  |
| Other expense, net |  | (3) |  |  | (4) |  |
| Income before income taxes |  | 31 |  |  | 17 |  |
| Provision for income taxes |  | 4 |  |  | 1 |  |
| Net income |  | 27 | % |  | 16 | % |

[0001137789-26-000159:mdna:22]
Revenue

[0001137789-26-000159:mdna:23]
The following table summarizes information regarding consolidated revenues by channel, geography, and market and HDD exabytes shipped:

[0001137789-26-000159:mdna:24]
|  |  | Fiscal Years Ended |
|  |  | July 3,2026 |  | June 27,2025 |
| Revenues by Channel (%) |  |  |  |  |
| OEMs |  | 81 | % |  | 80 | % |
| Distributors |  | 13 | % |  | 12 | % |
| Retailers |  | 6 | % |  | 8 | % |
| Revenues by Geography (%) (1) |  |  |  |  |
| Americas |  | 50 | % |  | 49 | % |
| Asia Pacific |  | 40 | % |  | 41 | % |
| EMEA |  | 10 | % |  | 10 | % |
| Revenues by Market (%) |  |  |  |  |
| Data Center |  | 80 | % |  | 75 | % |
| Edge IoT |  | 20 | % |  | 25 | % |
| HDD Exabytes Shipped |  |  |  |  |
| Nearline |  | 695 |  |  | 497 |  |
| Non-nearline |  | 94 |  |  | 98 |  |
| Total |  | 789 |  |  | 595 |  |

[0001137789-26-000159:mdna:25]
________________________________________________

[0001137789-26-000159:mdna:26]
(1) Revenue is attributed to geography based on the bill from location.

[0001137789-26-000159:mdna:27]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 3,2026 |  | June 27,2025 |  | Change |  | %Change |
| Revenue |  | $ | 12,195 |  |  | $ | 9,097 |  |  | $ | 3,098 |  |  | 34 | % |

[0001137789-26-000159:mdna:28]
Revenue in fiscal year 2026 increased approximately 34%, or $3.1 billion, from fiscal year 2025, primarily due to an increase in nearline exabytes shipped reflecting higher demand for nearline products and favorable pricing actions undertaken by the Company.

[0001137789-26-000159:mdna:29]
37

[0001137789-26-000159:mdna:30]
Cost of Revenue and Gross Margin

[0001137789-26-000159:mdna:31]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 3,2026 |  | June 27,2025 |  | Change |  | %Change |
| Cost of revenue |  | $ | 6,637 |  |  | $ | 5,897 |  |  | $ | 740 |  |  | 13 | % |
| Gross profit |  | 5,558 |  |  | 3,200 |  |  | 2,358 |  |  | 74 | % |
| Gross margin |  | 46 | % |  | 35 | % |  |  |  |  |

[0001137789-26-000159:mdna:32]
For fiscal year 2026, gross margin increased by 11 percentage points compared to the prior fiscal year primarily driven by pricing actions undertaken by the Company and product mix shift to higher capacity products.

[0001137789-26-000159:mdna:33]
Operating Expenses

[0001137789-26-000159:mdna:34]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 3,2026 |  | June 27,2025 |  | Change |  | %Change |
| Product development |  | $ | 755 |  |  | $ | 724 |  |  | $ | 31 |  |  | 4 | % |
| Marketing and administrative |  | 577 |  |  | 561 |  |  | 16 |  |  | 3 | % |
| Legal settlement |  | 105 |  | — |  |  | 105 |  | 100 | % |
| Restructuring and other, net |  | 27 |  |  | 25 |  |  | 2 |  |  | 8 | % |
| Operating expenses |  | $ | 1,464 |  |  | $ | 1,310 |  |  | $ | 154 |  |  |  |

[0001137789-26-000159:mdna:35]
Product Development Expense. Product development expenses for fiscal year 2026 increased by $31 million from fiscal year 2025 primarily due to a $22 million increase in outside services costs, a $7 million increase in compensation and other employee benefits and a $7 million increase in facilities costs, partially offset by an $8 million decrease in material expenses.

[0001137789-26-000159:mdna:36]
Marketing and Administrative Expense. Marketing and administrative expenses for fiscal year 2026 increased by $16 million from fiscal year 2025 primarily due to an $11 million increase in compensation and other employee benefits and a $5 million increase in information technology expenses.

[0001137789-26-000159:mdna:37]
Legal settlement. We recorded a charge of $105 million in fiscal year 2026 related to a litigation matter. Refer to “Item 8. Financial Statements and Supplementary Data—Note 12. Legal, Environmental and Other Contingencies” for more details.

[0001137789-26-000159:mdna:38]
Restructuring and Other, net. In fiscal year 2026, we recorded $27 million of restructuring charges, primarily related to employee related termination benefits. In fiscal year 2025, we recorded $25 million of restructuring charges in Operating expenses, primarily related to employee related termination benefits and right-of-use (“ROU”) asset impairment charges.

[0001137789-26-000159:mdna:39]
Other Expense, net

[0001137789-26-000159:mdna:40]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 3,2026 |  | June 27,2025 |  | Change |  | %Change |
| Other expense, net |  | $ | 404 |  |  | $ | 377 |  |  | $ | 27 |  |  | 7 | % |

[0001137789-26-000159:mdna:41]
Other expense, net for fiscal year 2026 primarily related to $284 million of interest expense and $151 million of net loss from debt transactions, partially offset by $30 million of interest income. Other expense, net for fiscal year 2025 primarily related to $321 million of interest expense and $53 million loss on investments.

[0001137789-26-000159:mdna:42]
Income Taxes

[0001137789-26-000159:mdna:43]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 3,2026 |  | June 27,2025 |  | Change |  | %Change |
| Provision for income taxes |  | $ | 506 |  |  | $ | 44 |  |  | $ | 462 |  |  | 1,050 | % |

[0001137789-26-000159:mdna:44]
We recorded an income tax provision of $506 million for fiscal year 2026 compared to an income tax provision of $44 million for fiscal year 2025.

[0001137789-26-000159:mdna:45]
We established Singapore as our principal executive offices in fiscal year 2024. Our parent holding company owns various U.S. and non-Singaporean subsidiaries that operate in multiple non-Singaporean income tax jurisdictions. Our worldwide operating income is either subject to varying rates of income tax or is exempt from income tax due to tax incentive programs we operate under in Singapore and Thailand. Starting from fiscal year 2026, major jurisdictions that we operate in have implemented Pillar Two global minimum tax. Our effective tax rate was 13.73% for fiscal year 2026 and 2.91% for fiscal year 2025.

[0001137789-26-000159:mdna:46]
Our income tax recorded for fiscal year 2026 differed from the provision for income taxes that would be derived by applying the Singaporean statutory rate of 17% to income before income taxes, primarily due to the net effect of tax benefits related to earnings generated in jurisdictions that are subject to tax incentive programs, offset by the effects of Pillar Two global minimum tax. The fiscal year 2026 provision for income taxes also includes a discrete tax benefit related to the release of certain valuation allowances in connection with the OBBBA in July 2025 and net excess tax benefits related to share-based compensation expense.

[0001137789-26-000159:mdna:47]
Our income tax provision recorded for fiscal year 2025 differed from the provision for income taxes that would be derived by applying the Singaporean statutory rate of 17% to income before income taxes, primarily due to the net effect of (i) tax benefits related to earnings generated in jurisdictions that are subject to tax incentive programs and (ii) changes in valuation allowance.

[0001137789-26-000159:mdna:48]
Liquidity and Capital Resources

[0001137789-26-000159:mdna:49]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash will continue to be sufficient to fund our operations and meet our cash requirements for the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs and capital expenditures, will allow us to manage the ongoing impact of market demand disruptions on our business operations for the foreseeable future. However, some challenges to our industry and to our business continue to remain uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to global economic factors.

[0001137789-26-000159:mdna:50]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of July 3, 2026. For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements among others, see “Part I, Item 1A. Risk Factors” of our Annual Report.

[0001137789-26-000159:mdna:51]
Cash and Cash Equivalents

[0001137789-26-000159:mdna:52]
|  |  | As of |  |  |
| (Dollars in millions) |  | July 3,2026 |  | June 27,2025 |  | Change |
| Cash and cash equivalents |  | $ | 1,704 |  |  | $ | 891 |  |  | $ | 813 |  |

[0001137789-26-000159:mdna:53]
The following table summarizes results from the Consolidated Statements of Cash Flows for the periods indicated:

[0001137789-26-000159:mdna:54]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 3,2026 |  | June 27,2025 |
| Net cash flow provided by (used in): |  |  |  |  |
| Operating activities |  | $ | 3,674 |  |  | $ | 1,083 |  |
| Investing activities |  | (525) |  |  | (276) |  |
| Financing activities |  | (2,337) |  |  | (1,274) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 812 |  |  | $ | (467) |  |

[0001137789-26-000159:mdna:55]
Cash Provided by Operating Activities

[0001137789-26-000159:mdna:56]
Cash provided by operating activities for fiscal year 2026 was $3.7 billion and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, and the following major working capital related movements:

[0001137789-26-000159:mdna:57]
•an increase of $575 million in accounts receivable, primarily due to increased revenue;

[0001137789-26-000159:mdna:58]
•an increase of $131 million in inventory, primarily due to an increase in work-in-process inventory; partially offset by

[0001137789-26-000159:mdna:59]
•an increase of $528 million in accrued expenses, income taxes and warranty, primarily due to an increase in accrued income taxes and legal settlements;

[0001137789-26-000159:mdna:60]
•an increase of $66 million in accounts payable, primarily due to an increase in capital expenditures.

[0001137789-26-000159:mdna:61]
Cash provided by operating activities for fiscal year 2025 was $1.1 billion and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, and the following major working capital related movements:

[0001137789-26-000159:mdna:62]
•an increase of $513 million in accounts receivable, primarily due to higher revenue and lower accounts receivable factoring;

[0001137789-26-000159:mdna:63]
•a decrease of $242 million in accounts payable, primarily due to timing of payments; and

[0001137789-26-000159:mdna:64]
•an increase of $201 million in inventory, primarily due to an increase in purchased materials and finished goods inventory; partially offset by

[0001137789-26-000159:mdna:65]
•an increase of $207 million in accrued employee compensation, primarily due to an increase in our variable compensation expense.

[0001137789-26-000159:mdna:66]
Cash Used in Investing Activities

[0001137789-26-000159:mdna:67]
In fiscal year 2026, we used $525 million net cash for investing activities, which was primarily due to payments for the purchase of property, equipment and leasehold improvements of $569 million, partially offset by $31 million proceeds from the sale of certain investments and $15 million proceeds from business divestiture.

[0001137789-26-000159:mdna:68]
In fiscal year 2025, we used $276 million net cash for investing activities, which was primarily due to payments for the purchase of property, equipment and leasehold improvements of $265 million and net cash used in the acquisition of Intevac of $47 million, which includes proceeds from the sale of Intevac’s investments post-acquisition (refer to “Item 8. Financial Statements and Supplementary Data—Note 16. Acquisition and Divestiture” for more details), offset by $10 million from the sale of equity investments, and $25 million from the proceeds of business divestiture.

[0001137789-26-000159:mdna:69]
Cash Used in Financing Activities

[0001137789-26-000159:mdna:70]
Net cash used in financing activities of $2.3 billion for fiscal year 2026 was primarily attributable to the following activities:

[0001137789-26-000159:mdna:71]
•$1.4 billion redemption and repurchase of long-term debt;

[0001137789-26-000159:mdna:72]
•$634 million in dividend payments;

[0001137789-26-000159:mdna:73]
•$176 million in payments for repurchases of our ordinary shares;

[0001137789-26-000159:mdna:74]
•$119 million taxes paid related to net share settlement of equity awards; and

[0001137789-26-000159:mdna:75]
•$22 million debt fees relating to redemption and repurchase of long-term debt and debt exchange; partially offset by

[0001137789-26-000159:mdna:76]
•$56 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-26-000159:mdna:77]
Net cash used in financing activities of $1.3 billion for fiscal year 2025 was primarily attributable to the following activities:

[0001137789-26-000159:mdna:78]
•$1.1 billion repurchases of long-term debt;

[0001137789-26-000159:mdna:79]
•$600 million in dividend payments;

[0001137789-26-000159:mdna:80]
•$54 million taxes paid related to net share settlement of equity awards; and

[0001137789-26-000159:mdna:81]
•$14 million debt fees relating to issuance and repurchase of long-term debt; partially offset by

[0001137789-26-000159:mdna:82]
•$400 million in net proceeds from the issuance of long-term debt; and

[0001137789-26-000159:mdna:83]
•$72 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-26-000159:mdna:84]
40

[0001137789-26-000159:mdna:85]
Liquidity Sources

[0001137789-26-000159:mdna:86]
Our primary sources of liquidity as of July 3, 2026, consist of: (1) approximately $1.7 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.3 billion available for borrowing under our senior unsecured revolving credit facility (“Revolving Credit Facility”), which is part of our Credit Agreement (as defined within “Item 8. Financial Statements and Supplementary Data—Note 4. Debt”).

[0001137789-26-000159:mdna:87]
As of July 3, 2026, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-26-000159:mdna:88]
As of July 3, 2026, the Credit Agreement includes one financial covenant, net leverage ratio of less than or equal to 6.75 to 1.00, commencing with the fiscal quarter ended June 27, 2025 and declining over time so that the maximum permitted net leverage ratio for each fiscal quarter ending after July 2, 2027 is 4.25 to 1.00. We continue to evaluate our debt portfolio and structure to comply with our financial debt covenants. As of July 3, 2026, we were in compliance with all of the covenants under our debt agreements.

[0001137789-26-000159:mdna:89]
We believe that our sources of cash will be sufficient to fund our operations and meet our cash requirements for at least the next 12 months. Our ability to fund liquidity requirements beyond 12 months will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001137789-26-000159:mdna:90]
For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, among others, see “Part I, Item 1A. Risk Factors” of this Annual Report.

[0001137789-26-000159:mdna:91]
Cash Requirements and Commitments

[0001137789-26-000159:mdna:92]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, quarterly dividend, share repurchase program and any future strategic investments.

[0001137789-26-000159:mdna:93]
Purchase obligations

[0001137789-26-000159:mdna:94]
Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. From time to time, we enter into long-term, non-cancelable purchase commitments or make large up-front investments with certain suppliers in order to secure certain components or technologies for the production of our products or to supplement our internal manufacturing capacity for certain components. As of July 3, 2026, we had unconditional purchase obligations of approximately $2.1 billion, primarily related to purchases of inventory components with our suppliers. We expect $1.6 billion of these commitments to be paid within one year. In addition, we also had certain long-term market share based non-cancellable inventory purchase commitments as of July 3, 2026.

[0001137789-26-000159:mdna:95]
Capital expenditures

[0001137789-26-000159:mdna:96]
We incur material capital expenditures to design and manufacture our products that depend on advanced technologies and manufacturing techniques. As of July 3, 2026, we had unconditional commitments of $465 million primarily related to purchases of equipment, of which approximately $375 million is expected to be paid within one year. For fiscal year 2027, supporting volume ramp of hard drives utilizing HAMR technology, we expect capital expenditures to be higher than fiscal year 2026 and still within our target range of 4-6% of revenue.

[0001137789-26-000159:mdna:97]
Operating leases

[0001137789-26-000159:mdna:98]
We are a lessee in several operating leases related to real estate facilities for warehouse, office and lab space. As of July 3, 2026, the amount of future minimum rent expense for both occupied and vacated facilities under non-cancelable operating lease contracts was $437 million, of which $66 million is expected to be paid within one year. Refer to “Item 8. Financial Statements and Supplementary Data—Note 6. Leases” for details.

[0001137789-26-000159:mdna:99]
41

[0001137789-26-000159:mdna:100]
Long-term debt and interest payments on debt

[0001137789-26-000159:mdna:101]
As of July 3, 2026, the future principal payment obligation on our long-term debt was $3.6 billion, which will mature in more than one year. As of July 3, 2026, future interest payments on this outstanding debt are estimated to be approximately $1.3 billion, of which $243 million is expected to be paid within one year. On June 11, 2026, we issued a Notice of Full Provisional Redemption to holders of the 2028 Notes for the remaining principal amount of $185 million. On September 8, 2026, all then-outstanding Notes that are called for Redemption and which have not been submitted for exchange will be redeemed for cash at a price equal to the principal amount plus accrued and unpaid interest. Additionally, subsequent to our Consolidated Balance Sheet date, on July 15, 2026, we redeemed $1 billion principal amount of certain Senior Notes. From time to time, we may refinance, repurchase, redeem or otherwise extinguish any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase or redeem outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 8. Financial Statements and Supplementary Data—Note 4. Debt” for more details.

[0001137789-26-000159:mdna:102]
Legal settlements

[0001137789-26-000159:mdna:103]
As of July 3, 2026, we accrued a total of $225 million relating to legal settlements, of which $150 million is expected to be paid within one year and $75 million thereafter. Refer to “Item 8. Financial Statements and Supplementary Data—Note 12. Legal, Environmental and Other Contingencies” for more details.

[0001137789-26-000159:mdna:104]
Income Tax

[0001137789-26-000159:mdna:105]
As of July 3, 2026, we had a $43 million liability for unrecognized tax benefits, none of which is expected to be settled within one year. Outside of one year, we are unable to make a reasonably reliable estimate of when cash settlement with a taxing authority will occur.

[0001137789-26-000159:mdna:106]
Dividends

[0001137789-26-000159:mdna:107]
On July 28, 2026, our Board of Directors declared a quarterly cash dividend of $0.74 per share, which will be payable on October 7, 2026 to shareholders of record as of the close of business on September 24, 2026. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-26-000159:mdna:108]
Share repurchases

[0001137789-26-000159:mdna:109]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means, including through the use of derivative transactions. During fiscal year 2026, we repurchased approximately 1 million of our ordinary shares including approximately 0.4 million shares withheld for statutory tax withholdings related to vesting of employee equity awards. See “Item 5. Market for Registrant’s Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities-Repurchases of Our Equity Securities”. As of July 3, 2026, $4.8 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-26-000159:mdna:110]
We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-26-000159:mdna:111]
Critical Accounting Policies and Estimates

[0001137789-26-000159:mdna:112]
The Company’s accounting policies are more fully described in “Item 8. Financial Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of Significant Accounting Policies”. The methods, estimates and judgments we use in applying our most critical accounting policies have a significant impact on the results we report in our Consolidated Financial Statements. Critical accounting estimates are those estimates that involve a significant level of estimation uncertainty and have had or are reasonably likely to have a material impact on our financial condition or results of operations. Based on this definition, our most critical accounting policies include: Revenue - Sales Program Accruals and Income Taxes. Below, we discuss these policies further, as well as the estimates and judgments involved. We also have other accounting policies and accounting estimates relating to warranty, valuation of inventories, assessing goodwill and other long-lived assets for impairment, valuation of share-based payments and restructuring. We believe that these other accounting policies and accounting estimates either do not generally require us to make estimates and judgments that are as difficult or as subjective, or it is less likely that they would have a material impact on our reported results of operations for a given period.

[0001137789-26-000159:mdna:113]
Revenue - Sales Program Accruals. We record estimated variable consideration at the time of revenue recognition as a reduction to revenue. Variable consideration generally consists of expected rebates to be provided in relation to sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer's volume of purchases from us or other agreed upon rebate programs. For the distribution and retail channel, these sales incentive programs typically involve estimating the most likely amount of rebates based on historical price incentives, known future price trends, and channel inventory level.

[0001137789-26-000159:mdna:114]
Income Taxes. We make certain estimates and judgments in determining income tax expense for financial statement purposes. These estimates and judgments occur in the calculation of tax credits, recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for income tax and financial statement purposes, as well as tax liabilities associated with uncertain tax positions.

[0001137789-26-000159:mdna:115]
The deferred tax assets we record each period depend primarily on our ability to generate future taxable income in the United States and certain non-U.S. jurisdictions. Each period, we evaluate the need for a valuation allowance for our deferred tax assets and, if necessary, adjust the valuation allowance so that net deferred tax assets are recorded only to the extent we conclude it is more likely than not that these deferred tax assets will be realized.

[0001137789-26-000159:mdna:116]
In evaluating our ability to recover our deferred tax assets, in full or in part, we consider all available positive and negative evidence, including our past operating results, and our forecast of future earnings, future taxable income and prudent and feasible tax planning strategies. Actual operating results in future years could differ from our current assumptions, judgments, and estimates. If our outlook for future taxable income changes significantly, our assessment of the need for, and the amount of, a valuation allowance may also change resulting in an additional tax provision or benefit.

[0001137789-26-000159:mdna:117]
Recent Accounting Pronouncements

[0001137789-26-000159:mdna:118]
See “Item 8. Financial Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.
