# STX MD&A — 0001137789-22-000031


## mdna

[0001137789-22-000031:mdna:1]
[same as prior period, unchanged from 0001137789-22-000014:mdna:1]

[0001137789-22-000031:mdna:2]
The following is a discussion of the financial condition, changes in financial condition and results of operations for our fiscal quarters ended April 1, 2022, December 31, 2021 and April 2, 2021, referred to herein as the “March 2022 quarter,” the “December 2021 quarter,” and the “March 2021 quarter,” respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The March 2022 quarter, the December 2021 quarter and the March 2021 quarter were each 13 weeks.

[0001137789-22-000031:mdna:3]
[same as prior period, unchanged from 0001137789-22-000014:mdna:3]

[0001137789-22-000031:mdna:4]
[same as prior period, unchanged from 0001137789-22-000014:mdna:4]

[0001137789-22-000031:mdna:5]
[same as prior period, unchanged from 0001137789-22-000014:mdna:5]

[0001137789-22-000031:mdna:6]
[same as prior period, unchanged from 0001137789-22-000014:mdna:6]

[0001137789-22-000031:mdna:7]
[same as prior period, unchanged from 0001137789-22-000014:mdna:7]

[0001137789-22-000031:mdna:8]
[same as prior period, unchanged from 0001137789-22-000014:mdna:8]

[0001137789-22-000031:mdna:9]
•the Company’s ability to effectively manage its debt obligations and comply with certain covenants in its credit facilities with respect to financial ratios and financial condition tests and its ability to maintain a favorable cash liquidity position;

[0001137789-22-000031:mdna:10]
[same as prior period, unchanged from 0001137789-22-000014:mdna:10]

[0001137789-22-000031:mdna:11]
[same as prior period, unchanged from 0001137789-22-000014:mdna:11]

[0001137789-22-000031:mdna:12]
•disruptions to the Company’s supply chain or production capabilities, including ongoing shortages of certain materials, any electricity restrictions and increases in logistics, materials and operation costs;

[0001137789-22-000031:mdna:13]
[same as prior period, unchanged from 0001137789-22-000014:mdna:13]

[0001137789-22-000031:mdna:14]
•changes in tax laws, such as global tax developments applicable to multinational businesses; the impact of trade barriers, such as import/export duties and restrictions, sanctions, tariffs and quotas, imposed by the U.S. or other countries in which the Company conducts business; the evolving legal and regulatory, economic, environmental and administrative climate in the international markets where the Company operates;

[0001137789-22-000031:mdna:15]
•the effect of geopolitical uncertainties, such as the Russia-Ukraine conflict, on international commerce, the global economy, and/or our business; and

[0001137789-22-000031:mdna:16]
[same as prior period, unchanged from 0001137789-22-000014:mdna:15]

[0001137789-22-000031:mdna:17]
[same as prior period, unchanged from 0001137789-22-000014:mdna:16]

[0001137789-22-000031:mdna:18]
[same as prior period, unchanged from 0001137789-22-000014:mdna:17]

[0001137789-22-000031:mdna:19]
•Overview of the March 2022 quarter. Highlights of events in the March 2022 quarter that impacted our financial position.

[0001137789-22-000031:mdna:20]
•Results of Operations. Analysis of our financial results comparing the March 2022 quarter to the December 2021 quarter and the March 2021 quarter.

[0001137789-22-000031:mdna:21]
[same as prior period, unchanged from 0001137789-22-000014:mdna:20]

[0001137789-22-000031:mdna:22]
[same as prior period, unchanged from 0001137789-22-000014:mdna:21]

[0001137789-22-000031:mdna:23]
[same as prior period, unchanged from 0001137789-22-000014:mdna:22]

[0001137789-22-000031:mdna:24]
Overview of the March 2022 quarter

[0001137789-22-000031:mdna:25]
During the March 2022 quarter, we shipped 154 exabytes of HDD storage capacity. We generated revenue of approximately $2.8 billion with a gross margin of 29% and our operating cash flow was $460 million. We fully repaid the $220 million principal amount outstanding of our 2022 Notes. We repurchased approximately 4.2 million of our ordinary shares for $417 million and paid $154 million in dividends.

[0001137789-22-000031:mdna:26]
Impact of COVID-19 Pandemic

[0001137789-22-000031:mdna:27]
The pandemic continues to impact our business and results of operations. During the March 2022 quarter, we experienced the ongoing impacts of supply chain disruptions, higher logistics, materials and operational costs globally, as well as other inflationary pressures. Additionally, constraints from certain component shortages impacted our ability to fulfill demand primarily for our non-HDD business. Our customers also continued to experience certain supply chain and demand disruptions, resulting in demand variations across certain of our end markets, including impacts from periodic governmental lockdown measures.

[0001137789-22-000031:mdna:28]
We continue to actively monitor the effects and potential impacts of the pandemic on all aspects of our business, supply chain, liquidity and capital resources, including governmental policies that could periodically shut down an entire city where we, our suppliers or our customers operate. We are also actively working on opportunities to lower our cost structure and drive further operational efficiencies. We are complying with governmental rules and guidelines across all of our sites. Although we are unable to predict the future impact of the pandemic on our business, results of operations, liquidity or capital resources at this time, we expect we will continue to be negatively affected if the pandemic and related public and private health measures result in substantial manufacturing or supply chain challenges, substantial reductions or delays in demand due to disruptions in the operations of our customers or partners, disruptions in local and global economies, volatility in the global financial markets, sustained reductions or volatility in overall demand trends, restrictions on the export or shipment of our products or our customer’s products, or other unexpected ramifications from the pandemic. For a further discussion of the uncertainties and business risks associated with the pandemic, see the section entitled “Risk Factors” in Part I, Item 1A of our Annual Report on Form 10-K for the fiscal year ended July 2, 2021.

[0001137789-22-000031:mdna:29]
[same as prior period, unchanged from 0001137789-22-000014:mdna:27]

[0001137789-22-000031:mdna:30]
[same as prior period, unchanged from 0001137789-22-000014:mdna:28]

[0001137789-22-000031:mdna:31]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 1,2022 |  | December 31,2021 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
| Revenue |  | $ | 2,802 |  |  | $ | 3,116 |  |  | $ | 2,731 |  |  | $ | 9,033 |  |  | $ | 7,668 |  |
| Cost of revenue |  | 1,996 |  |  | 2,168 |  |  | 1,991 |  |  | 6,323 |  |  | 5,636 |  |
| Gross profit |  | 806 |  |  | 948 |  |  | 740 |  |  | 2,710 |  |  | 2,032 |  |
| Product development |  | 233 |  |  | 228 |  |  | 227 |  |  | 694 |  |  | 671 |  |
| Marketing and administrative |  | 141 |  |  | 136 |  |  | 126 |  |  | 410 |  |  | 366 |  |
| Amortization of intangibles |  | 3 |  |  | 3 |  |  | 3 |  |  | 9 |  |  | 9 |  |
| Restructuring and other, net |  | — |  |  | 1 |  |  | (2) |  |  | 2 |  |  | 1 |  |
| Income from operations |  | 429 |  |  | 580 |  |  | 386 |  |  | 1,595 |  |  | 985 |  |
| Other expense, net |  | (78) |  |  | (66) |  |  | (47) |  |  | (197) |  |  | (134) |  |
| Income before income taxes |  | 351 |  |  | 514 |  |  | 339 |  |  | 1,398 |  |  | 851 |  |
| Provision for income taxes |  | 5 |  |  | 13 |  |  | 10 |  |  | 25 |  |  | 19 |  |
| Net income |  | $ | 346 |  |  | $ | 501 |  |  | $ | 329 |  |  | $ | 1,373 |  |  | $ | 832 |  |

[0001137789-22-000031:mdna:32]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
|  |  | April 1,2022 |  | December 31,2021 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 71 |  |  | 70 |  |  | 73 |  |  | 70 |  |  | 73 |  |
| Gross margin |  | 29 |  |  | 30 |  |  | 27 |  |  | 30 |  |  | 27 |  |
| Product development |  | 8 |  |  | 7 |  |  | 9 |  |  | 9 |  |  | 9 |  |
| Marketing and administrative |  | 5 |  |  | 4 |  |  | 5 |  |  | 5 |  |  | 5 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Restructuring and other, net |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating margin |  | 16 |  |  | 19 |  |  | 14 |  |  | 16 |  |  | 13 |  |
| Other expense, net |  | (4) |  |  | (3) |  |  | (2) |  |  | (2) |  |  | (2) |  |
| Income before income taxes |  | 12 |  |  | 16 |  |  | 12 |  |  | 14 |  |  | 11 |  |
| Provision for income taxes |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income |  | 12 | % |  | 16 | % |  | 12 | % |  | 16 | % |  | 11 | % |

[0001137789-22-000031:mdna:33]
[same as prior period, unchanged from 0001137789-22-000014:mdna:31]

[0001137789-22-000031:mdna:34]
[same as prior period, unchanged from 0001137789-22-000014:mdna:32]

[0001137789-22-000031:mdna:35]
[same as prior period, unchanged from 0001137789-22-000014:mdna:33]

[0001137789-22-000031:mdna:36]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
|  |  | April 1,2022 |  | December 31,2021 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 77 | % |  | 70 | % |  | 71 | % |  | 73 | % |  | 69 | % |
| Distributors |  | 12 | % |  | 18 | % |  | 17 | % |  | 16 | % |  | 17 | % |
| Retailers |  | 11 | % |  | 12 | % |  | 12 | % |  | 11 | % |  | 14 | % |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 46 | % |  | 46 | % |  | 47 | % |  | 48 | % |  | 48 | % |
| Americas |  | 42 | % |  | 38 | % |  | 34 | % |  | 38 | % |  | 34 | % |
| EMEA |  | 12 | % |  | 16 | % |  | 19 | % |  | 14 | % |  | 18 | % |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 69 | % |  | 66 | % |  | 60 | % |  | 66 | % |  | 59 | % |
| Legacy |  | 23 | % |  | 25 | % |  | 32 | % |  | 25 | % |  | 33 | % |
| Other |  | 8 | % |  | 9 | % |  | 8 | % |  | 9 | % |  | 8 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 133 |  |  | 137 |  |  | 111 |  |  | 402 |  |  | 294 |  |
| Legacy |  | 21 |  |  | 26 |  |  | 29 |  |  | 74 |  |  | 89 |  |
| Total |  | 154 |  |  | 163 |  |  | 140 |  |  | 476 |  |  | 383 |  |
| HDD Price per Terabyte |  | $ | 17 |  |  | $ | 17 |  |  | $ | 18 |  |  | $ | 17 |  |  | $ | 18 |  |

[0001137789-22-000031:mdna:37]
[same as prior period, unchanged from 0001137789-22-000014:mdna:35]

[0001137789-22-000031:mdna:38]
[same as prior period, unchanged from 0001137789-22-000014:mdna:36]

[0001137789-22-000031:mdna:39]
Revenue in the March 2022 quarter decreased by $314 million from the December 2021 quarter primarily due to the decrease in exabytes shipped as a result of lower demand in legacy and certain mass capacity markets that were impacted by the pandemic and seasonality declines.

[0001137789-22-000031:mdna:40]
Revenue in the March 2022 quarter increased by $71 million from the March 2021 quarter primarily due to an increase in mass capacity storage exabytes shipped, partially offset by a decrease in legacy market exabytes shipped.

[0001137789-22-000031:mdna:41]
Revenue for the nine months ended April 1, 2022 increased by $1.4 billion from the nine months ended April 2, 2021 primarily due to an increase in mass capacity storage exabytes shipped, partially offset by a decrease in legacy market exabytes shipped.

[0001137789-22-000031:mdna:42]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 14% of gross revenue for each of the March 2022 quarter, December 2021 quarter and March 2021 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-22-000031:mdna:43]
[same as prior period, unchanged from 0001137789-22-000014:mdna:42]

[0001137789-22-000031:mdna:44]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 1,2022 |  | December 31,2021 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
| Cost of revenue |  | $ | 1,996 |  |  | $ | 2,168 |  |  | $ | 1,991 |  |  | $ | 6,323 |  |  | $ | 5,636 |  |
| Gross profit |  | 806 |  |  | 948 |  |  | 740 |  |  | 2,710 |  |  | 2,032 |  |
| Gross margin |  | 29 | % |  | 30 | % |  | 27 | % |  | 30 | % |  | 27 | % |

[0001137789-22-000031:mdna:45]
[same as prior period, unchanged from 0001137789-22-000014:mdna:40]

[0001137789-22-000031:mdna:46]
Gross margin for the March 2022 quarter decreased compared to the December 2021 quarter primarily due to price erosion, less favorable product mix, a decrease in exabytes shipped and higher component costs resulting from the pandemic and global inflationary pressures.

[0001137789-22-000031:mdna:47]
Gross margin for the March 2022 quarter increased compared to the March 2021 quarter primarily due to improved product mix, partially offset by higher component and logistics costs resulting from the pandemic and global inflationary pressures.

[0001137789-22-000031:mdna:48]
Gross margin for the nine months ended April 1, 2022 increased compared to the nine months ended April 2, 2021 primarily driven by improved product mix, partially offset by higher component and logistics costs resulting from the pandemic and global inflationary pressures.

[0001137789-22-000031:mdna:49]
In the March 2022 quarter, total warranty cost was 0.9% of revenue and included an unfavorable change in estimates of prior warranty accruals of 0.2% of revenue primarily due to changes to our estimated future product return rates. Warranty cost related to new shipments was 0.7% of revenue for each of the March 2022 quarter, December 2021 quarter and March 2021 quarter, respectively.

[0001137789-22-000031:mdna:50]
[same as prior period, unchanged from 0001137789-22-000014:mdna:48]

[0001137789-22-000031:mdna:51]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 1,2022 |  | December 31,2021 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
| Product development |  | $ | 233 |  |  | $ | 228 |  |  | $ | 227 |  |  | $ | 694 |  |  | $ | 671 |  |
| Marketing and administrative |  | 141 |  |  | 136 |  |  | 126 |  |  | 410 |  |  | 366 |  |
| Amortization of intangibles |  | 3 |  |  | 3 |  |  | 3 |  |  | 9 |  |  | 9 |  |
| Restructuring and other, net |  | — |  |  | 1 |  |  | (2) |  |  | 2 |  |  | 1 |  |
| Operating expenses |  | $ | 377 |  |  | $ | 368 |  |  | $ | 354 |  |  | $ | 1,115 |  |  | $ | 1,047 |  |

[0001137789-22-000031:mdna:52]
Product development expense. Product development expense for the March 2022 quarter increased by $5 million compared to the December 2021 quarter primarily due to a $3 million increase in compensation and other employee benefits.

[0001137789-22-000031:mdna:53]
Product development expense increased by $6 million in the March 2022 quarter compared to the March 2021 quarter primarily due to a $6 million increase in materials expense and a $4 million increase in compensation and other employee benefits, partially offset by a $3 million decrease in outside services expense.

[0001137789-22-000031:mdna:54]
Product development expense increased by $23 million for the nine months ended April 1, 2022 compared to the nine months ended April 2, 2021 primarily due to a $16 million increase in materials expense, a $9 million increase in variable compensation expense, a $6 million increase in compensation and other employee benefits and a $3 million increase in equipment expense, partially offset by an $11 million decrease in outside services expense.

[0001137789-22-000031:mdna:55]
Marketing and administrative expense. Marketing and administrative expense increased by $5 million for the March 2022 quarter compared to the December 2021 quarter primarily due to a $2 million increase in outside services expense and $1 million increase in equipment expense.

[0001137789-22-000031:mdna:56]
Marketing and administrative expense increased by $15 million in the March 2022 quarter compared to the March 2021 quarter primarily due to a $5 million increase in compensation and other employee benefits, a $2 million increase in outside services and a $2 million increase in travel expenses as a result of the easing of pandemic-related travel restrictions.

[0001137789-22-000031:mdna:57]
Marketing and administrative expense increased by $44 million for the nine months ended April 1, 2022 compared to the nine months ended April 2, 2021 primarily due to a $10 million increase in compensation and other employee benefits, a $10 million increase in outside services expense, a $6 million increase in variable compensation expense, a $4 million increase in travel expenses as a result of the easing of pandemic-related travel restrictions, a $4 million increase in information technology costs and a $2 million increase in advertising costs.

[0001137789-22-000031:mdna:58]
Amortization of intangibles. Amortization of intangibles for the March 2022 quarter remained flat compared to the December 2021 quarter.

[0001137789-22-000031:mdna:59]
Amortization of intangibles for the three and nine months ended April 1, 2022 remained flat, compared to the three and nine months ended April 2, 2021, respectively.

[0001137789-22-000031:mdna:60]
[same as prior period, unchanged from 0001137789-22-000014:mdna:59]

[0001137789-22-000031:mdna:61]
[same as prior period, unchanged from 0001137789-22-000014:mdna:60]

[0001137789-22-000031:mdna:62]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 1,2022 |  | December 31,2021 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
| Other expense, net |  | $ | (78) |  |  | $ | (66) |  |  | $ | (47) |  |  | $ | (197) |  |  | $ | (134) |  |

[0001137789-22-000031:mdna:63]
Other expense, net. Other expense, net for the March 2022 quarter increased by $12 million from the December 2021 quarter primarily due to a net $13 million impairment charge related to a strategic investment in the March 2022 quarter.

[0001137789-22-000031:mdna:64]
Other expense, net for the March 2022 quarter increased by $31 million compared to the March 2021 quarter primarily due to a net $13 million impairment charge in the March 2022 quarter related to a strategic investment, a $10 million non-recurring gain from our strategic investments in the March 2021 quarter and a $4 million increase in interest expense from the issuance of long-term debt.

[0001137789-22-000031:mdna:65]
Other expense, net for the nine months ended April 1, 2022 increased by $63 million compared to the nine months ended April 2, 2021 primarily due to a net $34 million higher non-recurring gain from our strategic investments in the prior-year period and a $23 million increase in interest expense from the issuance of long-term debt.

[0001137789-22-000031:mdna:66]
[same as prior period, unchanged from 0001137789-22-000014:mdna:65]

[0001137789-22-000031:mdna:67]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 1,2022 |  | December 31,2021 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
| Provision for income taxes |  | $ | 5 |  |  | $ | 13 |  |  | $ | 10 |  |  | $ | 25 |  |  | $ | 19 |  |

[0001137789-22-000031:mdna:68]
We recorded income tax provisions of $5 million and $25 million for the three and nine months ended April 1, 2022, respectively. The income tax provision for the three months ended April 1, 2022 included approximately $6 million of net discrete tax benefit, primarily associated with a change in the applicable tax rate within our non-U.S. operations. The income tax provision for the nine months ended April 1, 2022 included approximately $15 million of net discrete tax benefit, primarily associated with the net excess tax benefits related to share-based compensation expense.

[0001137789-22-000031:mdna:69]
During the nine months ended April 1, 2022, our unrecognized tax benefits excluding interest and penalties increased by approximately $8 million to $116 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. During the twelve months beginning April 2, 2022, we expect that our unrecognized tax benefits could be reduced by an immaterial amount, as a result of the expiration of certain statutes of limitation.

[0001137789-22-000031:mdna:70]
We recorded income tax provisions of $10 million and $19 million for the three and nine months ended April 2, 2021, respectively. The income tax provision for the three months ended April 2, 2021 included approximately $4 million of net discrete tax benefit, primarily associated with filing of tax returns in various jurisdictions. The income tax provision for the nine months ended April 2, 2021 included approximately $15 million of net discrete tax benefits, primarily associated with net excess tax benefits related to share-based compensation expense, filing of tax returns in various jurisdictions, and postponement of the previously enacted United Kingdom tax rate change in the quarter ended October 2, 2020.

[0001137789-22-000031:mdna:71]
Our income tax provision recorded for the three and nine months ended April 1, 2022 and April 2, 2021 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-22-000031:mdna:72]
[same as prior period, unchanged from 0001137789-22-000014:mdna:68]

[0001137789-22-000031:mdna:73]
[same as prior period, unchanged from 0001137789-22-000014:mdna:72]

[0001137789-22-000031:mdna:74]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash will continue to be sufficient to fund our operations and meet our cash needs for the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs, will allow us to manage the ongoing impacts of the pandemic on our business operations for the foreseeable future. However, some challenges posed by the pandemic to our industry and to our business continue to remain uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to the pandemic.

[0001137789-22-000031:mdna:75]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of April 1, 2022.

[0001137789-22-000031:mdna:76]
[same as prior period, unchanged from 0001137789-22-000014:mdna:75]

[0001137789-22-000031:mdna:77]
| (Dollars in millions) |  | April 1,2022 |  | July 2,2021 |  | Change |
| Cash and cash equivalents |  | $ | 1,138 |  |  | $ | 1,209 |  |  | $ | (71) |  |

[0001137789-22-000031:mdna:78]
Our cash and cash equivalents as of April 1, 2022 decreased by $71 million from July 2, 2021 primarily as a result of repurchases of our ordinary shares of $1.3 billion, repayment of long-term debt of $701 million, dividends paid to our shareholders of $458 million and payments for capital expenditures of $309 million, partially offset by the net proceeds of $1.2 billion from the issuance of long-term debt and net cash of $1.5 billion provided by operating activities.

[0001137789-22-000031:mdna:79]
[same as prior period, unchanged from 0001137789-22-000014:mdna:78]

[0001137789-22-000031:mdna:80]
Cash provided by operating activities for the nine months ended April 1, 2022 was $1.5 billion and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-22-000031:mdna:81]
•an increase of $186 million in accounts receivable, primarily due to linearity of sales in the March 2022 quarter;

[0001137789-22-000031:mdna:82]
•an increase of $275 million in inventories, primarily due to timing of shipments and an increase in materials purchased for increased production of higher capacity drives; and

[0001137789-22-000031:mdna:83]
•a decrease in accrued employee compensation of $88 million, primarily due to cash paid to our employees as part of our discretionary spending plans;

[0001137789-22-000031:mdna:84]
•partially offset by an increase of $209 million in accounts payable, primarily due to an increase in direct materials purchased.

[0001137789-22-000031:mdna:85]
[same as prior period, unchanged from 0001137789-22-000014:mdna:85]

[0001137789-22-000031:mdna:86]
Cash used in investing activities for the nine months ended April 1, 2022 was $293 million, primarily attributable to the following activities:

[0001137789-22-000031:mdna:87]
•payments for the purchase of property, equipment and leasehold improvements of $309 million; and

[0001137789-22-000031:mdna:88]
•payments for the purchase of strategic investments of $18 million;

[0001137789-22-000031:mdna:89]
•partially offset by proceeds from the sale of strategic investments of $34 million.

[0001137789-22-000031:mdna:90]
[same as prior period, unchanged from 0001137789-22-000014:mdna:90]

[0001137789-22-000031:mdna:91]
Cash used in financing activities of $1.3 billion for the nine months ended April 1, 2022 was primarily attributable to the following activities:

[0001137789-22-000031:mdna:92]
•payments for the repurchase of our ordinary shares of $1.3 billion;

[0001137789-22-000031:mdna:93]
•repayments for long-term debt of $701 million;

[0001137789-22-000031:mdna:94]
•payments for dividends of $458 million; and

[0001137789-22-000031:mdna:95]
[same as prior period, unchanged from 0001137789-22-000014:mdna:95]

[0001137789-22-000031:mdna:96]
[same as prior period, unchanged from 0001137789-22-000014:mdna:84]

[0001137789-22-000031:mdna:97]
[same as prior period, unchanged from 0001137789-22-000014:mdna:96]

[0001137789-22-000031:mdna:98]
•proceeds from the issuance of ordinary shares under employee share plans of $68 million.

[0001137789-22-000031:mdna:99]
[same as prior period, unchanged from 0001137789-22-000014:mdna:98]

[0001137789-22-000031:mdna:100]
Our primary sources of liquidity as of April 1, 2022 consist of: (1) approximately $1.1 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.75 billion available for borrowing under our senior unsecured revolving credit facility (“Revolving Credit Facility”), which is part of our credit agreement (the “Credit Agreement”).

[0001137789-22-000031:mdna:101]
On October 14, 2021, our subsidiary Seagate HDD Cayman entered into an amendment to the Credit Agreement (“Fifth Amendment”), which provides for a new term loan facility in the aggregate principal amount of $1.2 billion that was extended in two tranches of $600 million each (the “Term Loans”). The Term Loans were drawn in full on October 14, 2021. On October 14, 2021, we utilized part of the proceeds of Term Loan A1 to fully repay the $475 million principal amount outstanding of our September 2019 Term Loan. Additionally, on February 1, 2022, we utilized part of the proceeds from the Term Loans to fully repay the entire outstanding principal amount of $220 million of our 2022 notes, plus accrued and unpaid interest.

[0001137789-22-000031:mdna:102]
In addition, pursuant to the Fifth Amendment, the maturity date for the revolving loan commitments was extended until October 14, 2026, the revolving commitments were increased to $1.75 billion and the interest rate margins for the Revolving Credit Facility was amended to LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of our Company. See “Part I, Item 1. Financial Statements—Note 3. Debt” for information regarding our amended Credit Agreement.

[0001137789-22-000031:mdna:103]
As of April 1, 2022, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-22-000031:mdna:104]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount.

[0001137789-22-000031:mdna:105]
[same as prior period, unchanged from 0001137789-22-000014:mdna:104]

[0001137789-22-000031:mdna:106]
For fiscal year 2022, we expect capital expenditures to be at or below the low end of our long-term targeted range of 4% to 6% of revenue. We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We may raise additional capital from time to time and will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-22-000031:mdna:107]
From time to time, we may repurchase any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase outstanding senior notes pursuant to the terms of the applicable indenture.

[0001137789-22-000031:mdna:108]
During the March 2022 quarter, our Board of Directors declared dividends of $0.70 per share, totaling $152 million, which were paid on April 6, 2022. On April 27, 2022, our Board of Directors declared a quarterly cash dividend of $0.70 per share, payable on July 7, 2022 to shareholders of record at the close of business on June 24, 2022.

[0001137789-22-000031:mdna:109]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker-assisted purchases, tender offers, or other means, including through the use of derivative transactions. As of April 1, 2022, $2.8 billion remained available for repurchases under our existing repurchase authorization. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-22-000031:mdna:110]
[same as prior period, unchanged from 0001137789-22-000014:mdna:107]

[0001137789-22-000031:mdna:111]
[same as prior period, unchanged from 0001137789-22-000014:mdna:110]

[0001137789-22-000031:mdna:112]
Our contractual cash obligations and commitments as of April 1, 2022, are summarized in the table below:

[0001137789-22-000031:mdna:113]
|  |  |  |  | Fiscal Year(s) |
| (Dollars in millions) |  | Total |  | 2022 |  | 2023-2024 |  | 2025-2026 |  | Thereafter |
| Contractual Cash Obligations: |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | $ | 5,715 |  |  | $ | — |  |  | $ | 1,145 |  |  | $ | 1,125 |  |  | $ | 3,445 |  |
| Interest payments on debt |  | 1,414 |  |  | 70 |  |  | 430 |  |  | 325 |  |  | 589 |  |
| Purchase obligations (1) |  | 1,831 |  |  | 1,062 |  |  | 525 |  |  | 148 |  |  | 96 |  |
| Operating leases, including imputed interest (2) |  | 63 |  |  | 4 |  |  | 25 |  |  | 13 |  |  | 21 |  |
| Capital expenditures |  | 257 |  |  | 80 |  |  | 176 |  |  | 1 |  |  | — |  |
| Subtotal |  | 9,280 |  |  | 1,216 |  |  | 2,301 |  |  | 1,612 |  |  | 4,151 |  |
| Commitments: |  |  |  |  |  |  |  |  |  |  |
| Letters of credit or bank guarantees |  | 38 |  |  | 9 |  |  | 20 |  |  | — |  |  | 9 |  |
| Total |  | $ | 9,318 |  |  | $ | 1,225 |  |  | $ | 2,321 |  |  | $ | 1,612 |  |  | $ | 4,160 |  |

[0001137789-22-000031:mdna:114]
[same as prior period, unchanged from 0001137789-22-000014:mdna:113]

[0001137789-22-000031:mdna:115]
[same as prior period, unchanged from 0001137789-22-000014:mdna:114]

[0001137789-22-000031:mdna:116]
[same as prior period, unchanged from 0001137789-22-000014:mdna:115]

[0001137789-22-000031:mdna:117]
[same as prior period, unchanged from 0001137789-22-000014:mdna:116]

[0001137789-22-000031:mdna:118]
[same as prior period, unchanged from 0001137789-22-000014:mdna:117]

[0001137789-22-000031:mdna:119]
[same as prior period, unchanged from 0001137789-22-000014:mdna:118]

[0001137789-22-000031:mdna:120]
[same as prior period, unchanged from 0001137789-22-000014:mdna:119]

[0001137789-22-000031:mdna:121]
[same as prior period, unchanged from 0001137789-22-000014:mdna:120]
