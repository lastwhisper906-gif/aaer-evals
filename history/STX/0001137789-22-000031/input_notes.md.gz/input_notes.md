# STX notes — 0001137789-22-000031


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001137789-22-000031:notes:1]
[same as prior period, unchanged from 0001137789-22-000014:notes:1]

[0001137789-22-000031:notes:2]
[same as prior period, unchanged from 0001137789-22-000014:notes:2]

[0001137789-22-000031:notes:3]
[same as prior period, unchanged from 0001137789-22-000014:notes:3]

[0001137789-22-000031:notes:4]
[same as prior period, unchanged from 0001137789-22-000014:notes:4]

[0001137789-22-000031:notes:5]
[same as prior period, unchanged from 0001137789-22-000014:notes:5]

[0001137789-22-000031:notes:6]
[same as prior period, unchanged from 0001137789-22-000014:notes:6]

[0001137789-22-000031:notes:7]
[same as prior period, unchanged from 0001137789-22-000014:notes:7]

[0001137789-22-000031:notes:8]
[same as prior period, unchanged from 0001137789-22-000014:notes:8]

[0001137789-22-000031:notes:9]
[same as prior period, unchanged from 0001137789-22-000014:notes:9]

[0001137789-22-000031:notes:10]
The Company’s consolidated financial statements for the fiscal year ended July 2, 2021 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 6, 2021. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 2, 2021, and the notes thereto, are adequate to make the information presented not misleading. The results of operations and the cash flows for the three and nine months ended April 1, 2022 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending July 1, 2022.

[0001137789-22-000031:notes:11]
[same as prior period, unchanged from 0001137789-22-000014:notes:11]

[0001137789-22-000031:notes:12]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and nine months ended April 1, 2022 and the three and nine months ended April 2, 2021 consisted of 13 and 39 weeks, respectively. Fiscal year 2022, which ends on July 1, 2022 and fiscal year 2021, which ended on July 2, 2021, are both comprised of 52 weeks. The fiscal quarters ended April 1, 2022, December 31, 2021 and April 2, 2021, are also referred to herein as the “March 2022 quarter”, the “December 2021 quarter” and the “March 2021 quarter”, respectively.

[0001137789-22-000031:notes:13]
[same as prior period, unchanged from 0001137789-22-000014:notes:13]

[0001137789-22-000031:notes:14]
[same as prior period, unchanged from 0001137789-22-000014:notes:14]

[0001137789-22-000031:notes:15]
Recently Adopted Accounting Pronouncements

[0001137789-22-000031:notes:16]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued ASU 2019-12 (ASC Topic 740), Simplifying the Accounting for Income Taxes. This ASU simplifies accounting for income taxes by removing certain exceptions to the general principles and amending existing guidance to improve consistent application. This ASU became effective and the Company adopted the guidance in the quarter ended October 1, 2021. The adoption of this ASU did not have an impact on the Company’s condensed consolidated financial statements.

[0001137789-22-000031:notes:17]
In July 2021, the FASB issued ASU 2021-05 (ASC Topic 842), Lessors—Certain Leases with Variable Lease Payments. This ASU requires lessors to classify and account for a lease with variable lease payments that do not depend on a reference index or a rate as an operating lease if the lease would have been classified as a sales-type lease or a direct financing lease and the lessor would have otherwise recognized a day-one loss. The Company adopted the guidance in the quarter ended October 1, 2021 on a prospective basis. The adoption of this ASU did not have an impact on the Company’s condensed consolidated financial statements.

[0001137789-22-000031:notes:18]
Recently Issued Accounting Pronouncements

[0001137789-22-000031:notes:19]
In March 2020, the FASB issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. Adoption of the expedients and exceptions is permitted upon issuance of this update through December 31, 2022. The Company does not expect the adoption of this ASU to have a material impact on its condensed consolidated financial statements.

[0001137789-22-000031:notes:20]
In November 2021, the FASB issued ASU 2021-10 (ASC Topic 832), Disclosures by Business Entities about Government Assistance. This ASU requires annual disclosures that increase the transparency of transactions involving government grants, including (1) the type of transactions, (2) the accounting for those transactions and (3) the effect of those transactions on an entity’s financial statements. The Company is required to adopt this new accounting pronouncement in the first quarter of fiscal year 2023. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001137789-22-000031:notes:21]
[same as prior period, unchanged from 0001137789-22-000014:notes:21]

[0001137789-22-000031:notes:22]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of April 1, 2022 and July 2, 2021:

[0001137789-22-000031:notes:23]
|  |  | April 1,2022 |  | July 2,2021 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 176 |  |  | $ | — |  |  | $ | 176 |  |  | $ | 552 |  |  | $ | — |  |  | $ | 552 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 36 |  |  | (13) |  |  | 23 |  |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 213 |  |  | $ | (13) |  |  | $ | 200 |  |  | $ | 571 |  |  | $ | — |  |  | $ | 571 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 176 |  |  |  |  |  |  | $ | 551 |  |
| Included in Other current assets |  |  |  |  |  | 1 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 23 |  |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 200 |  |  |  |  |  |  | $ | 571 |  |

[0001137789-22-000031:notes:24]
As of both April 1, 2022 and July 2, 2021, the Company’s Other current assets included $2 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001137789-22-000031:notes:25]
As of April 1, 2022 and July 2, 2021, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company recorded $13 million of allowance for credit losses related to an impairment of available-for-sale debt securities as of April 1, 2022. The Company determined no impairment related to credit losses for available-for-sale debt securities as of July 2, 2021.

[0001137789-22-000031:notes:26]
The fair value and amortized cost of the Company’s investments classified as available-for-sale debt securities as of April 1, 2022, by remaining contractual maturity were as follows:

[0001137789-22-000031:notes:27]
| (Dollars in millions) |  | Amortized Cost |  | Fair Value |
| Due in less than 1 year |  | $ | 190 |  |  | $ | 177 |  |
| Due in 1 to 5 years |  | 15 |  |  | 15 |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | 8 |  |  | 8 |  |
| Total |  | $ | 213 |  |  | $ | 200 |  |

[0001137789-22-000031:notes:28]
[same as prior period, unchanged from 0001137789-22-000014:notes:28]

[0001137789-22-000031:notes:29]
[same as prior period, unchanged from 0001137789-22-000014:notes:29]

[0001137789-22-000031:notes:30]
| (Dollars in millions) |  | April 1,2022 |  |  |  | July 2,2021 |  | April 2,2021 |  |  |  | July 3,2020 |
| Cash and cash equivalents |  | $ | 1,138 |  |  |  |  | $ | 1,209 |  |  | $ | 1,212 |  |  |  |  | $ | 1,722 |  |
| Restricted cash included in Other current assets |  | 2 |  |  |  |  | 2 |  |  | 2 |  |  |  |  | 2 |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  | $ | 1,140 |  |  |  |  | $ | 1,211 |  |  | $ | 1,214 |  |  |  |  | $ | 1,724 |  |

[0001137789-22-000031:notes:31]
Accounts Receivable, net

[0001137789-22-000031:notes:32]
In connection with an existing factoring agreement, from time to time the Company sells trade receivables to a third party for cash proceeds less a discount. During the three and nine months ended April 1, 2022, the Company sold trade receivables without recourse for cash proceeds of $75 million, all of which remained subject to servicing by the Company as of April 1, 2022. During the three and nine months ended April 2, 2021, the Company sold trade receivables without recourse for cash proceeds of $35 million and $183 million, respectively, of which $35 million remained subject to servicing by the Company as of April 2, 2021. The discounts on receivables sold were not material for the three and nine months ended April 1, 2022 and April 2, 2021.

[0001137789-22-000031:notes:33]
[same as prior period, unchanged from 0001137789-22-000014:notes:31]

[0001137789-22-000031:notes:34]
[same as prior period, unchanged from 0001137789-22-000014:notes:32]

[0001137789-22-000031:notes:35]
| (Dollars in millions) |  | April 1,2022 |  | July 2,2021 |
| Raw materials and components |  | $ | 536 |  |  | $ | 375 |  |
| Work-in-process |  | 456 |  |  | 443 |  |
| Finished goods |  | 487 |  |  | 386 |  |
| Total inventories |  | $ | 1,479 |  |  | $ | 1,204 |  |

[0001137789-22-000031:notes:36]
[same as prior period, unchanged from 0001137789-22-000014:notes:34]

[0001137789-22-000031:notes:37]
[same as prior period, unchanged from 0001137789-22-000014:notes:35]

[0001137789-22-000031:notes:38]
| (Dollars in millions) |  | April 1,2022 |  | July 2,2021 |
| Property, equipment and leasehold improvements |  | $ | 10,571 |  |  | $ | 10,378 |  |
| Accumulated depreciation and amortization |  | (8,374) |  |  | (8,197) |  |
| Property, equipment and leasehold improvements, net |  | $ | 2,197 |  |  | $ | 2,181 |  |

[0001137789-22-000031:notes:39]
[same as prior period, unchanged from 0001137789-22-000014:notes:37]

[0001137789-22-000031:notes:40]
[same as prior period, unchanged from 0001137789-22-000014:notes:38]

[0001137789-22-000031:notes:41]
| (Dollars in millions) |  | April 1,2022 |  | July 2,2021 |
| Dividends payable |  | $ | 152 |  |  | $ | 153 |  |
| Other accrued expenses |  | 493 |  |  | 455 |  |
| Total |  | $ | 645 |  |  | $ | 608 |  |

[0001137789-22-000031:notes:42]
Accumulated Other Comprehensive Income (Loss) (“AOCI”)

[0001137789-22-000031:notes:43]
The components of AOCI, net of tax, were as follows:

[0001137789-22-000031:notes:44]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  |  |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at July 2, 2021 |  | $ | (18) |  |  |  |  | $ | (22) |  |  | $ | (1) |  |  | $ | (41) |  |
| Other comprehensive income before reclassifications |  | 58 |  |  |  |  | 1 |  |  | — |  |  | 59 |  |
| Amounts reclassified from AOCI |  | 18 |  |  |  |  | 1 |  |  | — |  |  | 19 |  |
| Other comprehensive income |  | 76 |  |  |  |  | 2 |  |  | — |  |  | 78 |  |
| Balance at April 1, 2022 |  | $ | 58 |  |  |  |  | $ | (20) |  |  | $ | (1) |  |  | $ | 37 |  |
| Balance at July 3, 2020 |  | $ | (24) |  |  |  |  | $ | (26) |  |  | $ | (16) |  |  | $ | (66) |  |
| Other comprehensive income before reclassifications |  | 20 |  |  |  |  | — |  |  | — |  |  | 20 |  |
| Amounts reclassified from AOCI |  | (9) |  |  |  |  | 2 |  |  | 15 |  |  | 8 |  |
| Other comprehensive income |  | 11 |  |  |  |  | 2 |  |  | 15 |  |  | 28 |  |
| Balance at April 2, 2021 |  | $ | (13) |  |  |  |  | $ | (24) |  |  | $ | (1) |  |  | $ | (38) |  |


## us-gaap:DebtDisclosureTextBlock

[0001137789-22-000031:notes:45]
Debt
The following table provides details of the Company’s debt as of April 1, 2022 and July 2, 2021:

[0001137789-22-000031:notes:46]
| (Dollars in millions) |  | April 1,2022 |  | July 2,2021 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $750 issued on February 3, 2017 at 4.25% due on March 1, 2022 (the “2022 Notes”), interest payable semi-annually on March 1 and September 1 of each year, fully repaid on February 1, 2022. |  | $ | — |  |  | $ | 220 |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 541 |  |  | 541 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 464 |  |  | 461 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 499 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loan |  |  |  |  |
| $600 borrowed on October 14, 2021 at London Interbank Offered Rate (“LIBOR”) plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 600 |  |  | — |  |
| $600 borrowed on October 14, 2021 at LIBOR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | — |  |
| $500 borrowed on September 17, 2019 at LIBOR, (the “September 2019 Term Loan”), repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with a final maturity date of September 16, 2025, fully repaid on October 14, 2021. |  | — |  |  | 481 |  |
|  |  | 5,676 |  |  | 5,173 |  |
| Less: unamortized debt issuance costs |  | (32) |  |  | (34) |  |
| Debt, net of debt issuance costs |  | 5,644 |  |  | 5,139 |  |
| Less: current portion of long-term debt |  | (30) |  |  | (245) |  |
| Long-term debt, less current portion |  | $ | 5,614 |  |  | $ | 4,894 |  |

[0001137789-22-000031:notes:47]
______________________________

[0001137789-22-000031:notes:48]
(1) All unsecured senior notes are issued by Seagate HDD Cayman, and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and, pursuant to a supplemental indenture dated as of May 18, 2021, STX.

[0001137789-22-000031:notes:49]
Unsecured Senior Notes

[0001137789-22-000031:notes:50]
2022 Notes. On February 1, 2022, the entire outstanding principal amount of $220 million was repaid at par, plus accrued and unpaid interest. During the nine months ended April 2, 2021, $9 million aggregate principal amount of the 2022 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest.

[0001137789-22-000031:notes:51]
2023 Notes. During the nine months ended April 2, 2021, $5 million aggregate principal amount of the 2023 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss of $1 million on repurchases during the nine months ended April 2, 2021, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

[0001137789-22-000031:notes:52]
Credit Agreement

[0001137789-22-000031:notes:53]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement on February 20, 2019, which was amended on September 16, 2019, January 13, 2021, May 18, 2021 and October 14, 2021 (the “Credit Agreement”).

[0001137789-22-000031:notes:54]
Prior to the October 14, 2021 amendment, the Credit Agreement provided a term loan facility in an aggregate principal amount of $500 million and a $1.725 billion senior unsecured revolving credit facility (“Revolving Credit Facility”). The September 2019 Term Loan had a final maturity date of September 16, 2025 and the Revolving Credit Facility had a final maturity of February 20, 2024. On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the September 2019 Term Loan.

[0001137789-22-000031:notes:55]
On October 14, 2021, STX and Seagate HDD Cayman entered into an amendment to the Credit Agreement (“Fifth Amendment”), which provides for a new term loan facility in the aggregate principal amount of $1.2 billion that was extended in two tranches of $600 million each (“Term Loan A1” and “Term Loan A2” and together the “Term Loans”). Term Loan A1 and Term Loan A2 were each drawn in full on the closing date for the Fifth Amendment. Term Loan A1 bears interest at a rate of LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company. Term Loan A1 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of September 16, 2025. Term Loan A2 bears interest at a rate of LIBOR plus a variable margin ranging from 1.25% to 2.5% that will be determined based on the corporate credit rating of the Company. Term Loan A2 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of July 30, 2027. The proceeds of the Terms Loans may be used for, among other things, general corporate purposes.

[0001137789-22-000031:notes:56]
In addition, pursuant to the Fifth Amendment, the maturity date for the revolving loan commitments under the Revolving Credit Facility was extended until October 14, 2026, the revolving commitments were increased to $1.75 billion and the interest rate margins for the revolving loans were amended to LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company.

[0001137789-22-000031:notes:57]
STX and certain of its material subsidiaries, including STUC, fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loans.

[0001137789-22-000031:notes:58]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of April 1, 2022 and expects to be in compliance for the next 12 months. As of April 1, 2022, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility.

[0001137789-22-000031:notes:59]
Future Principal Payments on Long-term Debt

[0001137789-22-000031:notes:60]
At April 1, 2022, future principal payments on long-term debt were as follows (in millions):

[0001137789-22-000031:notes:61]
| Fiscal Year |  | Amount |
| Remainder of 2022 |  | $ | — |  |
| 2023 |  | 585 |  |
| 2024 |  | 560 |  |
| 2025 |  | 562 |  |
| 2026 |  | 563 |  |
| Thereafter |  | 3,445 |  |
| Total |  | $ | 5,715 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001137789-22-000031:notes:62]
Income Taxes
The Company recorded income tax provisions of $5 million and $25 million for the three and nine months ended April 1, 2022, respectively. The income tax provision for the three months ended April 1, 2022 included approximately $6 million of net discrete tax benefit, primarily associated with a change in the applicable tax rate within its non-U.S. operations. The income tax provision for the nine months ended April 1, 2022 included approximately $15 million of net discrete tax benefit, primarily associated with the net excess tax benefits related to share-based compensation expense.

[0001137789-22-000031:notes:63]
During the nine months ended April 1, 2022, the Company’s unrecognized tax benefits excluding interest and penalties increased by approximately $8 million to $116 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. During the twelve months beginning April 2, 2022, the Company expects that its unrecognized tax benefits could be reduced by an immaterial amount, as a result of the expiration of certain statutes of limitation.

[0001137789-22-000031:notes:64]
The Company recorded income tax provisions of $10 million and $19 million for the three and nine months ended April 2, 2021, respectively. The income tax provision for the three months ended April 2, 2021 included approximately $4 million of net discrete tax benefit, primarily associated with filing of tax returns in various jurisdictions. The income tax provision for the nine months ended April 2, 2021 included approximately $15 million of net discrete tax benefits, primarily associated with net excess tax benefits related to share-based compensation expense, filing of tax returns in various jurisdictions and postponement of the previously enacted United Kingdom tax rate change in the quarter ended October 2, 2020.

[0001137789-22-000031:notes:65]
The Company’s income tax provision recorded for the three and nine months ended April 1, 2022 and April 2, 2021 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001137789-22-000031:notes:66]
Restructuring and Exit Costs
For the nine months ended April 1, 2022, the Company recorded restructuring charges of $2 million. For the three and nine months ended April 2, 2021, the Company recorded a net gain of $2 million, comprised primarily of a gain of $3 million from sale of a property and restructuring charges of $1 million. The Company’s restructuring plans are comprised primarily of charges related to workforce reduction costs and facilities and other exit costs. All restructuring charges are reported in Restructuring and other, net on the Company’s Condensed Consolidated Statements of Operations.

[0001137789-22-000031:notes:67]
[same as prior period, unchanged from 0001137789-22-000014:notes:58]

[0001137789-22-000031:notes:68]
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at July 2, 2021 |  | $ | 2 |  |  | $ | 6 |  |  | $ | 8 |  |
| Restructuring charges |  | 2 |  |  | — |  |  | 2 |  |
| Cash payments |  | (3) |  |  | (2) |  |  | (5) |  |
| Accrual balances at April 1, 2022 |  | $ | 1 |  |  | $ | 4 |  |  | $ | 5 |  |
| Total costs incurred inception to date as of April 1, 2022 |  | $ | 65 |  |  | $ | 23 |  |  | $ | 88 |  |
| Total expected charges to be incurred as of April 1, 2022 |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001137789-22-000031:notes:69]
Derivative Financial Instruments
The Company is exposed to foreign currency exchange rate, interest rate and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies.

[0001137789-22-000031:notes:70]
The Company has entered into certain interest rate swap agreements to convert the variable interest rate on its Term Loans to fixed interest rates. The objective of the interest rate swap agreements is to eliminate the variability of interest payment cash flows associated with the variable interest rate under the Term Loans. The Company designated the interest rate swaps as cash flow hedges. As of April 1, 2022, the aggregate notional amount of the Company’s interest-rate swap contracts was $1.2 billion, of which $600 million will mature in September 2025 and $600 million will mature in July 2027.

[0001137789-22-000031:notes:71]
The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives on its Condensed Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The amount of net unrealized gain on cash flow hedges was $58 million and net unrealized loss was $18 million as of April 1, 2022 and as of July 2, 2021, respectively. As of April 1, 2022, the amount of existing net gains related to cash flow hedges recorded in Accumulated other comprehensive loss included a net gain of $4 million that is expected to be reclassified to earnings within twelve months.

[0001137789-22-000031:notes:72]
The Company de-designates its cash flow hedges when the forecasted hedged transactions affect earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss on the Company’s Condensed Consolidated Balance Sheets are reclassified into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company recognized a net loss of $2 million and $4 million in Cost of revenue and Interest expense, respectively, related to the loss of hedge designation on discontinued cash flow hedges during the three months ended April 1, 2022. The Company recognized a net loss of $10 million and $8 million in Cost of revenue and Interest expense, respectively, related to the loss of hedge designation on discontinued cash flow hedges during the nine months ended April 1, 2022. The Company recognized a net gain of $8 million and $12 million in Cost of revenue related to the loss of hedge designation on discontinued cash flow hedges during the three and nine months ended April 2, 2021, respectively. The Company recognized a net loss of $1 million and $5 million in Interest expense related to the loss of hedge designation on discontinued cash flow hedges during the three and nine months ended April 2, 2021, respectively.

[0001137789-22-000031:notes:73]
[same as prior period, unchanged from 0001137789-22-000014:notes:64]

[0001137789-22-000031:notes:74]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of April 1, 2022 and July 2, 2021. All of the foreign currency forward exchange contracts mature within 12 months.

[0001137789-22-000031:notes:75]
|  |  | As of April 1, 2022 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Singapore Dollar |  | $ | 178 |  |  | $ | 62 |  |
| Thai Baht |  | 143 |  |  | 41 |  |
| Chinese Renminbi |  | 92 |  |  | 23 |  |
| British Pound Sterling |  | 61 |  |  | 19 |  |
|  |  | $ | 474 |  |  | $ | 145 |  |

[0001137789-22-000031:notes:76]
[same as prior period, unchanged from 0001137789-22-000014:notes:67]

[0001137789-22-000031:notes:77]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its non-qualified deferred compensation plan: the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP’s liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP’s liabilities due to changes in the value of the investment options made by employees. As of April 1, 2022, the notional investments underlying the TRS amounted to $123 million and the contract term is through January 2023, settled on a monthly basis, limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP’s liabilities.

[0001137789-22-000031:notes:78]
The following tables show the Company’s derivative instruments measured at gross fair value as reflected in the Condensed Consolidated Balance Sheets as of April 1, 2022 and July 2, 2021:

[0001137789-22-000031:notes:79]
|  |  | As of April 1, 2022 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance Sheet Location |  | Fair Value |  | Balance Sheet Location |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 2 |  |  | Accrued expenses |  | $ | (1) |  |
| Interest rate swap |  | Other current assets |  | 57 |  |  | Accrued expenses |  | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 1 |  |  | Accrued expenses |  | (1) |  |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | (2) |  |
| Total derivatives |  |  |  | $ | 60 |  |  |  |  | $ | (4) |  |

[0001137789-22-000031:notes:80]
[same as prior period, unchanged from 0001137789-22-000014:notes:71]

[0001137789-22-000031:notes:81]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three and nine months ended April 1, 2022:

[0001137789-22-000031:notes:82]
|  |  |  |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 1 |  |  | $ | (1) |  |
| Total return swap |  | Operating expenses |  | (7) |  |  | (1) |  |

[0001137789-22-000031:notes:83]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
|  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | $ | (1) |  |  | $ | (6) |  |  | Cost of revenue |  | $ | (2) |  |  | $ | (10) |  |  | Other, net |  | $ | — |  |  | $ | 1 |  |
| Interest rate swap |  | 57 |  |  | 64 |  |  | Interest expense |  | (4) |  |  | (8) |  |  | Interest expense |  | — |  |  | — |  |

[0001137789-22-000031:notes:84]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three and nine months ended April 2, 2021:

[0001137789-22-000031:notes:85]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |
|  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (3) |  |  | $ | 11 |  |
| Total return swap |  | Operating expenses |  | $ | 6 |  |  | $ | 22 |  |

[0001137789-22-000031:notes:86]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
|  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | $ | (5) |  |  | $ | 10 |  |  | Cost of revenue |  | $ | 8 |  |  | $ | 12 |  |  | Other, net |  | $ | (1) |  |  | $ | — |  |
| Interest rate swap |  | 9 |  |  | 10 |  |  | Interest expense |  | (1) |  |  | (5) |  |  | Interest expense |  | — |  |  | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001137789-22-000031:notes:87]
[same as prior period, unchanged from 0001137789-22-000014:notes:78]

[0001137789-22-000031:notes:88]
[same as prior period, unchanged from 0001137789-22-000014:notes:79]

[0001137789-22-000031:notes:89]
[same as prior period, unchanged from 0001137789-22-000014:notes:80]

[0001137789-22-000031:notes:90]
[same as prior period, unchanged from 0001137789-22-000014:notes:81]

[0001137789-22-000031:notes:91]
[same as prior period, unchanged from 0001137789-22-000014:notes:82]

[0001137789-22-000031:notes:92]
[same as prior period, unchanged from 0001137789-22-000014:notes:83]

[0001137789-22-000031:notes:93]
[same as prior period, unchanged from 0001137789-22-000014:notes:84]

[0001137789-22-000031:notes:94]
[same as prior period, unchanged from 0001137789-22-000014:notes:85]

[0001137789-22-000031:notes:95]
[same as prior period, unchanged from 0001137789-22-000014:notes:86]

[0001137789-22-000031:notes:96]
[same as prior period, unchanged from 0001137789-22-000014:notes:87]

[0001137789-22-000031:notes:97]
|  |  | April 1, 2022 |  | July 2, 2021 |
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 175 |  |  | $ | — |  |  | $ | — |  |  | $ | 175 |  |  | $ | 551 |  |  | $ | — |  |  | $ | — |  |  | $ | 551 |  |
| Total cash equivalents |  | 175 |  |  | — |  |  | — |  |  | 175 |  |  | 551 |  |  | — |  |  | — |  |  | 551 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | — |  |  | — |  |  | 23 |  |  | 23 |  |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Derivative assets |  | — |  |  | 60 |  |  | — |  |  | 60 |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total assets |  | $ | 176 |  |  | $ | 61 |  |  | $ | 23 |  |  | $ | 260 |  |  | $ | 552 |  |  | $ | 5 |  |  | $ | 18 |  |  | $ | 575 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |
| Total liabilities |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |

[0001137789-22-000031:notes:98]
|  |  | April 1, 2022 |  | July 2, 2021 |
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 175 |  |  | $ | — |  |  | $ | — |  |  | $ | 175 |  |  | $ | 551 |  |  | $ | — |  |  | $ | — |  |  | $ | 551 |  |
| Other current assets |  | 1 |  |  | 61 |  |  | — |  |  | 62 |  |  | 1 |  |  | 5 |  |  | — |  |  | 6 |  |
| Other assets, net |  | — |  |  | — |  |  | 23 |  |  | 23 |  |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Total assets |  | $ | 176 |  |  | $ | 61 |  |  | $ | 23 |  |  | $ | 260 |  |  | $ | 552 |  |  | $ | 5 |  |  | $ | 18 |  |  | $ | 575 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |
| Total liabilities |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |

[0001137789-22-000031:notes:99]
[same as prior period, unchanged from 0001137789-22-000014:notes:90]

[0001137789-22-000031:notes:100]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair value of all of its cash equivalents. For the cash equivalents in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry-standard data providers or other third-party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of April 1, 2022, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts, interest rate swaps and the TRS. The Company recognizes derivative financial instruments in its condensed consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001137789-22-000031:notes:101]
[same as prior period, unchanged from 0001137789-22-000014:notes:92]

[0001137789-22-000031:notes:102]
[same as prior period, unchanged from 0001137789-22-000014:notes:93]

[0001137789-22-000031:notes:103]
For the investments that are accounted for under the equity method, the Company recorded a net gain of $2 million and a net gain of $5 million for the three and nine months ended April 1, 2022, respectively. The Company recorded a net gain of $3 million for the three and nine months ended April 2, 2021, respectively. The adjusted carrying value of the investments accounted for under the equity method amounted to $83 million and $78 million as of April 1, 2022 and July 2, 2021, respectively.

[0001137789-22-000031:notes:104]
For the investments that are accounted for under the measurement alternative, the Company recorded a net gain of $4 million for the nine months ended April 1, 2022. The Company recorded a net gain of $10 million and $26 million for the three and nine months ended April 2, 2021, respectively, related to downward and upward adjustments due to observable price changes. As of April 1, 2022 and July 2, 2021, the carrying value of the Company’s strategic investments under the measurement alternative was $88 million and $117 million, respectively.

[0001137789-22-000031:notes:105]
[same as prior period, unchanged from 0001137789-22-000014:notes:96]

[0001137789-22-000031:notes:106]
[same as prior period, unchanged from 0001137789-22-000014:notes:97]

[0001137789-22-000031:notes:107]
|  |  | April 1, 2022 |  | July 2, 2021 |
| (Dollars in millions) |  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 4.25% Senior Notes due March 2022 |  | $ | — |  |  | $ | — |  |  | $ | 220 |  |  | $ | 224 |  |
| 4.75% Senior Notes due June 2023 |  | 541 |  |  | 551 |  |  | 541 |  |  | 578 |  |
| 4.875% Senior Notes due March 2024 |  | 499 |  |  | 513 |  |  | 499 |  |  | 544 |  |
| 4.75% Senior Notes due January 2025 |  | 479 |  |  | 491 |  |  | 479 |  |  | 529 |  |
| 4.875% Senior Notes due June 2027 |  | 504 |  |  | 517 |  |  | 504 |  |  | 561 |  |
| 4.091% Senior Notes due June 2029 |  | 464 |  |  | 484 |  |  | 461 |  |  | 519 |  |
| 3.125% Senior Notes due July 2029 |  | 500 |  |  | 446 |  |  | 500 |  |  | 488 |  |
| 4.125% Senior Notes due January 2031 |  | 500 |  |  | 473 |  |  | 499 |  |  | 513 |  |
| 3.375% Senior Notes due July 2031 |  | 500 |  |  | 444 |  |  | 500 |  |  | 487 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 501 |  |  | 489 |  |  | 566 |  |
| LIBOR Based Term Loan A1 due September 2025 |  | 600 |  |  | 589 |  |  | — |  |  | — |  |
| LIBOR Based Term Loan A2 due July 2027 |  | 600 |  |  | 591 |  |  | — |  |  | — |  |
| LIBOR Based Term Loan due September 2025 |  | — |  |  | — |  |  | 481 |  |  | 478 |  |
|  |  | 5,676 |  |  | 5,600 |  |  | 5,173 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (32) |  |  | — |  |  | (34) |  |  | — |  |
| Debt, net of debt issuance costs |  | 5,644 |  |  | 5,600 |  |  | 5,139 |  |  | 5,487 |  |
| Less: current portion of debt |  | (30) |  |  | (30) |  |  | (245) |  |  | (249) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,614 |  |  | $ | 5,570 |  |  | $ | 4,894 |  |  | $ | 5,238 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001137789-22-000031:notes:108]
[same as prior period, unchanged from 0001137789-22-000014:notes:99]

[0001137789-22-000031:notes:109]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 215,565,360 shares were outstanding as of April 1, 2022, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of April 1, 2022.

[0001137789-22-000031:notes:110]
[same as prior period, unchanged from 0001137789-22-000014:notes:101]

[0001137789-22-000031:notes:111]
[same as prior period, unchanged from 0001137789-22-000014:notes:102]

[0001137789-22-000031:notes:112]
[same as prior period, unchanged from 0001137789-22-000014:notes:103]

[0001137789-22-000031:notes:113]
[same as prior period, unchanged from 0001137789-22-000014:notes:104]

[0001137789-22-000031:notes:114]
[same as prior period, unchanged from 0001137789-22-000014:notes:105]

[0001137789-22-000031:notes:115]
On May 14, 2021, STX’s Board of Directors resolved to adopt and continue the STUC Share Repurchase Program as its own and that the STX Board of Directors be authorized to effect the repurchase of STX ordinary shares in an amount equal to the remaining STUC Share Repurchase Program amount as of the effective time of the scheme of arrangement. As of April 1, 2022, $2.8 billion remained available for repurchase under the existing repurchase authorization limit. The following table sets forth information with respect to repurchases of ordinary shares during the nine months ended April 1, 2022:

[0001137789-22-000031:notes:116]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Repurchases of ordinary shares (1) |  | 14 |  |  | $ | 1,333 |  |
| Tax withholding related to vesting of equity awards |  | 1 |  |  | 45 |  |
| Total |  | 15 |  |  | $ | 1,378 |  |

[0001137789-22-000031:notes:117]
_________________________________

[0001137789-22-000031:notes:118]
(1) These amounts differ from the repurchases of ordinary shares amounts in the condensed consolidated statements of cash flows due to timing differences between repurchases and cash settlement thereof.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001137789-22-000031:notes:119]
[same as prior period, unchanged from 0001137789-22-000014:notes:108]

[0001137789-22-000031:notes:120]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 2,149 |  |  | $ | 1,950 |  |  | $ | 6,615 |  |  | $ | 5,299 |  |
| Distributors |  | 349 |  |  | 455 |  |  | 1,418 |  |  | 1,297 |  |
| Retailers |  | 304 |  |  | 326 |  |  | 1,000 |  |  | 1,072 |  |
| Total |  | $ | 2,802 |  |  | $ | 2,731 |  |  | $ | 9,033 |  |  | $ | 7,668 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,292 |  |  | $ | 1,268 |  |  | $ | 4,308 |  |  | $ | 3,680 |  |
| Americas |  | 1,171 |  |  | 939 |  |  | 3,436 |  |  | 2,582 |  |
| EMEA |  | 339 |  |  | 524 |  |  | 1,289 |  |  | 1,406 |  |
| Total |  | $ | 2,802 |  |  | $ | 2,731 |  |  | $ | 9,033 |  |  | $ | 7,668 |  |

[0001137789-22-000031:notes:121]
[same as prior period, unchanged from 0001137789-22-000014:notes:111]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001137789-22-000031:notes:122]
Guarantees
Indemnification Obligations

[0001137789-22-000031:notes:123]
[same as prior period, unchanged from 0001137789-22-000014:notes:113]

[0001137789-22-000031:notes:124]
[same as prior period, unchanged from 0001137789-22-000014:notes:114]

[0001137789-22-000031:notes:125]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product warranty return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the nine months ended April 1, 2022 and April 2, 2021 were as follows:

[0001137789-22-000031:notes:126]
|  |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | April 1,2022 |  | April 2,2021 |  |
| Balance, beginning of period |  | $ | 136 |  |  | $ | 151 |  |  |
| Warranties issued |  | 62 |  |  | 56 |  |  |
| Repairs and replacements |  | (65) |  |  | (62) |  |  |
| Changes in liability for pre-existing warranties, including expirations |  | 15 |  |  | (11) |  |  |
| Balance, end of period |  | $ | 148 |  |  | $ | 134 |  |  |


## us-gaap:EarningsPerShareTextBlock

[0001137789-22-000031:notes:127]
Earnings Per Share
Basic earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period. Diluted earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period and the number of additional shares that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding options, unvested restricted share units and performance-based share units and shares to be purchased under the Company’s Employee Stock Purchase Plan. The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in fair market value of the Company’s share price can result in a greater dilutive effect from potentially dilutive securities. The following table sets forth the computation of basic and diluted net income per share attributable to the shareholders of the Company:

[0001137789-22-000031:notes:128]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (In millions, except per share data) |  | April 1,2022 |  | April 2,2021 |  | April 1,2022 |  | April 2,2021 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 346 |  |  | $ | 329 |  |  | $ | 1,373 |  |  | $ | 832 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 218 |  |  | 233 |  |  | 222 |  |  | 246 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | 4 |  |  | 4 |  |  | 4 |  |  | 3 |  |
| Total shares for purpose of calculating diluted net income per share |  | 222 |  |  | 237 |  |  | 226 |  |  | 249 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.59 |  |  | $ | 1.41 |  |  | $ | 6.18 |  |  | $ | 3.38 |  |
| Diluted |  | 1.56 |  |  | 1.39 |  |  | 6.08 |  |  | 3.34 |  |

[0001137789-22-000031:notes:129]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share were not material for the three and nine months ended April 1, 2022 and April 2, 2021.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001137789-22-000031:notes:130]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001137789-22-000031:notes:131]
Litigation

[0001137789-22-000031:notes:132]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods”. The complaint seeks damages as well as additional relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial began on April 4, 2022. On April 14, 2022, the jury returned a verdict of non-infringement for Seagate finding that Seagate had not infringed any of the asserted claims. The district court entered judgment in favor of Seagate on April 19, 2022.

[0001137789-22-000031:notes:133]
Seagate Technology LLC, et al. v. NHK Spring Co. Ltd. and TDK Corporation, et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the United States District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc., and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, as well as additional relief permitted by law. On March 22, 2022, Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) and the Seagate Entities entered into a commercial arrangement and release of claims (“TDK Agreement”) to fully resolve the global disputes between the Seagate Entities and TDK relating to the antitrust law claims, breach of contract claim, and other matters described in the complaint. On April 1, 2022, the Seagate Entities and TDK filed a Stipulation for Dismissal with Prejudice to dismiss with prejudice all claims against TDK.

[0001137789-22-000031:notes:134]
Environmental Matters

[0001137789-22-000031:notes:135]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001137789-22-000031:notes:136]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001137789-22-000031:notes:137]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001137789-22-000031:notes:138]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001137789-22-000031:notes:139]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the U.S., Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001137789-22-000031:notes:140]
Other Matters

[0001137789-22-000031:notes:141]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:CommitmentsDisclosureTextBlock

[0001137789-22-000031:notes:142]
CommitmentsUnconditional Long-Term Purchase Obligations. As of April 1, 2022, the Company had unconditional long-term purchase obligations of approximately $769 million, primarily related to purchases of minimum quarterly amounts of inventory components. The Company expects the commitment to total $372 million, $153 million, $33 million, $115 million and $96 million for fiscal years 2023, 2024, 2025, 2026 and thereafter, respectively


## us-gaap:SubsequentEventsTextBlock

[0001137789-22-000031:notes:143]
Subsequent Events
Dividend Declared

[0001137789-22-000031:notes:144]
On April 27, 2022, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on July 7, 2022 to shareholders of record as of the close of business on June 24, 2022.
