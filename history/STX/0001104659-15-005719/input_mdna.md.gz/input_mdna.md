# STX MD&A — 0001104659-15-005719


## mdna

[0001104659-15-005719:mdna:1]
[same as prior period, unchanged from 0001104659-14-075666:mdna:1]

[0001104659-15-005719:mdna:2]
The following is a discussion of the financial condition and results of operations for our fiscal quarters ended January 2, 2015, October 3, 2014, and December 27, 2013, referred to herein as the  “December 2014 quarter”, the “September 2014 quarter”, and the “December 2013 quarter”, respectively. Unless the context indicates otherwise, as used herein, the terms “we,” “us,” “Seagate,” the “Company” and “our” refer to Seagate Technology plc, an Irish public limited company, and its subsidiaries. References to “$” are to United States dollars.

[0001104659-15-005719:mdna:3]
You should read this discussion in conjunction with financial information and related notes included elsewhere in this report. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The December 2014 and December 2013 quarters were both 13 weeks and the September 2014 quarter was 14 weeks. Except as noted, references to any fiscal year mean the twelve-month period ending on the Friday closest to June 30 of that year.

[0001104659-15-005719:mdna:4]
[same as prior period, unchanged from 0001104659-14-075666:mdna:4]

[0001104659-15-005719:mdna:5]
[same as prior period, unchanged from 0001104659-14-075666:mdna:5]

[0001104659-15-005719:mdna:6]
·                  Overview of the December 2014 quarter. Highlights of events in the December 2014 quarter that impacted our financial position.

[0001104659-15-005719:mdna:7]
·                  Results of Operations. An analysis of our financial results comparing the December 2014 quarter to the September 2014 quarter and the December 2013 quarter, and the six-month period ended December 2014 to the six-month period ended  December 2013.

[0001104659-15-005719:mdna:8]
[same as prior period, unchanged from 0001104659-14-075666:mdna:8]

[0001104659-15-005719:mdna:9]
[same as prior period, unchanged from 0001104659-14-075666:mdna:9]

[0001104659-15-005719:mdna:10]
[same as prior period, unchanged from 0001104659-14-075666:mdna:10]

[0001104659-15-005719:mdna:11]
We are a leading provider of electronic data storage solutions.  Our principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs.  Hard disk drives are devices that store digitally encoded data on rapidly

[0001104659-15-005719:mdna:12]
30

[0001104659-15-005719:mdna:13]
rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. In addition to HDDs, we produce a broad range of electronic data storage products including solid state hybrid drives (“SSHD”) and solid state drives (“SSD”).

[0001104659-15-005719:mdna:14]
[same as prior period, unchanged from 0001104659-14-075666:mdna:12]

[0001104659-15-005719:mdna:15]
[same as prior period, unchanged from 0001104659-14-075666:mdna:13]

[0001104659-15-005719:mdna:16]
[same as prior period, unchanged from 0001104659-14-075666:mdna:14]

[0001104659-15-005719:mdna:17]
Overview of the December 2014 Quarter

[0001104659-15-005719:mdna:18]
During the December 2014 quarter, we shipped 57 million units totaling 61 exabytes, generating revenue of $3.7 billion and gross margin of 28%. Our operating cash flow was $1.4 billion, which included $773 million from Western Digital as partial payment of the final award plus accrued interest in our arbitration case against Western Digital. We issued $500 million of 5.75% Senior Notes due 2034 and paid $411 million for the repurchase and redemption of $375 million par value of our outstanding debt as well as $177 million in dividends paid. In addition, we received the final audit assessment of $228 million from the Jiangsu Province State Tax Bureau of the People’s Republic of China related to tax and interest associated with changes to our tax filings for calendar years 2007 through 2013. The assessment was paid on January 4, 2015.

[0001104659-15-005719:mdna:19]
[same as prior period, unchanged from 0001104659-14-075666:mdna:17]

[0001104659-15-005719:mdna:20]
We list in the tables below summarized information from our Condensed Consolidated Statements of Operations by dollars and as a percentage of revenue:

[0001104659-15-005719:mdna:21]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |
| (Dollars in millions) |  | January 2, 2015 |  | October 3, 2014 |  | December 27, 2013 |  | January 2, 2015 |  | December 27, 2013 |  |
| Revenue |  | $ | 3,696 |  | $ | 3,785 |  | $ | 3,528 |  | $ | 7,481 |  | $ | 7,017 |  |
| Cost of revenue |  | 2,669 |  | 2,734 |  | 2,541 |  | 5,403 |  | 5,055 |  |
| Gross margin |  | 1,027 |  | 1,051 |  | 987 |  | 2,078 |  | 1,962 |  |
| Product development |  | 341 |  | 342 |  | 312 |  | 683 |  | 606 |  |
| Marketing and administrative |  | 218 |  | 216 |  | 190 |  | 434 |  | 371 |  |
| Amortization of intangibles |  | 32 |  | 31 |  | 25 |  | 62 |  | 45 |  |
| Restructuring and other, net |  | 3 |  | 6 |  | 16 |  | 10 |  | 18 |  |
| Gain on arbitration award, net |  | (620 | ) | — |  | — |  | (620 | ) | — |  |
| Income from operations |  | 1,053 |  | 456 |  | 444 |  | 1,509 |  | 922 |  |
| Other income (expense), net |  | 73 |  | (64 | ) | (2 | ) | 8 |  | (40 | ) |
| Income before income taxes |  | 1,126 |  | 392 |  | 442 |  | 1,517 |  | 882 |  |
| Provision for income taxes |  | 193 |  | 11 |  | 14 |  | 203 |  | 27 |  |
| Net income |  | $ | 933 |  | $ | 381 |  | $ | 428 |  | $ | 1,314 |  | $ | 855 |  |

[0001104659-15-005719:mdna:22]
[same as prior period, unchanged from 0001104659-14-075666:mdna:75]

[0001104659-15-005719:mdna:23]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |
|  |  | January 2, 2015 |  | October 3, 2014 |  | December 27, 2013 |  | January 2, 2015 |  | December 27, 2013 |  |
| Revenue |  | 100 | % | 100 | % | 100 | % | 100 | % | 100 | % |
| Cost of revenue |  | 72 |  | 72 |  | 72 |  | 72 |  | 72 |  |
| Gross margin |  | 28 |  | 28 |  | 28 |  | 28 |  | 28 |  |
| Product development |  | 9 |  | 9 |  | 9 |  | 9 |  | 9 |  |
| Marketing and administrative |  | 6 |  | 6 |  | 5 |  | 6 |  | 5 |  |
| Amortization of intangibles |  | 1 |  | 1 |  | 1 |  | 1 |  | 1 |  |
| Restructuring and other, net |  | — |  | — |  | 1 |  | — |  | — |  |
| Gain on arbitration award, net |  | (16 | ) | — |  | — |  | (8 | ) | — |  |
| Income from operations |  | 28 |  | 12 |  | 12 |  | 20 |  | 13 |  |
| Other income (expense), net |  | 2 |  | (2 | ) | — |  | — |  | (1 | ) |
| Income before income taxes |  | 30 |  | 10 |  | 12 |  | 20 |  | 12 |  |
| Provision for income taxes |  | 5 |  | — |  | — |  | 2 |  | — |  |
| Net income |  | 25 | % | 10 | % | 12 | % | 18 | % | 12 | % |

[0001104659-15-005719:mdna:24]
[same as prior period, unchanged from 0001104659-14-075666:mdna:22]

[0001104659-15-005719:mdna:25]
The following table summarizes information regarding drive volume shipments, exabytes shipped, average selling prices (“ASPs”) and revenues by channel and geography:

[0001104659-15-005719:mdna:26]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |
| (In millions, except percentages, exabytes and ASPs) |  | January 2, 2015 |  | October 3, 2014 |  | December 27, 2013 |  | January 2, 2015 |  | December 27, 2013 |  |
| Unit Shipments: |  |  |  |  |  |  |  |  |  |  |  |
| Enterprise |  | 9 |  | 9 |  | 8 |  | 18 |  | 16 |  |
| Client Compute |  | 36 |  | 39 |  | 36 |  | 75 |  | 72 |  |
| Client Non-Compute |  | 12 |  | 12 |  | 13 |  | 24 |  | 25 |  |
| Total Units Shipped |  | 57 |  | 60 |  | 57 |  | 117 |  | 113 |  |
| ASPs (per unit) |  | $ | 61 |  | $ | 60 |  | $ | 62 |  | $ | 61 |  | $ | 62 |  |
| Exabytes Shipped |  | 61 |  | 60 |  | 52 |  | 121 |  | 101 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 69 | % | 70 | % | 66 | % | 69 | % | 67 | % |
| Distributors |  | 18 | % | 18 | % | 21 | % | 18 | % | 21 | % |
| Retailers |  | 13 | % | 12 | % | 13 | % | 12 | % | 12 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | 26 | % | 27 | % | 27 | % | 27 | % | 28 | % |
| EMEA |  | 18 | % | 17 | % | 20 | % | 17 | % | 19 | % |
| Asia Pacific |  | 56 | % | 56 | % | 52 | % | 56 | % | 53 | % |

[0001104659-15-005719:mdna:27]
Revenue in the December 2014 quarter decreased compared to the September 2014 quarter primarily due to a decrease in shipments and price erosion, partially offset by favorable product mix.

[0001104659-15-005719:mdna:28]
Revenue in the December 2014 quarter increased by $0.2 billion compared to the December 2013 quarter as a result of  favorable product mix, partially offset by price erosion.

[0001104659-15-005719:mdna:29]
Revenue for the six months ended December 2014 increased by $0.5 billion, or 7%, as compared to the six months ended December 2013 primarily due to increased units shipped and favorable product mix, partially offset by price erosion.

[0001104659-15-005719:mdna:30]
32

[0001104659-15-005719:mdna:31]
We maintain various sales programs such as point-of-sale rebates, sales price adjustments and price protection, aimed at increasing customer demand. Sales programs were approximately 9.4%, 9.2% and 7.5% of gross drive revenue for the December 2014 quarter, September 2014 quarter and December 2013 quarter, respectively. Adjustments to revenues due to under or over accruals for sales programs related to revenues reported in prior quarterly periods have averaged 0.3% of quarterly gross revenue and were 0.1% of quarterly gross revenue in the December 2014 quarter.

[0001104659-15-005719:mdna:32]
[same as prior period, unchanged from 0001104659-14-075666:mdna:27]

[0001104659-15-005719:mdna:33]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |
| (Dollars in millions) |  | January 2, 2015 |  | October 3, 2014 |  | December 27, 2013 |  | January 2, 2015 |  | December 27, 2013 |  |
| Cost of revenue |  | $ | 2,669 |  | $ | 2,734 |  | $ | 2,541 |  | $ | 5,403 |  | $ | 5,055 |  |
| Gross margin |  | 1,027 |  | 1,051 |  | 987 |  | 2,078 |  | 1,962 |  |
| Gross margin percentage |  | 28 | % | 28 | % | 28 | % | 28 | % | 28 | % |

[0001104659-15-005719:mdna:34]
Gross margin as a percentage of revenue for the December 2014 quarter and the six months ended December 2014 was relatively flat when compared to the September 2014 quarter, December 2013 quarter and the six months ended December 2013. These margins reflect an environment where price erosion has been modest and was offset by improved product mix and cost savings due to increases in operational efficiencies.

[0001104659-15-005719:mdna:35]
In the December 2014 quarter, total warranty cost was 1.5% of revenue and included unfavorable changes in estimates of prior warranty accruals of approximately 0.4% of revenue.  Warranty cost related to new shipments was 1.1%, 1.1% and 1.4% of revenue for the December 2014 quarter, September 2014 quarter and December 2013 quarter, respectively.

[0001104659-15-005719:mdna:36]
[same as prior period, unchanged from 0001104659-14-075666:mdna:32]

[0001104659-15-005719:mdna:37]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |
| (Dollars in millions) |  | January 2, 2015 |  | October 3, 2014 |  | December 27, 2013 |  | January 2, 2015 |  | December 27, 2013 |  |
| Product development |  | $ | 341 |  | $ | 342 |  | $ | 312 |  | $ | 683 |  | $ | 606 |  |
| Marketing and administrative |  | 218 |  | 216 |  | 190 |  | 434 |  | 371 |  |
| Amortization of intangibles |  | 32 |  | 31 |  | 25 |  | 62 |  | 45 |  |
| Restructuring and other, net |  | 3 |  | 6 |  | 16 |  | 10 |  | 18 |  |
| Gain on arbitration award, net |  | (620 | ) | — |  | — |  | (620 | ) | — |  |
| Operating expenses |  | $ | (26 | ) | $ | 595 |  | $ | 543 |  | $ | 569 |  | $ | 1,040 |  |

[0001104659-15-005719:mdna:38]
Product development expense.  Product development expense for the December 2014 quarter was flat compared to the September 2014 quarter due to a full quarter effect of expenses related to LSI’s Flash Business acquired in September 2014 offset by the additional expenses related to a 14-week September 2014 quarter. Compared to the December 2013 quarter, Product development expense increased by $29 million, or 9% primarily due to an increase in headcount related costs of $28 million attributed to the consolidation of Xyratex and LSI’s Flash Business.

[0001104659-15-005719:mdna:39]
Product development expense for the six months ended December 2014 increased by $77 million, or 13% as compared to the corresponding period in the prior year mostly due to an increase in headcount related costs of $46 million attributed to consolidation of Xyratex and LSI’s Flash Business as well as a 14-week September 2014 quarter.

[0001104659-15-005719:mdna:40]
Marketing and administrative expense. Marketing and administrative expense for the December 2014 quarter was relatively flat when compared to the September 2014 quarter due to an increase in advertising and promotion expense partially offset by the additional expenses related to a 14-week September 2014 quarter. Compared to the December 2013 quarter, Marketing and administrative expense increased by $28 million, or 15%, which was primarily due to an increase in headcount related expense attributed to the consolidation of Xyratex and LSI’s Flash Business.

[0001104659-15-005719:mdna:41]
Marketing and administrative expense for the six months ended December 2014 increased by $63 million, or 17% as compared to the corresponding period in the prior year mostly due to an increase in headcount related expenses attributed to consolidation of Xyratex and LSI’s Flash Business as well as a 14-week September 2014 quarter.

[0001104659-15-005719:mdna:42]
Amortization of intangibles. Amortization of intangibles for the December 2014 quarter was relatively flat when compared to the September 2014 quarter due to a full quarter effect of amortization expenses related to LSI’s Flash Business partially offset by additional expenses related to a 14-week September 2014 quarter. Compared to the December 2013 quarter, Amortization of intangibles increased by $7 million, or 28% as a result of the acquisitions of LSI’s Flash Business and Xyratex.

[0001104659-15-005719:mdna:43]
Amortization of intangibles for the six months ended December 2014 increased as compared to the corresponding period in the prior year by $17 million, or 38% as a result of the acquisitions of LSI’s Flash Business and Xyratex.

[0001104659-15-005719:mdna:44]
Restructuring and Other, net. Restructuring and other, net for the December 2014 quarter decreased when compared to the September 2014 quarter due to a restructuring charge recorded during the September 2014 quarter to reduce work force as a result of our ongoing focus on cost efficiencies in all areas of our business.

[0001104659-15-005719:mdna:45]
Restructuring and other, net for the December 2014 quarter and the six months ended December 2014 decreased when compared to the December 2013 quarter and the six months ended December 2013 due to a restructuring charge recorded during the December 2013 quarter to reduce work force as a result of our ongoing focus on cost efficiencies in all areas of our business.

[0001104659-15-005719:mdna:46]
Gain on arbitration award, net. Gain on arbitration award, net for the December 2014 quarter and the six months ended December 2014 was related to the final award amount of $630 million, less litigation and other related costs of $10 million, in the Company’s case against Western Digital for the misappropriation of the Company’s trade secrets.

[0001104659-15-005719:mdna:47]
Other income (expense), net

[0001104659-15-005719:mdna:48]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |
| (Dollars in millions) |  | January 2, 2015 |  | October 3, 2014 |  | December 27, 2013 |  | January 2, 2015 |  | December 27, 2013 |  |
| Other income (expense), net |  | $ | 73 |  | $ | (64 | ) | $ | (2 | ) | $ | 8 |  | $ | (40 | ) |

[0001104659-15-005719:mdna:49]
Other income (expense), net increased for the December 2014 quarter when compared to the September 2014 quarter by $137 million, which was due to the partial payment of $143 million for interest accrued on the final arbitration award amount in the Company’s case against Western Digital, partially offset by a $23 million increase in losses from the early redemption and repurchase of debt. Compared to the December 2013 quarter, Other income (expense), net increased by $75 million primarily due to the partial payment of $143 million for interest accrued on the final arbitration award amount in the Company’s case against Western Digital, partially offset by a $37 million increase in losses from the early redemption and repurchase of debt and a gain of $32 million from the sale of one of our strategic investments recognized in the December 2013 quarter.

[0001104659-15-005719:mdna:50]
Other income (expense), net decreased for the six months ended December 2014 as compared to the corresponding period in the prior year primarily due to the partial payment of $143 million for interest accrued on the final arbitration award amount in our case against Western Digital, partially offset by a $52 million increase in losses from the early redemption and repurchase of debt and a gain of $32 million from the sale of one of our strategic investments in the December 2013 quarter.

[0001104659-15-005719:mdna:51]
[same as prior period, unchanged from 0001104659-14-075666:mdna:41]

[0001104659-15-005719:mdna:52]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |
| (Dollars in millions) |  | January 2, 2015 |  | October 3, 2014 |  | December 27, 2013 |  | January 2, 2015 |  | December 27, 2013 |  |
| Provision for income taxes |  | $ | 193 |  | $ | 11 |  | $ | 14 |  | $ | 203 |  | $ | 27 |  |

[0001104659-15-005719:mdna:53]
Our income tax provision recorded for the December 2014 quarter and for the first half of fiscal year 2015 included approximately $181 million of net tax expense due to the final audit assessment received from the Jiangsu Province State Tax Bureau of the People’s Republic of China (China assessment) for calendar years 2007 through 2013.

[0001104659-15-005719:mdna:54]
Our income tax provision recorded for the December 2014 quarter and for the first half of fiscal year 2015 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) tax expense associated

[0001104659-15-005719:mdna:55]
with the China assessment, and (iii) a decrease in valuation allowance for certain U.S. deferred tax assets. The acquisition of LSI’s Flash Business is not expected to have a material impact on our effective tax rate in fiscal year 2015.

[0001104659-15-005719:mdna:56]
The Tax Increase Prevention Act of 2014 (the Act) was enacted on December 19, 2014. The Act retroactively reinstated and extended the U.S. federal Research and Development Tax Credit (R&D Credit) to December 31, 2014, as well as the bonus depreciation on qualified property. The extension of the R&D Credit and bonus depreciation had no immediate impact on our income tax provision due to existing valuation allowances on our U.S. deferred tax assets. None of the other Act changes are expected to have a material impact on our income tax provision.

[0001104659-15-005719:mdna:57]
During the six months ended January 2, 2015, our unrecognized tax benefits excluding interest and penalties decreased by $42 million primarily due to (i) reductions associated with audit settlements of $45 million, (ii) reductions associated with the expiration of certain statutes of limitations of $4 million, (iii) increases in current year unrecognized tax benefits of $5 million, and (iv) net increases associated with changes in prior years’ positions of $2 million.

[0001104659-15-005719:mdna:58]
The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $73 million at January 2, 2015, subject to certain future valuation allowance reversals. During the 12 months beginning January 3, 2015, we expect that our unrecognized tax benefits could be reduced by approximately $3 million as a result of the expiration of certain statutes of limitation.

[0001104659-15-005719:mdna:59]
We are subject to taxation in many jurisdictions globally and are required to file U.S. federal, U.S. state, and non-U.S. income tax returns. In June 2014, we received the Revenue Agent’s Report and Notices of Proposed Adjustments for our U.S. federal income tax returns for fiscal years 2008, 2009 and 2010. We are currently contesting certain of these proposed adjustments through the IRS Appeals Office. We believe that the resolution of these disputed issues will not have a material impact on our financial statements. As discussed above, on December 31, 2014, we received the final audit assessment from the Jiangsu Province State Tax Bureau of the People’s Republic of China. The assessment is related to tax and interest associated with changes to our tax filings for calendar years 2007 through 2013. Resolving the audit in connection with obtaining agreement from the China tax authorities on predictable, future tax expense provides stability to our business model. Additional, future tax expense required by the agreement is not expected to have a material impact on our financial statements.

[0001104659-15-005719:mdna:60]
Our income tax provision recorded for the December 2013 quarter and for the first half of fiscal year 2014 included approximately $4 million and $6 million, respectively, of net discrete tax expense primarily related to increases in income tax reserves recorded for non-U.S. income positions taken in prior fiscal years offset by the tax benefits from the reversal of a portion of the U.S. valuation allowance recorded in prior periods and tax benefits associated with the release of tax reserves associated with the expiration of certain statutes of limitation.

[0001104659-15-005719:mdna:61]
Our income tax provision for the December 2013 quarter and for the first half of fiscal year 2014 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets.

[0001104659-15-005719:mdna:62]
[same as prior period, unchanged from 0001104659-14-075666:mdna:50]

[0001104659-15-005719:mdna:63]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist of readily marketable securities with remaining maturities of more than 90 days at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We intend to maintain a highly liquid portfolio by investing in money market funds, time deposits, interest-bearing bank accounts, and would invest only in those marketable securities that we believe have active secondary or resale markets. We believe our cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, these restrictions have not impeded our ability to conduct our business, nor do we expect them to in the next 12 months. We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term investments and accordingly, we do not believe the fair value of our short-term investments has significantly changed from the values reported as of January 2, 2015.

[0001104659-15-005719:mdna:64]
[same as prior period, unchanged from 0001104659-14-075666:mdna:52]

[0001104659-15-005719:mdna:65]
| (Dollars in millions) |  | January 2, 2015 |  | June 27, 2014 |  | Change |  |
| Cash and cash equivalents |  | $ | 3,296 |  | $ | 2,634 |  | $ | 662 |  |
| Short-term investments |  | 6 |  | 20 |  | (14 | ) |
| Restricted cash and investments |  | 4 |  | 4 |  | — |  |
| Total |  | $ | 3,306 |  | $ | 2,658 |  | $ | 648 |  |

[0001104659-15-005719:mdna:66]
Our cash and cash equivalents, short-term investments and restricted cash and investments increased from June 27, 2014 as a result of net cash provided by our operating activities, which included an arbitration award partial payment of $773 million from Western Digital, and the proceeds from the issuance of $500 million of our 5.75% Senior Notes due 2034. These cash inflows were partially offset by early redemption and repayments of long-term debt, repurchase of our ordinary shares, dividends paid to our shareholders, capital expenditures and the acquisition of LSI’s Flash Business, as disclosed below.

[0001104659-15-005719:mdna:67]
[same as prior period, unchanged from 0001104659-14-075666:mdna:55]

[0001104659-15-005719:mdna:68]
Cash provided by operating activities for the six months ended January 2, 2015 of $2.0 billion includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and an increase of $167 million in accrued expenses, income taxes and warranty primarily related to $190 million in accrued income taxes associated with the final audit assessment received from the Jiangsu Province State Tax Bureau of the People’s Republic of China related to tax and interest associated with changes to our tax filings for the calendar years 2007 through 2013.

[0001104659-15-005719:mdna:69]
Net income includes a partial payment of $773 million for the arbitration award and related accrued interest, received from Western Digital.

[0001104659-15-005719:mdna:70]
[same as prior period, unchanged from 0001104659-14-075666:mdna:59]

[0001104659-15-005719:mdna:71]
Cash used for investing activities for the six months ended January 2, 2015 was $853 million which includes $387 million used for acquired property, equipment and leasehold improvements and $450 million used for the acquisition of LSI’s Flash Business.

[0001104659-15-005719:mdna:72]
[same as prior period, unchanged from 0001104659-14-075666:mdna:61]

[0001104659-15-005719:mdna:73]
Net cash used in financing activities of $518 million for the six months ended January 2, 2015 was attributable to the following activities:

[0001104659-15-005719:mdna:74]
·                  $535 million of redemption and repayments of long-term debt;

[0001104659-15-005719:mdna:75]
·                  $317 million in dividend payments;

[0001104659-15-005719:mdna:76]
·                  $201 million paid to repurchase ordinary shares; and partially offset by

[0001104659-15-005719:mdna:77]
·                  net proceeds of $498 million received from issuance of our 5.75% Senior Notes due 2034.

[0001104659-15-005719:mdna:78]
[same as prior period, unchanged from 0001104659-14-075666:mdna:63]

[0001104659-15-005719:mdna:79]
Our primary sources of liquidity as of January 2, 2015 consisted of: (1) approximately $3.3 billion in cash, cash equivalents, and short-term investments, (2) cash we expect to generate from operations and (3) a $500 million senior revolving credit facility.

[0001104659-15-005719:mdna:80]
On January 15, 2015, the Company and Seagate HDD Cayman entered into the Third Amendment to the Credit Agreement (the “Amendment”) which increased the commitments available under the Revolving Credit Facility from $500 million to $700 million and also extended the maturity date on the Credit Agreement until January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Credit Agreement) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. As of January 30, 2015, no borrowings have been drawn or letters of credit utilized under the Revolving Credit Facility. The line of credit is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowings.

[0001104659-15-005719:mdna:81]
36

[0001104659-15-005719:mdna:82]
The credit agreement that governs our revolving credit facility, as amended, contains certain covenants that we must satisfy in order to remain in compliance with the credit agreement, as amended. The agreement also includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. As of January 2, 2015, we were in compliance with all of the covenants under our Revolving Credit Facility and debt agreements. Based on our current outlook, we expect to be in compliance with the covenants of our debt agreements over the next 12 months.

[0001104659-15-005719:mdna:83]
[same as prior period, unchanged from 0001104659-14-075666:mdna:67]

[0001104659-15-005719:mdna:84]
[same as prior period, unchanged from 0001104659-14-075666:mdna:68]

[0001104659-15-005719:mdna:85]
From time to time we may repurchase any of our outstanding notes in open market or privately negotiated purchases or otherwise, or may repurchase outstanding notes pursuant to the terms of the applicable indenture.

[0001104659-15-005719:mdna:86]
The Company’s Board of Directors approved a quarterly cash dividend of $0.54 per share on January 20, 2015, which is payable on February 24, 2015 to shareholders of record at the close of business on February 10, 2015.

[0001104659-15-005719:mdna:87]
From time to time we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases.  As of January 2, 2015, $1.3 billion remained available for repurchase under our existing repurchase authorization limit.  All repurchases are effected as redemptions in accordance with the Company’s Articles of Association.

[0001104659-15-005719:mdna:88]
On December 31, 2014, we received the final audit assessment from the Jiangsu Province State Tax Bureau of the People’s Republic of China. The assessment of $228 million was related to tax and interest associated with changes to our tax filings for calendar years 2007 through 2013. The assessment was paid on January 4, 2015.

[0001104659-15-005719:mdna:89]
[same as prior period, unchanged from 0001104659-14-075666:mdna:73]

[0001104659-15-005719:mdna:90]
[same as prior period, unchanged from 0001104659-14-075666:mdna:74]

[0001104659-15-005719:mdna:91]
Since our fiscal year ended June 27, 2014, there have been no material changes in our critical accounting policies and estimates.  Refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended June 27, 2014, as filed with the SEC on August 7, 2014, for a discussion of our critical accounting policies and estimates.

[0001104659-15-005719:mdna:92]
[same as prior period, unchanged from 0001104659-14-075666:mdna:77]

[0001104659-15-005719:mdna:93]
[same as prior period, unchanged from 0001104659-14-075666:mdna:78]
