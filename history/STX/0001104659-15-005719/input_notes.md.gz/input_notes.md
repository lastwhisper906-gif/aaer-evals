# STX notes — 0001104659-15-005719


## invest:InvestmentTableTextBlock

[0001104659-15-005719:notes:1]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,324 |  |  | $ | — |  |  | $ | 1,324 |  |
| Corporate bonds |  | 6 |  |  | — |  |  | 6 |  |
| Certificates of deposit |  | 1,440 |  |  | — |  |  | 1,440 |  |
|  |  | $ | 2,770 |  |  | $ | — |  |  | $ | 2,770 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 2,760 |  |
| Included in Short-term investments |  |  |  |  |  |  |  | 6 |  |
| Included in Restricted cash and investments |  |  |  |  |  |  |  | 4 |  |
| Total |  |  |  |  |  |  |  | $ | 2,770 |  |

[0001104659-15-005719:notes:2]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 793 |  |  | $ | — |  |  | $ | 793 |  |
| Commercial paper |  | 1,261 |  |  | — |  |  | 1,261 |  |
| Corporate bonds |  | 6 |  |  | — |  |  | 6 |  |
| Certificates of deposit |  | 273 |  |  | — |  |  | 273 |  |
| Total |  | $ | 2,333 |  |  | $ | — |  |  | $ | 2,333 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 2,309 |  |
| Included in Short-term investments |  |  |  |  |  |  |  | 20 |  |
| Included in Restricted cash and investments |  |  |  |  |  |  |  | 4 |  |
| Total |  |  |  |  |  |  |  | $ | 2,333 |  |


## stx:ScheduleOfShareRepurchasesTableTextBlock

[0001104659-15-005719:notes:3]
| (In millions) | Number ofSharesRepurchased |  | Dollar Valueof SharesRepurchased |
| Repurchased during the three months ended October 3, 2014 | 3 |  |  | $ | 183 |  |
| Repurchased during the three months ended January 2, 2015 (1) | 0 |  |  | 18 |  |
| Fiscal year repurchased through January 2, 2015 | 3 |  |  | $ | 201 |  |

[0001104659-15-005719:notes:4]
_______________________

[0001104659-15-005719:notes:5]
(1) A total of 0.3 million shares were repurchased during the three months ended January 2, 2015.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001104659-15-005719:notes:6]
[same as prior period, unchanged from 0001104659-14-075666:notes:1]

[0001104659-15-005719:notes:7]
[same as prior period, unchanged from 0001104659-14-075666:notes:2]

[0001104659-15-005719:notes:8]
[same as prior period, unchanged from 0001104659-14-075666:notes:3]

[0001104659-15-005719:notes:9]
[same as prior period, unchanged from 0001104659-14-075666:notes:4]

[0001104659-15-005719:notes:10]
[same as prior period, unchanged from 0001104659-14-075666:notes:5]

[0001104659-15-005719:notes:11]
[same as prior period, unchanged from 0001104659-14-075666:notes:6]

[0001104659-15-005719:notes:12]
[same as prior period, unchanged from 0001104659-14-075666:notes:7]

[0001104659-15-005719:notes:13]
[same as prior period, unchanged from 0001104659-14-075666:notes:8]

[0001104659-15-005719:notes:14]
The Company incurred approximately $1 million of expenses related to the acquisition of LSI's Flash Business during the six months ended January 2, 2015, which are included within Marketing and administrative expense on the Consolidated Statement of Operations.

[0001104659-15-005719:notes:15]
[same as prior period, unchanged from 0001104659-14-075666:notes:10]

[0001104659-15-005719:notes:16]
[same as prior period, unchanged from 0001104659-14-075666:notes:11]

[0001104659-15-005719:notes:17]
[same as prior period, unchanged from 0001104659-14-075666:notes:12]

[0001104659-15-005719:notes:18]
[same as prior period, unchanged from 0001104659-14-075666:notes:13]

[0001104659-15-005719:notes:19]
[same as prior period, unchanged from 0001104659-14-075666:notes:14]

[0001104659-15-005719:notes:20]
[same as prior period, unchanged from 0001104659-14-075666:notes:15]

[0001104659-15-005719:notes:21]
[same as prior period, unchanged from 0001104659-14-075666:notes:16]

[0001104659-15-005719:notes:22]
[same as prior period, unchanged from 0001104659-14-075666:notes:17]

[0001104659-15-005719:notes:23]
[same as prior period, unchanged from 0001104659-14-075666:notes:18]


## us-gaap:ConsolidationPolicyTextBlock

[0001104659-15-005719:notes:24]
[same as prior period, unchanged from 0001104659-14-075666:notes:19]

[0001104659-15-005719:notes:25]
[same as prior period, unchanged from 0001104659-14-075666:notes:20]

[0001104659-15-005719:notes:26]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income, cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature.

[0001104659-15-005719:notes:27]
[same as prior period, unchanged from 0001104659-14-075666:notes:22]


## us-gaap:DebtDisclosureTextBlock

[0001104659-15-005719:notes:28]
Debt

[0001104659-15-005719:notes:29]
Short-Term Borrowings

[0001104659-15-005719:notes:30]
As of January 2, 2015, the Company and its subsidiary, Seagate HDD Cayman, had a senior secured revolving credit facility (the "Revolving Credit Facility") of $500 million. On January 15, 2015, the Company and its subsidiary, Seagate HDD Cayman, entered into the Third Amendment to the 2011 Credit Agreement (the "Amendment") which increased the commitments available under the Revolving Credit Facility from $500 million to $700 million and also extended the maturity date on the Credit Agreement until January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Credit Agreement) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied.  The loans made under the Credit Agreement will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings and for the issuance of letters of credit up to a sub-limit of $75 million. As of January 2, 2015, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

[0001104659-15-005719:notes:31]
Long-Term Debt

[0001104659-15-005719:notes:32]
$600 million Aggregate Principal Amount of 6.8% Senior Notes due October 2016 (the “2016 Notes”). The interest on the 2016 Notes was payable semi-annually on April 1 and October 1 of each year. The issuer under the 2016 Notes was Seagate HDD Cayman, and the obligations under the 2016 Notes were unconditionally guaranteed by certain of the Company’s significant subsidiaries.  During the December 2014 quarter, the 2016 Notes were fully extinguished through repurchase and redemption for cash at a premium to their principal amount, plus accrued and unpaid interest.  The Company recorded a loss on the repurchase and redemption of approximately $34 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

[0001104659-15-005719:notes:33]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-15-005719:notes:34]
$600 million Aggregate Principal Amount of 6.875% Senior Notes due May 2020 (the “2020 Notes”). The interest on the 2020 Notes is payable semi-annually on May 1 and November 1 of each year. The issuer under the 2020 Notes is Seagate HDD Cayman, and the obligations under the 2020 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the December 2014 quarter, the Company repurchased $30 million aggregate principal amount of its 2020 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately of $2 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

[0001104659-15-005719:notes:35]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman, and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the December 2014 quarter, the Company repurchased $14 million aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately $2 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

[0001104659-15-005719:notes:36]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-15-005719:notes:37]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year, commencing on January 1, 2015. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-15-005719:notes:38]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 1, 2034 (the “2034 Notes”). On December 2, 2014, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 5.75% Senior Notes due 2034 which mature on December 1, 2034. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on June 1, 2015. At any time before June 1, 2034, Seagate HDD Cayman may redeem some or all of the Notes at a "make-whole" redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points, minus accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date. At any time on or after June 1, 2034, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-15-005719:notes:39]
At January 2, 2015, future principal payments on long-term debt were as follows (in millions):

[0001104659-15-005719:notes:40]
| Fiscal Year | Amount |
| Remainder of 2015 | $ | — |  |
| 2016 | — |  |
| 2017 | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| Thereafter | 3,134 |  |
|  | $ | 3,934 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001104659-15-005719:notes:41]
[same as prior period, unchanged from 0001104659-14-075666:notes:35]

[0001104659-15-005719:notes:42]
The Company is exposed to market risks due to the volatility of interest rates, foreign currency exchange rates, and bond markets. The Company enters into foreign currency forward exchange contracts to manage the foreign currency exchange rate risk on forecasted expenses denominated in foreign currencies and to mitigate the remeasurement risk of certain foreign currency denominated liabilities. The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The changes in the fair values of the effective portions of designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments and the ineffective portions of cash flow hedges are adjusted to fair value through earnings. The amount of net unrealized losses on cash flow hedges was $8 million and $1 million as of January 2, 2015 and June 27, 2014, respectively.

[0001104659-15-005719:notes:43]
The Company dedesignates its cash flow hedges when the forecasted hedged transactions are realized or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company did not recognize any net gains or losses related to the loss of hedge designation on discontinued cash flow hedges during the three and six months ended January 2, 2015. As of January 2, 2015, the Company’s existing foreign currency forward exchange contracts mature within 12 months. The deferred amount currently recorded in Accumulated other comprehensive loss expected to be recognized into earnings over the next 12 months is $9 million.

[0001104659-15-005719:notes:44]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of January 2, 2015 and June 27, 2014:

[0001104659-15-005719:notes:45]
|  |  | As of January 2, 2015 |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| Thai Baht |  | $ | — |  |  | $ | 31 |  |
| Singapore Dollars |  | 171 |  |  | 17 |  |
| Chinese Renminbi |  | 86 |  |  | — |  |
|  |  | $ | 257 |  |  | $ | 48 |  |

[0001104659-15-005719:notes:46]
[same as prior period, unchanged from 0001104659-14-075666:notes:40]

[0001104659-15-005719:notes:47]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plan—the Seagate Deferred Compensation Plan (the “SDCP”). In the quarter ended December 27, 2013, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees. As of January 2, 2015, the notional investments underlying the TRS amounted to $92 million. The contract term of the TRS is through January 2016 and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001104659-15-005719:notes:48]
The following tables show the Company’s derivative instruments measured at fair value as reflected in the Condensed Consolidated Balance Sheet as of January 2, 2015 and June 27, 2014:

[0001104659-15-005719:notes:49]
|  |  | As of January 2, 2015 |
|  |  | Asset Derivatives |  | Liability Derivatives |
| (Dollars in millions) |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (9 | ) |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (1 | ) |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | (1 | ) |
| Total derivatives |  |  |  | $ | — |  |  |  |  | $ | (11 | ) |

[0001104659-15-005719:notes:50]
[same as prior period, unchanged from 0001104659-14-075666:notes:44]

[0001104659-15-005719:notes:51]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statement of Comprehensive Income and the Condensed Consolidated Statement of Operations for the three and six months ended January 2, 2015:

[0001104659-15-005719:notes:52]
[same as prior period, unchanged from 0001104659-14-075666:notes:46]

[0001104659-15-005719:notes:53]
| Derivatives Designated as Hedging Instruments |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  |  |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
|  |  | For the Three Months |  | For the Six Months |  |  | For the Three Months |  | For the Six Months |  |  | For the Three Months |  | For the Six Months |
| Foreign currency forward exchange contracts |  | $ | (6 | ) |  | $ | (10 | ) |  | Cost of revenue |  | $ | (2 | ) |  | $ | (2 | ) |  | Cost of revenue |  | $ | (1 | ) |  | $ | — |  |

[0001104659-15-005719:notes:54]
| Derivatives Not Designated as Hedging Instruments |  | Location ofGain or (Loss)Recognized inIncome onDerivative |  | Amount ofGain or (Loss)Recognized in Incomeon Derivative |
|  |  |  |  | For the Three Months | For the Six Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (1 | ) | $ | (5 | ) |
| Total return swap |  | Operating expenses |  | $ | 2 |  | $ | — |  |

[0001104659-15-005719:notes:55]
[same as prior period, unchanged from 0001104659-14-075666:notes:49]

[0001104659-15-005719:notes:56]
| (a) | The amount of gain or (loss) recognized in income represents $0 related to the ineffective portion of the hedging relationships and $(1) million and $0 related to the amount excluded from the assessment of hedge effectiveness for the three and six months ended January 2, 2015, respectively. |

[0001104659-15-005719:notes:57]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statement of Comprehensive Income and the Condensed Consolidated Statement of Operations for the three and six months ended December 27, 2013:

[0001104659-15-005719:notes:58]
[same as prior period, unchanged from 0001104659-14-075666:notes:52]

[0001104659-15-005719:notes:59]
| Derivatives Designated as Hedging Instruments |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
|  |  | For the Three Months |  | For the Six Months |  |  |  | For the Three Months |  | For the Six Months |  |  |  | For the Three Months |  | For the Six Months |
| Foreign currency forward exchange contracts |  | $ | (1 | ) |  | $ | — |  |  | Cost of revenue |  | $ | — |  |  | $ | — |  |  | Cost of revenue |  | $ | — |  |  | $ | — |  |

[0001104659-15-005719:notes:60]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
|  |  |  |  | For the Three Months | For the Six Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (4 | ) | $ | (5 | ) |

[0001104659-15-005719:notes:61]
| (a) | The amount of gain or (loss) recognized in income represents $0 related to the ineffective portion of the hedging relationship and $0 related to the amount excluded from the assessment of hedge effectiveness for the three and six months ended December 27, 2013. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-15-005719:notes:62]
[same as prior period, unchanged from 0001104659-14-075666:notes:56]

[0001104659-15-005719:notes:63]
The Company recorded approximately $31 million and $73 million of stock-based compensation expense during the three and six months ended January 2, 2015, respectively. The Company recorded approximately $30 million and $57 million of stock-based compensation expense during the three and six months ended December 27, 2013, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001104659-15-005719:notes:64]
[same as prior period, unchanged from 0001104659-14-075666:notes:58]

[0001104659-15-005719:notes:65]
[same as prior period, unchanged from 0001104659-14-075666:notes:59]

[0001104659-15-005719:notes:66]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (In millions, except per share data) |  | January 2, 2015 |  | December 27, 2013 |  | January 2, 2015 |  | December 27, 2013 |
| Numerator: |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Seagate Technology plc |  | $ | 933 |  |  | $ | 428 |  |  | $ | 1,314 |  |  | $ | 855 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share attributable to Seagate Technology plc |  | 328 |  |  | 336 |  |  | 327 |  |  | 347 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | 8 |  |  | 10 |  |  | 9 |  |  | 10 |  |
| Total shares for purpose of calculating diluted net income per share attributable to Seagate Technology plc |  | 336 |  |  | 346 |  |  | 336 |  |  | 357 |  |
| Net income per share attributable to Seagate Technology plc shareholders: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.84 |  |  | $ | 1.27 |  |  | $ | 4.02 |  |  | $ | 2.46 |  |
| Diluted |  | $ | 2.78 |  |  | $ | 1.24 |  |  | $ | 3.91 |  |  | $ | 2.39 |  |

[0001104659-15-005719:notes:67]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share attributable to Seagate Technology plc were immaterial for the three and six months ended January 2, 2015 and December 27, 2013.


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001104659-15-005719:notes:68]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 1,324 |  |  | $ | 1,436 |  |  | $ | — |  |  | $ | 2,760 |  |
| Short-term investments | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Restricted cash and investments | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total assets | $ | 1,324 |  |  | $ | 1,446 |  |  | $ | — |  |  | $ | 2,770 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued expenses | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 11 |  |
| Total liabilities | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 11 |  |

[0001104659-15-005719:notes:69]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 793 |  |  | $ | 1,516 |  |  | $ | — |  |  | $ | 2,309 |  |
| Short-term investments | — |  |  | 20 |  |  | — |  |  | 20 |  |
| Restricted cash and investments | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Other assets, net | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Total assets | $ | 793 |  |  | $ | 1,545 |  |  | $ | — |  |  | $ | 2,338 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued expenses | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-15-005719:notes:70]
[same as prior period, unchanged from 0001104659-14-075666:notes:64]

[0001104659-15-005719:notes:71]
[same as prior period, unchanged from 0001104659-14-075666:notes:65]

[0001104659-15-005719:notes:72]
[same as prior period, unchanged from 0001104659-14-075666:notes:66]

[0001104659-15-005719:notes:73]
[same as prior period, unchanged from 0001104659-14-075666:notes:67]

[0001104659-15-005719:notes:74]
[same as prior period, unchanged from 0001104659-14-075666:notes:68]

[0001104659-15-005719:notes:75]
[same as prior period, unchanged from 0001104659-14-075666:notes:69]

[0001104659-15-005719:notes:76]
[same as prior period, unchanged from 0001104659-14-075666:notes:70]

[0001104659-15-005719:notes:77]
[same as prior period, unchanged from 0001104659-14-075666:notes:71]

[0001104659-15-005719:notes:78]
[same as prior period, unchanged from 0001104659-14-075666:notes:72]

[0001104659-15-005719:notes:79]
[same as prior period, unchanged from 0001104659-14-075666:notes:73]

[0001104659-15-005719:notes:80]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of January 2, 2015:

[0001104659-15-005719:notes:81]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,324 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,324 |  |
| Certificates of deposit | — |  |  | 1,436 |  |  | — |  |  | 1,436 |  |
| Corporate bonds | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total cash equivalents and short-term investments | 1,324 |  |  | 1,442 |  |  | — |  |  | 2,766 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |
| Other securities | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total assets | $ | 1,324 |  |  | $ | 1,446 |  |  | $ | — |  |  | $ | 2,770 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Total return swap | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total liabilities | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 11 |  |

[0001104659-15-005719:notes:82]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of June 27, 2014:

[0001104659-15-005719:notes:83]
[same as prior period, unchanged from 0001104659-14-075666:notes:77]

[0001104659-15-005719:notes:84]
[same as prior period, unchanged from 0001104659-14-075666:notes:78]

[0001104659-15-005719:notes:85]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds and U.S. Treasuries. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair values of all of its cash equivalents and short-term investments. For the cash equivalents and short-term investments in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry standard data providers or other third party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of January 2, 2015, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts and the TRS. The Company recognizes derivative financial instruments in its condensed consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001104659-15-005719:notes:86]
The Company enters into certain strategic investments for the achievement of business and strategic objectives. Strategic investments in equity securities where the Company does not have the ability to exercise significant influence over the investees, are included in Other assets, net in the Condensed Consolidated Balance Sheets, are recorded at cost and are periodically analyzed to determine whether or not there are indicators of impairment. The carrying value of the Company’s strategic investments at January 2, 2015 and June 27, 2014 totaled $71 million and $46 million, respectively, and consisted primarily of privately held equity securities without a readily determinable fair value.

[0001104659-15-005719:notes:87]
[same as prior period, unchanged from 0001104659-14-075666:notes:81]

[0001104659-15-005719:notes:88]
[same as prior period, unchanged from 0001104659-14-075666:notes:82]

[0001104659-15-005719:notes:89]
|  |  | January 2, 2015 |  | June 27, 2014 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 800 |  |  | $ | 824 |  |  | $ | 800 |  |  | $ | 820 |  |
| 6.875% Senior Notes due May 2020 |  | 476 |  |  | 501 |  |  | 534 |  |  | 578 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 174 |  |  | 251 |  |  | 284 |  |
| 4.75% Senior Notes due June 2023 |  | 1,000 |  |  | 1,050 |  |  | 1,000 |  |  | 1,009 |  |
| 4.75% Senior Notes due January 2025 |  | 1,000 |  |  | 1,032 |  |  | 1,000 |  |  | 995 |  |
| 5.75% Senior Notes due December 2034 |  | 498 |  |  | 537 |  |  | — |  |  | — |  |
| Long-term debt |  | $ | 3,932 |  |  | $ | 4,118 |  |  | $ | 3,585 |  |  | $ | 3,686 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-15-005719:notes:90]
| 6. | Goodwill and Other Intangible Assets |

[0001104659-15-005719:notes:91]
[same as prior period, unchanged from 0001104659-14-075666:notes:85]

[0001104659-15-005719:notes:92]
The changes in the carrying amount of goodwill for the six months ended January 2, 2015, are as follows:

[0001104659-15-005719:notes:93]
| (Dollars in millions) | Amount |
| Balance at June 27, 2014 | $ | 537 |  |
| Goodwill acquired | 337 |  |
| Foreign currency translation effect | (2 | ) |
| Balance at January 2, 2015 | $ | 872 |  |

[0001104659-15-005719:notes:94]
[same as prior period, unchanged from 0001104659-14-075666:notes:88]

[0001104659-15-005719:notes:95]
[same as prior period, unchanged from 0001104659-14-075666:notes:89]

[0001104659-15-005719:notes:96]
The carrying value of other intangible assets subject to amortization as of January 2, 2015, is set forth in the following table:

[0001104659-15-005719:notes:97]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 159 |  |  | $ | (41 | ) |  | $ | 118 |  |  | 3.1 years |
| Customer relationships |  | 488 |  |  | (237 | ) |  | 251 |  |  | 3.0 years |
| Trade names |  | 27 |  |  | (3 | ) |  | 24 |  |  | 3.7 years |
| Other intangible assets |  | 26 |  |  | (1 | ) |  | 25 |  |  | 4.7 years |
| Total amortizable other intangible assets |  | $ | 700 |  |  | $ | (282 | ) |  | $ | 418 |  |  | 3.2 years |

[0001104659-15-005719:notes:98]
The carrying value of In-process research and development not subject to amortization was $31 million on January 2, 2015.

[0001104659-15-005719:notes:99]
[same as prior period, unchanged from 0001104659-14-075666:notes:93]

[0001104659-15-005719:notes:100]
[same as prior period, unchanged from 0001104659-14-075666:notes:94]

[0001104659-15-005719:notes:101]
[same as prior period, unchanged from 0001104659-14-075666:notes:95]

[0001104659-15-005719:notes:102]
For the three and six months ended January 2, 2015, amortization expense of other intangible assets was $39 million and $72 million.  For the three and six months ended December 27, 2013, amortization expense of other intangible assets was $39 million and $76 million.  As of January 2, 2015, expected amortization expense for other intangible assets for each of the next five fiscal years and thereafter is as follows:

[0001104659-15-005719:notes:103]
| (Dollars in millions) | Amount |
| Remainder of 2015 | $ | 79 |  |
| 2016 | 137 |  |
| 2017 | 119 |  |
| 2018 | 58 |  |
| 2019 | 21 |  |
| Thereafter | 4 |  |
|  | $ | 418 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-15-005719:notes:104]
[same as prior period, unchanged from 0001104659-14-075666:notes:98]

[0001104659-15-005719:notes:105]
The Company recorded an income tax provision of $193 million and $203 million in the three and six months ended January 2, 2015, respectively. The income tax provision for the three and six months ended January 2, 2015, included approximately $181 million of net tax expense due to the final audit assessment received from the Jiangsu Province State Tax Bureau of the People's Republic of China (China assessment) for calendar years 2007 through 2013.

[0001104659-15-005719:notes:106]
The Company's income tax provision recorded for the three and six months ended January 2, 2015 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) tax expense associated with the China assessment, and (iii) a decrease in valuation allowance for certain U.S. deferred tax assets.

[0001104659-15-005719:notes:107]
The Tax Increase Prevention Act of 2014 (the Act) was enacted on December 19, 2014. The Act retroactively reinstated and extended the U.S. federal Research and Development Tax Credit (R&D Credit) to December 31, 2014, as well as the bonus depreciation on qualified property. The extension of the R&D Credit and bonus depreciation had no immediate impact on the Company’s income tax provision due to existing valuation allowances on its U.S. deferred tax assets. None of the other Act changes are expected to have a material impact on the Company’s income tax provision.

[0001104659-15-005719:notes:108]
During the six months ended January 2, 2015, the Company’s unrecognized tax benefits excluding interest and penalties decreased by $42 million primarily due to (i) reductions associated with audit settlements of $45 million, (ii) reductions associated with the expiration of certain statutes of limitations of $4 million, (iii) increases in current year unrecognized tax benefits of $5 million, and (iv) net increases associated with changes in prior years' positions of $2 million.

[0001104659-15-005719:notes:109]
The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $73 million at January 2, 2015, subject to certain future valuation allowance reversals. During the 12 months beginning January 3, 2015, the Company expects that its unrecognized tax benefits could be reduced by approximately $3 million as a result of the expiration of certain statutes of limitation.

[0001104659-15-005719:notes:110]
The Company is subject to taxation in many jurisdictions globally and is required to file U.S. federal, U.S. state and non-U.S. income tax returns. In June 2014, the Company received the Revenue Agent’s Report and Notices of Proposed Adjustments for its U.S. federal income tax returns for fiscal years 2008, 2009 and 2010. The Company is currently contesting certain of these proposed adjustments through the IRS Appeals Office. The Company believes that the resolution of these disputed issues will not have a material impact on its financial statements. As discussed above, on December 31, 2014, the Company received the final audit assessment from the Jiangsu Province State Tax Bureau of the People’s Republic of China. The assessment is related to tax and interest associated with changes to the Company’s tax filings for calendar years 2007 through 2013.

[0001104659-15-005719:notes:111]
The Company recorded an income tax provision of $14 million and $27 million in the three and six months ended December 27, 2013, respectively. The income tax provision recorded for the three and six months ended December 27, 2013 included approximately $4 million and $6 million, respectively, of net discrete tax expense primarily related to increases in income tax reserves recorded for non-U.S. income positions taken in prior fiscal years offset by the tax benefits from the reversal of a portion of the U.S. valuation allowance recorded in prior periods and tax benefits associated with the release of tax reserves associated with the expiration of certain statutes of limitation.

[0001104659-15-005719:notes:112]
The Company’s income tax provision recorded for the three and six months ended December 27, 2013 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001104659-15-005719:notes:113]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 2,770 |  |  | $ | 2,770 |  |
| Due in 1 to 5 years |  | — |  |  | — |  |
| Thereafter |  | — |  |  | — |  |
| Total |  | $ | 2,770 |  |  | $ | 2,770 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001104659-15-005719:notes:114]
Legal, Environmental and Other Contingencies

[0001104659-15-005719:notes:115]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss.  In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment.  In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect.  Litigation is inherently uncertain and may result in adverse rulings or decisions.  Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001104659-15-005719:notes:116]
Intellectual Property Litigation

[0001104659-15-005719:notes:117]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al.—On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent Nos. 4,916,635 (the “'635 patent”) and U.S. Patent No. 5,638,267 (the “'267 patent”), misappropriation of trade secrets, breach of contract, and other claims.  In the complaint, the plaintiffs requested injunctive relief, $800 million in compensatory damages and unspecified punitive damages, including for willful infringement.  On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe US Patent No. 6,314,473 (the “'473 patent”).  The district court ruled in 2010 that the '267 patent was out of the case.

[0001104659-15-005719:notes:118]
On August 16, 2011, the district court granted in part and denied in part the Company's motion for summary judgment.  On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court's summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court's summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent.  On July 11, 2014, the district court granted the Company’s summary judgment motion regarding Convolve’s only remaining cause of action, which alleged infringement of the ‘473 patent. The court entered judgment in favor of the Company on July 14, 2014. Convolve filed a notice of appeal on August 13, 2014. The court of appeals has not yet set a date for oral argument. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-15-005719:notes:119]
Alexander Shukh v. Seagate Technology—On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. On March 31, 2014, the district court granted Seagate’s summary judgment motion and entered judgment in favor of Seagate.  Mr. Shukh filed a notice of appeal on April 7, 2014. The court of appeals has not yet set a date for oral argument. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-15-005719:notes:120]
LEAP Co., Ltd. v. Seagate Singapore International Headquarters Pte. Ltd. and Nippon Seagate Inc.—On July 4, 2012, LEAP Co., Ltd. filed a lawsuit in the Tokyo District Court of Japan against Seagate Singapore International Headquarters Pte. Ltd., Nippon Seagate Inc. and Buffalo Inc. alleging wrongful termination of purchase agreements and other claims, and seeking approximately $38 million in damages. A date for the start of trial has not yet been scheduled. The Company believes the claims are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-15-005719:notes:121]
Realtek Semiconductor Corporation ITC Investigation re Certain Integrated Circuit Chips and Products Containing the Same-On September 19, 2012, Realtek Semiconductor Corporation filed a complaint with the International Trade Commission (“ITC”) seeking an investigation pursuant to Section 337 of the Tariff Act of 1930, as amended (“Section 337”). The complaint names LSI Corporation and Seagate Technology as respondents and alleges infringement of U.S. patents relating to integrated circuit chips that include bond pad structures. Realtek seeks an order to exclude entry of infringing integrated circuit chips and products containing the infringing integrated circuit chips into the U.S. and a cease and desist order. The ITC initiated an investigation on October 18, 2012. On March 21, 2014, the Administrative Law Judge (“ALJ”) issued an Initial Determination in favor of Seagate and LSI. On July 21, 2014, the Commission gave notice that it had determined to affirm in part, reverse in part and vacate in part the ALJ’s Initial Determination; the Commission found that no violation of Section 337 by Seagate or LSI has occurred based on findings that certain of the patent claims at issue were invalid, and that Realtek failed to show the existence of an industry in the U.S. that exploits the patent. Realtek filed a notice of appeal on September 18, 2014. By agreement of the parties, Realtek’s appeal was dismissed on October 17, 2014. In view of the Commission’s July 21, 2014 decision and the October 17, 2014 dismissal of Realtek’s appeal, the Company believes that this matter will not result in any loss or other adverse result.

[0001104659-15-005719:notes:122]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995, “Cryptographic Device,” and U.S. Patent No. 7,900,057, “Cryptographic Serial ATA Apparatus and Method.”  The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys' fees, and other relief.  The trial is scheduled to begin July 11, 2016.  The Company believes the claims are without merit and intends to vigorously defend this case.  In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-15-005719:notes:123]
Seagate Technology LLC v. Western Digital Corp.  On October 8, 2014, the Minnesota Supreme Court ruled that the arbitration award in favor of the Company in its case against Western Digital for the misappropriation of the Company’s trade secrets should be confirmed. In the arbitration award, issued on January 23, 2012, the arbitrator determined that Western Digital and its former employee had misappropriated the Company’s trade secrets. The arbitrator awarded the Company $525 million in compensatory damages and, after adding interest, issued a final award of $630 million. Interest on the final award has been accruing at 10%.  On October 14, 2014, the Company received a partial payment from Western Digital in the amount of $773 million. The amount of the final award, less litigation and other related costs, has been recorded by the Company in Gain on arbitration award, net, and the remaining amount received has been recorded in Other, net.

[0001104659-15-005719:notes:124]
Environmental Matters

[0001104659-15-005719:notes:125]
The Company's operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company's operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001104659-15-005719:notes:126]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001104659-15-005719:notes:127]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001104659-15-005719:notes:128]
While the Company's ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001104659-15-005719:notes:129]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.

[0001104659-15-005719:notes:130]
Other Matters

[0001104659-15-005719:notes:131]
The Company is involved in a number of other judicial and administrative proceedings incidental to its business, and the Company may be involved in various legal proceedings arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001104659-15-005719:notes:132]
In May 2014, The FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers. The ASU outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The ASU will be effective for the Company's first quarter of fiscal year 2018. The Company is in the process of assessing the impact, if any, of ASU 2014-09 on its consolidated financial statements.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001104659-15-005719:notes:133]
[same as prior period, unchanged from 0001104659-14-075666:notes:124]

[0001104659-15-005719:notes:134]
[same as prior period, unchanged from 0001104659-14-075666:notes:125]

[0001104659-15-005719:notes:135]
[same as prior period, unchanged from 0001104659-14-075666:notes:126]

[0001104659-15-005719:notes:136]
[same as prior period, unchanged from 0001104659-14-075666:notes:127]

[0001104659-15-005719:notes:137]
The Company continues to make strategic investments in order to expand its storage solutions, enter new market adjacencies, and expand its technical expertise. As a result of recent acquisitions, the Company's product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and high performance computing ("HPC") data storage solutions. The Company's storage subsystems supports a range of high-speed interconnect technologies to meet demanding cost and performance specifications. The Company's modular subsystem architecture allows it to support many segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.

[0001104659-15-005719:notes:138]
[same as prior period, unchanged from 0001104659-14-075666:notes:129]

[0001104659-15-005719:notes:139]
The results of operations for the three and six months ended January 2, 2015, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending July 3, 2015. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three and six months ended January 2, 2015 consisted of 13 weeks and 27 weeks, respectively. The three and six months ended December 27, 2013 consisted of 13 weeks and 26 weeks, respectively.  Fiscal year 2015 will be comprised of 53 weeks and will end on July 3, 2015. The fiscal quarters ended January 2, 2015, October 3, 2014, and December 27, 2013, are also referred to herein as the “December 2014 quarter”, the “September 2014 quarter”, and the “December 2013 quarter”, respectively.

[0001104659-15-005719:notes:140]
[same as prior period, unchanged from 0001104659-14-075666:notes:131]

[0001104659-15-005719:notes:141]
[same as prior period, unchanged from 0001104659-14-075666:notes:132]

[0001104659-15-005719:notes:142]
Recently Issued Accounting Pronouncements


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001104659-15-005719:notes:143]
[same as prior period, unchanged from 0001104659-14-075666:notes:134]

[0001104659-15-005719:notes:144]
[same as prior period, unchanged from 0001104659-14-075666:notes:135]

[0001104659-15-005719:notes:145]
On May 4, 2009,  Seagate Technology, an exempted company incorporated with limited liability under the laws of the Cayman Islands (“Seagate-Cayman”), then the parent company, entered into a new form of indemnification agreement (the “Revised Indemnification Agreement”) with its officers and directors of Seagate-Cayman and its subsidiaries (each, an “Indemnitee”). The Revised Indemnification Agreement provides indemnification in addition to any of Indemnitee's indemnification rights under Seagate-Cayman's Articles of Association, applicable law or otherwise, and indemnifies an Indemnitee for certain expenses (including attorneys' fees), judgments, fines and settlement amounts actually and reasonably incurred by him or her in any action or proceeding, including any action by or in the right of Seagate-Cayman or any of its subsidiaries, arising out of his or her service as a director, officer, employee or agent of Seagate-Cayman or any of its subsidiaries or of any other entity to which he or she provides services at Seagate-Cayman's request. However, an Indemnitee shall not be indemnified under the Revised Indemnification Agreement for (i) any fraud or dishonesty in the performance of Indemnitee's duty to Seagate-Cayman or the applicable subsidiary of Seagate-Cayman or (ii) Indemnitee's conscious, intentional or willful failure to act honestly, lawfully and in good faith with a view to the best interests of Seagate-Cayman or the applicable subsidiary of Seagate-Cayman. In addition, the Revised Indemnification Agreement provides that Seagate-Cayman will advance expenses incurred by an Indemnitee in connection with enforcement of the Revised Indemnification Agreement or with the investigation, settlement or appeal of any action or proceeding against him or her as to which he or she could be indemnified.

[0001104659-15-005719:notes:146]
On July 3, 2010, pursuant to a corporate reorganization, the common shareholders of Seagate-Cayman became ordinary shareholders of Seagate Technology plc (the "Company") and Seagate-Cayman became a wholly owned subsidiary of the Company, as described more fully in the Current Report on Form 8-K filed by the Company on July 6, 2010 (the “Redomestication”). On July 27, 2010, in connection with the Redomestication, the Company, as sole shareholder of Seagate-Cayman, approved a form of deed of indemnity (the “Deed of Indemnity”), which provides for the indemnification by Seagate-Cayman of any director, officer, employee or agent of the Company, Seagate-Cayman or any subsidiary of the Company (each, a “Deed Indemnitee”), in addition to any of a Deed Indemnitee's indemnification rights under the Company's Articles of Association, applicable law or otherwise, with a similar scope to the Revised Indemnification Agreement. Seagate-Cayman entered into the Deed of Indemnity with certain Deed Indemnitees effective as of July 3, 2010 and continues to enter into the Deed of Indemnity with additional Deed Indemnitees from time to time.

[0001104659-15-005719:notes:147]
[same as prior period, unchanged from 0001104659-14-075666:notes:138]

[0001104659-15-005719:notes:148]
[same as prior period, unchanged from 0001104659-14-075666:notes:139]

[0001104659-15-005719:notes:149]
[same as prior period, unchanged from 0001104659-14-075666:notes:140]

[0001104659-15-005719:notes:150]
[same as prior period, unchanged from 0001104659-14-075666:notes:141]

[0001104659-15-005719:notes:151]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the three and six months ended January 2, 2015 and December 27, 2013 were as follows:

[0001104659-15-005719:notes:152]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | January 2, 2015 |  | December 27, 2013 |  | January 2, 2015 |  | December 27, 2013 |
| Balance, beginning of period |  | $ | 273 |  |  | $ | 318 |  |  | $ | 273 |  |  | $ | 320 |  |
| Warranties issued |  | 40 |  |  | 48 |  |  | 80 |  |  | 96 |  |
| Repairs and replacements |  | (46 | ) |  | (61 | ) |  | (100 | ) |  | (119 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | 15 |  |  | (5 | ) |  | 21 |  |  | 3 |  |
| Warranty liability assumed from business acquisitions |  | — |  |  | — |  |  | 8 |  |  | — |  |
| Balance, end of period |  | $ | 282 |  |  | $ | 300 |  |  | $ | 282 |  |  | $ | 300 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001104659-15-005719:notes:153]
| (Dollars in millions) |  | January 2, 2015 |  | June 27, 2014 |
| Property, equipment and leasehold improvements |  | $ | 9,263 |  |  | $ | 8,979 |  |
| Accumulated depreciation and amortization |  | (7,108 | ) |  | (6,843 | ) |
|  |  | $ | 2,155 |  |  | $ | 2,136 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001104659-15-005719:notes:154]
| (Dollars in millions) |  | Unrealized Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Marketable Securities (a) |  | Unrealized Gains (Losses) on post-retirements |  | Foreign currency translation adjustments |  | Total |
| Balance at June 27, 2014 |  | $ | (1 | ) |  | $ | — |  |  | $ | (10 | ) |  | $ | 9 |  |  | $ | (2 | ) |
| Other comprehensive income (loss) before reclassifications |  | (9 | ) |  | — |  |  | — |  |  | (16 | ) |  | (25 | ) |
| Amounts reclassified from AOCI |  | 2 |  |  | — |  |  | — |  |  | — |  |  | 2 |  |
| Other comprehensive income (loss) |  | (7 | ) |  | — |  |  | — |  |  | (16 | ) |  | (23 | ) |
| Balance at January 2, 2015 |  | $ | (8 | ) |  | $ | — |  |  | $ | (10 | ) |  | $ | (7 | ) |  | $ | (25 | ) |
| Balance at June 28, 2013 |  | $ | — |  |  | $ | (3 | ) |  | $ | (10 | ) |  | $ | — |  |  | $ | (13 | ) |
| Other comprehensive income (loss) before reclassifications |  | (1 | ) |  | 1 |  |  | 1 |  |  | 5 |  |  | 6 |  |
| Amounts reclassified from AOCI |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) |  | (1 | ) |  | 1 |  |  | 1 |  |  | 5 |  |  | 6 |  |
| Balance at December 27, 2013 |  | $ | (1 | ) |  | $ | (2 | ) |  | $ | (9 | ) |  | $ | 5 |  |  | $ | (7 | ) |

[0001104659-15-005719:notes:155]
[same as prior period, unchanged from 0001104659-14-075666:notes:146]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001104659-15-005719:notes:156]
| (Dollars in millions) |  | January 2, 2015 |  | June 27, 2014 |
| Raw materials and components |  | $ | 326 |  |  | $ | 324 |  |
| Work-in-process |  | 328 |  |  | 267 |  |
| Finished goods |  | 475 |  |  | 394 |  |
|  |  | $ | 1,129 |  |  | $ | 985 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-15-005719:notes:157]
[same as prior period, unchanged from 0001104659-14-075666:notes:148]

[0001104659-15-005719:notes:158]
[same as prior period, unchanged from 0001104659-14-075666:notes:149]

[0001104659-15-005719:notes:159]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 328,835,128 shares were outstanding as of January 2, 2015, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of January 2, 2015.

[0001104659-15-005719:notes:160]
[same as prior period, unchanged from 0001104659-14-075666:notes:151]

[0001104659-15-005719:notes:161]
[same as prior period, unchanged from 0001104659-14-075666:notes:152]

[0001104659-15-005719:notes:162]
[same as prior period, unchanged from 0001104659-14-075666:notes:153]

[0001104659-15-005719:notes:163]
[same as prior period, unchanged from 0001104659-14-075666:notes:154]

[0001104659-15-005719:notes:164]
[same as prior period, unchanged from 0001104659-14-075666:notes:155]

[0001104659-15-005719:notes:165]
[same as prior period, unchanged from 0001104659-14-075666:notes:156]

[0001104659-15-005719:notes:166]
As of January 2, 2015, $1.3 billion remained available for repurchase under the existing repurchase authorization limit.

[0001104659-15-005719:notes:167]
The following table sets forth information with respect to repurchases of the Company’s shares during the six months ended January 2, 2015:


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001104659-15-005719:notes:168]
[same as prior period, unchanged from 0001104659-14-075666:notes:162]

[0001104659-15-005719:notes:169]
[same as prior period, unchanged from 0001104659-14-075666:notes:163]

[0001104659-15-005719:notes:170]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of January 2, 2015:

[0001104659-15-005719:notes:171]
As of January 2, 2015, the Company’s Restricted cash and investments consisted of $4 million in cash and investments held as collateral at banks for various performance obligations.

[0001104659-15-005719:notes:172]
As of January 2, 2015, the Company had no available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined that no available-for-sale securities were other-than-temporarily impaired as of January 2, 2015.

[0001104659-15-005719:notes:173]
The fair value and amortized cost of the Company’s investments classified as available-for-sale at January 2, 2015, by remaining contractual maturity were as follows:

[0001104659-15-005719:notes:174]
[same as prior period, unchanged from 0001104659-14-075666:notes:169]

[0001104659-15-005719:notes:175]
[same as prior period, unchanged from 0001104659-14-075666:notes:171]

[0001104659-15-005719:notes:176]
[same as prior period, unchanged from 0001104659-14-075666:notes:172]

[0001104659-15-005719:notes:177]
[same as prior period, unchanged from 0001104659-14-075666:notes:173]

[0001104659-15-005719:notes:178]
[same as prior period, unchanged from 0001104659-14-075666:notes:174]

[0001104659-15-005719:notes:179]
[same as prior period, unchanged from 0001104659-14-075666:notes:175]

[0001104659-15-005719:notes:180]
[same as prior period, unchanged from 0001104659-14-075666:notes:176]

[0001104659-15-005719:notes:181]
[same as prior period, unchanged from 0001104659-14-075666:notes:177]
