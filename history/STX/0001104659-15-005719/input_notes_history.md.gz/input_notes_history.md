# STX note change history — 0001104659-14-075666 → 0001104659-15-005719


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-01-30):
[0001104659-15-005719:note_history:1]
On August 16, 2011, the district court granted in part and denied in part the Company's motion for summary judgment.  On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court's summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court's summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent.  On July 11, 2014, the district court granted the Company’s summary judgment motion regarding Convolve’s only remaining cause of action, which alleged infringement of the ‘473 patent. The court entered judgment in favor of the Company on July 14, 2014. Convolve filed a notice of appeal on August 13, 2014. The court of appeals has not yet set a date for oral argument. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2014-11-03, similarity 0.6923):
[0001104659-14-075666:note_history:1]
On August 16, 2011, the district court granted in part and denied in part the Company's motion for summary judgment.  On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court's summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court's summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent.  On July 11, 2014, the district court granted its ruling on the Company’s summary judgment motion regarding Convolve’s only remaining cause of action, which alleged infringement of the ‘473 patent. The court entered judgment in favor of the Company on July 14, 2014. Convolve filed a notice of appeal on August 13, 2014. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- changed (2015-01-30):
[0001104659-15-005719:note_history:2]
Alexander Shukh v. Seagate Technology—On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. On March 31, 2014, the district court granted Seagate’s summary judgment motion and entered judgment in favor of Seagate.  Mr. Shukh filed a notice of appeal on April 7, 2014. The court of appeals has not yet set a date for oral argument. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2014-11-03, similarity 0.6667):
[0001104659-14-075666:note_history:2]
Alexander Shukh v. Seagate Technology—On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. The Company believes the claims are without merit and intends to vigorously defend this case. On March 31, 2014, the district court granted Seagate’s summary judgment motion and entered judgment in favor of Seagate.  Mr. Shukh filed a notice of appeal on April 7, 2014. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- changed (2015-01-30):
[0001104659-15-005719:note_history:3]
Realtek Semiconductor Corporation ITC Investigation re Certain Integrated Circuit Chips and Products Containing the Same-On September 19, 2012, Realtek Semiconductor Corporation filed a complaint with the International Trade Commission (“ITC”) seeking an investigation pursuant to Section 337 of the Tariff Act of 1930, as amended (“Section 337”). The complaint names LSI Corporation and Seagate Technology as respondents and alleges infringement of U.S. patents relating to integrated circuit chips that include bond pad structures. Realtek seeks an order to exclude entry of infringing integrated circuit chips and products containing the infringing integrated circuit chips into the U.S. and a cease and desist order. The ITC initiated an investigation on October 18, 2012. On March 21, 2014, the Administrative Law Judge (“ALJ”) issued an Initial Determination in favor of Seagate and LSI. On July 21, 2014, the Commission gave notice that it had determined to affirm in part, reverse in part and vacate in part the ALJ’s Initial Determination; the Commission found that no violation of Section 337 by Seagate or LSI has occurred based on findings that certain of the patent claims at issue were invalid, and that Realtek failed to show the existence of an industry in the U.S. that exploits the patent. Realtek filed a notice of appeal on September 18, 2014. By agreement of the parties, Realtek’s appeal was dismissed on October 17, 2014. In view of the Commission’s July 21, 2014 decision and the October 17, 2014 dismissal of Realtek’s appeal, the Company believes that this matter will not result in any loss or other adverse result.
  (was, 2014-11-03, similarity 0.8223):
[0001104659-14-075666:note_history:3]
Realtek Semiconductor Corporation ITC Investigation re Certain Integrated Circuit Chips and Products Containing the Same-On September 19, 2012, Realtek Semiconductor Corporation filed a complaint with the International Trade Commission (“ITC”) seeking an investigation pursuant to Section 337 of the Tariff Act of 1930, as amended (“Section 337”). The complaint names LSI Corporation and Seagate Technology as respondents and alleges infringement of U.S. patents relating to integrated circuit chips that include bond pad structures. Realtek seeks an order to exclude entry of infringing integrated circuit chips and products containing the infringing integrated circuit chips into the U.S. and a cease and desist order. The ITC initiated an investigation on October 18, 2012. On March 21, 2014, the Administrative Law Judge (“ALJ”) issued an Initial Determination in favor of Seagate and LSI. On July 21, 2014, the Commission gave notice that it had determined to affirm in part, reverse in part and vacate in part the ALJ’s Initial Determination; the Commission found that no violation of Section 337 by Seagate or LSI has occurred based on findings that certain of the patent claims at issue were invalid, and that Realtek failed to show the existence of an industry in the U.S. that exploits the patent. Realtek filed a notice of appeal on September 18, 2014. In view of the uncertainty regarding the possible outcome of this case and the nature of the relief sought, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible loss or range of loss, or other possible adverse result, if any, that may be incurred with respect to this matter.

- added (2015-01-30):
[0001104659-15-005719:note_history:4]
Seagate Technology LLC v. Western Digital Corp.  On October 8, 2014, the Minnesota Supreme Court ruled that the arbitration award in favor of the Company in its case against Western Digital for the misappropriation of the Company’s trade secrets should be confirmed. In the arbitration award, issued on January 23, 2012, the arbitrator determined that Western Digital and its former employee had misappropriated the Company’s trade secrets. The arbitrator awarded the Company $525 million in compensatory damages and, after adding interest, issued a final award of $630 million. Interest on the final award has been accruing at 10%.  On October 14, 2014, the Company received a partial payment from Western Digital in the amount of $773 million. The amount of the final award, less litigation and other related costs, has been recorded by the Company in Gain on arbitration award, net, and the remaining amount received has been recorded in Other, net.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-01-30):
[0001104659-15-005719:note_history:5]
The Company continues to make strategic investments in order to expand its storage solutions, enter new market adjacencies, and expand its technical expertise. As a result of recent acquisitions, the Company's product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and high performance computing ("HPC") data storage solutions. The Company's storage subsystems supports a range of high-speed interconnect technologies to meet demanding cost and performance specifications. The Company's modular subsystem architecture allows it to support many segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.
  (was, 2014-11-03, similarity 0.9956):
[0001104659-14-075666:note_history:5]
The Company continues to make strategic investments in order to expand its storage solutions, enter new market adjacencies, and expand our technical expertise. As a result of recent acquisitions, the Company's product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and high performance computing ("HPC") data storage solutions. The Company's storage subsystems support a range of high-speed interconnect technologies to meet demanding cost and performance specifications. The Company's modular subsystem architecture allows it to support many segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.

- added (2015-01-30):
[0001104659-15-005719:note_history:6]
The results of operations for the three and six months ended January 2, 2015, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending July 3, 2015. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three and six months ended January 2, 2015 consisted of 13 weeks and 27 weeks, respectively. The three and six months ended December 27, 2013 consisted of 13 weeks and 26 weeks, respectively.  Fiscal year 2015 will be comprised of 53 weeks and will end on July 3, 2015. The fiscal quarters ended January 2, 2015, October 3, 2014, and December 27, 2013, are also referred to herein as the “December 2014 quarter”, the “September 2014 quarter”, and the “December 2013 quarter”, respectively.

- removed (2015-01-30):
[0001104659-14-075666:note_history:7]
The results of operations for the three months ended October 3, 2014, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending July 3, 2015. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three months ended October 3, 2014 and September 27, 2013 consisted of 14 weeks and 13 weeks, respectively.  Fiscal year 2015 will be comprised of 53 weeks and will end on July 3, 2015.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-01-30):
[0001104659-15-005719:note_history:8]
As of January 2, 2015, the Company and its subsidiary, Seagate HDD Cayman, had a senior secured revolving credit facility (the "Revolving Credit Facility") of $500 million. On January 15, 2015, the Company and its subsidiary, Seagate HDD Cayman, entered into the Third Amendment to the 2011 Credit Agreement (the "Amendment") which increased the commitments available under the Revolving Credit Facility from $500 million to $700 million and also extended the maturity date on the Credit Agreement until January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Credit Agreement) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied.  The loans made under the Credit Agreement will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings and for the issuance of letters of credit up to a sub-limit of $75 million. As of January 2, 2015, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

- added (2015-01-30):
[0001104659-15-005719:note_history:9]
$600 million Aggregate Principal Amount of 6.8% Senior Notes due October 2016 (the “2016 Notes”). The interest on the 2016 Notes was payable semi-annually on April 1 and October 1 of each year. The issuer under the 2016 Notes was Seagate HDD Cayman, and the obligations under the 2016 Notes were unconditionally guaranteed by certain of the Company’s significant subsidiaries.  During the December 2014 quarter, the 2016 Notes were fully extinguished through repurchase and redemption for cash at a premium to their principal amount, plus accrued and unpaid interest.  The Company recorded a loss on the repurchase and redemption of approximately $34 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

- changed (2015-01-30):
[0001104659-15-005719:note_history:10]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2014-11-03, similarity 0.7004):
[0001104659-14-075666:note_history:10]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”).  The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2015-01-30):
[0001104659-15-005719:note_history:11]
$600 million Aggregate Principal Amount of 6.875% Senior Notes due May 2020 (the “2020 Notes”). The interest on the 2020 Notes is payable semi-annually on May 1 and November 1 of each year. The issuer under the 2020 Notes is Seagate HDD Cayman, and the obligations under the 2020 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the December 2014 quarter, the Company repurchased $30 million aggregate principal amount of its 2020 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately of $2 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.
  (was, 2014-11-03, similarity 0.9951):
[0001104659-14-075666:note_history:11]
$600 million Aggregate Principal Amount of 6.875% Senior Notes due May 2020 (the “2020 Notes”). The interest on the 2020 Notes is payable semi-annually on May 1 and November 1 of each year. The issuer under the 2020 Notes is Seagate HDD Cayman, and the obligations under the 2020 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2014 quarter, the Company repurchased $28 million aggregate principal amount of its 2020 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately of $2 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

- added (2015-01-30):
[0001104659-15-005719:note_history:12]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman, and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the December 2014 quarter, the Company repurchased $14 million aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately $2 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

- changed (2015-01-30):
[0001104659-15-005719:note_history:13]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2014-11-03, similarity 0.6979):
[0001104659-14-075666:note_history:13]
$1 billion Aggregate Principal Amount of 4.75%  Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2015-01-30):
[0001104659-15-005719:note_history:14]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year, commencing on January 1, 2015. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2014-11-03, similarity 0.6971):
[0001104659-14-075666:note_history:14]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”).  The interest on the Notes is payable in cash semiannually on January 1 and July 1 of each year, commencing on January 1, 2015. The issuer under the 2025 Notes is Seagate HDD Cayman and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- added (2015-01-30):
[0001104659-15-005719:note_history:15]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 1, 2034 (the “2034 Notes”). On December 2, 2014, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 5.75% Senior Notes due 2034 which mature on December 1, 2034. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on June 1, 2015. At any time before June 1, 2034, Seagate HDD Cayman may redeem some or all of the Notes at a "make-whole" redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points, minus accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date. At any time on or after June 1, 2034, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2015-01-30):
[0001104659-15-005719:note_history:16]
At January 2, 2015, future principal payments on long-term debt were as follows (in millions):
  (was, 2014-11-03, similarity 0.9326):
[0001104659-14-075666:note_history:16]
At October 3, 2014, future principal payments on long-term debt were as follows (in millions):

- changed (2015-01-30):
[0001104659-15-005719:note_history:17]
| Fiscal Year | Amount |
| Remainder of 2015 | $ | — |  |
| 2016 | — |  |
| 2017 | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| Thereafter | 3,134 |  |
|  | $ | 3,934 |  |
  (was, 2014-11-03, similarity 0.9926):
[0001104659-14-075666:note_history:17]
| Fiscal Year | Amount |
| Remainder of 2015 | $ | — |  |
| 2016 | — |  |
| 2017 | 331 |  |
| 2018 | — |  |
| 2019 | 800 |  |
| Thereafter | 2,678 |  |
|  | $ | 3,809 |  |

- removed (2015-01-30):
[0001104659-14-075666:note_history:18]
On January 18, 2011, the Company and its subsidiary, Seagate HDD Cayman, entered into a Credit Agreement which provided a $350 million senior secured revolving credit facility (the “Revolving Credit Facility”). On April 30, 2013, the Company and Seagate HDD Cayman entered into the Second Amendment to the Credit Agreement which increased the commitments available under the Revolving Credit Facility from $350 million to $500 million. The loans made under the Credit Agreement will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility matures in April 2018, and is available for cash borrowings and for the issuance of letters of credit up to a sub-limit of $75 million. As of October 3, 2014, no borrowings had been drawn under the Revolving Credit Facility or had been utilized for letters of credit.

- removed (2015-01-30):
[0001104659-14-075666:note_history:19]
$600 million Aggregate Principal Amount of 6.8% Senior Notes due October 2016 (the “2016 Notes”). The interest on the 2016 Notes is payable semi-annually on April 1 and October 1 of each year. The issuer under the 2016 Notes is Seagate HDD Cayman, and the obligations under the 2016 Notes are unconditionally guaranteed by certain of the Company’s significant subsidiaries.  During the September 2014 quarter, the Company repurchased $4 million aggregate principal amount of its 2016 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest.  The Company recorded a loss on the repurchase of approximately of $0.5 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

- removed (2015-01-30):
[0001104659-14-075666:note_history:20]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2014 quarter, the Company repurchased $79 million aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately of $11 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-01-30):
[0001104659-15-005719:note_history:21]
|  |  | January 2, 2015 |  | June 27, 2014 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 800 |  |  | $ | 824 |  |  | $ | 800 |  |  | $ | 820 |  |
| 6.875% Senior Notes due May 2020 |  | 476 |  |  | 501 |  |  | 534 |  |  | 578 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 174 |  |  | 251 |  |  | 284 |  |
| 4.75% Senior Notes due June 2023 |  | 1,000 |  |  | 1,050 |  |  | 1,000 |  |  | 1,009 |  |
| 4.75% Senior Notes due January 2025 |  | 1,000 |  |  | 1,032 |  |  | 1,000 |  |  | 995 |  |
| 5.75% Senior Notes due December 2034 |  | 498 |  |  | 537 |  |  | — |  |  | — |  |
| Long-term debt |  | $ | 3,932 |  |  | $ | 4,118 |  |  | $ | 3,585 |  |  | $ | 3,686 |  |
  (was, 2014-11-03, similarity 0.8213):
[0001104659-14-075666:note_history:21]
|  |  | October 3, 2014 |  | June 27, 2014 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 6.8% Senior Notes due October 2016 |  | $ | 331 |  |  | $ | 364 |  |  | $ | 335 |  |  | $ | 374 |  |
| 3.75% Senior Notes due November 2018 |  | 800 |  |  | 817 |  |  | 800 |  |  | 820 |  |
| 6.875% Senior Notes due May 2020 |  | 506 |  |  | 537 |  |  | 534 |  |  | 578 |  |
| 7.00% Senior Notes due November 2021 |  | 172 |  |  | 191 |  |  | 251 |  |  | 284 |  |
| 4.75% Senior Notes due June 2023 |  | 1,000 |  |  | 1,027 |  |  | 1,000 |  |  | 1,009 |  |
| 4.75% Senior Notes due January 2025 |  | 1,000 |  |  | 1,012 |  |  | 1,000 |  |  | 995 |  |
| Long-term debt |  | $ | 3,809 |  |  | $ | 3,948 |  |  | $ | 3,920 |  |  | $ | 4,060 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-01-30):
[0001104659-15-005719:note_history:22]
| Fiscal Year | Amount |
| Remainder of 2015 | $ | — |  |
| 2016 | — |  |
| 2017 | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| Thereafter | 3,134 |  |
|  | $ | 3,934 |  |
  (was, 2014-11-03, similarity 0.9926):
[0001104659-14-075666:note_history:22]
| Fiscal Year | Amount |
| Remainder of 2015 | $ | — |  |
| 2016 | — |  |
| 2017 | 331 |  |
| 2018 | — |  |
| 2019 | 800 |  |
| Thereafter | 2,678 |  |
|  | $ | 3,809 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2015-01-30):
[0001104659-14-075666:note_history:23]
Subsequent Events

- removed (2015-01-30):
[0001104659-14-075666:note_history:24]
On October 8, 2014, the Minnesota Supreme Court ruled that the arbitration award in favor of the Company in its case against Western Digital for the misappropriation of the Company trade secrets should be confirmed. In the arbitration award, issued on January 23, 2012, the arbitrator determined that Western Digital and its former employee had misappropriated the Company trade secrets. The arbitrator awarded the Company $525 million in compensatory damages and, after adding interest, issued a final award of approximately $630 million. Interest on the final award has been accruing at 10%.  On October 14, 2014, the Company received a partial payment from Western Digital in the amount of approximately $773 million.
