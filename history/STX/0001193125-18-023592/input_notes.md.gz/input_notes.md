# STX notes — 0001193125-18-023592


## invest:InvestmentTableTextBlock

[0001193125-18-023592:notes:1]
[same as prior period, unchanged from 0001193125-17-323042:notes:1]

[0001193125-18-023592:notes:2]
[same as prior period, unchanged from 0001193125-17-323042:notes:2]

[0001193125-18-023592:notes:3]
[same as prior period, unchanged from 0001193125-17-323042:notes:3]

[0001193125-18-023592:notes:4]
[same as prior period, unchanged from 0001193125-17-323042:notes:4]


## stx:ScheduleOfShareRepurchasesTableTextBlock

[0001193125-18-023592:notes:5]
[same as prior period, unchanged from 0001193125-17-323042:notes:5]

[0001193125-18-023592:notes:6]
[same as prior period, unchanged from 0001193125-17-323042:notes:6]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-18-023592:notes:7]
[same as prior period, unchanged from 0001193125-17-323042:notes:7]

[0001193125-18-023592:notes:8]
[same as prior period, unchanged from 0001193125-17-323042:notes:8]

[0001193125-18-023592:notes:9]
[same as prior period, unchanged from 0001193125-17-323042:notes:9]

[0001193125-18-023592:notes:10]
[same as prior period, unchanged from 0001193125-17-323042:notes:10]

[0001193125-18-023592:notes:11]
[same as prior period, unchanged from 0001193125-17-323042:notes:11]

[0001193125-18-023592:notes:12]
[same as prior period, unchanged from 0001193125-17-323042:notes:12]

[0001193125-18-023592:notes:13]
[same as prior period, unchanged from 0001193125-17-323042:notes:13]

[0001193125-18-023592:notes:14]
[same as prior period, unchanged from 0001193125-17-323042:notes:14]


## us-gaap:CommitmentsDisclosureTextBlock

[0001193125-18-023592:notes:15]
[same as prior period, unchanged from 0001193125-17-323042:notes:15]

[0001193125-18-023592:notes:16]
[same as prior period, unchanged from 0001193125-17-323042:notes:16]


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-18-023592:notes:17]
[same as prior period, unchanged from 0001193125-17-323042:notes:17]

[0001193125-18-023592:notes:18]
[same as prior period, unchanged from 0001193125-17-323042:notes:18]

[0001193125-18-023592:notes:19]
[same as prior period, unchanged from 0001193125-17-323042:notes:19]


## us-gaap:DebtDisclosureTextBlock

[0001193125-18-023592:notes:20]
Debt

[0001193125-18-023592:notes:21]
Short-Term Borrowings

[0001193125-18-023592:notes:22]
The credit agreement entered into by the Company and its subsidiary Seagate HDD Cayman on January 18, 2011 and subsequently amended (the "Revolving Credit Facility") provides the Company with a $700 million senior secured revolving credit facility. The term of the Revolving Credit Facility is through January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Revolving Credit Facility) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. The loans made under the Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing, and for the issuance of letters of credit up to a sub-limit of $75 million.

[0001193125-18-023592:notes:23]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to allow for higher net leverage levels. The Company was in compliance with the modified covenants as of September 29, 2017 and expects to be in compliance for the next 12 months.

[0001193125-18-023592:notes:24]
As of September 29, 2017, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

[0001193125-18-023592:notes:25]
Long-Term Debt

[0001193125-18-023592:notes:26]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2017 quarter, the Company repurchased $22 million aggregate principal amount of the 2018 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded an immaterial loss on the repurchase during the three months ended September 29, 2017, which is included in Other, net on the Condensed Consolidated Statements of Operations.

[0001193125-18-023592:notes:27]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-023592:notes:28]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-023592:notes:29]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”). The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-023592:notes:30]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-023592:notes:31]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-023592:notes:32]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-023592:notes:33]
At September 29, 2017, future principal payments on long-term debt were as follows (in millions):

[0001193125-18-023592:notes:34]
| Fiscal Year |  | Amount |
| Remainder of 2018 |  | $ | — |  |
| 2019 |  | 688 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| 2022 |  | 750 |  |
| Thereafter |  | 3,613 |  |
| Total |  | $ | 5,051 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-18-023592:notes:35]
[same as prior period, unchanged from 0001193125-17-323042:notes:35]

[0001193125-18-023592:notes:36]
[same as prior period, unchanged from 0001193125-17-323042:notes:36]

[0001193125-18-023592:notes:37]
[same as prior period, unchanged from 0001193125-17-323042:notes:37]

[0001193125-18-023592:notes:38]
[same as prior period, unchanged from 0001193125-17-323042:notes:38]

[0001193125-18-023592:notes:39]
[same as prior period, unchanged from 0001193125-17-323042:notes:39]

[0001193125-18-023592:notes:40]
[same as prior period, unchanged from 0001193125-17-323042:notes:40]

[0001193125-18-023592:notes:41]
[same as prior period, unchanged from 0001193125-17-323042:notes:41]

[0001193125-18-023592:notes:42]
[same as prior period, unchanged from 0001193125-17-323042:notes:42]

[0001193125-18-023592:notes:43]
[same as prior period, unchanged from 0001193125-17-323042:notes:43]

[0001193125-18-023592:notes:44]
[same as prior period, unchanged from 0001193125-17-323042:notes:44]

[0001193125-18-023592:notes:45]
[same as prior period, unchanged from 0001193125-17-323042:notes:45]

[0001193125-18-023592:notes:46]
[same as prior period, unchanged from 0001193125-17-323042:notes:46]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-18-023592:notes:47]
[same as prior period, unchanged from 0001193125-17-323042:notes:47]

[0001193125-18-023592:notes:48]
[same as prior period, unchanged from 0001193125-17-323042:notes:48]


## us-gaap:EarningsPerShareTextBlock

[0001193125-18-023592:notes:49]
[same as prior period, unchanged from 0001193125-17-323042:notes:49]

[0001193125-18-023592:notes:50]
[same as prior period, unchanged from 0001193125-17-323042:notes:50]

[0001193125-18-023592:notes:51]
[same as prior period, unchanged from 0001193125-17-323042:notes:51]

[0001193125-18-023592:notes:52]
[same as prior period, unchanged from 0001193125-17-323042:notes:52]


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001193125-18-023592:notes:53]
[same as prior period, unchanged from 0001193125-17-323042:notes:53]

[0001193125-18-023592:notes:54]
[same as prior period, unchanged from 0001193125-17-323042:notes:54]


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-18-023592:notes:55]
[same as prior period, unchanged from 0001193125-17-323042:notes:55]

[0001193125-18-023592:notes:56]
[same as prior period, unchanged from 0001193125-17-323042:notes:56]

[0001193125-18-023592:notes:57]
[same as prior period, unchanged from 0001193125-17-323042:notes:57]

[0001193125-18-023592:notes:58]
[same as prior period, unchanged from 0001193125-17-323042:notes:58]

[0001193125-18-023592:notes:59]
[same as prior period, unchanged from 0001193125-17-323042:notes:59]

[0001193125-18-023592:notes:60]
[same as prior period, unchanged from 0001193125-17-323042:notes:60]

[0001193125-18-023592:notes:61]
[same as prior period, unchanged from 0001193125-17-323042:notes:61]

[0001193125-18-023592:notes:62]
[same as prior period, unchanged from 0001193125-17-323042:notes:62]

[0001193125-18-023592:notes:63]
[same as prior period, unchanged from 0001193125-17-323042:notes:63]

[0001193125-18-023592:notes:64]
[same as prior period, unchanged from 0001193125-17-323042:notes:64]

[0001193125-18-023592:notes:65]
[same as prior period, unchanged from 0001193125-17-323042:notes:65]

[0001193125-18-023592:notes:66]
[same as prior period, unchanged from 0001193125-17-323042:notes:66]

[0001193125-18-023592:notes:67]
[same as prior period, unchanged from 0001193125-17-323042:notes:67]

[0001193125-18-023592:notes:68]
[same as prior period, unchanged from 0001193125-17-323042:notes:68]

[0001193125-18-023592:notes:69]
[same as prior period, unchanged from 0001193125-17-323042:notes:69]

[0001193125-18-023592:notes:70]
[same as prior period, unchanged from 0001193125-17-323042:notes:70]

[0001193125-18-023592:notes:71]
[same as prior period, unchanged from 0001193125-17-323042:notes:71]

[0001193125-18-023592:notes:72]
[same as prior period, unchanged from 0001193125-17-323042:notes:72]

[0001193125-18-023592:notes:73]
[same as prior period, unchanged from 0001193125-17-323042:notes:73]

[0001193125-18-023592:notes:74]
[same as prior period, unchanged from 0001193125-17-323042:notes:74]

[0001193125-18-023592:notes:75]
[same as prior period, unchanged from 0001193125-17-323042:notes:75]

[0001193125-18-023592:notes:76]
[same as prior period, unchanged from 0001193125-17-323042:notes:76]

[0001193125-18-023592:notes:77]
[same as prior period, unchanged from 0001193125-17-323042:notes:77]

[0001193125-18-023592:notes:78]
|  |  | September 29, 2017 |  | June 30, 2017 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 688 |  |  | $ | 701 |  |  | $ | 710 |  |  | $ | 726 |  |
| 4.25% Senior Notes due March 2022 |  | 748 |  |  | 746 |  |  | 748 |  |  | 765 |  |
| 4.75% Senior Notes due June 2023 |  | 951 |  |  | 963 |  |  | 951 |  |  | 987 |  |
| 4.875% Senior Notes due March 2024 |  | 497 |  |  | 493 |  |  | 497 |  |  | 511 |  |
| 4.75% Senior Notes due January 2025 |  | 975 |  |  | 949 |  |  | 975 |  |  | 984 |  |
| 4.875% Senior Notes due June 2027 |  | 695 |  |  | 659 |  |  | 695 |  |  | 698 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 459 |  |  | 489 |  |  | 488 |  |
|  |  | $ | 5,043 |  |  | $ | 4,970 |  |  | $ | 5,065 |  |  | $ | 5,159 |  |
| Less: debt issuance costs |  | (41 | ) |  | — |  |  | (44 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 5,002 |  |  | $ | 4,970 |  |  | $ | 5,021 |  |  | $ | 5,159 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-18-023592:notes:79]
[same as prior period, unchanged from 0001193125-17-323042:notes:79]

[0001193125-18-023592:notes:80]
[same as prior period, unchanged from 0001193125-17-323042:notes:80]

[0001193125-18-023592:notes:81]
[same as prior period, unchanged from 0001193125-17-323042:notes:81]

[0001193125-18-023592:notes:82]
[same as prior period, unchanged from 0001193125-17-323042:notes:82]

[0001193125-18-023592:notes:83]
[same as prior period, unchanged from 0001193125-17-323042:notes:83]

[0001193125-18-023592:notes:84]
[same as prior period, unchanged from 0001193125-17-323042:notes:84]

[0001193125-18-023592:notes:85]
[same as prior period, unchanged from 0001193125-17-323042:notes:85]

[0001193125-18-023592:notes:86]
[same as prior period, unchanged from 0001193125-17-323042:notes:86]

[0001193125-18-023592:notes:87]
[same as prior period, unchanged from 0001193125-17-323042:notes:87]

[0001193125-18-023592:notes:88]
[same as prior period, unchanged from 0001193125-17-323042:notes:88]

[0001193125-18-023592:notes:89]
[same as prior period, unchanged from 0001193125-17-323042:notes:89]

[0001193125-18-023592:notes:90]
[same as prior period, unchanged from 0001193125-17-323042:notes:90]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-18-023592:notes:91]
[same as prior period, unchanged from 0001193125-17-323042:notes:91]

[0001193125-18-023592:notes:92]
[same as prior period, unchanged from 0001193125-17-323042:notes:92]

[0001193125-18-023592:notes:93]
[same as prior period, unchanged from 0001193125-17-323042:notes:93]

[0001193125-18-023592:notes:94]
[same as prior period, unchanged from 0001193125-17-323042:notes:94]

[0001193125-18-023592:notes:95]
[same as prior period, unchanged from 0001193125-17-323042:notes:95]

[0001193125-18-023592:notes:96]
[same as prior period, unchanged from 0001193125-17-323042:notes:96]


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-18-023592:notes:97]
[same as prior period, unchanged from 0001193125-17-323042:notes:97]

[0001193125-18-023592:notes:98]
[same as prior period, unchanged from 0001193125-17-323042:notes:98]


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001193125-18-023592:notes:99]
Legal, Environmental and Other Contingencies

[0001193125-18-023592:notes:100]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001193125-18-023592:notes:101]
Intellectual Property Litigation

[0001193125-18-023592:notes:102]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al. On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “‘635 patent”) and U.S. Patent No. 5,638,267 (the “‘267 patent”), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe U.S. Patent No. 6,314,473 (the “‘473 patent”). The district court ruled in 2010 that the ‘267 patent was out of the case.

[0001193125-18-023592:notes:103]
On August 16, 2011, the district court granted in part and denied in part the Company’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-18-023592:notes:104]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al. On June 5, 2013, Enova Technology Corporation (“Enova”) filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995 (the “‘995 patent”), “Cryptographic Device,” and U.S. Patent No. 7,900,057 (the “‘057 patent”), “Cryptographic Serial ATA Apparatus and Method.” The Company believes the claims are without merit and intends to vigorously defend this case. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the ‘995 and ‘057 patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ‘057 patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 patent are held unpatentable. Enova appealed PTAB’s decisions on the ‘995 patent and the ‘057 patent to the U.S. Court of Appeals for the Federal Circuit. On March 20, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the ‘995 patent. On September 6, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the ‘057 patent. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-18-023592:notes:105]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017.  No trial date has been set. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-18-023592:notes:106]
Environmental Matters

[0001193125-18-023592:notes:107]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001193125-18-023592:notes:108]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001193125-18-023592:notes:109]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001193125-18-023592:notes:110]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001193125-18-023592:notes:111]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001193125-18-023592:notes:112]
Other Matters

[0001193125-18-023592:notes:113]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-18-023592:notes:114]
Recently Issued Accounting Pronouncements

[0001193125-18-023592:notes:115]
In May 2014, August 2015, April 2016, May 2016 and December 2016, the Financial Accounting Standards Board (“FASB”) issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, ASU 2016-12 (ASC Topic 606) Revenue from Contracts with Customers, Narrow-Scope Improvements and Practical Expedients, and ASU 2016-20 (ASC Topic 606) Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company is required to adopt the guidance in the first quarter of fiscal 2019. This standard may be applied retrospectively to all prior periods presented, or retrospectively with a cumulative adjustment to retained earnings in the year of adoption (“modified retrospective transition approach”). Based on its assessment, the Company plans to adopt the new revenue standard in the first quarter of fiscal 2019, utilizing the modified retrospective method of transition. While management has not yet completed its assessment of the impact of adopting this new standard on the Company’s consolidated financial statements, the Company expects the adoption of the new standard will result in the recognition of revenues generally upon shipment (sell-in basis) for sales of products to certain direct retail customers and customers in certain indirect retail channels which are currently being recognized on a sell-through basis. Accordingly, the Company will need to estimate variable consideration (e.g. rebates) related to customer incentives on these arrangements. These changes are not expected to have a material impact on the Company’s condensed consolidated financial statements.

[0001193125-18-023592:notes:116]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments—Overall Recognition and Measurement of Financial Assets and Financial Liabilities. The amendments in this ASU require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted for only certain portions of the ASU. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-18-023592:notes:117]
In February 2016, the FASB issued ASU 2016-02 (ASC Topic 842), Leases. The ASU amends a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The Company is required to adopt the guidance in the first quarter of fiscal 2020. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-18-023592:notes:118]
In January 2017, the FASB issued ASU 2017-01 (ASC Topic 805), Business Combination: Clarifying the Definition of a Business. The amendments in this ASU change the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-18-023592:notes:119]
In May 2017, the FASB issued ASU 2017-09 (ASC Topic 718), Stock Compensation: Scope of Modification Accounting. The amendments in this ASU provide guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-18-023592:notes:120]
Recently Adopted Accounting Pronouncements

[0001193125-18-023592:notes:121]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. This ASU became effective and was adopted by the Company in the September 2017 quarter on a prospective basis. The adoption of this guidance had no material impact on the Company’s condensed consolidated financial statements and disclosures.

[0001193125-18-023592:notes:122]
In March 2016, the FASB issued ASU 2016-09 (ASC Topic 718), Stock Compensation—Improvements to Employee Share-Based Payment Accounting. The amendments in this ASU are intended to simplify several areas of accounting for share-based compensation arrangements, including the income tax consequences, classification on the consolidated statement of cash flows and treatment of forfeitures. This ASU became effective and was adopted by the Company in the September 2017 quarter. Upon adoption, excess tax benefits or deficiencies from share-based award activity are reflected in the condensed consolidated statements of operations as a component of the provision for income taxes, whereas they previously were recognized in the Shareholder's equity in the condensed consolidated balance sheets. The Company also elected to continue to account for share-based compensation expense net of estimated forfeitures. The adoption of this ASU resulted in an increase in deferred tax assets relating to net operating losses of approximately $0.6 billion, offset by an equivalent increase in the valuation allowance with no impact to retained earnings. The adoption of this guidance had no material impact on the Company’s condensed consolidated financial statements and disclosures.

[0001193125-18-023592:notes:123]
In October 2016, the FASB issued ASU 2016-16 (ASC Topic 740), Income Taxes: Intra-Entity Transfers of Assets Other Than Inventory. The amendments in this ASU require the recognition of the income tax consequences for intra-entity transfers of assets other than inventory when the transfer occurs. The Company elected to adopt this ASU in the September 2017 quarter on a modified retrospective basis with no material impact on the Company's condensed consolidated financial statements and disclosures.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001193125-18-023592:notes:124]
[same as prior period, unchanged from 0001193125-17-323042:notes:124]

[0001193125-18-023592:notes:125]
[same as prior period, unchanged from 0001193125-17-323042:notes:125]

[0001193125-18-023592:notes:126]
[same as prior period, unchanged from 0001193125-17-323042:notes:126]

[0001193125-18-023592:notes:127]
[same as prior period, unchanged from 0001193125-17-323042:notes:127]

[0001193125-18-023592:notes:128]
[same as prior period, unchanged from 0001193125-17-323042:notes:128]

[0001193125-18-023592:notes:129]
[same as prior period, unchanged from 0001193125-17-323042:notes:129]

[0001193125-18-023592:notes:130]
[same as prior period, unchanged from 0001193125-17-323042:notes:130]

[0001193125-18-023592:notes:131]
[same as prior period, unchanged from 0001193125-17-323042:notes:131]

[0001193125-18-023592:notes:132]
[same as prior period, unchanged from 0001193125-17-323042:notes:132]

[0001193125-18-023592:notes:133]
[same as prior period, unchanged from 0001193125-17-323042:notes:133]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-18-023592:notes:134]
[same as prior period, unchanged from 0001193125-17-323042:notes:134]

[0001193125-18-023592:notes:135]
[same as prior period, unchanged from 0001193125-17-323042:notes:135]

[0001193125-18-023592:notes:136]
[same as prior period, unchanged from 0001193125-17-323042:notes:136]

[0001193125-18-023592:notes:137]
[same as prior period, unchanged from 0001193125-17-323042:notes:137]

[0001193125-18-023592:notes:138]
[same as prior period, unchanged from 0001193125-17-323042:notes:138]

[0001193125-18-023592:notes:139]
[same as prior period, unchanged from 0001193125-17-323042:notes:139]

[0001193125-18-023592:notes:140]
[same as prior period, unchanged from 0001193125-17-323042:notes:140]

[0001193125-18-023592:notes:141]
[same as prior period, unchanged from 0001193125-17-323042:notes:141]

[0001193125-18-023592:notes:142]
[same as prior period, unchanged from 0001193125-17-323042:notes:142]

[0001193125-18-023592:notes:143]
[same as prior period, unchanged from 0001193125-17-323042:notes:143]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-18-023592:notes:144]
[same as prior period, unchanged from 0001193125-17-323042:notes:144]

[0001193125-18-023592:notes:145]
[same as prior period, unchanged from 0001193125-17-323042:notes:145]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-18-023592:notes:146]
[same as prior period, unchanged from 0001193125-17-323042:notes:146]

[0001193125-18-023592:notes:147]
[same as prior period, unchanged from 0001193125-17-323042:notes:147]

[0001193125-18-023592:notes:148]
[same as prior period, unchanged from 0001193125-17-323042:notes:148]

[0001193125-18-023592:notes:149]
[same as prior period, unchanged from 0001193125-17-323042:notes:149]

[0001193125-18-023592:notes:150]
[same as prior period, unchanged from 0001193125-17-323042:notes:150]

[0001193125-18-023592:notes:151]
[same as prior period, unchanged from 0001193125-17-323042:notes:151]

[0001193125-18-023592:notes:152]
[same as prior period, unchanged from 0001193125-17-323042:notes:152]


## us-gaap:ScheduleOfAccountsPayableAndAccruedLiabilitiesTableTextBlock

[0001193125-18-023592:notes:153]
[same as prior period, unchanged from 0001193125-17-323042:notes:153]

[0001193125-18-023592:notes:154]
[same as prior period, unchanged from 0001193125-17-323042:notes:154]


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-18-023592:notes:155]
[same as prior period, unchanged from 0001193125-17-323042:notes:155]

[0001193125-18-023592:notes:156]
[same as prior period, unchanged from 0001193125-17-323042:notes:156]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-18-023592:notes:157]
[same as prior period, unchanged from 0001193125-17-323042:notes:157]

[0001193125-18-023592:notes:158]
[same as prior period, unchanged from 0001193125-17-323042:notes:158]


## us-gaap:ScheduleOfRestrictedCashAndCashEquivalentsTextBlock

[0001193125-18-023592:notes:159]
[same as prior period, unchanged from 0001193125-17-323042:notes:159]

[0001193125-18-023592:notes:160]
[same as prior period, unchanged from 0001193125-17-323042:notes:160]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-18-023592:notes:161]
[same as prior period, unchanged from 0001193125-17-323042:notes:161]

[0001193125-18-023592:notes:162]
[same as prior period, unchanged from 0001193125-17-323042:notes:162]

[0001193125-18-023592:notes:163]
[same as prior period, unchanged from 0001193125-17-323042:notes:163]

[0001193125-18-023592:notes:164]
[same as prior period, unchanged from 0001193125-17-323042:notes:164]

[0001193125-18-023592:notes:165]
[same as prior period, unchanged from 0001193125-17-323042:notes:165]

[0001193125-18-023592:notes:166]
[same as prior period, unchanged from 0001193125-17-323042:notes:166]

[0001193125-18-023592:notes:167]
[same as prior period, unchanged from 0001193125-17-323042:notes:167]

[0001193125-18-023592:notes:168]
[same as prior period, unchanged from 0001193125-17-323042:notes:168]

[0001193125-18-023592:notes:169]
[same as prior period, unchanged from 0001193125-17-323042:notes:169]

[0001193125-18-023592:notes:170]
[same as prior period, unchanged from 0001193125-17-323042:notes:170]


## us-gaap:SubsequentEventsTextBlock

[0001193125-18-023592:notes:171]
Subsequent Events

[0001193125-18-023592:notes:172]
Dividend Declared

[0001193125-18-023592:notes:173]
On October 23, 2017, the Company’s Board of Directors approved and declared a quarterly cash dividend of $0.63 per share, which will be payable on January 3, 2018 to shareholders of record as of the close of business on December 20, 2017.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-18-023592:notes:174]
[same as prior period, unchanged from 0001193125-17-323042:notes:174]

[0001193125-18-023592:notes:175]
[same as prior period, unchanged from 0001193125-17-323042:notes:175]

[0001193125-18-023592:notes:176]
[same as prior period, unchanged from 0001193125-17-323042:notes:176]

[0001193125-18-023592:notes:177]
[same as prior period, unchanged from 0001193125-17-323042:notes:177]

[0001193125-18-023592:notes:178]
[same as prior period, unchanged from 0001193125-17-323042:notes:178]

[0001193125-18-023592:notes:179]
[same as prior period, unchanged from 0001193125-17-323042:notes:179]

[0001193125-18-023592:notes:180]
[same as prior period, unchanged from 0001193125-17-323042:notes:180]

[0001193125-18-023592:notes:181]
[same as prior period, unchanged from 0001193125-17-323042:notes:181]

[0001193125-18-023592:notes:182]
[same as prior period, unchanged from 0001193125-17-323042:notes:182]

[0001193125-18-023592:notes:183]
[same as prior period, unchanged from 0001193125-17-323042:notes:183]

[0001193125-18-023592:notes:184]
[same as prior period, unchanged from 0001193125-17-323042:notes:184]
