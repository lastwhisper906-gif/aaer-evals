# STX MD&A — 0001193125-18-023592


## mdna

[0001193125-18-023592:mdna:1]
[same as prior period, unchanged from 0001193125-17-323042:mdna:1]

[0001193125-18-023592:mdna:2]
The following is a discussion of the financial condition, changes in financial condition, and results of operations for our fiscal quarters
ended December 29, 2017, September 29, 2017 and December 30, 2016, referred to herein as the “December 2017 quarter,” the “September 2017 quarter,” and the “December 2016 quarter,” respectively. We
operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The December 2017, September 2017 and December 2016 quarters were all 13 weeks.

[0001193125-18-023592:mdna:3]
You should read this discussion in conjunction with financial information and related notes included elsewhere in this report. Unless the
context indicates otherwise, as used herein, the terms “we,” “us,” “Seagate,” the “Company” and “our” refer to Seagate Technology plc, an Irish public limited company, and its subsidiaries.
References to “$” are to United States dollars.

[0001193125-18-023592:mdna:4]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is provided in addition
to the accompanying condensed consolidated financial statements and notes to assist readers in understanding our results of operations, financial condition, and cash flows. MD&A is organized as follows:

[0001193125-18-023592:mdna:5]
[same as prior period, unchanged from 0001193125-17-323042:mdna:5]

[0001193125-18-023592:mdna:6]
|  | • |  | Overview of the December 2017 Quarter. Highlights of events in the December 2017 quarter that impacted our financial position. |

[0001193125-18-023592:mdna:7]
|  | • |  | Results of Operations. An analysis of our financial results comparing the December 2017 quarter to the September 2017 quarter and the December 2016 quarter. |

[0001193125-18-023592:mdna:8]
[same as prior period, unchanged from 0001193125-17-323042:mdna:8]

[0001193125-18-023592:mdna:9]
|  | • |  | Contractual Obligations and Commitments. Overview of contractual obligations and contingent liabilities and commitments outstanding as of December 29, 2017. |

[0001193125-18-023592:mdna:10]
[same as prior period, unchanged from 0001193125-17-323042:mdna:10]

[0001193125-18-023592:mdna:11]
[same as prior period, unchanged from 0001193125-17-323042:mdna:11]

[0001193125-18-023592:mdna:12]
We are a leading provider of
data storage technology and solutions. Our principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, we produce a broad range of data storage products including solid state drives
(“SSD”) and their related controllers, solid state hybrid drives (“SSHD”) and storage subsystems.

[0001193125-18-023592:mdna:13]
Hard disk drives
are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness.
Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data with most SSDs using NAND-based flash memory. In addition to HDDs and SSDs, SSHDs combine the features of
SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed data.

[0001193125-18-023592:mdna:14]
Our products are designed for mission critical and nearline applications in enterprise servers and storage systems; edge compute / client
compute applications, where our products are designed primarily for desktop and mobile computing; and edge non-compute / client non-compute applications, where
our products are designed for a wide variety of end user devices such as portable external storage systems, surveillance systems, network-attached storage (“NAS”), digital video recorders (“DVRs”) and gaming consoles.

[0001193125-18-023592:mdna:15]
Our cloud systems and solutions extend innovation from the device into the information infrastructure, onsite and in the cloud. Our portfolio
includes modular original equipment manufacturer (“OEM”) storage systems and scale-out storage servers.

[0001193125-18-023592:mdna:16]
[same as prior period, unchanged from 0001193125-17-323042:mdna:22]

[0001193125-18-023592:mdna:17]
Overview of the December 2017 Quarter

[0001193125-18-023592:mdna:18]
During the December 2017 quarter, we shipped 88 exabytes of HDD storage capacity, generating revenue of approximately $2.9 billion and
gross margin of 30%. Our operating cash flow was $850 million. We repurchased 5 million of our ordinary shares for $195 million, paid $182 million in dividends, as well as paid $130 million for the repurchase of certain of
our outstanding debt.

[0001193125-18-023592:mdna:19]
[same as prior period, unchanged from 0001193125-17-323042:mdna:18]

[0001193125-18-023592:mdna:20]
We list in the tables below summarized information from our Condensed Consolidated Statements of Operations by dollars and as a percentage of
revenue:

[0001193125-18-023592:mdna:21]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 29,2017 |  | September 29,2017 |  | December 30,2016 |  | December 29,2017 |  | December 30,2016 |
| Revenue |  | $ | 2,914 |  |  | $ | 2,632 |  |  | $ | 2,894 |  |  | $ | 5,546 |  |  | $ | 5,691 |  |
| Cost of revenue |  |  | 2,037 |  |  |  | 1,896 |  |  |  | 2,003 |  |  |  | 3,933 |  |  |  | 3,999 |  |
| Gross margin |  |  | 877 |  |  |  | 736 |  |  |  | 891 |  |  |  | 1,613 |  |  |  | 1,692 |  |
| Product development |  |  | 250 |  |  |  | 263 |  |  |  | 305 |  |  |  | 513 |  |  |  | 620 |  |
| Marketing and administrative |  |  | 142 |  |  |  | 145 |  |  |  | 155 |  |  |  | 287 |  |  |  | 308 |  |
| Amortization of intangibles |  |  | 19 |  |  |  | 22 |  |  |  | 28 |  |  |  | 41 |  |  |  | 57 |  |
| Restructuring and other, net |  |  | 33 |  |  |  | 51 |  |  |  | 33 |  |  |  | 84 |  |  |  | 115 |  |
| Income from operations |  |  | 433 |  |  |  | 255 |  |  |  | 370 |  |  |  | 688 |  |  |  | 592 |  |
| Other expense, net |  |  | (62 | ) |  |  | (67 | ) |  |  | (60 | ) |  |  | (129 | ) |  |  | (109 | ) |
| Income before income taxes |  |  | 371 |  |  |  | 188 |  |  |  | 310 |  |  |  | 559 |  |  |  | 483 |  |
| Provision for income taxes |  |  | 212 |  |  |  | 7 |  |  |  | 13 |  |  |  | 219 |  |  |  | 19 |  |
| Net income |  | $ | 159 |  |  | $ | 181 |  |  | $ | 297 |  |  | $ | 340 |  |  | $ | 464 |  |
|  |  | For the Three Months Ended |  | For the Six Months Ended |
|  |  | December 29,2017 |  | September 29,2017 |  | December 30,2016 |  | December 29,2017 |  | December 30,2016 |
| Revenue |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |
| Cost of revenue |  |  | 70 |  |  |  | 72 |  |  |  | 69 |  |  |  | 71 |  |  |  | 70 |  |
| Gross margin |  |  | 30 |  |  |  | 28 |  |  |  | 31 |  |  |  | 29 |  |  |  | 30 |  |
| Product development |  |  | 9 |  |  |  | 10 |  |  |  | 11 |  |  |  | 9 |  |  |  | 11 |  |
| Marketing and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |  | 6 |  |
| Amortization of intangibles |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |
| Restructuring and other, net |  |  | 1 |  |  |  | 2 |  |  |  | 1 |  |  |  | 2 |  |  |  | 2 |  |
| Income from operations |  |  | 15 |  |  |  | 10 |  |  |  | 13 |  |  |  | 12 |  |  |  | 10 |  |
| Other expense, net |  |  | (3 | ) |  |  | (3 | ) |  |  | (2 | ) |  |  | (2 | ) |  |  | (2 | ) |
| Income before income taxes |  |  | 12 |  |  |  | 7 |  |  |  | 11 |  |  |  | 10 |  |  |  | 8 |  |
| Provision for income taxes |  |  | 7 |  |  |  | — |  |  |  | 1 |  |  |  | 4 |  |  |  | — |  |
| Net income |  |  | 5 | % |  |  | 7 | % |  |  | 10 | % |  |  | 6 | % |  |  | 8 | % |

[0001193125-18-023592:mdna:22]
[same as prior period, unchanged from 0001193125-17-323042:mdna:35]

[0001193125-18-023592:mdna:23]
[same as prior period, unchanged from 0001193125-17-323042:mdna:23]

[0001193125-18-023592:mdna:24]
The following table summarizes HDD information regarding average drive selling prices (“ASPs”), exabytes shipped, and revenues by
channel and geography:

[0001193125-18-023592:mdna:25]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
|  |  | December 29,2017 |  | September 29,2017 |  | December 30,2016 |  | December 29,2017 |  | December 30,2016 |
| ASPs (per unit) |  | $ | 68 |  |  | $ | 64 |  |  | $ | 67 |  |  | $ | 66 |  |  | $ | 67 |  |
| Exabytes Shipped |  |  | 88 |  |  |  | 70 |  |  |  | 68 |  |  |  | 158 |  |  |  | 135 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  |  | 67 | % |  |  | 67 | % |  |  | 66 | % |  |  | 67 | % |  |  | 68 | % |
| Distributors |  |  | 17 | % |  |  | 17 | % |  |  | 18 | % |  |  | 17 | % |  |  | 18 | % |
| Retailers |  |  | 16 | % |  |  | 16 | % |  |  | 16 | % |  |  | 16 | % |  |  | 14 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  |  | 26 | % |  |  | 26 | % |  |  | 30 | % |  |  | 26 | % |  |  | 32 | % |
| EMEA |  |  | 19 | % |  |  | 18 | % |  |  | 19 | % |  |  | 18 | % |  |  | 17 | % |
| Asia Pacific |  |  | 55 | % |  |  | 56 | % |  |  | 51 | % |  |  | 56 | % |  |  | 51 | % |

[0001193125-18-023592:mdna:26]
Revenue in the December 2017 quarter increased by $282 million from the September 2017 quarter as a
result of an increase in exabytes shipped driven primarily by higher seasonal demand in the consumer market and higher demand for the Company’s high capacity HDD product portfolio, partially offset by price erosion.

[0001193125-18-023592:mdna:27]
Compared to the December 2016 quarter, revenue in the December 2017 quarter increased modestly primarily due to increase in exabytes shipped,
offset by price erosion.

[0001193125-18-023592:mdna:28]
Revenue for the six months ended December 2017 quarter decreased by $145 million from the six months ended
December 2016 quarter as a result of price erosion, partially offset by an improved product mix.

[0001193125-18-023592:mdna:29]
We maintain various sales programs such
as channel rebates and price masking. Sales programs were approximately 12%, 11% and 11% of gross drive revenue for the December 2017 quarter, September 2017 quarter and December 2016 quarter, respectively. Adjustments to revenues due to under or
over accruals for sales programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001193125-18-023592:mdna:30]
[same as prior period, unchanged from 0001193125-17-323042:mdna:29]

[0001193125-18-023592:mdna:31]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 29,2017 |  | September 29,2017 |  | December 30,2016 |  | December 29,2017 |  | December 30,2016 |
| Cost of revenue |  | $ | 2,037 |  |  | $ | 1,896 |  |  | $ | 2,003 |  |  | $ | 3,933 |  |  | $ | 3,999 |  |
| Gross margin |  |  | 877 |  |  |  | 736 |  |  |  | 891 |  |  |  | 1,613 |  |  |  | 1,692 |  |
| Gross margin percentage |  |  | 30 | % |  |  | 28 | % |  |  | 31 | % |  |  | 29 | % |  |  | 30 | % |

[0001193125-18-023592:mdna:32]
Gross margin as a percentage of revenue for the December 2017 quarter increased by 200 basis points from the
September 2017 quarter primarily driven by favorable product mix and improved absorption of factories due to higher demand for the Company’s high capacity HDD product portfolio, partially offset by price erosion.

[0001193125-18-023592:mdna:33]
Compared to the corresponding three and six months ended December 2016 quarter, gross margin as a percentage of revenue for the three and six
months ended December 2017 quarter decreased by 100 basis points in both periods, primarily driven by price erosion, partially offset by favorable product mix and improved factory utilization resulting from cost savings due to our workforce
reductions and manufacturing consolidation activities.

[0001193125-18-023592:mdna:34]
In the December 2017 quarter, total warranty cost was within the historical range
of 1% to 1.5% of revenue and included a favorable change in estimates of prior warranty accruals of less than 0.2% of revenue. Warranty cost related to new shipments was 1.4%, 1.3%, and 1.2% of revenue for each of the December 2017, September 2017
and December 2016 quarters, respectively.

[0001193125-18-023592:mdna:35]
30

[0001193125-18-023592:mdna:36]
[same as prior period, unchanged from 0001193125-17-323042:mdna:33]

[0001193125-18-023592:mdna:37]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (Dollars in millions) |  | December 29,2017 |  |  | September 29,2017 |  |  | December 30,2016 |  |  | December 29,2017 |  |  | December 30,2016 |  |
| Product development |  | $ | 250 |  |  | $ | 263 |  |  | $ | 305 |  |  | $ | 513 |  |  | $ | 620 |  |
| Marketing and administrative |  |  | 142 |  |  |  | 145 |  |  |  | 155 |  |  |  | 287 |  |  |  | 308 |  |
| Amortization of intangibles |  |  | 19 |  |  |  | 22 |  |  |  | 28 |  |  |  | 41 |  |  |  | 57 |  |
| Restructuring and other, net |  |  | 33 |  |  |  | 51 |  |  |  | 33 |  |  |  | 84 |  |  |  | 115 |  |
| Operating expenses |  | $ | 444 |  |  | $ | 481 |  |  | $ | 521 |  |  | $ | 925 |  |  | $ | 1,100 |  |

[0001193125-18-023592:mdna:38]
Product development expense. Product development expense for the December 2017 quarter decreased
by $13 million from the September 2017 quarter primarily due to a $4 million decrease in salaries and employee benefits as a result of the restructuring of our workforce in prior periods, a $13 million decrease due to related
operational efficiencies, partially offset by an increase in variable compensation expense.

[0001193125-18-023592:mdna:39]
Compared to the December 2016 quarter,
product development expense decreased by $55 million primarily due to a $17 million decrease in salaries and employee benefits as a result of the restructuring of our workforce in prior periods, a $25 million decrease due to related
operational efficiencies and a $13 million decrease in variable compensation and share-based compensation expenses.

[0001193125-18-023592:mdna:40]
Compared to
corresponding six months ended December 2016 quarter, product development expense decreased by $107 million primarily due to a $47 million decrease in salaries and employee benefits as a result of the restructuring of our workforce in
prior periods, a $36 million decrease due to related operational efficiencies and a $24 million decrease in variable compensation and share-based compensation expenses.

[0001193125-18-023592:mdna:41]
Marketing and administrative expense. Marketing and administrative expense for the December 2017 quarter decreased by
$3 million from the September 2017 quarter primarily due to a decrease in salaries and related benefits as a result of the restructuring of our workforce in prior periods, partially offset by an increase in variable compensation expense.

[0001193125-18-023592:mdna:42]
Compared to the December 2016 quarter, Marketing and administrative expense decreased by $13 million, primarily due to a $9 million
decrease in salaries and related benefits as a result of the restructuring of our workforce in prior periods, and a $4 million decrease in variable compensation expense.

[0001193125-18-023592:mdna:43]
Compared to corresponding six months ended December 2016 quarter, marketing and administrative expense decreased by $21 million primarily
due to a $13 million decrease in salaries and related benefits as a result of the restructuring of our workforce in prior periods and a $8 million decrease in variable compensation expense.

[0001193125-18-023592:mdna:44]
Amortization of intangibles. Amortization of intangibles for the three and six months ended December 2017 quarter decreased by
$3 million, $9 million and $16 million respectively, from the three months ended September 2017 quarter and the three and six months ended December 2016 quarter due to certain intangible assets reaching the end of their useful life.

[0001193125-18-023592:mdna:45]
Restructuring and other, net. Restructuring and other, net for the three and six months ended December 2017 quarter was comprised
of restructuring charges to reduce our global workforce by 500 and 1100 employees, respectively.

[0001193125-18-023592:mdna:46]
Restructuring and other, net for the
three and six months ended December 2016 quarter was primarily comprised of restructuring charges to reduce our global workforce by 6,500 employees. Each of these restructuring activities have reduced our workforce as we continue to consolidate our
global footprint across Asia, EMEA and the Americas. See “Part I, Item 1. Financial Statements—Note 7. Restructuring and Exit Costs” for more details.

[0001193125-18-023592:mdna:47]
Other Expense, Net

[0001193125-18-023592:mdna:48]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (Dollars in millions) |  | December 29,2017 |  |  | September 29,2017 |  |  | December 30,2016 |  |  | December 29,2017 |  |  | December 30,2016 |  |
| Other expense, net |  | $ | (62 | ) |  | $ | (67 | ) |  | $ | (60 | ) |  | $ | (129 | ) |  | $ | (109 | ) |

[0001193125-18-023592:mdna:49]
Other expense, net decreased by $5 million from the September 2017 quarter primarily due to a favorable
$9 million change in foreign currency exchange rates, partially offset by a $2 million loss on repurchase of debt in the December 2017 quarter.

[0001193125-18-023592:mdna:50]
Compared to December 2016 quarter, Other expense, net increased by $2 million in the December 2017 quarter primarily due to a
$16 million of unfavorable change in foreign currency exchange rates and a $10 million increase in interest expense on the issuance of $750 million of 4.25% Senior Notes due 2022 and $500 million of 4.875% Senior Notes due 2024
in the quarter ended March 31, 2017, offset by the absence of a $25 million charge related to the impairment of a strategic investment in the December 2016 quarter.

[0001193125-18-023592:mdna:51]
31

[0001193125-18-023592:mdna:52]
Other expense, net for the six months ended December 2017 quarter increased by $20 million
from the corresponding period in the prior year, primarily due to a $22 million increase in interest expense on the issuance of $750 million of 4.25% Senior Notes due 2022 and $500 million of 4.875% Senior Notes due 2024, a
$26 million unfavorable change in foreign currency exchange rates, offset by the absence of a $25 million charge related to the impairment of a strategic investment in the December 2016 quarter.

[0001193125-18-023592:mdna:53]
[same as prior period, unchanged from 0001193125-17-323042:mdna:46]

[0001193125-18-023592:mdna:54]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (Dollars in millions) |  | December 29,2017 |  |  | September 29,2017 |  |  | December 30,2016 |  |  | December 29,2017 |  |  | December 30,2016 |  |
| Provision for income taxes |  | $ | 212 |  |  | $ | 7 |  |  | $ | 13 |  |  | $ | 219 |  |  | $ | 19 |  |

[0001193125-18-023592:mdna:55]
We recorded income tax provisions of $212 million and $219 million in the three and six months ended
December 2017 quarter, respectively. The income tax provision for the three and six months ended December 2017 quarter included approximately $197 million of net discrete tax expense, primarily associated with the revaluation of U.S.
deferred tax assets as a result of the enactment of the Tax Cuts and Jobs Act on December 22, 2017, partially offset by the recognition of previously unrecognized tax benefits associated with the expiration of certain statutes of limitation.

[0001193125-18-023592:mdna:56]
Our income tax provision recorded for the three and six months ended December 2017 quarter differed from the provision for income taxes
that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions
that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a reduction in the net U.S. deferred tax assets associated with revaluation to a lower U.S. tax rate.

[0001193125-18-023592:mdna:57]
During the six months ended December 2017 quarter, our unrecognized tax benefits excluding interest and penalties increased by approximately
$1 million to $75 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $75 million at December 29, 2017, subject to certain future changes in valuation allowance. During the twelve
months beginning December 30, 2017, we expect that our unrecognized tax benefits could be reduced by approximately $2 million, primarily as a result of the expiration of certain statutes of limitation.

[0001193125-18-023592:mdna:58]
Our income tax provision recorded for the six months ended December 2016 quarter included approximately $4 million of net discrete tax
benefits, primarily associated with the release of tax reserves associated with the expiration of certain statutes of limitation.

[0001193125-18-023592:mdna:59]
Our
income tax provision recorded for the three and six months ended December 2016 quarter differed from the provision from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to
the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and
(ii) a decrease in valuation allowance for certain deferred tax assets.

[0001193125-18-023592:mdna:60]
On December 22, 2017, the Tax Cuts and Jobs Act (the
“Act”) was enacted into law in the United States. The Act significantly revises U.S. corporate income tax law by, among other things, lowering corporate income tax rates from 35% to 21%, implementing a territorial tax system and imposing a
tax on deemed repatriated earnings of non-U.S. subsidiaries. The Act’s new international rules, including the Global Intangible Low-Taxed Income, the Foreign
Derived Intangible Income and the Base Erosion Anti-Avoidance Tax, are not expected to have a material impact on our financial statements. However, these assessments are based on preliminary review and analysis of the Act and are subject to change
as we continue to evaluate these highly complex rules as additional interpretive guidance is issued.

[0001193125-18-023592:mdna:61]
Pursuant to SEC Staff Accounting
Bulletin (SAB) 118 (regarding the application of ASC 740 associated with the enactment of the Act), we recorded a provisional tax expense of approximately $208 million for the three months ended December 29, 2017 to re-measure our U.S. deferred tax assets at the newly enacted 21% tax rate. The tax expense is provisional because we continue to evaluate the impact of various domestic and international provisions of the Act as
well as the impact of additional guidance that may be provided. This provisional tax expense increased our effective tax rate for the three months ended December 29, 2017 to approximately 56%. Many of the other U.S. tax changes are not expected
to impact our tax expense in the short-term due to our large net operating loss and tax credit carryovers.

[0001193125-18-023592:mdna:62]
32

[0001193125-18-023592:mdna:63]
[same as prior period, unchanged from 0001193125-17-323042:mdna:54]

[0001193125-18-023592:mdna:64]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital
resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist primarily of money market funds, time deposits and certificates of
deposit. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have
restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash have been and will continue to be sufficient to meet our cash needs for the next 12 months. We are not
aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term investments.

[0001193125-18-023592:mdna:65]
Cash and Cash
Equivalents and Short-term Investments

[0001193125-18-023592:mdna:66]
| (Dollars in millions) |  | December 29,2017 |  |  | June 30,2017 |  |  | Change |  |
| Cash and cash equivalents |  | $ | 2,556 |  |  | $ | 2,539 |  |  | $ | 17 |  |

[0001193125-18-023592:mdna:67]
Our cash and cash equivalents increased from June 30, 2017 as a result of an increase in the net cash
provided by operating activities, partially offset by net cash outflows for dividends paid to our shareholders, repurchase of our ordinary shares, capital expenditures, and repayments of long-term debt.

[0001193125-18-023592:mdna:68]
[same as prior period, unchanged from 0001193125-17-323042:mdna:59]

[0001193125-18-023592:mdna:69]
Cash provided by operating activities for the six months ended December 29, 2017 of $1,087 million includes the effects of net income
adjusted for non-cash items including depreciation, amortization, deferred income taxes primarily due to the remeasurement of our U.S. deferred tax assets at the lower corporate tax rate, share-based
compensation and:

[0001193125-18-023592:mdna:70]
|  | • |  | a decrease of $145 million in accounts receivable, primarily due to improved in-quarter linearity of shipments, partially offset by higher revenue; |

[0001193125-18-023592:mdna:71]
|  | • |  | an increase of $59 million in accounts payable, primarily due to timing of material purchases; |

[0001193125-18-023592:mdna:72]
|  | • |  | an increase of $32 million in inventory, primarily due to an increase in units built; |

[0001193125-18-023592:mdna:73]
|  | • |  | a decrease of $54 million in accrued employee compensation, primarily due to cash paid to our employees as part of our variable compensation plans in the September 2017 quarter; and |

[0001193125-18-023592:mdna:74]
|  | • |  | a decrease of $42 million in vendor receivables, primarily due to timing of receipt of vendor payments. |

[0001193125-18-023592:mdna:75]
[same as prior period, unchanged from 0001193125-17-323042:mdna:64]

[0001193125-18-023592:mdna:76]
Cash used for investing activities for the six months ended December 29, 2017 was $210 million, which was primarily attributable to
the payments for the purchase of property, equipment and leasehold improvements of $201 million.

[0001193125-18-023592:mdna:77]
Cash Used in Financing
Activities

[0001193125-18-023592:mdna:78]
Cash used in financing activities of $865 million for the six months ended December 29, 2017 was primarily
attributable to the following activities:

[0001193125-18-023592:mdna:79]
|  | • |  | $366 million in dividend payments; |

[0001193125-18-023592:mdna:80]
|  | • |  | $361 million paid to repurchase ordinary shares; |

[0001193125-18-023592:mdna:81]
|  | • |  | $152 million of repayments of long-term debt; |

[0001193125-18-023592:mdna:82]
|  | • |  | $21 million paid for taxes related to net share settlement of equity awards, partially offset by; |

[0001193125-18-023592:mdna:83]
|  | • |  | $35 million in proceeds from the issuance of ordinary shares under employee stock plans. |

[0001193125-18-023592:mdna:84]
[same as prior period, unchanged from 0001193125-17-323042:mdna:73]

[0001193125-18-023592:mdna:85]
Our primary sources of liquidity as of December 29, 2017 consisted of:
(1) approximately $2.6 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) a $700 million senior revolving credit facility.

[0001193125-18-023592:mdna:86]
As of December 29, 2017, no borrowings had been drawn under the revolving credit facility or had been utilized for letters of credit
issued under this credit facility. The line of credit is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001193125-18-023592:mdna:87]
[same as prior period, unchanged from 0001193125-17-323042:mdna:97]

[0001193125-18-023592:mdna:88]
The credit agreement that governs our revolving credit facility, as amended, includes three
financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. On April 28, 2016, the Revolving Credit Agreement was amended in order to
increase the allowable net leverage ratio to adjust for our current financial liquidity position. The term of the revolving credit facility is through January 15, 2020 provided that if we do not have Investment Grade Ratings (as defined in the
revolving credit facility) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. We were in compliance with the modified covenants as of December 29, 2017 and
expect to be in compliance for the next 12 months.

[0001193125-18-023592:mdna:89]
Our liquidity requirements are primarily to meet our working capital, product
development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend. Our ability to fund these requirements will depend on our future cash flows, which are
determined by future operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001193125-18-023592:mdna:90]
[same as prior period, unchanged from 0001193125-17-323042:mdna:78]

[0001193125-18-023592:mdna:91]
From time to time we may repurchase any of our outstanding notes in open market or privately negotiated purchases or otherwise, or may
repurchase outstanding notes pursuant to the terms of the applicable indenture.

[0001193125-18-023592:mdna:92]
Dividends declared in the December 2017 quarter of
$179 million were subsequently paid on January 3, 2018. The Company’s Board of Directors announced a quarterly cash dividend of $0.63 per share on January 29, 2018, which is payable on April 4, 2018 to shareholders of record
at the close of business on March 21, 2018.

[0001193125-18-023592:mdna:93]
From time to time we may repurchase any of our outstanding ordinary shares through
private, open market, or broker-assisted purchases. As of December 29, 2017, $0.9 billion remained available for repurchase under our existing repurchase authorization limit. All repurchases are effected as redemptions in accordance
with the Company’s Articles of Association.

[0001193125-18-023592:mdna:94]
[same as prior period, unchanged from 0001193125-17-323042:mdna:82]

[0001193125-18-023592:mdna:95]
Our contractual cash obligations and commitments as of December 29, 2017, have been summarized in the table below:

[0001193125-18-023592:mdna:96]
|  |  |  |  |  | Fiscal Year(s) |  |
| (Dollars in millions) |  | Total |  |  | Remainder of2018 |  |  | 2019-2020 |  |  | 2021-2022 |  |  | Thereafter |  |
| Contractual Cash Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | $ | 4,923 |  |  | $ | — |  |  | $ | 560 |  |  | $ | 750 |  |  | $ | 3,613 |  |
| Interest payments on debt |  |  | 1,720 |  |  |  | 115 |  |  |  | 430 |  |  |  | 420 |  |  |  | 755 |  |
| Purchase obligations(2) |  |  | 764 |  |  |  | 764 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Operating leases(1) |  |  | 122 |  |  |  | 9 |  |  |  | 25 |  |  |  | 13 |  |  |  | 75 |  |
| Capital expenditures |  |  | 127 |  |  |  | 116 |  |  |  | 10 |  |  |  | 1 |  |  |  | — |  |
| Other funding requirements (3) |  |  | 24 |  |  |  | 12 |  |  |  | 12 |  |  |  | — |  |  |  | — |  |
| Subtotal |  |  | 7,680 |  |  |  | 1,016 |  |  |  | 1,037 |  |  |  | 1,184 |  |  |  | 4,443 |  |
| Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit or bank guarantees |  |  | 107 |  |  |  | 15 |  |  |  | 91 |  |  |  | 1 |  |  |  | — |  |
| Total |  | $ | 7,787 |  |  | $ | 1,031 |  |  | $ | 1,128 |  |  | $ | 1,185 |  |  | $ | 4,443 |  |

[0001193125-18-023592:mdna:97]
| (1) | Includes total future minimum rent expense under non-cancelable leases for both occupied and vacated facilities (rent expense is shown net of sublease income). |

[0001193125-18-023592:mdna:98]
| (2) | Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. |

[0001193125-18-023592:mdna:99]
[same as prior period, unchanged from 0001193125-17-323042:mdna:89]

[0001193125-18-023592:mdna:100]
On September 28,
2017, we entered into an Equity Commitment Letter (“ECL”) with a consortium of investors led by Bain Capital Private Equity for the acquisition of Toshiba Memory Corporation (“TMC”). The ECL contemplates that, upon the closing of
the acquisition, we would purchase up to JPY 139.5 billion (approximately USD 1.24 billion based on an exchange rate as of December 29, 2017), of a newly
issued non-convertible preferred equity security of a newly formed company, K. K. Pangea, for the purpose of acquiring TMC. The closing of the acquisition is subject to regulatory approvals and other
closing conditions.

[0001193125-18-023592:mdna:101]
As of December 29, 2017, we had a liability for unrecognized tax benefits and an accrual for the payment of
related interest totaling $11 million, none of which is expected to be settled within one year. Outside of one year, we are unable to make a reasonably reliable estimate of when cash settlement with a taxing authority will occur.

[0001193125-18-023592:mdna:102]
[same as prior period, unchanged from 0001193125-17-323042:mdna:92]

[0001193125-18-023592:mdna:103]
Our
discussion and analysis of financial condition and results of operations are based upon our Condensed Consolidated Financial Statements, which have been prepared in accordance with U.S. generally accepted accounting principles. The preparation of
such statements requires us to make estimates and assumptions that affect the reported amounts of revenues and expenses during the reporting period and the reported amounts of assets and liabilities as of the date of the financial statements. Our
estimates are based on historical experience and other assumptions that we consider to be appropriate in the circumstances. However, actual future results may vary from our estimates.

[0001193125-18-023592:mdna:104]
Since our fiscal year ended June 30, 2017, there have been no material changes in our critical accounting policies and
estimates. Refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Part II, Item 7 of our Annual Report on
Form 10-K for the fiscal year ended June 30, 2017, as filed with the SEC on August 4, 2017, for a discussion of our critical accounting policies and estimates.

[0001193125-18-023592:mdna:105]
[same as prior period, unchanged from 0001193125-17-323042:mdna:95]

[0001193125-18-023592:mdna:106]
See
“Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.
