# STX MD&A — 0001137789-24-000182


## mdna

[0001137789-24-000182:mdna:1]
ITEM 2. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001137789-24-000182:mdna:2]
The following is a discussion of the Company’s financial condition, changes in financial condition and results of operations for the fiscal quarters ended September 27, 2024, June 28, 2024 and September 29, 2023, referred to herein as the “September 2024 quarter”, the “June 2024 quarter” and the “September 2023 quarter”, respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The September 2024 quarter, June 2024 quarter and September 2023 quarter were each 13 weeks.

[0001137789-24-000182:mdna:3]
You should read this discussion in conjunction with financial information and related notes included in this Quarterly Report on Form 10-Q, as well as our Annual Report on Form 10-K for the fiscal year ended June 28, 2024. Unless the context indicates otherwise, as used herein, the terms “we,” “us,” “Seagate,” the “Company” and “our” refer collectively to Seagate Technology Holdings plc, an Irish public limited company, and its subsidiaries. References to “$” or “dollars” are to United States dollars.

[0001137789-24-000182:mdna:4]
[same as prior period, unchanged from 0001137789-24-000034:mdna:4]

[0001137789-24-000182:mdna:5]
•Overview of the September 2024 quarter. Highlights of events in the September 2024 quarter that impacted our financial position.

[0001137789-24-000182:mdna:6]
•Results of Operations. Analysis of our financial results comparing the September 2024 quarter to the June 2024 quarter and the September 2023 quarter.

[0001137789-24-000182:mdna:7]
•Liquidity and Capital Resources. Analysis of changes in our balance sheets and cash flows and discussion of our financial condition, including potential sources of liquidity, material cash requirements and their general purpose.

[0001137789-24-000182:mdna:8]
•Critical Accounting Policies and Estimates. Accounting policies and estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001137789-24-000182:mdna:9]
[same as prior period, unchanged from 0001137789-24-000034:mdna:9]

[0001137789-24-000182:mdna:10]
Overview of the September 2024 quarter

[0001137789-24-000182:mdna:11]
During the September 2024 quarter, we shipped 138 exabytes of HDD storage capacity. We generated revenue of approximately $2.2 billion with a gross margin of 33%. Our operating cash flow was $95 million and we paid $147 million in dividends.

[0001137789-24-000182:mdna:12]
[same as prior period, unchanged from 0001137789-24-000034:mdna:12]

[0001137789-24-000182:mdna:13]
During the September 2024 quarter, revenue growth was driven by continued improvement in cloud customer demand for our high capacity nearline drives along with an increase in demand from the enterprise and OEM markets. We continue to exercise cost discipline and implement pricing actions to improve operational efficiency and profitability. The macroeconomic environment remains dynamic, which may impact our business and results of operations. However, we expect our HDD storage business to benefit from further growth in data demand, including potential demand driven by the adoption of Generative AI applications.

[0001137789-24-000182:mdna:14]
[same as prior period, unchanged from 0001137789-24-000034:mdna:15]

[0001137789-24-000182:mdna:15]
[same as prior period, unchanged from 0001137789-24-000034:mdna:16]

[0001137789-24-000182:mdna:16]
We list in the tables below summarized information from our Condensed Consolidated Statements of Operations by dollar amounts and as a percentage of revenue:

[0001137789-24-000182:mdna:17]
|  |  | For The Three Months Ended |
| (Dollars in millions) |  | September 27, 2024 |  | June 28, 2024 |  | September 29, 2023 |
| Revenue |  | $ | 2,168 |  |  | $ | 1,887 |  |  | $ | 1,454 |  |
| Cost of revenue |  | 1,454 |  |  | 1,287 |  |  | 1,305 |  |
| Gross profit |  | 714 |  |  | 600 |  |  | 149 |  |
| Product development |  | 181 |  |  | 158 |  |  | 171 |  |
| Marketing and administrative |  | 129 |  |  | 131 |  |  | 105 |  |
| Restructuring and other, net |  | 1 |  |  | (3) |  |  | 2 |  |
| Income (loss) from operations |  | 403 |  |  | 314 |  |  | (129) |  |
| Other (expense) income, net |  | (87) |  |  | 224 |  |  | (18) |  |
| Income (loss) before income taxes |  | 316 |  |  | 538 |  |  | (147) |  |
| Provision for income taxes |  | 11 |  |  | 25 |  |  | 37 |  |
| Net Income (loss) |  | $ | 305 |  |  | $ | 513 |  |  | $ | (184) |  |

[0001137789-24-000182:mdna:18]
|  |  | For The Three Months Ended |
|  |  | September 27, 2024 |  | June 28, 2024 |  | September 29, 2023 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 67 |  |  | 68 |  |  | 90 |  |
| Gross margin |  | 33 |  |  | 32 |  |  | 10 |  |
| Product development |  | 8 |  |  | 8 |  |  | 12 |  |
| Marketing and administrative |  | 6 |  |  | 7 |  |  | 7 |  |
| Restructuring and other, net |  | — |  |  | — |  |  | — |  |
| Operating margin |  | 19 |  |  | 17 |  |  | (9) |  |
| Other (expense) income, net |  | (4) |  |  | 12 |  |  | (1) |  |
| Income (loss) before income taxes |  | 15 |  |  | 29 |  |  | (10) |  |
| Provision for income taxes |  | 1 |  |  | 1 |  |  | 3 |  |
| Net Income (loss) |  | 14 | % |  | 28 | % |  | (13) | % |

[0001137789-24-000182:mdna:19]
[same as prior period, unchanged from 0001137789-24-000034:mdna:20]

[0001137789-24-000182:mdna:20]
The following table summarizes information regarding consolidated revenues by channel, geography, and market and HDD exabytes shipped by market and price per terabyte:

[0001137789-24-000182:mdna:21]
|  |  | For The Three Months Ended |
|  |  | September 27, 2024 |  | June 28, 2024 |  | September 29, 2023 |
| Revenues by Channel (%) |  |  |  |  |  |  |
| OEMs |  | 81 | % |  | 79 | % |  | 71 | % |
| Distributors |  | 11 | % |  | 12 | % |  | 18 | % |
| Retailers |  | 8 | % |  | 9 | % |  | 11 | % |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |
| Asia Pacific |  | 40 | % |  | 54 | % |  | 56 | % |
| Americas |  | 50 | % |  | 36 | % |  | 31 | % |
| EMEA |  | 10 | % |  | 10 | % |  | 13 | % |
| Revenues by Market (%) |  |  |  |  |  |  |
| Mass capacity |  | 80 | % |  | 76 | % |  | 70 | % |
| Legacy |  | 12 | % |  | 15 | % |  | 19 | % |
| Other |  | 8 | % |  | 9 | % |  | 11 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |
| Mass capacity |  | 128 |  |  | 104 |  |  | 79 |  |
| Legacy |  | 10 |  |  | 10 |  |  | 11 |  |
| Total |  | 138 |  |  | 114 |  |  | 90 |  |
| HDD Price per Terabyte |  | $ | 15 |  |  | $ | 15 |  |  | $ | 14 |  |

[0001137789-24-000182:mdna:22]
________________________________________________

[0001137789-24-000182:mdna:23]
(1) Revenue is attributed to geography based on the bill from location.

[0001137789-24-000182:mdna:24]
Revenue in the September 2024 quarter increased by $281 million compared to the June 2024 quarter, primarily due to an increase in mass capacity exabytes shipped as we experienced improved demand for our nearline products, and favorable pricing actions undertaken by the Company.

[0001137789-24-000182:mdna:25]
Revenue in the September 2024 quarter increased by $714 million compared to the September 2023 quarter, primarily due to an increase in mass capacity exabytes shipped as we experienced improved demand for our nearline products, and favorable pricing actions undertaken by the Company.

[0001137789-24-000182:mdna:26]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 13% of gross revenue for the September 2024 quarter, 12% for the June 2024 quarter and 20% for the September 2023 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-24-000182:mdna:27]
[same as prior period, unchanged from 0001137789-24-000034:mdna:28]

[0001137789-24-000182:mdna:28]
|  |  | For The Three Months Ended |  |  |  |
| (Dollars in millions) |  | September 27, 2024 |  | June 28, 2024 |  | September 29, 2023 |  |  |  |
| Cost of revenue |  | $ | 1,454 |  |  | $ | 1,287 |  |  | $ | 1,305 |  |  |  |  |
| Gross profit |  | 714 |  |  | 600 |  |  | 149 |  |  |  |  |
| Gross margin |  | 33 | % |  | 32 | % |  | 10 | % |  |  |  |

[0001137789-24-000182:mdna:29]
Gross margin for the September 2024 quarter increased compared to the June 2024 quarter, primarily driven by favorable product mix and an improved pricing environment.

[0001137789-24-000182:mdna:30]
25

[0001137789-24-000182:mdna:31]
Gross margin for the September 2024 quarter increased compared to the September 2023 quarter, primarily driven by favorable product mix and pricing actions undertaken by the Company, as well as $118 million of order cancellation fees, $59 million of factory underutilization charges, and $13 million of accelerated depreciation expense for certain capital equipment in the September 2023 quarter that did not recur.

[0001137789-24-000182:mdna:32]
Warranty cost related to new shipments was 0.7%, 0.7% and 0.9% of revenue for the September 2024 quarter, June 2024 quarter and September 2023 quarter, respectively.

[0001137789-24-000182:mdna:33]
[same as prior period, unchanged from 0001137789-24-000034:mdna:34]

[0001137789-24-000182:mdna:34]
|  |  | For The Three Months Ended |  |  |  |  |
| (Dollars in millions) |  | September 27, 2024 |  | June 28, 2024 |  | September 29, 2023 |  |  |  |  |
| Product development |  | $ | 181 |  |  | $ | 158 |  |  | $ | 171 |  |  |  |  |  |
| Marketing and administrative |  | 129 |  |  | 131 |  |  | 105 |  |  |  |  |  |
| Restructuring and other, net |  | 1 |  |  | (3) |  |  | 2 |  |  |  |  |  |
| Operating expenses |  | $ | 311 |  |  | $ | 286 |  |  | $ | 278 |  |  |  |  |  |

[0001137789-24-000182:mdna:35]
Product Development Expense. Product development expenses increased by $23 million in the September 2024 quarter compared to the June 2024 quarter primarily due to a $19 million increase in compensation and other employee benefits as a result of the variable compensation expense recognized in the September 2024 quarter, and a $3 million increase in materials expense.

[0001137789-24-000182:mdna:36]
Product development expenses increased by $10 million in the September 2024 quarter compared to the September 2023 quarter primarily due to an $11 million increase in compensation and other employee benefits as a result of the variable compensation expense recognized in the September 2024 quarter and temporary salary reductions in the September 2023 quarter, a $1 million increase in equipment expense, a $1 million increase in travel expense and a $1 million increase in lease expense, partially offset by a $5 million decrease in materials expense.

[0001137789-24-000182:mdna:37]
Marketing and Administrative Expense. Marketing and administrative expenses decreased by $2 million in the September 2024 quarter compared to the June 2024 quarter primarily due to an $8 million decrease in outside services expense, partially offset by a $5 million net increase in compensation and other employee benefits due to the variable compensation expense recognized in the September 2024 quarter.

[0001137789-24-000182:mdna:38]
Marketing and administrative expenses increased by $24 million in the September 2024 quarter compared to the September 2023 quarter primarily due to a $20 million increase in compensation and other employee benefits as a result of the variable compensation expense in the September 2024 quarter and temporary salary reductions in the September 2023 quarter and a $2 million increase in travel expense.

[0001137789-24-000182:mdna:39]
Other (Expense) Income, net

[0001137789-24-000182:mdna:40]
|  |  | For The Three Months Ended |
| (Dollars in millions) |  | September 27, 2024 |  | June 28, 2024 |  | September 29, 2023 |
| Other (expense) income, net |  | $ | (87) |  |  | $ | 224 |  |  | $ | (18) |  |

[0001137789-24-000182:mdna:41]
Other (expense) income, net. Other expense, net increased by $311 million in the September 2024 quarter compared to the June 2024 quarter primarily due to a $313 million gain from the sale of System-on-Chip operations in the June 2024 quarter, partially offset by a $7 million decrease in net loss from equity investments.

[0001137789-24-000182:mdna:42]
Other expense, net increased by $69 million in the September 2024 quarter compared to the September 2023 quarter primarily due to a $104 million net gain recognized from the termination of interest rate swaps associated with the repayment of term loans in the September 2023 quarter, partially offset by a $29 million net loss recognized from early redemption of debt in the September 2023 quarter and a $5 million increase in interest income in the September 2024 quarter.

[0001137789-24-000182:mdna:43]
[same as prior period, unchanged from 0001137789-24-000034:mdna:48]

[0001137789-24-000182:mdna:44]
For the three months ended September 27, 2024 and September 29, 2023, we recorded income tax expense of $11 million and $37 million, respectively. For further discussion, refer to “Part I, Item 1. Financial Statements—Note 4. Income Taxes”.

[0001137789-24-000182:mdna:45]
[same as prior period, unchanged from 0001137789-24-000034:mdna:56]

[0001137789-24-000182:mdna:46]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash will continue to be sufficient to fund our operations and meet our cash requirements for the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs and capital expenditures, will allow us to manage the ongoing impact of market demand disruptions on our business operations for the foreseeable future. However, some challenges to our industry and to our business continue to remain uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to the global economic factors.

[0001137789-24-000182:mdna:47]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of September 27, 2024. For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, see “Part II, Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q.

[0001137789-24-000182:mdna:48]
[same as prior period, unchanged from 0001137789-24-000034:mdna:59]

[0001137789-24-000182:mdna:49]
|  |  | As of |  |  |
| (Dollars in millions) |  | September 27, 2024 |  | June 28, 2024 |  | Change |
| Cash and cash equivalents |  | $ | 1,239 |  |  | $ | 1,358 |  |  | $ | (119) |  |

[0001137789-24-000182:mdna:50]
Our cash and cash equivalents as of September 27, 2024 decreased by $119 million from June 28, 2024 primarily as a result of $147 million dividends paid to our shareholders and $68 million payments for capital expenditures, partially offset by net cash of $95 million provided by operating activities.

[0001137789-24-000182:mdna:51]
[same as prior period, unchanged from 0001137789-24-000034:mdna:63]

[0001137789-24-000182:mdna:52]
Cash provided by operating activities for the three months ended September 27, 2024 was $95 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, and:

[0001137789-24-000182:mdna:53]
•an increase of $37 million in accrued employee compensation, primarily due to an increase in our variable compensation expense; partially offset by

[0001137789-24-000182:mdna:54]
•an increase of $199 million in accounts receivable, primarily due to increased revenue; and

[0001137789-24-000182:mdna:55]
•an increase of $144 million in inventories, primarily due to an increase in purchased materials.

[0001137789-24-000182:mdna:56]
[same as prior period, unchanged from 0001137789-24-000034:mdna:71]

[0001137789-24-000182:mdna:57]
Net cash used in investing activities for the three months ended September 27, 2024 was $68 million, attributable to payments for the purchase of property, equipment and leasehold improvements.

[0001137789-24-000182:mdna:58]
[same as prior period, unchanged from 0001137789-24-000034:mdna:73]

[0001137789-24-000182:mdna:59]
Net cash used in financing activities of $146 million for the three months ended September 27, 2024 was primarily attributable to the following activities:

[0001137789-24-000182:mdna:60]
•$147 million in dividends paid to our shareholders; and

[0001137789-24-000182:mdna:61]
•$28 million taxes paid related to net share settlement of equity awards; partially offset by

[0001137789-24-000182:mdna:62]
•$29 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-24-000182:mdna:63]
[same as prior period, unchanged from 0001137789-24-000034:mdna:81]

[0001137789-24-000182:mdna:64]
Our primary sources of liquidity as of September 27, 2024, consist of: (1) approximately $1.2 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.5 billion available for borrowing under our senior unsecured revolving credit facility (“Revolving Credit Facility”), which is part of our Credit Agreement (as defined below).

[0001137789-24-000182:mdna:65]
As of September 27, 2024, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-24-000182:mdna:66]
As of September 27, 2024, the Credit Agreement includes two financial covenants: (1) interest coverage ratio and (2) net leverage ratio. We continue to evaluate our debt portfolio and structure to comply with our financial debt covenants. As of September 27, 2024, we were in compliance with all of the covenants under our debt agreements. Refer to “Part I, Item 1. Financial Statements—Note 3. Debt” for more details.

[0001137789-24-000182:mdna:67]
As of September 27, 2024, cash and cash equivalents held by our subsidiaries was $1.2 billion. This amount is potentially subject to taxation in Singapore upon repatriation by means of an intercompany dividend into our parent company, unless certain exemption is given, or a special approval is granted by the Ministry of Finance in Singapore. However, it is our intent to indefinitely reinvest earnings of subsidiaries in excess of the amount paid as dividends to shareholders. Our current plans do not demonstrate a need to repatriate such excess earnings. Should funds be needed in the parent company and should we be unable to fund parent company activities through means other than a taxable repatriation, we would be required to accrue and pay taxes on such dividend.

[0001137789-24-000182:mdna:68]
[same as prior period, unchanged from 0001137789-24-000034:mdna:86]

[0001137789-24-000182:mdna:69]
For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, among others, see “Part II, Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q.

[0001137789-24-000182:mdna:70]
[same as prior period, unchanged from 0001137789-24-000034:mdna:89]

[0001137789-24-000182:mdna:71]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend and any future strategic investments. As of September 27, 2024, our contractual cash requirements have not changed materially outside of the normal course of business since our fiscal year ended June 28, 2024.

[0001137789-24-000182:mdna:72]
[same as prior period, unchanged from 0001137789-24-000034:mdna:91]

[0001137789-24-000182:mdna:73]
Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. From time to time, we enter into long-term, non-cancelable purchase commitments or make large up-front investments with certain suppliers in order to secure certain components or technologies for the production of our products or to supplement our internal manufacturing capacity for certain components. As of September 27, 2024, we had unconditional purchase obligations of approximately $862 million, primarily related to purchases of inventory components with our suppliers. We expect $809 million of these commitments to be paid within one year. In addition, we also had certain long-term, market share-based, non-cancellable inventory purchase commitments as of September 27, 2024.

[0001137789-24-000182:mdna:74]
We recorded order cancellation fees to terminate certain purchase commitments related to the purchase of inventory components and equipment. As of September 27, 2024, the cumulative unpaid order cancellation fees on the Condensed Consolidated Balance Sheets were $58 million, with $32 million in Accounts payable and $26 million in Accrued expenses, all of which is expected to be paid within one year. In certain instances, our unpaid order cancellation fees may change based on the expected timing or ongoing negotiations with our suppliers.

[0001137789-24-000182:mdna:75]
28

[0001137789-24-000182:mdna:76]
[same as prior period, unchanged from 0001137789-24-000034:mdna:94]

[0001137789-24-000182:mdna:77]
As of September 27, 2024, the future principal payment obligation on our long-term debt was $5.7 billion, of which $479 million will mature within one year. As of September 27, 2024, future interest payments on this outstanding debt is estimated to be approximately $1.9 billion, of which $312 million is expected to be paid within one year. From time to time, we may repurchase, redeem or otherwise extinguish any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase or redeem outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 1. Financial Statements—Note 3. Debt” for more details.

[0001137789-24-000182:mdna:78]
[same as prior period, unchanged from 0001137789-24-000034:mdna:97]

[0001137789-24-000182:mdna:79]
We accrued a settlement penalty of $300 million for fiscal year 2023, related to BIS’ allegations of violations of the U.S. EAR, which were subsequently resolved by the Settlement Agreement in April 2023. As part of the Settlement Agreement with BIS, quarterly payments of $15 million are made over the course of five years beginning October 31, 2023, of which $60 million is expected to be paid within one year and $180 million thereafter. Refer to “Item 1. Financial Statements—Note 11. Legal, Environmental and Other Contingencies” for more details.

[0001137789-24-000182:mdna:80]
[same as prior period, unchanged from 0001137789-24-000034:mdna:102]

[0001137789-24-000182:mdna:81]
On October 22, 2024, our Board of Directors declared a quarterly cash dividend of $0.72 per share, which will be payable on January 6, 2025 to shareholders of record as of the close of business on December 15, 2024. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-24-000182:mdna:82]
[same as prior period, unchanged from 0001137789-24-000034:mdna:104]

[0001137789-24-000182:mdna:83]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means, including through the use of derivative transactions. As of September 27, 2024, $1.9 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-24-000182:mdna:84]
[same as prior period, unchanged from 0001137789-24-000034:mdna:106]

[0001137789-24-000182:mdna:85]
For fiscal year 2025, we expect capital expenditures to be higher than fiscal year 2024. We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-24-000182:mdna:86]
[same as prior period, unchanged from 0001137789-24-000034:mdna:108]

[0001137789-24-000182:mdna:87]
[same as prior period, unchanged from 0001137789-24-000034:mdna:109]

[0001137789-24-000182:mdna:88]
Other than as described in “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies”, there have been no other material changes in our critical accounting policies and estimates. Refer to “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended June 28, 2024, as filed with the SEC on August 2, 2024, for a discussion of our critical accounting policies and estimates.

[0001137789-24-000182:mdna:89]
29

[0001137789-24-000182:mdna:90]
[same as prior period, unchanged from 0001137789-24-000034:mdna:111]

[0001137789-24-000182:mdna:91]
See “Item 8. Financial Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.
