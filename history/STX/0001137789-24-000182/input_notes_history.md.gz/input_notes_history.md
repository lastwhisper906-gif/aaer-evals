# STX note change history — 0001137789-24-000034 → 0001137789-24-000182


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-10-25):
[0001137789-24-000182:note_history:1]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material
  (was, 2024-04-26, similarity 0.634):
[0001137789-24-000034:note_history:1]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgement in favor of Seagate on April 19, 2022, following a jury trial. The parties filed post-trial motions with the district court, which were denied. An appeal to the Federal Circuit is pending. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

- added (2024-10-25):
[0001137789-24-000182:note_history:2]
Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgment in favor of Seagate on April 19, 2022, following a jury trial. The parties filed post-trial motions with the district court, which were denied. An appeal to the Federal Circuit is pending. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

- changed (2024-10-25):
[0001137789-24-000182:note_history:3]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the U.S. District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendant misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, and additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 8, 2022, the court entered an Amended Stipulation and Order of Dismissal with Prejudice to dismiss all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment under the Foreign Trade Antitrust Improvement Act (“FTAIA Motion”) against Seagate’s antitrust claims, and on October 14, 2022, the Seagate Entities filed their corresponding opposition. On May 15, 2023, the court issued a ruling that Seagate’s antitrust claims can proceed as to suspension assemblies that enter the United States but not as to suspension assembles that do not enter the United States. On July 28, 2023, the District Court initiated a reconsideration of this ruling and requested further briefing. On November 17, 2023, the Court granted NHK’s FTAIA Motion and denied Seagate’s Motion for Leave to Amend the Complaint. Seagate filed a motion on December 15, 2023 for the Court to certify the ruling for interlocutory appeal. On April 22, 2024, the District Court granted in part and denied in part Seagate’s motion to certify for interlocutory appeal the Court’s ruling on NHK’s FTAIA Motion. On May 2, 2024, Seagate filed a Petition for Permission to Appeal to the Ninth Circuit. On July 18, 2024, the United States Court of Appeals for the Ninth Circuit issued an order granting Seagate’s Petition for Permission to Appeal. The FTAIA issue is now on appeal with the Ninth Circuit.
  (was, 2024-04-26, similarity 0.8656):
[0001137789-24-000034:note_history:3]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the U.S. District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendant misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies and additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 8, 2022, the court entered an Amended Stipulation and Order of Dismissal with Prejudice to dismiss all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment under the Foreign Trade Antitrust Improvement Act (“FTAIA Motion”) against Seagate’s antitrust claims, and on October 14, 2022, the Seagate Entities filed their corresponding opposition. On May 15, 2023, the Court issued a ruling that Seagate’s antitrust claims can proceed as to suspension assemblies that enter the United States but not as to suspension assembles that do not enter the United States. On July 28, 2023, the District Court initiated a reconsideration of this ruling and requested further briefing. On November 17, 2023, the Court granted NHK’s FTAIA Motion and denied Seagate’s Motion for Leave to Amend the Complaint. Seagate plans to appeal the Court’s ruling on NHK’s FTAIA Motion to the Ninth Circuit and filed a motion on December 15, 2023 for the Court to certify the ruling for interlocutory appeal. On April 22, 2024, the District Court granted in part and denied in part Seagate’s motion to certify for interlocutory appeal the Court’s ruling on NHK’s FTAIA Motion.

- changed (2024-10-25):
[0001137789-24-000182:note_history:4]
In re Seagate Technology Holdings plc Securities Litigation. A putative class action lawsuit alleging violations of the federal securities laws, UA Local 38 Defined Contribution Pension Plan, et al. v. Seagate Technology Holdings PLC, et al., was filed on July 10, 2023, in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The complaint alleged that it was a securities class action on behalf of all purchasers of Seagate common stock between September 15, 2020 and October 25, 2022, inclusive, and asserted claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b5-1. The complaint sought unspecified monetary damages and other relief. A second action, Public Employees’ Retirement System of Mississippi v. Seagate Technology Holdings plc, William David Mosley, and Gianluca Romano, was filed on July 26, 2023, asserting similar claims. The cases were consolidated on September 25, 2023. On October 19, 2023, plaintiffs filed an amended complaint asserting similar claims with a putative class period of September 14, 2020 through April 19, 2023. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint. On August 8, 2024, the Court granted the Company’s motion to dismiss, with leave to amend. On September 12, 2024, the Plaintiffs filed an amended complaint. The Company believes that the asserted claims are without merit and intends to vigorously defend the case.
  (was, 2024-04-26, similarity 0.8505):
[0001137789-24-000034:note_history:4]
In re Seagate Technology Holdings plc Securities Litigation. A putative class action lawsuit alleging violations of the federal securities laws, UA Local 38 Defined Contribution Pension Plan, et al. v. Seagate Technology Holdings PLC, et al., was filed on July 10, 2023, in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The complaint alleged that it was a securities class action on behalf of all purchasers of Seagate common stock between September 15, 2020 and October 25, 2022, inclusive, and asserted claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b5-1. The complaint sought unspecified monetary damages and other relief. A second action, Public Employees’ Retirement System of Mississippi v. Seagate Technology Holdings plc, William David Mosley, and Gianluca Romano, was filed on July 26, 2023, asserting similar claims. The cases were consolidated on September 25, 2023. On October 19, 2023, plaintiffs filed an amended complaint asserting similar claims with a putative class period of September 14, 2020 through April 19, 2023. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint, which is currently pending before the court. A hearing regarding Seagate’s motion to dismiss occurred on March 26, 2024. The Company believes that the asserted claims are without merit and intends to vigorously defend the case.

- added (2024-10-25):
[0001137789-24-000182:note_history:5]
Godo Kaisha IP Bridge 1 v. Seagate Technology LLC, Seagate Technology (US) Holding, Inc., Seagate Technology (Thailand) Limited, Seagate Singapore International Headquarters Ltd., Seagate Technology (Netherlands) B.V. On March 15, 2024, a patent infringement action was filed by Godo Kaisha IP Bridge 1 (“IP Bridge”) against Seagate in U.S. District Court for the District of Delaware. The complaint alleges patent infringement by Seagate of three U.S. patents. On June 7, 2024, Seagate filed a motion to dismiss and a motion to transfer venue to Minnesota. On July 8, 2024, IP Bridge filed a First Amended Complaint alleging patent infringement by Seagate of six additional patents. IP Bridge is seeking damages as well as additional relief. On August 5, 2024, Seagate filed a motion to dismiss in part IP Bridge’s First Amended Complaint. On September 4, 2024, Seagate won its motion to transfer the case to the District Court in Minnesota. Seagate’s motion to dismiss on the remaining claims is pending. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

- changed (2024-10-25):
[0001137789-24-000182:note_history:6]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of
  (was, 2024-04-26, similarity 0.615):
[0001137789-24-000034:note_history:6]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

- added (2024-10-25):
[0001137789-24-000182:note_history:7]
hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

- added (2024-10-25):
[0001137789-24-000182:note_history:8]
The Company has established an environmental management system and continually reviews and updates environmental policies and standard operating procedures for operations worldwide as needed. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

- changed (2024-10-25):
[0001137789-24-000182:note_history:9]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fail to comply with the substance restrictions, recycle content requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.
  (was, 2024-04-26, similarity 0.9963):
[0001137789-24-000034:note_history:9]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fail to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

- added (2024-10-25):
[0001137789-24-000182:note_history:10]
On April 18, 2023, the Company’s subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd (collectively, “Seagate”), entered into a settlement agreement (the “Settlement Agreement”) with the U.S. Department of Commerce’s Bureau of Industry and Security (“BIS”) that resolved BIS’ allegations regarding Seagate’s sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, Seagate agreed to pay $300 million to BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. Seagate also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the U.S. Export Administration Regulations (“EAR”), including one audit by an unaffiliated third-party consultant chosen by Seagate with expertise in U.S. export control laws and two internal audits, and has completed the first audit. The Settlement Agreement also included a denial order that is suspended and will be waived five years after the date of the order issued under the Settlement Agreement, provided that Seagate has made full and timely payments under the Settlement Agreement and timely completed the audit requirements. While Seagate is in compliance with and upon successful compliance in full with the terms of the Settlement Agreement, BIS agreed it will not initiate any further administrative proceedings against Seagate in connection with any violation of the EAR arising out of the transactions detailed in the Settlement Agreement.

- changed (2024-10-25):
[0001137789-24-000182:note_history:11]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $180 million were included in Accrued expense and Other non-current liabilities, respectively, on the Condensed Consolidated Balance Sheets as of September 27, 2024. For the three months ended September 27, 2024, $15 million was paid and reported as an outflow from operating activities in its Condensed Consolidated Statements of Cash Flows.
  (was, 2024-04-26, similarity 0.8794):
[0001137789-24-000034:note_history:11]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $210 million were included in Accrued expense and Other non-current liabilities, respectively, on its Condensed Consolidated Balance Sheets as of March 29, 2024. For the nine months ended March 29, 2024, $30 million was paid and reported as an outflow from operating activities on its Condensed Consolidated Statements of Cash Flows.

- changed (2024-10-25):
[0001137789-24-000182:note_history:12]
Other Matters 
From time to time, arising in the normal course of business, the Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company expects to be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.
  (was, 2024-04-26, similarity 0.9877):
[0001137789-24-000034:note_history:12]
From time to time, arising in the normal course of business, the Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company expects to be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.

- removed (2024-10-25):
[0001137789-24-000034:note_history:13]
Godo Kaisha IP Bridge 1 v. Seagate Technology LLC, Seagate Technology (US) Holding, Inc., Seagate Technology (Thailand) Limited, Seagate Singapore International Headquarters Ltd., Seagate Technology (Netherlands) B.V. On March 15, 2024, a patent infringement action was filed by Godo Kaisha IP Bridge 1 (“IP Bridge”) against Seagate in United States District Court for the District of Delaware. The complaint alleges patent infringement by Seagate of US Patent Nos. 7,884,403 (entitled, “Magnetic tunnel junction device and memory device including the same”), 8,319,263 (entitled, “Magnetic tunnel junction device”), and 11,737,372 (entitled, “Method of manufacturing a magnetoresistive random access memory (MRAM)”). IP Bridge is seeking damages as well as additional relief. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

- removed (2024-10-25):
[0001137789-24-000034:note_history:14]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

- removed (2024-10-25):
[0001137789-24-000034:note_history:15]
On April 18, 2023, the Company’s subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd (collectively, “Seagate”), entered into a settlement agreement (the “Settlement Agreement”) with the U.S. Department of Commerce’s Bureau of Industry and Security (“BIS”) that resolves BIS’ allegations regarding Seagate’s sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, Seagate has agreed to pay $300 million to BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. Seagate has also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the U.S. Export Administration Regulations (“EAR”), including one audit by an unaffiliated third-party consultant chosen by Seagate with expertise in U.S. export control laws and two internal audits. The Settlement Agreement also includes a denial order that is suspended and will be waived five years after the date of the order issued under the Settlement Agreement, provided that Seagate has made full and timely payments under the Settlement Agreement and timely completed the audit requirements. While Seagate is in compliance with and upon successful compliance in full with the terms of the Settlement Agreement, BIS has agreed it will not initiate any further administrative proceedings against Seagate in connection with any violation of the EAR arising out of the transactions detailed in the Settlement Agreement.

- removed (2024-10-25):
[0001137789-24-000034:note_history:16]
Other Matters


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-10-25):
[0001137789-24-000182:note_history:17]
The Company’s Consolidated Financial Statements for the fiscal year ended June 28, 2024 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 2, 2024. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 28, 2024, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three months ended September 27, 2024 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 27, 2025.
  (was, 2024-04-26, similarity 0.9653):
[0001137789-24-000034:note_history:17]
The Company’s Consolidated Financial Statements for the fiscal year ended June 30, 2023 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 4, 2023. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 30, 2023, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and nine months ended March 29, 2024 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 28, 2024.

- changed (2024-10-25):
[0001137789-24-000182:note_history:18]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three months ended September 27, 2024 and September 29, 2023 consisted of 13 weeks. Fiscal years 2025 and 2024 both comprise 52 weeks and end on June 27, 2025 and June 28, 2024, respectively. The fiscal quarters ended September 27, 2024, June 28, 2024 and September 29, 2023, are also referred to herein as the “September 2024 quarter”, the “June 2024 quarter” and the “September 2023 quarter”, respectively.
  (was, 2024-04-26, similarity 0.6165):
[0001137789-24-000034:note_history:18]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and nine months ended March 29, 2024 and March 31, 2023 consisted of 13 and 39 weeks, respectively. Fiscal years 2024 and 2023 both comprise 52 weeks and end on June 28, 2024 and June 30, 2023, respectively. The fiscal quarters ended March 29, 2024, December 29, 2023 and March 31, 2023, are also referred to herein as the “March 2024 quarter”, the “December 2023 quarter” and the “March 2023 quarter”, respectively.

- changed (2024-10-25):
[0001137789-24-000182:note_history:19]
There have been no material changes to the Company’s significant accounting policies disclosed in Note 1. Basis of Presentation and Summary of Significant Accounting Policies of “Financial Statements and Supplementary Data” contained in Part II, Item 8. of the Company’s Annual Report on Form 10-K for the fiscal year ended June 28, 2024, as filed with the SEC on August 2, 2024.
  (was, 2024-04-26, similarity 0.8913):
[0001137789-24-000034:note_history:19]
Except for the change in the Company’s other long-lived assets policies described below, there have been no material changes to the Company’s significant accounting policies disclosed in Note 1. Basis of Presentation and Summary of Significant Accounting Policies of “Financial Statements and Supplementary Data” contained in Part II, Item 8. of the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2023, as filed with the SEC on August 4, 2023.

- changed (2024-10-25):
[0001137789-24-000182:note_history:20]
In September 2022, the Financial Accounting Standards Board (FASB) issued ASU 2022-04 (ASC Subtopic 405-50), Disclosure of Supplier Finance Program Obligations. This ASU requires disclosure of key terms of the outstanding supplier finance programs and a rollforward of the related obligations. The Company adopted the disclosure requirement on rollforward information in the quarter ended September 27, 2024. Refer to “Note 2. Balance Sheet Information” for more details.
  (was, 2024-04-26, similarity 0.6696):
[0001137789-24-000034:note_history:20]
In September 2022, the Financial Accounting Standards Board (FASB) issued ASU 2022-04 (ASC Subtopic 405-50), Disclosure of Supplier Finance Program Obligations. This ASU requires disclosure of key terms of the outstanding supplier finance programs and a roll forward of the related obligations. The Company adopted this guidance in the quarter ended September 29, 2023. The adoption of this ASU did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

- changed (2024-10-25):
[0001137789-24-000182:note_history:21]
In November 2023, the FASB issued ASU 2023-07 (ASC Topic 280), Improvements to Reportable Segment Disclosures. This ASU improves reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The Company is required to adopt this guidance for its annual reporting in fiscal year 2025 and for interim period reporting beginning the first quarter of fiscal year 2026 on a retrospective basis. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have an impact on its Condensed Consolidated Financial Statements.
In December 2023, the FASB issued ASU 2023-09 (ASC Topic 740), Improvements to Income Tax Disclosures. This ASU requires disaggregated income tax disclosures on the rate reconciliation and income taxes paid. The Company is required to adopt this guidance for its annual reporting in fiscal year 2026 on a prospective basis but has the option to apply it retrospectively. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have an impact on its Condensed Consolidated Financial Statements.
  (was, 2024-04-26, similarity 0.6918):
[0001137789-24-000034:note_history:21]
In November 2023, the FASB issued ASU 2023-07 (ASC Topic 280), Improvements to Reportable Segment Disclosures. This ASU improves reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The Company is required to adopt this guidance for its annual reporting in fiscal year 2025 and for interim period reporting beginning the first quarter of fiscal year 2026 on a retrospective basis. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have impact on its Condensed Consolidated Financial Statements.

- removed (2024-10-25):
[0001137789-24-000034:note_history:22]
In January 2024, the Company established Singapore as its principal executive offices to better align its operational footprint.

- removed (2024-10-25):
[0001137789-24-000034:note_history:23]
Other Long-Lived Assets

- removed (2024-10-25):
[0001137789-24-000034:note_history:24]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. Effective from the first quarter of fiscal year 2024, the Company changed the useful lives of certain manufacturing equipment from a range of three to seven years to a range of three to ten years based on its review of technology product roadmap. The effect of this change in estimate increased the net income by approximately $30 million and $70 million for three and nine months ended March 29, 2024, respectively. Earnings per share for the three months ended March 29, 2024 increased by $0.14 and loss per share for the nine months ended March 29, 2024 decreased by $0.33.

- removed (2024-10-25):
[0001137789-24-000034:note_history:25]
In December 2023, the FASB issued ASU 2023-09 (ASC Topic 740), Improvements to Income Tax Disclosures. This ASU requires disaggregated income tax disclosures on the rate reconciliation and income taxes paid. The Company is required to adopt this guidance in the first quarter of the fiscal year 2026. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have impact on its Condensed Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-25):
[0001137789-24-000182:note_history:26]
Debt
The following table provides details of the Company’s debt as of September 27, 2024 and June 28, 2024:
  (was, 2024-04-26, similarity 0.9474):
[0001137789-24-000034:note_history:26]
Debt
The following table provides details of the Company’s debt as of March 29, 2024 and June 30, 2023:

- changed (2024-10-25):
[0001137789-24-000182:note_history:27]
| (Dollars in millions) |  | September 27, 2024 |  | June 28, 2024 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 505 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 472 |  |  | 471 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,705 |  |  | 5,704 |  |
| Less: unamortized debt issuance costs |  | (29) |  |  | (30) |  |
| Debt, net of debt issuance costs |  | 5,676 |  |  | 5,674 |  |
| Less: current portion of long-term debt |  | (479) |  |  | (479) |  |
| Long-term debt, less current portion |  | $ | 5,197 |  |  | $ | 5,195 |  |
  (was, 2024-04-26, similarity 0.8508):
[0001137789-24-000034:note_history:27]
| (Dollars in millions) |  | March 29, 2024 |  | June 30, 2023 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | $ | 479 |  |  | $ | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 469 |  |  | 465 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | — |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | — |  |  | 430 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
|  |  | 5,702 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (31) |  |  | (36) |  |
| Debt, net of debt issuance costs |  | 5,671 |  |  | 5,451 |  |
| Less: current portion of long-term debt |  | (479) |  |  | (63) |  |
| Long-term debt, less current portion |  | $ | 5,192 |  |  | $ | 5,388 |  |

- added (2024-10-25):
[0001137789-24-000182:note_history:28]
___________________________________

- changed (2024-10-25):
[0001137789-24-000182:note_history:29]
(1) All unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and Seagate Technology Holdings plc.
  (was, 2024-04-26, similarity 0.9386):
[0001137789-24-000034:note_history:29]
| (1) All unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX. |

- added (2024-10-25):
[0001137789-24-000182:note_history:30]
For the three months ended September 27, 2024, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $26 million and immaterial amortization of debt issuance costs.

- changed (2024-10-25):
[0001137789-24-000182:note_history:31]
The entire outstanding principal amount of Term Loans A1, A2 and A3 were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in the Net loss recognized from early redemption of debt in the Company’s Condensed Consolidated Statements of Operations. In connection with the repayment of Term Loans, the Company terminated certain interest rate swap agreements. Refer to “Note 5. Derivative Financial Instruments” for more details.
  (was, 2024-04-26, similarity 0.6496):
[0001137789-24-000034:note_history:31]
The entire outstanding principal amount of Term Loans A1, A2 and A3 were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in the Net gain (loss) recognized from early redemption of debt in the Company’s Condensed Consolidated Statements of Operations for the nine months ended March 29, 2024. In connection with the repayment of Term Loans, the Company terminated its interest rate swap agreements. Refer to “Note 6. Derivative Financial Instruments” for more details.

- added (2024-10-25):
[0001137789-24-000182:note_history:32]
Prior to March 1, 2028, the 2028 Notes are exchangeable at the option of the holders only under the following circumstances:

- added (2024-10-25):
[0001137789-24-000182:note_history:33]
•during any calendar quarter commencing after the calendar quarter ending on December 31, 2023 (and only during such calendar quarter), if the last reported sale price of the ordinary Shares for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter is greater than or equal to 130% of the exchange price in effect on each applicable trading day;

- added (2024-10-25):
[0001137789-24-000182:note_history:34]
•during the five business day period after any ten consecutive trading day period in which the trading price per $1,000 principal amount of 2028 Notes for each trading day period was less than 98% of the product of the last reported sale price of the ordinary shares and the applicable exchange rate on such trading day; or

- added (2024-10-25):
[0001137789-24-000182:note_history:35]
•upon the occurrence of specified corporate events described in the indenture with respect to the 2028 Notes.

- added (2024-10-25):
[0001137789-24-000182:note_history:36]
On or after March 1, 2028, the 2028 Notes are exchangeable at any time at the option of the holders until the close of business on the second scheduled trading day immediately preceding the maturity date, unless the 2028 Notes have been previously redeemed or repurchased by Seagate HDD.

- changed (2024-10-25):
[0001137789-24-000182:note_history:37]
Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The initial exchange rate for the 2028 Notes is 12.1253 ordinary shares per $1,000 principal amount of 2028 Notes, which is equivalent to an exchange price of approximately $82.47 per share.
  (was, 2024-04-26, similarity 0.6303):
[0001137789-24-000034:note_history:37]
Prior to March 1, 2028, the 2028 Notes are exchangeable at the option of the holders only under certain circumstances as set forth in the indenture with respect to the 2028 Notes. On or after March 1, 2028, the 2028 Notes are exchangeable at any time at the option of the holders until the close of business on the second scheduled trading day immediately preceding the maturity date, unless the 2028 Notes have been previously redeemed or repurchased by Seagate HDD. Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The initial exchange rate for the 2028 Notes is 12.1253 ordinary shares per $1,000 principal amount of 2028 Notes.

- changed (2024-10-25):
[0001137789-24-000182:note_history:38]
Seagate HDD may redeem the 2028 Notes at its option, in whole but not in part, if Seagate HDD or the Guarantors have, or on the next interest payment date would, become obligated to pay to the holder of any Note additional amounts as a result of certain tax-related events at a redemption price equal to 100% of the principal amount plus accrued and unpaid interest, including additional interest, if any, to, but excluding, the redemption date; provided that Seagate HDD may only redeem the 2028 Notes if: (x) Seagate HDD or the relevant Guarantor cannot avoid these obligations by taking commercially reasonable measures available to Seagate HDD or such Guarantor; and (y) Seagate HDD delivers to the Trustee an opinion of outside legal counsel of recognized standing in the relevant taxing jurisdiction attesting to such tax-related event and obligation to pay additional amounts.
  (was, 2024-04-26, similarity 0.9989):
[0001137789-24-000034:note_history:38]
Seagate HDD may redeem the 2028 Notes at its option, in whole but not in part, if Seagate HDD or the Guarantors have, or on the next interest payment date would, become obligated to pay to the holder of any Note additional amounts as a result of certain tax-related events at a redemption price equal to 100% of the principal amount plus accrued and unpaid interest, including additional interest, if any, to, but excluding, the redemption date; provided that Seagate HDD may only redeem the Notes if: (x) Seagate HDD or the relevant Guarantor cannot avoid these obligations by taking commercially reasonable measures available to Seagate HDD or such Guarantor; and (y) Seagate HDD delivers to the Trustee an opinion of outside legal counsel of recognized standing in the relevant taxing jurisdiction attesting to such tax-related event and obligation to pay additional amounts.

- added (2024-10-25):
[0001137789-24-000182:note_history:39]
As of September 27, 2024, the 2028 Notes were not exchangeable. Refer to “Note 10. Earnings (Loss) Per Share” for the potential dilutive impact of the 2028 Notes.

- changed (2024-10-25):
[0001137789-24-000182:note_history:40]
The credit agreement dated as of February 20, 2019, by and among, Seagate Technology Holdings plc, Seagate HDD, The Bank of Nova Scotia, as administrative agent, and the lenders party thereto (as amended from time to time, the “Credit Agreement”) includes two financial covenants: (1) interest coverage ratio and (2) total net leverage ratio. For the fiscal quarter ended September 27, 2024, and for each fiscal quarter until the end of the covenant relief period, which terminates on June 27, 2025, the maximum permitted total net leverage ratio is 6.75 to 1.00, and applies only to the extent that the aggregate outstanding amount of revolving loans, swing line loans and the aggregate face amount of certain letters of credit exceeds 25% of the then outstanding revolving commitments in effect (the “Testing Condition”) as of the last day of the relevant fiscal quarter. The maximum permitted total leverage ratio for each fiscal quarter ending after June 27, 2025 is 4.00 to 1.00.
  (was, 2024-04-26, similarity 0.751):
[0001137789-24-000034:note_history:40]
The credit agreement dated as of February 20, 2019, by and among, Seagate Technology Holdings plc, Seagate HDD, The Bank of Nova Scotia, as administrative agent, and the lenders party thereto (as amended from time to time, the “Credit Agreement”) includes two financial covenants: (1) interest coverage ratio and (2) total net leverage ratio. The maximum permitted total net leverage ratio did not apply for the fiscal quarter ended March 29, 2024. For the fiscal quarters ending June 28, 2024 until the end of the covenant relief period, which terminates on June 27, 2025, the maximum permitted total net leverage ratio is 6.75 to 1.00, and applies only to the extent that the aggregate outstanding amount of revolving loans, swing line loans and the aggregate face amount of certain letters of credit exceeds 25% of the then outstanding revolving commitments in effect (the “Testing Condition”) as of the last day of the fiscal quarter. The maximum permitted total leverage ratio for each fiscal quarter ending after June 27, 2025 is 4.00 to 1.00.

- added (2024-10-25):
[0001137789-24-000182:note_history:41]
For the fiscal quarter ended September 27, 2024, and for each fiscal quarter until the end of the covenant relief period, which terminates on June 27, 2025, the minimum interest coverage ratio is 2.25 to 1.00, and applies only to the extent that the Testing Condition is satisfied as of the last day of the relevant fiscal quarter. The minimum interest coverage ratio for each fiscal quarter ending after June 27, 2025 is 3.25 to 1.00.

- changed (2024-10-25):
[0001137789-24-000182:note_history:42]
At September 27, 2024, future principal payments on long-term debt were as follows (in millions):
  (was, 2024-04-26, similarity 0.9438):
[0001137789-24-000034:note_history:42]
At March 29, 2024, future principal payments on long-term debt were as follows (in millions):

- changed (2024-10-25):
[0001137789-24-000182:note_history:43]
| Fiscal Year |  | Amount |
| Remainder of 2025 |  | $ | 479 |  |
| 2026 |  | — |  |
| 2027 |  | 505 |  |
| 2028 |  | 1,500 |  |
| 2029 |  | 495 |  |
| Thereafter |  | 2,750 |  |
| Total |  | $ | 5,729 |  |
  (was, 2024-04-26, similarity 0.8834):
[0001137789-24-000034:note_history:43]
| Fiscal Year |  | Principal Amount |
| Remainder of 2024 |  | $ | — |  |
| 2025 |  | 479 |  |
| 2026 |  | — |  |
| 2027 |  | 505 |  |
| 2028 |  | 1,500 |  |
| Thereafter |  | 3,245 |  |
| Total |  | $ | 5,729 |  |

- removed (2024-10-25):
[0001137789-24-000034:note_history:44]
As of March 29, 2024, the 2028 Notes were not exchangeable and the aggregate if-converted value of the 2028 Notes exceeded their aggregate principal amount by approximately $100 million. Refer to “Note 11. Net Income (Loss) Per Share” for the potential dilutive impact of the 2028 Notes.

- removed (2024-10-25):
[0001137789-24-000034:note_history:45]
The minimum interest coverage ratio did not apply for the fiscal quarter ended March 29, 2024. For the fiscal quarters ending June 28, 2024 until June 27, 2025, the minimum interest coverage ratio is 2.25 to 1.00, and applies only to the extent that the Testing Condition is satisfied as of the last day of the fiscal quarter. The minimum interest coverage ratio is 3.25 to 1.00 for each fiscal quarter ending after June 27, 2025.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2024-10-25):
[0001137789-24-000034:note_history:46]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of March 29, 2024 and June 30, 2023:

- removed (2024-10-25):
[0001137789-24-000034:note_history:47]
|  |  | March 29, 2024 |  | June 30, 2023 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 172 |  |  | $ | — |  |  | $ | 172 |  |  | $ | 73 |  |  | $ | — |  |  | $ | 73 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 15 |  |  | — |  |  | 15 |  |  | 16 |  |  | — |  |  | 16 |  |
| Total |  | $ | 188 |  |  | $ | — |  |  | $ | 188 |  |  | $ | 90 |  |  | $ | — |  |  | $ | 90 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 171 |  |  |  |  |  |  | $ | 72 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 15 |  |  |  |  |  |  | 16 |  |
| Total |  |  |  |  |  | $ | 188 |  |  |  |  |  |  | $ | 90 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2024-10-25):
[0001137789-24-000182:note_history:48]
The Company’s debt is carried at amortized cost. The estimated fair value of the Company’s debt is derived using the closing price of the same debt instruments as of the date of valuation, which takes into account the yield curve, interest rates and other observable inputs. Accordingly, these fair value measurements are categorized as Level 2. The following table presents the fair value and amortized cost of the Company’s debt in order of maturity:

- added (2024-10-25):
[0001137789-24-000182:note_history:49]
|  |  | September 27, 2024 |  | June 28, 2024 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 4.75% Senior Notes due January 2025 |  | 479 |  |  | 478 |  |  | 479 |  |  | 476 |  |
| 4.875% Senior Notes due June 2027 |  | 505 |  |  | 504 |  |  | 505 |  |  | 493 |  |
| 3.50% Exchangeable Senior Notes due June 2028 |  | 1,500 |  |  | 2,142 |  |  | 1,500 |  |  | 2,070 |  |
| 4.091% Senior Notes due June 2029 |  | 472 |  |  | 475 |  |  | 471 |  |  | 459 |  |
| 3.125% Senior Notes due July 2029 |  | 163 |  |  | 147 |  |  | 163 |  |  | 139 |  |
| 8.25% Senior Notes due December 2029 |  | 500 |  |  | 544 |  |  | 500 |  |  | 537 |  |
| 4.125% Senior Notes due January 2031 |  | 275 |  |  | 254 |  |  | 275 |  |  | 245 |  |
| 3.375% Senior Notes due July 2031 |  | 72 |  |  | 61 |  |  | 72 |  |  | 58 |  |
| 8.50% Senior Notes due July 2031 |  | 500 |  |  | 547 |  |  | 500 |  |  | 538 |  |
| 9.625% Senior Notes due December 2032 |  | 750 |  |  | 871 |  |  | 750 |  |  | 855 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 494 |  |  | 489 |  |  | 472 |  |
|  |  | $ | 5,705 |  |  | $ | 6,517 |  |  | $ | 5,704 |  |  | $ | 6,342 |  |
| Less: unamortized debt issuance costs |  | (29) |  |  | — |  |  | (30) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 5,676 |  |  | $ | 6,517 |  |  | $ | 5,674 |  |  | $ | 6,342 |  |
| Less: current portion of debt, net of debt issuance costs |  | (479) |  |  | (478) |  |  | (479) |  |  | (476) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,197 |  |  | $ | 6,039 |  |  | $ | 5,195 |  |  | $ | 5,866 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-25):
[0001137789-24-000182:note_history:50]
The following table provides details of the Company’s debt as of September 27, 2024 and June 28, 2024:
  (was, 2024-04-26, similarity 0.9444):
[0001137789-24-000034:note_history:50]
The following table provides details of the Company’s debt as of March 29, 2024 and June 30, 2023:

- changed (2024-10-25):
[0001137789-24-000182:note_history:51]
| (Dollars in millions) |  | September 27, 2024 |  | June 28, 2024 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 505 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 472 |  |  | 471 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,705 |  |  | 5,704 |  |
| Less: unamortized debt issuance costs |  | (29) |  |  | (30) |  |
| Debt, net of debt issuance costs |  | 5,676 |  |  | 5,674 |  |
| Less: current portion of long-term debt |  | (479) |  |  | (479) |  |
| Long-term debt, less current portion |  | $ | 5,197 |  |  | $ | 5,195 |  |
  (was, 2024-04-26, similarity 0.8508):
[0001137789-24-000034:note_history:51]
| (Dollars in millions) |  | March 29, 2024 |  | June 30, 2023 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | $ | 479 |  |  | $ | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 469 |  |  | 465 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | — |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | — |  |  | 430 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
|  |  | 5,702 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (31) |  |  | (36) |  |
| Debt, net of debt issuance costs |  | 5,671 |  |  | 5,451 |  |
| Less: current portion of long-term debt |  | (479) |  |  | (63) |  |
| Long-term debt, less current portion |  | $ | 5,192 |  |  | $ | 5,388 |  |

- added (2024-10-25):
[0001137789-24-000182:note_history:52]
___________________________________

- changed (2024-10-25):
[0001137789-24-000182:note_history:53]
(1) All unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and Seagate Technology Holdings plc.
  (was, 2024-04-26, similarity 0.9386):
[0001137789-24-000034:note_history:53]
| (1) All unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX. |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-25):
[0001137789-24-000182:note_history:54]
At September 27, 2024, future principal payments on long-term debt were as follows (in millions):
  (was, 2024-04-26, similarity 0.9438):
[0001137789-24-000034:note_history:54]
At March 29, 2024, future principal payments on long-term debt were as follows (in millions):

- changed (2024-10-25):
[0001137789-24-000182:note_history:55]
| Fiscal Year |  | Amount |
| Remainder of 2025 |  | $ | 479 |  |
| 2026 |  | — |  |
| 2027 |  | 505 |  |
| 2028 |  | 1,500 |  |
| 2029 |  | 495 |  |
| Thereafter |  | 2,750 |  |
| Total |  | $ | 5,729 |  |
  (was, 2024-04-26, similarity 0.8834):
[0001137789-24-000034:note_history:55]
| Fiscal Year |  | Principal Amount |
| Remainder of 2024 |  | $ | — |  |
| 2025 |  | 479 |  |
| 2026 |  | — |  |
| 2027 |  | 505 |  |
| 2028 |  | 1,500 |  |
| Thereafter |  | 3,245 |  |
| Total |  | $ | 5,729 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-10-25):
[0001137789-24-000182:note_history:56]
The following table provides information about disaggregated revenue by sales channel and country for the Company’s single reportable segment:
  (was, 2024-04-26, similarity 0.9324):
[0001137789-24-000034:note_history:56]
The following table provides information about disaggregated revenue by sales channel and geographical region for the Company’s single reportable segment:

- added (2024-10-25):
[0001137789-24-000182:note_history:57]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 27, 2024 |  | September 29, 2023 |  |  |
| Revenues by Channel |  |  |  |  |  |  |
| OEMs |  | $ | 1,749 |  |  | $ | 1,032 |  |  |  |
| Distributors |  | 248 |  |  | 266 |  |  |  |
| Retailers |  | 171 |  |  | 156 |  |  |  |
| Total |  | $ | 2,168 |  |  | $ | 1,454 |  |  |  |

- added (2024-10-25):
[0001137789-24-000182:note_history:58]
| Revenue by Country (1): |  |  |  |  |  |  |
| Singapore |  | $ | 860 |  |  | $ | 808 |  |  |  |
| United States |  | 1,097 |  |  | 455 |  |  |  |
| The Netherlands |  | 210 |  |  | 188 |  |  |  |
| Other |  | 1 |  |  | 3 |  |  |  |
| Total |  | $ | 2,168 |  |  | $ | 1,454 |  |  |  |

- removed (2024-10-25):
[0001137789-24-000034:note_history:59]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |  |
| (Dollars in millions) |  | March 29, 2024 |  | March 31, 2023 |  | March 29, 2024 |  | March 31, 2023 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,236 |  |  | $ | 1,358 |  |  | $ | 3,408 |  |  | $ | 4,268 |  |  |  |  |  |
| Distributors |  | 252 |  |  | 294 |  |  | 736 |  |  | 890 |  |  |  |  |  |
| Retailers |  | 167 |  |  | 208 |  |  | 520 |  |  | 624 |  |  |  |  |  |
| Total |  | $ | 1,655 |  |  | $ | 1,860 |  |  | $ | 4,664 |  |  | $ | 5,782 |  |  |  |  |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 837 |  |  | $ | 774 |  |  | $ | 2,425 |  |  | $ | 2,335 |  |  |  |  |  |
| Americas |  | 618 |  |  | 799 |  |  | 1,617 |  |  | 2,588 |  |  |  |  |  |
| EMEA |  | 200 |  |  | 287 |  |  | 622 |  |  | 859 |  |  |  |  |  |
| Total |  | $ | 1,655 |  |  | $ | 1,860 |  |  | $ | 4,664 |  |  | $ | 5,782 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-10-25):
[0001137789-24-000182:note_history:60]
Revenue
The following table provides information about disaggregated revenue by sales channel and country for the Company’s single reportable segment:
  (was, 2024-04-26, similarity 0.9359):
[0001137789-24-000034:note_history:60]
Revenue
The following table provides information about disaggregated revenue by sales channel and geographical region for the Company’s single reportable segment:

- added (2024-10-25):
[0001137789-24-000182:note_history:61]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 27, 2024 |  | September 29, 2023 |  |  |
| Revenues by Channel |  |  |  |  |  |  |
| OEMs |  | $ | 1,749 |  |  | $ | 1,032 |  |  |  |
| Distributors |  | 248 |  |  | 266 |  |  |  |
| Retailers |  | 171 |  |  | 156 |  |  |  |
| Total |  | $ | 2,168 |  |  | $ | 1,454 |  |  |  |

- added (2024-10-25):
[0001137789-24-000182:note_history:62]
| Revenue by Country (1): |  |  |  |  |  |  |
| Singapore |  | $ | 860 |  |  | $ | 808 |  |  |  |
| United States |  | 1,097 |  |  | 455 |  |  |  |
| The Netherlands |  | 210 |  |  | 188 |  |  |  |
| Other |  | 1 |  |  | 3 |  |  |  |
| Total |  | $ | 2,168 |  |  | $ | 1,454 |  |  |  |

- removed (2024-10-25):
[0001137789-24-000034:note_history:63]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |  |
| (Dollars in millions) |  | March 29, 2024 |  | March 31, 2023 |  | March 29, 2024 |  | March 31, 2023 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,236 |  |  | $ | 1,358 |  |  | $ | 3,408 |  |  | $ | 4,268 |  |  |  |  |  |
| Distributors |  | 252 |  |  | 294 |  |  | 736 |  |  | 890 |  |  |  |  |  |
| Retailers |  | 167 |  |  | 208 |  |  | 520 |  |  | 624 |  |  |  |  |  |
| Total |  | $ | 1,655 |  |  | $ | 1,860 |  |  | $ | 4,664 |  |  | $ | 5,782 |  |  |  |  |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 837 |  |  | $ | 774 |  |  | $ | 2,425 |  |  | $ | 2,335 |  |  |  |  |  |
| Americas |  | 618 |  |  | 799 |  |  | 1,617 |  |  | 2,588 |  |  |  |  |  |
| EMEA |  | 200 |  |  | 287 |  |  | 622 |  |  | 859 |  |  |  |  |  |
| Total |  | $ | 1,655 |  |  | $ | 1,860 |  |  | $ | 4,664 |  |  | $ | 5,782 |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2024-10-25):
[0001137789-24-000182:note_history:64]
Subsequent Event
Dividend Declared
  (was, 2024-04-26, similarity 0.9855):
[0001137789-24-000034:note_history:64]
Subsequent Events
Dividend Declared

- changed (2024-10-25):
[0001137789-24-000182:note_history:65]
On October 22, 2024, the Board of Directors of the Company declared a quarterly cash dividend of $0.72 per share, which will be payable on January 6, 2025 to shareholders of record as of the close of business on December 15, 2024.
  (was, 2024-04-26, similarity 0.6005):
[0001137789-24-000034:note_history:65]
On April 23, 2024, the Board of Directors of the Company declared a quarterly cash dividend of $0.70 per share, which will be payable on July 5, 2024 to shareholders of record as of the close of business on June 20, 2024.

- removed (2024-10-25):
[0001137789-24-000034:note_history:66]
Sale of System-on-Chip (“SoC”) Operations

- removed (2024-10-25):
[0001137789-24-000034:note_history:67]
On April 23, 2024, the Company entered into an Asset Purchase Agreement with Avago Technologies International Sales Pte. Limited (“Purchaser”), a subsidiary of Broadcom Inc., to sell certain intellectual property, equipment and other assets related to the design, development and manufacture of its SoC products to Purchaser for $600 million. Purchaser and its affiliates have agreed to offer employment to certain of the Company’s employees engaged in the SoC Operations. In connection with this transaction, the Company and Purchaser have also restructured an existing purchasing agreement.
