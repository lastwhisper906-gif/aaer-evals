# STX notes — 0001137789-24-000182


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001137789-24-000182:notes:1]
[same as prior period, unchanged from 0001137789-24-000034:notes:1]

[0001137789-24-000182:notes:2]
[same as prior period, unchanged from 0001137789-24-000034:notes:2]

[0001137789-24-000182:notes:3]
[same as prior period, unchanged from 0001137789-24-000034:notes:3]

[0001137789-24-000182:notes:4]
[same as prior period, unchanged from 0001137789-24-000034:notes:4]

[0001137789-24-000182:notes:5]
[same as prior period, unchanged from 0001137789-24-000034:notes:5]

[0001137789-24-000182:notes:6]
[same as prior period, unchanged from 0001137789-24-000034:notes:6]

[0001137789-24-000182:notes:7]
[same as prior period, unchanged from 0001137789-24-000034:notes:8]

[0001137789-24-000182:notes:8]
[same as prior period, unchanged from 0001137789-24-000034:notes:9]

[0001137789-24-000182:notes:9]
[same as prior period, unchanged from 0001137789-24-000034:notes:10]

[0001137789-24-000182:notes:10]
The Company’s Consolidated Financial Statements for the fiscal year ended June 28, 2024 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 2, 2024. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 28, 2024, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three months ended September 27, 2024 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 27, 2025.

[0001137789-24-000182:notes:11]
[same as prior period, unchanged from 0001137789-24-000034:notes:12]

[0001137789-24-000182:notes:12]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three months ended September 27, 2024 and September 29, 2023 consisted of 13 weeks. Fiscal years 2025 and 2024 both comprise 52 weeks and end on June 27, 2025 and June 28, 2024, respectively. The fiscal quarters ended September 27, 2024, June 28, 2024 and September 29, 2023, are also referred to herein as the “September 2024 quarter”, the “June 2024 quarter” and the “September 2023 quarter”, respectively.

[0001137789-24-000182:notes:13]
[same as prior period, unchanged from 0001137789-24-000034:notes:14]

[0001137789-24-000182:notes:14]
There have been no material changes to the Company’s significant accounting policies disclosed in Note 1. Basis of Presentation and Summary of Significant Accounting Policies of “Financial Statements and Supplementary Data” contained in Part II, Item 8. of the Company’s Annual Report on Form 10-K for the fiscal year ended June 28, 2024, as filed with the SEC on August 2, 2024.

[0001137789-24-000182:notes:15]
Recently Adopted Accounting Pronouncements

[0001137789-24-000182:notes:16]
In September 2022, the Financial Accounting Standards Board (FASB) issued ASU 2022-04 (ASC Subtopic 405-50), Disclosure of Supplier Finance Program Obligations. This ASU requires disclosure of key terms of the outstanding supplier finance programs and a rollforward of the related obligations. The Company adopted the disclosure requirement on rollforward information in the quarter ended September 27, 2024. Refer to “Note 2. Balance Sheet Information” for more details.

[0001137789-24-000182:notes:17]
Recently Issued Accounting Pronouncements

[0001137789-24-000182:notes:18]
In November 2023, the FASB issued ASU 2023-07 (ASC Topic 280), Improvements to Reportable Segment Disclosures. This ASU improves reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The Company is required to adopt this guidance for its annual reporting in fiscal year 2025 and for interim period reporting beginning the first quarter of fiscal year 2026 on a retrospective basis. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have an impact on its Condensed Consolidated Financial Statements.
In December 2023, the FASB issued ASU 2023-09 (ASC Topic 740), Improvements to Income Tax Disclosures. This ASU requires disaggregated income tax disclosures on the rate reconciliation and income taxes paid. The Company is required to adopt this guidance for its annual reporting in fiscal year 2026 on a prospective basis but has the option to apply it retrospectively. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have an impact on its Condensed Consolidated Financial Statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001137789-24-000182:notes:19]
Balance Sheet Information
Cash, Cash Equivalents and Restricted Cash

[0001137789-24-000182:notes:20]
The details of the cash, cash equivalents and restricted cash were as follows:

[0001137789-24-000182:notes:21]
| (Dollars in millions) |  | September 27, 2024 |  | June 28, 2024 |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,239 |  |  | $ | 1,358 |  |  |  |  |  |
| Restricted cash included in Other current assets |  | 2 |  |  | 2 |  |  |  |  |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  | $ | 1,241 |  |  | $ | 1,360 |  |  |  |  |  |

[0001137789-24-000182:notes:22]
Accounts Receivable, net

[0001137789-24-000182:notes:23]
In connection with the Company’s factoring agreements, from time to time the Company sells accounts receivables to third parties for cash proceeds less a discount.

[0001137789-24-000182:notes:24]
During the three months ended September 27, 2024, the Company sold accounts receivables without recourse for cash proceeds of $343 million. As of September 27, 2024, the total amount that remained subject to servicing by the Company was $343 million. During the three months ended September 29, 2023, the Company sold accounts receivables without recourse for cash proceeds of $292 million. As of September 29, 2023, the total amount that remained subject to servicing by the Company was $363 million.

[0001137789-24-000182:notes:25]
The discounts on accounts receivables sold were not material for the three months ended September 27, 2024, and September 29, 2023, respectively.

[0001137789-24-000182:notes:26]
[same as prior period, unchanged from 0001137789-24-000034:notes:37]

[0001137789-24-000182:notes:27]
The details of the inventory, net were as follows:

[0001137789-24-000182:notes:28]
| (Dollars in millions) |  | September 27, 2024 |  | June 28, 2024 |
| Raw materials and components |  | $ | 441 |  |  | $ | 270 |  |
| Work-in-process |  | 829 |  |  | 831 |  |
| Finished goods |  | 113 |  |  | 138 |  |
| Total inventories, net |  | $ | 1,383 |  |  | $ | 1,239 |  |

[0001137789-24-000182:notes:29]
[same as prior period, unchanged from 0001137789-24-000034:notes:40]

[0001137789-24-000182:notes:30]
[same as prior period, unchanged from 0001137789-24-000034:notes:41]

[0001137789-24-000182:notes:31]
| (Dollars in millions) |  | September 27, 2024 |  | June 28, 2024 |
| Vendor receivables |  | $ | 125 |  |  | $ | 110 |  |
| Other current assets |  | 233 |  |  | 196 |  |
| Total |  | $ | 358 |  |  | $ | 306 |  |

[0001137789-24-000182:notes:32]
[same as prior period, unchanged from 0001137789-24-000034:notes:43]

[0001137789-24-000182:notes:33]
The components of property, equipment and leasehold improvements, net were as follows:

[0001137789-24-000182:notes:34]
| (Dollars in millions) |  | September 27, 2024 |  | June 28, 2024 |
| Gross property, equipment and leasehold improvements |  | 10,280 |  |  | 10,260 |  |
| Less: accumulated depreciation and amortization |  | (8,681) |  |  | (8,646) |  |
| Property, equipment and leasehold improvements, net |  | $ | 1,599 |  |  | $ | 1,614 |  |

[0001137789-24-000182:notes:35]
During the three months ended September 27, 2024, the accelerated depreciation charge recognized was immaterial.

[0001137789-24-000182:notes:36]
During the three months ended September 29, 2023, the Company recognized a charge of $13 million for the accelerated depreciation of certain fixed assets, which was recorded to Cost of revenue in the Condensed Consolidated Statements of Operations.

[0001137789-24-000182:notes:37]
[same as prior period, unchanged from 0001137789-24-000034:notes:48]

[0001137789-24-000182:notes:38]
[same as prior period, unchanged from 0001137789-24-000034:notes:49]

[0001137789-24-000182:notes:39]
| (Dollars in millions) |  | September 27, 2024 |  | June 28, 2024 |
| Dividends payable |  | $ | 148 |  |  | $ | 147 |  |
| Other accrued expenses |  | 537 |  |  | 507 |  |
| Total |  | $ | 685 |  |  | $ | 654 |  |

[0001137789-24-000182:notes:40]
Supplier Financing Arrangements

[0001137789-24-000182:notes:41]
The Company facilitates the opportunity for suppliers to participate in a voluntary supply chain financing ("SCF") program with third-party financial institutions. This SCF program does not result in changes to the Company's contractual payment terms with the suppliers regardless of program participation. At the suppliers' election, they can receive payment of the Company's obligations prior to the scheduled due dates, at a discount price to the third-party financial institution. The Company does not determine the terms or conditions of the arrangement between suppliers and the third-party financial institution. Participating suppliers are paid directly by the third-party financial institution and the Company pays the third-party financial institution the stated amount of confirmed invoices from its designated suppliers at the original invoice amount on the agreed due dates. The Company has not pledged any assets or provided other guarantees under its SCF program.

[0001137789-24-000182:notes:42]
All outstanding amounts related to suppliers participating in the SCF Program are recorded within Accounts payable in the Company's Condensed Consolidated Balance Sheets and the associated payments are included in Net cash provided by operating activities on its Condensed Consolidated Statements of Cash Flows.

[0001137789-24-000182:notes:43]
The details of the outstanding supplier financing obligation were as follows:

[0001137789-24-000182:notes:44]
| (Dollars in millions) |  | September 27, 2024 |  | September 29, 2023 |
| Outstanding at the beginning of the period |  | $ | 50 |  |  | $ | 51 |  |
| Added to the program during the period |  | 332 |  |  | 161 |  |
| Settled during the period |  | (348) |  |  | (163) |  |
| Outstanding at the ending of the period |  | $ | 34 |  |  | $ | 49 |  |

[0001137789-24-000182:notes:45]
Accumulated Other Comprehensive (Loss) Income (“AOCI”)

[0001137789-24-000182:notes:46]
[same as prior period, unchanged from 0001137789-24-000034:notes:52]

[0001137789-24-000182:notes:47]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at June 28, 2024 |  | $ | — |  |  |  | $ | (2) |  |  | $ | — |  |  | $ | (2) |  |
| Other comprehensive income before reclassifications |  | — |  |  |  | — |  |  | — |  |  | — |  |
| Amounts reclassified from AOCI |  | — |  |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income |  | — |  |  |  | — |  |  | — |  |  | — |  |
| Balance at September 27, 2024 |  | — |  |  |  | (2) |  |  | — |  |  | (2) |  |
| Balance at June 30, 2023 |  | 103 |  |  |  | (4) |  |  | (1) |  |  | 98 |  |
| Other comprehensive (loss) before reclassifications |  | (22) |  |  |  | — |  |  | — |  |  | (22) |  |
| Amounts reclassified from AOCI |  | (92) |  |  |  | — |  |  | 1 |  |  | (91) |  |
| Other comprehensive (loss) |  | (114) |  |  |  | — |  |  | 1 |  |  | (113) |  |
| Balance at September 29, 2023 |  | $ | (11) |  |  |  | $ | (4) |  |  | $ | — |  |  | $ | (15) |  |


## us-gaap:DebtDisclosureTextBlock

[0001137789-24-000182:notes:48]
Debt
The following table provides details of the Company’s debt as of September 27, 2024 and June 28, 2024:

[0001137789-24-000182:notes:49]
| (Dollars in millions) |  | September 27, 2024 |  | June 28, 2024 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 505 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 472 |  |  | 471 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,705 |  |  | 5,704 |  |
| Less: unamortized debt issuance costs |  | (29) |  |  | (30) |  |
| Debt, net of debt issuance costs |  | 5,676 |  |  | 5,674 |  |
| Less: current portion of long-term debt |  | (479) |  |  | (479) |  |
| Long-term debt, less current portion |  | $ | 5,197 |  |  | $ | 5,195 |  |

[0001137789-24-000182:notes:50]
___________________________________

[0001137789-24-000182:notes:51]
(1) All unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and Seagate Technology Holdings plc.

[0001137789-24-000182:notes:52]
2028 Exchangeable Senior Notes and related Capped Call Transactions

[0001137789-24-000182:notes:53]
2028 Notes. On September 13, 2023, Seagate HDD, in a private placement, issued $1.5 billion in aggregate principal amount of 3.50% Exchangeable Senior Notes due 2028 (the “2028 Notes”), which includes $200 million aggregate principal amount pursuant to the over-allotment option of the initial purchasers to purchase additional notes. The 2028 Notes will mature on June 1, 2028, with interest payable semi-annually on March 1 and September 1 of each year, commencing March 1, 2024.

[0001137789-24-000182:notes:54]
For the three months ended September 27, 2024, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $26 million and immaterial amortization of debt issuance costs.

[0001137789-24-000182:notes:55]
The entire outstanding principal amount of Term Loans A1, A2 and A3 were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in the Net loss recognized from early redemption of debt in the Company’s Condensed Consolidated Statements of Operations. In connection with the repayment of Term Loans, the Company terminated certain interest rate swap agreements. Refer to “Note 5. Derivative Financial Instruments” for more details.

[0001137789-24-000182:notes:56]
Prior to March 1, 2028, the 2028 Notes are exchangeable at the option of the holders only under the following circumstances:

[0001137789-24-000182:notes:57]
•during any calendar quarter commencing after the calendar quarter ending on December 31, 2023 (and only during such calendar quarter), if the last reported sale price of the ordinary Shares for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter is greater than or equal to 130% of the exchange price in effect on each applicable trading day;

[0001137789-24-000182:notes:58]
•during the five business day period after any ten consecutive trading day period in which the trading price per $1,000 principal amount of 2028 Notes for each trading day period was less than 98% of the product of the last reported sale price of the ordinary shares and the applicable exchange rate on such trading day; or

[0001137789-24-000182:notes:59]
•upon the occurrence of specified corporate events described in the indenture with respect to the 2028 Notes.

[0001137789-24-000182:notes:60]
On or after March 1, 2028, the 2028 Notes are exchangeable at any time at the option of the holders until the close of business on the second scheduled trading day immediately preceding the maturity date, unless the 2028 Notes have been previously redeemed or repurchased by Seagate HDD.

[0001137789-24-000182:notes:61]
Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The initial exchange rate for the 2028 Notes is 12.1253 ordinary shares per $1,000 principal amount of 2028 Notes, which is equivalent to an exchange price of approximately $82.47 per share.

[0001137789-24-000182:notes:62]
Seagate HDD may redeem the 2028 Notes at its option, in whole but not in part, if Seagate HDD or the Guarantors have, or on the next interest payment date would, become obligated to pay to the holder of any Note additional amounts as a result of certain tax-related events at a redemption price equal to 100% of the principal amount plus accrued and unpaid interest, including additional interest, if any, to, but excluding, the redemption date; provided that Seagate HDD may only redeem the 2028 Notes if: (x) Seagate HDD or the relevant Guarantor cannot avoid these obligations by taking commercially reasonable measures available to Seagate HDD or such Guarantor; and (y) Seagate HDD delivers to the Trustee an opinion of outside legal counsel of recognized standing in the relevant taxing jurisdiction attesting to such tax-related event and obligation to pay additional amounts.

[0001137789-24-000182:notes:63]
Seagate HDD also may redeem the 2028 Notes at its option on or after September 8, 2026, in whole or in part, if the last reported sale price of ordinary shares of the Company has been at least 130% of the exchange price then in effect for at least 20 trading days (whether or not consecutive), including the trading day immediately preceding the date on which Seagate HDD provides notice of redemption, during any 30 consecutive trading day period ending on, and including, the trading day immediately preceding the date on which Seagate HDD provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If Seagate HDD redeems less than all the outstanding 2028 Notes, at least $150 million aggregate principal amount of 2028 Notes must be outstanding and not subject to redemption as of the relevant notice of redemption date.

[0001137789-24-000182:notes:64]
As of September 27, 2024, the 2028 Notes were not exchangeable. Refer to “Note 10. Earnings (Loss) Per Share” for the potential dilutive impact of the 2028 Notes.

[0001137789-24-000182:notes:65]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The cap price of the capped call transactions will initially be $107.848 per share. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets.

[0001137789-24-000182:notes:66]
Credit Agreement

[0001137789-24-000182:notes:67]
The credit agreement dated as of February 20, 2019, by and among, Seagate Technology Holdings plc, Seagate HDD, The Bank of Nova Scotia, as administrative agent, and the lenders party thereto (as amended from time to time, the “Credit Agreement”) includes two financial covenants: (1) interest coverage ratio and (2) total net leverage ratio. For the fiscal quarter ended September 27, 2024, and for each fiscal quarter until the end of the covenant relief period, which terminates on June 27, 2025, the maximum permitted total net leverage ratio is 6.75 to 1.00, and applies only to the extent that the aggregate outstanding amount of revolving loans, swing line loans and the aggregate face amount of certain letters of credit exceeds 25% of the then outstanding revolving commitments in effect (the “Testing Condition”) as of the last day of the relevant fiscal quarter. The maximum permitted total leverage ratio for each fiscal quarter ending after June 27, 2025 is 4.00 to 1.00.

[0001137789-24-000182:notes:68]
For the fiscal quarter ended September 27, 2024, and for each fiscal quarter until the end of the covenant relief period, which terminates on June 27, 2025, the minimum interest coverage ratio is 2.25 to 1.00, and applies only to the extent that the Testing Condition is satisfied as of the last day of the relevant fiscal quarter. The minimum interest coverage ratio for each fiscal quarter ending after June 27, 2025 is 3.25 to 1.00.

[0001137789-24-000182:notes:69]
Future Principal Payments on Long-term Debt

[0001137789-24-000182:notes:70]
At September 27, 2024, future principal payments on long-term debt were as follows (in millions):

[0001137789-24-000182:notes:71]
| Fiscal Year |  | Amount |
| Remainder of 2025 |  | $ | 479 |  |
| 2026 |  | — |  |
| 2027 |  | 505 |  |
| 2028 |  | 1,500 |  |
| 2029 |  | 495 |  |
| Thereafter |  | 2,750 |  |
| Total |  | $ | 5,729 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001137789-24-000182:notes:72]
Income Taxes


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001137789-24-000182:notes:73]
Derivative Financial Instruments 
The Company is exposed to foreign currency exchange rate, interest rate and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies.

[0001137789-24-000182:notes:74]
The Company entered into certain interest rate swap agreements to convert the variable interest rate on its Term Loans to fixed interest rates. The objective of the interest rate swap agreements was to eliminate the variability of interest payment cash flows associated with the variable interest rate under the Term Loans. The Company designated the interest rate swaps as cash flow hedges. On September 13, 2023, the Company terminated its then existing interest rate swap agreements as a result of the repayment of Term Loans A1, A2 and A3 and received cash proceeds of $25 million from the counterparty. The cash proceeds are reported within Net cash provided by operating activities in the Company’s Condensed Consolidated Statements of Cash Flows as of September 29, 2023. The Company discontinued the related hedge accounting prospectively and realized a net gain of $104 million in Net gain from termination of interest rate swap in the Condensed Consolidated Statements of Operations as of September 29, 2023. Additionally, $6 million of the gains were amortized to Interest expense prior to the termination of interest rate swap in the Company’s Condensed Consolidated Statements of Operations as of September 29, 2023.

[0001137789-24-000182:notes:75]
As of September 27, 2024, the Company does not have any interest rate swap contracts.

[0001137789-24-000182:notes:76]
The Company did not record any net unrealized gain or loss on cash flow hedges as of September 27, 2024 and the net unrealized loss as of June 28, 2024 was immaterial.

[0001137789-24-000182:notes:77]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its non-qualified deferred compensation plan: the Seagate Deferred Compensation Plan (the “SDCP”). The Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP’s liabilities. The TRS is designed to substantially offset changes in the SDCP’s liabilities due to changes in the value of the investment options made by employees. The contract, which settles monthly and effectively mitigates counterparty risk will mature in June 2025. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP’s liabilities.

[0001137789-24-000182:notes:78]
The following tables show the effect of the Company’s derivative instruments in the Condensed Consolidated Statements of Comprehensive Income (Loss) and the Condensed Consolidated Statements of Operations for the three months ended September 27, 2024.

[0001137789-24-000182:notes:79]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 11 |  |
| Total return swap |  | Operating expenses |  | 4 |  |

[0001137789-24-000182:notes:80]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
| Foreign currency forward exchange contracts |  | $ | — |  |  |  | Cost of revenue |  | $ | — |  |  |  | Other, net |  | $ | 1 |  |

[0001137789-24-000182:notes:81]
The following tables show the effect of the Company’s derivative instruments in the Condensed Consolidated Statements of Comprehensive Income (Loss) and the Condensed Consolidated Statements of Operations for the three months ended September 29, 2023.

[0001137789-24-000182:notes:82]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (6) |  |
| Total return swap |  | Operating expenses |  | (3) |  |

[0001137789-24-000182:notes:83]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
| Foreign currency forward exchange contracts |  | $ | (7) |  |  |  | Cost of revenue |  | $ | (1) |  |  |  | Other, net |  | $ | — |  |
| Interest rate swap |  | (15) |  |  |  | Interest expense |  | (11) |  |  |  | Net gain from termination of interest rate swap1 |  | 104 |  |

[0001137789-24-000182:notes:84]
1The net gain recognized into earnings as a result of the discontinuance of interest rate swap during the three months ended September 29, 2023.

[0001137789-24-000182:notes:85]
The gross notional and fair value of derivative instruments in the Condensed Consolidated Balance Sheets as of September 27, 2024 and June 28, 2024 were as follows:

[0001137789-24-000182:notes:86]
|  |  |  |  | As of September 27, 2024 |
|  |  |  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Outstanding Gross Notional |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | $ | — |  |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | 294 |  |  | Other current assets |  | 1 |  |  | Accrued expenses |  | — |  |
| Total return swap |  | 115 |  |  | Other current assets |  | — |  |  | Accrued expenses |  | (1) |  |
| Total derivatives |  | $ | 409 |  |  |  |  | $ | 1 |  |  |  |  | $ | (1) |  |

[0001137789-24-000182:notes:87]
|  |  |  |  | As of June 28, 2024 |
|  |  |  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Outstanding Gross Notional |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | $ | 35 |  |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (1) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | 165 |  |  | Other current assets |  | 1 |  |  | Accrued expenses |  | — |  |
| Total return swap |  | 112 |  |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  | $ | 312 |  |  |  |  | $ | 1 |  |  |  |  | $ | (1) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001137789-24-000182:notes:88]
[same as prior period, unchanged from 0001137789-24-000034:notes:104]

[0001137789-24-000182:notes:89]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact and it considers assumptions that market participants would use when pricing the asset or liability.

[0001137789-24-000182:notes:90]
[same as prior period, unchanged from 0001137789-24-000034:notes:106]

[0001137789-24-000182:notes:91]
A fair value hierarchy is based on whether the market participant assumptions used in determining fair value are obtained from independent sources (observable inputs) or reflect the Company's own assumptions of market participant valuation (unobservable inputs). A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The three levels of inputs that may be used to measure fair value are:

[0001137789-24-000182:notes:92]
Level 1 - Quoted prices in active markets that are unadjusted and accessible at the measurement date for identical, unrestricted assets or liabilities;

[0001137789-24-000182:notes:93]
Level 2 - Quoted prices for identical assets and liabilities in markets that are inactive; quoted prices for similar assets and liabilities in active markets or financial instruments for which significant inputs are observable, either directly or indirectly; or

[0001137789-24-000182:notes:94]
Level 3 - Prices or valuations that require inputs that are both unobservable and significant to the fair value measurement.

[0001137789-24-000182:notes:95]
[same as prior period, unchanged from 0001137789-24-000034:notes:111]

[0001137789-24-000182:notes:96]
[same as prior period, unchanged from 0001137789-24-000034:notes:112]

[0001137789-24-000182:notes:97]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of:

[0001137789-24-000182:notes:98]
|  |  |  |  | September 27, 2024 |  | June 28, 2024 |
|  |  |  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Balance SheetLocation |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | Cash and cash equivalents |  | $ | 458 |  |  | $ | — |  |  | $ | — |  |  | $ | 458 |  |  | $ | 386 |  |  | $ | — |  |  | $ | — |  |  | $ | 386 |  |
| Total cash equivalents |  | 458 |  |  | — |  |  | — |  |  | 458 |  |  | 386 |  |  | — |  |  | — |  |  | 386 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | Other current assets |  | 1 |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | Other current assets |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | Other assets, net |  | — |  |  | — |  |  | 15 |  |  | 15 |  |  | — |  |  | — |  |  | 15 |  |  | 15 |  |
| Derivative assets |  | Other current assets |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total assets |  |  |  | $ | 459 |  |  | $ | 2 |  |  | $ | 15 |  |  | $ | 476 |  |  | $ | 387 |  |  | $ | 2 |  |  | $ | 15 |  |  | $ | 404 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | Accrued expenses |  | $ | — |  |  | $ | (1) |  |  | $ | — |  |  | $ | (1) |  |  | $ | — |  |  | $ | (1) |  |  | $ | — |  |  | $ | (1) |  |
| Total liabilities |  |  |  | $ | — |  |  | $ | (1) |  |  | $ | — |  |  | $ | (1) |  |  | $ | — |  |  | $ | (1) |  |  | $ | — |  |  | $ | (1) |  |

[0001137789-24-000182:notes:99]
As of September 27, 2024 and June 28, 2024, the Company’s Other current assets included $2 million in restricted cash equivalents held as collateral at banks for various performance obligations.

[0001137789-24-000182:notes:100]
As of September 27, 2024 and June 28, 2024, the Company had no material available-for-sale investments that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no impairment related to credit losses for available-for-sale investments as of September 27, 2024 and June 28, 2024, respectively.

[0001137789-24-000182:notes:101]
The fair value and amortized cost of the Company’s available-for-sale investments as of September 27, 2024, was $15 million due within 2 years. The fair value and amortized cost of the Company’s available-for-sale investments as of June 28, 2024 was $15 million due in 2 years.

[0001137789-24-000182:notes:102]
[same as prior period, unchanged from 0001137789-24-000034:notes:118]

[0001137789-24-000182:notes:103]
[same as prior period, unchanged from 0001137789-24-000034:notes:119]

[0001137789-24-000182:notes:104]
For the investments that are accounted for under the equity method, the Company recorded no adjustment and an immaterial loss for the three months ended September 27, 2024 and September 29, 2023, respectively. The adjusted carrying value of the investments accounted under the equity method amounted to $12 million and $12 million as of September 27, 2024 and June 28, 2024, respectively.

[0001137789-24-000182:notes:105]
For the investments that are accounted under the measurement alternative, the Company recorded a net loss of $2 million for the three months ended September 27, 2024, related to downward adjustments to write down the carrying amount of certain investments to their fair value. The Company recorded no adjustment for the three months ended September 29, 2023. As of September 27, 2024 and June 28, 2024, the carrying value of the Company’s strategic investments under the measurement alternative was $63 million and $65 million, respectively.

[0001137789-24-000182:notes:106]
[same as prior period, unchanged from 0001137789-24-000034:notes:122]

[0001137789-24-000182:notes:107]
[same as prior period, unchanged from 0001137789-24-000034:notes:123]

[0001137789-24-000182:notes:108]
|  |  | September 27, 2024 |  | June 28, 2024 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 4.75% Senior Notes due January 2025 |  | 479 |  |  | 478 |  |  | 479 |  |  | 476 |  |
| 4.875% Senior Notes due June 2027 |  | 505 |  |  | 504 |  |  | 505 |  |  | 493 |  |
| 3.50% Exchangeable Senior Notes due June 2028 |  | 1,500 |  |  | 2,142 |  |  | 1,500 |  |  | 2,070 |  |
| 4.091% Senior Notes due June 2029 |  | 472 |  |  | 475 |  |  | 471 |  |  | 459 |  |
| 3.125% Senior Notes due July 2029 |  | 163 |  |  | 147 |  |  | 163 |  |  | 139 |  |
| 8.25% Senior Notes due December 2029 |  | 500 |  |  | 544 |  |  | 500 |  |  | 537 |  |
| 4.125% Senior Notes due January 2031 |  | 275 |  |  | 254 |  |  | 275 |  |  | 245 |  |
| 3.375% Senior Notes due July 2031 |  | 72 |  |  | 61 |  |  | 72 |  |  | 58 |  |
| 8.50% Senior Notes due July 2031 |  | 500 |  |  | 547 |  |  | 500 |  |  | 538 |  |
| 9.625% Senior Notes due December 2032 |  | 750 |  |  | 871 |  |  | 750 |  |  | 855 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 494 |  |  | 489 |  |  | 472 |  |
|  |  | $ | 5,705 |  |  | $ | 6,517 |  |  | $ | 5,704 |  |  | $ | 6,342 |  |
| Less: unamortized debt issuance costs |  | (29) |  |  | — |  |  | (30) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 5,676 |  |  | $ | 6,517 |  |  | $ | 5,674 |  |  | $ | 6,342 |  |
| Less: current portion of debt, net of debt issuance costs |  | (479) |  |  | (478) |  |  | (479) |  |  | (476) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,197 |  |  | $ | 6,039 |  |  | $ | 5,195 |  |  | $ | 5,866 |  |

[0001137789-24-000182:notes:109]
For the balance of the Company’s financial instruments, primarily accounts receivable, accounts payable and financial liabilities included within accrued expenses, the carrying value approximates fair value due to their short-term nature. If measured at fair value in the Condensed Consolidated Balance Sheets, these other financial instruments would be classified in Level 2 or Level 3 of the fair value hierarchy. 
The Company’s non-financial assets, such as goodwill and property, plant and equipment, are recorded at cost. Fair value adjustments are made to these non-financial assets in the period an impairment charge is recognized. If measured at fair value in the Condensed Consolidated Balance Sheets, these would generally be classified in Level 3 of the fair value hierarchy.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001137789-24-000182:notes:110]
[same as prior period, unchanged from 0001137789-24-000034:notes:125]

[0001137789-24-000182:notes:111]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 211,455,486 shares were outstanding as of September 27, 2024, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of September 27, 2024.

[0001137789-24-000182:notes:112]
[same as prior period, unchanged from 0001137789-24-000034:notes:130]

[0001137789-24-000182:notes:113]
[same as prior period, unchanged from 0001137789-24-000034:notes:131]

[0001137789-24-000182:notes:114]
As of September 27, 2024, $1.9 billion remained available for repurchase under the existing repurchase authorization limit approved by the Board of Directors. The number of ordinary shares repurchased for tax withholding related to the vesting of equity awards was 0.3 million and the dollar value of shares repurchased was $28 million for the three months ended September 27, 2024,


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001137789-24-000182:notes:115]
Revenue
The following table provides information about disaggregated revenue by sales channel and country for the Company’s single reportable segment:

[0001137789-24-000182:notes:116]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 27, 2024 |  | September 29, 2023 |  |  |
| Revenues by Channel |  |  |  |  |  |  |
| OEMs |  | $ | 1,749 |  |  | $ | 1,032 |  |  |  |
| Distributors |  | 248 |  |  | 266 |  |  |  |
| Retailers |  | 171 |  |  | 156 |  |  |  |
| Total |  | $ | 2,168 |  |  | $ | 1,454 |  |  |  |

[0001137789-24-000182:notes:117]
| Revenue by Country (1): |  |  |  |  |  |  |
| Singapore |  | $ | 860 |  |  | $ | 808 |  |  |  |
| United States |  | 1,097 |  |  | 455 |  |  |  |
| The Netherlands |  | 210 |  |  | 188 |  |  |  |
| Other |  | 1 |  |  | 3 |  |  |  |
| Total |  | $ | 2,168 |  |  | $ | 1,454 |  |  |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001137789-24-000182:notes:118]
[same as prior period, unchanged from 0001137789-24-000034:notes:136]

[0001137789-24-000182:notes:119]
[same as prior period, unchanged from 0001137789-24-000034:notes:137]

[0001137789-24-000182:notes:120]
[same as prior period, unchanged from 0001137789-24-000034:notes:138]

[0001137789-24-000182:notes:121]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product warranty return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the three months ended September 27, 2024 and September 29, 2023 were as follows:

[0001137789-24-000182:notes:122]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 27, 2024 |  | September 29, 2023 |
| Balance, beginning of period |  | $ | 149 |  |  | $ | 168 |  |
| Warranties issued |  | 15 |  |  | 13 |  |
| Repairs and replacements |  | (22) |  |  | (18) |  |
| Changes in liability for pre-existing warranties, including expirations |  | (1) |  |  | 13 |  |
| Balance, end of period |  | $ | 141 |  |  | $ | 176 |  |


## us-gaap:EarningsPerShareTextBlock

[0001137789-24-000182:notes:123]
(Loss) Per Share
The following table sets forth the computation of basic and diluted net income (loss) per share attributable to the shareholders of the Company:

[0001137789-24-000182:notes:124]
|  |  | For the Three Months Ended |
| (In millions, except per share data) |  | September 27, 2024 |  | September 29, 2023 |
| Numerator: |  |  |  |  |
| Net income (loss) |  | $ | 305 |  |  | $ | (184) |  |
| Number of shares used in per share calculations: |  |  |  |  |
| Total shares for purposes of calculating basic net income (loss) per share |  | 211 |  |  | 208 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |
| Employee equity award plans |  | 2 |  |  | — |  |
| 2028 Notes if-converted shares |  | 3 |  |  | — |  |
| Total shares for purposes of calculating diluted net income (loss) per share |  | 216 |  |  | 208 |  |
| Net income (loss) per share |  |  |  |  |
| Basic |  | $ | 1.45 |  |  | $ | (0.88) |  |
| Diluted |  | 1.41 |  |  | (0.88) |  |

[0001137789-24-000182:notes:125]
All potentially dilutive securities that could have an anti-dilutive effect on the calculation of the earnings per share have been excluded for the periods presented. The weighted average anti-dilutive shares that were excluded from the computation of diluted net income (loss) per share were not material for the three months ended September 27, 2024 and 6 million for the three months ended September 29, 2023


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001137789-24-000182:notes:126]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001137789-24-000182:notes:127]
Litigation

[0001137789-24-000182:notes:128]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material

[0001137789-24-000182:notes:129]
Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgment in favor of Seagate on April 19, 2022, following a jury trial. The parties filed post-trial motions with the district court, which were denied. An appeal to the Federal Circuit is pending. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

[0001137789-24-000182:notes:130]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the U.S. District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendant misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, and additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 8, 2022, the court entered an Amended Stipulation and Order of Dismissal with Prejudice to dismiss all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment under the Foreign Trade Antitrust Improvement Act (“FTAIA Motion”) against Seagate’s antitrust claims, and on October 14, 2022, the Seagate Entities filed their corresponding opposition. On May 15, 2023, the court issued a ruling that Seagate’s antitrust claims can proceed as to suspension assemblies that enter the United States but not as to suspension assembles that do not enter the United States. On July 28, 2023, the District Court initiated a reconsideration of this ruling and requested further briefing. On November 17, 2023, the Court granted NHK’s FTAIA Motion and denied Seagate’s Motion for Leave to Amend the Complaint. Seagate filed a motion on December 15, 2023 for the Court to certify the ruling for interlocutory appeal. On April 22, 2024, the District Court granted in part and denied in part Seagate’s motion to certify for interlocutory appeal the Court’s ruling on NHK’s FTAIA Motion. On May 2, 2024, Seagate filed a Petition for Permission to Appeal to the Ninth Circuit. On July 18, 2024, the United States Court of Appeals for the Ninth Circuit issued an order granting Seagate’s Petition for Permission to Appeal. The FTAIA issue is now on appeal with the Ninth Circuit.

[0001137789-24-000182:notes:131]
In re Seagate Technology Holdings plc Securities Litigation. A putative class action lawsuit alleging violations of the federal securities laws, UA Local 38 Defined Contribution Pension Plan, et al. v. Seagate Technology Holdings PLC, et al., was filed on July 10, 2023, in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The complaint alleged that it was a securities class action on behalf of all purchasers of Seagate common stock between September 15, 2020 and October 25, 2022, inclusive, and asserted claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b5-1. The complaint sought unspecified monetary damages and other relief. A second action, Public Employees’ Retirement System of Mississippi v. Seagate Technology Holdings plc, William David Mosley, and Gianluca Romano, was filed on July 26, 2023, asserting similar claims. The cases were consolidated on September 25, 2023. On October 19, 2023, plaintiffs filed an amended complaint asserting similar claims with a putative class period of September 14, 2020 through April 19, 2023. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint. On August 8, 2024, the Court granted the Company’s motion to dismiss, with leave to amend. On September 12, 2024, the Plaintiffs filed an amended complaint. The Company believes that the asserted claims are without merit and intends to vigorously defend the case.

[0001137789-24-000182:notes:132]
Godo Kaisha IP Bridge 1 v. Seagate Technology LLC, Seagate Technology (US) Holding, Inc., Seagate Technology (Thailand) Limited, Seagate Singapore International Headquarters Ltd., Seagate Technology (Netherlands) B.V. On March 15, 2024, a patent infringement action was filed by Godo Kaisha IP Bridge 1 (“IP Bridge”) against Seagate in U.S. District Court for the District of Delaware. The complaint alleges patent infringement by Seagate of three U.S. patents. On June 7, 2024, Seagate filed a motion to dismiss and a motion to transfer venue to Minnesota. On July 8, 2024, IP Bridge filed a First Amended Complaint alleging patent infringement by Seagate of six additional patents. IP Bridge is seeking damages as well as additional relief. On August 5, 2024, Seagate filed a motion to dismiss in part IP Bridge’s First Amended Complaint. On September 4, 2024, Seagate won its motion to transfer the case to the District Court in Minnesota. Seagate’s motion to dismiss on the remaining claims is pending. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

[0001137789-24-000182:notes:133]
Environmental Matters

[0001137789-24-000182:notes:134]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of

[0001137789-24-000182:notes:135]
hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001137789-24-000182:notes:136]
The Company has established an environmental management system and continually reviews and updates environmental policies and standard operating procedures for operations worldwide as needed. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001137789-24-000182:notes:137]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001137789-24-000182:notes:138]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001137789-24-000182:notes:139]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fail to comply with the substance restrictions, recycle content requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001137789-24-000182:notes:140]
BIS Settlement

[0001137789-24-000182:notes:141]
On April 18, 2023, the Company’s subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd (collectively, “Seagate”), entered into a settlement agreement (the “Settlement Agreement”) with the U.S. Department of Commerce’s Bureau of Industry and Security (“BIS”) that resolved BIS’ allegations regarding Seagate’s sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, Seagate agreed to pay $300 million to BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. Seagate also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the U.S. Export Administration Regulations (“EAR”), including one audit by an unaffiliated third-party consultant chosen by Seagate with expertise in U.S. export control laws and two internal audits, and has completed the first audit. The Settlement Agreement also included a denial order that is suspended and will be waived five years after the date of the order issued under the Settlement Agreement, provided that Seagate has made full and timely payments under the Settlement Agreement and timely completed the audit requirements. While Seagate is in compliance with and upon successful compliance in full with the terms of the Settlement Agreement, BIS agreed it will not initiate any further administrative proceedings against Seagate in connection with any violation of the EAR arising out of the transactions detailed in the Settlement Agreement.

[0001137789-24-000182:notes:142]
While Seagate believed that it complied with all relevant export control laws at the time it made the hard disk drive sales at issue, Seagate determined that engaging with BIS and settling this matter was in the best interest of the Company, its customers, and its shareholders. In determining to engage with BIS and resolve this matter through a settlement agreement, the Company considered a number of factors, including the risks and cost of protracted litigation involving the U.S. government, and the size of the potential penalty and the Company’s desire to focus on current business challenges and long-term business strategy. The Settlement Agreement includes a finding that the Company incorrectly interpreted the regulation at issue to require evaluation of only the last stage of Seagate’s hard disk drive manufacturing process rather than the entire process. As part of this settlement, Seagate has agreed not to contest BIS’ determination that the sales in question did not comply with the U.S. EAR.

[0001137789-24-000182:notes:143]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $180 million were included in Accrued expense and Other non-current liabilities, respectively, on the Condensed Consolidated Balance Sheets as of September 27, 2024. For the three months ended September 27, 2024, $15 million was paid and reported as an outflow from operating activities in its Condensed Consolidated Statements of Cash Flows.

[0001137789-24-000182:notes:144]
Other Matters 
From time to time, arising in the normal course of business, the Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company expects to be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:CommitmentsDisclosureTextBlock

[0001137789-24-000182:notes:145]
Commitments
Unconditional Long-Term Purchase Obligations. As of September 27, 2024, the Company had unconditional long-term purchase obligations of approximately $53 million. The Company expects the commitment to be paid to total $28 million, $16 million, $6 million and $3 million for fiscal years 2026, 2027, 2028 and 2029 respectively. In addition, the Company also had certain long-term market share based inventory purchase commitments as of September 27, 2024.

[0001137789-24-000182:notes:146]
The Company recorded order cancellation fees to terminate certain purchase commitments related to the purchase of inventory components and equipment. As of September 27, 2024, cumulative unpaid order cancellation fees on the Condensed Consolidated Balance Sheets were $58 million, with $32 million in Accounts payable and $26 million in Accrued expenses, all of which is expected to be paid within one year.


## us-gaap:SubsequentEventsTextBlock

[0001137789-24-000182:notes:147]
Subsequent Event
Dividend Declared

[0001137789-24-000182:notes:148]
On October 22, 2024, the Board of Directors of the Company declared a quarterly cash dividend of $0.72 per share, which will be payable on January 6, 2025 to shareholders of record as of the close of business on December 15, 2024.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001137789-24-000182:notes:149]
The table below summarizes the material terms of trading arrangements adopted by any of our executive officers or directors during the September 2024 quarter. All of the trading arrangements listed below are intended to satisfy the affirmative defense of Rule 10b5-1(c).

[0001137789-24-000182:notes:150]
| Name | Title | Date of Adoption | End Date¹ | Aggregate number of ordinary shares to be sold pursuant to the trading agreement |
| Gianluca Romano | Executive Vice President and Chief Financial Officer | August 23, 2024 | March 31, 2025 | 68,954 |

[0001137789-24-000182:notes:151]
¹ The plan will expire on the earlier of the end date or the completion of all transactions under the trading arrangement.
