# STX notes — 0001193125-17-148855


## invest:InvestmentTableTextBlock

[0001193125-17-148855:notes:1]
[same as prior period, unchanged from 0001193125-17-019732:notes:1]

[0001193125-17-148855:notes:2]
[same as prior period, unchanged from 0001193125-17-019732:notes:2]

[0001193125-17-148855:notes:3]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of March 31, 2017:

[0001193125-17-148855:notes:4]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,214 |  |  | $ | — |  |  | $ | 1,214 |  |
| Time deposits and certificates of deposit |  | 503 |  |  | — |  |  | 503 |  |
| Total |  | $ | 1,717 |  |  | $ | — |  |  | $ | 1,717 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 1,712 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 5 |  |
| Total |  |  |  |  |  |  |  | $ | 1,717 |  |


## stx:ScheduleOfShareRepurchasesTableTextBlock

[0001193125-17-148855:notes:5]
The following table sets forth information with respect to repurchases of the Company’s shares during the nine months ended March 31, 2017:

[0001193125-17-148855:notes:6]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Repurchases of ordinary shares |  | 7 |  |  | $ | 248 |  |
| Tax withholding related to vesting of equity awards |  | 1 |  |  | 25 |  |
| Total |  | 8 |  |  | $ | 273 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-17-148855:notes:7]
[same as prior period, unchanged from 0001193125-17-019732:notes:7]

[0001193125-17-148855:notes:8]
[same as prior period, unchanged from 0001193125-17-019732:notes:8]

[0001193125-17-148855:notes:9]
[same as prior period, unchanged from 0001193125-17-019732:notes:9]

[0001193125-17-148855:notes:10]
[same as prior period, unchanged from 0001193125-17-019732:notes:10]

[0001193125-17-148855:notes:11]
[same as prior period, unchanged from 0001193125-17-019732:notes:11]

[0001193125-17-148855:notes:12]
[same as prior period, unchanged from 0001193125-17-019732:notes:12]

[0001193125-17-148855:notes:13]
[same as prior period, unchanged from 0001193125-17-019732:notes:13]

[0001193125-17-148855:notes:14]
[same as prior period, unchanged from 0001193125-17-019732:notes:14]

[0001193125-17-148855:notes:15]
[same as prior period, unchanged from 0001193125-17-019732:notes:15]

[0001193125-17-148855:notes:16]
[same as prior period, unchanged from 0001193125-17-019732:notes:16]

[0001193125-17-148855:notes:17]
[same as prior period, unchanged from 0001193125-17-019732:notes:17]

[0001193125-17-148855:notes:18]
[same as prior period, unchanged from 0001193125-17-019732:notes:18]

[0001193125-17-148855:notes:19]
[same as prior period, unchanged from 0001193125-17-019732:notes:19]

[0001193125-17-148855:notes:20]
[same as prior period, unchanged from 0001193125-17-019732:notes:20]


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-17-148855:notes:21]
[same as prior period, unchanged from 0001193125-17-019732:notes:21]

[0001193125-17-148855:notes:22]
[same as prior period, unchanged from 0001193125-17-019732:notes:22]

[0001193125-17-148855:notes:23]
[same as prior period, unchanged from 0001193125-17-019732:notes:23]


## us-gaap:DebtDisclosureTextBlock

[0001193125-17-148855:notes:24]
Debt

[0001193125-17-148855:notes:25]
Short-Term Borrowings

[0001193125-17-148855:notes:26]
The credit agreement entered into by the Company and its subsidiary Seagate HDD Cayman on January 18, 2011 and subsequently amended (the "Revolving Credit Facility") provides the Company with a $700 million senior secured revolving credit facility. The term of the Revolving Credit Facility is through January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Revolving Credit Facility) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. The loans made under the Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing, and for the issuance of letters of credit up to a sub-limit of $75 million.

[0001193125-17-148855:notes:27]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio.  On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to allow for higher net leverage levels. The Company was in compliance with the modified covenants as of March 31, 2017 and expects to be in compliance for the next 12 months.

[0001193125-17-148855:notes:28]
As of March 31, 2017, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

[0001193125-17-148855:notes:29]
Long-Term Debt

[0001193125-17-148855:notes:30]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2017 quarter, the Company repurchased $39 million aggregate principal amount of the 2018 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately $1 million during the three and nine months ended March 31, 2017, which is included in Other, net on the Condensed Consolidated Statements of Operations.

[0001193125-17-148855:notes:31]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman, and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. On March 15, 2017, the Company exercised its call option by providing notice of the redemption to the trustee of its intention to redeem all of its remaining outstanding 2021 Notes. The Notes will be redeemed on May 1, 2017 (the "Redemption Date") at a redemption price equal to $102.333 per $100 principal amount of the 2021 Notes redeemed plus accrued interest to the Redemption Date. As a result, the 2021 Notes are classified as Current portion of long-term debt on the Company's Condensed Consolidated Balance Sheet at March 31, 2017.

[0001193125-17-148855:notes:32]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). On February 3, 2017, Seagate HDD Cayman issued, in a private placement, $750 million in aggregate principal amount of 4.25% Senior Notes which will mature on March 1, 2022. The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year, commencing on September 1, 2017. At any time before February 1, 2022, Seagate HDD Cayman may redeem some or all of the 2022 Notes at a 'make whole' redemption price, plus accrued and unpaid interest, if any. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the 2022 Notes redeemed, plus (2) the excess, if any, of (a) the sum of the present values of the remaining scheduled payments of principal and interest on the 2022 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 40 basis points, minus accrued and unpaid interest, if any, on the 2022 Notes being redeemed to, but excluding, the redemption date over (b) the principal amount of the 2022 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the 2022 Notes being redeemed to, but excluding, the redemption date. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-17-148855:notes:33]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2017 quarter, the Company repurchased $34 million aggregate principal amount of the 2023 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded an immaterial loss on the repurchase during the three and nine months ended March 31, 2017, which is included in Other, net on the Condensed Consolidated Statements of Operations.

[0001193125-17-148855:notes:34]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”).  On February 3, 2017, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 4.875% Senior Notes which will mature on March 1, 2024. The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year, commencing on September 1, 2017. At any time before January 1, 2024, Seagate HDD Cayman may redeem some or all of the 2024 Notes at a 'make whole' redemption price, plus accrued and unpaid interest, if any. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the 2024 Notes redeemed, plus (2) the excess, if any, of (a) the sum of the present values of the remaining scheduled payments of principal and interest on the 2024 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 45 basis points, minus accrued and unpaid interest, if any, on the 2024 Notes being redeemed to, but excluding, the redemption date over (b) the principal amount of the 2024 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the 2024 Notes being redeemed to, but excluding, the redemption date. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-17-148855:notes:35]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2017 quarter, the Company repurchased $20 million aggregate principal amount of the 2025 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded a gain on the repurchase of approximately $1 million during the three and nine months ended March 31, 2017, which is included in Other, net on the Condensed Consolidated Statements of Operations.

[0001193125-17-148855:notes:36]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2017 quarter, the Company repurchased $4 million aggregate principal amount of the 2027 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded an immaterial gain on the repurchase during the three and nine months ended March 31, 2017, which is included in Other, net on the Condensed Consolidated Statements of Operations.

[0001193125-17-148855:notes:37]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-17-148855:notes:38]
At March 31, 2017, future principal payments on long-term debt were as follows (in millions):

[0001193125-17-148855:notes:39]
| Fiscal Year |  | Amount |
| Remainder of 2017 |  | $ | 158 |  |
| 2018 |  | — |  |
| 2019 |  | 761 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| Thereafter |  | 4,367 |  |
| Total |  | $ | 5,286 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-17-148855:notes:40]
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity market risks relating to its ongoing business operations.  The Company enters into foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses denominated in foreign currencies. The Company's accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments.  The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The changes in the fair value of the effective portions of designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings.  Derivatives that are not designated as hedging instruments and the ineffective portions of cash flow hedges are adjusted to fair value through earnings. The amounts of net unrealized loss on cash flow hedges were $1 million and $2 million as of March 31, 2017 and July 1, 2016, respectively.

[0001193125-17-148855:notes:41]
The Company dedesignates its cash flow hedges when the forecasted hedged transactions are realized or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company did not recognize any net gains or losses related to the loss of hedge designation on discontinued cash flow hedges during the three months ended March 31, 2017. As of March 31, 2017, the Company’s existing foreign currency forward exchange contracts mature within 12 months. The deferred amount currently recorded in Accumulated other comprehensive loss expected to be recognized into earnings over the next 12 months is immaterial.

[0001193125-17-148855:notes:42]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of March 31, 2017 and July 1, 2016:

[0001193125-17-148855:notes:43]
|  |  | As of March 31, 2017 |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| Singapore Dollars |  | $ | — |  |  | $ | 22 |  |
| Thai Baht |  | — |  |  | 22 |  |
| British Pound Sterling |  | 19 |  |  | 8 |  |

[0001193125-17-148855:notes:44]
[same as prior period, unchanged from 0001193125-17-019732:notes:42]

[0001193125-17-148855:notes:45]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plan—the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees. As of March 31, 2017, the notional investments underlying the TRS amounted to $104 million. The original contract term of the TRS was through January 2016, and was settled on a monthly basis, therefore limiting counterparty performance risk. The Company renewed the contract term through January 2018 under materially the same terms. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001193125-17-148855:notes:46]
The following tables show the Company’s derivative instruments measured at fair value as reflected in the Condensed Consolidated Balance Sheet as of March 31, 2017 and July 1, 2016:

[0001193125-17-148855:notes:47]
|  |  | As of March 31, 2017 |
|  |  | Asset Derivatives |  | Liability Derivatives |
| (Dollars in millions) |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (2 | ) |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 2 |  |  | Accrued expenses |  | — |  |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 2 |  |  |  |  | $ | (2 | ) |

[0001193125-17-148855:notes:48]
[same as prior period, unchanged from 0001193125-17-019732:notes:46]

[0001193125-17-148855:notes:49]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statement of Comprehensive Income (Loss) and the Condensed Consolidated Statement of Operations for the three and nine months ended March 31, 2017:

[0001193125-17-148855:notes:50]
[same as prior period, unchanged from 0001193125-17-019732:notes:48]

[0001193125-17-148855:notes:51]
|  |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
| Derivatives Designated as Hedging Instruments |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | $ | 1 |  |  | $ | (2 | ) |  | Cost of revenue |  | $ | (1 | ) |  | $ | (2 | ) |  | Cost of revenue |  | $ | — |  |  | $ | — |  |

[0001193125-17-148855:notes:52]
|  |  | Location of Gain or(Loss) Recognized inIncome on Derivative |  | Amount of Gain or(Loss) Recognized inIncome on Derivative |
| Derivatives Not Designated as Hedging Instruments |  |  | For the Three Months | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 4 |  | $ | 1 |  |
| Total return swap |  | Operating expenses |  | 4 |  | 8 |  |

[0001193125-17-148855:notes:53]
[same as prior period, unchanged from 0001193125-17-019732:notes:51]

[0001193125-17-148855:notes:54]
| (a) | The amount of gain or (loss) recognized in income represents less than $1 million related to the ineffective portion of the hedging relationships and less than $1 million related to the amount excluded from the assessment of hedge effectiveness for the three and nine months ended March 31, 2017, respectively. |

[0001193125-17-148855:notes:55]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statement of Comprehensive Income (Loss) and the Condensed Consolidated Statement of Operations for the three and nine months ended April 1, 2016:

[0001193125-17-148855:notes:56]
[same as prior period, unchanged from 0001193125-17-019732:notes:54]

[0001193125-17-148855:notes:57]
| Derivatives Designated as Hedging Instruments |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
|  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | $ | (1 | ) |  | $ | (3 | ) |  | Cost of revenue |  | $ | — |  |  | $ | (2 | ) |  | Cost of revenue |  | $ | — |  |  | $ | — |  |

[0001193125-17-148855:notes:58]
|  |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
| Derivatives Not Designated as Hedging Instruments |  |  | For the Three Months | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | — |  | $ | (4 | ) |
| Total return swap |  | Operating expenses |  | 1 |  | (3 | ) |

[0001193125-17-148855:notes:59]
| (a) | The amount of gain or (loss) recognized in income represents less than $1 million related to the ineffective portion of the hedging relationships and less than $1 million related to the amount excluded from the assessment of hedge effectiveness for the three and nine months ended April 1, 2016, respectively. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-17-148855:notes:60]
[same as prior period, unchanged from 0001193125-17-019732:notes:58]

[0001193125-17-148855:notes:61]
The Company recorded approximately $37 million and $110 million of share-based compensation expense during the three and nine months ended March 31, 2017, respectively. The Company recorded approximately $30 million and $95 million of share-based compensation expense during the three and nine months ended April 1, 2016, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001193125-17-148855:notes:62]
[same as prior period, unchanged from 0001193125-17-019732:notes:60]

[0001193125-17-148855:notes:63]
Basic earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period. Diluted earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period and the number of additional shares that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding options, unvested restricted stock units and shares to be purchased under the Employee Stock Purchase Plan ("ESPP"). The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in fair market value of the Company’s share price can result in a greater dilutive effect from potentially dilutive securities. The following table sets forth the computation of basic and diluted net income (loss) per share attributable to the shareholders of the Company:

[0001193125-17-148855:notes:64]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (In millions, except per share data) |  | March 31, 2017 |  | April 1, 2016 |  | March 31, 2017 |  | April 1, 2016 |
| Numerator: |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 194 |  |  | $ | (21 | ) |  | $ | 658 |  |  | $ | 178 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income (loss) per share |  | 296 |  |  | 298 |  |  | 297 |  |  | 300 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | 4 |  |  | — |  |  | 2 |  |  | 3 |  |
| Total shares for purpose of calculating diluted net income (loss) per share |  | 300 |  |  | 298 |  |  | 299 |  |  | 303 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.66 |  |  | $ | (0.07 | ) |  | $ | 2.22 |  |  | $ | 0.59 |  |
| Diluted |  | $ | 0.65 |  |  | $ | (0.07 | ) |  | $ | 2.20 |  |  | $ | 0.59 |  |

[0001193125-17-148855:notes:65]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income (loss) per share were 1 million and  2 million for the three and nine months ended March 31, 2017, respectively, and 4 million and 2 million for the three and nine months ended April 1, 2016, respectively.


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001193125-17-148855:notes:66]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,212 |  |  | $ | 500 |  |  | $ | — |  |  | $ | 1,712 |  |
| Other current assets |  | 2 |  |  | 5 |  |  | — |  |  | 7 |  |
| Total assets |  | $ | 1,214 |  |  | $ | 505 |  |  | $ | — |  |  | $ | 1,719 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | (2 | ) |  | $ | — |  |  | $ | (2 | ) |
| Total liabilities |  | $ | — |  |  | $ | (2 | ) |  | $ | — |  |  | $ | (2 | ) |

[0001193125-17-148855:notes:67]
[same as prior period, unchanged from 0001193125-17-019732:notes:65]


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-17-148855:notes:68]
[same as prior period, unchanged from 0001193125-17-019732:notes:66]

[0001193125-17-148855:notes:69]
[same as prior period, unchanged from 0001193125-17-019732:notes:67]

[0001193125-17-148855:notes:70]
[same as prior period, unchanged from 0001193125-17-019732:notes:68]

[0001193125-17-148855:notes:71]
[same as prior period, unchanged from 0001193125-17-019732:notes:69]

[0001193125-17-148855:notes:72]
[same as prior period, unchanged from 0001193125-17-019732:notes:70]

[0001193125-17-148855:notes:73]
[same as prior period, unchanged from 0001193125-17-019732:notes:71]

[0001193125-17-148855:notes:74]
[same as prior period, unchanged from 0001193125-17-019732:notes:72]

[0001193125-17-148855:notes:75]
[same as prior period, unchanged from 0001193125-17-019732:notes:73]

[0001193125-17-148855:notes:76]
[same as prior period, unchanged from 0001193125-17-019732:notes:74]

[0001193125-17-148855:notes:77]
[same as prior period, unchanged from 0001193125-17-019732:notes:75]

[0001193125-17-148855:notes:78]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of March 31, 2017:

[0001193125-17-148855:notes:79]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,212 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,212 |  |
| Time deposits |  | — |  |  | 500 |  |  | — |  |  | 500 |  |
| Total cash equivalents and short-term investments |  | 1,212 |  |  | 500 |  |  | — |  |  | 1,712 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Time deposits and certificates of deposit |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Derivative Assets |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Total assets |  | $ | 1,214 |  |  | $ | 505 |  |  | $ | — |  |  | $ | 1,719 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | (2 | ) |  | $ | — |  |  | $ | (2 | ) |
| Total liabilities |  | $ | — |  |  | $ | (2 | ) |  | $ | — |  |  | $ | (2 | ) |

[0001193125-17-148855:notes:80]
In the December 2016 quarter, the Company reclassified demand deposits from certificates of deposit and money market funds to cash. The corresponding prior period amounts were also reclassified to conform to that period's presentation. This reclassification did not result in any change to the cash and cash equivalents balance as reported in the Condensed Consolidated Balance Sheets and Statements of Cash Flows for all periods presented.

[0001193125-17-148855:notes:81]
[same as prior period, unchanged from 0001193125-17-019732:notes:79]

[0001193125-17-148855:notes:82]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 230 |  |  | $ | — |  |  | $ | — |  |  | $ | 230 |  |
| Corporate bonds |  | — |  |  | 6 |  |  | — |  |  | — |  |
| Total cash equivalents and short-term investments |  | 230 |  |  | 6 |  |  | — |  |  | 236 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Certificates of deposit |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Derivative assets |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets |  | $ | 232 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 246 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |
| Total liabilities |  | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |

[0001193125-17-148855:notes:83]
[same as prior period, unchanged from 0001193125-17-019732:notes:81]

[0001193125-17-148855:notes:84]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair values of all of its cash equivalents and short-term investments. For the cash equivalents and short-term investments in the Company's portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry standard data providers or other third party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of March 31, 2017, has not found it necessary to make any adjustments to the prices obtained. The Company's derivative financial instruments are also classified within Level 2. The Company's derivative financial instruments consist of foreign currency forward exchange contracts and the TRS. The Company recognizes derivative financial instruments in its consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001193125-17-148855:notes:85]
As of March 31, 2017 and July 1, 2016, the Company had no Level 3 assets or liabilities measured at fair value on a recurring basis.

[0001193125-17-148855:notes:86]
[same as prior period, unchanged from 0001193125-17-019732:notes:84]

[0001193125-17-148855:notes:87]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments primarily include cost basis investments representing those where the Company does not have the ability to exercise significant influence as well as equity method investments representing those where the Company does have the ability to exercise significant influence but does not have control. These investments are included in Other assets, net in the Condensed Consolidated Balance Sheets, and are periodically analyzed to determine whether or not there are indicators of impairment. The carrying value of the Company’s strategic investments at March 31, 2017 and July 1, 2016 totaled $99 million and $113 million, respectively, and consisted primarily of privately held equity securities without a readily determinable fair value.

[0001193125-17-148855:notes:88]
For the nine months ended March 31, 2017, the Company determined that a certain equity investment accounted for under the cost method was other-than-temporarily impaired, and recognized a charge of $25 million in order to write down the carrying amount of the investment to zero. The Company did not record any impairment charges in the three months ended March 31, 2017. For the three and nine months ended April 1, 2016, the Company recognized a charge of $2 million and $12 million, respectively in order to write down the carrying amount of the investment to zero. Since there was no active market for the equity securities of the investee, the Company estimated fair value of the investee by analyzing the underlying cash flows and future prospects of the investee. These amounts were recorded in Other, net in the Condensed Consolidated Statements of Operations.

[0001193125-17-148855:notes:89]
As of March 31, 2017, the Company has $47 million held for sale assets included in Other current assets on the Condensed Consolidated Balance Sheet, which primarily consisted of $37 million of land and building in Korea and the remainder of the balance comprised of property at another location (collectively, the “properties”). The respective properties to be sold met the criteria to be classified as held for sale during the March 2017 and December 2016 quarters. Depreciation related to the properties ceased as of the date these were determined to be held for sale.  During the three and nine month ended March 31, 2017, the Company recorded impairment charges of $26 million and $31 million, respectively in order to write down the carrying amount of such properties to their estimated fair values less costs to sell. The impairment charges were recorded in Operating expenses in the Condensed Consolidated Statements of Operations. The fair values were determined using Level 3 unobservable inputs including non-binding real estate brokers’ quotations and related market analyses.

[0001193125-17-148855:notes:90]
[same as prior period, unchanged from 0001193125-17-019732:notes:87]

[0001193125-17-148855:notes:91]
The Company’s debt is carried at amortized cost. The fair value of the Company’s debt is derived using the closing price as of the date of valuation, which takes into account the yield curve, interest rates and other observable inputs. Accordingly, these fair value measurements are categorized as Level 2. The following table presents the fair value and amortized cost of the Company’s debt in order of maturity:

[0001193125-17-148855:notes:92]
|  |  | March 31, 2017 |  | July 1, 2016 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 761 |  |  | $ | 781 |  |  | $ | 800 |  |  | $ | 804 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 162 |  |  | 158 |  |  | 164 |  |
| 4.25% Senior Notes due March 2022 |  | 748 |  |  | 743 |  |  | — |  |  | — |  |
| 4.75% Senior Notes due June 2023 |  | 956 |  |  | 961 |  |  | 990 |  |  | 857 |  |
| 4.875% Senior Notes due March 2024 |  | 496 |  |  | 491 |  |  | — |  |  | — |  |
| 4.75% Senior Notes due January 2025 |  | 975 |  |  | 958 |  |  | 995 |  |  | 795 |  |
| 4.875% Senior Notes due June 2027 |  | 695 |  |  | 654 |  |  | 698 |  |  | 514 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 446 |  |  | 489 |  |  | 357 |  |
|  |  | $ | 5,278 |  |  | $ | 5,196 |  |  | $ | 4,130 |  |  | $ | 3,491 |  |
| Less: debt issuance costs |  | (47 | ) |  | — |  |  | (39 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 5,231 |  |  | $ | 5,196 |  |  | $ | 4,091 |  |  | $ | 3,491 |  |
| Less: short-term borrowings and current portion of long-term debt |  | (158 | ) |  | (162 | ) |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 5,073 |  |  | $ | 5,034 |  |  | $ | 4,091 |  |  | $ | 3,491 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-17-148855:notes:93]
[same as prior period, unchanged from 0001193125-17-019732:notes:90]

[0001193125-17-148855:notes:94]
[same as prior period, unchanged from 0001193125-17-019732:notes:91]

[0001193125-17-148855:notes:95]
The changes in the carrying amount of goodwill for the nine months ended March 31, 2017, are as follows:

[0001193125-17-148855:notes:96]
| (Dollars in millions) |  | Amount |
| Balance at July 1, 2016 |  | $ | 1,237 |  |
| Goodwill acquired |  | — |  |
| Foreign currency translation effect |  | — |  |
| Balance at March 31, 2017 |  | $ | 1,237 |  |

[0001193125-17-148855:notes:97]
[same as prior period, unchanged from 0001193125-17-019732:notes:94]

[0001193125-17-148855:notes:98]
Other intangible assets consist primarily of existing technology, customer relationships and trade names acquired in business combinations. During March 2017 quarter, the in-process research and development ("IPR&D") of $14 million was completed and reclassified to existing technology. Intangibles are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization is charged to Operating expenses in the Condensed Consolidated Statements of Operations.

[0001193125-17-148855:notes:99]
The carrying value of other intangible assets subject to amortization as of March 31, 2017, is set forth in the following table:

[0001193125-17-148855:notes:100]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted-AverageRemaining Useful Life |
| Existing technology |  | $ | 311 |  |  | $ | (126 | ) |  | $ | 185 |  |  | 3.7 years |
| Customer relationships |  | 508 |  |  | (394 | ) |  | 114 |  |  | 3.2 years |
| Trade name |  | 29 |  |  | (20 | ) |  | 9 |  |  | 2.2 years |
| Other intangible assets |  | 29 |  |  | (14 | ) |  | 15 |  |  | 2.8 years |
| Total amortizable other intangible assets |  | $ | 877 |  |  | $ | (554 | ) |  | $ | 323 |  |  | 3.4 years |

[0001193125-17-148855:notes:101]
[same as prior period, unchanged from 0001193125-17-019732:notes:99]

[0001193125-17-148855:notes:102]
[same as prior period, unchanged from 0001193125-17-019732:notes:100]

[0001193125-17-148855:notes:103]
[same as prior period, unchanged from 0001193125-17-019732:notes:101]

[0001193125-17-148855:notes:104]
For the three and nine months ended March 31, 2017, the amortization expense of other intangible assets was $42 million and $126 million, respectively. For the three and nine months ended April 1, 2016, the amortization expense of other intangible assets was $44 million and $131 million, respectively. As of March 31, 2017, expected amortization expense for other intangible assets for each of the next five fiscal years and thereafter is as follows:

[0001193125-17-148855:notes:105]
| (Dollars in millions) |  | Amount |
| Remainder of 2017 |  | $ | 42 |  |
| 2018 |  | 109 |  |
| 2019 |  | 71 |  |
| 2020 |  | 53 |  |
| 2021 |  | 25 |  |
| Thereafter |  | 23 |  |
| Total |  | $ | 323 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-17-148855:notes:106]
[same as prior period, unchanged from 0001193125-17-019732:notes:104]

[0001193125-17-148855:notes:107]
The Company recorded an income tax provision of $18 million and $37 million in the three and nine months ended March 31, 2017. The income tax provision for the three and nine months ended March 31, 2017 included approximately $8 million of net discrete tax expense and approximately $3 million of net discrete tax expense, respectively. These discrete items are primarily associated with changes in valuation allowances offset by release of tax reserves due to the expiration of certain statutes of limitation, and prior year tax adjustments.

[0001193125-17-148855:notes:108]
The Company's income tax provision recorded for the three and nine months ended March 31, 2017 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) restructuring expenses with no associated tax benefits, and (iii) a net decrease in valuation allowance for certain deferred tax assets.

[0001193125-17-148855:notes:109]
During the nine months ended March 31, 2017, the Company’s unrecognized tax benefits excluding interest and penalties increased by approximately $6 million to $76 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $76 million at March 31, 2017, subject to certain future valuation allowance reversals. During the 12 months beginning April 1, 2017, the Company expects that its unrecognized tax benefits could be reduced by approximately $13 million, primarily as a result of the expiration of certain statutes of limitation.

[0001193125-17-148855:notes:110]
The Company recorded an income tax provision of $30 million and $43 million in the three and nine months ended April 1, 2016. The income tax provision for the nine months ended April 1, 2016 included approximately $2 million of net discrete tax provision associated with prior year tax adjustments offset by the release of tax reserves due to the expiration of certain statutes of limitation.

[0001193125-17-148855:notes:111]
The Company’s income tax provision recorded for the three and nine months ended April 1, 2016 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a net decrease in valuation allowance for certain U.S. deferred tax assets.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-17-148855:notes:112]
The fair value and amortized cost of the Company’s investments classified as available-for-sale at March 31, 2017, by remaining contractual maturity were as follows:

[0001193125-17-148855:notes:113]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 1,717 |  |  | $ | 1,717 |  |
| Due in 1 to 5 years |  | — |  |  | — |  |
| Thereafter |  | — |  |  | — |  |
| Total |  | $ | 1,717 |  |  | $ | 1,717 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001193125-17-148855:notes:114]
Legal, Environmental and Other Contingencies

[0001193125-17-148855:notes:115]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001193125-17-148855:notes:116]
Intellectual Property Litigation

[0001193125-17-148855:notes:117]
Convolve, Inc. ("Convolve") and Massachusetts Institute of Technology ("MIT") v. Seagate Technology LLC, et al.— On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the "'635 patent") and U.S. Patent No. 5,638,267 (the "'267 patent"), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringed U.S. Patent No. 6,314,473 (the "'473 patent"). The district court ruled in 2010 that the '267 patent was out of the case.

[0001193125-17-148855:notes:118]
On August 16, 2011, the district court granted in part and denied in part the Company's motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court's summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court's summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent. On July 11, 2014, the district court granted the Company's further summary judgment motion regarding the '473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-17-148855:notes:119]
Alexander Shukh v. Seagate Technology —On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination and wrongful failure to name him as an inventor on certain Seagate patents. On March 31, 2014, the district court granted Seagate’s summary judgment motion. Mr. Shukh filed a notice of appeal on April 7, 2014. On October 2, 2015, the U.S. Court of Appeals for the Federal Circuit vacated and remanded the district court’s grant of summary judgment on Mr. Shukh’s claim for correction of inventorship and affirmed the district court’s grant of summary judgment as to all other claims. On October 29, 2015, Mr. Shukh filed a petition for rehearing en banc with the court of appeals; the petition was denied on December 17, 2015. On March 16, 2016, Shukh filed a petition for writ of certiorari to the U.S. Supreme Court; the petition was denied on June 27, 2016. On March 30, 2017, the parties entered into a confidential settlement to resolve this matter. This settlement did not have a material impact on the Company’s condensed consolidated financial statements.

[0001193125-17-148855:notes:120]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.—On June 5, 2013, Enova Technology Corporation (“Enova”) filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995 (the '"995 patent"), “Cryptographic Device,” and U.S. Patent No. 7,900,057 (the "'057 patent"), “Cryptographic Serial ATA Apparatus and Method.” The Company believes the claims are without merit and intends to vigorously defend this case. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the ‘995 and ‘057 patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ‘057 patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 patent are held unpatentable. Enova has appealed PTAB’s decisions on the ‘995 patent and the ‘057 patent to the U.S. Court of Appeals for the Federal Circuit. Oral argument for the appeal from PTAB’s decision on the ‘995 patent was held on March 13, 2017, at the court of appeals. On March 20, 2017, the court of appeals issued its judgment affirming PTAB's decision on the '995 patent. A hearing before the court of appeals for the appeal from PTAB’s decision on the ‘057 patent has not yet been scheduled. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-17-148855:notes:121]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al.—On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-17-148855:notes:122]
Environmental Matters

[0001193125-17-148855:notes:123]
The Company's operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company's operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001193125-17-148855:notes:124]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001193125-17-148855:notes:125]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001193125-17-148855:notes:126]
While the Company's ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001193125-17-148855:notes:127]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.

[0001193125-17-148855:notes:128]
Other Matters

[0001193125-17-148855:notes:129]
The Company is involved in a number of other judicial, regulatory and administrative proceedings incidental to its business, and from time to time, the Company may be involved in various legal, regulatory or administrative investigation, negotiations or proceeding arising in the normal course of business.  Although occasional adverse decisions or settlements may occur or adverse actions taken against the Company, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-17-148855:notes:130]
Recently Issued Accounting Pronouncements

[0001193125-17-148855:notes:131]
In May 2014, August 2015, April 2016, May 2016 and December 2016, the Financial Accounting Standards Board ("FASB") issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, ASU 2016-12 (ASC Topic 606) Revenue from Contracts with Customers, Narrow-Scope Improvements and Practical Expedients, and ASU 2016-20 (ASC Topic 606) Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted for annual periods beginning after December 15, 2016, which is first quarter of fiscal 2018 for the Company. This standard may be applied retrospectively to all prior periods presented, or retrospectively with a cumulative adjustment to retained earnings in the year of adoption ("modified retrospective transition approach"). The Company is in the process of assessing the impact, on its condensed consolidated financial statements and plans to adopt the modified retrospective transition approach.

[0001193125-17-148855:notes:132]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. The Company is required to adopt the guidance in the first quarter of fiscal 2018. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company is in the process of finalizing its assessment of the impact of this ASU, which is not expected to have a material impact on its condensed consolidated financial statements.

[0001193125-17-148855:notes:133]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments - Overall Recognition and Measurement of Financial Assets and Financial Liabilities. The amendments in this ASU require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted for only certain portions of the ASU. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-17-148855:notes:134]
In February 2016, the FASB issued ASU 2016-02 (ASC Topic 842), Leases. The ASU amends a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The Company is required to adopt the guidance in the first quarter of fiscal 2020. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-17-148855:notes:135]
In March 2016, the FASB issued ASU 2016-09 (ASC Topic 718), Stock Compensation - Improvements to Employee Share-Based Payment Accounting. The amendments in this ASU are intended to simplify several areas of accounting for share-based compensation arrangements, including the income tax consequences, classification on the consolidated statement of cash flows and treatment of forfeitures. The Company is required to adopt the guidance in the first quarter of fiscal 2018. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-17-148855:notes:136]
In August 2016, the FASB issued ASU 2016-15 (ASC Topic 230), Statement of Cash Flows - Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU are intended to clarify how certain cash receipts and cash payment are presented and classified in the statement of cash flows. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-17-148855:notes:137]
In October 2016, the FASB issued ASU 2016-16 (ASC Topic 740), Income Taxes: Intra-Entity Transfers of Assets Other Than Inventory. The amendments in this ASU require the recognition of the income tax consequences for intra-entity transfers of assets other than inventory when the transfer occurs. Under current GAAP, current and deferred income taxes for intra-entity asset transfers are not recognized until the asset has been sold to an outside party. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-17-148855:notes:138]
In January 2017, the FASB issued ASU 2017-01 (ASC Topic 805), Business Combination: Clarifying the Definition of a Business. The amendments in this ASU change the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-17-148855:notes:139]
Recently Adopted Accounting Pronouncements

[0001193125-17-148855:notes:140]
In April 2015 and August 2015, the FASB issued ASU 2015-03 (ASC Subtopic 835-30), Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs and ASU 2015-15 (ASC Subtopic 835-30), Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements- Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting, respectively. The ASUs require that debt issuance costs related to a recognized debt liability, with the exception of those related to line-of-credit arrangements, be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability.  ASU 2015-03 became effective and was adopted by the Company in the September 2016 quarter on a retrospective basis. The adoption of this guidance resulted in a reduction to Other assets, net and Long-term debt by $39 million, within the Consolidated Balance Sheet as of July 1, 2016. ASU 2015-15 became effective and was adopted by the Company in the September 2016 quarter on a prospective basis with no material impact on the Company’s condensed consolidated financial statements and disclosures.

[0001193125-17-148855:notes:141]
In September 2015, the FASB issued ASU 2015-16 (ASC Topic 805), Business Combinations Simplifying the Accounting for Measurement-Period Adjustments. The amendments in this update require that an acquirer recognize measurement period adjustments in the period in which the adjustments are determined. The income effects of such measurement period adjustments are to be recorded in the same period’s financial statements but calculated as if the accounting had been completed as of the acquisition date. The impact of measurement period adjustments to earnings that relate to prior period financial statements are to be presented separately on the income statement or disclosed by line item. The amendments in this update are for fiscal years, including interim periods within those fiscal years, beginning after December 15, 2015. This ASU became effective and was adopted by the Company in the September 2016 quarter on a prospective basis with no material impact on the Company’s condensed consolidated financial statements and disclosures.

[0001193125-17-148855:notes:142]
In November 2016, the FASB issued ASU 2016-18 (ASC Topic 230), Statement of Cash Flows: Restricted Cash. The amendments in this update provide guidance on the classification and presentation of changes in restricted cash on the statement of cash flows. The ASU requires amounts generally described as restricted cash and restricted cash equivalents to be included with cash and cash equivalents when reconciling the total beginning and ending balances for the periods presented on the statement of cash flows. The amendments in this update are for fiscal years, including interim periods within those fiscal years, beginning after December 15, 2017. The Company elected to adopt this ASU in the December 2016 quarter on a retrospective basis with no material impact on the Company's condensed consolidated financial statements and disclosures. The Company classifies restricted cash within Other current assets in the condensed consolidated balance sheets.

[0001193125-17-148855:notes:143]
In January 2017, the FASB issued ASU 2017-04 (ASC Topic 350), Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment. The amendments in this ASU eliminate Step 2 from the goodwill impairment test, which requires entities to calculate the implied fair value of goodwill to measure a goodwill impairment charge. Instead, entities will record an impairment charge based on the excess of a reporting unit's carrying amount over its fair value, determined in step 1. The Company elected to adopt this ASU in the March 2017 quarter on a prospective basis with no material impact on the Company's condensed consolidated financial statements and disclosures.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001193125-17-148855:notes:144]
[same as prior period, unchanged from 0001193125-17-019732:notes:141]

[0001193125-17-148855:notes:145]
[same as prior period, unchanged from 0001193125-17-019732:notes:142]

[0001193125-17-148855:notes:146]
Seagate Technology plc (the "Company" or "Seagate") is a leading provider of electronic data storage technology and solutions.  Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, it produces a broad range of electronic data storage products including solid state drives ("SSD") in its Enterprise market portfolio and solid state hybrid drives ("SSHD"). The Company's storage technology portfolio also includes storage subsystems, and high performance computing ("HPC") solutions.

[0001193125-17-148855:notes:147]
[same as prior period, unchanged from 0001193125-17-019732:notes:144]

[0001193125-17-148855:notes:148]
The Company's products are designed for mission critical and nearline applications in enterprise servers and storage systems; client compute applications, where its products are designed primarily for desktop and mobile computing; and client non-compute applications, where its products are designed for a wide variety of end user devices such as portable external storage systems, personal data backup systems, surveillance systems, digital video recorders ("DVRs") and gaming consoles.

[0001193125-17-148855:notes:149]
[same as prior period, unchanged from 0001193125-17-019732:notes:146]

[0001193125-17-148855:notes:150]
[same as prior period, unchanged from 0001193125-17-019732:notes:147]

[0001193125-17-148855:notes:151]
The results of operations for the three and nine months ended March 31, 2017, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending June 30, 2017. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three and nine months ended March 31, 2017 and the three and nine months ended April 1, 2016 consisted of 13 weeks and 39 weeks, respectively. Fiscal year 2017 will be comprised of 52 weeks and will end on June 30, 2017. The fiscal quarters ended March 31, 2017, December 30, 2016, and April 1, 2016, are also referred to herein as the “March 2017 quarter”, the “December 2016 quarter”, and the “March 2016 quarter”, respectively.

[0001193125-17-148855:notes:152]
[same as prior period, unchanged from 0001193125-17-019732:notes:149]

[0001193125-17-148855:notes:153]
[same as prior period, unchanged from 0001193125-17-019732:notes:150]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-17-148855:notes:154]
[same as prior period, unchanged from 0001193125-17-019732:notes:151]

[0001193125-17-148855:notes:155]
[same as prior period, unchanged from 0001193125-17-019732:notes:152]

[0001193125-17-148855:notes:156]
[same as prior period, unchanged from 0001193125-17-019732:notes:153]

[0001193125-17-148855:notes:157]
[same as prior period, unchanged from 0001193125-17-019732:notes:154]

[0001193125-17-148855:notes:158]
[same as prior period, unchanged from 0001193125-17-019732:notes:155]

[0001193125-17-148855:notes:159]
[same as prior period, unchanged from 0001193125-17-019732:notes:156]

[0001193125-17-148855:notes:160]
[same as prior period, unchanged from 0001193125-17-019732:notes:157]

[0001193125-17-148855:notes:161]
[same as prior period, unchanged from 0001193125-17-019732:notes:158]

[0001193125-17-148855:notes:162]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the three and nine months ended March 31, 2017 and April 1, 2016 were as follows:

[0001193125-17-148855:notes:163]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 31, 2017 |  | April 1, 2016 |  | March 31, 2017 |  | April 1, 2016 |
| Balance, beginning of period |  | $ | 222 |  |  | $ | 223 |  |  | $ | 206 |  |  | $ | 248 |  |
| Warranties issued |  | 32 |  |  | 30 |  |  | 97 |  |  | 96 |  |
| Repairs and replacements |  | (28 | ) |  | (37 | ) |  | (87 | ) |  | (118 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | (3 | ) |  | (11 | ) |  | 7 |  |  | (23 | ) |
| Warranty liability assumed from business acquisitions |  | — |  |  | — |  |  | — |  |  | 2 |  |
| Balance, end of period |  | $ | 223 |  |  | $ | 205 |  |  | $ | 223 |  |  | $ | 205 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-17-148855:notes:164]
[same as prior period, unchanged from 0001193125-17-019732:notes:161]

[0001193125-17-148855:notes:165]
| (Dollars in millions) |  | March 31, 2017 |  | July 1, 2016 |
| Property, equipment and leasehold improvements |  | $ | 9,709 |  |  | $ | 9,884 |  |
| Accumulated depreciation and amortization |  | (7,798 | ) |  | (7,724 | ) |
|  |  | $ | 1,911 |  |  | $ | 2,160 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-17-148855:notes:166]
[same as prior period, unchanged from 0001193125-17-019732:notes:163]

[0001193125-17-148855:notes:167]
For the three and nine months ended March 31, 2017, the Company recorded restructuring charges of approximately $48 million and $164 million, respectively, comprised primarily of charges related to workforce reduction costs and facility exit costs associated with the restructuring of its workforce during the fiscal year. The Company's significant restructuring plans are described below. All restructuring charges are reported in Restructuring and other, net on the Condensed Consolidated Statements of Operations.

[0001193125-17-148855:notes:168]
March 2017 Plan - On March 9, 2017, the Company committed to an additional restructuring plan (the “March 2017 Plan”) in connection with the continued consolidation of its global footprint. The Company is in the process of closing its design center in Korea, which will result in the reduction of the Company’s headcount by approximately 300 employees. The March 2017 Plan is expected to be substantially completed by the end of fiscal year 2017 with total future costs expected to be incurred of approximately $6 million, comprised primarily of facility exit costs. For the three and nine months ended March 31, 2017, the Company recorded total restructuring charges of approximately $28 million and made cash payment of $16 million, comprised primarily of workforce reduction costs related to the March 2017 Plan. In addition, the Company committed to sell its land and building in Korea in the March 2017 quarter as part of the plan. This land and building met the criteria to be classified as assets held for sale and were included in Other current assets on the Condensed Consolidated Balance Sheet. The Company recorded an impairment charge of $26 million as part of the fair value measurement to reduce the carrying amount of its land and building to its estimated fair value less costs to sell, which is included in Operating expenses on the Condensed Consolidated Statements of Operations.

[0001193125-17-148855:notes:169]
July 2016 Plan - On July 11, 2016, the Company committed to a restructuring plan (the “July 2016 Plan”) for continued consolidation of its global footprint across Asia, EMEA and the Americas. The July 2016 Plan included reducing worldwide headcount by approximately 6,500 employees. The July 2016 Plan, is expected to be largely completed by the end of fiscal year 2017 with total future costs expected to be incurred of approximately $22 million, comprised of approximately $1 million of workforces reduction costs and $21 million of facility exit costs. For the three months ended March 31, 2017, the Company recorded total restructuring charges of approximately $9 million related to the July 2016 Plan, comprised of approximately $1 million of workforce reduction costs and $8 million of facility exit costs. For the nine months ended March 31, 2017, the Company recorded total restructuring charges of approximately $91 million, comprised of approximately $76 million for workforce reduction costs, $12 million for facility exit costs and $3 million of foreign currency remeasurement charges. For the three months ended March 31, 2017, the Company made cash payments of $33 million, comprised primarily of $27 million for workforce reduction costs and $6 million for facility exit costs. For the nine months ended March 31, 2017, the Company made cash payments of $52 million comprised primarily of $42 million for workforce reduction costs and $10 million for facility exit related to the July 2016 Plan.

[0001193125-17-148855:notes:170]
June 2016 Plan - On June 27, 2016, the Company committed to a restructuring plan (the “June 2016 Plan”) as part of the Company's efforts to reduce its cost structure to align with the then current macroeconomic conditions. The June 2016 Plan included reducing worldwide headcount by approximately 1,600 employees. The June 2016 Plan was largely completed by the fiscal quarter ended December 30, 2016 with no material future costs expected to be incurred. For the three months ended March 31, 2017, the Company did not record any material restructuring charges. For the nine months ended March 31, 2017, the Company recorded total restructuring charges of approximately $1 million, comprised of facility exit costs. As of March 31, 2017, the cumulative amount incurred to date was approximately $70 million. For the three and nine months ended March 31, 2017, the Company made cash payments of $2 million and $40 million, respectively, comprised primarily of workforce reduction costs related to the June 2016 Plan.

[0001193125-17-148855:notes:171]
Other Restructuring and Exit Costs - The total future costs expected to be incurred for other restructuring and exit activities is approximately $3 million, comprised primarily of facility exit costs. For the three months ended March 31, 2017, the Company recorded total restructuring charges of approximately $11 million, comprised of approximately $1 million of workforce reduction costs and $10 million of facility exit costs. For the nine months ended March 31, 2017, the Company recorded total restructuring charges of approximately $44 million, comprised of approximately $26 million for workforce reduction costs and $18 million for facility exit costs. For the three months ended March 31, 2017, the Company made cash payments of $27 million, comprised primarily of $23 million for workforce reduction costs and $4 million for facility exit costs. For the nine months ended March 31, 2017, the Company made cash payments of $42 million comprised primarily of $28 million for workforce reduction costs and $14 million for facility exit costs.


## us-gaap:ScheduleOfAccountsPayableAndAccruedLiabilitiesTableTextBlock

[0001193125-17-148855:notes:172]
[same as prior period, unchanged from 0001193125-17-019732:notes:170]

[0001193125-17-148855:notes:173]
| (Dollars in millions) |  | March 31, 2017 |  | July 1, 2016 |
| Dividends payable |  | $ | 187 |  |  | $ | — |  |
| Other accrued expenses |  | 496 |  |  | 444 |  |
| Total |  | $ | 683 |  |  | $ | 444 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-17-148855:notes:174]
[same as prior period, unchanged from 0001193125-17-019732:notes:172]

[0001193125-17-148855:notes:175]
| (Dollars in millions) |  | Unrealized Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Marketable Securities (a) |  | Unrealized Gains (Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at July 1, 2016 |  | $ | (1 | ) |  | $ | — |  |  | $ | (7 | ) |  | $ | (17 | ) |  | $ | (25 | ) |
| Other comprehensive income (loss) before reclassifications |  | (2 | ) |  | — |  |  | — |  |  | (3 | ) |  | (5 | ) |
| Amounts reclassified from AOCI |  | 2 |  |  | — |  |  | 1 |  |  | — |  |  | 3 |  |
| Other comprehensive income (loss) |  | — |  |  | — |  |  | 1 |  |  | (3 | ) |  | (2 | ) |
| Balance at March 31, 2017 |  | $ | (1 | ) |  | $ | — |  |  | $ | (6 | ) |  | $ | (20 | ) |  | $ | (27 | ) |
| Balance at July 3, 2015 |  | $ | 1 |  |  | $ | — |  |  | $ | (15 | ) |  | $ | (16 | ) |  | $ | (30 | ) |
| Other comprehensive income (loss) before reclassifications |  | (3 | ) |  | — |  |  | 1 |  |  | 2 |  |  | — |  |
| Amounts reclassified from AOCI |  | 2 |  |  | — |  |  | — |  |  | — |  |  | 2 |  |
| Other comprehensive income (loss) |  | (1 | ) |  | — |  |  | 1 |  |  | 2 |  |  | 2 |  |
| Balance at April 1, 2016 |  | $ | — |  |  | $ | — |  |  | $ | (14 | ) |  | $ | (14 | ) |  | $ | (28 | ) |

[0001193125-17-148855:notes:176]
[same as prior period, unchanged from 0001193125-17-019732:notes:174]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-17-148855:notes:177]
[same as prior period, unchanged from 0001193125-17-019732:notes:175]

[0001193125-17-148855:notes:178]
| (Dollars in millions) |  | March 31, 2017 |  | July 1, 2016 |
| Raw materials and components |  | $ | 382 |  |  | $ | 307 |  |
| Work-in-process |  | 262 |  |  | 297 |  |
| Finished goods |  | 394 |  |  | 264 |  |
|  |  | $ | 1,038 |  |  | $ | 868 |  |


## us-gaap:ScheduleOfRestrictedCashAndCashEquivalentsTextBlock

[0001193125-17-148855:notes:179]
[same as prior period, unchanged from 0001193125-17-019732:notes:177]

[0001193125-17-148855:notes:180]
| (Dollars in millions) |  | March 31, 2017 |  | July 1, 2016 |  | April 1, 2016 |  | July 3, 2015 |
| Cash and cash equivalents |  | $ | 3,026 |  |  | $ | 1,125 |  |  | $ | 1,193 |  |  | $ | 2,479 |  |
| Restricted cash included in Other current assets |  | 5 |  |  | 7 |  |  | 7 |  |  | 7 |  |
| Total cash, cash equivalents, and restricted cash shown in the Statements of Cash Flows |  | $ | 3,031 |  |  | $ | 1,132 |  |  | $ | 1,200 |  |  | $ | 2,486 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-17-148855:notes:181]
[same as prior period, unchanged from 0001193125-17-019732:notes:179]

[0001193125-17-148855:notes:182]
[same as prior period, unchanged from 0001193125-17-019732:notes:180]

[0001193125-17-148855:notes:183]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 296,600,790 shares were outstanding as of March 31, 2017, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of March 31, 2017.

[0001193125-17-148855:notes:184]
[same as prior period, unchanged from 0001193125-17-019732:notes:182]

[0001193125-17-148855:notes:185]
[same as prior period, unchanged from 0001193125-17-019732:notes:183]

[0001193125-17-148855:notes:186]
[same as prior period, unchanged from 0001193125-17-019732:notes:184]

[0001193125-17-148855:notes:187]
[same as prior period, unchanged from 0001193125-17-019732:notes:185]

[0001193125-17-148855:notes:188]
[same as prior period, unchanged from 0001193125-17-019732:notes:186]

[0001193125-17-148855:notes:189]
[same as prior period, unchanged from 0001193125-17-019732:notes:187]

[0001193125-17-148855:notes:190]
As of March 31, 2017, $1.5 billion remained available for repurchase under the existing repurchase authorization limit. During the quarter ended March 31, 2017, the Company did not repurchase any ordinary shares.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-17-148855:notes:191]
[same as prior period, unchanged from 0001193125-17-019732:notes:189]

[0001193125-17-148855:notes:192]
[same as prior period, unchanged from 0001193125-17-019732:notes:190]

[0001193125-17-148855:notes:193]
As of March 31, 2017, the Company’s Other current assets included $5 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001193125-17-148855:notes:194]
As of March 31, 2017, the Company had no material available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined that no available-for-sale securities were other-than-temporarily impaired as of March 31, 2017.

[0001193125-17-148855:notes:195]
[same as prior period, unchanged from 0001193125-17-019732:notes:193]

[0001193125-17-148855:notes:196]
[same as prior period, unchanged from 0001193125-17-019732:notes:194]

[0001193125-17-148855:notes:197]
[same as prior period, unchanged from 0001193125-17-019732:notes:195]

[0001193125-17-148855:notes:198]
[same as prior period, unchanged from 0001193125-17-019732:notes:196]

[0001193125-17-148855:notes:199]
[same as prior period, unchanged from 0001193125-17-019732:notes:197]

[0001193125-17-148855:notes:200]
Accrued Expenses

[0001193125-17-148855:notes:201]
[same as prior period, unchanged from 0001193125-17-019732:notes:199]
