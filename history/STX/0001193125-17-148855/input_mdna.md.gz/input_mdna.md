# STX MD&A — 0001193125-17-148855


## mdna

[0001193125-17-148855:mdna:1]
[same as prior period, unchanged from 0001193125-17-019732:mdna:1]

[0001193125-17-148855:mdna:2]
The following is a discussion of the financial condition, changes in financial condition, and results of operations for our fiscal quarters
ended March 31, 2017, December 30, 2016 and April 1, 2016, referred to herein as the “March 2017 quarter,” the “December 2016 quarter,” and the “March 2016 quarter,” respectively. We operate and
report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The March 2017, December 2016 and March 2016 quarters were all 13 weeks.

[0001193125-17-148855:mdna:3]
[same as prior period, unchanged from 0001193125-17-019732:mdna:3]

[0001193125-17-148855:mdna:4]
Our Management’s Discussion and Analysis of Financial Condition and Results of
Operations (“MD&A”) is provided in addition to the accompanying condensed consolidated financial statements and notes to assist readers in understanding our results of operations, financial condition, and cash flows. Our MD&A is
organized as follows:

[0001193125-17-148855:mdna:5]
[same as prior period, unchanged from 0001193125-17-019732:mdna:5]

[0001193125-17-148855:mdna:6]
|  | • |  | Overview of the March 2017 quarter. Highlights of events in the March 2017 quarter that impacted our financial position. |

[0001193125-17-148855:mdna:7]
|  | • |  | Results of Operations. An analysis of our financial results comparing the March 2017 quarter to the December 2016 quarter and the March 2016 quarter. |

[0001193125-17-148855:mdna:8]
|  | • |  | Liquidity and Capital Resources. An analysis of changes in our balance sheet and cash flows, and discussion of our financial condition including the credit quality of our investment portfolio and potential sources of liquidity. |

[0001193125-17-148855:mdna:9]
[same as prior period, unchanged from 0001193125-17-019732:mdna:9]

[0001193125-17-148855:mdna:10]
[same as prior period, unchanged from 0001193125-17-019732:mdna:23]

[0001193125-17-148855:mdna:11]
[same as prior period, unchanged from 0001193125-17-019732:mdna:10]

[0001193125-17-148855:mdna:12]
We are a leading provider of electronic data storage technology and solutions. Our principal products are hard disk drives, commonly referred
to as disk drives, hard drives or HDDs. In addition to HDDs, we produce a broad range of electronic data storage products including solid state drives (“SSD”) in our Enterprise market portfolio and solid state hybrid drives
(“SSHD”). Our storage technology portfolio also includes storage subsystems, and high performance computing (“HPC”) solutions.

[0001193125-17-148855:mdna:13]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be
the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to
store data, and most SSDs use NAND-based flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed
data.

[0001193125-17-148855:mdna:14]
Our products are designed for mission critical and nearline applications in enterprise servers and storage systems; client compute
applications, where our products are designed primarily for desktop and mobile computing; and client non-compute applications, where our products are designed for a wide variety of end user devices such as
portable external storage systems, personal data backup systems, surveillance systems, digital video recorders (“DVRs”) and gaming consoles.

[0001193125-17-148855:mdna:15]
Our Cloud Systems and Solutions product portfolio builds on the Seagate legacy to extend innovation from the device into the information
infrastructure, onsite and in the cloud. This product portfolio includes HPC storage solutions, modular original equipment manufacturers (“OEM”) storage systems and scale-out storage systems.

[0001193125-17-148855:mdna:16]
Overview of the March 2017 Quarter

[0001193125-17-148855:mdna:17]
During the March 2017 quarter, we shipped 65 exabytes of storage capacity, generating revenue of approximately $2.7 billion and gross
margin of 31%. Our operating cash flow was $426 million. We issued $750 million of 4.25% Senior Notes due 2022 and $500 million of 4.875% Senior Notes due 2024, paid $97 million for the repurchase of our outstanding debt, as well
as paid $186 million in dividends.

[0001193125-17-148855:mdna:18]
[same as prior period, unchanged from 0001193125-17-019732:mdna:19]

[0001193125-17-148855:mdna:19]
We list in the tables below summarized information from our Condensed Consolidated Statements of Operations by dollars and as a percentage of
revenue:

[0001193125-17-148855:mdna:20]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | March 31,2017 |  |  | December 30,2016 |  |  | April 1,2016 |  |  | March 31,2017 |  |  | April 1,2016 |  |
| Revenue |  | $ | 2,674 |  |  | $ | 2,894 |  |  | $ | 2,595 |  |  | $ | 8,365 |  |  | $ | 8,506 |  |
| Cost of revenue |  |  | 1,858 |  |  |  | 2,003 |  |  |  | 2,071 |  |  |  | 5,857 |  |  |  | 6,553 |  |
| Gross margin |  |  | 816 |  |  |  | 891 |  |  |  | 524 |  |  |  | 2,508 |  |  |  | 1,953 |  |
| Product development |  |  | 324 |  |  |  | 305 |  |  |  | 298 |  |  |  | 944 |  |  |  | 930 |  |
| Marketing and administrative |  |  | 150 |  |  |  | 155 |  |  |  | 150 |  |  |  | 457 |  |  |  | 491 |  |
| Amortization of intangibles |  |  | 28 |  |  |  | 28 |  |  |  | 29 |  |  |  | 85 |  |  |  | 94 |  |
| Restructuring and other, net |  |  | 48 |  |  |  | 33 |  |  |  | 20 |  |  |  | 164 |  |  |  | 95 |  |
| Income from operations |  |  | 266 |  |  |  | 370 |  |  |  | 27 |  |  |  | 858 |  |  |  | 343 |  |
| Other expense, net |  |  | (54 | ) |  |  | (60 | ) |  |  | (18 | ) |  |  | (163 | ) |  |  | (122 | ) |
| Income before income taxes |  |  | 212 |  |  |  | 310 |  |  |  | 9 |  |  |  | 695 |  |  |  | 221 |  |
| Provision for income taxes |  |  | 18 |  |  |  | 13 |  |  |  | 30 |  |  |  | 37 |  |  |  | 43 |  |
| Net income (loss) |  | $ | 194 |  |  | $ | 297 |  |  | $ | (21 | ) |  | $ | 658 |  |  | $ | 178 |  |

[0001193125-17-148855:mdna:21]
[same as prior period, unchanged from 0001193125-17-019732:mdna:34]

[0001193125-17-148855:mdna:22]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
|  |  | March 31,2017 |  |  | December 30,2016 |  |  | April 1,2016 |  |  | March 31,2017 |  |  | April 1,2016 |  |
| Revenue |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |
| Cost of revenue |  |  | 69 |  |  |  | 69 |  |  |  | 80 |  |  |  | 70 |  |  |  | 77 |  |
| Gross margin |  |  | 31 |  |  |  | 31 |  |  |  | 20 |  |  |  | 30 |  |  |  | 23 |  |
| Product development |  |  | 12 |  |  |  | 11 |  |  |  | 11 |  |  |  | 11 |  |  |  | 11 |  |
| Marketing and administrative |  |  | 6 |  |  |  | 5 |  |  |  | 6 |  |  |  | 6 |  |  |  | 6 |  |
| Amortization of intangibles |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |
| Restructuring and other, net |  |  | 2 |  |  |  | 1 |  |  |  | 1 |  |  |  | 2 |  |  |  | 1 |  |
| Income from operations |  |  | 10 |  |  |  | 13 |  |  |  | 1 |  |  |  | 10 |  |  |  | 4 |  |
| Other expense, net |  |  | (2 | ) |  |  | (2 | ) |  |  | (1 | ) |  |  | (2 | ) |  |  | (1 | ) |
| Income before income taxes |  |  | 8 |  |  |  | 11 |  |  |  | — |  |  |  | 8 |  |  |  | 3 |  |
| Provision for income taxes |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | — |  |  |  | 1 |  |
| Net income (loss) |  |  | 7 | % |  |  | 10 | % |  |  | (1 | )% |  |  | 8 | % |  |  | 2 | % |

[0001193125-17-148855:mdna:23]
[same as prior period, unchanged from 0001193125-17-019732:mdna:24]

[0001193125-17-148855:mdna:24]
The following table summarizes HDD information regarding average drive selling prices (“ASPs”), exabytes shipped, and revenues by
channel and geography:

[0001193125-17-148855:mdna:25]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
|  |  | March 31,2017 |  |  | December 30,2016 |  |  | April 1,2016 |  |  | March 31,2017 |  |  | April 1,2016 |  |
| ASPs (per unit) |  | $ | 67 |  |  | $ | 66 |  |  | $ | 60 |  |  | $ | 67 |  |  | $ | 59 |  |
| Exabytes Shipped |  |  | 65 |  |  |  | 68 |  |  |  | 56 |  |  |  | 200 |  |  |  | 171 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  |  | 66 | % |  |  | 66 | % |  |  | 69 | % |  |  | 67 | % |  |  | 69 | % |
| Distributors |  |  | 19 | % |  |  | 18 | % |  |  | 16 | % |  |  | 18 | % |  |  | 17 | % |
| Retailers |  |  | 15 | % |  |  | 16 | % |  |  | 15 | % |  |  | 14 | % |  |  | 14 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  |  | 30 | % |  |  | 30 | % |  |  | 30 | % |  |  | 31 | % |  |  | 28 | % |
| EMEA |  |  | 17 | % |  |  | 19 | % |  |  | 17 | % |  |  | 17 | % |  |  | 18 | % |
| Asia Pacific |  |  | 53 | % |  |  | 51 | % |  |  | 53 | % |  |  | 52 | % |  |  | 54 | % |

[0001193125-17-148855:mdna:26]
Revenue in the March 2017 quarter decreased by $220 million from the December 2016 quarter as a result of
a decrease in exabytes shipped driven primarily by higher seasonal demand in the December 2016 quarter and price erosion, partially offset by favorable product mix.

[0001193125-17-148855:mdna:27]
Revenue in the March 2017 quarter increased by $79 million from the March 2016 quarter primarily as a result of improved product mix
translating to an increase in exabytes shipped. Revenue for the nine months ended March 31, 2017 decreased by $141 million from the nine months ended April 1, 2016 as a result of the impact of price erosion, partially offset by
improved product mix translating to an increase in exabytes shipped.

[0001193125-17-148855:mdna:28]
We maintain various sales programs such as channel rebates and price
masking. Sales programs were approximately at 11%, 11% and 14% of gross drive revenue for the March 2017 quarter, December 2016 quarter and March 2016 quarter, respectively. Adjustments to revenues due to under or over accruals for sales programs
related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001193125-17-148855:mdna:29]
[same as prior period, unchanged from 0001193125-17-019732:mdna:47]

[0001193125-17-148855:mdna:30]
[same as prior period, unchanged from 0001193125-17-019732:mdna:31]

[0001193125-17-148855:mdna:31]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | March 31,2017 |  |  | December 30,2016 |  |  | April 1,2016 |  |  | March 31,2017 |  |  | April 1,2016 |  |
| Cost of revenue |  | $ | 1,858 |  |  | $ | 2,003 |  |  | $ | 2,071 |  |  | $ | 5,857 |  |  | $ | 6,553 |  |
| Gross margin |  |  | 816 |  |  |  | 891 |  |  |  | 524 |  |  |  | 2,508 |  |  |  | 1,953 |  |
| Gross margin percentage |  |  | 31 | % |  |  | 31 | % |  |  | 20 | % |  |  | 30 | % |  |  | 23 | % |

[0001193125-17-148855:mdna:32]
Gross margin as a percentage of revenue for the March 2017 quarter remained flat from the December 2016
quarter. Compared to the March 2016 quarter, gross margin as a percentage of revenue increased by 1,100 basis points driven by favorable product mix, and improved utilization of factories resulting from cost savings due to our ongoing workforce
reductions and manufacturing consolidation activities, partially offset by price erosion.

[0001193125-17-148855:mdna:33]
Compared to the nine months ended April 1,
2016, gross margin for the nine months ended March 31, 2017 increased by 700 basis points due to a favorable product mix, and improved utilization of factories resulting from cost savings due to our ongoing workforce reductions and
manufacturing consolidation activities, partially offset by price erosion.

[0001193125-17-148855:mdna:34]
In the March 2017 quarter, total warranty cost was in the
historical range of 1% to 1.5% of revenue and included a favorable change in estimates of prior warranty accruals of less than 0.5% of revenue. Warranty cost related to new shipments was 1.2%, 1.2%, and 1.1% of revenue for each of the March 2017,
December 2016 and March 2016 quarters, respectively.

[0001193125-17-148855:mdna:35]
[same as prior period, unchanged from 0001193125-17-019732:mdna:37]

[0001193125-17-148855:mdna:36]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | March 31,2017 |  |  | December 30,2016 |  |  | April 1,2016 |  |  | March 31,2017 |  |  | April 1,2016 |  |
| Product development |  | $ | 324 |  |  | $ | 305 |  |  | $ | 298 |  |  | $ | 944 |  |  | $ | 930 |  |
| Marketing and administrative |  |  | 150 |  |  |  | 155 |  |  |  | 150 |  |  |  | 457 |  |  |  | 491 |  |
| Amortization of intangibles |  |  | 28 |  |  |  | 28 |  |  |  | 29 |  |  |  | 85 |  |  |  | 94 |  |
| Restructuring and other, net |  |  | 48 |  |  |  | 33 |  |  |  | 20 |  |  |  | 164 |  |  |  | 95 |  |
| Operating expenses |  | $ | 550 |  |  | $ | 521 |  |  | $ | 497 |  |  | $ | 1,650 |  |  | $ | 1,610 |  |

[0001193125-17-148855:mdna:37]
Product development expense. Product development expense for the March 2017 quarter increased by
$19 million from the December 2016 quarter due to a $26 million increase in impairment charges related to the closure of the Korea design center and $14 million increase in employee related benefits primarily due to increased use of
vacation in the December 2016 quarter, partially offset by a $20 million increase in operational efficiencies in our business and a decrease in variable compensation.

[0001193125-17-148855:mdna:38]
Compared to the March 2016 quarter, product development expense increased by $26 million due to a $26 million increase in impairment
charges related to the closure of Korea design center and $22 million increase in variable compensation driven by improved financial performance, offset by a decrease of $25 million due to an increase in operational efficiencies in our
business and a decrease in salaries and related benefits as a result of the restructuring of our workforce in prior periods.

[0001193125-17-148855:mdna:39]
Product
development expense for the nine months ended March 31, 2017 increased by $14 million as compared to the corresponding period in the prior year due to a $26 million increase in impairment charges related to the closure of Korea design
center, an increase in variable compensation and share-based compensation of $66 million driven by better financial performance, offset by an $81 million decrease in salaries and related benefits as a result of an increase in operational
efficiencies in our business and the restructuring of our workforce in the prior periods.

[0001193125-17-148855:mdna:40]
Marketing and administrative
expense. Marketing and administrative expense for the March 2017 quarter decreased by $5 million from the December 2016 quarter primarily due to an increase in operational efficiencies in our business. Marketing and administrative
expense remained flat from the March 2016 quarter.

[0001193125-17-148855:mdna:41]
Marketing and administrative expense for the nine months ended March 31, 2017
decreased by $34 million compared to the corresponding period in the prior year due to a decrease in salaries and related benefits of $46 million as a result of the restructuring of our workforce in prior periods, a $34 million
reduction resulting from an increase in operational efficiencies in our business and the completion of certain promotional and branding activities in fiscal year 2016, partially offset by a $48 million increase in variable compensation and
share-based compensation driven by better financial performance.

[0001193125-17-148855:mdna:42]
[same as prior period, unchanged from 0001193125-17-019732:mdna:61]

[0001193125-17-148855:mdna:43]
Amortization of intangibles. Amortization of intangibles for the March 2017 quarter
remained flat from the December 2016 quarter and March 2016 quarter.

[0001193125-17-148855:mdna:44]
Amortization of intangibles for the nine months ended March 31,
2017 decreased by $9 million as compared to the corresponding period in the prior year due to certain intangible assets reaching the end of their useful life.

[0001193125-17-148855:mdna:45]
Restructuring and other, net. Restructuring and other, net for the three and nine months ended March 31, 2017 was comprised
primarily of restructuring charges to reduce our global workforce by 300 and 6,800 employees respectively, as we continue to consolidate our global footprint across Asia, EMEA and the Americas.

[0001193125-17-148855:mdna:46]
Restructuring and other, net for the three and nine months ended April 1, 2016 was comprised primarily of a restructuring charge recorded
for February 2016 Plan and the September 2015 Plan to reduce our workforce by approximately 2,000 and 1,000 employees respectively, as a result of our ongoing focus on cost efficiencies in all areas of our business, which were largely completed
during fiscal year 2016. See “Part I, Item 1. Financial Statements-Note 7. Restructuring and Exit Costs” for more details.

[0001193125-17-148855:mdna:47]
[same as prior period, unchanged from 0001193125-17-019732:mdna:48]

[0001193125-17-148855:mdna:48]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | March 31,2017 |  |  | December 30,2016 |  |  | April 1,2016 |  |  | March 31,2017 |  |  | April 1,2016 |  |
| Other expense, net |  | $ | (54 | ) |  | $ | (60 | ) |  | $ | (18 | ) |  | $ | (163 | ) |  | $ | (122 | ) |

[0001193125-17-148855:mdna:49]
Other expense, net decreased by $6 million from the December 2016 quarter, due to a $25 million
charge related to the impairment of a strategic investment in the December 2016 quarter and a $4 million increase in earnings from strategic investments in the March 2017 quarter, partially offset by increase of $27 million expense in the
March 2017 quarter including a $17 million change from unfavorable foreign currency changes in foreign exchange rates and $10 million interest expense on the issuance of $750 million of 4.25% Senior Notes due 2022 and
$500 million of 4.875% Senior Notes due 2024.

[0001193125-17-148855:mdna:50]
Compared to the March 2016 quarter, Other expense, net increased by $36 million
primarily due to the $33 million final payment of unpaid interest on the arbitration award amount in the Company’s case against Western Digital in the March 2016 quarter, a $10 million interest expense on the issuance of
$750 million of 4.25% Senior Notes due 2022 and $500 million of 4.875% Senior Notes due 2024, partially offset by favorable foreign currency changes in foreign exchange rates and a $4 million increase in earnings from strategic
investments.

[0001193125-17-148855:mdna:51]
Other expense, net for the nine months ended March 31, 2017 increased by $41 million from the corresponding period
in the prior year primarily due to the $33 million final payment of unpaid interest on the arbitration award amount in the Company’s case against Western Digital in the March 2016 quarter, a $13 million increase related to the
impairment of certain strategic investments, $10 million interest expense on the issuance of $750 million of 4.25% Senior Notes due 2022 and $500 million of 4.875% Senior Notes due 2024, offset by $14 million foreign currency
remeasurement related to favorable foreign currency changes in foreign exchange rates.

[0001193125-17-148855:mdna:52]
[same as prior period, unchanged from 0001193125-17-019732:mdna:52]

[0001193125-17-148855:mdna:53]
|  |  | For the Three Months Ended |  |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | March 31,2017 |  |  | December 30,2016 |  |  | April 1,2016 |  |  | March 31,2017 |  |  | April 1,2016 |  |
| Provision for income taxes |  | $ | 18 |  |  | $ | 13 |  |  | $ | 30 |  |  | $ | 37 |  |  | $ | 43 |  |

[0001193125-17-148855:mdna:54]
Our income tax provision of $18 million and $37 million in the three and nine months ended
March 31, 2017 included approximately $8 million of net discrete tax expense and approximately $3 million of net discrete tax expense, respectively. These discrete items are primarily associated with changes in valuation allowances
offset by the release of tax reserves due to the expiration of certain statutes of limitation, and prior year tax adjustments.

[0001193125-17-148855:mdna:55]
Our income
tax provision recorded for the March 2017 quarter and for the first nine months of fiscal year 2017 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes,
primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely
reinvested outside of Ireland, (ii) restructuring expenses with no associated tax benefits, and (iii) a net decrease in valuation allowance for certain deferred tax assets.

[0001193125-17-148855:mdna:56]
[same as prior period, unchanged from 0001193125-17-019732:mdna:84]

[0001193125-17-148855:mdna:57]
During the nine months ended March 31, 2017, our unrecognized tax benefits excluding
interest and penalties increased by approximately $6 million to $76 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $76 million at March 31, 2017, subject to certain future
valuation allowance reversals. During the 12 months beginning April 1, 2017, we expect that our unrecognized tax benefits could be reduced by approximately $13 million, primarily as a result of the expiration of certain statutes of
limitation.

[0001193125-17-148855:mdna:58]
Our income tax provision recorded for the first nine months of fiscal year 2016 included approximately $2 million of net
discrete tax provision associated with prior year tax adjustments offset by the release of tax reserves due to the expiration of certain statutes of limitation.

[0001193125-17-148855:mdna:59]
Our income tax provision recorded for the March 2016 quarter and for the first nine months of fiscal year 2016 differed from the provision for
income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in
jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets. The acquisition of Dot Hill
Systems Corporation did not have a material impact on our effective tax rate in fiscal year 2016.

[0001193125-17-148855:mdna:60]
[same as prior period, unchanged from 0001193125-17-019732:mdna:59]

[0001193125-17-148855:mdna:61]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital
resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist primarily of money market funds, time deposits and certificates of
deposit. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have
restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash have been and will continue to be sufficient to meet our cash needs for the
next 12 months unimpeded by any restrictive regulations. We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term investments and we do not believe the fair
value of our short-term investments has significantly changed from the values reported as of March 31, 2017.

[0001193125-17-148855:mdna:62]
Cash and Cash Equivalents and
Short-term Investments

[0001193125-17-148855:mdna:63]
| (Dollars in millions) |  | March 31,2017 |  |  | July 1,2016 |  |  | Change |  |
| Cash and cash equivalents |  | $ | 3,026 |  |  | $ | 1,125 |  |  | $ | 1,901 |  |
| Short-term investments |  |  | — |  |  |  | 6 |  |  |  | (6 | ) |
| Total |  | $ | 3,026 |  |  | $ | 1,131 |  |  | $ | 1,895 |  |

[0001193125-17-148855:mdna:64]
Our cash and cash equivalents and short-term investments increased from July 1, 2016 as a result of an
increase in net cash provided by operating activities and the proceeds from the issuance of $750 million of 4.25% Senior Notes due 2022 and $500 million of 4.875% Senior Notes due 2024. These cash inflows were partially offset by net cash
outflows for capital expenditures, early redemption and repayments of long-term debt, repurchase of our ordinary shares and dividends paid to our shareholders.

[0001193125-17-148855:mdna:65]
[same as prior period, unchanged from 0001193125-17-019732:mdna:66]

[0001193125-17-148855:mdna:66]
Cash provided by operating activities for the nine months ended March 31, 2017 of $1,673 million includes the effects of net income
adjusted for non-cash items including depreciation, amortization, share-based compensation, and:

[0001193125-17-148855:mdna:67]
|  | • |  | a decrease of $165 million in accounts receivable, primarily due to a decrease in revenues and improved collection; and |

[0001193125-17-148855:mdna:68]
|  | • |  | an increase of $124 million in accounts payable, primarily due to the timing of payments of material purchases; offset by |

[0001193125-17-148855:mdna:69]
|  | • |  | an increase in inventory of $170 million primarily due to an increase in units built in connection with adjustments to our manufacturing footprint. |

[0001193125-17-148855:mdna:70]
[same as prior period, unchanged from 0001193125-17-019732:mdna:71]

[0001193125-17-148855:mdna:71]
Cash used for investing activities for the nine months ended March 31, 2017 was $337 million and primarily attributable to the
following activities:

[0001193125-17-148855:mdna:72]
|  | • |  | $330 million used to acquire property, equipment and leasehold improvements. |

[0001193125-17-148855:mdna:73]
Cash Used in Financing Activities

[0001193125-17-148855:mdna:74]
Cash used in financing activities of $571 million for the nine months ended March 31, 2017 was primarily attributable to the
following activities:

[0001193125-17-148855:mdna:75]
|  | • |  | net proceeds of $1,232 million received from issuance of $750 million of 4.25% Senior Notes due 2022 and $500 million of 4.875% Senior Notes due 2024; |

[0001193125-17-148855:mdna:76]
|  | • |  | $83 million in proceeds from the issuance of ordinary shares under employee stock plans, offset by; |

[0001193125-17-148855:mdna:77]
|  | • |  | $374 million in dividend payments; |

[0001193125-17-148855:mdna:78]
[same as prior period, unchanged from 0001193125-17-019732:mdna:76]

[0001193125-17-148855:mdna:79]
|  | • |  | $97 million of redemption and repayments of long-term debt; |

[0001193125-17-148855:mdna:80]
|  | • |  | $25 million paid for taxes related to net share settlement of equity awards. |

[0001193125-17-148855:mdna:81]
[same as prior period, unchanged from 0001193125-17-019732:mdna:80]

[0001193125-17-148855:mdna:82]
Our primary sources of liquidity as of March 31, 2017 consisted of: (1) approximately
$3.0 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) a $700 million senior revolving credit facility.

[0001193125-17-148855:mdna:83]
As of March 31, 2017, no borrowings had been drawn under the revolving credit facility or had been utilized for letters of credit issued
under this credit facility. The line of credit is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001193125-17-148855:mdna:84]
The credit agreement that governs our revolving credit facility, as amended, includes three financial covenants: (1) minimum cash, cash
equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. On April 28, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to adjust for
our current financial liquidity position. We were in compliance with the modified covenants as of March 31, 2017 and expect to be in compliance for the next 12 months.

[0001193125-17-148855:mdna:85]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled
payments of principal and interest on our indebtedness, and to fund our quarterly dividend. Our ability to fund these requirements will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to
prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. However, we believe our sources of cash will continue to be sufficient to meet our cash needs for the
next 12 months

[0001193125-17-148855:mdna:86]
For fiscal year 2017, we expect capital expenditures to be less than 5% of revenue.

[0001193125-17-148855:mdna:87]
From time to time we may repurchase any of our outstanding notes in open market or privately negotiated purchases or otherwise, or may
repurchase outstanding notes pursuant to the terms of the applicable indenture.

[0001193125-17-148855:mdna:88]
Dividends declared in the March 2017 quarter of
$187 million were subsequently paid on April 5, 2017. The Company’s Board of Directors declared a quarterly cash dividend of $0.63 per share on April 26, 2017, which is payable on July 5, 2017 to shareholders of record at
the close of business on June 21, 2017.

[0001193125-17-148855:mdna:89]
From time to time we may repurchase any of our outstanding ordinary shares through private,
open market, or broker assisted purchases. As of March 31, 2017, $1.5 billion remained available for repurchase under our existing repurchase authorization limit. All repurchases are effected as redemptions in accordance with the
Company’s Articles of Association.

[0001193125-17-148855:mdna:90]
On March 15, 2017, we exercised our call option by providing notice of the redemption to the
trustee of our intention to redeem all $158 million of our remaining outstanding 2021 Notes. The Notes will be redeemed on May 1, 2017 (the “Redemption Date”) at a redemption price equal to $102.333 per $100 principal amount of
the 2021 Notes redeemed plus accrued interest to the Redemption Date.

[0001193125-17-148855:mdna:91]
36

[0001193125-17-148855:mdna:92]
[same as prior period, unchanged from 0001193125-17-019732:mdna:90]

[0001193125-17-148855:mdna:93]
Our contractual cash obligations and commitments as of March 31, 2017, have been summarized in the table below:

[0001193125-17-148855:mdna:94]
|  |  |  |  |  | Fiscal Year(s) |  |
| (Dollars in millions) |  | Total |  |  | Remainder of2017 |  |  | 2018-2019 |  |  | 2020-2021 |  |  | Thereafter |  |
| Contractual Cash Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt (including current portion) |  | $ | 5,286 |  |  | $ | 158 |  |  | $ | 761 |  |  | $ | — |  |  | $ | 4,367 |  |
| Interest payments on debt |  |  | 1,974 |  |  |  | 121 |  |  |  | 467 |  |  |  | 420 |  |  |  | 966 |  |
| Purchase obligations(2) |  |  | 1,554 |  |  |  | 629 |  |  |  | 750 |  |  |  | 175 |  |  |  | — |  |
| Operating leases(1) |  |  | 140 |  |  |  | 6 |  |  |  | 34 |  |  |  | 20 |  |  |  | 80 |  |
| Capital expenditures |  |  | 130 |  |  |  | 130 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other funding requirements (3) |  |  | 36 |  |  |  | 6 |  |  |  | 22 |  |  |  | 8 |  |  |  | — |  |
| Subtotal |  |  | 9,120 |  |  |  | 1,050 |  |  |  | 2,034 |  |  |  | 623 |  |  |  | 5,413 |  |
| Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit or bank guarantees |  |  | 102 |  |  |  | 102 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 9,222 |  |  | $ | 1,152 |  |  | $ | 2,034 |  |  | $ | 623 |  |  | $ | 5,413 |  |

[0001193125-17-148855:mdna:95]
| (1) | Includes total future minimum rent expense under non-cancelable leases for both occupied and vacated facilities (rent expense |

[0001193125-17-148855:mdna:96]
is shown net of sublease income).

[0001193125-17-148855:mdna:97]
[same as prior period, unchanged from 0001193125-17-019732:mdna:94]

[0001193125-17-148855:mdna:98]
[same as prior period, unchanged from 0001193125-17-019732:mdna:95]

[0001193125-17-148855:mdna:99]
As of March 31, 2017,
we had a liability for unrecognized tax benefits and an accrual for the payment of related interest totaling $14 million, none of which is expected to be settled within one year. Outside of one year, we are unable to make a reasonably reliable
estimate of when cash settlement with a taxing authority will occur.

[0001193125-17-148855:mdna:100]
[same as prior period, unchanged from 0001193125-17-019732:mdna:97]

[0001193125-17-148855:mdna:101]
[same as prior period, unchanged from 0001193125-17-019732:mdna:98]

[0001193125-17-148855:mdna:102]
Since our fiscal year ended July 1, 2016, there have been no material changes in
our critical accounting policies and estimates. Refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended July 1, 2016, as filed with the SEC on August 5, 2016, for a discussion of our critical accounting policies and estimates.

[0001193125-17-148855:mdna:103]
[same as prior period, unchanged from 0001193125-17-019732:mdna:100]

[0001193125-17-148855:mdna:104]
See
“Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.

[0001193125-17-148855:mdna:105]
37
