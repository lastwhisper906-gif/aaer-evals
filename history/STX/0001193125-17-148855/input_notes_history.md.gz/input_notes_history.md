# STX note change history — 0001193125-17-019732 → 0001193125-17-148855


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-04-28):
[0001193125-17-148855:note_history:1]
Convolve, Inc. ("Convolve") and Massachusetts Institute of Technology ("MIT") v. Seagate Technology LLC, et al.— On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the "'635 patent") and U.S. Patent No. 5,638,267 (the "'267 patent"), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringed U.S. Patent No. 6,314,473 (the "'473 patent"). The district court ruled in 2010 that the '267 patent was out of the case.
  (was, 2017-01-26, similarity 0.9969):
[0001193125-17-019732:note_history:1]
Convolve, Inc. ("Convolve") and Massachusetts Institute of Technology ("MIT") v. Seagate Technology LLC, et al. - On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the "'635 patent") and U.S. Patent No. 5,638,267 (the "'267 patent"), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe U.S. Patent No. 6,314,473 (the "'473 patent"). The district court ruled in 2010 that the '267 patent was out of the case.

- changed (2017-04-28):
[0001193125-17-148855:note_history:2]
Alexander Shukh v. Seagate Technology —On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination and wrongful failure to name him as an inventor on certain Seagate patents. On March 31, 2014, the district court granted Seagate’s summary judgment motion. Mr. Shukh filed a notice of appeal on April 7, 2014. On October 2, 2015, the U.S. Court of Appeals for the Federal Circuit vacated and remanded the district court’s grant of summary judgment on Mr. Shukh’s claim for correction of inventorship and affirmed the district court’s grant of summary judgment as to all other claims. On October 29, 2015, Mr. Shukh filed a petition for rehearing en banc with the court of appeals; the petition was denied on December 17, 2015. On March 16, 2016, Shukh filed a petition for writ of certiorari to the U.S. Supreme Court; the petition was denied on June 27, 2016. On March 30, 2017, the parties entered into a confidential settlement to resolve this matter. This settlement did not have a material impact on the Company’s condensed consolidated financial statements.
  (was, 2017-01-26, similarity 0.8109):
[0001193125-17-019732:note_history:2]
Alexander Shukh v. Seagate Technology - On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination and wrongful failure to name him as an inventor on certain Seagate patents. On March 31, 2014, the district court granted Seagate’s summary judgment motion. Mr. Shukh filed a notice of appeal on April 7, 2014. On October 2, 2015, the U.S. Court of Appeals for the Federal Circuit vacated and remanded the district court’s grant of summary judgment on Mr. Shukh’s claim for correction of inventorship and affirmed the district court’s grant of summary judgment as to all other claims. On October 29, 2015, Mr. Shukh filed a petition for rehearing en banc with the court of appeals; the petition was denied on December 17, 2015. On March 16, 2016, Shukh filed a petition for writ of certiorari to the U.S. Supreme Court; the petition was denied on June 27, 2016. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- changed (2017-04-28):
[0001193125-17-148855:note_history:3]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.—On June 5, 2013, Enova Technology Corporation (“Enova”) filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995 (the '"995 patent"), “Cryptographic Device,” and U.S. Patent No. 7,900,057 (the "'057 patent"), “Cryptographic Serial ATA Apparatus and Method.” The Company believes the claims are without merit and intends to vigorously defend this case. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the ‘995 and ‘057 patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ‘057 patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 patent are held unpatentable. Enova has appealed PTAB’s decisions on the ‘995 patent and the ‘057 patent to the U.S. Court of Appeals for the Federal Circuit. Oral argument for the appeal from PTAB’s decision on the ‘995 patent was held on March 13, 2017, at the court of appeals. On March 20, 2017, the court of appeals issued its judgment affirming PTAB's decision on the '995 patent. A hearing before the court of appeals for the appeal from PTAB’s decision on the ‘057 patent has not yet been scheduled. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2017-01-26, similarity 0.9452):
[0001193125-17-019732:note_history:3]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.—On June 5, 2013, Enova Technology Corporation (“Enova”) filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995 (the '"995 patent"), “Cryptographic Device,” and U.S. Patent No. 7,900,057 (the "'057 patent"), “Cryptographic Serial ATA Apparatus and Method.” The Company believes the claims are without merit and intends to vigorously defend this case. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the ‘995 and ‘057 patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ‘057 patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 patent are held unpatentable. Enova has appealed PTAB’s decisions on the ‘995 patent and the ‘057 patent to the U.S. Court of Appeals for the Federal Circuit. Oral argument for the appeal from PTAB’s decision on the ‘995 patent is scheduled for March 13, 2017, at the court of appeals. A hearing before the court of appeals for the appeal from PTAB’s decision on the ‘057 patent has not yet been scheduled. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- added (2017-04-28):
[0001193125-17-148855:note_history:4]
The Company is involved in a number of other judicial, regulatory and administrative proceedings incidental to its business, and from time to time, the Company may be involved in various legal, regulatory or administrative investigation, negotiations or proceeding arising in the normal course of business.  Although occasional adverse decisions or settlements may occur or adverse actions taken against the Company, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.

- removed (2017-04-28):
[0001193125-17-019732:note_history:5]
The Company is involved in a number of other judicial and administrative proceedings incidental to its business, and the Company may be involved in various legal proceedings arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-04-28):
[0001193125-17-148855:note_history:6]
Seagate Technology plc (the "Company" or "Seagate") is a leading provider of electronic data storage technology and solutions.  Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, it produces a broad range of electronic data storage products including solid state drives ("SSD") in its Enterprise market portfolio and solid state hybrid drives ("SSHD"). The Company's storage technology portfolio also includes storage subsystems, and high performance computing ("HPC") solutions.
  (was, 2017-01-26, similarity 0.6575):
[0001193125-17-019732:note_history:6]
Seagate Technology plc (the "Company"or "Seagate") is a leading provider of electronic data storage technology and solutions.  Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, it produces a broad range of electronic data storage products including solid state hybrid drives ("SSHD"), solid state drives ("SSD"), PCIe cards and SATA controllers. Its storage technology portfolio also includes storage subsystems, and high performance computing ("HPC") solutions.

- changed (2017-04-28):
[0001193125-17-148855:note_history:7]
The Company's products are designed for mission critical and nearline applications in enterprise servers and storage systems; client compute applications, where its products are designed primarily for desktop and mobile computing; and client non-compute applications, where its products are designed for a wide variety of end user devices such as portable external storage systems, personal data backup systems, surveillance systems, digital video recorders ("DVRs") and gaming consoles.
  (was, 2017-01-26, similarity 0.7776):
[0001193125-17-019732:note_history:7]
The Company's products are designed for mission critical and nearline applications in enterprise servers and storage systems; client compute applications, where its products are designed primarily for desktop and mobile computing; and client non-compute applications, where its products are designed for a wide variety of end user devices such as digital video recorders ("DVRs"), personal data backup systems, portable external storage systems, digital media systems and surveillance systems.

- changed (2017-04-28):
[0001193125-17-148855:note_history:8]
The results of operations for the three and nine months ended March 31, 2017, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending June 30, 2017. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three and nine months ended March 31, 2017 and the three and nine months ended April 1, 2016 consisted of 13 weeks and 39 weeks, respectively. Fiscal year 2017 will be comprised of 52 weeks and will end on June 30, 2017. The fiscal quarters ended March 31, 2017, December 30, 2016, and April 1, 2016, are also referred to herein as the “March 2017 quarter”, the “December 2016 quarter”, and the “March 2016 quarter”, respectively.
  (was, 2017-01-26, similarity 0.8053):
[0001193125-17-019732:note_history:8]
The results of operations for the three and six months ended December 30, 2016, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending June 30, 2017. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three and six months ended December 30, 2016 and the three and six months ended January 1, 2016 consisted of 13 weeks and 26 weeks, respectively. Fiscal year 2017 will be comprised of 52 weeks and will end on June 30, 2017. The fiscal quarters ended December 30, 2016, September 30, 2016, and January 1, 2016, are also referred to herein as the “December 2016 quarter”, the “September 2016 quarter”, and the “December 2015 quarter”, respectively.

- changed (2017-04-28):
[0001193125-17-148855:note_history:9]
In May 2014, August 2015, April 2016, May 2016 and December 2016, the Financial Accounting Standards Board ("FASB") issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, ASU 2016-12 (ASC Topic 606) Revenue from Contracts with Customers, Narrow-Scope Improvements and Practical Expedients, and ASU 2016-20 (ASC Topic 606) Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted for annual periods beginning after December 15, 2016, which is first quarter of fiscal 2018 for the Company. This standard may be applied retrospectively to all prior periods presented, or retrospectively with a cumulative adjustment to retained earnings in the year of adoption ("modified retrospective transition approach"). The Company is in the process of assessing the impact, on its condensed consolidated financial statements and plans to adopt the modified retrospective transition approach.
  (was, 2017-01-26, similarity 0.9976):
[0001193125-17-019732:note_history:9]
In May 2014, August 2015, April 2016, May 2016 and December 2016, the Financial Accounting Standards Board ("FASB") issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, ASU 2016-12 (ASC Topic 606) Revenue from Contracts with Customers, Narrow-Scope Improvements and Practical Expedients, and ASU 2016-20 (ASC Topic 606) Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted for annual periods beginning after December 15, 2016, which is first quarter of fiscal 2018 for the Company. This standard may be applied retrospectively to all prior periods presented, or retrospectively with a cumulative adjustment to retained earnings in the year of adoption ("modified retrospective transition approach"). The Company is in the process of assessing the impact, if any, on its condensed consolidated financial statements and plans to adopt the modified retrospective transition approach.

- changed (2017-04-28):
[0001193125-17-148855:note_history:10]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. The Company is required to adopt the guidance in the first quarter of fiscal 2018. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company is in the process of finalizing its assessment of the impact of this ASU, which is not expected to have a material impact on its condensed consolidated financial statements.
  (was, 2017-01-26, similarity 0.882):
[0001193125-17-019732:note_history:10]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. The Company is required to adopt the guidance in the first quarter of fiscal 2018. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company is in the process of assessing the impact, if any, of this ASU on its condensed consolidated financial statements.

- changed (2017-04-28):
[0001193125-17-148855:note_history:11]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments - Overall Recognition and Measurement of Financial Assets and Financial Liabilities. The amendments in this ASU require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted for only certain portions of the ASU. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.
  (was, 2017-01-26, similarity 0.9895):
[0001193125-17-019732:note_history:11]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments - Overall Recognition and Measurement of Financial Assets and Financial Liabilities. The amendments in this ASU require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities.The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted for only certain portions of the ASU. The Company is in the process of assessing the impact, if any, on its condensed consolidated financial statements.

- changed (2017-04-28):
[0001193125-17-148855:note_history:12]
In February 2016, the FASB issued ASU 2016-02 (ASC Topic 842), Leases. The ASU amends a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The Company is required to adopt the guidance in the first quarter of fiscal 2020. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.
  (was, 2017-01-26, similarity 0.9893):
[0001193125-17-019732:note_history:12]
In February 2016, the FASB issued ASU 2016-02 (ASC Topic 842), Leases. The ASU amends a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The Company is required to adopt the guidance in the first quarter of fiscal 2020. Early adoption is permitted. The Company is in the process of assessing the impact on its condensed consolidated financial statements.

- changed (2017-04-28):
[0001193125-17-148855:note_history:13]
In March 2016, the FASB issued ASU 2016-09 (ASC Topic 718), Stock Compensation - Improvements to Employee Share-Based Payment Accounting. The amendments in this ASU are intended to simplify several areas of accounting for share-based compensation arrangements, including the income tax consequences, classification on the consolidated statement of cash flows and treatment of forfeitures. The Company is required to adopt the guidance in the first quarter of fiscal 2018. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.
  (was, 2017-01-26, similarity 0.9926):
[0001193125-17-019732:note_history:13]
In March 2016, the FASB issued ASU 2016-09 (ASC Topic 718), Stock Compensation - Improvements to Employee Share-Based Payment Accounting. The amendments in this ASU are intended to simplify several areas of accounting for share-based compensation arrangements, including the income tax consequences, classification on the consolidated statement of cash flows and treatment of forfeitures. The Company is required to adopt the guidance in the first quarter of fiscal 2018. Early adoption is permitted. The Company is in the process of assessing the impact, if any, of this ASU on its condensed consolidated financial statements.

- changed (2017-04-28):
[0001193125-17-148855:note_history:14]
In August 2016, the FASB issued ASU 2016-15 (ASC Topic 230), Statement of Cash Flows - Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU are intended to clarify how certain cash receipts and cash payment are presented and classified in the statement of cash flows. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.
  (was, 2017-01-26, similarity 0.9914):
[0001193125-17-019732:note_history:14]
In August 2016, the FASB issued ASU 2016-15 (ASC Topic 230), Statement of Cash Flows - Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU are intended to clarify how certain cash receipts and cash payment are presented and classified in the statement of cash flows. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact, if any, of this ASU on its condensed consolidated financial statements.

- changed (2017-04-28):
[0001193125-17-148855:note_history:15]
In October 2016, the FASB issued ASU 2016-16 (ASC Topic 740), Income Taxes: Intra-Entity Transfers of Assets Other Than Inventory. The amendments in this ASU require the recognition of the income tax consequences for intra-entity transfers of assets other than inventory when the transfer occurs. Under current GAAP, current and deferred income taxes for intra-entity asset transfers are not recognized until the asset has been sold to an outside party. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.
  (was, 2017-01-26, similarity 0.9933):
[0001193125-17-019732:note_history:15]
In October 2016, the FASB issued ASU 2016-16 (ASC Topic 740), Income Taxes: Intra-Entity Transfers of Assets Other Than Inventory. The amendments in this ASU require the recognition of the income tax consequences for intra-entity transfers of assets other than inventory when the transfer occurs. Under current GAAP, current and deferred income taxes for intra-entity asset transfers are not recognized until the asset has been sold to an outside party. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact, if any, of this ASU on its condensed consolidated financial statements.

- changed (2017-04-28):
[0001193125-17-148855:note_history:16]
In January 2017, the FASB issued ASU 2017-01 (ASC Topic 805), Business Combination: Clarifying the Definition of a Business. The amendments in this ASU change the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.
  (was, 2017-01-26, similarity 0.9909):
[0001193125-17-019732:note_history:16]
In January 2017, the FASB issued ASU 2017-01 (ASC Topic 805), Business Combination: Clarifying the Definition of a Business. The amendments in this ASU change the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company is required to adopt the guidance in the first quarter of fiscal 2019. Early adoption is permitted. The Company is in the process of assessing the impact, if any, of this ASU on its condensed consolidated financial statements.

- added (2017-04-28):
[0001193125-17-148855:note_history:17]
In January 2017, the FASB issued ASU 2017-04 (ASC Topic 350), Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment. The amendments in this ASU eliminate Step 2 from the goodwill impairment test, which requires entities to calculate the implied fair value of goodwill to measure a goodwill impairment charge. Instead, entities will record an impairment charge based on the excess of a reporting unit's carrying amount over its fair value, determined in step 1. The Company elected to adopt this ASU in the March 2017 quarter on a prospective basis with no material impact on the Company's condensed consolidated financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-04-28):
[0001193125-17-148855:note_history:18]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio.  On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to allow for higher net leverage levels. The Company was in compliance with the modified covenants as of March 31, 2017 and expects to be in compliance for the next 12 months.
  (was, 2017-01-26, similarity 0.9866):
[0001193125-17-019732:note_history:18]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio.  On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to allow for higher net leverage levels. The Company was in compliance with the modified covenants as of December 30, 2016 and expects to be in compliance for the next 12 months.

- changed (2017-04-28):
[0001193125-17-148855:note_history:19]
As of March 31, 2017, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.
  (was, 2017-01-26, similarity 0.96):
[0001193125-17-019732:note_history:19]
As of December 30, 2016, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

- changed (2017-04-28):
[0001193125-17-148855:note_history:20]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2017 quarter, the Company repurchased $39 million aggregate principal amount of the 2018 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately $1 million during the three and nine months ended March 31, 2017, which is included in Other, net on the Condensed Consolidated Statements of Operations.
  (was, 2017-01-26, similarity 0.6409):
[0001193125-17-019732:note_history:20]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- added (2017-04-28):
[0001193125-17-148855:note_history:21]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman, and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. On March 15, 2017, the Company exercised its call option by providing notice of the redemption to the trustee of its intention to redeem all of its remaining outstanding 2021 Notes. The Notes will be redeemed on May 1, 2017 (the "Redemption Date") at a redemption price equal to $102.333 per $100 principal amount of the 2021 Notes redeemed plus accrued interest to the Redemption Date. As a result, the 2021 Notes are classified as Current portion of long-term debt on the Company's Condensed Consolidated Balance Sheet at March 31, 2017.

- added (2017-04-28):
[0001193125-17-148855:note_history:22]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). On February 3, 2017, Seagate HDD Cayman issued, in a private placement, $750 million in aggregate principal amount of 4.25% Senior Notes which will mature on March 1, 2022. The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year, commencing on September 1, 2017. At any time before February 1, 2022, Seagate HDD Cayman may redeem some or all of the 2022 Notes at a 'make whole' redemption price, plus accrued and unpaid interest, if any. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the 2022 Notes redeemed, plus (2) the excess, if any, of (a) the sum of the present values of the remaining scheduled payments of principal and interest on the 2022 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 40 basis points, minus accrued and unpaid interest, if any, on the 2022 Notes being redeemed to, but excluding, the redemption date over (b) the principal amount of the 2022 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the 2022 Notes being redeemed to, but excluding, the redemption date. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2017-04-28):
[0001193125-17-148855:note_history:23]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2017 quarter, the Company repurchased $34 million aggregate principal amount of the 2023 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded an immaterial loss on the repurchase during the three and nine months ended March 31, 2017, which is included in Other, net on the Condensed Consolidated Statements of Operations.
  (was, 2017-01-26, similarity 0.6483):
[0001193125-17-019732:note_history:23]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- added (2017-04-28):
[0001193125-17-148855:note_history:24]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”).  On February 3, 2017, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 4.875% Senior Notes which will mature on March 1, 2024. The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year, commencing on September 1, 2017. At any time before January 1, 2024, Seagate HDD Cayman may redeem some or all of the 2024 Notes at a 'make whole' redemption price, plus accrued and unpaid interest, if any. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the 2024 Notes redeemed, plus (2) the excess, if any, of (a) the sum of the present values of the remaining scheduled payments of principal and interest on the 2024 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 45 basis points, minus accrued and unpaid interest, if any, on the 2024 Notes being redeemed to, but excluding, the redemption date over (b) the principal amount of the 2024 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the 2024 Notes being redeemed to, but excluding, the redemption date. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2017-04-28):
[0001193125-17-148855:note_history:25]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2017 quarter, the Company repurchased $20 million aggregate principal amount of the 2025 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded a gain on the repurchase of approximately $1 million during the three and nine months ended March 31, 2017, which is included in Other, net on the Condensed Consolidated Statements of Operations.
  (was, 2017-01-26, similarity 0.6396):
[0001193125-17-019732:note_history:25]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2017-04-28):
[0001193125-17-148855:note_history:26]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2017 quarter, the Company repurchased $4 million aggregate principal amount of the 2027 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded an immaterial gain on the repurchase during the three and nine months ended March 31, 2017, which is included in Other, net on the Condensed Consolidated Statements of Operations.
  (was, 2017-01-26, similarity 0.6464):
[0001193125-17-019732:note_history:26]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2017-04-28):
[0001193125-17-148855:note_history:27]
At March 31, 2017, future principal payments on long-term debt were as follows (in millions):
  (was, 2017-01-26, similarity 0.9492):
[0001193125-17-019732:note_history:27]
At December 30, 2016, future principal payments on long-term debt were as follows (in millions):

- changed (2017-04-28):
[0001193125-17-148855:note_history:28]
| Fiscal Year |  | Amount |
| Remainder of 2017 |  | $ | 158 |  |
| 2018 |  | — |  |
| 2019 |  | 761 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| Thereafter |  | 4,367 |  |
| Total |  | $ | 5,286 |  |
  (was, 2017-01-26, similarity 0.9937):
[0001193125-17-019732:note_history:28]
| Fiscal Year |  | Amount |
| Remainder of 2017 |  | $ | — |  |
| 2018 |  | — |  |
| 2019 |  | 800 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| Thereafter |  | 3,333 |  |
| Total |  | $ | 4,133 |  |

- removed (2017-04-28):
[0001193125-17-019732:note_history:29]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman, and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-04-28):
[0001193125-17-148855:note_history:30]
|  |  | March 31, 2017 |  | July 1, 2016 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 761 |  |  | $ | 781 |  |  | $ | 800 |  |  | $ | 804 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 162 |  |  | 158 |  |  | 164 |  |
| 4.25% Senior Notes due March 2022 |  | 748 |  |  | 743 |  |  | — |  |  | — |  |
| 4.75% Senior Notes due June 2023 |  | 956 |  |  | 961 |  |  | 990 |  |  | 857 |  |
| 4.875% Senior Notes due March 2024 |  | 496 |  |  | 491 |  |  | — |  |  | — |  |
| 4.75% Senior Notes due January 2025 |  | 975 |  |  | 958 |  |  | 995 |  |  | 795 |  |
| 4.875% Senior Notes due June 2027 |  | 695 |  |  | 654 |  |  | 698 |  |  | 514 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 446 |  |  | 489 |  |  | 357 |  |
|  |  | $ | 5,278 |  |  | $ | 5,196 |  |  | $ | 4,130 |  |  | $ | 3,491 |  |
| Less: debt issuance costs |  | (47 | ) |  | — |  |  | (39 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 5,231 |  |  | $ | 5,196 |  |  | $ | 4,091 |  |  | $ | 3,491 |  |
| Less: short-term borrowings and current portion of long-term debt |  | (158 | ) |  | (162 | ) |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 5,073 |  |  | $ | 5,034 |  |  | $ | 4,091 |  |  | $ | 3,491 |  |
  (was, 2017-01-26, similarity 0.9186):
[0001193125-17-019732:note_history:30]
|  |  | December 30, 2016 |  | July 1, 2016 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 800 |  |  | $ | 822 |  |  | $ | 800 |  |  | $ | 804 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 163 |  |  | 158 |  |  | 164 |  |
| 4.75% Senior Notes due June 2023 |  | 990 |  |  | 984 |  |  | 990 |  |  | 857 |  |
| 4.75% Senior Notes due January 2025 |  | 995 |  |  | 944 |  |  | 995 |  |  | 795 |  |
| 4.875% Senior Notes due June 2027 |  | 698 |  |  | 633 |  |  | 698 |  |  | 514 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 419 |  |  | 489 |  |  | 357 |  |
|  |  | $ | 4,130 |  |  | $ | 3,965 |  |  | $ | 4,130 |  |  | $ | 3,491 |  |
| Less: debt issuance costs |  | (37 | ) |  | — |  |  | (39 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 4,093 |  |  | $ | 3,965 |  |  | $ | 4,091 |  |  | $ | 3,491 |  |
| Less: short-term borrowings and current portion of long-term debt |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 4,093 |  |  | $ | 3,965 |  |  | $ | 4,091 |  |  | $ | 3,491 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-04-28):
[0001193125-17-148855:note_history:31]
At March 31, 2017, future principal payments on long-term debt were as follows (in millions):
  (was, 2017-01-26, similarity 0.9492):
[0001193125-17-019732:note_history:31]
At December 30, 2016, future principal payments on long-term debt were as follows (in millions):

- changed (2017-04-28):
[0001193125-17-148855:note_history:32]
| Fiscal Year |  | Amount |
| Remainder of 2017 |  | $ | 158 |  |
| 2018 |  | — |  |
| 2019 |  | 761 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| Thereafter |  | 4,367 |  |
| Total |  | $ | 5,286 |  |
  (was, 2017-01-26, similarity 0.9937):
[0001193125-17-019732:note_history:32]
| Fiscal Year |  | Amount |
| Remainder of 2017 |  | $ | — |  |
| 2018 |  | — |  |
| 2019 |  | 800 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| Thereafter |  | 3,333 |  |
| Total |  | $ | 4,133 |  |
