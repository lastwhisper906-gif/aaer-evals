# STX MD&A — 0001137789-23-000128


## mdna

[0001137789-23-000128:mdna:1]
[same as prior period, unchanged from 0001137789-23-000029:mdna:1]

[0001137789-23-000128:mdna:2]
The following is a discussion of the financial condition, changes in financial condition and results of operations for our fiscal quarters ended September 29, 2023, June 30, 2023 and September 30, 2022, referred to herein as the “September 2023 quarter”, the “June 2023 quarter” and the “September 2022 quarter”, respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The September 2023 quarter, June 2023 quarter and September 2022 quarter were each 13 weeks.

[0001137789-23-000128:mdna:3]
You should read this discussion in conjunction with financial information and related notes included in this Quarterly Report on Form 10-Q. Unless the context indicates otherwise, as used herein, the terms “we,” “us,” “Seagate,” the “Company” and “our” refer collectively to Seagate Technology Holdings plc, an Irish public limited company, and its subsidiaries. References to “$” or “dollars” are to United States dollars.

[0001137789-23-000128:mdna:4]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is provided in addition to the accompanying Condensed Consolidated Financial Statements and notes to assist readers in understanding our results of operations, financial condition and cash flows. Our MD&A is organized as follows:

[0001137789-23-000128:mdna:5]
•Overview of the September 2023 quarter. Highlights of events in the September 2023 quarter that impacted our financial position.

[0001137789-23-000128:mdna:6]
•Results of Operations. Analysis of our financial results comparing the September 2023 quarter to the June 2023 quarter and the September 2022 quarter.

[0001137789-23-000128:mdna:7]
•Liquidity and Capital Resources. Analysis of changes in our balance sheets and cash flows, and discussion of our financial condition including potential sources of liquidity, material cash requirements and their general purpose.

[0001137789-23-000128:mdna:8]
[same as prior period, unchanged from 0001137789-23-000029:mdna:8]

[0001137789-23-000128:mdna:9]
[same as prior period, unchanged from 0001137789-23-000029:mdna:9]

[0001137789-23-000128:mdna:10]
Overview of the September 2023 quarter

[0001137789-23-000128:mdna:11]
During the September 2023 quarter, we shipped 90 exabytes of HDD storage capacity. We generated revenue of approximately $1.5 billion with a gross margin of 10%. Our operating cash flow was $127 million and we paid $145 million in dividends. We issued $1.5 billion of convertible senior notes, repaid $1.3 billion of variable rate term loans, recorded a net loss of $29 million from early redemption of debt and a net gain of $104 million as a result of the termination of interest rate swap agreements.

[0001137789-23-000128:mdna:12]
Recent Developments, Economic Conditions and Challenges

[0001137789-23-000128:mdna:13]
During the September 2023 quarter, the data storage industry and our business continued to be impacted by macroeconomic headwinds and customer inventory adjustments, which continued to restrain near term demand for our products. As a result of the challenging demand environment, we reduced manufacturing production plans and incurred order cancellation fees to terminate certain purchase commitments that were made with our suppliers and recognized manufacturing underutilization charges, among other actions. We expect these factors will continue to impact our business and results of operations over the near-term.

[0001137789-23-000128:mdna:14]
For a further discussion of the uncertainties and business risks, see “Part II, Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q.

[0001137789-23-000128:mdna:15]
[same as prior period, unchanged from 0001137789-23-000029:mdna:21]

[0001137789-23-000128:mdna:16]
[same as prior period, unchanged from 0001137789-23-000029:mdna:22]

[0001137789-23-000128:mdna:17]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | September 29, 2023 |  | June 30, 2023 |  | September 30, 2022 |  |  |  |  |
| Revenue |  | $ | 1,454 |  |  | $ | 1,602 |  |  | $ | 2,035 |  |  |  |  |  |
| Cost of revenue |  | 1,305 |  |  | 1,298 |  |  | 1,553 |  |  |  |  |  |
| Gross profit |  | 149 |  |  | 304 |  |  | 482 |  |  |  |  |  |
| Product development |  | 171 |  |  | 172 |  |  | 234 |  |  |  |  |  |
| Marketing and administrative |  | 105 |  |  | 114 |  |  | 129 |  |  |  |  |  |
| Amortization of intangibles |  | — |  |  | — |  |  | 3 |  |  |  |  |  |
| Restructuring and other, net |  | 2 |  |  | (8) |  |  | 9 |  |  |  |  |  |
| (Loss) income from operations |  | (129) |  |  | 26 |  |  | 107 |  |  |  |  |  |
| Other expense, net |  | (18) |  |  | (111) |  |  | (80) |  |  |  |  |  |
| (Loss) income before income taxes |  | (147) |  |  | (85) |  |  | 27 |  |  |  |  |  |
| Provision for (Benefit from) income taxes |  | 37 |  |  | 7 |  |  | (2) |  |  |  |  |  |
| Net (loss) income |  | $ | (184) |  |  | $ | (92) |  |  | $ | 29 |  |  |  |  |  |

[0001137789-23-000128:mdna:18]
|  |  | For the Three Months Ended |  |  |
|  |  | September 29, 2023 |  | June 30, 2023 |  | September 30, 2022 |  |  |  |  |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  |  |  |  |
| Cost of revenue |  | 90 |  |  | 81 |  |  | 76 |  |  |  |  |  |
| Gross margin |  | 10 |  |  | 19 |  |  | 24 |  |  |  |  |  |
| Product development |  | 12 |  |  | 11 |  |  | 12 |  |  |  |  |  |
| Marketing and administrative |  | 7 |  |  | 7 |  |  | 7 |  |  |  |  |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |  |  |  |  |
| Restructuring and other, net |  | — |  |  | — |  |  | — |  |  |  |  |  |
| Operating margin |  | (9) |  |  | 1 |  |  | 5 |  |  |  |  |  |
| Other expense, net |  | (1) |  |  | (7) |  |  | (4) |  |  |  |  |  |
| (Loss) income before income taxes |  | (10) |  |  | (6) |  |  | 1 |  |  |  |  |  |
| Provision for income taxes |  | 3 |  |  | — |  |  | — |  |  |  |  |  |
| Net (loss) income |  | (13) | % |  | (6) | % |  | 1 | % |  |  |  |  |

[0001137789-23-000128:mdna:19]
29

[0001137789-23-000128:mdna:20]
[same as prior period, unchanged from 0001137789-23-000029:mdna:25]

[0001137789-23-000128:mdna:21]
The following table summarizes information regarding consolidated revenues by channel, geography and market, and HDD exabytes shipped by market and price per terabyte:

[0001137789-23-000128:mdna:22]
|  |  | For the Three Months Ended |  |  |
|  |  | September 29, 2023 |  | June 30, 2023 |  | September 30, 2022 |  |  |  |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 71 | % |  | 74 | % |  | 76 | % |  |  |  |  |
| Distributors |  | 18 | % |  | 14 | % |  | 15 | % |  |  |  |  |
| Retailers |  | 11 | % |  | 12 | % |  | 9 | % |  |  |  |  |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 56 | % |  | 59 | % |  | 39 | % |  |  |  |  |
| Americas |  | 31 | % |  | 29 | % |  | 46 | % |  |  |  |  |
| EMEA |  | 13 | % |  | 12 | % |  | 15 | % |  |  |  |  |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 70 | % |  | 61 | % |  | 68 | % |  |  |  |  |
| Legacy |  | 19 | % |  | 25 | % |  | 19 | % |  |  |  |  |
| Other |  | 11 | % |  | 14 | % |  | 13 | % |  |  |  |  |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 79 |  |  | 75 |  |  | 104 |  |  |  |  |  |
| Legacy |  | 11 |  |  | 16 |  |  | 14 |  |  |  |  |  |
| Total |  | 90 |  |  | 91 |  |  | 118 |  |  |  |  |  |
| HDD Price per Terabyte |  | $ | 14 |  |  | $ | 15 |  |  | $ | 15 |  |  |  |  |  |

[0001137789-23-000128:mdna:23]
______________________________

[0001137789-23-000128:mdna:24]
[same as prior period, unchanged from 0001137789-23-000029:mdna:29]

[0001137789-23-000128:mdna:25]
Revenue in the September 2023 quarter decreased by $148 million compared to the June 2023 quarter, primarily due to lower market demand in legacy markets and our non-HDD products that were impacted by macroeconomic conditions, partially offset by an increase in mass capacity exabytes shipped.

[0001137789-23-000128:mdna:26]
Revenue in the September 2023 quarter decreased by $581 million compared to the September 2022 quarter, primarily due to a decrease in exabytes shipped, reflecting broad-based demand slowdown resulting from weaker macroeconomic conditions.

[0001137789-23-000128:mdna:27]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 20% of gross revenue for the September 2023 quarter, 19% for the June 2023 quarter and 18% for the September 2022 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 3% of quarterly gross revenue in all periods presented.

[0001137789-23-000128:mdna:28]
[same as prior period, unchanged from 0001137789-23-000029:mdna:33]

[0001137789-23-000128:mdna:29]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | September 29, 2023 |  | June 30, 2023 |  | September 30, 2022 |  |  |  |  |
| Cost of revenue |  | $ | 1,305 |  |  | $ | 1,298 |  |  | $ | 1,553 |  |  |  |  |  |
| Gross profit |  | 149 |  |  | 304 |  |  | 482 |  |  |  |  |  |
| Gross margin |  | 10 | % |  | 19 | % |  | 24 | % |  |  |  |  |

[0001137789-23-000128:mdna:30]
Gross margin for the September 2023 quarter decreased compared to the June 2023 quarter, primarily driven by $118 million of order cancellation fees, an increase of $19 million, for a total of $59 million, in factory underutilization charges associated with lower production levels and an increase of $10 million in accelerated depreciation expense for certain capital equipment, partially offset by a decrease of $9 million in depreciation expense as a result of change in useful lives of certain capital equipment.

[0001137789-23-000128:mdna:31]
Gross margin for the September 2023 quarter decreased compared to the September 2022 quarter primarily driven by $118 million of order cancellation fees, accelerated depreciation expense for certain capital equipment and less favorable product mix.

[0001137789-23-000128:mdna:32]
In the September 2023 quarter, total warranty cost was 1.8% of revenue and included an unfavorable change in estimates of prior warranty accruals of 0.9% of revenue primarily due to changes to our estimated future product return rates. Warranty cost related to new shipments was 0.9%, 0.8% and 0.6% of revenue for the September 2023 quarter, June 2023 quarter and September 2022 quarter, respectively.

[0001137789-23-000128:mdna:33]
[same as prior period, unchanged from 0001137789-23-000029:mdna:40]

[0001137789-23-000128:mdna:34]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | September 29, 2023 |  | June 30, 2023 |  | September 30, 2022 |  |  |  |  |
| Product development |  | $ | 171 |  |  | $ | 172 |  |  | $ | 234 |  |  |  |  |  |
| Marketing and administrative |  | 105 |  |  | 114 |  |  | 129 |  |  |  |  |  |
| Amortization of intangibles |  | — |  |  | — |  |  | 3 |  |  |  |  |  |
| Restructuring and other, net |  | 2 |  |  | (8) |  |  | 9 |  |  |  |  |  |
| Operating expenses |  | $ | 278 |  |  | $ | 278 |  |  | $ | 375 |  |  |  |  |  |

[0001137789-23-000128:mdna:35]
Product development expense. Product development expenses decreased by $1 million in the September 2023 quarter compared to the June 2023 quarter, primarily due to a $6 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our restructuring plans and temporary salary reduction, and a $2 million decrease in depreciation expense, partially offset by a $4 million increase in lease expense and a $3 million increase in supply costs.

[0001137789-23-000128:mdna:36]
Product development expenses decreased by $63 million in the September 2023 quarter compared to the September 2022 quarter, primarily due to a $38 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our restructuring plans and temporary salary reduction, and a $27 million decrease in depreciation expense, partially offset by a $6 million increase in lease expense.

[0001137789-23-000128:mdna:37]
Marketing and administrative expense. Marketing and administrative expenses decreased by $9 million in the September 2023 quarter compared to the June 2023 quarter primarily due to a $5 million decrease in outside services expense, a $2 million decrease in compensation and other employee benefits primarily from the reduction in headcount as a result of our restructuring plans and temporary salary reduction, and a $2 million decrease in advertising costs.

[0001137789-23-000128:mdna:38]
Marketing and administrative expenses decreased by $24 million in the September 2023 quarter compared to the September 2022 quarter primarily due to a $9 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our restructuring plans and temporary salary reduction, a $6 million decrease in advertising costs, a $5 million decrease in outside services expense and a $4 million decrease in travel expenses due to cost saving measures.

[0001137789-23-000128:mdna:39]
Restructuring and other, net. Restructuring and other, net in the September 2023 quarter was not material.

[0001137789-23-000128:mdna:40]
Restructuring and other, net for the June 2023 quarter was a net gain of $8 million, primarily from the sales of certain properties and assets of $156 million, partially offset by workforce reduction costs and other exit costs under our April 2023 restructuring plan.

[0001137789-23-000128:mdna:41]
Restructuring and other, net for the September 2022 quarter was $9 million primarily related to cost incurred as part of restructuring of our workforce.

[0001137789-23-000128:mdna:42]
Other Expense, Net

[0001137789-23-000128:mdna:43]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | September 29, 2023 |  | June 30, 2023 |  | September 30, 2022 |  |  |  |  |
| Other Expense, net |  | $ | (18) |  |  | $ | (111) |  |  | $ | (80) |  |  |  |  |  |

[0001137789-23-000128:mdna:44]
Other expense, net. Other expense, net decreased by $93 million for the September 2023 quarter compared to the June 2023 quarter primarily due to $104 million of net gain recognized from the termination of interest rate swaps associated with the repayment of term loans in the September 2023 quarter and $9 million impairment of investment in the June 2023 quarter, partially offset by $29 million of net loss recognized from early redemption of debt in the September 2023 quarter.

[0001137789-23-000128:mdna:45]
[same as prior period, unchanged from 0001137789-23-000029:mdna:20]

[0001137789-23-000128:mdna:46]
Other expense, net decreased by $62 million for the September 2023 quarter compared to the September 2022 quarter primarily due to $104 million of net gain recognized from the termination of interest rate swaps associated with the repayment of term loans, partially offset by $29 million of net loss recognized from early redemption of debt and $13 million net increase in interest expense primarily related to the new senior notes issued in the June 2023 quarter and the September 2023 quarter.

[0001137789-23-000128:mdna:47]
[same as prior period, unchanged from 0001137789-23-000029:mdna:56]

[0001137789-23-000128:mdna:48]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | September 29, 2023 |  | June 30, 2023 |  | September 30, 2022 |  |  |  |  |
| Provision for (benefit from) income taxes |  | $ | 37 |  |  | $ | 33 |  |  | $ | (2) |  |  |  |  |  |

[0001137789-23-000128:mdna:49]
We recorded an income tax provision of $37 million for the three months ended September 29, 2023. The income tax provision included approximately $33 million of net discrete expense, primarily associated with an increase in our valuation allowance to account for the impacts of new tax guidance which clarifies the treatment of specified research and experimental expenditures issued by the U.S. Treasury Department under Internal Revenue Code Section 174 during the September 2023 quarter, partially offset by excess tax benefits related to share-based compensation expense. We will have income taxes payable based on profits generated in various jurisdictions.

[0001137789-23-000128:mdna:50]
On August 16, 2022, the Inflation Reduction Act of 2022 (the “IRA”) was enacted into U.S. law. The legislation includes a new corporate alternative minimum tax (the “CAMT”) of 15% on the adjusted financial statement income (“AFSI”) of corporations with average AFSI exceeding $1.0 billion over a three-year period. We did not meet the criteria for fiscal year 2024. We will continue to monitor the potential application of CAMT for future years.

[0001137789-23-000128:mdna:51]
During the three months ended September 29, 2023, our unrecognized tax benefits, excluding interest and penalties decreased by approximately $9 million to $107 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. We do not expect material changes to our unrecognized tax benefits in the next twelve months beginning September 30, 2023.

[0001137789-23-000128:mdna:52]
We recorded an income tax benefit of $2 million for the three months ended September 30, 2022. The income tax provision for the three months ended September 30, 2022 included approximately $7 million of net discrete tax benefit, primarily associated with net excess tax benefits related to share-based compensation expense.

[0001137789-23-000128:mdna:53]
Our income tax provision recorded for the three months ended September 29, 2023 and September 30, 2022 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) increase in valuation allowance.

[0001137789-23-000128:mdna:54]
[same as prior period, unchanged from 0001137789-23-000029:mdna:63]

[0001137789-23-000128:mdna:55]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash will continue to be sufficient to fund our operations and meet our cash requirements for the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs and capital expenditures, will allow us to manage the ongoing impacts of macroeconomic headwinds including higher inflationary pressures, inventory adjustments by our customers and the overall market demand disruptions on our business operations for the foreseeable future. However, some challenges to our industry and to our business continue to remain uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to the global economic factors.

[0001137789-23-000128:mdna:56]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of September 29, 2023. For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, see “Part II, Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q.

[0001137789-23-000128:mdna:57]
[same as prior period, unchanged from 0001137789-23-000029:mdna:66]

[0001137789-23-000128:mdna:58]
| (Dollars in millions) |  | September 29, 2023 |  | June 30, 2023 |  | Change |
| Cash and cash equivalents |  | $ | 795 |  |  | $ | 786 |  |  | $ | 9 |  |

[0001137789-23-000128:mdna:59]
Our cash and cash equivalents as of September 29, 2023 increased by $9 million from June 30, 2023 primarily as a result of net cash of $127 million provided by operating activities and net proceeds of $1.5 billion from the issuance of convertible senior notes, partially offset by $1.3 billion redemption of term loans, dividends paid to our shareholders of $145 million, $126 million debt fees relating to issuance of long-term debt and capped call transaction and payments for capital expenditures of $70 million.

[0001137789-23-000128:mdna:60]
[same as prior period, unchanged from 0001137789-23-000029:mdna:69]

[0001137789-23-000128:mdna:61]
Cash provided by operating activities for the three months ended September 29, 2023 was $127 million and includes the effects of net loss adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-23-000128:mdna:62]
•a decrease of $100 million in accounts receivable, primarily due to lower revenue and timing of collections;

[0001137789-23-000128:mdna:63]
•a decrease of $88 million in inventories, primarily due to a decrease in units built to align with the prevailing demand environment; and

[0001137789-23-000128:mdna:64]
•an increase of $25 million cash proceeds received from the settlement of certain interest rate swap agreements; partially offset by

[0001137789-23-000128:mdna:65]
•a decrease of $89 million in accrued expenses as a result of payments related to restructuring activities;

[0001137789-23-000128:mdna:66]
•a decrease of $70 million in accounts payable, primarily due to a decrease in materials purchased; and

[0001137789-23-000128:mdna:67]
•a decrease of $12 million in accrued employee compensation, primarily due to timing of payroll accrual.

[0001137789-23-000128:mdna:68]
[same as prior period, unchanged from 0001137789-23-000029:mdna:76]

[0001137789-23-000128:mdna:69]
Cash used in investing activities for the three months ended September 29, 2023 was $70 million, primarily attributable to payments for the purchase of property, equipment and leasehold improvements.

[0001137789-23-000128:mdna:70]
[same as prior period, unchanged from 0001137789-23-000029:mdna:78]

[0001137789-23-000128:mdna:71]
Net cash used in financing activities of $49 million for the three months ended September 29, 2023 was primarily attributable to the following activities:

[0001137789-23-000128:mdna:72]
•$1.3 billion redemption of term loans;

[0001137789-23-000128:mdna:73]
•$145 million in dividend payments;

[0001137789-23-000128:mdna:74]
•$126 million debt fees relating to issuance of long-term debt and capped call transaction; and

[0001137789-23-000128:mdna:75]
•$25 million taxes paid related to net share settlement of equity awards; partially offset by

[0001137789-23-000128:mdna:76]
•$1.5 billion in net proceeds from the issuance of 2028 Notes and

[0001137789-23-000128:mdna:77]
•$35 million proceeds from issuance of ordinary shares under employee stock purchase plans.

[0001137789-23-000128:mdna:78]
[same as prior period, unchanged from 0001137789-23-000029:mdna:84]

[0001137789-23-000128:mdna:79]
Our primary sources of liquidity as of September 29, 2023 consist of: (1) approximately $795 million in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.5 billion available for borrowing under the revolving credit facility of the Tenth Amendment (the “Revolving Credit Facility”).

[0001137789-23-000128:mdna:80]
As of September 29, 2023, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-23-000128:mdna:81]
On September 27, 2023, we entered into the Tenth Amendment to modify our financial covenants: (1) interest coverage ratio and (2) total net leverage ratio. The Company is in compliance with the covenants as of September 29, 2023. We continue to evaluate our debt portfolio and structure to comply with our financial debt covenants.

[0001137789-23-000128:mdna:82]
[same as prior period, unchanged from 0001137789-23-000029:mdna:36]

[0001137789-23-000128:mdna:83]
[same as prior period, unchanged from 0001137789-23-000029:mdna:88]

[0001137789-23-000128:mdna:84]
[same as prior period, unchanged from 0001137789-23-000029:mdna:89]

[0001137789-23-000128:mdna:85]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness and to fund our quarterly dividend and any future strategic investments. As of September 29, 2023, our contractual cash requirements have not changed materially since our Annual Report on Form 10-K for the fiscal year ended June 30, 2023, except for the purchase obligations and long-term debt obligations.

[0001137789-23-000128:mdna:86]
[same as prior period, unchanged from 0001137789-23-000029:mdna:91]

[0001137789-23-000128:mdna:87]
Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. From time to time, we enter into long-term, non-cancelable purchase commitments or make large up-front investments with certain suppliers in order to secure certain components or technologies for the production of our products or to supplement our internal manufacturing capacity for certain components. As of September 29, 2023, we had unconditional purchase obligations of approximately $3.7 billion primarily related to purchases of inventory components with our suppliers. We expect $1.1 billion of these short-term commitments to be paid within one year and expect $2.6 billion of these long-term commitments to be paid thereafter.

[0001137789-23-000128:mdna:88]
During the three months ended September 29, 2023, we recorded order cancellation fees of $118 million to terminate certain purchase commitments related to the purchase of inventory components and equipment, which were reflected under Cost of revenue on our Condensed Consolidated Statements of Operations. As of September 29, 2023, cumulative unpaid order cancellation fees on the Condensed Consolidated Balance Sheet were $151 million, with $133 million in Accrued expenses and $18 million in Accounts payable, all of which is expected to be paid within one year.

[0001137789-23-000128:mdna:89]
[same as prior period, unchanged from 0001137789-23-000029:mdna:94]

[0001137789-23-000128:mdna:90]
On September 13, 2023, we issued the 2028 Notes of $1.5 billion and repaid Term Loans A1, A2 and A3 of $1.3 billion. The exchange was accounted for as a debt extinguishment and resulted in a net loss of $29 million for the first quarter of fiscal year 2024.

[0001137789-23-000128:mdna:91]
As of September 29, 2023, the future principal payment obligation on our long-term debt was $5.7 billion, which will mature in more than one year. As of September 29, 2023, future interest payments on this outstanding debt are estimated to be approximately $2.3 billion, of which $325 million is expected to be paid within one year. From time to time, we may repurchase any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 1. Financial Statements—Note 3. Debt” for more details.

[0001137789-23-000128:mdna:92]
[same as prior period, unchanged from 0001137789-23-000029:mdna:100]

[0001137789-23-000128:mdna:93]
We accrued a settlement penalty of $300 million for the quarter ended March 31, 2023, related to BIS’ allegations of violations of the U.S. EAR, which were subsequently resolved by the Settlement Agreement in April 2023. As part of the Settlement Agreement with BIS, quarterly payments of $15 million will be made over the course of five years beginning October 31, 2023, of which $60 million is expected to be paid within one year and $240 million thereafter. Refer to “Item 1. Financial Statements—Note 12. Legal, Environmental and Other Contingencies” for more details.

[0001137789-23-000128:mdna:94]
[same as prior period, unchanged from 0001137789-23-000029:mdna:102]

[0001137789-23-000128:mdna:95]
During the three months ended September 29, 2023, we recorded restructuring and other, net of $2 million, primarily related to the workforce reduction costs under the restructuring plans, and made cash payments of $89 million.

[0001137789-23-000128:mdna:96]
As of September 29, 2023, the future cash payments related to our remaining active restructuring plans were $32 million, of which $30 million is expected to be paid within one year.

[0001137789-23-000128:mdna:97]
[same as prior period, unchanged from 0001137789-23-000029:mdna:105]

[0001137789-23-000128:mdna:98]
During the September 2023 quarter, our Board of Directors declared dividends of $0.70 per share, totaling $146 million, which was paid on October 10, 2023. On October 26, 2023, our Board of Directors declared a quarterly cash dividend of $0.70 per share, payable on January 9, 2024 to shareholders of record at the close of business on December 21, 2023. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-23-000128:mdna:99]
[same as prior period, unchanged from 0001137789-23-000029:mdna:107]

[0001137789-23-000128:mdna:100]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker-assisted purchases, tender offers, or other means, including through the use of derivative transactions. As of September 29, 2023, $1.9 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-23-000128:mdna:101]
[same as prior period, unchanged from 0001137789-23-000029:mdna:109]

[0001137789-23-000128:mdna:102]
For fiscal year 2024, we expect capital expenditures to be lower than fiscal year 2023. We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-23-000128:mdna:103]
[same as prior period, unchanged from 0001137789-23-000029:mdna:114]

[0001137789-23-000128:mdna:104]
Our discussion and analysis of financial condition and results of operations are based upon our Condensed Consolidated Financial Statements, which have been prepared in accordance with U.S. generally accepted accounting principles. The preparation of such statements requires us to make estimates and assumptions that affect the reported amounts of revenues and expenses during the reporting period and the reported amounts of assets and liabilities as of the date of the financial statements. Our estimates are based on historical experience and other assumptions that we consider to be appropriate in the circumstances. However, actual future results may vary from our estimates.

[0001137789-23-000128:mdna:105]
Other than as described in “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies”, there have been no other material changes in our critical accounting policies and estimates. Refer to “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended June 30, 2023, as filed with the SEC on August 4, 2023, for a discussion of our critical accounting policies and estimates.

[0001137789-23-000128:mdna:106]
[same as prior period, unchanged from 0001137789-23-000029:mdna:117]

[0001137789-23-000128:mdna:107]
[same as prior period, unchanged from 0001137789-23-000029:mdna:118]
