# STX note change history — 0001137789-23-000029 → 0001137789-23-000128


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-10-27):
[0001137789-23-000128:note_history:1]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.
  (was, 2023-04-26, similarity 0.9996):
[0001137789-23-000029:note_history:1]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

- changed (2023-10-27):
[0001137789-23-000128:note_history:2]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgement in favor of Seagate on April 19, 2022. The parties filed post-trial motions with the district court in May 2022. On November 22, 2022, the court denied all pending post-trial motions. Lambeth Magnetic Structures LLC filed a notice of appeal to the Federal Circuit on December 20, 2022. A hearing date has not been set. The Company believes the asserted claims are without merit and intends to vigorously defend this case.
  (was, 2023-04-26, similarity 0.9994):
[0001137789-23-000029:note_history:2]
Lambeth Magnetic Structures LLC, v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgement in favor of Seagate on April 19, 2022. The parties filed post-trial motions with the district court in May 2022. On November 22, 2022, the court denied all pending post-trial motions. Lambeth Magnetic Structures LLC filed a notice of appeal to the Federal Circuit on December 20, 2022. A hearing date has not been set. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

- changed (2023-10-27):
[0001137789-23-000128:note_history:3]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the U.S. District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendant misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, as well as additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 8, 2022, the court entered an Amended Stipulation and Order of Dismissal with Prejudice to dismiss all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment Regarding Foreign Commerce and on October 14, 2022, the Seagate Entities filed their corresponding opposition. On May 15, 2023, the court issued a ruling that Seagate’s antitrust claims can proceed as to suspension assemblies that enter the United States but not as to suspension assembles that do not enter the United States. On July 28, 2023, the judge initiated a reconsideration of this ruling and requested further briefing. A trial date has not been set.
  (was, 2023-04-26, similarity 0.8825):
[0001137789-23-000029:note_history:3]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the U.S. District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, as well as additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 8, 2022, the court entered an Amended Stipulation and Order of Dismissal with Prejudice to dismiss all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment Regarding Foreign Commerce and on October 14, 2022, Seagate Entities’ filed their corresponding opposition. A trial date has not been set.

- added (2023-10-27):
[0001137789-23-000128:note_history:4]
In re Seagate Technology Holdings plc Securities Litigation. A putative class action lawsuit alleging violations of the federal securities laws, UA Local 38 Defined Contribution Pension Plan, et al. v. Seagate Technology Holdings PLC, et al., was filed on July 10, 2023, in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The complaint alleges that it is a securities class action on behalf of all purchasers of Seagate common stock between September 15, 2020 and October 25, 2022, inclusive, and asserts claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b5-1. The complaint seeks unspecified monetary damages and other relief. A second action, Public Employees’ Retirement System of Mississippi v. Seagate Technology Holdings plc, William David Mosley, and Gianluca Romano, was filed on July 26, 2023, asserting similar claims. The cases were consolidated on September 25, 2023. An amended complaint was filed on October 19, 2023. The Company believes that the asserted claims are without merit and intends to vigorously defend these cases.

- changed (2023-10-27):
[0001137789-23-000128:note_history:5]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fail to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.
  (was, 2023-04-26, similarity 0.9921):
[0001137789-23-000029:note_history:5]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the U.S., Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

- changed (2023-10-27):
[0001137789-23-000128:note_history:6]
On April 18, 2023, the Company’s subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd (collectively, “Seagate”), entered into a settlement agreement (the “Settlement Agreement”) with the U.S. Department of Commerce’s Bureau of Industry and Security (“BIS”) that resolves BIS’ allegations regarding Seagate’s sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, Seagate has agreed to pay $300 million to BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. Seagate has also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the U.S. Export Administration Regulations (“EAR”), including one audit by an unaffiliated third-party consultant chosen by Seagate with expertise in U.S. export control laws and two internal audits. The Settlement Agreement also includes a denial order that is suspended and will be waived five years after the date of the order issued under the Settlement Agreement, provided that Seagate has made full and timely payments under the Settlement Agreement and timely completed the audit requirements. While Seagate is in compliance with and upon successful compliance in full with the terms of the Settlement Agreement, BIS has agreed it will not initiate any further administrative proceedings against Seagate in connection with any violation of the EAR arising out of the transactions detailed in the Settlement Agreement.
  (was, 2023-04-26, similarity 0.9987):
[0001137789-23-000029:note_history:6]
On April 18, 2023, the Company’s subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd (collectively, “Seagate”), entered into a settlement agreement (the “Settlement Agreement”) with the U.S. Department of Commerce’s  Bureau of Industry and Security (“BIS”) that resolves BIS’ allegations regarding Seagate’s sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, Seagate has agreed to pay $300 million to the BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. Seagate has also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the U.S. Export Administration Regulations (“EAR”), including one audit by an unaffiliated third-party consultant chosen by Seagate with expertise in U.S. export control laws and two internal audits. The Settlement Agreement also includes a denial order that is suspended and will be waived five years after the date of the order issued under the Settlement Agreement, provided that Seagate has made full and timely payments under the Settlement Agreement and timely completed the audit requirements. While Seagate is in compliance with and upon successful compliance in full with the terms of the Settlement Agreement, BIS has agreed it will not initiate any further administrative proceedings against Seagate in connection with any violation of the EAR arising out of the transactions detailed in the Settlement Agreement.

- changed (2023-10-27):
[0001137789-23-000128:note_history:7]
While Seagate believed that it complied with all relevant export control laws at the time it made the hard disk drive sales at issue, Seagate determined that engaging with BIS and settling this matter was in the best interest of the Company, its customers, and its shareholders. In determining to engage with BIS and resolve this matter through a settlement agreement, the Company considered a number of factors, including the risks and cost of protracted litigation involving the U.S. government, as well as the size of the potential penalty and the Company’s desire to focus on current business challenges and long-term business strategy. The Settlement Agreement includes a finding that the Company incorrectly interpreted the regulation at issue to require evaluation of only the last stage of Seagate’s hard disk drive manufacturing process rather than the entire process. As part of this settlement, Seagate has agreed not to contest BIS’ determination that the sales in question did not comply with the U.S. EAR.
  (was, 2023-04-26, similarity 0.9995):
[0001137789-23-000029:note_history:7]
While Seagate believed that it complied with all relevant export control laws at the time it made the hard disk drive sales at issue, Seagate determined that engaging with BIS and settling this matter was in the best interest of the Company, its customers and its shareholders. In determining to engage with BIS and resolve this matter through a settlement agreement, the Company considered a number of factors, including the risks and cost of protracted litigation involving the U.S. government, as well as the size of the potential penalty and the Company’s desire to focus on current business challenges and long-term business strategy. The Settlement Agreement includes a finding that the Company incorrectly interpreted the regulation at issue to require evaluation of only the last stage of Seagate’s hard disk drive manufacturing process rather than the entire process. As part of this settlement, Seagate has agreed not to contest BIS’ determination that the sales in question did not comply with the U.S. EAR.

- changed (2023-10-27):
[0001137789-23-000128:note_history:8]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $240 million were included in Accrued expense and Other non-current liabilities, respectively, on its Condensed Consolidated Balance Sheets as of September 29, 2023.
  (was, 2023-04-26, similarity 0.6701):
[0001137789-23-000029:note_history:8]
The Company accrued a charge of $300 million for the March 2023 quarter, which is reflected under BIS settlement penalty on its Condensed Consolidated Statements of Operations. As of March 31, 2023, $30 million and $270 million were included in Accrued expense and Other non-current liabilities, respectively, on its Condensed Consolidated Balance Sheet.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-10-27):
[0001137789-23-000128:note_history:9]
Seagate Technology Holdings plc (“STX”) and its subsidiaries (collectively, unless the context otherwise indicates, the “Company”) is a leading provider of data storage technology and infrastructure solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”) and storage subsystems and offers storage solutions such as a scalable edge-to-cloud mass data platform that includes data transfer shuttles and a storage-as-a-service cloud.
  (was, 2023-04-26, similarity 0.7568):
[0001137789-23-000029:note_history:9]
Seagate Technology Holdings plc (“STX”) and its subsidiaries (collectively, unless the context otherwise indicates, the “Company”) is a leading provider of data storage technology and infrastructure solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”), solid state hybrid drives (“SSHDs”), storage subsystems, as well as a scalable edge-to-cloud mass data platform that includes data transfer shuttles and a storage-as-a-service cloud.

- changed (2023-10-27):
[0001137789-23-000128:note_history:10]
HDDs are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. HDDs continue to be the primary medium of mass data storage due to their performance attributes, reliability, high capacities, superior quality and cost effectiveness. Complementing HDD storage architectures, SSDs use NAND flash memory integrated circuit assemblies to store data.
  (was, 2023-04-26, similarity 0.6435):
[0001137789-23-000029:note_history:10]
HDDs are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. HDDs continue to be the primary medium of mass data storage due to their performance attributes, reliability, high capacities, superior quality and cost effectiveness. Complementing existing storage architectures, SSDs use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory. In contrast to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high-capacity HDD and a smaller SSD acting as a cache to improve performance.

- added (2023-10-27):
[0001137789-23-000128:note_history:11]
The Company’s HDD products are designed for mass capacity storage and legacy markets. Mass capacity storage involves well-established use cases, such as hyperscale data centers and public clouds as well as emerging use cases. Legacy markets are those that the Company continues to sell to but does not plan to invest in significantly. The Company’s HDD and SSD product portfolio includes Serial Advanced Technology Attachment (“SATA”), Serial Attached SCSI (“SAS”) and Non-Volatile Memory Express (“NVMe”) based designs to support a wide variety of mass capacity and legacy applications.

- changed (2023-10-27):
[0001137789-23-000128:note_history:12]
The Company’s systems portfolio includes storage subsystems for enterprises, cloud service providers (“CSPs”), scale-out storage servers and original equipment manufacturers (“OEMs”). Engineered for modularity, mobility, capacity and performance, these solutions include the Company’s enterprise HDDs and SSDs, enabling customers to integrate powerful, scalable storage within existing environments or create new ecosystems from the ground up in a secure, cost-effective manner.
  (was, 2023-04-26, similarity 0.9905):
[0001137789-23-000029:note_history:12]
The Company’s systems portfolio includes storage subsystems for enterprises, cloud service providers, scale-out storage servers and original equipment manufacturers (“OEMs”). Engineered for modularity, mobility, capacity and performance, these solutions include the Company’s enterprise HDDs and SSDs, enabling customers to integrate powerful, scalable storage within existing environments or create new ecosystems from the ground up in a secure, cost-effective manner.

- changed (2023-10-27):
[0001137789-23-000128:note_history:13]
The Company’s Lyve portfolio provides a simple, cost-efficient and secure way to manage massive volumes of data across the distributed enterprise. The Lyve platform includes a shuttle solution that enables enterprises to transfer massive amounts of data from endpoints to the core cloud and a storage-as-a-service cloud offering that provides frictionless mass capacity storage at the metro edge.
  (was, 2023-04-26, similarity 0.9937):
[0001137789-23-000029:note_history:13]
The Company’s Lyve portfolio provides a simple, cost-efficient and secure way to manage massive volumes of data across the distributed enterprise. The Lyve platform includes a shuttle solution that enables enterprises to transfer massive amounts of data from endpoints to the core cloud, a storage-as-a-service cloud offering that provides frictionless mass capacity storage at the metro edge.

- changed (2023-10-27):
[0001137789-23-000128:note_history:14]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its Condensed Consolidated Financial Statements.
  (was, 2023-04-26, similarity 0.9317):
[0001137789-23-000029:note_history:14]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. These estimates and assumptions include the impact of the COVID-19 pandemic. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements.

- changed (2023-10-27):
[0001137789-23-000128:note_history:15]
The Company’s Consolidated Financial Statements for the fiscal year ended June 30, 2023 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 4, 2023. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 30, 2023, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three months ended September 29, 2023 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 28, 2024.
  (was, 2023-04-26, similarity 0.9597):
[0001137789-23-000029:note_history:15]
The Company’s consolidated financial statements for the fiscal year ended July 1, 2022 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 5, 2022. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 1, 2022, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and nine months ended March 31, 2023 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 30, 2023.

- added (2023-10-27):
[0001137789-23-000128:note_history:16]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three months ended September 29, 2023 and September 30, 2022 consisted of 13 weeks. Fiscal years 2024 and 2023 both comprise 52 weeks and end on June 28, 2024 and June 30, 2023, respectively. The fiscal quarters ended September 29, 2023, June 30, 2023 and September 30, 2022, are also referred to herein as the “September 2023 quarter”, the “June 2023 quarter” and the “September 2022 quarter”, respectively.

- changed (2023-10-27):
[0001137789-23-000128:note_history:17]
Except for the change in the Company’s other long-lived assets policies described below, there have been no material changes to the Company’s significant accounting policies disclosed in Note 1. Basis of Presentation and Summary of Significant Accounting Policies of “Financial Statements and Supplementary Data” contained in Part II, Item 8. of the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2023, as filed with the SEC on August 4, 2023.
  (was, 2023-04-26, similarity 0.8864):
[0001137789-23-000029:note_history:17]
There have been no material changes to the Company’s significant accounting policies disclosed in Note 1. Basis of Presentation and Summary of Significant Accounting Policies of “Financial Statements and Supplementary Data” contained in Part II, Item 8. of the Company’s Annual Report on Form 10-K for the fiscal year ended July 1, 2022, as filed with the SEC on August 5, 2022.

- added (2023-10-27):
[0001137789-23-000128:note_history:18]
Other Long-Lived Assets

- added (2023-10-27):
[0001137789-23-000128:note_history:19]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. Effective from the first quarter of fiscal year 2024, the Company changed the useful lives of certain manufacturing equipment from a range of three to seven years to a range of three to ten years based on its review of technology product roadmap. The effect of this change in estimate increased the net income and diluted earnings per share by approximately $10 million and $0.05, respectively, for the three months ended September 29, 2023.

- added (2023-10-27):
[0001137789-23-000128:note_history:20]
Recently Adopted Accounting Pronouncements
In September 2022, the FASB issued ASU 2022-04 (ASC Subtopic 405-50), Disclosure of Supplier Finance Program Obligations. This ASU requires disclosure of key terms of the outstanding supplier finance programs and a roll forward of the related obligations. The Company adopted this guidance in the quarter ended September 29, 2023. The adoption of this ASU did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

- removed (2023-10-27):
[0001137789-23-000029:note_history:21]
The Company’s HDD products are designed for mass capacity storage and legacy markets. Mass capacity storage involves well-established use cases—such as hyperscale data centers and public clouds as well as emerging use cases. Legacy markets include markets the Company continues to sell to but that it does not plan to invest in significantly. The Company’s HDD and SSD product portfolio includes Serial Advanced Technology Attachment, Serial Attached SCSI and Non-Volatile Memory Express based designs to support a wide variety of mass capacity and legacy applications.

- removed (2023-10-27):
[0001137789-23-000029:note_history:22]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and nine months ended March 31, 2023 and the three and nine months ended April 1, 2022 consisted of 13 and 39 weeks, respectively. Fiscal years 2023 and 2022 both comprise of 52 weeks and end on June 30, 2023 and July 1, 2022, respectively. The fiscal quarters ended March 31, 2023, December 30, 2022 and April 1, 2022, are also referred to herein as the “March 2023 quarter”, the “December 2022 quarter” and the “March 2022 quarter”, respectively.

- removed (2023-10-27):
[0001137789-23-000029:note_history:23]
Recently Adopted Accounting Pronouncements

- removed (2023-10-27):
[0001137789-23-000029:note_history:24]
In March 2020, the Financial Accounting Standards Board (“FASB”) issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. In December 2022, FASB issued ASU 2022-06 (ASC Topic 848) and deferred the sunset date from December 31, 2022 to December 31, 2024. The Company adopted the guidance in the quarter ended September 30, 2022 on a prospective basis and is transitioning from an interest rate based on London Interbank Offered Rate (“LIBOR”) to Secured Overnight Financing Rate (“SOFR”). The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.

- removed (2023-10-27):
[0001137789-23-000029:note_history:25]
In November 2021, the FASB issued ASU 2021-10 (ASC Topic 832), Disclosures by Business Entities about Government Assistance. This ASU requires annual disclosures that increase the transparency of transactions involving government grants, including (1) the type of transactions, (2) the accounting for those transactions and (3) the effect of those transactions on an entity’s financial statements. The Company adopted the guidance in the quarter ended September 30, 2022.

- removed (2023-10-27):
[0001137789-23-000029:note_history:26]
Recently Issued Accounting Pronouncements

- removed (2023-10-27):
[0001137789-23-000029:note_history:27]
In September 2022, the FASB issued ASU 2022-04 (ASC Subtopic 405-50), Disclosure of Supplier Finance Program Obligations. This ASU requires disclosure of key terms of the outstanding supplier finance programs and a rollforward of the related obligations. The Company is required to adopt this guidance in the first quarter of fiscal year 2024. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- removed (2023-10-27):
[0001137789-23-000029:note_history:28]
In June 2022, the FASB issued ASU 2022-03 (ASC Topic 820), Fair Value Measurement of Equity Securities Subject to Contractual Sale Restrictions. This ASU clarifies that a contractual restriction on the sale of equity security is not considered when measuring its fair value and requires new disclosures for equity securities subject to contractual sale restriction. The Company is required to adopt this guidance in the first quarter of fiscal year 2025. The Company does not expect the adoption of this ASU to have a material impact on its condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-10-27):
[0001137789-23-000128:note_history:29]
Debt
The following table provides details of the Company’s debt as of September 29, 2023 and June 30, 2023:
  (was, 2023-04-26, similarity 0.9263):
[0001137789-23-000029:note_history:29]
Debt
The following table provides details of the Company’s debt as of March 31, 2023 and July 1, 2022:

- changed (2023-10-27):
[0001137789-23-000128:note_history:30]
| (Dollars in millions) |  | September 29, 2023 |  | June 30, 2023 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | $ | 479 |  |  | $ | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 467 |  |  | 465 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Convertible Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | — |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | — |  |  | 430 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
|  |  | 5,699 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (33) |  |  | (36) |  |
| Debt, net of debt issuance costs |  | 5,666 |  |  | 5,451 |  |
| Less: current portion of long-term debt |  | — |  |  | (63) |  |
| Long-term debt, less current portion |  | $ | 5,666 |  |  | $ | 5,388 |  |
  (was, 2023-04-26, similarity 0.8103):
[0001137789-23-000029:note_history:30]
| (Dollars in millions) |  | March 31,2023 |  | July 1,2022 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | $ | 540 |  |  | $ | 540 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 500 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 465 |  |  | 466 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 500 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | — |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 585 |  |  | 600 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 585 |  |  | 600 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 585 |  |  | — |  |
|  |  | 5,992 |  |  | 5,677 |  |
| Less: unamortized debt issuance costs |  | (34) |  |  | (31) |  |
| Debt, net of debt issuance costs |  | 5,958 |  |  | 5,646 |  |
| Less: current portion of long-term debt |  | (1,118) |  |  | (584) |  |
| Long-term debt, less current portion |  | $ | 4,840 |  |  | $ | 5,062 |  |

- changed (2023-10-27):
[0001137789-23-000128:note_history:31]
_____________________________
  (was, 2023-04-26, similarity 0.9831):
[0001137789-23-000029:note_history:31]
______________________________

- changed (2023-10-27):
[0001137789-23-000128:note_history:32]
(1) All unsecured senior notes and convertible senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX.
  (was, 2023-04-26, similarity 0.9446):
[0001137789-23-000029:note_history:32]
(1) All unsecured senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX.

- added (2023-10-27):
[0001137789-23-000128:note_history:33]
2028 Convertible Senior Notes and related Capped Call Transactions

- added (2023-10-27):
[0001137789-23-000128:note_history:34]
2028 Notes. On September 13, 2023, Seagate HDD, in a private placement, issued $1.5 billion in aggregate principal amount of 3.50% Convertible Senior Notes due 2028 (the “2028 Notes”), which includes $200 million aggregate principal amount pursuant to the over-allotment option of the initial purchasers to purchase additional notes. The 2028 Notes will mature on June 1, 2028, with interest payable semi-annually on March 1 and September 1 of each year, commencing March 1, 2024.

- added (2023-10-27):
[0001137789-23-000128:note_history:35]
The entire outstanding principal amount of Term Loans A1, A2 and A3 were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in the Net loss recognized from early redemption of debt in the Company’s Condensed Consolidated Statements of Operations for the first quarter of fiscal year 2024. In connection with the repayment of Term Loans, the Company terminated its interest rate swap agreements. Refer to “Note 6. Derivative Financial Instruments” for more details.

- added (2023-10-27):
[0001137789-23-000128:note_history:36]
Prior to March 1, 2028, the 2028 Notes are convertible at the option of the holders only under certain circumstances as set forth in the indenture with respect to the 2028 Notes. On or after March 1, 2028, the 2028 Notes are convertible at any time at the option of the holders until the close of business on the second scheduled trading day immediately preceding the maturity date, unless the 2028 Notes have been previously redeemed or repurchased by Seagate HDD. Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The initial exchange rate for the 2028 Notes is 12.1253 ordinary shares per $1,000 principal amount of 2028 Notes.

- added (2023-10-27):
[0001137789-23-000128:note_history:37]
Seagate HDD may redeem the 2028 Notes at its option, in whole but not in part, if Seagate HDD or the Guarantors have, or on the next interest payment date would, become obligated to pay to the holder of any Note additional amounts as a result of certain tax-related events at a redemption price equal to 100% of the principal amount plus accrued and unpaid interest, including additional interest, if any, to, but excluding, the redemption date; provided that Seagate HDD may only redeem the Notes if: (x) Seagate HDD or the relevant Guarantor cannot avoid these obligations by taking commercially reasonable measures available to Seagate HDD or such Guarantor; and (y) Seagate HDD delivers to the Trustee an opinion of outside legal counsel of recognized standing in the relevant taxing jurisdiction attesting to such tax-related event and obligation to pay additional amounts.

- added (2023-10-27):
[0001137789-23-000128:note_history:38]
Seagate HDD also may redeem the 2028 Notes at its option on or after September 8, 2026, in whole or in part, if the last reported sale price of ordinary shares of the Company has been at least 130% of the exchange price then in effect for at least 20 trading days (whether or not consecutive), including the trading day immediately preceding the date on which Seagate HDD provides notice of redemption, during any 30 consecutive trading day period ending on, and including, the trading day immediately preceding the date on which Seagate HDD provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If Seagate HDD redeems less than all the outstanding 2028 Notes, at least $150 million aggregate principal amount of 2028 Notes must be outstanding and not subject to redemption as of the relevant notice of redemption date.

- added (2023-10-27):
[0001137789-23-000128:note_history:39]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The cap price of the capped call transactions will initially be $107.848 per share, which represents a premium of approximately 70% over the last reported sale price of the ordinary shares of $63.44 per share on the Nasdaq Global Market on September 7, 2023. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets as of September 29, 2023.

- added (2023-10-27):
[0001137789-23-000128:note_history:40]
On September 27, 2023, Seagate Technology Holdings plc and Seagate HDD entered into an amendment to its credit agreement, dated September 20, 2019 (the “Tenth Amendment”). Under the Tenth Amendment, the maximum permitted total net leverage ratio is 6.75 to 1.00 for the fiscal quarter ending September 29, 2023. For the fiscal quarters ending December 29, 2023 and March 29, 2024, the total net leverage ratio covenant will not apply. For the fiscal quarters ending June 28, 2024 until the end of the covenant relief period, which terminates on June 27, 2025, the maximum permitted total net leverage ratio is 6.75 to 1.00, and applies only to the extent that the aggregate outstanding amount of revolving loans, swing line loans and the aggregate face amount of certain letters of credit exceeds 25% of the then outstanding revolving commitments in effect (the “Testing Condition”) as of the last day of the fiscal quarter. The maximum permitted total leverage ratio for each fiscal quarter ending after June 27, 2025 is 4.00 to 1.00.

- added (2023-10-27):
[0001137789-23-000128:note_history:41]
The minimum interest coverage ratio is 2.25 to 1.00 for the fiscal quarter ending September 29, 2023. For the fiscal quarters ending December 29, 2023 and March 29, 2024, the minimum interest coverage ratio covenant will not apply. For the fiscal quarters ending June 28, 2024 until June 27, 2025, the minimum interest coverage ratio is 2.25 to 1.00, and applies only to the extent that the Testing Condition is satisfied as of the last day of the fiscal quarter. The minimum interest coverage ratio is 3.25 to 1.00 for each fiscal quarter ending after June 27, 2025.

- added (2023-10-27):
[0001137789-23-000128:note_history:42]
The Tenth Amendment also removed the minimum liquidity covenant of $700 million. As of September 29, 2023, the Tenth Amendment includes two financial covenants: (1) interest coverage ratio and (2) total net leverage ratio. The Company was in compliance with the covenants as of September 29, 2023.

- changed (2023-10-27):
[0001137789-23-000128:note_history:43]
At September 29, 2023, future principal payments on long-term debt were as follows (in millions):
  (was, 2023-04-26, similarity 0.9438):
[0001137789-23-000029:note_history:43]
At March 31, 2023, future principal payments on long-term debt were as follows (in millions):

- changed (2023-10-27):
[0001137789-23-000128:note_history:44]
| Fiscal Year |  | Principal Amount |
| Remainder of 2024 |  | $ | — |  |
| 2025 |  | 479 |  |
| 2026 |  | — |  |
| 2027 |  | 505 |  |
| 2028 |  | 1,500 |  |
| Thereafter |  | 3,245 |  |
| Total |  | $ | 5,729 |  |
  (was, 2023-04-26, similarity 0.9571):
[0001137789-23-000029:note_history:44]
| Fiscal Year |  | Amount |
| Remainder of 2023 |  | $ | 563 |  |
| 2024 |  | 586 |  |
| 2025 |  | 617 |  |
| 2026 |  | 667 |  |
| 2027 |  | 649 |  |
| Thereafter |  | 2,943 |  |
| Total |  | $ | 6,025 |  |

- removed (2023-10-27):
[0001137789-23-000029:note_history:45]
Debt Exchange

- removed (2023-10-27):
[0001137789-23-000029:note_history:46]
2032 Notes. On November 30, 2022, Seagate HDD issued, in a private placement, $750 million in aggregate principal amount of 9.625% Senior Notes due on December 1, 2032, in connection with Seagate HDD’s exchange offers to certain eligible holders of Seagate HDD’s outstanding existing senior notes as set forth below:

- removed (2023-10-27):
[0001137789-23-000029:note_history:47]
| (Dollars in millions) |  |  |  |  |  |  |  |  |
| Existing Notes |  | Principal Amount Outstanding as of July 1, 2022 |  | Principal Amount Exchanged |  |  |  |  |
| July 2031 Notes |  | $ | 500 |  |  | $ | 423 |  |  |  |  |  |
| July 2029 Notes |  | 500 |  |  | 336 |  |  |  |  |  |
| January 2031 Notes |  | 500 |  |  | 205 |  |  |  |  |  |
| Total |  | $ | 1,500 |  |  | $ | 964 |  |  |  |  |  |

- removed (2023-10-27):
[0001137789-23-000029:note_history:48]
The exchange was accounted for as a debt extinguishment and the Company recorded a net gain of $204 million, which was included in Net gain recognized from early redemption of debt in the Company’s Condensed Consolidated Statements of Operations for the nine months ended March 31, 2023.

- removed (2023-10-27):
[0001137789-23-000029:note_history:49]
At any time prior to December 1, 2027, Seagate HDD may redeem the 2032 Notes at its option, in whole or in part, at any time and from time to time, at a “make-whole” redemption price. The “make-whole” redemption price will be equal to the greater of: (1) (a) the sum of the present values at such redemption date of the redemption price of the 2032 Notes that would apply if the new 2032 Notes were redeemed on December 1, 2027 plus the remaining scheduled payments of interest thereon to and including December 1, 2027 discounted to the redemption date on a semi-annual basis at the Treasury Rate plus 50 basis points less (b) interest accrued to the date of redemption, and (2) 100% of the principal amount of the 2032 Notes to be redeemed plus, in either case, accrued and unpaid interest thereon, if any, to, but excluding, the redemption date. At any time on or after December 1, 2027, Seagate HDD may redeem some or all of the 2032 Notes at the prices specified in the Indenture, plus accrued and unpaid interest to, but excluding, the redemption date. In addition, Seagate HDD may redeem with the net cash proceeds from one or more equity offerings up to 40% of the 2032 Notes before December 1, 2025, at a redemption price of 109.625% plus accrued and unpaid interest to, but excluding, the redemption date.

- removed (2023-10-27):
[0001137789-23-000029:note_history:50]
Debt Repurchases

- removed (2023-10-27):
[0001137789-23-000029:note_history:51]
During the March 2023 quarter, $20 million principal amount of the January 2031 Notes, $5 million principal amount of the June 2029 Notes, and $5 million principal amount of the July 2031 Notes were repurchased for cash at a discount to their principal amounts, plus accrued and unpaid interest. The Company recorded a gain of $3 million on these repurchases during the March 2023 quarter, which was included in Net gain recognized from early redemption of debt in the Company’s Condensed Consolidated Statements of Operations.

- removed (2023-10-27):
[0001137789-23-000029:note_history:52]
On August 18, 2022, Seagate Technology Holdings plc and Seagate HDD (the “Borrower”) entered into an amendment to its Credit Agreement (the “Sixth Amendment”), which provided for a new term loan facility in the aggregate principal amount of $600 million (“Term Loan A3”). Term Loan A3 was borrowed in full at the closing of the Sixth Amendment. The Sixth Amendment to the Credit Agreement also replaced the LIBOR interest rates plus variable margin for the Term Loans A1 and A2 with the SOFR interest rates plus a variable margin that will be determined based on the corporate credit rating of the Borrower or one of its parent entities. The Sixth Amendment also permits the Borrower to increase the revolving loan commitments or obtain new term loans of up to $100 million in aggregate (the “Incremental facility”), subject to the satisfaction of certain terms and conditions.

- removed (2023-10-27):
[0001137789-23-000029:note_history:53]
On November 8, 2022, Seagate Technology Holdings plc and the Borrower entered into an amendment to its Credit Agreement (the “Seventh Amendment”), to increase the maximum permitted total leverage ratio the Company must comply with during the covenant relief period that ends on June 28, 2024 and prohibit the Company from pursuing the use of the Incremental Facility during the covenant relief period. The maximum permitted total leverage ratio is 5.0 to 1.0 from the fiscal quarters ending December 30, 2022 to June 30, 2023. For the fiscal quarter ending September 29, 2023, the maximum permitted total leverage ratio is 4.75 to 1.0 and then steps down to 4.5 to 1.0 from the fiscal quarters ending December 29, 2023 to June 28, 2024. The maximum permitted leverage ratio will return to 4.0 to 1.0 for any fiscal quarter ending after June 28, 2024.

- removed (2023-10-27):
[0001137789-23-000029:note_history:54]
The Credit Agreement provides a term loan facility in an aggregate principal amount of $1.8 billion that is extended in three tranches of $600 million each for Term Loans A1, A2 and A3 (the “Term Loans”), and a $1.75 billion senior unsecured revolving credit facility (“Revolving Credit Facility”). During the March 2023 quarter the Company repaid $45 million principal amount of the Term Loans. As of March 31, 2023, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. STX and certain of its material subsidiaries, including STUC, fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loans. The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of March 31, 2023.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-10-27):
[0001137789-23-000128:note_history:55]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of September 29, 2023 and June 30, 2023:
  (was, 2023-04-26, similarity 0.9576):
[0001137789-23-000029:note_history:55]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of March 31, 2023 and July 1, 2022:

- changed (2023-10-27):
[0001137789-23-000128:note_history:56]
|  |  | September 29, 2023 |  | June 30, 2023 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 121 |  |  | $ | — |  |  | $ | 121 |  |  | $ | 73 |  |  | $ | — |  |  | $ | 73 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 15 |  |  | — |  |  | 15 |  |  | 16 |  |  | — |  |  | 16 |  |
| Total |  | $ | 137 |  |  | $ | — |  |  | $ | 137 |  |  | $ | 90 |  |  | $ | — |  |  | $ | 90 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 120 |  |  |  |  |  |  | $ | 72 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 15 |  |  |  |  |  |  | 16 |  |
| Total |  |  |  |  |  | $ | 137 |  |  |  |  |  |  | $ | 90 |  |
  (was, 2023-04-26, similarity 0.9883):
[0001137789-23-000029:note_history:56]
|  |  | March 31,2023 |  | July 1,2022 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 235 |  |  | $ | — |  |  | $ | 235 |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 16 |  |  | — |  |  | 16 |  |  | 23 |  |  | — |  |  | 23 |  |
| Total |  | $ | 252 |  |  | $ | — |  |  | $ | 252 |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 234 |  |  |  |  |  |  | $ | 59 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 16 |  |  |  |  |  |  | 23 |  |
| Total |  |  |  |  |  | $ | 252 |  |  |  |  |  |  | $ | 84 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-10-27):
[0001137789-23-000128:note_history:57]
The following table provides details of the Company’s debt as of September 29, 2023 and June 30, 2023:

- changed (2023-10-27):
[0001137789-23-000128:note_history:58]
| (Dollars in millions) |  | September 29, 2023 |  | June 30, 2023 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | $ | 479 |  |  | $ | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 467 |  |  | 465 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Convertible Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | — |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | — |  |  | 430 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
|  |  | 5,699 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (33) |  |  | (36) |  |
| Debt, net of debt issuance costs |  | 5,666 |  |  | 5,451 |  |
| Less: current portion of long-term debt |  | — |  |  | (63) |  |
| Long-term debt, less current portion |  | $ | 5,666 |  |  | $ | 5,388 |  |
  (was, 2023-04-26, similarity 0.8103):
[0001137789-23-000029:note_history:58]
| (Dollars in millions) |  | March 31,2023 |  | July 1,2022 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | $ | 540 |  |  | $ | 540 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 500 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 465 |  |  | 466 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 500 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | — |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 585 |  |  | 600 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 585 |  |  | 600 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 585 |  |  | — |  |
|  |  | 5,992 |  |  | 5,677 |  |
| Less: unamortized debt issuance costs |  | (34) |  |  | (31) |  |
| Debt, net of debt issuance costs |  | 5,958 |  |  | 5,646 |  |
| Less: current portion of long-term debt |  | (1,118) |  |  | (584) |  |
| Long-term debt, less current portion |  | $ | 4,840 |  |  | $ | 5,062 |  |

- changed (2023-10-27):
[0001137789-23-000128:note_history:59]
_____________________________
  (was, 2023-04-26, similarity 0.9831):
[0001137789-23-000029:note_history:59]
______________________________

- changed (2023-10-27):
[0001137789-23-000128:note_history:60]
(1) All unsecured senior notes and convertible senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX.
  (was, 2023-04-26, similarity 0.9446):
[0001137789-23-000029:note_history:60]
(1) All unsecured senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX.


## us-gaap:ScheduleOfExtinguishmentOfDebtTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2023-10-27):
[0001137789-23-000029:note_history:61]
On November 30, 2022, Seagate HDD issued, in a private placement, $750 million in aggregate principal amount of 9.625% Senior Notes due on December 1, 2032, in connection with Seagate HDD’s exchange offers to certain eligible holders of Seagate HDD’s outstanding existing senior notes as set forth below:

- removed (2023-10-27):
[0001137789-23-000029:note_history:62]
| (Dollars in millions) |  |  |  |  |  |  |  |  |
| Existing Notes |  | Principal Amount Outstanding as of July 1, 2022 |  | Principal Amount Exchanged |  |  |  |  |
| July 2031 Notes |  | $ | 500 |  |  | $ | 423 |  |  |  |  |  |
| July 2029 Notes |  | 500 |  |  | 336 |  |  |  |  |  |
| January 2031 Notes |  | 500 |  |  | 205 |  |  |  |  |  |
| Total |  | $ | 1,500 |  |  | $ | 964 |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-10-27):
[0001137789-23-000128:note_history:63]
At September 29, 2023, future principal payments on long-term debt were as follows (in millions):
  (was, 2023-04-26, similarity 0.9438):
[0001137789-23-000029:note_history:63]
At March 31, 2023, future principal payments on long-term debt were as follows (in millions):

- changed (2023-10-27):
[0001137789-23-000128:note_history:64]
| Fiscal Year |  | Principal Amount |
| Remainder of 2024 |  | $ | — |  |
| 2025 |  | 479 |  |
| 2026 |  | — |  |
| 2027 |  | 505 |  |
| 2028 |  | 1,500 |  |
| Thereafter |  | 3,245 |  |
| Total |  | $ | 5,729 |  |
  (was, 2023-04-26, similarity 0.9571):
[0001137789-23-000029:note_history:64]
| Fiscal Year |  | Amount |
| Remainder of 2023 |  | $ | 563 |  |
| 2024 |  | 586 |  |
| 2025 |  | 617 |  |
| 2026 |  | 667 |  |
| 2027 |  | 649 |  |
| Thereafter |  | 2,943 |  |
| Total |  | $ | 6,025 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-10-27):
[0001137789-23-000128:note_history:65]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | September 29, 2023 |  | September 30, 2022 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,032 |  |  | $ | 1,545 |  |  |  |  |  |
| Distributors |  | 266 |  |  | 299 |  |  |  |  |  |
| Retailers |  | 156 |  |  | 191 |  |  |  |  |  |
| Total |  | $ | 1,454 |  |  | $ | 2,035 |  |  |  |  |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 811 |  |  | $ | 801 |  |  |  |  |  |
| Americas |  | 455 |  |  | 936 |  |  |  |  |  |
| EMEA |  | 188 |  |  | 298 |  |  |  |  |  |
| Total |  | $ | 1,454 |  |  | $ | 2,035 |  |  |  |  |  |

- changed (2023-10-27):
[0001137789-23-000128:note_history:66]
_____________________________
  (was, 2023-04-26, similarity 0.9355):
[0001137789-23-000029:note_history:66]
_________________________________

- removed (2023-10-27):
[0001137789-23-000029:note_history:67]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,358 |  |  | $ | 2,149 |  |  | $ | 4,268 |  |  | $ | 6,615 |  |
| Distributors |  | 294 |  |  | 349 |  |  | 890 |  |  | 1,418 |  |
| Retailers |  | 208 |  |  | 304 |  |  | 624 |  |  | 1,000 |  |
| Total |  | $ | 1,860 |  |  | $ | 2,802 |  |  | $ | 5,782 |  |  | $ | 9,033 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 774 |  |  | $ | 1,292 |  |  | $ | 2,335 |  |  | $ | 4,308 |  |
| Americas |  | 799 |  |  | 1,171 |  |  | 2,588 |  |  | 3,436 |  |
| EMEA |  | 287 |  |  | 339 |  |  | 859 |  |  | 1,289 |  |
| Total |  | $ | 1,860 |  |  | $ | 2,802 |  |  | $ | 5,782 |  |  | $ | 9,033 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-10-27):
[0001137789-23-000128:note_history:68]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | September 29, 2023 |  | September 30, 2022 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,032 |  |  | $ | 1,545 |  |  |  |  |  |
| Distributors |  | 266 |  |  | 299 |  |  |  |  |  |
| Retailers |  | 156 |  |  | 191 |  |  |  |  |  |
| Total |  | $ | 1,454 |  |  | $ | 2,035 |  |  |  |  |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 811 |  |  | $ | 801 |  |  |  |  |  |
| Americas |  | 455 |  |  | 936 |  |  |  |  |  |
| EMEA |  | 188 |  |  | 298 |  |  |  |  |  |
| Total |  | $ | 1,454 |  |  | $ | 2,035 |  |  |  |  |  |

- changed (2023-10-27):
[0001137789-23-000128:note_history:69]
_____________________________
  (was, 2023-04-26, similarity 0.9355):
[0001137789-23-000029:note_history:69]
_________________________________

- removed (2023-10-27):
[0001137789-23-000029:note_history:70]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,358 |  |  | $ | 2,149 |  |  | $ | 4,268 |  |  | $ | 6,615 |  |
| Distributors |  | 294 |  |  | 349 |  |  | 890 |  |  | 1,418 |  |
| Retailers |  | 208 |  |  | 304 |  |  | 624 |  |  | 1,000 |  |
| Total |  | $ | 1,860 |  |  | $ | 2,802 |  |  | $ | 5,782 |  |  | $ | 9,033 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 774 |  |  | $ | 1,292 |  |  | $ | 2,335 |  |  | $ | 4,308 |  |
| Americas |  | 799 |  |  | 1,171 |  |  | 2,588 |  |  | 3,436 |  |
| EMEA |  | 287 |  |  | 339 |  |  | 859 |  |  | 1,289 |  |
| Total |  | $ | 1,860 |  |  | $ | 2,802 |  |  | $ | 5,782 |  |  | $ | 9,033 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2023-10-27):
[0001137789-23-000128:note_history:71]
On October 26, 2023, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on January 9, 2024 to shareholders of record as of the close of business on December 21, 2023.
  (was, 2023-04-26, similarity 0.938):
[0001137789-23-000029:note_history:71]
On April 20, 2023, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on July 5, 2023 to shareholders of record as of the close of business on June 21, 2023.

- removed (2023-10-27):
[0001137789-23-000029:note_history:72]
Restructuring Plan

- removed (2023-10-27):
[0001137789-23-000029:note_history:73]
On April 20, 2023, the Company committed to the April 2023 plan to further reduce its cost structure in response to changes in macroeconomic and business conditions. See “Note 5. Restructuring and Exit Costs” for more information.

- removed (2023-10-27):
[0001137789-23-000029:note_history:74]
Subsequent Regulatory Settlement
On April 18, 2023, the Company entered into the Settlement Agreement with BIS that resolves BIS’ allegations regarding its sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. See “Note 12. Legal, Environmental and Other Contingencies” for more information.
