# STX MD&A — 0001137789-20-000015


## mdna

[0001137789-20-000015:mdna:1]
ITEM 2.MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001137789-20-000015:mdna:2]
The following is a discussion of the financial condition, changes in financial condition, and results of operations for our fiscal quarters ended January 3, 2020, October 4, 2019 and December 28, 2018, referred to herein as the “December 2019 quarter,” the “September 2019 quarter,” and the “December 2018 quarter,” respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The December 2019 quarter and the December 2018 quarter were each 13 weeks, and the September 2019 quarter was 14 weeks.

[0001137789-20-000015:mdna:3]
You should read this discussion in conjunction with financial information and related notes included elsewhere in this report. Unless the context indicates otherwise, as used herein, the terms “we,” “us,” “Seagate,” the “Company” and “our” refer collectively to Seagate Technology plc, an Irish public limited company, and its subsidiaries. References to “$” or “dollars” are to United States dollars.

[0001137789-20-000015:mdna:4]
•the development and introduction of products based on new technologies and expansion into new data storage markets, and market acceptance of new products;

[0001137789-20-000015:mdna:5]
•the impact of competitive product announcements and unexpected advances in competing technologies or changes in market trends;

[0001137789-20-000015:mdna:6]
•the impact of variable demand, changes in market demand, and an adverse pricing environment for storage products;

[0001137789-20-000015:mdna:7]
•the Company’s ability to effectively manage its debt obligations and comply with certain covenants in its credit facilities with respect to financial ratios and financial condition tests and its ability to maintain a favorable cash liquidity position;

[0001137789-20-000015:mdna:8]
•the Company’s ability to successfully qualify, manufacture and sell its storage products in increasing volumes on a cost-effective basis and with acceptable quality;

[0001137789-20-000015:mdna:9]
•any price erosion or volatility of sales volumes through the Company’s distributor and retail channel;

[0001137789-20-000015:mdna:10]
•disruptions to the Company’s supply chain or production capabilities;

[0001137789-20-000015:mdna:11]
•currency fluctuations that may impact the Company’s margins, international sales and results of operations;

[0001137789-20-000015:mdna:12]
•the impact of trade barriers, such as import/export duties and restrictions, tariffs and quotas, imposed by the U.S. or other countries in which the Company conducts business; and

[0001137789-20-000015:mdna:13]
•cyber-attacks or other data breaches that disrupt the Company’s operations or result in the dissemination of proprietary or confidential information and cause reputational harm.

[0001137789-20-000015:mdna:14]
29

[0001137789-20-000015:mdna:15]
[same as prior period, unchanged from 0001628280-19-013092:mdna:17]

[0001137789-20-000015:mdna:16]
•Overview of the December 2019 quarter. Highlights of events in the December 2019 quarter that impacted our financial position.

[0001137789-20-000015:mdna:17]
•Results of Operations. An analysis of our financial results comparing the December 2019 quarter to the September 2019 quarter and the December 2018 quarter.

[0001137789-20-000015:mdna:18]
•Liquidity and Capital Resources. An analysis of changes in our balance sheet and cash flows, and discussion of our financial condition including the credit quality of our investment portfolio and potential sources of liquidity.

[0001137789-20-000015:mdna:19]
•Critical Accounting Policies. Accounting policies and estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001137789-20-000015:mdna:20]
[same as prior period, unchanged from 0001628280-19-013092:mdna:22]

[0001137789-20-000015:mdna:21]
Overview of the December 2019 quarter

[0001137789-20-000015:mdna:22]
During the December 2019 quarter, we shipped 107 exabytes of HDD storage capacity. We generated revenue of approximately $2.7 billion, gross margin of 28% and our operating cash flow was $480 million. We repurchased approximately 3 million of our ordinary shares for $150 million and paid $165 million in dividends.

[0001137789-20-000015:mdna:23]
[same as prior period, unchanged from 0001628280-19-013092:mdna:25]

[0001137789-20-000015:mdna:24]
[same as prior period, unchanged from 0001628280-19-013092:mdna:26]

[0001137789-20-000015:mdna:25]
|  |  | For the Three Months Ended |  |  |  |  |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | January 3,2020 |  | October 4,2019 |  | December 28,2018 |  | January 3,2020 |  | December 28,2018 |
| Revenue |  | $ | 2,696 |  |  | $ | 2,578 |  |  | $ | 2,715 |  |  | $ | 5,274 |  |  | $ | 5,706 |  |
| Cost of revenue |  | 1,938 |  |  | 1,907 |  |  | 1,921 |  |  | 3,845 |  |  | 3,999 |  |
| Gross margin |  | 758 |  |  | 671 |  |  | 794 |  |  | 1,429 |  |  | 1,707 |  |
| Product development |  | 250 |  |  | 255 |  |  | 246 |  |  | 505 |  |  | 512 |  |
| Marketing and administrative |  | 120 |  |  | 122 |  |  | 120 |  |  | 242 |  |  | 235 |  |
| Amortization of intangibles |  | 4 |  |  | 4 |  |  | 5 |  |  | 8 |  |  | 11 |  |
| Restructuring and other, net |  | — |  |  | 17 |  |  | 7 |  |  | 17 |  |  | 30 |  |
| Income from operations |  | 384 |  |  | 273 |  |  | 416 |  |  | 657 |  |  | 919 |  |
| Other expense, net |  | (48) |  |  | (75) |  |  | (18) |  |  | (123) |  |  | (53) |  |
| Income before income taxes |  | 336 |  |  | 198 |  |  | 398 |  |  | 534 |  |  | 866 |  |
| Provision (benefit) for income taxes |  | 18 |  |  | (2) |  |  | 14 |  |  | 16 |  |  | 32 |  |
| Net income |  | $ | 318 |  |  | $ | 200 |  |  | $ | 384 |  |  | $ | 518 |  |  | $ | 834 |  |

[0001137789-20-000015:mdna:26]
30

[0001137789-20-000015:mdna:27]
|  |  | For the Three Months Ended |  |  |  |  |  | For the Six Months Ended |  |  |
|  |  | January 3,2020 |  | October 4,2019 |  | December 28,2018 |  | January 3,2020 |  | December 28,2018 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 72 |  |  | 74 |  |  | 71 |  |  | 73 |  |  | 70 |  |
| Gross margin |  | 28 |  |  | 26 |  |  | 29 |  |  | 27 |  |  | 30 |  |
| Product development |  | 9 |  |  | 10 |  |  | 9 |  |  | 10 |  |  | 9 |  |
| Marketing and administrative |  | 4 |  |  | 5 |  |  | 5 |  |  | 5 |  |  | 4 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Restructuring and other, net |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Income from operations |  | 15 |  |  | 11 |  |  | 15 |  |  | 12 |  |  | 16 |  |
| Other expense, net |  | (2) |  |  | (3) |  |  | (1) |  |  | (2) |  |  | (1) |  |
| Income before income taxes |  | 13 |  |  | 8 |  |  | 14 |  |  | 10 |  |  | 15 |  |
| Provision (benefit) for income taxes |  | 1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income |  | 12 | % |  | 8 | % |  | 14 | % |  | 10 | % |  | 15 | % |

[0001137789-20-000015:mdna:28]
[same as prior period, unchanged from 0001628280-19-013092:mdna:30]

[0001137789-20-000015:mdna:29]
The following table summarizes information regarding consolidated revenues by channel, geography and market and HDD exabytes shipped by market and price per terabyte:

[0001137789-20-000015:mdna:30]
|  |  | For the Three Months Ended |  |  |  |  |  | For the Six Months Ended |  |  |
|  |  | January 3,2020 |  | October 4,2019 |  | December 28,2018 |  | January 3,2020 |  | December 28,2018 |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 68 | % |  | 71 | % |  | 69 | % |  | 69 | % |  | 70 | % |
| Distributors |  | 17 | % |  | 18 | % |  | 16 | % |  | 18 | % |  | 17 | % |
| Retailers |  | 15 | % |  | 11 | % |  | 15 | % |  | 13 | % |  | 13 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 51 | % |  |  | 50 | % |  |  | 51 | % |  |  | 50 | % |  |  | 50 | % |
| Americas |  | 28 | % |  | 32 | % |  | 27 | % |  | 30 | % |  | 30 | % |
| EMEA |  | 21 | % |  | 18 | % |  | 22 | % |  | 20 | % |  | 20 | % |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 49 | % |  | 47 | % |  | 39 | % |  | 48 | % |  | 43 | % |
| Legacy |  | 43 | % |  | 46 | % |  | 53 | % |  | 44 | % |  | 50 | % |
| Other |  | 8 | % |  | 7 | % |  | 8 | % |  | 8 | % |  | 7 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 71 |  |  |  | 64 |  |  |  | 47 |  |  |  | 135 |  |  |  | 107 |  |
| Legacy |  | 36 |  |  | 34 |  |  | 40 |  |  | 70 |  |  | 79 |  |
| Total |  | 107 |  |  | 98 |  |  | 87 |  |  | 205 |  |  | 186 |  |
| HDD Price per Terabyte |  | $ | 23 |  |  | $ | 24 |  |  | $ | 28 |  |  | $ | 24 |  |  | $ | 28 |  |

[0001137789-20-000015:mdna:31]
Revenue in the December 2019 quarter increased by $118 million from the September 2019 quarter primarily due to an increase in exabytes shipped, partially offset by price erosion.

[0001137789-20-000015:mdna:32]
Revenue in the December 2019 quarter decreased by $19 million from the December 2018 quarter primarily due to price erosion, partially offset by an increase in exabytes shipped.

[0001137789-20-000015:mdna:33]
Revenue for the six months ended January 3, 2020 decreased by $432 million from the six months ended December 28, 2018 primarily as a result of price erosion, partially offset by an increase in exabytes shipped.

[0001137789-20-000015:mdna:34]
[same as prior period, unchanged from 0001628280-19-013092:mdna:64]

[0001137789-20-000015:mdna:35]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 13% of gross HDD revenue for each of the December 2019, September 2019 and December 2018 quarters. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-20-000015:mdna:36]
[same as prior period, unchanged from 0001628280-19-013092:mdna:36]

[0001137789-20-000015:mdna:37]
|  |  | For the Three Months Ended |  |  |  |  |  | For the Six Months Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | January 3,2020 |  | October 4,2019 |  | December 28,2018 |  | January 3,2020 |  | December 28,2018 |  |  |  |  |
| Cost of revenue |  | $ | 1,938 |  |  | $ | 1,907 |  |  | $ | 1,921 |  |  | $ | 3,845 |  |  | $ | 3,999 |  |  |  |  |  |
| Gross margin |  | 758 |  |  | 671 |  |  | 794 |  |  | 1,429 |  |  | 1,707 |  |  |  |  |  |
| Gross margin percentage |  | 28 | % |  | 26 | % |  | 29 | % |  | 27 | % |  | 30 | % |  |  |  |  |

[0001137789-20-000015:mdna:38]
Gross margin as a percentage of revenue for the December 2019 quarter increased compared to the September 2019 quarter primarily driven by improved product mix and lower depreciation expense due to the change in useful lives of our manufacturing equipment in the September 2019 quarter, partially offset by price erosion.

[0001137789-20-000015:mdna:39]
Gross margin as a percentage of revenue for the December 2019 quarter decreased compared to the December 2018 quarter primarily driven by price erosion, partially offset by improved product mix and lower depreciation expense due to the change in useful lives of our manufacturing equipment in the September 2019 quarter.

[0001137789-20-000015:mdna:40]
Gross margin as a percentage of revenue for the six months ended January 3, 2020 decreased compared to the six months ended December 28, 2018 primarily driven by price erosion and factory underutilization, partially offset by improved product mix and lower depreciation expense due to the change in useful lives of our manufacturing equipment in the September 2019 quarter.

[0001137789-20-000015:mdna:41]
In the December 2019 quarter, total warranty cost was 0.2% of revenue and included a favorable change in estimates of prior warranty accruals of 0.6% of revenue primarily due to lower repair costs and improvements in return rates on newer generation products. Warranty cost related to new shipments was 0.8%, 0.9% and 1.1% of revenue for the December 2019 quarter, September 2019 quarter and December 2018 quarter, respectively.

[0001137789-20-000015:mdna:42]
[same as prior period, unchanged from 0001628280-19-013092:mdna:41]

[0001137789-20-000015:mdna:43]
|  |  | For the Three Months Ended |  |  |  |  |  | For the Six Months Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | January 3,2020 |  | October 4,2019 |  | December 28,2018 |  | January 3,2020 |  | December 28,2018 |  |  |  |  |
| Product development |  | $ | 250 |  |  | $ | 255 |  |  | $ | 246 |  |  | $ | 505 |  |  | $ | 512 |  |  |  |  |  |
| Marketing and administrative |  | 120 |  |  | 122 |  |  | 120 |  |  | 242 |  |  | 235 |  |  |  |  |  |
| Amortization of intangibles |  | 4 |  |  | 4 |  |  | 5 |  |  | 8 |  |  | 11 |  |  |  |  |  |
| Restructuring and other, net |  | — |  |  | 17 |  |  | 7 |  |  | 17 |  |  | 30 |  |  |  |  |  |
| Operating expenses |  | $ | 374 |  |  | $ | 398 |  |  | $ | 378 |  |  | $ | 772 |  |  | $ | 788 |  |  |  |  |  |

[0001137789-20-000015:mdna:44]
Product development expense. Product development expense for the December 2019 quarter decreased by $5 million compared to the September 2019 quarter primarily due to a $6 million decrease in compensation and other employee benefits resulting primarily from the additional fourteenth week in the September 2019 quarter, partially offset by a $3 million increase in variable compensation expense.

[0001137789-20-000015:mdna:45]
Product development expense increased by $4 million in the December 2019 quarter compared to the December 2018 quarter primarily due to an $8 million increase in compensation and other employee benefits, a $3 million increase in outside services expense and a $3 million increase in variable compensation expense partially offset by a $6 million decrease in depreciation expense and a $4 million decrease in material purchases.

[0001137789-20-000015:mdna:46]
Product development expense decreased by $7 million for the six months ended January 3, 2020 compared to the six months ended December 28, 2018 primarily due to a $13 million decrease in other general expenses as a result of timing of materials purchases and the additional fourteenth week in the September 2019 quarter, and a $13 million decrease in depreciation expense, which was partially offset by an $11 million increase in compensation and other employee benefits and a $6 million increase in outside services expense.

[0001137789-20-000015:mdna:47]
[same as prior period, unchanged from 0001628280-19-013092:mdna:89]

[0001137789-20-000015:mdna:48]
Marketing and administrative expense. Marketing and administrative expense for the December 2019 quarter remained relatively flat compared to both the September 2019 quarter and the December 2018 quarter.

[0001137789-20-000015:mdna:49]
Marketing and administrative expense for the six months ended January 3, 2020 increased by $7 million compared to the six months ended December 28, 2018 primarily due to a $3 million increase in share-based compensation expense and a $2 million increase in compensation and other employee benefits due to the additional fourteenth week in the September 2019 quarter.

[0001137789-20-000015:mdna:50]
Amortization of intangibles. Amortization of intangibles for the December 2019 quarter remained flat compared to the September 2019 quarter.

[0001137789-20-000015:mdna:51]
Amortization of intangibles for the three and six months ended January 3, 2020 decreased by $1 million and $3 million, respectively, compared to the three and six months ended December 28, 2018, due to certain intangible assets that reached the end of their useful lives.

[0001137789-20-000015:mdna:52]
Restructuring and other, net. Restructuring and other, net for the six months ended January 3, 2020 and the three and six months ended December 28, 2018 were comprised of charges primarily related to voluntary early exit programs.

[0001137789-20-000015:mdna:53]
[same as prior period, unchanged from 0001628280-19-013092:mdna:51]

[0001137789-20-000015:mdna:54]
|  |  | For the Three Months Ended |  |  |  |  |  | For the Six Months Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | January 3,2020 |  | October 4,2019 |  | December 28,2018 |  | January 3,2020 |  | December 28,2018 |  |  |  |  |
| Other expense, net |  | $ | (48) |  |  | $ | (75) |  |  | $ | (18) |  |  | $ | (123) |  |  | $ | (53) |  |  |  |  |  |

[0001137789-20-000015:mdna:55]
Other expense, net. Other expense, net for the December 2019 quarter decreased by $27 million from the September 2019 quarter primarily due to a $30 million non-recurring loss resulting from the repurchase of certain long-term debt in the September 2019 quarter and a $5 million decrease in interest expense in the December 2019 quarter due to the decrease in long-term debt, partially offset by a $7 million decrease in interest income in the December 2019 quarter mainly resulting from lower average invested balances.

[0001137789-20-000015:mdna:56]
Other expense, net for the December 2019 quarter increased by $30 million compared to the December 2018 quarter primarily due to $29 million of non-recurring income, net in the December 2018 quarter related to our previous investment in Toshiba Memory Holdings Corporation (“TMHC”), which was redeemed in the quarter ended June 28, 2019 .

[0001137789-20-000015:mdna:57]
Other expense, net for the six months ended January 3, 2020 increased by $70 million compared to the six months ended December 28, 2018 primarily due to $53 million of non-recurring income, net in the six months ended December 28, 2018 related to our previous investment in TMHC, which was redeemed in the quarter ended June 28, 2019 and a $30 million loss resulting from the repurchase of certain long-term debt, partially offset by a related $3 million decrease in interest expense and a $6 million net increase in gains due to favorable changes in foreign currency exchange rates.

[0001137789-20-000015:mdna:58]
[same as prior period, unchanged from 0001628280-19-013092:mdna:55]

[0001137789-20-000015:mdna:59]
|  |  | For the Three Months Ended |  |  |  |  |  | For the Six Months Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | January 3,2020 |  | October 4,2019 |  | December 28,2018 |  | January 3,2020 |  | December 28,2018 |  |  |  |  |
| Provision (benefit) for income taxes |  | $ | 18 |  |  | $ | (2) |  |  | $ | 14 |  |  | $ | 16 |  |  | $ | 32 |  |  |  |  |  |

[0001137789-20-000015:mdna:60]
We recorded income tax provisions of $18 million and $16 million in the three and six months ended January 3, 2020, respectively. The discrete items in the income tax provision were not material for the three months ended January 3, 2020. The income tax provision for the six months ended January 3, 2020 included approximately $10 million of net discrete tax benefits, primarily associated with net excess tax benefits related to share-based compensation expense.

[0001137789-20-000015:mdna:61]
Our income tax provision recorded for the three and six months ended January 3, 2020 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-20-000015:mdna:62]
During the six months ended January 3, 2020, our unrecognized tax benefits excluding interest and penalties increased by approximately $3 million to $86 million; substantially all of which would impact our effective tax rate, if recognized, subject to certain future valuation allowance reversals. During the twelve months beginning January 4, 2020, we expect that our unrecognized tax benefits could be reduced by an immaterial amount as a result of the expiration of certain statutes of limitation.

[0001137789-20-000015:mdna:63]
During the three months ended January 3, 2020, there has been various tax legislation passed which become effective in our fiscal years 2020 and 2021. Tax legislation effective in fiscal year 2020 has no impact to our financial statements. For tax legislation effective beginning in fiscal year 2021, we are in the process of assessing the impact of these tax law changes to our consolidated financial statements.

[0001137789-20-000015:mdna:64]
We recorded income tax provisions of $14 million and $32 million in the three and six months ended December 28, 2018, respectively. The income tax provision for the three and six months ended December 28, 2018 included approximately $5 million and $4 million of net discrete tax benefits, respectively, primarily associated with the recognition of previously unrecognized tax benefits related to the expiration of certain statutes of limitation.

[0001137789-20-000015:mdna:65]
Our income tax provision recorded for the three months ended December 28, 2018 differed from the provision from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-Irish earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.

[0001137789-20-000015:mdna:66]
[same as prior period, unchanged from 0001628280-19-013092:mdna:62]

[0001137789-20-000015:mdna:67]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist primarily of money market funds, time deposits and certificates of deposit. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash have been and will continue to be sufficient to meet our cash needs for the next 12 months. We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term investments, and we do not believe the fair value of our short-term investments has significantly changed from the values reported as of January 3, 2020.

[0001137789-20-000015:mdna:68]
[same as prior period, unchanged from 0001628280-19-013092:mdna:65]

[0001137789-20-000015:mdna:69]
| (Dollars in millions) |  | January 3,2020 |  | June 28,2019 |  | Change |
| Cash and cash equivalents |  | $ | 1,744 |  |  | $ | 2,220 |  |  | $ | (476) |  |

[0001137789-20-000015:mdna:70]
Our cash and cash equivalents as of January 3, 2020 decreased by $476 million from June 28, 2019 primarily as a result of the repurchase of certain senior notes of $645 million for $620 million in aggregate principal amount, repurchases of our ordinary shares of $600 million, payments for capital expenditures of $341 million, and dividends to our shareholders of $335 million, partially offset by net cash of $936 million provided by operating activities and net proceeds of $498 million from borrowings under our Term Loan.

[0001137789-20-000015:mdna:71]
[same as prior period, unchanged from 0001628280-19-013092:mdna:68]

[0001137789-20-000015:mdna:72]
Cash provided by operating activities for the six months ended January 3, 2020 was $936 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-20-000015:mdna:73]
•an increase of $458 million in accounts payable, primarily due to timing of payments and an increase in materials purchased;

[0001137789-20-000015:mdna:74]
•an increase of $22 million in accrued employee compensation primarily due to timing of cash paid to our employees as part of our discretionary spending plans;

[0001137789-20-000015:mdna:75]
•partially offset by an increase of $172 million in inventories, primarily due to an increase in materials purchased for new product ramps; and

[0001137789-20-000015:mdna:76]
•an increase of $124 million in accounts receivable, primarily due to an increase in revenue.

[0001137789-20-000015:mdna:77]
34

[0001137789-20-000015:mdna:78]
[same as prior period, unchanged from 0001628280-19-013092:mdna:74]

[0001137789-20-000015:mdna:79]
Cash used in investing activities for the six months ended January 3, 2020 was $385 million, primarily attributable to the following activities:

[0001137789-20-000015:mdna:80]
•payments for the purchase of property, equipment and leasehold improvements of $341 million; and

[0001137789-20-000015:mdna:81]
•payments for the purchase of investments of $45 million.

[0001137789-20-000015:mdna:82]
[same as prior period, unchanged from 0001628280-19-013092:mdna:76]

[0001137789-20-000015:mdna:83]
Cash used in financing activities of $1,054 million for the six months ended January 3, 2020 was primarily attributable to the following activities:

[0001137789-20-000015:mdna:84]
•$645 million in payments for repurchase of certain long-term debt;

[0001137789-20-000015:mdna:85]
•$600 million in payments for repurchase of our ordinary shares;

[0001137789-20-000015:mdna:86]
•$335 million in dividend payments;

[0001137789-20-000015:mdna:87]
•$39 million in payments for taxes related to net share settlement of equity awards;

[0001137789-20-000015:mdna:88]
•partially offset by $498 million in net proceeds from borrowings under the Term Loan; and

[0001137789-20-000015:mdna:89]
•$69 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-20-000015:mdna:90]
[same as prior period, unchanged from 0001628280-19-013092:mdna:84]

[0001137789-20-000015:mdna:91]
Our primary sources of liquidity as of January 3, 2020 consisted of: (1) approximately $1.7 billion in cash and cash equivalents, (2) cash we expect to generate from operations, and (3) up to $1.5 billion available for borrowing under our Revolving Credit Facility.

[0001137789-20-000015:mdna:92]
As of January 3, 2020, no borrowings had been drawn and no borrowings had been utilized for letters of credit or swing line loans issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-20-000015:mdna:93]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The term of the Revolving Credit Facility is through February 20, 2024, and the maturity date of the Term Loan is September 16, 2025. We were in compliance with the covenants as of January 3, 2020 and expect to be in compliance for the next 12 months.

[0001137789-20-000015:mdna:94]
[same as prior period, unchanged from 0001628280-19-013092:mdna:90]

[0001137789-20-000015:mdna:95]
[same as prior period, unchanged from 0001628280-19-013092:mdna:91]

[0001137789-20-000015:mdna:96]
From time to time we may repurchase any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase outstanding senior notes pursuant to the terms of the applicable indenture.

[0001137789-20-000015:mdna:97]
During the December 2019 quarter, our Board of Directors declared dividends of $0.65 per share, totaling $170 million, which were paid on January 8, 2020. On January 27, 2020, our Board of Directors declared a quarterly cash dividend of $0.65 per share, payable on April 8, 2020 to shareholders of record at the close of business on March 25, 2020.

[0001137789-20-000015:mdna:98]
From time to time, we may repurchase any of our outstanding ordinary shares through tender offers, private, open market or broker-assisted purchases or other means. As of January 3, 2020, $1.6 billion remained available for repurchases under our existing repurchase authorization. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-20-000015:mdna:99]
[same as prior period, unchanged from 0001628280-19-013092:mdna:95]

[0001137789-20-000015:mdna:100]
[same as prior period, unchanged from 0001628280-19-013092:mdna:96]

[0001137789-20-000015:mdna:101]
Other than as described in “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies”, there have been no other material changes in our critical accounting policies and estimates. Refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Part II, Item 7. of our Annual Report on Form 10-K for the fiscal year ended June 28, 2019, as filed with the SEC on August 2, 2019, for a discussion of our critical accounting policies and estimates.

[0001137789-20-000015:mdna:102]
[same as prior period, unchanged from 0001628280-19-013092:mdna:98]

[0001137789-20-000015:mdna:103]
See “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.

[0001137789-20-000015:mdna:104]
36
