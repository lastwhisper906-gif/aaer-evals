# STX notes — 0001137789-20-000015


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001137789-20-000015:notes:1]
Basis of Presentation and Summary of Significant Accounting Policies
Organization

[0001137789-20-000015:notes:2]
[same as prior period, unchanged from 0001628280-19-013092:notes:3]

[0001137789-20-000015:notes:3]
HDDs are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. HDDs continue to be the primary medium of mass data storage due to their performance attributes, reliability, high quality and cost effectiveness. Complementing existing data center storage architecture, SSDs use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high capacity HDD and a smaller SSD acting as a cache to improve performance of frequently accessed data.

[0001137789-20-000015:notes:4]
The Company’s HDD products are designed for both mass capacity storage and legacy markets. Mass capacity storage supports high capacity, low-cost storage applications, including nearline, video and image applications and network-attached storage (“NAS”). Legacy markets include mission critical, desktop, notebook, digital video recorders (“DVRs”), gaming consoles and consumer applications. These markets were previously categorized as enterprise servers and storage systems, edge non-compute applications, and edge compute applications. The Company’s SSD product portfolio is mainly comprised of Serial Attached SCSI (“SAS”) and Non-Volatile Memory Express (“NVMe”) and is designed primarily for applications in enterprise servers and storage systems.

[0001137789-20-000015:notes:5]
[same as prior period, unchanged from 0001628280-19-013092:notes:6]

[0001137789-20-000015:notes:6]
[same as prior period, unchanged from 0001628280-19-013092:notes:7]

[0001137789-20-000015:notes:7]
[same as prior period, unchanged from 0001628280-19-013092:notes:8]

[0001137789-20-000015:notes:8]
The preparation of financial statements in accordance with the United States (“U.S.”) generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements.

[0001137789-20-000015:notes:9]
The Company’s consolidated financial statements for the fiscal year ended June 28, 2019 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 2, 2019. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of June 28, 2019, and the notes thereto, are adequate to make the information presented not misleading.

[0001137789-20-000015:notes:10]
[same as prior period, unchanged from 0001628280-19-013092:notes:11]

[0001137789-20-000015:notes:11]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three and six months ended January 3, 2020 consisted of 13 weeks and 27 weeks, respectively, and the three and six months ended December 28, 2018 consisted of 13 weeks and 26 weeks, respectively. Fiscal year 2020, which ends on July 3, 2020, is comprised of 53 weeks and fiscal year 2019, which ended on June 28, 2019, was comprised of 52 weeks. The fiscal quarters ended January 3, 2020, October 4, 2019 and December 28, 2018, are also referred to herein as the “December 2019 quarter”, the “September 2019 quarter” and the “December 2018 quarter”, respectively. The results of operations for the three and six months ended January 3, 2020 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending July 3, 2020.

[0001137789-20-000015:notes:12]
[same as prior period, unchanged from 0001628280-19-013092:notes:13]

[0001137789-20-000015:notes:13]
Except for the change in the Company’s other long-lived assets and leases policies described below, there have been no material changes to the Company’s significant accounting policies disclosed in Note 1. Basis of Presentation and Summary of Significant Accounting Policies of “Financial Statements and Supplementary Data” contained in Part II, Item 8. of the Company’s Annual Report on Form 10-K for the fiscal year ended June 28, 2019, as filed with the SEC on August 2, 2019.

[0001137789-20-000015:notes:14]
[same as prior period, unchanged from 0001628280-19-013092:notes:15]

[0001137789-20-000015:notes:15]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. This review indicated that the actual lives of certain manufacturing equipment at its manufacturing facilities were longer than the estimated useful lives used for depreciation purposes in the Company’s condensed consolidated financial statements. As a result, effective June 29, 2019, the Company changed its estimate of the useful lives of its manufacturing equipment from a range of three to five years to a range of three to seven years. The effect of this change in estimate increased the net income by $42 million and $65 million for the three and six months ended January 3, 2020, respectively, and increased the diluted earnings per share by $0.16 and $0.24 for the three and six months ended January 3, 2020, respectively.

[0001137789-20-000015:notes:16]
[same as prior period, unchanged from 0001628280-19-013092:notes:17]

[0001137789-20-000015:notes:17]
Effective June 29, 2019, the Company adopted a new accounting policy for leases in accordance with Accounting Standard Codification (“ASC”) 842, Leases, using the modified retrospective approach. Accordingly, the Company applied the new lease accounting standard prospectively to leases existing or commencing on or after June 29, 2019. The Company elected to apply the practical expedients which allow for not reassessing whether existing contracts contain leases, the classification of existing leases and whether the existing initial direct costs meet the new definition. In addition, the Company elected to combine lease and non-lease components for facility leases and to not recognize right-of-use (“ROU”) assets and lease liabilities for leases with an initial term of 12 months or less on the balance sheet.

[0001137789-20-000015:notes:18]
[same as prior period, unchanged from 0001628280-19-013092:notes:19]

[0001137789-20-000015:notes:19]
[same as prior period, unchanged from 0001628280-19-013092:notes:20]

[0001137789-20-000015:notes:20]
[same as prior period, unchanged from 0001628280-19-013092:notes:21]

[0001137789-20-000015:notes:21]
Recently Adopted Accounting Pronouncements

[0001137789-20-000015:notes:22]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) 2016-02 (ASC Topic 842), Leases, and subsequently issued certain interpretive clarifications on this new guidance which amend a number of aspects of lease accounting, including requiring a lessee to recognize an ROU asset and corresponding lease liability for operating leases and enhanced disclosures. As of June 29, 2019, adoption of the standard resulted in the recognition of ROU assets and corresponding current and non-current lease liabilities of $115 million, $17 million and $57 million, respectively, on the Company’s Condensed Consolidated Balance Sheet, primarily relating to real estate operating leases. The adoption of this ASU did not have a material impact on the Company’s other condensed consolidated financial statements. For information regarding the impact of ASC 842 adoption, see Summary of Significant Accounting Policies - Leases above and Note 5. Leases.

[0001137789-20-000015:notes:23]
In February 2018, the FASB issued ASU 2018-02 (ASC Topic 220), Income Statement—Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”) and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. This ASU became effective and the Company adopted the guidance in the September 2019 quarter. The Company has elected not to reclassify the stranded amounts. The adoption of this guidance did not have a material impact on its condensed consolidated financial statements and disclosures.

[0001137789-20-000015:notes:24]
Recently Issued Accounting Pronouncements

[0001137789-20-000015:notes:25]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles - Goodwill and Other - Internal-Use Software - Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company is required to adopt the guidance in the first quarter of fiscal year 2021. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

[0001137789-20-000015:notes:26]
In June 2016, the FASB issued ASU 2016-13 (ASC Topic 326), Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held. The Company is required to adopt this guidance in the first quarter of fiscal year 2021. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

[0001137789-20-000015:notes:27]
In December 2019, the FASB issued ASU 2019-12 (ASC Topic 740), Simplifying the Accounting for Income Taxes. This ASU simplifies accounting for income taxes by removing certain exceptions to the general principles and amending existing guidance to improve consistent application. The Company is required to adopt this guidance in the first quarter of fiscal year 2022. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001137789-20-000015:notes:28]
[same as prior period, unchanged from 0001628280-19-013092:notes:29]

[0001137789-20-000015:notes:29]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of January 3, 2020:

[0001137789-20-000015:notes:30]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale debt securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 571 |  |  | $ | — |  |  | $ | 571 |  |
| Time deposits and certificates of deposit |  | 101 |  |  | — |  |  | 101 |  |
| Other debt securities |  | 14 |  |  | — |  |  | 14 |  |
| Total |  | $ | 686 |  |  | $ | — |  |  | $ | 686 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 670 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 14 |  |
| Total |  |  |  |  |  | $ | 686 |  |

[0001137789-20-000015:notes:31]
As of January 3, 2020, the Company’s Other current assets included $2 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001137789-20-000015:notes:32]
As of January 3, 2020, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale debt securities were other-than-temporarily impaired as of January 3, 2020.

[0001137789-20-000015:notes:33]
The fair value and amortized cost of the Company’s investments classified as available-for-sale debt securities as of January 3, 2020, by remaining contractual maturity were as follows:

[0001137789-20-000015:notes:34]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 672 |  |  | $ | 672 |  |
| Due in 1 to 5 years |  | 6 |  |  | 6 |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | 8 |  |  | 8 |  |
| Total |  | $ | 686 |  |  | $ | 686 |  |

[0001137789-20-000015:notes:35]
[same as prior period, unchanged from 0001628280-19-013092:notes:36]

[0001137789-20-000015:notes:36]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale debt securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 417 |  |  | $ | — |  |  | $ | 417 |  |
| Time deposits and certificates of deposit |  | 133 |  |  | — |  |  | 133 |  |
| Other debt securities |  | 7 |  |  | — |  |  | 7 |  |
| Total |  | $ | 557 |  |  | $ | — |  |  | $ | 557 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 548 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 7 |  |
| Total |  |  |  |  |  | $ | 557 |  |

[0001137789-20-000015:notes:37]
[same as prior period, unchanged from 0001628280-19-013092:notes:38]

[0001137789-20-000015:notes:38]
As of June 28, 2019, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale debt securities were other-than-temporarily impaired as of June 28, 2019.

[0001137789-20-000015:notes:39]
[same as prior period, unchanged from 0001628280-19-013092:notes:40]

[0001137789-20-000015:notes:40]
[same as prior period, unchanged from 0001628280-19-013092:notes:41]

[0001137789-20-000015:notes:41]
| (Dollars in millions) |  | January 3,2020 |  |  |  | June 28,2019 |  | December 28,2018 |  |  |  | June 29,2018 |
| Cash and cash equivalents |  | $ | 1,744 |  |  |  |  | $ | 2,220 |  |  | $ | 1,357 |  |  |  |  | $ | 1,853 |  |
| Restricted cash included in Other current assets |  | 2 |  |  |  |  | 31 |  |  | 3 |  |  |  |  | 4 |  |
| Total cash, cash equivalents and restricted cash presented on the Statements of Cash Flows |  | $ | 1,746 |  |  |  |  | $ | 2,251 |  |  | $ | 1,360 |  |  |  |  | $ | 1,857 |  |

[0001137789-20-000015:notes:42]
As of June 28, 2019, the Company’s Other current assets included $31 million in restricted cash and cash equivalents in an escrow account for the sale of certain properties and cash equivalents held as collateral at banks for various performance obligations.

[0001137789-20-000015:notes:43]
[same as prior period, unchanged from 0001628280-19-013092:notes:43]

[0001137789-20-000015:notes:44]
[same as prior period, unchanged from 0001628280-19-013092:notes:44]

[0001137789-20-000015:notes:45]
| (Dollars in millions) |  | January 3,2020 |  | June 28,2019 |
| Raw materials and components |  | $ | 346 |  |  | $ | 336 |  |
| Work-in-process |  | 365 |  |  | 217 |  |
| Finished goods |  | 437 |  |  | 417 |  |
| Total inventories |  | $ | 1,148 |  |  | $ | 970 |  |

[0001137789-20-000015:notes:46]
[same as prior period, unchanged from 0001628280-19-013092:notes:46]

[0001137789-20-000015:notes:47]
[same as prior period, unchanged from 0001628280-19-013092:notes:47]

[0001137789-20-000015:notes:48]
| (Dollars in millions) |  | January 3,2020 |  | June 28,2019 |
| Property, equipment and leasehold improvements |  | $ | 10,095 |  |  | $ | 9,835 |  |
| Accumulated depreciation and amortization |  | (8,046) |  |  | (7,966) |  |
| Property, equipment and leasehold improvements, net |  | $ | 2,049 |  |  | $ | 1,869 |  |

[0001137789-20-000015:notes:49]
[same as prior period, unchanged from 0001628280-19-013092:notes:49]

[0001137789-20-000015:notes:50]
[same as prior period, unchanged from 0001628280-19-013092:notes:50]

[0001137789-20-000015:notes:51]
| (Dollars in millions) |  | January 3,2020 |  | June 28,2019 |
| Dividends payable |  | $ | 170 |  |  | $ | 170 |  |
| Other accrued expenses |  | 383 |  |  | 382 |  |
| Total accrued expenses |  | $ | 553 |  |  | $ | 552 |  |

[0001137789-20-000015:notes:52]
[same as prior period, unchanged from 0001628280-19-013092:notes:52]

[0001137789-20-000015:notes:53]
[same as prior period, unchanged from 0001628280-19-013092:notes:53]

[0001137789-20-000015:notes:54]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  | Unrealized Gains/(Losses) on Available-for-Sale Debt Securities |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at June 28, 2019 |  | $ | — |  |  | $ | — |  |  | $ | (20) |  |  | $ | (14) |  |  | $ | (34) |  |
| Other comprehensive income (loss) before reclassifications |  | 2 |  |  | — |  |  | — |  |  | (2) |  |  | — |  |
| Amounts reclassified from AOCI |  | 1 |  |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Other comprehensive income (loss) |  | 3 |  |  | — |  |  | — |  |  | (2) |  |  | 1 |  |
| Balance at January 3, 2020 |  | $ | 3 |  |  | $ | — |  |  | $ | (20) |  |  | $ | (16) |  |  | $ | (33) |  |
| Balance at June 29, 2018 |  | $ | — |  |  | $ | — |  |  | $ | (4) |  |  | $ | (12) |  |  | $ | (16) |  |
| Other comprehensive loss before reclassifications |  | (1) |  |  | — |  |  | — |  |  | (2) |  |  | (3) |  |
| Amounts reclassified from AOCI |  | (2) |  |  | — |  |  | — |  |  | — |  |  | (2) |  |
| Other comprehensive loss |  | (3) |  |  | — |  |  | — |  |  | (2) |  |  | (5) |  |
| Balance at December 28, 2018 |  | $ | (3) |  |  | $ | — |  |  | $ | (4) |  |  | $ | (14) |  |  | $ | (21) |  |


## us-gaap:DebtDisclosureTextBlock

[0001137789-20-000015:notes:55]
Debt
Credit Agreement

[0001137789-20-000015:notes:56]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement (the “Credit Agreement”) on February 20, 2019, which was most recently amended on September 16, 2019. The Credit Agreement provides an up to $1.5 billion senior unsecured revolving credit facility (“Revolving Credit Facility”) and a term loan facility in an aggregate principal amount of $500 million (“Term Loan”). The Revolving Credit Facility has a final maturity of February 20, 2024 and the Term Loan has a final maturity date of September 16, 2025. The loans made under the Revolving Credit Facility and the Term Loan will bear interest at a rate of the London Interbank Offered Rate (“LIBOR”) plus a variable margin for each facility that will be determined based on the corporate credit rating of the Company. STX and certain of its material subsidiaries fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loan. The Revolving Credit Facility also allows such facility to increase by an additional $100 million, provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at least $25 million, and (iii) the existing commitments under such facility receive 0.50% most favored nation protection. An aggregate amount of up to $75 million of the Revolving Credit Facility is available for the issuance of letters of credit, and an aggregate amount of up to $50 million of such facility is also available for swing line loans.

[0001137789-20-000015:notes:57]
On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the Term Loan and the proceeds were used to repurchase a portion of its outstanding senior notes. The Term Loan is repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with the remaining balance payable upon maturity.

[0001137789-20-000015:notes:58]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of January 3, 2020 and expects to be in compliance for the next 12 months.

[0001137789-20-000015:notes:59]
As of January 3, 2020, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the Revolving Credit Facility.

[0001137789-20-000015:notes:60]
Other Long-Term Debt

[0001137789-20-000015:notes:61]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of approximately $250 million was repurchased pursuant to cash tender offers for certain senior notes (the “Tender Offers”). The Company recorded a loss of $10 million during the six months ended January 3, 2020, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

[0001137789-20-000015:notes:62]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of $200 million was repurchased pursuant to the Tender Offers. The Company recorded a loss of $10 million during the six months ended January 3, 2020, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

[0001137789-20-000015:notes:63]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”). The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

[0001137789-20-000015:notes:64]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of approximately $170 million was repurchased pursuant to the Tender Offers. The Company recorded a loss of $8 million during the six months ended January 3, 2020, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

[0001137789-20-000015:notes:65]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

[0001137789-20-000015:notes:66]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

[0001137789-20-000015:notes:67]
At January 3, 2020, future principal payments on long-term debt were as follows (in millions):

[0001137789-20-000015:notes:68]
| Fiscal Year |  | Amount |
| Remainder of 2020 |  | $ | — |  |
| 2021 |  | 19 |  |
| 2022 |  | 525 |  |
| 2023 |  | 766 |  |
| 2024 |  | 525 |  |
| Thereafter |  | 2,336 |  |
| Total |  | $ | 4,171 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001137789-20-000015:notes:69]
The Company recorded income tax provisions of $18 million and $16 million in the three and six months ended January 3, 2020, respectively. The discrete items in the income tax provision were not material for the three months ended January 3, 2020. The income tax provision for the six months ended January 3, 2020 included approximately $10 million of net discrete tax benefits, primarily associated with net excess tax benefits related to share-based compensation expense.

[0001137789-20-000015:notes:70]
The Company’s income tax provision recorded for the three and six months ended January 3, 2020 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-20-000015:notes:71]
During the six months ended January 3, 2020, the Company’s unrecognized tax benefits excluding interest and penalties increased by approximately $3 million to $86 million; substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. During the twelve months beginning January 4, 2020, the Company expects that its unrecognized tax benefits could be reduced by an immaterial amount as a result of the expiration of certain statutes of limitation.

[0001137789-20-000015:notes:72]
During the three months ended January 3, 2020, there has been various tax legislation passed which become effective in the Company’s fiscal years 2020 and 2021. Tax legislation effective in fiscal year 2020 has no impact to the Company’s financial statements. For tax legislation effective beginning fiscal year 2021, the Company is in the process of assessing the impact of these tax law changes to the consolidated financial statements.

[0001137789-20-000015:notes:73]
The Company recorded income tax provisions of $14 million and $32 million in the three and six months ended December 28, 2018, respectively. The income tax provision for the three and six months ended December 28, 2018 included approximately $5 million and $4 million of net discrete tax benefits, respectively, primarily associated with the recognition of previously unrecognized tax benefits related to the expiration of certain statutes of limitation.

[0001137789-20-000015:notes:74]
The Company’s income tax provision recorded for the three and six months ended December 28, 2018 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001137789-20-000015:notes:75]
Leases
The Company is a lessee in several operating leases related to real estate facilities for warehouse and office space.

[0001137789-20-000015:notes:76]
[same as prior period, unchanged from 0001628280-19-013092:notes:76]

[0001137789-20-000015:notes:77]
[same as prior period, unchanged from 0001628280-19-013092:notes:77]

[0001137789-20-000015:notes:78]
| (Dollars in millions) |  | For the Three Months Ended January 3, 2020 |  | For the Six Months Ended January 3, 2020 |
| Operating lease cost |  | $ | 5 |  |  | $ | 11 |  |
| Variable lease cost |  | 1 |  |  | 2 |  |
| Total lease cost |  | $ | 6 |  |  | $ | 13 |  |
| Operating cash outflows from operating leases |  | $ | 5 |  |  | $ | 9 |  |

[0001137789-20-000015:notes:79]
|  |  | January 3,2020 |
| Weighted-average remaining lease term |  | 12.9 years |
| Weighted-average discount rate |  | 6.29 | % |

[0001137789-20-000015:notes:80]
[same as prior period, unchanged from 0001628280-19-013092:notes:79]

[0001137789-20-000015:notes:81]
| (Dollars in millions) |  | Balance Sheet Location |  | January 3,2020 |
| ROU assets |  | Other assets, net |  | $ | 109 |  |
| Current lease liabilities |  | Accrued expenses |  | $ | 14 |  |
| Non-current lease liabilities |  | Other non-current liabilities |  | $ | 55 |  |

[0001137789-20-000015:notes:82]
At January 3, 2020, future lease payments included in the measurement of lease liabilities were as follows (in millions):

[0001137789-20-000015:notes:83]
| Fiscal Year |  | Amount |
| Remainder of 2020 |  | $ | 6 |  |
| 2021 |  | 16 |  |
| 2022 |  | 14 |  |
| 2023 |  | 10 |  |
| 2024 |  | 5 |  |
| Thereafter |  | 105 |  |
| Total lease payments |  | 156 |  |
| Less: imputed interest |  | (87) |  |
| Present value of lease liabilities |  | $ | 69 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001137789-20-000015:notes:84]
The Company recorded net restructuring charges of approximately $17 million for the six months ended January 3, 2020. Restructuring charges were not material for the three months ended January 3, 2020. The Company’s restructuring plans are comprised primarily of charges related to workforce reduction costs and facilities and other exit costs. All restructuring charges are reported in Restructuring and other, net on the Company’s Condensed Consolidated Statements of Operations.

[0001137789-20-000015:notes:85]
The following table summarizes the Company’s restructuring activities under all of the Company’s active restructuring plans for the six months ended January 3, 2020:

[0001137789-20-000015:notes:86]
|  |  | Restructuring Plans |  |  |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at June 28, 2019 |  | $ | 13 |  |  | $ | 17 |  |  | $ | 30 |  |
| Lease adoption adjustment |  | — |  |  | (11) |  |  | (11) |  |
| Restructuring charges |  | 20 |  |  | 1 |  |  | 21 |  |
| Cash payments |  | (15) |  |  | (3) |  |  | (18) |  |
| Adjustments |  | (4) |  |  | — |  |  | (4) |  |
| Accrual balances at January 3, 2020 |  | $ | 14 |  |  | $ | 4 |  |  | $ | 18 |  |
| Total costs incurred to date as of January 3, 2020 |  | $ | 474 |  |  | $ | 118 |  |  | $ | 592 |  |
| Total expected charges to be incurred as of January 3, 2020 |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001137789-20-000015:notes:87]
Derivative Financial Instruments
 The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts. The objective of foreign currency forward exchange contracts is to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies.

[0001137789-20-000015:notes:88]
In the September 2019 quarter, the Company entered into certain interest rate swap agreements with a notional amount of $500 million to convert the variable interest rate on its Term Loan to fixed interest rates. The contracts will mature on September 16, 2025. The objective of the interest rate swap agreements is to eliminate the variability of interest payment cash flows associated with variable interest rates. The Company designated the interest rate swaps as cash flow hedges.

[0001137789-20-000015:notes:89]
The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives on its Condensed Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The amount of net unrealized gain on cash flow hedges was $3 million as of January 3, 2020 and the amount of net unrealized loss on cash flow hedges was not material as of June 28, 2019. As of January 3, 2020, the amount of existing net gains related to cash flow hedges recorded in Accumulated other comprehensive loss included $3 million that is expected to be reclassified to earnings within twelve months.

[0001137789-20-000015:notes:90]
The Company de-designates its cash flow hedges when the forecasted hedged transactions affect earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss on the Company’s Condensed Consolidated Balance Sheets are reclassified into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company recognized a net loss of $1 million in Other expense, net related to the loss of hedge designation on discontinued cash flow hedges during the three and six months ended January 3, 2020. The Company recognized a net gain of $1 million and $2 million in Other expense, net related to the loss of hedge designation on discontinued cash flow hedges during the three and six months ended December 28, 2018, respectively.

[0001137789-20-000015:notes:91]
Other derivatives not designated as hedging instruments consist of foreign currency forward exchange contracts that the Company uses to hedge the foreign currency exposure on forecasted expenditures denominated in currencies other than the U.S. dollar. The Company recognizes gains and losses on these contracts, as well as the related costs in Other, net on its Condensed Consolidated Statements of Operations.

[0001137789-20-000015:notes:92]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of January 3, 2020 and June 28, 2019. All of the foreign currency forward exchange contracts mature within 12 months.

[0001137789-20-000015:notes:93]
|  |  | As of January 3, 2020 |  |  |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| Singapore Dollar |  | $ | 26 |  |  | $ | 32 |  |
| Chinese Renminbi |  | 10 |  |  | 20 |  |
|  |  | $ | 36 |  |  | $ | 52 |  |

[0001137789-20-000015:notes:94]
|  |  | As of June 28, 2019 |  |  |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| Singapore Dollar |  | $ | 60 |  |  | $ | 40 |  |
| Chinese Renminbi |  | 79 |  |  | 20 |  |
| British Pound Sterling |  | 6 |  |  | 12 |  |
|  |  | $ | 145 |  |  | $ | 72 |  |

[0001137789-20-000015:notes:95]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its non-qualified deferred compensation plan: the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees. As of January 3, 2020, the notional investments underlying the TRS amounted to $124 million. The contract term of the TRS is through January 2021 and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001137789-20-000015:notes:96]
The following tables show the Company’s derivative instruments measured at gross fair value as reflected on its Condensed Consolidated Balance Sheets as of January 3, 2020 and June 28, 2019:

[0001137789-20-000015:notes:97]
|  |  | As of January 3, 2020 |  |  |  |  |  |  |
|  |  | Derivative Assets |  |  |  | Derivative Liabilities |  |  |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 1 |  |  | Accrued expenses |  | $ | — |  |
| Interest rate swap |  | Other current assets |  | 2 |  |  | Accrued expenses |  | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 3 |  |  |  |  | $ | — |  |

[0001137789-20-000015:notes:98]
|  |  | As of June 28, 2019 |  |  |  |  |  |  |
|  |  | Derivative Assets |  |  |  | Derivative Liabilities |  |  |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 1 |  |  | Accrued expenses |  | (1) |  |
| Total derivatives |  |  |  | $ | 1 |  |  |  |  | $ | (1) |  |

[0001137789-20-000015:notes:99]
The following tables show the effect of the Company’s derivative instruments on its Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three and six months ended January 3, 2020:

[0001137789-20-000015:notes:100]
|  |  | Location of Gain/(Loss) Recognized inIncome on Derivatives |  | Amount of Gain/(Loss) Recognized inIncome on Derivatives |  |  |
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  |  |  | For the Three Months |  | For the Six Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 1 |  |  | $ | (2) |  |
| Total return swap |  | Operating expenses |  | $ | 7 |  |  | $ | 7 |  |

[0001137789-20-000015:notes:101]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  |  |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  |  |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  |  |
|  |  | For the Three Months |  | For the Six Months |  |  |  | For the Three Months |  | For the Six Months |  |  |  | For the Three Months |  | For the Six Months |
| Foreign currency forward exchange contracts |  | $ | 1 |  |  | $ | — |  |  | Other expense, net |  |  | $ | (1) |  |  | $ | (1) |  |  | Other expense, net |  |  | $ | — |  |  | $ | — |  |
| Interest rate swap |  | $ | 2 |  |  | $ | 2 |  |  | Other expense, net |  | $ | — |  |  | $ | — |  |  | Other expense, net |  | $ | — |  |  | $ | — |  |

[0001137789-20-000015:notes:102]
The following tables show the effect of the Company’s derivative instruments on its Condensed Consolidated Statements of Comprehensive Income and its Condensed Consolidated Statements of Operations for the three and six months ended December 28, 2018:

[0001137789-20-000015:notes:103]
|  |  | Location of Gain/(Loss) Recognized inIncome on Derivatives |  | Amount of Gain/(Loss) Recognized inIncome on Derivatives |  |  |
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  |  |  | For the Three Months |  | For the Six Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (13) |  |  | $ | 28 |  |
| Total return swap |  | Operating expenses |  | $ | (15) |  |  | $ | (11) |  |

[0001137789-20-000015:notes:104]
|  |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  |  |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  |  |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  |  |
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | For the Three Months |  | For the Six Months |  |  |  | For the Three Months |  | For the Six Months |  |  |  | For the Three Months |  | For the Six Months |
| Foreign currency forward exchange contracts |  | $ | (4) |  |  | $ | (1) |  |  | Other expense, net |  |  | $ | 1 |  |  | $ | 2 |  |  | Other expense, net |  |  | $ | 1 |  |  | $ | 1 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001137789-20-000015:notes:105]
Fair Value
Measurement of Fair Value

[0001137789-20-000015:notes:106]
[same as prior period, unchanged from 0001628280-19-013092:notes:109]

[0001137789-20-000015:notes:107]
[same as prior period, unchanged from 0001628280-19-013092:notes:110]

[0001137789-20-000015:notes:108]
[same as prior period, unchanged from 0001628280-19-013092:notes:111]

[0001137789-20-000015:notes:109]
[same as prior period, unchanged from 0001628280-19-013092:notes:112]

[0001137789-20-000015:notes:110]
[same as prior period, unchanged from 0001628280-19-013092:notes:113]

[0001137789-20-000015:notes:111]
[same as prior period, unchanged from 0001628280-19-013092:notes:114]

[0001137789-20-000015:notes:112]
The Company considers an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and views an inactive market as one in which there are few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, the Company’s or the counterparty’s non-performance risk is considered in determining the fair values of liabilities and assets, respectively.

[0001137789-20-000015:notes:113]
[same as prior period, unchanged from 0001628280-19-013092:notes:116]

[0001137789-20-000015:notes:114]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item, that are measured at fair value on a recurring basis, excluding accrued interest components, as of January 3, 2020:

[0001137789-20-000015:notes:115]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |  |  |  |  |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 570 |  |  | $ | — |  |  | $ | — |  |  | $ | 570 |  |
| Time deposits and certificates of deposit |  | — |  |  | 100 |  |  | — |  |  | 100 |  |
| Total cash equivalents |  | 570 |  |  | 100 |  |  | — |  |  | 670 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | — |  |  | — |  |  | 14 |  |  | 14 |  |
| Derivative assets |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets |  | $ | 571 |  |  | $ | 104 |  |  | $ | 14 |  |  | $ | 689 |  |

[0001137789-20-000015:notes:116]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |  |  |  |  |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 570 |  |  | $ | 100 |  |  | $ | — |  |  | $ | 670 |  |
| Other current assets |  | 1 |  |  | 4 |  |  | — |  |  | 5 |  |
| Other assets, net |  | — |  |  | — |  |  | 14 |  |  | 14 |  |
| Total assets |  | $ | 571 |  |  | $ | 104 |  |  | $ | 14 |  |  | $ | 689 |  |

[0001137789-20-000015:notes:117]
[same as prior period, unchanged from 0001628280-19-013092:notes:120]

[0001137789-20-000015:notes:118]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |  |  |  |  |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 416 |  |  | $ | — |  |  | $ | — |  |  | $ | 416 |  |
| Time deposits and certificates of deposit |  | — |  |  | 132 |  |  | — |  |  | 132 |  |
| Total cash equivalents |  | 416 |  |  | 132 |  |  | — |  |  | 548 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | — |  |  | — |  |  | 7 |  |  | 7 |  |
| Derivative assets |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total assets |  | $ | 417 |  |  | $ | 134 |  |  | $ | 7 |  |  | $ | 558 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Total liabilities |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |

[0001137789-20-000015:notes:119]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |  |  |  |  |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 416 |  |  | $ | 132 |  |  | $ | — |  |  | $ | 548 |  |
| Other current assets |  | 1 |  |  | 2 |  |  | — |  |  | 3 |  |
| Other assets, net |  | — |  |  | — |  |  | 7 |  |  | 7 |  |
| Total assets |  | $ | 417 |  |  | $ | 134 |  |  | $ | 7 |  |  | $ | 558 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Total liabilities |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |

[0001137789-20-000015:notes:120]
[same as prior period, unchanged from 0001628280-19-013092:notes:123]

[0001137789-20-000015:notes:121]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair value of all of its cash equivalents and short-term investments. For the cash equivalents and short-term investments in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry-standard data providers or other third-party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of January 3, 2020, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts, interest rate swaps and the TRS. The Company recognizes derivative financial instruments in its condensed consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001137789-20-000015:notes:122]
[same as prior period, unchanged from 0001628280-19-013092:notes:125]

[0001137789-20-000015:notes:123]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments primarily include cost basis investments representing those where the Company does not have the ability to exercise significant influence. These investments are included in Other assets, net on the Company’s Condensed Consolidated Balance Sheets, and are periodically analyzed to determine whether or not there are indicators of impairment.

[0001137789-20-000015:notes:124]
As of January 3, 2020 and June 28, 2019, the carrying value of the Company’s strategic investments was $151 million and $114 million, respectively. For the three and six months ended January 3, 2020, the Company recorded a downward adjustment of $1 million in order to write down the carrying amount of an investment to its fair value. This amount was recorded in Other, net in the Condensed Consolidated Statements of Operations. For the three and six months ended December 28, 2018, there were no upward or downward adjustments on equity investments.

[0001137789-20-000015:notes:125]
As of June 28, 2019, the Company had $23 million of held for sale land and building (collectively, the “properties”) included in Other current assets on its Condensed Consolidated Balance Sheets. In July 2019, the Company completed the sale of the properties. As of January 3, 2020, the Company had no held for sale land or buildings.

[0001137789-20-000015:notes:126]
[same as prior period, unchanged from 0001628280-19-013092:notes:129]

[0001137789-20-000015:notes:127]
The Company’s debt is carried at amortized cost. The estimated fair value of the Company’s debt is derived using the closing price of the same debt instruments as of the date of valuation, which takes into account the yield curve, interest rates and other observable inputs. Accordingly, these fair value measurements are categorized as Level 2. The following table presents the fair value and amortized cost of the Company’s debt:

[0001137789-20-000015:notes:128]
|  |  | January 3, 2020 |  |  |  | June 28, 2019 |  |  |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 4.25% Senior Notes due March 2022 |  | $ | 499 |  |  | $ | 517 |  |  | $ | 749 |  |  | $ | 763 |  |
| 4.75% Senior Notes due June 2023 |  | 741 |  |  | 785 |  |  | 941 |  |  | 973 |  |
| 4.875% Senior Notes due March 2024 |  | 498 |  |  | 533 |  |  | 498 |  |  | 514 |  |
| 4.75% Senior Notes due January 2025 |  | 750 |  |  | 798 |  |  | 920 |  |  | 929 |  |
| 4.875% Senior Notes due June 2027 |  | 689 |  |  | 734 |  |  | 689 |  |  | 688 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 520 |  |  | 489 |  |  | 482 |  |
| LIBOR based Term Loan due September 2025 |  | 500 |  |  | 502 |  |  | — |  |  | — |  |
|  |  | 4,166 |  |  | 4,389 |  |  | 4,286 |  |  | 4,349 |  |
| Less: debt issuance costs |  | (25) |  |  | — |  |  | (33) |  |  | — |  |
| Debt, net of debt issuance costs |  | 4,141 |  |  | 4,389 |  |  | 4,253 |  |  | 4,349 |  |
| Less: current portion of long-term debt |  | (6) |  |  | (6) |  |  | — |  |  | — |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 4,135 |  |  | $ | 4,383 |  |  | $ | 4,253 |  |  | $ | 4,349 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001137789-20-000015:notes:129]
Equity
Share Capital

[0001137789-20-000015:notes:130]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 260,923,948 shares were outstanding as of January 3, 2020, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of January 3, 2020.

[0001137789-20-000015:notes:131]
Ordinary shares—Holders of ordinary shares are entitled to receive dividends as and when declared by the Board of Directors. Upon any liquidation, dissolution, or winding up, after required payments are made to holders of preferred shares, any remaining assets will be distributed ratably to holders of the preferred and ordinary shares. Holders of shares are entitled to one vote per share on all matters upon which the ordinary shares are entitled to vote, including the election of directors.

[0001137789-20-000015:notes:132]
[same as prior period, unchanged from 0001628280-19-013092:notes:136]

[0001137789-20-000015:notes:133]
[same as prior period, unchanged from 0001628280-19-013092:notes:137]

[0001137789-20-000015:notes:134]
[same as prior period, unchanged from 0001628280-19-013092:notes:138]

[0001137789-20-000015:notes:135]
All repurchases are effected as redemptions in accordance with the Company’s Constitution.

[0001137789-20-000015:notes:136]
As of January 3, 2020, $1.6 billion remained available for repurchase under the existing repurchase authorization limit.

[0001137789-20-000015:notes:137]
The following table sets forth information with respect to repurchases of ordinary shares during the six months ended January 3, 2020:

[0001137789-20-000015:notes:138]
| (In millions) |  |  | Number of Shares Repurchased |  |  | Dollar Value of Shares Repurchased |  |
| Repurchases of ordinary shares |  |  | 12 |  |  | $ | 597 |  |
| Tax withholding related to vesting of equity awards |  |  | 1 |  |  | 39 |  |
| Total |  |  | 13 |  |  | $ | 636 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001137789-20-000015:notes:139]
RevenueThe following table provides information about disaggregated revenue by sales channel and geographical region for the Company’s single reportable segment:

[0001137789-20-000015:notes:140]
|  |  | For the Three Months Ended |  |  |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | January 3,2020 |  | December 28,2018 |  | January 3,2020 |  | December 28,2018 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,843 |  |  | $ | 1,865 |  |  | $ | 3,663 |  |  | $ | 4,003 |  |
| Distributors |  | 463 |  |  | 443 |  |  | 924 |  |  | 977 |  |
| Retailers |  | 390 |  |  | 407 |  |  | 687 |  |  | 726 |  |
| Total |  | $ | 2,696 |  |  | $ | 2,715 |  |  | $ | 5,274 |  |  | $ | 5,706 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,377 |  |  | $ | 1,386 |  |  | $ | 2,655 |  |  | $ | 2,854 |  |
| Americas |  | 761 |  |  | 731 |  |  | 1,596 |  |  | 1,737 |  |
| EMEA |  | 558 |  |  | 598 |  |  | 1,023 |  |  | 1,115 |  |
| Total |  | $ | 2,696 |  |  | $ | 2,715 |  |  | $ | 5,274 |  |  | $ | 5,706 |  |

[0001137789-20-000015:notes:141]
_________________________________

[0001137789-20-000015:notes:142]
[same as prior period, unchanged from 0001628280-19-013092:notes:147]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001137789-20-000015:notes:143]
Guarantees
Indemnifications of Officers and Directors

[0001137789-20-000015:notes:144]
Seagate Technology, an exempted company incorporated with limited liability under the laws of the Cayman Islands (“Seagate-Cayman”) and wholly-owned subsidiary of STX, from time to time enters into indemnification agreements with the directors, officers, employees and agents of STX or any of its subsidiaries (each, an “Indemnitee”). The indemnification agreements provide indemnification in addition to any of Indemnitee’s indemnification rights under any relevant Articles of Association (or similar constitutional document), applicable law or otherwise, and indemnifies an Indemnitee for certain expenses (including attorneys’ fees), judgments, fines and settlement amounts actually and reasonably incurred by him or her in any action or proceeding, including any action by or in the right of STX or any of its subsidiaries, arising out of his or her service as a director, officer, employee or agent of STX or any of its subsidiaries or of any other entity to which he or she provides services at the Company’s request. However, Indemnitees are not indemnified under the indemnification agreements for (i) any fraud or dishonesty in the performance of Indemnitee’s duty to STX or the applicable subsidiary or (ii) Indemnitee’s conscious, intentional or willful failure to act honestly, lawfully and in good faith with a view to the best interests of the Company. In addition, the indemnification agreements provide that Seagate-Cayman will advance expenses incurred by an Indemnitee in connection with enforcement of the indemnification agreement or with the investigation, settlement or appeal of any action or proceeding against him or her as to which he or she could be indemnified.

[0001137789-20-000015:notes:145]
[same as prior period, unchanged from 0001628280-19-013092:notes:151]

[0001137789-20-000015:notes:146]
Indemnification Obligations

[0001137789-20-000015:notes:147]
The Company from time to time enters into agreements with customers, suppliers, partners and others in the ordinary course of business that provide indemnification for certain matters including, but not limited to, intellectual property infringement claims, environmental claims and breach of agreement claims. The nature of the Company’s indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the Company’s condensed consolidated financial statements with respect to these indemnification obligations.

[0001137789-20-000015:notes:148]
[same as prior period, unchanged from 0001628280-19-013092:notes:154]

[0001137789-20-000015:notes:149]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the six months ended January 3, 2020 and December 28, 2018 were as follows:

[0001137789-20-000015:notes:150]
|  |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | January 3,2020 |  | December 28,2018 |
| Balance, beginning of period |  | $ | 195 |  |  | $ | 237 |  |
| Warranties issued |  | 46 |  |  | 65 |  |
| Repairs and replacements |  | (44) |  |  | (52) |  |
| Changes in liability for pre-existing warranties, including expirations |  | (28) |  |  | (28) |  |
| Balance, end of period |  | $ | 169 |  |  | $ | 222 |  |


## us-gaap:EarningsPerShareTextBlock

[0001137789-20-000015:notes:151]
Earnings Per Share
Basic earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period. Diluted earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period and the number of additional shares that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding options, unvested restricted share units and performance-based share units and shares to be purchased under the Company’s Employee Stock Purchase Plan (“ESPP”). The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in fair market value of the Company’s share price can result in a greater dilutive effect from potentially dilutive securities. The following table sets forth the computation of basic and diluted net income per share attributable to the shareholders of the Company:

[0001137789-20-000015:notes:152]
|  |  | For the Three Months Ended |  |  |  | For the Six Months Ended |  |  |
| (In millions, except per share data) |  | January 3,2020 |  | December 28,2018 |  | January 3,2020 |  | December 28,2018 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 318 |  |  | $ | 384 |  |  | $ | 518 |  |  | $ | 834 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 262 |  |  | 285 |  |  | 264 |  |  | 286 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | 3 |  |  | 2 |  |  | 4 |  |  | 4 |  |
| Total shares for purpose of calculating diluted net income per share |  | 265 |  |  | 287 |  |  | 268 |  |  | 290 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.21 |  |  | $ | 1.35 |  |  | $ | 1.96 |  |  | $ | 2.92 |  |
| Diluted |  | 1.20 |  |  | 1.34 |  |  | 1.93 |  |  | 2.88 |  |

[0001137789-20-000015:notes:153]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share were not material for the three and six months ended January 3, 2020 and were approximately 1 million for the three and six months ended December 28, 2018.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001137789-20-000015:notes:154]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001137789-20-000015:notes:155]
Intellectual Property Litigation

[0001137789-20-000015:notes:156]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al. On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “‘635 patent”) and U.S. Patent No. 5,638,267 (the “‘267 patent”), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants were infringing U.S. Patent No. 6,314,473 (the “‘473 patent”). The district court ruled in 2010 that the ‘267 patent was out of the case.

[0001137789-20-000015:notes:157]
On August 16, 2011, the district court granted in part and denied in part Seagate’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001137789-20-000015:notes:158]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. A jury trial in this matter is scheduled for June 1, 2020. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.

[0001137789-20-000015:notes:159]
Environmental Matters

[0001137789-20-000015:notes:160]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001137789-20-000015:notes:161]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001137789-20-000015:notes:162]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001137789-20-000015:notes:163]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001137789-20-000015:notes:164]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the U.S., Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001137789-20-000015:notes:165]
Other Matters

[0001137789-20-000015:notes:166]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:SubsequentEventsTextBlock

[0001137789-20-000015:notes:167]
Subsequent Events
Dividend Declared

[0001137789-20-000015:notes:168]
On January 27, 2020, the Company’s Board of Directors declared a quarterly cash dividend of $0.65 per share, which will be payable on April 8, 2020 to shareholders of record as of the close of business on March 25, 2020.
