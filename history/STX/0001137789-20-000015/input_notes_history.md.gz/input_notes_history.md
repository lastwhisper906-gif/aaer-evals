# STX note change history — 0001628280-19-013092 → 0001137789-20-000015


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2020-02-05):
[0001137789-20-000015:note_history:1]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

- changed (2020-02-05):
[0001137789-20-000015:note_history:2]
On August 16, 2011, the district court granted in part and denied in part Seagate’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2019-11-01, similarity 0.995):
[0001628280-19-013092:note_history:2]
On August 16, 2011, the district court granted in part and denied in part the Company’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- changed (2020-02-05):
[0001137789-20-000015:note_history:3]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the U.S., Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.
  (was, 2019-11-01, similarity 0.993):
[0001628280-19-013092:note_history:3]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

- removed (2020-02-05):
[0001628280-19-013092:note_history:4]
Legal, Environmental and Other Contingencies

- removed (2020-02-05):
[0001628280-19-013092:note_history:5]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure

- removed (2020-02-05):
[0001628280-19-013092:note_history:6]
to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0001137789-20-000015:note_history:7]
Basis of Presentation and Summary of Significant Accounting Policies
Organization
  (was, 2019-11-01, similarity 0.9128):
[0001628280-19-013092:note_history:7]
Basis of Presentation and Summary of Significant Accounting Policies

- changed (2020-02-05):
[0001137789-20-000015:note_history:8]
HDDs are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. HDDs continue to be the primary medium of mass data storage due to their performance attributes, reliability, high quality and cost effectiveness. Complementing existing data center storage architecture, SSDs use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high capacity HDD and a smaller SSD acting as a cache to improve performance of frequently accessed data.
  (was, 2019-11-01, similarity 0.9381):
[0001628280-19-013092:note_history:8]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, reliability, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state drives use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high capacity hard disk drive and a smaller SSD acting as a cache to improve performance of frequently accessed data.

- added (2020-02-05):
[0001137789-20-000015:note_history:9]
The Company’s HDD products are designed for both mass capacity storage and legacy markets. Mass capacity storage supports high capacity, low-cost storage applications, including nearline, video and image applications and network-attached storage (“NAS”). Legacy markets include mission critical, desktop, notebook, digital video recorders (“DVRs”), gaming consoles and consumer applications. These markets were previously categorized as enterprise servers and storage systems, edge non-compute applications, and edge compute applications. The Company’s SSD product portfolio is mainly comprised of Serial Attached SCSI (“SAS”) and Non-Volatile Memory Express (“NVMe”) and is designed primarily for applications in enterprise servers and storage systems.

- changed (2020-02-05):
[0001137789-20-000015:note_history:10]
The preparation of financial statements in accordance with the United States (“U.S.”) generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements.
  (was, 2019-11-01, similarity 0.9805):
[0001628280-19-013092:note_history:10]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements.

- changed (2020-02-05):
[0001137789-20-000015:note_history:11]
The Company’s consolidated financial statements for the fiscal year ended June 28, 2019 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 2, 2019. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of June 28, 2019, and the notes thereto, are adequate to make the information presented not misleading.
  (was, 2019-11-01, similarity 0.9849):
[0001628280-19-013092:note_history:11]
The Company’s consolidated financial statements for the fiscal year ended June 28, 2019, are included in its Annual Report on Form 10-K, as filed with the United States Securities and Exchange Commission (“SEC”) on August 2, 2019. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of June 28, 2019, and the notes thereto, are adequate to make the information presented not misleading.

- added (2020-02-05):
[0001137789-20-000015:note_history:12]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three and six months ended January 3, 2020 consisted of 13 weeks and 27 weeks, respectively, and the three and six months ended December 28, 2018 consisted of 13 weeks and 26 weeks, respectively. Fiscal year 2020, which ends on July 3, 2020, is comprised of 53 weeks and fiscal year 2019, which ended on June 28, 2019, was comprised of 52 weeks. The fiscal quarters ended January 3, 2020, October 4, 2019 and December 28, 2018, are also referred to herein as the “December 2019 quarter”, the “September 2019 quarter” and the “December 2018 quarter”, respectively. The results of operations for the three and six months ended January 3, 2020 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending July 3, 2020.

- changed (2020-02-05):
[0001137789-20-000015:note_history:13]
Except for the change in the Company’s other long-lived assets and leases policies described below, there have been no material changes to the Company’s significant accounting policies disclosed in Note 1. Basis of Presentation and Summary of Significant Accounting Policies of “Financial Statements and Supplementary Data” contained in Part II, Item 8. of the Company’s Annual Report on Form 10-K for the fiscal year ended June 28, 2019, as filed with the SEC on August 2, 2019.
  (was, 2019-11-01, similarity 0.9979):
[0001628280-19-013092:note_history:13]
Except for the change in the Company’s other long-lived assets and leases policies described below, there have been no material changes to the Company’s significant accounting policies disclosed in Note 1 - Basis of Presentation and Summary of Significant Accounting Policies of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended June 28, 2019, as filed with the SEC on August 2, 2019.

- changed (2020-02-05):
[0001137789-20-000015:note_history:14]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. This review indicated that the actual lives of certain manufacturing equipment at its manufacturing facilities were longer than the estimated useful lives used for depreciation purposes in the Company’s condensed consolidated financial statements. As a result, effective June 29, 2019, the Company changed its estimate of the useful lives of its manufacturing equipment from a range of three to five years to a range of three to seven years. The effect of this change in estimate increased the net income by $42 million and $65 million for the three and six months ended January 3, 2020, respectively, and increased the diluted earnings per share by $0.16 and $0.24 for the three and six months ended January 3, 2020, respectively.
  (was, 2019-11-01, similarity 0.842):
[0001628280-19-013092:note_history:14]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. This review indicated that the actual lives of certain manufacturing equipment at its manufacturing facilities were longer than the estimated useful lives used for deprecation purposes in the Company’s condensed consolidated financial statements. As a result, effective June 29, 2019, the Company changed its estimate of the useful lives of its manufacturing equipment from a range of three to five years to a range of three to seven years. The effect of this change in estimate increased the September 2019 quarter net income by $23 million and diluted earnings per share by $0.09.

- changed (2020-02-05):
[0001137789-20-000015:note_history:15]
Effective June 29, 2019, the Company adopted a new accounting policy for leases in accordance with Accounting Standard Codification (“ASC”) 842, Leases, using the modified retrospective approach. Accordingly, the Company applied the new lease accounting standard prospectively to leases existing or commencing on or after June 29, 2019. The Company elected to apply the practical expedients which allow for not reassessing whether existing contracts contain leases, the classification of existing leases and whether the existing initial direct costs meet the new definition. In addition, the Company elected to combine lease and non-lease components for facility leases and to not recognize right-of-use (“ROU”) assets and lease liabilities for leases with an initial term of 12 months or less on the balance sheet.
  (was, 2019-11-01, similarity 0.9987):
[0001628280-19-013092:note_history:15]
Effective June 29, 2019, the Company adopted a new accounting policy for leases in accordance with Accounting Standard Codification (“ASC”) 842, Leases, using the modified retrospective approach. Accordingly, the Company applied the new lease accounting standard prospectively to leases existing or commencing on or after June 29, 2019. The Company elected to apply the practical expedients which allow for not reassessing whether existing contracts contain leases, the classification of existing leases and whether the existing initial direct costs meet the new definition. In addition, the Company elected to combine lease and non-lease components for facility leases and to not recognize right-of-use (“ROU”) assets and lease liabilities for leases with an initial term of 12 months of less on the balance sheet.

- changed (2020-02-05):
[0001137789-20-000015:note_history:16]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) 2016-02 (ASC Topic 842), Leases, and subsequently issued certain interpretive clarifications on this new guidance which amend a number of aspects of lease accounting, including requiring a lessee to recognize an ROU asset and corresponding lease liability for operating leases and enhanced disclosures. As of June 29, 2019, adoption of the standard resulted in the recognition of ROU assets and corresponding current and non-current lease liabilities of $115 million, $17 million and $57 million, respectively, on the Company’s Condensed Consolidated Balance Sheet, primarily relating to real estate operating leases. The adoption of this ASU did not have a material impact on the Company’s other condensed consolidated financial statements. For information regarding the impact of ASC 842 adoption, see Summary of Significant Accounting Policies - Leases above and Note 5. Leases.
  (was, 2019-11-01, similarity 0.999):
[0001628280-19-013092:note_history:16]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) 2016-02 (ASC Topic 842), Leases and subsequently issued certain interpretive clarifications on this new guidance which amends a number of aspects of lease accounting, including requiring a lessee to recognize an ROU asset and corresponding lease liability for operating leases and enhanced disclosures. As of June 29, 2019, adoption of the standard resulted in the recognition of ROU assets and corresponding current and non-current lease liabilities of $115 million, $17 million and $57 million, respectively, on the Company’s Condensed Consolidated Balance Sheet, primarily relating to real estate operating leases. The adoption of this ASU did not have a material impact on the Company’s other condensed consolidated financial statements. For information regarding the impact of ASC 842 adoption, see Summary of Significant Accounting Policies - Leases above and Note 5. Leases.

- added (2020-02-05):
[0001137789-20-000015:note_history:17]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles - Goodwill and Other - Internal-Use Software - Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company is required to adopt the guidance in the first quarter of fiscal year 2021. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

- changed (2020-02-05):
[0001137789-20-000015:note_history:18]
In June 2016, the FASB issued ASU 2016-13 (ASC Topic 326), Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held. The Company is required to adopt this guidance in the first quarter of fiscal year 2021. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.
  (was, 2019-11-01, similarity 0.9891):
[0001628280-19-013092:note_history:18]
In June 2016, the FASB issued ASU 2016-13 (ASC Topic 326), Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held. The Company is required to adopt this guidance in the first quarter of fiscal year 2021. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- added (2020-02-05):
[0001137789-20-000015:note_history:19]
In December 2019, the FASB issued ASU 2019-12 (ASC Topic 740), Simplifying the Accounting for Income Taxes. This ASU simplifies accounting for income taxes by removing certain exceptions to the general principles and amending existing guidance to improve consistent application. The Company is required to adopt this guidance in the first quarter of fiscal year 2022. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

- removed (2020-02-05):
[0001628280-19-013092:note_history:20]
Organization

- removed (2020-02-05):
[0001628280-19-013092:note_history:21]
The Company’s HDD products are designed for nearline and mission critical applications in enterprise servers and storage systems; edge non-compute applications, where its products are designed for a wide variety of end user devices such as portable external storage systems, video and image applications, including surveillance systems, network-attached storage (“NAS”), digital video recorders (“DVRs”) and gaming consoles; and edge compute applications, where its products are designed primarily for desktop and mobile computing. The Company’s SSD product portfolio is mainly comprised of Serial Attached SCSI (“SAS”) and Non-Volatile Memory Express (“NVMe”) and is designed for applications in enterprise servers and storage systems.

- removed (2020-02-05):
[0001628280-19-013092:note_history:22]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three months ended October 4, 2019 consisted of 14 weeks and the three months ended September 28, 2018 consisted of 13 weeks. Fiscal year 2020, which ends on July 3, 2020, is comprised of 53 weeks and fiscal year 2019, which ended on June 28, 2019, is comprised of 52 weeks. The fiscal quarters ended October 4, 2019, June 28, 2019 and September 28, 2018, are also referred to herein as the “September 2019 quarter”, the “June 2019 quarter”, and the “September 2018 quarter”, respectively. The results of operations for the three months ended October 4, 2019 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending July 3, 2020.

- removed (2020-02-05):
[0001628280-19-013092:note_history:23]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles - Goodwill and Other - Internal-Use Software - Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service

- removed (2020-02-05):
[0001628280-19-013092:note_history:24]
Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company is required to adopt the guidance in the first quarter of fiscal year 2021. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0001137789-20-000015:note_history:25]
Debt
Credit Agreement
  (was, 2019-11-01, similarity 0.8649):
[0001628280-19-013092:note_history:25]
Credit Agreement

- changed (2020-02-05):
[0001137789-20-000015:note_history:26]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of January 3, 2020 and expects to be in compliance for the next 12 months.
  (was, 2019-11-01, similarity 0.974):
[0001628280-19-013092:note_history:26]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of October 4, 2019 and expects to be in compliance for the next 12 months.

- changed (2020-02-05):
[0001137789-20-000015:note_history:27]
As of January 3, 2020, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the Revolving Credit Facility.
  (was, 2019-11-01, similarity 0.9577):
[0001628280-19-013092:note_history:27]
As of October 4, 2019, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the Revolving Credit Facility.

- changed (2020-02-05):
[0001137789-20-000015:note_history:28]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of approximately $250 million was repurchased pursuant to cash tender offers for certain senior notes (the “Tender Offers”). The Company recorded a loss of $10 million during the six months ended January 3, 2020, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2019-11-01, similarity 0.9694):
[0001628280-19-013092:note_history:28]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of approximately $250 million was repurchased pursuant to cash tender offers for certain senior notes (the “Tender Offers”). The Company recorded a loss of $10 million, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- changed (2020-02-05):
[0001137789-20-000015:note_history:29]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of $200 million was repurchased pursuant to the Tender Offers. The Company recorded a loss of $10 million during the six months ended January 3, 2020, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2019-11-01, similarity 0.9661):
[0001628280-19-013092:note_history:29]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of $200 million was repurchased pursuant to the Tender Offers. The Company recorded a loss of $10 million, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- changed (2020-02-05):
[0001137789-20-000015:note_history:30]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”). The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.
  (was, 2019-11-01, similarity 0.9986):
[0001628280-19-013092:note_history:30]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”).The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

- changed (2020-02-05):
[0001137789-20-000015:note_history:31]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of approximately $170 million was repurchased pursuant to the Tender Offers. The Company recorded a loss of $8 million during the six months ended January 3, 2020, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2019-11-01, similarity 0.967):
[0001628280-19-013092:note_history:31]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of approximately $170 million was repurchased pursuant to the Tender Offers. The Company recorded a loss of $8 million, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- changed (2020-02-05):
[0001137789-20-000015:note_history:32]
At January 3, 2020, future principal payments on long-term debt were as follows (in millions):
  (was, 2019-11-01, similarity 0.9326):
[0001628280-19-013092:note_history:32]
At October 4, 2019, future principal payments on long-term debt were as follows (in millions):

- removed (2020-02-05):
[0001628280-19-013092:note_history:33]
Debt


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0001137789-20-000015:note_history:34]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of January 3, 2020:
  (was, 2019-11-01, similarity 0.9531):
[0001628280-19-013092:note_history:34]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of October 4, 2019:

- changed (2020-02-05):
[0001137789-20-000015:note_history:35]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale debt securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 571 |  |  | $ | — |  |  | $ | 571 |  |
| Time deposits and certificates of deposit |  | 101 |  |  | — |  |  | 101 |  |
| Other debt securities |  | 14 |  |  | — |  |  | 14 |  |
| Total |  | $ | 686 |  |  | $ | — |  |  | $ | 686 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 670 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 14 |  |
| Total |  |  |  |  |  | $ | 686 |  |
  (was, 2019-11-01, similarity 0.9681):
[0001628280-19-013092:note_history:35]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 471 |  |  | $ | — |  |  | $ | 471 |  |
| Time deposits and certificates of deposit |  | 351 |  |  | — |  |  | 351 |  |
| Other debt securities |  | 10 |  |  | — |  |  | 10 |  |
| Total |  | $ | 832 |  |  | $ | — |  |  | $ | 832 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 820 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 10 |  |
| Total |  |  |  |  |  |  |  | $ | 832 |  |

- added (2020-02-05):
[0001137789-20-000015:note_history:36]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale debt securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 417 |  |  | $ | — |  |  | $ | 417 |  |
| Time deposits and certificates of deposit |  | 133 |  |  | — |  |  | 133 |  |
| Other debt securities |  | 7 |  |  | — |  |  | 7 |  |
| Total |  | $ | 557 |  |  | $ | — |  |  | $ | 557 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 548 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 7 |  |
| Total |  |  |  |  |  | $ | 557 |  |

- removed (2020-02-05):
[0001628280-19-013092:note_history:37]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 417 |  |  | $ | — |  |  | $ | 417 |  |
| Time deposits and certificates of deposit |  | 133 |  |  | — |  |  | 133 |  |
| Other debt securities |  | 7 |  |  | — |  |  | 7 |  |
| Total |  | $ | 557 |  |  | $ | — |  |  | $ | 557 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 548 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 7 |  |
| Total |  |  |  |  |  |  |  | $ | 557 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0001137789-20-000015:note_history:38]
At January 3, 2020, future principal payments on long-term debt were as follows (in millions):
  (was, 2019-11-01, similarity 0.9326):
[0001628280-19-013092:note_history:38]
At October 4, 2019, future principal payments on long-term debt were as follows (in millions):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-02-05):
[0001137789-20-000015:note_history:39]
|  |  | For the Three Months Ended |  |  |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | January 3,2020 |  | December 28,2018 |  | January 3,2020 |  | December 28,2018 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,843 |  |  | $ | 1,865 |  |  | $ | 3,663 |  |  | $ | 4,003 |  |
| Distributors |  | 463 |  |  | 443 |  |  | 924 |  |  | 977 |  |
| Retailers |  | 390 |  |  | 407 |  |  | 687 |  |  | 726 |  |
| Total |  | $ | 2,696 |  |  | $ | 2,715 |  |  | $ | 5,274 |  |  | $ | 5,706 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,377 |  |  | $ | 1,386 |  |  | $ | 2,655 |  |  | $ | 2,854 |  |
| Americas |  | 761 |  |  | 731 |  |  | 1,596 |  |  | 1,737 |  |
| EMEA |  | 558 |  |  | 598 |  |  | 1,023 |  |  | 1,115 |  |
| Total |  | $ | 2,696 |  |  | $ | 2,715 |  |  | $ | 5,274 |  |  | $ | 5,706 |  |

- changed (2020-02-05):
[0001137789-20-000015:note_history:40]
_________________________________
  (was, 2019-11-01, similarity 0.88):
[0001628280-19-013092:note_history:40]
__________________________________________

- removed (2020-02-05):
[0001628280-19-013092:note_history:41]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 4, 2019 |  | September 28, 2018 |
| Revenues by Channel |  |  |  |  |  |
| OEMs |  | $ | 1,820 |  |  | $ | 2,138 |  |
| Distributors |  | 461 |  |  | 534 |  |
| Retailers |  | 297 |  |  | 319 |  |
| Total |  | $ | 2,578 |  |  | $ | 2,991 |  |
| Revenues by Geography(1) |  |  |  |  |
| Americas |  | $ | 835 |  |  | $ | 1,006 |  |
| EMEA |  | 465 |  |  | 517 |  |
| Asia Pacific |  | 1,278 |  |  | 1,468 |  |
| Total |  | $ | 2,578 |  |  | $ | 2,991 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0001137789-20-000015:note_history:42]
RevenueThe following table provides information about disaggregated revenue by sales channel and geographical region for the Company’s single reportable segment:
  (was, 2019-11-01, similarity 0.9778):
[0001628280-19-013092:note_history:42]
The following table provides information about disaggregated revenue by sales channel and geographical region for the Company’s single reportable segment:

- added (2020-02-05):
[0001137789-20-000015:note_history:43]
|  |  | For the Three Months Ended |  |  |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | January 3,2020 |  | December 28,2018 |  | January 3,2020 |  | December 28,2018 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,843 |  |  | $ | 1,865 |  |  | $ | 3,663 |  |  | $ | 4,003 |  |
| Distributors |  | 463 |  |  | 443 |  |  | 924 |  |  | 977 |  |
| Retailers |  | 390 |  |  | 407 |  |  | 687 |  |  | 726 |  |
| Total |  | $ | 2,696 |  |  | $ | 2,715 |  |  | $ | 5,274 |  |  | $ | 5,706 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,377 |  |  | $ | 1,386 |  |  | $ | 2,655 |  |  | $ | 2,854 |  |
| Americas |  | 761 |  |  | 731 |  |  | 1,596 |  |  | 1,737 |  |
| EMEA |  | 558 |  |  | 598 |  |  | 1,023 |  |  | 1,115 |  |
| Total |  | $ | 2,696 |  |  | $ | 2,715 |  |  | $ | 5,274 |  |  | $ | 5,706 |  |

- changed (2020-02-05):
[0001137789-20-000015:note_history:44]
_________________________________
  (was, 2019-11-01, similarity 0.88):
[0001628280-19-013092:note_history:44]
__________________________________________

- removed (2020-02-05):
[0001628280-19-013092:note_history:45]
Revenue

- removed (2020-02-05):
[0001628280-19-013092:note_history:46]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 4, 2019 |  | September 28, 2018 |
| Revenues by Channel |  |  |  |  |  |
| OEMs |  | $ | 1,820 |  |  | $ | 2,138 |  |
| Distributors |  | 461 |  |  | 534 |  |
| Retailers |  | 297 |  |  | 319 |  |
| Total |  | $ | 2,578 |  |  | $ | 2,991 |  |
| Revenues by Geography(1) |  |  |  |  |
| Americas |  | $ | 835 |  |  | $ | 1,006 |  |
| EMEA |  | 465 |  |  | 517 |  |
| Asia Pacific |  | 1,278 |  |  | 1,468 |  |
| Total |  | $ | 2,578 |  |  | $ | 2,991 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2020-02-05):
[0001137789-20-000015:note_history:47]
Subsequent Events
Dividend Declared
  (was, 2019-11-01, similarity 0.6538):
[0001628280-19-013092:note_history:47]
Subsequent Events

- added (2020-02-05):
[0001137789-20-000015:note_history:48]
On January 27, 2020, the Company’s Board of Directors declared a quarterly cash dividend of $0.65 per share, which will be payable on April 8, 2020 to shareholders of record as of the close of business on March 25, 2020.

- removed (2020-02-05):
[0001628280-19-013092:note_history:49]
Dividend Declared

- removed (2020-02-05):
[0001628280-19-013092:note_history:50]
On October 28, 2019, the Company’s Board of Directors declared a quarterly cash dividend of $0.65 per share, which will be payable on January 8, 2020 to shareholders of record as of the close of business on December 26, 2019.
