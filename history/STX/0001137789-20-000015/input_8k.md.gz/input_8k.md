# STX 8-K — 0001137789-20-000013 filed 2020-02-04

## item codes, every 8-K on or before 2020-02-05

- 2020-02-04 0001137789-20-000013 — 2.02, 7.01, 9.01
- 2019-11-04 0001193125-19-283563 — 5.02, 5.07, 9.01
- 2019-11-01 0001628280-19-013012 — 2.02, 7.01, 9.01
- 2019-09-19 0001193125-19-248970 — 1.01, 2.03, 8.01, 9.01
- 2019-09-18 0001193125-19-247385 — 7.01, 9.01
- 2019-09-04 0001193125-19-237150 — 8.01, 9.01
- 2019-08-02 0001193125-19-211505 — 2.02, 7.01, 9.01
- 2019-06-26 0001193125-19-182712 — 5.02
- 2019-06-18 0001193125-19-175303 — 8.01
- 2019-04-30 0001193125-19-129480 — 5.07
- 2019-04-30 0001193125-19-127378 — 2.02, 7.01, 9.01
- 2019-02-20 0001193125-19-045470 — 1.01, 2.03
- 2019-02-04 0001193125-19-027004 — 2.02, 7.01, 9.01
- 2018-12-21 0001193125-18-356446 — 5.02, 9.01
- 2018-11-02 0001193125-18-316430 — 5.07, 8.01, 9.01
- 2018-11-02 0001193125-18-316418 — 2.02, 7.01, 9.01
- 2018-09-07 0001193125-18-268679 — 5.02 — amendment of 0001193125-18-230467
- 2018-07-30 0001193125-18-230467 — 5.02, 9.01
- 2018-07-30 0001193125-18-230452 — 2.02, 7.01, 9.01
- 2018-07-26 0001193125-18-226626 — 5.02
- 2018-06-01 0001193125-18-181093 — 8.01, 9.01
- 2018-05-01 0001193125-18-145112 — 2.02, 7.01, 9.01
- 2018-01-29 0001193125-18-022528 — 2.02, 7.01, 9.01
- 2018-01-25 0001193125-18-019820 — 5.02, 9.01
- 2018-01-09 0001137789-18-000009 — 2.02, 7.01, 9.01
- 2018-01-08 0001137789-18-000004 — 2.02, 7.01, 9.01
- 2017-12-11 0001137789-17-000101 — 2.05
- 2017-10-23 0001193125-17-316068 — 2.02, 7.01, 9.01
- 2017-10-18 0001137789-17-000068 — 5.02, 5.07, 9.01
- 2017-09-28 0001137789-17-000060 — 1.01
- 2017-07-28 0001137789-17-000046 — 5.02
- 2017-07-25 0001193125-17-234440 — 2.02, 2.05, 5.02, 7.01, 9.01
- 2017-06-02 0001193125-17-192960 — 5.02
- 2017-04-26 0001193125-17-138005 — 2.02, 7.01, 9.01
- 2017-03-10 0001193125-17-077510 — 2.05
- 2017-02-03 0001104659-17-006357 — 1.01, 2.03, 9.01
- 2017-01-31 0001104659-17-005357 — 8.01, 9.01
- 2017-01-31 0001104659-17-005173 — 8.01, 9.01
- 2017-01-27 0001104659-17-004448 — 8.01
- 2017-01-24 0001193125-17-016690 — 2.02, 7.01, 9.01
- 2017-01-20 0001193125-17-013685 — 5.02, 9.01
- 2016-10-24 0001104659-16-151422 — 5.02, 5.03, 5.07, 9.01
- 2016-10-19 0001193125-16-741277 — 2.02, 7.01, 9.01
- 2016-10-11 0001193125-16-734835 — 2.02, 9.01
- 2016-10-04 0001104659-16-148575 — 5.02
- 2016-09-27 0001104659-16-146813 — 5.02
- 2016-08-02 0001104659-16-135908 — 2.02, 7.01, 9.01
- 2016-07-28 0001104659-16-135046 — 5.02
- 2016-07-11 0001104659-16-131996 — 2.02, 2.05, 9.01
- 2016-07-08 0001104659-16-131749 — 5.02
- 2016-06-29 0001104659-16-130122 — 2.05
- 2016-06-27 0001104659-16-129505 — 5.02
- 2016-04-29 0001104659-16-115593 — 2.02, 7.01, 9.01
- 2016-04-13 0001104659-16-111266 — 2.02, 9.01
- 2016-01-29 0001104659-16-092323 — 2.02, 7.01, 9.01
- 2016-01-04 0001104659-16-087730 — 5.02, 9.01
- 2015-10-30 0001104659-15-074350 — 2.02, 7.01, 9.01
- 2015-10-21 0001104659-15-071908 — 5.02, 9.01
- 2015-10-21 0001104659-15-071906 — 5.07, 7.01, 9.01
- 2015-10-15 0001104659-15-070776 — 2.02, 9.01
- 2015-09-21 0001104659-15-066273 — 5.02
- 2015-09-10 0001104659-15-064389 — 2.05
- 2015-08-06 0001104659-15-057159 — 5.02
- 2015-07-31 0001104659-15-055040 — 2.02, 7.01, 9.01
- 2015-07-22 0001104659-15-052507 — 5.02, 9.01
- 2015-07-13 0001104659-15-050755 — 2.02, 9.01
- 2015-05-14 0001104659-15-038166 — 1.01, 2.03, 9.01
- 2015-05-12 0001104659-15-036968 — 8.01, 9.01
- 2015-05-11 0001104659-15-036533 — 8.01, 9.01
- 2015-05-01 0001104659-15-033202 — 5.02
- 2015-04-23 0001104659-15-029483 — 8.01, 9.01
- 2015-04-17 0001104659-15-028152 — 2.02, 7.01, 9.01
- 2015-04-07 0001104659-15-026148 — 7.01
- 2015-01-26 0001104659-15-004316 — 2.02, 7.01, 9.01
- 2015-01-16 0001104659-15-002732 — 1.01, 9.01
- 2015-01-02 0001104659-15-000147 — 8.01
- 2014-12-02 0001104659-14-084370 — 1.01, 2.03, 9.01
- 2014-11-25 0001104659-14-083066 — 8.01, 9.01
- 2014-11-24 0001104659-14-082837 — 8.01, 9.01
- 2014-10-27 0001104659-14-073832 — 2.02, 7.01, 9.01
- 2014-10-24 0001104659-14-073609 — 5.02, 5.07, 9.01
- 2014-10-22 0001104659-14-073104 — 7.01, 9.01
- 2014-10-08 0001104659-14-070767 — 8.01
- 2014-09-12 0001104659-14-066107 — 5.02
- 2014-09-12 0001104659-14-066101 — 7.01
- 2014-07-23 0001104659-14-052995 — 5.02
- 2014-07-17 0001104659-14-052019 — 2.02, 7.01, 9.01
- 2014-06-18 0001104659-14-046714 — 8.01, 9.01
- 2014-06-09 0001104659-14-044575 — 7.01
- 2014-06-04 0001104659-14-043897 — 8.01
- 2014-05-28 0001104659-14-041862 — 1.01, 2.03, 8.01, 9.01
- 2014-05-20 0001104659-14-040454 — 8.01, 9.01
- 2014-05-20 0001104659-14-040220 — 8.01, 9.01
- 2014-04-29 0001104659-14-031916 — 2.02, 7.01, 9.01
- 2014-04-22 0001104659-14-029197 — 5.02
- 2014-02-24 0001104659-14-012465 — 5.02, 7.01, 9.01
- 2014-01-27 0001104659-14-004298 — 2.02, 7.01, 9.01
- 2014-01-23 0001104659-14-003803 — 5.02
- 2013-12-23 0001104659-13-091738 — 1.01, 8.01, 9.01
- 2013-11-05 0001104659-13-081194 — 1.01, 2.03, 9.01
- 2013-11-04 0001104659-13-080161 — 5.02, 5.03, 5.07, 9.01
- 2013-10-31 0001104659-13-079635 — 8.01, 9.01
- 2013-10-31 0001104659-13-079438 — 8.01, 9.01
- 2013-10-28 0001104659-13-078341 — 2.02, 7.01, 9.01
- 2013-10-28 0001104659-13-078316 — 5.02, 7.01, 9.01
- 2013-10-08 0001104659-13-074454 — 1.01, 1.02, 9.01
- 2013-09-20 0001104659-13-071413 — 5.02
- 2013-07-24 0001104659-13-056053 — 5.02, 7.01
- 2013-07-24 0001104659-13-056052 — 2.02, 7.01, 9.01
- 2013-06-14 0001104659-13-049436 — 8.01, 9.01
- 2013-05-31 0001104659-13-045928 — 8.01, 9.01
- 2013-05-22 0001104659-13-043876 — 1.01, 2.03, 9.01
- 2013-05-16 0001104659-13-042180 — 7.01, 9.01
- 2013-05-15 0001104659-13-042028 — 8.01, 9.01
- 2013-05-15 0001104659-13-041695 — 8.01, 9.01
- 2013-05-07 0001104659-13-038226 — 5.02
- 2013-05-01 0001104659-13-036004 — 2.02, 9.01
- 2013-03-15 0001104659-13-021156 — 7.01
- 2013-01-28 0001104659-13-005180 — 2.02, 9.01
- 2013-01-08 0001104659-13-001291 — 2.02, 9.01
- 2012-11-29 0001104659-12-080911 — 8.01, 9.01
- 2012-10-31 0001104659-12-072476 — 2.02, 9.01
- 2012-10-25 0001104659-12-071208 — 5.07
- 2012-10-16 0001104659-12-069238 — 7.01
- 2012-09-28 0001104659-12-066105 — 7.01
- 2012-09-21 0001104659-12-064869 — 7.01
- 2012-08-02 0001104659-12-053775 — 5.02
- 2012-07-30 0001104659-12-052298 — 2.02, 5.02, 8.01, 9.01
- 2012-07-05 0001104659-12-047737 — 2.02, 9.01
- 2012-04-26 0001104659-12-029099 — 5.02, 8.01, 9.01
- 2012-04-17 0001104659-12-025931 — 2.02, 9.01
- 2012-01-31 0001104659-12-005522 — 2.02, 9.01
- 2012-01-27 0001104659-12-004299 — 8.01, 9.01
- 2012-01-04 0001104659-12-000411 — 2.02, 9.01
- 2011-12-20 0001104659-11-070207 — 2.01, 3.02, 9.01
- 2011-12-12 0001104659-11-069005 — 8.01
- 2011-12-05 0001104659-11-067679 — 5.02, 9.01
- 2011-11-29 0001104659-11-066436 — 7.01, 9.01
- 2011-11-22 0001104659-11-065589 — 7.01, 9.01
- 2011-11-03 0001104659-11-060307 — 7.01
- 2011-10-21 0001104659-11-056997 — 2.02, 8.01, 9.01
- 2011-10-12 0001104659-11-055849 — 7.01, 9.01
- 2011-07-29 0001104659-11-041897 — 5.02
- 2011-07-20 0001104659-11-039922 — 2.02, 9.01
- 2011-06-01 0001104659-11-032473 — 8.01
- 2011-05-23 0001104659-11-030867 — 8.01
- 2011-05-18 0001104659-11-029869 — 1.01, 2.03, 9.01
- 2011-05-04 0001104659-11-025801 — 8.01, 9.01
- 2011-05-04 0001104659-11-025462 — 8.01, 9.01
- 2011-04-19 0001104659-11-020787 — 1.01, 2.02, 3.02, 9.01
- 2011-04-08 0001104659-11-019316 — 5.02, 9.01
- 2011-04-07 0001104659-11-019141 — 2.02, 8.01, 9.01
- 2011-03-09 0001104659-11-013084 — 5.02
- 2011-02-18 0001104659-11-008419 — 8.01
- 2011-02-01 0001104659-11-004106 — 5.02, 9.01
- 2011-01-19 0001104659-11-002037 — 1.01, 2.02, 2.03, 5.07, 9.01
- 2010-12-14 0001104659-10-062647 — 1.01, 2.03, 9.01
- 2010-12-08 0001104659-10-061747 — 8.01, 9.01
- 2010-12-08 0001104659-10-061643 — 7.01, 8.01, 9.01
- 2010-11-29 0001104659-10-060338 — 7.01, 9.01
- 2010-10-20 0001104659-10-052966 — 2.02, 9.01
- 2010-10-15 0001104659-10-052362 — 8.01, 9.01
- 2010-09-13 0001104659-10-048317 — 5.02, 9.01
- 2010-08-16 0001104659-10-044431 — 5.02
- 2010-07-29 0001104659-10-040519 — 5.02, 9.01
- 2010-07-20 0001104659-10-038670 — 2.02, 9.01
- 2010-07-06 0001104659-10-036996 — 1.01, 2.03, 3.01, 3.03, 5.01, 5.02, 8.01, 9.01
- 2010-06-25 0001104659-10-035630 — 8.01, 9.01
- 2010-05-26 0001104659-10-030931 — 5.02
- 2010-05-14 0001104659-10-028664 — 1.01, 2.03, 9.01
- 2010-04-30 0001104659-10-023493 — 8.01, 9.01
- 2010-04-29 0001104659-10-022773 — 1.02, 8.01, 9.01
- 2010-04-20 0001104659-10-020750 — 2.02, 9.01
- 2010-04-16 0001104659-10-020113 — 5.07
- 2010-03-22 0001104659-10-015668 — 1.01, 9.01
- 2010-03-03 0001104659-10-011870 — 1.01, 2.03, 9.01
- 2010-01-20 0001104659-10-002269 — 2.02, 9.01
- 2009-10-29 0001104659-09-060949 — 5.02, 7.01
- 2009-10-20 0001104659-09-059594 — 2.02, 9.01
- 2009-10-01 0001104659-09-057311 — 1.01, 2.03, 2.06, 9.01
- 2009-09-22 0001104659-09-055716 — 7.01, 9.01
- 2009-08-04 0001193125-09-163032 — 2.05
- 2009-07-31 0001193125-09-160678 — 5.02, 9.01
- 2009-07-21 0001193125-09-152269 — 2.02, 9.01
- 2009-07-09 0001193125-09-146452 — 5.02
- 2009-06-24 0001193125-09-136674 — 7.01, 9.01
- 2009-06-01 0001193125-09-122549 — 1.01, 2.03, 9.01
- 2009-05-14 0001193125-09-110016 — 8.01, 9.01
- 2009-05-13 0001193125-09-109216 — 2.05, 7.01, 9.01
- 2009-05-05 0001193125-09-099861 — 1.01, 2.03, 9.01
- 2009-04-21 0001193125-09-083544 — 2.02, 9.01
- 2009-04-17 0001193125-09-081018 — 8.01, 9.01
- 2009-04-13 0001193125-09-077471 — 2.02, 9.01
- 2009-04-13 0001193125-09-077470 — 8.01, 9.01
- 2009-04-06 0001193125-09-073113 — 1.01, 2.03, 9.01
- 2009-03-09 0001193125-09-048538 — 5.02
- 2009-03-04 0001193125-09-044916 — 5.02, 8.01
- 2009-02-06 0001193125-09-021262 — 5.02
- 2009-02-04 0001193125-09-018804 — 5.02, 8.01
- 2009-02-02 0001193125-09-016478 — 2.06 — amendment, the index does not say of what
- 2009-01-27 0001193125-09-012058 — 5.02
- 2009-01-21 0001193125-09-009019 — 2.02, 5.02, 9.01
- 2009-01-14 0001193125-09-005721 — 2.05, 7.01
- 2009-01-12 0001193125-09-004420 — 5.02, 7.01, 9.01
- 2008-12-24 0001193125-08-259972 — 2.06
- 2008-12-12 0001193125-08-252765 — 2.03
- 2008-12-10 0001193125-08-250840 — 7.01
- 2008-11-12 0001193125-08-233906 — 5.02
- 2008-10-22 0001193125-08-214482 — 2.02, 9.01
- 2008-09-19 0001193125-08-198664 — 2.05
- 2008-09-12 0001193125-08-195206 — 1.01
- 2008-08-27 0001193125-08-185448 — 1.02, 3.01, 5.02, 9.01
- 2008-07-15 0001193125-08-151292 — 2.02, 9.01
- 2008-07-11 0001193125-08-149749 — 2.05
- 2008-07-03 0001193125-08-146791 — 5.02
- 2008-04-29 0001193125-08-094835 — 5.02, 9.01
- 2008-04-15 0001193125-08-081743 — 2.02, 9.01
- 2008-03-12 0001193125-08-054331 — 8.01, 9.01
- 2008-03-04 0001193125-08-045657 — 7.01
- 2008-02-04 0001193125-08-019262 — 8.01, 9.01
- 2008-01-18 0001193125-08-008849 — 8.01, 9.01
- 2008-01-17 0001193125-08-008120 — 2.02, 9.01
- 2007-12-21 0001193125-07-269469 — 2.05
- 2007-12-05 0001193125-07-259675 — 5.02
- 2007-10-17 0001193125-07-220376 — 8.01, 9.01
- 2007-10-16 0001193125-07-219386 — 2.02, 9.01
- 2007-09-18 0000950134-07-020112 — 5.02, 9.01
- 2007-08-29 0000950134-07-019145 — 1.01, 2.02, 9.01
- 2007-07-20 0001193125-07-159001 — 8.01, 9.01
- 2007-07-19 0001193125-07-158214 — 2.02, 9.01
- 2007-04-18 0001193125-07-083845 — 8.01, 9.01
- 2007-04-17 0001193125-07-082824 — 2.02, 9.01
- 2007-04-10 0001193125-07-077251 — 2.02, 9.01
- 2007-02-27 0001193125-07-040081 — 5.02, 7.01
- 2007-01-24 0001193125-07-011834 — 8.01, 9.01
- 2007-01-23 0001193125-07-010955 — 2.02, 9.01
- 2006-12-21 0001193125-06-257603 — 8.01, 9.01
- 2006-12-07 0001193125-06-247897 — 5.02
- 2006-11-07 0001193125-06-225545 — 2.02, 7.01, 8.01, 9.01
- 2006-11-01 0001193125-06-220706 — 1.01, 9.01
- 2006-10-25 0001193125-06-214798 — 8.01, 9.01
- 2006-10-24 0001193125-06-213813 — 2.02, 9.01
- 2006-10-11 0001193125-06-206304 — 5.02
- 2006-10-03 0001193125-06-201845 — 5.02, 9.01
- 2006-09-21 0001193125-06-194878 — 1.01, 1.02, 2.03, 2.04, 8.01, 9.01
- 2006-09-19 0001193125-06-192726 — 8.01, 9.01
- 2006-09-12 0001193125-06-189437 — 5.02, 8.01, 9.01
- 2006-08-24 0001193125-06-179258 — 1.01
- 2006-08-09 0001193125-06-167961 — 8.01, 9.01
- 2006-08-08 0001193125-06-165853 — 2.02, 9.01
- 2006-06-01 0001193125-06-122124 — 7.01, 9.01
- 2006-05-25 0001193125-06-119646 — 1.01, 2.01, 2.03, 5.02, 9.01
- 2006-05-17 0001193125-06-114760 — 8.01, 9.01
- 2006-05-04 0001193125-06-099262 — 8.01, 9.01
- 2006-05-03 0001193125-06-098229 — 5.05, 9.01
- 2006-04-27 0001193125-06-090749 — 8.01
- 2006-04-20 0001193125-06-084566 — 8.01, 9.01
- 2006-04-18 0001193125-06-082414 — 2.02, 9.01
- 2006-04-13 0001193125-06-079690 — 8.01
- 2006-04-03 0001193125-06-071956 — 8.01
- 2006-03-13 0001193125-06-051798 — 8.01
- 2006-02-14 0001193125-06-030829 — 8.01, 9.01
- 2006-01-26 0001193125-06-012909 — 8.01, 9.01
- 2006-01-25 0001193125-06-011608 — 8.01, 9.01
- 2006-01-19 0001193125-06-008770 — 8.01, 9.01
- 2006-01-18 0001193125-06-007939 — 2.02, 9.01
- 2005-12-22 0001193125-05-247782 — 1.01, 5.02, 9.01
- 2005-12-22 0001193125-05-247766 — 1.01, 9.01
- 2005-12-21 0001193125-05-246701 — 8.01, 9.01
- 2005-12-01 0001193125-05-234733 — 7.01
- 2005-11-23 0001193125-05-231674 — 1.01, 1.02, 7.01, 9.01
- 2005-10-19 0001193125-05-203955 — 2.02, 9.01
- 2005-10-18 0001193125-05-203356 — 2.02, 7.01, 9.01
- 2005-09-08 0001193125-05-181893 — 7.01, 9.01
- 2005-09-07 0001193125-05-181605 — 1.01
- 2005-08-04 0001193125-05-157913 — 8.01, 9.01
- 2005-08-03 0001193125-05-156407 — 1.01, 8.01, 9.01
- 2005-07-19 0001193125-05-144591 — 2.02, 9.01
- 2005-06-08 0001193125-05-121880 — 7.01
- 2005-05-17 0001193125-05-109518 — 7.01
- 2005-04-19 0001193125-05-079453 — 2.02, 9.01
- 2005-03-22 0001193125-05-057519 — 1.01
- 2005-03-16 0001193125-05-052560 — 7.01
- 2005-03-07 0001193125-05-043752 — 7.01, 9.01
- 2005-02-08 0001193125-05-022340 — 1.01, 7.01
- 2005-01-18 0001193125-05-007666 — 2.02, 9.01
- 2004-12-13 0001193125-04-211590 — 7.01, 8.01, 9.01
- 2004-12-07 0001193125-04-208768 — 7.01, 9.01
- 2004-10-29 0001193125-04-181463 — 1.01, 5.02, 9.01
- 2004-10-19 0001193125-04-173795 — 2.02, 9.01
- 2004-09-23 0001193125-04-160889 — 8.01, 9.01
- 2004-09-21 0001193125-04-159593 — 8.01, 9.01
- 2004-09-07 0001193125-04-152868 — 7.01, 9.01
- 2004-07-28 0001193125-04-126152 — 5, 7
- 2004-07-20 0001193125-04-121017 — 12, 7
- 2004-06-02 0001193125-04-097697 — 7, 9
- 2004-04-30 0001193125-04-075386 — 5, 7
- 2004-04-20 0001193125-04-065621 — 12, 7
- 2004-04-06 0001193125-04-057855 — 12, 7
- 2004-03-16 0001193125-04-042542 — 5
- 2004-03-03 0001193125-04-033653 — 7, 9
- 2004-01-21 0001193125-04-006388 — 12, 5, 7
- 2003-10-31 0001193125-03-070294 — 5, 7
- 2003-10-27 0001193125-03-067685 — 5, 7
- 2003-10-22 0001193125-03-065398 — 12, 5, 7
- 2003-07-16 0001193125-03-019880 — 7, 9
- 2003-07-10 0001193125-03-018043 — 5
- 2003-07-07 0001193125-03-016864 — 5
- 2003-06-27 0001193125-03-014262 — 5, 7
- 2003-04-16 0001012870-03-001799 — 7, 9

## late-filing notifications on or before 2020-02-05

- none on or before 2020-02-05

## item 2.02 — earnings release, exhibit 99.1

[0001137789-20-000013:8k_2_02:1]
EX-99.1
2
stxq220pressreleasefin.htm
EX-99.1

[0001137789-20-000013:8k_2_02:2]
Document

[0001137789-20-000013:8k_2_02:3]
Exhibit 99.1

[0001137789-20-000013:8k_2_02:4]
Investor Relations Contact:

[0001137789-20-000013:8k_2_02:5]
Shanye Hudson, (408) 658-1863

[0001137789-20-000013:8k_2_02:6]
shanye.hudson@seagate.com

[0001137789-20-000013:8k_2_02:7]
Media Contact:

[0001137789-20-000013:8k_2_02:8]
Gregory Belloni, (408) 658-1018

[0001137789-20-000013:8k_2_02:9]
gregory.belloni@seagate.com

[0001137789-20-000013:8k_2_02:10]
SEAGATE TECHNOLOGY REPORTS FISCAL SECOND QUARTER 2020 FINANCIAL RESULTS

[0001137789-20-000013:8k_2_02:11]
–Reported revenue of $2.7 billion

[0001137789-20-000013:8k_2_02:12]
–Expanded GAAP operating margin to 14.2%; non-GAAP operating margin to 15.7%

[0001137789-20-000013:8k_2_02:13]
–Delivered GAAP diluted earnings per share (EPS) of $1.20; non-GAAP diluted EPS of $1.35

[0001137789-20-000013:8k_2_02:14]
–Returned $315 million to shareholders; declared cash dividend of $0.65 per share

[0001137789-20-000013:8k_2_02:15]
CUPERTINO, CA - February 4, 2020 - Seagate Technology plc (NASDAQ: STX) (the “Company” or “Seagate”) today reported financial results for its fiscal second quarter ended January 3, 2020.

[0001137789-20-000013:8k_2_02:16]
“In the December quarter, Seagate expanded non-GAAP operating margin by nearly 300 basis points and delivered non-GAAP EPS growth of more than 30% quarter-over-quarter while driving strong operational cash flow in an improving demand environment,” said Dave Mosley, Seagate’s chief executive officer.

[0001137789-20-000013:8k_2_02:17]
“We executed the company's fastest ever product ramp with our industry capacity leading 16-terabyte drives, which contributed to both sequential revenue growth and record exabyte shipments in the December quarter. We are poised to benefit from ongoing demand for mass capacity storage which we expect to offset typical seasonal declines in the legacy markets in the first half of the calendar year.”

[0001137789-20-000013:8k_2_02:18]
Quarterly Financial Results

[0001137789-20-000013:8k_2_02:19]
|  | GAAP |  |  |  | Non-GAAP |  |  |  |  |
|  | FQ2 2020 |  | FQ2 2019 |  | FQ2 2020 |  | FQ2 2019 |  |  |
| Revenue ($M) | $ | 2,696 |  |  | $ | 2,715 |  |  | $ | 2,696 |  |  | $ | 2,715 |  |  |  |
| Gross Margin | 28.1 | % |  | 29.2 | % |  | 28.7 | % |  | 29.9 | % |  |  |
| Operating Margin | 14.2 | % |  | 15.3 | % |  | 15.7 | % |  | 17.2 | % |  |  |
| Net Income ($M) | $ | 318 |  |  | $ | 384 |  |  | $ | 359 |  |  | $ | 432 |  |  |  |
| Diluted Earnings Per Share | $ | 1.20 |  |  | $ | 1.34 |  |  | $ | 1.35 |  |  | $ | 1.51 |  |  |  |

[0001137789-20-000013:8k_2_02:20]
The Company generated $480 million in cash flow from operations and $286 million in free cash flow during the fiscal second quarter 2020. Seagate maintained a healthy balance sheet and during the fiscal second quarter 2020, the Company paid cash dividends of $165 million and repurchased 2.5 million ordinary shares for $150 million. Cash and cash equivalents totaled $1.7 billion at the end of the quarter. There were 261 million ordinary shares issued and outstanding as of the end of the quarter.

[0001137789-20-000013:8k_2_02:21]
All periods presented exclude share-based compensation from non-GAAP results. For a detailed reconciliation of GAAP to non-GAAP results, see accompanying financial tables.

[0001137789-20-000013:8k_2_02:22]
Seagate has issued a Supplemental Financial Information document, which is available on Seagate’s Investor Relations website at investors.seagate.com.

[0001137789-20-000013:8k_2_02:23]
Quarterly Cash Dividend

[0001137789-20-000013:8k_2_02:24]
The Board of Directors of the Company (the “Board”) declared a quarterly cash dividend of $0.65 per share, which will be payable on April 8, 2020 to shareholders of record as of the close of business on March 25, 2020. The payment of any future quarterly dividends will be at the discretion of the Board and will be dependent upon Seagate’s financial position, results of operations, available cash, cash flow, capital requirements and other factors deemed relevant by the Board.

[0001137789-20-000013:8k_2_02:25]
Business Outlook

[0001137789-20-000013:8k_2_02:26]
The Company is providing the following guidance for its fiscal third quarter 2020:

[0001137789-20-000013:8k_2_02:27]
•Revenue of $2.7 billion, plus or minus 7%

[0001137789-20-000013:8k_2_02:28]
•Non-GAAP diluted EPS of $1.35, plus or minus 7%

[0001137789-20-000013:8k_2_02:29]
Guidance regarding non-GAAP diluted EPS excludes known charges related to amortization of acquired intangible assets and estimated share-based compensation expenses of $0.05 per share and $0.11 per share, respectively.

[0001137789-20-000013:8k_2_02:30]
We have not reconciled our non-GAAP diluted EPS to the most directly comparable GAAP measure because material items that may impact these measures are out of our control and/or cannot be reasonably predicted including, but not limited to, accelerated depreciation, impairment, and other charges related to cost saving efforts, restructuring charges, strategic investment losses or impairment recognized, income tax adjustments on these measures, and other charges or benefits that may arise. The amounts of these measures are not currently available, but may be material to future results. A reconciliation of the non-GAAP diluted EPS to the corresponding GAAP measures is not available without unreasonable effort. A reconciliation of our historical non-GAAP financial measures to their nearest GAAP equivalent is contained in this release.

[0001137789-20-000013:8k_2_02:31]
Investor Communications

[0001137789-20-000013:8k_2_02:32]
Seagate management will hold a public webcast today at 2:00 p.m. Pacific / 5:00 p.m. Eastern that can be accessed on its Investor Relations website at investors.seagate.com.

[0001137789-20-000013:8k_2_02:33]
An archived audio webcast of this event will be available on Seagate’s Investor Relations website at investors.seagate.com shortly following the event conclusion.

[0001137789-20-000013:8k_2_02:34]
About Seagate

[0001137789-20-000013:8k_2_02:35]
Seagate crafts the datasphere, helping to maximize humanity’s potential by innovating world-class, precision-engineered data management solutions with a focus on sustainable partnerships. Learn more about Seagate by visiting www.seagate.com or following us on Twitter, Facebook, LinkedIn, YouTube, and subscribing to our blog.

[0001137789-20-000013:8k_2_02:36]
© 2020 Seagate Technology LLC. All rights reserved. Seagate, Seagate Technology, and the Spiral logo are registered trademarks of Seagate Technology LLC in the United States and/or other countries.

[0001137789-20-000013:8k_2_02:37]
Cautionary Note Regarding Forward-Looking Statements

[0001137789-20-000013:8k_2_02:38]
The inclusion of Seagate’s website addresses in this press release are intended to be inactive textual references only and not active hyperlinks. The information contained in, or that can be accessed through, Seagate’s websites and social media channels are not part of this press release.

[0001137789-20-000013:8k_2_02:39]
SEAGATE TECHNOLOGY PLC

[0001137789-20-000013:8k_2_02:40]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001137789-20-000013:8k_2_02:41]
(In millions)

[0001137789-20-000013:8k_2_02:42]
|  | January 3,2020 |  | June 28,2019 |
|  | (unaudited) |  |  |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,744 |  |  | $ | 2,220 |  |
| Accounts receivable, net | 1,112 |  |  | 989 |  |
| Inventories | 1,148 |  |  | 970 |  |
| Other current assets | 148 |  |  | 184 |  |
| Total current assets | 4,152 |  |  | 4,363 |  |
| Property, equipment and leasehold improvements, net | 2,049 |  |  | 1,869 |  |
| Goodwill | 1,237 |  |  | 1,237 |  |
| Other intangible assets, net | 83 |  |  | 111 |  |
| Deferred income taxes | 1,119 |  |  | 1,114 |  |
| Other assets, net | 292 |  |  | 191 |  |
| Total Assets | $ | 8,932 |  |  | $ | 8,885 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |
| Accounts payable | $ | 1,870 |  |  | $ | 1,420 |  |
| Accrued employee compensation | 191 |  |  | 169 |  |
| Accrued warranty | 80 |  |  | 91 |  |
| Current portion of long-term debt | 6 |  |  | — |  |
| Accrued expenses | 553 |  |  | 552 |  |
| Total current liabilities | 2,700 |  |  | 2,232 |  |
| Long-term accrued warranty | 89 |  |  | 104 |  |
| Long-term accrued income taxes | 3 |  |  | 4 |  |
| Other non-current liabilities | 175 |  |  | 130 |  |
| Long-term debt | 4,135 |  |  | 4,253 |  |
| Total Liabilities | 7,102 |  |  | 6,723 |  |
| Total Equity | 1,830 |  |  | 2,162 |  |
| Total Liabilities and Equity | $ | 8,932 |  |  | $ | 8,885 |  |

[0001137789-20-000013:8k_2_02:43]
SEAGATE TECHNOLOGY PLC

[0001137789-20-000013:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001137789-20-000013:8k_2_02:45]
(In millions, except per share data)

[0001137789-20-000013:8k_2_02:46]
(Unaudited)

[0001137789-20-000013:8k_2_02:47]
|  | For the Three Months Ended |  |  |  |  |  | For the Six Months Ended |  |  |
|  | January 3,2020 |  | October 4,2019 |  | December 28,2018 |  | January 3,2020 |  | December 28,2018 |
| Revenue | $ | 2,696 |  |  | $ | 2,578 |  |  | $ | 2,715 |  |  | $ | 5,274 |  |  | $ | 5,706 |  |
| Cost of revenue | 1,938 |  |  | 1,907 |  |  | 1,921 |  |  | 3,845 |  |  | 3,999 |  |
| Product development | 250 |  |  | 255 |  |  | 246 |  |  | 505 |  |  | 512 |  |
| Marketing and administrative | 120 |  |  | 122 |  |  | 120 |  |  | 242 |  |  | 235 |  |
| Amortization of intangibles | 4 |  |  | 4 |  |  | 5 |  |  | 8 |  |  | 11 |  |
| Restructuring and other, net | — |  |  | 17 |  |  | 7 |  |  | 17 |  |  | 30 |  |
| Total operating expenses | 2,312 |  |  | 2,305 |  |  | 2,299 |  |  | 4,617 |  |  | 4,787 |  |
| Income from operations | 384 |  |  | 273 |  |  | 416 |  |  | 657 |  |  | 919 |  |
| Interest income | 4 |  |  | 11 |  |  | 22 |  |  | 15 |  |  | 46 |  |
| Interest expense | (48) |  |  | (55) |  |  | (56) |  |  | (103) |  |  | (114) |  |
| Other, net | (4) |  |  | (31) |  |  | 16 |  |  | (35) |  |  | 15 |  |
| Other expense, net | (48) |  |  | (75) |  |  | (18) |  |  | (123) |  |  | (53) |  |
| Income before income taxes | 336 |  |  | 198 |  |  | 398 |  |  | 534 |  |  | 866 |  |
| Provision (benefit) for income taxes | 18 |  |  | (2) |  |  | 14 |  |  | 16 |  |  | 32 |  |
| Net income | $ | 318 |  |  | $ | 200 |  |  | $ | 384 |  |  | $ | 518 |  |  | $ | 834 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | 1.21 |  |  | $ | 0.75 |  |  | $ | 1.35 |  |  | $ | 1.96 |  |  | $ | 2.92 |  |
| Diluted | 1.20 |  |  | 0.74 |  |  | 1.34 |  |  | 1.93 |  |  | 2.88 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |  |
| Basic | 262 |  |  | 266 |  |  | 285 |  |  | 264 |  |  | 286 |  |
| Diluted | 265 |  |  | 270 |  |  | 287 |  |  | 268 |  |  | 290 |  |
| Cash dividends declared per ordinary share | $ | 0.65 |  |  | $ | 0.63 |  |  | $ | 0.63 |  |  | $ | 1.28 |  |  | $ | 1.26 |  |

[0001137789-20-000013:8k_2_02:48]
SEAGATE TECHNOLOGY PLC

[0001137789-20-000013:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001137789-20-000013:8k_2_02:50]
(In millions)

[0001137789-20-000013:8k_2_02:51]
(Unaudited)

[0001137789-20-000013:8k_2_02:52]
|  | For the Six Months Ended |  |  |  |
|  | January 3,2020 |  | December 28,2018 |
| OPERATING ACTIVITIES |  |  |  |
| Net income | $ | 518 |  |  | $ | 834 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 185 |  |  | 272 |  |
| Share-based compensation | 53 |  |  | 45 |  |
| Deferred income taxes | (4) |  |  | 1 |  |
| Other non-cash operating activities, net | 47 |  |  | (44) |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (124) |  |  | 135 |  |
| Inventories | (172) |  |  | (47) |  |
| Accounts payable | 458 |  |  | (240) |  |
| Accrued employee compensation | 22 |  |  | (89) |  |
| Accrued expenses, income taxes and warranty | (38) |  |  | (16) |  |
| Other assets and liabilities | (9) |  |  | 24 |  |
| Net cash provided by operating activities | 936 |  |  | 875 |  |
| INVESTING ACTIVITIES |  |  |  |
| Acquisition of property, equipment and leasehold improvements | (341) |  |  | (304) |  |
| Proceeds from settlement of foreign currency forward exchange contracts | — |  |  | 66 |  |
| Proceeds from sale of strategic investments | — |  |  | 10 |  |
| Proceeds from the sale of assets | 1 |  |  | 6 |  |
| Purchases of investments | (45) |  |  | (8) |  |
| Net cash used in investing activities | (385) |  |  | (230) |  |
| FINANCING ACTIVITIES |  |  |  |
| Redemption and repurchase of debt | (645) |  |  | (499) |  |
| Dividends to shareholders | (335) |  |  | (361) |  |
| Repurchases of ordinary shares | (600) |  |  | (286) |  |
| Taxes paid related to net share settlement of equity awards | (39) |  |  | (30) |  |
| Net proceeds from issuance of long-term debt | 498 |  |  | — |  |
| Proceeds from issuance of ordinary shares under employee stock plans | 69 |  |  | 35 |  |
| Other financing activities, net | (2) |  |  | — |  |
| Net cash used in financing activities | (1,054) |  |  | (1,141) |  |
| Effect of foreign currency exchange rate changes on cash, cash equivalents and restricted cash | (2) |  |  | (1) |  |
| Decrease in cash, cash equivalents and restricted cash | (505) |  |  | (497) |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 2,251 |  |  | 1,857 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 1,746 |  |  | $ | 1,360 |  |

[0001137789-20-000013:8k_2_02:53]
Use of non-GAAP financial information

[0001137789-20-000013:8k_2_02:54]
The Company uses non-GAAP measures of adjusted revenue, gross margin, gross margin as a percentage of revenue, operating expenses, income from operations, operating margin as a percentage of revenue, net income, diluted EPS, and free cash flow, which are adjusted from results based on GAAP to exclude certain benefits, expenses, gains and losses. These non-GAAP financial measures may be provided to enhance the user’s overall understanding of the Company’s current financial performance and its prospects for the future. Specifically, the Company believes non-GAAP results provide useful information to both management and investors as these non-GAAP results exclude certain benefits, expenses, gains and losses that it believes are not indicative of its core operating results and because it is similar to the approach used in connection with the financial models and estimates published by financial analysts who follow the Company. Free cash flow does not reflect all of the Company's expenses and non-cash items, and does not reflect the Company's uses of cash in financing and investing activities.

[0001137789-20-000013:8k_2_02:55]
These non-GAAP results are some of the measurements management uses to assess the Company’s performance, allocate resources and plan for future periods. Reported non-GAAP results should only be considered as supplemental to results prepared in accordance with GAAP, and not considered as a substitute or replacement for, or superior to, GAAP results. These non-GAAP measures may differ from the non-GAAP measures reported by other companies in its industry.

[0001137789-20-000013:8k_2_02:56]
SEAGATE TECHNOLOGY PLC

[0001137789-20-000013:8k_2_02:57]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001137789-20-000013:8k_2_02:58]
(In millions, except per share amounts and gross margin)

[0001137789-20-000013:8k_2_02:59]
(Unaudited)

[0001137789-20-000013:8k_2_02:60]
|  | For the Three Months Ended |  |  |  |  |  | For the Six Months Ended |  |  |
|  | January 3,2020 |  | October 4,2019 |  | December 28, 2018 (a) |  | January 3,2020 |  | December 28, 2018 (a) |
| GAAP Revenue | $ | 2,696 |  |  | $ | 2,578 |  |  | $ | 2,715 |  |  | $ | 5,274 |  |  |  | $ | 5,706 |  |
| Adjustment to discontinued products | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Non-GAAP Revenue | $ | 2,696 |  |  | $ | 2,578 |  |  | $ | 2,715 |  |  | $ | 5,274 |  |  | $ | 5,707 |  |
| GAAP Gross Margin | $ | 758 |  |  | $ | 671 |  |  | $ | 794 |  |  | $ | 1,429 |  |  |  | $ | 1,707 |  |
| Adjustment to discontinued products | — |  |  | — |  |  | — |  |  | — |  |  |  | 1 |  |
| Amortization of acquired intangible assets | 10 |  |  | 10 |  |  | 13 |  |  | 20 |  |  |  | 26 |  |
| Share-based compensation | 6 |  |  | 7 |  |  | 6 |  |  |  | 13 |  |  |  | 11 |  |
| Restructuring and other, net | — |  |  | — |  |  | (1) |  |  | — |  |  |  | (1) |  |
| Non-GAAP Gross Margin | $ | 774 |  |  | $ | 688 |  |  | $ | 812 |  |  | $ | 1,462 |  |  |  | $ | 1,744 |  |
| GAAP Gross Margin | 28.1 | % |  | 26.0 | % |  | 29.2 | % |  | 27.1 | % |  |  | 29.9 | % |
| Non-GAAP Gross Margin | 28.7 | % |  | 26.7 | % |  | 29.9 | % |  | 27.7 | % |  |  | 30.6 | % |
| GAAP Operating Expenses | $ | 374 |  |  | $ | 398 |  |  | $ | 378 |  |  |  | $ | 772 |  |  | $ | 788 |  |
| Accelerated depreciation, impairment and other charges related to cost saving efforts | — |  |  | — |  |  | (1) |  |  |  | — |  |  | (2) |  |
| Amortization of acquired intangible assets | (3) |  |  | (3) |  |  | (5) |  |  |  | (6) |  |  | (9) |  |
| Restructuring and other, net | — |  |  | (17) |  |  | (7) |  |  |  | (17) |  |  | (30) |  |
| Share-based compensation | (21) |  |  | (19) |  |  | (21) |  |  | (40) |  |  |  | (34) |  |
| Non-GAAP Operating Expenses | $ | 350 |  |  | $ | 359 |  |  | $ | 344 |  |  | $ | 709 |  |  |  | $ | 713 |  |
| GAAP Income From Operations | $ | 384 |  |  | $ | 273 |  |  | $ | 416 |  |  |  | $ | 657 |  |  |  | $ | 919 |  |
| Adjustment to discontinued products | — |  |  | — |  |  | — |  |  |  | — |  |  |  | 1 |  |
| Accelerated depreciation, impairment and other charges related to cost saving efforts | — |  |  | — |  |  | 1 |  |  |  | — |  |  |  | 2 |  |
| Amortization of acquired intangible assets | 13 |  |  | 13 |  |  | 18 |  |  |  | 26 |  |  |  | 35 |  |
| Restructuring and other, net | — |  |  | 17 |  |  | 7 |  |  |  | 17 |  |  |  | 30 |  |
| Share-based compensation | 27 |  |  | 26 |  |  | 27 |  |  |  | 53 |  |  |  | 45 |  |
| Other charges | — |  |  | — |  |  | (1) |  |  |  | — |  |  |  | (1) |  |
| Non-GAAP Income From Operations | $ | 424 |  |  | $ | 329 |  |  | $ | 468 |  |  |  | $ | 753 |  |  |  | $ | 1,031 |  |
| GAAP Operating Margin | 14.2 | % |  |  | 10.6 | % |  |  | 15.3 | % |  |  | 12.5 | % |  |  | 16.1 | % |
| Non-GAAP Operating Margin | 15.7 | % |  |  | 12.8 | % |  |  | 17.2 | % |  |  | 14.3 | % |  |  | 18.1 | % |

[0001137789-20-000013:8k_2_02:61]
SEAGATE TECHNOLOGY PLC

[0001137789-20-000013:8k_2_02:62]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001137789-20-000013:8k_2_02:63]
(In millions, except per share amounts and gross margin)

[0001137789-20-000013:8k_2_02:64]
(Unaudited)

[0001137789-20-000013:8k_2_02:65]
|  | For the Three Months Ended |  |  |  |  |  | For the Six Months Ended |  |  |
|  | January 3,2020 |  | October 4,2019 |  | December 28, 2018 (a) |  | January 3,2020 |  | December 28, 2018 (a) |
| GAAP Net Income | $ | 318 |  |  | $ | 200 |  |  | $ | 384 |  |  | $ | 518 |  |  |  | $ | 834 |  |
| Adjustment to discontinued products | — |  |  | — |  |  | — |  |  | — |  |  |  | 1 |  |
| Accelerated depreciation, impairment and other charges related to cost saving efforts | — |  |  | — |  |  | 1 |  |  | — |  |  |  | 2 |  |
| Amortization of acquired intangible assets | 13 |  |  | 13 |  |  | 18 |  |  | 26 |  |  |  | 35 |  |
| Restructuring and other, net | — |  |  | 17 |  |  | 7 |  |  | 17 |  |  |  | 30 |  |
| Losses recognized on the early redemption and repurchase of debt | — |  |  | 30 |  |  | — |  |  | 30 |  |  |  | — |  |
| Strategic investment losses (gains) or impairment recognized | 1 |  |  | — |  |  | (2) |  |  | 1 |  |  |  | 2 |  |
| Share-based compensation | 27 |  |  | 26 |  |  | 27 |  |  | 53 |  |  |  | 45 |  |
| Other charges | — |  |  | — |  |  | (1) |  |  | — |  |  |  | (1) |  |
| Income tax adjustments | — |  |  | (8) |  |  | (2) |  |  | (8) |  |  |  | (2) |  |
| Non-GAAP Net Income | $ | 359 |  |  | $ | 278 |  |  | $ | 432 |  |  | $ | 637 |  |  | $ | 946 |  |
| Shares used in diluted net income per share calculation | 265 |  |  | 270 |  |  | 287 |  |  | 268 |  |  |  | 290 |  |
| GAAP Diluted Net Income Per Share | $ | 1.20 |  |  | $ | 0.74 |  |  | $ | 1.34 |  |  | $ | 1.93 |  |  |  | $ | 2.88 |  |
| Non-GAAP Diluted Net Income Per Share | 1.35 |  |  |  | 1.03 |  |  |  | 1.51 |  |  |  | 2.38 |  |  |  | 3.26 |  |
| GAAP Net Cash Provided by Operating Activities | $ | 480 |  |  | $ | 456 |  |  | $ | 288 |  |  |  | $ | 936 |  |  | $ | 875 |  |
| Acquisition of property, equipment and leasehold improvements | 194 |  |  | 147 |  |  | 127 |  |  |  | 341 |  |  | 304 |  |
| Free Cash Flow | $ | 286 |  |  | $ | 309 |  |  | $ | 161 |  |  |  | $ | 595 |  |  | $ | 571 |  |

[0001137789-20-000013:8k_2_02:66]
(a) In the fiscal first quarter of 2020, the Company began excluding share-based compensation from non-GAAP results. To provide improved visibility and comparability, the Company has reflected this change to its non-GAAP results retrospectively to the earliest date presented.

[0001137789-20-000013:8k_2_02:67]
The Company’s Non-GAAP measures are adjusted for the following items:

[0001137789-20-000013:8k_2_02:68]
Adjustment to discontinued products

[0001137789-20-000013:8k_2_02:69]
These adjustments relate to sales of certain discontinued products or changes in sales provision for discontinued products. These adjustments are inconsistent in amount and frequency and are excluded in the non-GAAP measures as these adjustments are not indicative of the underlying ongoing operating performance.

[0001137789-20-000013:8k_2_02:70]
Accelerated depreciation, impairment and other charges related to cost saving efforts

[0001137789-20-000013:8k_2_02:71]
These expenses are excluded in the non-GAAP measures due to the inconsistency in amount and frequency and are excluded to facilitate a more meaningful evaluation of the Company’s current operating performance and comparison to its past periods’ operating performance.

[0001137789-20-000013:8k_2_02:72]
Amortization of acquired intangible assets

[0001137789-20-000013:8k_2_02:73]
The Company records expense from amortization of intangible assets that were acquired in connection with its business combinations over their estimated useful lives. Such charges are inconsistent in size and are significantly impacted by the timing and magnitude of the Company’s acquisitions. Consequently, these expenses are excluded in the non-GAAP measures to facilitate a more meaningful evaluation of its current operating performance and comparison to its past periods’ operating performance.

[0001137789-20-000013:8k_2_02:74]
Share-based compensation

[0001137789-20-000013:8k_2_02:75]
As disclosed in the Company’s fiscal fourth quarter 2019 earnings release, share-based compensation expense is excluded from its non-GAAP results. These expenses consist primarily of expenses for employee share-based compensation. Given the variety of equity awards used by companies, the varying methodologies for determining share-based compensation expense, the subjective assumptions involved in those determinations, and the volatility in valuations that can be driven by market conditions outside the Company’s control, the Company believes excluding share-based compensation expense enhances the ability of management and investors to understand and assess the underlying performance of its business over time and compare it against the Company’s peers, a majority of whom also exclude share-based compensation expense from their non-GAAP results.

[0001137789-20-000013:8k_2_02:76]
Other charges

[0001137789-20-000013:8k_2_02:77]
The other charges primarily include write-offs of certain discontinued inventory and expense related to disposed business. These charges are inconsistent in amount and frequency and are excluded in the non-GAAP measures to facilitate a more meaningful evaluation of its current operating performance and comparison to its past periods’ operating performance.

[0001137789-20-000013:8k_2_02:78]
Restructuring and other, net

[0001137789-20-000013:8k_2_02:79]
Restructuring and other, net are costs associated with restructuring plans that are primarily related to costs associated with reduction in the Company’s workforce, exiting certain facilities and other related costs. These also exclude charges or gains from sale of properties. These costs or benefits do not reflect the Company’s ongoing operating performance and consequently are excluded from the non-GAAP measures to facilitate a more meaningful evaluation of its current operating performance and comparison to its past periods’ operating performance.

[0001137789-20-000013:8k_2_02:80]
Losses recognized on the early redemption and repurchase of debt

[0001137789-20-000013:8k_2_02:81]
From time to time, the Company incurs losses from the early redemption and repurchase of certain long-term debt instruments. These losses represent the difference between the reacquisition costs and the par value of the debt extinguished and include the write off of any related unamortized debt issuance costs. The amount of these charges may be inconsistent in size and varies depending on the timing of the repurchase of debt.

[0001137789-20-000013:8k_2_02:82]
Strategic investment losses (gains) or impairment recognized

[0001137789-20-000013:8k_2_02:83]
From time to time, the Company incurs losses or gains from strategic investments accounted for under the equity method of accounting or records impairment charges which are not considered as part of its ongoing operating performance. The resulting expense or gain is inconsistent in amount and frequency and consequently is excluded from the non-GAAP measures to facilitate a more meaningful evaluation of its current operating performance and comparison to its past periods’ operating performance.

[0001137789-20-000013:8k_2_02:84]
Income tax adjustments

[0001137789-20-000013:8k_2_02:85]
Provision or benefit for income taxes represents the tax effects of non-GAAP adjustments determined using a hybrid with and without method and effective tax rate for the applicable adjustment and jurisdiction.

[0001137789-20-000013:8k_2_02:86]
Free cash flow

[0001137789-20-000013:8k_2_02:87]
Free cash flow is a non-GAAP measure defined as net cash provided by operating activities less acquisition of property, equipment and leasehold improvements. This non-GAAP financial measure is used by management to assess the Company's sources of liquidity, capital structure and operating performance.
