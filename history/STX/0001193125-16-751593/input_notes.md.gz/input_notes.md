# STX notes — 0001193125-16-751593


## invest:InvestmentTableTextBlock

[0001193125-16-751593:notes:1]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of July 1, 2016:

[0001193125-16-751593:notes:2]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 318 |  |  | $ | — |  |  | $ | 318 |  |
| Certificates of deposit |  | 444 |  |  | — |  |  | 444 |  |
| Corporate bonds |  | 6 |  |  | — |  |  | 6 |  |
| Total |  | $ | 768 |  |  | $ | — |  |  | $ | 768 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 755 |  |
| Included in Short-term investments |  |  |  |  |  |  |  | 6 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 7 |  |
| Total |  |  |  |  |  |  |  | $ | 768 |  |

[0001193125-16-751593:notes:3]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of September 30, 2016:

[0001193125-16-751593:notes:4]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 534 |  |  | $ | — |  |  | $ | 534 |  |
| Certificates of deposit |  | 550 |  |  | — |  |  | 550 |  |
| Corporate bonds |  | 5 |  |  | — |  |  | 5 |  |
| Total |  | $ | 1,089 |  |  | $ | — |  |  | $ | 1,089 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 1,078 |  |
| Included in Short-term investments |  |  |  |  |  |  |  | 5 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 6 |  |
| Total |  |  |  |  |  |  |  | $ | 1,089 |  |


## stx:ScheduleOfShareRepurchasesTableTextBlock

[0001193125-16-751593:notes:5]
The following table sets forth information with respect to repurchases of the Company’s shares during the three months ended September 30, 2016:

[0001193125-16-751593:notes:6]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Repurchases of Ordinary Shares |  | 3 |  |  | $ | 101 |  |
| Tax Withholding Related to Vesting of Equity Awards |  | 1 |  |  | 23 |  |
| Total |  | 4 |  |  | $ | 124 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-16-751593:notes:7]
[same as prior period, unchanged from 0001104659-16-116201:notes:7]

[0001193125-16-751593:notes:8]
[same as prior period, unchanged from 0001104659-16-116201:notes:8]

[0001193125-16-751593:notes:9]
[same as prior period, unchanged from 0001104659-16-116201:notes:9]

[0001193125-16-751593:notes:10]
[same as prior period, unchanged from 0001104659-16-116201:notes:10]

[0001193125-16-751593:notes:11]
[same as prior period, unchanged from 0001104659-16-116201:notes:11]

[0001193125-16-751593:notes:12]
[same as prior period, unchanged from 0001104659-16-116201:notes:12]

[0001193125-16-751593:notes:13]
[same as prior period, unchanged from 0001104659-16-116201:notes:13]

[0001193125-16-751593:notes:14]
[same as prior period, unchanged from 0001104659-16-116201:notes:14]

[0001193125-16-751593:notes:15]
[same as prior period, unchanged from 0001104659-16-116201:notes:17]

[0001193125-16-751593:notes:16]
[same as prior period, unchanged from 0001104659-16-116201:notes:18]

[0001193125-16-751593:notes:17]
[same as prior period, unchanged from 0001104659-16-116201:notes:19]

[0001193125-16-751593:notes:18]
[same as prior period, unchanged from 0001104659-16-116201:notes:20]

[0001193125-16-751593:notes:19]
[same as prior period, unchanged from 0001104659-16-116201:notes:21]

[0001193125-16-751593:notes:20]
[same as prior period, unchanged from 0001104659-16-116201:notes:22]


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-16-751593:notes:21]
[same as prior period, unchanged from 0001104659-16-116201:notes:30]

[0001193125-16-751593:notes:22]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income, cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature. Certain prior period amounts in the condensed consolidated financial statements and notes to the condensed consolidated financial statements have been reclassified to conform to the current period’s presentation.

[0001193125-16-751593:notes:23]
The Company’s Consolidated Financial Statements for the fiscal year ended July 1, 2016, are included in its Annual Report on Form 10-K as filed with the United States Securities and Exchange Commission (“SEC”) on August 5, 2016. The Company believes that the disclosures included in the unaudited condensed consolidated financial statements, when read in conjunction with its Consolidated Financial Statements as of July 1, 2016, and the notes thereto, are adequate to make the information presented not misleading.


## us-gaap:DebtDisclosureTextBlock

[0001193125-16-751593:notes:24]
Debt

[0001193125-16-751593:notes:25]
Short-Term Borrowings

[0001193125-16-751593:notes:26]
The credit agreement entered into by the Company and its subsidiary Seagate HDD Cayman on January 18, 2011 and subsequently amended (the "Revolving Credit Facility") provides the Company with a $700 million senior secured revolving credit facility. The term of the Revolving Credit Facility is through January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Revolving Credit Facility) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. The loans made under the Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing, and for the issuance of letters of credit up to a sub-limit of $75 million.

[0001193125-16-751593:notes:27]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio.  On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to allow for higher net leverage levels. The Company was in compliance with the modified covenants as of September 30, 2016 and expects to be in compliance for the next 12 months.

[0001193125-16-751593:notes:28]
As of September 30, 2016, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

[0001193125-16-751593:notes:29]
Long-Term Debt

[0001193125-16-751593:notes:30]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-16-751593:notes:31]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman, and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-16-751593:notes:32]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-16-751593:notes:33]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-16-751593:notes:34]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-16-751593:notes:35]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-16-751593:notes:36]
At September 30, 2016, future principal payments on long-term debt were as follows (in millions):

[0001193125-16-751593:notes:37]
| Fiscal Year | Amount |
| Remainder of 2017 | $ | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| 2020 | — |  |
| 2021 | — |  |
| Thereafter | 3,333 |  |
|  | $ | 4,133 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-16-751593:notes:38]
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity price risks relating to its ongoing business operations.  The Company enters into foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses denominated in foreign currencies and to mitigate the remeasurement risk of certain foreign currency denominated liabilities. The Company's accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments.  The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value.  The changes in the fair value of the effective portions of designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings.  Derivatives that are not designated as hedging instruments and the ineffective portions of cash flow hedges are adjusted to fair value through earnings. The amounts of net unrealized loss on cash flow hedges were $2 million and $2 million, respectively as of September 30, 2016 and July 1, 2016.

[0001193125-16-751593:notes:39]
The Company dedesignates its cash flow hedges when the forecasted hedged transactions are realized or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive income are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company did not recognize any net gains or losses related to the loss of hedge designation on discontinued cash flow hedges during the three months ended September 30, 2016. As of September 30, 2016, the Company’s existing foreign currency forward exchange contracts mature within 12 months. The deferred amount currently recorded in Accumulated other comprehensive loss expected to be recognized into earnings over the next 12 months is immaterial.

[0001193125-16-751593:notes:40]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of September 30, 2016 and July 1, 2016:

[0001193125-16-751593:notes:41]
|  |  | As of September 30, 2016 |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| British Pound Sterling |  | $ | 46 |  |  | $ | 10 |  |

[0001193125-16-751593:notes:42]
|  |  | As of July 1, 2016 |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| British Pound Sterling |  | $ | 47 |  |  | $ | 10 |  |

[0001193125-16-751593:notes:43]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plan—the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees. As of September 30, 2016, the notional investments underlying the TRS amounted to $99 million. The original contract term of the TRS was through January 2016, and was settled on a monthly basis, therefore limiting counterparty performance risk. The Company renewed the contract term through January 2017 under materially the same terms. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001193125-16-751593:notes:44]
The following tables show the Company’s derivative instruments measured at fair value as reflected in the Condensed Consolidated Balance Sheet as of September 30, 2016 and July 1, 2016:

[0001193125-16-751593:notes:45]
|  |  | As of September 30, 2016 |
|  |  | Asset Derivatives |  | Liability Derivatives |
| (Dollars in millions) |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (2 | ) |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | — |  |  | Accrued expenses |  | (1 | ) |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | — |  |  |  |  | $ | (3 | ) |

[0001193125-16-751593:notes:46]
|  |  | As of July 1, 2016 |
|  |  | Asset Derivatives |  | Liability Derivatives |
| (Dollars in millions) |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (2 | ) |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | — |  |  | Accrued expenses |  | (1 | ) |
| Total return swap |  | Other current assets |  | 3 |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 3 |  |  |  |  | $ | (3 | ) |

[0001193125-16-751593:notes:47]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statement of Comprehensive Income and the Condensed Consolidated Statement of Operations for the three months ended September 30, 2016:

[0001193125-16-751593:notes:48]
[same as prior period, unchanged from 0001104659-16-116201:notes:57]

[0001193125-16-751593:notes:49]
| Derivatives Designated as Hedging Instruments |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
| Foreign currency forward exchange contracts |  | $ | (1 | ) |  | Cost of revenue |  | $ | (1 | ) |  | Cost of revenue |  | $ | — |  |

[0001193125-16-751593:notes:50]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivative |  | Amount of Gain or(Loss) Recognized inIncome on Derivative |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (1 | ) |
| Total return swap |  | Operating expenses |  | 3 |  |

[0001193125-16-751593:notes:51]
[same as prior period, unchanged from 0001104659-16-116201:notes:60]

[0001193125-16-751593:notes:52]
| (a) | The amount of gain or (loss) recognized in income represents $0 related to the ineffective portion of the hedging relationships and $0 related to the amount excluded from the assessment of hedge effectiveness for the three months ended September 30, 2016, respectively. |

[0001193125-16-751593:notes:53]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statement of Comprehensive Income (Loss) and the Condensed Consolidated Statement of Operations for the three months ended October 2, 2015:

[0001193125-16-751593:notes:54]
[same as prior period, unchanged from 0001104659-16-116201:notes:63]

[0001193125-16-751593:notes:55]
| Derivatives Designated as Hedging Instruments |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
| Foreign currency forward exchange contracts |  | $ | (2 | ) |  | Cost of revenue |  | $ | (1 | ) |  | Cost of revenue |  | $ | — |  |

[0001193125-16-751593:notes:56]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (5 | ) |
| Total return swap |  | Operating expenses |  | (5 | ) |

[0001193125-16-751593:notes:57]
| (a) | The amount of gain or (loss) recognized in income represents $0 related to the ineffective portion of the hedging relationships and $0 related to the amount excluded from the assessment of hedge effectiveness for the three months ended October 2, 2015, respectively. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-16-751593:notes:58]
[same as prior period, unchanged from 0001104659-16-116201:notes:67]

[0001193125-16-751593:notes:59]
The Company recorded approximately $40 million and $33 million share-based compensation expense during the three months ended September 30, 2016 and October 2, 2015, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001193125-16-751593:notes:60]
[same as prior period, unchanged from 0001104659-16-116201:notes:69]

[0001193125-16-751593:notes:61]
[same as prior period, unchanged from 0001104659-16-116201:notes:70]

[0001193125-16-751593:notes:62]
|  |  | For the Three Months Ended |
| (In millions, except per share data) |  | September 30, 2016 |  | October 2, 2015 |
| Numerator: |  |  |  |  |  |  |
| Net income |  | $ | 167 |  |  | $ | 34 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 299 |  |  | 302 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |
| Employee equity award plans |  | 2 |  |  | 6 |  |
| Total shares for purpose of calculating diluted net income per share |  | 301 |  |  | 308 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 0.56 |  |  | $ | 0.11 |  |
| Diluted |  | $ | 0.55 |  |  | $ | 0.11 |  |

[0001193125-16-751593:notes:63]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income (loss) were 3 million for the three months ended September 30, 2016 and immaterial for the three months ended October 2, 2015.


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001193125-16-751593:notes:64]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 532 |  |  | $ | 546 |  |  | $ | — |  |  | $ | 1,078 |  |
| Short-term investments | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Other current assets | 2 |  |  | 4 |  |  | — |  |  | 6 |  |
| Total assets | $ | 534 |  |  | $ | 555 |  |  | $ | — |  |  | $ | 1,089 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued expenses | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |
| Total liabilities | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |

[0001193125-16-751593:notes:65]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 316 |  |  | $ | 439 |  |  | $ | — |  |  | $ | 755 |  |
| Short-term investments | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Other current assets | 2 |  |  | 8 |  |  | — |  |  | 10 |  |
| Total assets | $ | 318 |  |  | $ | 453 |  |  | $ | — |  |  | $ | 771 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued expenses | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |
| Total liabilities | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-16-751593:notes:66]
[same as prior period, unchanged from 0001104659-16-116201:notes:75]

[0001193125-16-751593:notes:67]
[same as prior period, unchanged from 0001104659-16-116201:notes:76]

[0001193125-16-751593:notes:68]
[same as prior period, unchanged from 0001104659-16-116201:notes:77]

[0001193125-16-751593:notes:69]
[same as prior period, unchanged from 0001104659-16-116201:notes:78]

[0001193125-16-751593:notes:70]
[same as prior period, unchanged from 0001104659-16-116201:notes:79]

[0001193125-16-751593:notes:71]
[same as prior period, unchanged from 0001104659-16-116201:notes:80]

[0001193125-16-751593:notes:72]
[same as prior period, unchanged from 0001104659-16-116201:notes:81]

[0001193125-16-751593:notes:73]
[same as prior period, unchanged from 0001104659-16-116201:notes:82]

[0001193125-16-751593:notes:74]
[same as prior period, unchanged from 0001104659-16-116201:notes:83]

[0001193125-16-751593:notes:75]
[same as prior period, unchanged from 0001104659-16-116201:notes:84]

[0001193125-16-751593:notes:76]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of September 30, 2016:

[0001193125-16-751593:notes:77]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 532 |  |  | $ | — |  |  | $ | — |  |  | $ | 532 |  |
| Certificates of deposit | — |  |  | 546 |  |  | — |  |  | 546 |  |
| Corporate bonds | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Total cash equivalents and short-term investments | 532 |  |  | 551 |  |  | — |  |  | 1,083 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |
| Money market funds | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Certificates of deposit | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Derivative assets | — |  |  | — |  |  | — |  |  | — |  |
| Total assets | $ | 534 |  |  | $ | 555 |  |  | $ | — |  |  | $ | 1,089 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |
| Total liabilities | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |

[0001193125-16-751593:notes:78]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of July 1, 2016:

[0001193125-16-751593:notes:79]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 316 |  |  | $ | — |  |  | $ | — |  |  | $ | 316 |  |
| Certificates of deposit | — |  |  | 439 |  |  | — |  |  | 439 |  |
| Corporate bonds | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total cash equivalents and short-term investments | 316 |  |  | 445 |  |  | — |  |  | 761 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |
| Money market funds | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Certificates of deposit | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Derivative assets | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets | $ | 318 |  |  | $ | 453 |  |  | $ | — |  |  | $ | 771 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |
| Total liabilities | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |

[0001193125-16-751593:notes:80]
[same as prior period, unchanged from 0001104659-16-116201:notes:89]

[0001193125-16-751593:notes:81]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs.  The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities.  Level 2 assets include:  agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries and certificates of deposits. These debt investments are priced using observable inputs and valuation models which vary by asset class.  The Company uses a pricing service to assist in determining the fair values of all of its cash equivalents and short-term investments.  For the cash equivalents and short-term investments in the Company's portfolio, multiple pricing sources are generally available.  The pricing service uses inputs from multiple industry standard data providers or other third party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date.  The Company corroborates the prices obtained from the pricing service against other independent sources and, as of September 30, 2016, has not found it necessary to make any adjustments to the prices obtained.  The Company's derivative financial instruments are also classified within Level 2.  The Company's derivative financial instruments consist of foreign currency forward exchange contracts and the TRS.  The Company recognizes derivative financial instruments in its consolidated financial statements at fair value.  The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001193125-16-751593:notes:82]
As of September 30, 2016 and July 1, 2016, the Company had no Level 3 assets or liabilities measured at fair value on a recurring basis.

[0001193125-16-751593:notes:83]
[same as prior period, unchanged from 0001104659-16-116201:notes:92]

[0001193125-16-751593:notes:84]
The Company enters into certain strategic investments for the promotion of business and strategic objectives. Strategic investments in equity securities where the Company does not have the ability to exercise significant influence over the investees, included in Other assets, net in the Condensed Consolidated Balance Sheets, are recorded at cost and are periodically analyzed to determine whether or not there are indicators of impairment. The carrying value of the Company’s strategic investments at September 30, 2016 and July 1, 2016 totaled $114 million and $113 million, respectively, and consisted primarily of privately held equity securities without a readily determinable fair value.

[0001193125-16-751593:notes:85]
For the three months ended October 2, 2015, the Company determined that a certain equity investment accounted for under the cost method was other-than-temporarily impaired, and recognized a charge of $10 million in order to write down the carrying amount of the investments to zero. This amount was recorded in Other, net in the Condensed Consolidated Statement of Operations. The Company did not record any impairment charges in the three months ended September 30, 2016.

[0001193125-16-751593:notes:86]
[same as prior period, unchanged from 0001104659-16-116201:notes:95]

[0001193125-16-751593:notes:87]
[same as prior period, unchanged from 0001104659-16-116201:notes:96]

[0001193125-16-751593:notes:88]
|  |  | September 30, 2016 |  | July 1, 2016 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 800 |  |  | $ | 823 |  |  | $ | 800 |  |  | $ | 804 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 163 |  |  | 158 |  |  | 164 |  |
| 4.75% Senior Notes due June 2023 |  | 990 |  |  | 975 |  |  | 990 |  |  | 857 |  |
| 4.75% Senior Notes due January 2025 |  | 995 |  |  | 951 |  |  | 995 |  |  | 795 |  |
| 4.875% Senior Notes due June 2027 |  | 698 |  |  | 626 |  |  | 698 |  |  | 514 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 410 |  |  | 489 |  |  | 357 |  |
|  |  | $ | 4,130 |  |  | $ | 3,948 |  |  | $ | 4,130 |  |  | $ | 3,491 |  |
| Less: debt issuance costs |  | (38 | ) |  | — |  |  | (39 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 4,092 |  |  | $ | 3,948 |  |  | $ | 4,091 |  |  | $ | 3,491 |  |
| Less: short-term borrowings and current portion of long-term debt |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 4,092 |  |  | $ | 3,948 |  |  | $ | 4,091 |  |  | $ | 3,491 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-16-751593:notes:89]
[same as prior period, unchanged from 0001104659-16-116201:notes:98]

[0001193125-16-751593:notes:90]
[same as prior period, unchanged from 0001104659-16-116201:notes:99]

[0001193125-16-751593:notes:91]
The changes in the carrying amount of goodwill for the three months ended September 30, 2016, are as follows:

[0001193125-16-751593:notes:92]
| (Dollars in millions) | Amount |
| Balance at July 1, 2016 | $ | 1,237 |  |
| Goodwill acquired | — |  |
| Foreign currency translation effect | — |  |
| Balance at September 30, 2016 | $ | 1,237 |  |

[0001193125-16-751593:notes:93]
[same as prior period, unchanged from 0001104659-16-116201:notes:103]

[0001193125-16-751593:notes:94]
Other intangible assets consist primarily of existing technology, customer relationships, in-process research and development ("IPR&D") and trade names acquired in business combinations. With the exception of IPR&D, acquired intangibles are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization is charged to Operating expenses in the Condensed Consolidated Statements of Operations. IPR&D has been determined to have an indefinite useful life and is not amortized, but instead tested for impairment annually or more frequently if events or changes in circumstance indicate that the asset might be impaired. If the carrying amount of IPR&D exceeds its fair value, an impairment loss is recognized in an amount equal to that excess. There were no impairment charges recognized for IPR&D. Upon completion of the IPR&D, the related assets will be accounted for as a finite-lived intangible asset, and will be amortized over its useful life.

[0001193125-16-751593:notes:95]
The carrying value of other intangible assets subject to amortization as of September 30, 2016, is set forth in the following table:

[0001193125-16-751593:notes:96]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted-AverageRemaining Useful Life |
| Existing technology |  | $ | 297 |  |  | $ | (95 | ) |  | $ | 202 |  |  | 4.0 years |
| Customer relationships |  | 510 |  |  | (351 | ) |  | 159 |  |  | 3.1 years |
| Trade name |  | 29 |  |  | (16 | ) |  | 13 |  |  | 2.4 years |
| Other intangible assets |  | 29 |  |  | (11 | ) |  | 18 |  |  | 3.1 years |
| Total amortizable other intangible assets |  | $ | 865 |  |  | $ | (473 | ) |  | $ | 392 |  |  | 3.5 years |

[0001193125-16-751593:notes:97]
The carrying value of IPR&D not subject to amortization was $14 million as of September 30, 2016.

[0001193125-16-751593:notes:98]
The carrying value of other intangible assets subject to amortization as of July 1, 2016 is set forth in the following table:

[0001193125-16-751593:notes:99]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted-AverageRemaining Useful Life |
| Existing technology |  | $ | 297 |  |  | $ | (79 | ) |  | $ | 218 |  |  | 4.1 years |
| Customer relationships |  | 510 |  |  | (328 | ) |  | 182 |  |  | 3.2 years |
| Trade name |  | 29 |  |  | (14 | ) |  | 15 |  |  | 2.6 years |
| Other intangible assets |  | 29 |  |  | (10 | ) |  | 19 |  |  | 3.2 years |
| Total amortizable other intangible assets |  | $ | 865 |  |  | $ | (431 | ) |  | $ | 434 |  |  | 3.6 years |

[0001193125-16-751593:notes:100]
The carrying value of IPR&D not subject to amortization was 14 million on July 1, 2016.

[0001193125-16-751593:notes:101]
The amortization expense of other intangible assets was $42 million and $41 million for the three months ended September 30, 2016 and October 2, 2015, respectively. As of September 30, 2016, expected amortization expense for other intangible assets for each of the next five fiscal years and thereafter is as follows:

[0001193125-16-751593:notes:102]
| (Dollars in millions) | Amount |
| Remainder of 2017 | $ | 124 |  |
| 2018 | 106 |  |
| 2019 | 68 |  |
| 2020 | 50 |  |
| 2021 | 23 |  |
| Thereafter | 21 |  |
|  | $ | 392 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-16-751593:notes:103]
[same as prior period, unchanged from 0001104659-16-116201:notes:112]

[0001193125-16-751593:notes:104]
The Company's income tax provision of $6 million in the three months ended September 30, 2016 included approximately $5 million of net discrete tax benefits, primarily associated with the release of tax reserves due to the expiration of certain statutes of limitation and prior year tax adjustments.

[0001193125-16-751593:notes:105]
The Company's income tax provision recorded for the three months ended September 30, 2016 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.

[0001193125-16-751593:notes:106]
During the three months ended September 30, 2016, the Company’s unrecognized tax benefits excluding interest and penalties decreased by approximately $2 million to $68 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $68 million at September 30, 2016, subject to certain future valuation allowance reversals. During the 12 months beginning October 1, 2016, the Company expects that its unrecognized tax benefits could be reduced by approximately $11 million, primarily as a result of the expiration of certain statutes of limitation.

[0001193125-16-751593:notes:107]
The Company's income tax benefit of $3 million in the three months ended October 2, 2015 included approximately $4 million of net discrete tax benefits, primarily associated with the release of tax reserves associated with the expiration of certain statutes of limitation.

[0001193125-16-751593:notes:108]
The Company’s income tax benefit recorded for the three months ended October 2, 2015 differed from the benefit from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-16-751593:notes:109]
The fair value and amortized cost of the Company’s investments classified as available-for-sale at September 30, 2016, by remaining contractual maturity were as follows:

[0001193125-16-751593:notes:110]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 1,089 |  |  | $ | 1,089 |  |
| Due in 1 to 5 years |  | — |  |  | — |  |
| Thereafter |  | — |  |  | — |  |
| Total |  | $ | 1,089 |  |  | $ | 1,089 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001193125-16-751593:notes:111]
Legal, Environmental and Other Contingencies

[0001193125-16-751593:notes:112]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001193125-16-751593:notes:113]
Intellectual Property Litigation

[0001193125-16-751593:notes:114]
Convolve, Inc. ("Convolve") and Massachusetts Institute of Technology ("MIT") v. Seagate Technology LLC, et al. - On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the "'635 patent") and U.S. Patent No. 5,638,267 (the "'267 patent"), misappropriation of trade secrets, breach of contract, and other claims. In the complaint, the plaintiffs requested injunctive relief, $800 million in compensatory damages and unspecified punitive damages, including for willful infringement. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe U.S. Patent No. 6,314,473 (the "'473 patent"). The district court ruled in 2010 that the '267 patent was out of the case.

[0001193125-16-751593:notes:115]
On August 16, 2011, the district court granted in part and denied in part the Company's motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court's summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court's summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent. On July 11, 2014, the district court granted the Company's summary judgment motion regarding Convolve's only remaining cause of action, which alleged infringement of the '473 patent. The district court entered judgment in favor of the Company on July 14, 2014. Convolve filed a notice of appeal on August 13, 2014. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-16-751593:notes:116]
Alexander Shukh v. Seagate Technology - On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. On March 31, 2014, the district court granted Seagate’s summary judgment motion and entered judgment in favor of Seagate. Mr. Shukh filed a notice of appeal on April 7, 2014. On October 2, 2015, the court of appeals vacated and remanded the district court’s grant of summary judgment on Mr. Shukh’s claim for correction of inventorship and affirmed the district court’s grant of summary judgment as to all other claims. On October 29, 2015, Mr. Shukh filed a petition for rehearing en banc with the court of appeals; the petition was denied on December 17, 2015. On March 16, 2016, Shukh filed a petition for writ of certiorari to the U.S. Supreme Court; the petition was denied on June 27, 2016. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-16-751593:notes:117]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.—On June 5, 2013, Enova Technology Corporation (“Enova”) filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995 (the '"995 patent"), “Cryptographic Device,” and U.S. Patent No. 7,900,057 (the "'057 patent"), “Cryptographic Serial ATA Apparatus and Method.” The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys’ fees, and other relief. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the ‘995 and ‘057 patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. The Company believes the claims are without merit and intends to vigorously defend this case. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ‘057 patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 patent are held unpatentable. Enova has appealed PTAB’s decisions on the ‘995 patent and the ‘057 patent to the U.S. Court of Appeals for the Federal Circuit. A hearing before the court of appeals has not yet been scheduled. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-16-751593:notes:118]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al.—On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys’ fees, and other relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-16-751593:notes:119]
Environmental Matters

[0001193125-16-751593:notes:120]
The Company's operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company's operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001193125-16-751593:notes:121]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001193125-16-751593:notes:122]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001193125-16-751593:notes:123]
While the Company's ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001193125-16-751593:notes:124]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.

[0001193125-16-751593:notes:125]
Other Matters

[0001193125-16-751593:notes:126]
The Company is involved in a number of other judicial and administrative proceedings incidental to its business, and the Company may be involved in various legal proceedings arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-16-751593:notes:127]
Recently Issued Accounting Pronouncements

[0001193125-16-751593:notes:128]
In May 2014, August 2015, April 2016 and May 2016, the Financial Accounting Standards Board ("FASB") issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, and ASU 2016-12 (ASC Topic 606) Revenue from Contracts with Customers, Narrow-Scope Improvements and Practical Expedients, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The amendments in these ASUs are effective for fiscal years, and interim periods within those years, beginning after December 15, 2017. Early adoption is permitted for annual periods beginning after December 15, 2016. This standard may be applied retrospectively to all prior periods presented, or retrospectively with a cumulative adjustment to retained earnings in the year of adoption ("modified retrospective transition approach"). The Company is in the process of assessing the impact, if any, on its condensed consolidated financial statements and plans to adopt the modified retrospective transition approach.

[0001193125-16-751593:notes:129]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. The amendments in this ASU are effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company is in the process of assessing the impact, if any, of this ASU on its condensed consolidated financial statements.

[0001193125-16-751593:notes:130]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments - Overall Recognition and Measurement of Financial Assets and Financial Liabilities. The amendments in this ASU require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The amendments in this ASU are effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. Early adoption is permitted for only certain portions of the ASU. The Company is in the process of assessing the impact, if any, on its condensed consolidated financial statements.

[0001193125-16-751593:notes:131]
In February 2016, the FASB issued ASU 2016-02 (ASC Topic 842), Leases. The ASU amends a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The amendments in this ASU are effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted.  The Company is in the process of assessing the impact on its condensed consolidated financial statements.

[0001193125-16-751593:notes:132]
In March 2016, the FASB issued ASU 2016-09 (ASC Topic 718), Stock Compensation - Improvements to Employee Share-Based Payment Accounting. The amendments in this ASU are intended to simplify several areas of accounting for share-based compensation arrangements, including the income tax consequences, classification on the consolidated statement of cash flows and treatment of forfeitures. The amendments in this ASU are effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted. The Company is in the process of assessing the impact, if any, of this ASU on its condensed consolidated financial statements.

[0001193125-16-751593:notes:133]
In August 2016, the FASB issued ASU 2016-15 (ASC Topic 230), Statement of Cash Flows - Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU are intended to clarify how certain cash receipts and cash payment are presented and classified in the statement of cash flows. The amendments in this ASU are effective for annual periods beginning after December 15, 2017, and interim periods within those annual periods. Early adoption is permitted. The Company is in the process of assessing the impact, if any, of this ASU on its condensed consolidated financial statements.

[0001193125-16-751593:notes:134]
Recently Adopted Accounting Pronouncements

[0001193125-16-751593:notes:135]
In April 2015 and August 2015, the FASB issued ASU 2015-03 (ASC Subtopic 835-30), Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs and ASU 2015-15 (ASC Subtopic 835-30), Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements- Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting, respectively. The ASUs require that debt issuance costs related to a recognized debt liability, with the exception of those related to line-of-credit arrangements, be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability.  ASU 2015-03 became effective and was adopted by the Company in the September 2016 quarter on a retrospective basis. The adoption of this guidance resulted in a reduction to Other assets, net and Long-term debt by 38 million and 39 million, within the Condensed Consolidated Balance Sheet as of September 30, 2016 and the Consolidated Balance Sheet as of July 1, 2016, respectively. ASU 2015-15 became effective and was adopted by the Company in the September 2016 quarter on a prospective basis with no material impact on the Company’s condensed consolidated financial statements and disclosures.

[0001193125-16-751593:notes:136]
In September 2015, the FASB issued ASU 2015-16 (ASC Topic 805), Business Combinations Simplifying the Accounting for Measurement-Period Adjustments. The amendments in this update require that an acquirer recognize measurement period adjustments in the period in which the adjustments are determined. The income effects of such measurement period adjustments are to be recorded in the same period’s financial statements but calculated as if the accounting had been completed as of the acquisition date. The impact of measurement period adjustments to earnings that relate to prior period financial statements are to be presented separately on the income statement or disclosed by line item. The amendments in this update are for fiscal years, including interim periods within those fiscal years, beginning after December 15, 2015. This ASU became effective and was adopted by the Company in the September 2016 quarter on a prospective basis with no material impact on the Company’s condensed consolidated financial statements and disclosures.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001193125-16-751593:notes:137]
[same as prior period, unchanged from 0001104659-16-116201:notes:147]

[0001193125-16-751593:notes:138]
[same as prior period, unchanged from 0001104659-16-116201:notes:148]

[0001193125-16-751593:notes:139]
Seagate Technology plc (the "Company") is a leading provider of electronic data storage technology and solutions.  Our principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, we produce a broad range of electronic data storage products including solid state hybrid drives ("SSHD"), solid state drives ("SSD"), PCIe cards and SATA controllers. Our storage technology portfolio also includes storage subsystems, and high performance computing ("HPC") solutions.

[0001193125-16-751593:notes:140]
[same as prior period, unchanged from 0001104659-16-116201:notes:150]

[0001193125-16-751593:notes:141]
The Company's products are designed for mission critical and nearline applications in enterprise servers and storage systems; client compute applications, where our products are designed primarily for desktop and mobile computing; and client non-compute applications, where our products are designed for a wide variety of end user devices such as digital video recorders ("DVRs"), personal data backup systems, portable external storage systems, digital media systems and surveillance systems.

[0001193125-16-751593:notes:142]
The Company's Cloud Systems and Solutions builds on the Seagate legacy to extend innovation from the device into the information infrastructure, onsite and in the cloud. Our portfolio includes HPC storage solutions, modular original equipment manufacturers ("OEM") storage systems and scale-out storage systems.

[0001193125-16-751593:notes:143]
[same as prior period, unchanged from 0001104659-16-116201:notes:153]

[0001193125-16-751593:notes:144]
The results of operations for the three months ended September 30, 2016, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending June 30, 2017. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three months ended September 30, 2016 and the three months ended October 2, 2015 consisted of 13 weeks. Fiscal year 2017 will be comprised of 52 weeks and will end on June 30, 2017. The fiscal quarters ended September 30, 2016, July 1, 2016, and October 2, 2015, are also referred to herein as the “September 2016 quarter”, the “June 2016 quarter”, and the “September 2015 quarter”, respectively.

[0001193125-16-751593:notes:145]
[same as prior period, unchanged from 0001104659-16-116201:notes:155]

[0001193125-16-751593:notes:146]
There have been no significant changes in the Company's significant accounting policies. Please refer to Note 1 of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended July 1, 2016, as filed with the SEC on August 5, 2016 for a discussion of the Company’s other significant accounting policies.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-16-751593:notes:147]
[same as prior period, unchanged from 0001104659-16-116201:notes:158]

[0001193125-16-751593:notes:148]
[same as prior period, unchanged from 0001104659-16-116201:notes:159]

[0001193125-16-751593:notes:149]
[same as prior period, unchanged from 0001104659-16-116201:notes:160]

[0001193125-16-751593:notes:150]
[same as prior period, unchanged from 0001104659-16-116201:notes:161]

[0001193125-16-751593:notes:151]
The nature of these indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay on behalf of its officers and directors. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the accompanying condensed consolidated financial statements with respect to these indemnification obligations.

[0001193125-16-751593:notes:152]
[same as prior period, unchanged from 0001104659-16-116201:notes:163]

[0001193125-16-751593:notes:153]
The Company has entered into agreements with customers and suppliers that include limited intellectual property indemnification obligations that are customary in the industry. These guarantees generally require the Company to compensate the other party for certain damages and costs incurred as a result of third party intellectual property claims arising from these transactions. The nature of the intellectual property indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay to its customers and suppliers. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the accompanying condensed consolidated financial statements with respect to these indemnification obligations.

[0001193125-16-751593:notes:154]
[same as prior period, unchanged from 0001104659-16-116201:notes:165]

[0001193125-16-751593:notes:155]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the three months ended September 30, 2016 and October 2, 2015 were as follows:

[0001193125-16-751593:notes:156]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 30, 2016 |  | October 2, 2015 |
| Balance, beginning of period |  | $ | 206 |  |  | $ | 248 |  |
| Warranties issued |  | 31 |  |  | 33 |  |
| Repairs and replacements |  | (30 | ) |  | (41 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | 9 |  |  | (15 | ) |
| Balance, end of period |  | $ | 216 |  |  | $ | 225 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-16-751593:notes:157]
[same as prior period, unchanged from 0001104659-16-116201:notes:168]

[0001193125-16-751593:notes:158]
| (Dollars in millions) |  | September 30, 2016 |  | July 1, 2016 |
| Property, equipment and leasehold improvements |  | $ | 9,898 |  |  | $ | 9,884 |  |
| Accumulated depreciation and amortization |  | (7,805 | ) |  | (7,724 | ) |
|  |  | $ | 2,093 |  |  | $ | 2,160 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-16-751593:notes:159]
[same as prior period, unchanged from 0001104659-16-116201:notes:170]

[0001193125-16-751593:notes:160]
For the three months ended September 30, 2016, the Company recorded restructuring charges of approximately 82 million, comprised primarily of charges related to employee termination costs and facility exit costs associated with restructuring of its workforce during the fiscal year.  The Company's significant restructuring plans are described below.  All restructuring charges are reported in Restructuring and other, net on the Condensed Consolidated Statements of Operations.

[0001193125-16-751593:notes:161]
July 2016 Plan - On July 11, 2016, the Company committed to a restructuring plan (the “July 2016 Plan”) for continued consolidation of its global footprint across Asia, EMEA and the Americas. The July 2016 Plan included reducing worldwide headcount by approximately 6,500 employees. The July 2016 Plan, is expected to be largely completed by the end of fiscal year 2017. For the three months ended September 30, 2016, the Company recorded total restructuring charges of approximately $73 million related to the July 2016 Plan, comprised of approximately $72 million for employee termination costs and $1 million facility exit costs, respectively. For the three months ended September 30, 2016, the Company made cash payments of $4 million, comprised primarily of $3 million for employee termination costs and $1 million for facility exit costs related to the July 2016 Plan.

[0001193125-16-751593:notes:162]
June 2016 Plan - On June 27, 2016, the Company committed to a restructuring plan (the “June 2016 Plan”) as part of the Company's efforts to reduce its cost structure to align with the current macroeconomic conditions. The June 2016 Plan included reducing worldwide headcount by approximately 1,600 employees. The June 2016 Plan was largely completed by the fiscal quarter ended September 30, 2016. The Company did not record any material restructuring charges related to the June 2016 Plan for the three months ended September 30, 2016. For the three months ended September 30, 2016, the Company made cash payments of $35 million comprised primarily of employee termination costs related to the June 2016 Plan.

[0001193125-16-751593:notes:163]
February 2016 Plan - On February 15, 2016, the Company committed to a restructuring plan (the “February 2016 Plan”) intended to align its manufacturing footprint with current macroeconomic conditions. The February 2016 Plan included reducing worldwide headcount by approximately 2,000 employees. The February 2016 Plan was largely completed by the fiscal quarter ended April 1, 2016. For the three months ended September 30, 2016, the Company recorded total restructuring charges and made cash payments of $1 million related to the February 2016 Plan, comprised of facility exit costs.

[0001193125-16-751593:notes:164]
September 2015 Plan - On September 4, 2015, the Company committed to a restructuring plan (the “September 2015 Plan”) intended to realign its cost structure with the current macroeconomic business environment. The September 2015 Plan included reducing worldwide headcount by approximately 1,000 employees. The September 2015 Plan was largely completed by the fiscal quarter ended January 1, 2016. For the three months ended September 30, 2016, the Company recorded total restructuring charges of approximately $2 million and made cash payments of approximately $1 million related to the September 2015 Plan, comprised primarily of facility exit costs.

[0001193125-16-751593:notes:165]
Other Restructuring and Exit Costs - For the three months ended September 30, 2016, the Company recorded restructuring charges of approximately $6 million, and made cash payments of $1 million, respectively, related to other restructuring plans.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-16-751593:notes:166]
[same as prior period, unchanged from 0001104659-16-116201:notes:175]

[0001193125-16-751593:notes:167]
| (Dollars in millions) |  | Unrealized Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Marketable Securities (a) |  | Unrealized Gains (Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at July 1, 2016 |  | $ | (1 | ) |  | $ | — |  |  | $ | (7 | ) |  | $ | (17 | ) |  | $ | (25 | ) |
| Other comprehensive income (loss) before reclassifications |  | (1 | ) |  | — |  |  | — |  |  | 1 |  |  | — |  |
| Amounts reclassified from AOCI |  | 1 |  |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Other comprehensive income (loss) |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Balance at September 30, 2016 |  | $ | (1 | ) |  | $ | — |  |  | $ | (7 | ) |  | $ | (16 | ) |  | $ | (24 | ) |
| Balance at July 3, 2015 |  | $ | 1 |  |  | $ | — |  |  | $ | (15 | ) |  | $ | (16 | ) |  | $ | (30 | ) |
| Other comprehensive income (loss) before reclassifications |  | (2 | ) |  | — |  |  | 1 |  |  | — |  |  | (1 | ) |
| Amounts reclassified from AOCI |  | 1 |  |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Other comprehensive income (loss) |  | (1 | ) |  | — |  |  | 1 |  |  | — |  |  | — |  |
| Balance at October 2, 2015 |  | $ | — |  |  | $ | — |  |  | $ | (14 | ) |  | $ | (16 | ) |  | $ | (30 | ) |

[0001193125-16-751593:notes:168]
[same as prior period, unchanged from 0001104659-16-116201:notes:177]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-16-751593:notes:169]
[same as prior period, unchanged from 0001104659-16-116201:notes:178]

[0001193125-16-751593:notes:170]
| (Dollars in millions) |  | September 30, 2016 |  | July 1, 2016 |
| Raw materials and components |  | $ | 287 |  |  | $ | 307 |  |
| Work-in-process |  | 279 |  |  | 297 |  |
| Finished goods |  | 348 |  |  | 264 |  |
|  |  | $ | 914 |  |  | $ | 868 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-16-751593:notes:171]
[same as prior period, unchanged from 0001104659-16-116201:notes:180]

[0001193125-16-751593:notes:172]
[same as prior period, unchanged from 0001104659-16-116201:notes:181]

[0001193125-16-751593:notes:173]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 298,607,364 shares were outstanding as of September 30, 2016, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of September 30, 2016.

[0001193125-16-751593:notes:174]
[same as prior period, unchanged from 0001104659-16-116201:notes:183]

[0001193125-16-751593:notes:175]
[same as prior period, unchanged from 0001104659-16-116201:notes:184]

[0001193125-16-751593:notes:176]
[same as prior period, unchanged from 0001104659-16-116201:notes:185]

[0001193125-16-751593:notes:177]
[same as prior period, unchanged from 0001104659-16-116201:notes:186]

[0001193125-16-751593:notes:178]
On April 22, 2015, the Board of Directors authorized the Company to repurchase an additional $2.5 billion of its outstanding ordinary shares.

[0001193125-16-751593:notes:179]
[same as prior period, unchanged from 0001104659-16-116201:notes:189]

[0001193125-16-751593:notes:180]
As of September 30, 2016, $1.6 billion remained available for repurchase under the existing repurchase authorization limit.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-16-751593:notes:181]
[same as prior period, unchanged from 0001104659-16-116201:notes:191]

[0001193125-16-751593:notes:182]
[same as prior period, unchanged from 0001104659-16-116201:notes:192]

[0001193125-16-751593:notes:183]
As of September 30, 2016, the Company’s Other current assets included $6 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001193125-16-751593:notes:184]
As of September 30, 2016, the Company had no material available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined that no available-for-sale securities were other-than-temporarily impaired as of September 30, 2016.

[0001193125-16-751593:notes:185]
As of July 1, 2016, the Company’s Other current assets included $7 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001193125-16-751593:notes:186]
As of July 1, 2016, the Company had no material available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale securities were other-than-temporarily impaired as of July 1, 2016.

[0001193125-16-751593:notes:187]
[same as prior period, unchanged from 0001104659-16-116201:notes:197]

[0001193125-16-751593:notes:188]
[same as prior period, unchanged from 0001104659-16-116201:notes:198]

[0001193125-16-751593:notes:189]
[same as prior period, unchanged from 0001104659-16-116201:notes:200]
