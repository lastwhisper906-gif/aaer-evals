# STX MD&A — 0001193125-16-751593


## mdna

[0001193125-16-751593:mdna:1]
| ITEM 2. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001193125-16-751593:mdna:2]
The following is a discussion of the financial condition, changes in financial condition, and results of operations for our fiscal quarters
ended September 30, 2016, July 1, 2016 and October 2, 2015, referred to herein as the “September 2016 quarter,” the “June 2016 quarter,” and the “September 2015 quarter,” respectively. We operate and
report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The September 2016, June 2016, and September 2015 quarters were 13 weeks.

[0001193125-16-751593:mdna:3]
You should read this discussion in conjunction with financial information and related notes included elsewhere in this report. Unless the
context indicates otherwise, as used herein, the terms “we,” “us,” “Seagate,” the “Company” and “our” refer to Seagate Technology plc, an Irish public limited company, and its subsidiaries.
References to “$” are to United States dollars.

[0001193125-16-751593:mdna:4]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is provided in addition
to the accompanying condensed consolidated financial statements and notes to assist readers in understanding our results of operations, financial condition, and cash flows. Our MD&A is organized as follows:

[0001193125-16-751593:mdna:5]
|  | • |  | Our Company. Overview of our business. |

[0001193125-16-751593:mdna:6]
|  | • |  | Overview of the September 2016 quarter. Highlights of events in the September 2016 quarter that impacted our financial position. |

[0001193125-16-751593:mdna:7]
|  | • |  | Results of Operations. An analysis of our financial results comparing the September 2016 quarter to the June 2016 quarter and the September 2015 quarter. |

[0001193125-16-751593:mdna:8]
|  | • |  | Liquidity and Capital Resources. An analysis of changes in our balance sheets and cash flows, and discussion of our financial condition including the credit quality of our investment portfolio and potential sources of liquidity. |

[0001193125-16-751593:mdna:9]
|  | • |  | Critical Accounting Policies. Accounting policies and estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results. |

[0001193125-16-751593:mdna:10]
[same as prior period, unchanged from 0001104659-16-116201:mdna:10]

[0001193125-16-751593:mdna:11]
We are a leading provider of
electronic data storage technology and solutions. Our principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, we produce a broad range of electronic data storage products including
solid state hybrid drives (“SSHD”) and solid state drives (“SSD”) in our Enterprise market portfolio. Our storage technology portfolio also includes storage subsystems, and high performance computing (“HPC”) solutions.

[0001193125-16-751593:mdna:12]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to
be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to
store data, and most SSDs use NAND-based flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs

[0001193125-16-751593:mdna:13]
28

[0001193125-16-751593:mdna:14]
[same as prior period, unchanged from 0001104659-16-116201:mdna:14]

[0001193125-16-751593:mdna:15]
Our products are designed for mission critical and nearline applications in enterprise servers and storage systems; client compute
applications, where our products are designed primarily for desktop and mobile computing; and client non-compute applications, where our products are designed for a wide variety of end user devices such as portable external storage systems, personal
data backup systems, surveillance systems, digital video recorders (“DVRs”) and gaming consoles.

[0001193125-16-751593:mdna:16]
Our Cloud Systems and
Solutions build on the Seagate legacy to extend innovation from the device into the information infrastructure, onsite and in the cloud. Our portfolio includes HPC storage solutions, modular original equipment manufacturers (“OEM”) storage
systems and scale-out storage systems.

[0001193125-16-751593:mdna:17]
Overview of the September 2016 Quarter

[0001193125-16-751593:mdna:18]
During the September 2016 quarter, we shipped 39 million drive units totaling 67 exabytes of storage capacity, generating revenue of
approximately $2.8 billion and gross margin of 29%. Our operating cash flow was $592 million. We paid $101 million for repurchases of ordinary shares.

[0001193125-16-751593:mdna:19]
[same as prior period, unchanged from 0001104659-16-116201:mdna:19]

[0001193125-16-751593:mdna:20]
We list in the
tables below summarized information from our Condensed Consolidated Statements of Operations by dollars and as a percentage of revenue:

[0001193125-16-751593:mdna:21]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | September 30,2016 |  |  | July 1,2016 |  |  | October 2,2015 |  |
| Revenue |  | $ | 2,797 |  |  | $ | 2,654 |  |  | $ | 2,925 |  |
| Cost of revenue |  |  | 1,996 |  |  |  | 1,992 |  |  |  | 2,236 |  |
| Gross margin |  |  | 801 |  |  |  | 662 |  |  |  | 689 |  |
| Product development |  |  | 315 |  |  |  | 307 |  |  |  | 328 |  |
| Marketing and administrative |  |  | 155 |  |  |  | 143 |  |  |  | 182 |  |
| Amortization of intangibles |  |  | 28 |  |  |  | 29 |  |  |  | 34 |  |
| Restructuring and other, net |  |  | 82 |  |  |  | 80 |  |  |  | 59 |  |
| Income from operations |  |  | 221 |  |  |  | 103 |  |  |  | 86 |  |
| Other expense (income), net |  |  | (48 | ) |  |  | (49 | ) |  |  | (55 | ) |
| Income before income taxes |  |  | 173 |  |  |  | 54 |  |  |  | 31 |  |
| Provision for (benefit from) income taxes |  |  | 6 |  |  |  | (16 | ) |  |  | (3 | ) |
| Net income |  | $ | 167 |  |  | $ | 70 |  |  | $ | 34 |  |

[0001193125-16-751593:mdna:22]
|  |  | For the Three Months Ended |  |
|  |  | September 30,2016 |  |  | July 1,2016 |  |  | October 2,2015 |  |
| Revenue |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |
| Cost of revenue |  |  | 71 |  |  |  | 75 |  |  |  | 76 |  |
| Gross margin |  |  | 29 |  |  |  | 25 |  |  |  | 24 |  |
| Product development |  |  | 11 |  |  |  | 12 |  |  |  | 11 |  |
| Marketing and administrative |  |  | 6 |  |  |  | 5 |  |  |  | 7 |  |
| Amortization of intangibles |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |
| Restructuring and other, net |  |  | 3 |  |  |  | 3 |  |  |  | 2 |  |
| Income from operations |  |  | 8 |  |  |  | 4 |  |  |  | 3 |  |
| Other (expense) income, net |  |  | (2 | ) |  |  | (2 | ) |  |  | (2 | ) |
| Income before income taxes |  |  | 6 |  |  |  | 2 |  |  |  | 1 |  |
| Provision for (benefit from) income taxes |  |  | — |  |  |  | (1 | ) |  |  | — |  |
| Net income |  |  | 6 | % |  |  | 3 | % |  |  | 1 | % |

[0001193125-16-751593:mdna:23]
29

[0001193125-16-751593:mdna:24]
[same as prior period, unchanged from 0001104659-16-116201:mdna:24]

[0001193125-16-751593:mdna:25]
The following table summarizes information regarding average drive selling prices (“ASPs”), drive volume unit shipments, exabytes
shipped, and revenues by channel and geography:

[0001193125-16-751593:mdna:26]
|  |  | For the Three Months Ended |  |
| (In millions, except percentages, exabytes and ASPs) |  | September 30,2016 |  |  | July 1,2016 |  |  | October 2,2015 |  |
| Unit Shipments (1): |  |  |  |  |  |  |  |  |  |  |  |  |
| Enterprise |  |  | 9 |  |  |  | 9 |  |  |  | 8 |  |
| Client Compute |  |  | 16 |  |  |  | 16 |  |  |  | 24 |  |
| Client Non-Compute |  |  | 14 |  |  |  | 12 |  |  |  | 15 |  |
| Total Units Shipped |  |  | 39 |  |  |  | 37 |  |  |  | 47 |  |
| ASPs (per unit) |  | $ | 67 |  |  | $ | 67 |  |  | $ | 58 |  |
| Exabytes Shipped |  |  | 67 |  |  |  | 62 |  |  |  | 56 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  |  | 71 | % |  |  | 71 | % |  |  | 70 | % |
| Distributors |  |  | 17 | % |  |  | 16 | % |  |  | 18 | % |
| Retailers |  |  | 12 | % |  |  | 13 | % |  |  | 12 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  |  | 34 | % |  |  | 33 | % |  |  | 28 | % |
| EMEA |  |  | 15 | % |  |  | 16 | % |  |  | 17 | % |
| Asia Pacific |  |  | 51 | % |  |  | 51 | % |  |  | 55 | % |

[0001193125-16-751593:mdna:27]
| (1) | For the periods presented, gaming units in Client Compute have been reclassified to Client Non-Compute to better align with current market trends. |

[0001193125-16-751593:mdna:28]
Revenue in the September 2016 quarter increased by $143 million from the June 2016 quarter as a result of favorable product mix and an
increase in unit shipments driven primarily by better demand for the Company’s high capacity enterprise HDD product portfolio. Compared to the September 2015 quarter, revenue decreased by $128 million as a result of a decrease in unit shipments
and price erosion, partially offset by improved product mix.

[0001193125-16-751593:mdna:29]
We maintain various sales programs such as channel rebates and price
masking. Price masking rebates are primarily a function of OEM enterprise revenue and contributed to a higher proportion of the sales programs as a percentage of revenue in the September 2016 quarter. Sales programs were at the low range of its
historical range at 10%, 11% and 13% of gross drive revenue for the September 2016 quarter, June 2016 quarter and September 2015 quarter, respectively. Adjustments to revenues due to under or over accruals for sales programs related to revenues
reported in prior quarterly periods were less than 1.0% of quarterly gross revenue in the September 2016 quarter.

[0001193125-16-751593:mdna:30]
[same as prior period, unchanged from 0001104659-16-116201:mdna:32]

[0001193125-16-751593:mdna:31]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | September 30,2016 |  |  | July 1,2016 |  |  | October 2,2015 |  |
| Cost of revenue |  | $ | 1,996 |  |  | $ | 1,992 |  |  | $ | 2,236 |  |
| Gross margin |  |  | 801 |  |  |  | 662 |  |  |  | 689 |  |
| Gross margin percentage |  |  | 29 | % |  |  | 25 | % |  |  | 24 | % |

[0001193125-16-751593:mdna:32]
Gross margin as a percentage of revenue for the September 2016 quarter increased by approximately 400 basis
points compared to the June 2016 quarter driven by favorable product mix and improved utilization of factories resulting from cost savings due to our ongoing workforce reductions and manufacturing consolidation activities.

[0001193125-16-751593:mdna:33]
Compared to the September 2015 quarter, gross margin in the September 2016 quarter increased by approximately 500 basis points, as a result of
favorable product mix and improved utilization of factories resulting from cost savings due to our ongoing workforce reductions and manufacturing consolidation activities, partially offset by price erosion.

[0001193125-16-751593:mdna:34]
In the September 2016 quarter, total warranty cost was in the historical range of 1% to 5% of
revenue and included an unfavorable change in estimates of prior warranty accruals of less than 0.5% of revenue. Warranty cost related to new unit shipments was 1.1% of revenue for each of the September 2016, June 2016 and September 2015
quarters, respectively.

[0001193125-16-751593:mdna:35]
[same as prior period, unchanged from 0001104659-16-116201:mdna:38]

[0001193125-16-751593:mdna:36]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | September 30,2016 |  |  | July 1,2016 |  |  | October 2,2015 |  |
| Product development |  | $ | 315 |  |  | $ | 307 |  |  | $ | 328 |  |
| Marketing and administrative |  |  | 155 |  |  |  | 143 |  |  |  | 182 |  |
| Amortization of intangibles |  |  | 28 |  |  |  | 29 |  |  |  | 34 |  |
| Restructuring and other, net |  |  | 82 |  |  |  | 80 |  |  |  | 59 |  |
| Operating expenses |  | $ | 580 |  |  | $ | 559 |  |  | $ | 603 |  |

[0001193125-16-751593:mdna:37]
Product development expense. Product development expense for the September 2016 quarter increased
by $8 million from the June 2016 quarter due to a $19 million increase in variable compensation and share-based compensation driven by better financial performance, partially offset by a $7 million decrease in salaries as a result of the
restructuring of our workforce in the June 2016 and September 2016 quarters, and increased operational efficiencies in our business. Compared to the September 2015 quarter, product development expense decreased by $13 million due to a $24 million
decrease in salaries and other employee benefits as a result of our ongoing restructuring actions to reduce our global workforce. The decrease was partially offset by a $22 million increase in variable compensation in the September 2016 quarter with
the remainder of the decrease due to increased operational efficiencies in our business.

[0001193125-16-751593:mdna:38]
Marketing and administrative
expense. Marketing and administrative expense for the September 2016 quarter increased by $12 million from the June 2016 quarter mainly due to a $17 million increase in variable compensation and share-based compensation driven by better
financial performance, partially offset by a $10 million decrease in salaries and other employee benefits as a result of the restructuring of our workforce in the June 2016 and September 2016 quarters. Compared to the September 2015 quarter,
marketing and administrative expense decreased by $27 million due to a $25 million decrease in salaries and other employee benefits as a result of our ongoing restructuring actions to reduce global workforce, a $6 million reduction in advertising
and marketing expenses in the September 2016 quarter. The decrease was partially offset by a $13 million increase in variable compensation and share-based compensation driven by better financial performance in the September 2016 quarter, with the
remainder of the decrease due to increased operational efficiencies in our business.

[0001193125-16-751593:mdna:39]
Amortization of
intangibles. Amortization of intangibles for the September 2016 quarter remained flat from June 2016 quarter. Compared to the September 2015 quarter, amortization of intangibles decreased by $6 million, due to certain intangible assets
reaching the end of their useful life, partially offset by the intangibles acquired in the acquisition of Dot Hill during the quarter ended January 1, 2016.

[0001193125-16-751593:mdna:40]
Restructuring and other, net. Restructuring and other, net for the September 2016, June 2016 and September 2015 quarters was
comprised primarily of restructuring charges to reduce our global workforce by approximately 6,500, 1,600 and 1,000 employees in each of those quarters, respectively, as we continue to consolidate our global footprint across Asia, EMEA and the
Americas. See “Part I, Item 1. Financial Statements-Note 7. Restructuring and Exit Costs” for more details.

[0001193125-16-751593:mdna:41]
Other (Expense) Income, Net

[0001193125-16-751593:mdna:42]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | September 30,2016 |  |  | July 1,2016 |  |  | October 2,2015 |  |
| Other (expense) income, net |  | $ | (48 | ) |  | $ | (49 | ) |  | $ | (55 | ) |

[0001193125-16-751593:mdna:43]
Other (expense) income, net remained flat from the June 2016 quarter. Compared to the September 2015 quarter,
other (expense) income, net decreased by $7 million due to a $10 million loss related to the impairment of a strategic investment in the September 2015 quarter, partially offset by a higher interest expense capitalization in the September 2015
quarter.

[0001193125-16-751593:mdna:44]
[same as prior period, unchanged from 0001104659-16-116201:mdna:22]

[0001193125-16-751593:mdna:45]
Income Taxes

[0001193125-16-751593:mdna:46]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | September 30,2016 |  |  | July 1,2016 |  |  | October 2,2015 |  |
| Provision for (benefit from) income taxes |  | $ | 6 |  |  | $ | (16 | ) |  | $ | (3 | ) |

[0001193125-16-751593:mdna:47]
Our income tax provision of $6 million for the September 2016 quarter included approximately $5 million of net
discrete tax benefits, primarily associated with the release of tax reserves due to the expiration of certain statutes of limitation and prior year tax adjustments.

[0001193125-16-751593:mdna:48]
Our income tax provision recorded for the September 2016 quarter differed from the provision for income taxes that would be derived by
applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and
are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.

[0001193125-16-751593:mdna:49]
During the three months ended September 30, 2016, our unrecognized tax benefits excluding interest and penalties decreased by
approximately $2 million to $68 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $68 million at September 30, 2016, subject to certain future valuation allowance reversals. During the 12
months beginning October 1, 2016, we expect that our unrecognized tax benefits could be reduced by approximately $11 million, primarily as a result of the expiration of certain statutes of limitation.

[0001193125-16-751593:mdna:50]
Our income tax benefit recorded for the September 2015 quarter included approximately $4 million of net discrete tax benefits, primarily
associated with the release of tax reserves associated with the expiration of certain statutes of limitation.

[0001193125-16-751593:mdna:51]
Our income tax benefit
recorded for the September 2015 quarter differed from the benefit from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to
non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax
assets.

[0001193125-16-751593:mdna:52]
[same as prior period, unchanged from 0001104659-16-116201:mdna:65]

[0001193125-16-751593:mdna:53]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital
resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist primarily of money market funds, and certificates of deposits. The
principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have restrictive
regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash have been and will continue to be sufficient to meet our cash needs for the next 12 months unimpeded by any
restrictive regulations. We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term investments and we do not believe the fair value of our short-term investments has
significantly changed from the values reported as of September 30, 2016.

[0001193125-16-751593:mdna:54]
[same as prior period, unchanged from 0001104659-16-116201:mdna:67]

[0001193125-16-751593:mdna:55]
| (Dollars in millions) |  | September 30,2016 |  |  | July 1,2016 |  |  | Change |  |
| Cash and cash equivalents |  | $ | 1,489 |  |  | $ | 1,125 |  |  | $ | 364 |  |
| Short-term investments |  |  | 5 |  |  |  | 6 |  |  |  | (1 | ) |
| Total |  | $ | 1,494 |  |  | $ | 1,131 |  |  | $ | 363 |  |

[0001193125-16-751593:mdna:56]
Our cash and cash equivalents and short-term investments increased from July 1, 2016 as a result of an
increase in net cash provided by operating activities, partially offset by net cash outflows for repurchase of our ordinary shares.

[0001193125-16-751593:mdna:57]
[same as prior period, unchanged from 0001104659-16-116201:mdna:70]

[0001193125-16-751593:mdna:58]
Cash provided by operating activities for the three months ended September 30, 2016 of $592 million includes the effects of net income
adjusted for non-cash items including depreciation, amortization, share-based compensation, and:

[0001193125-16-751593:mdna:59]
|  | • |  | an increase of $101 million in accounts payable, primarily due to the timing of payments on material purchases and an increase in units built |

[0001193125-16-751593:mdna:60]
[same as prior period, unchanged from 0001104659-16-116201:mdna:73]

[0001193125-16-751593:mdna:61]
Cash used for investing activities for the three months ended September 30, 2016 was $139 million and primarily attributable to the
following activities:

[0001193125-16-751593:mdna:62]
|  | • |  | $140 million used to acquire property, equipment and leasehold improvements |

[0001193125-16-751593:mdna:63]
Cash Used in
Financing Activities

[0001193125-16-751593:mdna:64]
Cash used in financing activities of $89 million for the three months ended September 30, 2016 was primarily
attributable to the following activities:

[0001193125-16-751593:mdna:65]
|  | • |  | $101 million paid to repurchase ordinary shares; and |

[0001193125-16-751593:mdna:66]
|  | • |  | $23 million paid for taxes related to net share settlement of equity awards; offset by |

[0001193125-16-751593:mdna:67]
|  | • |  | $35 million in proceeds from issuance of ordinary shares under employee stock plans |

[0001193125-16-751593:mdna:68]
Liquidity Sources,
Cash Requirements and Commitments

[0001193125-16-751593:mdna:69]
Our primary sources of liquidity as of September 30, 2016 consisted of:
(1) approximately $1.5 billion in cash, cash equivalents, and short-term investments, (2) cash we expect to generate from operations and (3) a $700 million senior revolving credit facility.

[0001193125-16-751593:mdna:70]
As of September 30, 2016, no borrowings had been drawn under the revolving credit facility or had been utilized for letters of credit
issued under this credit facility. The line of credit is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001193125-16-751593:mdna:71]
The credit agreement that governs our revolving credit facility, as amended, includes three financial covenants: (1) minimum cash, cash
equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. On April 28, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to adjust for
our current financial liquidity position. We were in compliance with the modified covenants as of September 30, 2016 and expect to be in compliance for the next 12 months.

[0001193125-16-751593:mdna:72]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled
payments of principal and interest on our indebtedness, and to fund our quarterly dividend. Our ability to fund these requirements will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to
prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001193125-16-751593:mdna:73]
For
fiscal year 2017, we expect capital expenditures to be less than 5% of revenue.

[0001193125-16-751593:mdna:74]
From time to time we may repurchase any of our
outstanding notes in open market or privately negotiated purchases or otherwise, or may repurchase outstanding notes pursuant to the terms of the applicable indenture.

[0001193125-16-751593:mdna:75]
Dividends declared in the September 2016 quarter of $188 million were subsequently paid on October 5, 2016. The Company’s Board of
Directors declared a quarterly cash dividend of $0.63 per share on October 19, 2016, which is payable on January 4, 2017 to shareholders of record at the close of business on December 21, 2016.

[0001193125-16-751593:mdna:76]
From time to time we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases. As of
September 30, 2016, $1.6 billion remained available for repurchase under our existing repurchase authorization limit. All repurchases are effected as redemptions in accordance with the Company’s Articles of Association.

[0001193125-16-751593:mdna:77]
[same as prior period, unchanged from 0001104659-16-116201:mdna:90]

[0001193125-16-751593:mdna:78]
Our
discussion and analysis of financial condition and results of operations are based upon our Condensed Consolidated Financial Statements, which have been prepared in accordance with U.S. generally accepted accounting principles. The preparation of
such statements requires us to make estimates and assumptions that affect the reported amounts of revenues and expenses during the reporting period and the reported amounts of assets and liabilities as of the date of the financial statements. Our
estimates are

[0001193125-16-751593:mdna:79]
[same as prior period, unchanged from 0001104659-16-116201:mdna:43]

[0001193125-16-751593:mdna:80]
based on historical experience and other assumptions that we consider to be appropriate in the circumstances. However, actual future results may vary from our estimates.

[0001193125-16-751593:mdna:81]
Since our fiscal year ended July 1, 2016, there have been no material changes in our critical accounting policies and
estimates. Refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended July 1,
2016, as filed with the SEC on August 5, 2016, for a discussion of our critical accounting policies and estimates.

[0001193125-16-751593:mdna:82]
Recent Accounting
Pronouncements

[0001193125-16-751593:mdna:83]
See “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of
Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.
