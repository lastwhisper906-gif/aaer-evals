# STX note change history — 0001104659-16-116201 → 0001193125-16-751593


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-10-28):
[0001193125-16-751593:note_history:1]
Convolve, Inc. ("Convolve") and Massachusetts Institute of Technology ("MIT") v. Seagate Technology LLC, et al. - On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the "'635 patent") and U.S. Patent No. 5,638,267 (the "'267 patent"), misappropriation of trade secrets, breach of contract, and other claims. In the complaint, the plaintiffs requested injunctive relief, $800 million in compensatory damages and unspecified punitive damages, including for willful infringement. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe U.S. Patent No. 6,314,473 (the "'473 patent"). The district court ruled in 2010 that the '267 patent was out of the case.
  (was, 2016-04-29, similarity 0.9969):
[0001104659-16-116201:note_history:1]
Convolve, Inc. ("Convolve") and Massachusetts Institute of Technology ("MIT") v. Seagate Technology LLC, et al. - On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent Nos. 4,916,635 (the "'635 patent") and U.S. Patent No. 5,638,267 (the "'267 patent"), misappropriation of trade secrets, breach of contract, and other claims. In the complaint, the plaintiffs requested injunctive relief, $800 million in compensatory damages and unspecified punitive damages, including for willful infringement. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe US Patent No. 6,314,473 (the "'473 patent"). The district court ruled in 2010 that the '267 patent was out of the case.

- changed (2016-10-28):
[0001193125-16-751593:note_history:2]
Alexander Shukh v. Seagate Technology - On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. On March 31, 2014, the district court granted Seagate’s summary judgment motion and entered judgment in favor of Seagate. Mr. Shukh filed a notice of appeal on April 7, 2014. On October 2, 2015, the court of appeals vacated and remanded the district court’s grant of summary judgment on Mr. Shukh’s claim for correction of inventorship and affirmed the district court’s grant of summary judgment as to all other claims. On October 29, 2015, Mr. Shukh filed a petition for rehearing en banc with the court of appeals; the petition was denied on December 17, 2015. On March 16, 2016, Shukh filed a petition for writ of certiorari to the U.S. Supreme Court; the petition was denied on June 27, 2016. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2016-04-29, similarity 0.6165):
[0001104659-16-116201:note_history:2]
Alexander Shukh v. Seagate Technology - On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. On March 31, 2014, the district court granted Seagate's summary judgment motion and entered judgment in favor of Seagate. Mr. Shukh filed a notice of appeal on April 7, 2014. On October 2, 2015, the court of appeals vacated and remanded the district court’s grant of summary judgment on Mr. Shukh’s claim for correction of inventorship and affirmed the district court’s grant of summary judgment as to all other claims. On October 29, 2015, Mr. Shukh filed a petition for rehearing en banc with the court of appeals; the petition was denied on December 17, 2015. On March 16, 2016, Shukh filed a petition for writ of certiorari to the U.S. Supreme Court. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- added (2016-10-28):
[0001193125-16-751593:note_history:3]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.—On June 5, 2013, Enova Technology Corporation (“Enova”) filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995 (the '"995 patent"), “Cryptographic Device,” and U.S. Patent No. 7,900,057 (the "'057 patent"), “Cryptographic Serial ATA Apparatus and Method.” The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys’ fees, and other relief. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the ‘995 and ‘057 patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. The Company believes the claims are without merit and intends to vigorously defend this case. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ‘057 patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 patent are held unpatentable. Enova has appealed PTAB’s decisions on the ‘995 patent and the ‘057 patent to the U.S. Court of Appeals for the Federal Circuit. A hearing before the court of appeals has not yet been scheduled. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- added (2016-10-28):
[0001193125-16-751593:note_history:4]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al.—On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys’ fees, and other relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- changed (2016-10-28):
[0001193125-16-751593:note_history:5]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.
  (was, 2016-04-29, similarity 0.9882):
[0001104659-16-116201:note_history:5]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the "Superfund" law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

- changed (2016-10-28):
[0001193125-16-751593:note_history:6]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.
  (was, 2016-04-29, similarity 0.9899):
[0001104659-16-116201:note_history:6]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union ("EU") enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern ("SVHCs") in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.

- removed (2016-10-28):
[0001104659-16-116201:note_history:7]
LEAP Co., Ltd. v. Seagate Singapore International Headquarters Pte. Ltd. and Nippon Seagate Inc. - On July 4, 2012, LEAP Co., Ltd. filed a lawsuit in the Tokyo District Court of Japan against Seagate Singapore International Headquarters Pte. Ltd., Nippon Seagate Inc. and Buffalo Inc. alleging wrongful termination of purchase agreements and other claims, and seeking approximately $38 million in damages. On March 16, 2016, the Company and LEAP reached a settlement.  As a result of the settlement, this litigation between the Company and LEAP has ended.  There is no damage or loss to the Company related to this matter.

- removed (2016-10-28):
[0001104659-16-116201:note_history:8]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation ("Enova") filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995, "Cryptographic Device," and U.S. Patent No. 7,900,057, "Cryptographic Serial ATA Apparatus and Method." The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys' fees, and other relief. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the '995 and '057 Patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. The Company believes the claims are without merit and intends to vigorously defend this case. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 Patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ’057 Patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 Patent are held unpatentable. Enova has appealed PTAB’s decisions on the ‘995 Patent and the 057 Patent to the U.S. Court of Appeals for the Federal Circuit. A hearing before the court of appeals has not yet been scheduled. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- removed (2016-10-28):
[0001104659-16-116201:note_history:9]
Seagate Technology LLC v. Western Digital Corp.  On October 8, 2014, the Minnesota Supreme Court ruled that the arbitration award in favor of the Company in its case against Western Digital for the misappropriation of the Company’s trade secrets should be confirmed. In the arbitration award, issued on January 23, 2012, the arbitrator determined that Western Digital and its former employee had misappropriated the Company’s trade secrets. The arbitrator awarded the Company $525 million in compensatory damages and, after adding interest, issued a final award of $630 million. Interest on the final award has been accruing at 10%. On October 14, 2014, the Company received a partial payment from Western Digital in the amount of $773 million. During the quarter ended January 2, 2015, the amount of the final award, less litigation and other related costs, was recorded by the Company in Gain on arbitration award, net, and the remaining amount received was recorded in Other, net. On April 7, 2015, the Hennepin County District Court of Minnesota (“district court”) denied Seagate’s motion for entry of judgment for an amount of additional interest owing on the arbitration award.  On January 25, 2016, the Minnesota Court of Appeals reversed and remanded the district court’s order regarding the unpaid interest. On January 27, 2016, the Company received a further payment from Western Digital in the amount of $33 million, which was the remaining balance of interest owed on the final award. This amount was recorded in Other, net in the Condensed Consolidated Statement of Operations for the three and nine months ended April 1, 2016. On January 29, 2016, the parties filed a stipulation of dismissal with the district court, ending the litigation.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-10-28):
[0001193125-16-751593:note_history:10]
Seagate Technology plc (the "Company") is a leading provider of electronic data storage technology and solutions.  Our principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, we produce a broad range of electronic data storage products including solid state hybrid drives ("SSHD"), solid state drives ("SSD"), PCIe cards and SATA controllers. Our storage technology portfolio also includes storage subsystems, and high performance computing ("HPC") solutions.
  (was, 2016-04-29, similarity 0.9401):
[0001104659-16-116201:note_history:10]
Seagate Technology plc (the "Company") is a leading provider of electronic data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, it produces a broad range of electronic data storage products including solid state hybrid drives ("SSHD"), solid state drives ("SSD"), PCIe cards and SATA controllers. Its storage technology portfolio also includes storage subsystems, high performance computing ("HPC") solutions, and data storage services.

- changed (2016-10-28):
[0001193125-16-751593:note_history:11]
The Company's products are designed for mission critical and nearline applications in enterprise servers and storage systems; client compute applications, where our products are designed primarily for desktop and mobile computing; and client non-compute applications, where our products are designed for a wide variety of end user devices such as digital video recorders ("DVRs"), personal data backup systems, portable external storage systems, digital media systems and surveillance systems.
  (was, 2016-04-29, similarity 0.8195):
[0001104659-16-116201:note_history:11]
The Company's products are designed for enterprise servers and storage systems in mission critical and nearline applications; client compute applications, where its products are designed primarily for desktop and mobile computing; and client non-compute applications, where its products are designed for a wide variety of end user devices such as digital video recorders ("DVRs"), personal data backup systems, portable external storage systems, digital media systems and surveillance systems.

- added (2016-10-28):
[0001193125-16-751593:note_history:12]
The Company's Cloud Systems and Solutions builds on the Seagate legacy to extend innovation from the device into the information infrastructure, onsite and in the cloud. Our portfolio includes HPC storage solutions, modular original equipment manufacturers ("OEM") storage systems and scale-out storage systems.

- changed (2016-10-28):
[0001193125-16-751593:note_history:13]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income, cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature. Certain prior period amounts in the condensed consolidated financial statements and notes to the condensed consolidated financial statements have been reclassified to conform to the current period’s presentation.
  (was, 2016-04-29, similarity 0.9969):
[0001104659-16-116201:note_history:13]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income (loss), cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature. Certain prior period amounts in the condensed consolidated financial statements and notes to the condensed consolidated financial statements have been reclassified to conform to the current period’s presentation.

- added (2016-10-28):
[0001193125-16-751593:note_history:14]
The results of operations for the three months ended September 30, 2016, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending June 30, 2017. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three months ended September 30, 2016 and the three months ended October 2, 2015 consisted of 13 weeks. Fiscal year 2017 will be comprised of 52 weeks and will end on June 30, 2017. The fiscal quarters ended September 30, 2016, July 1, 2016, and October 2, 2015, are also referred to herein as the “September 2016 quarter”, the “June 2016 quarter”, and the “September 2015 quarter”, respectively.

- added (2016-10-28):
[0001193125-16-751593:note_history:15]
In May 2014, August 2015, April 2016 and May 2016, the Financial Accounting Standards Board ("FASB") issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, and ASU 2016-12 (ASC Topic 606) Revenue from Contracts with Customers, Narrow-Scope Improvements and Practical Expedients, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The amendments in these ASUs are effective for fiscal years, and interim periods within those years, beginning after December 15, 2017. Early adoption is permitted for annual periods beginning after December 15, 2016. This standard may be applied retrospectively to all prior periods presented, or retrospectively with a cumulative adjustment to retained earnings in the year of adoption ("modified retrospective transition approach"). The Company is in the process of assessing the impact, if any, on its condensed consolidated financial statements and plans to adopt the modified retrospective transition approach.

- changed (2016-10-28):
[0001193125-16-751593:note_history:16]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. The amendments in this ASU are effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company is in the process of assessing the impact, if any, of this ASU on its condensed consolidated financial statements.
  (was, 2016-04-29, similarity 0.9913):
[0001104659-16-116201:note_history:16]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. The amendments in this ASU are effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company is in the process of assessing the impact, if any, of this ASU on its consolidated financial statements.

- changed (2016-10-28):
[0001193125-16-751593:note_history:17]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments - Overall Recognition and Measurement of Financial Assets and Financial Liabilities. The amendments in this ASU require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The amendments in this ASU are effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. Early adoption is permitted for only certain portions of the ASU. The Company is in the process of assessing the impact, if any, on its condensed consolidated financial statements.
  (was, 2016-04-29, similarity 0.995):
[0001104659-16-116201:note_history:17]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments- Overall Recognition and Measurement of Financial Assets and Financial Liabilities. The amendments in this ASU require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The amendments in this ASU are effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. Early adoption is permitted for only certain portions of the ASU. The Company is in the process of assessing the impact, if any, on its consolidated financial statements.

- changed (2016-10-28):
[0001193125-16-751593:note_history:18]
In February 2016, the FASB issued ASU 2016-02 (ASC Topic 842), Leases. The ASU amends a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The amendments in this ASU are effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted.  The Company is in the process of assessing the impact on its condensed consolidated financial statements.
  (was, 2016-04-29, similarity 0.9918):
[0001104659-16-116201:note_history:18]
In February 2016, the FASB issued ASU 2016-02 (ASC Topic 842), Leases.  The ASU amends a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The amendments in this ASU are effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted.  The Company is in the process of assessing the impact on its consolidated financial statements.

- changed (2016-10-28):
[0001193125-16-751593:note_history:19]
In March 2016, the FASB issued ASU 2016-09 (ASC Topic 718), Stock Compensation - Improvements to Employee Share-Based Payment Accounting. The amendments in this ASU are intended to simplify several areas of accounting for share-based compensation arrangements, including the income tax consequences, classification on the consolidated statement of cash flows and treatment of forfeitures. The amendments in this ASU are effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted. The Company is in the process of assessing the impact, if any, of this ASU on its condensed consolidated financial statements.
  (was, 2016-04-29, similarity 0.991):
[0001104659-16-116201:note_history:19]
In March 2016, the FASB issued ASU 2016-09 (ASC Topic 718), Stock Compensation  - Improvements to Employee Share-Based Payment Accounting. The amendments in this ASU are intended to simplify several areas of accounting for share based compensation arrangements, including the income tax consequences, classification on the consolidated statement of cash flows and treatment of forfeitures.  The amendments in this ASU are effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted.  The Company is in the process of assessing the impact, if any, of this ASU on its consolidated financial statements.

- added (2016-10-28):
[0001193125-16-751593:note_history:20]
In August 2016, the FASB issued ASU 2016-15 (ASC Topic 230), Statement of Cash Flows - Classification of Certain Cash Receipts and Cash Payments. The amendments in this ASU are intended to clarify how certain cash receipts and cash payment are presented and classified in the statement of cash flows. The amendments in this ASU are effective for annual periods beginning after December 15, 2017, and interim periods within those annual periods. Early adoption is permitted. The Company is in the process of assessing the impact, if any, of this ASU on its condensed consolidated financial statements.

- added (2016-10-28):
[0001193125-16-751593:note_history:21]
Recently Adopted Accounting Pronouncements

- changed (2016-10-28):
[0001193125-16-751593:note_history:22]
In April 2015 and August 2015, the FASB issued ASU 2015-03 (ASC Subtopic 835-30), Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs and ASU 2015-15 (ASC Subtopic 835-30), Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements- Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting, respectively. The ASUs require that debt issuance costs related to a recognized debt liability, with the exception of those related to line-of-credit arrangements, be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability.  ASU 2015-03 became effective and was adopted by the Company in the September 2016 quarter on a retrospective basis. The adoption of this guidance resulted in a reduction to Other assets, net and Long-term debt by 38 million and 39 million, within the Condensed Consolidated Balance Sheet as of September 30, 2016 and the Consolidated Balance Sheet as of July 1, 2016, respectively. ASU 2015-15 became effective and was adopted by the Company in the September 2016 quarter on a prospective basis with no material impact on the Company’s condensed consolidated financial statements and disclosures.
  (was, 2016-04-29, similarity 0.7049):
[0001104659-16-116201:note_history:22]
In April 2015 and August 2015, the FASB issued ASU 2015-03 (ASC Subtopic 835-30), Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs and ASU 2015-15 (ASC Subtopic 835-30), Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements- Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting, respectively. The ASUs require that debt issuance costs related to a recognized debt liability, with the exception of those related to line-of-credit arrangements, be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability. The amendments in these ASUs are effective for fiscal years, and interim periods within those years, beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued. The adoption of this new guidance is not expected to have a material impact on the Company’s consolidated financial statements and disclosures.

- changed (2016-10-28):
[0001193125-16-751593:note_history:23]
In September 2015, the FASB issued ASU 2015-16 (ASC Topic 805), Business Combinations Simplifying the Accounting for Measurement-Period Adjustments. The amendments in this update require that an acquirer recognize measurement period adjustments in the period in which the adjustments are determined. The income effects of such measurement period adjustments are to be recorded in the same period’s financial statements but calculated as if the accounting had been completed as of the acquisition date. The impact of measurement period adjustments to earnings that relate to prior period financial statements are to be presented separately on the income statement or disclosed by line item. The amendments in this update are for fiscal years, including interim periods within those fiscal years, beginning after December 15, 2015. This ASU became effective and was adopted by the Company in the September 2016 quarter on a prospective basis with no material impact on the Company’s condensed consolidated financial statements and disclosures.
  (was, 2016-04-29, similarity 0.8558):
[0001104659-16-116201:note_history:23]
In September 2015, the FASB issued ASU 2015-16 (ASC Topic 805), Business Combinations Simplifying the Accounting for Measurement-Period Adjustments. The amendments in this update require that an acquirer recognize measurement period adjustments in the period in which the adjustments are determined. The income effects of such measurement period adjustments are to be recorded in the same period’s financial statements but calculated as if the accounting had been completed as of the acquisition date. The impact of measurement period adjustments to earnings that relate to prior period financial statements are to be presented separately on the income statement or disclosed by line item. The amendments in this update are for fiscal years, including interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted for public business entities for reporting periods for which financial statements have not yet been issued. The adoption of this new guidance is not expected to have a material impact on the Company’s consolidated financial statements and disclosures.

- removed (2016-10-28):
[0001104659-16-116201:note_history:24]
The Company's product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and HPC data storage solutions. Its storage subsystems support a range of high-speed interconnect technologies to meet demanding cost and performance specifications. Its modular subsystem architecture allows it to support many segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.

- removed (2016-10-28):
[0001104659-16-116201:note_history:25]
The results of operations for the three and nine months ended April 1, 2016, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending July 1, 2016. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three and nine months ended April 1, 2016 consisted of 13 weeks and 39 weeks, respectively. The three and nine months ended April 3, 2015 consisted of 13 weeks and 40 weeks, respectively.  Fiscal year 2016 will be comprised of 52 weeks and will end on July 1, 2016. The fiscal quarters ended April 1, 2016, January 1, 2016, and April 3, 2015, are also referred to herein as the “March 2016 quarter”, the “December 2015 quarter”, and the “March 2015 quarter”, respectively.

- removed (2016-10-28):
[0001104659-16-116201:note_history:26]
In May 2014, August 2015, and April 2016, the FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, and ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The amendments in these ASUs are effective for fiscal years, and interim periods within those years, beginning after December 15, 2017. Early adoption is permitted for annual periods beginning after December 15, 2016. The Company is in the process of assessing the impact, if any, on its consolidated financial statements.

- removed (2016-10-28):
[0001104659-16-116201:note_history:27]
In November 2015, the FASB issued ASU 2015-17 (ASC Topic 740), Income Taxes Balance Sheet Classification of Deferred Taxes. The amendments in this Update are effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company early adopted this ASU for the December 2015 quarter on a prospective basis. See footnote 4 for disclosure of the financial statement impact of this adoption.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-10-28):
[0001193125-16-751593:note_history:28]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio.  On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to allow for higher net leverage levels. The Company was in compliance with the modified covenants as of September 30, 2016 and expects to be in compliance for the next 12 months.
  (was, 2016-04-29, similarity 0.6592):
[0001104659-16-116201:note_history:28]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio.  On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to adjust for our current financial liquidity position.  We were in compliance with the modified covenants as of April 1, 2016 and expect to be in compliance for the next 12 months.

- changed (2016-10-28):
[0001193125-16-751593:note_history:29]
As of September 30, 2016, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.
  (was, 2016-04-29, similarity 0.9558):
[0001104659-16-116201:note_history:29]
As of April 1, 2016, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

- changed (2016-10-28):
[0001193125-16-751593:note_history:30]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2016-04-29, similarity 0.6492):
[0001104659-16-116201:note_history:30]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2016 quarter, the Company repurchased $10 million aggregate principal amount of its 2034 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded a gain on the repurchase of approximately $3 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

- added (2016-10-28):
[0001193125-16-751593:note_history:31]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2016-10-28):
[0001193125-16-751593:note_history:32]
At September 30, 2016, future principal payments on long-term debt were as follows (in millions):
  (was, 2016-04-29, similarity 0.9438):
[0001104659-16-116201:note_history:32]
At April 1, 2016, future principal payments on long-term debt were as follows (in millions):

- changed (2016-10-28):
[0001193125-16-751593:note_history:33]
| Fiscal Year | Amount |
| Remainder of 2017 | $ | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| 2020 | — |  |
| 2021 | — |  |
| Thereafter | 3,333 |  |
|  | $ | 4,133 |  |
  (was, 2016-04-29, similarity 0.9853):
[0001104659-16-116201:note_history:33]
| Fiscal Year | Amount |
| Remainder of 2016 | $ | — |  |
| 2017 | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| 2020 | — |  |
| Thereafter | 3,333 |  |
|  | $ | 4,133 |  |

- removed (2016-10-28):
[0001104659-16-116201:note_history:34]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, which commenced on December 1, 2015. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-10-28):
[0001193125-16-751593:note_history:35]
|  |  | September 30, 2016 |  | July 1, 2016 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 800 |  |  | $ | 823 |  |  | $ | 800 |  |  | $ | 804 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 163 |  |  | 158 |  |  | 164 |  |
| 4.75% Senior Notes due June 2023 |  | 990 |  |  | 975 |  |  | 990 |  |  | 857 |  |
| 4.75% Senior Notes due January 2025 |  | 995 |  |  | 951 |  |  | 995 |  |  | 795 |  |
| 4.875% Senior Notes due June 2027 |  | 698 |  |  | 626 |  |  | 698 |  |  | 514 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 410 |  |  | 489 |  |  | 357 |  |
|  |  | $ | 4,130 |  |  | $ | 3,948 |  |  | $ | 4,130 |  |  | $ | 3,491 |  |
| Less: debt issuance costs |  | (38 | ) |  | — |  |  | (39 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 4,092 |  |  | $ | 3,948 |  |  | $ | 4,091 |  |  | $ | 3,491 |  |
| Less: short-term borrowings and current portion of long-term debt |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 4,092 |  |  | $ | 3,948 |  |  | $ | 4,091 |  |  | $ | 3,491 |  |

- removed (2016-10-28):
[0001104659-16-116201:note_history:36]
|  |  | April 1, 2016 |  | July 3, 2015 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 800 |  |  | $ | 804 |  |  | $ | 800 |  |  | $ | 828 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 164 |  |  | 158 |  |  | 170 |  |
| 4.75% Senior Notes due June 2023 |  | 990 |  |  | 826 |  |  | 1,000 |  |  | 1,016 |  |
| 4.75% Senior Notes due January 2025 |  | 995 |  |  | 787 |  |  | 1,000 |  |  | 995 |  |
| 4.875% Senior Notes due June 2027 |  | 698 |  |  | 518 |  |  | 698 |  |  | 675 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 356 |  |  | 499 |  |  | 491 |  |
| Long-term debt |  | $ | 4,130 |  |  | $ | 3,455 |  |  | $ | 4,155 |  |  | $ | 4,175 |  |
| Less short-term borrowings and current portion of long-term debt |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 4,130 |  |  | $ | 3,455 |  |  | $ | 4,155 |  |  | $ | 4,175 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-10-28):
[0001193125-16-751593:note_history:37]
At September 30, 2016, future principal payments on long-term debt were as follows (in millions):
  (was, 2016-04-29, similarity 0.9438):
[0001104659-16-116201:note_history:37]
At April 1, 2016, future principal payments on long-term debt were as follows (in millions):

- changed (2016-10-28):
[0001193125-16-751593:note_history:38]
| Fiscal Year | Amount |
| Remainder of 2017 | $ | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| 2020 | — |  |
| 2021 | — |  |
| Thereafter | 3,333 |  |
|  | $ | 4,133 |  |
  (was, 2016-04-29, similarity 0.9853):
[0001104659-16-116201:note_history:38]
| Fiscal Year | Amount |
| Remainder of 2016 | $ | — |  |
| 2017 | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| 2020 | — |  |
| Thereafter | 3,333 |  |
|  | $ | 4,133 |  |
