# STX MD&A — 0001193125-18-317143


## mdna

[0001193125-18-317143:mdna:1]
[same as prior period, unchanged from 0001193125-18-146598:mdna:1]

[0001193125-18-317143:mdna:2]
The following is a discussion of the financial condition, changes in financial condition, and results of operations for our fiscal quarters ended
September 28, 2018, June 29, 2018 and September 29, 2017, referred to herein as the “September 2018 quarter,” the “June 2018 quarter,” and the “September 2017 quarter,” respectively. We operate and
report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The September 2018, June 2018 and September 2017 quarters were all 13 weeks.

[0001193125-18-317143:mdna:3]
You should read this discussion in conjunction with financial information and related notes included elsewhere in this report. Unless the context
indicates otherwise, as used herein, the terms “we,” “us,” “Seagate,” the “Company” and “our” refer to Seagate Technology plc, an Irish public limited company, and its subsidiaries. References to
“$” are to United States dollars.

[0001193125-18-317143:mdna:4]
|  | • |  | the uncertainty in global economic and political conditions; |

[0001193125-18-317143:mdna:5]
|  | • |  | the development and introduction of products based on new technologies and expansion into new data storage markets; |

[0001193125-18-317143:mdna:6]
|  | • |  | the impact of competitive product announcements and unexpected advances in competing technologies or changes in market trends; |

[0001193125-18-317143:mdna:7]
|  | • |  | the impact of variable demand and an adverse pricing environment for storage products; |

[0001193125-18-317143:mdna:8]
|  | • |  | any regulatory, legal, logistical or other impediments to the Company’s ability to execute on its restructuring efforts; |

[0001193125-18-317143:mdna:9]
|  | • |  | the Company’s ability to achieve projected cost savings in connection with its restructuring plans and consolidation of its manufacturing activities; |

[0001193125-18-317143:mdna:10]
|  | • |  | the Company’s ability to effectively manage its debt obligations and comply with certain covenants in its credit facilities with respect to financial ratios and financial condition tests and maintain a favorable cash liquidity position; |

[0001193125-18-317143:mdna:11]
|  | • |  | the Company’s ability to successfully qualify, manufacture and sell its storage products, particularly the new disk drive products with lower cost structures, in increasing volumes on a cost-effective basis and with acceptable quality; |

[0001193125-18-317143:mdna:12]
|  | • |  | possible excess industry supply both with respect to particular disk drive products and competing alternative storage technology solutions; |

[0001193125-18-317143:mdna:13]
|  | • |  | disruptions to the Company’s supply chain or production capabilities; |

[0001193125-18-317143:mdna:14]
|  | • |  | consolidation trends in the data storage industry; |

[0001193125-18-317143:mdna:15]
|  | • |  | fluctuations in interest rates; |

[0001193125-18-317143:mdna:16]
|  | • |  | currency fluctuations that may impact the Company’s margins, international sales and results of operations; |

[0001193125-18-317143:mdna:17]
|  | • |  | fluctuations in the value of the Company’s investments and the associated investment income; |

[0001193125-18-317143:mdna:18]
|  | • |  | the impact of trade barriers imposed by the U.S. government, such as import/export duties and restrictions, tariffs and quotas, and potential corresponding actions by other countries in which the Company conducts its business; |

[0001193125-18-317143:mdna:19]
|  | • |  | the evolving legal, regulatory and administrative climate in the international markets where the Company operates including changes in regulations relating to privacy and protection of data and environmental matters; and |

[0001193125-18-317143:mdna:20]
|  | • |  | cyber-attacks or other data breaches that disrupt the Company’s operations or result in the dissemination of proprietary or confidential information and cause reputational harm, and the cybersecurity threats and vulnerabilities associated with the Company’s infrastructure updates to its information technology systems. |

[0001193125-18-317143:mdna:21]
Our Management’s
Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is provided in addition to the accompanying condensed consolidated financial statements and notes to assist readers in understanding our results of
operations, financial condition, and cash flows. MD&A is organized as follows:

[0001193125-18-317143:mdna:22]
[same as prior period, unchanged from 0001193125-18-146598:mdna:6]

[0001193125-18-317143:mdna:23]
|  | • |  | Overview of the September 2018 quarter. Highlights of events in the September 2018 quarter that impacted our financial position. |

[0001193125-18-317143:mdna:24]
|  | • |  | Results of Operations. An analysis of our financial results comparing the September 2018 quarter to the June 2018 quarter and the September 2017 quarter. |

[0001193125-18-317143:mdna:25]
[same as prior period, unchanged from 0001193125-18-146598:mdna:9]

[0001193125-18-317143:mdna:26]
[same as prior period, unchanged from 0001193125-18-146598:mdna:11]

[0001193125-18-317143:mdna:27]
[same as prior period, unchanged from 0001193125-18-146598:mdna:12]

[0001193125-18-317143:mdna:28]
We are a leading provider of data storage technology and solutions. Our principal products are hard disk drives, commonly referred to as disk drives, hard
drives or HDDs. In addition to HDDs, we produce a broad range of data storage products including solid state drives (“SSD”) and storage subsystems.

[0001193125-18-317143:mdna:29]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary
medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and
most SSDs use NAND flash memory.

[0001193125-18-317143:mdna:30]
Our HDD products are designed for mission critical and nearline applications in enterprise servers and storage
systems; edge compute applications, where our products are designed primarily for desktop and mobile computing; and edge non-compute applications, where our products are designed for a wide variety of end
user devices such as portable external storage systems, surveillance systems, digital video recorders (“DVRs”), network-attached storage (“NAS”) and gaming consoles. Our SSD products mainly include serial attached SCSI
(“SAS”) and Non-Volatile Memory Express (“NVMe”) SSDs.

[0001193125-18-317143:mdna:31]
Our enterprise data solutions
(formerly referred to as the “cloud systems and solutions”) portfolio includes modular original equipment manufacturer (“OEM”) storage systems and scale-out storage servers.

[0001193125-18-317143:mdna:32]
Overview of the September 2018 Quarter

[0001193125-18-317143:mdna:33]
During the September
2018 quarter, we shipped 99 exabytes of HDD storage capacity. We generated revenue of approximately $3.0 billion, gross margin of 31% and our operating cash flow was $587 million. We paid $181 million in dividends and repurchased
3 million of our ordinary shares for $150 million.

[0001193125-18-317143:mdna:34]
[same as prior period, unchanged from 0001193125-18-146598:mdna:20]

[0001193125-18-317143:mdna:35]
We list in the tables below summarized information from our Condensed Consolidated Statements of Operations by dollars and as a percentage of revenue:

[0001193125-18-317143:mdna:36]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | September 28,2018 |  |  | June 29, 2018 |  |  | September 29,2017 |  |
| Revenue |  | $ | 2,991 |  |  | $ | 2,835 |  |  | $ | 2,632 |  |
| Cost of revenue |  |  | 2,078 |  |  |  | 1,931 |  |  |  | 1,896 |  |
| Gross margin |  |  | 913 |  |  |  | 904 |  |  |  | 736 |  |
| Product development |  |  | 266 |  |  |  | 259 |  |  |  | 263 |  |
| Marketing and administrative |  |  | 115 |  |  |  | 140 |  |  |  | 145 |  |
| Amortization of intangibles |  |  | 6 |  |  |  | 6 |  |  |  | 22 |  |
| Restructuring and other, net |  |  | 23 |  |  |  | (6 | ) |  |  | 51 |  |
| Income from operations |  |  | 503 |  |  |  | 505 |  |  |  | 255 |  |
| Other expense, net |  |  | (35 | ) |  |  | (39 | ) |  |  | (67 | ) |
| Income before income taxes |  |  | 468 |  |  |  | 466 |  |  |  | 188 |  |
| Provision for income taxes |  |  | 18 |  |  |  | 5 |  |  |  | 7 |  |
| Net income |  | $ | 450 |  |  | $ | 461 |  |  | $ | 181 |  |
|  |  | For the Three Months Ended |  |
|  |  | September 28,2018 |  |  | June 29,2018 |  |  | September 29,2017 |  |
| Revenue |  |  | 100% |  |  |  | 100% |  |  |  | 100% |  |
| Cost of revenue |  |  | 69 |  |  |  | 68 |  |  |  | 72 |  |
| Gross margin |  |  | 31 |  |  |  | 32 |  |  |  | 28 |  |
| Product development |  |  | 9 |  |  |  | 9 |  |  |  | 10 |  |
| Marketing and administrative |  |  | 4 |  |  |  | 5 |  |  |  | 6 |  |
| Amortization of intangibles |  |  | — |  |  |  | — |  |  |  | 1 |  |
| Restructuring and other, net |  |  | 1 |  |  |  | — |  |  |  | 2 |  |
| Income from operations |  |  | 17 |  |  |  | 18 |  |  |  | 10 |  |
| Other expense, net |  |  | (1) |  |  |  | (2) |  |  |  | (3) |  |
| Income before income taxes |  |  | 16 |  |  |  | 16 |  |  |  | 7 |  |
| Provision for income taxes |  |  | 1 |  |  |  | — |  |  |  | — |  |
| Net income |  |  | 15% |  |  |  | 16% |  |  |  | 7% |  |

[0001193125-18-317143:mdna:37]
[same as prior period, unchanged from 0001193125-18-146598:mdna:36]

[0001193125-18-317143:mdna:38]
[same as prior period, unchanged from 0001193125-18-146598:mdna:24]

[0001193125-18-317143:mdna:39]
The
following table summarizes information regarding consolidated revenues by channel and geography, HDD average drive selling prices (“ASPs”) and HDD exabytes shipped:

[0001193125-18-317143:mdna:40]
|  |  | For the Three Months Ended |
|  |  | September 28,2018 |  | June 29, 2018 |  | September 29,2017 |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  |  | 71 | % |  |  | 73 | % |  |  | 70 | % |
| Distributors |  |  | 18 | % |  |  | 17 | % |  |  | 16 | % |
| Retailers |  |  | 11 | % |  |  | 10 | % |  |  | 14 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  |  | 34 | % |  |  | 36 | % |  |  | 33 | % |
| EMEA |  |  | 17 | % |  |  | 15 | % |  |  | 18 | % |
| Asia Pacific |  |  | 49 | % |  |  | 49 | % |  |  | 49 | % |
| HDD ASPs (per unit) |  | $ | 70 |  |  | $ | 72 |  |  | $ | 64 |  |
| HDD Exabytes Shipped |  |  | 99 |  |  |  | 93 |  |  |  | 70 |  |

[0001193125-18-317143:mdna:41]
Revenue in the September 2018 quarter increased by $156 million from the June 2018 quarter as a result of an
increase in exabytes shipped driven primarily by higher seasonal demand for our client and consumer markets, partially offset by price erosion.

[0001193125-18-317143:mdna:42]
Revenue in the September 2018 quarter increased by $359 million from the September 2017 quarter as a result of an increase in exabytes shipped
driven primarily by higher demand for our enterprise and client markets, partially offset by price erosion.

[0001193125-18-317143:mdna:43]
We maintain various sales programs such
as channel rebates and price masking. Sales programs were approximately 11%, 12% and 11% of gross drive revenue for the September 2018 quarter, June 2018 quarter and September 2017 quarter, respectively. Adjustments to revenues due to under or over
accruals for sales programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001193125-18-317143:mdna:44]
Cost
of Revenue and Gross Margin

[0001193125-18-317143:mdna:45]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 28,2018 |  | June 29, 2018 |  | September 29,2017 |
| Cost of revenue |  | $ | 2,078 |  |  | $ | 1,931 |  |  | $ | 1,896 |  |
| Gross margin |  |  | 913 |  |  |  | 904 |  |  |  | 736 |  |
| Gross margin percentage |  |  | 31 | % |  |  | 32 | % |  |  | 28 | % |

[0001193125-18-317143:mdna:46]
Gross margin as a percentage of revenue for the September 2018 quarter decreased by approximately 100 basis points from
the June 2018 quarter primarily due to a decline in prices for NAND flash memory and general price erosion. Compared to the September 2017 quarter, gross margin as a percentage of revenue increased by 300 basis points primarily driven by favorable
product mix and improved factory utilization as a result of higher demand for our enterprise and client markets, partially offset by a decline in prices for NAND flash memory and general price erosion.

[0001193125-18-317143:mdna:47]
In the September 2018 quarter, total warranty cost was 0.7% of revenue and included a favorable change in estimates of prior warranty accruals of 0.5% of
revenue due to improvements in return rates on newer generation products. Warranty cost related to new shipments was 1.2%, 1.3% and 1.3% of revenue for the September 2018, June 2018 and September 2017 quarters, respectively.

[0001193125-18-317143:mdna:48]
32

[0001193125-18-317143:mdna:49]
[same as prior period, unchanged from 0001193125-18-146598:mdna:37]

[0001193125-18-317143:mdna:50]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | September 28,2018 |  |  | June 29, 2018 |  |  | September 29,2017 |  |
| Product development |  | $ | 266 |  |  | $ | 259 |  |  | $ | 263 |  |
| Marketing and administrative |  |  | 115 |  |  |  | 140 |  |  |  | 145 |  |
| Amortization of intangibles |  |  | 6 |  |  |  | 6 |  |  |  | 22 |  |
| Restructuring and other, net |  |  | 23 |  |  |  | (6 | ) |  |  | 51 |  |
| Operating expenses |  | $ | 410 |  |  | $ | 399 |  |  | $ | 481 |  |

[0001193125-18-317143:mdna:51]
Product development expense. Product development expense for the September 2018 quarter remained relatively
flat compared to the June 2018 quarter and the September 2017 quarter.

[0001193125-18-317143:mdna:52]
Marketing and administrative expense. Marketing and
administrative expense for the September 2018 quarter decreased by $25 million from the June 2018 quarter primarily due to a $13 million decrease in variable compensation and share-based compensation expenses, a $5 million decrease in
salaries and employee benefits as a result of the restructuring of our workforce in prior periods and a $7 million decrease in other general expenses due to related operational efficiencies.

[0001193125-18-317143:mdna:53]
Compared to the September 2017 quarter, Marketing and administrative expense decreased by $30 million primarily due to a $13 million decrease
in salaries and employee benefits as a result of the restructuring of our workforce in prior periods, a $9 million decrease in other general expenses due to related operational efficiencies and an $8 million decrease in variable
compensation and share-based compensation expenses.

[0001193125-18-317143:mdna:54]
Amortization of intangibles. Amortization of intangibles for the September 2018
quarter remained flat compared to the June 2018 quarter. Amortization of intangibles for the September 2018 quarter decreased by $16 million from the September 2017 quarter due to certain intangible assets reaching the end of their useful life.

[0001193125-18-317143:mdna:55]
Restructuring and other, net. Restructuring and other, net for the September 2018 quarter was comprised of charges primarily related to a
voluntary early exit program.

[0001193125-18-317143:mdna:56]
Restructuring and other, net for the June 2018 quarter included a gain of $24 million from the sale of certain
properties previously classified as held for sale, offset by restructuring charges announced in prior periods.

[0001193125-18-317143:mdna:57]
Restructuring and other, net for the
September 2017 quarter was comprised of restructuring charges to reduce our global workforce by 600 employees.

[0001193125-18-317143:mdna:58]
[same as prior period, unchanged from 0001193125-18-146598:mdna:48]

[0001193125-18-317143:mdna:59]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | September 28,2018 |  |  | June 29, 2018 |  |  | September 29,2017 |  |
| Other expense, net |  | $ | (35 | ) |  | $ | (39 | ) |  | $ | (67 | ) |

[0001193125-18-317143:mdna:60]
Other expense, net decreased by $4 million from the June 2018 quarter primarily due to an $11 million increase
in interest income on investment in a debt security, offset by a $5 million net increase in losses due to unfavorable changes in foreign currency exchange rates.

[0001193125-18-317143:mdna:61]
Compared to the September 2017 quarter, Other expense, net decreased by $32 million primarily due to a $16 million net increase in gains due to
favorable changes in foreign currency exchange rates and a $16 million increase in interest income on investment in a debt security.

[0001193125-18-317143:mdna:62]
[same as prior period, unchanged from 0001193125-18-146598:mdna:53]

[0001193125-18-317143:mdna:63]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | September 28,2018 |  |  | June 29, 2018 |  |  | September 29,2017 |  |
| Provision for income taxes |  | $ | 18 |  |  | $ | 5 |  |  | $ | 7 |  |

[0001193125-18-317143:mdna:64]
Our income tax provision of $18 million for the September 2018 quarter included approximately $1 million of net
discrete tax expense.

[0001193125-18-317143:mdna:65]
[same as prior period, unchanged from 0001193125-18-146598:mdna:60]

[0001193125-18-317143:mdna:66]
Our income tax provision recorded for the September 2018 quarter differed from the provision from
income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings
generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.

[0001193125-18-317143:mdna:67]
During the three months ended September 28, 2018 our unrecognized tax benefits excluding interest and penalties increased by approximately
$2 million to $62 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $62 million at September 28, 2018, subject to certain future valuation allowance reversals. During the 12
months beginning September 29, 2018, we expect that our unrecognized tax benefits could be reduced by approximately $19 million, primarily as a result of the expiration of certain statutes of limitation.

[0001193125-18-317143:mdna:68]
Our income tax provision of $7 million recorded for the September 2017 quarter included approximately $1 million of net discrete tax expense.

[0001193125-18-317143:mdna:69]
Our income tax provision recorded for the September 2017 quarter differed from the provision from income taxes that would be derived by applying the
Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax
holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.

[0001193125-18-317143:mdna:70]
On December 22, 2017, the Tax Act was enacted into law in the United States. The Tax Act significantly revises U.S. corporate income tax law by,
among other things, lowering U.S. corporate income tax rates from 35% to 21%, implementing a territorial tax system, and imposing a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries.

[0001193125-18-317143:mdna:71]
The U.S. tax law changes, including limitations on various business deductions such as
executive compensation under Internal Revenue Code §162(m), will not impact our tax expense in the short-term due to our large net operating loss and tax credit carryovers and associated valuation allowance. The Tax Act’s new international
rules, including Global Intangible Low-Taxed Income (“GILTI”), Foreign Derived Intangible Income (“FDII”), and Base Erosion Anti-Avoidance Tax (“BEAT”) are effective beginning in
fiscal year 2019. For fiscal year 2019, we have included these effects of the Tax Act in our financial statements and have concluded the impact will not be material.

[0001193125-18-317143:mdna:72]
Pursuant to SEC Staff Accounting Bulletin (“SAB”) 118 (regarding the application of ASC 740 associated with the enactment of the Tax Act), we
believe our accounting under ASC 740 for the provisions of the Tax Act is now complete.

[0001193125-18-317143:mdna:73]
[same as prior period, unchanged from 0001193125-18-146598:mdna:63]

[0001193125-18-317143:mdna:74]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our
cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist primarily of money market funds, time deposits and certificates of deposit. The
principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have restrictive
regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash have been and will continue to be sufficient to meet our cash needs for the next 12 months. We are not aware of any
downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term investments and we do not believe the fair value of our short-term investments has significantly changed from the values reported as of
September 28, 2018.

[0001193125-18-317143:mdna:75]
Cash and Cash Equivalents

[0001193125-18-317143:mdna:76]
| (Dollars in millions) |  | September 28,2018 |  |  | June 29, 2018 |  |  | Change |  |
| Cash and cash equivalents |  | $ | 1,942 |  |  | $ | 1,853 |  |  | $ | 89 |  |

[0001193125-18-317143:mdna:77]
Our cash and cash equivalents increased from June 29, 2018 as a result of an increase in the net cash provided by
operating activities, partially offset by net cash outflows for dividends paid to our shareholders of $181 million, capital expenditures of $177 million and repurchases of our ordinary shares of $150 million.

[0001193125-18-317143:mdna:78]
[same as prior period, unchanged from 0001193125-18-146598:mdna:68]

[0001193125-18-317143:mdna:79]
Cash provided by
operating activities for the three months ended September 28, 2018 was $587 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization,
share-based compensation and:

[0001193125-18-317143:mdna:80]
|  | • |  | an increase of $119 million in accounts payable, primarily due to higher material purchases; |

[0001193125-18-317143:mdna:81]
34

[0001193125-18-317143:mdna:82]
|  | • |  | partially offset by a decrease of $79 million in accrued employee compensation primarily due to cash paid to our employees as part of our variable compensation plans; and |

[0001193125-18-317143:mdna:83]
|  | • |  | an increase of $66 million in inventory, primarily due to an increase in units built. |

[0001193125-18-317143:mdna:84]
[same as prior period, unchanged from 0001193125-18-146598:mdna:74]

[0001193125-18-317143:mdna:85]
Cash used in investing
activities for the three months ended September 28, 2018 was $176 million, which was primarily attributable to the payments for the purchase of property, equipment and leasehold improvements of $177 million.

[0001193125-18-317143:mdna:86]
[same as prior period, unchanged from 0001193125-18-146598:mdna:76]

[0001193125-18-317143:mdna:87]
Cash used in financing
activities of $326 million for the three months ended September 28, 2018 was primarily attributable to the following activities:

[0001193125-18-317143:mdna:88]
|  | • |  | $181 million in dividend payments; |

[0001193125-18-317143:mdna:89]
|  | • |  | $150 million paid to repurchase ordinary shares; and |

[0001193125-18-317143:mdna:90]
|  | • |  | $27 million paid for taxes related to net share settlement of equity awards; |

[0001193125-18-317143:mdna:91]
|  | • |  | partially offset by $32 million in proceeds from the issuance of ordinary shares under employee stock plans. |

[0001193125-18-317143:mdna:92]
[same as prior period, unchanged from 0001193125-18-146598:mdna:83]

[0001193125-18-317143:mdna:93]
Our primary sources of liquidity as of September 28, 2018 consisted of: (1) approximately $1.9 billion in cash and cash equivalents,
(2) cash we expect to generate from operations and (3) a $700 million senior revolving credit facility.

[0001193125-18-317143:mdna:94]
As of September 28,
2018, no borrowings had been drawn under the revolving credit facility or had been utilized for letters of credit issued under this credit facility. The line of credit is available for borrowings, subject to compliance with financial covenants and
other customary conditions to borrowing.

[0001193125-18-317143:mdna:95]
The credit agreement that governs our revolving credit facility, as amended, includes three financial
covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. The term of the revolving credit facility is through January 15, 2020. We were in
compliance with the modified covenants as of September 28, 2018 and expect to be in compliance for the next 12 months.

[0001193125-18-317143:mdna:96]
Our liquidity
requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend and any future strategic
investments. Our ability to fund these requirements will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other
factors, some of which are beyond our control.

[0001193125-18-317143:mdna:97]
For fiscal year 2019, we expect capital expenditures to remain below our long-term targeted range of
6% to 8% of revenue.

[0001193125-18-317143:mdna:98]
From time to time we may repurchase any of our outstanding notes in open market or privately negotiated purchases or otherwise,
or we may repurchase outstanding notes pursuant to the terms of the applicable indenture.

[0001193125-18-317143:mdna:99]
Dividends declared in the September 2018 quarter of
$180 million were subsequently paid on October 3, 2018. The Company’s Board of Directors declared a quarterly cash dividend of $0.63 per share on November 2, 2018, which is payable on January 2, 2019 to shareholders of
record at the close of business on December 19, 2018.

[0001193125-18-317143:mdna:100]
From time to time we may repurchase any of our outstanding ordinary shares through
private, open market, tender offers broker-assisted purchases or other means. As of September 28, 2018, $0.7 billion remained available for repurchase under our existing repurchase authorization limit. All repurchases are effected as
redemptions in accordance with the Company’s Articles of Association. On October 29, 2018, the Board of Directors authorized the repurchase of an additional $2.3 billion of our outstanding ordinary shares.

[0001193125-18-317143:mdna:101]
[same as prior period, unchanged from 0001193125-18-146598:mdna:100]

[0001193125-18-317143:mdna:102]
Our discussion and analysis of financial condition and results of operations are based upon our condensed consolidated financial statements, which have
been prepared in accordance with U.S. generally accepted accounting principles. The preparation of such statements requires us to make estimates and assumptions that affect the reported amounts of revenues and expenses during the reporting period
and the reported amounts of assets and liabilities as of the date of the financial statements. Our estimates are based on historical experience and other assumptions that we consider to be appropriate in the circumstances. However, actual future
results may vary from our estimates.

[0001193125-18-317143:mdna:103]
Other than as described in Note 1. “Basis of Presentation and Summary of Significant Accounting
Policies” in the notes to the condensed consolidated financial statements, there have been no other material changes in our critical accounting policies and estimates. Refer to “Management’s Discussion and Analysis of Financial
Condition and Results of Operations” contained in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended June 29, 2018, as filed with the SEC on
August 3, 2018, for a discussion of our critical accounting policies and estimates.

[0001193125-18-317143:mdna:104]
[same as prior period, unchanged from 0001193125-18-146598:mdna:103]

[0001193125-18-317143:mdna:105]
See “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies”
for information regarding the effect of new accounting pronouncements on our financial statements.

[0001193125-18-317143:mdna:106]
36
