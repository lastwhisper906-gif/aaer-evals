# STX 10-Q controls and the auditor's report


## item_4_controls

[0001193125-18-317143:item_4_controls:1]
| ITEM 4. | CONTROLS AND PROCEDURES |

[0001193125-18-317143:item_4_controls:2]
As required by the Exchange Act Rule 13a-15, as of September 28, 2018 we carried out an evaluation under the
supervision and with the participation of our management, including our chief executive officer and chief financial officer, of the effectiveness of the design and operation of our disclosure controls and procedures as of the end of the period
covered by this Quarterly Report. Based on the evaluation, our management, including our chief executive officer and chief financial officer, concluded that our disclosure controls and procedures are effective as of September 28, 2018.

[0001193125-18-317143:item_4_controls:3]
In connection with our adoption of the new revenue recognition standard in the September 2018 quarter, we implemented internal controls to ensure that
the necessary revenue contracts, policies and process flows were reviewed to identify the impact of adoption. There were no significant changes to our internal control over financial reporting due to the adoption of the new revenue recognition
standard. During the quarter ended September 28, 2018, there were no other changes in our internal control over financial reporting that materially affected, or were reasonably likely to materially affect, our internal control over financial
reporting.

[0001193125-18-317143:item_4_controls:4]
38
