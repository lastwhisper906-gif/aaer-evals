# STX notes — 0001193125-18-317143


## invest:InvestmentTableTextBlock

[0001193125-18-317143:notes:1]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of June 29, 2018:

[0001193125-18-317143:notes:2]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 621 |  |  | $ | — |  |  | $ | 621 |  |
| Time deposits and certificates of deposit |  | 395 |  |  | — |  |  | 395 |  |
| Total |  | $ | 1,016 |  |  | $ | — |  |  | $ | 1,016 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 1,012 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 4 |  |
| Total |  |  |  |  |  |  |  | $ | 1,016 |  |

[0001193125-18-317143:notes:3]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of September 28, 2018:

[0001193125-18-317143:notes:4]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 801 |  |  | $ | — |  |  | $ | 801 |  |
| Time deposits and certificates of deposit |  | 428 |  |  | — |  |  | 428 |  |
| Total |  | $ | 1,229 |  |  | $ | — |  |  | $ | 1,229 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 1,226 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 3 |  |
| Total |  |  |  |  |  |  |  | $ | 1,229 |  |


## stx:ScheduleOfShareRepurchasesTableTextBlock

[0001193125-18-317143:notes:5]
The following table sets forth information with respect to repurchases of the Company’s shares during the three months ended September 28, 2018:

[0001193125-18-317143:notes:6]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Repurchases of ordinary shares |  | 3 |  |  | $ | 150 |  |
| Tax withholding related to vesting of equity awards |  | 1 |  |  | 27 |  |
| Total |  | 4 |  |  | $ | 177 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-18-317143:notes:7]
The Company's unaudited condensed consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

[0001193125-18-317143:notes:8]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income, cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature.

[0001193125-18-317143:notes:9]
The Company’s consolidated financial statements for the fiscal year ended June 29, 2018, are included in its Annual Report on Form 10-K as filed with the United States Securities and Exchange Commission (“SEC”) on August 3, 2018. The Company believes that the disclosures included in the unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of June 29, 2018, and the notes thereto, are adequate to make the information presented not misleading.


## us-gaap:DebtDisclosureTextBlock

[0001193125-18-317143:notes:10]
Debt

[0001193125-18-317143:notes:11]
Short-Term Borrowings

[0001193125-18-317143:notes:12]
The credit agreement entered into by the Company and its subsidiary Seagate HDD Cayman on January 18, 2011 and subsequently amended (the "Revolving Credit Facility") provides the Company with a $700 million senior secured revolving credit facility. The term of the Revolving Credit Facility is through January 15, 2020. The loans made under the Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing, and for the issuance of letters of credit up to a sub-limit of $75 million.

[0001193125-18-317143:notes:13]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio.   The Company was in compliance with the modified covenants as of September 28, 2018 and expects to be in compliance for the next 12 months.

[0001193125-18-317143:notes:14]
As of September 28, 2018, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

[0001193125-18-317143:notes:15]
Long-Term Debt

[0001193125-18-317143:notes:16]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2017 quarter, the Company repurchased $22 million aggregate principal amount of the 2018 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded an immaterial loss on the repurchase during the three months ended September 29, 2017, which is included in Other, net on the Compnay's Condensed Consolidated Statements of Operations. There were no repurchases during the three months ended September 28, 2018. The remainder of the 2018 Notes were classified as Current portion of long-term debt on the Company's Condensed Consolidated Balance Sheets at September 28, 2018 and June 29, 2018.

[0001193125-18-317143:notes:17]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-317143:notes:18]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-317143:notes:19]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”). The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-317143:notes:20]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-317143:notes:21]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-317143:notes:22]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-18-317143:notes:23]
At September 28, 2018, future principal payments on long-term debt were as follows (in millions):

[0001193125-18-317143:notes:24]
| Fiscal Year |  | Amount |
| Remainder of 2019 |  | $ | 499 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| 2022 |  | 750 |  |
| 2023 |  | 951 |  |
| Thereafter |  | 2,662 |  |
| Total |  | $ | 4,862 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-18-317143:notes:25]
[same as prior period, unchanged from 0001193125-18-146598:notes:35]

[0001193125-18-317143:notes:26]
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies. The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives in its Condensed Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The amount of net unrealized gain on cash flow hedges was $2 million as of September 28, 2018 and less than $1 million as of June 29, 2018.

[0001193125-18-317143:notes:27]
The Company de-designates its cash flow hedges when the forecasted hedged transactions affect earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss on the Company's Condensed Consolidated Balance Sheets are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company recognized a net gain of $1 million in Other expense, net related to the loss of hedge designation on discontinued cash flow hedges during the three months ended September 28, 2018. The Company did not recognize any net gains or losses related to the loss of hedge designation on discontinued cash flow hedges during the three months ended September 29, 2017.

[0001193125-18-317143:notes:28]
Other derivatives not designated as hedging instruments consist of foreign currency forward exchange contracts that the Company uses to hedge the foreign currency exposure on the investment in debt security and forecasted expenditures denominated in currency other than the U.S. dollar. The Company recognizes gains and losses on these contracts, as well as the related costs in Other, net on its Condensed Consolidated Statement of Operations along with foreign currency gains and losses on investment in debt security, and deferred gains of derivatives in Other current assets on the Condensed Consolidated Balance Sheets.

[0001193125-18-317143:notes:29]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of September 28, 2018 and June 29, 2018. All these foreign currency forward exchange contracts mature within 12 months.

[0001193125-18-317143:notes:30]
|  |  | As of September 28, 2018 |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| Thai Baht |  | $ | 37 |  |  | $ | 19 |  |
| Singapore Dollars |  | 50 |  |  | 25 |  |
| Chinese Renminbi |  | 30 |  |  | — |  |
| British Pound Sterling |  | 31 |  |  | 12 |  |
| Japanese Yen |  | 44 |  |  | 1,332 |  |
|  |  | $ | 192 |  |  | $ | 1,388 |  |

[0001193125-18-317143:notes:31]
|  |  | As of June 29, 2018 |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| Japanese Yen |  | $ | 66 |  |  | $ | 1,310 |  |

[0001193125-18-317143:notes:32]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plan—the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees. As of September 28, 2018, the notional investments underlying the TRS amounted to $120 million. The contract term of the TRS is through January 2019 and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001193125-18-317143:notes:33]
The following tables show the Company's derivative instruments measured at gross fair value as reflected in its Condensed Consolidated Balance Sheet as of September 28, 2018 and June 29, 2018:

[0001193125-18-317143:notes:34]
|  |  | As of September 28, 2018 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 4 |  |  | Accrued expenses |  | $ | (1 | ) |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 50 |  |  | Accrued expenses |  | — |  |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 54 |  |  |  |  | $ | (1 | ) |

[0001193125-18-317143:notes:35]
|  |  | As of June 29, 2018 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 10 |  |  | Accrued expenses |  | — |  |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 10 |  |  |  |  | $ | — |  |

[0001193125-18-317143:notes:36]
The following tables show the effect of the Company’s derivative instruments on its Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three months ended September 28, 2018:

[0001193125-18-317143:notes:37]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 41 |  |
| Total return swap |  | Operating expenses |  | $ | 4 |  |

[0001193125-18-317143:notes:38]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount ofGain (Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGain (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
| Foreign currency forward exchange contracts |  | $ | 3 |  |  | Other expense, net |  | $ | 1 |  |  | Other expense, net |  | $ | — |  |

[0001193125-18-317143:notes:39]
As of September 29, 2017, the Company had no outstanding foreign currency forward exchange contracts and the gross fair value of the TRS reflected in the Condensed Consolidated Balance Sheet was immaterial.

[0001193125-18-317143:notes:40]
The following table shows the effect of the Company's derivative instruments on its Condensed Consolidated Statement of Operations for the three months ended September 29, 2017:

[0001193125-18-317143:notes:41]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | — |  |
| Total return swap |  | Operating expenses |  | $ | 3 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001193125-18-317143:notes:42]
The following table provides information about disaggregated revenue by sales channel and geographical region for the Company’s single reportable segment:

[0001193125-18-317143:notes:43]
|  |  | For the Three Months Ended |
| (Dollars in million) |  | September 28, 2018 |  | September 29, 2017 |
| Revenues by Channel |  |  |  |  |  |
| OEMs |  | $ | 2,138 |  |  | $ | 1,834 |  |
| Distributors |  | 534 |  |  | 434 |  |
| Retailers |  | 319 |  |  | 364 |  |
| Total |  | $ | 2,991 |  |  | $ | 2,632 |  |
| Revenues by Geography(1) |  |  |  |  |
| Americas |  | $ | 1,006 |  |  | $ | 875 |  |
| EMEA |  | 517 |  |  | 472 |  |
| Asia Pacific |  | 1,468 |  |  | 1,285 |  |
| Total |  | $ | 2,991 |  |  | $ | 2,632 |  |

[0001193125-18-317143:notes:44]
(1) Revenue is attributed to countries based on bill from locations.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-18-317143:notes:45]
[same as prior period, unchanged from 0001193125-18-146598:notes:48]

[0001193125-18-317143:notes:46]
The Company recorded approximately $18 million and $32 million of share-based compensation expense during the three months ended September 28, 2018 and September 29, 2017, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001193125-18-317143:notes:47]
[same as prior period, unchanged from 0001193125-18-146598:notes:50]

[0001193125-18-317143:notes:48]
[same as prior period, unchanged from 0001193125-18-146598:notes:51]

[0001193125-18-317143:notes:49]
|  |  | For the Three Months Ended |
| (In millions, except per share data) |  | September 28, 2018 |  | September 29, 2017 |
| Numerator: |  |  |  |  |  |  |
| Net income |  | $ | 450 |  |  | $ | 181 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 287 |  |  | 290 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |
| Employee equity award plans |  | 5 |  |  | 2 |  |
| Total shares for purpose of calculating diluted net income per share |  | 292 |  |  | 292 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 1.57 |  |  | $ | 0.62 |  |
| Diluted |  | $ | 1.54 |  |  | $ | 0.62 |  |

[0001193125-18-317143:notes:50]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share were less than 1 million for the three months ended September 28, 2018, and approximately 2 million for the three months ended September 29, 2017.


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001193125-18-317143:notes:51]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 801 |  |  | $ | 425 |  |  | $ | — |  |  | $ | 1,226 |  |
| Other current assets |  | — |  |  | 57 |  |  | — |  |  | 57 |  |
| Total assets |  | $ | 801 |  |  | $ | 482 |  |  | $ | — |  |  | $ | 1,283 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |
| Total liabilities |  | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |

[0001193125-18-317143:notes:52]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 620 |  |  | $ | 392 |  |  | $ | — |  |  | $ | 1,012 |  |
| Other current assets |  | 1 |  |  | 13 |  |  | — |  |  | 14 |  |
| Total assets |  | $ | 621 |  |  | $ | 405 |  |  | $ | — |  |  | $ | 1,026 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-18-317143:notes:53]
[same as prior period, unchanged from 0001193125-18-146598:notes:56]

[0001193125-18-317143:notes:54]
[same as prior period, unchanged from 0001193125-18-146598:notes:57]

[0001193125-18-317143:notes:55]
[same as prior period, unchanged from 0001193125-18-146598:notes:58]

[0001193125-18-317143:notes:56]
[same as prior period, unchanged from 0001193125-18-146598:notes:59]

[0001193125-18-317143:notes:57]
[same as prior period, unchanged from 0001193125-18-146598:notes:60]

[0001193125-18-317143:notes:58]
[same as prior period, unchanged from 0001193125-18-146598:notes:61]

[0001193125-18-317143:notes:59]
[same as prior period, unchanged from 0001193125-18-146598:notes:62]

[0001193125-18-317143:notes:60]
[same as prior period, unchanged from 0001193125-18-146598:notes:63]

[0001193125-18-317143:notes:61]
[same as prior period, unchanged from 0001193125-18-146598:notes:64]

[0001193125-18-317143:notes:62]
[same as prior period, unchanged from 0001193125-18-146598:notes:65]

[0001193125-18-317143:notes:63]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of September 28, 2018:

[0001193125-18-317143:notes:64]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 801 |  |  | $ | — |  |  | $ | — |  |  | $ | 801 |  |
| Time deposits and certificates of deposit |  | — |  |  | 425 |  |  | — |  |  | 425 |  |
| Total cash equivalents |  | 801 |  |  | 425 |  |  | — |  |  | 1,226 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | — |  |  | — |  |  | — |  |  | — |  |
| Time deposits and certificates of deposit |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Derivative Assets |  | — |  |  | 54 |  |  | — |  |  | 54 |  |
| Total assets |  | $ | 801 |  |  | $ | 482 |  |  | $ | — |  |  | $ | 1,283 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |
| Total liabilities |  | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |

[0001193125-18-317143:notes:65]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of June 29, 2018:

[0001193125-18-317143:notes:66]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 620 |  |  | $ | — |  |  | $ | — |  |  | $ | 620 |  |
| Time deposits and certificates of deposit |  | — |  |  | 392 |  |  | — |  |  | 392 |  |
| Total cash equivalents |  | 620 |  |  | 392 |  |  | — |  |  | 1,012 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Derivative assets |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Total assets |  | $ | 621 |  |  | $ | 405 |  |  | $ | — |  |  | $ | 1,026 |  |

[0001193125-18-317143:notes:67]
[same as prior period, unchanged from 0001193125-18-146598:notes:70]

[0001193125-18-317143:notes:68]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair value of all of its cash equivalents and short-term investments. For the cash equivalents and short-term investments in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry standard data providers or other third party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of September 28, 2018, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts and the TRS. The Company recognizes derivative financial instruments in its condensed consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001193125-18-317143:notes:69]
As of September 28, 2018 and June 29, 2018, the Company had no Level 3 assets or liabilities measured at fair value on a recurring basis.

[0001193125-18-317143:notes:70]
[same as prior period, unchanged from 0001193125-18-146598:notes:73]

[0001193125-18-317143:notes:71]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments primarily include cost basis investments representing those where the Company does not have the ability to exercise significant influence as well as equity method investments representing those where the Company does have the ability to exercise significant influence but does not have control. These investments are included in Other assets, net in the Company's Condensed Consolidated Balance Sheets, and are periodically analyzed to determine whether or not there are indicators of impairment.

[0001193125-18-317143:notes:72]
Prior to fiscal year 2019, the Company’s strategic investments in privately-held companies without readily determinable fair values were accounted for under the cost method and were recorded at historical cost at the time of investment, with adjustments to the balance only in the event of impairment. Effective June 30, 2018, the Company adopted ASU 2016-01, Financial Instruments, which changed the way the Company accounts for equity investments, excluding investments that qualify for the equity method of accounting. The Company's equity investments in privately-held companies without readily determinable fair values are now measured using the measurement alternative, defined by ASC 321, Investments - Equity Securities, as cost, less impairments, and adjusted up or down based on observable price changes in orderly transactions for identical or similar investments of the same issuer. Any adjustments resulting from impairments and/or observable price changes are recorded as Other, net in the Company's Condensed Consolidated Statements of Operations.

[0001193125-18-317143:notes:73]
As of September 28, 2018 and June 29, 2018, the carrying value of the Company’s strategic investments were $107 million and $118 million, respectively. For the three months ended September 28, 2018 and September 29, 2017, the Company did not have any equity investments accounted for under the cost method that were other-than-temporarily impaired and did not record any impairment charges. There were no upward or downward adjustments on equity investments as a result of adoption of measurement alternative during the September 2018 quarter.

[0001193125-18-317143:notes:74]
As of September 28, 2018 and June 29, 2018, the Company had $26 million of held for sale land and building (collectively, the "property") in Asia included in Other current assets on its Condensed Consolidated Balance Sheets. The respective property to be sold met the criteria to be classified as held for sale at the end of fiscal year 2017. During the September 2018 quarter, the Company accepted an offer to sell the property to a third party. The sale is expected to be completed by the end of fiscal year 2019, subject to government approval and customary closing conditions. No impairment was identified for the three months ended September 28, 2018 and September 29, 2017.

[0001193125-18-317143:notes:75]
[same as prior period, unchanged from 0001193125-18-146598:notes:77]

[0001193125-18-317143:notes:76]
The Company’s investment in a debt security, classified as held-to-maturity, represents shares of non-convertible preferred stock of TMC. This debt security has a maturity date of six years starting from May 31, 2018 and is classified as Investment in debt security on the Company’s Condensed Consolidated Balance Sheets. The debt security is recorded at amortized cost and its fair value approximated the carrying value at June 29, 2018. As of September 28, 2018, the fair value of this investment was $1,289 million with an unrealized gain of $30 million on the carrying value of $1,259 million. The fair value was determined utilizing Level 2 inputs such as discount rates and yield terms of similar types of securities issued by comparable companies.

[0001193125-18-317143:notes:77]
The Company’s debt is carried at amortized cost. The estimated fair value of the Company’s debt is derived using the closing price of the same debt instruments as of the date of valuation, which takes into account the yield curve, interest rates and other observable inputs. Accordingly, these fair value measurements are categorized as Level 2. The following table presents the fair value and amortized cost of the Company’s debt in order of maturity:

[0001193125-18-317143:notes:78]
|  |  | September 28, 2018 |  | June 29, 2018 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 499 |  |  | $ | 500 |  |  | $ | 499 |  |  | $ | 501 |  |
| 4.25% Senior Notes due March 2022 |  | 749 |  |  | 746 |  |  | 749 |  |  | 743 |  |
| 4.75% Senior Notes due June 2023 |  | 951 |  |  | 950 |  |  | 951 |  |  | 942 |  |
| 4.875% Senior Notes due March 2024 |  | 497 |  |  | 492 |  |  | 497 |  |  | 489 |  |
| 4.75% Senior Notes due January 2025 |  | 975 |  |  | 937 |  |  | 975 |  |  | 936 |  |
| 4.875% Senior Notes due June 2027 |  | 695 |  |  | 655 |  |  | 695 |  |  | 650 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 443 |  |  | 489 |  |  | 441 |  |
|  |  | $ | 4,855 |  |  | $ | 4,723 |  |  | $ | 4,855 |  |  | $ | 4,702 |  |
| Less: debt issuance costs |  | (34 | ) |  | — |  |  | (36 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 4,821 |  |  | $ | 4,723 |  |  | $ | 4,819 |  |  | $ | 4,702 |  |
| Less: current portion of long-term debt, net of debt issuance costs |  | (499 | ) |  | (500 | ) |  | (499 | ) |  | (501 | ) |
| Long-term debt, less current portion |  | $ | 4,322 |  |  | $ | 4,223 |  |  | $ | 4,320 |  |  | $ | 4,201 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-18-317143:notes:79]
[same as prior period, unchanged from 0001193125-18-146598:notes:80]

[0001193125-18-317143:notes:80]
[same as prior period, unchanged from 0001193125-18-146598:notes:81]

[0001193125-18-317143:notes:81]
The changes in the carrying amount of goodwill for the three months ended September 28, 2018, are as follows:

[0001193125-18-317143:notes:82]
| (Dollars in millions) |  | Amount |
| Balance at June 29, 2018 |  | $ | 1,237 |  |
| Goodwill acquired |  | — |  |
| Goodwill disposed |  | — |  |
| Foreign currency translation effect |  | — |  |
| Balance at September 28, 2018 |  | $ | 1,237 |  |

[0001193125-18-317143:notes:83]
[same as prior period, unchanged from 0001193125-18-146598:notes:84]

[0001193125-18-317143:notes:84]
Other intangible assets consist primarily of existing technology, customer relationships and trade names acquired in business combinations. Intangibles are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization is charged to Operating expenses in the Company's Condensed Consolidated Statements of Operations.

[0001193125-18-317143:notes:85]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of September 28, 2018, is set forth in the following table:

[0001193125-18-317143:notes:86]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted-AverageRemaining Useful Life |
| Existing technology |  | $ | 256 |  |  | $ | (158 | ) |  | $ | 98 |  |  | 2.3 years |
| Customer relationships |  | 89 |  |  | (46 | ) |  | 43 |  |  | 3.8 years |
| Trade name |  | 17 |  |  | (14 | ) |  | 3 |  |  | 1.1 years |
| Other intangible assets |  | 45 |  |  | (20 | ) |  | 25 |  |  | 3.0 years |
| Total amortizable other intangible assets |  | $ | 407 |  |  | $ | (238 | ) |  | $ | 169 |  |  | 2.8 years |

[0001193125-18-317143:notes:87]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of June 29, 2018, is set forth in the following table:

[0001193125-18-317143:notes:88]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted-AverageRemaining Useful Life |
| Existing technology |  | $ | 256 |  |  | $ | (145 | ) |  | $ | 111 |  |  | 2.5 years |
| Customer relationships |  | 89 |  |  | (42 | ) |  | 47 |  |  | 4.0 years |
| Trade name |  | 17 |  |  | (13 | ) |  | 4 |  |  | 1.3 years |
| Other intangible assets |  | 45 |  |  | (19 | ) |  | 26 |  |  | 3.0 years |
| Total amortizable other intangible assets |  | $ | 407 |  |  | $ | (219 | ) |  | $ | 188 |  |  | 2.9 years |

[0001193125-18-317143:notes:89]
For the three months ended September 28, 2018 and September 29, 2017, the amortization expense of other intangible assets were $19 million and $36 million, respectively. As of September 28, 2018, expected amortization expense for other intangible assets for each of the next five fiscal years and thereafter is as follows:

[0001193125-18-317143:notes:90]
| (Dollars in millions) |  | Amount |
| Remainder of 2019 |  | $ | 58 |  |
| 2020 |  | 57 |  |
| 2021 |  | 29 |  |
| 2022 |  | 20 |  |
| 2023 |  | 5 |  |
| Thereafter |  | — |  |
| Total |  | $ | 169 |  |


## us-gaap:HeldToMaturitySecuritiesTextBlock

[0001193125-18-317143:notes:91]
As of September 28, 2018 and June 29, 2018, the Company had approximately $1.3 billion investment in non-convertible preferred stock of Toshiba Memory Corporation ("TMC", formerly known as "K.K. Pangea"). The investment, with a contractual maturity of six years starting from May 31, 2018, is accounted for as a held-to-maturity debt security, carried at cost and adjusted for amortization of transaction costs into interest income. Additionally, the debt security has a contractual payment-in-kind ("PIK") income which will be paid in cash upon redemption of the investment. PIK income computed at the contractual rate is accrued into Interest income in the Company's Condensed Consolidated Statement of Operations and added to the carrying value of the Investment in debt security on its Condensed Consolidated Balance Sheets. For the three months ended September 28, 2018, the PIK income earned was $16 million. No impairment was identified as of September 28, 2018 and June 29, 2018. Please refer to Note 8 - Fair Value for more details.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-18-317143:notes:92]
[same as prior period, unchanged from 0001193125-18-146598:notes:92]

[0001193125-18-317143:notes:93]
The Company's income tax provision of $18 million in the three months ended September 28, 2018 included approximately $1 million of net discrete tax expense.

[0001193125-18-317143:notes:94]
The Company's income tax provision recorded for the three months ended September 28, 2018 differed from the provision  from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.

[0001193125-18-317143:notes:95]
During the three months ended September 28, 2018, the Company’s unrecognized tax benefits excluding interest and penalties increased by approximately $2 million to $62 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $62 million at September 28, 2018, subject to certain future valuation allowance reversals. During the twelve months beginning September 29, 2018, the Company expects that its unrecognized tax benefits could be reduced by approximately $19 million, primarily as a result of the expiration of certain statutes of limitation.

[0001193125-18-317143:notes:96]
The Company's income tax provision of $7 million in the three months ended September 29, 2017 included approximately $1 million of net discrete tax expense.

[0001193125-18-317143:notes:97]
The Company’s income tax provision recorded for the three months ended September 29, 2017 differed from the provision from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax  incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.

[0001193125-18-317143:notes:98]
On December 22, 2017, the Tax Act was enacted into law in the United States. The Tax Act significantly revises U.S. corporate income tax law by, among other things, lowering U.S. corporate income tax rates from 35% to 21%, implementing a territorial tax system, and imposing a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries.

[0001193125-18-317143:notes:99]
The U.S. tax law changes, including limitations on various business deductions such as executive compensation under Internal Revenue Code §162(m), will not impact the Company’s tax expense in the short-term due to the Company's large net operating loss and tax credit carryovers and associated valuation allowance. The Tax Act’s new international rules, including Global Intangible Low-Taxed Income (“GILTI”), Foreign Derived Intangible Income (“FDII”), and Base Erosion Anti-Avoidance Tax (“BEAT”) are effective beginning in fiscal year 2019. For fiscal year 2019, the Company has included these effects of the Tax Act in its  financial statements and concluded the impact will not be material.

[0001193125-18-317143:notes:100]
Pursuant to SEC Staff Accounting Bulletin (“SAB”) 118 (regarding the application of ASC 740, Income Taxes ("ASC 740") associated with the enactment of the Tax Act), the Company believes its accounting under ASC 740 for the provisions of the Tax Act is now complete.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-18-317143:notes:101]
The fair value and amortized cost of the Company’s debt securities investments classified as available-for-sale as of September 28, 2018, by remaining contractual maturity were as follows:

[0001193125-18-317143:notes:102]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 1,229 |  |  | $ | 1,229 |  |
| Due in 1 to 5 years |  | — |  |  | — |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | — |  |  | — |  |
| Total |  | $ | 1,229 |  |  | $ | 1,229 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001193125-18-317143:notes:103]
Legal, Environmental and Other Contingencies

[0001193125-18-317143:notes:104]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001193125-18-317143:notes:105]
Intellectual Property Litigation

[0001193125-18-317143:notes:106]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al. On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “‘635 patent”) and U.S. Patent No. 5,638,267 (the “‘267 patent”), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants were infringing U.S. Patent No. 6,314,473 (the “‘473 patent”). The district court ruled in 2010 that the ‘267 patent was out of the case.

[0001193125-18-317143:notes:107]
On August 16, 2011, the district court granted in part and denied in part the Company’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-18-317143:notes:108]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017.  No trial date has been set. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.

[0001193125-18-317143:notes:109]
Environmental Matters

[0001193125-18-317143:notes:110]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001193125-18-317143:notes:111]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001193125-18-317143:notes:112]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001193125-18-317143:notes:113]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001193125-18-317143:notes:114]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001193125-18-317143:notes:115]
Other Matters

[0001193125-18-317143:notes:116]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-18-317143:notes:117]
Recently Issued Accounting Pronouncements

[0001193125-18-317143:notes:118]
In February 2016 and July 2018, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") 2016-02 (ASC Topic 842), Leases ASU 2018-10, Codification Improvements to Topic 842, and Leases, ASU 2018-11, Leases (ASC Topic 842), Target improvements, respectively. These ASUs amend a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The Company plans to adopt this guidance in the first quarter of fiscal year 2020. The Company is in the process of assessing the impact of these ASUs on its condensed consolidated financial statements.

[0001193125-18-317143:notes:119]
In June 2016, the FASB issued ASU 2016-13 (ASC Topic 326), Financial Instruments - Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held. The Company is required to adopt this guidance in the first quarter of fiscal year 2021. Early adoption is permitted in the first quarter of fiscal year 2020. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-18-317143:notes:120]
In February 2018, the FASB issued ASU 2018-02 (ASC Topic 220), Income Statement—Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 (the "Tax Act") and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. The Company is required to adopt this guidance in the first quarter of fiscal year 2020.  Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-18-317143:notes:121]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles - Goodwill and Other - Internal-Use Software - Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company is required to adopt the guidance in the first quarter of fiscal year 2021.  Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001193125-18-317143:notes:122]
Recently Adopted Accounting Pronouncements

[0001193125-18-317143:notes:123]
In May 2014, the FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, and FASB also issued certain interpretive clarifications on this new guidance which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes the revenue recognition guidance under ASC 605. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. This ASU became effective and was adopted by the Company in the September 2018 quarter retrospectively with a cumulative adjustment to accumulated deficit at the date of adoption ("modified retrospective transition approach"). The Company has completed the adoption and implemented policies, processes and controls to support the new standard’s measurement and disclosure requirements.

[0001193125-18-317143:notes:124]
The Company applied the ASC 606 using a modified retrospective transition approach to all contracts that were not completed as of June 29, 2018. Results for reporting periods beginning June 30, 2018 are presented under ASC 606, while prior period amounts were not adjusted and continue to be reported under the historical accounting standard. As a result of the adoption, the Company identified a change in revenue recognition timing on its product sales made to certain retail customers and started to recognize revenue when the Company transfers control to the applicable customers rather than deferring recognition until those customers sell the products. In addition, the Company established accruals for the variable consideration related to customer incentives on these arrangements. On the date of initial adoption, the Company removed the related deferred income on the product sales made to these customers and recorded estimates of the accrual for variable consideration through a cumulative adjustment to accumulated deficit. The cumulative effect of the change to the Company's Condensed Consolidated Balance Sheet from the adoption of ASC 606 was as follows:

[0001193125-18-317143:notes:125]
| (Dollars in millions) |  | As of June 29, 2018 |  | Effect of adoption of ASC 606 |  | As of June 30, 2018 |
| Accounts receivable, net |  | $ | 1,184 |  |  | $ | 9 |  |  | $ | 1,193 |  |
| Inventory |  | $ | 1,053 |  |  | $ | (9 | ) |  | $ | 1,044 |  |
| Accrued expenses |  | $ | 598 |  |  | $ | (34 | ) |  | $ | 564 |  |
| Accumulated deficit |  | $ | (4,696 | ) |  | $ | 34 |  |  | $ | (4,662 | ) |

[0001193125-18-317143:notes:126]
The impact of applying the new accounting standard on the Company's condensed consolidated financial statements for the September 2018 quarter was not material.

[0001193125-18-317143:notes:127]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments—Overall Recognition and Measurement of Financial Assets and Financial Liabilities, as amended by ASU 2018-03, Financial Instruments—Overall: Technical Correction and Improvements, issued in February 2018. The amendments in these ASUs require entities to measure all equity investments at fair value with changes recognized through net income. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. These ASUs became effective and were adopted by the Company in the September 2018 quarter. For equity investments without readily determinable fair value, the Company elected the measurement alternative for measurement of equity investments, defined as cost, less impairments, if any, plus or minus changes resulting from observable price changes in orderly transactions for an identical or similar investment in the same issuer until the equity investments' fair value becomes readily determinable. The adoption of this guidance had no impact on the Company's condensed consolidated financial statements and disclosures.

[0001193125-18-317143:notes:128]
In January 2017, the FASB issued ASU 2017-01 (ASC Topic 805), Business Combination: Clarifying the Definition of a Business. The amendments in this ASU change the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company adopted the guidance in the September 2018 quarter. The adoption of this guidance had no impact on the Company's condensed consolidated financial statements and disclosures.

[0001193125-18-317143:notes:129]
In May 2017, the FASB issued ASU 2017-09 (ASC Topic 718), Stock Compensation: Scope of Modification Accounting. The amendments in this ASU provide guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting. The Company adopted the guidance in the September 2018 quarter. The adoption of this guidance had no impact on its condensed consolidated financial statements and disclosures.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001193125-18-317143:notes:130]
[same as prior period, unchanged from 0001193125-18-146598:notes:130]

[0001193125-18-317143:notes:131]
[same as prior period, unchanged from 0001193125-18-146598:notes:131]

[0001193125-18-317143:notes:132]
Seagate Technology plc (the “Company”) is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”) and storage subsystems.

[0001193125-18-317143:notes:133]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory.

[0001193125-18-317143:notes:134]
The Company’s HDD products are designed for mission critical and nearline applications in enterprise servers and storage systems; edge compute applications, where its products are designed primarily for desktop and mobile computing; and edge non-compute applications, where its products are designed for a wide variety of end user devices such as portable external storage systems, surveillance systems, digital video recorders (“DVRs”), network-attached storage (“NAS”),  and gaming consoles. The Company's SSD products mainly include serial attached SCSI ("SAS") and Non-Volatile Memory Express ("NVMe") SSDs.

[0001193125-18-317143:notes:135]
The Company’s enterprise data solutions (formerly referred to as the "cloud systems and solutions") portfolio includes modular original equipment manufacturers (“OEM”) storage systems and scale-out storage servers.

[0001193125-18-317143:notes:136]
[same as prior period, unchanged from 0001193125-18-146598:notes:136]

[0001193125-18-317143:notes:137]
The results of operations for the three months ended September 28, 2018 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending June 28, 2019. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three months ended September 28, 2018 and the three months ended September 29, 2017 consisted of 13 weeks. Fiscal year 2019, which ends on June 28, 2019, and fiscal year 2018, which ended on June 29, 2018, are both comprised of 52 weeks. The fiscal quarters ended September 28, 2018, June 29, 2018, and September 29, 2017, are also referred to herein as the “September 2018 quarter ”, the “June 2018 quarter” and the “September 2017 quarter”, respectively.

[0001193125-18-317143:notes:138]
[same as prior period, unchanged from 0001193125-18-146598:notes:138]

[0001193125-18-317143:notes:139]
Except for the change in the Company's revenue recognition policy described below, there have been no material changes to the Company’s significant accounting policies disclosed in Note 1 - Basis of Presentation and Summary of Significant Accounting Policies of "Financial Statements and Supplementary Data" contained in Part II, Item 8 of the Company's Annual Report on Form 10-K for the fiscal year ended June 29, 2018, as filed with the SEC on August 3, 2018.

[0001193125-18-317143:notes:140]
Revenue Recognition

[0001193125-18-317143:notes:141]
Effective June 30, 2018, the Company adopted a new revenue recognition policy in accordance with Accounting Standard Codification ("ASC") 606, Revenue from Contracts with Customers, using the modified retrospective transition approach as discussed in the section titled Recently Adopted Accounting Pronouncements in this Note 1. Prior to fiscal year 2019, the revenue recognition policy was based on ASC 605, Revenue Recognition. Under ASC 606, the Company determines revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, the Company satisfies a performance obligation.

[0001193125-18-317143:notes:142]
Revenue from sales of products is generally recognized upon transfer of control to customers in an amount that reflects the consideration the Company expects to receive in exchange for those products, net of sales taxes. This typically occurs upon shipment from the Company. When applicable, the Company includes shipping charges billed to customers in Revenue and includes the related shipping costs in Cost of revenue on the Company's Condensed Consolidated Statements of Operations.

[0001193125-18-317143:notes:143]
The Company records estimated variable consideration at the time of revenue recognition as a reduction to net revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer’s volume of purchases from Seagate or other agreed upon rebate programs. For the distribution and retailing channel, these programs typically involve estimating the most likely amount of rebates related to a customer’s level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Marketing development program costs are accrued and recorded as a reduction to revenue at the same time that the related revenue is recognized.

[0001193125-18-317143:notes:144]
Practical Expedient and Exemptions

[0001193125-18-317143:notes:145]
The Company elected a practical expedient to expense sales commissions when the commissions are incurred because the amortization period would have been one year or less. These costs are recorded as Marketing and administrative on the Company's Condensed Consolidated Statements of Operations.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-18-317143:notes:146]
[same as prior period, unchanged from 0001193125-18-146598:notes:140]

[0001193125-18-317143:notes:147]
Indemnifications of Officers and Directors

[0001193125-18-317143:notes:148]
[same as prior period, unchanged from 0001193125-18-146598:notes:142]

[0001193125-18-317143:notes:149]
On July 3, 2010, pursuant to a corporate reorganization, the common shareholders of Seagate-Cayman became ordinary shareholders  of  the Company and Seagate-Cayman became a wholly owned subsidiary of the Company, as described more fully in the Current Report on Form 8-K filed by the Company on July 6, 2010 (the “Redomestication”). On July 27, 2010, in connection with the Redomestication, the Company, as sole shareholder of Seagate-Cayman, approved a form of deed of indemnity (the “Deed of Indemnity”), which provides for the indemnification by Seagate-Cayman of any director, officer, employee or agent of the Company, Seagate-Cayman or any subsidiary of the Company (each, a “Deed Indemnitee”), in addition to any indemnification rights of a Deed Indemnitee under the Company’s Articles of Association, applicable law or otherwise, with a similar scope to the Revised Indemnification Agreement. Seagate-Cayman entered into Deeds of Indemnity with certain Deed Indemnitees effective as of July 3, 2010 and continues to enter into Deeds of Indemnity with additional Deed Indemnitees from time to time.

[0001193125-18-317143:notes:150]
The nature of these indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay on behalf of its officers and directors. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the Company’s consolidated financial statements with respect to these indemnification obligations.

[0001193125-18-317143:notes:151]
[same as prior period, unchanged from 0001193125-18-146598:notes:145]

[0001193125-18-317143:notes:152]
The Company has entered into agreements with customers and suppliers that include limited intellectual property indemnification obligations that are customary in the industry. These guarantees generally require the Company to compensate the other party for certain damages and costs incurred as a result of third party intellectual property claims arising from these transactions. The nature of the intellectual property indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay to its customers and suppliers. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the Company's condensed consolidated financial statements with respect to these indemnification obligations.

[0001193125-18-317143:notes:153]
[same as prior period, unchanged from 0001193125-18-146598:notes:147]

[0001193125-18-317143:notes:154]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the three months ended September 28, 2018 and September 29, 2017 were as follows:

[0001193125-18-317143:notes:155]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 28, 2018 |  | September 29, 2017 |
| Balance, beginning of period |  | $ | 237 |  |  | $ | 233 |  |
| Warranties issued |  | 34 |  |  | 35 |  |
| Repairs and replacements |  | (25 | ) |  | (27 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | (14 | ) |  | (11 | ) |
| Balance, end of period |  | $ | 232 |  |  | $ | 230 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-18-317143:notes:156]
[same as prior period, unchanged from 0001193125-18-146598:notes:150]

[0001193125-18-317143:notes:157]
| (Dollars in millions) |  | September 28, 2018 |  | June 29, 2018 |
| Property, equipment and leasehold improvements |  | $ | 9,586 |  |  | $ | 9,525 |  |
| Accumulated depreciation and amortization |  | (7,797 | ) |  | (7,733 | ) |
| Property, equipment and leasehold improvements, net |  | $ | 1,789 |  |  | $ | 1,792 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-18-317143:notes:158]
[same as prior period, unchanged from 0001193125-18-146598:notes:152]

[0001193125-18-317143:notes:159]
For the three months ended September 28, 2018 and September 29, 2017, the Company recorded restructuring charges of approximately $23 million and $51 million, respectively, comprised primarily of charges related to workforce reduction costs and facilities and other exit costs associated with the restructuring of its workforce. The Company's significant restructuring plans are described below. All restructuring charges are reported in Restructuring and other, net on the Company's Condensed Consolidated Statements of Operations.

[0001193125-18-317143:notes:160]
December 2017 Plan - On December 8, 2017, the Company committed to a restructuring plan (the “December 2017 Plan”) to reduce its cost structure. The December 2017 Plan included reducing the Company's global headcount by approximately 500 employees. The December 2017 Plan was substantially completed by the end of fiscal year 2018.

[0001193125-18-317143:notes:161]
July 2017 Plan - On July 25, 2017, the Company committed to a restructuring plan (the “July 2017 Plan”) to reduce its cost structure. The July 2017 Plan included reducing the Company’s global headcount by approximately 600 employees. The July 2017 Plan was substantially completed during fiscal year 2018.

[0001193125-18-317143:notes:162]
March 2017 Plan - On March 9, 2017, the Company committed to a restructuring plan (the “March 2017 Plan”) in connection with the continued consolidation of its global footprint. The Company closed its design center in Korea, resulting in the reduction of the Company’s headcount by approximately 300 employees. The March 2017 Plan was substantially completed by the end of fiscal year 2017.

[0001193125-18-317143:notes:163]
July 2016 Plan - On July 11, 2016, the Company committed to a restructuring plan (the “July 2016 Plan”) for continued consolidation of its global footprint across Asia, EMEA and the Americas. The July 2016 Plan included reducing worldwide headcount by approximately 6,500 employees. The July 2016 Plan was substantially completed during fiscal year 2018.

[0001193125-18-317143:notes:164]
The following table summarizes the Company’s restructuring activities under all of the Company’s active restructuring plans for the three months ended September 28, 2018:

[0001193125-18-317143:notes:165]
|  |  | December 2017 Plan |  | July 2017 Plan |  | March 2017 Plan |  | July 2016 Plan |  | Other Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at June 29, 2018 |  | $ | 5 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 11 |  |  | $ | 18 |  |  | $ | 42 |  |
| Restructuring charges |  | — |  |  | 1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | 19 |  |  | 2 |  |  | 24 |  |
| Cash payments |  | (4 | ) |  | (2 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |  | (10 | ) |  | (2 | ) |  | (20 | ) |
| Adjustments |  | — |  |  | (1 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (1 | ) |
| Accrual balances at September 28, 2018 |  | $ | 1 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 20 |  |  | $ | 18 |  |  | $ | 45 |  |
| Total costs incurred to date as of September 28, 2018 |  | $ | 26 |  |  | $ | 6 |  |  | $ | 37 |  |  | $ | 4 |  |  | $ | 31 |  |  | $ | 3 |  |  | $ | 82 |  |  | $ | 36 |  |  | $ | 259 |  |  | $ | 61 |  |  | $ | 545 |  |
| Total expected charges to be incurred as of September 28, 2018 |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | 4 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-18-317143:notes:166]
Revenue


## us-gaap:ScheduleOfAccountsPayableAndAccruedLiabilitiesTableTextBlock

[0001193125-18-317143:notes:167]
[same as prior period, unchanged from 0001193125-18-146598:notes:161]

[0001193125-18-317143:notes:168]
| (Dollars in millions) |  | September 28, 2018 |  | June 29, 2018 |
| Dividends payable |  | $ | 180 |  |  | $ | 181 |  |
| Other accrued expenses |  | 436 |  |  | 417 |  |
| Total accrued expenses |  | $ | 616 |  |  | $ | 598 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-18-317143:notes:169]
[same as prior period, unchanged from 0001193125-18-146598:notes:163]

[0001193125-18-317143:notes:170]
| (Dollars in millions) |  | Unrealized Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Available-for-Sale Debt Securities |  | Unrealized Gains (Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at June 29, 2018 |  | $ | — |  |  | $ | — |  |  | $ | (4 | ) |  | $ | (12 | ) |  | $ | (16 | ) |
| Other comprehensive income (loss) before reclassifications |  | 3 |  |  | — |  |  | — |  |  | 2 |  |  | 5 |  |
| Amounts reclassified from AOCI |  | (1 | ) |  | — |  |  | — |  |  | — |  |  | (1 | ) |
| Other comprehensive income (loss) |  | 2 |  |  | — |  |  | — |  |  | 2 |  |  | 4 |  |
| Balance at September 28, 2018 |  | $ | 2 |  |  | $ | — |  |  | $ | (4 | ) |  | $ | (10 | ) |  | $ | (12 | ) |
| Balance at June 30, 2017 |  | $ | — |  |  | $ | — |  |  | $ | (5 | ) |  | $ | (12 | ) |  | $ | (17 | ) |
| Other comprehensive income (loss) before reclassifications |  | — |  |  | — |  |  | — |  |  | 4 |  |  | 4 |  |
| Amounts reclassified from AOCI |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) |  | — |  |  | — |  |  | — |  |  | 4 |  |  | 4 |  |
| Balance at September 29, 2017 |  | $ | — |  |  | $ | — |  |  | $ | (5 | ) |  | $ | (8 | ) |  | $ | (13 | ) |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-18-317143:notes:171]
[same as prior period, unchanged from 0001193125-18-146598:notes:165]

[0001193125-18-317143:notes:172]
| (Dollars in millions) |  | September 28, 2018 |  | June 29, 2018 |
| Raw materials and components |  | $ | 325 |  |  | $ | 329 |  |
| Work-in-process |  | 375 |  |  | 347 |  |
| Finished goods |  | 416 |  |  | 377 |  |
| Total inventories |  | $ | 1,116 |  |  | $ | 1,053 |  |


## us-gaap:ScheduleOfRestrictedCashAndCashEquivalentsTextBlock

[0001193125-18-317143:notes:173]
The following table provides a summary of cash, cash equivalents and restricted cash reported within the Company's Condensed Consolidated Balance Sheets that reconciles to the corresponding amount in its Condensed Consolidated Statements of Cash Flows:

[0001193125-18-317143:notes:174]
| (Dollars in millions) |  | September 28, 2018 |  | June 29, 2018 |  | September 29, 2017 |  | June 30, 2017 |
| Cash and cash equivalents |  | $ | 1,942 |  |  | $ | 1,853 |  |  | $ | 2,285 |  |  | $ | 2,539 |  |
| Restricted cash included in Other current assets |  | 3 |  |  | 4 |  |  | 4 |  |  | 4 |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  | $ | 1,945 |  |  | $ | 1,857 |  |  | $ | 2,289 |  |  | $ | 2,543 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-18-317143:notes:175]
[same as prior period, unchanged from 0001193125-18-146598:notes:169]

[0001193125-18-317143:notes:176]
[same as prior period, unchanged from 0001193125-18-146598:notes:170]

[0001193125-18-317143:notes:177]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 286,127,032 shares were outstanding as of September 28, 2018, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of September 28, 2018.

[0001193125-18-317143:notes:178]
[same as prior period, unchanged from 0001193125-18-146598:notes:172]

[0001193125-18-317143:notes:179]
Preferred shares—The Company may issue preferred shares in one or more series, up to the authorized amount, without shareholder approval. The Board of Directors is authorized to establish from time to time the number of shares to be included in each series, and to fix the rights, preferences and privileges of the shares of each wholly unissued series and any of its qualifications, limitations or restrictions. The Board of Directors can also increase or decrease the number of shares of a series, but not below the number of shares of that series then outstanding, without any further vote or action by the shareholders.

[0001193125-18-317143:notes:180]
[same as prior period, unchanged from 0001193125-18-146598:notes:174]

[0001193125-18-317143:notes:181]
[same as prior period, unchanged from 0001193125-18-146598:notes:175]

[0001193125-18-317143:notes:182]
[same as prior period, unchanged from 0001193125-18-146598:notes:177]

[0001193125-18-317143:notes:183]
As of September 28, 2018, $0.7 billion remained available for repurchase under the existing repurchase authorization limit.


## us-gaap:SubsequentEventsTextBlock

[0001193125-18-317143:notes:184]
Subsequent Events

[0001193125-18-317143:notes:185]
Dividend Declared

[0001193125-18-317143:notes:186]
On November 2, 2018, the Company’s Board of Directors declared a quarterly cash dividend of $0.63 per share, which will be payable on January 2, 2019 to shareholders of record as of the close of business on December 19, 2018.

[0001193125-18-317143:notes:187]
Share Repurchases

[0001193125-18-317143:notes:188]
On October 29, 2018, the Company's Board of Directors authorized the repurchase of $2.3 billion of its outstanding ordinary shares.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-18-317143:notes:189]
[same as prior period, unchanged from 0001193125-18-146598:notes:182]

[0001193125-18-317143:notes:190]
Available-for-sale Debt Securities

[0001193125-18-317143:notes:191]
As of September 28, 2018, the Company’s Other current assets included $3 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001193125-18-317143:notes:192]
As of September 28, 2018, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale debt securities were other-than-temporarily impaired as of September 28, 2018.

[0001193125-18-317143:notes:193]
As of June 29, 2018, the Company’s Other current assets included $4 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001193125-18-317143:notes:194]
As of June 29, 2018, the Company had no material available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale securities were other-than-temporarily impaired as of June 29, 2018.

[0001193125-18-317143:notes:195]
Cash, Cash Equivalents and Restricted Cash

[0001193125-18-317143:notes:196]
[same as prior period, unchanged from 0001193125-18-146598:notes:189]

[0001193125-18-317143:notes:197]
[same as prior period, unchanged from 0001193125-18-146598:notes:190]

[0001193125-18-317143:notes:198]
Investment in Debt Security

[0001193125-18-317143:notes:199]
[same as prior period, unchanged from 0001193125-18-146598:notes:191]

[0001193125-18-317143:notes:200]
[same as prior period, unchanged from 0001193125-18-146598:notes:192]
