# STX note change history — 0001193125-18-146598 → 0001193125-18-317143


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0001193125-18-317143:note_history:1]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al. On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “‘635 patent”) and U.S. Patent No. 5,638,267 (the “‘267 patent”), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants were infringing U.S. Patent No. 6,314,473 (the “‘473 patent”). The district court ruled in 2010 that the ‘267 patent was out of the case.
  (was, 2018-05-01, similarity 0.9822):
[0001193125-18-146598:note_history:1]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al. On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “‘635 patent”) and U.S. Patent No. 5,638,267 (the “‘267 patent”), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe U.S. Patent No. 6,314,473 (the “‘473 patent”). The district court ruled in 2010 that the ‘267 patent was out of the case.

- changed (2018-11-02):
[0001193125-18-317143:note_history:2]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017.  No trial date has been set. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.
  (was, 2018-05-01, similarity 0.7486):
[0001193125-18-146598:note_history:2]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017.  No trial date has been set. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- changed (2018-11-02):
[0001193125-18-317143:note_history:3]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.
  (was, 2018-05-01, similarity 0.992):
[0001193125-18-146598:note_history:3]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

- removed (2018-11-02):
[0001193125-18-146598:note_history:4]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al. On June 5, 2013, Enova Technology Corporation (“Enova”) filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995 (the “‘995 patent”), “Cryptographic Device,” and U.S. Patent No. 7,900,057 (the “‘057 patent”), “Cryptographic Serial ATA Apparatus and Method.” The Company believes the claims are without merit and intends to vigorously defend this case. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the ‘995 and ‘057 patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ‘057 patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 patent are held unpatentable. Enova appealed PTAB’s decisions on the ‘995 patent and the ‘057 patent to the U.S. Court of Appeals for the Federal Circuit. On March 20, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the ‘995 patent. On September 6, 2017, the court of appeals issued its judgment affirming PTAB’s decision on the ‘057 patent. On November 27, 2017, Enova filed a petition for writ of certiorari with the U.S. Supreme Court challenging the court of appeals’ decision on the ‘057 Patent. The Supreme Court denied the petition on April 30, 2018. The district court case remains stayed. In light of the Supreme Court’s denial of the petition, the Company does not expect to incur a loss in this matter.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0001193125-18-317143:note_history:5]
Seagate Technology plc (the “Company”) is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”) and storage subsystems.
  (was, 2018-05-01, similarity 0.8857):
[0001193125-18-146598:note_history:5]
Seagate Technology plc (the “Company”) is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSD”) and their related controllers, solid state hybrid drives (“SSHD”) and storage subsystems.

- changed (2018-11-02):
[0001193125-18-317143:note_history:6]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory.
  (was, 2018-05-01, similarity 0.7668):
[0001193125-18-146598:note_history:6]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data with most SSDs using NAND-based flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed data.

- changed (2018-11-02):
[0001193125-18-317143:note_history:7]
The Company’s HDD products are designed for mission critical and nearline applications in enterprise servers and storage systems; edge compute applications, where its products are designed primarily for desktop and mobile computing; and edge non-compute applications, where its products are designed for a wide variety of end user devices such as portable external storage systems, surveillance systems, digital video recorders (“DVRs”), network-attached storage (“NAS”),  and gaming consoles. The Company's SSD products mainly include serial attached SCSI ("SAS") and Non-Volatile Memory Express ("NVMe") SSDs.
  (was, 2018-05-01, similarity 0.7665):
[0001193125-18-146598:note_history:7]
The Company’s products are designed for mission critical and nearline applications in enterprise servers and storage systems; edge compute / client compute applications, where its products are designed primarily for desktop and mobile computing; and edge non-compute / client non-compute applications, where its products are designed for a wide variety of end user devices such as portable external storage systems, surveillance systems, network-attached storage (“NAS”), digital video recorders (“DVRs”) and gaming consoles.

- added (2018-11-02):
[0001193125-18-317143:note_history:8]
The Company’s enterprise data solutions (formerly referred to as the "cloud systems and solutions") portfolio includes modular original equipment manufacturers (“OEM”) storage systems and scale-out storage servers.

- added (2018-11-02):
[0001193125-18-317143:note_history:9]
The Company's unaudited condensed consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

- changed (2018-11-02):
[0001193125-18-317143:note_history:10]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income, cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature.
  (was, 2018-05-01, similarity 0.8946):
[0001193125-18-146598:note_history:10]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income, cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature. Certain prior period amounts in the condensed consolidated financial statements and notes to the condensed consolidated financial statements have been reclassified to conform to the current period's presentation.

- added (2018-11-02):
[0001193125-18-317143:note_history:11]
The results of operations for the three months ended September 28, 2018 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending June 28, 2019. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three months ended September 28, 2018 and the three months ended September 29, 2017 consisted of 13 weeks. Fiscal year 2019, which ends on June 28, 2019, and fiscal year 2018, which ended on June 29, 2018, are both comprised of 52 weeks. The fiscal quarters ended September 28, 2018, June 29, 2018, and September 29, 2017, are also referred to herein as the “September 2018 quarter ”, the “June 2018 quarter” and the “September 2017 quarter”, respectively.

- added (2018-11-02):
[0001193125-18-317143:note_history:12]
Except for the change in the Company's revenue recognition policy described below, there have been no material changes to the Company’s significant accounting policies disclosed in Note 1 - Basis of Presentation and Summary of Significant Accounting Policies of "Financial Statements and Supplementary Data" contained in Part II, Item 8 of the Company's Annual Report on Form 10-K for the fiscal year ended June 29, 2018, as filed with the SEC on August 3, 2018.

- added (2018-11-02):
[0001193125-18-317143:note_history:13]
Revenue Recognition

- added (2018-11-02):
[0001193125-18-317143:note_history:14]
Effective June 30, 2018, the Company adopted a new revenue recognition policy in accordance with Accounting Standard Codification ("ASC") 606, Revenue from Contracts with Customers, using the modified retrospective transition approach as discussed in the section titled Recently Adopted Accounting Pronouncements in this Note 1. Prior to fiscal year 2019, the revenue recognition policy was based on ASC 605, Revenue Recognition. Under ASC 606, the Company determines revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, the Company satisfies a performance obligation.

- added (2018-11-02):
[0001193125-18-317143:note_history:15]
Revenue from sales of products is generally recognized upon transfer of control to customers in an amount that reflects the consideration the Company expects to receive in exchange for those products, net of sales taxes. This typically occurs upon shipment from the Company. When applicable, the Company includes shipping charges billed to customers in Revenue and includes the related shipping costs in Cost of revenue on the Company's Condensed Consolidated Statements of Operations.

- added (2018-11-02):
[0001193125-18-317143:note_history:16]
The Company records estimated variable consideration at the time of revenue recognition as a reduction to net revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer’s volume of purchases from Seagate or other agreed upon rebate programs. For the distribution and retailing channel, these programs typically involve estimating the most likely amount of rebates related to a customer’s level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Marketing development program costs are accrued and recorded as a reduction to revenue at the same time that the related revenue is recognized.

- added (2018-11-02):
[0001193125-18-317143:note_history:17]
Practical Expedient and Exemptions

- added (2018-11-02):
[0001193125-18-317143:note_history:18]
The Company elected a practical expedient to expense sales commissions when the commissions are incurred because the amortization period would have been one year or less. These costs are recorded as Marketing and administrative on the Company's Condensed Consolidated Statements of Operations.

- added (2018-11-02):
[0001193125-18-317143:note_history:19]
In February 2016 and July 2018, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") 2016-02 (ASC Topic 842), Leases ASU 2018-10, Codification Improvements to Topic 842, and Leases, ASU 2018-11, Leases (ASC Topic 842), Target improvements, respectively. These ASUs amend a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The Company plans to adopt this guidance in the first quarter of fiscal year 2020. The Company is in the process of assessing the impact of these ASUs on its condensed consolidated financial statements.

- changed (2018-11-02):
[0001193125-18-317143:note_history:20]
In June 2016, the FASB issued ASU 2016-13 (ASC Topic 326), Financial Instruments - Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held. The Company is required to adopt this guidance in the first quarter of fiscal year 2021. Early adoption is permitted in the first quarter of fiscal year 2020. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.
  (was, 2018-05-01, similarity 0.9746):
[0001193125-18-146598:note_history:20]
In June 2016, the FASB issued ASU 2016-13 (ASC Topic 326), Financial Instruments - Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held. The Company is required to adopt this guidance in the first quarter of fiscal year 2021. Early adoption in the first quarter of fiscal year 2020 is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- changed (2018-11-02):
[0001193125-18-317143:note_history:21]
In February 2018, the FASB issued ASU 2018-02 (ASC Topic 220), Income Statement—Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 (the "Tax Act") and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. The Company is required to adopt this guidance in the first quarter of fiscal year 2020.  Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.
  (was, 2018-05-01, similarity 0.9919):
[0001193125-18-146598:note_history:21]
In February 2018, the FASB issued ASU 2018-02 (ASC Topic 220), Income Statement—Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 (the "Act") and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Act. The Company is required to adopt the guidance in the first quarter of fiscal year 2020.  Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- added (2018-11-02):
[0001193125-18-317143:note_history:22]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles - Goodwill and Other - Internal-Use Software - Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company is required to adopt the guidance in the first quarter of fiscal year 2021.  Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- added (2018-11-02):
[0001193125-18-317143:note_history:23]
In May 2014, the FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, and FASB also issued certain interpretive clarifications on this new guidance which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes the revenue recognition guidance under ASC 605. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. This ASU became effective and was adopted by the Company in the September 2018 quarter retrospectively with a cumulative adjustment to accumulated deficit at the date of adoption ("modified retrospective transition approach"). The Company has completed the adoption and implemented policies, processes and controls to support the new standard’s measurement and disclosure requirements.

- added (2018-11-02):
[0001193125-18-317143:note_history:24]
The Company applied the ASC 606 using a modified retrospective transition approach to all contracts that were not completed as of June 29, 2018. Results for reporting periods beginning June 30, 2018 are presented under ASC 606, while prior period amounts were not adjusted and continue to be reported under the historical accounting standard. As a result of the adoption, the Company identified a change in revenue recognition timing on its product sales made to certain retail customers and started to recognize revenue when the Company transfers control to the applicable customers rather than deferring recognition until those customers sell the products. In addition, the Company established accruals for the variable consideration related to customer incentives on these arrangements. On the date of initial adoption, the Company removed the related deferred income on the product sales made to these customers and recorded estimates of the accrual for variable consideration through a cumulative adjustment to accumulated deficit. The cumulative effect of the change to the Company's Condensed Consolidated Balance Sheet from the adoption of ASC 606 was as follows:

- added (2018-11-02):
[0001193125-18-317143:note_history:25]
| (Dollars in millions) |  | As of June 29, 2018 |  | Effect of adoption of ASC 606 |  | As of June 30, 2018 |
| Accounts receivable, net |  | $ | 1,184 |  |  | $ | 9 |  |  | $ | 1,193 |  |
| Inventory |  | $ | 1,053 |  |  | $ | (9 | ) |  | $ | 1,044 |  |
| Accrued expenses |  | $ | 598 |  |  | $ | (34 | ) |  | $ | 564 |  |
| Accumulated deficit |  | $ | (4,696 | ) |  | $ | 34 |  |  | $ | (4,662 | ) |

- added (2018-11-02):
[0001193125-18-317143:note_history:26]
The impact of applying the new accounting standard on the Company's condensed consolidated financial statements for the September 2018 quarter was not material.

- added (2018-11-02):
[0001193125-18-317143:note_history:27]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments—Overall Recognition and Measurement of Financial Assets and Financial Liabilities, as amended by ASU 2018-03, Financial Instruments—Overall: Technical Correction and Improvements, issued in February 2018. The amendments in these ASUs require entities to measure all equity investments at fair value with changes recognized through net income. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. These ASUs became effective and were adopted by the Company in the September 2018 quarter. For equity investments without readily determinable fair value, the Company elected the measurement alternative for measurement of equity investments, defined as cost, less impairments, if any, plus or minus changes resulting from observable price changes in orderly transactions for an identical or similar investment in the same issuer until the equity investments' fair value becomes readily determinable. The adoption of this guidance had no impact on the Company's condensed consolidated financial statements and disclosures.

- changed (2018-11-02):
[0001193125-18-317143:note_history:28]
In January 2017, the FASB issued ASU 2017-01 (ASC Topic 805), Business Combination: Clarifying the Definition of a Business. The amendments in this ASU change the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company adopted the guidance in the September 2018 quarter. The adoption of this guidance had no impact on the Company's condensed consolidated financial statements and disclosures.
  (was, 2018-05-01, similarity 0.666):
[0001193125-18-146598:note_history:28]
In January 2017, the FASB issued ASU 2017-01 (ASC Topic 805), Business Combination: Clarifying the Definition of a Business. The amendments in this ASU change the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company plans to adopt the guidance in the first quarter of fiscal year 2019. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- changed (2018-11-02):
[0001193125-18-317143:note_history:29]
In May 2017, the FASB issued ASU 2017-09 (ASC Topic 718), Stock Compensation: Scope of Modification Accounting. The amendments in this ASU provide guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting. The Company adopted the guidance in the September 2018 quarter. The adoption of this guidance had no impact on its condensed consolidated financial statements and disclosures.
  (was, 2018-05-01, similarity 0.6376):
[0001193125-18-146598:note_history:29]
In May 2017, the FASB issued ASU 2017-09 (ASC Topic 718), Stock Compensation: Scope of Modification Accounting. The amendments in this ASU provide guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting. The Company plans to adopt the guidance in the first quarter of fiscal year 2019. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- removed (2018-11-02):
[0001193125-18-146598:note_history:30]
The Company’s cloud systems and solutions extend innovation from the device into the information infrastructure, onsite and in the cloud. Its portfolio includes modular original equipment manufacturers (“OEM”) storage systems and scale-out storage servers.

- removed (2018-11-02):
[0001193125-18-146598:note_history:31]
The unaudited condensed consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

- removed (2018-11-02):
[0001193125-18-146598:note_history:32]
The results of operations for the three and nine months ended March 30, 2018 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending June 29, 2018. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three and nine months ended March 30, 2018 and the three and nine months ended March 31, 2017 consisted of 13 weeks and 39 weeks, respectively. Fiscal year 2018, which ends on June 29, 2018, and fiscal year 2017, which ended on June 30, 2017, are both comprised of 52 weeks. The fiscal quarters ended March 30, 2018, December 29, 2017, and March 31, 2017, are also referred to herein as the “March 2018 quarter”, the “December 2017 quarter”, and the “March 2017 quarter”, respectively.

- removed (2018-11-02):
[0001193125-18-146598:note_history:33]
There have been no significant changes in the Company's significant accounting policies. Please refer to Note 1 of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2017, as filed with the SEC on August 4, 2017 for a discussion of the Company’s significant accounting policies.

- removed (2018-11-02):
[0001193125-18-146598:note_history:34]
In May 2014, August 2015, April 2016, May 2016 and December 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update ("ASU") 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, ASU 2016-12 (ASC Topic 606) Revenue from Contracts with Customers, Narrow-Scope Improvements and Practical Expedients, and ASU 2016-20 (ASC Topic 606) Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company is required to adopt the guidance in the first quarter of fiscal year 2019. This standard may be applied retrospectively to all prior periods presented, or retrospectively with a cumulative adjustment to retained earnings in the year of adoption (“modified retrospective transition approach”). Based on its assessment, the Company plans to adopt the new revenue standard in the first quarter of fiscal year 2019, utilizing the modified retrospective method of transition. While management has not yet completed its assessment of the impact of adopting this new standard on the Company’s consolidated financial statements, the Company expects the adoption of the new standard will result in the recognition of revenue generally upon shipment (sell-in basis) for sales of products to certain direct retail customers and customers in certain indirect retail channels which are currently being recognized on a sell-through basis. Accordingly, the Company will need to estimate variable consideration (e.g. rebates) related to customer incentives on these arrangements. These changes are not expected to have a material impact on the Company’s condensed consolidated financial statements.

- removed (2018-11-02):
[0001193125-18-146598:note_history:35]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments—Overall Recognition and Measurement of Financial Assets and Financial Liabilities, as amended by ASU 2018-03, Financial Instruments—Overall: Technical Correction and Improvements, issued in February 2018. The amendments in these ASUs require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The Company is required to adopt the guidance in the first quarter of fiscal year 2019. Early adoption is permitted for only certain portions of the ASU. The Company expects to elect the measurement alternative for measurement of equity investments, defined as cost, less impairments, if any, plus or minus changes resulting from observable price changes in orderly transactions for an identical or similar investment in the same issuer (the "Price Changes") until the equity investments' fair value becomes readily determinable. The amount of the impact to equity investments will depend on any Price Changes observed after adoption in the first quarter of fiscal year 2019.

- removed (2018-11-02):
[0001193125-18-146598:note_history:36]
In February 2016, the FASB issued ASU 2016-02 (ASC Topic 842), Leases. This ASU amends a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The Company is required to adopt this guidance in the first quarter of fiscal year 2020. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- removed (2018-11-02):
[0001193125-18-146598:note_history:37]
In August 2017, the FASB issued ASU 2017-12 (ASC Topic 815), Derivatives and Hedging: Targeted Improvements to Accounting for Hedging Activities. The amendments in this ASU were issued to simplify existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. The amended guidance will eliminate the separate measurement and presentation of hedge ineffectiveness. The Company is required to adopt the guidance in the first quarter of fiscal year 2020. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

- removed (2018-11-02):
[0001193125-18-146598:note_history:38]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. This ASU became effective and was adopted by the Company in the September 2017 quarter on a prospective basis. The adoption of this guidance had no material impact on the Company’s condensed consolidated financial statements and disclosures.

- removed (2018-11-02):
[0001193125-18-146598:note_history:39]
In March 2016, the FASB issued ASU 2016-09 (ASC Topic 718), Stock Compensation—Improvements to Employee Share-Based Payment Accounting. The amendments in this ASU are intended to simplify several areas of accounting for share-based compensation arrangements, including the income tax consequences, classification on the consolidated statement of cash flows and treatment of forfeitures. This ASU became effective and was adopted by the Company in the September 2017 quarter. Upon adoption, excess tax benefits or deficiencies from share-based award activity are reflected in the condensed consolidated statements of operations as a component of the provision for income taxes, whereas they previously were recognized in the Shareholder's equity in the condensed consolidated balance sheets. The Company also elected to continue to account for share-based compensation expense net of estimated forfeitures. The adoption of this ASU resulted in an increase in deferred tax assets relating to net operating losses of approximately $0.6 billion, offset by an equivalent increase in the valuation allowance with no impact to retained earnings. The adoption of this guidance had no material impact on the Company’s condensed consolidated financial statements and disclosures.

- removed (2018-11-02):
[0001193125-18-146598:note_history:40]
In October 2016, the FASB issued ASU 2016-16 (ASC Topic 740), Income Taxes: Intra-Entity Transfers of Assets Other Than Inventory. The amendments in this ASU require the recognition of the income tax consequences for intra-entity transfers of assets other than inventory when the transfer occurs. The Company elected to adopt this ASU in the September 2017 quarter on a modified retrospective basis with no material impact on the Company's condensed consolidated financial statements and disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0001193125-18-317143:note_history:41]
The credit agreement entered into by the Company and its subsidiary Seagate HDD Cayman on January 18, 2011 and subsequently amended (the "Revolving Credit Facility") provides the Company with a $700 million senior secured revolving credit facility. The term of the Revolving Credit Facility is through January 15, 2020. The loans made under the Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing, and for the issuance of letters of credit up to a sub-limit of $75 million.
  (was, 2018-05-01, similarity 0.8815):
[0001193125-18-146598:note_history:41]
The credit agreement entered into by the Company and its subsidiary Seagate HDD Cayman on January 18, 2011 and subsequently amended (the "Revolving Credit Facility") provides the Company with a $700 million senior secured revolving credit facility. The term of the Revolving Credit Facility is through January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Revolving Credit Facility) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. The loans made under the Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing, and for the issuance of letters of credit up to a sub-limit of $75 million.

- changed (2018-11-02):
[0001193125-18-317143:note_history:42]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio.   The Company was in compliance with the modified covenants as of September 28, 2018 and expects to be in compliance for the next 12 months.
  (was, 2018-05-01, similarity 0.7825):
[0001193125-18-146598:note_history:42]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to allow for higher net leverage levels. The Company was in compliance with the modified covenants as of March 30, 2018 and expects to be in compliance for the next 12 months.

- changed (2018-11-02):
[0001193125-18-317143:note_history:43]
As of September 28, 2018, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.
  (was, 2018-05-01, similarity 0.9558):
[0001193125-18-146598:note_history:43]
As of March 30, 2018, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

- added (2018-11-02):
[0001193125-18-317143:note_history:44]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2017 quarter, the Company repurchased $22 million aggregate principal amount of the 2018 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded an immaterial loss on the repurchase during the three months ended September 29, 2017, which is included in Other, net on the Compnay's Condensed Consolidated Statements of Operations. There were no repurchases during the three months ended September 28, 2018. The remainder of the 2018 Notes were classified as Current portion of long-term debt on the Company's Condensed Consolidated Balance Sheets at September 28, 2018 and June 29, 2018.

- changed (2018-11-02):
[0001193125-18-317143:note_history:45]
At September 28, 2018, future principal payments on long-term debt were as follows (in millions):
  (was, 2018-05-01, similarity 0.9438):
[0001193125-18-146598:note_history:45]
At March 30, 2018, future principal payments on long-term debt were as follows (in millions):

- changed (2018-11-02):
[0001193125-18-317143:note_history:46]
| Fiscal Year |  | Amount |
| Remainder of 2019 |  | $ | 499 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| 2022 |  | 750 |  |
| 2023 |  | 951 |  |
| Thereafter |  | 2,662 |  |
| Total |  | $ | 4,862 |  |
  (was, 2018-05-01, similarity 0.9114):
[0001193125-18-146598:note_history:46]
| Fiscal Year |  | Amount |
| Remainder of 2018 |  | $ | — |  |
| 2019 |  | 504 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| 2022 |  | 750 |  |
| Thereafter |  | 3,613 |  |
| Total |  | $ | 4,867 |  |

- removed (2018-11-02):
[0001193125-18-146598:note_history:47]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the three and nine months ended March 30, 2018, the Company repurchased $56 million and $206 million aggregate principal amount of the 2018 Notes, respectively, for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss of approximately $1 million and $3 million on repurchases during the three and nine months ended March 30, 2018, respectively, which is included in Other, net on the Condensed Consolidated Statements of Operations. The remainder of the 2018 Notes are classified as Current portion of long-term debt on the Company's Condensed Consolidated Balance Sheet at March 30, 2018.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0001193125-18-317143:note_history:48]
|  |  | September 28, 2018 |  | June 29, 2018 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 499 |  |  | $ | 500 |  |  | $ | 499 |  |  | $ | 501 |  |
| 4.25% Senior Notes due March 2022 |  | 749 |  |  | 746 |  |  | 749 |  |  | 743 |  |
| 4.75% Senior Notes due June 2023 |  | 951 |  |  | 950 |  |  | 951 |  |  | 942 |  |
| 4.875% Senior Notes due March 2024 |  | 497 |  |  | 492 |  |  | 497 |  |  | 489 |  |
| 4.75% Senior Notes due January 2025 |  | 975 |  |  | 937 |  |  | 975 |  |  | 936 |  |
| 4.875% Senior Notes due June 2027 |  | 695 |  |  | 655 |  |  | 695 |  |  | 650 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 443 |  |  | 489 |  |  | 441 |  |
|  |  | $ | 4,855 |  |  | $ | 4,723 |  |  | $ | 4,855 |  |  | $ | 4,702 |  |
| Less: debt issuance costs |  | (34 | ) |  | — |  |  | (36 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 4,821 |  |  | $ | 4,723 |  |  | $ | 4,819 |  |  | $ | 4,702 |  |
| Less: current portion of long-term debt, net of debt issuance costs |  | (499 | ) |  | (500 | ) |  | (499 | ) |  | (501 | ) |
| Long-term debt, less current portion |  | $ | 4,322 |  |  | $ | 4,223 |  |  | $ | 4,320 |  |  | $ | 4,201 |  |
  (was, 2018-05-01, similarity 0.973):
[0001193125-18-146598:note_history:48]
|  |  | March 30, 2018 |  | June 30, 2017 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 504 |  |  | $ | 507 |  |  | $ | 710 |  |  | $ | 726 |  |
| 4.25% Senior Notes due March 2022 |  | 749 |  |  | 741 |  |  | 748 |  |  | 765 |  |
| 4.75% Senior Notes due June 2023 |  | 951 |  |  | 954 |  |  | 951 |  |  | 987 |  |
| 4.875% Senior Notes due March 2024 |  | 497 |  |  | 498 |  |  | 497 |  |  | 511 |  |
| 4.75% Senior Notes due January 2025 |  | 975 |  |  | 953 |  |  | 975 |  |  | 984 |  |
| 4.875% Senior Notes due June 2027 |  | 695 |  |  | 660 |  |  | 695 |  |  | 698 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 467 |  |  | 489 |  |  | 488 |  |
|  |  | $ | 4,860 |  |  | $ | 4,780 |  |  | $ | 5,065 |  |  | $ | 5,159 |  |
| Less: debt issuance costs |  | (38 | ) |  | — |  |  | (44 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 4,822 |  |  | $ | 4,780 |  |  | $ | 5,021 |  |  | $ | 5,159 |  |
| Less: current portion of long-term debt, net of debt issuance costs of $1 million |  | (503 | ) |  | (507 | ) |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 4,319 |  |  | $ | 4,273 |  |  | $ | 5,021 |  |  | $ | 5,159 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0001193125-18-317143:note_history:49]
At September 28, 2018, future principal payments on long-term debt were as follows (in millions):
  (was, 2018-05-01, similarity 0.9438):
[0001193125-18-146598:note_history:49]
At March 30, 2018, future principal payments on long-term debt were as follows (in millions):

- changed (2018-11-02):
[0001193125-18-317143:note_history:50]
| Fiscal Year |  | Amount |
| Remainder of 2019 |  | $ | 499 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| 2022 |  | 750 |  |
| 2023 |  | 951 |  |
| Thereafter |  | 2,662 |  |
| Total |  | $ | 4,862 |  |
  (was, 2018-05-01, similarity 0.9114):
[0001193125-18-146598:note_history:50]
| Fiscal Year |  | Amount |
| Remainder of 2018 |  | $ | — |  |
| 2019 |  | 504 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| 2022 |  | 750 |  |
| Thereafter |  | 3,613 |  |
| Total |  | $ | 4,867 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-11-02):
[0001193125-18-317143:note_history:51]
The following table provides information about disaggregated revenue by sales channel and geographical region for the Company’s single reportable segment:

- added (2018-11-02):
[0001193125-18-317143:note_history:52]
|  |  | For the Three Months Ended |
| (Dollars in million) |  | September 28, 2018 |  | September 29, 2017 |
| Revenues by Channel |  |  |  |  |  |
| OEMs |  | $ | 2,138 |  |  | $ | 1,834 |  |
| Distributors |  | 534 |  |  | 434 |  |
| Retailers |  | 319 |  |  | 364 |  |
| Total |  | $ | 2,991 |  |  | $ | 2,632 |  |
| Revenues by Geography(1) |  |  |  |  |
| Americas |  | $ | 1,006 |  |  | $ | 875 |  |
| EMEA |  | 517 |  |  | 472 |  |
| Asia Pacific |  | 1,468 |  |  | 1,285 |  |
| Total |  | $ | 2,991 |  |  | $ | 2,632 |  |

- added (2018-11-02):
[0001193125-18-317143:note_history:53]
(1) Revenue is attributed to countries based on bill from locations.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-11-02):
[0001193125-18-317143:note_history:54]
Revenue

- added (2018-11-02):
[0001193125-18-317143:note_history:55]
The following table provides information about disaggregated revenue by sales channel and geographical region for the Company’s single reportable segment:

- added (2018-11-02):
[0001193125-18-317143:note_history:56]
|  |  | For the Three Months Ended |
| (Dollars in million) |  | September 28, 2018 |  | September 29, 2017 |
| Revenues by Channel |  |  |  |  |  |
| OEMs |  | $ | 2,138 |  |  | $ | 1,834 |  |
| Distributors |  | 534 |  |  | 434 |  |
| Retailers |  | 319 |  |  | 364 |  |
| Total |  | $ | 2,991 |  |  | $ | 2,632 |  |
| Revenues by Geography(1) |  |  |  |  |
| Americas |  | $ | 1,006 |  |  | $ | 875 |  |
| EMEA |  | 517 |  |  | 472 |  |
| Asia Pacific |  | 1,468 |  |  | 1,285 |  |
| Total |  | $ | 2,991 |  |  | $ | 2,632 |  |

- added (2018-11-02):
[0001193125-18-317143:note_history:57]
(1) Revenue is attributed to countries based on bill from locations.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-11-02):
[0001193125-18-317143:note_history:58]
Revenue Recognition

- added (2018-11-02):
[0001193125-18-317143:note_history:59]
Effective June 30, 2018, the Company adopted a new revenue recognition policy in accordance with Accounting Standard Codification ("ASC") 606, Revenue from Contracts with Customers, using the modified retrospective transition approach as discussed in the section titled Recently Adopted Accounting Pronouncements in this Note 1. Prior to fiscal year 2019, the revenue recognition policy was based on ASC 605, Revenue Recognition. Under ASC 606, the Company determines revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, the Company satisfies a performance obligation.

- added (2018-11-02):
[0001193125-18-317143:note_history:60]
Revenue from sales of products is generally recognized upon transfer of control to customers in an amount that reflects the consideration the Company expects to receive in exchange for those products, net of sales taxes. This typically occurs upon shipment from the Company. When applicable, the Company includes shipping charges billed to customers in Revenue and includes the related shipping costs in Cost of revenue on the Company's Condensed Consolidated Statements of Operations.

- added (2018-11-02):
[0001193125-18-317143:note_history:61]
The Company records estimated variable consideration at the time of revenue recognition as a reduction to net revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer’s volume of purchases from Seagate or other agreed upon rebate programs. For the distribution and retailing channel, these programs typically involve estimating the most likely amount of rebates related to a customer’s level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Marketing development program costs are accrued and recorded as a reduction to revenue at the same time that the related revenue is recognized.

- added (2018-11-02):
[0001193125-18-317143:note_history:62]
Practical Expedient and Exemptions

- added (2018-11-02):
[0001193125-18-317143:note_history:63]
The Company elected a practical expedient to expense sales commissions when the commissions are incurred because the amortization period would have been one year or less. These costs are recorded as Marketing and administrative on the Company's Condensed Consolidated Statements of Operations.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0001193125-18-317143:note_history:64]
On November 2, 2018, the Company’s Board of Directors declared a quarterly cash dividend of $0.63 per share, which will be payable on January 2, 2019 to shareholders of record as of the close of business on December 19, 2018.
  (was, 2018-05-01, similarity 0.9403):
[0001193125-18-146598:note_history:64]
On May 1, 2018, the Company’s Board of Directors declared a quarterly cash dividend of $0.63 per share, which will be payable on July 5, 2018 to shareholders of record as of the close of business on June 20, 2018.

- added (2018-11-02):
[0001193125-18-317143:note_history:65]
Share Repurchases

- added (2018-11-02):
[0001193125-18-317143:note_history:66]
On October 29, 2018, the Company's Board of Directors authorized the repurchase of $2.3 billion of its outstanding ordinary shares.
