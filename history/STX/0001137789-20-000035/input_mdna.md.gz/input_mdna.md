# STX MD&A — 0001137789-20-000035


## mdna

[0001137789-20-000035:mdna:1]
[same as prior period, unchanged from 0001137789-20-000015:mdna:1]

[0001137789-20-000035:mdna:2]
The following is a discussion of the financial condition, changes in financial condition and results of operations for our fiscal quarters ended April 3, 2020, January 3, 2020 and March 29, 2019, referred to herein as the “March 2020 quarter,” the “December 2019 quarter,” and the “March 2019 quarter,” respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The March 2020 quarter, the December 2019 quarter and the March 2019 quarter were each 13 weeks.

[0001137789-20-000035:mdna:3]
[same as prior period, unchanged from 0001137789-20-000015:mdna:3]

[0001137789-20-000035:mdna:4]
•the uncertainty in global economic and political conditions;

[0001137789-20-000035:mdna:5]
[same as prior period, unchanged from 0001137789-20-000015:mdna:4]

[0001137789-20-000035:mdna:6]
[same as prior period, unchanged from 0001137789-20-000015:mdna:5]

[0001137789-20-000035:mdna:7]
[same as prior period, unchanged from 0001137789-20-000015:mdna:6]

[0001137789-20-000035:mdna:8]
•the Company’s ability to effectively manage its debt obligations and comply with certain covenants in its credit facilities with respect to financial ratios and financial condition tests and its ability to maintain a favorable cash liquidity position;

[0001137789-20-000035:mdna:9]
[same as prior period, unchanged from 0001137789-20-000015:mdna:8]

[0001137789-20-000035:mdna:10]
[same as prior period, unchanged from 0001137789-20-000015:mdna:9]

[0001137789-20-000035:mdna:11]
•the effects of the outbreak of COVID-19 and related individual, business and government responses on the global economy and their impact on the Company’s business, operations and financial results;

[0001137789-20-000035:mdna:12]
[same as prior period, unchanged from 0001137789-20-000015:mdna:10]

[0001137789-20-000035:mdna:13]
[same as prior period, unchanged from 0001137789-20-000015:mdna:11]

[0001137789-20-000035:mdna:14]
•the impact of trade barriers, such as import/export duties and restrictions, tariffs and quotas, imposed by the U.S. or other countries in which the Company conducts business;

[0001137789-20-000035:mdna:15]
•the evolving legal and regulatory, economic, environmental and administrative climate in the international markets where the Company operates; and

[0001137789-20-000035:mdna:16]
[same as prior period, unchanged from 0001137789-20-000015:mdna:13]

[0001137789-20-000035:mdna:17]
[same as prior period, unchanged from 0001137789-20-000015:mdna:15]

[0001137789-20-000035:mdna:18]
•Overview of the March 2020 quarter. Highlights of events in the March 2020 quarter that impacted our financial position.

[0001137789-20-000035:mdna:19]
•Results of Operations. An analysis of our financial results comparing the March 2020 quarter to the December 2019 quarter and the March 2019 quarter.

[0001137789-20-000035:mdna:20]
[same as prior period, unchanged from 0001137789-20-000015:mdna:18]

[0001137789-20-000035:mdna:21]
[same as prior period, unchanged from 0001137789-20-000015:mdna:19]

[0001137789-20-000035:mdna:22]
[same as prior period, unchanged from 0001137789-20-000015:mdna:20]

[0001137789-20-000035:mdna:23]
Overview of the March 2020 quarter

[0001137789-20-000035:mdna:24]
During the March 2020 quarter, we shipped 120 exabytes of HDD storage capacity. We generated revenue of approximately $2.7 billion, gross margin of 27% and our operating cash flow was $390 million. We repurchased approximately 4 million of our ordinary shares for $195 million and paid $170 million in dividends.

[0001137789-20-000035:mdna:25]
Impact of COVID-19

[0001137789-20-000035:mdna:26]
The COVID-19 pandemic has resulted in a widespread health crisis and numerous disease control measures being taken to limit its spread, the effects of which began during our March 2020 quarter. We incurred certain supply chain and demand disruptions during the March 2020 quarter, that we expect to continue into our fiscal fourth quarter, as well as factory under-utilization and higher logistics and operational costs due to the COVID-19 pandemic. We are continuing to actively monitor the effects and potential impacts of the COVID-19 pandemic on all aspects of our business, liquidity and capital resources. We are complying with governmental rules and guidelines across all of our sites and are actively working on opportunities to lower our cost structure and drive further operational efficiencies. Although we are unable to predict the impact of COVID-19 effects on our business, results of operations, liquidity or capital resources at this time, we expect we will be negatively affected if the pandemic and related public health measures result in substantial manufacturing or supply chain problems, reductions in demand due to disruptions in the operations of our customers or partners, disruptions in local and global economies, volatility in the global financial markets, reductions in overall demand trends, restrictions on the export or shipment of our products, or other ramifications from the COVID-19 pandemic. For a further discussion of the uncertainties and business risks associated with the COVID-19 pandemic, see the section entitled “Risk Factors” in Part II, Item 1A of this Quarterly Report.

[0001137789-20-000035:mdna:27]
[same as prior period, unchanged from 0001137789-20-000015:mdna:23]

[0001137789-20-000035:mdna:28]
[same as prior period, unchanged from 0001137789-20-000015:mdna:24]

[0001137789-20-000035:mdna:29]
|  |  | For the Three Months Ended |  |  |  |  |  | For the Nine Months Ended |  |  |
| (Dollars in millions) |  | April 3,2020 |  | January 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |
| Revenue |  | $ | 2,718 |  |  | $ | 2,696 |  |  | $ | 2,313 |  |  | $ | 7,992 |  |  | $ | 8,019 |  |
| Cost of revenue |  | 1,972 |  |  | 1,938 |  |  | 1,712 |  |  | 5,817 |  |  | 5,711 |  |
| Gross margin |  | 746 |  |  | 758 |  |  | 601 |  |  | 2,175 |  |  | 2,308 |  |
| Product development |  | 246 |  |  | 250 |  |  | 238 |  |  | 751 |  |  | 750 |  |
| Marketing and administrative |  | 119 |  |  | 120 |  |  | 110 |  |  | 361 |  |  | 345 |  |
| Amortization of intangibles |  | 3 |  |  | 4 |  |  | 6 |  |  | 11 |  |  | 17 |  |
| Restructuring and other, net |  | 2 |  |  | — |  |  | 11 |  |  | 19 |  |  | 41 |  |
| Income from operations |  | 376 |  |  | 384 |  |  | 236 |  |  | 1,033 |  |  | 1,155 |  |
| Other expense, net |  | (38) |  |  | (48) |  |  | (21) |  |  | (161) |  |  | (74) |  |
| Income before income taxes |  | 338 |  |  | 336 |  |  | 215 |  |  | 872 |  |  | 1,081 |  |
| Provision for income taxes |  | 18 |  |  | 18 |  |  | 20 |  |  | 34 |  |  | 52 |  |
| Net income |  | $ | 320 |  |  | $ | 318 |  |  | $ | 195 |  |  | $ | 838 |  |  | $ | 1,029 |  |

[0001137789-20-000035:mdna:30]
|  |  | For the Three Months Ended |  |  |  |  |  | For the Nine Months Ended |  |  |
|  |  | April 3,2020 |  | January 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 73 |  |  | 72 |  |  | 74 |  |  | 73 |  |  | 71 |  |
| Gross margin |  | 27 |  |  | 28 |  |  | 26 |  |  | 27 |  |  | 29 |  |
| Product development |  | 9 |  |  | 9 |  |  | 10 |  |  | 9 |  |  | 9 |  |
| Marketing and administrative |  | 4 |  |  | 4 |  |  | 5 |  |  | 5 |  |  | 4 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Restructuring and other, net |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Income from operations |  | 14 |  |  | 15 |  |  | 10 |  |  | 13 |  |  | 15 |  |
| Other expense, net |  | (1) |  |  | (2) |  |  | (1) |  |  | (2) |  |  | (1) |  |
| Income before income taxes |  | 13 |  |  | 13 |  |  | 9 |  |  | 11 |  |  | 14 |  |
| Provision for income taxes |  | 1 |  |  | 1 |  |  | 1 |  |  | 1 |  |  | 1 |  |
| Net income |  | 12 | % |  | 12 | % |  | 8 | % |  | 10 | % |  | 13 | % |

[0001137789-20-000035:mdna:31]
[same as prior period, unchanged from 0001137789-20-000015:mdna:47]

[0001137789-20-000035:mdna:32]
[same as prior period, unchanged from 0001137789-20-000015:mdna:28]

[0001137789-20-000035:mdna:33]
[same as prior period, unchanged from 0001137789-20-000015:mdna:29]

[0001137789-20-000035:mdna:34]
|  |  | For the Three Months Ended |  |  |  |  |  | For the Nine Months Ended |  |  |
|  |  | April 3,2020 |  | January 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 73 | % |  | 68 | % |  | 68 | % |  | 71 | % |  | 70 | % |
| Distributors |  | 17 | % |  | 17 | % |  | 18 | % |  | 17 | % |  | 17 | % |
| Retailers |  | 10 | % |  | 15 | % |  | 14 | % |  | 12 | % |  | 13 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 46 | % |  | 51 | % |  | 46 | % |  | 49 | % |  | 49 | % |
| Americas |  | 35 | % |  | 28 | % |  | 35 | % |  | 32 | % |  | 32 | % |
| EMEA |  | 19 | % |  | 21 | % |  | 19 | % |  | 19 | % |  | 19 | % |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 57 | % |  | 49 | % |  | 40 | % |  | 51 | % |  | 42 | % |
| Legacy |  | 36 | % |  | 43 | % |  | 52 | % |  | 42 | % |  | 51 | % |
| Other |  | 7 | % |  | 8 | % |  | 8 | % |  | 7 | % |  | 7 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 91 |  |  | 71 |  |  | 43 |  |  | 226 |  |  | 150 |  |
| Legacy |  | 29 |  |  | 36 |  |  | 34 |  |  | 99 |  |  | 113 |  |
| Total |  | 120 |  |  | 107 |  |  | 77 |  |  | 325 |  |  | 263 |  |
| HDD Price per Terabyte |  | $ | 21 |  |  | $ | 23 |  |  | $ | 28 |  |  | $ | 23 |  |  | $ | 28 |  |

[0001137789-20-000035:mdna:35]
Revenue in the March 2020 quarter increased by $22 million from the December 2019 quarter primarily due to an increase in mass capacity storage exabytes shipped, partially offset by a decrease in legacy market exabytes shipped and price erosion.

[0001137789-20-000035:mdna:36]
Revenue in the March 2020 quarter increased by $405 million from the March 2019 quarter primarily due to an increase in mass capacity storage exabytes shipped, partially offset by price erosion.

[0001137789-20-000035:mdna:37]
Revenue for the nine months ended April 3, 2020 decreased by $27 million from the nine months ended March 29, 2019 primarily as a result of price erosion, partially offset by an increase in mass capacity storage exabytes shipped.

[0001137789-20-000035:mdna:38]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 12% of gross HDD revenue for the March 2020 quarter and 13% for each of the December 2019 and March 2019 quarters. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-20-000035:mdna:39]
[same as prior period, unchanged from 0001137789-20-000015:mdna:36]

[0001137789-20-000035:mdna:40]
|  |  | For the Three Months Ended |  |  |  |  |  | For the Nine Months Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | April 3,2020 |  | January 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |  |  |  |
| Cost of revenue |  | $ | 1,972 |  |  | $ | 1,938 |  |  | $ | 1,712 |  |  | $ | 5,817 |  |  | $ | 5,711 |  |  |  |  |  |
| Gross margin |  | 746 |  |  | 758 |  |  | 601 |  |  | 2,175 |  |  | 2,308 |  |  |  |  |  |
| Gross margin percentage |  | 27 | % |  | 28 | % |  | 26 | % |  | 27 | % |  | 29 | % |  |  |  |  |

[0001137789-20-000035:mdna:41]
Gross margin as a percentage of revenue for the March 2020 quarter decreased compared to the December 2019 quarter primarily driven by price erosion and higher logistics costs and factory under-utilization due to COVID-19 disruptions, partially offset by improved product mix.

[0001137789-20-000035:mdna:42]
Gross margin as a percentage of revenue for the March 2020 quarter increased compared to the March 2019 quarter primarily driven by improved product mix and lower depreciation expense due to the change in useful lives of our manufacturing equipment in the quarter ended October 4, 2019, partially offset by price erosion and higher logistics costs and factory under-utilization due to COVID-19 disruptions.

[0001137789-20-000035:mdna:43]
Gross margin as a percentage of revenue for the nine months ended April 3, 2020 decreased compared to the nine months ended March 29, 2019 primarily driven by price erosion, partially offset by improved product mix and lower depreciation expense due to the change in useful lives of our manufacturing equipment in the quarter ended October 4, 2019.

[0001137789-20-000035:mdna:44]
In the March 2020 quarter, total warranty cost was 0.6% of revenue and included a favorable change in estimates of prior warranty accruals of 0.2% of revenue primarily due to lower repair costs and improvements in return rates on newer generation products. Warranty cost related to new shipments was 0.8%, 0.8% and 1.1% of revenue for the March 2020 quarter, December 2019 quarter and March 2019 quarter, respectively.

[0001137789-20-000035:mdna:45]
[same as prior period, unchanged from 0001137789-20-000015:mdna:42]

[0001137789-20-000035:mdna:46]
|  |  | For the Three Months Ended |  |  |  |  |  | For the Nine Months Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | April 3,2020 |  | January 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |  |  |  |
| Product development |  | $ | 246 |  |  | $ | 250 |  |  | $ | 238 |  |  | $ | 751 |  |  | $ | 750 |  |  |  |  |  |
| Marketing and administrative |  | 119 |  |  | 120 |  |  | 110 |  |  | 361 |  |  | 345 |  |  |  |  |  |
| Amortization of intangibles |  | 3 |  |  | 4 |  |  | 6 |  |  | 11 |  |  | 17 |  |  |  |  |  |
| Restructuring and other, net |  | 2 |  |  | — |  |  | 11 |  |  | 19 |  |  | 41 |  |  |  |  |  |
| Operating expenses |  | $ | 370 |  |  | $ | 374 |  |  | $ | 365 |  |  | $ | 1,142 |  |  | $ | 1,153 |  |  |  |  |  |

[0001137789-20-000035:mdna:47]
Product development expense. Product development expense for the March 2020 quarter remained relatively flat compared to the December 2019 quarter.

[0001137789-20-000035:mdna:48]
Product development expense increased by $8 million in the March 2020 quarter compared to the March 2019 quarter primarily due to a $7 million increase in variable compensation expense, a $6 million increase in outside services expense and a $5 million increase in other general expenses mainly as a result of timing of materials purchases, partially offset by a $6 million decrease related to timing of grants received and a $5 million decrease in depreciation expense.

[0001137789-20-000035:mdna:49]
Product development expense for the nine months ended April 3, 2020 remained relatively flat compared to the nine months ended March 29, 2019.

[0001137789-20-000035:mdna:50]
Marketing and administrative expense. Marketing and administrative expense for the March 2020 quarter remained relatively flat compared to the December 2019 quarter.

[0001137789-20-000035:mdna:51]
Marketing and administrative expense increased by $9 million in the March 2020 quarter compared to the March 2019 quarter primarily due to a $6 million increase in outside services expense and a $3 million increase in variable compensation expense.

[0001137789-20-000035:mdna:52]
Marketing and administrative expense for the nine months ended April 3, 2020 increased by $16 million compared to the nine months ended March 29, 2019 primarily due to an $8 million increase in other general expenses and a $7 million increase in outside services expense.

[0001137789-20-000035:mdna:53]
Amortization of intangibles. Amortization of intangibles for the March 2020 quarter remained relatively flat compared to the December 2019 quarter.

[0001137789-20-000035:mdna:54]
Amortization of intangibles for the three and nine months ended April 3, 2020 decreased by $3 million and $6 million, respectively, compared to the three and nine months ended March 29, 2019, due to certain intangible assets that reached the end of their useful lives.

[0001137789-20-000035:mdna:55]
Restructuring and other, net. Restructuring and other, net for the three months ended April 3, 2020 was primarily comprised of workforce reduction costs. Restructuring and other, net for the nine months ended April 3, 2020 and the three and nine months ended March 29, 2019 were comprised of charges primarily related to voluntary early exit programs.

[0001137789-20-000035:mdna:56]
[same as prior period, unchanged from 0001137789-20-000015:mdna:77]

[0001137789-20-000035:mdna:57]
[same as prior period, unchanged from 0001137789-20-000015:mdna:53]

[0001137789-20-000035:mdna:58]
|  |  | For the Three Months Ended |  |  |  |  |  | For the Nine Months Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | April 3,2020 |  | January 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |  |  |  |
| Other expense, net |  | $ | (38) |  |  | $ | (48) |  |  | $ | (21) |  |  | $ | (161) |  |  | $ | (74) |  |  |  |  |  |

[0001137789-20-000035:mdna:59]
Other expense, net. Other expense, net for the March 2020 quarter decreased by $10 million from the December 2019 quarter primarily due to a $9 million net increase in gains due to favorable changes in foreign currency exchange rates.

[0001137789-20-000035:mdna:60]
Other expense, net for the March 2020 quarter increased by $17 million compared to the March 2019 quarter primarily due to $25 million of non-recurring income, net in the March 2019 quarter related to our previous investment in Toshiba Memory Holdings Corporation (“TMHC”), which was redeemed in the quarter ended June 28, 2019, partially offset by $5 million net increase in gains due to favorable changes in foreign currency exchange rates and $4 million decrease in interest expense from the repurchase of certain long-term debt.

[0001137789-20-000035:mdna:61]
Other expense, net for the nine months ended April 3, 2020 increased by $87 million compared to the nine months ended March 29, 2019 primarily due to $78 million of non-recurring income, net in the nine months ended March 29, 2019 related to our previous investment in TMHC, which was redeemed in the quarter ended June 28, 2019 and a $30 million loss resulting from the repurchase of certain long-term debt, partially offset by a related $14 million decrease in interest expense and a $7 million net increase in gains due to favorable changes in foreign currency exchange rates.

[0001137789-20-000035:mdna:62]
[same as prior period, unchanged from 0001137789-20-000015:mdna:58]

[0001137789-20-000035:mdna:63]
|  |  | For the Three Months Ended |  |  |  |  |  | For the Nine Months Ended |  |  |  |  |  |  |
| (Dollars in millions) |  | April 3,2020 |  | January 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |  |  |  |  |
| Provision for income taxes |  | $ | 18 |  |  | $ | 18 |  |  | $ | 20 |  |  | $ | 34 |  |  | $ | 52 |  |  |  |  |  |

[0001137789-20-000035:mdna:64]
We recorded income tax provisions of $18 million and $34 million in the three and nine months ended April 3, 2020, respectively. The discrete items in the income tax provision were not material for the three months ended April 3, 2020. The income tax provision for the nine months ended April 3, 2020 included approximately $13 million of net discrete tax benefits, primarily associated with net excess tax benefits related to share-based compensation expense.

[0001137789-20-000035:mdna:65]
Our income tax provision recorded for the three and nine months ended April 3, 2020 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-20-000035:mdna:66]
During the nine months ended April 3, 2020, our unrecognized tax benefits excluding interest and penalties increased by approximately $4 million to $87 million; substantially all of which would impact our effective tax rate, if recognized, subject to certain future valuation allowance reversals. During the twelve months beginning April 4, 2020, we expect that our unrecognized tax benefits could be reduced by an immaterial amount as a result of the expiration of certain statutes of limitation.

[0001137789-20-000035:mdna:67]
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (“CARES Act”) was signed into law. The CARES Act includes provisions relating to refundable payroll tax credits, deferral of certain payroll taxes, technical corrections to tax depreciation methods for qualified improvement property, net operating loss carryback periods, alternative minimum tax credit refunds and modifications to the net interest deduction limitations which are not expected to have a material impact to our consolidated financial statements.

[0001137789-20-000035:mdna:68]
During the nine months ended April 3, 2020, various tax legislation has been passed, in addition to the CARES Act, which becomes effective in our fiscal years 2020 and 2021. Tax legislation effective in fiscal year 2020 has no material impact to our consolidated financial statements. For tax legislation effective beginning fiscal year 2021, we are in the process of assessing the impact of these tax law changes to our consolidated financial statements.

[0001137789-20-000035:mdna:69]
We recorded income tax provisions of $20 million and $52 million in the three and nine months ended March 29, 2019, respectively. The income tax provision for the three and nine months ended March 29, 2019 included approximately $9 million and $5 million of net discrete tax expense, respectively, primarily associated with a deferred withholding tax liability resulting from a change in indefinite reinvestment assertion for a foreign subsidiary. This was partially offset by the recognition of previously unrecognized tax benefits related to the expiration of certain statutes of limitation.

[0001137789-20-000035:mdna:70]
35

[0001137789-20-000035:mdna:71]
Our income tax provision recorded for the three months ended March 29, 2019 differed from the provision from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-Irish earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.

[0001137789-20-000035:mdna:72]
[same as prior period, unchanged from 0001137789-20-000015:mdna:66]

[0001137789-20-000035:mdna:73]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist primarily of money market funds, time deposits and certificates of deposit. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. We believe our sources of cash will continue to be sufficient to meet our cash needs for the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs, will allow us to manage the potential impacts of the COVID-19 pandemic on our business operations for the foreseeable future. However, the challenges posed by COVID-19 to our industry and to our business are evolving rapidly and are highly uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to COVID-19.

[0001137789-20-000035:mdna:74]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of April 3, 2020.

[0001137789-20-000035:mdna:75]
[same as prior period, unchanged from 0001137789-20-000015:mdna:68]

[0001137789-20-000035:mdna:76]
| (Dollars in millions) |  | April 3,2020 |  | June 28,2019 |  | Change |
| Cash and cash equivalents |  | $ | 1,612 |  |  | $ | 2,220 |  |  | $ | (608) |  |

[0001137789-20-000035:mdna:77]
Our cash and cash equivalents as of April 3, 2020 decreased by $608 million from June 28, 2019 primarily as a result of the repurchases of our ordinary shares of $795 million, repurchases of certain senior notes of $685 million for $660 million in aggregate principal amount, dividends to our shareholders of $505 million and payments for capital expenditures of $471 million, partially offset by net cash of $1,326 million provided by operating activities and net proceeds of $498 million from borrowings under our Term Loan.

[0001137789-20-000035:mdna:78]
[same as prior period, unchanged from 0001137789-20-000015:mdna:71]

[0001137789-20-000035:mdna:79]
Cash provided by operating activities for the nine months ended April 3, 2020 was $1,326 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-20-000035:mdna:80]
•an increase of $424 million in accounts payable, primarily due to timing of payments and an increase in materials purchased;

[0001137789-20-000035:mdna:81]
•partially offset by an increase of $172 million in accounts receivable, primarily due to the timing of collections; and

[0001137789-20-000035:mdna:82]
•an increase of $126 million in inventories, primarily due to an increase in materials purchased for new product ramps and the potential for supply chain disruptions due to COVID-19;

[0001137789-20-000035:mdna:83]
[same as prior period, unchanged from 0001137789-20-000015:mdna:78]

[0001137789-20-000035:mdna:84]
Cash used in investing activities for the nine months ended April 3, 2020 was $527 million, primarily attributable to the following activities:

[0001137789-20-000035:mdna:85]
•payments for the purchase of property, equipment and leasehold improvements of $471 million; and

[0001137789-20-000035:mdna:86]
•payments for the purchase of investments of $57 million.

[0001137789-20-000035:mdna:87]
[same as prior period, unchanged from 0001137789-20-000015:mdna:82]

[0001137789-20-000035:mdna:88]
Cash used in financing activities of $1,428 million for the nine months ended April 3, 2020 was primarily attributable to the following activities:

[0001137789-20-000035:mdna:89]
•$795 million in payments for repurchase of our ordinary shares;

[0001137789-20-000035:mdna:90]
•$685 million in payments for repurchase of certain long-term debt;

[0001137789-20-000035:mdna:91]
[same as prior period, unchanged from 0001137789-20-000015:mdna:104]

[0001137789-20-000035:mdna:92]
•$505 million in dividend payments;

[0001137789-20-000035:mdna:93]
[same as prior period, unchanged from 0001137789-20-000015:mdna:87]

[0001137789-20-000035:mdna:94]
[same as prior period, unchanged from 0001137789-20-000015:mdna:88]

[0001137789-20-000035:mdna:95]
•$100 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-20-000035:mdna:96]
[same as prior period, unchanged from 0001137789-20-000015:mdna:90]

[0001137789-20-000035:mdna:97]
Our primary sources of liquidity as of April 3, 2020 consisted of: (1) approximately $1.6 billion in cash and cash equivalents, (2) cash we expect to generate from operations, and (3) subject to compliance with certain requirements under our control, up to $1.5 billion available for borrowing under our Revolving Credit Facility.

[0001137789-20-000035:mdna:98]
As of April 3, 2020, no borrowings had been drawn and no borrowings had been utilized for letters of credit or swing line loans issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-20-000035:mdna:99]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The term of the Revolving Credit Facility is through February 20, 2024, and the maturity date of the Term Loan is September 16, 2025. We were in compliance with the covenants as of April 3, 2020 and expect to be in compliance for the next 12 months.

[0001137789-20-000035:mdna:100]
[same as prior period, unchanged from 0001137789-20-000015:mdna:94]

[0001137789-20-000035:mdna:101]
For fiscal year 2020, we expect capital expenditures to be at or below our long-term targeted range of 6% to 8% of revenue to align to market conditions.

[0001137789-20-000035:mdna:102]
From time to time, we may repurchase any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase outstanding senior notes pursuant to the terms of the applicable indenture.

[0001137789-20-000035:mdna:103]
During the March 2020 quarter, our Board of Directors declared dividends of $0.65 per share, totaling $168 million, which were paid on April 8, 2020. On April 21, 2020, our Board of Directors declared a quarterly cash dividend of $0.65 per share, payable on July 8, 2020 to shareholders of record at the close of business on June 24, 2020.

[0001137789-20-000035:mdna:104]
From time to time, at the Company’s discretion, we may repurchase any of our outstanding ordinary shares through tender offers, private, open market or broker-assisted purchases or other means under our stock repurchase authorization. As of April 3, 2020, $1.3 billion remained available for repurchases under our existing repurchase authorization. The timing of purchases will depend upon prevailing market conditions, alternative uses of capital and other factors. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-20-000035:mdna:105]
[same as prior period, unchanged from 0001137789-20-000015:mdna:99]

[0001137789-20-000035:mdna:106]
[same as prior period, unchanged from 0001137789-20-000015:mdna:100]

[0001137789-20-000035:mdna:107]
[same as prior period, unchanged from 0001137789-20-000015:mdna:101]

[0001137789-20-000035:mdna:108]
[same as prior period, unchanged from 0001137789-20-000015:mdna:102]

[0001137789-20-000035:mdna:109]
[same as prior period, unchanged from 0001137789-20-000015:mdna:103]

[0001137789-20-000035:mdna:110]
38
