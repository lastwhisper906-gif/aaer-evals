# STX note change history — 0001137789-20-000015 → 0001137789-20-000035


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2020-04-30):
[0001137789-20-000035:note_history:1]
Litigation

- changed (2020-04-30):
[0001137789-20-000035:note_history:2]
On August 16, 2011, the district court granted in part and denied in part the Company’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that the Company did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by the Company because the Company’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2020-02-05, similarity 0.9801):
[0001137789-20-000015:note_history:2]
On August 16, 2011, the district court granted in part and denied in part Seagate’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- changed (2020-04-30):
[0001137789-20-000035:note_history:3]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. A jury trial in this matter was previously scheduled to begin on June 1, 2020.  On April 20, 2020, the court scheduled the jury trial for November 30, 2020. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.
  (was, 2020-02-05, similarity 0.741):
[0001137789-20-000015:note_history:3]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. A jury trial in this matter is scheduled for June 1, 2020. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.

- added (2020-04-30):
[0001137789-20-000035:note_history:4]
Seagate Technology LLC, et al. v. NHK Spring Co. Ltd. and TDK Corporation, et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology International filed a complaint in the United States District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc., and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Company had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Company paid artificially high prices on its purchases of suspension assemblies. The Company seeks to recover the overcharges it paid for suspension assemblies, as well as additional relief permitted by law.

- removed (2020-04-30):
[0001137789-20-000015:note_history:5]
Intellectual Property Litigation


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-04-30):
[0001137789-20-000035:note_history:6]
The Company’s HDD products are designed for both mass capacity storage and legacy markets. Mass capacity storage supports high capacity, low-cost storage applications, including nearline, video and image applications and network-attached storage (“NAS”). Legacy markets include mission critical, desktop, notebook, digital video recorders (“DVRs”), gaming consoles and consumer applications. These markets were previously categorized as enterprise servers and storage systems, edge non-compute applications and edge compute applications. The Company’s SSD product portfolio is mainly comprised of Serial Attached SCSI (“SAS”) and Non-Volatile Memory Express (“NVMe”) and is designed primarily for applications in enterprise servers and storage systems.
  (was, 2020-02-05, similarity 0.9993):
[0001137789-20-000015:note_history:6]
The Company’s HDD products are designed for both mass capacity storage and legacy markets. Mass capacity storage supports high capacity, low-cost storage applications, including nearline, video and image applications and network-attached storage (“NAS”). Legacy markets include mission critical, desktop, notebook, digital video recorders (“DVRs”), gaming consoles and consumer applications. These markets were previously categorized as enterprise servers and storage systems, edge non-compute applications, and edge compute applications. The Company’s SSD product portfolio is mainly comprised of Serial Attached SCSI (“SAS”) and Non-Volatile Memory Express (“NVMe”) and is designed primarily for applications in enterprise servers and storage systems.

- changed (2020-04-30):
[0001137789-20-000035:note_history:7]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three and nine months ended April 3, 2020 consisted of 13 weeks and 40 weeks, respectively, and the three and nine months ended March 29, 2019 consisted of 13 weeks and 39 weeks, respectively. Fiscal year 2020, which ends on July 3, 2020, is comprised of 53 weeks and fiscal year 2019, which ended on June 28, 2019, was comprised of 52 weeks. The fiscal quarters ended April 3, 2020, January 3, 2020 and March 29, 2019, are also referred to herein as the “March 2020 quarter”, the “December 2019 quarter” and the “March 2019 quarter”, respectively. The results of operations for the three and nine months ended April 3, 2020 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending July 3, 2020.
  (was, 2020-02-05, similarity 0.8882):
[0001137789-20-000015:note_history:7]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three and six months ended January 3, 2020 consisted of 13 weeks and 27 weeks, respectively, and the three and six months ended December 28, 2018 consisted of 13 weeks and 26 weeks, respectively. Fiscal year 2020, which ends on July 3, 2020, is comprised of 53 weeks and fiscal year 2019, which ended on June 28, 2019, was comprised of 52 weeks. The fiscal quarters ended January 3, 2020, October 4, 2019 and December 28, 2018, are also referred to herein as the “December 2019 quarter”, the “September 2019 quarter” and the “December 2018 quarter”, respectively. The results of operations for the three and six months ended January 3, 2020 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending July 3, 2020.

- changed (2020-04-30):
[0001137789-20-000035:note_history:8]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. This review indicated that the actual lives of certain manufacturing equipment at its manufacturing facilities were longer than the estimated useful lives used for depreciation purposes in the Company’s condensed consolidated financial statements. As a result, effective June 29, 2019, the Company changed its estimate of the useful lives of its manufacturing equipment from a range of three to five years to a range of three to seven years. The effect of this change in estimate increased the net income by $38 million and $103 million for the three and nine months ended April 3, 2020, respectively, and increased the diluted earnings per share by $0.14 and $0.39 for the three and nine months ended April 3, 2020, respectively.
  (was, 2020-02-05, similarity 0.943):
[0001137789-20-000015:note_history:8]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. This review indicated that the actual lives of certain manufacturing equipment at its manufacturing facilities were longer than the estimated useful lives used for depreciation purposes in the Company’s condensed consolidated financial statements. As a result, effective June 29, 2019, the Company changed its estimate of the useful lives of its manufacturing equipment from a range of three to five years to a range of three to seven years. The effect of this change in estimate increased the net income by $42 million and $65 million for the three and six months ended January 3, 2020, respectively, and increased the diluted earnings per share by $0.16 and $0.24 for the three and six months ended January 3, 2020, respectively.

- changed (2020-04-30):
[0001137789-20-000035:note_history:9]
In February 2018, the FASB issued ASU 2018-02 (ASC Topic 220), Income Statement—Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”) and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. This ASU became effective and the Company adopted the guidance in the quarter ended October 4, 2019. The Company has elected not to reclassify the stranded amounts. The adoption of this guidance did not have a material impact on its condensed consolidated financial statements and disclosures.
  (was, 2020-02-05, similarity 0.979):
[0001137789-20-000015:note_history:9]
In February 2018, the FASB issued ASU 2018-02 (ASC Topic 220), Income Statement—Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”) and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. This ASU became effective and the Company adopted the guidance in the September 2019 quarter. The Company has elected not to reclassify the stranded amounts. The adoption of this guidance did not have a material impact on its condensed consolidated financial statements and disclosures.

- added (2020-04-30):
[0001137789-20-000035:note_history:10]
In March 2020, the FASB issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. generally accepted accounting principles to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. Adoption of the expedients and exceptions is permitted upon issuance of this update through December 31, 2022. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-04-30):
[0001137789-20-000035:note_history:11]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of April 3, 2020 and expects to be in compliance for the next 12 months.
  (was, 2020-02-05, similarity 0.9776):
[0001137789-20-000015:note_history:11]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of January 3, 2020 and expects to be in compliance for the next 12 months.

- changed (2020-04-30):
[0001137789-20-000035:note_history:12]
As of April 3, 2020, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the Revolving Credit Facility.
  (was, 2020-02-05, similarity 0.9716):
[0001137789-20-000015:note_history:12]
As of January 3, 2020, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the Revolving Credit Facility.

- added (2020-04-30):
[0001137789-20-000035:note_history:13]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the three and nine months ended April 3, 2020, the Company repurchased $23 million and $273 million aggregate principal amount of the 2022 Notes, respectively, for cash at a premium to their principal amount, plus accrued and unpaid interest, approximately $250 million principal amount of which was repurchased pursuant to cash tender offers for certain senior notes on September 18, 2019 (the “Tender Offers”). The Company recorded an immaterial loss and a loss of approximately $10 million on repurchases during the three and nine months ended April 3, 2020, respectively, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- added (2020-04-30):
[0001137789-20-000035:note_history:14]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the three and nine months ended April 3, 2020, the Company repurchased $17 million and $217 million aggregate principal amount of the 2023 Notes for cash at a discount or at a premium to their principal amount, plus accrued and unpaid interest, respectively, approximately $200 million principal amount of which was repurchased pursuant to the Tender Offers. The Company recorded an immaterial gain and a loss of approximately $10 million on repurchases during the three and nine months ended April 3, 2020, respectively, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- changed (2020-04-30):
[0001137789-20-000035:note_history:15]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of approximately $170 million was repurchased pursuant to the Tender Offers. The Company recorded a loss of $8 million during the nine months ended April 3, 2020, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2020-02-05, similarity 0.9633):
[0001137789-20-000015:note_history:15]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of approximately $170 million was repurchased pursuant to the Tender Offers. The Company recorded a loss of $8 million during the six months ended January 3, 2020, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- changed (2020-04-30):
[0001137789-20-000035:note_history:16]
At April 3, 2020, future principal payments on long-term debt were as follows (in millions):
  (was, 2020-02-05, similarity 0.9545):
[0001137789-20-000015:note_history:16]
At January 3, 2020, future principal payments on long-term debt were as follows (in millions):

- removed (2020-04-30):
[0001137789-20-000015:note_history:17]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of approximately $250 million was repurchased pursuant to cash tender offers for certain senior notes (the “Tender Offers”). The Company recorded a loss of $10 million during the six months ended January 3, 2020, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- removed (2020-04-30):
[0001137789-20-000015:note_history:18]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of $200 million was repurchased pursuant to the Tender Offers. The Company recorded a loss of $10 million during the six months ended January 3, 2020, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-04-30):
[0001137789-20-000035:note_history:19]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of April 3, 2020:
  (was, 2020-02-05, similarity 0.9685):
[0001137789-20-000015:note_history:19]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of January 3, 2020:


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-04-30):
[0001137789-20-000035:note_history:20]
At April 3, 2020, future principal payments on long-term debt were as follows (in millions):
  (was, 2020-02-05, similarity 0.9545):
[0001137789-20-000015:note_history:20]
At January 3, 2020, future principal payments on long-term debt were as follows (in millions):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-04-30):
[0001137789-20-000035:note_history:21]
|  |  | For the Three Months Ended |  |  |  | For the Nine Months Ended |  |  |
| (Dollars in millions) |  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,970 |  |  | $ | 1,568 |  |  | $ | 5,633 |  |  | $ | 5,571 |  |
| Distributors |  | 465 |  |  | 411 |  |  | 1,389 |  |  | 1,388 |  |
| Retailers |  | 283 |  |  | 334 |  |  | 970 |  |  | 1,060 |  |
| Total |  | $ | 2,718 |  |  | $ | 2,313 |  |  | $ | 7,992 |  |  | $ | 8,019 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,257 |  |  | $ | 1,069 |  |  | $ | 3,912 |  |  | $ | 3,923 |  |
| Americas |  | 938 |  |  | 796 |  |  | 2,534 |  |  | 2,533 |  |
| EMEA |  | 523 |  |  | 448 |  |  | 1,546 |  |  | 1,563 |  |
| Total |  | $ | 2,718 |  |  | $ | 2,313 |  |  | $ | 7,992 |  |  | $ | 8,019 |  |
  (was, 2020-02-05, similarity 0.9275):
[0001137789-20-000015:note_history:21]
|  |  | For the Three Months Ended |  |  |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | January 3,2020 |  | December 28,2018 |  | January 3,2020 |  | December 28,2018 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,843 |  |  | $ | 1,865 |  |  | $ | 3,663 |  |  | $ | 4,003 |  |
| Distributors |  | 463 |  |  | 443 |  |  | 924 |  |  | 977 |  |
| Retailers |  | 390 |  |  | 407 |  |  | 687 |  |  | 726 |  |
| Total |  | $ | 2,696 |  |  | $ | 2,715 |  |  | $ | 5,274 |  |  | $ | 5,706 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,377 |  |  | $ | 1,386 |  |  | $ | 2,655 |  |  | $ | 2,854 |  |
| Americas |  | 761 |  |  | 731 |  |  | 1,596 |  |  | 1,737 |  |
| EMEA |  | 558 |  |  | 598 |  |  | 1,023 |  |  | 1,115 |  |
| Total |  | $ | 2,696 |  |  | $ | 2,715 |  |  | $ | 5,274 |  |  | $ | 5,706 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-04-30):
[0001137789-20-000035:note_history:22]
Revenue
The following table provides information about disaggregated revenue by sales channel and geographical region for the Company’s single reportable segment:
  (was, 2020-02-05, similarity 0.9969):
[0001137789-20-000015:note_history:22]
RevenueThe following table provides information about disaggregated revenue by sales channel and geographical region for the Company’s single reportable segment:

- changed (2020-04-30):
[0001137789-20-000035:note_history:23]
|  |  | For the Three Months Ended |  |  |  | For the Nine Months Ended |  |  |
| (Dollars in millions) |  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,970 |  |  | $ | 1,568 |  |  | $ | 5,633 |  |  | $ | 5,571 |  |
| Distributors |  | 465 |  |  | 411 |  |  | 1,389 |  |  | 1,388 |  |
| Retailers |  | 283 |  |  | 334 |  |  | 970 |  |  | 1,060 |  |
| Total |  | $ | 2,718 |  |  | $ | 2,313 |  |  | $ | 7,992 |  |  | $ | 8,019 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,257 |  |  | $ | 1,069 |  |  | $ | 3,912 |  |  | $ | 3,923 |  |
| Americas |  | 938 |  |  | 796 |  |  | 2,534 |  |  | 2,533 |  |
| EMEA |  | 523 |  |  | 448 |  |  | 1,546 |  |  | 1,563 |  |
| Total |  | $ | 2,718 |  |  | $ | 2,313 |  |  | $ | 7,992 |  |  | $ | 8,019 |  |
  (was, 2020-02-05, similarity 0.9275):
[0001137789-20-000015:note_history:23]
|  |  | For the Three Months Ended |  |  |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | January 3,2020 |  | December 28,2018 |  | January 3,2020 |  | December 28,2018 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,843 |  |  | $ | 1,865 |  |  | $ | 3,663 |  |  | $ | 4,003 |  |
| Distributors |  | 463 |  |  | 443 |  |  | 924 |  |  | 977 |  |
| Retailers |  | 390 |  |  | 407 |  |  | 687 |  |  | 726 |  |
| Total |  | $ | 2,696 |  |  | $ | 2,715 |  |  | $ | 5,274 |  |  | $ | 5,706 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,377 |  |  | $ | 1,386 |  |  | $ | 2,655 |  |  | $ | 2,854 |  |
| Americas |  | 761 |  |  | 731 |  |  | 1,596 |  |  | 1,737 |  |
| EMEA |  | 558 |  |  | 598 |  |  | 1,023 |  |  | 1,115 |  |
| Total |  | $ | 2,696 |  |  | $ | 2,715 |  |  | $ | 5,274 |  |  | $ | 5,706 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2020-04-30):
[0001137789-20-000035:note_history:24]
On April 21, 2020, the Company’s Board of Directors declared a quarterly cash dividend of $0.65 per share, which will be payable on July 8, 2020 to shareholders of record as of the close of business on June 24, 2020.

- removed (2020-04-30):
[0001137789-20-000015:note_history:25]
On January 27, 2020, the Company’s Board of Directors declared a quarterly cash dividend of $0.65 per share, which will be payable on April 8, 2020 to shareholders of record as of the close of business on March 25, 2020.
