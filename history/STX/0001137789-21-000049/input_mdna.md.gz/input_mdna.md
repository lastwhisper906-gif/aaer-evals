# STX MD&A — 0001137789-21-000049


## mdna

[0001137789-21-000049:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001137789-21-000049:mdna:2]
The following is a discussion of the Company’s financial condition, changes in financial condition and results of operations for the fiscal years ended July 2, 2021, July 3, 2020 and June 28, 2019.

[0001137789-21-000049:mdna:3]
You should read this discussion in conjunction with “Item 8. Financial Statements and Supplementary Data” included elsewhere in this Annual Report on Form 10-K. Except as noted, references to any fiscal year mean the twelve-month period ending on the Friday closest to June 30 of that year. Accordingly, fiscal year 2021 comprised 52 weeks and ended on July 2, 2021. Fiscal year 2020 comprised 53 weeks and ended on July 3, 2020. Fiscal year 2019 comprised 52 weeks and ended on June 28, 2019. Fiscal year 2026 will also be comprised of 53 weeks and will end on July 3, 2026.

[0001137789-21-000049:mdna:4]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is provided in addition to the accompanying consolidated financial statements and notes to assist readers in understanding our results of operations, financial condition and cash flows. Our MD&A is organized as follows:

[0001137789-21-000049:mdna:5]
•Fiscal Year 2021 Summary. Overview of financial and other highlights affecting us in fiscal year 2021.

[0001137789-21-000049:mdna:6]
•Results of Operations. Analysis of our financial results comparing fiscal years 2021 and 2020 to the prior-year periods.

[0001137789-21-000049:mdna:7]
•Liquidity and Capital Resources. Analysis of changes in our balance sheets and cash flows, and discussion of our financial condition including potential sources of liquidity.

[0001137789-21-000049:mdna:8]
•Contractual Obligations and Off-Balance Sheet Arrangements. Overview of contractual obligations and contingent liabilities and commitments outstanding as of July 2, 2021 and an explanation of off-balance sheet arrangements.

[0001137789-21-000049:mdna:9]
•Critical Accounting Estimates. Accounting estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001137789-21-000049:mdna:10]
•For an overview of our business, see “Part I - Item 1. Business—Overview.”

[0001137789-21-000049:mdna:11]
Fiscal Year 2021 Summary

[0001137789-21-000049:mdna:12]
During fiscal year 2021, we shipped 535 exabytes of HDD storage capacity. We generated revenue of $10.7 billion, gross margins of 27%, net income of $1.3 billion and diluted EPS of $5.36 and our operating cash flow was $1.6 billion. We increased our unsecured revolving credit facility (“Revolving Credit Facility”) to $1.725 billion and issued $1.0 billion of new senior notes. We repurchased approximately 33 million of our ordinary shares for $2.0 billion and paid $649 million in dividends.

[0001137789-21-000049:mdna:13]
Impact of COVID-19

[0001137789-21-000049:mdna:14]
The COVID-19 pandemic has resulted in a widespread health crisis and numerous disease control measures being taken to limit its spread, the effects of which began during our quarter ended April 3, 2020. We continued to incur certain supply chain and demand disruptions during the fiscal year 2021, as well as higher logistics and operational costs and softer or higher demand across certain markets due to the COVID-19 pandemic, which we expect to continue into our fiscal year 2022. Our customers also continued to experience certain supply chain and demand disruptions in fiscal year 2021, which we anticipate will continue into fiscal year 2022. We are continuing to actively monitor the effects and potential impacts of the COVID-19 pandemic on all aspects of our business, liquidity and capital resources. We are complying with governmental rules and guidelines across all of our sites and are actively working on opportunities to lower our cost structure and drive further operational efficiencies. Although we are unable to predict the impact of COVID-19 on our business, results of operations, liquidity or capital resources at this time, we expect we will be negatively affected if the pandemic and related public and private health measures result in substantial manufacturing or supply chain problems, substantial reductions in demand due to disruptions in the operations of our customers or partners, disruptions in local and global economies, volatility in the global financial markets, sustained reductions or volatility in overall demand trends, restrictions on the export or shipment of our products, or other ramifications from the COVID-19 pandemic. For a further discussion of the uncertainties and business risks associated with the COVID-19 pandemic, see the section entitled “Risk Factors” in Part I, Item 1A of this Annual Report.

[0001137789-21-000049:mdna:15]
Corporate Reorganization

[0001137789-21-000049:mdna:16]
On May 18, 2021 we completed a corporate reorganization whereby a new Irish public limited company, Seagate Technology Holdings plc, serves as the publicly traded parent company of Seagate. The reorganization was carried out pursuant to a scheme of arrangement (the “Scheme”) under Irish law, which resulted in the exchange of ordinary shares of Seagate Technology plc for ordinary shares of Seagate Technology Holdings plc on a one-for-one basis. The purpose of the reorganization and the related transactions, which were completed on July 16, 2021, was to allow us to maintain our ability to make future distributions to our shareholders, including making dividend payments and effecting share redemptions and repurchases.

[0001137789-21-000049:mdna:17]
Results of Operations

[0001137789-21-000049:mdna:18]
We list in the tables below summarized information from our Consolidated Statements of Operations by dollar amounts and as a percentage of revenue:

[0001137789-21-000049:mdna:19]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | June 28,2019 |
| Revenue |  | $ | 10,681 |  |  | $ | 10,509 |  |  | $ | 10,390 |  |
| Cost of revenue |  | 7,764 |  |  | 7,667 |  |  | 7,458 |  |
| Gross profit |  | 2,917 |  |  | 2,842 |  |  | 2,932 |  |
| Product development |  | 903 |  |  | 973 |  |  | 991 |  |
| Marketing and administrative |  | 502 |  |  | 473 |  |  | 453 |  |
| Amortization of intangibles |  | 12 |  |  | 14 |  |  | 23 |  |
| Restructuring and other, net |  | 8 |  |  | 82 |  |  | (22) |  |
| Income from operations |  | 1,492 |  |  | 1,300 |  |  | 1,487 |  |
| Other expense, net |  | (144) |  |  | (268) |  |  | (115) |  |
| Income before income taxes |  | 1,348 |  |  | 1,032 |  |  | 1,372 |  |
| Provision (Benefit) for income taxes |  | 34 |  |  | 28 |  |  | (640) |  |
| Net income |  | $ | 1,314 |  |  | $ | 1,004 |  |  | $ | 2,012 |  |

[0001137789-21-000049:mdna:20]
39

[0001137789-21-000049:mdna:21]
|  |  | Fiscal Years Ended |
|  |  | July 2,2021 |  | July 3,2020 |  | June 28,2019 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 73 |  |  | 73 |  |  | 72 |  |
| Gross margin |  | 27 |  |  | 27 |  |  | 28 |  |
| Product development |  | 8 |  |  | 9 |  |  | 10 |  |
| Marketing and administrative |  | 5 |  |  | 5 |  |  | 4 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |
| Restructuring and other, net |  | — |  |  | 1 |  |  | — |  |
| Operating margin |  | 14 |  |  | 12 |  |  | 14 |  |
| Other expense, net |  | (2) |  |  | (2) |  |  | (1) |  |
| Income before income taxes |  | 12 |  |  | 10 |  |  | 13 |  |
| Provision (Benefit) for income taxes |  | — |  |  | — |  |  | (6) |  |
| Net income |  | 12 | % |  | 10 | % |  | 19 | % |

[0001137789-21-000049:mdna:22]
The following table summarizes information regarding consolidated revenues by channel, geography, and market and HDD exabytes shipped by market and price per terabyte:

[0001137789-21-000049:mdna:23]
|  |  | Fiscal Years Ended |
|  |  | July 2,2021 |  | July 3,2020 |  | June 28,2019 |
| Revenues by Channel (%) |  |  |  |  |  |  |
| OEMs |  | 69 | % |  | 71 | % |  | 70 | % |
| Distributors |  | 18 | % |  | 17 | % |  | 17 | % |
| Retailers |  | 13 | % |  | 12 | % |  | 13 | % |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |
| Asia Pacific |  | 49 | % |  | 48 | % |  | 49 | % |
| Americas |  | 34 | % |  | 34 | % |  | 32 | % |
| EMEA |  | 17 | % |  | 18 | % |  | 19 | % |
| Revenues by Market (%) |  |  |  |  |  |  |
| Mass capacity |  | 60 | % |  | 53 | % |  | 43 | % |
| Legacy |  | 32 | % |  | 39 | % |  | 50 | % |
| Other |  | 8 | % |  | 8 | % |  | 7 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |
| Mass capacity |  | 417 |  |  | 317 |  |  | 202 |  |
| Legacy |  | 118 |  |  | 125 |  |  | 145 |  |
| Total |  | 535 |  |  | 442 |  |  | 347 |  |
| HDD Price per Terabyte |  | $ | 18 |  |  | $ | 22 |  |  | $ | 28 |  |

[0001137789-21-000049:mdna:24]
____________________________________________________________

[0001137789-21-000049:mdna:25]
(1) Revenue is attributed to geography based on the bill from location.

[0001137789-21-000049:mdna:26]
Fiscal Year 2021 Compared to Fiscal Year 2020

[0001137789-21-000049:mdna:27]
Revenue

[0001137789-21-000049:mdna:28]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | Change |  | %Change |
| Revenue |  | $ | 10,681 |  |  | $ | 10,509 |  |  | $ | 172 |  |  | 2 | % |

[0001137789-21-000049:mdna:29]
40

[0001137789-21-000049:mdna:30]
Revenue in fiscal year 2021 increased approximately 2%, or $172 million, from fiscal year 2020, primarily due to an increase in mass capacity exabytes shipped, partially offset by price erosion and a decrease in legacy exabytes shipped.

[0001137789-21-000049:mdna:31]
Cost of Revenue and Gross Margin

[0001137789-21-000049:mdna:32]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | Change |  | %Change |
| Cost of revenue |  | $ | 7,764 |  |  | $ | 7,667 |  |  | $ | 97 |  |  | 1 | % |
| Gross profit |  | 2,917 |  |  | 2,842 |  |  | 75 |  |  | 3 | % |
| Gross margin |  | 27 | % |  | 27 | % |  |  |  |  |

[0001137789-21-000049:mdna:33]
For fiscal year 2021, gross margin as a percentage of revenue remained flat compared to the prior fiscal year primarily due to improved product mix, offset by price erosion and higher logistics costs as a result of the COVID-19 pandemic.

[0001137789-21-000049:mdna:34]
Operating Expenses

[0001137789-21-000049:mdna:35]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | Change |  | %Change |
| Product development |  | $ | 903 |  |  | $ | 973 |  |  | $ | (70) |  |  | (7) | % |
| Marketing and administrative |  | 502 |  |  | 473 |  |  | 29 |  |  | 6 | % |
| Amortization of intangibles |  | 12 |  |  | 14 |  |  | (2) |  |  | (14) | % |
| Restructuring and other, net |  | 8 |  |  | 82 |  |  | (74) |  |  | (90) | % |
| Operating expenses |  | $ | 1,425 |  |  | $ | 1,542 |  |  | $ | (117) |  |  |  |

[0001137789-21-000049:mdna:36]
Product Development Expense. Product development expenses for fiscal year 2021 decreased by $70 million from fiscal year 2020 primarily due to a $42 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our June 2020 restructuring plan and the additional fourteenth week in the quarter ended October 4, 2019, a $19 million decrease in information technology and software costs, a $9 million decrease in travel and entertainment expenses mainly as a result of the disruptions related to COVID-19, a $9 million decrease in materials expense and a $6 million decrease in outside services, partially offset by a $23 million increase in variable compensation expense.

[0001137789-21-000049:mdna:37]
Marketing and Administrative Expense. Marketing and administrative expenses for fiscal year 2021 increased by $29 million from fiscal year 2020 primarily due to a $46 million increase in information technology and software costs and a $14 million increase in variable compensation expense, partially offset by a $12 million decrease in depreciation expense, an $11 million decrease in travel and entertainment expenses mainly as a result of disruptions related to COVID-19, an $8 million decrease in equipment expense and a $7 million decrease in rent expense.

[0001137789-21-000049:mdna:38]
Amortization of Intangibles. Amortization of intangibles for fiscal year 2021 decreased by $2 million, as compared to fiscal year 2020, due to certain intangible assets that reached the end of their useful lives.

[0001137789-21-000049:mdna:39]
Restructuring and Other, net. Restructuring and other, net for fiscal year 2021 was $8 million, primarily comprised of workforce reduction costs and supplier transition costs, partially offset by a gain from the sale of a certain property and a gain upon termination of an operating lease.

[0001137789-21-000049:mdna:40]
Restructuring and other, net for fiscal year 2020 was $82 million, primarily comprised of restructuring charges related to the restructuring plan the Company committed to on June 1, 2020 to reduce our workforce by approximately 500 employees and charges related to a voluntary early exit program and other restructuring plans.

[0001137789-21-000049:mdna:41]
Other Expense, net

[0001137789-21-000049:mdna:42]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | Change |  | %Change |
| Other expense, net |  | $ | (144) |  |  | $ | (268) |  |  | $ | 124 |  |  | (46) | % |

[0001137789-21-000049:mdna:43]
Other expense, net for fiscal year 2021 decreased by $124 million compared to fiscal year 2020 primarily due to $62 million non-recurring losses in fiscal year 2020 from the repurchase and exchange of certain long-term debt, $51 million of strategic investment gains resulting from sales and upward adjustments in fiscal year 2021, a $49 million increase in equity method investment gains, a $15 million increase in gains on de-designated cash flow hedges and a $6 million decrease in strategic investment impairment charges. These changes were partially offset by a $20 million increase in foreign exchange remeasurement expense, a $19 million increase in interest expense due to the net increase in debt and a $17 million decrease in interest income primarily due to a decline in interest rates.

[0001137789-21-000049:mdna:44]
Income Taxes

[0001137789-21-000049:mdna:45]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | Change |  | %Change |
| Provision for income taxes |  | $ | 34 |  |  | $ | 28 |  |  | $ | 6 |  |  | 21 | % |

[0001137789-21-000049:mdna:46]
We recorded an income tax provision of $34 million for fiscal year 2021 compared to an income tax provision of $28 million for fiscal year 2020. Our fiscal year 2021 income tax provision included net tax benefits of approximately $8 million associated with share-based compensation and $13 million related to the United Kingdom tax rate changes enacted in June 2021. Our fiscal year 2020 income tax provision included net tax benefits of approximately $12 million associated with share-based compensation and $16 million associated with the release of valuation allowances on deferred tax assets driven by our profitability outlook in the U.S.

[0001137789-21-000049:mdna:47]
Our Irish tax resident parent holding company owns various U.S. and non-Irish subsidiaries that operate in multiple non-Irish income tax jurisdictions. Our worldwide operating income is either subject to varying rates of income tax or is exempt from income tax due to tax incentive programs we operate under in Malaysia, Singapore and Thailand. These tax incentives are scheduled to expire in whole or in part at various dates through 2025. Certain tax incentives may be extended if specific conditions are met.

[0001137789-21-000049:mdna:48]
Our income tax provision recorded for fiscal year 2021 and 2020 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. and non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland; and (ii) tax benefits related to research credits.

[0001137789-21-000049:mdna:49]
Based on our ownership structure and subject to (i) potential future increases in our valuation allowance for deferred tax assets; and (ii) a future change in our intention to indefinitely reinvest earnings from our subsidiaries outside of Ireland, we anticipate that our effective tax rate in future periods will generally be less than the Irish statutory rate.

[0001137789-21-000049:mdna:50]
Fiscal Year 2020 Compared to Fiscal Year 2019

[0001137789-21-000049:mdna:51]
Revenue

[0001137789-21-000049:mdna:52]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 3,2020 |  | June 28,2019 |  | Change |  | %Change |
| Revenue |  | $ | 10,509 |  |  | $ | 10,390 |  |  | $ | 119 |  |  | 1 | % |

[0001137789-21-000049:mdna:53]
Revenue in fiscal year 2020 increased approximately 1%, or $119 million, from fiscal year 2019, primarily due to an increase in mass capacity storage exabytes shipped, partially offset by price erosion and a decrease in legacy exabytes shipped.

[0001137789-21-000049:mdna:54]
Cost of Revenue and Gross Margin

[0001137789-21-000049:mdna:55]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 3,2020 |  | June 28,2019 |  | Change |  | %Change |
| Cost of revenue |  | $ | 7,667 |  |  | $ | 7,458 |  |  | $ | 209 |  |  | 3 | % |
| Gross profit |  | 2,842 |  |  | 2,932 |  |  | (90) |  |  | (3) | % |
| Gross margin |  | 27 | % |  | 28 | % |  |  |  |  |

[0001137789-21-000049:mdna:56]
For fiscal year 2020, gross margin as a percentage of revenue decreased compared to the prior fiscal year due to price erosion and higher logistics costs and factory under-utilization due to COVID-19 related disruptions, partially offset by improved product mix and lower depreciation expense due to the change in useful lives of our manufacturing equipment in the quarter ended October 4, 2019.

[0001137789-21-000049:mdna:57]
Operating Expenses

[0001137789-21-000049:mdna:58]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 3,2020 |  | June 28,2019 |  | Change |  | %Change |
| Product development |  | $ | 973 |  |  | $ | 991 |  |  | $ | (18) |  |  | (2) | % |
| Marketing and administrative |  | 473 |  |  | 453 |  |  | 20 |  |  | 4 | % |
| Amortization of intangibles |  | 14 |  |  | 23 |  |  | (9) |  |  | (39) | % |
| Restructuring and other, net |  | 82 |  |  | (22) |  |  | 104 |  |  | (473) | % |
| Operating expenses |  | $ | 1,542 |  |  | $ | 1,445 |  |  | $ | 97 |  |  |  |

[0001137789-21-000049:mdna:59]
Product Development Expense. Product development expenses for fiscal year 2020 decreased by $18 million from fiscal year 2019 primarily due to a $21 million decrease in depreciation expense and an $18 million decrease in materials expense, partially offset by a $13 million increase in outside services expense, an $8 million increase in variable compensation expense and a $7 million increase in compensation and other employee benefits.

[0001137789-21-000049:mdna:60]
Marketing and Administrative Expense. Marketing and administrative expenses for fiscal year 2020 increased by $20 million from fiscal year 2019 primarily due to a $13 million increase in other general expenses, an $11 million increase in outside services expense, a $6 million increase in share-based compensation expense and a $5 million increase in variable compensation expense, partially offset by a $5 million decrease in compensation and other employee benefits and a $4 million decrease in depreciation expense.

[0001137789-21-000049:mdna:61]
Amortization of Intangibles. Amortization of intangibles for fiscal year 2020 decreased by $9 million compared to fiscal year 2019, due to certain intangible assets reaching the end of their useful lives.

[0001137789-21-000049:mdna:62]
Restructuring and Other, net. Restructuring and other, net for fiscal year 2020 was comprised of a $82 million, primarily comprised of restructuring charges related to the restructuring plan the Company committed to on June 1, 2020 to reduce our workforce by approximately 500 employees and charges related to a voluntary early exit program and other restructuring plans.

[0001137789-21-000049:mdna:63]
Restructuring and other, net for fiscal year 2019 was comprised of a $75 million net gain from the sale of a certain property, partially offset by charges related to a voluntary early exit program.

[0001137789-21-000049:mdna:64]
Other Expense, net

[0001137789-21-000049:mdna:65]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 3,2020 |  | June 28,2019 |  | Change |  | %Change |
| Other expense, net |  | $ | (268) |  |  | $ | (115) |  |  | $ | (153) |  |  | 133 | % |

[0001137789-21-000049:mdna:66]
Other expense, net for fiscal year 2020 increased by $153 million compared to fiscal year 2019 mainly due to $80 million of non-recurring income, net in fiscal year 2019 related to our previous investment in Toshiba Memory Holdings Corporation (“TMHC”), now known as Kioxia, which was redeemed in fiscal year 2019, a $62 million loss resulting from the repurchase of certain long-term debt, an $18 million strategic investment impairment and an $11 million net increase in losses due to unfavorable changes in foreign currency exchange rates, partially offset by a $20 million decrease in interest expense related to the repurchase of certain long-term debt.

[0001137789-21-000049:mdna:67]
Income Taxes

[0001137789-21-000049:mdna:68]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | July 3,2020 |  | June 28,2019 |  | Change |  | %Change |
| Provision (benefit) for income taxes |  | $ | 28 |  |  | $ | (640) |  |  | $ | 668 |  |  | (104) | % |

[0001137789-21-000049:mdna:69]
43

[0001137789-21-000049:mdna:70]
We recorded an income tax provision of $28 million for fiscal year 2020 compared to an income tax benefit of $640 million for fiscal year 2019. Our fiscal year 2020 income tax provision included net tax benefits of approximately $12 million associated with share-based compensation and $16 million associated with the release of valuation allowance on deferred tax assets driven by our profitability outlook in the U.S. Our fiscal year 2019 income tax benefit included a net tax benefit of $761 million primarily associated with the release of valuation allowance on deferred tax assets driven by improvements in our profitability outlook in the U.S., including our efforts to structurally and operationally align our systems business with the rest of the Company.

[0001137789-21-000049:mdna:71]
Our Irish tax resident parent holding company owns various U.S. and non-Irish subsidiaries that operate in multiple non-Irish income tax jurisdictions. Our worldwide operating income is either subject to varying rates of income tax or is exempt from income tax due to tax incentive programs we operate under in Malaysia, Singapore and Thailand. These tax incentives are scheduled to expire in whole or in part at various dates through 2025. Certain tax incentives may be extended if specific conditions are met.

[0001137789-21-000049:mdna:72]
Our income tax provision recorded for fiscal year 2020 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. and non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland; and (ii) tax benefits related to research credits. Our income tax benefit recorded for fiscal year 2019 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) a decrease in valuation allowances for certain deferred tax assets, primarily driven by improvements in our profitability outlook in the U.S.; and (ii) tax benefits related to non-U.S. and non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland.

[0001137789-21-000049:mdna:73]
Based on our ownership structure and subject to (i) potential future increases in our valuation allowance for deferred tax assets; and (ii) a future change in our intention to indefinitely reinvest earnings from our subsidiaries outside of Ireland, we anticipate that our effective tax rate in future periods will generally be less than the Irish statutory rate.

[0001137789-21-000049:mdna:74]
Liquidity and Capital Resources

[0001137789-21-000049:mdna:75]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe that our sources of cash have been and will continue to be sufficient to fund our operations and meet our cash requirements for at least the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs, will allow us to manage the potential impacts of the COVID-19 pandemic on our business operations for the foreseeable future. However, the challenges posed by the COVID-19 pandemic to our industry and to our business continue to remain uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to the COVID-19 pandemic.

[0001137789-21-000049:mdna:76]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of July 2, 2021.

[0001137789-21-000049:mdna:77]
Cash and Cash Equivalents

[0001137789-21-000049:mdna:78]
|  |  | As of |  |  |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | Change |
| Cash and cash equivalents |  | $ | 1,209 |  |  | $ | 1,722 |  |  | $ | (513) |  |

[0001137789-21-000049:mdna:79]
Our cash and cash equivalents decreased by $513 million from July 3, 2020 primarily as a result of repurchases of our ordinary shares of $2,047 million, payment of dividends to our shareholders of $649 million and payments for capital expenditures of $498 million, partially offset by net cash of $1,626 million provided by operating activities and net proceeds of $986 million from issuance of long-term debt. The following table summarizes results from the Consolidated Statement of Cash Flows for the periods indicated:

[0001137789-21-000049:mdna:80]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | June 28,2019 |
| Net cash flow provided by (used in): |  |  |  |  |  |  |
| Operating activities |  | $ | 1,626 |  |  | $ | 1,714 |  |  | $ | 1,761 |  |
| Investing activities |  | (466) |  |  | (635) |  |  | 846 |  |
| Financing activities |  | (1,673) |  |  | (1,605) |  |  | (2,212) |  |
| Effect of foreign currency exchange rates |  | — |  |  | (1) |  |  | (1) |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  | $ | (513) |  |  | $ | (527) |  |  | $ | 394 |  |

[0001137789-21-000049:mdna:81]
Cash Provided by Operating Activities

[0001137789-21-000049:mdna:82]
Cash provided by operating activities for fiscal year 2021 was approximately $1.6 billion and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-21-000049:mdna:83]
•an increase of $58 million in accrued employee compensation, primarily due to an increase in our variable compensation expense; partially offset by

[0001137789-21-000049:mdna:84]
•an increase of $64 million in inventories, primarily due to an increase in materials purchased for increased production of higher capacity drives and to mitigate supply chain disruptions; and

[0001137789-21-000049:mdna:85]
•an increase of $42 million in accounts receivable, primarily due to an increase in revenue.

[0001137789-21-000049:mdna:86]
Cash provided by operating activities for fiscal year 2020 was approximately $1.7 billion and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-21-000049:mdna:87]
•an increase of $394 million in accounts payable, primarily due to timing of payments and an increase in materials purchased; partially offset by

[0001137789-21-000049:mdna:88]
•an increase of $166 million in inventories, primarily due to an increase in materials purchased for new product ramps and the potential for supply chain disruptions due to the COVID-19 pandemic; and

[0001137789-21-000049:mdna:89]
•an increase of $127 million in accounts receivable, primarily due to the timing of shipments.

[0001137789-21-000049:mdna:90]
Cash provided by operating activities for fiscal year 2019 was approximately $1.8 billion and includes the effects of net income adjusted for non-cash items including depreciation and amortization, share-based compensation, a release of valuation allowance related to our U.S. deferred tax assets and:

[0001137789-21-000049:mdna:91]
•    a decrease of $204 million in accounts receivable, primarily due to lower revenue; and

[0001137789-21-000049:mdna:92]
•    a decrease of $80 million in inventories, primarily due to a decrease in units built; partially offset by

[0001137789-21-000049:mdna:93]
•    a decrease of $268 million in accounts payable, primarily due to a decrease in direct material purchases; and

[0001137789-21-000049:mdna:94]
•    a decrease of $84 million in accrued employee compensation, primarily due to a decrease in our variable compensation expense.

[0001137789-21-000049:mdna:95]
Cash (Used in) Provided by Investing Activities

[0001137789-21-000049:mdna:96]
In fiscal year 2021, we used $0.5 billion for net cash investing activities, which was primarily due to payments for the purchase of property, equipment and leasehold improvements of approximately $498 million, partially offset by proceeds from the sale of investments of $29 million.

[0001137789-21-000049:mdna:97]
In fiscal year 2020, we used $0.6 billion for net cash investing activities, which was primarily due to payments for the purchase of property, equipment and leasehold improvements of approximately $585 million and payments for the purchase of investments of $58 million.

[0001137789-21-000049:mdna:98]
In fiscal year 2019, we received $0.8 billion for net cash investing activities, which was primarily due to proceeds of $1.3 billion from the redemption of an investment in non-convertible preferred stock of TMHC and the proceeds of $144 million primarily from the sale of certain properties, partially offset by the payments for the purchase of property, equipment and leasehold improvements of approximately $602 million.

[0001137789-21-000049:mdna:99]
Cash Used in Financing Activities

[0001137789-21-000049:mdna:100]
Net cash used in financing activities of $1.7 billion for fiscal year 2021 was primarily attributable to the following activities:

[0001137789-21-000049:mdna:101]
•$2,047 million in payments for repurchases of our ordinary shares;

[0001137789-21-000049:mdna:102]
•$649 million in dividend payments; partially offset by

[0001137789-21-000049:mdna:103]
•$986 million from the issuance of Senior Notes; and

[0001137789-21-000049:mdna:104]
•$108 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-21-000049:mdna:105]
Net cash used in financing activities of $1.6 billion for fiscal year 2020 was primarily attributable to the following activities:

[0001137789-21-000049:mdna:106]
•$1,137 million net repurchases of long-term debt;

[0001137789-21-000049:mdna:107]
•$850 million in payments for repurchases of our ordinary shares;

[0001137789-21-000049:mdna:108]
•$673 million in dividend payments; partially offset by

[0001137789-21-000049:mdna:109]
•$498 million in net proceeds from borrowings under the Term Loan;

[0001137789-21-000049:mdna:110]
•$496 million from the issuance of Senior Notes; and

[0001137789-21-000049:mdna:111]
•$103 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-21-000049:mdna:112]
Net cash used in financing activities of $2.2 billion for fiscal year 2019 was primarily attributable to the following activities:

[0001137789-21-000049:mdna:113]
•$963 million in payments for repurchases of our ordinary shares;

[0001137789-21-000049:mdna:114]
•$713 million in dividend payments; and

[0001137789-21-000049:mdna:115]
•$574 million net repurchases of long-term debt.

[0001137789-21-000049:mdna:116]
Liquidity Sources

[0001137789-21-000049:mdna:117]
Our primary sources of liquidity as of July 2, 2021, consist of: (1) approximately $1.2 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.725 billion available for borrowing under our senior unsecured revolving credit facility (“Revolving Credit Facility”), which is part of our credit agreement (the “Credit Agreement”).

[0001137789-21-000049:mdna:118]
As of July 2, 2021, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-21-000049:mdna:119]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The term of the Revolving Credit Facility is through February 20, 2024.

[0001137789-21-000049:mdna:120]
As of July 2, 2021, cash and cash equivalents held by non-Irish subsidiaries was $1.2 billion. This amount is potentially subject to taxation in Ireland upon repatriation by means of a dividend into our Irish parent. However, it is our intent to indefinitely reinvest earnings of non-Irish subsidiaries outside of Ireland and our current plans do not demonstrate a need to repatriate such earnings by means of a taxable Irish dividend. Should funds be needed in the Irish parent company and should we be unable to fund parent company activities through means other than a taxable Irish dividend, we would be required to accrue and pay Irish taxes on such dividend.

[0001137789-21-000049:mdna:121]
We believe that our sources of cash will be sufficient to fund our operations and meet our cash requirements for at least the next 12 months. For additional information on factors that could impact our ability to fund our operations and meet our cash requirements, including the COVID-19 pandemic, see the section entitled “Risk Factors” in Part I, Item 1A of this Annual Report.

[0001137789-21-000049:mdna:122]
Cash Requirements and Commitments

[0001137789-21-000049:mdna:123]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend and any future strategic investments. Our ability to fund these requirements will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001137789-21-000049:mdna:124]
From time to time, we may repurchase any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase outstanding senior notes pursuant to the terms of the applicable indenture.

[0001137789-21-000049:mdna:125]
On July 19, 2021, our Board of Directors declared a quarterly cash dividend of $0.67 per share, which will be payable on October 6, 2021 to shareholders of record as of the close of business on September 22, 2021.

[0001137789-21-000049:mdna:126]
As of July 2, 2021, we were in compliance with all of the covenants under our debt agreements. Based on our current outlook and the information we currently have available to us, we expect to be in compliance with the covenants in our debt agreements over the next 12 months.

[0001137789-21-000049:mdna:127]
The carrying value of our debt as of July 2, 2021 and July 3, 2020 was $5.1 billion and $4.2 billion, respectively. The table below presents the principal amounts of our outstanding debt:

[0001137789-21-000049:mdna:128]
|  |  | As of |  |  |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | Change |
| 4.250% Senior Notes due March 2022 |  | $ | 220 |  |  | $ | 229 |  |  | $ | (9) |  |
| 4.750% Senior Notes due June 2023 |  | 541 |  |  | 546 |  |  | (5) |  |
| 4.875% Senior Notes due March 2024 |  | 500 |  |  | 500 |  |  | — |  |
| 4.750% Senior Notes due January 2025 |  | 479 |  |  | 479 |  |  | — |  |
| 4.875% Senior Notes due June 2027 |  | 505 |  |  | 505 |  |  | — |  |
| 4.091% Senior Notes due June 2029 |  | 500 |  |  | 500 |  |  | — |  |
| 3.125% Senior Notes due July 2029 |  | 500 |  |  | — |  |  | 500 |  |
| 4.125% Senior Notes due January 2031 |  | 500 |  |  | 500 |  |  | — |  |
| 3.375% Senior Notes due July 2031 |  | 500 |  |  | — |  |  | 500 |  |
| 5.75% Senior Notes due December 2034 |  | 490 |  |  | 490 |  |  | — |  |
| LIBOR based Term Loan due September 2025 |  | 481 |  |  | 500 |  |  | (19) |  |
|  |  | $ | 5,216 |  |  | $ | 4,249 |  |  | $ | 967 |  |

[0001137789-21-000049:mdna:129]
From time to time, at the Company’s discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means, including through the use of derivative transactions. Our Board of Directors increased the authorization for the repurchase of our outstanding ordinary shares by $3.0 billion on October 21, 2020, and $2.0 billion on February 22, 2021. During fiscal year 2021, we repurchased approximately 34 million of our ordinary shares including shares withheld for statutory tax withholdings related to vesting of employee equity awards. See “Item 5. Market for Registrant’s Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities-Repurchases of Our Equity Securities.” As of July 2, 2021, $4.2 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-21-000049:mdna:130]
For fiscal year 2022, we expect capital expenditures to be aligned to our updated long-term targeted range of 4% to 6% of revenue. We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-21-000049:mdna:131]
Contractual Obligations and Commitments

[0001137789-21-000049:mdna:132]
Our contractual cash obligations and commitments as of July 2, 2021, are summarized in the table below:

[0001137789-21-000049:mdna:133]
|  |  |  |  | Fiscal Year(s) |
| (Dollars in millions) |  | Total |  | 2022 |  | 2023-2024 |  | 2025-2026 |  | Thereafter |
| Contractual Cash Obligations: |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | $ | 5,216 |  |  | $ | 245 |  |  | $ | 1,091 |  |  | $ | 885 |  |  | $ | 2,995 |  |
| Interest payments on debt |  | 1,486 |  |  | 228 |  |  | 391 |  |  | 291 |  |  | 576 |  |
| Purchase obligations (1) |  | 1,658 |  |  | 1,497 |  |  | 91 |  |  | 56 |  |  | 14 |  |
| Operating leases, including imputed interest (2) |  | 65 |  |  | 15 |  |  | 20 |  |  | 9 |  |  | 21 |  |
| Capital expenditures |  | 269 |  |  | 204 |  |  | 65 |  |  | — |  |  | — |  |
| Subtotal |  | 8,694 |  |  | 2,189 |  |  | 1,658 |  |  | 1,241 |  |  | 3,606 |  |
| Commitments: |  |  |  |  |  |  |  |  |  |  |
| Letters of credit or bank guarantees |  | 31 |  |  | 22 |  |  | — |  |  | — |  |  | 9 |  |
| Total |  | $ | 8,725 |  |  | $ | 2,211 |  |  | $ | 1,658 |  |  | $ | 1,241 |  |  | $ | 3,615 |  |

[0001137789-21-000049:mdna:134]
___________________________________

[0001137789-21-000049:mdna:135]
(1)Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms.

[0001137789-21-000049:mdna:136]
(2)Includes total future minimum rent expense under non-cancelable leases for both occupied and vacated facilities (rent expense is shown net of sublease income). Refer to “Item 8. Financial Statements and Supplementary Data—Note 6. Leases” for details.

[0001137789-21-000049:mdna:137]
As of July 2, 2021, we had a liability for unrecognized tax benefits and an accrual for the payment of related interest totaling $3 million, none of which is expected to be settled within one year. Outside of one year, we are unable to make a reasonably reliable estimate of when cash settlement with a taxing authority will occur.

[0001137789-21-000049:mdna:138]
Off-Balance Sheet Arrangements

[0001137789-21-000049:mdna:139]
As of July 2, 2021, we did not have any material off-balance sheet arrangements (as defined in Item 303(a)(4)(ii) of Regulation S-K).

[0001137789-21-000049:mdna:140]
Critical Accounting Policies and Estimates

[0001137789-21-000049:mdna:141]
The methods, estimates and judgments we use in applying our most critical accounting policies have a significant impact on the results we report in our consolidated financial statements. The SEC has defined the most critical accounting policies as the ones that are most important to the portrayal of our financial condition and operating results, and require us to make our most difficult and subjective judgments, often as a result of the need to make estimates of matters that are highly uncertain at the time of estimation. Based on this definition, our most critical accounting policies include: Revenue - Sales Program Accruals, Warranty and Income taxes. Below, we discuss these policies further, as well as the estimates and judgments involved. We also have other accounting policies and accounting estimates relating to uncollectible customer accounts, valuation of inventories, assessing goodwill and other long-lived assets for impairment, valuation of share-based payments and restructuring. We believe that these other accounting policies and accounting estimates either do not generally require us to make estimates and judgments that are as difficult or as subjective, or it is less likely that they would have a material impact on our reported results of operations for a given period.

[0001137789-21-000049:mdna:142]
Revenue - Sales Program Accruals. We record estimated variable consideration at the time of revenue recognition as a reduction to revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer's volume of purchases from us or other agreed upon rebate programs. For the distribution and retail channel, these sales incentive programs typically involve estimating the most likely amount of rebates related to a customer's level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Total sales programs were 14%, 12% and 11% of gross revenue in fiscal years 2021, 2020 and 2019, respectively. Adjustments to revenues due to under or over accruals for sales programs related to revenues reported in prior quarterly periods were less than 1% of gross revenue in fiscal years 2021, 2020 and 2019.

[0001137789-21-000049:mdna:143]
48

[0001137789-21-000049:mdna:144]
Warranty. We estimate probable product warranty costs at the time revenue is recognized. We generally provide a warranty on our products for a period of 1 to 5 years. Our warranty provision considers estimated product failure rates and trends (including the timing of product returns during the warranty periods), and estimated repair or replacement costs related to product quality issues, if any. We also exercise judgment in estimating our ability to sell refurbished products based on historical experience. Our judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited experience with those products upon which to base our warranty estimates.

[0001137789-21-000049:mdna:145]
Income Taxes. We make certain estimates and judgments in determining income tax expense for financial statement purposes. These estimates and judgments occur in the calculation of tax credits, recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for income tax and financial statement purposes, as well as tax liabilities associated with uncertain tax positions. The calculation of tax liabilities involves uncertainties in the application of complex tax rules and the potential for future adjustment of our uncertain tax positions by various taxing authorities. If estimates of these tax liabilities are greater or less than actual results, an additional tax provision or benefit will result. The deferred tax assets we record each period depend primarily on our ability to generate future taxable income in the United States and certain non-U.S. jurisdictions. Each period, we evaluate the need for a valuation allowance for our deferred tax assets and, if necessary, adjust the valuation allowance so that net deferred tax assets are recorded only to the extent we conclude it is more likely than not that these deferred tax assets will be realized. If our outlook for future taxable income changes significantly, our assessment of the need for, and the amount of, a valuation allowance may also change.

[0001137789-21-000049:mdna:146]
Recent Accounting Pronouncements

[0001137789-21-000049:mdna:147]
See “Item 8. Financial Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.
