# STX notes — 0001137789-21-000049


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001137789-21-000049:notes:1]
Basis of Presentation and Summary of Significant Accounting Policies 
Organization

[0001137789-21-000049:notes:2]
Seagate Technology Holdings plc (“STX”) and its subsidiaries (collectively, unless the context otherwise indicates, the “Company”) is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”), solid state hybrid drives (“SSHDs”) and storage subsystems.

[0001137789-21-000049:notes:3]
On May 18, 2021, Seagate Technology plc, now known as Seagate Technology Unlimited Company (“STUC”), and STX completed a scheme of arrangement pursuant to which STUC’s ordinary shares were acquired by STX and the ordinary shareholders of STUC received, on a one-for-one basis, new ordinary shares of STX (the “Scheme”). As a result of the Scheme, STUC is now a direct, wholly-owned subsidiary of STX, which is the successor issuer to STUC. In connection with the Scheme, STX assumed STUC’s existing obligations in connection with awards granted under STUC’s incentive plans and other similar employee awards and amended such plans and awards as necessary to provide for the issuance of STX’s registered shares rather than the ordinary shares of STUC upon the exercise or vesting of awards.

[0001137789-21-000049:notes:4]
Basis of Presentation and Consolidation

[0001137789-21-000049:notes:5]
The Company’s consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

[0001137789-21-000049:notes:6]
The preparation of financial statements in accordance with the United States (“U.S.”) generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated financial statements and accompanying notes. These estimates and assumptions include the impact of the COVID-19 pandemic. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its consolidated financial statements.

[0001137789-21-000049:notes:7]
Fiscal Year

[0001137789-21-000049:notes:8]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Accordingly, fiscal years 2021 and 2019 were comprised of 52 weeks and ended on July 2, 2021 and June 28, 2019, respectively. Fiscal year 2020 was comprised of 53 weeks and ended on July 3, 2020. All references to years in these Notes to Consolidated Financial Statements represent fiscal years unless otherwise noted. Fiscal year 2026 will also be comprised of 53 weeks and will end on July 3, 2026.

[0001137789-21-000049:notes:9]
Summary of Significant Accounting Policies

[0001137789-21-000049:notes:10]
Cash and Cash Equivalents. The Company considers all highly liquid investments with a remaining maturity of 90 days or less at the time of purchase to be cash equivalents. The Company’s highly liquid investments are primarily comprised of money market funds, time deposits and certificates of deposits. The Company has classified its marketable debt securities as available-for-sale and they are stated at fair value with unrealized gains and losses included in Accumulated other comprehensive loss, which is a component of Shareholders’ Equity. The Company evaluates the available-for sale debt securities in an unrealized loss position for other-than-temporary impairment. Realized gains and losses are included in Other, net on the Company’s Consolidated Statements of Operations. The cost of securities sold is based on the specific identification method. Other cash equivalents are carried at cost, which approximates fair value.

[0001137789-21-000049:notes:11]
Restricted Cash and Cash Equivalents. Restricted cash and cash equivalents represent cash and cash equivalents that are restricted as to withdrawal or use for other than current operations.

[0001137789-21-000049:notes:12]
Allowance for expected credit loss. The Company maintains an allowance for expected credit loss relating to its accounts receivable based upon expected collectability. This reserve is established based upon historical trends, global macroeconomic conditions, reasonable and supportable forecasts of future conditions and an analysis of specific exposures. The provision for expected credit loss is recorded as a charge to Marketing and administrative expense on the Company’s Consolidated Statements of Operations.

[0001137789-21-000049:notes:13]
Inventories. Inventories are valued at the lower of cost (using the first-in, first-out method) and net realizable value. Net realizable value is based upon the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. Adjustments to reduce cost of inventories to its net realizable value are made, if required, for estimated excess or obsolescence determined primarily by future demand forecasts.

[0001137789-21-000049:notes:14]
Property, Equipment and Leasehold Improvements. Property, equipment and leasehold improvements are stated at cost less accumulated depreciation and amortization. Equipment and buildings are depreciated using the straight-line method over the estimated useful lives of the assets. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated life of the asset or the remaining term of the lease. The costs of additions and substantial improvements to property, equipment and leasehold improvements, which extend the economic life of the underlying assets, are capitalized. The cost of maintenance and repairs to property, equipment and leasehold improvements is expensed as incurred.

[0001137789-21-000049:notes:15]
Goodwill. The Company performs a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. If it is determined in the qualitative assessment that the fair value of a reporting unit is more likely than not below its carrying amount, including goodwill, then the Company will perform a quantitative impairment test. The quantitative goodwill impairment test is performed by comparing the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit over its fair value is recognized as an impairment loss, limited to the total amount of goodwill allocated to that reporting unit.

[0001137789-21-000049:notes:16]
Other Long-lived Assets. The Company tests other long-lived assets, including property, equipment and leasehold improvements and other intangible assets subject to amortization, for recoverability whenever events or changes in circumstances indicate that the carrying value of those assets may not be recoverable. The Company performs a recoverability test to assess the recoverability of an asset group. If the recoverability test indicates that the carrying value of the asset group is not recoverable, the Company will estimate the fair value of the asset group and the excess of the carrying value over the fair value is allocated pro rata to derive the adjusted carrying value of assets in the asset group. The adjusted carrying value of each asset in the asset group is not reduced below its fair value.

[0001137789-21-000049:notes:17]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. This review indicated that the actual lives of certain manufacturing equipment at its manufacturing facilities were longer than the estimated useful lives used for depreciation purposes in the Company’s consolidated financial statements. As a result, effective June 29, 2019, the Company changed its estimate of the useful lives of its manufacturing equipment from a range of three to five years to a range of three to seven years. The effect of this change in estimate increased the net income by $134 million for the fiscal year ended July 3, 2020 and increased the diluted earnings per share by $0.51 for the fiscal year ended July 3, 2020.

[0001137789-21-000049:notes:18]
The Company tests other intangible assets not subject to amortization whenever events occur or circumstances change, such as declining financial performance, deterioration in the environment in which the entity operates or deteriorating macroeconomic conditions that have a negative effect on future expected earnings and cash flows that could affect significant inputs used to determine the fair value of the indefinite-lived intangible asset.

[0001137789-21-000049:notes:19]
Assets Held for Sale. The Company classifies its long-lived assets to be sold as held for sale in the period (i) it has approved and committed to a plan to sell the asset, (ii) the asset is available for immediate sale in its present condition, (iii) an active program to locate a buyer and other actions required to sell the asset have been initiated, (iv) the sale of the asset is probable, (v) the asset is being actively marketed for sale at a price that is reasonable in relation to its current fair value and (vi) it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn. The Company initially measures a long-lived asset that is classified as held for sale at the lower of its carrying value or fair value less any costs to sell. Any loss resulting from this measurement is recognized in the period in which the held for sale criteria are met. Conversely, gains are not recognized on the sale of a long-lived asset until the date of sale. Upon designation as an asset held for sale, the Company stops recording depreciation expense on the asset. The Company assesses the fair value of a long-lived asset less any costs to sell at each reporting period and until the asset is no longer classified as held for sale.

[0001137789-21-000049:notes:20]
Leases. Effective June 29, 2019, the Company adopted a new accounting policy for leases in accordance with Accounting Standard Codification (“ASC”) 842, Leases, using the modified retrospective approach. Accordingly, the Company applied the new lease accounting standard prospectively to leases existing or commencing on or after June 29, 2019. The Company elected to apply the practical expedients which allow for not reassessing whether existing contracts contain leases, the classification of existing leases and whether the existing initial direct costs meet the new definition. In addition, the Company elected to combine lease and non-lease components for facility leases and to not recognize right-of-use (“ROU”) assets and lease liabilities for leases with an initial term of 12 months or less on the balance sheet.

[0001137789-21-000049:notes:21]
The Company determines if an arrangement is a lease or contains a lease at inception. ROU assets are included in Other assets, net and lease liabilities are included in Accrued expenses and Other non-current liabilities on the Company’s Consolidated Balance Sheets. ROU assets represent the Company’s right to use an underlying asset for the lease term and the corresponding lease liabilities represent its obligation to make lease payments arising from the lease.

[0001137789-21-000049:notes:22]
Lease liabilities are measured at the present value of the remaining lease payments and ROU assets are based on the lease liability, adjusted for lease prepayments, lease incentives received and the lessee’s initial direct costs. For the Company’s leases that do not provide an implicit rate, the net present value of future minimum lease payments is determined using the Company’s estimated incremental borrowing rate based on the information available at the lease commencement date. Additionally, the Company’s lease term may include options to extend or terminate the lease. These options are reflected in the ROU asset and lease liability when it is reasonably certain that the Company will exercise the option. The Company’s lease agreements do not contain any material residual value guarantees.

[0001137789-21-000049:notes:23]
The Company recognizes lease expense on a straight-line basis over the lease term. Variable lease payments not dependent on an index or a rate primarily consist of common area maintenance charges, are expensed as incurred, and are not included in the ROU asset and lease liability calculation. The total operating and variable lease costs were included in operating expenses in the Company’s Consolidated Statements of Operations.

[0001137789-21-000049:notes:24]
Payment-in-Kind (“PIK”) Income. The Company had a debt investment in non-convertible preferred stock of Toshiba Memory Holdings Corporation (“TMHC”), now known as Kioxia, that was fully redeemed by TMHC in June 2019. Transaction costs incurred by the Company to acquire this investment were capitalized and amortized as a reduction of interest income on the Consolidated Statements of Operations over the respective term of the investment. The investment contained a PIK income provision, which represented contractual interest that was due upon redemption, and was accrued and recorded as Interest income each reporting period and added to the carrying value of the Investment in debt security.

[0001137789-21-000049:notes:25]
Derivative Financial Instruments. The Company records all derivatives on the balance sheet at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company excludes the change in forward points from the assessment of hedge effectiveness and recognizes the excluded component in Other, net in the Consolidated Statements of Operations. Foreign currency forward exchange contracts not designated as hedge instruments are used to economically hedge the foreign currency exposure on forecasted expenditures in currencies other than U.S. dollar. The Company recognizes the unrealized gains and losses due to the changes in the fair value of these contracts, as well as the related costs in Other, net in the Consolidated Statements of Operations.

[0001137789-21-000049:notes:26]
Warranty. The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally provides warranty on its products for a period of 1 to 5 years. The Company's warranty provision considers estimated product failure rates and trends (including the timing of product returns during the warranty periods), and estimated repair or replacement costs related to product quality issues, if any. The Company also exercises judgment in estimating its ability to sell refurbished products. The Company's judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited experience with those products upon which to base our warranty estimates.

[0001137789-21-000049:notes:27]
Revenue Recognition and Sales Incentive Programs. The Company determines revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, the Company satisfies a performance obligation.

[0001137789-21-000049:notes:28]
Revenue from sales of products is generally recognized upon transfer of control to customers in an amount that reflects the consideration the Company expects to receive in exchange for those products, net of sales taxes. This typically occurs upon shipment from the Company. When applicable, the Company includes shipping charges billed to customers in Revenue and includes the related shipping costs in Cost of revenue on the Company's Consolidated Statements of Operations.

[0001137789-21-000049:notes:29]
The Company records estimated variable consideration at the time of revenue recognition as a reduction to revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For original equipment manufacturers (“OEMs”) sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer’s volume of purchases from the Company or other agreed upon rebate programs. For the distribution and retail channel, these programs typically involve estimating the most likely amount of rebates related to a customer’s level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Marketing development program costs are accrued and recorded as a reduction to revenue at the same time that the related revenue is recognized.

[0001137789-21-000049:notes:30]
The Company expenses sales commissions as incurred because the amortization period would have been one year or less. These costs are recorded as Marketing and administrative on the Company’s Consolidated Statements of Operations.

[0001137789-21-000049:notes:31]
Restructuring Costs. The timing of recognition for severance costs depends on whether employees are required to render service until they are terminated in order to receive the termination benefits. If employees are required to render service until they are terminated in order to receive the termination benefits, a liability is recognized ratably over the future service period. Otherwise, a liability is recognized when management has committed to a restructuring plan and has communicated those actions to employees. Employee termination benefit costs covered by existing benefit arrangements are recognized when management has committed to a restructuring plan and the severance costs are probable and estimable.

[0001137789-21-000049:notes:32]
Advertising Expense. The cost of advertising is expensed as incurred. Advertising costs were approximately $13 million, $19 million and $22 million in fiscal years 2021, 2020 and 2019, respectively.

[0001137789-21-000049:notes:33]
Share-Based Compensation. The Company has elected to apply the with-and-without method to assess the realization of related excess tax benefits. The Company also elected to continue to account for share-based compensation expense net of estimated forfeitures. Refer to Note 11. Compensation for details.

[0001137789-21-000049:notes:34]
Accounting for Income Taxes. The Company makes certain estimates and judgments in determining income tax expense for financial statement purposes. These estimates and judgments occur in the calculation of tax credits, recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for income tax and financial statement purposes, as well as tax liabilities associated with uncertain tax positions. The calculation of tax liabilities involves uncertainties in the application of complex tax rules and the potential for future adjustment of the Company’s uncertain tax positions by various taxing authorities. If estimates of these tax liabilities are greater or less than actual results, an additional tax provision or benefit will result. The deferred tax assets the Company records each period depend primarily on the Company’s ability to generate future taxable income in the United States and certain non-U.S. jurisdictions. Each period, the Company evaluates the need for a valuation allowance for its deferred tax assets and, if necessary, adjusts the valuation allowance so that net deferred tax assets are recorded only to the extent the Company concludes it is more likely than not that these deferred tax assets will be realized. If the Company’s outlook for future taxable income changes significantly, the Company’s assessment of the need for, and the amount of, a valuation allowance may also change.

[0001137789-21-000049:notes:35]
Equity Investments. From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives, which are accounted for either under equity method or the measurement alternative. These investments are included in Other assets, net in the Company's Consolidated Balance Sheets and are adjusted through Other, net in the Consolidated Statement of Operations.

[0001137789-21-000049:notes:36]
Investments are accounted for under the equity method if the Company has the ability to exercise significant influence, but does not have a controlling financial interest. These investments are measured at cost, less any impairment plus the Company's portion of investee’s income or loss. The Company uses the financial statements of investees to determine any adjustments, which are received on a one-quarter lag.

[0001137789-21-000049:notes:37]
For equity investments where the Company does not have the ability to exercise significant influence and there are no readily determinable fair values, the Company has elected to apply the measurement alternative, under which investments are measured at cost, less impairment, and adjusted for qualifying observable price changes on a prospective basis.

[0001137789-21-000049:notes:38]
The Company’s strategic investments are periodically analyzed to determine whether or not there are indicators of impairment by assessing factors such as deterioration of earnings, adverse change in market/industry conditions, the ability to operate as a going concern, and other factors which indicate that the carrying amount of the investment might not be recoverable. In such a case, the decrease in value is recognized in the period the impairment occurs in the Consolidated Statements of Operations.

[0001137789-21-000049:notes:39]
Comprehensive Income. The Company presents comprehensive income in a separate statement. Comprehensive income is comprised of net income and other gains and losses affecting equity that are excluded from net income.

[0001137789-21-000049:notes:40]
Foreign Currency Remeasurement and Translation. The U.S. dollar is the functional currency for the majority of the Company's foreign operations. Monetary assets and liabilities denominated in foreign currencies are remeasured into the functional currency of the subsidiary at the balance sheet date. The gains and losses from the remeasurement of foreign currency denominated balances into the functional currency of the subsidiary are included in Other, net on the Company's Consolidated Statements of Operations. The Company’s subsidiaries that use the U.S. dollar as their functional currency remeasure monetary assets and liabilities at exchange rates in effect at the end of each period, and nonmonetary assets and liabilities at historical rates.

[0001137789-21-000049:notes:41]
The Company translates the assets and liabilities of its non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recognized in foreign currency translation included in Accumulated other comprehensive loss, which is a component of Shareholders’ Equity.

[0001137789-21-000049:notes:42]
Concentrations

[0001137789-21-000049:notes:43]
Concentration of Credit Risk. The Company’s customer base is concentrated with a small number of customers. The Company does not generally require collateral or other security to support accounts receivable. To reduce credit risk, the Company performs ongoing credit evaluations on its customers’ financial condition. The Company establishes allowances for expected credit losses based upon factors surrounding the credit risk of customers, global macroeconomic conditions and an analysis of specific exposures. One customer accounted for 11% and 11% of the Company’s accounts receivable as of July 2, 2021 and July 3, 2020, respectively, and one customer accounted for 15% of the Company’s accounts receivable as of July 3, 2020.

[0001137789-21-000049:notes:44]
Financial instruments that potentially subject the Company to concentrations of credit risk consist primarily of cash equivalents, investments and foreign currency forward exchange contracts. The Company mitigates concentrations of credit risk in its financial instruments through diversification, by investing in highly-rated securities and/or major multinational companies.

[0001137789-21-000049:notes:45]
In entering into foreign currency forward exchange contracts, the Company assumes the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial and investment banks, and the Company has not incurred and does not expect any losses as a result of counterparty defaults.

[0001137789-21-000049:notes:46]
Supplier Concentration. Certain of the raw materials, components and equipment used by the Company in the manufacture of its products are available from single-sourced direct and indirect vendors. Shortages could occur in these essential materials and components due to an interruption of supply or increased demand in the industry. If the Company were unable to procure certain materials, components or equipment at all or acceptable prices, it would be required to reduce its manufacturing operations, which could have a material adverse effect on its results of operations. In addition, the Company may make prepayments to certain suppliers or enter into minimum volume commitment agreements. Should these suppliers be unable to deliver on their obligations or experience financial difficulty, the Company may not be able to recover these prepayments.

[0001137789-21-000049:notes:47]
Recently Issued Accounting Pronouncements

[0001137789-21-000049:notes:48]
In December 2019, the FASB issued ASU 2019-12 (ASC Topic 740), Simplifying the Accounting for Income Taxes. This ASU simplifies accounting for income taxes by removing certain exceptions to the general principles and amending existing guidance to improve consistent application. The Company is required to adopt this guidance in the first quarter of fiscal year 2022. The Company does not expect the adoption of this ASU to have a material impact on its consolidated financial statements.

[0001137789-21-000049:notes:49]
In March 2020, the FASB issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. generally accepted accounting principles to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. Adoption of the expedients and exceptions is permitted upon issuance of this update through December 31, 2022. The Company does not expect the adoption of this ASU to have a material impact on its consolidated financial statements.

[0001137789-21-000049:notes:50]
Recently Adopted Accounting Pronouncements

[0001137789-21-000049:notes:51]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13 (ASC Topic 326), Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held to include future conditions in its estimate of expected credit losses. The Company adopted this new accounting pronouncement in the quarter ended October 2, 2020. The adoption of this ASU did not have a material impact on the Company’s consolidated financial statements.

[0001137789-21-000049:notes:52]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles—Goodwill and Other - Internal-Use Software—Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company adopted this new accounting pronouncement in the quarter ended October 2, 2020. The adoption of this ASU did not have a material impact on the Company’s consolidated financial statements.


## us-gaap:DerivativesPolicyTextBlock

[0001137789-21-000049:notes:53]
Derivative Financial Instruments. The Company records all derivatives on the balance sheet at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company excludes the change in forward points from the assessment of hedge effectiveness and recognizes the excluded component in Other, net in the Consolidated Statements of Operations. Foreign currency forward exchange contracts not designated as hedge instruments are used to economically hedge the foreign currency exposure on forecasted expenditures in currencies other than U.S. dollar. The Company recognizes the unrealized gains and losses due to the changes in the fair value of these contracts, as well as the related costs in Other, net in the Consolidated Statements of Operations. July 2, 2021 and July 3, 2020. respectively. As of July 2, 2021, the amount of existing net losses related to cash flow hedges recorded in Accumulated other comprehensive loss included a net loss of $5 million that is expected to be reclassified to earnings within twelve months.The Company de-designates its cash flow hedges when the forecasted hedged transactions affects earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss on the Company’s Consolidated Balance Sheets are reclassified into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company recognized a net gain of $14 million in Cost of revenue and a net loss of $7 million in Interest expense related to the loss of hedge designation on discontinued cash flow hedges during fiscal year 2021. The Company recognized a net loss of $3 million in Other expense, net related to the loss of hedge designation on discontinued cash flow hedges during fiscal year 2020. The Company did not recognize any material amounts related to the loss of hedge designation on discontinued cash flow hedges during the fiscal year 2019.Other derivatives not designated as hedging instruments consist of foreign currency forward exchange contracts that the Company uses to hedge the foreign currency exposure on forecasted expenditures denominated in currencies other than the U.S. dollar. The Company recognizes gains and losses on these contracts, as well as the related costs in Other, net on its Consolidated Statements of Operations.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001137789-21-000049:notes:54]
Balance Sheet Information
Available-for-sale Debt Securities

[0001137789-21-000049:notes:55]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of July 2, 2021:

[0001137789-21-000049:notes:56]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale debt securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 552 |  |  | $ | — |  |  | $ | 552 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 571 |  |  | $ | — |  |  | $ | 571 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 551 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 571 |  |

[0001137789-21-000049:notes:57]
As of July 2, 2021, the Company’s Other current assets included $2 million in restricted cash equivalents held as collateral at banks for various performance obligations.

[0001137789-21-000049:notes:58]
As of July 2, 2021, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale debt securities were other-than-temporarily impaired as of July 2, 2021.

[0001137789-21-000049:notes:59]
The fair value and amortized cost of the Company’s investments classified as available-for-sale debt securities at July 2, 2021 by remaining contractual maturity were as follows:

[0001137789-21-000049:notes:60]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 553 |  |  | $ | 553 |  |
| Due in 1 to 5 years |  | 10 |  |  | 10 |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | 8 |  |  | 8 |  |
| Total |  | $ | 571 |  |  | $ | 571 |  |

[0001137789-21-000049:notes:61]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of July 3, 2020:

[0001137789-21-000049:notes:62]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 495 |  |  | $ | — |  |  | $ | 495 |  |
| Time deposits and certificates of deposits |  | 56 |  |  | — |  |  | 56 |  |
| Other debt securities |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 569 |  |  | $ | — |  |  | $ | 569 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 549 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 569 |  |

[0001137789-21-000049:notes:63]
As of July 3, 2020, the Company’s Other current assets included $2 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001137789-21-000049:notes:64]
As of July 3, 2020, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale debt securities were other-than-temporarily impaired as of July 3, 2020.

[0001137789-21-000049:notes:65]
Cash, Cash Equivalents and Restricted Cash

[0001137789-21-000049:notes:66]
The following table provides a summary of cash, cash equivalents and restricted cash reported within the Consolidated Balance Sheets that reconciles to the corresponding amount in the Consolidated Statements of Cash Flows:

[0001137789-21-000049:notes:67]
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | June 28,2019 |  | June 29,2018 |
| Cash and cash equivalents |  | $ | 1,209 |  |  | $ | 1,722 |  |  | $ | 2,220 |  |  | $ | 1,853 |  |
| Restricted cash included in Other current assets |  | 2 |  |  | 2 |  |  | 31 |  |  | 4 |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  | $ | 1,211 |  |  | $ | 1,724 |  |  | $ | 2,251 |  |  | $ | 1,857 |  |

[0001137789-21-000049:notes:68]
As of June 28, 2019, the Company’s Other current assets included $31 million in restricted cash and cash equivalents in an escrow account for the sale of certain properties and cash equivalents held as collateral at banks for various performance obligations

[0001137789-21-000049:notes:69]
Accounts Receivable, net

[0001137789-21-000049:notes:70]
The following table provides details of the accounts receivable, net balance sheet item:

[0001137789-21-000049:notes:71]
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |
| Accounts receivable |  | $ | 1,162 |  |  | $ | 1,120 |  |
| Allowances for expected credit losses |  | (4) |  |  | (5) |  |
| Account receivable, net |  | $ | 1,158 |  |  | $ | 1,115 |  |

[0001137789-21-000049:notes:72]
Activity in the expected credit losses accounts is as follows:

[0001137789-21-000049:notes:73]
| (Dollars in millions) |  | Balance at Beginning of Period |  | Charges (Credit) to Operations |  | Deductions (1) |  | Balance at End of Period |
| Fiscal year ended June 28, 2019 |  | $ | 4 |  |  | — |  |  | — |  |  | $ | 4 |  |
| Fiscal year ended July 3 2020 |  | $ | 4 |  |  | 1 |  |  | — |  |  | $ | 5 |  |
| Fiscal year ended July 2, 2021 |  | $ | 5 |  |  | — |  |  | (1) |  |  | $ | 4 |  |

[0001137789-21-000049:notes:74]
______________________________________________

[0001137789-21-000049:notes:75]
(1)    Uncollectible accounts written off, net of recoveries.

[0001137789-21-000049:notes:76]
In connection with an existing factoring agreement, the Company sells trade receivables to a third party for cash proceeds less a discount. During fiscal year 2021, the Company sold trade receivables without recourse for cash proceeds of $183 million, of which none remained subject to servicing by the Company as of July 2, 2021. During fiscal year 2020, the Company sold trade receivables without recourse for cash proceeds of $89 million, of which $10 million remained subject to servicing by the Company as of July 3, 2020. The discounts on trade receivables sold were not material for fiscal years 2021 and 2020.

[0001137789-21-000049:notes:77]
Inventories

[0001137789-21-000049:notes:78]
The following table provides details of the inventory balance sheet item:

[0001137789-21-000049:notes:79]
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |
| Raw materials and components |  | $ | 375 |  |  | $ | 451 |  |
| Work-in-process |  | 443 |  |  | 313 |  |
| Finished goods |  | 386 |  |  | 378 |  |
| Total inventories |  | $ | 1,204 |  |  | $ | 1,142 |  |

[0001137789-21-000049:notes:80]
Property, Equipment and Leasehold Improvements, net

[0001137789-21-000049:notes:81]
The components of property, equipment and leasehold improvements, net were as follows:

[0001137789-21-000049:notes:82]
| (Dollars in millions) |  | Useful Life in Years (1) |  | July 2,2021 |  | July 3,2020 |
| Land and land improvements |  |  |  | $ | 47 |  |  | $ | 48 |  |
| Equipment |  | 3 – 7 |  | 8,250 |  |  | 8,033 |  |
| Buildings and leasehold improvements |  | Up to 30 |  | 1,881 |  |  | 1,848 |  |
| Construction in progress |  |  |  | 200 |  |  | 283 |  |
|  |  |  |  | 10,378 |  |  | 10,212 |  |
| Less: accumulated depreciation and amortization |  |  |  | (8,197) |  |  | (8,083) |  |
| Property, equipment and leasehold improvements, net |  |  |  | $ | 2,181 |  |  | $ | 2,129 |  |

[0001137789-21-000049:notes:83]
(1)    Effective June 29, 2019, the Company changed its estimate of the useful lives of its manufacturing equipment from a range of three to five years to a range of three to seven years. Please refer to Note 1. Basis of Presentation and Summary of Significant Accounting Policies for more details.

[0001137789-21-000049:notes:84]
Depreciation expense, which includes amortization of leasehold improvements, was $368 million, $325 million and $464 million for fiscal years 2021, 2020 and 2019, respectively. Interest on borrowings related to eligible capital expenditures is capitalized as part of the cost of the qualified assets and amortized over the estimated useful lives of the assets. During fiscal years 2021, 2020 and 2019, the Company capitalized interest of $5 million, $6 million and $3 million, respectively.

[0001137789-21-000049:notes:85]
Accrued Expenses

[0001137789-21-000049:notes:86]
The following table provides details of the accrued expenses balance sheet item:

[0001137789-21-000049:notes:87]
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |
| Dividends payable |  | $ | 153 |  |  | $ | 167 |  |
| Other accrued expenses |  | 455 |  |  | 435 |  |
| Total |  | $ | 608 |  |  | $ | 602 |  |

[0001137789-21-000049:notes:88]
Accumulated Other Comprehensive Loss (“AOCL”)

[0001137789-21-000049:notes:89]
The components of AOCL, net of tax, were as follows:

[0001137789-21-000049:notes:90]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at June 28, 2019 |  | $ | — |  |  |  | $ | (20) |  |  | $ | (14) |  |  | $ | (34) |  |
| Other comprehensive loss before reclassifications |  | (27) |  |  |  | (7) |  |  | (2) |  |  | (36) |  |
| Amounts reclassified from AOCL to Consolidated Statements of Operations |  | 3 |  |  |  | 1 |  |  | — |  |  | 4 |  |
| Other comprehensive loss |  | (24) |  |  |  | (6) |  |  | (2) |  |  | (32) |  |
| Balance at July 3, 2020 |  | (24) |  |  |  | (26) |  |  | (16) |  |  | (66) |  |
| Other comprehensive gain before reclassifications |  | 15 |  |  |  | 1 |  |  | 15 |  |  | 31 |  |
| Amounts reclassified from AOCL to Consolidated Statements of Operations |  | (9) |  |  |  | 3 |  |  | — |  |  | (6) |  |
| Other comprehensive income |  | 6 |  |  |  | 4 |  |  | 15 |  |  | 25 |  |
| Balance at July 2, 2021 |  | $ | (18) |  |  |  | $ | (22) |  |  | $ | (1) |  |  | $ | (41) |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0001137789-21-000049:notes:91]
July 2, 2021:

[0001137789-21-000049:notes:92]
July 3, 2020:


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001137789-21-000049:notes:93]
Goodwill and Other Intangible Assets
Goodwill

[0001137789-21-000049:notes:94]
The carrying amount of goodwill was $1,237 million as of July 2, 2021 and July 3, 2020. There were no additions to, disposals of, impairments of or translation adjustments to goodwill in fiscal years 2021, 2020 and 2019.

[0001137789-21-000049:notes:95]
Other Intangible Assets

[0001137789-21-000049:notes:96]
Other intangible assets consist primarily of existing technology, customer relationships and trade names acquired in business combinations. Intangibles are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization is charged to Operating expenses in the Consolidated Statements of Operations.

[0001137789-21-000049:notes:97]
In fiscal years 2021, 2020 and 2019, amortization expense for other intangible assets was $29 million, $53 million and $77 million, respectively.

[0001137789-21-000049:notes:98]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of July 2, 2021, is set forth in the following table:

[0001137789-21-000049:notes:99]
| (Dollars in millions) |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life |
| Existing technology |  | $ | 43 |  |  | $ | (30) |  |  | $ | 13 |  |  | 1.8 Years |
| Customer relationships |  | 71 |  |  | (58) |  |  | 13 |  |  | 1.2 Years |
| Other intangible assets |  | 9 |  |  | (6) |  |  | 3 |  |  | 1.7 Years |
| Total amortizable other intangible assets |  | $ | 123 |  |  | $ | (94) |  |  | $ | 29 |  |  | 1.5 Years |

[0001137789-21-000049:notes:100]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of July 3, 2020 is set forth in the following table:

[0001137789-21-000049:notes:101]
| (Dollars in millions) |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life |
| Existing technology |  | $ | 199 |  |  | $ | (179) |  |  | $ | 20 |  |  | 1.5 Years |
| Customer relationships |  | 71 |  |  | (48) |  |  | 23 |  |  | 2.2 Years |
| Trade name |  | 2 |  |  | (2) |  |  | — |  |  | 0.2 Years |
| Other intangible assets |  | 19 |  |  | (4) |  |  | 15 |  |  | 2.9 Years |
| Total amortizable other intangible assets |  | $ | 291 |  |  | $ | (233) |  |  | $ | 58 |  |  | 2.1 Years |

[0001137789-21-000049:notes:102]
As of July 2, 2021, expected amortization expense for other intangible assets for each of the next two years is as follows:

[0001137789-21-000049:notes:103]
| (Dollars in millions) |  | Amount |
| 2022 |  | $ | 20 |  |
| 2023 |  | 9 |  |
| Thereafter |  | — |  |
| Total |  | $ | 29 |  |


## us-gaap:DebtDisclosureTextBlock

[0001137789-21-000049:notes:104]
Debt
Credit Agreement

[0001137789-21-000049:notes:105]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement on February 20, 2019, which was   amended on January 13, 2021 and May 18, 2021 (the “Credit Agreement”), increasing the size of the senior unsecured revolving credit facility (“Revolving Credit Facility”), capping the indebtedness guaranteed by certain of Seagate HDD Cayman’s material subsidiaries to an amount $100 million less than the amount that would give rise to a guarantee requirement by such subsidiaries in respect of any series of senior notes and amending certain definitions, covenants, and other provisions to contemplate STX as the parent entity as of the Scheme effective time, respectively. In connection with the May 18, 2021 amendment, STX entered into a joinder agreement pursuant to which, at the Scheme effective time, it became a party to and guarantor of the Credit Agreement. The Credit Agreement provides an up to $1.725 billion senior unsecured revolving credit facility and a term loan facility in an aggregate principal amount of $500 million (“Term Loan”). The Revolving Credit Facility has a final maturity of February 20, 2024 and the Term Loan has a final maturity date of September 16, 2025. The loans made under the Revolving Credit Facility and Term Loan will bear interest at a rate of the London Interbank Offered Rate (“LIBOR”) plus a variable margin for each facility that will be determined based on the corporate credit rating of the Company. STX and certain of its material subsidiaries, including STUC, fully and unconditionally guarantee both the Revolving Credit Facility and Term Loan. The Revolving Credit Facility also allows such facility to increase by an additional $275 million, provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at least $25 million and (iii) the existing commitments under the facility receive 0.50% most favored nation protection. An aggregate amount of up to $75 million of the Revolving Credit Facility is available for the issuance of letters of credit, and an aggregate amount of up to $50 million of such facility is also available for swing line loans.

[0001137789-21-000049:notes:106]
On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the Term Loan and the proceeds were used to repurchase a portion of its outstanding senior notes. The Term Loan is repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with the remaining balance payable upon maturity. The Company repaid $19 million principal amount of the Term Loan during fiscal year 2021.

[0001137789-21-000049:notes:107]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of July 2, 2021 and expects to be in compliance for the next 12 months.

[0001137789-21-000049:notes:108]
As of July 2, 2021, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility.

[0001137789-21-000049:notes:109]
Long-Term Debt

[0001137789-21-000049:notes:110]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). On November 5, 2013, Seagate HDD Cayman, issued $800 million in aggregate principal amount of 3.75% Senior Notes. The obligations under the 2018 Notes were fully and unconditionally guaranteed on a senior unsecured basis by Seagate Technology plc. The interest on the Notes was payable semi-annually on May 15 and November 15 of each year. On November 15, 2018, the 2018 Notes matured and the entire outstanding principal amount of $499 million was repaid, plus accrued and unpaid interest.

[0001137789-21-000049:notes:111]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). On February 3, 2017, Seagate HDD Cayman issued, in a private placement, $750 million in aggregate principal amount of 4.25% Senior Notes which will mature on March 1, 2022. The obligations under the 2022 Notes are fully and unconditionally guaranteed on a senior unsecured basis, by STUC and, pursuant to a supplemental indenture dated as of May 18, 2021, STX. The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year, commencing on September 1, 2017. At any time before February 1, 2022, Seagate HDD Cayman may redeem some or all of the 2022 Notes at a “make whole” redemption price, plus accrued and unpaid interest, if any. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the 2022 Notes redeemed, plus (2) the excess, if any, of (a) the sum of the present values of the remaining scheduled payments of principal and interest on the 2022 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate (as defined in the relevant Indenture) plus 40 basis points, minus accrued and unpaid interest, if any, on the 2022 Notes being redeemed to, but excluding, the redemption date over (b) the principal amount of the 2022 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the 2022 Notes being redeemed to, but excluding, the redemption date. During fiscal year 2021, $9 million aggregate principal amount of the 2022 Notes was repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. During fiscal year 2020, $521 million aggregate principal amount of the 2022 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest, $250 million and $248 million principal amount of which were repurchased pursuant to cash tender offers for certain senior notes on September 18, 2019 and June 18, 2020 (the “Tender Offers”), respectively. The Company recorded an immaterial loss and a loss of $29 million on repurchases during fiscal years 2021 and 2020, respectively, which is included in Other, net in the Company’s Consolidated Statements of Operations. At any time on or after February 1,

[0001137789-21-000049:notes:112]
2022, Seagate HDD Cayman may redeem some or all of the 2022 Notes at a redemption price equal to 100% of the principal amount of the 2022 Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date.

[0001137789-21-000049:notes:113]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). On May 22, 2013, Seagate HDD Cayman issued, in a private placement, $1 billion in aggregate principal amount of 4.75% Senior Notes, which will mature on June 1, 2023. The obligations under the 2023 Notes are fully and unconditionally guaranteed on a senior unsecured basis, by STUC and, pursuant to a supplemental indenture dated as of May 18, 2021, STX. The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. Seagate HDD Cayman may redeem the 2023 Notes in whole or in part, on not less than 30, nor more than 60 days’ notice, at a “make-whole” premium redemption price. The “make-whole” redemption price will be equal to the greater of (1) 100% of the principal amount of the 2023 Notes being redeemed, or (2) the sum of the present values of the remaining scheduled payments of principal and interest on the 2023 Notes being redeemed, discounted at the redemption date on a semi-annual basis at a rate equal to the sum of the applicable Treasury Rate plus 50 basis points. Accrued and unpaid interest, if any, will be paid to, but excluding, the redemption date. During fiscal years 2021 and 2019, $5 million and $10 million aggregate principal amount of the 2023 Notes was repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest, respectively. During fiscal year 2020, $395 million aggregate principal amount of the 2023 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest, $200 million and $178 million principal amount of which was repurchased pursuant to the Tender Offers on September 18, 2019 and June 18, 2020, respectively. The Company recorded a loss of $1 million and $20 million for fiscal years 2021 and 2020, which is included in Other, net in the Company’s Consolidated Statement of Operations. The loss recorded on the repurchases in fiscal year 2019 was immaterial.

[0001137789-21-000049:notes:114]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”). On February 3, 2017, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 4.875% Senior Notes which will mature on March 1, 2024. The obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STUC and, pursuant to a supplemental indenture dated as of May 18, 2021, STX. The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year, commencing on September 1, 2017. At any time before January 1, 2024, Seagate HDD Cayman may redeem some or all of the 2024 Notes at a “make-whole” redemption price, plus accrued and unpaid interest, if any. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the 2024 Notes redeemed, plus (2) the excess, if any, of (a) the sum of the present values of the remaining scheduled payments of principal and interest on the 2024 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 45 basis points, minus accrued and unpaid interest, if any, on the 2024 Notes being redeemed to, but excluding, the redemption date over (b) the principal amount of the 2024 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the 2024 Notes being redeemed to, but excluding, the redemption date.

[0001137789-21-000049:notes:115]
$1 billion Aggregate Principal amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). On May 28, 2014, Seagate HDD Cayman issued, in a private placement, $1 billion in aggregate principal amount of 4.75% Senior Notes due 2025, which will mature on January 1, 2025. The obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STUC and, pursuant to a supplemental indenture dated as of May 18, 2021, STX. The interest on the 2025 Notes will be payable in cash semiannually on January 1 and July 1 of each year, commencing on January 1, 2015. At any time, upon not less than 30 nor more than 60 days’ notice, Seagate HDD may redeem some or all of the 2025 Notes at a ‘‘make-whole’’ redemption price. The ‘‘make-whole’’ redemption price will be equal to the greater of (1) 100% of the principal amount of the 2025 Notes redeemed, and (2) the sum of the present values of the remaining scheduled payments of principal and interest on the 2025 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points. Accrued and unpaid interest, if any, will be paid to, but excluding, the redemption date. On September 18, 2019, $170 million principal amount of the 2025 Notes was repurchased at a premium pursuant to the Tender Offers. During fiscal year 2019, $55 million aggregate principal amount of the 2025 Notes were repurchased for cash at a discount to their principal amount, plus accrued and unpaid interest. For fiscal years 2020 and 2019 the Company recorded a loss of $8 million and a gain of approximately $1 million on the repurchases respectively, which is included in Other, net in the Company’s Consolidated Statements of Operations. On June 18, 2020, Seagate HDD Cayman completed an exchange offer in which the principal amount of $271 million of the 2025 Notes was exchanged for the principal amount of $297 million of the July 2029 Notes (as defined below). The exchange was accounted for as a debt modification with no gain or loss recognized.

[0001137789-21-000049:notes:116]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). On May 14, 2015, Seagate HDD Cayman issued, in a private placement, $700 million in aggregate principal amount of 4.875% Senior Notes, which will mature on June 1, 2027. The obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STUC and, pursuant to a supplemental indenture dated as of May 18, 2021, STX. The interest on the 2027 Notes is payable semi-annually on June 1 and December 1 of each year, commencing on December 1, 2015. At any time before March 1, 2027, Seagate HDD Cayman may redeem some or all of the 2027 Notes at a “make-whole” redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the 2027 Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the 2027 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 40 basis points, minus accrued and unpaid interest, if any, on the 2027 Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the 2027 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the 2027 Notes being redeemed to, but excluding, the redemption date. At any time on or after March 1, 2027, Seagate HDD Cayman may redeem some or all of the 2027 Notes at a redemption price equal to 100% of the principal amount of the 2027 Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. During fiscal year 2019, $6 million aggregate principal amount of the 2027 Notes were repurchased for cash at a discount to their principal amount, plus accrued and unpaid interest. For fiscal year 2019, the Company recorded an immaterial gain on the repurchase, which is included in Other, net in the Company’s Consolidated Statements of Operations. On June 18, 2020, Seagate HDD Cayman completed an exchange offer in which the principal amount of $185 million of the 2027 Notes was exchanged for the principal amount of $203 million of the July 2029 Notes (as defined below). The exchange was accounted for as a debt modification with no gain or loss recognized.

[0001137789-21-000049:notes:117]
$500 million Aggregate Principal Amount of 4.091% Senior Notes due June 2029 (the “June 2029 Notes”). On June 18, 2020, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 4.091% Senior Notes in connection with Seagate HDD Cayman’s exchange offers to certain eligible holders of Seagate HDD Cayman’s outstanding 2025 Notes and 2027 Notes (the “Exchange Offers”). The obligations under the June 2029 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STUC and, pursuant to a supplemental indenture dated as of May 18, 2021, STX. The June 2029 Notes will mature on June 1, 2029. Interest on the June 2029 Notes will be payable in cash semiannually on June 1 and December 1 of each year, commencing on December 1, 2020. At any time before March 1, 2029, Seagate HDD Cayman may redeem any or all of the June 2029 Notes at a “make-whole” redemption price. The “make-whole” redemption price will be equal to (1) 100% of the principal amount of the June 2029 Notes redeemed, plus (2) the excess, if any, of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the June 2029 Notes being redeemed (as if the 2029 Notes matured on the Notes Par Call Date, as defined below), discounted to the redemption date on a semi-annual basis (assuming a 360-day year of twelve 30-day months) at a rate equal to the sum of the Treasury Rate plus 50 basis points, minus accrued and unpaid interest, if any, on the June 2029 Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the June 2029 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the June 2029 Notes being redeemed to, but excluding, the redemption date. At any time on or after March 1, 2029 (the “Notes Par Call Date”), Seagate HDD Cayman may redeem some or all of the June 2029 Notes at a redemption price equal to 100% of the principal amount of the June 2029 Notes redeemed, plus accrued and unpaid interest thereon, if any, to, but excluding, the redemption date.

[0001137789-21-000049:notes:118]
$500 million Aggregate Principal Amount of 3.125% Senior Notes due July 2029 (the “July 2029 Notes”). On December 8, 2020, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of the July 2029 Notes, which will mature on July 15, 2029. The obligations under the July 2029 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STUC and, pursuant to a supplemental indenture dated as of May 18, 2021, STX. The interest on the July 2029 Notes is payable semi-annually on January 15 and July 15 of each year, commencing on July 15, 2021. At any time before January 15, 2024, Seagate HDD Cayman may redeem some or all of the July 2029 Notes at a “make-whole” redemption price. The “make-whole” redemption price will be equal to (1) 100% of the principal amount of the July 2029 Notes redeemed, plus (2) the greater of (a) 1.0% of the principal amount of the July 2029 Notes and (b) the excess, if any, of (i) the present value at such redemption date of (x) the applicable redemption price of such July 2029 Notes that would apply if such July 2029 Notes were redeemed on January 15, 2024, plus (y) all remaining scheduled payments of interest due on such July 2029 Notes to and including January 15, 2024, computed using a discount rate equal to the applicable Treasury Rate as of such redemption date plus 50 basis points; over (ii) the sum of accrued and unpaid interest, if any, to, but excluding, the redemption date, plus the principal amount of such July 2029 Notes, plus (3) accrued and unpaid interest, if any, to, but excluding, the redemption date. At any time on or after January 15, 2024, Seagate HDD Cayman may redeem some or all of such July 2029 Notes at a price of 101.563%, 100.781% and 100.000%, after January 15, 2024, January 15, 2025 and January 15, 2026, respectively, plus accrued and unpaid interest thereon, if any, to, but excluding, the redemption date. In addition, Seagate HDD Cayman may redeem with the net cash proceeds from one or more equity offerings up to 40% of the July 2029 Notes before January 15, 2024, at a redemption price of 103.125%, plus accrued and unpaid interest to, but excluding, the redemption date.

[0001137789-21-000049:notes:119]
$500 million Aggregate Principal Amount of 4.125% Senior Notes due January 2031 (the “January 2031 Notes”). On June 10, 2020, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 4.125% Senior Notes, which will mature on January 15, 2031. The obligations under the January 2031 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STUC and, pursuant to a supplemental indenture dated as of May 18, 2021, STX. Interest on the Notes will be payable in cash semiannually on January 15 and July 15 of each year, commencing on January 15, 2021. At any time before October 15, 2030, Seagate HDD Cayman may redeem any or all of the Notes at a “make-whole” redemption price. The “make-whole” redemption price will be equal to (1) 100% of the principal amount of the January 2031 Notes redeemed, plus (2) the excess, if any, of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the January 2031 Notes being redeemed (as if the January 2031 Notes matured on the January 2031 Notes Par Call Date, as defined below), discounted to the redemption date on a semi-annual basis (assuming a 360-day year of twelve 30-day months) at a rate equal to the sum of the Treasury Rate plus 50 basis points, minus accrued and unpaid interest, if any, on the January 2031 Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the January 2031 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the January 2031 Notes being redeemed to, but excluding, the redemption date. At any time on or after October 15, 2030 (the “January 2031 Notes Par Call Date”), Seagate HDD Cayman may redeem some or all of the January 2031 Notes at a redemption price equal to 100% of the principal amount of the January 2031 Notes redeemed, plus accrued and unpaid interest thereon, if any, to, but excluding, the redemption date.

[0001137789-21-000049:notes:120]
$500 million Aggregate Principal Amount of 3.375% Senior Notes due July 2031 (the “July 2031 Notes”). On December 8, 2020, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of the July 2031 Notes, which will mature on July 15, 2031. The obligations under the July 2031 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STUC and, pursuant to a supplemental indenture dated as of May 18, 2021, STX. The interest on the July 2031 Notes is payable semi-annually on January 15 and July 15 of each year, commencing on July 15, 2021. At any time before January 15, 2026, Seagate HDD Cayman may redeem some or all of the July 2031 Notes at a “make-whole” redemption price. The “make-whole” redemption price will be equal to (1) 100% of the principal amount of the July 2031 Notes redeemed, plus (2) the greater of (a) 1.0% of the principal amount of the July 2031 Notes and (b) the excess, if any, of (i) the present value at such redemption date of (x) the applicable redemption price of such July 2031 Notes that would apply if such July 2031 Notes were redeemed on January 15, 2026, plus (y) all remaining scheduled payments of interest due on such July 2031 Notes to and including January 15, 2026, computed using a discount rate equal to the Treasury Rate as of such redemption date plus 50 basis points; over (ii) the sum of accrued and unpaid interest, if any, to, but excluding, the redemption date, plus the principal amount of such July 2031 Notes, plus (3) accrued and unpaid interest, if any, to, but excluding, the redemption date. At any time on or after January 15, 2026, Seagate HDD Cayman may redeem some or all of such July 2031 Notes at a price of 101.688%, 101.125%, 100.563% and 100.000%, after January 15, 2026, January 15, 2027, January 15, 2028 and January 15, 2029, respectively, plus accrued and unpaid interest thereon, if any, to, but excluding, the redemption date. In addition, Seagate HDD Cayman may redeem with the net cash proceeds from one or more equity offerings up to 40% of the July 2031 Notes before January 15, 2024, a redemption price of 103.375%, accrued and unpaid interest to, but excluding, the redemption date.

[0001137789-21-000049:notes:121]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). On December 2, 2014, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 5.75% Senior Notes, which will mature on December 1, 2034. The obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STUC and, pursuant to a supplemental indenture dated as of May 18, 2021, STX. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on June 1, 2015. At any time before June 1, 2034, Seagate HDD Cayman may redeem some or all of the 2034 Notes at a “make-whole” redemption price. The “make-whole” redemption price will be equal to (1) 100% of the principal amount of the 2034 Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the 2034 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points, minus accrued and unpaid interest, if any, on the 2034 Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the 2034 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the 2034 Notes being redeemed to, but excluding, the redemption date. At any time on or after June 1, 2034, Seagate HDD Cayman may redeem some or all of the 2034 Notes at a redemption price equal to 100% of the principal amount of the 2034 Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date.

[0001137789-21-000049:notes:122]
At July 2, 2021, future principal payments on long-term debt were as follows (in millions):

[0001137789-21-000049:notes:123]
| Fiscal Year |  | Amount |
| 2022 |  | $ | 245 |  |
| 2023 |  | 566 |  |
| 2024 |  | 525 |  |
| 2025 |  | 504 |  |
| 2026 |  | 381 |  |
| Thereafter |  | 2,995 |  |
| Total |  | $ | 5,216 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001137789-21-000049:notes:124]
Income Taxes
Income before income taxes consisted of the following:

[0001137789-21-000049:notes:125]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | June 28,2019 |
| U.S. |  | $ | 191 |  |  | $ | 121 |  |  | $ | 275 |  |
| Non-U.S. |  | 1,157 |  |  | 911 |  |  | 1,097 |  |
|  |  | $ | 1,348 |  |  | $ | 1,032 |  |  | $ | 1,372 |  |

[0001137789-21-000049:notes:126]
The provision (benefit) for income taxes consisted of the following:

[0001137789-21-000049:notes:127]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | June 28,2019 |
| Current income tax expense: |  |  |  |  |  |  |
| U.S. |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Non-U.S. |  | 38 |  |  | 36 |  |  | 45 |  |
| Total Current |  | 38 |  |  | 36 |  |  | 45 |  |
| Deferred income tax benefit: |  |  |  |  |  |  |
| U.S. |  | 8 |  |  | (18) |  |  | (678) |  |
| Non-U.S. |  | (12) |  |  | 10 |  |  | (7) |  |
| Total Deferred |  | (4) |  |  | (8) |  |  | (685) |  |
| Provision (benefit) for income taxes |  | $ | 34 |  |  | $ | 28 |  |  | $ | (640) |  |

[0001137789-21-000049:notes:128]
The significant components of the Company’s deferred tax assets and liabilities were as follows (in millions):

[0001137789-21-000049:notes:129]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |
| Deferred tax assets |  |  |  |  |
| Accrued warranty |  | $ | 31 |  |  | $ | 35 |  |
| Inventory carrying value adjustments |  | 39 |  |  | 30 |  |
| Receivable allowances |  | 15 |  |  | 11 |  |
| Accrued compensation and benefits |  | 66 |  |  | 55 |  |
| Depreciation |  | 47 |  |  | 59 |  |
| Restructuring accruals |  | 1 |  |  | 9 |  |
| Other accruals and deferred items |  | 25 |  |  | 22 |  |
| Net operating losses |  | 698 |  |  | 735 |  |
| Tax credit carryforwards |  | 628 |  |  | 603 |  |
| Other assets |  | 1 |  |  | 7 |  |
| Gross: Deferred tax assets |  | 1,551 |  |  | 1,566 |  |
| Less: Valuation allowance |  | (429) |  |  | (438) |  |
| Net: Deferred tax assets |  | 1,122 |  |  | 1,128 |  |
| Deferred tax liabilities |  |  |  |  |
| Unremitted earnings of certain non-U.S. entities |  | (5) |  |  | (16) |  |
| Acquisition-related Items |  | (5) |  |  | (8) |  |
| Other liabilities |  | (9) |  |  | (5) |  |
| Net: Deferred tax liabilities |  | (19) |  |  | (29) |  |
| Total net deferred tax assets |  | $ | 1,103 |  |  | $ | 1,099 |  |

[0001137789-21-000049:notes:130]
At July 2, 2021, the Company recorded $1.1 billion of net deferred tax assets. The realization of most of these deferred tax assets is primarily dependent on the Company’s ability to generate sufficient U.S. and certain non-Irish taxable income in future periods. Although realization is not assured, the Company’s management believes it is more likely than not that these deferred tax assets will be realized. The amount of deferred tax assets considered realizable, however, may increase or decrease in subsequent periods when the Company re-evaluates the underlying basis for its estimates of future U.S. and certain non-Irish taxable income.

[0001137789-21-000049:notes:131]
The deferred tax asset valuation allowance decreased by $9 million in fiscal year 2021.

[0001137789-21-000049:notes:132]
At July 2, 2021, the Company had U.S. and non-U.S. tax net operating loss carryforwards of approximately $4.6 billion and $65 million, respectively, which will expire at various dates beginning in fiscal year 2022, if not utilized. Net operating loss carryforwards of approximately $103 million are scheduled to expire in fiscal year 2022. At July 2, 2021, the Company had U.S. tax credit carryforwards of $731 million which will expire at various dates beginning in fiscal year 2022 if not utilized.

[0001137789-21-000049:notes:133]
As of July 2, 2021, approximately $222 million and $108 million of the Company’s total U.S. net operating loss and tax credit carryforwards, respectively, are subject to annual limitations ranging from $1 million to $45 million pursuant to U.S. tax law.

[0001137789-21-000049:notes:134]
For purposes of the reconciliation between the provision (benefit) for income taxes at the statutory rate and the effective tax rate, the Irish statutory rate of 25% was applied as follows:

[0001137789-21-000049:notes:135]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | June 28,2019 |
| Provision at statutory rate |  | $ | 337 |  |  | $ | 258 |  |  | $ | 343 |  |
| Permanent differences |  | 8 |  |  | (1) |  |  | 3 |  |
| Valuation allowance |  | (2) |  |  | (16) |  |  | (742) |  |
| Earnings taxed at less than statutory rate |  | (287) |  |  | (193) |  |  | (234) |  |
| Research Credit |  | (27) |  |  | (27) |  |  | (38) |  |
| Tax expense related to intercompany transactions |  | — |  |  | — |  |  | 23 |  |
| Other individually immaterial items |  | 5 |  |  | 7 |  |  | 5 |  |
| Provision (benefit) for income taxes |  | $ | 34 |  |  | $ | 28 |  |  | $ | (640) |  |

[0001137789-21-000049:notes:136]
A substantial portion of the Company's operations in Malaysia, Singapore and Thailand operate under various tax incentive programs, which expire in whole or in part at various dates through 2025. Certain tax incentives may be extended if specific conditions are met. The net impact of these tax incentive programs was to increase the Company's net income by approximately $226 million in fiscal year 2021 ($0.92 per share, diluted), to increase the Company's net income by approximately $206 million in fiscal year 2020 ($0.78 per share, diluted) and to increase the Company’s net income by approximately $194 million in fiscal year 2019 ($0.68 per share, diluted).

[0001137789-21-000049:notes:137]
The Company consists of an Irish tax resident parent holding company with various U.S. and non-U.S. subsidiaries that operate in multiple non-Irish taxing jurisdictions. The amount of temporary differences (including undistributed earnings) related to outside basis differences in the stock of non-Irish resident subsidiaries considered indefinitely reinvested outside of Ireland for which Irish income taxes have not been provided as of July 2, 2021, was approximately $4.0 billion. If such amounts were remitted to Ireland as a dividend, income tax at 25%, or approximately $1.0 billion would result.

[0001137789-21-000049:notes:138]
As of July 2, 2021, and July 3, 2020, the Company had approximately $108 million and $89 million, respectively, of unrecognized tax benefits excluding interest and penalties. These amounts, if recognized, would impact the effective tax rate subject to certain future valuation allowance offsets.

[0001137789-21-000049:notes:139]
The following table summarizes the activities related to the Company’s gross unrecognized tax benefits:

[0001137789-21-000049:notes:140]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | June 28,2019 |
| Balance of unrecognized tax benefits at the beginning of the year |  | $ | 89 |  |  | $ | 83 |  |  | $ | 60 |  |
| Gross increase for tax positions of prior years |  | 7 |  |  | — |  |  | 22 |  |
| Gross decrease for tax positions of prior years |  | (1) |  |  | (1) |  |  | (9) |  |
| Gross increase for tax positions of current year |  | 15 |  |  | 8 |  |  | 16 |  |
| Gross decrease for tax positions of current year |  | — |  |  | — |  |  | — |  |
| Settlements |  | (1) |  |  | (1) |  |  | — |  |
| Lapse of statutes of limitation |  | (1) |  |  | — |  |  | (6) |  |
| Non-U.S. exchange gain |  | — |  |  | — |  |  | — |  |
| Balance of unrecognized tax benefits at the end of the year |  | $ | 108 |  |  | $ | 89 |  |  | $ | 83 |  |

[0001137789-21-000049:notes:141]
It is the Company’s policy to include interest and penalties related to unrecognized tax benefits in the provision for income taxes on the Consolidated Statements of Operations. During fiscal year 2021, the Company recognized net income tax benefit for interest and penalties of less than $1 million, as compared to net tax benefit of less than $1 million during fiscal year 2020, and net tax benefit of $2 million during fiscal year 2019. As of July 2, 2021, the Company’s accrued interest and penalties related to unrecognized tax benefits remains unchanged at less than $1 million compared with fiscal year 2020.

[0001137789-21-000049:notes:142]
During the 12 months beginning July 3, 2021, the Company expects that its unrecognized tax benefits could be reduced by less than $1 million as a result of the expiration of certain statutes of limitation. 
The Company is required to file U.S. and non-U.S. income tax returns. The Company is no longer subject to examination of its U.S. income tax returns for years prior to fiscal year 2009 and prior to fiscal year 2010 for non-U.S. income tax returns.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001137789-21-000049:notes:143]
The Company is a lessee in several operating leases related to real estate facilities for warehouse and office space.

[0001137789-21-000049:notes:144]
The Company’s lease arrangements comprise operating leases with various expiration dates through 2067. The lease term includes the non-cancelable period of the lease, adjusted for options to extend or terminate the lease when it is reasonably certain that an option will be exercised.

[0001137789-21-000049:notes:145]
Operating lease costs include short-term lease costs and are shown net of immaterial sublease income. The components of lease costs and other information related to leases were as follows:

[0001137789-21-000049:notes:146]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |
| Operating lease cost |  | $ | 15 |  |  | 22 |
| Variable lease cost |  | 4 |  |  | 4 |
| Total lease cost |  | $ | 19 |  |  | 26 |
| Operating cash outflows from operating leases |  | $ | 19 |  |  | 18 |

[0001137789-21-000049:notes:147]
Prior to fiscal year 2020, the Company recognized rent expense for operating leases under the legacy guidance ASC 840. Total rent expense for all land, facility and equipment operating leases, net of sublease income, was $18 million for fiscal year 2019.

[0001137789-21-000049:notes:148]
|  |  | July 2,2021 |  | July 3,2020 |
| Weighted-average remaining lease term |  | 7.2 years |  | 13.2 years |
| Weighted-average discount rate |  | 6.02 | % |  | 6.53 | % |

[0001137789-21-000049:notes:149]
ROU assets and lease liabilities are included on the Company’s Consolidated Balance Sheet as follows:

[0001137789-21-000049:notes:150]
| (Dollars in millions) |  | Balance Sheet Location |  | July 2,2021 |  | July 3,2020 |
| ROU assets |  | Other assets, net |  | $ | 97 |  |  | $ | 103 |  |
| Current lease liabilities |  | Accrued expenses |  | 15 |  |  | 14 |
| Non-current lease liabilities |  | Other non-current liabilities |  | 39 |  |  | 49 |

[0001137789-21-000049:notes:151]
At July 2, 2021, future lease payments included in the measurement of lease liabilities were as follows (in millions):

[0001137789-21-000049:notes:152]
| Fiscal Year |  | Amount |
| 2022 |  | $ | 15 |  |
| 2023 |  | 12 |  |
| 2024 |  | 8 |  |
| 2025 |  | 5 |  |
| 2026 |  | 4 |  |
| Thereafter |  | 21 |  |
| Total lease payments |  | 65 |  |
| Less: imputed interest |  | (11) |  |
| Present value of lease liabilities |  | $ | 54 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001137789-21-000049:notes:153]
Restructuring and Exit Costs
During fiscal years 2021 and 2020, the Company recorded restructuring charges of $8 million and $82 million, respectively, comprised primarily of charges related to workforce reduction costs and facilities and other exit costs associated with the restructuring of its workforce. During fiscal year 2019, the Company recorded a net gain of $22 million that included a gain from the sale of a certain property. The Company’s significant restructuring plans are described below. All restructuring charges are reported in Restructuring and other, net on the Consolidated Statements of Operations.

[0001137789-21-000049:notes:154]
June 2020 Plan - On June 1, 2020, the Company committed to a restructuring plan (the “June 2020 Plan”) consistent with its long-term strategy to drive operational efficiencies, reduce its cost structure and invest in future opportunities. The June 2020 Plan included consolidating the Company’s Minnesota facilities into one location and reducing its headcount worldwide by approximately 500 employees. The June 2020 Plan was substantially completed during the first quarter of fiscal year 2021.

[0001137789-21-000049:notes:155]
December 2017 Plan - On December 8, 2017, the Company committed to a restructuring plan (the “December 2017 Plan”) to reduce its cost structure. The December 2017 Plan included reducing the Company’s global headcount by approximately 500 employees. The December 2017 Plan was substantially completed during fiscal year 2018.

[0001137789-21-000049:notes:156]
The following table summarizes the Company’s restructuring activities under all of the Company’s active restructuring plans for fiscal years 2021, 2020 and 2019:

[0001137789-21-000049:notes:157]
|  |  | June 2020 Plan |  | December 2017 Plan |  | Other Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at June 29, 2018 |  | $ | — |  |  | $ | — |  |  | $ | 5 |  |  | $ | 4 |  |  | $ | 14 |  |  | $ | 19 |  |  | $ | 42 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | 3 |  |  | 41 |  |  | 10 |  |  | 54 |  |
| Cash payments |  | — |  |  | — |  |  | (5) |  |  | (5) |  |  | (43) |  |  | (12) |  |  | (65) |  |
| Adjustments |  | — |  |  | — |  |  | — |  |  | (1) |  |  | 1 |  |  | (1) |  |  | (1) |  |
| Accrual balances at June 28, 2019 |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 13 |  |  | 16 |  |  | 30 |  |
| Lease adoption adjustment |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (11) |  |  | (11) |  |
| Restructuring charges |  | 56 |  |  | 2 |  |  | — |  |  | — |  |  | 26 |  |  | 2 |  |  | 86 |  |
| Cash payments |  | (18) |  |  | — |  |  | — |  |  | (1) |  |  | (30) |  |  | (4) |  |  | (53) |  |
| Adjustments |  | — |  |  | — |  |  | — |  |  | — |  |  | (4) |  |  | — |  |  | (4) |  |
| Accrual balances at July 3, 2020 |  | 38 |  |  | 2 |  |  | — |  |  | — |  |  | 5 |  |  | 3 |  |  | 48 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | — |  |  | 6 |  |  | 8 |  |  | 14 |  |
| Cash payments |  | (37) |  |  | (1) |  |  | — |  |  | — |  |  | (10) |  |  | (5) |  |  | (53) |  |
| Adjustments |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (1) |  |  | (1) |  |
| Accrual balances at July 2, 2021 |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 5 |  |  | $ | 8 |  |
| Total costs incurred to date as of July 2, 2021 |  | $ | 56 |  |  | $ | 2 |  |  | $ | 26 |  |  | $ | 8 |  |  | $ | 156 |  |  | $ | 52 |  |  | $ | 300 |  |
| Total expected costs to be incurred as of July 2, 2021 |  | $ | — |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 7 |  |

[0001137789-21-000049:notes:158]
The accrued restructuring balance of $8 million at July 2, 2021 is included in Accrued expenses in the Company’s Consolidated Balance Sheet.

[0001137789-21-000049:notes:159]
During fiscal year 2021, the Company recognized a gain of $3 million from the sale of a certain property and a gain of $2 million from termination of an operating lease, which are reported in Restructuring and other, net on the Company’s Condensed Consolidated Statements of Operations.

[0001137789-21-000049:notes:160]
During fiscal year 2019, the Company sold a certain property, which was previously classified as assets held for sale and recognized a gain of approximately $78 million. The Company also recorded an impairment charge of $3 million on its held for sale land and building during fiscal year 2019. The gain and impairment charge were included in Restructuring and other, net in the Company’s Consolidated Statements of Operations.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001137789-21-000049:notes:161]
Derivative Financial Instruments The Company is exposed to foreign currency exchange rate, interest rate and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign 
currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies.

[0001137789-21-000049:notes:162]
In the quarter ended October 4, 2019, the Company entered into certain interest rate swap agreements with a notional amount of $500 million to convert the variable interest rate on its Term Loan to fixed interest rates. The contracts will mature on September 16, 2025. The notional amount of the interest rate swap agreements was $481 million as of July 2, 2021. The objective of the interest rate swap agreements is to eliminate the variability of interest payment cash flows associated with the variable interest rates under the Term Loan. The Company designated the interest rate swaps as cash flow hedges.

[0001137789-21-000049:notes:163]
The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives on its Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The amount of net unrealized loss on cash flow hedges was $18 million and $24 million as of July 2, 2021 and July 3, 2020. respectively. As of July 2, 2021, the amount of existing net losses related to cash flow hedges recorded in Accumulated other comprehensive loss included a net loss of $5 million that is expected to be reclassified to earnings within twelve months.

[0001137789-21-000049:notes:164]
The Company de-designates its cash flow hedges when the forecasted hedged transactions affects earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss on the Company’s Consolidated Balance Sheets are reclassified into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company recognized a net gain of $14 million in Cost of revenue and a net loss of $7 million in Interest expense related to the loss of hedge designation on discontinued cash flow hedges during fiscal year 2021. The Company recognized a net loss of $3 million in Other expense, net related to the loss of hedge designation on discontinued cash flow hedges during fiscal year 2020. The Company did not recognize any material amounts related to the loss of hedge designation on discontinued cash flow hedges during the fiscal year 2019.

[0001137789-21-000049:notes:165]
Other derivatives not designated as hedging instruments consist of foreign currency forward exchange contracts that the Company uses to hedge the foreign currency exposure on forecasted expenditures denominated in currencies other than the U.S. dollar. The Company recognizes gains and losses on these contracts, as well as the related costs in Other, net on its Consolidated Statements of Operations.

[0001137789-21-000049:notes:166]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of July 2, 2021 and July 3, 2020. All of the foreign currency forward exchange contracts mature within 12 months.

[0001137789-21-000049:notes:167]
|  |  | As of July 2, 2021 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Singapore Dollar |  | $ | 172 |  |  | $ | 43 |  |
| Thai Baht |  | 131 |  |  | 46 |  |
| Chinese Renminbi |  | 73 |  |  | 21 |  |
| British Pound Sterling |  | 54 |  |  | 16 |  |
|  |  | $ | 430 |  |  | $ | 126 |  |

[0001137789-21-000049:notes:168]
|  |  | As of July 3, 2020 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Singapore Dollar |  | $ | 187 |  |  | $ | 56 |  |
| Thai Baht |  | 157 |  |  | 42 |  |
| Chinese Renminbi |  | 81 |  |  | 25 |  |
| British Pound Sterling |  | 64 |  |  | 20 |  |
|  |  | $ | 489 |  |  | $ | 143 |  |

[0001137789-21-000049:notes:169]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its non-qualified deferred compensation plan: the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP’s liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP’s liabilities due to changes in the value of the investment options made by employees. As of July 2, 2021, the notional investments underlying the TRS amounted to $126 million. The contract term of the TRS is through January 2022 and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP’s liabilities.

[0001137789-21-000049:notes:170]
The following tables show the Company’s derivative instruments measured at gross fair value as reflected in the Consolidated Balance Sheets as of July 2, 2021 and July 3, 2020:

[0001137789-21-000049:notes:171]
|  |  | As of July 2, 2021 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 1 |  |  | Accrued expenses |  | $ | (5) |  |
| Interest rate swap |  | Other current assets |  | — |  |  | Accrued expenses |  | (14) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 1 |  |  | Accrued expenses |  | (2) |  |
| Total return swap |  | Other current assets |  | 2 |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 4 |  |  |  |  | $ | (21) |  |

[0001137789-21-000049:notes:172]
|  |  | As of July 3, 2020 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 3 |  |  | Accrued expenses |  | $ | — |  |
| Interest rate swap |  | Other current assets |  | — |  |  | Accrued expenses |  | $ | (27) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 2 |  |  | Accrued expenses |  | (2) |  |
| Total return swap |  | Other current assets |  | 1 |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 6 |  |  |  |  | $ | (29) |  |

[0001137789-21-000049:notes:173]
The following tables show the effect of the Company’s derivative instruments on the Consolidated Statement of Comprehensive Income and Consolidated Statement of Operations for the fiscal year ended July 2, 2021:

[0001137789-21-000049:notes:174]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized inIncome on Derivatives |  | Amount of Gain/(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 10 |  |
| Total return swap |  | Operating expenses |  | 30 |  |

[0001137789-21-000049:notes:175]
| (Dollars in millions) Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
| Foreign currency forward exchange contracts |  | $ | 7 |  |  | Cost of revenue |  | $ | 14 |  |  | Other, net |  | $ | 1 |  |
| Interest rate swap |  | 8 |  |  | Interest expense |  | (7) |  |  | Interest expense |  | — |  |

[0001137789-21-000049:notes:176]
The following table shows the effect of the Company’s derivative instruments on the Consolidated Statement of Comprehensive Income and Consolidated Statement of Operations for the fiscal year ended July 3, 2020:

[0001137789-21-000049:notes:177]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized inIncome on Derivatives |  | Amount of Gain/(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (2) |  |
| Total return swap |  | Operating expenses |  | 2 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001137789-21-000049:notes:178]
Fair Value
Measurement of Fair Value

[0001137789-21-000049:notes:179]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact and it considers assumptions that market participants would use when pricing the asset or liability.

[0001137789-21-000049:notes:180]
Fair Value Hierarchy

[0001137789-21-000049:notes:181]
A fair value hierarchy is based on whether the market participant assumptions used in determining fair value are obtained from independent sources (observable inputs) or reflects the Company's own assumptions of market participant valuation (unobservable inputs). A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The three levels of inputs that may be used to measure fair value are:

[0001137789-21-000049:notes:182]
Level 1 - Quoted prices in active markets that are unadjusted and accessible at the measurement date for identical, unrestricted assets or liabilities;

[0001137789-21-000049:notes:183]
Level 2 - Quoted prices for identical assets and liabilities in markets that are inactive; quoted prices for similar assets and liabilities in active markets or financial instruments for which significant inputs are observable, either directly or indirectly; or

[0001137789-21-000049:notes:184]
Level 3 - Prices or valuations that require inputs that are both unobservable and significant to the fair value measurement.

[0001137789-21-000049:notes:185]
The Company considers an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and views an inactive market as one in which there are few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, the Company’s or the counterparty’s non-performance risk is considered in determining the fair values of liabilities and assets, respectively.

[0001137789-21-000049:notes:186]
Items Measured at Fair Value on a Recurring Basis

[0001137789-21-000049:notes:187]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of July 2, 2021:

[0001137789-21-000049:notes:188]
|  |  | Fair Value Measurements at Reporting Date Using |
| (US Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 551 |  |  | $ | — |  |  | $ | — |  |  | $ | 551 |  |
| Time deposits and certificates of deposit |  | — |  |  | — |  |  | — |  |  | — |  |
| Total cash equivalents |  | 551 |  |  | — |  |  | — |  |  | 551 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Derivative assets |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total assets |  | $ | 552 |  |  | $ | 5 |  |  | $ | 18 |  |  | $ | 575 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |
| Total liabilities |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |

[0001137789-21-000049:notes:189]
|  |  | Fair Value Measurements at Reporting Date Using |
| (US Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 551 |  |  | $ | — |  |  | $ | — |  |  | $ | 551 |  |
| Other current assets |  | 1 |  |  | 5 |  |  | — |  |  | 6 |  |
| Other assets, net |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Total assets |  | $ | 552 |  |  | $ | 5 |  |  | $ | 18 |  |  | $ | 575 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |
| Total liabilities |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |

[0001137789-21-000049:notes:190]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of July 3, 2020:

[0001137789-21-000049:notes:191]
|  |  | Fair Value Measurements at Reporting Date Using |
| (US Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 494 |  |  | $ | — |  |  | $ | — |  |  | $ | 494 |  |
| Time deposits and certificates of deposit |  | — |  |  | 55 |  |  | — |  |  | 55 |  |
| Total cash equivalents |  | 494 |  |  | 55 |  |  | — |  |  | 549 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Derivative assets |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total assets |  | $ | 495 |  |  | $ | 62 |  |  | $ | 18 |  |  | $ | 575 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |
| Total liabilities |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |

[0001137789-21-000049:notes:192]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 494 |  |  | $ | 55 |  |  | $ | — |  |  | $ | 549 |  |
| Other current assets |  | 1 |  |  | 7 |  |  | — |  |  | 8 |  |
| Other assets, net |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Total assets |  | $ | 495 |  |  | $ | 62 |  |  | $ | 18 |  |  | $ | 575 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expense |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |
| Total liabilities |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |

[0001137789-21-000049:notes:193]
The Company classifies items in Level 1 if the financial assets consist of securities for which quoted prices are available in an active market.

[0001137789-21-000049:notes:194]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair value of all of its cash equivalents. For the cash equivalents in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry standard data providers or other third-party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of July 2, 2021, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts, interest rate swaps and the TRS. The Company recognizes derivative financial instruments in its consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001137789-21-000049:notes:195]
Items Measured at Fair Value on a Non-Recurring Basis

[0001137789-21-000049:notes:196]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives, which are accounted for either under the equity method or the measurement alternative. If measured at fair value in the Consolidated Balance Sheets, these investments would generally be classified in Level 3 of the fair value hierarchy.

[0001137789-21-000049:notes:197]
For the investments that are accounted for under the equity method, the Company recorded a net gain of $48 million in fiscal year 2021, a net loss of $2 million and $2 million in fiscal year 2020 and 2019, respectively. The adjusted carrying value of the investments accounted for under the equity method amounted to $78 million and $29 million as of July 2, 2021 and July 3, 2020 respectively.

[0001137789-21-000049:notes:198]
For the investments that are accounted for under the measurement alternative, Company recorded $51 million of net gains in fiscal year 2021, of which $27 million is unrealized as of July 2, 2021 related to upward adjustments due to observable price changes. For fiscal year 2021 and 2020, the Company recorded downward adjustments of $12 million and $18 million, respectively, to write down the carrying amount of certain investments to their fair value. As of July 2, 2021, and July 3, 2020, the carrying value of the Company’s strategic investments under the measurement alternative was $117 million and $106 million, respectively.

[0001137789-21-000049:notes:199]
The Company’s debt is carried at amortized cost. The estimated fair value of the Company’s debt is derived using the closing price of the same debt instruments as of the date of valuation, which takes into account the yield curve, interest rates and other observable inputs. Accordingly, these fair value measurements are categorized as Level 2. The following table presents the fair value and amortized cost of the Company’s debt in order of maturity:

[0001137789-21-000049:notes:200]
|  |  | July 2, 2021 |  | July 3, 2020 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 4.250% Senior Notes due March 2022 |  | $ | 220 |  |  | $ | 224 |  |  | $ | 229 |  |  | $ | 237 |  |
| 4.750% Senior Notes due June 2023 |  | 541 |  |  | 578 |  |  | 546 |  |  | 576 |  |
| 4.875% Senior Notes due March 2024 |  | 499 |  |  | 544 |  |  | 498 |  |  | 541 |  |
| 4.750% Senior Notes due January 2025 |  | 479 |  |  | 529 |  |  | 479 |  |  | 517 |  |
| 4.875% Senior Notes due June 2027 |  | 504 |  |  | 561 |  |  | 504 |  |  | 549 |  |
| 4.091% Senior Notes due June 2029 |  | 461 |  |  | 519 |  |  | 456 |  |  | 523 |  |
| 3.125% Senior Notes due July 2029 |  | 500 |  |  | 488 |  |  | — |  |  | — |  |
| 4.125% Senior Notes due January 2031 |  | 499 |  |  | 513 |  |  | 499 |  |  | 524 |  |
| 3.375% Senior Notes due July 2031 |  | 500 |  |  | 487 |  |  | — |  |  | — |  |
| 5.750% Senior Notes due December 2034 |  | 489 |  |  | 566 |  |  | 489 |  |  | 543 |  |
| LIBOR Based Term Loan due September 2025 |  | 481 |  |  | 478 |  |  | 500 |  |  | 490 |  |
|  |  | $ | 5,173 |  |  | $ | 5,487 |  |  | $ | 4,200 |  |  | $ | 4,500 |  |
| Less: debt issuance costs |  | (34) |  |  | — |  |  | (25) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 5,139 |  |  | $ | 5,487 |  |  | $ | 4,175 |  |  | $ | 4,500 |  |
| Less: current portion of debt, net of debt issuance costs |  | (245) |  |  | (249) |  |  | (19) |  |  | (19) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 4,894 |  |  | $ | 5,238 |  |  | $ | 4,156 |  |  | $ | 4,481 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001137789-21-000049:notes:201]
Shareholders’ Equity
Share Capital

[0001137789-21-000049:notes:202]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 227,382,980 shares were outstanding as of July 2, 2021, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of July 2, 2021.

[0001137789-21-000049:notes:203]
On May 18, 2021, in connection with a corporate reorganization, a new Irish public limited company, STX, began serving as the publicly traded parent company, and pursuant to a scheme of arrangement under Irish law, each STUC ordinary shareholder received one ordinary share, par value $0.00001, of STX on a one-for-one basis. As of May 18, 2021, there were 227,340,817 ordinary shares of $0.0001 par value per share exchanged in connection with the reorganization.

[0001137789-21-000049:notes:204]
Ordinary shares - Holders of ordinary shares are entitled to receive dividends when and as declared by the Company’s board of directors (the “Board of Directors”). Upon any liquidation, dissolution, or winding up of the Company, after required payments are made to holders of preferred shares, any remaining assets of the Company will be distributed ratably to holders of the preferred and ordinary shares. Holders of shares are entitled to one vote per share on all matters upon which the ordinary shares are entitled to vote, including the election of directors.

[0001137789-21-000049:notes:205]
Preferred shares - The Company may issue preferred shares in one or more series, up to the authorized amount, without shareholder approval. The Board of Directors is authorized to establish from time to time the number of shares to be included in each series, and to fix the rights, preferences and privileges of the shares of each wholly unissued series and any of its qualifications, limitations or restrictions. The Board of Directors can also increase or decrease the number of shares of a series, but not below the number of shares of that series then outstanding, without any further vote or action by the shareholders.

[0001137789-21-000049:notes:206]
The Board of Directors may authorize the issuance of preferred shares with voting or conversion rights that could harm the voting power or other rights of the holders of the ordinary shares. The issuance of preferred shares, while providing flexibility in connection with possible acquisitions and other corporate purposes, could, among other things, have the effect of delaying, deferring or preventing a change in control of the Company and might harm the market price of its ordinary shares and the voting and other rights of the holders of ordinary shares.

[0001137789-21-000049:notes:207]
Repurchases of Equity Securities

[0001137789-21-000049:notes:208]
All repurchases are effected as redemptions in accordance with the Company’s Constitution.

[0001137789-21-000049:notes:209]
The Company’s Board of Directors increased the authorization for the repurchase of its outstanding ordinary shares by $3.0 billion on October 21, 2020, and $2.0 billion on February 22, 2021. As of July 2, 2021, $4.2 billion remained available for repurchase under the existing repurchase authorization limit.

[0001137789-21-000049:notes:210]
The following table sets forth information with respect to repurchases of the Company’s ordinary shares during fiscal years 2021, 2020 and 2019:

[0001137789-21-000049:notes:211]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Cumulative repurchased through June 29, 2018 |  | 352 |  |  | $ | 10,502 |  |
| Repurchased in fiscal year 2019(1) |  | 22 |  |  | 997 |  |
| Cumulative repurchased through June 28, 2019 |  | 374 |  |  | 11,499 |  |
| Repurchased in fiscal year 2020(1) |  | 18 |  |  | 887 |  |
| Cumulative repurchased through July 3, 2020 |  | 392 |  |  | 12,386 |  |
| Repurchased in fiscal year 2021(1) |  | 34 |  |  | 2,081 |  |
| Cumulative repurchased through July 2, 2021 |  | 426 |  |  | $ | 14,467 |  |

[0001137789-21-000049:notes:212]
___________________________________________________

[0001137789-21-000049:notes:213]
(1)     For fiscal years 2021, 2020 and 2019, includes net share settlements of $33 million, $40 million and $31 million for 1 million, 1 million and 1 million shares, respectively, in connection with tax withholding related to vesting of restricted share units.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001137789-21-000049:notes:214]
Share-Based Compensation
Share-Based Compensation Plans

[0001137789-21-000049:notes:215]
The Company’s share-based compensation plans have been established to promote the Company’s long-term growth and financial success by providing incentives to its employees, directors and consultants through grants of share-based awards. The provisions of the Company's share-based benefit plans, which allow for the grant of various types of equity-based awards, are also intended to provide greater flexibility to maintain the Company's competitive ability to attract, retain and motivate participants for the benefit of the Company and its shareholders.

[0001137789-21-000049:notes:216]
Seagate Technology Holdings plc 2012 Equity Incentive Plan (the “EIP”). On October 26, 2011, the shareholders approved the EIP and authorized the issuance of up to a total of approximately 27.0 million ordinary shares, par value $0.00001 per share, plus any shares remaining available for grant under the Seagate Technology plc 2004 Share Compensation Plan (the “SCP”) as of the effective date of the EIP (which was equal to approximately 11.0 million ordinary shares as of the effective date of the EIP and which will increase by such additional number of shares as will be returned to the share reserve in respect of awards previously granted under the SCP) (together, the “Share Reserve”). On October 22, 2014, the shareholders authorized the issuance under the EIP of an additional 25.0 million ordinary shares, par value $0.00001 per share. On October 19, 2016, the shareholders authorized the issuance under the EIP of an additional 7.5 million ordinary shares, par value $0.00001 per share. On October 29, 2019, the shareholders authorized the issuance under the EIP of an additional 12.1 million ordinary shares, par value $0.00001 per share. Any shares that are subject to options or share appreciation rights granted under the EIP will be counted against the Share Reserve as one share for every one share granted, and any shares that are subject to restricted share units (“RSUs”) or performance-based share units (“PSU”) (collectively, “Full-Value Share Awards”) will generally be counted, after October 29, 2019, against the Share Reserve as 2.25 shares for every one share granted. As of July 2, 2021, there were approximately 19.0 million ordinary shares available for issuance of Full-Value Share Awards under the EIP.

[0001137789-21-000049:notes:217]
Dot Hill Systems 2009 Equity Incentive Plan (the “DHEIP”). Effective May 18, 2021, Seagate Technology Holdings plc assumed the Dot Hill Systems 2009 Equity Incentive Plan, which was acquired by STUC effective October 6, 2015. The Company assumed the remaining authorized but unused share reserve of approximately 2.0 million shares, based on the conversion ratio, from the DHEIP on the acquisition date. Effective April 24, 2019, the Company terminated the DHEIP and thus, no further grants will be made under the DHEIP. Outstanding awards granted under the DHEIP will remain subject to the terms of the DHEIP.

[0001137789-21-000049:notes:218]
Seagate Technology Holdings plc Employee Stock Purchase Plan (the “ESPP”). There are 60.0 million ordinary shares authorized to be issued under the ESPP. The ESPP consists of a six-month offering period with a maximum issuance of 1.5 million ordinary shares per offering period. The ESPP permits eligible employees to purchase ordinary shares through payroll deductions generally at 85% of the fair market value of the ordinary shares. As of July 2, 2021, there were approximately 8.4 million ordinary shares available for issuance under the ESPP.

[0001137789-21-000049:notes:219]
Equity Awards

[0001137789-21-000049:notes:220]
RSUs generally vest over a period of four years, with cliff vesting of a portion of each award occurring annually, subject to continuous employment with the Company through the vesting date. Options generally vest as follows: 25% of the options will vest on the first anniversary of the vesting commencement date and the remaining 75% will vest ratably each month thereafter over the next 36 months. Options granted under the EIP and SCP have an exercise price equal to the fair market value of the Company’s ordinary shares on the grant date. Fair market value is defined as the closing price of the Company's ordinary shares on NASDAQ on the grant date.

[0001137789-21-000049:notes:221]
The Company granted PSUs to its senior executive officers under the SCP and the EIP where vesting is subject to both the continued employment of the participant by the Company and the achievement of certain financial and operational performance goals established by the Compensation Committee of the Company’s Board of Directors. A single PSU represents the right to receive a single ordinary share of the Company. During fiscal years 2021, 2020 and 2019, the Company granted 0.3 million, 0.3 million and 0.4 million PSUs, respectively, where performance is measured based on a three-year average return on invested capital (“ROIC”) goal and a relative total shareholder return (“TSR”) goal, which is based on the Company’s ordinary shares measured against a benchmark TSR of a peer group over the same three-year period (the “TSR/ROIC” awards). These awards vest after the end of the performance period of three years from the grant date. A percentage of these units may vest only if at least the minimum ROIC goal is met regardless of whether the TSR goal is met. The number of share units to vest will range from 0% to 200% of the targeted units. In evaluating the fair value of these units, the Company used a Monte Carlo simulation on the grant date, taking the market-based TSR goal into consideration. Compensation expense related to these units is only recorded in a period if it is probable that the ROIC goal will be met, and it is to be recorded at the expected level of achievement.

[0001137789-21-000049:notes:222]
The Company also granted 0.1 million, 0.1 million and 0.1 million PSUs during fiscal years 2021, 2020 and 2019, respectively, to its senior executive officers which are subject to a performance goal related to the Company's adjusted earnings per share (“AEPS”). These awards have a maximum seven-year vesting period, with 25% annual vesting starting on the first anniversary of the grant date. If the AEPS goal is not achieved, vesting is delayed to a following year in which the AEPS goal is achieved. Any unvested awards from prior years may vest cumulatively in a future year within the seven-year vesting period if the annual AEPS goal is achieved during a subsequent year. If the AEPS goal has not been met by the end of the seven-year period, any unvested shares will be forfeited.

[0001137789-21-000049:notes:223]
Determining Fair Value of Seagate Technology Share Plans

[0001137789-21-000049:notes:224]
Valuation and amortization method - The Company estimates the fair value of granted share options, RSUs and PSUs subject to an AEPS condition granted using the Black-Scholes-Merton valuation model and a single share award approach. This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period or the remaining service (vesting) period.

[0001137789-21-000049:notes:225]
Expected Term - Expected term represents the period that the Company’s share-based awards are expected to be outstanding and was determined based on historical experience of similar awards, giving consideration to the contractual terms of the share-based awards, vesting schedules and expectations of future employee behavior as influenced by changes to the terms of its share-based awards.

[0001137789-21-000049:notes:226]
Expected Volatility - The Company uses a combination of the implied volatility of its traded options and historical volatility of its share price.

[0001137789-21-000049:notes:227]
Expected Dividend - The Black-Scholes-Merton valuation model calls for a single expected dividend yield as an input. The dividend yield is determined by dividing the expected per share dividend during the coming year by the grant date share price. The expected dividend assumption is based on the Company’s current expectations about its anticipated dividend policy. Also, because the expected dividend yield should reflect marketplace participants’ expectations, the Company does not incorporate changes in dividends anticipated by management unless those changes have been communicated to or otherwise are anticipated by marketplace participants.

[0001137789-21-000049:notes:228]
Risk-Free Interest Rate - The Company bases the risk-free interest rate used in the Black-Scholes-Merton valuation model on the implied yield currently available on U.S. Treasury zero-coupon issues with an equivalent remaining term. Where the expected term of the Company's share-based awards do not correspond with the terms for which interest rates are quoted, the Company performed a straight-line interpolation to determine the rate from the available term maturities.

[0001137789-21-000049:notes:229]
The fair value of the Company’s shares related to options and RSUs granted to employees, shares issued from the ESPP and PSUs subject to TSR/ROIC or AEPS conditions for fiscal years 2021, 2020 and 2019 were estimated using the following assumptions:

[0001137789-21-000049:notes:230]
|  | Fiscal Years |
|  | 2021 |  | 2020 |  | 2019 |
| Options |  |  |  |  |  |
| Expected term (in years) | 4.2 |  | 4.2 |  | 4.2 |
| Volatility | 37 - 38% |  | 39 % |  | 39 - 40% |
| Weighted-average volatility | 38 | % |  | 39 | % |  | 39 | % |
| Expected dividend rate | 3.2 - 5.2% |  | 4.2 % |  | 4.6 - 5.0% |
| Weighted-average expected dividend rate | 4.7 | % |  | 4.2 | % |  | 4.7 | % |
| Risk-free interest rate | 0.2 - 0.7% |  | 1.4 % |  | 2.5 - 2.8% |
| Weighted-average fair value | $ | 10.77 |  |  | $ | 12.41 |  |  | $ | 11.49 |  |
| RSUs |  |  |  |  |  |
| Expected term (in years) | 1 - 2.5 |  | 1 - 2.5 |  | 1 - 2.5 |
| Expected dividend rate | 2.5 - 5.4% |  | 3.9 - 5.8% |  | 4.1 - 6.4% |
| Weighted-average expected dividend rate | 4.6 | % |  | 4.3 | % |  | 4.7 | % |
| Weighted-average fair value | $ | 50.64 |  |  | $ | 49.49 |  |  | $ | 44.37 |  |
| ESPP |  |  |  |  |  |
| Expected term (in years) | 0.5 |  | 0.5 |  | 0.5 |
| Volatility | 39 - 44% |  | 32 - 35% |  | 34 - 42% |
| Weighted-average volatility | 42 | % |  | 33 | % |  | 38 | % |
| Expected dividend rate | 4.0 - 5.8% |  | 4.3 - 5.4% |  | 4.8 - 5.6% |
| Weighted-average expected dividend rate | 5.1 | % |  | 4.9 | % |  | 5.2 | % |
| Risk-free interest rate | 0.1% |  | 1.6 - 2.0% |  | 2.2 - 2.4% |
| Weighted-average fair value | $ | 13.77 |  |  | $ | 12.23 |  |  | $ | 12.18 |  |
| PSUs subject to TSR/ROIC conditions |  |  |  |  |  |
| Expected term (in years) | 3.0 |  | 3.0 |  | 3.0 |
| Volatility | 38 | % |  | 37 | % |  | 46 | % |
| Weighted-average volatility | 38 | % |  | 37 | % |  | 46 | % |
| Expected dividend rate | 5.6 | % |  | 4.6 | % |  | 5.0 | % |
| Weighted-average expected dividend rate | 5.6 | % |  | 4.6 | % |  | 5.0 | % |
| Risk-free interest rate | 0.2 | % |  | 1.5 | % |  | 2.8 | % |
| Weighted-average fair value | $ | 43.20 |  |  | $ | 52.39 |  |  | $ | 46.38 |  |
| PSUs subject to an AEPS condition |  |  |  |  |  |
| Expected term (in years) | 2.5 |  | 2.5 |  | 2.5 |
| Expected dividend rate | 3.2 - 5.2% |  | 4.2 % |  | 4.6 - 5.0% |
| Weighted-average expected dividend rate | 4.9 | % |  | 4.2 | % |  | 4.7 | % |
| Weighted-average fair value | $ | 45.50 |  |  | $ | 49.27 |  |  | $ | 43.92 |  |

[0001137789-21-000049:notes:231]
Share-Based Compensation Expense

[0001137789-21-000049:notes:232]
The Company recorded $112 million, $109 million and $99 million of share-based compensation during fiscal years 2021, 2020 and 2019, respectively. Management has made an estimate of expected forfeitures and is recognizing compensation costs only for those equity awards expected to vest. When estimating forfeitures, the Company considers voluntary termination behavior as well as the historical analysis of actual forfeited awards.

[0001137789-21-000049:notes:233]
Share Option Activity

[0001137789-21-000049:notes:234]
The Company issues new ordinary shares upon exercise of share options. The following is a summary of option activities:

[0001137789-21-000049:notes:235]
| Options |  | Number of Shares(In millions) |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term(In years) |  | Aggregate Intrinsic Value(Dollars in millions) |
| Outstanding at July 3, 2020 |  | 2.4 |  |  | $ | 44.18 |  |  | 3.7 |  | $ | 15 |  |
| Granted |  | 0.3 |  |  | $ | 53.06 |  |  |  |  |  |
| Exercised |  | (1.1) |  |  | $ | 46.62 |  |  |  |  |  |
| Forfeitures |  | — |  |  | $ | 30.95 |  |  |  |  |  |
| Expirations |  | — |  |  | $ | 65.68 |  |  |  |  |  |
| Outstanding at July 2, 2021 |  | 1.6 |  |  | $ | 44.24 |  |  | 4.0 |  | $ | 69 |  |
| Vested and expected to vest at July 2, 2021 |  | 1.6 |  |  | $ | 44.09 |  |  | 4.0 |  | $ | 68 |  |
| Exercisable at July 2, 2021 |  | 1.0 |  |  | $ | 39.94 |  |  | 3.1 |  | $ | 47 |  |

[0001137789-21-000049:notes:236]
The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company’s ordinary shares for the options that were in-the-money at July 2, 2021. During fiscal years 2021, 2020 and 2019, the aggregate intrinsic value of options exercised under the Company’s share option plans was $31 million, $22 million and $5 million, respectively, determined as of the date of option exercise. The aggregate fair value of options vested during fiscal years 2021, 2020 and 2019 was approximately $4 million, $6 million and $9 million, respectively.

[0001137789-21-000049:notes:237]
At July 2, 2021, the total compensation cost related to options granted to employees but not yet recognized was approximately $6 million, net of an immaterial amount of estimated forfeitures. This cost is being amortized on a straight-line basis over a weighted-average remaining term of approximately 2.4 years and will be adjusted for subsequent changes in estimated forfeitures.

[0001137789-21-000049:notes:238]
Unvested Awards Activity

[0001137789-21-000049:notes:239]
The following is a summary of unvested award activities which do not contain a performance condition:

[0001137789-21-000049:notes:240]
| Unvested Awards |  | Number of Shares(In millions) |  | Weighted-Average Grant-Date Fair Value |
| Unvested at July 3, 2020 |  | 4.8 |  |  | $ | 41.77 |  |
| Granted |  | 3.3 |  |  | $ | 50.64 |  |
| Forfeitures |  | (0.2) |  |  | $ | 38.06 |  |
| Vested |  | (2.0) |  |  | $ | 38.28 |  |
| Unvested at July 2, 2021 |  | 5.9 |  |  | $ | 47.81 |  |

[0001137789-21-000049:notes:241]
At July 2, 2021, the total compensation cost related to unvested awards granted to employees but not yet recognized was approximately $204 million, net of estimated forfeitures of approximately $16 million. This cost is being amortized on a straight-line basis over a weighted-average remaining term of 2.5 years and will be adjusted for subsequent changes in estimated forfeitures. The aggregate fair value of unvested awards vested during fiscal years 2021, 2020 and 2019 were approximately $75 million, $71 million and $57 million, respectively.

[0001137789-21-000049:notes:242]
Performance Awards

[0001137789-21-000049:notes:243]
The following is a summary of unvested award activities which contain a performance condition:

[0001137789-21-000049:notes:244]
| Performance Awards |  | Number of Shares(In millions) |  | Weighted-Average Grant-Date Fair Value |
| Performance units at July 3, 2020 |  | 0.9 |  |  | $ | 42.77 |  |
| Granted |  | 0.6 |  |  | $ | 38.11 |  |
| Forfeitures |  | — |  |  | $ | 46.93 |  |
| Vested |  | (0.5) |  |  | $ | 28.20 |  |
| Performance units at July 2, 2021 |  | 1.0 |  |  | $ | 46.56 |  |

[0001137789-21-000049:notes:245]
At July 2, 2021, the total compensation cost related to performance awards granted to employees but not yet recognized was approximately $23 million, net of estimated forfeitures of approximately $3 million. This cost is being amortized on a straight-line basis over a weighted-average remaining term of 1.5 years. The aggregate fair value of performance awards vested during fiscal years 2021, 2020 and 2019 were approximately $8 million, $12 million and $12 million, respectively.

[0001137789-21-000049:notes:246]
ESPP

[0001137789-21-000049:notes:247]
During fiscal years 2021, 2020 and 2019, the aggregate intrinsic value of shares purchased under the Company's ESPP was approximately $27 million, $19 million and $10 million, respectively. At July 2, 2021, the total compensation cost related to options to purchase the Company's ordinary shares under the ESPP but not yet recognized was approximately $1.4 million. This cost will be amortized on a straight-line basis over a weighted-average period of approximately one month. During fiscal year 2021, the Company issued 1.5 million ordinary shares with a weighted-average exercise price of $38.24 per share.

[0001137789-21-000049:notes:248]
Tax-Deferred Savings Plan

[0001137789-21-000049:notes:249]
The Company has a tax-deferred savings plan, the Seagate 401(k) Plan (the "401(k) plan"), for the benefit of qualified employees. The 401(k) plan is designed to provide employees with an accumulation of funds at retirement. Qualified employees may elect to make contributions to the 401(k) plan on a bi-weekly basis. Pursuant to the 401(k) plan, the Company matches 50% of employee contributions, up to 6% of compensation, subject to maximum annual contributions of $6,000 per participating employee. During fiscal years 2021, 2020 and 2019, the Company made matching contributions of $15 million, $15 million and $16 million, respectively.

[0001137789-21-000049:notes:250]
Deferred Compensation Plan

[0001137789-21-000049:notes:251]
The Company has adopted the SDCP for the benefit of eligible employees. The plan is designed to permit certain discretionary employer contributions, in excess of the tax limits applicable to the 401(k) plan, and to permit employee deferrals in excess of certain tax limits. During fiscal year 2014, the Company entered into a TRS in order to manage the equity market risks associated with the SDCP liabilities. See Note 8. Derivative Financial Instruments contained in this report for additional information about the TRS.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001137789-21-000049:notes:252]
Guarantees
Indemnifications of Officers and Directors

[0001137789-21-000049:notes:253]
Seagate Technology, an exempted company incorporated with limited liability under the laws of the Cayman Islands (“Seagate-Cayman”) and wholly-owned subsidiary of STX, from time to time enters into indemnification agreements with the directors, officers, employees and agents of STX or any of its subsidiaries (each, an “Indemnitee”). The indemnification agreements provide indemnification in addition to any of Indemnitee’s indemnification rights under any relevant Articles of Association (or similar constitutional document), applicable law or otherwise, and indemnifies an Indemnitee for certain expenses (including attorneys’ fees), judgments, fines and settlement amounts actually and reasonably incurred by him or her in any action or proceeding, including any action by or in the right of STX or any of its subsidiaries, arising out of his or her service as a director, officer, employee or agent of STX or any of its subsidiaries or of any other entity to which he or she provides services at the Company’s request. However, Indemnitees are not indemnified under the indemnification agreements for (i) any fraud or dishonesty in the performance of Indemnitee’s duty to STX or the applicable subsidiary or (ii) Indemnitee’s conscious, intentional or willful failure to act honestly, lawfully and in good faith with a view to the best interests of the Company. In addition, the indemnification agreements provide that Seagate-Cayman will advance expenses incurred by an Indemnitee in connection with enforcement of the indemnification agreement or with the investigation, settlement or appeal of any action or proceeding against him or her as to which he or she could be indemnified.

[0001137789-21-000049:notes:254]
The nature of these indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay on behalf of its officers and directors. Historically, the Company has not made any significant indemnification payments under such indemnification agreements and no amount has been accrued in the Company’s consolidated financial statements with respect to these indemnification obligations.

[0001137789-21-000049:notes:255]
Indemnification Obligations

[0001137789-21-000049:notes:256]
The Company from time to time enters into agreements with customers, suppliers, partners and others in the ordinary course of business that provide indemnification for certain matters including, but not limited to, intellectual property infringement claims, environmental claims and breach of agreement claims. The nature of the Company’s indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the Company’s consolidated financial statements with respect to these indemnification obligations.

[0001137789-21-000049:notes:257]
Product Warranty

[0001137789-21-000049:notes:258]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation. As of July 2, 2021, the Company’s reserve for product warranty was $136 million compared to $151 million as of July 3, 2020. This decrease of $15 million was primarily driven by a continued decline in total number of units under warranty and a decrease in the Company’s warranty return rate as compared to prior year.

[0001137789-21-000049:notes:259]
Changes in the Company’s product warranty liability during the fiscal years ended July 2, 2021, July 3, 2020 and June 28, 2019 were as follows:

[0001137789-21-000049:notes:260]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | June 28,2019 |
| Balance, beginning of period |  | $ | 151 |  |  | $ | 195 |  |  | $ | 237 |  |
| Warranties issued |  | 76 |  |  | 86 |  |  | 112 |  |
| Repairs and replacements |  | (81) |  |  | (85) |  |  | (99) |  |
| Changes in liability for pre-existing warranties, including expirations |  | (10) |  |  | (45) |  |  | (55) |  |
| Balance, end of period |  | $ | 136 |  |  | $ | 151 |  |  | $ | 195 |  |


## us-gaap:EarningsPerShareTextBlock

[0001137789-21-000049:notes:261]
Earnings Per Share
Basic earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period. Diluted earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period and the number of additional shares that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding options, unvested RSUs and PSUs and shares to be purchased under the ESPP. The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in fair market value of the Company’s share price can result in a greater dilutive effect from potentially dilutive securities. The following table sets forth the computation of basic and diluted net income per share attributable to the shareholders of the Company:

[0001137789-21-000049:notes:262]
|  |  | Fiscal Years Ended |
| (In millions, except per share data) |  | July 2,2021 |  | July 3,2020 |  | June 28,2019 |
| Numerator: |  |  |  |  |  |  |
| Net income |  | $ | 1,314 |  |  | $ | 1,004 |  |  | $ | 2,012 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 242 |  |  | 262 |  |  | 282 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |
| Employee equity award plans |  | 3 |  |  | 3 |  |  | 3 |  |
| Total shares for purposes of calculating diluted net income per share |  | 245 |  |  | 265 |  |  | 285 |  |
| Net income per share |  |  |  |  |  |  |
| Basic |  | $ | 5.43 |  |  | $ | 3.83 |  |  | $ | 7.13 |  |
| Diluted |  | 5.36 |  |  | 3.79 |  |  | 7.06 |  |

[0001137789-21-000049:notes:263]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share were not material for the fiscal years ended July 2, 2021, July 3, 2020 and June 28, 2019.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001137789-21-000049:notes:264]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001137789-21-000049:notes:265]
Litigation

[0001137789-21-000049:notes:266]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al. On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “‘635 patent”) and U.S. Patent No. 5,638,267 (the “‘267 patent”), misappropriation of trade secrets, breach of contract and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants were infringing U.S. Patent No. 6,314,473 (the “‘473 patent”). The district court ruled in 2010 that the ‘267 patent was out of the case.

[0001137789-21-000049:notes:267]
On August 16, 2011, the district court granted in part and denied in part the Company’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that the Company did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by the Company because the Company’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001137789-21-000049:notes:268]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial is scheduled to begin on February 7, 2022. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.

[0001137789-21-000049:notes:269]
Seagate Technology LLC, et al. v. NHK Spring Co. Ltd. and TDK Corporation, et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology International filed a complaint in the United States District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc., and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Company had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Company paid artificially high prices on its purchases of suspension assemblies. The Company seeks to recover the overcharges it paid for suspension assemblies, as well as additional relief permitted by law.

[0001137789-21-000049:notes:270]
Nidec Corporation v. Seagate Technology LLC, et al. On January 18, 2021, Nidec Corporation filed a complaint against Seagate Technology LLC, Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology (Netherlands) B.V. in the United States District Court for the District of Delaware, alleging infringement of the following patents: U.S. Patent No. 8,737,017, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,742,239, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,935,528, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 10,407,775, titled “Base Plate, Hard Disk Drive, and Method of Manufacturing Base Plate,” and U.S. Patent No. 10,460,767, titled “Base Member Including Information Mark and Insulating Coating Layer, and Disk Drive Apparatus Including the Same.” The complaint seeks unspecified compensatory damages and other relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001137789-21-000049:notes:271]
Environmental Matters

[0001137789-21-000049:notes:272]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001137789-21-000049:notes:273]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001137789-21-000049:notes:274]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001137789-21-000049:notes:275]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001137789-21-000049:notes:276]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the U.S., Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001137789-21-000049:notes:277]
Other Matters 
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:CommitmentsDisclosureTextBlock

[0001137789-21-000049:notes:278]
Commitments 
Unconditional Long-Term Purchase Obligations. As of July 2, 2021, the Company had unconditional long-term purchase obligations of approximately $161 million, primarily related to purchases of minimum quarterly amounts of inventory components at fixed contractual prices. The Company expects the commitment to total $47 million, $44 million, $32 million, $24 million and $14 million for fiscal years 2023, 2024, 2025, 2026 and thereafter, respectively.

[0001137789-21-000049:notes:279]
Unconditional Long-term Capital Expenditures. As of July 2, 2021, the Company had $65 million unconditional long-term commitment primarily related to purchases of equipment.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001137789-21-000049:notes:280]
Business Segment and Geographic Information
 The Company’s manufacturing operations are based on technology platforms that are used to produce various data storage and systems solutions that serve multiple applications and markets. The Company has determined that its Chief Operating Decision Maker, the Chief Executive Officer, evaluates performance of the Company and makes decisions regarding investments in the Company’s technology platforms and manufacturing infrastructure based on the Company’s consolidated results. As a result, the Company has concluded that its manufacture and distribution of storage solutions constitutes one reporting segment.

[0001137789-21-000049:notes:281]
In fiscal year 2021, one customer accounted for approximately 11% of consolidated revenue. In fiscal years 2020 and 2019, no customer accounted for more than 10% of consolidated revenue.

[0001137789-21-000049:notes:282]
The following table summarizes the Company’s operations by country:

[0001137789-21-000049:notes:283]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | June 28,2019 |
| Revenue from external customers (1): |  |  |  |  |  |  |
| Singapore |  | $ | 5,180 |  |  | $ | 5,032 |  |  | $ | 5,085 |  |
| United States |  | 3,656 |  |  | 3,583 |  |  | 3,310 |  |
| The Netherlands |  | 1,825 |  |  | 1,572 |  |  | 1,630 |  |
| Other |  | 20 |  |  | 322 |  |  | 365 |  |
| Consolidated |  | $ | 10,681 |  |  | $ | 10,509 |  |  | $ | 10,390 |  |
| Long-lived assets: |  |  |  |  |  |  |
| Thailand |  | $ | 682 |  |  | $ | 681 |  |  | $ | 558 |  |
| United States |  | 612 |  |  | 567 |  |  | 523 |  |
| Singapore |  | 570 |  |  | 601 |  |  | 556 |  |
| Other |  | 411 |  |  | 376 |  |  | 286 |  |
| Consolidated |  | $ | 2,275 |  |  | $ | 2,225 |  |  | $ | 1,923 |  |

[0001137789-21-000049:notes:284]
___________________________________ 
(1) Revenue is attributed to countries based on the bill from location.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001137789-21-000049:notes:285]
Revenue
The following table provides information about disaggregated revenue by sales channel and geographical region for the Company’s single reportable segment:

[0001137789-21-000049:notes:286]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 2,2021 |  | July 3,2020 |  | June 28,2019 |
| Revenues by Channel |  |  |  |  |  |  |
| OEMs |  | $ | 7,403 |  |  | $ | 7,504 |  |  | $ | 7,261 |  |
| Distributors |  | 1,854 |  |  | 1,738 |  |  | 1,780 |  |
| Retailers |  | 1,424 |  |  | 1,267 |  |  | 1,349 |  |
| Total |  | $ | 10,681 |  |  | $ | 10,509 |  |  | $ | 10,390 |  |
| Revenues by Geography(1) |  |  |  |  |  |  |
| Asia Pacific |  | $ | 5,198 |  |  | $ | 5,060 |  |  | $ | 5,115 |  |
| Americas |  | 3,656 |  |  | 3,583 |  |  | 3,310 |  |
| EMEA |  | 1,827 |  |  | 1,866 |  |  | 1,965 |  |
| Total |  | $ | 10,681 |  |  | $ | 10,509 |  |  | $ | 10,390 |  |

[0001137789-21-000049:notes:287]
____________________________________________________
(1) Revenue is attributed to countries based on bill from locations.


## us-gaap:SubsequentEventsTextBlock

[0001137789-21-000049:notes:288]
Subsequent Events
Dividend Declared

[0001137789-21-000049:notes:289]
On July 19, 2021, the Company’s Board of Directors declared a quarterly cash dividend of $0.67 per share, which will be payable on October 6, 2021 to shareholders of record as of the close of business on September 22, 2021.
