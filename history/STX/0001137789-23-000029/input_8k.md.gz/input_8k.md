# STX 8-K — 0001137789-23-000025 filed 2023-04-20

## item codes, every 8-K on or before 2023-04-26

- 2023-04-20 0001137789-23-000025 — 2.02, 2.05, 5.02, 7.01, 9.01
- 2023-04-19 0001193125-23-106624 — 1.01, 2.02, 9.01
- 2023-03-29 0001137789-23-000021 — 2.05, 5.02
- 2023-01-25 0001137789-23-000007 — 2.02, 7.01, 9.01
- 2022-11-30 0001193125-22-295386 — 1.01, 2.03, 8.01, 9.01
- 2022-11-15 0001137789-22-000137 — 8.01
- 2022-11-09 0001137789-22-000129 — 5.02, 9.01
- 2022-11-08 0001193125-22-280194 — 1.01, 2.03
- 2022-10-26 0001137789-22-000118 — 8.01, 9.01
- 2022-10-26 0001137789-22-000116 — 2.02, 2.05, 7.01, 9.01
- 2022-10-25 0001193125-22-268425 — 5.02, 9.01 — amendment of 0001193125-22-228640
- 2022-10-25 0001193125-22-268417 — 5.07, 9.01
- 2022-08-31 0001137789-22-000062 — 7.01, 9.01
- 2022-08-24 0001193125-22-228640 — 5.02, 9.01
- 2022-08-19 0001193125-22-225260 — 1.01, 2.03
- 2022-07-21 0001137789-22-000039 — 2.02, 7.01, 9.01
- 2022-04-27 0001137789-22-000028 — 2.02, 7.01, 9.01
- 2022-03-30 0001193125-22-089760 — 5.02
- 2022-02-24 0001193125-22-052046 — 5.02
- 2022-01-26 0001137789-22-000008 — 2.02, 7.01, 9.01
- 2022-01-25 0001193125-22-017071 — 5.02, 9.01
- 2021-10-26 0001193125-21-307931 — 5.07
- 2021-10-22 0001137789-21-000105 — 2.02, 7.01, 9.01
- 2021-10-15 0001193125-21-299005 — 1.01, 2.03
- 2021-07-21 0001137789-21-000041 — 2.02, 7.01, 9.01
- 2021-06-08 0001137789-21-000033 — 7.01, 9.01
- 2021-05-19 0001193125-21-165970 — 1.01, 2.03, 3.01, 3.03, 5.02, 5.03, 8.01, 9.01
- 2021-04-22 0001137789-21-000023 — 2.02, 7.01, 9.01
- 2021-04-16 0001193125-21-119304 — 5.07
- 2021-03-22 0001193125-21-089557 — 5.02, 9.01
- 2021-01-21 0001137789-21-000003 — 2.02, 7.01, 9.01
- 2021-01-13 0001193125-21-008148 — 1.01, 2.03
- 2020-12-28 0001193125-20-327026 — 5.02, 9.01
- 2020-12-09 0001193125-20-313800 — 1.01, 2.03, 9.01
- 2020-12-04 0001193125-20-310713 — 1.01, 8.01, 9.01
- 2020-10-28 0001193125-20-279868 — 5.07
- 2020-10-22 0001137789-20-000098 — 2.02, 7.01, 9.01
- 2020-07-28 0001137789-20-000055 — 2.02, 7.01, 9.01
- 2020-07-02 0001193125-20-186902 — 8.01, 9.01
- 2020-06-18 0001193125-20-172622 — 1.01, 2.03, 8.01, 9.01
- 2020-06-11 0001193125-20-166696 — 1.01, 2.03, 9.01
- 2020-06-04 0001193125-20-160796 — 1.01, 8.01, 9.01
- 2020-06-03 0001193125-20-159172 — 7.01, 8.01, 9.01
- 2020-06-02 0001193125-20-157932 — 2.05
- 2020-05-11 0001193125-20-139025 — 8.01
- 2020-04-22 0001137789-20-000028 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001137789-20-000013 — 2.02, 7.01, 9.01
- 2019-11-04 0001193125-19-283563 — 5.02, 5.07, 9.01
- 2019-11-01 0001628280-19-013012 — 2.02, 7.01, 9.01
- 2019-09-19 0001193125-19-248970 — 1.01, 2.03, 8.01, 9.01
- 2019-09-18 0001193125-19-247385 — 7.01, 9.01
- 2019-09-04 0001193125-19-237150 — 8.01, 9.01
- 2019-08-02 0001193125-19-211505 — 2.02, 7.01, 9.01
- 2019-06-26 0001193125-19-182712 — 5.02
- 2019-06-18 0001193125-19-175303 — 8.01
- 2019-04-30 0001193125-19-129480 — 5.07
- 2019-04-30 0001193125-19-127378 — 2.02, 7.01, 9.01
- 2019-02-20 0001193125-19-045470 — 1.01, 2.03
- 2019-02-04 0001193125-19-027004 — 2.02, 7.01, 9.01
- 2018-12-21 0001193125-18-356446 — 5.02, 9.01
- 2018-11-02 0001193125-18-316430 — 5.07, 8.01, 9.01
- 2018-11-02 0001193125-18-316418 — 2.02, 7.01, 9.01
- 2018-09-07 0001193125-18-268679 — 5.02 — amendment of 0001193125-18-230467
- 2018-07-30 0001193125-18-230467 — 5.02, 9.01
- 2018-07-30 0001193125-18-230452 — 2.02, 7.01, 9.01
- 2018-07-26 0001193125-18-226626 — 5.02
- 2018-06-01 0001193125-18-181093 — 8.01, 9.01
- 2018-05-01 0001193125-18-145112 — 2.02, 7.01, 9.01
- 2018-01-29 0001193125-18-022528 — 2.02, 7.01, 9.01
- 2018-01-25 0001193125-18-019820 — 5.02, 9.01
- 2018-01-09 0001137789-18-000009 — 2.02, 7.01, 9.01
- 2018-01-08 0001137789-18-000004 — 2.02, 7.01, 9.01
- 2017-12-11 0001137789-17-000101 — 2.05
- 2017-10-23 0001193125-17-316068 — 2.02, 7.01, 9.01
- 2017-10-18 0001137789-17-000068 — 5.02, 5.07, 9.01
- 2017-09-28 0001137789-17-000060 — 1.01
- 2017-07-28 0001137789-17-000046 — 5.02
- 2017-07-25 0001193125-17-234440 — 2.02, 2.05, 5.02, 7.01, 9.01
- 2017-06-02 0001193125-17-192960 — 5.02
- 2017-04-26 0001193125-17-138005 — 2.02, 7.01, 9.01
- 2017-03-10 0001193125-17-077510 — 2.05
- 2017-02-03 0001104659-17-006357 — 1.01, 2.03, 9.01
- 2017-01-31 0001104659-17-005357 — 8.01, 9.01
- 2017-01-31 0001104659-17-005173 — 8.01, 9.01
- 2017-01-27 0001104659-17-004448 — 8.01
- 2017-01-24 0001193125-17-016690 — 2.02, 7.01, 9.01
- 2017-01-20 0001193125-17-013685 — 5.02, 9.01
- 2016-10-24 0001104659-16-151422 — 5.02, 5.03, 5.07, 9.01
- 2016-10-19 0001193125-16-741277 — 2.02, 7.01, 9.01
- 2016-10-11 0001193125-16-734835 — 2.02, 9.01
- 2016-10-04 0001104659-16-148575 — 5.02
- 2016-09-27 0001104659-16-146813 — 5.02
- 2016-08-02 0001104659-16-135908 — 2.02, 7.01, 9.01
- 2016-07-28 0001104659-16-135046 — 5.02
- 2016-07-11 0001104659-16-131996 — 2.02, 2.05, 9.01
- 2016-07-08 0001104659-16-131749 — 5.02
- 2016-06-29 0001104659-16-130122 — 2.05
- 2016-06-27 0001104659-16-129505 — 5.02
- 2016-04-29 0001104659-16-115593 — 2.02, 7.01, 9.01
- 2016-04-13 0001104659-16-111266 — 2.02, 9.01
- 2016-01-29 0001104659-16-092323 — 2.02, 7.01, 9.01
- 2016-01-04 0001104659-16-087730 — 5.02, 9.01
- 2015-10-30 0001104659-15-074350 — 2.02, 7.01, 9.01
- 2015-10-21 0001104659-15-071908 — 5.02, 9.01
- 2015-10-21 0001104659-15-071906 — 5.07, 7.01, 9.01
- 2015-10-15 0001104659-15-070776 — 2.02, 9.01
- 2015-09-21 0001104659-15-066273 — 5.02
- 2015-09-10 0001104659-15-064389 — 2.05
- 2015-08-06 0001104659-15-057159 — 5.02
- 2015-07-31 0001104659-15-055040 — 2.02, 7.01, 9.01
- 2015-07-22 0001104659-15-052507 — 5.02, 9.01
- 2015-07-13 0001104659-15-050755 — 2.02, 9.01
- 2015-05-14 0001104659-15-038166 — 1.01, 2.03, 9.01
- 2015-05-12 0001104659-15-036968 — 8.01, 9.01
- 2015-05-11 0001104659-15-036533 — 8.01, 9.01
- 2015-05-01 0001104659-15-033202 — 5.02
- 2015-04-23 0001104659-15-029483 — 8.01, 9.01
- 2015-04-17 0001104659-15-028152 — 2.02, 7.01, 9.01
- 2015-04-07 0001104659-15-026148 — 7.01
- 2015-01-26 0001104659-15-004316 — 2.02, 7.01, 9.01
- 2015-01-16 0001104659-15-002732 — 1.01, 9.01
- 2015-01-02 0001104659-15-000147 — 8.01
- 2014-12-02 0001104659-14-084370 — 1.01, 2.03, 9.01
- 2014-11-25 0001104659-14-083066 — 8.01, 9.01
- 2014-11-24 0001104659-14-082837 — 8.01, 9.01
- 2014-10-27 0001104659-14-073832 — 2.02, 7.01, 9.01
- 2014-10-24 0001104659-14-073609 — 5.02, 5.07, 9.01
- 2014-10-22 0001104659-14-073104 — 7.01, 9.01
- 2014-10-08 0001104659-14-070767 — 8.01
- 2014-09-12 0001104659-14-066107 — 5.02
- 2014-09-12 0001104659-14-066101 — 7.01
- 2014-07-23 0001104659-14-052995 — 5.02
- 2014-07-17 0001104659-14-052019 — 2.02, 7.01, 9.01
- 2014-06-18 0001104659-14-046714 — 8.01, 9.01
- 2014-06-09 0001104659-14-044575 — 7.01
- 2014-06-04 0001104659-14-043897 — 8.01
- 2014-05-28 0001104659-14-041862 — 1.01, 2.03, 8.01, 9.01
- 2014-05-20 0001104659-14-040454 — 8.01, 9.01
- 2014-05-20 0001104659-14-040220 — 8.01, 9.01
- 2014-04-29 0001104659-14-031916 — 2.02, 7.01, 9.01
- 2014-04-22 0001104659-14-029197 — 5.02
- 2014-02-24 0001104659-14-012465 — 5.02, 7.01, 9.01
- 2014-01-27 0001104659-14-004298 — 2.02, 7.01, 9.01
- 2014-01-23 0001104659-14-003803 — 5.02
- 2013-12-23 0001104659-13-091738 — 1.01, 8.01, 9.01
- 2013-11-05 0001104659-13-081194 — 1.01, 2.03, 9.01
- 2013-11-04 0001104659-13-080161 — 5.02, 5.03, 5.07, 9.01
- 2013-10-31 0001104659-13-079635 — 8.01, 9.01
- 2013-10-31 0001104659-13-079438 — 8.01, 9.01
- 2013-10-28 0001104659-13-078341 — 2.02, 7.01, 9.01
- 2013-10-28 0001104659-13-078316 — 5.02, 7.01, 9.01
- 2013-10-08 0001104659-13-074454 — 1.01, 1.02, 9.01
- 2013-09-20 0001104659-13-071413 — 5.02
- 2013-07-24 0001104659-13-056053 — 5.02, 7.01
- 2013-07-24 0001104659-13-056052 — 2.02, 7.01, 9.01
- 2013-06-14 0001104659-13-049436 — 8.01, 9.01
- 2013-05-31 0001104659-13-045928 — 8.01, 9.01
- 2013-05-22 0001104659-13-043876 — 1.01, 2.03, 9.01
- 2013-05-16 0001104659-13-042180 — 7.01, 9.01
- 2013-05-15 0001104659-13-042028 — 8.01, 9.01
- 2013-05-15 0001104659-13-041695 — 8.01, 9.01
- 2013-05-07 0001104659-13-038226 — 5.02
- 2013-05-01 0001104659-13-036004 — 2.02, 9.01
- 2013-03-15 0001104659-13-021156 — 7.01
- 2013-01-28 0001104659-13-005180 — 2.02, 9.01
- 2013-01-08 0001104659-13-001291 — 2.02, 9.01
- 2012-11-29 0001104659-12-080911 — 8.01, 9.01
- 2012-10-31 0001104659-12-072476 — 2.02, 9.01
- 2012-10-25 0001104659-12-071208 — 5.07
- 2012-10-16 0001104659-12-069238 — 7.01
- 2012-09-28 0001104659-12-066105 — 7.01
- 2012-09-21 0001104659-12-064869 — 7.01
- 2012-08-02 0001104659-12-053775 — 5.02
- 2012-07-30 0001104659-12-052298 — 2.02, 5.02, 8.01, 9.01
- 2012-07-05 0001104659-12-047737 — 2.02, 9.01
- 2012-04-26 0001104659-12-029099 — 5.02, 8.01, 9.01
- 2012-04-17 0001104659-12-025931 — 2.02, 9.01
- 2012-01-31 0001104659-12-005522 — 2.02, 9.01
- 2012-01-27 0001104659-12-004299 — 8.01, 9.01
- 2012-01-04 0001104659-12-000411 — 2.02, 9.01
- 2011-12-20 0001104659-11-070207 — 2.01, 3.02, 9.01
- 2011-12-12 0001104659-11-069005 — 8.01
- 2011-12-05 0001104659-11-067679 — 5.02, 9.01
- 2011-11-29 0001104659-11-066436 — 7.01, 9.01
- 2011-11-22 0001104659-11-065589 — 7.01, 9.01
- 2011-11-03 0001104659-11-060307 — 7.01
- 2011-10-21 0001104659-11-056997 — 2.02, 8.01, 9.01
- 2011-10-12 0001104659-11-055849 — 7.01, 9.01
- 2011-07-29 0001104659-11-041897 — 5.02
- 2011-07-20 0001104659-11-039922 — 2.02, 9.01
- 2011-06-01 0001104659-11-032473 — 8.01
- 2011-05-23 0001104659-11-030867 — 8.01
- 2011-05-18 0001104659-11-029869 — 1.01, 2.03, 9.01
- 2011-05-04 0001104659-11-025801 — 8.01, 9.01
- 2011-05-04 0001104659-11-025462 — 8.01, 9.01
- 2011-04-19 0001104659-11-020787 — 1.01, 2.02, 3.02, 9.01
- 2011-04-08 0001104659-11-019316 — 5.02, 9.01
- 2011-04-07 0001104659-11-019141 — 2.02, 8.01, 9.01
- 2011-03-09 0001104659-11-013084 — 5.02
- 2011-02-18 0001104659-11-008419 — 8.01
- 2011-02-01 0001104659-11-004106 — 5.02, 9.01
- 2011-01-19 0001104659-11-002037 — 1.01, 2.02, 2.03, 5.07, 9.01
- 2010-12-14 0001104659-10-062647 — 1.01, 2.03, 9.01
- 2010-12-08 0001104659-10-061747 — 8.01, 9.01
- 2010-12-08 0001104659-10-061643 — 7.01, 8.01, 9.01
- 2010-11-29 0001104659-10-060338 — 7.01, 9.01
- 2010-10-20 0001104659-10-052966 — 2.02, 9.01
- 2010-10-15 0001104659-10-052362 — 8.01, 9.01
- 2010-09-13 0001104659-10-048317 — 5.02, 9.01
- 2010-08-16 0001104659-10-044431 — 5.02
- 2010-07-29 0001104659-10-040519 — 5.02, 9.01
- 2010-07-20 0001104659-10-038670 — 2.02, 9.01
- 2010-07-06 0001104659-10-036996 — 1.01, 2.03, 3.01, 3.03, 5.01, 5.02, 8.01, 9.01
- 2010-06-25 0001104659-10-035630 — 8.01, 9.01
- 2010-05-26 0001104659-10-030931 — 5.02
- 2010-05-14 0001104659-10-028664 — 1.01, 2.03, 9.01
- 2010-04-30 0001104659-10-023493 — 8.01, 9.01
- 2010-04-29 0001104659-10-022773 — 1.02, 8.01, 9.01
- 2010-04-20 0001104659-10-020750 — 2.02, 9.01
- 2010-04-16 0001104659-10-020113 — 5.07
- 2010-03-22 0001104659-10-015668 — 1.01, 9.01
- 2010-03-03 0001104659-10-011870 — 1.01, 2.03, 9.01
- 2010-01-20 0001104659-10-002269 — 2.02, 9.01
- 2009-10-29 0001104659-09-060949 — 5.02, 7.01
- 2009-10-20 0001104659-09-059594 — 2.02, 9.01
- 2009-10-01 0001104659-09-057311 — 1.01, 2.03, 2.06, 9.01
- 2009-09-22 0001104659-09-055716 — 7.01, 9.01
- 2009-08-04 0001193125-09-163032 — 2.05
- 2009-07-31 0001193125-09-160678 — 5.02, 9.01
- 2009-07-21 0001193125-09-152269 — 2.02, 9.01
- 2009-07-09 0001193125-09-146452 — 5.02
- 2009-06-24 0001193125-09-136674 — 7.01, 9.01
- 2009-06-01 0001193125-09-122549 — 1.01, 2.03, 9.01
- 2009-05-14 0001193125-09-110016 — 8.01, 9.01
- 2009-05-13 0001193125-09-109216 — 2.05, 7.01, 9.01
- 2009-05-05 0001193125-09-099861 — 1.01, 2.03, 9.01
- 2009-04-21 0001193125-09-083544 — 2.02, 9.01
- 2009-04-17 0001193125-09-081018 — 8.01, 9.01
- 2009-04-13 0001193125-09-077471 — 2.02, 9.01
- 2009-04-13 0001193125-09-077470 — 8.01, 9.01
- 2009-04-06 0001193125-09-073113 — 1.01, 2.03, 9.01
- 2009-03-09 0001193125-09-048538 — 5.02
- 2009-03-04 0001193125-09-044916 — 5.02, 8.01
- 2009-02-06 0001193125-09-021262 — 5.02
- 2009-02-04 0001193125-09-018804 — 5.02, 8.01
- 2009-02-02 0001193125-09-016478 — 2.06 — amendment, the index does not say of what
- 2009-01-27 0001193125-09-012058 — 5.02
- 2009-01-21 0001193125-09-009019 — 2.02, 5.02, 9.01
- 2009-01-14 0001193125-09-005721 — 2.05, 7.01
- 2009-01-12 0001193125-09-004420 — 5.02, 7.01, 9.01
- 2008-12-24 0001193125-08-259972 — 2.06
- 2008-12-12 0001193125-08-252765 — 2.03
- 2008-12-10 0001193125-08-250840 — 7.01
- 2008-11-12 0001193125-08-233906 — 5.02
- 2008-10-22 0001193125-08-214482 — 2.02, 9.01
- 2008-09-19 0001193125-08-198664 — 2.05
- 2008-09-12 0001193125-08-195206 — 1.01
- 2008-08-27 0001193125-08-185448 — 1.02, 3.01, 5.02, 9.01
- 2008-07-15 0001193125-08-151292 — 2.02, 9.01
- 2008-07-11 0001193125-08-149749 — 2.05
- 2008-07-03 0001193125-08-146791 — 5.02
- 2008-04-29 0001193125-08-094835 — 5.02, 9.01
- 2008-04-15 0001193125-08-081743 — 2.02, 9.01
- 2008-03-12 0001193125-08-054331 — 8.01, 9.01
- 2008-03-04 0001193125-08-045657 — 7.01
- 2008-02-04 0001193125-08-019262 — 8.01, 9.01
- 2008-01-18 0001193125-08-008849 — 8.01, 9.01
- 2008-01-17 0001193125-08-008120 — 2.02, 9.01
- 2007-12-21 0001193125-07-269469 — 2.05
- 2007-12-05 0001193125-07-259675 — 5.02
- 2007-10-17 0001193125-07-220376 — 8.01, 9.01
- 2007-10-16 0001193125-07-219386 — 2.02, 9.01
- 2007-09-18 0000950134-07-020112 — 5.02, 9.01
- 2007-08-29 0000950134-07-019145 — 1.01, 2.02, 9.01
- 2007-07-20 0001193125-07-159001 — 8.01, 9.01
- 2007-07-19 0001193125-07-158214 — 2.02, 9.01
- 2007-04-18 0001193125-07-083845 — 8.01, 9.01
- 2007-04-17 0001193125-07-082824 — 2.02, 9.01
- 2007-04-10 0001193125-07-077251 — 2.02, 9.01
- 2007-02-27 0001193125-07-040081 — 5.02, 7.01
- 2007-01-24 0001193125-07-011834 — 8.01, 9.01
- 2007-01-23 0001193125-07-010955 — 2.02, 9.01
- 2006-12-21 0001193125-06-257603 — 8.01, 9.01
- 2006-12-07 0001193125-06-247897 — 5.02
- 2006-11-07 0001193125-06-225545 — 2.02, 7.01, 8.01, 9.01
- 2006-11-01 0001193125-06-220706 — 1.01, 9.01
- 2006-10-25 0001193125-06-214798 — 8.01, 9.01
- 2006-10-24 0001193125-06-213813 — 2.02, 9.01
- 2006-10-11 0001193125-06-206304 — 5.02
- 2006-10-03 0001193125-06-201845 — 5.02, 9.01
- 2006-09-21 0001193125-06-194878 — 1.01, 1.02, 2.03, 2.04, 8.01, 9.01
- 2006-09-19 0001193125-06-192726 — 8.01, 9.01
- 2006-09-12 0001193125-06-189437 — 5.02, 8.01, 9.01
- 2006-08-24 0001193125-06-179258 — 1.01
- 2006-08-09 0001193125-06-167961 — 8.01, 9.01
- 2006-08-08 0001193125-06-165853 — 2.02, 9.01
- 2006-06-01 0001193125-06-122124 — 7.01, 9.01
- 2006-05-25 0001193125-06-119646 — 1.01, 2.01, 2.03, 5.02, 9.01
- 2006-05-17 0001193125-06-114760 — 8.01, 9.01
- 2006-05-04 0001193125-06-099262 — 8.01, 9.01
- 2006-05-03 0001193125-06-098229 — 5.05, 9.01
- 2006-04-27 0001193125-06-090749 — 8.01
- 2006-04-20 0001193125-06-084566 — 8.01, 9.01
- 2006-04-18 0001193125-06-082414 — 2.02, 9.01
- 2006-04-13 0001193125-06-079690 — 8.01
- 2006-04-03 0001193125-06-071956 — 8.01
- 2006-03-13 0001193125-06-051798 — 8.01
- 2006-02-14 0001193125-06-030829 — 8.01, 9.01
- 2006-01-26 0001193125-06-012909 — 8.01, 9.01
- 2006-01-25 0001193125-06-011608 — 8.01, 9.01
- 2006-01-19 0001193125-06-008770 — 8.01, 9.01
- 2006-01-18 0001193125-06-007939 — 2.02, 9.01
- 2005-12-22 0001193125-05-247782 — 1.01, 5.02, 9.01
- 2005-12-22 0001193125-05-247766 — 1.01, 9.01
- 2005-12-21 0001193125-05-246701 — 8.01, 9.01
- 2005-12-01 0001193125-05-234733 — 7.01
- 2005-11-23 0001193125-05-231674 — 1.01, 1.02, 7.01, 9.01
- 2005-10-19 0001193125-05-203955 — 2.02, 9.01
- 2005-10-18 0001193125-05-203356 — 2.02, 7.01, 9.01
- 2005-09-08 0001193125-05-181893 — 7.01, 9.01
- 2005-09-07 0001193125-05-181605 — 1.01
- 2005-08-04 0001193125-05-157913 — 8.01, 9.01
- 2005-08-03 0001193125-05-156407 — 1.01, 8.01, 9.01
- 2005-07-19 0001193125-05-144591 — 2.02, 9.01
- 2005-06-08 0001193125-05-121880 — 7.01
- 2005-05-17 0001193125-05-109518 — 7.01
- 2005-04-19 0001193125-05-079453 — 2.02, 9.01
- 2005-03-22 0001193125-05-057519 — 1.01
- 2005-03-16 0001193125-05-052560 — 7.01
- 2005-03-07 0001193125-05-043752 — 7.01, 9.01
- 2005-02-08 0001193125-05-022340 — 1.01, 7.01
- 2005-01-18 0001193125-05-007666 — 2.02, 9.01
- 2004-12-13 0001193125-04-211590 — 7.01, 8.01, 9.01
- 2004-12-07 0001193125-04-208768 — 7.01, 9.01
- 2004-10-29 0001193125-04-181463 — 1.01, 5.02, 9.01
- 2004-10-19 0001193125-04-173795 — 2.02, 9.01
- 2004-09-23 0001193125-04-160889 — 8.01, 9.01
- 2004-09-21 0001193125-04-159593 — 8.01, 9.01
- 2004-09-07 0001193125-04-152868 — 7.01, 9.01
- 2004-07-28 0001193125-04-126152 — 5, 7
- 2004-07-20 0001193125-04-121017 — 12, 7
- 2004-06-02 0001193125-04-097697 — 7, 9
- 2004-04-30 0001193125-04-075386 — 5, 7
- 2004-04-20 0001193125-04-065621 — 12, 7
- 2004-04-06 0001193125-04-057855 — 12, 7
- 2004-03-16 0001193125-04-042542 — 5
- 2004-03-03 0001193125-04-033653 — 7, 9
- 2004-01-21 0001193125-04-006388 — 12, 5, 7
- 2003-10-31 0001193125-03-070294 — 5, 7
- 2003-10-27 0001193125-03-067685 — 5, 7
- 2003-10-22 0001193125-03-065398 — 12, 5, 7
- 2003-07-16 0001193125-03-019880 — 7, 9
- 2003-07-10 0001193125-03-018043 — 5
- 2003-07-07 0001193125-03-016864 — 5
- 2003-06-27 0001193125-03-014262 — 5, 7
- 2003-04-16 0001012870-03-001799 — 7, 9

## late-filing notifications on or before 2023-04-26

- none on or before 2023-04-26

## item 2.02 — earnings release, exhibit 99.1

[0001137789-23-000025:8k_2_02:1]
EX-99.1
2
stxq323pressreleasefinanci.htm
EX-99.1

[0001137789-23-000025:8k_2_02:2]
Document

[0001137789-23-000025:8k_2_02:3]
Exhibit 99.1

[0001137789-23-000025:8k_2_02:4]
Investor Relations Contact:

[0001137789-23-000025:8k_2_02:5]
Shanye Hudson, (510) 661-1600

[0001137789-23-000025:8k_2_02:6]
shanye.hudson@seagate.com

[0001137789-23-000025:8k_2_02:7]
Media Contact:

[0001137789-23-000025:8k_2_02:8]
Jen Bradfield

[0001137789-23-000025:8k_2_02:9]
jennifer.l.bradfield@seagate.com

[0001137789-23-000025:8k_2_02:10]
SEAGATE TECHNOLOGY REPORTS FISCAL THIRD QUARTER 2023 FINANCIAL RESULTS

[0001137789-23-000025:8k_2_02:11]
•Revenue of $1.86 billion

[0001137789-23-000025:8k_2_02:12]
•GAAP (loss) per share of $(2.09); non-GAAP (loss) per share of $(0.28)

[0001137789-23-000025:8k_2_02:13]
•Cash flow from operations of $228 million and free cash flow of $174 million

[0001137789-23-000025:8k_2_02:14]
•Declared cash dividend of $0.70 per share

[0001137789-23-000025:8k_2_02:15]
FREMONT, CA – April 20, 2023 - Seagate Technology Holdings plc (NASDAQ: STX) (the “Company” or “Seagate”) today reported financial results for its fiscal third quarter ended March 31, 2023.

[0001137789-23-000025:8k_2_02:16]
“We are seeing a more elongated customer inventory correction that led to weaker than expected nearline demand among a few large customers late in the quarter. Consequently, our March quarter revenue came in at the low-end of our guidance range, which along with underutilization charges and other factors had a severe impact on our reported margins and profitability,” said Dave Mosley, Seagate’s chief executive officer.

[0001137789-23-000025:8k_2_02:17]
“Looking ahead, we now expect demand recovery to begin towards the end of the calendar year. In response to this dynamic environment, we are taking aggressive actions to lower our cost structure while still positioning Seagate to thrive over the long-term and sustain our technology leadership. To that end, we continue to execute on our product roadmap, including our strategically vital HAMR platform that we launched in April, as anticipated.”

[0001137789-23-000025:8k_2_02:18]
Quarterly Financial Results

[0001137789-23-000025:8k_2_02:19]
|  | GAAP |  | Non-GAAP |  |  |
|  | FQ3 2023 |  | FQ3 2022 |  | FQ3 2023 |  | FQ3 2022 |  |  |
| Revenue ($M) | $ | 1,860 |  | $ | 2,802 |  | $ | 1,860 |  | $ | 2,802 |  |  |
| Gross Margin | 17.2% |  | 28.8% |  | 18.7% |  | 29.2% |  |  |
| Operating Margin | (16.9)% |  | 15.3% |  | 3.5% |  | 16.8% |  |  |
| Net (Loss) Income ($M) | $ | (433) |  | $ | 346 |  | $ | (58) |  | $ | 401 |  |  |
| Diluted (Loss) Earnings Per Share | $ | (2.09) |  | $ | 1.56 |  | $ | (0.28) |  | $ | 1.81 |  |  |

[0001137789-23-000025:8k_2_02:20]
GAAP operating expenses for the fiscal third quarter included a $300 million settlement penalty for alleged violations of U.S. Export Administration Regulations by the U.S. Department of Commerce’s Bureau of Industry and Security (“BIS”), that were subsequently resolved by a settlement agreement on April 18, 2023. Quarterly payments of $15 million will be made over the course of 5 years, starting in fiscal second quarter 2024.

[0001137789-23-000025:8k_2_02:21]
During the fiscal third quarter the Company generated $228 million in cash flow from operations and $174 million in free cash flow, and paid cash dividends of $145 million. Cash and cash equivalents totaled $766 million. There were 207 million ordinary shares issued and outstanding as of the end of the quarter.

[0001137789-23-000025:8k_2_02:22]
Seagate has issued a Supplemental Financial Information document, which is available on Seagate’s Investor Relations website at investors.seagate.com.

[0001137789-23-000025:8k_2_02:23]
Quarterly Cash Dividend

[0001137789-23-000025:8k_2_02:24]
The Board of Directors of the Company (the “Board”) declared a quarterly cash dividend of $0.70 per share, which will be payable on July 5, 2023 to shareholders of record as of the close of business on June 21, 2023. The payment of any future quarterly dividends will be at the discretion of the Board and will be dependent upon Seagate’s financial position, results of operations, available cash, cash flow, capital requirements and other factors deemed relevant by the Board.

[0001137789-23-000025:8k_2_02:25]
Restructuring Plan

[0001137789-23-000025:8k_2_02:26]
On April 20, 2023, the Company committed to a restructuring plan (the “Plan”) to reduce its cost structure in response to changes in macroeconomic and business conditions. The Plan is intended to align the Company’s operational needs with the near-term demand environment while continuing to support the long-term business strategy. The Plan, which the Company expects to be substantially completed by the end of the fiscal fourth quarter 2023, is expected to result in total pre-tax charges of approximately $150 million. The charges are expected to be primarily cash-based and consist of employee severance and other one-time termination benefits. The Company expects to realize run-rate savings of approximately $200 million on an annualized basis starting in the fiscal first quarter 2024.

[0001137789-23-000025:8k_2_02:27]
Business Outlook

[0001137789-23-000025:8k_2_02:28]
The Company is providing the following guidance for its fiscal fourth quarter 2023:

[0001137789-23-000025:8k_2_02:29]
•Revenue of $1.7 billion, plus or minus $150 million

[0001137789-23-000025:8k_2_02:30]
•Non-GAAP (loss) per share of $(0.20), plus or minus $0.20

[0001137789-23-000025:8k_2_02:31]
Guidance regarding non-GAAP diluted EPS excludes known pre-tax charges related to estimated share-based compensation expenses of $0.16 per share and restructuring costs of approximately $0.72 per share.

[0001137789-23-000025:8k_2_02:32]
We have not reconciled our non-GAAP diluted EPS guidance for fiscal fourth quarter 2023 to the most directly comparable GAAP measure because material items that may impact these measures are out of our control and/or cannot be reasonably predicted, including, but not limited to, accelerated depreciation, impairment and other charges related to cost saving efforts, net (gain) recognized from early redemption of debt and debt modification costs, pandemic-related lockdown charges, purchase order cancellation fees, strategic investment losses (gains) or impairment charges, income tax adjustments on these measures, and other charges or benefits that may arise. The amounts of these measures are not currently available but may be material to future results. A reconciliation of the non-GAAP diluted EPS guidance for fiscal fourth quarter 2023 to the corresponding GAAP measures is not available without unreasonable effort. A reconciliation of our historical non-GAAP financial measures to their nearest GAAP equivalent is contained in this release.

[0001137789-23-000025:8k_2_02:33]
Investor Communications

[0001137789-23-000025:8k_2_02:34]
Seagate management will hold a public webcast today at 6:00 AM PT / 9:00 AM ET that can be accessed on its Investor Relations website at investors.seagate.com.

[0001137789-23-000025:8k_2_02:35]
An archived audio webcast of this event will be available on Seagate’s Investor Relations website at investors.seagate.com shortly following the event conclusion.

[0001137789-23-000025:8k_2_02:36]
About Seagate

[0001137789-23-000025:8k_2_02:37]
Seagate Technology crafts the datasphere, helping to maximize humanity’s potential by innovating world-class, precision-engineered data storage and management solutions with a focus on sustainable partnerships. A global technology leader for more than 40 years, the company has shipped over four billion terabytes of data capacity. Learn more about Seagate by visiting www.seagate.com or following us on Twitter, Facebook, LinkedIn, YouTube, and subscribing to our blog.

[0001137789-23-000025:8k_2_02:38]
© 2023 Seagate Technology LLC. All rights reserved. Seagate, Seagate Technology, and the Spiral logo are registered trademarks of Seagate Technology LLC in the United States and/or other countries.

[0001137789-23-000025:8k_2_02:39]
Cautionary Note Regarding Forward-Looking Statements

[0001137789-23-000025:8k_2_02:40]
The inclusion of Seagate’s website addresses in this press release are provided for convenience only. The information contained in, or that can be accessed through, Seagate’s websites and social media channels are not part of this press release.

[0001137789-23-000025:8k_2_02:41]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-23-000025:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001137789-23-000025:8k_2_02:43]
(In millions)

[0001137789-23-000025:8k_2_02:44]
|  | March 31,2023 |  | July 1,2022 |
|  | (unaudited) |  |  |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 766 |  |  | $ | 615 |  |
| Accounts receivable, net | 994 |  |  | 1,532 |  |
| Inventories | 1,200 |  |  | 1,565 |  |
| Other current assets | 637 |  |  | 321 |  |
| Total current assets | 3,597 |  |  | 4,033 |  |
| Property, equipment and leasehold improvements, net | 1,753 |  |  | 2,239 |  |
| Goodwill | 1,237 |  |  | 1,237 |  |
| Other intangible assets, net | 1 |  |  | 9 |  |
| Deferred income taxes | 1,127 |  |  | 1,132 |  |
| Other assets, net | 252 |  |  | 294 |  |
| Total Assets | $ | 7,967 |  |  | $ | 8,944 |  |
| LIABILITIES AND (DEFICIT) EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 1,697 |  |  | $ | 2,058 |  |
| Accrued employee compensation | 84 |  |  | 252 |  |
| Accrued warranty | 73 |  |  | 65 |  |
| Current portion of long-term debt | 1,118 |  |  | 584 |  |
| Accrued expenses | 667 |  |  | 596 |  |
| Total current liabilities | 3,639 |  |  | 3,555 |  |
| Long-term accrued warranty | 88 |  |  | 83 |  |
| Other non-current liabilities | 404 |  |  | 135 |  |
| Long-term debt, less current portion | 4,840 |  |  | 5,062 |  |
| Total Liabilities | 8,971 |  |  | 8,835 |  |
| Total Shareholders' (Deficit) Equity | (1,004) |  |  | 109 |  |
| Total Liabilities and Shareholders’ (Deficit) Equity | $ | 7,967 |  |  | $ | 8,944 |  |

[0001137789-23-000025:8k_2_02:45]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-23-000025:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001137789-23-000025:8k_2_02:47]
(In millions, except per share data)

[0001137789-23-000025:8k_2_02:48]
(Unaudited)

[0001137789-23-000025:8k_2_02:49]
|  | For the Three Months Ended |  | For the Nine Months Ended |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| Revenue | $ | 1,860 |  |  | $ | 2,802 |  |  | $ | 5,782 |  |  | $ | 9,033 |  |
| Cost of revenue | 1,541 |  |  | 1,996 |  |  | 4,735 |  |  | 6,323 |  |
| Product development | 191 |  |  | 233 |  |  | 625 |  |  | 694 |  |
| Marketing and administrative | 123 |  |  | 141 |  |  | 377 |  |  | 410 |  |
| Amortization of intangibles | — |  |  | 3 |  |  | 3 |  |  | 9 |  |
| BIS settlement penalty | 300 |  |  | — |  |  | 300 |  |  | — |  |
| Restructuring and other, net | 20 |  |  | — |  |  | 110 |  |  | 2 |  |
| Total operating expenses | 2,175 |  |  | 2,373 |  |  | 6,150 |  |  | 7,438 |  |
| (Loss) income from operations | (315) |  |  | 429 |  |  | (368) |  |  | 1,595 |  |
| Interest income | 2 |  |  | — |  |  | 4 |  |  | 1 |  |
| Interest expense | (81) |  |  | (63) |  |  | (229) |  |  | (184) |  |
| Net gain recognized from early redemption of debt | 3 |  |  | — |  |  | 207 |  |  | — |  |
| Other, net | (9) |  |  | (15) |  |  | (25) |  |  | (14) |  |
| Other expense, net | (85) |  |  | (78) |  |  | (43) |  |  | (197) |  |
| (Loss) income before income taxes | (400) |  |  | 351 |  |  | (411) |  |  | 1,398 |  |
| Provision for income taxes | 33 |  |  | 5 |  |  | 26 |  |  | 25 |  |
| Net (loss) income | $ | (433) |  |  | $ | 346 |  |  | $ | (437) |  |  | $ | 1,373 |  |
| Net (loss) income per share: |  |  |  |  |  |  |  |
| Basic | $ | (2.09) |  |  | $ | 1.59 |  |  | $ | (2.11) |  |  | $ | 6.18 |  |
| Diluted | $ | (2.09) |  |  | $ | 1.56 |  |  | $ | (2.11) |  |  | $ | 6.08 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 207 |  |  | 218 |  |  | 207 |  |  | 222 |  |
| Diluted | 207 |  |  | 222 |  |  | 207 |  |  | 226 |  |
| Cash dividends declared per ordinary share | $ | 0.70 |  |  | $ | 0.70 |  |  | $ | 2.10 |  |  | $ | 2.07 |  |

[0001137789-23-000025:8k_2_02:50]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-23-000025:8k_2_02:51]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001137789-23-000025:8k_2_02:52]
(In millions)

[0001137789-23-000025:8k_2_02:53]
(Unaudited)

[0001137789-23-000025:8k_2_02:54]
|  | For the Nine Months Ended |
|  | March 31,2023 |  | April 1,2022 |
| OPERATING ACTIVITIES |  |  |  |
| Net (loss) income | $ | (437) |  |  | $ | 1,373 |  |
| Adjustments to reconcile net (loss) income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 409 |  |  | 324 |  |
| Share-based compensation | 93 |  |  | 106 |  |
| Deferred income taxes | 4 |  |  | 2 |  |
| Net gain on redemption and repurchase of debt | (207) |  |  | — |  |
| Other non-cash operating activities, net | 15 |  |  | 46 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 538 |  |  | (186) |  |
| Inventories | 365 |  |  | (275) |  |
| Accounts payable | (327) |  |  | 209 |  |
| Accrued employee compensation | (168) |  |  | (88) |  |
| Accrued expenses, income taxes and warranty | 69 |  |  | 19 |  |
| Other assets and liabilities | 370 |  |  | (53) |  |
| Net cash provided by operating activities | 724 |  |  | 1,477 |  |
| INVESTING ACTIVITIES |  |  |  |
| Acquisition of property, equipment and leasehold improvements | (266) |  |  | (309) |  |
| Proceeds from the sale of assets | 15 |  |  | — |  |
| Purchases of investments | (1) |  |  | (18) |  |
| Proceeds from sale of investments | — |  |  | 34 |  |
| Net cash used in investing activities | (252) |  |  | (293) |  |
| FINANCING ACTIVITIES |  |  |  |
| Redemption and repurchase of debt | (71) |  |  | (701) |  |
| Dividends to shareholders | (437) |  |  | (458) |  |
| Repurchases of ordinary shares | (408) |  |  | (1,313) |  |
| Taxes paid related to net share settlement of equity awards | (41) |  |  | (45) |  |
| Proceeds from issuance of long-term debt | 600 |  |  | 1,200 |  |
| Proceeds from issuance of ordinary shares under employee stock plans | 59 |  |  | 68 |  |
| Other financing activities, net | (23) |  |  | (6) |  |
| Net cash used in financing activities | (321) |  |  | (1,255) |  |
| Increase in cash, cash equivalents and restricted cash | 151 |  |  | (71) |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 617 |  |  | 1,211 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 768 |  |  | $ | 1,140 |  |

[0001137789-23-000025:8k_2_02:55]
Use of non-GAAP financial information

[0001137789-23-000025:8k_2_02:56]
The Company uses non-GAAP measures of gross profit, gross margin, operating expenses, income from operations, operating margin, net income, diluted EPS, free cash flow, EBITDA, adjusted EBITDA and last twelve months adjusted EBITDA, which are adjusted from results based on GAAP to exclude certain benefits, expenses, gains and losses. These non-GAAP financial measures are provided to enhance the user’s overall understanding of the Company’s current financial performance and its prospects for the future. Specifically, the Company believes non-GAAP results provide useful information to both management and investors as these non-GAAP results exclude certain benefits, expenses, gains and losses that it believes are not indicative of its core operating results and because it is similar to the approach used in connection with the financial models and estimates published by financial analysts who follow the Company.

[0001137789-23-000025:8k_2_02:57]
These non-GAAP results are some of the measurements management uses to assess the Company’s performance, allocate resources and plan for future periods. Reported non-GAAP results should only be considered as supplemental to results prepared in accordance with GAAP, and not considered as a substitute or replacement for, or superior to, GAAP results. These non-GAAP measures may differ from the non-GAAP measures reported by other companies in its industry.

[0001137789-23-000025:8k_2_02:58]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-23-000025:8k_2_02:59]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001137789-23-000025:8k_2_02:60]
(In millions, except per share amounts, gross margin and operating margin)

[0001137789-23-000025:8k_2_02:61]
(Unaudited)

[0001137789-23-000025:8k_2_02:62]
|  | For the Three Months Ended |  | For the Nine Months Ended |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| GAAP Gross Profit | $ | 319 |  | $ | 806 |  | $ | 1,047 |  | $ | 2,710 |
| Accelerated depreciation, impairment and other charges related to cost saving efforts | 18 |  | 1 |  | 57 |  | 1 |
| Amortization of acquired intangible assets | 1 |  | 1 |  | 3 |  | 3 |
| Pandemic-related lockdown charges | — |  | — |  | 7 |  | — |
| Purchase order cancellation fees | — |  | — |  | 108 |  | — |
| Share-based compensation | 8 |  | 9 |  | 24 |  | 27 |
| Other charges | 1 |  | — |  | 2 |  | — |
| Non-GAAP Gross Profit | $ | 347 |  | $ | 817 |  | $ | 1,248 |  | $ | 2,741 |
| GAAP Gross Margin | 17.2% |  | 28.8% |  | 18.1% |  | 30.0% |
| Non-GAAP Gross Margin | 18.7% |  | 29.2% |  | 21.6% |  | 30.3% |
| GAAP Operating Expenses | $ | 634 |  | $ | 377 |  | $ | 1,415 |  | $ | 1,115 |
| Accelerated depreciation, impairment and other charges related to cost saving efforts | (3) |  | — |  | (25) |  | — |
| Amortization of acquired intangible assets | — |  | (3) |  | (3) |  | (9) |
| BIS settlement penalty | (300) |  | — |  | (300) |  | — |
| Restructuring and other, net | (20) |  | — |  | (110) |  | (2) |
| Share-based compensation | (23) |  | (27) |  | (69) |  | (79) |
| Other charges | (6) |  | (2) |  | (18) |  | (4) |
| Non-GAAP Operating Expenses | $ | 282 |  | $ | 345 |  | $ | 890 |  | $ | 1,021 |
| GAAP (Loss) Income From Operations | $ | (315) |  | $ | 429 |  | $ | (368) |  | $ | 1,595 |
| Accelerated depreciation, impairment and other charges related to cost saving efforts | 21 |  | 1 |  | 82 |  | 1 |
| Amortization of acquired intangible assets | 1 |  | 4 |  | 6 |  | 12 |
| BIS settlement penalty | 300 |  | — |  | 300 |  | — |
| Pandemic-related lockdown charges | — |  | — |  | 7 |  | — |
| Purchase order cancellation fees | — |  | — |  | 108 |  | — |
| Restructuring and other, net | 20 |  | — |  | 110 |  | 2 |
| Share-based compensation | 31 |  | 36 |  | 93 |  | 106 |
| Other charges | 7 |  | 2 |  | 20 |  | 4 |
| Non-GAAP Income From Operations | $ | 65 |  | $ | 472 |  | $ | 358 |  | $ | 1,720 |
| GAAP Operating Margin | (16.9)% |  | 15.3% |  | (6.4)% |  | 17.7% |
| Non-GAAP Operating Margin | 3.5% |  | 16.8% |  | 6.2% |  | 19.0% |

[0001137789-23-000025:8k_2_02:63]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-23-000025:8k_2_02:64]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001137789-23-000025:8k_2_02:65]
(In millions, except per share amounts, gross margin and operating margin)

[0001137789-23-000025:8k_2_02:66]
(Unaudited)

[0001137789-23-000025:8k_2_02:67]
|  | For the Three Months Ended |  | For the Nine Months Ended |
|  | March 31,2023 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| GAAP Net (Loss) Income | $ | (433) |  | $ | 346 |  | $ | (437) |  | $ | 1,373 |
| Accelerated depreciation, impairment and other charges related to cost saving efforts | 21 |  | 1 |  | 82 |  | 1 |
| Amortization of acquired intangible assets | 1 |  | 4 |  | 6 |  | 12 |
| BIS settlement penalty | 300 |  | — |  | 300 |  | — |
| Net (gain) recognized from early redemption of debt and debt modification costs | (3) |  | — |  | (207) |  | 1 |
| Pandemic-related lockdown charges | — |  | — |  | 7 |  | — |
| Purchase order cancellation fees | — |  | — |  | 108 |  | — |
| Restructuring and other, net | 20 |  | — |  | 110 |  | 2 |
| Share-based compensation | 31 |  | 36 |  | 93 |  | 106 |
| Strategic investment losses or impairment charges | 1 |  | 13 |  | 1 |  | 6 |
| Other charges | 7 |  | 2 |  | 20 |  | 4 |
| Income tax adjustments | (3) |  | (1) |  | (6) |  | (17) |
| Non-GAAP Net (Loss) Income | $ | (58) |  | $ | 401 |  | $ | 77 |  | $ | 1,488 |
| GAAP Diluted Net (Loss) Income Per Share | $ | (2.09) |  |  | $ | 1.56 |  |  | $ | (2.11) |  |  | $ | 6.08 |  |
| Accelerated depreciation, impairment and other charges related to cost saving efforts | 0.10 |  |  | — |  |  | 0.39 |  |  | — |  |
| Amortization of acquired intangible assets | — |  |  | 0.02 |  |  | 0.03 |  |  | 0.05 |  |
| BIS settlement penalty | 1.45 |  |  | — |  |  | 1.45 |  |  | — |  |
| Net (gain) recognized from early redemption of debt and debt modification costs | (0.01) |  |  | — |  |  | (0.99) |  |  | — |  |
| Pandemic-related lockdown charges | — |  |  | — |  |  | 0.03 |  |  | — |  |
| Purchase order cancellation fees | — |  |  | — |  |  | 0.52 |  |  | — |  |
| Restructuring and other, net | 0.10 |  |  | — |  |  | 0.53 |  |  | 0.01 |  |
| Share-based compensation | 0.15 |  |  | 0.16 |  |  | 0.45 |  |  | 0.47 |  |
| Strategic investment losses or impairment charges | — |  |  | 0.06 |  |  | — |  |  | 0.03 |  |
| Other charges | 0.03 |  |  | 0.01 |  |  | 0.10 |  |  | 0.02 |  |
| Income tax adjustments | (0.01) |  |  | — |  |  | (0.03) |  |  | (0.08) |  |
| Non-GAAP Diluted Net (Loss) Income Per Share1 | $ | (0.28) |  |  | $ | 1.81 |  |  | $ | 0.37 |  |  | $ | 6.58 |  |
| Shares used in diluted net (loss) income per share calculation |  |  |  |  |  |  |  |
| GAAP | 207 |  |  | 222 |  |  | 207 |  |  | 226 |  |
| Non-GAAP | 207 |  |  | 222 |  |  | 209 |  |  | 226 |  |
| GAAP Net Cash Provided by Operating Activities | $ | 228 |  |  | $ | 460 |  |  | $ | 724 |  |  | $ | 1,477 |  |
| Acquisition of property, equipment and leasehold improvements | 54 |  |  | 97 |  |  | 266 |  |  | 309 |  |
| Free Cash Flow | $ | 174 |  |  | $ | 363 |  |  | $ | 458 |  |  | $ | 1,168 |  |

[0001137789-23-000025:8k_2_02:68]
1 For the three months ended March 31, 2023, GAAP and non-GAAP diluted net loss per share were computed using weighted average basic shares of 207 million, as a result of the net loss reported during the period. For the nine months ended March 31, 2023, GAAP diluted net loss per share was computed using weighted average basic shares of 207 million, as a result of the net loss reported during the period.

[0001137789-23-000025:8k_2_02:69]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-23-000025:8k_2_02:70]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001137789-23-000025:8k_2_02:71]
(In millions)

[0001137789-23-000025:8k_2_02:72]
(Unaudited)

[0001137789-23-000025:8k_2_02:73]
|  | For the Three Months Ended |  |  |
|  | March 31, 2023 |  | December 30, 2022 |  | September 30, 2022 |  | July 1, 2022 |  | Last Twelve Months |
| GAAP Net (Loss) Income | $ | (433) |  |  | $ | (33) |  |  | $ | 29 |  |  | $ | 276 |  |  | $ | (161) |  |
| Depreciation and amortization | 126 |  |  | 148 |  |  | 135 |  |  | 127 |  |  | 536 |  |
| Interest expense | 81 |  |  | 77 |  |  | 71 |  |  | 65 |  |  | 294 |  |
| Interest income | (2) |  |  | (1) |  |  | (1) |  |  | (1) |  |  | (5) |  |
| Income tax expense (benefit) | 33 |  |  | (5) |  |  | (2) |  |  | 5 |  |  | 31 |  |
| Non-GAAP EBITDA | (195) |  |  | 186 |  |  | 232 |  |  | 472 |  |  | 695 |  |
| BIS settlement penalty | 300 |  |  | — |  |  | — |  |  | — |  |  | 300 |  |
| Impairment and other charges related to cost saving efforts | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Net (gain) recognized from early redemption of debt and debt modification costs | (3) |  |  | (204) |  |  | — |  |  | — |  |  | (207) |  |
| Pandemic-related lockdown charges | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Purchase order cancellation fees | — |  |  | 108 |  |  | — |  |  | — |  |  | 108 |  |
| Restructuring and other, net | 20 |  |  | 81 |  |  | 9 |  |  | 1 |  |  | 111 |  |
| Share-based compensation | 31 |  |  | 33 |  |  | 29 |  |  | 39 |  |  | 132 |  |
| Strategic investment losses or impairment charges | 1 |  |  | — |  |  | — |  |  | 6 |  |  | 7 |  |
| Underutilization charges, net of depreciation and amortization | 60 |  |  | 45 |  |  | 37 |  |  | — |  |  | 142 |  |
| Other charges | 7 |  |  | 7 |  |  | 6 |  |  | 6 |  |  | 26 |  |
| Non-GAAP Adjusted EBITDA | $ | 221 |  |  | $ | 256 |  |  | $ | 319 |  |  | $ | 525 |  |  | $ | 1,321 |  |

[0001137789-23-000025:8k_2_02:74]
The Company’s Non-GAAP measures are adjusted for the following items:

[0001137789-23-000025:8k_2_02:75]
Accelerated depreciation, impairment and other charges related to cost saving efforts

[0001137789-23-000025:8k_2_02:76]
These expenses are excluded in the non-GAAP measures due to the inconsistency in amount and frequency and are excluded to facilitate a more meaningful evaluation of the Company’s current operating performance and comparison to its past periods’ operating performance.

[0001137789-23-000025:8k_2_02:77]
Amortization of acquired intangible assets

[0001137789-23-000025:8k_2_02:78]
The Company records expense from amortization of intangible assets that were acquired in connection with its business combinations over their estimated useful lives. Such charges are inconsistent in size and are significantly impacted by the timing and magnitude of the Company’s acquisitions. Consequently, these expenses are excluded in the non-GAAP measures to facilitate a more meaningful evaluation of its current operating performance and comparison to its past periods’ operating performance.

[0001137789-23-000025:8k_2_02:79]
BIS settlement penalty

[0001137789-23-000025:8k_2_02:80]
The Company accrued a settlement penalty of $300 million for the fiscal third quarter of 2023 related to the alleged violations of the U.S. Export Administration Regulations between August 17, 2020 and September 29, 2021 by the BIS, which were subsequently resolved by a settlement agreement on April 18, 2023. This settlement penalty is excluded from the non-GAAP measures to facilitate a more meaningful evaluation of the Company's current operating performance and comparison to its past periods' operating performance.

[0001137789-23-000025:8k_2_02:81]
Net (gain) recognized from early redemption of debt and debt modification costs

[0001137789-23-000025:8k_2_02:82]
From time to time, the Company incurs gains, losses and fees from the early redemption and repurchase of certain long-term debt instruments. The gains and losses represent the difference between the reacquisition price and the par value of the debt extinguished less the write-off of any unamortized debt issuance costs and discount. Fees include certain costs associated with a debt extinguishment or modification. The amount of these charges may be inconsistent in size and varies depending on the timing of the early redemption of debt and consequently is excluded from the non-GAAP measures to facilitate a more meaningful evaluation of its current operating performance and comparison to its past periods' operating performance.

[0001137789-23-000025:8k_2_02:83]
Pandemic-related lockdown charges

[0001137789-23-000025:8k_2_02:84]
Pandemic-related lockdown charges are factory under-utilization costs incurred due to the pandemic-related lockdown measures at our factory in Wuxi, China. These charges are inconsistent in amount and frequency and are excluded in the non-GAAP measures to facilitate a more meaningful evaluation of its current operating performance and comparison to its past periods’ operating performance.

[0001137789-23-000025:8k_2_02:85]
Purchase order cancellation fees

[0001137789-23-000025:8k_2_02:86]
Purchase order cancellation fees are the costs incurred to cancel certain purchase commitments made with the Company's suppliers for component and equipment purchases that will not be received due to change in forecasted demand. These charges are inconsistent in amount and frequency and are excluded in the non-GAAP measures to facilitate a more meaningful evaluation of its current operating performance and comparison to its past periods’ operating performance.

[0001137789-23-000025:8k_2_02:87]
Restructuring and other, net

[0001137789-23-000025:8k_2_02:88]
Restructuring and other, net are costs associated with restructuring plans that are primarily related to costs associated with reduction in the Company’s workforce, exiting certain facilities and other related costs, as well as charges or gains from sale of properties. These costs or benefits do not reflect the Company’s ongoing operating performance and consequently are excluded from the non-GAAP measures to facilitate a more meaningful evaluation of its current operating performance and comparison to its past periods’ operating performance.

[0001137789-23-000025:8k_2_02:89]
Share-based compensation

[0001137789-23-000025:8k_2_02:90]
These expenses consist primarily of expenses for employee share-based compensation. Given the variety of equity awards used by companies, the varying methodologies for determining share-based compensation expense, the subjective assumptions involved in those determinations, and the volatility in valuations that can be driven by market conditions outside the Company’s control, the Company believes excluding share-based compensation expense enhances the ability of management and investors to understand and assess the underlying performance of its business over time and compare it against the Company’s peers, a majority of whom also exclude share-based compensation expense from their non-GAAP results.

[0001137789-23-000025:8k_2_02:91]
Strategic investment losses or impairment charges

[0001137789-23-000025:8k_2_02:92]
From time to time, the Company incurs losses, gains or impairment charges from strategic investments that are measured and accounted at fair value, under the equity method of accounting, as available-for-sale debt securities or adjust for downward or upward adjustments to the carrying value under the measurement alternative if an impairment or observable price adjustment is recognized in the current period that are not considered as part of its ongoing operating performance. The resulting expense, gain or impairment loss is inconsistent in amount and frequency and consequently is excluded from the non-GAAP measures to facilitate a more meaningful evaluation of its current operating performance and comparison to its past periods’ operating performance.

[0001137789-23-000025:8k_2_02:93]
Other charges

[0001137789-23-000025:8k_2_02:94]
The other charges primarily include IT transformation costs. These charges are inconsistent in amount and frequency and are excluded in the non-GAAP measures to facilitate a more meaningful evaluation of its current operating performance and comparison to its past periods’ operating performance.

[0001137789-23-000025:8k_2_02:95]
Income tax adjustments

[0001137789-23-000025:8k_2_02:96]
Provision or benefit for income taxes represents the tax effects of non-GAAP adjustments determined using a hybrid with and without method and effective tax rate for the applicable adjustment and jurisdiction.

[0001137789-23-000025:8k_2_02:97]
Free cash flow

[0001137789-23-000025:8k_2_02:98]
Free cash flow is a non-GAAP measure defined as net cash provided by operating activities less acquisition of property, equipment and leasehold improvements. Free cash flow does not reflect non-cash items, net cash used or provided by financing activities and net cash used or provided by investing activities, other than acquisition of property, equipment and leasehold improvements. This non-GAAP financial measure is used by management to assess the Company's sources of liquidity, capital structure and operating performance.

[0001137789-23-000025:8k_2_02:99]
EBITDA, adjusted EBITDA and last twelve months (LTM) adjusted EBITDA

[0001137789-23-000025:8k_2_02:100]
EBITDA is defined as net income (loss) before income tax expense, interest expense, interest income, depreciation and amortization. Adjusted EBITDA excludes certain expenses, gains and losses that the Company believes are not indicative of its core operating results. These adjustments primarily include impairment and other charges related to cost saving efforts, net gain recognized from early redemption of debt and debt modification costs, pandemic-related lockdown charges, purchase order cancellation fees, restructuring and other, net, share-based compensation, strategic investment losses (gains) or impairment charges, other extraordinary charges such as factory underutilization charges and BIS settlement penalty. LTM adjusted EBITDA is defined as the total of last twelve months adjusted EBITDA. These non-GAAP financial measures are used by management to evaluate the Company’s debt portfolio and structure to comply with its financial debt covenants.

## item 5.02 — body, verbatim

[0001137789-23-000025:8k_body:1]
Item 5.02    Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001137789-23-000025:8k_body:2]
On April 16, 2023, the Board of Directors approved temporary salary reductions for the Company's named executive officers. Effective beginning May 1, 2023, for a period of 6 months, the base salary of each of William D. Mosley, the Company's Chief Executive Officer, and Gianluca Romano, the Company’s Executive Vice President and Chief Financial Officer, will be reduced by 100% and the base salary of Ban Seng Teh, the Company’s Executive Vice President and Chief Commercial Officer, will be reduced by 50%.

[0001137789-23-000025:8k_body:3]
On April 20, 2023, the Company announced that, in connection with the Plan, Jeffrey D. Nygaard, Executive Vice President of Operations and Technology, will leave the Company effective May 1, 2023.
