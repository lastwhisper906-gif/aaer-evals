# STX MD&A — 0001137789-23-000029


## mdna

[0001137789-23-000029:mdna:1]
[same as prior period, unchanged from 0001137789-23-000010:mdna:1]

[0001137789-23-000029:mdna:2]
The following is a discussion of the financial condition, changes in financial condition and results of operations for our fiscal quarters ended March 31, 2023, December 30, 2022 and April 1, 2022, referred to herein as the “March 2023 quarter,” the “December 2022 quarter,” and the “March 2022 quarter,” respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The March 2023 quarter, the December 2022 quarter and the March 2022 quarter were each 13 weeks.

[0001137789-23-000029:mdna:3]
[same as prior period, unchanged from 0001137789-23-000010:mdna:3]

[0001137789-23-000029:mdna:4]
[same as prior period, unchanged from 0001137789-23-000010:mdna:4]

[0001137789-23-000029:mdna:5]
•Overview of the March 2023 quarter. Highlights of events in the March 2023 quarter that impacted our financial position.

[0001137789-23-000029:mdna:6]
•Results of Operations. Analysis of our financial results comparing the March 2023 quarter to the December 2022 quarter and the March 2022 quarter.

[0001137789-23-000029:mdna:7]
[same as prior period, unchanged from 0001137789-23-000010:mdna:7]

[0001137789-23-000029:mdna:8]
[same as prior period, unchanged from 0001137789-23-000010:mdna:8]

[0001137789-23-000029:mdna:9]
[same as prior period, unchanged from 0001137789-23-000010:mdna:9]

[0001137789-23-000029:mdna:10]
Overview of the March 2023 quarter

[0001137789-23-000029:mdna:11]
During the March 2023 quarter, we shipped 119 exabytes of HDD storage capacity. We generated revenue of approximately $1.9 billion with a gross margin of 17%. Our operating cash flow was $228 million and we paid $145 million in dividends. Additionally, we accrued a settlement penalty of $300 million related to BIS’ allegations regarding violations of the U.S. EAR, which were subsequently resolved by a settlement agreement in April 2023.

[0001137789-23-000029:mdna:12]
[same as prior period, unchanged from 0001137789-23-000010:mdna:13]

[0001137789-23-000029:mdna:13]
During the March 2023 quarter, the data storage industry and our business continued to be impacted by macroeconomic headwinds and customer inventory adjustments, which led to a slowdown in demand for our products, particularly in the mass capacity markets. These reductions in demand have required us to reduce manufacturing production plans and recognize manufacturing underutilization charges. We expect these factors will continue to impact our business and results of operations over the near-term.

[0001137789-23-000029:mdna:14]
[same as prior period, unchanged from 0001137789-23-000010:mdna:17]

[0001137789-23-000029:mdna:15]
During the March 2023 quarter, in light of further deteriorating economic conditions, we committed to an expansion of the October 2022 Plan to further reduce the global headcount by approximately 480 employees to a total reduction of approximately 3,480 employees. This expanded plan includes aligning our business plan to near-term market conditions, along with other cost saving measures. The October 2022 Plan is expected to be substantially completed by the end of the fiscal year 2023. In connection to this expansion of the October 2022 Plan, we incurred additional employee termination costs and accelerated depreciation of certain capital equipment that would not be utilized as part of our operations.

[0001137789-23-000029:mdna:16]
We continue to actively monitor the effects and potential impacts of the macroeconomic conditions, pandemic and other factors on all aspects of our business, supply chain, liquidity and capital resources. We are also actively working on opportunities to further lower our cost structure, drive operational efficiencies through simplifying our product roadmaps and maintain supply chain discipline including adjusting our manufacturing production plans, annual capital expenditure plans and other meaningful cost savings measures in response to these business conditions. Subsequently on April 20, 2023, we committed to undertake the April 2023 restructuring plan to further reduce our cost in response to changes in macroeconomic and business conditions. The April 2023 Plan is expected to be substantially completed by the end of the fiscal year 2023, with estimated total pre-tax charges of approximately $150 million. These charges are expected to be primarily cash-based and consist of employee severance and other one-time termination benefits. For a further discussion of the uncertainties and business risks associated with the COVID-19 pandemic, see “Part II, Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q.

[0001137789-23-000029:mdna:17]
Subsequent Regulatory Settlement

[0001137789-23-000029:mdna:18]
On April 18, 2023, our subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd entered into the Settlement Agreement with the BIS that resolves BIS’ allegations regarding our sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, we agreed to pay $300 million to the BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. We have also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the U.S. EAR, including one audit by an unaffiliated third-party consultant chosen by us with expertise in U.S. export control laws and two internal audits. The Settlement Agreement also includes a denial order that is suspended and will be waived five years after the date of the order issued under the Settlement Agreement, provided that we have made full and timely payments under the Settlement Agreement and timely completed the audit requirements. While we are in compliance with and upon successful compliance in full with the terms of the Settlement Agreement, BIS has agreed it will not initiate any further administrative proceedings against us in connection with any violation of the EAR arising out of the transactions detailed in the Settlement Agreement.

[0001137789-23-000029:mdna:19]
While we believed that we complied with all relevant export control laws at the time we made the hard disk drive sales at issue, we determined that engaging with BIS and settling this matter was in the best interest of Seagate, our customers and our shareholders. In determining to engage with BIS and resolve this matter through a settlement agreement, we considered a number of factors, including the risks and cost of protracted litigation involving the U.S. government, as well as the size of the potential penalty and our desire to focus on current business challenges and long-term business strategy. The Settlement Agreement includes a finding that we incorrectly interpreted the regulation at issue to require evaluation of only the last stage of our hard disk drive manufacturing process rather than the entire process. As part of this settlement, we have agreed not to contest BIS’ determination that the sales in question did not comply with the U.S. EAR. Refer to “Item 1. Financial Statements—Note 12. Legal, Environmental and Other Contingencies” for more details.

[0001137789-23-000029:mdna:20]
[same as prior period, unchanged from 0001137789-23-000010:mdna:22]

[0001137789-23-000029:mdna:21]
[same as prior period, unchanged from 0001137789-23-000010:mdna:18]

[0001137789-23-000029:mdna:22]
[same as prior period, unchanged from 0001137789-23-000010:mdna:19]

[0001137789-23-000029:mdna:23]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 31,2023 |  | December 30,2022 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| Revenue |  | $ | 1,860 |  |  | $ | 1,887 |  |  | $ | 2,802 |  |  | $ | 5,782 |  |  | $ | 9,033 |  |
| Cost of revenue |  | 1,541 |  |  | 1,641 |  |  | 1,996 |  |  | 4,735 |  |  | 6,323 |  |
| Gross profit |  | 319 |  |  | 246 |  |  | 806 |  |  | 1,047 |  |  | 2,710 |  |
| Product development |  | 191 |  |  | 200 |  |  | 233 |  |  | 625 |  |  | 694 |  |
| Marketing and administrative |  | 123 |  |  | 125 |  |  | 141 |  |  | 377 |  |  | 410 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | 3 |  |  | 3 |  |  | 9 |  |
| BIS settlement penalty |  | 300 |  |  | — |  |  | — |  |  | 300 |  |  | — |  |
| Restructuring and other, net |  | 20 |  |  | 81 |  |  | — |  |  | 110 |  |  | 2 |  |
| (Loss) income from operations |  | (315) |  |  | (160) |  |  | 429 |  |  | (368) |  |  | 1,595 |  |
| Other (expense) income, net |  | (85) |  |  | 122 |  |  | (78) |  |  | (43) |  |  | (197) |  |
| (Loss) income before income taxes |  | (400) |  |  | (38) |  |  | 351 |  |  | (411) |  |  | 1,398 |  |
| Provision for (Benefit from) income taxes |  | 33 |  |  | (5) |  |  | 5 |  |  | 26 |  |  | 25 |  |
| Net (loss) income |  | $ | (433) |  |  | $ | (33) |  |  | $ | 346 |  |  | $ | (437) |  |  | $ | 1,373 |  |

[0001137789-23-000029:mdna:24]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
|  |  | March 31,2023 |  | December 30,2022 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 83 |  |  | 87 |  |  | 71 |  |  | 82 |  |  | 70 |  |
| Gross margin |  | 17 |  |  | 13 |  |  | 29 |  |  | 18 |  |  | 30 |  |
| Product development |  | 10 |  |  | 11 |  |  | 8 |  |  | 11 |  |  | 9 |  |
| Marketing and administrative |  | 7 |  |  | 7 |  |  | 5 |  |  | 7 |  |  | 5 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| BIS settlement penalty |  | 16 |  |  | — |  |  | — |  |  | 5 |  |  | — |  |
| Restructuring and other, net |  | 1 |  |  | 4 |  |  | — |  |  | 1 |  |  | — |  |
| Operating margin |  | (17) |  |  | (8) |  |  | 16 |  |  | (6) |  |  | 16 |  |
| Other (expense) income, net |  | (4) |  |  | 6 |  |  | (4) |  |  | (1) |  |  | (2) |  |
| (Loss) income before income taxes |  | (21) |  |  | (2) |  |  | 12 |  |  | (7) |  |  | 14 |  |
| Provision for (Benefit from) income taxes |  | 2 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |
| Net (loss) income |  | (23) | % |  | (2) | % |  | 12 | % |  | (8) | % |  | 14 | % |

[0001137789-23-000029:mdna:25]
[same as prior period, unchanged from 0001137789-23-000010:mdna:23]

[0001137789-23-000029:mdna:26]
[same as prior period, unchanged from 0001137789-23-000010:mdna:24]

[0001137789-23-000029:mdna:27]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
|  |  | March 31,2023 |  | December 30,2022 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 73 | % |  | 72 | % |  | 77 | % |  | 74 | % |  | 73 | % |
| Distributors |  | 16 | % |  | 16 | % |  | 12 | % |  | 15 | % |  | 16 | % |
| Retailers |  | 11 | % |  | 12 | % |  | 11 | % |  | 11 | % |  | 11 | % |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 42 | % |  | 40 | % |  | 46 | % |  | 40 | % |  | 48 | % |
| Americas |  | 43 | % |  | 45 | % |  | 42 | % |  | 45 | % |  | 38 | % |
| EMEA |  | 15 | % |  | 15 | % |  | 12 | % |  | 15 | % |  | 14 | % |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 66 | % |  | 66 | % |  | 69 | % |  | 67 | % |  | 66 | % |
| Legacy |  | 20 | % |  | 22 | % |  | 23 | % |  | 20 | % |  | 25 | % |
| Other |  | 14 | % |  | 12 | % |  | 8 | % |  | 13 | % |  | 9 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 104 |  |  | 97 |  |  | 133 |  |  | 305 |  |  | 402 |  |
| Legacy |  | 15 |  |  | 16 |  |  | 21 |  |  | 45 |  |  | 74 |  |
| Total |  | 119 |  |  | 113 |  |  | 154 |  |  | 350 |  |  | 476 |  |
| HDD Price per Terabyte |  | $ | 14 |  |  | $ | 15 |  |  | $ | 17 |  |  | $ | 14 |  |  | $ | 17 |  |

[0001137789-23-000029:mdna:28]
[same as prior period, unchanged from 0001137789-23-000010:mdna:26]

[0001137789-23-000029:mdna:29]
[same as prior period, unchanged from 0001137789-23-000010:mdna:27]

[0001137789-23-000029:mdna:30]
Revenue in the March 2023 quarter decreased by $27 million from the December 2022 quarter primarily due to price erosion, partially offset by an increase in mass capacity exabytes shipped and higher demand for our non-HDD products.

[0001137789-23-000029:mdna:31]
Revenue for the three and nine months ended March 31, 2023 decreased by $942 million and $3.3 billion from the three and nine months ended April 1, 2022, respectively, primarily due to a decrease in exabytes shipped as a result of lower market demand in mass capacity and legacy markets that were impacted by macroeconomic conditions and price erosion. Additionally, the decrease in revenue for the nine months ended March 31, 2023 compared to the nine months ended April 1, 2022 was impacted by pandemic-related headwinds.

[0001137789-23-000029:mdna:32]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 16% of gross revenue for the March 2023 quarter, 17% for the December 2022 quarter and 14% for the March 2022 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-23-000029:mdna:33]
[same as prior period, unchanged from 0001137789-23-000010:mdna:31]

[0001137789-23-000029:mdna:34]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 31,2023 |  | December 30,2022 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| Cost of revenue |  | $ | 1,541 |  |  | $ | 1,641 |  |  | $ | 1,996 |  |  | $ | 4,735 |  |  | $ | 6,323 |  |
| Gross profit |  | 319 |  |  | 246 |  |  | 806 |  |  | 1,047 |  |  | 2,710 |  |
| Gross margin |  | 17 | % |  | 13 | % |  | 29 | % |  | 18 | % |  | 30 | % |

[0001137789-23-000029:mdna:35]
Gross margin for the March 2023 quarter increased compared to the December 2022 quarter primarily driven by $108 million of order cancellation fees incurred during the December 2022 quarter that did not recur, and lower accelerated depreciation expense for certain capital equipment, partially offset by price erosion.

[0001137789-23-000029:mdna:36]
33

[0001137789-23-000029:mdna:37]
Gross margin for the March 2023 quarter decreased compared to the March 2022 quarter primarily due to price erosion, less favorable product mix, $75 million of factory underutilization charges associated with lower production levels and accelerated depreciation expense for certain capital equipment.

[0001137789-23-000029:mdna:38]
Gross margin for the nine months ended March 31, 2023 decreased compared to the nine months ended April 1, 2022 primarily driven by $210 million factory underutilization charges associated with lower production levels and pandemic-related lockdown in one of our factories, $108 million of order cancellation fees, price erosion and accelerated depreciation expense for certain capital equipment.

[0001137789-23-000029:mdna:39]
In the March 2023 quarter, total warranty cost was 1.7% of revenue and included an unfavorable change in estimates of prior warranty accruals of 0.9% of revenue primarily due to changes to our estimated future product return rates. Warranty cost related to new shipments was 0.8%, 0.7% and 0.7% of revenue for the March 2023 quarter, December 2022 quarter and March 2022 quarter, respectively.

[0001137789-23-000029:mdna:40]
[same as prior period, unchanged from 0001137789-23-000010:mdna:36]

[0001137789-23-000029:mdna:41]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 31,2023 |  | December 30,2022 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| Product development |  | $ | 191 |  |  | $ | 200 |  |  | $ | 233 |  |  | $ | 625 |  |  | $ | 694 |  |
| Marketing and administrative |  | 123 |  |  | 125 |  |  | 141 |  |  | 377 |  |  | 410 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | 3 |  |  | 3 |  |  | 9 |  |
| BIS settlement penalty |  | 300 |  |  | — |  |  | — |  |  | 300 |  |  | — |  |
| Restructuring and other, net |  | 20 |  |  | 81 |  |  | — |  |  | 110 |  |  | 2 |  |
| Operating expenses |  | $ | 634 |  |  | $ | 406 |  |  | $ | 377 |  |  | $ | 1,415 |  |  | $ | 1,115 |  |

[0001137789-23-000029:mdna:42]
Product development expense. Product development expenses decreased by $9 million in the March 2023 quarter compared to the December 2022 quarter primarily due to a $7 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our October 2022 restructuring plan and a $2 million decrease in materials expense.

[0001137789-23-000029:mdna:43]
Product development expenses decreased by $42 million in the March 2023 quarter compared to the March 2022 quarter primarily due to a $17 million decrease in variable compensation and related benefit expense, a $16 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our October 2022 restructuring plan and a $6 million decrease in materials expense.

[0001137789-23-000029:mdna:44]
Product development expenses decreased by $69 million for the nine months ended March 31, 2023 compared to the nine months ended April 1, 2022 primarily due to a $57 million decrease in variable compensation and related benefit expense, a $19 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our October 2022 restructuring plan, a $7 million decrease in materials expense and a $4 million decrease in equipment expense, partially offset by a $24 million increase in depreciation expense as a result of acceleration of depreciation for certain capital equipment.

[0001137789-23-000029:mdna:45]
Marketing and administrative expense. Marketing and administrative expenses decreased by $2 million in the March 2023 quarter compared to the December 2022 quarter primarily due to a $5 million decrease in compensation and other employee benefits primarily from the reduction in headcount as a result of our October 2022 restructuring plan and a $3 million decrease in outside services expense, partially offset by a $7 million recovery in December 2022 quarter of an accounts receivable previously written-off in prior year.

[0001137789-23-000029:mdna:46]
Marketing and administrative expenses decreased by $18 million in the March 2023 quarter compared to the March 2022 quarter primarily due to a $10 million decrease in variable compensation and related benefit expense, a $4 million decrease compensation and other employee benefits primarily from the reduction in headcount as a result of our October 2022 restructuring plan and a $3 million decrease in outside services expense.

[0001137789-23-000029:mdna:47]
Marketing and administrative expenses decreased by $33 million for the nine months ended March 31, 2023 compared to the nine months ended April 1, 2022 primarily due to a $34 million decrease in variable compensation and related benefit expense, a $7 million decrease in compensation and other employee benefits primarily from the reduction in headcount as a result of our October 2022 restructuring plan and a $7 million recovery of an accounts receivable previously written-off in the prior year, partially offset by a $5 million increase in travel expenses as a result of the easing of pandemic-related travel restrictions, a $3 million increase in outside services expense and a $2 million increase in advertising costs.

[0001137789-23-000029:mdna:48]
Amortization of intangibles. Amortization of intangibles for the three and nine months ended March 31, 2023 decreased by $3 million and $6 million, respectively, compared to the three and nine months ended April 1, 2022, due to certain intangible assets that reached the end of their useful lives.

[0001137789-23-000029:mdna:49]
BIS settlement penalty. BIS settlement penalty for the three and nine months ended March 31, 2023 was $300 million, related to BIS’ allegations of violations of the U.S. EAR, which were subsequently resolved by the Settlement Agreement in April 2023.

[0001137789-23-000029:mdna:50]
Restructuring and other, net. Restructuring and other, net for the three and nine months ended March 31, 2023 was $20 million and $110 million, respectively, which was primarily comprised of workforce reduction costs under our October 2022 Plan.

[0001137789-23-000029:mdna:51]
Other (Expense) Income, Net

[0001137789-23-000029:mdna:52]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 31,2023 |  | December 30,2022 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| Other (expense) income, net |  | $ | (85) |  |  | $ | 122 |  |  | $ | (78) |  |  | $ | (43) |  |  | $ | (197) |  |

[0001137789-23-000029:mdna:53]
Other (expense) income, net. Other expense, net increased by $207 million for the March 2023 quarter compared to the December 2022 quarter primarily due to a $204 million net gain recognized in December 2022 quarter from early redemption and extinguishment of $964 million of debt from the July 2029 Notes, January 2031 Notes and July 2031 Notes in exchange with issuance of the new December 2032 Notes of $750 million.

[0001137789-23-000029:mdna:54]
Other expense, net increased by $7 million for the March 2023 quarter compared to the March 2022 quarter primarily due to a $19 million increase in interest expense from the issuance of long-term debt partially offset by a net $10 million higher non-recurring gain from our strategic investments in the March 2022 quarter.

[0001137789-23-000029:mdna:55]
Other expense, net decreased by $154 million for the nine months ended March 31, 2023 compared to the nine months ended April 1, 2022 primarily due to a $204 million net gain recognized from early redemption and extinguishment of $964 million of debt from the July 2029 Notes, January 2031 Notes and July 2031 Notes in exchange with issuance of the new December 2032 Notes of $750 million, partially offset by a $45 million increase in interest expense.

[0001137789-23-000029:mdna:56]
[same as prior period, unchanged from 0001137789-23-000010:mdna:51]

[0001137789-23-000029:mdna:57]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | March 31,2023 |  | December 30,2022 |  | April 1,2022 |  | March 31,2023 |  | April 1,2022 |
| Provision for (benefit from) income taxes |  | $ | 33 |  |  | $ | (5) |  |  | $ | 5 |  |  | $ | 26 |  |  | $ | 25 |  |

[0001137789-23-000029:mdna:58]
We recorded income tax provisions of $33 million and $26 million for the three and nine months ended March 31, 2023, respectively. The discrete items in the income tax provision were not material for the three and nine months ended March 31, 2023.

[0001137789-23-000029:mdna:59]
[same as prior period, unchanged from 0001137789-23-000010:mdna:54]

[0001137789-23-000029:mdna:60]
During the nine months ended March 31, 2023, our unrecognized tax benefits excluding interest and penalties increased by approximately $1 million to $115 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. We do not expect material changes to our unrecognized tax benefits in the next twelve months beginning April 1, 2023.

[0001137789-23-000029:mdna:61]
We recorded income tax provisions of $5 million and $25 million for the three and nine months ended April 1, 2022, respectively. The income tax provision for the three months ended April 1, 2022 included approximately $6 million of net discrete tax benefit, primarily associated with a change in the applicable tax rate within our non-U.S. operations. The income tax provision for the nine months ended April 1, 2022 included approximately $15 million of net discrete tax benefit, primarily associated with net excess tax benefits related to share-based compensation expense.

[0001137789-23-000029:mdna:62]
Our income tax provision recorded for the three and nine months ended March 31, 2023 and April 1, 2022 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-23-000029:mdna:63]
[same as prior period, unchanged from 0001137789-23-000010:mdna:58]

[0001137789-23-000029:mdna:64]
[same as prior period, unchanged from 0001137789-23-000010:mdna:59]

[0001137789-23-000029:mdna:65]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of March 31, 2023.

[0001137789-23-000029:mdna:66]
[same as prior period, unchanged from 0001137789-23-000010:mdna:61]

[0001137789-23-000029:mdna:67]
| (Dollars in millions) |  | March 31,2023 |  | July 1,2022 |  | Change |
| Cash and cash equivalents |  | $ | 766 |  |  | $ | 615 |  |  | $ | 151 |  |

[0001137789-23-000029:mdna:68]
Our cash and cash equivalents as of March 31, 2023 increased by $151 million from July 1, 2022 primarily as a result of net cash of $724 million provided by operating activities and net proceeds of $600 million from the issuance of long-term debt partially offset by the dividends paid to our shareholders of $437 million, repurchases of our ordinary shares of $408 million, payments for capital expenditures of $266 million and $71 million redemption and repurchases of long-term debt.

[0001137789-23-000029:mdna:69]
[same as prior period, unchanged from 0001137789-23-000010:mdna:64]

[0001137789-23-000029:mdna:70]
Cash provided by operating activities for the nine months ended March 31, 2023 was $724 million and includes the effects of net loss adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-23-000029:mdna:71]
•a decrease of $538 million in accounts receivable, primarily due to lower revenue and timing of collections;

[0001137789-23-000029:mdna:72]
•a decrease of $365 million in inventories, primarily due to a decrease in units built to align with the prevailing demand environment;

[0001137789-23-000029:mdna:73]
[same as prior period, unchanged from 0001137789-23-000010:mdna:68]

[0001137789-23-000029:mdna:74]
•a decrease of $327 million in accounts payable, primarily due to a decrease in materials purchased; and

[0001137789-23-000029:mdna:75]
•a decrease of $168 million in accrued employee compensation, primarily due to cash paid to our employees as part of our discretionary spending plans.

[0001137789-23-000029:mdna:76]
[same as prior period, unchanged from 0001137789-23-000010:mdna:71]

[0001137789-23-000029:mdna:77]
Cash used in investing activities for the nine months ended March 31, 2023 was $252 million, primarily attributable to payments for the purchase of property, equipment and leasehold improvements.

[0001137789-23-000029:mdna:78]
Cash Used in Financing Activities

[0001137789-23-000029:mdna:79]
Net cash used in financing activities of $321 million for the nine months ended March 31, 2023 was primarily attributable to the following activities:

[0001137789-23-000029:mdna:80]
•$437 million in dividend payments;

[0001137789-23-000029:mdna:81]
[same as prior period, unchanged from 0001137789-23-000010:mdna:75]

[0001137789-23-000029:mdna:82]
•$71 million redemption and repurchases of long-term debt; partially offset by

[0001137789-23-000029:mdna:83]
[same as prior period, unchanged from 0001137789-23-000010:mdna:77]

[0001137789-23-000029:mdna:84]
[same as prior period, unchanged from 0001137789-23-000010:mdna:78]

[0001137789-23-000029:mdna:85]
Our primary sources of liquidity as of March 31, 2023 consist of: (1) approximately $766 million in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.75 billion available for borrowing under our Revolving Credit Facility, which is part of the Credit Agreement.

[0001137789-23-000029:mdna:86]
As of March 31, 2023, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-23-000029:mdna:87]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The term of the Revolving Credit Facility is through October 14, 2026. As of March 31, 2023, we were in compliance with all of the covenants under our debt agreements. On November 8, 2022, we entered into the Seventh Amendment to our Credit Agreement to increase the maximum permitted total leverage ratio we must comply with during the covenant relief period which ends on June 28, 2024. We continue to evaluate our debt portfolio and structure to comply with our financial debt covenants.

[0001137789-23-000029:mdna:88]
[same as prior period, unchanged from 0001137789-23-000010:mdna:82]

[0001137789-23-000029:mdna:89]
[same as prior period, unchanged from 0001137789-23-000010:mdna:83]

[0001137789-23-000029:mdna:90]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness and to fund our quarterly dividend and any future strategic investments. As of March 31, 2023, our contractual cash requirements have not changed materially since our Annual Report on Form 10-K for the fiscal year ended July 1, 2022, except for the purchase obligations, long-term debt obligations, restructuring and BIS settlement penalty.

[0001137789-23-000029:mdna:91]
[same as prior period, unchanged from 0001137789-23-000010:mdna:85]

[0001137789-23-000029:mdna:92]
Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. From time to time, we enter into long-term, non-cancelable purchase commitments or make large up-front investments with certain suppliers in order to secure certain components or technologies for the production of our products or to supplement our internal manufacturing capacity for certain components. As of March 31, 2023, we had unconditional purchase obligations of approximately $4.1 billion primarily related to purchases of inventory components with our suppliers. We expect $1.6 billion of these short-term commitments to be paid within one year and expect $2.5 billion of these long-term commitments to be paid thereafter.

[0001137789-23-000029:mdna:93]
During the nine months ended March 31, 2023, we recorded order cancellation fees of $108 million to terminate certain purchase commitments related to the purchase of inventory components and equipment, of which $68 million remained unpaid as of March 31, 2023. We expect these remaining amounts to be paid within one year.

[0001137789-23-000029:mdna:94]
[same as prior period, unchanged from 0001137789-23-000010:mdna:89]

[0001137789-23-000029:mdna:95]
On August 18, 2022, we amended our credit agreement and borrowed a new Term Loan A3 in the aggregate principal amount of $600 million. Term Loan A3 bears interest at a rate of SOFR plus a variable margin of 1.25% to 2.5%, in each case with such margin being determined based on the corporate credit rating of the Borrower or one of its parent entities. Term Loan A3 is repayable in quarterly installments and is scheduled to mature on July 30, 2027.

[0001137789-23-000029:mdna:96]
On November 30, 2022, we completed an exchange offer in which $964 million principal amount in aggregate of the July 2029 Notes, January 2031 Notes and July 2031 Notes were exchanged for $750 million principal amount of 9.625% Senior Notes due on December 1, 2032. The exchange was accounted for as a debt extinguishment and resulted in a net gain of $204 million for the nine months ended March 31, 2023.

[0001137789-23-000029:mdna:97]
During the March 2023 quarter, $20 million principal amount of the January 2031 Notes, $5 million principal amount of the June 2029 Notes and $5 million principal amount of the July 2031 Notes were repurchased for cash at a discount to their principal amounts, plus accrued and unpaid interest. We recorded a gain of $3 million on these repurchases during the March

[0001137789-23-000029:mdna:98]
2023 quarter.

[0001137789-23-000029:mdna:99]
As of March 31, 2023, the future principal payment obligation on our long-term debt was $6.0 billion, of which $1.1 billion will mature within one year. As of March 31, 2023, future interest payments on this outstanding debt is estimated to be approximately $1.8 billion, of which $316 million is expected to be paid within one year. From time to time, we may repurchase any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 1. Financial Statements—Note 3. Debt” for more details.

[0001137789-23-000029:mdna:100]
BIS settlement penalty

[0001137789-23-000029:mdna:101]
We accrued a settlement penalty of $300 million for the March 2023 quarter, related to BIS’ allegations of violations of the U.S. EAR, which were subsequently resolved by the Settlement Agreement in April 2023. As part of the Settlement Agreement with BIS, quarterly payments of $15 million will be made over the course of five years beginning October 31, 2023, of which $30 million is expected to be paid within one year and $270 million thereafter. Refer to “Item 1. Financial Statements—Note 12. Legal, Environmental and Other Contingencies” for more details.

[0001137789-23-000029:mdna:102]
[same as prior period, unchanged from 0001137789-23-000010:mdna:93]

[0001137789-23-000029:mdna:103]
On October 24, 2022, we committed to an October 2022 plan to reduce our cost structure to better align our operational needs to current economic conditions while continuing to support the long-term business strategy. On March 29, 2023, in light of further deteriorating economic conditions, we committed to an expansion of the October 2022 Plan to further reduce the global headcount by approximately 480 employees to a total reduction of approximately 3,480 employees. The expanded plan includes aligning our business plan to near-term market conditions, along with other cost saving measures. The October 2022 Plan is expected to be substantially completed by the end of the fiscal year 2023. During the nine months ended March 31, 2023, we recorded restructuring and other, net of $110 million, primarily related to the workforce reduction costs under the October 2022 plan, and made cash payments of $88 million for all active restructuring plans.

[0001137789-23-000029:mdna:104]
As of March 31, 2023, the future cash payments related to our remaining active restructuring plans were $38 million, of which $35 million is expected to be paid within one year.

[0001137789-23-000029:mdna:105]
[same as prior period, unchanged from 0001137789-23-000010:mdna:96]

[0001137789-23-000029:mdna:106]
During the March 2023 quarter, our Board of Directors declared dividends of $0.70 per share, totaling $145 million, which was paid on April 6, 2023. On April 20, 2023, our Board of Directors declared a quarterly cash dividend of $0.70 per share, payable on July 5, 2023 to shareholders of record at the close of business on June 21, 2023. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-23-000029:mdna:107]
[same as prior period, unchanged from 0001137789-23-000010:mdna:98]

[0001137789-23-000029:mdna:108]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker-assisted purchases, tender offers, or other means, including through the use of derivative transactions. As of March 31, 2023, $1.9 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-23-000029:mdna:109]
[same as prior period, unchanged from 0001137789-23-000010:mdna:100]

[0001137789-23-000029:mdna:110]
For fiscal year 2023, we expect capital expenditures to be at the low-end of our long-term targeted range of 4% to 6% of revenue. We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-23-000029:mdna:111]
Subsequent event

[0001137789-23-000029:mdna:112]
On April 20, 2023, we committed to the April 2023 restructuring plan to further reduce our cost structure in response to changes in macroeconomic and business conditions. The April 2023 Plan is intended to align our operational needs with the near-term demand environment while continuing to support the long-term business strategy. The April 2023 Plan is expected to be substantially completed by the end of the fiscal year 2023, with estimated total pre-tax charges of approximately $150 million. These charges are expected to be primarily cash-based and consist of employee severance and other one-time termination benefits.

[0001137789-23-000029:mdna:113]
38

[0001137789-23-000029:mdna:114]
[same as prior period, unchanged from 0001137789-23-000010:mdna:102]

[0001137789-23-000029:mdna:115]
[same as prior period, unchanged from 0001137789-23-000010:mdna:103]

[0001137789-23-000029:mdna:116]
[same as prior period, unchanged from 0001137789-23-000010:mdna:104]

[0001137789-23-000029:mdna:117]
[same as prior period, unchanged from 0001137789-23-000010:mdna:105]

[0001137789-23-000029:mdna:118]
[same as prior period, unchanged from 0001137789-23-000010:mdna:106]
