# STX notes — 0001137789-20-000117


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001137789-20-000117:notes:1]
[same as prior period, unchanged from 0001137789-20-000035:notes:1]

[0001137789-20-000117:notes:2]
[same as prior period, unchanged from 0001137789-20-000035:notes:2]

[0001137789-20-000117:notes:3]
HDDs are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. HDDs continue to be the primary medium of mass data storage due to their performance attributes, reliability, high quality and cost effectiveness. Complementing existing storage architectures, SSDs use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory. In contrast to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high-capacity HDD and a smaller SSD acting as a cache to improve performance of frequently accessed data.

[0001137789-20-000117:notes:4]
The Company’s HDD products are designed for mass capacity storage and legacy markets. Mass capacity storage supports high capacity, low-cost per terabyte storage applications, including nearline, video and image applications and network-attached storage. Legacy markets include mission critical, desktop, notebook, consumer, digital video recorders and gaming applications. These markets were previously categorized as enterprise servers and storage systems, edge non-compute applications and edge compute applications. The Company’s HDD and SSD product portfolio includes Serial Advanced Technology Attachment, Serial Attached SCSI and Non-Volatile Memory Express based designs to support a wide variety of mass capacity and legacy applications.

[0001137789-20-000117:notes:5]
The Company’s enterprise data solutions portfolio includes storage subsystems and mass capacity optimized private cloud storage solutions for enterprises and cloud and managed service providers. Engineered for modularity, mobility, mass capacity and performance, these solutions include the Company’s enterprise HDDs and SSDs, enabling customers to integrate powerful, scalable storage within legacy enterprise IT environments or build new on premises private storage clouds from the ground up in a secure, cost-effective manner.

[0001137789-20-000117:notes:6]
[same as prior period, unchanged from 0001137789-20-000035:notes:6]

[0001137789-20-000117:notes:7]
[same as prior period, unchanged from 0001137789-20-000035:notes:7]

[0001137789-20-000117:notes:8]
The preparation of financial statements in accordance with the United States (“U.S.”) generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. These estimates and assumptions include the impact of the COVID-19 pandemic. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements.

[0001137789-20-000117:notes:9]
The Company’s consolidated financial statements for the fiscal year ended July 3, 2020 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 7, 2020. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 3, 2020, and the notes thereto, are adequate to make the information presented not misleading.

[0001137789-20-000117:notes:10]
[same as prior period, unchanged from 0001137789-20-000035:notes:10]

[0001137789-20-000117:notes:11]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three months ended October 2, 2020 consisted of 13 weeks and the three months ended October 4, 2019 consisted of 14 weeks. Fiscal year 2021, which ends on July 2, 2021, is comprised of 52 weeks and fiscal year 2020, which ended on July 3, 2020, was comprised of 53 weeks. The fiscal quarters ended October 2, 2020, July 3, 2020 and October 4, 2019, are also referred to herein as the “September 2020 quarter”, the “June 2020 quarter” and the “September 2019 quarter”, respectively. The results of operations for the three months ended October 2, 2020 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending July 2, 2021.

[0001137789-20-000117:notes:12]
[same as prior period, unchanged from 0001137789-20-000035:notes:12]

[0001137789-20-000117:notes:13]
There have been no material changes to the Company’s significant accounting policies disclosed in Note 1. Basis of Presentation and Summary of Significant Accounting Policies of “Financial Statements and Supplementary Data” contained in Part II, Item 8. of the Company’s Annual Report on Form 10-K for the fiscal year ended July 3, 2020, as filed with the SEC on August 7, 2020.

[0001137789-20-000117:notes:14]
Recently Adopted Accounting Pronouncements

[0001137789-20-000117:notes:15]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13 (ASC Topic 326), Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held to include future conditions in its estimate of expected credit losses. The Company adopted this new accounting pronouncement in the September 2020 quarter. The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.

[0001137789-20-000117:notes:16]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles—Goodwill and Other - Internal-Use Software—Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company adopted this new accounting pronouncement in the September 2020 quarter. The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.

[0001137789-20-000117:notes:17]
Recently Issued Accounting Pronouncements

[0001137789-20-000117:notes:18]
In December 2019, the FASB issued ASU 2019-12 (ASC Topic 740), Simplifying the Accounting for Income Taxes. This ASU simplifies accounting for income taxes by removing certain exceptions to the general principles and amending existing guidance to improve consistent application. The Company is required to adopt this new accounting pronouncement in the first quarter of fiscal year 2022. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001137789-20-000117:notes:19]
In March 2020, the FASB issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. generally accepted accounting principles to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. Adoption of the expedients and exceptions is permitted upon issuance of this update through December 31, 2022. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001137789-20-000117:notes:20]
Available-for-sale Debt Securities

[0001137789-20-000117:notes:21]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of October 2, 2020:

[0001137789-20-000117:notes:22]
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 418 |  |  | $ | — |  |  | $ | 418 |  |
| Time deposits and certificates of deposit |  | 62 |  |  | — |  |  | 62 |  |
| Other debt securities |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 498 |  |  | $ | — |  |  | $ | 498 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 475 |  |
| Included in Other current assets |  |  |  |  |  | 5 |  |
| Included in Other assets, net |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 498 |  |

[0001137789-20-000117:notes:23]
As of October 2, 2020, the Company’s Other current assets included $2 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001137789-20-000117:notes:24]
As of October 2, 2020, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no impairment related to credit losses for available-for-sale debt securities as of October 2, 2020.

[0001137789-20-000117:notes:25]
The fair value and amortized cost of the Company’s investments classified as available-for-sale debt securities as of October 2, 2020, by remaining contractual maturity were as follows:

[0001137789-20-000117:notes:26]
| (Dollars in millions) |  | Amortized Cost |  | Fair Value |
| Due in less than 1 year |  | $ | 480 |  |  | $ | 480 |  |
| Due in 1 to 5 years |  | 10 |  |  | 10 |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | 8 |  |  | 8 |  |
| Total |  | $ | 498 |  |  | $ | 498 |  |

[0001137789-20-000117:notes:27]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of July 3, 2020:

[0001137789-20-000117:notes:28]
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 495 |  |  | $ | — |  |  | $ | 495 |  |
| Time deposits and certificates of deposit |  | 56 |  |  | — |  |  | 56 |  |
| Other debt securities |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 569 |  |  | $ | — |  |  | $ | 569 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 549 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 569 |  |

[0001137789-20-000117:notes:29]
As of July 3, 2020, the Company’s Other current assets included $2 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001137789-20-000117:notes:30]
As of July 3, 2020, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale debt securities were other-than-temporarily impaired as of July 3, 2020.

[0001137789-20-000117:notes:31]
[same as prior period, unchanged from 0001137789-20-000035:notes:40]

[0001137789-20-000117:notes:32]
The following table provides a summary of cash, cash equivalents and restricted cash reported within the Condensed Consolidated Balance Sheets that reconciles to the corresponding amount in the Condensed Consolidated Statements of Cash Flows:

[0001137789-20-000117:notes:33]
| (Dollars in millions) |  | October 2,2020 |  |  |  | July 3,2020 |  | October 4,2019 |  |  |  | June 28,2019 |
| Cash and cash equivalents |  | $ | 1,664 |  |  |  |  | $ | 1,722 |  |  | $ | 1,784 |  |  |  |  | $ | 2,220 |  |
| Restricted cash included in Other current assets |  | 2 |  |  |  |  | 2 |  |  | 2 |  |  |  |  | 31 |  |
| Total cash, cash equivalents and restricted cash presented in the Statements of Cash Flows |  | $ | 1,666 |  |  |  |  | $ | 1,724 |  |  | $ | 1,786 |  |  |  |  | $ | 2,251 |  |

[0001137789-20-000117:notes:34]
[same as prior period, unchanged from 0001137789-20-000035:notes:43]

[0001137789-20-000117:notes:35]
[same as prior period, unchanged from 0001137789-20-000035:notes:44]

[0001137789-20-000117:notes:36]
In connection with an existing factoring agreement, the Company sells trade receivables to a third party for cash proceeds less a discount. During the three months ended October 2, 2020, the Company sold trade receivables without recourse for cash proceeds of $148 million, all of which remained subject to servicing by the Company as of October 2, 2020. The discounts on receivables sold were not material for the three months ended October 2, 2020.

[0001137789-20-000117:notes:37]
[same as prior period, unchanged from 0001137789-20-000035:notes:46]

[0001137789-20-000117:notes:38]
[same as prior period, unchanged from 0001137789-20-000035:notes:47]

[0001137789-20-000117:notes:39]
| (Dollars in millions) |  | October 2,2020 |  | July 3,2020 |
| Raw materials and components |  | $ | 536 |  |  | $ | 451 |  |
| Work-in-process |  | 365 |  |  | 313 |  |
| Finished goods |  | 422 |  |  | 378 |  |
| Total inventories |  | $ | 1,323 |  |  | $ | 1,142 |  |

[0001137789-20-000117:notes:40]
[same as prior period, unchanged from 0001137789-20-000035:notes:49]

[0001137789-20-000117:notes:41]
[same as prior period, unchanged from 0001137789-20-000035:notes:50]

[0001137789-20-000117:notes:42]
| (Dollars in millions) |  | October 2,2020 |  | July 3,2020 |
| Property, equipment and leasehold improvements |  | $ | 10,280 |  |  | $ | 10,212 |  |
| Accumulated depreciation and amortization |  | (8,113) |  |  | (8,083) |  |
| Property, equipment and leasehold improvements, net |  | $ | 2,167 |  |  | $ | 2,129 |  |

[0001137789-20-000117:notes:43]
[same as prior period, unchanged from 0001137789-20-000035:notes:52]

[0001137789-20-000117:notes:44]
[same as prior period, unchanged from 0001137789-20-000035:notes:53]

[0001137789-20-000117:notes:45]
| (Dollars in millions) |  | October 2,2020 |  | July 3,2020 |
| Dividends payable |  | $ | 167 |  |  | $ | 167 |  |
| Other accrued expenses |  | 436 |  |  | 435 |  |
| Total |  | $ | 603 |  |  | $ | 602 |  |

[0001137789-20-000117:notes:46]
Accumulated Other Comprehensive Loss (“AOCL”)

[0001137789-20-000117:notes:47]
The components of AOCL, net of tax, were as follows:

[0001137789-20-000117:notes:48]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  |  |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at July 3, 2020 |  | $ | (24) |  |  |  |  | $ | (26) |  |  | $ | (16) |  |  | $ | (66) |  |
| Other comprehensive income before reclassifications |  | 4 |  |  |  |  | — |  |  | — |  |  | 4 |  |
| Amounts reclassified from AOCL |  | — |  |  |  |  | 1 |  |  | 15 |  |  | 16 |  |
| Other comprehensive income |  | 4 |  |  |  |  | 1 |  |  | 15 |  |  | 20 |  |
| Balance at October 2, 2020 |  | $ | (20) |  |  |  |  | $ | (25) |  |  | $ | (1) |  |  | $ | (46) |  |
| Balance at June 28, 2019 |  | $ | — |  |  |  |  | $ | (20) |  |  | $ | (14) |  |  | $ | (34) |  |
| Other comprehensive loss before reclassifications |  | (1) |  |  |  |  | — |  |  | (5) |  |  | (6) |  |
| Amounts reclassified from AOCL |  | — |  |  |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive loss |  | (1) |  |  |  |  | — |  |  | (5) |  |  | (6) |  |
| Balance at October 4, 2019 |  | $ | (1) |  |  |  |  | $ | (20) |  |  | $ | (19) |  |  | $ | (40) |  |


## us-gaap:DebtDisclosureTextBlock

[0001137789-20-000117:notes:49]
Credit Agreement

[0001137789-20-000117:notes:50]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement (the “Credit Agreement”) on February 20, 2019, which was most recently amended on September 16, 2019. The Credit Agreement provides an up to $1.5 billion senior unsecured revolving credit facility (“Revolving Credit Facility”) and a term loan facility in an aggregate principal amount of $500 million (“Term Loan”). The Revolving Credit Facility has a final maturity of February 20, 2024 and the Term Loan has a final maturity date of September 16, 2025. The loans made under the Revolving Credit Facility and the Term Loan will bear interest at a rate of the London Interbank Offered Rate (“LIBOR”) plus a variable margin for each facility that will be determined based on the corporate credit rating of the Company. STX and certain of its material subsidiaries fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loan. The Revolving Credit Facility also allows such facility to increase by an additional $100 million, provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at least $25 million, and (iii) the existing commitments under such facility receive 0.50% most favored nation protection. An aggregate amount of up to $75 million of the Revolving Credit Facility is available for the issuance of letters of credit, and an aggregate amount of up to $50 million of such facility is also available for swing line loans.

[0001137789-20-000117:notes:51]
On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the Term Loan and the proceeds were used to repurchase a portion of its outstanding senior notes. The Term Loan is repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with the remaining balance payable upon maturity.

[0001137789-20-000117:notes:52]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of October 2, 2020 and expects to be in compliance for the next 12 months.

[0001137789-20-000117:notes:53]
As of October 2, 2020, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the Revolving Credit Facility.

[0001137789-20-000117:notes:54]
Other Long-Term Debt

[0001137789-20-000117:notes:55]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March, 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the three months ended October 2, 2020, $9 million aggregate principal amount of the 2022 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. During the three months ended October 4, 2019, $250 million aggregate principal amount was repurchased pursuant to cash tender offers for certain senior notes (“the Tender Offers”). The Company recorded an immaterial loss and a loss of $10 million, respectively, on repurchases during the three months ended October 2, 2020 and October 4, 2019, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

[0001137789-20-000117:notes:56]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June, 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the three months ended October 2, 2020, $5 million aggregate principal amount of the 2023 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest, of which $2 million remained unsettled as of October 2, 2020. During the three months ended October 4, 2019, $200 million aggregate principal amount was repurchased pursuant to the Tender Offers. The Company recorded a loss of $1 million and $10 million, respectively, on repurchases during the three months ended October 2, 2020 and October 4, 2019, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

[0001137789-20-000117:notes:57]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March, 2024 (the “2024 Notes”). The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

[0001137789-20-000117:notes:58]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January, 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the three months ended October 4, 2019, $170 million aggregate principal amount was repurchased pursuant to the Tender Offers. The Company recorded a loss of $8 million on repurchases during the three months ended October 4, 2019, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

[0001137789-20-000117:notes:59]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June, 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

[0001137789-20-000117:notes:60]
$500 million Aggregate Principal Amount of 4.091% Senior Notes due June, 2029 (the “2029 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2029 Notes is Seagate HDD Cayman, and the obligations under the 2029 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

[0001137789-20-000117:notes:61]
$500 million Aggregate Principal Amount of 4.125% Senior Notes due January, 2031 (the “2031 Notes”). The interest on the Notes is payable semi-annually on January 15 and July 15 of each year. The issuer under the 2031 Notes is Seagate HDD Cayman, and the obligations under the 2031 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

[0001137789-20-000117:notes:62]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December, 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

[0001137789-20-000117:notes:63]
At October 2, 2020, future principal payments on long-term debt were as follows (in millions):

[0001137789-20-000117:notes:64]
| Fiscal Year |  | Amount |
| Remainder of 2021 |  | $ | 19 |  |
| 2022 |  | 245 |  |
| 2023 |  | 566 |  |
| 2024 |  | 525 |  |
| 2025 |  | 504 |  |
| Thereafter |  | 2,376 |  |
| Total |  | $ | 4,235 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001137789-20-000117:notes:65]
Income Taxes
The Company’s income tax benefit of $2 million for the three months ended October 2, 2020 included approximately $10 million of net discrete tax benefit of which $4 million was associated with net excess tax benefits related to share-based compensation expense and $3 million was associated with the postponement of the previously enacted United Kingdom (“U.K.”) tax rate change in the September 2020 quarter.

[0001137789-20-000117:notes:66]
The Company’s income tax provision recorded for the three months ended October 2, 2020 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-20-000117:notes:67]
During the three months ended October 2, 2020, the Company had approximately $89 million of unrecognized tax benefits excluding interest and penalties, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. During the twelve months beginning October 3, 2020, the Company expects that its unrecognized tax benefits could be reduced by an immaterial amount, as a result of the expiration of certain statutes of limitation.

[0001137789-20-000117:notes:68]
The Company’s income tax benefit of $2 million for the three months ended October 4, 2019 included approximately $11 million of net discrete tax benefit of which $8 million was associated with net excess tax benefits related to share-based compensation expense.

[0001137789-20-000117:notes:69]
The Company’s income tax provision recorded for the three months ended October 4, 2019 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001137789-20-000117:notes:70]
[same as prior period, unchanged from 0001137789-20-000035:notes:78]

[0001137789-20-000117:notes:71]
[same as prior period, unchanged from 0001137789-20-000035:notes:79]

[0001137789-20-000117:notes:72]
[same as prior period, unchanged from 0001137789-20-000035:notes:80]

[0001137789-20-000117:notes:73]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 2,2020 |  | October 4,2019 |
| Operating lease cost |  | $ | 3 |  |  | $ | 6 |  |
| Variable lease cost |  | 1 |  |  | 1 |  |
| Total lease cost |  | $ | 4 |  |  | $ | 7 |  |
| Operating cash outflows from operating leases |  | $ | 4 |  |  | $ | 4 |  |

[0001137789-20-000117:notes:74]
|  |  | October 2,2020 |  | July 3,2020 |
| Weighted-average remaining lease term |  | 13.1 years |  | 13.2 years |
| Weighted-average discount rate |  | 6.46 | % |  | 6.53 | % |

[0001137789-20-000117:notes:75]
Right-of-use (“ROU”) assets and lease liabilities are included on the Company’s Condensed Consolidated Balance Sheet as follows:

[0001137789-20-000117:notes:76]
| (Dollars in millions) |  | Balance Sheet Location |  | October 2,2020 |  | July 3,2020 |
| ROU assets |  | Other assets, net |  | $ | 103 |  |  | $ | 103 |  |
| Current lease liabilities |  | Accrued expenses |  | $ | 16 |  |  | $ | 14 |  |
| Non-current lease liabilities |  | Other non-current liabilities |  | $ | 49 |  |  | $ | 49 |  |

[0001137789-20-000117:notes:77]
At October 2, 2020, future lease payments included in the measurement of lease liabilities were as follows (in millions):

[0001137789-20-000117:notes:78]
| Fiscal Year |  | Amount |
| Remainder of 2021 |  | $ | 12 |  |
| 2022 |  | 15 |  |
| 2023 |  | 10 |  |
| 2024 |  | 6 |  |
| 2025 |  | 4 |  |
| Thereafter |  | 103 |  |
| Total lease payments |  | 150 |  |
| Less: imputed interest |  | (85) |  |
| Present value of lease liabilities |  | $ | 65 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001137789-20-000117:notes:79]
The Company recorded restructuring charges of $1 million for the three months ended October 2, 2020, and $17 million for the three months ended October 4, 2019. The Company’s restructuring plans are comprised primarily of charges related to workforce reduction costs and facilities and other exit costs. All restructuring charges are reported in Restructuring and other, net on the Company’s Condensed Consolidated Statements of Operations.

[0001137789-20-000117:notes:80]
June 2020 Plan - On June 1, 2020, the Company committed to a restructuring plan (the “June 2020 Plan”) consistent with its long-term strategy to drive operational efficiencies, reduce its cost structure and invest in future opportunities. The June 2020 Plan included consolidating the Company’s Minnesota facilities into one location and reducing its headcount worldwide by approximately 500 employees. The June 2020 Plan was substantially completed during the September 2020 quarter.

[0001137789-20-000117:notes:81]
The following tables summarize the Company’s restructuring activities under all of the Company’s restructuring plans:

[0001137789-20-000117:notes:82]
|  |  | June 2020 Plan |  | Other Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at July 3, 2020 |  | $ | 38 |  |  | $ | 2 |  |  | $ | 5 |  |  | $ | 3 |  |  | $ | 48 |  |
| Restructuring charges |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Cash payments |  | (35) |  |  | (1) |  |  | (3) |  |  | — |  |  | (39) |  |
| Adjustments |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Accrual balances at October 2, 2020 |  | $ | 3 |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | 3 |  |  | $ | 10 |  |
| Total costs incurred to date as of October 2, 2020 |  | $ | 56 |  |  | $ | 2 |  |  | $ | 17 |  |  | $ | 28 |  |  | $ | 103 |  |
| Total expected charges to be incurred as of October 2, 2020 |  | $ | — |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  | $ | 7 |  |

[0001137789-20-000117:notes:83]
|  |  | Restructuring Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at June 28, 2019 |  | $ | 13 |  |  | $ | 17 |  |  | $ | 30 |  |
| Lease adoption adjustment |  | — |  |  | (11) |  |  | (11) |  |
| Restructuring charges |  | 17 |  |  | — |  |  | 17 |  |
| Cash payments |  | (13) |  |  | (1) |  |  | (14) |  |
| Adjustments |  | — |  |  | — |  |  | — |  |
| Accrual balances at October 4, 2019 |  | $ | 17 |  |  | $ | 5 |  |  | $ | 22 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001137789-20-000117:notes:84]
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies.

[0001137789-20-000117:notes:85]
In the quarter ended October 4, 2019, the Company entered into certain interest rate swap agreements with a notional amount of $500 million to convert the variable interest rate on its Term Loan to fixed interest rates. The contracts will mature on September 16, 2025. The objective of the interest rate swap agreements is to eliminate the variability of interest payment cash flows associated with the variable interest rate under the Term Loan. The Company designated the interest rate swaps as cash flow hedges.

[0001137789-20-000117:notes:86]
The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives on its Condensed Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The amount of net unrealized loss on cash flow hedges was $21 million and $24 million as of October 2, 2020 and as of July 3, 2020, respectively. As of October 2, 2020, the amount of existing net losses related to cash flow hedges recorded in Accumulated other comprehensive loss included $2 million that is expected to be reclassified to earnings within twelve months.

[0001137789-20-000117:notes:87]
The Company de-designates its cash flow hedges when the forecasted hedged transactions affect earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss on the Company’s Condensed Consolidated Balance Sheets are reclassified into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company did not recognize any material amounts related to the loss of hedge designation on discontinued cash flow hedges during the three months ended October 2, 2020 and October 4, 2019.

[0001137789-20-000117:notes:88]
[same as prior period, unchanged from 0001137789-20-000035:notes:93]

[0001137789-20-000117:notes:89]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of October 2, 2020 and July 3, 2020. All of the foreign currency forward exchange contracts mature within 12 months.

[0001137789-20-000117:notes:90]
|  |  | As of October 2, 2020 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Singapore Dollar |  | $ | 175 |  |  | $ | 48 |  |
| Thai Baht |  | 130 |  |  | 41 |  |
| Chinese Renminbi |  | 66 |  |  | 23 |  |
| British Pound Sterling |  | 58 |  |  | 17 |  |
|  |  | $ | 429 |  |  | $ | 129 |  |

[0001137789-20-000117:notes:91]
|  |  | As of July 3, 2020 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Singapore Dollar |  | $ | 187 |  |  | $ | 56 |  |
| Thai Baht |  | 157 |  |  | 42 |  |
| Chinese Renminbi |  | 81 |  |  | 25 |  |
| British Pound Sterling |  | 64 |  |  | 20 |  |
|  |  | $ | 489 |  |  | $ | 143 |  |

[0001137789-20-000117:notes:92]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its non-qualified deferred compensation plan: the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP’s liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP’s liabilities due to changes in the value of the investment options made by employees. As of October 2, 2020, the notional investments underlying the TRS amounted to $110 million. The contract term of the TRS is through January 2021 and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP’s liabilities.

[0001137789-20-000117:notes:93]
The following tables show the Company’s derivative instruments measured at gross fair value as reflected in the Condensed Consolidated Balance Sheets as of October 2, 2020 and July 3, 2020:

[0001137789-20-000117:notes:94]
|  |  | As of October 2, 2020 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance Sheet Location |  | Fair Value |  | Balance Sheet Location |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 7 |  |  | Accrued expenses |  | $ | (1) |  |
| Interest rate swap |  | Other current assets |  | — |  |  | Accrued expenses |  | (27) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 2 |  |  | Accrued expenses |  | — |  |
| Total return swap |  | Other current assets |  | 1 |  |  | Accrued expenses |  | (2) |  |
| Total derivatives |  |  |  | $ | 10 |  |  |  |  | $ | (30) |  |

[0001137789-20-000117:notes:95]
|  |  | As of July 3, 2020 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance Sheet Location |  | Fair Value |  | Balance Sheet Location |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 3 |  |  | Accrued expenses |  | $ | — |  |
| Interest rate swap |  | Other current assets |  | — |  |  | Accrued expenses |  | (27) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 2 |  |  | Accrued expenses |  | (2) |  |
| Total return swap |  | Other current assets |  | 1 |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 6 |  |  |  |  | $ | (29) |  |

[0001137789-20-000117:notes:96]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three months ended October 2, 2020:

[0001137789-20-000117:notes:97]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |  |  |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 6 |  |  |  |
| Total return swap |  | Operating expenses |  | 5 |  |  |  |

[0001137789-20-000117:notes:98]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  |  |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  |  |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  |  |
| Foreign currency forward exchange contracts |  | $ | 4 |  |  |  |  | Other expense, net |  | $ | 2 |  |  |  |  | Other expense, net |  | $ | — |  |  |  |
| Interest rate swap |  | — |  |  |  |  | Other expense, net |  | (2) |  |  |  |  | Other expense, net |  | — |  |  |  |

[0001137789-20-000117:notes:99]
The following table shows the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three months ended October 4, 2019:

[0001137789-20-000117:notes:100]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |  |  |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 3 |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001137789-20-000117:notes:101]
[same as prior period, unchanged from 0001137789-20-000035:notes:107]

[0001137789-20-000117:notes:102]
[same as prior period, unchanged from 0001137789-20-000035:notes:108]

[0001137789-20-000117:notes:103]
[same as prior period, unchanged from 0001137789-20-000035:notes:109]

[0001137789-20-000117:notes:104]
[same as prior period, unchanged from 0001137789-20-000035:notes:110]

[0001137789-20-000117:notes:105]
[same as prior period, unchanged from 0001137789-20-000035:notes:111]

[0001137789-20-000117:notes:106]
[same as prior period, unchanged from 0001137789-20-000035:notes:112]

[0001137789-20-000117:notes:107]
[same as prior period, unchanged from 0001137789-20-000035:notes:113]

[0001137789-20-000117:notes:108]
[same as prior period, unchanged from 0001137789-20-000035:notes:114]

[0001137789-20-000117:notes:109]
[same as prior period, unchanged from 0001137789-20-000035:notes:115]

[0001137789-20-000117:notes:110]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item, that are measured at fair value on a recurring basis, excluding accrued interest components, as of October 2, 2020:

[0001137789-20-000117:notes:111]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 417 |  |  | $ | — |  |  | $ | — |  |  | $ | 417 |  |
| Time deposits and certificates of deposit |  | — |  |  | 58 |  |  | — |  |  | 58 |  |
| Total cash equivalents |  | 417 |  |  | 58 |  |  | — |  |  | 475 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Other debt securities |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Derivative assets |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Total assets |  | $ | 418 |  |  | $ | 72 |  |  | $ | 18 |  |  | $ | 508 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 30 |  |  | $ | — |  |  | $ | 30 |  |
| Total liabilities |  | $ | — |  |  | $ | 30 |  |  | $ | — |  |  | $ | 30 |  |

[0001137789-20-000117:notes:112]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 417 |  |  | $ | 58 |  |  | $ | — |  |  | $ | 475 |  |
| Other current assets |  | 1 |  |  | 14 |  |  | — |  |  | 15 |  |
| Other assets, net |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Total assets |  | $ | 418 |  |  | $ | 72 |  |  | $ | 18 |  |  | $ | 508 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | 30 |  |  | $ | — |  |  | $ | 30 |  |
| Total liabilities |  | $ | — |  |  | $ | 30 |  |  | $ | — |  |  | $ | 30 |  |

[0001137789-20-000117:notes:113]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item, that are measured at fair value on a recurring basis, excluding accrued interest components, as of July 3, 2020:

[0001137789-20-000117:notes:114]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 494 |  |  | $ | — |  |  | $ | — |  |  | $ | 494 |  |
| Time deposits and certificates of deposit |  | — |  |  | 55 |  |  | — |  |  | 55 |  |
| Total cash equivalents |  | 494 |  |  | 55 |  |  | — |  |  | 549 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Derivative assets |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total assets |  | $ | 495 |  |  | $ | 62 |  |  | $ | 18 |  |  | $ | 575 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |
| Total liabilities |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |

[0001137789-20-000117:notes:115]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 494 |  |  | $ | 55 |  |  | $ | — |  |  | $ | 549 |  |
| Other current assets |  | 1 |  |  | 7 |  |  | — |  |  | 8 |  |
| Other assets, net |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Total assets |  | $ | 495 |  |  | $ | 62 |  |  | $ | 18 |  |  | $ | 575 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |
| Total liabilities |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |

[0001137789-20-000117:notes:116]
[same as prior period, unchanged from 0001137789-20-000035:notes:122]

[0001137789-20-000117:notes:117]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair value of all of its cash equivalents. For the cash equivalents in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry-standard data providers or other third-party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of October 2, 2020, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts, interest rate swaps and the TRS. The Company recognizes derivative financial instruments in its condensed consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001137789-20-000117:notes:118]
[same as prior period, unchanged from 0001137789-20-000035:notes:124]

[0001137789-20-000117:notes:119]
[same as prior period, unchanged from 0001137789-20-000035:notes:125]

[0001137789-20-000117:notes:120]
As of October 2, 2020 and July 3, 2020, the carrying value of the Company’s strategic investments was $157 million and $135 million, respectively. The Company’s strategic investments are recorded at fair value only if an impairment or observable price change is recognized in the current period. If an observable price change or impairment is recognized on the Company’s strategic investments during the period, the Company classifies these assets as Level 3 within the fair value hierarchy based on the nature of the fair value inputs. For the three months ended October 2, 2020, the Company recorded an upward adjustment of  $23 million due to an observable price change of a strategic investment, which is included in Other, net in the Company’s Condensed Consolidated Statement of Operations. For the three months ended October 4, 2019, there were no upward or downward adjustments for equity investments.

[0001137789-20-000117:notes:121]
[same as prior period, unchanged from 0001137789-20-000035:notes:128]

[0001137789-20-000117:notes:122]
The Company’s debt is carried at amortized cost. The estimated fair value of the Company’s debt is derived using the closing price of the same debt instruments as of the date of valuation, which takes into account the yield curve, interest rates and other observable inputs. Accordingly, these fair value measurements are categorized as Level 2. The following table presents the fair value and amortized cost of the Company’s debt in order of maturity:

[0001137789-20-000117:notes:123]
|  |  | October 2, 2020 |  | July 3, 2020 |
| (Dollars in millions) |  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 4.250% Senior Notes due March 2022 |  | $ | 220 |  |  | $ | 229 |  |  | $ | 229 |  |  | $ | 237 |  |
| 4.750% Senior Notes due June 2023 |  | 540 |  |  | 587 |  |  | 546 |  |  | 576 |  |
| 4.875% Senior Notes due March 2024 |  | 499 |  |  | 546 |  |  | 498 |  |  | 541 |  |
| 4.750% Senior Notes due January 2025 |  | 479 |  |  | 527 |  |  | 479 |  |  | 517 |  |
| 4.875% Senior Notes due June 2027 |  | 504 |  |  | 565 |  |  | 504 |  |  | 549 |  |
| 4.091% Senior Notes due June 2029 |  | 458 |  |  | 541 |  |  | 456 |  |  | 523 |  |
| 4.125% Senior Notes due January 2031 |  | 499 |  |  | 542 |  |  | 499 |  |  | 524 |  |
| 5.750% Senior Notes due December 2034 |  | 489 |  |  | 558 |  |  | 489 |  |  | 543 |  |
| LIBOR Based Term Loan due September 2025 |  | 500 |  |  | 495 |  |  | 500 |  |  | 490 |  |
|  |  | 4,188 |  |  | 4,590 |  |  | 4,200 |  |  | 4,500 |  |
| Less: debt issuance costs |  | (25) |  |  | — |  |  | (25) |  |  | — |  |
| Debt, net of debt issuance costs |  | 4,163 |  |  | 4,590 |  |  | 4,175 |  |  | 4,500 |  |
| Less: current portion of debt, net of debt issuance costs |  | (25) |  |  | (25) |  |  | (19) |  |  | (19) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 4,138 |  |  | $ | 4,565 |  |  | $ | 4,156 |  |  | $ | 4,481 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001137789-20-000117:notes:124]
Share Capital

[0001137789-20-000117:notes:125]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 257,604,703 shares were outstanding as of October 2, 2020, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of October 2, 2020.

[0001137789-20-000117:notes:126]
Ordinary shares—Holders of ordinary shares are entitled to receive dividends when declared by the Board of Directors. Upon any liquidation, dissolution, or winding up, after required payments are made to holders of preferred shares, any remaining assets will be distributed ratably to holders of the preferred and ordinary shares. Holders of shares are entitled to one vote per share on all matters upon which the ordinary shares are entitled to vote, including the election of directors.

[0001137789-20-000117:notes:127]
[same as prior period, unchanged from 0001137789-20-000035:notes:134]

[0001137789-20-000117:notes:128]
[same as prior period, unchanged from 0001137789-20-000035:notes:135]

[0001137789-20-000117:notes:129]
[same as prior period, unchanged from 0001137789-20-000035:notes:136]

[0001137789-20-000117:notes:130]
[same as prior period, unchanged from 0001137789-20-000035:notes:137]

[0001137789-20-000117:notes:131]
As of October 2, 2020, $1.2 billion remained available for repurchase under the existing repurchase authorization limit.

[0001137789-20-000117:notes:132]
The following table sets forth information with respect to repurchases of ordinary shares during the three months ended October 2, 2020:

[0001137789-20-000117:notes:133]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Repurchases of ordinary shares |  | 1 |  |  | $ | 68 |  |
| Tax withholding related to vesting of equity awards |  | 1 |  |  | 31 |  |
| Total |  | 2 |  |  | $ | 99 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001137789-20-000117:notes:134]
[same as prior period, unchanged from 0001137789-20-000035:notes:141]

[0001137789-20-000117:notes:135]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | October 2,2020 |  | October 4,2019 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 1,608 |  |  | $ | 1,820 |  |  |  |  |  |
| Distributors |  | 367 |  |  | 461 |  |  |  |  |  |
| Retailers |  | 339 |  |  | 297 |  |  |  |  |  |
| Total |  | $ | 2,314 |  |  | $ | 2,578 |  |  |  |  |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,106 |  |  | $ | 1,278 |  |  |  |  |  |
| Americas |  | 805 |  |  | 835 |  |  |  |  |  |
| EMEA |  | 403 |  |  | 465 |  |  |  |  |  |
| Total |  | $ | 2,314 |  |  | $ | 2,578 |  |  |  |  |  |

[0001137789-20-000117:notes:136]
[same as prior period, unchanged from 0001137789-20-000035:notes:143]

[0001137789-20-000117:notes:137]
[same as prior period, unchanged from 0001137789-20-000035:notes:144]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001137789-20-000117:notes:138]
Indemnifications of Officers and Directors

[0001137789-20-000117:notes:139]
[same as prior period, unchanged from 0001137789-20-000035:notes:146]

[0001137789-20-000117:notes:140]
The nature of these indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay on behalf of its officers and directors. Historically, the Company has not made any significant indemnification payments under such indemnification agreements and no amount has been accrued in the Company’s condensed consolidated financial statements with respect to these indemnification obligations.

[0001137789-20-000117:notes:141]
[same as prior period, unchanged from 0001137789-20-000035:notes:148]

[0001137789-20-000117:notes:142]
[same as prior period, unchanged from 0001137789-20-000035:notes:149]

[0001137789-20-000117:notes:143]
[same as prior period, unchanged from 0001137789-20-000035:notes:150]

[0001137789-20-000117:notes:144]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the three months ended October 2, 2020 and October 4, 2019 were as follows:

[0001137789-20-000117:notes:145]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 2,2020 |  | October 4,2019 |
| Balance, beginning of period |  | $ | 151 |  |  | $ | 195 |  |
| Warranties issued |  | 18 |  |  | 24 |  |
| Repairs and replacements |  | (21) |  |  | (23) |  |
| Changes in liability for pre-existing warranties, including expirations |  | (6) |  |  | (12) |  |
| Balance, end of period |  | $ | 142 |  |  | $ | 184 |  |


## us-gaap:EarningsPerShareTextBlock

[0001137789-20-000117:notes:146]
Basic earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period. Diluted earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period and the number of additional shares that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding options, unvested restricted share units and performance-based share units and shares to be purchased under the Company’s Employee Stock Purchase Plan. The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in fair market value of the Company’s share price can result in a greater dilutive effect from potentially dilutive securities. The following table sets forth the computation of basic and diluted net income per share attributable to the shareholders of the Company:

[0001137789-20-000117:notes:147]
|  |  | For the Three Months Ended |  |  |
| (In millions, except per share data) |  | October 2,2020 |  | October 4,2019 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 223 |  |  | $ | 200 |  |  |  |  |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 257 |  |  | 266 |  |  |  |  |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | 2 |  |  | 4 |  |  |  |  |  |
| Total shares for purpose of calculating diluted net income per share |  | 259 |  |  | 270 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.87 |  |  | $ | 0.75 |  |  |  |  |  |
| Diluted |  | 0.86 |  |  | 0.74 |  |  |  |  |  |

[0001137789-20-000117:notes:148]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share were not material for the three months ended October 2, 2020 and October 4, 2019.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001137789-20-000117:notes:149]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001137789-20-000117:notes:150]
Litigation

[0001137789-20-000117:notes:151]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al. On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “‘635 patent”) and U.S. Patent No. 5,638,267 (the “‘267 patent”), misappropriation of trade secrets, breach of contract, and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants were infringing U.S. Patent No. 6,314,473 (the “‘473 patent”). The district court ruled in 2010 that the ‘267 patent was out of the case.

[0001137789-20-000117:notes:152]
On August 16, 2011, the district court granted in part and denied in part the Company’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that the Company did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by the Company because the Company’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001137789-20-000117:notes:153]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial is scheduled to begin on June 21, 2021. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.

[0001137789-20-000117:notes:154]
Seagate Technology LLC, et al. v. NHK Spring Co. Ltd. and TDK Corporation, et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology International filed a complaint in the United States District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc., and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Company had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Company paid artificially high prices on its purchases of suspension assemblies. The Company seeks to recover the overcharges it paid for suspension assemblies, as well as additional relief permitted by law.

[0001137789-20-000117:notes:155]
Environmental Matters

[0001137789-20-000117:notes:156]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001137789-20-000117:notes:157]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001137789-20-000117:notes:158]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001137789-20-000117:notes:159]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001137789-20-000117:notes:160]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the U.S., Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001137789-20-000117:notes:161]
Other Matters

[0001137789-20-000117:notes:162]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:SubsequentEventsTextBlock

[0001137789-20-000117:notes:163]
Dividend Declared

[0001137789-20-000117:notes:164]
On October 22, 2020, the Company’s Board of Directors declared a quarterly cash dividend of $0.67 per share, which will be payable on January 6, 2021 to shareholders of record as of the close of business on December 23, 2020.
