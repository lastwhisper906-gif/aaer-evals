# STX note change history — 0001137789-20-000035 → 0001137789-20-000117


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001137789-20-000117:note_history:1]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.
  (was, 2020-04-30, similarity 0.9798):
[0001137789-20-000035:note_history:1]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

- changed (2020-10-29):
[0001137789-20-000117:note_history:2]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial is scheduled to begin on June 21, 2021. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.
  (was, 2020-04-30, similarity 0.9267):
[0001137789-20-000035:note_history:2]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. A jury trial in this matter was previously scheduled to begin on June 1, 2020.  On April 20, 2020, the court scheduled the jury trial for November 30, 2020. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001137789-20-000117:note_history:3]
HDDs are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. HDDs continue to be the primary medium of mass data storage due to their performance attributes, reliability, high quality and cost effectiveness. Complementing existing storage architectures, SSDs use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory. In contrast to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high-capacity HDD and a smaller SSD acting as a cache to improve performance of frequently accessed data.
  (was, 2020-04-30, similarity 0.9419):
[0001137789-20-000035:note_history:3]
HDDs are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. HDDs continue to be the primary medium of mass data storage due to their performance attributes, reliability, high quality and cost effectiveness. Complementing existing data center storage architecture, SSDs use integrated circuit assemblies as memory to store data, and most SSDs use NAND flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a high capacity HDD and a smaller SSD acting as a cache to improve performance of frequently accessed data.

- added (2020-10-29):
[0001137789-20-000117:note_history:4]
The Company’s HDD products are designed for mass capacity storage and legacy markets. Mass capacity storage supports high capacity, low-cost per terabyte storage applications, including nearline, video and image applications and network-attached storage. Legacy markets include mission critical, desktop, notebook, consumer, digital video recorders and gaming applications. These markets were previously categorized as enterprise servers and storage systems, edge non-compute applications and edge compute applications. The Company’s HDD and SSD product portfolio includes Serial Advanced Technology Attachment, Serial Attached SCSI and Non-Volatile Memory Express based designs to support a wide variety of mass capacity and legacy applications.

- added (2020-10-29):
[0001137789-20-000117:note_history:5]
The Company’s enterprise data solutions portfolio includes storage subsystems and mass capacity optimized private cloud storage solutions for enterprises and cloud and managed service providers. Engineered for modularity, mobility, mass capacity and performance, these solutions include the Company’s enterprise HDDs and SSDs, enabling customers to integrate powerful, scalable storage within legacy enterprise IT environments or build new on premises private storage clouds from the ground up in a secure, cost-effective manner.

- added (2020-10-29):
[0001137789-20-000117:note_history:6]
The preparation of financial statements in accordance with the United States (“U.S.”) generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. These estimates and assumptions include the impact of the COVID-19 pandemic. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements.

- changed (2020-10-29):
[0001137789-20-000117:note_history:7]
The Company’s consolidated financial statements for the fiscal year ended July 3, 2020 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 7, 2020. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 3, 2020, and the notes thereto, are adequate to make the information presented not misleading.
  (was, 2020-04-30, similarity 0.9919):
[0001137789-20-000035:note_history:7]
The Company’s consolidated financial statements for the fiscal year ended June 28, 2019 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 2, 2019. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of June 28, 2019, and the notes thereto, are adequate to make the information presented not misleading.

- changed (2020-10-29):
[0001137789-20-000117:note_history:8]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three months ended October 2, 2020 consisted of 13 weeks and the three months ended October 4, 2019 consisted of 14 weeks. Fiscal year 2021, which ends on July 2, 2021, is comprised of 52 weeks and fiscal year 2020, which ended on July 3, 2020, was comprised of 53 weeks. The fiscal quarters ended October 2, 2020, July 3, 2020 and October 4, 2019, are also referred to herein as the “September 2020 quarter”, the “June 2020 quarter” and the “September 2019 quarter”, respectively. The results of operations for the three months ended October 2, 2020 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending July 2, 2021.
  (was, 2020-04-30, similarity 0.7206):
[0001137789-20-000035:note_history:8]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three and nine months ended April 3, 2020 consisted of 13 weeks and 40 weeks, respectively, and the three and nine months ended March 29, 2019 consisted of 13 weeks and 39 weeks, respectively. Fiscal year 2020, which ends on July 3, 2020, is comprised of 53 weeks and fiscal year 2019, which ended on June 28, 2019, was comprised of 52 weeks. The fiscal quarters ended April 3, 2020, January 3, 2020 and March 29, 2019, are also referred to herein as the “March 2020 quarter”, the “December 2019 quarter” and the “March 2019 quarter”, respectively. The results of operations for the three and nine months ended April 3, 2020 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending July 3, 2020.

- changed (2020-10-29):
[0001137789-20-000117:note_history:9]
There have been no material changes to the Company’s significant accounting policies disclosed in Note 1. Basis of Presentation and Summary of Significant Accounting Policies of “Financial Statements and Supplementary Data” contained in Part II, Item 8. of the Company’s Annual Report on Form 10-K for the fiscal year ended July 3, 2020, as filed with the SEC on August 7, 2020.
  (was, 2020-04-30, similarity 0.8747):
[0001137789-20-000035:note_history:9]
Except for the change in the Company’s other long-lived assets and leases policies described below, there have been no material changes to the Company’s significant accounting policies disclosed in Note 1. Basis of Presentation and Summary of Significant Accounting Policies of “Financial Statements and Supplementary Data” contained in Part II, Item 8. of the Company’s Annual Report on Form 10-K for the fiscal year ended June 28, 2019, as filed with the SEC on August 2, 2019.

- added (2020-10-29):
[0001137789-20-000117:note_history:10]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13 (ASC Topic 326), Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held to include future conditions in its estimate of expected credit losses. The Company adopted this new accounting pronouncement in the September 2020 quarter. The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.

- changed (2020-10-29):
[0001137789-20-000117:note_history:11]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles—Goodwill and Other - Internal-Use Software—Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company adopted this new accounting pronouncement in the September 2020 quarter. The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.
  (was, 2020-04-30, similarity 0.776):
[0001137789-20-000035:note_history:11]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles - Goodwill and Other - Internal-Use Software - Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company is required to adopt the guidance in the first quarter of fiscal year 2021. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

- changed (2020-10-29):
[0001137789-20-000117:note_history:12]
In December 2019, the FASB issued ASU 2019-12 (ASC Topic 740), Simplifying the Accounting for Income Taxes. This ASU simplifies accounting for income taxes by removing certain exceptions to the general principles and amending existing guidance to improve consistent application. The Company is required to adopt this new accounting pronouncement in the first quarter of fiscal year 2022. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.
  (was, 2020-04-30, similarity 0.9545):
[0001137789-20-000035:note_history:12]
In December 2019, the FASB issued ASU 2019-12 (ASC Topic 740), Simplifying the Accounting for Income Taxes. This ASU simplifies accounting for income taxes by removing certain exceptions to the general principles and amending existing guidance to improve consistent application. The Company is required to adopt this guidance in the first quarter of fiscal year 2022. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

- changed (2020-10-29):
[0001137789-20-000117:note_history:13]
In March 2020, the FASB issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. generally accepted accounting principles to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. Adoption of the expedients and exceptions is permitted upon issuance of this update through December 31, 2022. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.
  (was, 2020-04-30, similarity 0.9905):
[0001137789-20-000035:note_history:13]
In March 2020, the FASB issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. generally accepted accounting principles to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. Adoption of the expedients and exceptions is permitted upon issuance of this update through December 31, 2022. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

- removed (2020-10-29):
[0001137789-20-000035:note_history:14]
The Company’s HDD products are designed for both mass capacity storage and legacy markets. Mass capacity storage supports high capacity, low-cost storage applications, including nearline, video and image applications and network-attached storage (“NAS”). Legacy markets include mission critical, desktop, notebook, digital video recorders (“DVRs”), gaming consoles and consumer applications. These markets were previously categorized as enterprise servers and storage systems, edge non-compute applications and edge compute applications. The Company’s SSD product portfolio is mainly comprised of Serial Attached SCSI (“SAS”) and Non-Volatile Memory Express (“NVMe”) and is designed primarily for applications in enterprise servers and storage systems.

- removed (2020-10-29):
[0001137789-20-000035:note_history:15]
The Company’s enterprise data solutions (“EDS”) portfolio includes storage subsystems for enterprises, cloud service providers, scale-out storage servers and original equipment manufacturers (“OEMs”).

- removed (2020-10-29):
[0001137789-20-000035:note_history:16]
The preparation of financial statements in accordance with the United States (“U.S.”) generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements.

- removed (2020-10-29):
[0001137789-20-000035:note_history:17]
Other Long-Lived Assets

- removed (2020-10-29):
[0001137789-20-000035:note_history:18]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. This review indicated that the actual lives of certain manufacturing equipment at its manufacturing facilities were longer than the estimated useful lives used for depreciation purposes in the Company’s condensed consolidated financial statements. As a result, effective June 29, 2019, the Company changed its estimate of the useful lives of its manufacturing equipment from a range of three to five years to a range of three to seven years. The effect of this change in estimate increased the net income by $38 million and $103 million for the three and nine months ended April 3, 2020, respectively, and increased the diluted earnings per share by $0.14 and $0.39 for the three and nine months ended April 3, 2020, respectively.

- removed (2020-10-29):
[0001137789-20-000035:note_history:19]
Leases

- removed (2020-10-29):
[0001137789-20-000035:note_history:20]
Effective June 29, 2019, the Company adopted a new accounting policy for leases in accordance with Accounting Standard Codification (“ASC”) 842, Leases, using the modified retrospective approach. Accordingly, the Company applied the new lease accounting standard prospectively to leases existing or commencing on or after June 29, 2019. The Company elected to apply the practical expedients which allow for not reassessing whether existing contracts contain leases, the classification of existing leases and whether the existing initial direct costs meet the new definition. In addition, the Company elected to combine lease and non-lease components for facility leases and to not recognize right-of-use (“ROU”) assets and lease liabilities for leases with an initial term of 12 months or less on the balance sheet.

- removed (2020-10-29):
[0001137789-20-000035:note_history:21]
The Company determines if an arrangement is a lease or contains a lease at inception. ROU assets are included in Other assets, net and lease liabilities are included in Accrued expenses and Other non-current liabilities on the Company’s Condensed Consolidated Balance Sheets. ROU assets represent the Company’s right to use an underlying asset for the lease term and the corresponding lease liabilities represent its obligation to make lease payments arising from the lease.

- removed (2020-10-29):
[0001137789-20-000035:note_history:22]
Lease liabilities are measured at the present value of the remaining lease payments and ROU assets are based on the lease liability, adjusted for lease prepayments, lease incentives received and the lessee’s initial direct costs. As the Company’s leases do not provide an implicit rate, the net present value of future minimum lease payments is determined using the Company’s estimated incremental borrowing rate based on the information available at the lease commencement date. Additionally, the Company’s lease term may include options to extend or terminate the lease. These options are reflected in the ROU asset and lease liability when it is reasonably certain that the Company will exercise the option. The Company’s lease agreements do not contain any material residual value guarantees.

- removed (2020-10-29):
[0001137789-20-000035:note_history:23]
The Company recognizes lease expense on a straight-line basis over the lease term. Variable lease payments not dependent on an index or a rate primarily consist of common area maintenance charges, are expensed as incurred, and are not included in the ROU asset and lease liability calculation. The total operating and variable lease costs were included in operating expenses in the Company’s Condensed Consolidated Statements of Operations.

- removed (2020-10-29):
[0001137789-20-000035:note_history:24]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) 2016-02 (ASC Topic 842), Leases, and subsequently issued certain interpretive clarifications on this new guidance which amend a number of aspects of lease accounting, including requiring a lessee to recognize an ROU asset and corresponding lease liability for operating leases and enhanced disclosures. As of June 29, 2019, adoption of the standard resulted in the recognition of ROU assets and corresponding current and non-current lease liabilities of $115 million, $17 million and $57 million, respectively, on the Company’s Condensed Consolidated Balance Sheet, primarily relating to real estate operating leases. The adoption of this ASU did not have a material impact on the Company’s other condensed consolidated financial statements. For information regarding the impact of ASC 842 adoption, see Summary of Significant Accounting Policies - Leases above and Note 5. Leases.

- removed (2020-10-29):
[0001137789-20-000035:note_history:25]
In February 2018, the FASB issued ASU 2018-02 (ASC Topic 220), Income Statement—Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”) and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. This ASU became effective and the Company adopted the guidance in the quarter ended October 4, 2019. The Company has elected not to reclassify the stranded amounts. The adoption of this guidance did not have a material impact on its condensed consolidated financial statements and disclosures.

- removed (2020-10-29):
[0001137789-20-000035:note_history:26]
In June 2016, the FASB issued ASU 2016-13 (ASC Topic 326), Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held. The Company is required to adopt this guidance in the first quarter of fiscal year 2021. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001137789-20-000117:note_history:27]
Credit Agreement
  (was, 2020-04-30, similarity 0.8649):
[0001137789-20-000035:note_history:27]
Debt
Credit Agreement

- changed (2020-10-29):
[0001137789-20-000117:note_history:28]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of October 2, 2020 and expects to be in compliance for the next 12 months.
  (was, 2020-04-30, similarity 0.8134):
[0001137789-20-000035:note_history:28]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of April 3, 2020 and expects to be in compliance for the next 12 months.

- changed (2020-10-29):
[0001137789-20-000117:note_history:29]
As of October 2, 2020, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the Revolving Credit Facility.
  (was, 2020-04-30, similarity 0.9645):
[0001137789-20-000035:note_history:29]
As of April 3, 2020, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the Revolving Credit Facility.

- added (2020-10-29):
[0001137789-20-000117:note_history:30]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March, 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the three months ended October 2, 2020, $9 million aggregate principal amount of the 2022 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. During the three months ended October 4, 2019, $250 million aggregate principal amount was repurchased pursuant to cash tender offers for certain senior notes (“the Tender Offers”). The Company recorded an immaterial loss and a loss of $10 million, respectively, on repurchases during the three months ended October 2, 2020 and October 4, 2019, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- changed (2020-10-29):
[0001137789-20-000117:note_history:31]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June, 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the three months ended October 2, 2020, $5 million aggregate principal amount of the 2023 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest, of which $2 million remained unsettled as of October 2, 2020. During the three months ended October 4, 2019, $200 million aggregate principal amount was repurchased pursuant to the Tender Offers. The Company recorded a loss of $1 million and $10 million, respectively, on repurchases during the three months ended October 2, 2020 and October 4, 2019, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2020-04-30, similarity 0.6049):
[0001137789-20-000035:note_history:31]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the three and nine months ended April 3, 2020, the Company repurchased $17 million and $217 million aggregate principal amount of the 2023 Notes for cash at a discount or at a premium to their principal amount, plus accrued and unpaid interest, respectively, approximately $200 million principal amount of which was repurchased pursuant to the Tender Offers. The Company recorded an immaterial gain and a loss of approximately $10 million on repurchases during the three and nine months ended April 3, 2020, respectively, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- changed (2020-10-29):
[0001137789-20-000117:note_history:32]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March, 2024 (the “2024 Notes”). The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.
  (was, 2020-04-30, similarity 0.9986):
[0001137789-20-000035:note_history:32]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”). The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

- changed (2020-10-29):
[0001137789-20-000117:note_history:33]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January, 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the three months ended October 4, 2019, $170 million aggregate principal amount was repurchased pursuant to the Tender Offers. The Company recorded a loss of $8 million on repurchases during the three months ended October 4, 2019, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.
  (was, 2020-04-30, similarity 0.65):
[0001137789-20-000035:note_history:33]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. During the three and nine months ended April 3, 2020, the Company repurchased $23 million and $273 million aggregate principal amount of the 2022 Notes, respectively, for cash at a premium to their principal amount, plus accrued and unpaid interest, approximately $250 million principal amount of which was repurchased pursuant to cash tender offers for certain senior notes on September 18, 2019 (the “Tender Offers”). The Company recorded an immaterial loss and a loss of approximately $10 million on repurchases during the three and nine months ended April 3, 2020, respectively, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- changed (2020-10-29):
[0001137789-20-000117:note_history:34]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June, 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.
  (was, 2020-04-30, similarity 0.9985):
[0001137789-20-000035:note_history:34]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

- changed (2020-10-29):
[0001137789-20-000117:note_history:35]
$500 million Aggregate Principal Amount of 4.091% Senior Notes due June, 2029 (the “2029 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2029 Notes is Seagate HDD Cayman, and the obligations under the 2029 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.
  (was, 2020-04-30, similarity 0.9784):
[0001137789-20-000035:note_history:35]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

- changed (2020-10-29):
[0001137789-20-000117:note_history:36]
$500 million Aggregate Principal Amount of 4.125% Senior Notes due January, 2031 (the “2031 Notes”). The interest on the Notes is payable semi-annually on January 15 and July 15 of each year. The issuer under the 2031 Notes is Seagate HDD Cayman, and the obligations under the 2031 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.
  (was, 2020-04-30, similarity 0.6978):
[0001137789-20-000035:note_history:36]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX. On September 18, 2019, the principal amount of approximately $170 million was repurchased pursuant to the Tender Offers. The Company recorded a loss of $8 million during the nine months ended April 3, 2020, which was included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- added (2020-10-29):
[0001137789-20-000117:note_history:37]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December, 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by STX.

- changed (2020-10-29):
[0001137789-20-000117:note_history:38]
At October 2, 2020, future principal payments on long-term debt were as follows (in millions):
  (was, 2020-04-30, similarity 0.9432):
[0001137789-20-000035:note_history:38]
At April 3, 2020, future principal payments on long-term debt were as follows (in millions):

- changed (2020-10-29):
[0001137789-20-000117:note_history:39]
| Fiscal Year |  | Amount |
| Remainder of 2021 |  | $ | 19 |  |
| 2022 |  | 245 |  |
| 2023 |  | 566 |  |
| 2024 |  | 525 |  |
| 2025 |  | 504 |  |
| Thereafter |  | 2,376 |  |
| Total |  | $ | 4,235 |  |
  (was, 2020-04-30, similarity 0.9937):
[0001137789-20-000035:note_history:39]
| Fiscal Year |  | Amount |
| Remainder of 2020 |  | $ | — |  |
| 2021 |  | 19 |  |
| 2022 |  | 502 |  |
| 2023 |  | 749 |  |
| 2024 |  | 525 |  |
| Thereafter |  | 2,336 |  |
| Total |  | $ | 4,131 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001137789-20-000117:note_history:40]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of October 2, 2020:
  (was, 2020-04-30, similarity 0.9644):
[0001137789-20-000035:note_history:40]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of June 28, 2019:

- changed (2020-10-29):
[0001137789-20-000117:note_history:41]
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 418 |  |  | $ | — |  |  | $ | 418 |  |
| Time deposits and certificates of deposit |  | 62 |  |  | — |  |  | 62 |  |
| Other debt securities |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 498 |  |  | $ | — |  |  | $ | 498 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 475 |  |
| Included in Other current assets |  |  |  |  |  | 5 |  |
| Included in Other assets, net |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 498 |  |
  (was, 2020-04-30, similarity 0.9973):
[0001137789-20-000035:note_history:41]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale debt securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 352 |  |  | $ | — |  |  | $ | 352 |  |
| Time deposits and certificates of deposit |  | 255 |  |  | — |  |  | 255 |  |
| Other debt securities |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 625 |  |  | $ | — |  |  | $ | 625 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 605 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 625 |  |

- removed (2020-10-29):
[0001137789-20-000035:note_history:42]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of April 3, 2020:

- removed (2020-10-29):
[0001137789-20-000035:note_history:43]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale debt securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 417 |  |  | $ | — |  |  | $ | 417 |  |
| Time deposits and certificates of deposit |  | 133 |  |  | — |  |  | 133 |  |
| Other debt securities |  | 7 |  |  | — |  |  | 7 |  |
| Total |  | $ | 557 |  |  | $ | — |  |  | $ | 557 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 548 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 7 |  |
| Total |  |  |  |  |  | $ | 557 |  |

- added (2020-10-29):
[0001137789-20-000117:note_history:44]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of July 3, 2020:

- added (2020-10-29):
[0001137789-20-000117:note_history:45]
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 495 |  |  | $ | — |  |  | $ | 495 |  |
| Time deposits and certificates of deposit |  | 56 |  |  | — |  |  | 56 |  |
| Other debt securities |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 569 |  |  | $ | — |  |  | $ | 569 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 549 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 569 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001137789-20-000117:note_history:46]
At October 2, 2020, future principal payments on long-term debt were as follows (in millions):
  (was, 2020-04-30, similarity 0.9432):
[0001137789-20-000035:note_history:46]
At April 3, 2020, future principal payments on long-term debt were as follows (in millions):

- changed (2020-10-29):
[0001137789-20-000117:note_history:47]
| Fiscal Year |  | Amount |
| Remainder of 2021 |  | $ | 19 |  |
| 2022 |  | 245 |  |
| 2023 |  | 566 |  |
| 2024 |  | 525 |  |
| 2025 |  | 504 |  |
| Thereafter |  | 2,376 |  |
| Total |  | $ | 4,235 |  |
  (was, 2020-04-30, similarity 0.9937):
[0001137789-20-000035:note_history:47]
| Fiscal Year |  | Amount |
| Remainder of 2020 |  | $ | — |  |
| 2021 |  | 19 |  |
| 2022 |  | 502 |  |
| 2023 |  | 749 |  |
| 2024 |  | 525 |  |
| Thereafter |  | 2,336 |  |
| Total |  | $ | 4,131 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-10-29):
[0001137789-20-000117:note_history:48]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | October 2,2020 |  | October 4,2019 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 1,608 |  |  | $ | 1,820 |  |  |  |  |  |
| Distributors |  | 367 |  |  | 461 |  |  |  |  |  |
| Retailers |  | 339 |  |  | 297 |  |  |  |  |  |
| Total |  | $ | 2,314 |  |  | $ | 2,578 |  |  |  |  |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,106 |  |  | $ | 1,278 |  |  |  |  |  |
| Americas |  | 805 |  |  | 835 |  |  |  |  |  |
| EMEA |  | 403 |  |  | 465 |  |  |  |  |  |
| Total |  | $ | 2,314 |  |  | $ | 2,578 |  |  |  |  |  |

- removed (2020-10-29):
[0001137789-20-000035:note_history:49]
|  |  | For the Three Months Ended |  |  |  | For the Nine Months Ended |  |  |
| (Dollars in millions) |  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,970 |  |  | $ | 1,568 |  |  | $ | 5,633 |  |  | $ | 5,571 |  |
| Distributors |  | 465 |  |  | 411 |  |  | 1,389 |  |  | 1,388 |  |
| Retailers |  | 283 |  |  | 334 |  |  | 970 |  |  | 1,060 |  |
| Total |  | $ | 2,718 |  |  | $ | 2,313 |  |  | $ | 7,992 |  |  | $ | 8,019 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,257 |  |  | $ | 1,069 |  |  | $ | 3,912 |  |  | $ | 3,923 |  |
| Americas |  | 938 |  |  | 796 |  |  | 2,534 |  |  | 2,533 |  |
| EMEA |  | 523 |  |  | 448 |  |  | 1,546 |  |  | 1,563 |  |
| Total |  | $ | 2,718 |  |  | $ | 2,313 |  |  | $ | 7,992 |  |  | $ | 8,019 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-10-29):
[0001137789-20-000117:note_history:50]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | October 2,2020 |  | October 4,2019 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | $ | 1,608 |  |  | $ | 1,820 |  |  |  |  |  |
| Distributors |  | 367 |  |  | 461 |  |  |  |  |  |
| Retailers |  | 339 |  |  | 297 |  |  |  |  |  |
| Total |  | $ | 2,314 |  |  | $ | 2,578 |  |  |  |  |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,106 |  |  | $ | 1,278 |  |  |  |  |  |
| Americas |  | 805 |  |  | 835 |  |  |  |  |  |
| EMEA |  | 403 |  |  | 465 |  |  |  |  |  |
| Total |  | $ | 2,314 |  |  | $ | 2,578 |  |  |  |  |  |

- removed (2020-10-29):
[0001137789-20-000035:note_history:51]
|  |  | For the Three Months Ended |  |  |  | For the Nine Months Ended |  |  |
| (Dollars in millions) |  | April 3,2020 |  | March 29,2019 |  | April 3,2020 |  | March 29,2019 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,970 |  |  | $ | 1,568 |  |  | $ | 5,633 |  |  | $ | 5,571 |  |
| Distributors |  | 465 |  |  | 411 |  |  | 1,389 |  |  | 1,388 |  |
| Retailers |  | 283 |  |  | 334 |  |  | 970 |  |  | 1,060 |  |
| Total |  | $ | 2,718 |  |  | $ | 2,313 |  |  | $ | 7,992 |  |  | $ | 8,019 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,257 |  |  | $ | 1,069 |  |  | $ | 3,912 |  |  | $ | 3,923 |  |
| Americas |  | 938 |  |  | 796 |  |  | 2,534 |  |  | 2,533 |  |
| EMEA |  | 523 |  |  | 448 |  |  | 1,546 |  |  | 1,563 |  |
| Total |  | $ | 2,718 |  |  | $ | 2,313 |  |  | $ | 7,992 |  |  | $ | 8,019 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001137789-20-000117:note_history:52]
Dividend Declared
  (was, 2020-04-30, similarity 0.6538):
[0001137789-20-000035:note_history:52]
Subsequent Events
Dividend Declared

- changed (2020-10-29):
[0001137789-20-000117:note_history:53]
On October 22, 2020, the Company’s Board of Directors declared a quarterly cash dividend of $0.67 per share, which will be payable on January 6, 2021 to shareholders of record as of the close of business on December 23, 2020.
  (was, 2020-04-30, similarity 0.938):
[0001137789-20-000035:note_history:53]
On April 21, 2020, the Company’s Board of Directors declared a quarterly cash dividend of $0.65 per share, which will be payable on July 8, 2020 to shareholders of record as of the close of business on June 24, 2020.
