# STX MD&A — 0001137789-20-000117


## mdna

[0001137789-20-000117:mdna:1]
[same as prior period, unchanged from 0001137789-20-000035:mdna:1]

[0001137789-20-000117:mdna:2]
The following is a discussion of the financial condition, changes in financial condition and results of operations for our fiscal quarters ended October 2, 2020, July 3, 2020 and October 4, 2019, referred to herein as the “September 2020 quarter,” the “June 2020 quarter,” and the “September 2019 quarter,” respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The September 2020 quarter and the June 2020 quarter were each 13 weeks and the September 2019 quarter was 14 weeks.

[0001137789-20-000117:mdna:3]
[same as prior period, unchanged from 0001137789-20-000035:mdna:3]

[0001137789-20-000117:mdna:4]
[same as prior period, unchanged from 0001137789-20-000035:mdna:4]

[0001137789-20-000117:mdna:5]
[same as prior period, unchanged from 0001137789-20-000035:mdna:5]

[0001137789-20-000117:mdna:6]
[same as prior period, unchanged from 0001137789-20-000035:mdna:6]

[0001137789-20-000117:mdna:7]
[same as prior period, unchanged from 0001137789-20-000035:mdna:7]

[0001137789-20-000117:mdna:8]
[same as prior period, unchanged from 0001137789-20-000035:mdna:14]

[0001137789-20-000117:mdna:9]
•the Company’s ability to effectively manage its debt obligations and comply with certain covenants in its credit facilities with respect to financial ratios and financial condition tests and its ability to maintain a favorable cash liquidity position;

[0001137789-20-000117:mdna:10]
[same as prior period, unchanged from 0001137789-20-000035:mdna:9]

[0001137789-20-000117:mdna:11]
[same as prior period, unchanged from 0001137789-20-000035:mdna:10]

[0001137789-20-000117:mdna:12]
[same as prior period, unchanged from 0001137789-20-000035:mdna:11]

[0001137789-20-000117:mdna:13]
[same as prior period, unchanged from 0001137789-20-000035:mdna:12]

[0001137789-20-000117:mdna:14]
[same as prior period, unchanged from 0001137789-20-000035:mdna:13]

[0001137789-20-000117:mdna:15]
[same as prior period, unchanged from 0001137789-20-000035:mdna:15]

[0001137789-20-000117:mdna:16]
[same as prior period, unchanged from 0001137789-20-000035:mdna:16]

[0001137789-20-000117:mdna:17]
28

[0001137789-20-000117:mdna:18]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is provided in addition to the accompanying condensed consolidated financial statements and notes to assist readers in understanding our results of operations, financial condition and cash flows. Our MD&A is organized as follows:

[0001137789-20-000117:mdna:19]
•Overview of the September 2020 quarter. Highlights of events in the September 2020 quarter that impacted our financial position.

[0001137789-20-000117:mdna:20]
•Results of Operations. Analysis of our financial results comparing the September 2020 quarter to the June 2020 quarter and the September 2019 quarter.

[0001137789-20-000117:mdna:21]
•Liquidity and Capital Resources. An analysis of changes in our balance sheet and cash flows, and discussion of our financial condition including potential sources of liquidity.

[0001137789-20-000117:mdna:22]
[same as prior period, unchanged from 0001137789-20-000035:mdna:21]

[0001137789-20-000117:mdna:23]
For an overview of our business, see “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies—Organization”.

[0001137789-20-000117:mdna:24]
Overview of the September 2020 quarter

[0001137789-20-000117:mdna:25]
During the September 2020 quarter, we shipped 114 exabytes of HDD storage capacity. We generated revenue of approximately $2.3 billion and gross margin of 26% and our operating cash flow was $297 million. We repurchased approximately 1 million of our ordinary shares for $68 million and paid $167 million in dividends.

[0001137789-20-000117:mdna:26]
[same as prior period, unchanged from 0001137789-20-000035:mdna:25]

[0001137789-20-000117:mdna:27]
The COVID-19 pandemic has resulted in a widespread health crisis and numerous disease control measures are being taken to limit its spread, the effects of which began during our quarter ended April 3, 2020. We continued to incur certain supply chain and demand disruptions during the September 2020 quarter, as well as factory under-utilization, higher logistics and operational costs and softer demand across our markets due to the COVID-19 pandemic, which we expect to continue during fiscal year 2021. Our customers also continued to experience certain supply chain and demand disruptions during the September 2020 quarter, which we anticipate will continue during fiscal year 2021. We are continuing to actively monitor the effects and potential impacts of the COVID-19 pandemic on all aspects of our business, liquidity and capital resources. We are complying with governmental rules and guidelines across all of our sites and are actively working on opportunities to lower our cost structure and drive further operational efficiencies. Although we are unable to predict the impact of COVID-19 on our business, results of operations, liquidity or capital resources at this time, we expect we will be negatively affected if the pandemic and related public and private health measures result in substantial manufacturing or supply chain problems, substantial reductions in demand due to disruptions in the operations of our customers or partners, disruptions in local and global economies, volatility in the global financial markets, sustained reductions or volatility in overall demand trends, restrictions on the export or shipment of our products, or other ramifications from the COVID-19 pandemic. For a further discussion of the uncertainties and business risks associated with the COVID-19 pandemic, see the section entitled “Item 1A. Risk Factors” in our Annual Report on Form 10-K for the fiscal year ended July 3, 2020.

[0001137789-20-000117:mdna:28]
[same as prior period, unchanged from 0001137789-20-000035:mdna:27]

[0001137789-20-000117:mdna:29]
[same as prior period, unchanged from 0001137789-20-000035:mdna:28]

[0001137789-20-000117:mdna:30]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | October 2,2020 |  | July 3,2020 |  | October 4,2019 |  |  |  |  |
| Revenue |  | $ | 2,314 |  |  | $ | 2,517 |  |  | $ | 2,578 |  |  |  |  |  |
| Cost of revenue |  | 1,718 |  |  | 1,850 |  |  | 1,907 |  |  |  |  |  |
| Gross profit |  | 596 |  |  | 667 |  |  | 671 |  |  |  |  |  |
| Product development |  | 223 |  |  | 222 |  |  | 255 |  |  |  |  |  |
| Marketing and administrative |  | 118 |  |  | 112 |  |  | 122 |  |  |  |  |  |
| Amortization of intangibles |  | 3 |  |  | 3 |  |  | 4 |  |  |  |  |  |
| Restructuring and other, net |  | 1 |  |  | 63 |  |  | 17 |  |  |  |  |  |
| Income from operations |  | 251 |  |  | 267 |  |  | 273 |  |  |  |  |  |
| Other expense, net |  | (30) |  |  | (107) |  |  | (75) |  |  |  |  |  |
| Income before income taxes |  | 221 |  |  | 160 |  |  | 198 |  |  |  |  |  |
| Benefit for income taxes |  | (2) |  |  | (6) |  |  | (2) |  |  |  |  |  |
| Net income |  | $ | 223 |  |  | $ | 166 |  |  | $ | 200 |  |  |  |  |  |

[0001137789-20-000117:mdna:31]
|  |  | For the Three Months Ended |  |  |
|  |  | October 2,2020 |  | July 3,2020 |  | October 4,2019 |  |  |  |  |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  |  |  |  |
| Cost of revenue |  | 74 |  |  | 74 |  |  | 74 |  |  |  |  |  |
| Gross profit |  | 26 |  |  | 26 |  |  | 26 |  |  |  |  |  |
| Product development |  | 10 |  |  | 9 |  |  | 10 |  |  |  |  |  |
| Marketing and administrative |  | 5 |  |  | 4 |  |  | 5 |  |  |  |  |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |  |  |  |  |
| Restructuring and other, net |  | — |  |  | 2 |  |  | — |  |  |  |  |  |
| Income from operations |  | 11 |  |  | 11 |  |  | 11 |  |  |  |  |  |
| Other expense, net |  | (1) |  |  | (4) |  |  | (3) |  |  |  |  |  |
| Income before income taxes |  | 10 |  |  | 7 |  |  | 8 |  |  |  |  |  |
| Benefit for income taxes |  | — |  |  | — |  |  | — |  |  |  |  |  |
| Net income |  | 10 | % |  | 7 | % |  | 8 | % |  |  |  |  |

[0001137789-20-000117:mdna:32]
30

[0001137789-20-000117:mdna:33]
[same as prior period, unchanged from 0001137789-20-000035:mdna:32]

[0001137789-20-000117:mdna:34]
[same as prior period, unchanged from 0001137789-20-000035:mdna:33]

[0001137789-20-000117:mdna:35]
|  |  | For the Three Months Ended |  |  |
|  |  | October 2,2020 |  | July 3,2020 |  | October 4,2019 |  |  |  |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| Original equipment manufacturers |  | 69 | % |  | 74 | % |  | 71 | % |  |  |  |  |
| Distributors |  | 16 | % |  | 14 | % |  | 18 | % |  |  |  |  |
| Retailers |  | 15 | % |  | 12 | % |  | 11 | % |  |  |  |  |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 48 | % |  | 45 | % |  | 50 | % |  |  |  |  |
| Americas |  | 35 | % |  | 42 | % |  | 32 | % |  |  |  |  |
| EMEA |  | 17 | % |  | 13 | % |  | 18 | % |  |  |  |  |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 58 | % |  | 58 | % |  | 47 | % |  |  |  |  |
| Legacy |  | 34 | % |  | 34 | % |  | 46 | % |  |  |  |  |
| Other |  | 8 | % |  | 8 | % |  | 7 | % |  |  |  |  |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 86 |  |  | 91 |  |  | 64 |  |  |  |  |  |
| Legacy |  | 28 |  |  | 26 |  |  | 34 |  |  |  |  |  |
| Total |  | 114 |  |  | 117 |  |  | 98 |  |  |  |  |  |
| HDD Price per Terabyte |  | $ | 19 |  |  | $ | 20 |  |  | $ | 24 |  |  |  |  |  |

[0001137789-20-000117:mdna:36]
Revenue in the September 2020 quarter decreased by $203 million from the June 2020 quarter primarily due to price erosion, lower demand as a result of the COVID-19 pandemic and a decrease in exabytes shipped.

[0001137789-20-000117:mdna:37]
Revenue in the September 2020 quarter decreased by $264 million from the September 2019 quarter primarily due to the additional fourteenth week in the September 2019 quarter, price erosion and lower demand as a result of the COVID-19 pandemic, partially offset by an increase in mass capacity storage exabytes shipped.

[0001137789-20-000117:mdna:38]
We maintain various sales incentive programs such as channel and original equipment manufacturers rebates. Sales incentive programs were approximately 15% of gross HDD revenue for the September 2020 quarter, 12% for the July 2020 quarter and 12% for the September 2019 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-20-000117:mdna:39]
[same as prior period, unchanged from 0001137789-20-000035:mdna:39]

[0001137789-20-000117:mdna:40]
|  |  | For the Three Months Ended |  |  |  |  |
| (Dollars in millions) |  | October 2,2020 |  | July 3,2020 |  | October 4,2019 |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,718 |  |  | $ | 1,850 |  |  | $ | 1,907 |  |  |  |  |  |  |  |  |  |
| Gross profit |  | 596 |  |  | 667 |  |  | 671 |  |  |  |  |  |  |  |  |  |
| Gross margin |  | 26 | % |  | 26 | % |  | 26 | % |  |  |  |  |  |  |  |  |

[0001137789-20-000117:mdna:41]
Gross margin for the September 2020 quarter remained flat compared to the June 2020 quarter and the September 2019 quarter.

[0001137789-20-000117:mdna:42]
In the September 2020 quarter, total warranty cost was 0.5% of revenue and included a favorable change in estimates of prior warranty accruals of 0.3% of revenue primarily due to lower repair costs and a decrease in the number of drives under warranty. Warranty cost related to new shipments was 0.8%, 0.8% and 0.9% of revenue for the September 2020 quarter, June 2020 quarter and September 2019 quarter, respectively.

[0001137789-20-000117:mdna:43]
[same as prior period, unchanged from 0001137789-20-000035:mdna:45]

[0001137789-20-000117:mdna:44]
|  |  | For the Three Months Ended |  |  |  |  |
| (Dollars in millions) |  | October 2,2020 |  | July 3,2020 |  | October 4,2019 |  |  |  |  |  |  |  |  |
| Product development |  | $ | 223 |  |  | $ | 222 |  |  | $ | 255 |  |  |  |  |  |  |  |  |  |
| Marketing and administrative |  | 118 |  |  | 112 |  |  | 122 |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  | 3 |  |  | 3 |  |  | 4 |  |  |  |  |  |  |  |  |  |
| Restructuring and other, net |  | 1 |  |  | 63 |  |  | 17 |  |  |  |  |  |  |  |  |  |
| Operating expenses |  | $ | 345 |  |  | $ | 400 |  |  | $ | 398 |  |  |  |  |  |  |  |  |  |

[0001137789-20-000117:mdna:45]
Product development expense. Product development expense for the September 2020 quarter remained flat compared to the June 2020 quarter.

[0001137789-20-000117:mdna:46]
Product development expense decreased by $32 million in the September 2020 quarter compared to the September 2019 quarter primarily due to a $19 million decrease in compensation and other employee benefits from the additional fourteenth week in the September 2019 quarter and the reduction in headcount as a result of our June 2020 restructuring plan, a $4 million decrease in other general expenses and a $3 million decrease in travel expenses mainly as a result of disruptions related to COVID-19.

[0001137789-20-000117:mdna:47]
Marketing and administrative expense. Marketing and administrative expense increased by $6 million for the September 2020 quarter compared to the June 2020 quarter primarily due to a $4 million increase in compensation and other employee benefits.

[0001137789-20-000117:mdna:48]
Marketing and administrative expense decreased by $4 million in the September 2020 quarter compared to the September 2019 quarter primarily due to a $6 million decrease in travel expenses as a result of disruptions related to COVID-19 and a $3 million decrease in compensation and other employee benefits resulting from the additional fourteenth week in the September 2019 quarter, partially offset by a $2 million increase in share-based compensation expense.

[0001137789-20-000117:mdna:49]
Amortization of intangibles. Amortization of intangibles for the September 2020 quarter remained flat compared to the June 2020 quarter.

[0001137789-20-000117:mdna:50]
Amortization of intangibles for the September 2020 quarter decreased by $1 million compared to the September 2019 quarter, due to certain intangible assets that reached the end of their useful lives.

[0001137789-20-000117:mdna:51]
Restructuring and other, net. Restructuring and other, net for the September 2020 quarter was not material.

[0001137789-20-000117:mdna:52]
Restructuring and other, net for the June 2020 quarter was primarily comprised of restructuring charges related to the restructuring plan the Company committed to on June 1, 2020 to reduce our workforce by approximately 500 employees and charges related to other restructuring plans.

[0001137789-20-000117:mdna:53]
Restructuring and other, net for the September 2019 quarter was comprised of charges primarily related to a voluntary early exit program.

[0001137789-20-000117:mdna:54]
[same as prior period, unchanged from 0001137789-20-000035:mdna:57]

[0001137789-20-000117:mdna:55]
|  |  | For the Three Months Ended |  |  |  |  |
| (Dollars in millions) |  | October 2,2020 |  | July 3,2020 |  | October 4,2019 |  |  |  |  |  |  |  |  |
| Other expense, net |  | $ | (30) |  |  | $ | (107) |  |  | $ | (75) |  |  |  |  |  |  |  |  |  |

[0001137789-20-000117:mdna:56]
Other expense, net. Other expense, net for the September 2020 quarter decreased by $77 million from the June 2020 quarter primarily due to $31 million of strategic investment gains in the September 2020 quarter, of which $23 million is an upward adjustment and $8 million is a gain upon sale of an investment, a $30 million non-recurring loss from the repurchase and exchange of certain long-term debt in the June 2020 quarter and an $18 million non-recurring impairment charge in the June 2020 quarter.

[0001137789-20-000117:mdna:57]
[same as prior period, unchanged from 0001137789-20-000035:mdna:31]

[0001137789-20-000117:mdna:58]
Other expense, net for the September 2020 quarter decreased by $45 million compared to the September 2019 quarter primarily due to $31 million of strategic investment gains in the September 2020 quarter, of which $23 million is an upward adjustment and $8 million is a gain upon sale of an investment, and a $28 million non-recurring net loss from the repurchase of certain long-term debt in the September 2019 quarter, partially offset by a $13 million increase in foreign exchange remeasurement expense in the September 2020 quarter.

[0001137789-20-000117:mdna:59]
[same as prior period, unchanged from 0001137789-20-000035:mdna:62]

[0001137789-20-000117:mdna:60]
|  |  | For the Three Months Ended |  |  |  |  |
| (Dollars in millions) |  | October 2,2020 |  | July 3,2020 |  | October 4,2019 |  |  |  |  |  |  |  |  |
| Benefit for income taxes |  | $ | (2) |  |  | $ | (6) |  |  | $ | (2) |  |  |  |  |  |  |  |  |  |

[0001137789-20-000117:mdna:61]
Our income tax benefit of $2 million for the three months ended October 2, 2020 included approximately $10 million of net discrete tax benefit of which $4 million was associated with net excess tax benefits related to share-based compensation expense and $3 million was associated with the postponement of the previously enacted U.K. tax rate change in the September 2020 quarter.

[0001137789-20-000117:mdna:62]
Our income tax provision recorded for the three months ended October 2, 2020 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-20-000117:mdna:63]
During the three months ended October 2, 2020, we had approximately $89 million of unrecognized tax benefits excluding interest and penalties, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. During the twelve months beginning October 3, 2020, we expect that our unrecognized tax benefits could be reduced by an immaterial amount, as a result of the expiration of certain statutes of limitation.

[0001137789-20-000117:mdna:64]
Our income tax benefit of $2 million for the three months ended October 4, 2019 included approximately $11 million of net discrete tax benefit of which $8 million was associated with net excess tax benefits related to share-based compensation expense.

[0001137789-20-000117:mdna:65]
Our income tax provision recorded for the three months ended October 4, 2019 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-20-000117:mdna:66]
[same as prior period, unchanged from 0001137789-20-000035:mdna:72]

[0001137789-20-000117:mdna:67]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash will continue to be sufficient to meet our cash needs for the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs, will allow us to manage the potential impacts of the COVID-19 pandemic on our business operations for the foreseeable future. However, the challenges posed by COVID-19 to our industry and to our business are evolving rapidly, are highly uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to COVID-19.

[0001137789-20-000117:mdna:68]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of October 2, 2020.

[0001137789-20-000117:mdna:69]
[same as prior period, unchanged from 0001137789-20-000035:mdna:75]

[0001137789-20-000117:mdna:70]
| (Dollars in millions) |  | October 2,2020 |  | July 3,2020 |  | Change |
| Cash and cash equivalents |  | $ | 1,664 |  |  | $ | 1,722 |  |  | $ | (58) |  |

[0001137789-20-000117:mdna:71]
Our cash and cash equivalents as of October 2, 2020 decreased by $58 million from July 3, 2020 primarily as a result of dividends paid to our shareholders of $167 million, the repurchases of our ordinary shares of $68 million and payments for capital expenditures of $111 million, partially offset by net cash of $297 million provided by operating activities.

[0001137789-20-000117:mdna:72]
[same as prior period, unchanged from 0001137789-20-000035:mdna:78]

[0001137789-20-000117:mdna:73]
Cash provided by operating activities for the three months ended October 2, 2020 was $297 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-20-000117:mdna:74]
•a decrease of $249 million in accounts receivable, primarily due to a decrease in revenue and the sale of receivables in connection with an existing factoring agreement;

[0001137789-20-000117:mdna:75]
•partially offset by an increase of $181 million in inventories, primarily due to timing of shipments and an increase in materials purchased, including strategic purchases;

[0001137789-20-000117:mdna:76]
•a decrease of $67 million in accrued employee compensation, primarily due to cash paid to our employees as part of our discretionary spending plans;

[0001137789-20-000117:mdna:77]
•a decrease of $38 million in accrued restructuring, primarily due to severance payments to impacted employees; and

[0001137789-20-000117:mdna:78]
•a decrease of $24 million in accounts payable, primarily due to lower operating expenses.

[0001137789-20-000117:mdna:79]
[same as prior period, unchanged from 0001137789-20-000035:mdna:83]

[0001137789-20-000117:mdna:80]
Cash used in investing activities for the three months ended October 2, 2020 was $104 million, primarily attributable to the following activities:

[0001137789-20-000117:mdna:81]
•payments for the purchase of property, equipment and leasehold improvements of $111 million; and

[0001137789-20-000117:mdna:82]
•payments for the purchase of investments of $4 million;

[0001137789-20-000117:mdna:83]
•offset by proceeds from the sale of investments of $11 million.

[0001137789-20-000117:mdna:84]
[same as prior period, unchanged from 0001137789-20-000035:mdna:87]

[0001137789-20-000117:mdna:85]
Cash used in financing activities of $251 million for the three months ended October 2, 2020 was primarily attributable to the following activities:

[0001137789-20-000117:mdna:86]
•payments for dividends of $167 million;

[0001137789-20-000117:mdna:87]
•payments for the repurchase of our ordinary shares of $68 million;

[0001137789-20-000117:mdna:88]
•payments for taxes related to net share settlement of equity awards of $31 million; and

[0001137789-20-000117:mdna:89]
•payments for the repurchase of long-term debt of $13 million;

[0001137789-20-000117:mdna:90]
•partially offset by proceeds from the issuance of ordinary shares under employee share plans of $29 million.

[0001137789-20-000117:mdna:91]
[same as prior period, unchanged from 0001137789-20-000035:mdna:96]

[0001137789-20-000117:mdna:92]
Our primary sources of liquidity as of October 2, 2020 consisted of: (1) approximately $1.7 billion in cash and cash equivalents, (2) cash we expect to generate from operations, and (3) subject to compliance with certain requirements under our control, up to $1.5 billion available for borrowing under our Revolving Credit Facility.

[0001137789-20-000117:mdna:93]
As of October 2, 2020, no borrowings had been drawn and no borrowings had been utilized for letters of credit or swing line loans issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-20-000117:mdna:94]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The term of the Revolving Credit Facility is through February 20, 2024, and the maturity date of the Term Loan is September 16, 2025. We were in compliance with the covenants as of October 2, 2020 and expect to be in compliance for the next 12 months.

[0001137789-20-000117:mdna:95]
[same as prior period, unchanged from 0001137789-20-000035:mdna:100]

[0001137789-20-000117:mdna:96]
[same as prior period, unchanged from 0001137789-20-000035:mdna:56]

[0001137789-20-000117:mdna:97]
For fiscal year 2021, we expect capital expenditures to be at or below our long-term targeted range of 6% to 8% of revenue. We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We may raise additional capital from time to time and will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-20-000117:mdna:98]
From time to time, we may repurchase any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase outstanding senior notes pursuant to the terms of the applicable indenture.

[0001137789-20-000117:mdna:99]
During the September 2020 quarter, our Board of Directors declared dividends of $0.65 per share, totaling $167 million, which were paid on October 7, 2020. On October 22, 2020, our Board of Directors declared a quarterly cash dividend of $0.67 per share, payable on January 6, 2021 to shareholders of record at the close of business on December 23, 2020.

[0001137789-20-000117:mdna:100]
From time to time, at the Company’s discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means, including through the use of derivative transactions. As of October 2, 2020, $1.2 billion remained available for repurchases under our existing repurchase authorization. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution. On October 21, 2020, our Board of Directors increased the authorization for the repurchase of our outstanding ordinary shares by $3.0 billion.

[0001137789-20-000117:mdna:101]
[same as prior period, unchanged from 0001137789-20-000035:mdna:105]

[0001137789-20-000117:mdna:102]
[same as prior period, unchanged from 0001137789-20-000035:mdna:106]

[0001137789-20-000117:mdna:103]
Other than as described in “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies”, there have been no other material changes in our critical accounting policies and estimates. Refer to “Part II, Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended July 3, 2020, as filed with the SEC on August 7, 2020, for a discussion of our critical accounting policies and estimates.

[0001137789-20-000117:mdna:104]
[same as prior period, unchanged from 0001137789-20-000035:mdna:108]

[0001137789-20-000117:mdna:105]
[same as prior period, unchanged from 0001137789-20-000035:mdna:109]
