# STX MD&A — 0001047469-16-014732


## mdna

[0001047469-16-014732:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001047469-16-014732:mdna:2]
The following is a discussion of the Company's financial condition, changes in financial condition and results
of operations for the fiscal years ended, July 1, 2016, July 3, 2015 and June 27, 2014.

[0001047469-16-014732:mdna:3]
You should read this discussion in conjunction with "Item 6. Selected Financial Data" and "Item 8. Financial Statements and Supplementary Data"
included elsewhere in this Annual Report on Form 10-K. Except as noted, references to any fiscal year mean the twelve-month period ending on the Friday closest to June 30 of that year.
Accordingly, fiscal year 2016 comprised 52 weeks and ended on July 1, 2016. Fiscal year
2015 comprised 53 weeks and ended on July 3, 2015. Fiscal year 2014 comprised 52 weeks and ended on June 27, 2014. Fiscal year 2017 will be 52 weeks and will end on
June 30, 2017.

[0001047469-16-014732:mdna:4]
Our
Management's Discussion and Analysis of Financial Condition and Results of Operations ("MD&A") is provided in addition to the accompanying consolidated financial statements and notes
to assist readers in understanding our results of operations, financial condition, and cash flows. MD&A is organized as follows:

[0001047469-16-014732:mdna:5]
•

[0001047469-16-014732:mdna:6]
Our Company.  Discussion of our business.

[0001047469-16-014732:mdna:7]
•

[0001047469-16-014732:mdna:8]
Business Overview.  Discussion of industry trends and
their impact on our business.

[0001047469-16-014732:mdna:9]
•

[0001047469-16-014732:mdna:10]
Fiscal Year 2016 Summary.  Overview of financial and
other highlights affecting us for fiscal year 2016.

[0001047469-16-014732:mdna:11]
•

[0001047469-16-014732:mdna:12]
Results of Operations.  Analysis of our financial results
comparing fiscal year 2016 to 2015 and comparing fiscal years 2015 to 2014.

[0001047469-16-014732:mdna:13]
•

[0001047469-16-014732:mdna:14]
Liquidity and Capital Resources.  An analysis of changes
in our balance sheets and cash flows, and discussion of our financial condition including the credit quality of our investment portfolio and potential sources of liquidity.

[0001047469-16-014732:mdna:15]
•

[0001047469-16-014732:mdna:16]
Contractual Obligations and Off-Balance Sheet
Arrangements.  Overview of contractual obligations and contingent liabilities and commitments outstanding as of July 1, 2016 and
an explanation of off-balance sheet arrangements.

[0001047469-16-014732:mdna:17]
•

[0001047469-16-014732:mdna:18]
Critical Accounting Estimates.  Accounting estimates that
we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001047469-16-014732:mdna:19]
Our Company

[0001047469-16-014732:mdna:20]
We are a leading provider of electronic data storage technology and solutions. Our principal products are hard disk drives, commonly
referred to as disk drives, hard drives or HDDs. In addition to HDDs, we produce a broad range of electronic data storage products including solid state hybrid drives ("SSHD"), solid state drives
("SSD"), PCIe cards and SATA controllers. Our storage technology portfolio also includes storage subsystems, and high performance computing ("HPC") solutions.

[0001047469-16-014732:mdna:21]
Hard
disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to
their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to
store data, and most SSDs use NAND-based flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache
to improve performance of frequently accessed data.

[0001047469-16-014732:mdna:22]
Our
products are designed for mission critical and nearline applications in enterprise servers and storage systems; client compute applications, where our products are designed primarily
for desktop and mobile computing; and client non-compute applications, where our products are designed for a wide variety of end user devices such as digital video recorders ("DVRs"), personal data
backup systems, portable external storage systems, digital media systems and surveillance systems.

[0001047469-16-014732:mdna:23]
Our
Cloud Systems and Solutions builds on the Seagate legacy to extend innovation from the device into the information infrastructure, onsite and in the cloud. Our approach to data
management supports HPC, open source and software-defined solutions. Our portfolio includes HPC storage solutions, modular original equipment manufacturers ("OEM") storage systems and scale-out
storage systems.

[0001047469-16-014732:mdna:24]
Business Overview

[0001047469-16-014732:mdna:25]
Our industry is characterized by several trends and factors that have a material impact on our strategic planning, financial condition
and results of operations.

[0001047469-16-014732:mdna:26]
Demand for Electronic Data Storage

[0001047469-16-014732:mdna:27]
The continued advancement of the cloud, the proliferation of a variety of mobile devices globally, development of the Internet of
Things ("IoT"), increasingly pervasive use of video surveillance, evolution of consumer electronic devices, and enterprise use of big data analytics are driving the growth of digital content. Factors
contributing to this growth include:

[0001047469-16-014732:mdna:28]
•

[0001047469-16-014732:mdna:29]
Creation, sharing, and consumption of media-rich digital content, such as high-resolution photos, high definition video, and digital
music through smart phones, tablets, digital cameras, personal video cameras, DVRs, gaming consoles or other digital devices;

[0001047469-16-014732:mdna:30]
44

[0001047469-16-014732:mdna:31]
•

[0001047469-16-014732:mdna:32]
Creation, aggregation and distribution of digital content through services and other offerings such as Facebook®,
Instagram®, iTunes®, Netflix®, Google® and YouTube®;

[0001047469-16-014732:mdna:33]
•

[0001047469-16-014732:mdna:34]
New surveillance systems which feature higher resolution digital cameras and thus require larger data storage capacities;

[0001047469-16-014732:mdna:35]
•

[0001047469-16-014732:mdna:36]
Creation and collection of data through the evolution of the IoT ecosystem, big data analytics and new technology trends such as
self-driving cars and drones;

[0001047469-16-014732:mdna:37]
•

[0001047469-16-014732:mdna:38]
Build out of large numbers of cloud data centers by cloud service providers and private companies transitioning on-site data centers
into the cloud;

[0001047469-16-014732:mdna:39]
•

[0001047469-16-014732:mdna:40]
Protection of increased digital content through redundant storage on backup devices and externally provided storage services.

[0001047469-16-014732:mdna:41]
As
a result of these factors, the nature and volume of content being created requires greater storage, which is more efficiently and economically facilitated by higher capacity storage
devices in order to store, manage, distribute, analyze and backup such content. We expect this to support the growth in demand for electronic data storage solutions in developed and emerging economies
well into the future.

[0001047469-16-014732:mdna:42]
The
amount of data created as well as where and how data is stored continues to evolve with the proliferation of mobile devices, the growth of cloud computing, and the evolving IoT. In
addition, the economics of storage infrastructure are also evolving with the utilization of public and private hyper-scale storage and open-source solutions reducing the total cost of ownership of
storage while increasing the speed and efficiency with which customers can leverage massive computing and storage devices. Accordingly, we expect these trends will continue to create significant
demand for electronic data storage solutions going forward.

[0001047469-16-014732:mdna:43]
Demand Trends for Disk Drives

[0001047469-16-014732:mdna:44]
We believe that continued growth in digital content requires increasingly higher storage capacity in order to store, aggregate, host,
distribute, analyze, manage, backup and use such content. We also believe that as architectures evolve to serve the growing commercial and consumer user base throughout the world, the manner which
hard drives are delivered to market and utilized by our customers will evolve as well.

[0001047469-16-014732:mdna:45]
We
believe that in the foreseeable future the traditional enterprise and client compute markets that require high capacity storage solutions, and the data intensive client non-compute
markets will continue to be best served by hard disk drives due to the industry's ability to deliver the most cost effective, reliable and energy efficient mass storage devices. Furthermore, the
increased use of client
non-compute devices that both consume media-rich digital content streamed from the cloud and create rich digital content that is stored in the cloud, increases the demand for high capacity hard disk
drives in enterprise Nearline applications.

[0001047469-16-014732:mdna:46]
We
also believe that as hard disk drive capacities continue to increase, unit demand does not reflect the increase in Exabytes demand. In recent years, this trend has resulted in demand
for fewer units, but with higher average capacity per drive.

[0001047469-16-014732:mdna:47]
Industry Supply Balance

[0001047469-16-014732:mdna:48]
From time to time the HDD industry has experienced periods of imbalance between supply and demand. To the extent that the disk drive
industry builds or maintains capacity based on expectations of demand that do not materialize, price erosion may become more pronounced. Conversely, during periods where demand exceeds supply, price
erosion is generally muted.

[0001047469-16-014732:mdna:49]
45

[0001047469-16-014732:mdna:50]
Price Erosion.

[0001047469-16-014732:mdna:51]
Historically, our industry has been characterized by price declines for disk drive products with comparable capacity, performance and
feature sets ("like-for-like products"). Price declines for like-for-like products ("price erosion") have been more pronounced during periods of:

[0001047469-16-014732:mdna:52]
•

[0001047469-16-014732:mdna:53]
economic contraction in which competitors may use discounted pricing to attempt to maintain or gain market share;

[0001047469-16-014732:mdna:54]
•

[0001047469-16-014732:mdna:55]
few new product introductions when competitors have comparable or alternative product offerings; and

[0001047469-16-014732:mdna:56]
•

[0001047469-16-014732:mdna:57]
industry supply exceeding demand.

[0001047469-16-014732:mdna:58]
Disk
drive manufacturers typically attempt to offset price erosion with an improved mix of disk drive products characterized by higher capacity, better performance and additional feature
sets and product cost reductions.

[0001047469-16-014732:mdna:59]
We
believe the HDD industry experienced benign price erosion in fiscal year 2014, whereas price erosion increased in fiscal years 2015 and 2016.

[0001047469-16-014732:mdna:60]
Product Life Cycles and Changing Technology.    Success in our industry has been dependent to a large extent on the ability to balance the
introduction
and transition of new products with time-to-volume, performance, capacity and quality metrics at a competitive price, level of service and support that our customers expect. Generally, the drive
manufacturer that introduces a new product first benefits from improved product mix, favorable profit margins and less pricing pressure until comparable products are introduced. Changing technology
also necessitates on-going investments in research and development, which may be difficult to recover due to rapid product life cycles and economic declines. Further, there is a continued need to
successfully execute product transitions and new product introductions, as factors such as quality, reliability and manufacturing yields continue to be of significant competitive importance.

[0001047469-16-014732:mdna:61]
Seasonality

[0001047469-16-014732:mdna:62]
The disk drive industry traditionally experiences seasonal variability in demand with higher levels of demand in the second half of the
calendar year. This seasonality is driven by consumer spending in the back-to-school season from late summer to fall and the traditional holiday shopping season from fall to winter. We believe fiscal
year 2015 reflected seasonality consistent with historical patterns, whereas in fiscal year 2014 our industry experienced more muted seasonal patterns as supply and demand were relatively in balance.
In fiscal year 2016, beyond traditional seasonality,
variability of sales was a reflection of more cyclical demand from CSPs based on the timing of large systems installations and the shift of the underlying technology.

[0001047469-16-014732:mdna:63]
Fiscal Year 2016 Summary

[0001047469-16-014732:mdna:64]
During the fiscal year 2016, we shipped 169 million units totaling 233 exabytes, generating revenue of $11.2 billion and
gross margins of 23% of revenue. Our operating cash flow was $1.7 billion. We repurchased approximately 24 million of our ordinary shares during the year for approximately
$1.1 billion, paid dividends during the year of $727 million, and completed our acquisition of Dot Hill Systems Corp. ("Dot Hill"), a supplier of software and hardware storage systems
for $674 million in cash.

[0001047469-16-014732:mdna:65]
Results of Operations

[0001047469-16-014732:mdna:66]
We list in the tables below summarized information from our Consolidated Statements of Operations by dollars and as a percentage of
revenue:

[0001047469-16-014732:mdna:67]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |  |
| Revenue |  | $ | 11,160 |  | $ | 13,739 |  | $ | 13,724 |  |
| Cost of revenue |  |  | 8,545 |  |  | 9,930 |  |  | 9,878 |  |
| Gross margin |  |  | 2,615 |  |  | 3,809 |  |  | 3,846 |  |
| Product development |  |  | 1,237 |  |  | 1,353 |  |  | 1,226 |  |
| Marketing and administrative |  |  | 635 |  |  | 857 |  |  | 722 |  |
| Amortization of intangibles |  |  | 123 |  |  | 129 |  |  | 98 |  |
| Restructuring and other, net |  |  | 175 |  |  | 32 |  |  | 24 |  |
| Gain on arbitration award, net |  |  | — |  |  | (620 | ) |  | — |  |
| Income from operations |  |  | 445 |  |  | 2,058 |  |  | 1,776 |  |
| Other income (expense), net |  |  | (171 | ) |  | (88 | ) |  | (220 | ) |
| Income before income taxes |  |  | 274 |  |  | 1,970 |  |  | 1,556 |  |
| Provision for (benefit from) income taxes |  |  | 26 |  |  | 228 |  |  | (14 | ) |
| Net income |  | $ | 248 |  | $ | 1,742 |  | $ | 1,570 |  |

[0001047469-16-014732:mdna:68]
|  |  | Fiscal Years Ended |  |
|  |  | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |  |
| Revenue |  |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  |  | 77 |  |  | 72 |  |  | 72 |  |
| Gross margin |  |  | 23 |  |  | 28 |  |  | 28 |  |
| Product development |  |  | 11 |  |  | 10 |  |  | 9 |  |
| Marketing and administrative |  |  | 6 |  |  | 7 |  |  | 5 |  |
| Amortization of intangibles |  |  | 1 |  |  | 1 |  |  | 1 |  |
| Restructuring and other, net |  |  | 2 |  |  | — |  |  | — |  |
| Gain on arbitration award, net |  |  | — |  |  | (5 | ) |  | — |  |
| Income from operations |  |  | 4 |  |  | 15 |  |  | 13 |  |
| Other income (expense), net |  |  | (2 | ) |  | (1 | ) |  | (2 | ) |
| Income before income taxes |  |  | 2 |  |  | 14 |  |  | 11 |  |
| Provision for (benefit from) income taxes |  |  | — |  |  | 2 |  |  | — |  |
| Net income |  |  | 2 | % |  | 12 | % |  | 11 | % |

[0001047469-16-014732:mdna:69]
47

[0001047469-16-014732:mdna:70]
The
following table summarizes information regarding average drive selling prices ("ASPs") excluding storage systems; drive volume shipments, exabytes shipped, and revenues by channel
and geography:

[0001047469-16-014732:mdna:71]
|  |  | Fiscal Years Ended |  |
| (In millions, except percentages, exabytes and ASPs) |  | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |  |
| Unit Shipments: |  |  |  |  |  |  |  |  |  |  |
| Enterprise |  |  | 32 |  |  | 36 |  |  | 31 |  |
| Client Compute |  |  | 93 |  |  | 132 |  |  | 144 |  |
| Client Non-Compute |  |  | 44 |  |  | 44 |  |  | 45 |  |
| Total Units Shipped |  |  | 169 |  |  | 212 |  |  | 220 |  |
| ASPs (per unit) |  | $ | 61 |  | $ | 61 |  | $ | 61 |  |
| Exabytes Shipped |  |  | 233 |  |  | 228 |  |  | 202 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  |  | 70 | % |  | 71 | % |  | 68 | % |
| Distributors |  |  | 16 | % |  | 17 | % |  | 20 | % |
| Retailers |  |  | 14 | % |  | 12 | % |  | 12 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |
| Americas |  |  | 29 | % |  | 28 | % |  | 27 | % |
| EMEA |  |  | 17 | % |  | 17 | % |  | 19 | % |
| Asia Pacific |  |  | 54 | % |  | 55 | % |  | 54 | % |

[0001047469-16-014732:mdna:72]
Fiscal Year 2016 Compared to Fiscal Year 2015

[0001047469-16-014732:mdna:73]
Revenue

[0001047469-16-014732:mdna:74]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 1, 2016 |  | July 3, 2015 |  | Change |  | % Change |  |
| Revenue |  | $ | 11,160 |  | $ | 13,739 |  | $ | (2,579 | ) |  | (19 | )% |

[0001047469-16-014732:mdna:75]
Revenue
in fiscal year 2016 decreased approximately 19% or $2.6 billion, from fiscal year 2015, as a result of a decrease in shipments by 43 million units and price
erosion, which were due to lower demand in the client compute market and reduced demand for mission critical HDD enterprise products, partially offset by improved product mix.

[0001047469-16-014732:mdna:76]
Cost of Revenue and Gross Margin

[0001047469-16-014732:mdna:77]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 1, 2016 |  | July 3, 2015 |  | Change |  | % Change |  |
| Cost of revenue |  | $ | 8,545 |  | $ | 9,930 |  | $ | (1,385 | ) |  | (14 | )% |
| Gross margin |  | $ | 2,615 |  | $ | 3,809 |  | $ | (1,194 | ) |  | (31 | )% |
| Gross margin percentage |  |  | 23 | % |  | 28 | % |  |  |  |  |  |  |

[0001047469-16-014732:mdna:78]
For
fiscal year 2016, gross margin as a percentage of revenue decreased by 500 basis points compared to the prior fiscal year due to price erosion and reduced demand in legacy hard
drives resulting in underutilization of certain factories, partially offset by improved product mix in the second half of fiscal year 2016.

[0001047469-16-014732:mdna:79]
Operating Expenses

[0001047469-16-014732:mdna:80]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 1, 2016 |  | July 3, 2015 |  | Change |  | % Change |  |
| Product development |  | $ | 1,237 |  | $ | 1,353 |  | $ | (116 | ) |  | (9 | )% |
| Marketing and administrative |  |  | 635 |  |  | 857 |  |  | (222 | ) |  | (26 | )% |
| Amortization of intangibles |  |  | 123 |  |  | 129 |  |  | (6 | ) |  | (5 | )% |
| Restructuring and other, net |  |  | 175 |  |  | 32 |  |  | 143 |  |  | 447 | % |
| Gain on arbitration award, net |  |  | — |  |  | (620 | ) |  | 620 |  |  | (100 | )% |
| Operating expenses |  | $ | 2,170 |  | $ | 1,751 |  | $ | 419 |  |  |  |  |

[0001047469-16-014732:mdna:81]
Product Development Expense.    Product development expenses for fiscal year 2016 decreased from fiscal year 2015 due to a decrease in
salaries and
other employee benefits of $63 million as a result of the
restructuring of our workforce beginning in the second half of fiscal year 2015, a $29 million decrease in variable compensation, and other cost reduction efforts, partially offset by the
consolidation of Dot Hill in fiscal year 2016 and LSI's Flash Business in fiscal year 2015.

[0001047469-16-014732:mdna:82]
Marketing and Administrative Expense.    Marketing and administrative expenses for fiscal year 2016 decreased from fiscal year 2015
primarily due to a
decrease in salaries and other employee benefits of $82 million as a result of a restructuring of our workforce beginning in the second half of fiscal year 2015, a $45 million decrease
in variable compensation and stock-based compensation, a $33 million reduction in advertising due to the completion of certain promotional and branding activities in fiscal year 2016, and
increased operational efficiencies in our business.

[0001047469-16-014732:mdna:83]
Amortization of Intangibles.    Amortization of intangibles for fiscal year 2016 decreased by $6 million, as compared to fiscal year
2015, as a
result of certain intangible assets reaching the end of their useful lives, partially offset by the amortization of intangibles acquired from the Dot Hill acquisition in fiscal 2016.

[0001047469-16-014732:mdna:84]
Restructuring and Other, net.    Restructuring and other, net for fiscal year 2016 was comprised of restructuring charges recorded during
the September
2015 quarter, March 2016 quarter and June 2016 quarter, to reduce our workforce by approximately 4,600 employees and align our manufacturing footprint with current macroeconomic conditions.

[0001047469-16-014732:mdna:85]
Restructuring
and other, net for fiscal year 2015 was due to charges to reduce our workforce as a result of our ongoing focus on cost efficiencies in all areas of our business.

[0001047469-16-014732:mdna:86]
Gain on arbitration award, net.    Gain on arbitration award, net for fiscal year 2015 was related to the final award amount of
$630 million,
less litigation and other related costs of $10 million, in the Company's case against Western Digital for the misappropriation of the Company's trade secrets.

[0001047469-16-014732:mdna:87]
Other income (expense), net

[0001047469-16-014732:mdna:88]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 1, 2016 |  | July 3, 2015 |  | Change |  | % Change |  |
| Other income (expense), net |  | $ | (171 | ) | $ | (88 | ) | $ | (83 | ) |  | 94 | % |

[0001047469-16-014732:mdna:89]
Other
income (expense), net for fiscal year 2016 increased by $83 million, as compared to fiscal year 2015 primarily due to the absence of partial receipt of $143 million
for interest accrued on the final arbitration award amount in the Company's case against Western Digital in fiscal year 2015 compared to $33 million in fiscal year 2016, and a
$33 million change in foreign currency remeasurement related to net gains and losses from changes in foreign exchange rates, which were more pronounced in the prior year, partially offset by
$74 million of losses from the early redemptions and repurchases of debt in fiscal year 2015 compared to a $3 million gain from the early redemptions and repurchases of debt in fiscal
year 2016.

[0001047469-16-014732:mdna:90]
Income Taxes

[0001047469-16-014732:mdna:91]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 1, 2016 |  | July 3, 2015 |  | Change |  | % Change |  |
| Provision for income taxes |  | $ | 26 |  | $ | 228 |  | $ | (202 | ) |  | (89 | )% |

[0001047469-16-014732:mdna:92]
We
recorded an income tax provision of $26 million for fiscal year 2016 compared to an income tax provision of $228 million for fiscal year 2015. Our fiscal year 2016
income tax provision included approximately $22 million of income tax benefits primarily associated with the release of tax reserves due to the expiration of certain statutes of limitation. Our
fiscal year 2015 income tax provision included approximately $193 million of net income tax expense due to the final audit assessment received from the Jiangsu Province State Tax Bureau of the
People's Republic of China (China assessment) for calendar years 2007 through 2013.

[0001047469-16-014732:mdna:93]
Our
Irish tax resident parent holding company owns various U.S. and non-U.S. subsidiaries that operate in multiple non-Irish income tax jurisdictions. Our worldwide operating income is
either subject to varying rates of income tax or is exempt from income tax due to tax holiday programs we operate under in Malaysia, Singapore and Thailand. These tax holidays are scheduled to expire
in whole or in part at various dates through 2024.

[0001047469-16-014732:mdna:94]
Our
income tax provision recorded for fiscal year 2016 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before
income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are
considered indefinitely reinvested outside of Ireland, (ii) tax benefits associated with the reversal of previously recorded taxes, and (iii) a decrease in valuation allowance for
certain deferred tax assets. The acquisition of Dot Hill System Corporation did not have a material impact on our effective tax rate. Our income tax provision recorded for fiscal year 2015 differed
from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related
to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) tax expense
associated with the China assessment recorded during the December 2014 quarter, and (iii) an increase
in valuation allowance for certain deferred tax assets. The acquisition of LSI's Flash Business did not have a material impact on our effective tax rate.

[0001047469-16-014732:mdna:95]
On
December 18, 2015, the Protecting Americans from Tax Hikes ("PATH") Act of 2015 was enacted. Among, other provisions, the PATH Act retroactively reinstated and permanently
extended the federal Research and Development ("R&D") tax credit from December 31, 2014. The permanent extension of the R&D credit had no immediate impact on our income tax provision due to
valuation allowances on our U.S. deferred tax assets. None of the other PATH Act changes had a material impact on our income tax provision.

[0001047469-16-014732:mdna:96]
Based
on our non-U.S. ownership structure and subject to (i) potential future increases in our valuation allowance for deferred tax assets; and (ii) a future change in our
intention to indefinitely reinvest earnings from our subsidiaries outside of Ireland, we anticipate that our effective tax rate in future periods will generally be less than the Irish statutory rate.

[0001047469-16-014732:mdna:97]
At
July 1, 2016, our deferred tax asset valuation allowance was approximately $984 million.

[0001047469-16-014732:mdna:98]
At
July 1, 2016, we had net deferred tax assets of $606 million. The realization of these deferred tax assets is primarily dependent on our ability to generate sufficient
U.S. and certain non-U.S. taxable income in future periods. Although realization is not assured, we believe that it is more likely than not that these deferred tax assets will be realized. The amount
of deferred tax assets considered realizable, however, may increase or decrease in subsequent periods when we re-evaluate the underlying basis for our estimates of future U.S. and certain non-U.S.
taxable income.

[0001047469-16-014732:mdna:99]
As
of July 1, 2016, approximately $677 million of our U.S. net operating losses and $99 million of our tax credit carryforwards are subject to annual limitations
from $1 million to $45 million pursuant to U.S. tax law.

[0001047469-16-014732:mdna:100]
As
of July 1, 2016 and July 3, 2015, we had approximately $70 million and $83 million, respectively, of unrecognized tax benefits excluding interest and
penalties. The amount of unrecognized tax benefits that, if recognized, would impact the effective tax rate are $70 million and $83 million as of July 1, 2016 and July 3,
2015, respectively, subject to certain future valuation allowance offsets.

[0001047469-16-014732:mdna:101]
It
is our policy to include interest and penalties related to unrecognized tax benefits in the provision for income taxes on our Consolidated Statements of Operations. During fiscal year
2016, we recognized a net income tax benefit for interest and penalties of $8 million as compared to a net income tax expense for interest and penalties of $26 million during fiscal year
2015 and $8 million during fiscal year 2014. As of July 1, 2016, we had $12 million of accrued interest and penalties related to unrecognized tax benefits compared to
$20 million in fiscal year 2015.

[0001047469-16-014732:mdna:102]
During
the fiscal year ended July 1, 2016, our unrecognized tax benefits excluding interest and penalties decreased by approximately $13 million primarily due to
(i) reductions associated with the expiration of certain statutes of limitation of $27 million, (ii) increases in current year unrecognized tax benefits of $11 million,
(iii) net increases in prior years' unrecognized tax benefits of $4 million, (iv) net reductions from other activity, including non-U.S. exchange gains, of $1 million.

[0001047469-16-014732:mdna:103]
During
the 12 months beginning July 2, 2016, we expect that our unrecognized tax benefits could be reduced by approximately $16 million as a result of the expiration
of certain statutes of limitation.

[0001047469-16-014732:mdna:104]
We
are subject to taxation in many jurisdictions globally and are required to file U.S. federal, U.S. state, and non-U.S income tax returns. On April 4, 2016, the IRS
approved the audit settlement reached in December 2015 regarding all disputed issues associated with our U.S. federal income tax returns for fiscal years 2008, 2009 and 2010. This audit settlement did
not have a material impact on our financial statements.

[0001047469-16-014732:mdna:105]
We
are no longer subject to tax examination of U.S. federal income tax returns for years prior to fiscal year 2013. With respect to U.S. state and non-U.S. income tax returns, we are
generally no longer subject to tax examination for years ending prior to fiscal year 2005.

[0001047469-16-014732:mdna:106]
Fiscal Year 2015 Compared to Fiscal Year 2014

[0001047469-16-014732:mdna:107]
Revenue

[0001047469-16-014732:mdna:108]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |  | Change |  | % Change |  |
| Revenue |  | $ | 13,739 |  | $ | 13,724 |  | $ | 15 |  |  | 0.1 | % |

[0001047469-16-014732:mdna:109]
Revenue
in fiscal year 2015 remained flat from fiscal year 2014, as a result of revenue contributed from our acquisitions of Xyratex and LSI's Flash Business and a favorable product mix,
partially offset by a 4% decrease in units shipped and moderate price erosion.

[0001047469-16-014732:mdna:110]
Cost of Revenue and Gross Margin

[0001047469-16-014732:mdna:111]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |  | Change |  | % Change |  |
| Cost of revenue |  | $ | 9,930 |  | $ | 9,878 |  | $ | 52 |  |  | 1 | % |
| Gross margin |  | $ | 3,809 |  | $ | 3,846 |  | $ | (37 | ) |  | (1 | )% |
| Gross margin percentage |  |  | 28 | % |  | 28 | % |  |  |  |  |  |  |

[0001047469-16-014732:mdna:112]
For
fiscal year 2015, gross margin as a percentage of revenue remained flat from the prior fiscal year as a result of improved product mix and cost savings due to increased operational
efficiencies, offset by moderate price erosion.

[0001047469-16-014732:mdna:113]
Operating Expenses

[0001047469-16-014732:mdna:114]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |  | Change |  | % Change |  |
| Product development |  | $ | 1,353 |  | $ | 1,226 |  | $ | 127 |  |  | 10 | % |
| Marketing and administrative |  |  | 857 |  |  | 722 |  |  | 135 |  |  | 19 | % |
| Amortization of intangibles |  |  | 129 |  |  | 98 |  |  | 31 |  |  | 32 | % |
| Restructuring and other, net |  |  | 32 |  |  | 24 |  |  | 8 |  |  | 33 | % |
| Gain on arbitration award, net |  |  | (620 | ) |  | — |  |  | (620 | ) |  | (100 | )% |
| Operating expenses |  | $ | 1,751 |  | $ | 2,070 |  | $ | (319 | ) |  |  |  |

[0001047469-16-014732:mdna:115]
Product Development Expense.    Product development expenses for fiscal year 2015 increased from fiscal year 2014 mostly due to an
increase in headcount
related costs of $111 million attributed to the consolidation of Xyratex and LSI's Flash Business as well as a 53-week fiscal year in 2015 compared to 52 weeks in 2014.

[0001047469-16-014732:mdna:116]
Marketing and Administrative Expense.    Marketing and administrative expenses for fiscal year 2015 increased from fiscal year 2014
primarily due to an
increase in headcount related costs of $50 million attributed to the consolidation of Xyratex and LSI's Flash Business, non-recurring legal cost reimbursement received in fiscal year 2014 of
$24 million, as well as a 53-week fiscal year in 2015 compared to 52 weeks in 2014.

[0001047469-16-014732:mdna:117]
Amortization of Intangibles.    Amortization of intangibles for fiscal year 2015 increased by $31 million, as compared to fiscal year
2014, as a
result of the acquisitions of LSI's Flash Business and Xyratex.

[0001047469-16-014732:mdna:118]
Restructuring and Other, net.    Restructuring and other, net for fiscal year 2015 increased by $8 million, as compared to fiscal year
2014
primarily due to a restructuring charge recorded during the March 2015 quarter to reduce workforce as a result of our ongoing focus on cost efficiencies in all areas of our business.

[0001047469-16-014732:mdna:119]
Gain on arbitration award, net.    Gain on arbitration award, net for fiscal year 2015 increased from fiscal year 2014 due to final award
received in
the amount of $630 million, less litigation and other related costs of $10 million, in the Company's case against Western Digital for the misappropriation of the Company's trade secrets.

[0001047469-16-014732:mdna:120]
Other income (expense), net

[0001047469-16-014732:mdna:121]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |  | Change |  | % Change |  |
| Other income (expense), net |  | $ | (88 | ) | $ | (220 | ) | $ | 132 |  |  | (60 | )% |

[0001047469-16-014732:mdna:122]
Other
income (expense), net for fiscal year 2015 decreased by $132 million, as compared to fiscal year 2014 primarily due to the partial payment of $143 million for
interest accrued on the final arbitration award amount in our case against Western Digital and a decrease in losses from early redemption and repurchase of debt of $15 million, partially offset
by a $12 million increase in interest expense.

[0001047469-16-014732:mdna:123]
52

[0001047469-16-014732:mdna:124]
Income Taxes

[0001047469-16-014732:mdna:125]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 3, 2015 |  | June 27, 2014 |  | Change |  | % Change |  |
| Provision for (benefit from) income taxes |  | $ | 228 |  | $ | (14 | ) | $ | 242 |  |  | 1,729 | % |

[0001047469-16-014732:mdna:126]
We
recorded an income tax provision of $228 million for fiscal year 2015 compared to an income tax benefit of $14 million for fiscal year 2014. Our fiscal year 2015 income
tax provision included approximately $193 million of net income tax expense due to the final audit assessment received from the Jiangsu Province State Tax Bureau of the People's Republic of
China (China assessment) for calendar years 2007 through 2013. Our fiscal year 2014 benefit from income taxes included $58 million of income tax benefits related to the reversal of a portion of
the valuation allowances recorded in prior periods and a net decrease in tax reserves related to audit settlements offset by tax reserves on non-U.S. tax positions taken in prior fiscal years.

[0001047469-16-014732:mdna:127]
Our
income tax provision recorded for fiscal year 2015 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before
income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are
considered indefinitely reinvested outside of Ireland, (ii) tax expense associated with the China assessment recorded during the December 2014 quarter, and (iii) an increase in valuation
allowance for certain deferred tax assets. The acquisition of LSI's Flash Business did not have a material impact on our effective tax rate. Our income tax benefit recorded for fiscal year 2014
differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits
related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, and (ii) a
decrease in valuation allowance for certain deferred tax assets. The acquisition of Xyratex did not have a material impact on our effective tax rate in fiscal year 2014. Fiscal year 2014 included a
valuation allowance release associated with post-acquisition restructuring.

[0001047469-16-014732:mdna:128]
Liquidity and Capital Resources

[0001047469-16-014732:mdna:129]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and
capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist primarily
of money market funds and certificates of deposits. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents
and short-term investments are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However,
these restrictions have not impeded our ability to conduct our business, nor do we expect them to in the next 12 months. We are not aware of any downgrades, losses or other significant
deterioration in the fair value of our cash equivalents or short-term investments and we do not believe the fair value of our short-term investments has significantly changed from the values reported
as of July 1, 2016.

[0001047469-16-014732:mdna:130]
Cash and Cash Equivalents and Short-term Investments

[0001047469-16-014732:mdna:131]
|  |  | As of |  |
| (Dollars in millions) |  | July 1, 2016 |  | July 3, 2015 |  | Change |  |
| Cash and cash equivalents |  | $ | 1,125 |  | $ | 2,479 |  | $ | (1,354 | ) |
| Short-term investments |  |  | 6 |  |  | 6 |  |  | — |  |
| Total |  | $ | 1,131 |  | $ | 2,485 |  | $ | (1,354 | ) |

[0001047469-16-014732:mdna:132]
Our
cash and cash equivalents and short-term investments decreased from July 3, 2015 as a result of net cash outflows for the acquisition of Dot Hill of $674 million,
repurchase of our ordinary shares of $1.1 billion, dividends paid to our shareholders of $727 million, and capital expenditures of $587 million. These cash outflows were partially
offset by our net cash provided by operating activities. The following table summarizes results from the statement of cash flows for the periods indicated:

[0001047469-16-014732:mdna:133]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |  |
| Net cash flow provided by (used in): |  |  |  |  |  |  |  |  |  |  |
| Operating activities |  | $ | 1,680 |  | $ | 2,647 |  | $ | 2,558 |  |
| Investing activities |  |  | (1,211 | ) |  | (1,287 | ) |  | (322 | ) |
| Financing activities |  |  | (1,820 | ) |  | (1,495 | ) |  | (1,311 | ) |
| Effect of foreign currency exchange rates |  |  | (3 | ) |  | (20 | ) |  | 1 |  |
| Net (decrease) increase in cash and cash equivalents |  | $ | (1,354 | ) | $ | (155 | ) | $ | 926 |  |

[0001047469-16-014732:mdna:134]
Cash Provided by Operating Activities

[0001047469-16-014732:mdna:135]
Cash provided by operating activities for fiscal year2016 was approximately $1.7 billion and includes the effects of net income
adjusted for non-cash items including depreciation and amortization, stock-based compensation, and:

[0001047469-16-014732:mdna:136]
•

[0001047469-16-014732:mdna:137]
a decrease in revenue accelerating a reduction in the cash conversion cycle, leading to a decrease in working capital.

[0001047469-16-014732:mdna:138]
Cash
provided by operating activities for fiscal year 2015 was approximately $2.6 billion and includes the effects of net income adjusted for non-cash items including
depreciation, amortization, stock-based compensation. Net income includes:

[0001047469-16-014732:mdna:139]
•

[0001047469-16-014732:mdna:140]
a partial payment of $773 million for the arbitration award and related accrued interest received from Western Digital; and

[0001047469-16-014732:mdna:141]
•

[0001047469-16-014732:mdna:142]
a $225 million payment related to the final audit assessment received from the Jiangsu Province State Tax Bureau of the
People's Republic of China for tax and interest associated with changes to our tax filings for the calendar years 2007 through 2013.

[0001047469-16-014732:mdna:143]
Cash
provided by operating activities for fiscal year 2014 was approximately $2.6 billion and includes the effects of net income adjusted for non-cash items including
depreciation, amortization, stock-based compensation, and:

[0001047469-16-014732:mdna:144]
•

[0001047469-16-014732:mdna:145]
a decrease of $217 million in vendor non-trade receivables primarily related to a change in the contractual relationship with
some of our contract manufacturers which reduced the volume of components we sold to them;

[0001047469-16-014732:mdna:146]
•

[0001047469-16-014732:mdna:147]
a decrease of $190 million in accounts payable due to a change in the contractual relationship with some of our contract
manufacturers which resulted in a reduction in direct materials purchased and subsequently sold to our contract manufacturers; and

[0001047469-16-014732:mdna:148]
•

[0001047469-16-014732:mdna:149]
a decrease of $104 million in restricted cash and investments primarily due to the restricted cash and investments held in a
rabbi trust being replaced with a standby letter of credit.

[0001047469-16-014732:mdna:150]
Cash Used in Investing Activities

[0001047469-16-014732:mdna:151]
In fiscal year 2016, we used $1.2 billion for net cash investing activities, which was primarily due to payments for the
purchase of property, equipment and leasehold improvements of approximately $587 million and the acquisition of Dot Hill, net of cash acquired for $634 million.

[0001047469-16-014732:mdna:152]
54

[0001047469-16-014732:mdna:153]
In
fiscal year 2015, we used $1.3 billion for net cash investing activities, which was primarily due to payments for the purchase of property, equipment and leasehold improvements
of approximately $747 million and the acquisition of LSI's Flash Business for $450 million.

[0001047469-16-014732:mdna:154]
In
fiscal year 2014, we used $0.3 billion for net cash investing activities, which was primarily due to payments for property, equipment and leasehold improvements of
approximately $559 million and the acquisition of Xyratex for $285 million, partially offset by $508 million of proceeds from sales of short-term investments.

[0001047469-16-014732:mdna:155]
Cash Used in Financing Activities

[0001047469-16-014732:mdna:156]
Net cash used in financing activities of $1.8 billion for fiscal year 2016 was primarily attributable to the following
activities:

[0001047469-16-014732:mdna:157]
•

[0001047469-16-014732:mdna:158]
$1.1 billion paid to repurchase 24 million of our ordinary shares; and

[0001047469-16-014732:mdna:159]
•

[0001047469-16-014732:mdna:160]
$0.7 billion in dividends paid to our shareholders.

[0001047469-16-014732:mdna:161]
Net
cash used in financing activities of $1.5 billion for fiscal year 2015 was primarily attributable to the following
activities:

[0001047469-16-014732:mdna:162]
•

[0001047469-16-014732:mdna:163]
$1.1 billion paid to repurchase 19 million of our ordinary shares;

[0001047469-16-014732:mdna:164]
•

[0001047469-16-014732:mdna:165]
$1.0 billion for the repurchase and redemption of long-term debt;

[0001047469-16-014732:mdna:166]
•

[0001047469-16-014732:mdna:167]
$0.7 billion in dividends paid to our shareholders; partially offset by

[0001047469-16-014732:mdna:168]
•

[0001047469-16-014732:mdna:169]
proceeds of $1.2 billion from aggregate cash generated from the issuance of our 5.75% Senior Notes due 2034 and 4.875% Senior
Notes due 2027.

[0001047469-16-014732:mdna:170]
Net
cash used in financing activities of $1.3 billion for fiscal year 2014 was attributable to the following activities:

[0001047469-16-014732:mdna:171]
•

[0001047469-16-014732:mdna:172]
$1.9 billion paid to repurchase 41 million of our ordinary shares;

[0001047469-16-014732:mdna:173]
•

[0001047469-16-014732:mdna:174]
$0.7 billion for the repurchase and redemption of long-term debt;

[0001047469-16-014732:mdna:175]
•

[0001047469-16-014732:mdna:176]
$0.6 billion in dividends paid to our shareholders; partially offset by

[0001047469-16-014732:mdna:177]
•

[0001047469-16-014732:mdna:178]
proceeds of $1.8 billion from aggregate cash generated from the issuance of our 3.75% Senior Notes due in 2018 and 4.75% Senior
Notes due in 2025.

[0001047469-16-014732:mdna:179]
Liquidity Sources

[0001047469-16-014732:mdna:180]
Our primary sources of liquidity as of July 1, 2016, consisted of: (1) approximately $1.1 billion in cash and cash
equivalents, and short-term investments, (2) cash we expect to generate from operations and (3) a $700 million senior revolving credit facility.

[0001047469-16-014732:mdna:181]
As
of July 1, 2016, no borrowings had been drawn under the revolving credit facility or had been utilized for letters of credit issued under this credit facility. The line of
credit is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001047469-16-014732:mdna:182]
The
credit agreement that governs our revolving credit facility, as amended, contains certain covenants that we must satisfy in order to remain in compliance with the credit agreement,
as amended. The agreement includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net
leverage ratio. On April 28, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to adjust for our current financial liquidity position. We
were in compliance with the modified covenants as of July 1, 2016 and expect to be in compliance for the next 12 months.

[0001047469-16-014732:mdna:183]
As
of July 1, 2016, cash and cash equivalents held by non-Irish subsidiaries was $1.1 billion. This amount is potentially subject to taxation in Ireland upon repatriation
by means of a dividend into our Irish parent. However, it is our intent to indefinitely reinvest earnings of non-Irish subsidiaries outside of

[0001047469-16-014732:mdna:184]
55

[0001047469-16-014732:mdna:185]
Ireland
and our current plans do not demonstrate a need to repatriate such earnings by means of a taxable Irish dividend. Should funds be needed in the Irish parent company and should we be unable to
fund parent company activities through means other than a taxable Irish dividend, we would be required to accrue and pay Irish taxes on such dividend.

[0001047469-16-014732:mdna:186]
We
believe that our sources of cash will be sufficient to fund our operations and meet our cash requirements for at least the next 12 months.

[0001047469-16-014732:mdna:187]
Cash Requirements and Commitments

[0001047469-16-014732:mdna:188]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund
scheduled payments of principal and interest on our indebtedness, and to fund our dividend. Our ability to fund these requirements will depend on our future cash flows, which are determined by future
operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001047469-16-014732:mdna:189]
On
August 2, 2016, our Board of Directors approved a quarterly cash dividend of $0.63 per share, which will be payable on October 5, 2016 to shareholders of record as of
the close of business on September 21, 2016.

[0001047469-16-014732:mdna:190]
As
of July 1, 2016, we were in compliance with all of the covenants under our debt agreements. Based on our current outlook, we expect to be in compliance with the covenants of
our debt agreements over the next 12 months.

[0001047469-16-014732:mdna:191]
The
carrying value of our long-term debt as of July 1, 2016 and July 3, 2015 was $4.1 billion and $4.2 billion, respectively. The table below presents the
principal amounts of our outstanding long-term debt:

[0001047469-16-014732:mdna:192]
|  |  | As of |  |
| (Dollars in millions) |  | July 1, 2016 |  | July 3, 2015 |  | Change |  |
| 3.75% Senior Notes due November 2018 |  | $ | 800 |  | $ | 800 |  | $ | — |  |
| 7.00% Senior Notes due November 2021 |  |  | 158 |  |  | 158 |  |  | — |  |
| 4.75% Senior Notes due June 2023 |  |  | 990 |  |  | 1,000 |  |  | (10 | ) |
| 4.75% Senior Notes due January 2025 |  |  | 995 |  |  | 1,000 |  |  | (5 | ) |
| 4.875% Senior Notes Due June 2027 |  |  | 700 |  |  | 700 |  |  | — |  |
| 5.75% Senior Notes Due December 2034 |  |  | 490 |  |  | 500 |  |  | (10 | ) |
| Total |  | $ | 4,133 |  | $ | 4,158 |  | $ | (25 | ) |

[0001047469-16-014732:mdna:193]
From time to time we may repurchase any of our outstanding ordinary shares through private, open market, tender offers, broker assisted purchases or other means.
During fiscal year 2016, we repurchased approximately 24 million of our ordinary shares. See "Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer
Purchases of Equity Securities-Repurchases of Our Equity Securities." As of July 1, 2016, $1.8 billion remained available for repurchase under our existing repurchase authorization
limit. All repurchases are effected as redemptions in accordance with the Company's Articles of Association.

[0001047469-16-014732:mdna:194]
For
fiscal year 2017, we expect capital expenditures to be below our long-term targeted range of 6% to 8% of revenue. We require substantial amounts of cash to fund scheduled payments of
principal and interest on our indebtedness, future capital expenditures and any increased working capital requirements. We will continue to evaluate and manage the retirement and replacement of
existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to
privately negotiated transactions, open market purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions and investments, which may
require additional capital.

[0001047469-16-014732:mdna:195]
Contractual Obligations and Commitments

[0001047469-16-014732:mdna:196]
Our contractual cash obligations and commitments as of July 1, 2016, have been summarized in the table below:

[0001047469-16-014732:mdna:197]
|  |  |  |  | Fiscal Year(s) |  |
| (Dollars in millions) |  | Total |  | 2017 |  | 2018- 2019 |  | 2020- 2021 |  | Thereafter |  |
| Contractual Cash Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | $ | 4,133 |  | $ | — |  | $ | 800 |  | $ | — |  | $ | 3,333 |  |
| Interest payments on debt |  |  | 1,761 |  |  | 198 |  |  | 381 |  |  | 334 |  |  | 848 |  |
| Purchase obligations(2) |  |  | 713 |  |  | 713 |  |  | — |  |  | — |  |  | — |  |
| Operating leases(1) |  |  | 168 |  |  | 27 |  |  | 38 |  |  | 21 |  |  | 82 |  |
| Capital expenditures |  |  | 110 |  |  | 110 |  |  | — |  |  | — |  |  | — |  |
| Other funding requirements(3) |  |  | 44 |  |  | 12 |  |  | 24 |  |  | 8 |  |  | — |  |
| Subtotal |  |  | 6,929 |  |  | 1,060 |  |  | 1,243 |  |  | 363 |  |  | 4,263 |  |
| Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit or bank guarantees |  |  | 108 |  |  | 108 |  |  | — |  |  | — |  |  | — |  |
| Total |  | $ | 7,037 |  | $ | 1,168 |  | $ | 1,243 |  | $ | 363 |  | $ | 4,263 |  |

[0001047469-16-014732:mdna:198]
(1)

[0001047469-16-014732:mdna:199]
Includes
total future minimum rent expense under non-cancelable leases for both occupied and vacated facilities (rent expense is shown net of sublease
income).

[0001047469-16-014732:mdna:200]
(2)

[0001047469-16-014732:mdna:201]
Purchase
obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that
specify all significant terms.

[0001047469-16-014732:mdna:202]
(3)

[0001047469-16-014732:mdna:203]
Consists
of funding requirements related to strategic commitments.

[0001047469-16-014732:mdna:204]
As
of July 1, 2016, we had a liability for unrecognized tax benefits and an accrual for the payment of related interest totaling $13 million, none of which is expected to
be settled within one year. Outside of one year, we are unable to make a reasonably reliable estimate of when cash settlement with a taxing authority will occur.

[0001047469-16-014732:mdna:205]
Off-Balance Sheet Arrangements

[0001047469-16-014732:mdna:206]
As of July 1, 2016, we did not have any material off-balance sheet arrangements (as defined in Item 303(a)(4)(ii) of
Regulation S-K).

[0001047469-16-014732:mdna:207]
Critical Accounting Policies

[0001047469-16-014732:mdna:208]
The methods, estimates and judgments we use in applying our most critical accounting policies have a significant impact on the results
we report in our consolidated financial statements. The SEC has defined the most critical accounting policies as the ones that are most important to the portrayal of our financial condition and
operating results, and require us to make our most difficult and subjective judgments, often as a result of the need to make estimates of matters that are highly uncertain at the time of estimation.
Based on this definition, our most critical policies include: establishment of sales program accruals, establishment of warranty accruals, accounting for income taxes, and the accounting for goodwill
and other long-lived assets. Below, we discuss these policies further, as well as the estimates and judgments involved. We also have other accounting policies and accounting estimates relating to
uncollectible customer accounts, valuation of inventory, valuation of share-based payments and restructuring. We believe that these other accounting policies and accounting estimates either do not
generally require us to make estimates and judgments that are as difficult or as subjective, or it is less likely that they would have a material impact on our reported results of operations for a
given period.

[0001047469-16-014732:mdna:209]
Establishment of Sales Program Accruals.    We establish certain distributor and OEM sales programs aimed at increasing customer demand.
For OEM sales,
rebates are typically based on an OEM
customer's volume of purchases or other agreed upon rebate programs. For the distribution channel, these programs typically involve rebates related to a distributor's level of sales, order size,
advertising or point of sale activity and price protection adjustments. We provide for these obligations at the time that revenue is recorded based on estimated requirements. We estimate these
contra-revenue rebates and adjustments based on various factors, including price reductions during the period reported, estimated future price erosion, customer orders, distributor sell-through and
inventory levels, program participation, customer claim submittals and sales returns. Our estimates reflect contractual arrangements but also our judgment relating to variables such as customer claim
rates and attainment of program goals, and inventory and sell-through levels reported by our distribution customers. Currently, our distributors' inventories are within the historical range.

[0001047469-16-014732:mdna:210]
While
we believe we have sufficient experience and knowledge of the market and customer buying patterns to reasonably estimate such rebates and adjustments, actual market conditions or
customer behavior could differ from our expectations. As a result, actual payments under these programs, which may spread over several months after the related sale, may vary from the amount accrued.
Accordingly, revenues and margins in the period in which the adjustment occurs may be affected.

[0001047469-16-014732:mdna:211]
Significant
actual variations in any of the factors upon which we base our contra-revenue estimates could have a material effect on our operating results. In fiscal year 2016, sales
programs were approximately 13% of gross revenue. For fiscal years 2015 and 2014, total sales programs ranged from 8% to 10% of gross revenues. Adjustments to revenues due to under or over accruals
for sales programs related to revenues reported in prior quarterly periods were approximately 0.1% of gross revenue in fiscal year 2016 and averaged 0.3% of quarterly gross revenue for fiscal year
2015 through 2014. Any future shifts in the industry supply-demand balance as well as other factors may result in a more competitive pricing environment and may cause sales programs as a percentage of
gross revenue to increase from the current or historical levels. If such rebates and incentives trend upwards, revenues and margins may be reduced.

[0001047469-16-014732:mdna:212]
Establishment of Warranty Accruals.    We estimate probable product warranty costs at the time revenue is recognized. We generally warrant
our products
for a period of 1 to 5 years. Our warranty provision considers estimated product failure rates and trends (including the timing of product returns during the warranty periods), and estimated
repair or replacement costs related to product quality issues, if any. We also exercise judgment in estimating our ability to sell certain repaired products. Should actual experience in any future
period differ significantly from our estimates, our future results of operations could be materially affected. Our judgment is subject to a greater degree of subjectivity with respect to

[0001047469-16-014732:mdna:213]
newly
introduced products because of limited experience with those products upon which to base our warranty estimates.

[0001047469-16-014732:mdna:214]
The
actual results with regard to warranty expenditures could have an adverse or favorable effect on our results of operations if the actual rate of unit failure, the cost to repair a
unit, or the actual cost required to satisfy customer claims differs from those estimates we used in determining the warranty accrual. Since we typically outsource our warranty repairs, our repair
cost is subject to periodic negotiations with vendors and may vary from our estimates. We also exercise judgment in estimating our ability to sell certain repaired products. To the extent such sales
fall below our forecast, warranty cost will be adversely impacted.

[0001047469-16-014732:mdna:215]
We
review our warranty accrual quarterly for products shipped in prior periods and which are still under warranty. Any changes in the estimates underlying the accrual may result in
adjustments that impact the current period gross margins and income. In fiscal years 2016, 2015 and 2014 net changes in estimates of prior warranty accruals as a percentage of revenue were immaterial.
Our total warranty cost was 1.0%, 1.1% and 1.3% of revenue during fiscal years 2016, 2015 and 2014, respectively, while warranty cost related to new shipments (exclusive of the impact of re-estimates
of pre-existing liabilities) were 1.1%, 1.1% and 1.3% respectively, for the same periods. Changes in anticipated failure rates of specific products and significant changes in repair or replacement
costs have historically been the major reasons for significant changes in prior estimates. Any future changes in failure rates of certain products, as well as changes in repair costs or the cost of
replacement parts, may result in increased or decreased warranty accruals.

[0001047469-16-014732:mdna:216]
Accounting for Income Taxes.    We account for income taxes pursuant to Accounting Standards Codification ("ASC") Topic 740 ("ASC 740"),
Income Taxes.
In applying, ASC 740, we make certain estimates and judgments in determining income tax expense for financial statement purposes. These estimates and judgments occur in the calculation of tax credits,
recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for tax and financial
statement purposes, as well as tax liabilities associated with uncertain tax positions. The calculation of tax liabilities involves uncertainties in the application of complex tax rules and the
potential for future adjustment of our uncertain tax positions by the Internal Revenue Service or other tax jurisdictions. If estimates of these tax liabilities are greater or less than actual
results, an additional tax benefit or provision will result. The deferred tax assets we record each period depend primarily on our ability to generate future taxable income in the United States and
certain non-U.S. jurisdictions. Each period, we evaluate the need for a valuation allowance for our deferred tax assets and, if necessary, we adjust the valuation allowance so that net deferred tax
assets are recorded only to the extent we conclude it is more likely than not that these deferred tax assets will be realized. If our outlook for future taxable income changes significantly, our
assessment of the need for a valuation allowance may also change.

[0001047469-16-014732:mdna:217]
Assessing Goodwill and Other Long-lived Assets for Impairment.    We account for goodwill in accordance with ASC Topic 350,
Intangibles—Goodwill and Other. As permitted by ASC 350, we perform a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment
exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely
than not reduce the fair value of a reporting unit below its carrying amount. Based on the qualitative assessment, if it is not more likely than not that the fair value of a reporting unit is less
than its carrying amount, then the Company is not required to perform the two-step goodwill impairment test. If it is determined in the qualitative assessment that the fair value of a reporting unit
is more likely than not below its carrying amount, including goodwill, then we perform a quantitative two-step impairment test. The first step, identifying a potential impairment, compares the fair
value of a reporting unit with its carrying amount, including goodwill. If the carrying value of the reporting unit exceeds its fair value, the second step would need to be conducted. The second step,
measuring the impairment loss, compares the implied fair value of

[0001047469-16-014732:mdna:218]
59

[0001047469-16-014732:mdna:219]
the
reporting unit goodwill with the carrying amount of that goodwill. Any excess of the reporting unit goodwill carrying value over its implied fair value is recognized as an impairment loss.

[0001047469-16-014732:mdna:220]
In
accordance with ASC 360-05-4, Impairment or Disposal of Long-lived Assets, we test other long-lived assets, including property,
equipment and leasehold improvements and other intangible assets subject to amortization, for recoverability whenever events or changes in circumstances indicate that the carrying values of those
assets may not be recoverable. We assess the recoverability of an asset group by determining if the carrying value of the asset group exceeds the sum of the projected undiscounted cash flows expected
to result from the use and eventual disposition of the assets over the remaining economic life of the primary asset in the asset group. If the recoverability test indicates that the carrying value of
the asset group is not recoverable, we will estimate the fair value of the asset group and compare it to its carrying value. The excess of the carrying value over the fair value is allocated pro rata
to derive the adjusted carrying value of each asset in the asset group. The adjusted carrying value of each asset in the asset group is not reduced below its fair value.

[0001047469-16-014732:mdna:221]
Recent Accounting Pronouncements

[0001047469-16-014732:mdna:222]
See "Item 8. Financial Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of
Significant Accounting Policies" for information regarding the effect of new accounting pronouncements on our financial statements.
