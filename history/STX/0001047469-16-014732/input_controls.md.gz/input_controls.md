# STX 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001047469-16-014732:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0001047469-16-014732:item_9a:2]
Conclusions Regarding Disclosure Controls and Procedures

[0001047469-16-014732:item_9a:3]
Our chief executive officer and our chief financial officer have concluded, based on the evaluation of the effectiveness of our
disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) of the Securities Exchange Act of 1934, as amended) by our management, with the participation of our chief
executive officer and our chief financial officer, that our disclosure controls and procedures were effective as of July 1, 2016.

[0001047469-16-014732:item_9a:4]
Management's Report on Internal Control over Financial Reporting

[0001047469-16-014732:item_9a:5]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as defined in
Rules 13a-15(f) and 15d-15(f) under the Securities Exchange Act of 1934, as amended). Under the supervision and with the participation of our management, including our chief executive officer
and chief financial officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting based on the framework in Internal Control-Integrated Framework (2013)
issued by the Committee of Sponsoring Organizations of the Treadway Commission, or COSO.

[0001047469-16-014732:item_9a:6]
Based
on our evaluation under the 2013 framework in Internal Control—Integrated Framework, our management has concluded that
our internal control over financial reporting was effective as of July 1, 2016. The effectiveness of our internal control over financial reporting as of July 1, 2016 has been audited by
Ernst & Young LLP, the independent registered public accounting firm that audited our financial statements included in this Form 10-K, as stated in their report that is included
herein.

[0001047469-16-014732:item_9a:7]
Changes in Internal Control over Financial Reporting

[0001047469-16-014732:item_9a:8]
There were no changes in our internal control over financial reporting during our fourth fiscal quarter that have materially affected,
or are reasonably likely to materially affect, our internal control over financial reporting.

[0001047469-16-014732:item_9a:9]
Limitations on the Effectiveness of Controls

[0001047469-16-014732:item_9a:10]
Our management, including our chief executive officer and chief financial officer, does not expect that our disclosure controls and
procedures or our internal controls will prevent all errors and all fraud. A control system, no matter how well conceived and operated, can provide only reasonable, not absolute, assurance that the
objectives of the control system are met. Further, the design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to
their costs. Our disclosure controls and procedures and our internal controls have been designed to provide reasonable assurance of achieving their objectives. Because of the inherent limitations in
all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within Seagate have been detected. An evaluation was performed
under the supervision and with the participation of our management, including our chief executive officer and chief financial officer, of the effectiveness of the design and operation of our
disclosure controls and procedures as of July 1, 2016. Based on that evaluation, our management, including our chief executive officer and chief financial officer, concluded that our disclosure
controls and procedures were effective at the reasonable assurance level.

[0001047469-16-014732:item_9a:11]
117
