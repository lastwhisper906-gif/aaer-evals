# STX notes — 0001047469-16-014732


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001047469-16-014732:notes:1]
0.1


## invest:InvestmentTableTextBlock

[0001047469-16-014732:notes:2]
The following table summarizes, by major type, the fair value and amortized cost of the Company's investments as of July 3, 2015:

[0001047469-16-014732:notes:3]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 1,203 |  |  | $ | — |  |  | $ | 1,203 |  |
| Corporate bonds |  | 6 |  |  | — |  |  | 6 |  |
| Certificates of deposit |  | 867 |  |  | — |  |  | 867 |  |
| Total |  | $ | 2,076 |  |  | $ | — |  |  | $ | 2,076 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  | $ | 2,063 |  |
| Included in Short-term investments |  |  |  |  |  |  | 6 |  |
| Included in Other current assets |  |  |  |  |  |  | 7 |  |
| Total |  |  |  |  |  |  | $ | 2,076 |  |

[0001047469-16-014732:notes:4]
The following table summarizes, by major type, the fair value and amortized cost of the Company's investments as of July 1, 2016:

[0001047469-16-014732:notes:5]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 318 |  |  | $ | — |  |  | $ | 318 |  |
| Corporate bonds |  | 6 |  |  | — |  |  | 6 |  |
| Certificates of deposit |  | 444 |  |  | — |  |  | 444 |  |
| Total |  | $ | 768 |  |  | $ | — |  |  | $ | 768 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  | $ | 755 |  |
| Included in Short-term investments |  |  |  |  |  |  | 6 |  |
| Included in Other current assets |  |  |  |  |  |  | 7 |  |
| Total |  |  |  |  |  |  | $ | 768 |  |


## stx:ScheduleOfFairValueOfNonvestedSharesAndPerformanceSharesTableTextBlock

[0001047469-16-014732:notes:6]
|  | Fiscal Years |
|  | 2016 |  | 2015 |  | 2014 |
| Nonvested awards: |  |  |  |  |  |
| Weighted-average fair value | $ | 41.47 |  |  | $ | 58.93 |  |  | $ | 41.18 |  |
| Performance awards: |  |  |  |  |  |
| Weighted-average fair value | $ | 42.09 |  |  | $ | 59.51 |  |  | $ | 48.69 |  |


## stx:ScheduleOfShareBasedPaymentAwardStockOptionAndEmployeeStockPurchasePlanValuationAssumptionsAndFairValueDisclosuresTableTextBlock

[0001047469-16-014732:notes:7]
|  | Fiscal Years |
|  | 2016 |  | 2015 |  | 2014 |
| Options |  |  |  |  |  |
| Expected term (in years) | 2.1 - 4.2 |  |  | 4.2 |  |  | 4.2 |  |
| Volatility | 33 - 48% |  |  | 33 - 35% |  |  | 35 - 41% |  |
| Weighted-average volatility | 36 | % |  | 34 | % |  | 40 | % |
| Expected dividend rate | 4.6 - 11.0% |  |  | 2.9 - 4.0% |  |  | 3.1-3.8% |  |
| Weighted-average expected dividend rate | 5.6 | % |  | 3.0 | % |  | 3.7 | % |
| Risk-free interest rate | 0.6 - 1.5% |  |  | 1.1 - 1.5% |  |  | 1.2 - 1.4% |  |
| Weighted-average fair value | $ | 12.28 |  |  | $ | 12.98 |  |  | $ | 10.41 |  |
| ESPP |  |  |  |  |  |  |  |  |
| Expected term (in years) | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Volatility | 28 - 46% |  |  | 28 - 29% |  |  | 34-36% |  |
| Weighted-average volatility | 39 | % |  | 28 | % |  | 35 | % |
| Expected dividend rate | 4.6 - 8.3% |  |  | 3.0 - 3.8% |  |  | 3.3-3.5% |  |
| Weighted-average expected dividend rate | 6.9 | % |  | 3.4 | % |  | 3.4 | % |
| Risk-free interest rate | 0.5 | % |  | 0.1 | % |  | 0.1 | % |
| Weighted-average fair value | $ | 9.08 |  |  | $ | 12.21 |  |  | $ | 10.46 |  |
| Performance restricted share awards subject to market condition |  |  |  |  |  |  |  |  |
| Expected term (in years) | 3.00 |  |  | 3.00 |  |  | 3.00 |  |
| Weighted-average volatility | 30 | % |  | 40 | % |  | 46 | % |
| Expected dividend rate | 4.3 | % |  | 2.8 | % |  | 3.8 | % |
| Risk-free interest rate | 1.1 | % |  | 1.1 | % |  | 0.9 | % |
| Weighted-average fair value | $ | 47.34 |  |  | $ | 58.31 |  |  | $ | 37.51 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0001047469-16-014732:notes:8]
| (In millions) | Number ofSharesRepurchased |  | Dollar Valueof SharesRepurchased |
| Cumulative repurchased through June 28, 2013 | 244 |  |  | $ | 5,486 |  |
| Repurchased in fiscal year 2014 | 41 |  |  | 1,912 |  |
| Cumulative repurchased through June 27, 2014 | 285 |  |  | 7,398 |  |
| Repurchased in fiscal year 2015 | 19 |  |  | 1,087 |  |
| Cumulative repurchased through July 3, 2015 | 304 |  |  | 8,485 |  |
| Repurchased in fiscal year 2016(a) | 24 |  |  | 1,146 |  |
| Cumulative repurchased through July 1, 2016 | 328 |  |  | $ | 9,631 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001047469-16-014732:notes:9]
Advertising Expense.    The cost of advertising is expensed as incurred. Advertising costs were approximately $31 million, $64 million and $52 million in fiscal years 2016, 2015 and 2014, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001047469-16-014732:notes:10]
Acquisitions

[0001047469-16-014732:notes:11]
Dot Hill Systems Corp.

[0001047469-16-014732:notes:12]
On October 6, 2015 , the Company acquired all of the outstanding shares of Dot Hill Systems Corp. (“Dot Hill”), a supplier of software and hardware storage systems. The Company paid $9.75 per share, or $674 million, in cash for the acquisition. The acquisition of Dot Hill further expands the Company's OEM-focused cloud storage systems business and advances the Company's strategic efforts.

[0001047469-16-014732:notes:13]
The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the acquisition date:

[0001047469-16-014732:notes:14]
| (Dollars in millions) |  | Amount |
| Cash and cash equivalents |  | $ | 40 |  |
| Accounts receivable, net |  | 48 |  |
| Inventories |  | 21 |  |
| Other current and non-current assets |  | 7 |  |
| Property, plant and equipment |  | 10 |  |
| Intangible assets |  | 252 |  |
| Goodwill |  | 364 |  |
| Total assets |  | 742 |  |
| Accounts payable, accrued expenses and other |  | (68 | ) |
| Total liabilities |  | (68 | ) |
| Total |  | $ | 674 |  |

[0001047469-16-014732:notes:15]
The following table shows the fair value of the separately identifiable intangible assets at the time of acquisition and the period over which each intangible asset will be amortized:

[0001047469-16-014732:notes:16]
| (Dollars in millions) |  | Fair Value |  | Weighted-AverageAmortizationPeriod |
| Existing technology |  | $ | 164 |  |  | 5.0 years |
| Customer relationships |  | 71 |  |  | 7.0 years |
| Trade names |  | 3 |  |  | 5.0 years |
| Total amortizable intangible assets acquired |  | 238 |  |  | 5.5 years |
| In-process research and development |  | 14 |  |  |  |
| Total acquired identifiable intangible assets |  | $ | 252 |  |  |  |

[0001047469-16-014732:notes:17]
The recognized goodwill, which is not deductible for income tax purposes, is primarily attributable to cost synergies expected to arise after the acquisition and the benefits the Company expects to derive from enhanced market opportunities.

[0001047469-16-014732:notes:18]
The expenses related to the acquisition of Dot Hill for the fiscal year ended July 1, 2016, which are included within Marketing and administrative expense on the Consolidated Statement of Operations, are not significant.

[0001047469-16-014732:notes:19]
The amounts of revenue and earnings of Dot Hill included in the Company's Consolidated Statement of Operations from the acquisition date were not significant.

[0001047469-16-014732:notes:20]
LSI's Flash Business

[0001047469-16-014732:notes:21]
On September 2, 2014, the Company completed the acquisition of certain assets and liabilities of LSI Corporation's ("LSI") Accelerated Solutions Division and Flash Components Division (collectively, the "Flash Business") from Avago Technologies Limited for $450 million in cash. The transaction is intended to strengthen Seagate's strategy to deliver a full suite of storage solutions, providing Seagate with established enterprise PCIe flash and SSD controller capabilities to deliver solutions for the growing flash storage market.

[0001047469-16-014732:notes:22]
| (Dollars in millions) |  | Amount |
| Inventories |  | $ | 37 |  |
| Property, plant and equipment |  | 22 |  |
| Intangible assets |  | 141 |  |
| Other assets |  | 6 |  |
| Goodwill |  | 337 |  |
| Total assets |  | 543 |  |
| Liabilities |  | (93 | ) |
| Total liabilities |  | (93 | ) |
| Total |  | $ | 450 |  |

[0001047469-16-014732:notes:23]
The following table shows the fair value of the separately identifiable intangible assets at the time of acquisition and the weighted-average period over which intangible assets within each category will be amortized:

[0001047469-16-014732:notes:24]
| (Dollars in millions) |  | Fair Value |  | Weighted-AverageAmortizationPeriod |
| Existing technology |  | $ | 84 |  |  | 3.5 years |
| Customer relationships |  | 40 |  |  | 3.8 years |
| Trade names |  | 17 |  |  | 4.5 years |
| Total acquired identifiable intangible assets |  | $ | 141 |  |  |  |

[0001047469-16-014732:notes:25]
The goodwill recognized is primarily attributable to the benefits the Company expects to derive from enhanced market opportunities, and is not deductible for income tax purposes.

[0001047469-16-014732:notes:26]
The Company incurred approximately $1 million of expenses related to the acquisition of LSI's Flash Business in fiscal year 2015, which are included within Marketing and administrative expense on the Consolidated Statement of Operations.

[0001047469-16-014732:notes:27]
The amounts of revenue and earnings of LSI's Flash Business included in the Company's Consolidated Statement of Operations from the acquisition date through the end of fiscal year ended July 3, 2015 were not significant.

[0001047469-16-014732:notes:28]
Xyratex Ltd

[0001047469-16-014732:notes:29]
On March 31, 2014, the Company acquired all of the outstanding shares of Xyratex Ltd (“Xyratex”), a leading provider of data storage technology.  The Company paid $13.25 per share, or approximately $376 million in cash for the acquisition. The acquisition of Xyratex further strengthens the Company’s vertically integrated supply and manufacturing chain for disk drives and provides access to important capital requirements, as well as expands the Company’s storage solutions portfolio.

[0001047469-16-014732:notes:30]
| (Dollars in millions) |  | Amount |
| Cash and cash equivalents |  | $ | 91 |  |
| Accounts receivable, net |  | 67 |  |
| Inventories |  | 111 |  |
| Other current and non-current assets |  | 28 |  |
| Property, plant and equipment |  | 55 |  |
| Intangible assets |  | 80 |  |
| Goodwill |  | 60 |  |
| Total assets |  | 492 |  |
| Accounts payable and accrued expenses |  | (116 | ) |
| Total liabilities |  | (116 | ) |
| Total |  | $ | 376 |  |

[0001047469-16-014732:notes:31]
| (Dollars in millions) |  | Fair Value |  | Weighted-AverageAmortizationPeriod |
| Existing technology |  | $ | 23 |  |  | 5.5 years |
| Customer relationships |  | 18 |  |  | 3.9 years |
| Total amortizable intangible assets acquired |  | 41 |  |  | 4.8 years |
| In-process research and development |  | 39 |  |  |  |
| Total acquired identifiable intangible assets |  | $ | 80 |  |  |  |

[0001047469-16-014732:notes:32]
The goodwill recognized is primarily attributable to the synergies expected to arise after the acquisition, and is not deductible for income tax purposes.

[0001047469-16-014732:notes:33]
The Company incurred a total of $10 million of expenses related to the acquisition of Xyratex in fiscal year 2014, which are included within Marketing and administrative expense on the Consolidated Statement of Operations.

[0001047469-16-014732:notes:34]
The amounts of revenue and earnings of Xyratex included in the Company's Consolidated Statement of Operations from the acquisition date through the end of fiscal year ended June 27, 2014 were not significant.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001047469-16-014732:notes:35]
Summary of Significant Accounting Policies

[0001047469-16-014732:notes:36]
Cash, Cash Equivalents and Short-Term Investments.   The Company considers all highly liquid investments with a remaining maturity of 90 days or less at the time of purchase to be cash equivalents. Cash equivalents are carried at cost, which approximates fair value. The Company's short-term investments are primarily comprised of money market funds, certificates of deposits, and other interest-bearing bank deposits. The Company has classified its marketable securities as available-for-sale and they are stated at fair value with unrealized gains and losses included in Accumulated other comprehensive income (loss), which is a component of Shareholders' Equity. The Company evaluates the available-for sale securities in an unrealized loss position for other-than-temporary impairment. Realized gains and losses are included in Other, net. The cost of securities sold is based on the specific identification method.


## us-gaap:CommitmentsDisclosureTextBlock

[0001047469-16-014732:notes:37]
Commitments

[0001047469-16-014732:notes:38]
Leases. The Company leases certain property, facilities and equipment under non-cancelable lease agreements. Land and facility leases expire at various dates through 2082 and contain various provisions for rental adjustments including, in certain cases, a provision based on increases in the Consumer Price Index. Also, certain leases provide for renewal of the lease at the Company's option at expiration of the lease. All of the leases require the Company to pay property taxes, insurance and normal maintenance costs.

[0001047469-16-014732:notes:39]
Future minimum lease payments for operating leases (including accrued lease payments relating to restructuring plans) with initial or remaining terms of one year or more were as follows at July 1, 2016 (lease payments are shown net of sublease income):

[0001047469-16-014732:notes:40]
| Fiscal Years Ending |  | Operating Leases |
| (Dollars in millions) |  |  |
| 2017 |  | $ | 27 |  |
| 2018 |  | 22 |  |
| 2019 |  | 16 |  |
| 2020 |  | 12 |  |
| 2021 |  | 9 |  |
| Thereafter |  | 82 |  |
|  |  | $ | 168 |  |

[0001047469-16-014732:notes:41]
Total rent expense for all land, facility and equipment operating leases, net of sublease income, was $43 million, $50 million and $39 million for fiscal years  2016,  2015 and 2014, respectively. Total sublease rental income for fiscal years  2016,  2015 and  2014 was $3 million, $3 million and $2 million, respectively. The Company subleases a portion of its facilities that it considers to be in excess of current requirements. As of July 1, 2016, total future lease income to be recognized for the Company's existing subleases is approximately $12 million.

[0001047469-16-014732:notes:42]
Capital Expenditures.    The Company's non-cancelable commitments for construction of manufacturing and product development facilities and purchases of equipment approximated $110 million at July 1, 2016.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001047469-16-014732:notes:43]
Stock-Based Compensation.    The Company accounts for stock-based compensation under the provisions of ASC Topic 718 (ASC 718), Compensation-Stock Compensation. The Company has elected to apply the with-and-without method to assess the realization of related excess tax benefits.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001047469-16-014732:notes:44]
Comprehensive Income.    The Company presents comprehensive income in a separate statement. Comprehensive income is comprised of net income and other gains and losses affecting equity that are excluded from net income.


## us-gaap:ConsolidationPolicyTextBlock

[0001047469-16-014732:notes:45]
Basis of Presentation and Consolidation

[0001047469-16-014732:notes:46]
The consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

[0001047469-16-014732:notes:47]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles also requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its consolidated financial statements.

[0001047469-16-014732:notes:48]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Accordingly, fiscal year 2016 comprised 52 weeks and ended on July 1, 2016. Fiscal years 2015 and 2014 were comprised of 53 and 52 weeks and ended on July 3, 2015, and June 27, 2014, respectively. All references to years in these Notes to Consolidated Financial Statements represent fiscal years unless otherwise noted. Fiscal year 2017 will be 52 weeks and will end on June 30, 2017.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0001047469-16-014732:notes:49]
Restructuring Costs.     The Company records restructuring activities including costs for one-time termination benefits in accordance with ASC Topic 420 ("ASC 420"), Exit or Disposal Cost Obligations. The timing of recognition for severance costs accounted for under ASC 420 depends on whether employees are required to render service until they are terminated in order to receive the termination benefits.  If employees are required to render service until they are terminated in order to receive the termination benefits, a liability is recognized ratably over the future service period. Otherwise, a liability is recognized when management has committed to a restructuring plan and has communicated those actions to employees.  Employee termination benefits covered by existing benefit arrangements are recorded in accordance with ASC Topic 712, Non-retirement Postemployment Benefits. These costs are recognized when management has committed to a restructuring plan and the severance costs are probable and estimable.


## us-gaap:DebtDisclosureTextBlock

[0001047469-16-014732:notes:50]
Debt

[0001047469-16-014732:notes:51]
Short-Term Borrowings

[0001047469-16-014732:notes:52]
The credit agreement entered into by the Company and its subsidiary Seagate HDD Cayman on January 18, 2011 and subsequently amended (the "Revolving Credit Facility") provides the Company with a $700 million senior secured revolving credit facility. The term of the Revolving Credit Facility is through January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Revolving Credit Facility) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. The loans made under the Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing, and for the issuance of letters of credit up to a sub-limit of $75 million. The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to allow for higher net leverage levels. The Company were in compliance with the modified covenants as of July 1, 2016 and expect to be in compliance for the next 12 months. As of July 1, 2016, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

[0001047469-16-014732:notes:53]
Long-Term Debt

[0001047469-16-014732:notes:54]
$600 million Aggregate Principal Amount of 6.8% Senior Notes due October 2016 (the “2016 Notes”).   On September 20, 2006, the Company's subsidiary, Seagate Technology HDD Holdings, completed the sale of $600 million aggregate principal amount of the 2016 Notes, in a private placement exempt from the registration requirements of the Securities Act of 1933, as amended. The interest on the 2016 Notes is payable semi-annually on April 1 and October 1 of each year. The issuer under the 2016 Notes is Seagate HDD Cayman, and the obligations under the 2016 Notes are unconditionally guaranteed by certain of the Company’s significant subsidiaries. The 2016 Notes are redeemable at the option of the Company in whole or in part, on not less than 30, nor more than 60 days notice, at a "make-whole" premium redemption price. The "make-whole" redemption price will be equal to the greater of (1) 100% of the principal amount of the notes being redeemed, or (2) the sum of the present values of the remaining scheduled payments of principal and interest on the 2016 Notes being redeemed, discounted at the redemption date on a semi-annual basis at a rate equal to the sum of the applicable Treasury rate plus 50 basis points. During the December 2014 quarter, the 2016 Notes were fully extinguished through repurchase and redemption for cash at a premium to their principal amount, plus accrued and unpaid interest.  The Company recorded a loss on the repurchase and redemption of approximately $34 million, which is included in Other, net in the Company’s Consolidated Statement of Operations.

[0001047469-16-014732:notes:55]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”).  On November 5, 2013, Seagate HDD Cayman, issued $800 million in aggregate principal amount of 3.75% Senior Notes, which mature on November 15, 2018, in a private placement. The interest on the Notes is payable semi-annually on May 15 and November 15 of each year. The Notes are redeemable at the option of Seagate HDD Cayman in whole or in part, on not less than 30, nor more than 60 days' notice, at a “make-whole” premium redemption price. The “make-whole” premium redemption price will be equal to the greater of (1) 100% of the principal amount of the notes being redeemed, or (2) the sum of the present values of the remaining schedule payments of principal and interest on the Notes being redeemed, discounted at the redemption date on a semi-annual basis at a rate equal to the sum of the applicable Treasury rate plus 50 basis points. Accrued and unpaid interest, if any will be paid to, but excluding, the redemption date. The Notes are fully and unconditionally guaranteed by the Company on a senior unsecured basis.

[0001047469-16-014732:notes:56]
$600 million Aggregate Principal Amount of 6.875% Senior Notes due May 2020 (the “2020 Notes”). On May 13, 2010, the Company's subsidiary, Seagate HDD Cayman, completed the sale of $600 million aggregate principal amount of the 2020 Notes, in a private placement exempt from the registration requirements of the Securities Act of 1933, as amended. The obligations under the 2020 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.  The interest on the 2020 Notes is payable semi-annually on May 1 and November 1 of each year. The 2020 Notes were redeemable any time prior to May 1, 2015 at the option of the Company, in whole or in part, at a redemption price of 100% of the principal amount plus an “applicable premium” and accrued and unpaid interest, if any, to the redemption date. The "applicable premium" was equal to the greater of (1) 1% of the principal amount of the 2020 Notes, or (2) the excess, if any, of (a) the present value of the redemption price on May 1, 2015 plus interest payments due through May 1, 2015, discounted at the applicable Treasury rate as of the redemption date plus 50 basis points; over (b) the principal amount of such note. The 2020 Notes are redeemable at any time on or after May 1, 2015 at various prices expressed as a percentage of principal amount, as set forth in the indentures, plus accrued and unpaid interest, if any, to the redemption date. The issuer under the 2020 Notes is Seagate HDD Cayman, and the obligations under the 2020 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During fiscal year 2014, the Company repurchased $66 million aggregate principal amount of its 2020 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately $7 million, which is included in Other, net in the Company's Consolidated Statement of Operations. During fiscal year 2015, the 2020 Notes were fully extinguished through repurchase and redemption for cash at a premium to their principal amount, plus accrued and unpaid interest.  The Company recorded a loss on the repurchase of approximately $26 million, which is included in Other, net in the Company's Consolidated Statement of Operations.

[0001047469-16-014732:notes:57]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”).  On May 18, 2011, the Company's subsidiary, Seagate HDD Cayman, completed the sale of $600 million aggregate principal amount of the 2021 Notes, in a private placement exempt from the registration requirements of the Securities Act of 1933, as amended. The obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.  The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year.  The 2021 Notes are redeemable any time prior to May 1, 2016 at the option of the Company, in whole or in part, at a redemption price of 100% of the principal amount plus an “applicable premium” and accrued and unpaid interest, if any, to the redemption date. The "applicable premium" will be equal to the greater of (1) 1% of the principal amount of the 2021 Notes, or (2) the excess, if any, of (a) the present value of the redemption price on May 1, 2016 plus interest payments due through May 1, 2016, discounted at the applicable Treasury rate as of the redemption date plus 50 basis points; over (b) the principal amount of such note. The 2021 Notes are redeemable at any time on or after May 1, 2016 at various prices expressed as a percentage of principal amount, as set forth in the indentures, plus accrued and unpaid interest, if any, to the redemption date. In addition, any time before May 1, 2014, the Company may redeem up to 35% of the principal amount with the net cash proceeds from permitted sales of the Company's stock at a redemption price of 107% of the principal amount plus accrued interest to the redemption date.  The issuer under the 2021 Notes is Seagate HDD Cayman and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During fiscal year 2014, the Company repurchased $349 million aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately $54 million, which is included in Other, net in the Company's Consolidated Statement of Operations. During fiscal year 2015, the Company repurchased $93 million aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately $13 million, which is included in Other, net in the Company's Consolidated Statement of Operations. During fiscal year 2016, the Company repurchased $1 million aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The loss recorded on the repurchase was immaterial, which is included in Other, net in the Company's Consolidated Statement of Operations.

[0001047469-16-014732:notes:58]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). On May 22, 2013, Seagate HDD Cayman, issued $1 billion in aggregate principal amount of 4.75% Senior Notes, which mature on June 1, 2023, in a private placement. The obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year.  The 2023 Notes are redeemable at the option of the Company in whole or in part, on not less than 30, nor more than 60 days notice, at a "make-whole" premium redemption price.  The "make-whole" redemption price will be equal to the greater of (1) 100% of the principal amount of the notes being redeemed, or (2) the sum of the present values of the remaining scheduled payments of principal and interest on the 2023 Notes being redeemed, discounted at the redemption date on a semi-annual basis at a rate equal to the sum of the applicable Treasury rate plus 50 basis points.  Accrued and unpaid interest, if any, will be paid to, but excluding, the redemption date. During fiscal year 2016, the Company repurchased $10 million aggregate principal amount of its 2023 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The loss recorded on the repurchase was immaterial, which is included in Other, net in the Company's Consolidated Statement of Operations.

[0001047469-16-014732:notes:59]
$1 billion Aggregate principal amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”).  On May 28, 2014, Seagate HDD Cayman issued, in a private placement, $1 billion in aggregate principal amount of 4.75% Senior Notes due 2025, which mature on January 1, 2025. The interest on the Notes will be payable in cash semiannually on January 1 and July 1 of each year, commencing on January 1, 2015. At any time, upon not less than 30 nor more than 60 days’ notice, Seagate HDD may redeem some or all of the Notes at a ‘‘make-whole’’ redemption price. The ‘‘make-whole’’ redemption price will be equal to the greater of (1) 100% of the principal amount of the Notes redeemed, and (2) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points. Accrued and unpaid interest, if any, will be paid to, but excluding, the redemption date. The Notes are fully and unconditionally guaranteed by the Company on a senior unsecured basis. During fiscal year 2016, the Company repurchased $5 million aggregate principal amount of its 2025 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The gain recorded on the repurchase was immaterial, which is included in Other, net in the Company's Consolidated Statement of Operations.

[0001047469-16-014732:notes:60]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December, 2034 (the “2034 Notes”). On December 2, 2014, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 5.75% Senior Notes, which mature on December 1, 2034. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on June 1, 2015. At any time before June 1, 2034, Seagate HDD Cayman may redeem some or all of the Notes at a “make-whole” redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points, minus accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date. At any time on or after June 1, 2034, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During fiscal year 2016, the Company repurchased $10 million aggregate principal amount of its 2034 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded a gain on the repurchase of approximately $3 million, which is included in Other, net in the Company's Consolidated Statement of Operations.

[0001047469-16-014732:notes:61]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June, 2027 (the “2027 Notes”). On May 14, 2015, Seagate HDD Cayman issued, in a private placement, $700 million in aggregate principal amount of 4.875% Senior Notes, which mature on June 1, 2027. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on December 1, 2015. At any time before March 1, 2027, Seagate HDD Cayman may redeem some or all of the Notes at a “make-whole” redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 40 basis points, minus accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date. At any time on or after March 1, 2027, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001047469-16-014732:notes:62]
At July 1, 2016, future principal payments on long-term debt were as follows (in millions):

[0001047469-16-014732:notes:63]
| Fiscal Year |  | Amount |
| 2017 |  | $ | — |  |
| 2018 |  | — |  |
| 2019 |  | 800 |  |
| 2020 |  | — |  |
| 2021 |  | — |  |
| Thereafter |  | 3,333 |  |
|  |  | $ | 4,133 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001047469-16-014732:notes:64]
Derivative Financial Instruments

[0001047469-16-014732:notes:65]
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity price risks relating to its ongoing business operations. The Company enters into foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses denominated in foreign currencies and to mitigate the remeasurement risk of certain foreign currency denominated liabilities. The Company's accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives in the Consolidated Balance Sheets at fair value. The changes in the fair value of the effective portions of designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments and the ineffective portions of cash flow hedges are adjusted to fair value through earnings. The amount of net unrealized loss on cash flow hedges was $2 million as of July 1, 2016 and the amount of net unrealized gain on cash flow hedges was $1 million as of July 3, 2015.

[0001047469-16-014732:notes:66]
The Company dedesignates its cash flow hedges when the forecasted hedged transactions are realized or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company did not recognize any material net gains or losses related to the loss of hedge designation on discontinued cash flow hedges during fiscal years 2016,  2015 and 2014. As of July 1, 2016, the Company's existing foreign currency forward exchange contracts mature within 12 months. The deferred amount currently recorded in Accumulated other comprehensive loss expected to be recognized into earnings over the next 12 months is immaterial.

[0001047469-16-014732:notes:67]
The following tables show the total notional value of the Company's outstanding foreign currency forward exchange contracts as of July 1, 2016 and July 3, 2015:

[0001047469-16-014732:notes:68]
|  |  | As of July 1, 2016 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| British Pound Sterling |  | $ | 47 |  |  | $ | 10 |  |

[0001047469-16-014732:notes:69]
|  |  | As of July 3, 2015 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Thai Baht |  | $ | 18 |  |  | $ | 48 |  |
| Singapore Dollars |  | 23 |  |  | 42 |  |
| Chinese Renminbi |  | 5 |  |  | 16 |  |
| Euro |  | — |  |  | 13 |  |
| British Pound Sterling |  | 35 |  |  | — |  |
| Malaysian Ringgit |  | 12 |  |  | 15 |  |
|  |  | $ | 93 |  |  | $ | 134 |  |

[0001047469-16-014732:notes:70]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plan—the Seagate Deferred Compensation Plan (the “SDCP”).  In the quarter ended December 27, 2013, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees.  As of July 1, 2016, the notional investments underlying the TRS amounted to $94 million. The contract term of the TRS is through January 2016 and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company renewed the contract term through January 2017 under materially the same terms. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001047469-16-014732:notes:71]
The following tables show the Company's derivative instruments measured at gross fair value as reflected in the Consolidated Balance Sheets as of July 1, 2016 and July 3, 2015:

[0001047469-16-014732:notes:72]
|  |  | As of July 1, 2016 |
|  |  | Asset Derivatives |  | Liability Derivatives |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (2 | ) |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | — |  |  | Accrued expenses |  | (1 | ) |
| Total return swap |  | Other current assets |  | 3 |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 3 |  |  |  |  | $ | (3 | ) |

[0001047469-16-014732:notes:73]
|  |  | As of July 3, 2015 |
|  |  | Asset Derivatives |  | Liability Derivatives |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 2 |  |  | Accrued expenses |  | $ | (1 | ) |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | — |  |  | Accrued expenses |  | (3 | ) |
| Total return swap |  | Other current assets |  | 1 |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 3 |  |  |  |  | $ | (4 | ) |

[0001047469-16-014732:notes:74]
The following tables show the effect of the Company's derivative instruments on the Consolidated Statement of Comprehensive Income and the Consolidated Statements of Operations for the fiscal year ended July 1, 2016:

[0001047469-16-014732:notes:75]
| (Dollars in millions) Derivatives Designated as Cash Flow Hedges |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
| Foreign currency forward exchange contracts |  | $ | (4 | ) |  | Cost of revenue |  | $ | (2 | ) |  | Cost of revenue |  | $ | — |  |

[0001047469-16-014732:notes:76]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (5 | ) |
| Total return swap |  | Operating expenses |  | $ | (1 | ) |

[0001047469-16-014732:notes:77]
___________________________________

[0001047469-16-014732:notes:78]
| (a) | The amounts of gains or losses recognized in income related to the ineffective portion of the hedging relationships and to the amount excluded from the assessment of hedge effectiveness were immaterial for the fiscal year ended July 1, 2016. |

[0001047469-16-014732:notes:79]
The following tables show the effect of the Company's derivative instruments on the Consolidated Statement of Comprehensive Income and the Consolidated Statements of Operations for the fiscal year ended July 3, 2015:

[0001047469-16-014732:notes:80]
| (Dollars in millions) Derivatives Designated as Cash Flow Hedges |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
| Foreign currency forward exchange contracts |  | $ | (11 | ) |  | Cost of revenue |  | $ | (13 | ) |  | Cost of revenue |  | $ | 1 |  |

[0001047469-16-014732:notes:81]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (4 | ) |
| Total return swap |  | Operating expenses |  | $ | — |  |

[0001047469-16-014732:notes:82]
| (a) | The amounts of gains or losses recognized in income related to the ineffective portion of the hedging relationships were immaterial for the fiscal year ended July 3, 2015. The amount of gains recognized in income related to the amount excluded from the assessment of hedge effectiveness was $1 million for the fiscal year ended July 3, 2015. |


## us-gaap:DerivativesPolicyTextBlock

[0001047469-16-014732:notes:83]
Derivative Financial Instruments.    The Company applies the requirements of ASC Topic 815 ("ASC 815"), Derivatives and Hedging. ASC 815 requires that all derivatives be recorded on the balance sheet at fair value and establishes criteria for designation and effectiveness of hedging relationships.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001047469-16-014732:notes:84]
Compensation

[0001047469-16-014732:notes:85]
Stock-Based Compensation Plans

[0001047469-16-014732:notes:86]
The Company's stock-based compensation plans have been established to promote the Company's long-term growth and financial success by providing incentives to its employees, directors, and consultants through grants of share-based awards. The provisions of the Company's stock-based benefit plans, which allow for the grant of various types of equity-based awards, are also intended to provide greater flexibility to maintain the Company's competitive ability to attract, retain and motivate participants for the benefit of the Company and its shareholders.

[0001047469-16-014732:notes:87]
Seagate Technology plc 2012 Equity Incentive Plan (the “EIP”).  On October 26, 2011, the shareholders approved the EIP and authorized the issuance of up to a total of  27.0 million ordinary shares, par value $0.0001 per share, plus any shares remaining available for grant under the Seagate Technology plc 2004 Share Compensation Plan (the "SCP") as of the effective date of the EIP (which was equal to 11.0 million ordinary shares as of the effective date of the EIP and which will increase by such additional number of shares as will be returned to the share reserve in respect of awards previously granted under the SCP) (together, the “Share Reserve”). On October 22, 2014, the shareholders authorized the issuance from the EIP of an additional 25 million ordinary shares, par value $0.0001 per share. Any shares that are subject to options or share appreciation rights granted under the EIP will be counted against the Share Reserve as one share for every one share granted, and any shares that are subject to restricted share bonus awards, restricted share units, performance share bonus awards or performance share awards (collectively, “Full-Value Share Awards”) will generally be counted against the Share Reserve as two and five-tenths shares for every one share granted. As of July 1, 2016, there were approximately 32.7 million ordinary shares available for issuance under the EIP.

[0001047469-16-014732:notes:88]
Dot Hill Systems 2009 Equity Incentive Plan (the "DHEIP").  Seagate Technology plc acquired the Dot Hill Systems 2009 Equity Incentive Plan effective October 6, 2015. The Company assumed the remaining authorized but unused share reserve of approximately 2 million shares, based on the conversion ratio, from the DHEIP on the acquisition date. Any shares that are subject to options or share appreciation rights granted under the DHEIP will be counted against the Share Reserve as one share for every one share granted, and any shares that are subject to restricted share bonus awards, restricted share units, performance share bonus awards or performance share awards (collectively, “Full-Value Share Awards”) will generally be counted against the Share Reserve as one and five-tenths shares for every one share granted. As of July 1, 2016, there were approximately 1 million ordinary shares available for issuance under the DHEIP.

[0001047469-16-014732:notes:89]
Seagate Technology plc Employee Stock Purchase Plan (the "ESPP").  There are 50.0 million ordinary shares authorized to be issued under the ESPP. In no event shall the total number of shares issued under the ESPP exceed 75.0 million ordinary shares.  The ESPP consists of a six-month offering period with a maximum issuance of 1.5 million ordinary shares per offering period.  The ESPP permits eligible employees to purchase ordinary shares through payroll deductions generally at 85% of the fair market value of the ordinary shares. As of July 1, 2016 there were approximately 6.8 million ordinary shares available for issuance under the ESPP.

[0001047469-16-014732:notes:90]
Equity Awards

[0001047469-16-014732:notes:91]
Full-Value Share Awards (e.g. restricted share units) generally vest over a period of three to four years, with cliff vesting of a portion of each award occurring annually. Options generally vest as follows:  25% of the options will vest on the first anniversary of the vesting commencement date and the remaining 75% will vest ratably each month thereafter over the next 36 months. Options granted under the EIP and SCP have an exercise price equal to the closing price of the Company's ordinary shares on date of grant.

[0001047469-16-014732:notes:92]
The Company granted performance awards to its senior executive officers under the SCP and the EIP where vesting is subject to both the continued employment of the participant by the Company and the achievement of certain performance goals established by the Compensation Committee of the Company's Board of Directors, including market based performance goals.  A single award represents the right to receive a single ordinary share of the Company. During fiscal years 2016,  2015 and 2014, the Company granted 0.4 million, 0.3 million and 0.4 million performance awards, respectively, where performance is measured based on a three-year average return on invested capital ("ROIC") goal and a relative total shareholder return ("TSR") goal, which is based on the Company's ordinary shares measured against a benchmark TSR of a peer group over the same three-year period (the "TSR/ROIC" awards).  These awards vest after the end of the performance period of three years from the grant date. A percentage of these units may vest only if at least the minimum ROIC goal is met regardless of whether the TSR goal is met. The number of stock units to vest will range from 0% to 200% of the targeted units. In evaluating the fair value of these units, the Company used a Monte Carlo simulation on the grant date, taking the market-based TSR goal into consideration. Compensation expense related to these units is only recorded in a period if it is probable that the ROIC goal will be met, and it is to be recorded at the expected level of achievement.

[0001047469-16-014732:notes:93]
The Company also granted 0.2 million, 0.4 million and 0.3 million performance awards during fiscal years  2016,  2015 and  2014 respectively, to its senior executive officers which are subject to a performance goal related to the Company's adjusted earnings per share (the "AEPS" awards). These awards have a maximum seven-year vesting period, with 25% annual vesting starting on the first anniversary of the grant date. If the performance goal is not achieved, vesting is delayed to a following year in which the AEPS goal is achieved. Any unvested awards from prior years may vest cumulatively in a future year within the seven-year vesting period if the annual AEPS goal is achieved during a subsequent year. If the AEPS goal has not been met by the end of the seven year period, any unvested shares will be forfeited.

[0001047469-16-014732:notes:94]
During fiscal year 2016 and 2015, the Company did not grant any performance-based options and performance based restricted share units to its CEO.

[0001047469-16-014732:notes:95]
Determining Fair Value of Seagate Technology Stock Plans

[0001047469-16-014732:notes:96]
Valuation and amortization method - The Company estimates the fair value of stock options granted using the Black-Scholes-Merton valuation model and a single option award approach. This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period or the remaining service (vesting) period.

[0001047469-16-014732:notes:97]
Expected Term - Expected term represents the period that the Company's stock-based awards are expected to be outstanding and was determined based on historical experience of similar awards, giving consideration to the contractual terms of the stock-based awards, vesting schedules and expectations of future employee behavior as influenced by changes to the terms of its stock-based awards.

[0001047469-16-014732:notes:98]
Expected Volatility - The Company uses a combination of the implied volatility of its traded options and historical volatility of its share price.

[0001047469-16-014732:notes:99]
Expected Dividend - The Black-Scholes-Merton valuation model calls for a single expected dividend yield as an input. The dividend yield is determined by dividing the expected per share dividend during the coming year by the grant date share price.  The expected dividend assumption is based on the Company's current expectations about its anticipated dividend policy. Also, because the expected dividend yield should reflect marketplace participants' expectations, the Company does not incorporate changes in dividends anticipated by management unless those changes have been communicated to or otherwise are anticipated by marketplace participants.

[0001047469-16-014732:notes:100]
Risk-Free Interest Rate - The Company bases the risk-free interest rate used in the Black-Scholes-Merton valuation model on the implied yield currently available on U.S. Treasury zero-coupon issues with an equivalent remaining term.  Where the expected term of the Company's stock-based awards do not correspond with the terms for which interest rates are quoted, the Company performed a straight-line interpolation to determine the rate from the available term maturities.

[0001047469-16-014732:notes:101]
Fair Value - The fair value of the Company's nonvested awards and performance awards subject to an AEPS condition for fiscal years 2016, 2015, and 2014, is the price per share of the Company's common stock on the grant date. The weighted-average grant date fair value of awards granted are as follows:

[0001047469-16-014732:notes:102]
The fair value of the Company's shares related to options granted to employees, shares issued from the ESPP and performance awards subject to TSR/ROIC conditions for fiscal years  2016,  2015 and  2014 were estimated using the following assumptions:

[0001047469-16-014732:notes:103]
Stock Compensation Expense

[0001047469-16-014732:notes:104]
The Company recorded $120 million, $137 million and $118 million of share-based compensation during fiscal years 2016,  2015, and  2014, respectively. Management has made an estimate of expected forfeitures and is recognizing compensation costs only for those equity awards expected to vest. When estimating forfeitures, the Company considers voluntary termination behavior as well as analysis of actual forfeited awards.

[0001047469-16-014732:notes:105]
Stock Option Activity

[0001047469-16-014732:notes:106]
The Company issues new ordinary shares upon exercise of stock options. The following is a summary of option activities:

[0001047469-16-014732:notes:107]
| Options |  | Number ofShares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualTerm |  | AggregateIntrinsicValue |
|  |  | (In millions) |  |  |  | (In years) |  | (Dollars In millions) |
| Outstanding at July 3, 2015 |  | 4.9 |  |  | $ | 27.94 |  |  | 3.6 |  | $ | 110 |  |
| Granted |  | 2.6 |  |  | $ | 35.86 |  |  |  |  |  |  |
| Exercised |  | (1.5 | ) |  | $ | 8.32 |  |  |  |  |  |  |
| Forfeitures |  | (0.4 | ) |  | $ | 47.03 |  |  |  |  |  |  |
| Expirations |  | (0.2 | ) |  | 46.43 |  |  |  |  |  |  |
| Outstanding at July 1, 2016 |  | 5.4 |  |  | $ | 34.91 |  |  | 4.6 |  | $ | 14 |  |
| Vested and expected to vest at July 1, 2016 |  | 5.3 |  |  | $ | 34.93 |  |  | 4.6 |  | $ | 14 |  |
| Exercisable at July 1, 2016 |  | 2.5 |  |  | $ | 27.46 |  |  | 3.2 |  | $ | 12 |  |

[0001047469-16-014732:notes:108]
The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company's ordinary shares for the options that were in-the-money at July 1, 2016. During fiscal years 2016,  2015, and  2014, the aggregate intrinsic value of options exercised under the Company's stock option plans was $44 million, $92 million and $140 million, respectively, determined as of the date of option exercise. The aggregate fair value of options vested during fiscal year 2016 was approximately $18 million.

[0001047469-16-014732:notes:109]
At July 1, 2016, the total compensation cost related to options granted to employees but not yet recognized was approximately $28 million, net of estimated forfeitures of approximately $1 million. This cost is being amortized on a straight-line basis over a weighted-average remaining term of approximately 2.5 years and will be adjusted for subsequent changes in estimated forfeitures.

[0001047469-16-014732:notes:110]
Nonvested Awards Activity

[0001047469-16-014732:notes:111]
The following is a summary of nonvested award activities which do not contain a performance condition:

[0001047469-16-014732:notes:112]
| Nonvested Awards |  | Number ofShares |  | Weighted-AverageGrant-DateFair Value |
|  |  | (In millions) |  |  |
| Nonvested at July 3, 2015 |  | 5.2 |  |  | $ | 39.73 |  |
| Granted |  | 2.4 |  |  | $ | 41.47 |  |
| Forfeitures |  | (0.7 | ) |  | $ | 45.04 |  |
| Vested |  | (2.1 | ) |  | $ | 30.95 |  |
| Nonvested at July 1, 2016 |  | 4.8 |  |  | $ | 39.95 |  |

[0001047469-16-014732:notes:113]
At July 1, 2016, the total compensation cost related to nonvested awards granted to employees but not yet recognized was approximately $133 million, net of estimated forfeitures of approximately $7 million.  This cost is being amortized on a straight-line basis over a weighted-average remaining term of 2.4 years and will be adjusted for subsequent changes in estimated forfeitures.  The aggregate fair value of nonvested awards vested during fiscal year 2016 was approximately $102 million.

[0001047469-16-014732:notes:114]
Performance Awards

[0001047469-16-014732:notes:115]
The following is a summary of nonvested award activities which contain a performance condition:

[0001047469-16-014732:notes:116]
| Performance Awards |  | Number ofShares |  | Weighted-AverageGrant-DateFair Value |
|  |  | (In millions) |  |  |
| Performance units at July 3, 2015 |  | 2.1 |  |  | $ | 61.12 |  |
| Granted |  | 0.6 |  |  | $ | 45.68 |  |
| Forfeitures |  | (0.2 | ) |  | $ | 53.99 |  |
| Vested |  | (1.1 | ) |  | $ | 27.05 |  |
| Performance units at July 1, 2016 |  | 1.4 |  |  | $ | 47.41 |  |

[0001047469-16-014732:notes:117]
At July 1, 2016, the total compensation cost related to performance awards granted to employees but not yet recognized was approximately $23 million. This cost is being amortized on a straight-line basis over a weighted-average remaining term of 3.5 years.

[0001047469-16-014732:notes:118]
ESPP

[0001047469-16-014732:notes:119]
During fiscal years 2016, 2015 and  2014, the aggregate intrinsic value of shares purchased under the Company's ESPP was approximately $12 million, $15 million and $26 million respectively.  At July 1, 2016, the total compensation cost related to options to purchase the Company's ordinary shares under the ESPP but not yet recognized was approximately $1.7 million. This cost will be amortized on a straight-line basis over a weighted-average period of approximately one month. During fiscal year 2016, the Company issued 2.1 million ordinary shares with a weighted-average purchase price of $31.54 per share.

[0001047469-16-014732:notes:120]
Tax-Deferred Savings Plan

[0001047469-16-014732:notes:121]
The Company has a tax-deferred savings plan, the Seagate 401(k) Plan (the "40l(k) plan"), for the benefit of qualified employees.  The 40l(k) plan is designed to provide employees with an accumulation of funds at retirement. Qualified employees may elect to make contributions to the 401(k) plan on a bi-weekly basis. Pursuant to the 401(k) plan, the Company matches 50% of employee contributions, up to 6% of compensation, subject to maximum annual contributions of $4,500 per participating employee. During fiscal years 2016,  2015, and  2014, the Company made matching contributions of $19 million, $18 million and $16 million, respectively.

[0001047469-16-014732:notes:122]
Deferred Compensation Plan

[0001047469-16-014732:notes:123]
On January 1, 2001, the Company adopted the SDCP for the benefit of eligible employees. This plan is designed to permit certain discretionary employer contributions, in excess of the tax limits applicable to the 401(k) plan and to permit employee deferrals in excess of certain tax limits.  In the quarter ended December 27, 2013, the Company entered into a TRS in order to manage the equity market risks associated with the SDCP liabilities.  See "Note 8. Derivative Financial Instruments" contained in this report for additional information about the TRS.


## us-gaap:EarningsPerShareTextBlock

[0001047469-16-014732:notes:124]
Earnings Per Share

[0001047469-16-014732:notes:125]
The following table sets forth the computation of basic and diluted net income per share:

[0001047469-16-014732:notes:126]
|  | Fiscal Years Ended |
| (In millions, except per share data) | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |
| Numerator: |  |  |  |  |  |
| Net income attributable to Seagate Technology plc | $ | 248 |  |  | $ | 1,742 |  |  | $ | 1,570 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share attributable to Seagate Technology plc | 299 |  |  | 324 |  |  | 337 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |
| Employee equity award plans | 3 |  |  | 7 |  |  | 10 |  |
| Total shares for purpose of calculating diluted net income per share attributable to Seagate Technology plc | 302 |  |  | 331 |  |  | 347 |  |
| Net income per share attributable to Seagate Technology plc shareholders: |  |  |  |  |  |
| Basic | $ | 0.83 |  |  | $ | 5.38 |  |  | $ | 4.66 |  |
| Diluted | $ | 0.82 |  |  | $ | 5.26 |  |  | $ | 4.52 |  |

[0001047469-16-014732:notes:127]
The following potential shares were excluded from the computation of diluted net income per share as their effect would have been anti-dilutive:

[0001047469-16-014732:notes:128]
|  | Fiscal Years Ended |
| (In millions) | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |
| Employee equity award plans | 3 |  |  | — |  |  | — |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001047469-16-014732:notes:129]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 316 |  |  | $ | 439 |  |  | $ | — |  |  | $ | 755 |  |
| Short-term investments |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Other current assets |  | 2 |  |  | 8 |  |  | — |  |  | 10 |  |
| Total assets |  | $ | 318 |  |  | $ | 453 |  |  | $ | — |  |  | $ | 771 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |
| Total liabilities |  | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |

[0001047469-16-014732:notes:130]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,201 |  |  | $ | 862 |  |  | $ | — |  |  | $ | 2,063 |  |
| Short-term investments |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Other current assets |  | 2 |  |  | 8 |  |  | — |  |  | 10 |  |
| Total assets |  | $ | 1,203 |  |  | $ | 876 |  |  | $ | — |  |  | $ | 2,079 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |
| Total liabilities |  | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001047469-16-014732:notes:131]
Fair Value

[0001047469-16-014732:notes:132]
Measurement of Fair Value

[0001047469-16-014732:notes:133]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact and it considers assumptions that market participants would use when pricing the asset or liability.

[0001047469-16-014732:notes:134]
Fair Value Hierarchy

[0001047469-16-014732:notes:135]
A fair value hierarchy is based on whether the market participant assumptions used in determining fair value are obtained from independent sources (observable inputs) or reflects the Company's own assumptions of market participant valuation (unobservable inputs). A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The three levels of inputs that may be used to measure fair value:

[0001047469-16-014732:notes:136]
Level 1 - Quoted prices in active markets that are unadjusted and accessible at the measurement date for identical, unrestricted assets or liabilities;

[0001047469-16-014732:notes:137]
Level 2 - Quoted prices for identical assets and liabilities in markets that are inactive; quoted prices for similar assets and liabilities in active markets or financial instruments for which significant inputs are observable, either directly or indirectly; or

[0001047469-16-014732:notes:138]
Level 3 - Prices or valuations that require inputs that are both unobservable and significant to the fair value measurement.

[0001047469-16-014732:notes:139]
The Company considers an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and views an inactive market as one in which there are few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate the Company's or the counterparty's non-performance risk is considered in determining the fair values of liabilities and assets, respectively.

[0001047469-16-014732:notes:140]
Items Measured at Fair Value on a Recurring Basis

[0001047469-16-014732:notes:141]
The following table presents the Company's assets and liabilities that are measured at fair value on a recurring basis, excluding accrued interest components, as of July 1, 2016:

[0001047469-16-014732:notes:142]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 316 |  |  | $ | — |  |  | $ | — |  |  | $ | 316 |  |
| Certificates of deposit |  | — |  |  | 439 |  |  | — |  |  | 439 |  |
| Corporate bonds |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total cash equivalents and short-term investments |  | 316 |  |  | 445 |  |  | — |  |  | 761 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Certificates of deposit |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Derivative assets |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets |  | $ | 318 |  |  | $ | 453 |  |  | $ | — |  |  | $ | 771 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |
| Total liabilities |  | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |

[0001047469-16-014732:notes:143]
The following table presents the Company's assets and liabilities that are measured at fair value on a recurring basis, excluding accrued interest components, as of July 3, 2015:

[0001047469-16-014732:notes:144]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,201 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,201 |  |
| Certificates of deposit |  | — |  |  | 862 |  |  | — |  |  | 862 |  |
| Corporate bonds |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total cash equivalents and short-term investments |  | 1,201 |  |  | 868 |  |  | — |  |  | 2,069 |  |
| Restricted Cash and Investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Other debt securities |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Derivative assets |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Total assets |  | $ | 1,203 |  |  | $ | 876 |  |  | $ | — |  |  | $ | 2,079 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |
| Total liabilities |  | $ | — |  |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |

[0001047469-16-014732:notes:145]
The Company classifies items in Level 1 if the financial assets consist of securities for which quoted prices are available in an active market.

[0001047469-16-014732:notes:146]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries and certificates of deposits. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair values of all of its cash equivalents and short-term investments. For the cash equivalents and short-term investments in the Company's portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry standard data providers or other third party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of July 1, 2016, has not found it necessary to make any adjustments to the prices obtained.  The Company's derivative financial instruments are also classified within Level 2. The Company's derivative financial instruments consist of foreign currency forward exchange contracts and the TRS. The Company recognizes derivative financial instruments in its consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001047469-16-014732:notes:147]
As of July 1, 2016 and July 3, 2015, we had no Level 3 assets or liabilities.

[0001047469-16-014732:notes:148]
Items Measured at Fair Value on a Non-Recurring Basis

[0001047469-16-014732:notes:149]
The Company enters into certain strategic investments for the promotion of business and strategic objectives. Strategic investments in equity securities where the Company does not have the ability to exercise significant influence over the investees, included in Other assets, net in the Consolidated Balance Sheets, are recorded at cost and are periodically analyzed to determine whether or not there are indicators of impairment. The carrying value of the Company's strategic investments at July 1, 2016 and July 3, 2015 totaled $113 million and $120 million, respectively, and consisted primarily of privately held equity securities without a readily determinable fair value.

[0001047469-16-014732:notes:150]
During the fiscal years  2016,  2015 and  2014, the Company determined that certain of its equity investments accounted for under the cost method were other-than-temporarily impaired, and recognized charges of $13 million, $7 million and $2 million, respectively, in order to write down the carrying amount of the investments to its estimated fair value. These amounts were recorded in Other, net in the Consolidated Statements of Operations. Since there was no active market for the equity securities of the investee, the Company estimated fair value of the investee by analyzing the underlying cash flows and future prospects of the investee.

[0001047469-16-014732:notes:151]
Other Fair Value Disclosures

[0001047469-16-014732:notes:152]
The Company's debt is carried at amortized cost. The fair value of the Company's debt is derived using the closing price of the same debt instruments as of the date of valuation, which takes into account the yield curve, interest rates, and other observable inputs.  Accordingly, these fair value measurements are categorized as Level 2.  The following table presents the fair value and amortized cost of the Company's debt in order of maturity:

[0001047469-16-014732:notes:153]
|  |  | July 1, 2016 |  | July 3, 2015 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 800 |  |  | $ | 804 |  |  | $ | 800 |  |  | $ | 828 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 164 |  |  | 158 |  |  | 170 |  |
| 4.75% Senior Notes due June 2023 |  | 990 |  |  | 857 |  |  | 1,000 |  |  | 1,016 |  |
| 4.75% Senior Notes due January 2025 |  | 995 |  |  | 795 |  |  | 1,000 |  |  | 995 |  |
| 4.875% Senior Notes due June 2027 |  | 698 |  |  | 514 |  |  | 698 |  |  | 675 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 357 |  |  | 499 |  |  | 491 |  |
|  |  | 4,130 |  |  | 3,491 |  |  | 4,155 |  |  | 4,175 |  |
| Less short-term borrowings and current portion of long-term debt |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 4,130 |  |  | $ | 3,491 |  |  | $ | 4,155 |  |  | $ | 4,175 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001047469-16-014732:notes:154]
Foreign Currency Remeasurement and Translation.    The U.S. dollar is the functional currency for the majority of the Company's foreign operations. Monetary assets and liabilities denominated in foreign currencies are remeasured into the functional currency of the subsidiary at the balance sheet date. The gains and losses from the remeasurement of foreign currency denominated balances into the functional currency of the subsidiary are included in Other, net on the Company's Consolidated Statements of Operations. The Company had $1 million in remeasurement losses in fiscal year 2016 with $33 million and $8 million in remeasurement gains in fiscal years 2015 and 2014, respectively.

[0001047469-16-014732:notes:155]
The Company translates the assets and liabilities of its non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recognized in foreign currency translation included in Accumulated Other comprehensive income (loss), which is a component of shareholders’ equity. The Company’s subsidiaries that use the U.S. dollar as their functional currency remeasure monetary assets and liabilities at exchange rates in effect at the end of each period, and inventories, property, and nonmonetary assets and liabilities at historical rates. Gains and losses from these remeasurements were not significant and have been included in the Company’s results of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001047469-16-014732:notes:156]
Goodwill and Other Intangible Assets

[0001047469-16-014732:notes:157]
Goodwill

[0001047469-16-014732:notes:158]
The changes in the carrying amount of goodwill are as follows:

[0001047469-16-014732:notes:159]
| (Dollars in millions) | Amount |
| As of June 27, 2014 | $ | 537 |  |
| Goodwill acquired | 339 |  |
| Foreign currency translation effect | (2 | ) |
| As of July 3, 2015 | $ | 874 |  |
| Goodwill acquired | 364 |  |
| Goodwill disposed | (1 | ) |
| Foreign currency translation effect | — |  |
| As of July 1, 2016 | $ | 1,237 |  |

[0001047469-16-014732:notes:160]
Other Intangible Assets

[0001047469-16-014732:notes:161]
Other intangible assets consist primarily of existing technology, customer relationships, in-process research and development ("IPR&D") and trade names acquired in business combinations. With the exception of IPR&D, acquired intangibles are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization is charged to Operating expenses in the Consolidated Statements of Operations. IPR&D has been determined to have an indefinite useful life and is not amortized, but instead tested for impairment annually or more frequently if events or changes in circumstance indicate that the asset might be impaired. If the carrying amount of IPR&D exceeds its fair value, an impairment loss is recognized in an amount equal to that excess. There were no impairment charges recognized for IPR&D. Upon completion of the IPR&D, the related assets will be accounted for as a finite-lived intangible asset, and will be amortized over its useful life.

[0001047469-16-014732:notes:162]
In fiscal years 2016, 2015 and 2014, amortization expense for other intangible assets was $174 million, $152 million and $131 million, respectively.

[0001047469-16-014732:notes:163]
The carrying value of other intangible assets subject to amortization as of July 1, 2016, is set forth in the following table:

[0001047469-16-014732:notes:164]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 297 |  |  | $ | (79 | ) |  | $ | 218 |  |  | 4.1 years |
| Customer relationships |  | 510 |  |  | (328 | ) |  | 182 |  |  | 3.2 years |
| Trade name |  | 29 |  |  | (14 | ) |  | 15 |  |  | 2.6 years |
| Other intangible assets |  | 29 |  |  | (10 | ) |  | 19 |  |  | 3.2 years |
| Total amortizable other intangible assets |  | $ | 865 |  |  | $ | (431 | ) |  | $ | 434 |  |  | 3.6 years |

[0001047469-16-014732:notes:165]
The carrying value of IPR&D not subject to amortization was $14 million on July 1, 2016.

[0001047469-16-014732:notes:166]
The carrying value of other intangible assets subject to amortization as of July 3, 2015 is set forth in the following table:

[0001047469-16-014732:notes:167]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 191 |  |  | $ | (69 | ) |  | $ | 122 |  |  | 4.1 years |
| Customer relationships |  | 487 |  |  | (282 | ) |  | 205 |  |  | 2.4 years |
| Trade name |  | 27 |  |  | (7 | ) |  | 20 |  |  | 3.2 years |
| Other intangible assets |  | 27 |  |  | (4 | ) |  | 23 |  |  | 4.2 years |
| Total amortizable other intangible assets |  | $ | 732 |  |  | $ | (362 | ) |  | $ | 370 |  |  | 3.1 years |

[0001047469-16-014732:notes:168]
The carrying value of IPR&D not subject to amortization was $0 million on July 3, 2015.

[0001047469-16-014732:notes:169]
As of July 1, 2016, expected amortization expense for other intangible assets for each of the next five years and thereafter is as follows:

[0001047469-16-014732:notes:170]
| (Dollars in millions) |  | Amount |
| 2017 |  | $ | 166 |  |
| 2018 |  | 106 |  |
| 2019 |  | 68 |  |
| 2020 |  | 50 |  |
| 2021 |  | 23 |  |
| Thereafter |  | 21 |  |
|  |  | $ | 434 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001047469-16-014732:notes:171]
Assessment of Goodwill and Other Long-lived Assets for Impairment.  The Company accounts for goodwill in accordance with Accounting Standards Codification ("ASC") Topic 350 ("ASC 350"), Intangibles - Goodwill and Other. During fiscal year 2012, the Company adopted Accounting Standard Update ("ASU") No. 2011-08, Intangibles - Goodwill and Other (ASC Topic 350) - Testing Goodwill for Impairment. The Company performs a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. If it is determined in the qualitative assessment that the fair value of a reporting unit is more likely than not below its carrying amount, including goodwill, then the Company performs a quantitative two-step impairment test. The first step, identifying a potential impairment, compares the fair value of a reporting unit with its carrying amount, including goodwill. If the carrying value of the reporting unit exceeds its fair value, the second step would need to be conducted. The second step, measuring the impairment loss, compares the implied fair value of the reporting unit goodwill with the carrying amount of that goodwill. Any excess of the reporting unit goodwill carrying value over its implied fair value is recognized as an impairment loss.

[0001047469-16-014732:notes:172]
The Company tests other long-lived assets, including property, equipment and leasehold improvements and other intangible assets subject to amortization, for recoverability whenever events or changes in circumstances indicate that the carrying value of those assets may not be recoverable. The Company performs a recoverability test to assess the recoverability of an asset group. If the recoverability test indicates that the carrying value of the asset group is not recoverable, the Company will estimate the fair value of the asset group and the excess of the carrying value over the fair value is allocated pro rata to derive the adjusted carrying value of assets in the asset group. The adjusted carrying value of each asset in the asset group is not reduced below its fair value.

[0001047469-16-014732:notes:173]
The Company tests other intangible assets not subject to amortization whenever events occur or circumstances change, such as declining financial performance, deterioration in the environment in which the entity operates or deteriorating macroeconomic conditions that have a negative effect on future expected earnings and cash flows that could affect significant inputs used to determine the fair value of the indefinite-lived intangible asset.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001047469-16-014732:notes:174]
Income Taxes

[0001047469-16-014732:notes:175]
The provision for (benefit from) income taxes consisted of the following:

[0001047469-16-014732:notes:176]
|  | Fiscal Years Ended |
| (Dollars in millions) | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |
| Current income tax expense (benefit): |  |  |  |  |  |
| U.S. Federal | $ | 1 |  |  | $ | — |  |  | $ | (12 | ) |
| U.S. State | 2 |  |  | 4 |  |  | 3 |  |
| Non-U.S. | 25 |  |  | 222 |  |  | 62 |  |
| Total Current | 28 |  |  | 226 |  |  | 53 |  |
| Deferred income tax expense (benefit): |  |  |  |  |  |
| U.S. Federal | — |  |  | (6 | ) |  | (43 | ) |
| U.S. State | — |  |  | (2 | ) |  | 2 |  |
| Non-U.S. | (2 | ) |  | 10 |  |  | (26 | ) |
| Total Deferred | (2 | ) |  | 2 |  |  | (67 | ) |
| Provision for (benefit from) income taxes | $ | 26 |  |  | $ | 228 |  |  | $ | (14 | ) |

[0001047469-16-014732:notes:177]
Income before income taxes consisted of the following:

[0001047469-16-014732:notes:178]
|  | Fiscal Years Ended |
| (Dollars in millions) | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |
| U.S. | $ | — |  |  | $ | 101 |  |  | $ | 149 |  |
| Non-U.S. | 274 |  |  | 1,869 |  |  | 1,407 |  |
|  | $ | 274 |  |  | $ | 1,970 |  |  | $ | 1,556 |  |

[0001047469-16-014732:notes:179]
On December 18, 2015, the Protecting Americans from Tax Hikes ("PATH") Act of 2015 was enacted. Among, other provisions, the PATH Act retroactively reinstated and permanently extended the federal Research and Development ("R&D") tax credit from December 31, 2014. The permanent extension of the R&D credit had no immediate impact on the Company’s income tax provision due to valuation allowances on its U.S. deferred tax assets. None of the other PATH Act changes had a material impact on the Company’s income tax provision.

[0001047469-16-014732:notes:180]
The Company recorded $0.6 million, $2.0 million and $0.3 million of excess tax benefits associated with stock option deductions in fiscal years 2016, 2015 and 2014, respectively.

[0001047469-16-014732:notes:181]
Deferred income taxes reflect the net tax effects of temporary differences between the carrying amounts of assets and liabilities for financial reporting purposes and the amounts used for income tax purposes. The significant components of the Company's deferred tax assets and liabilities were as follows:

[0001047469-16-014732:notes:182]
|  | Fiscal Years Ended |
| (Dollars in millions) | July 1, 2016 |  | July 3, 2015 |
| Deferred tax assets |  |  |  |
| Accrued warranty | $ | 74 |  |  | $ | 88 |  |
| Inventory carrying value adjustments | 32 |  |  | 43 |  |
| Receivable allowance | 11 |  |  | 16 |  |
| Accrued compensation and benefits | 85 |  |  | 106 |  |
| Depreciation | 173 |  |  | 171 |  |
| Restructuring accruals | 14 |  |  | 4 |  |
| Other accruals and deferred items | 50 |  |  | 31 |  |
| Net operating losses and tax credit carry-forwards | 1,252 |  |  | 1,099 |  |
| Other assets | 2 |  |  | 5 |  |
| Total deferred tax assets | 1,693 |  |  | 1,563 |  |
| Valuation allowance | (984 | ) |  | (929 | ) |
| Net deferred tax assets | 709 |  |  | 634 |  |
| Deferred tax liabilities |  |  |  |
| Unremitted earnings of certain non-U.S. entities | (11 | ) |  | (6 | ) |
| Acquisition-related items | (92 | ) |  | (15 | ) |
| Other liabilities | — |  |  | (1 | ) |
| Total deferred tax liabilities | (103 | ) |  | (22 | ) |
| Total net deferred tax assets | $ | 606 |  |  | $ | 612 |  |
| As Reported on the Balance Sheet |  |  |  |  |  |
| Current assets—deferred income taxes | $ | — |  |  | $ | 122 |  |
| Non-current assets—deferred income taxes | 616 |  |  | 496 |  |
| Other non-current liabilities | (10 | ) |  | (6 | ) |
| Total net deferred income taxes | $ | 606 |  |  | $ | 612 |  |

[0001047469-16-014732:notes:183]
Consistent with the intent of ASU 2015-17 to simplify the presentation of deferred income taxes, the Company elected to adopt ASU 2015-17 on a prospective basis as of the second quarter, fiscal year 2016. Prior periods were not retrospectively adjusted. As a result of this change in accounting principle, the Company’s current deferred tax assets were reclassified to non-current.

[0001047469-16-014732:notes:184]
The deferred tax asset valuation allowance increased by $55 million and $41 million in fiscal years 2016 and 2015, respectively, and decreased by $101 million in fiscal year 2014.

[0001047469-16-014732:notes:185]
At July 1, 2016, the Company recorded $606 million of net deferred tax assets. The realization of these deferred tax assets is primarily dependent on the Company's ability to generate sufficient U.S. and certain non-U.S. taxable income in future periods. Although realization is not assured, the Company's management believes it is more likely than not that these deferred tax assets will be realized. The amount of deferred tax assets considered realizable, however, may increase or decrease in subsequent periods when the Company reevaluates the underlying basis for its estimates of future U.S. and certain non-U.S. taxable income.

[0001047469-16-014732:notes:186]
At July 1, 2016, the Company had U.S. federal, state and non-U.S. tax net operating loss carryforwards of approximately $3.4 billion, $2.1 billion and $121 million, respectively which will expire at various dates beginning in fiscal year 2018, if not utilized.  U.S. state net operating loss carryforwards of approximately $104 million are scheduled to expire in fiscal year 2017. At July 1, 2016, the Company had U.S. federal and state tax credit carryforwards of $437 million and $96 million, respectively, which will expire at various dates beginning in fiscal year 2018, if not utilized.

[0001047469-16-014732:notes:187]
As of July 1, 2016, approximately $677 million of the Company's U.S. net operating losses and $99 million of its tax credit carryforwards are subject to annual limitations from $1 million to $45 million pursuant to U.S. tax law.

[0001047469-16-014732:notes:188]
For purposes of the reconciliation between the provision for (benefit from) income taxes at the statutory rate and the effective tax rate, the Irish statutory rate of 25% was applied as follows:

[0001047469-16-014732:notes:189]
|  | Fiscal Years Ended |
| (Dollars in millions) | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |
| Provision at statutory rate | $ | 69 |  |  | $ | 493 |  |  | $ | 389 |  |
| Net U.S. federal and state income taxes | 3 |  |  | 7 |  |  | 3 |  |
| Permanent differences | 10 |  |  | 2 |  |  | 3 |  |
| Valuation allowance | (1 | ) |  | 15 |  |  | (100 | ) |
| Non-U.S. losses with no tax benefits | 1 |  |  | 2 |  |  | 8 |  |
| Non-U.S. earnings taxed at less than statutory rate | (37 | ) |  | (463 | ) |  | (313 | ) |
| Audit assessment | — |  |  | 173 |  |  | — |  |
| Reversal of previously recorded taxes | (19 | ) |  | (5 | ) |  | (19 | ) |
| Other individually immaterial items | — |  |  | 4 |  |  | 15 |  |
| Provision for (benefit from) income taxes | $ | 26 |  |  | $ | 228 |  |  | $ | (14 | ) |

[0001047469-16-014732:notes:190]
A substantial portion of the Company's operations in Malaysia, Singapore, and Thailand operate under various tax holiday programs, which expire in whole or in part at various dates through 2024. Certain of the tax holidays may be extended if specific conditions are met. The net impact of these tax holiday programs was to increase the Company's net income by approximately $67 million in fiscal year 2016 ($0.22 per share, diluted), to increase the Company's net income by approximately $349 million in fiscal year 2015 ($1.05 per share, diluted), and to increase the Company's net income by approximately $289 million in fiscal year 2014 ($0.83 per share, diluted).

[0001047469-16-014732:notes:191]
The Company consists of an Irish tax resident parent holding company with various U.S. and non-U.S. subsidiaries that operate in multiple non-Irish taxing jurisdictions. The amount of temporary differences (including undistributed earnings) related to outside basis differences in the stock of non-Irish resident subsidiaries considered indefinitely reinvested outside of Ireland for which Irish income taxes have not been provided as of July 1, 2016, was approximately $1.6 billion. If such amount were remitted to Ireland as a dividend, it is likely that tax at 25% or approximately $400 million would result.

[0001047469-16-014732:notes:192]
As of July 1, 2016 and July 3, 2015, the Company had approximately $70 million and $83 million, respectively, of unrecognized tax benefits excluding interest and penalties. The amount of unrecognized tax benefits that, if recognized, would impact the effective tax rate are $70 million and $83 million as of July 1, 2016 and July 3, 2015, respectively, subject to certain future valuation allowance offsets.

[0001047469-16-014732:notes:193]
The following table summarizes the activity related to the Company's gross unrecognized tax benefits:

[0001047469-16-014732:notes:194]
|  | Fiscal Years Ended |
| (Dollars in millions) | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |
| Balance of unrecognized tax benefits at the beginning of the year | $ | 83 |  |  | $ | 115 |  |  | $ | 157 |  |
| Gross increase for tax positions of prior years | 12 |  |  | 12 |  |  | 10 |  |
| Gross decrease for tax positions of prior years | (8 | ) |  | (4 | ) |  | (64 | ) |
| Gross increase for tax positions of current year | 11 |  |  | 9 |  |  | 13 |  |
| Gross decrease for tax positions of current year | — |  |  | — |  |  | — |  |
| Settlements | — |  |  | (45 | ) |  | — |  |
| Lapse of statutes of limitation | (27 | ) |  | (3 | ) |  | (3 | ) |
| Non-U.S. exchange (gain)/loss | (1 | ) |  | (1 | ) |  | 2 |  |
| Balance of unrecognized tax benefits at the end of the year | $ | 70 |  |  | $ | 83 |  |  | $ | 115 |  |

[0001047469-16-014732:notes:195]
It is the Company's policy to include interest and penalties related to unrecognized tax benefits in the provision for income taxes on the Consolidated Statements of Operations. During fiscal year 2016, the Company recognized net income tax benefit for interest and penalties of $8 million as compared to net income tax expense of $26 million during fiscal year 2015, and income tax expense of $8 million during fiscal year 2014. As of July 1, 2016, the Company had $12 million of accrued interest and penalties related to unrecognized tax benefits compared to $20 million in fiscal year 2015.

[0001047469-16-014732:notes:196]
During the 12 months beginning July 2, 2016, the Company expects that its unrecognized tax benefits could be reduced by approximately $16 million as a result of the expiration of certain statutes of limitation.

[0001047469-16-014732:notes:197]
The Company is subject to taxation in many jurisdictions globally and is required to file U.S. federal, U.S. state and non-U.S. income tax returns. On April 4, 2016, the IRS approved the audit settlement reached in December 2015 regarding all disputed issues associated with the Company’s U.S. federal income tax returns for fiscal years 2008, 2009 and 2010. This audit settlement did not have a material impact on the Company’s financial statements.

[0001047469-16-014732:notes:198]
The Company is no longer subject to examination of its U.S. federal income tax returns for years prior to fiscal year 2013. With respect to U.S. state and non-U.S. income tax returns, the Company is generally no longer subject to tax examination for years ending prior to fiscal year 2005.


## us-gaap:IncomeTaxPolicyTextBlock

[0001047469-16-014732:notes:199]
Accounting for Income Taxes. The Company accounts for income taxes pursuant to ASC Topic 740 ("ASC 740"), Income Taxes.  In applying ASC 740, the Company makes certain estimates and judgments in determining income tax expense for financial statement purposes.  These estimates and judgments occur in the calculation of tax credits, recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for income tax and financial statement purposes, as well as tax liabilities associated with uncertain tax positions. The calculation of tax liabilities involves uncertainties in the application of complex tax rules and the potential for future adjustment of the Company’s uncertain tax positions by the Internal Revenue Service or other tax jurisdictions. If estimates of these tax liabilities are greater or less than actual results, an additional tax benefit or provision will result. The deferred tax assets the Company records each period depend primarily on the Company’s ability to generate future taxable income in the United States and certain non-U.S. jurisdictions. Each period, the Company evaluates the need for a valuation allowance for its deferred tax assets and, if necessary, adjusts the valuation allowance so that net deferred tax assets are recorded only to the extent the Company concludes it is more likely than not that these deferred tax assets will be realized. If the Company’s outlook for future taxable income changes significantly, the Company’s assessment of the need for, and the amount of, a valuation allowance may also change.


## us-gaap:InventoryPolicyTextBlock

[0001047469-16-014732:notes:200]
Inventory.    Inventories are valued at the lower of cost (using the first-in, first-out method) or market. Market value is based upon an estimated average selling price reduced by estimated cost of completion and disposal.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001047469-16-014732:notes:201]
The fair value and amortized cost of the Company's investments classified as available-for-sale at July 1, 2016 by remaining contractual maturity was as follows:

[0001047469-16-014732:notes:202]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 767 |  |  | $ | 767 |  |
| Due in 1 to 5 years |  | 1 |  |  | 1 |  |
| Due in 5 to 10 years |  | — |  |  | — |  |
| Thereafter |  | — |  |  | — |  |
| Total |  | $ | 768 |  |  | $ | 768 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001047469-16-014732:notes:203]
Legal, Environmental and Other Contingencies

[0001047469-16-014732:notes:204]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss.  In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment.  In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect.  Litigation is inherently uncertain and may result in adverse rulings or decisions.  Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001047469-16-014732:notes:205]
Intellectual Property Litigation

[0001047469-16-014732:notes:206]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al.—On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent Nos. 4,916,635 (the “'635 patent”) and U.S. Patent No. 5,638,267 (the “'267 patent”), misappropriation of trade secrets, breach of contract, and other claims.  In the complaint, the plaintiffs requested injunctive relief, $800 million in compensatory damages and unspecified punitive damages, including for willful infringement.  On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe US Patent No. 6,314,473 (the “'473 patent”).  The district court ruled in 2010 that the '267 patent was out of the case.

[0001047469-16-014732:notes:207]
On August 16, 2011, the district court granted in part and denied in part the Company's motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court's summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court's summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent. On July 11, 2014, the district court granted the Company's summary judgment motion regarding Convolve's only remaining cause of action, which alleged infringement of the '473 patent. The district court entered judgment in favor of the Company on July 14, 2014. Convolve filed a notice of appeal on August 13, 2014. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001047469-16-014732:notes:208]
Alexander Shukh v. Seagate Technology—On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. On March 31, 2014, the district court granted Seagate’s summary judgment motion and entered judgment in favor of Seagate. Mr. Shukh filed a notice of appeal on April 7, 2014. On October 2, 2015, the court of appeals vacated and remanded the district court’s grant of summary judgment on Mr. Shukh’s claim for correction of inventorship and affirmed the district court’s grant of summary judgment as to all other claims. On October 29, 2015, Mr. Shukh filed a petition for rehearing en banc with the court of appeals; the petition was denied on December 17, 2015. On March 16, 2016, Shukh filed a petition for writ of certiorari to the U.S. Supreme Court; the petition was denied on June 27, 2016. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001047469-16-014732:notes:209]
LEAP Co., Ltd. v. Seagate Singapore International Headquarters Pte. Ltd. and Nippon Seagate Inc.—On July 4, 2012, LEAP Co., Ltd. filed a lawsuit in the Tokyo District Court of Japan against Seagate Singapore International Headquarters Pte. Ltd., Nippon Seagate Inc. and Buffalo Inc. alleging wrongful termination of purchase agreements and other claims, and seeking approximately $38 million in damages.  On March 16, 2016, the Company and LEAP reached a settlement. As a result of the settlement, this litigation between the Company and LEAP has ended. There is no damage or loss to the Company related to this matter.

[0001047469-16-014732:notes:210]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.—On June 5, 2013, Enova Technology Corporation (“Enova”) filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995, “Cryptographic Device,” and U.S. Patent No. 7,900,057, “Cryptographic Serial ATA Apparatus and Method.” The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys’ fees, and other relief. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the ‘995 and ‘057 Patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. The Company believes the claims are without merit and intends to vigorously defend this case. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 Patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ‘057 Patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 Patent are held unpatentable. Enova has appealed PTAB’s decisions on the ‘995 Patent and the ‘057 Patent to the U.S. Court of Appeals for the Federal Circuit. A hearing before the court of appeals has not yet been scheduled. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001047469-16-014732:notes:211]
Seagate Technology LLC v. Western Digital Corp.—On October 8, 2014, the Minnesota Supreme Court ruled that the arbitration award in favor of the Company in its case against Western Digital for the misappropriation of the Company’s trade secrets should be confirmed. In the arbitration award, issued on January 23, 2012, the arbitrator determined that Western Digital and its former employee had misappropriated the Company’s trade secrets. The arbitrator awarded the Company $525 million in compensatory damages and, after adding interest, issued a final award of $630 million. Interest on the final award has been accruing at 10%. On October 14, 2014, the Company received a partial payment from Western Digital in the amount of $773 million. During the quarter ended January 2, 2015, the amount of the final award, less litigation and other related costs, was recorded by the Company in Gain on arbitration award, net, and the remaining amount received was recorded in Other, net. On April 7, 2015, the Hennepin County District Court of Minnesota (“district court”) denied Seagate’s motion for entry of judgment for an amount of additional interest owing on the arbitration award.  On January 25, 2016, the Minnesota Court of Appeals reversed and remanded the district court’s order regarding the unpaid interest. On January 27, 2016, the Company received a further payment from Western Digital in the amount of $33 million, which was the remaining balance of interest owed on the final award. This amount was recorded in Other, net in the Condensed Consolidated Statement of Operations for the three and nine months ended April 1, 2016. On January 29, 2016, the parties filed a stipulation of dismissal with the district court, ending the litigation.

[0001047469-16-014732:notes:212]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al.—On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.”  The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys’ fees, and other relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001047469-16-014732:notes:213]
Environmental Matters

[0001047469-16-014732:notes:214]
The Company's operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites.  Some of the Company's operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001047469-16-014732:notes:215]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide.  The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits.  The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws.  If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001047469-16-014732:notes:216]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity.  The Company has been identified as a potentially responsible party at several sites.  At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties.  The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001047469-16-014732:notes:217]
While the Company's ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001047469-16-014732:notes:218]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products.  For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006.  Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others.  The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products.  If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.

[0001047469-16-014732:notes:219]
Other Matters

[0001047469-16-014732:notes:220]
The Company is involved in a number of other judicial and administrative proceedings incidental to its business, and the Company may be involved in various legal proceedings arising in the normal course of its business in the future.  Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001047469-16-014732:notes:221]
Recent Accounting Pronouncements

[0001047469-16-014732:notes:222]
In May 2014, August 2015, April 2016 and May 2016, the Financial Accounting Standards Board ("FASB") issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, and ASU 2016-12 (ASC Topic 606) Revenue from Contracts with Customers, Narrow-Scope Improvements and Practical Expedients, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The amendments in these ASUs are effective for fiscal years, and interim periods within those years, beginning after December 15, 2017. Early adoption is permitted for annual periods beginning after December 15, 2016. This standard may be applied retrospectively to all prior periods presented, or retrospectively with a cumulative adjustment to retained earnings in the year of adoption. The Company is in the process of assessing the impact, if any, on its consolidated financial statements and plans to adopt the modified retrospective transition approach.

[0001047469-16-014732:notes:223]
In April 2015 and August 2015, the FASB issued ASU 2015-03 (ASC Subtopic 835-30), Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs and ASU 2015-15 (ASC Subtopic 835-30), Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements- Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting, respectively. The ASUs require that debt issuance costs related to a recognized debt liability, with the exception of those related to line-of-credit arrangements, be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability. The amendments in these ASUs are effective for fiscal years, and interim periods within those years, beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued. The adoption of this new guidance is not expected to have a material impact on the Company’s consolidated financial statements and disclosures.

[0001047469-16-014732:notes:224]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. The amendments in this ASU are effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company is in the process of assessing the impact, if any, of this ASU on its consolidated financial statements.

[0001047469-16-014732:notes:225]
In September 2015, the FASB issued ASU 2015-16 (ASC Topic 805), Business Combinations Simplifying the Accounting for Measurement-Period Adjustments. The amendments in this update require that an acquirer recognize measurement period adjustments in the period in which the adjustments are determined. The income effects of such measurement period adjustments are to be recorded in the same period’s financial statements but calculated as if the accounting had been completed as of the acquisition date. The impact of measurement period adjustments to earnings that relate to prior period financial statements are to be presented separately on the income statement or disclosed by line item. The amendments in this update are for fiscal years, including interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted for public business entities for reporting periods for which financial statements have not yet been issued. The adoption of this new guidance is not expected to have a material impact on the Company’s consolidated financial statements and disclosures.

[0001047469-16-014732:notes:226]
In November 2015, the FASB issued ASU 2015-17 (ASC Topic 740), Income Taxes Balance Sheet Classification of Deferred Taxes. The amendments in this Update are effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company early adopted this ASU for the December 2015 quarter on a prospective basis. See "Note 7. Income Taxes" for disclosure of the financial statement impact of this adoption.

[0001047469-16-014732:notes:227]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments - Overall Recognition and Measurement of Financial Assets and Financial Liabilities. The amendments in this ASU require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The amendments in this ASU are effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. Early adoption is permitted for only certain portions of the ASU. The Company is in the process of assessing the impact, if any, on its consolidated financial statements.

[0001047469-16-014732:notes:228]
In February 2016, the FASB issued ASU 2016-02 (ASC Topic 842), Leases. The ASU amends a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The amendments in this ASU are effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted.  The Company is in the process of assessing the impact on its consolidated financial statements.

[0001047469-16-014732:notes:229]
In March 2016, the FASB issued ASU 2016-09 (ASC Topic 718), Stock Compensation - Improvements to Employee Share-Based Payment Accounting. The amendments in this ASU are intended to simplify several areas of accounting for share-based compensation arrangements, including the income tax consequences, classification on the consolidated statement of cash flows and treatment of forfeitures. The amendments in this ASU are effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted. The Company is in the process of assessing the impact, if any, of this ASU on its consolidated financial statements.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001047469-16-014732:notes:230]
Basis of Presentation and Summary of Significant Accounting Policies

[0001047469-16-014732:notes:231]
Organization

[0001047469-16-014732:notes:232]
Seagate Technology plc (the "Company") is a leading provider of electronic data storage technology and solutions.  Our principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, we produce a broad range of electronic data storage products including solid state hybrid drives ("SSHD"), solid state drives ("SSD"), PCIe cards and SATA controllers. Our storage technology portfolio also includes storage subsystems, and high performance computing ("HPC") solutions.

[0001047469-16-014732:notes:233]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and most SSDs use NAND-based flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed data.

[0001047469-16-014732:notes:234]
The Company's products are designed for mission critical and nearline applications in enterprise servers and storage systems; client compute applications, where our products are designed primarily for desktop and mobile computing; and client non-compute applications, where our products are designed for a wide variety of end user devices such as digital video recorders ("DVRs"), personal data backup systems, portable external storage systems, digital media systems and surveillance systems.

[0001047469-16-014732:notes:235]
The Company's Cloud Systems and Solutions builds on the Seagate legacy to extend innovation from the device into the information infrastructure, onsite and in the cloud. Our approach to data management supports HPC, open source and software-defined solutions. Our portfolio includes HPC storage solutions, modular original equipment manufacturers ("OEM") storage systems and scale-out storage systems.

[0001047469-16-014732:notes:236]
Restricted Cash and Investments.    Restricted cash and investments represent cash and cash equivalents and investments that are restricted as to withdrawal or use for other than current operations.

[0001047469-16-014732:notes:237]
Allowances for Doubtful Accounts.    The Company maintains an allowance for uncollectible accounts receivable based upon expected collectability. This reserve is established based upon historical trends, global macroeconomic conditions and an analysis of specific exposures. The provision for doubtful accounts is recorded as a charge to Marketing and administrative expense.

[0001047469-16-014732:notes:238]
Property, Equipment and Leasehold Improvements.    Property, equipment and leasehold improvements are stated at cost. Equipment and buildings are depreciated using the straight-line method over the estimated useful lives of the assets. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated life of the asset or the remaining term of the lease. The costs of additions and substantial improvements to property, equipment and leasehold improvements, which extend the economic life of the underlying assets, are capitalized. The cost of maintenance and repairs to property, equipment and leasehold improvements are expensed as incurred.

[0001047469-16-014732:notes:239]
Establishment of Warranty Accruals.    The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company's warranty provision considers estimated product failure rates and trends (including the timing of product returns during the warranty periods), and estimated repair or replacement costs related to product quality issues, if any. The Company also exercises judgment in estimating its ability to sell certain repaired products. Should actual experience in any future period differ significantly from its estimates, the Company's future results of operations could be materially affected.

[0001047469-16-014732:notes:240]
Revenue Recognition, Sales Returns and Allowances, and Sales Incentive Programs.    The Company's revenue recognition policy complies with ASC Topic 605 (ASC 605), Revenue Recognition. Revenue from sales of products, including sales to distribution customers, is generally recognized when title and risk of loss has passed to the buyer, which typically occurs upon shipment from the Company or third party warehouse facilities, persuasive evidence of an arrangement exists, including a fixed or determinable price to the buyer, and when collectability is reasonably assured. Revenue from sales of products to certain direct retail customers and to customers in certain indirect retail channels is recognized on a sell-through basis.

[0001047469-16-014732:notes:241]
The Company records estimated product returns at the time of shipment. The Company also estimates reductions to revenue for sales incentive programs, such as price protection, and volume incentives, and records such reductions when revenue is recorded. The Company establishes certain distributor and OEM sales programs aimed at increasing customer demand. For OEM sales, rebates are typically based on an OEM customer's volume of purchases from Seagate or other agreed upon rebate programs. For the distribution channel, these programs typically involve rebates related to a distributor's level of sales, order size, advertising or point of sale activity and price protection adjustments. The Company provides for these obligations at the time that revenue is recorded based on estimated requirements. Marketing development programs are recorded as a reduction to revenue.

[0001047469-16-014732:notes:242]
Shipping and Handling.    The Company includes costs related to shipping and handling in Cost of revenue for all periods presented.

[0001047469-16-014732:notes:243]
Concentrations

[0001047469-16-014732:notes:244]
Concentration of Credit Risk.    The Company's customer base for disk drive products is concentrated with a small number of OEMs and distributors. The Company does not generally require collateral or other security to support accounts receivable. To reduce credit risk, the Company performs ongoing credit evaluations on its customers' financial condition. The Company establishes an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information. Hewlett-Packard Company and Dell Inc. each accounted for more than 10% of the Company's accounts receivable as of July 1, 2016.

[0001047469-16-014732:notes:245]
Financial instruments that potentially subject the Company to concentrations of credit risk consist primarily of cash equivalents, short-term investments and foreign currency forward exchange contracts. The Company further mitigates concentrations of credit risk in its investments through diversification, by limiting its investments in the debt securities of a single issuer, and investing in highly rated securities.

[0001047469-16-014732:notes:246]
In entering into foreign currency forward exchange contracts, the Company assumes the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and the Company has not incurred and does not expect any losses as a result of counterparty defaults.

[0001047469-16-014732:notes:247]
Supplier Concentration.    Certain of the raw materials, components and equipment used by the Company in the manufacture of its products are available from a sole supplier or a limited number of suppliers. Shortages could occur in these essential materials and components due to an interruption of supply or increased demand in the industry. If the Company were unable to procure certain materials, components or equipment at acceptable prices, it would be required to reduce its manufacturing operations, which could have a material adverse effect on its results of operations. In addition, the Company may make prepayments to certain suppliers. Should these suppliers be unable to deliver on their obligations or experience financial difficulty, the Company may not be able to recover these prepayments.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001047469-16-014732:notes:248]
Guarantees

[0001047469-16-014732:notes:249]
Indemnifications to Officers and Directors

[0001047469-16-014732:notes:250]
On May 4, 2009,  Seagate Technology, an exempted company incorporated with limited liability under the laws of the Cayman Islands (“Seagate-Cayman”), then the parent company, entered into a new form of indemnification agreement (the “Revised Indemnification Agreement”) with its officers and directors of Seagate-Cayman and its subsidiaries (each, an “Indemnitee”). The Revised Indemnification Agreement provides indemnification in addition to any of Indemnitee's indemnification rights under Seagate-Cayman's Articles of Association, applicable law or otherwise, and indemnifies an Indemnitee for certain expenses (including attorneys' fees), judgments, fines and settlement amounts actually and reasonably incurred by him or her in any action or proceeding, including any action by or in the right of Seagate-Cayman or any of its subsidiaries, arising out of his or her service as a director, officer, employee or agent of Seagate-Cayman or any of its subsidiaries or of any other entity to which he or she provides services at Seagate-Cayman's request. However, an Indemnitee shall not be indemnified under the Revised Indemnification Agreement for (i) any fraud or dishonesty in the performance of Indemnitee's duty to Seagate-Cayman or the applicable subsidiary of Seagate-Cayman or (ii) Indemnitee's conscious, intentional or willful failure to act honestly, lawfully and in good faith with a view to the best interests of Seagate-Cayman or the applicable subsidiary of Seagate-Cayman. In addition, the Revised Indemnification Agreement provides that Seagate-Cayman will advance expenses incurred by an Indemnitee in connection with enforcement of the Revised Indemnification Agreement or with the investigation, settlement or appeal of any action or proceeding against him or her as to which he or she could be indemnified.

[0001047469-16-014732:notes:251]
On July 3, 2010, pursuant to a corporate reorganization, the common shareholders of Seagate-Cayman became ordinary shareholders of Seagate Technology plc (the "Company") and Seagate-Cayman became a wholly owned subsidiary of the Company, as described more fully in the Current Report on Form 8-K filed by the Company on July 6, 2010 (the “Redomestication”). On July 27, 2010, in connection with the Redomestication, the Company, as sole shareholder of Seagate-Cayman, approved a form of deed of indemnity (the “Deed of Indemnity”), which provides for the indemnification by Seagate-Cayman of any director, officer, employee or agent of the Company, Seagate-Cayman or any subsidiary of the Company (each, a “Deed Indemnitee”), in addition to any of a Deed Indemnitee's indemnification rights under the Company's Articles of Association, applicable law or otherwise, with a similar scope to the Revised Indemnification Agreement. Seagate-Cayman entered into the Deed of Indemnity with certain Deed Indemnitees effective as of July 3, 2010 and continues to enter into the Deed of Indemnity with additional Deed Indemnitees from time to time.

[0001047469-16-014732:notes:252]
The nature of these indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay on behalf of its officers and directors. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the accompanying consolidated financial statements with respect to these indemnification obligations.

[0001047469-16-014732:notes:253]
Intellectual Property Indemnification Obligations

[0001047469-16-014732:notes:254]
The Company has entered into agreements with customers and suppliers that include limited intellectual property indemnification obligations that are customary in the industry. These guarantees generally require the Company to compensate the other party for certain damages and costs incurred as a result of third party intellectual property claims arising from these transactions. The nature of the intellectual property indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay to its customers and suppliers. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the accompanying consolidated financial statements with respect to these indemnification obligations.

[0001047469-16-014732:notes:255]
Product Warranty

[0001047469-16-014732:notes:256]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation.  Changes in the Company's product warranty liability during the fiscal years ended July 1, 2016, July 3, 2015 and June 27, 2014 were as follows:

[0001047469-16-014732:notes:257]
|  |  | Fiscal Years Ended |
| (In millions) |  | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |
| Balance, beginning of period |  | $ | 248 |  |  | $ | 273 |  |  | $ | 320 |  |
| Warranties issued |  | 125 |  |  | 147 |  |  | 177 |  |
| Repairs and replacements |  | (152 | ) |  | (187 | ) |  | (228 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | (17 | ) |  | 7 |  |  | 1 |  |
| Warranty liability assumed from acquisitions |  | 2 |  |  | 8 |  |  | 3 |  |
| Balance, end of period |  | $ | 206 |  |  | $ | 248 |  |  | $ | 273 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001047469-16-014732:notes:258]
| (Dollars in millions) |  | Useful Lifein Years |  | July 1, 2016 |  | July 3, 2015 |
| Land and land improvements |  |  |  | $ | 69 |  |  | $ | 48 |  |
| Equipment |  | 3 – 5 |  | 7,681 |  |  | 7,440 |  |
| Buildings and leasehold improvements |  | Up to 48 |  | 1,900 |  |  | 1,595 |  |
| Construction in progress |  |  |  | 234 |  |  | 547 |  |
|  |  |  |  | 9,884 |  |  | 9,630 |  |
| Less: accumulated depreciation and amortization |  |  |  | (7,724 | ) |  | (7,352 | ) |
|  |  |  |  | $ | 2,160 |  |  | $ | 2,278 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001047469-16-014732:notes:259]
Related Party Transactions

[0001047469-16-014732:notes:260]
Samsung Electronics Co. Ltd. (“Samsung”) In connection with the Company's acquisition of the Samsung HDD business, Samsung became a shareholder of the Company and appointed one of its executives to the Company's Board of Directors. On October 22, 2013, Samsung filed an amendment to its Schedule 13D indicating that it holds less than 5% of the Company's outstanding shares. Dr. Seh-Woong Jeong was appointed to our Board of Directors by Samsung and joined our Board of Directors on April 26, 2012.  He retired from our Board of Directors on October 22, 2014 and ceased to be a related party. The Company recorded revenue of $216 million from sales to Samsung for fiscal year 2014. The Company made payments to Samsung in fiscal years 2014 of $318 million, related to purchases of components and services.

[0001047469-16-014732:notes:261]
Microsoft Corporation (“Microsoft”) The Company's Chairman and Chief Executive Officer also served on the board of Microsoft until March 2014 upon his resignation and Microsoft ceased to be a related party. The Company recorded revenue of $208 million from sales to Microsoft for fiscal years 2014. The Company made payments to Microsoft in fiscal years 2014 of $1 million related to purchases of licensed software.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001047469-16-014732:notes:262]
Restructuring and Exit Costs

[0001047469-16-014732:notes:263]
During fiscal years 2016, 2015 and 2014, the Company recorded restructuring charges of $175 million, $32 million and $24 million, respectively, comprised primarily of charges related to employee termination costs and facility exit costs associated with restructuring of our workforce during each fiscal year. The Company's significant restructuring plans are described below.  All restructuring charges are reported in Restructuring and other, net on the Consolidated Statements of Operations.

[0001047469-16-014732:notes:264]
June 2016 Plan - On June 27, 2016, the Company committed to a restructuring plan (the “June 2016 Plan”) as part of the Company's efforts to reduce its cost structure to align with the current macroeconomic conditions. The June 2016 Plan included reducing worldwide headcount by approximately 1,600 employees. The June 2016 Plan is expected to be largely completed by the end of the September 2016 quarter. During fiscal year 2016, the Company recorded total restructuring charges of approximately $69 million related to the June 2016 Plan, comprised of employee termination costs. The Company made cash payments of $24 million in fiscal year 2016, comprised of employee termination costs related to the June 2016 Plan.

[0001047469-16-014732:notes:265]
February 2016 Plan - On February 15, 2016, the Company committed to a restructuring plan (the “February 2016 Plan”) intended to align our manufacturing footprint with current macroeconomic conditions. The February 2016 Plan included reducing worldwide headcount by approximately 2,000 employees. The February 2016 Plan was largely completed by the fiscal quarter ended April 1, 2016. During fiscal year 2016, the Company recorded total restructuring charges and made cash payments of approximately $15 million related to the February 2016 Plan, comprised primarily of employee termination costs.

[0001047469-16-014732:notes:266]
September 2015 Plan - On September 4, 2015, the Company committed to a restructuring plan (the “September 2015 Plan”) intended to realign its cost structure with the current macroeconomic business environment. The September 2015 Plan included reducing worldwide headcount by approximately 1,000 employees. The September 2015 Plan was largely completed by the fiscal quarter ended January 1, 2016. During fiscal year 2016, the Company recorded total restructuring charges of approximately $65 million related to the September 2015 Plan, comprised of approximately $57 million for employee termination costs and $8 million facility exit costs, respectively.  The Company made cash payments of $59 million, comprised primarily of employee termination costs related to the September 2015 Plan.

[0001047469-16-014732:notes:267]
Fiscal 2015 Plan - During fiscal year 2015, the Company recorded employee termination costs of $25 million and made cash payments of $16 million associated with a reduction in the workforce. The 2015 Plan was largely completed by fiscal year 2015. The Company did not record any material restructuring charges related to the 2015 Plan during fiscal year 2016.

[0001047469-16-014732:notes:268]
Other Restructuring and Exit Costs - During fiscal year 2016, the Company recorded restructuring charges of approximately $26 million, comprised of approximately $12 million for employee termination costs and $14 million facility exit costs. The Company made cash payments of $33 million, comprised of approximately $19 million for employee termination costs and $14 million facility exit costs related to other restructuring plans.

[0001047469-16-014732:notes:269]
The following table summarizes the Company's restructuring activities under all of the Company’s active restructuring plans for fiscal years 2016,  2015 and  2014:

[0001047469-16-014732:notes:270]
| (Dollars in millions) |  | Post-EmploymentBenefits |  | OperatingLeases |  | OtherExitCosts |  | Total |
| All Restructuring Activities |  |  |  |  |  |  |  |  |
| Accrual balances at June 28, 2013 |  | $ | 2 |  |  | $ | 15 |  |  | $ | — |  |  | $ | 17 |  |
| Restructuring charges |  | 18 |  |  | 3 |  |  | 2 |  |  | 23 |  |
| Cash payments |  | (20 | ) |  | (5 | ) |  | (2 | ) |  | (27 | ) |
| Adjustments |  | 2 |  |  | (1 | ) |  | — |  |  | 1 |  |
| Accrual balances at June 27, 2014 |  | 2 |  |  | 12 |  |  | — |  |  | 14 |  |
| Restructuring charges |  | 23 |  |  | 3 |  |  | 4 |  |  | 30 |  |
| Cash payments |  | (17 | ) |  | (6 | ) |  | (4 | ) |  | (27 | ) |
| Adjustments |  | 3 |  |  | (1 | ) |  | — |  |  | 2 |  |
| Accrual balances at July 3, 2015 |  | 11 |  |  | 8 |  |  | — |  |  | 19 |  |
| Restructuring charges |  | 151 |  |  | 14 |  |  | 10 |  |  | 175 |  |
| Cash payments |  | (113 | ) |  | (8 | ) |  | (10 | ) |  | (131 | ) |
| Adjustments |  | 1 |  |  | (1 | ) |  | — |  |  | — |  |
| Accrual balances at July 1, 2016 |  | $ | 50 |  |  | $ | 13 |  |  | $ | — |  |  | $ | 63 |  |

[0001047469-16-014732:notes:271]
Of the accrued restructuring balance of $63 million at July 1, 2016, $61 million is included in Accrued expenses and $2 million is included in Other non-current liabilities in the Company's Consolidated Balance Sheet.  Of the accrued restructuring balance of approximately $19 million at July 3, 2015, $15 million is included in Accrued expenses and $4 million is included in Other non-current liabilities in the Company's Consolidated Balance Sheet.


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001047469-16-014732:notes:272]
The following table provides details of the accounts receivable, net balance sheet item:

[0001047469-16-014732:notes:273]
| (Dollars in millions) |  | July 1, 2016 |  | July 3, 2015 |
| Accounts receivable |  | $ | 1,327 |  |  | $ | 1,744 |  |
| Allowance for doubtful accounts |  | (9 | ) |  | (9 | ) |
|  |  | $ | 1,318 |  |  | $ | 1,735 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001047469-16-014732:notes:274]
| (Dollars in millions) |  | UnrealizedGains (Losses)on Cash FlowHedges |  | UnrealizedGains (Losses)on MarketableSecurities (a) |  | UnrealizedGains (Losses)on Post-Retirement Plans |  | ForeignCurrencyTranslationAdjustments |  | Total |
| Balance at June 27, 2014 |  | $ | (1 | ) |  | $ | — |  |  | $ | (10 | ) |  | $ | 9 |  |  | $ | (2 | ) |
| Other comprehensive income (loss) before reclassifications |  | (11 | ) |  | — |  |  | (5 | ) |  | (25 | ) |  | (41 | ) |
| Amounts reclassified from AOCI |  | 13 |  |  | — |  |  | — |  |  | — |  |  | 13 |  |
| Other comprehensive income (loss) |  | 2 |  |  | — |  |  | (5 | ) |  | (25 | ) |  | (28 | ) |
| Balance at July 3, 2015 |  | 1 |  |  | — |  |  | (15 | ) |  | (16 | ) |  | (30 | ) |
| Other comprehensive income (loss) before reclassifications |  | (4 | ) |  | — |  |  | 8 |  |  | (1 | ) |  | 3 |  |
| Amounts reclassified from AOCI |  | 2 |  |  | — |  |  | — |  |  | — |  |  | 2 |  |
| Other comprehensive income (loss) |  | (2 | ) |  | — |  |  | 8 |  |  | (1 | ) |  | 5 |  |
| Balance at July 1, 2016 |  | $ | (1 | ) |  | $ | — |  |  | $ | (7 | ) |  | $ | (17 | ) |  | $ | (25 | ) |

[0001047469-16-014732:notes:275]
___________________________________________

[0001047469-16-014732:notes:276]
| (a) | The cost of a security sold or the amount reclassified out of AOCI into earnings was determined using the specific identification method. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001047469-16-014732:notes:277]
| (Dollars in millions) |  | July 1, 2016 |  | July 3, 2015 |
| Raw materials and components |  | $ | 307 |  |  | $ | 352 |  |
| Work-in-process |  | 297 |  |  | 239 |  |
| Finished goods |  | 264 |  |  | 402 |  |
|  |  | $ | 868 |  |  | $ | 993 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001047469-16-014732:notes:278]
| (Dollars in millions) |  | July 1, 2016 |  | July 3, 2015 |
| Vendor non-trade receivables |  | $ | 66 |  |  | $ | 66 |  |
| Other |  | 150 |  |  | 167 |  |
|  |  | $ | 216 |  |  | $ | 233 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001047469-16-014732:notes:279]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | July 1, 2016 |  | July 3, 2015 |  | June 27, 2014 |
| Revenue from external customers (a): |  |  |  |  |  |  |
| Singapore |  | $ | 5,354 |  |  | $ | 6,844 |  |  | $ | 6,828 |  |
| United States |  | 3,376 |  |  | 3,929 |  |  | 3,679 |  |
| The Netherlands |  | 1,813 |  |  | 2,291 |  |  | 2,652 |  |
| Other |  | 617 |  |  | 675 |  |  | 565 |  |
| Consolidated |  | $ | 11,160 |  |  | $ | 13,739 |  |  | $ | 13,724 |  |
| Long-lived assets: |  |  |  |  |  |  |
| United States |  | $ | 1,029 |  |  | $ | 725 |  |  | $ | 500 |  |
| Singapore |  | 726 |  |  | 900 |  |  | 788 |  |
| Thailand |  | 349 |  |  | 328 |  |  | 398 |  |
| Malaysia |  | 201 |  |  | 248 |  |  | 146 |  |
| China |  | 115 |  |  | 138 |  |  | 167 |  |
| Other |  | 444 |  |  | 568 |  |  | 680 |  |
| Consolidated |  | $ | 2,864 |  |  | $ | 2,907 |  |  | $ | 2,679 |  |

[0001047469-16-014732:notes:280]
| (a) | Revenue is attributed to countries based on the shipping location. |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001047469-16-014732:notes:281]
| (Dollars in millions) |  | Balance atBeginning ofPeriod |  | Charges(Credit) toOperations |  | Deductions (a) |  | Balance atEnd ofPeriod |
| Fiscal year ended June 27, 2014 |  | $ | 8 |  |  | 4 |  |  | — |  |  | $ | 12 |  |
| Fiscal year ended July 3, 2015 |  | $ | 12 |  |  | — |  |  | (3 | ) |  | $ | 9 |  |
| Fiscal year ended July 1, 2016 |  | $ | 9 |  |  | 1 |  |  | (1 | ) |  | $ | 9 |  |

[0001047469-16-014732:notes:282]
| (a) | Uncollectible accounts written off, net of recoveries. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001047469-16-014732:notes:283]
Business Segment and Geographic Information

[0001047469-16-014732:notes:284]
The Company has concluded that its manufacture and distribution of electronic storage solutions constitutes one reporting segment. The Company's manufacturing operations are based on technology platforms that are used to produce various electronic storage solutions that serve multiple applications and markets. The Company's main technology platforms are primarily focused around areal density of media and read/write head technologies. In addition, the Company also invests in certain other technology platforms including motors, servo formatting read/write channels, solid state and other technologies.  The Company has determined that its Chief Executive Officer is the Company's chief operating decision maker ("CODM") as he is responsible for reviewing and approving investments in the Company's technology platforms and manufacturing infrastructure.

[0001047469-16-014732:notes:285]
In fiscal years 2016, 2015 and 2014, Dell Inc. accounted for approximately 12%, 14% and 13% of consolidated revenue, respectively. In fiscal years 2015 and 2014, Hewlett-Packard Company accounted for approximately 12% and 13% of consolidated revenue, respectively. In fiscal year 2016, HP Inc., formerly known as Hewlett-Packard Company, completed its separation with Hewlett Packard Enterprise Company, and each company accounted for less than 10% of our consolidated revenue. No other customer accounted for more than 10% of consolidated revenue in any year presented.

[0001047469-16-014732:notes:286]
Other long-lived assets consist of property, equipment and leasehold improvements, other intangible assets, capital leases, equity investments and other non-current assets as recorded by the Company's operations in each area.

[0001047469-16-014732:notes:287]
The following table summarizes the Company's operations by geographic area:


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001047469-16-014732:notes:288]
Shareholders' Equity

[0001047469-16-014732:notes:289]
Share Capital

[0001047469-16-014732:notes:290]
The Company's authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 298,572,217 shares were outstanding as of July 1, 2016, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of July 1, 2016.

[0001047469-16-014732:notes:291]
Ordinary shares - Holders of ordinary shares are entitled to receive dividends when and as declared by the Company's board of directors (the "Board of Directors"). Upon any liquidation, dissolution, or winding up of the Company, after required payments are made to holders of preferred shares, any remaining assets of the Company will be distributed ratably to holders of the preferred and ordinary shares. Holders of shares are entitled to one vote per share on all matters upon which the ordinary shares are entitled to vote, including the election of directors.

[0001047469-16-014732:notes:292]
Preferred shares - The Company may issue preferred shares in one or more series, up to the authorized amount, without shareholder approval. The Board of Directors is authorized to establish from time to time the number of shares to be included in each series, and to fix the rights, preferences and privileges of the shares of each wholly unissued series and any of its qualifications, limitations or restrictions. The Board of Directors can also increase or decrease the number of shares of a series, but not below the number of shares of that series then outstanding, without any further vote or action by the shareholders.

[0001047469-16-014732:notes:293]
The Board of Directors may authorize the issuance of preferred shares with voting or conversion rights that could harm the voting power or other rights of the holders of the ordinary shares. The issuance of preferred shares, while providing flexibility in connection with possible acquisitions and other corporate purposes, could, among other things, have the effect of delaying, deferring or preventing a change in control of the Company and might harm the market price of its ordinary shares and the voting and other rights of the holders of ordinary shares.

[0001047469-16-014732:notes:294]
Repurchases of Equity Securities

[0001047469-16-014732:notes:295]
On July 24, 2013, the Board of Directors authorized the Company to repurchase an additional $2.5 billion of its outstanding ordinary shares.

[0001047469-16-014732:notes:296]
On April 22, 2015, the Board of Directors authorized the Company to repurchase an additional $2.5 billion of its outstanding ordinary shares.

[0001047469-16-014732:notes:297]
All repurchases are effected as redemptions in accordance with the Company's Articles of Association.

[0001047469-16-014732:notes:298]
As of July 1, 2016, $1.8 billion remained available for repurchase under the existing repurchase authorization limit.

[0001047469-16-014732:notes:299]
The following table sets forth information with respect to repurchases of the Company's ordinary shares during fiscal years 2016, 2015 and 2014:

[0001047469-16-014732:notes:300]
_______________________________

[0001047469-16-014732:notes:301]
| (a) | Including net share settlement of $56 million for 1 million shares in connection with tax withholding related to vesting of restricted stock units. |


## us-gaap:SubsequentEventsTextBlock

[0001047469-16-014732:notes:302]
Subsequent Events

[0001047469-16-014732:notes:303]
July 2016 Restructuring Plan

[0001047469-16-014732:notes:304]
On July 11, 2016, the Company committed to an additional restructuring plan (the “July 2016 Plan”) for continued consolidation of its global footprint across Asia, EMEA and the Americas. The July 2016 Plan included reducing worldwide headcount by approximately 6,500 employees. The July 2016 Plan, which the Company expects to be largely completed by the end of fiscal year 2017, is expected to result in total pretax charges of approximately $164 million in fiscal year 2017. These charges are expected to consist of cash expenditures of approximately $82 million of employee termination costs and $51 million of other exit costs, as well as other non-cash charges of approximately $31 million.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001047469-16-014732:notes:305]
Balance Sheet Information

[0001047469-16-014732:notes:306]
Investments

[0001047469-16-014732:notes:307]
As of July 1, 2016, the Company's Other current assets included of $7 million in restricted cash and investments held as collateral at banks for various performance obligations

[0001047469-16-014732:notes:308]
As of July 1, 2016, the Company had no material available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months.  The Company determined no available-for-sale securities were other-than-temporarily impaired as of July 1, 2016.

[0001047469-16-014732:notes:309]
Equity securities which do not have a contractual maturity date are not included in the above table.

[0001047469-16-014732:notes:310]
As of July 3, 2015, the Company's Other current assets included of $7 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001047469-16-014732:notes:311]
As of July 3, 2015, the Company had no available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months.  The Company determined no available-for-sale securities were other-than-temporarily impaired as of July 3, 2015.

[0001047469-16-014732:notes:312]
Accounts Receivable, net

[0001047469-16-014732:notes:313]
Activity in the allowance for doubtful accounts is as follows:

[0001047469-16-014732:notes:314]
Inventories

[0001047469-16-014732:notes:315]
The following table provides details of the inventory balance sheet item:

[0001047469-16-014732:notes:316]
Other Current Assets

[0001047469-16-014732:notes:317]
The following table provides details of the other current assets balance sheet item:

[0001047469-16-014732:notes:318]
Other current assets include non-trade receivables from certain manufacturing vendors resulting from the sale of components to these vendors who manufacture completed sub-assemblies or finished goods for the Company. The Company does not reflect the sale of these components in revenue and does not recognize any profits on these sales. The costs of the completed sub-assemblies are included in inventory upon purchase from the vendors.

[0001047469-16-014732:notes:319]
Property, Equipment and Leasehold Improvements, net

[0001047469-16-014732:notes:320]
The components of property, equipment and leasehold improvements, net were as follows:

[0001047469-16-014732:notes:321]
Depreciation expense, which includes amortization of leasehold improvements, was $641 million, $689 million and $748 million for fiscal years 2016, 2015 and 2014, respectively. Interest on borrowings related to eligible capital expenditures is capitalized as part of the cost of the qualified assets and amortized over the estimated useful lives of the assets. During fiscal years     2016, 2015 and 2014, the Company capitalized interest of $13 million, $15 million and $7 million, respectively.

[0001047469-16-014732:notes:322]
During fiscal year ended  2016, the Company determined it would discontinue the use of certain manufacturing property and equipment in the short-term, and that certain other manufacturing property and equipment was permanently impaired, and as a result recognized a charge of $53 million from the write-off and accelerated depreciation of of these fixed assets. This amount was recorded in Cost of revenue in the Consolidated Statement of Operations. The Company did not record any material impairment charges in fiscal years  2015 and 2014.

[0001047469-16-014732:notes:323]
Accumulated Other Comprehensive Income (Loss) (“AOCI”)

[0001047469-16-014732:notes:324]
The components of AOCI, net of tax, were as follows:
