# STX notes — 0001137789-22-000014


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001137789-22-000014:notes:1]
[same as prior period, unchanged from 0001137789-21-000128:notes:1]

[0001137789-22-000014:notes:2]
[same as prior period, unchanged from 0001137789-21-000128:notes:2]

[0001137789-22-000014:notes:3]
[same as prior period, unchanged from 0001137789-21-000128:notes:3]

[0001137789-22-000014:notes:4]
[same as prior period, unchanged from 0001137789-21-000128:notes:4]

[0001137789-22-000014:notes:5]
[same as prior period, unchanged from 0001137789-21-000128:notes:5]

[0001137789-22-000014:notes:6]
[same as prior period, unchanged from 0001137789-21-000128:notes:6]

[0001137789-22-000014:notes:7]
[same as prior period, unchanged from 0001137789-21-000128:notes:7]

[0001137789-22-000014:notes:8]
The unaudited Condensed Consolidated Financial Statements of the Company and the accompanying notes were prepared in accordance with United States (“U.S.”) Generally Accepted Accounting Principles (“GAAP”). The Company’s unaudited condensed consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

[0001137789-22-000014:notes:9]
[same as prior period, unchanged from 0001137789-21-000128:notes:9]

[0001137789-22-000014:notes:10]
The Company’s consolidated financial statements for the fiscal year ended July 2, 2021 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 6, 2021. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 2, 2021, and the notes thereto, are adequate to make the information presented not misleading. The results of operations and the cash flows for the three and six months ended December 31, 2021 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending July 1, 2022.

[0001137789-22-000014:notes:11]
[same as prior period, unchanged from 0001137789-21-000128:notes:11]

[0001137789-22-000014:notes:12]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three and six months ended December 31, 2021 consisted of 13 and 26 weeks, respectively, and the three and six months ended January 1, 2021 consisted of 13 and 26 weeks, respectively. Fiscal year 2022, which ends on July 1, 2022, is comprised of 52 weeks and fiscal year 2021, which ended on July 2, 2021, was comprised of 52 weeks. The fiscal quarters ended December 31, 2021, October 1, 2021 and January 1, 2021, are also referred to herein as the “December 2021 quarter”, the “September 2021 quarter” and the “December 2020 quarter”, respectively.

[0001137789-22-000014:notes:13]
[same as prior period, unchanged from 0001137789-21-000128:notes:13]

[0001137789-22-000014:notes:14]
[same as prior period, unchanged from 0001137789-21-000128:notes:14]

[0001137789-22-000014:notes:15]
Recently Adopted Accounting Pronouncements

[0001137789-22-000014:notes:16]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued ASU 2019-12 (ASC Topic 740), Simplifying the Accounting for Income Taxes. This ASU simplifies accounting for income taxes by removing certain exceptions to the general principles and amending existing guidance to improve consistent application. This ASU became effective and the Company adopted the guidance in the September 2021 quarter. The adoption of this ASU did not have an impact on the Company’s condensed consolidated financial statements.

[0001137789-22-000014:notes:17]
In July 2021, the FASB issued ASU 2021-05 (ASC Topic 842), Lessors—Certain Leases with Variable Lease Payments. This ASU requires lessors to classify and account for a lease with variable lease payments that do not depend on a reference index or a rate as an operating lease if the lease would have been classified as a sales-type lease or a direct financing lease and the lessor would have otherwise recognized a day-one loss. The Company adopted the guidance in the September 2021 quarter on a prospective basis. The adoption of this ASU did not have an impact on the Company’s condensed consolidated financial statements.

[0001137789-22-000014:notes:18]
Recently Issued Accounting Pronouncements


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001137789-22-000014:notes:19]
In March 2020, the FASB issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. Adoption of the expedients and exceptions is permitted upon issuance of this update through December 31, 2022. The Company does not expect the adoption of this ASU to have a material impact on its condensed consolidated financial statements.

[0001137789-22-000014:notes:20]
In November 2021, the FASB issued ASU 2021-10 (ASC Topic 832), Disclosures by Business Entities about Government Assistance. This ASU requires annual disclosures that increase the transparency of transactions involving government grants, including (1) the type of transactions, (2) the accounting for those transactions and (3) the effect of those transactions on an entity’s financial statements. The Company is required to adopt this new accounting pronouncement in the first quarter of fiscal year 2023. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001137789-22-000014:notes:21]
Balance Sheet Information
Available-for-sale Debt Securities

[0001137789-22-000014:notes:22]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of December 31, 2021 and July 2, 2021:

[0001137789-22-000014:notes:23]
|  |  | December 31,2021 |  | July 2,2021 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 435 |  |  | $ | — |  |  | $ | 435 |  |  | $ | 552 |  |  | $ | — |  |  | $ | 552 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 36 |  |  | — |  |  | 36 |  |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 472 |  |  | $ | — |  |  | $ | 472 |  |  | $ | 571 |  |  | $ | — |  |  | $ | 571 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 434 |  |  |  |  |  |  | $ | 551 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 36 |  |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 472 |  |  |  |  |  |  | $ | 571 |  |

[0001137789-22-000014:notes:24]
As of both December 31, 2021 and July 2, 2021, the Company’s Other current assets included $2 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001137789-22-000014:notes:25]
As of December 31, 2021 and July 2, 2021, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no impairment related to credit losses for available-for-sale debt securities as of December 31, 2021 and July 2, 2021.

[0001137789-22-000014:notes:26]
The fair value and amortized cost of the Company’s investments classified as available-for-sale debt securities as of December 31, 2021, by remaining contractual maturity were as follows:

[0001137789-22-000014:notes:27]
| (Dollars in millions) |  | Amortized Cost |  | Fair Value |
| Due in less than 1 year |  | $ | 436 |  |  | $ | 436 |  |
| Due in 1 to 5 years |  | 28 |  |  | 28 |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | 8 |  |  | 8 |  |
| Total |  | $ | 472 |  |  | $ | 472 |  |

[0001137789-22-000014:notes:28]
[same as prior period, unchanged from 0001137789-21-000128:notes:27]

[0001137789-22-000014:notes:29]
[same as prior period, unchanged from 0001137789-21-000128:notes:28]

[0001137789-22-000014:notes:30]
| (Dollars in millions) |  | December 31,2021 |  |  |  | July 2,2021 |  | January 1,2021 |  |  |  | July 3,2020 |
| Cash and cash equivalents |  | $ | 1,535 |  |  |  |  | $ | 1,209 |  |  | $ | 1,799 |  |  |  |  | $ | 1,722 |  |
| Restricted cash included in Other current assets |  | 2 |  |  |  |  | 2 |  |  | 2 |  |  |  |  | 2 |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  | $ | 1,537 |  |  |  |  | $ | 1,211 |  |  | $ | 1,801 |  |  |  |  | $ | 1,724 |  |

[0001137789-22-000014:notes:31]
[same as prior period, unchanged from 0001137789-21-000128:notes:30]

[0001137789-22-000014:notes:32]
[same as prior period, unchanged from 0001137789-21-000128:notes:31]

[0001137789-22-000014:notes:33]
| (Dollars in millions) |  | December 31,2021 |  | July 2,2021 |
| Raw materials and components |  | $ | 474 |  |  | $ | 375 |  |
| Work-in-process |  | 463 |  |  | 443 |  |
| Finished goods |  | 350 |  |  | 386 |  |
| Total inventories |  | $ | 1,287 |  |  | $ | 1,204 |  |

[0001137789-22-000014:notes:34]
[same as prior period, unchanged from 0001137789-21-000128:notes:33]

[0001137789-22-000014:notes:35]
[same as prior period, unchanged from 0001137789-21-000128:notes:34]

[0001137789-22-000014:notes:36]
| (Dollars in millions) |  | December 31,2021 |  | July 2,2021 |
| Property, equipment and leasehold improvements |  | $ | 10,521 |  |  | $ | 10,378 |  |
| Accumulated depreciation and amortization |  | (8,305) |  |  | (8,197) |  |
| Property, equipment and leasehold improvements, net |  | $ | 2,216 |  |  | $ | 2,181 |  |

[0001137789-22-000014:notes:37]
[same as prior period, unchanged from 0001137789-21-000128:notes:36]

[0001137789-22-000014:notes:38]
[same as prior period, unchanged from 0001137789-21-000128:notes:37]

[0001137789-22-000014:notes:39]
| (Dollars in millions) |  | December 31,2021 |  | July 2,2021 |
| Dividends payable |  | $ | 154 |  |  | $ | 153 |  |
| Other accrued expenses |  | 501 |  |  | 455 |  |
| Total |  | $ | 655 |  |  | $ | 608 |  |

[0001137789-22-000014:notes:40]
[same as prior period, unchanged from 0001137789-21-000128:notes:39]

[0001137789-22-000014:notes:41]
[same as prior period, unchanged from 0001137789-21-000128:notes:40]

[0001137789-22-000014:notes:42]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  |  |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at July 2, 2021 |  | $ | (18) |  |  |  |  | $ | (22) |  |  | $ | (1) |  |  | $ | (41) |  |
| Other comprehensive income before reclassifications |  | 2 |  |  |  |  | 1 |  |  | — |  |  | 3 |  |
| Amounts reclassified from AOCL |  | 12 |  |  |  |  | 1 |  |  | — |  |  | 13 |  |
| Other comprehensive income |  | 14 |  |  |  |  | 2 |  |  | — |  |  | 16 |  |
| Balance at December 31, 2021 |  | $ | (4) |  |  |  |  | $ | (20) |  |  | $ | (1) |  |  | $ | (25) |  |
| Balance at July 3, 2020 |  | $ | (24) |  |  |  |  | $ | (26) |  |  | $ | (16) |  |  | $ | (66) |  |
| Other comprehensive income (loss) before reclassifications |  | 16 |  |  |  |  | (1) |  |  | — |  |  | 15 |  |
| Amounts reclassified from AOCL |  | (2) |  |  |  |  | 2 |  |  | 15 |  |  | 15 |  |
| Other comprehensive income |  | 14 |  |  |  |  | 1 |  |  | 15 |  |  | 30 |  |
| Balance at January 1, 2021 |  | $ | (10) |  |  |  |  | $ | (25) |  |  | $ | (1) |  |  | $ | (36) |  |


## us-gaap:DebtDisclosureTextBlock

[0001137789-22-000014:notes:43]
During the six months ended January 1, 2021, $9 million aggregate principal amount of the 2022 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. 
2023 Notes. During the six months ended January 1, 2021, $5 million aggregate principal amount of the 2023 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss of $1 million on repurchases during the six months ended January 1, 2021, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

[0001137789-22-000014:notes:44]
Credit Agreement

[0001137789-22-000014:notes:45]
The Company’s subsidiary, Seagate HDD Cayman, entered into a credit agreement on February 20, 2019, which was amended on September 16, 2019, January 13, 2021, May 18, 2021 and October 14, 2021 (the “Credit Agreement”).

[0001137789-22-000014:notes:46]
Prior to the October 14, 2021 amendment, the Credit Agreement provided a term loan facility in an aggregate principal amount of $500 million and a $1.725 billion senior unsecured revolving credit facility (“Revolving Credit Facility”). The September 2019 Term Loan had a final maturity date of September 16, 2025 and the Revolving Credit Facility had a final maturity of February 20, 2024. On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the September 2019 Term Loan.

[0001137789-22-000014:notes:47]
On October 14, 2021, STX and Seagate HDD Cayman entered into an amendment to the Credit Agreement (“Fifth Amendment”), which provides for a new term loan facility in the aggregate principal amount of $1.2 billion that was extended in two tranches of $600 million each (“Term Loan A1” and “Term Loan A2” and together the “Term Loans”). Term Loan A1 and Term Loan A2 were each drawn in full on the closing date for the Fifth Amendment. The proceeds of the Term Loans may be used for general corporate purposes, to refinance or repay the September 2019 Term Loan and to refinance or repay the 2022 Notes. Term Loan A1 bears interest at a rate of LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company. Term Loan A1 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of September 16, 2025. Term Loan A2 bears interest at a rate of LIBOR plus a variable margin ranging from 1.25% to 2.5% that will be determined based on the corporate credit rating of the Company. Term Loan A2 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of July 30, 2027. On October 14, 2021, Seagate HDD Cayman utilized part of the proceeds of Term Loan A1 to fully repay the $475 million principal amount outstanding of the September 2019 Term Loan.

[0001137789-22-000014:notes:48]
In addition, pursuant to the Fifth Amendment, the maturity date for the revolving loan commitments under the Revolving Credit Facility was extended until October 14, 2026, the revolving commitments were increased to $1.75 billion and the interest rate margins for the revolving loans were amended to LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company.

[0001137789-22-000014:notes:49]
STX and certain of its material subsidiaries, including STUC, fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loans.

[0001137789-22-000014:notes:50]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of December 31, 2021 and expects to be in compliance for the next 12 months. As of December 31, 2021, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001137789-22-000014:notes:51]
At December 31, 2021, future principal payments on long-term debt were as follows (in millions):

[0001137789-22-000014:notes:52]
| Fiscal Year |  | Amount |
| Remainder of 2022 |  | $ | 220 |  |
| 2023 |  | 585 |  |
| 2024 |  | 560 |  |
| 2025 |  | 562 |  |
| 2026 |  | 563 |  |
| Thereafter |  | 3,445 |  |
| Total |  | $ | 5,935 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001137789-22-000014:notes:53]
Income Taxes
The Company recorded income tax provisions of $13 million and $20 million for the three and six months ended December 31, 2021, respectively. The discrete items in the income tax provision were not material for the three months ended December 31, 2021. The income tax provision for the six months ended December 31, 2021 included approximately $9 million of net discrete tax benefit, primarily associated with net excess tax benefits related to share-based compensation expense.

[0001137789-22-000014:notes:54]
During the six months ended December 31, 2021, the Company’s unrecognized tax benefits excluding interest and penalties increased by approximately $7 million to $115 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. During the twelve months beginning January 1, 2022, the Company expects that its unrecognized tax benefits could be reduced by an immaterial amount, as a result of the expiration of certain statutes of limitation.

[0001137789-22-000014:notes:55]
The Company recorded income tax provisions of $11 million and $9 million for the three and six months ended January 1, 2021, respectively. The discrete items in the income tax provision were not material for the three months ended January 1, 2021. The income tax provision for the six months ended January 1, 2021 included approximately $11 million of net discrete tax benefit, primarily associated with net excess tax benefits related to share-based compensation expense and postponement of the previously enacted United Kingdom tax rate change in the quarter ended October 2, 2020.

[0001137789-22-000014:notes:56]
The Company’s income tax provision recorded for the three and six months ended December 31, 2021 and the three and six months ended January 1, 2021 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001137789-22-000014:notes:57]
Restructuring and Exit Costs
For the three and six months ended December 31, 2021, the Company recorded restructuring charges of $1 million and $2 million, respectively. For the three and six months ended January 1, 2021, the Company recorded restructuring charges of $2 million and $3 million, respectively. The Company’s restructuring plans are comprised primarily of charges related to workforce reduction costs and facilities and other exit costs. All restructuring charges are reported in Restructuring and other, net on the Company’s Condensed Consolidated Statements of Operations.

[0001137789-22-000014:notes:58]
[same as prior period, unchanged from 0001137789-21-000128:notes:65]

[0001137789-22-000014:notes:59]
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at July 2, 2021 |  | $ | 2 |  |  | $ | 6 |  |  | $ | 8 |  |
| Restructuring charges |  | 2 |  |  | — |  |  | 2 |  |
| Cash payments |  | (2) |  |  | (2) |  |  | (4) |  |
| Accrual balances at December 31, 2021 |  | $ | 2 |  |  | $ | 4 |  |  | $ | 6 |  |
| Total costs incurred inception to date as of December 31, 2021 |  | $ | 65 |  |  | $ | 23 |  |  | $ | 88 |  |
| Total expected charges to be incurred as of December 31, 2021 |  | $ | — |  |  | $ | 8 |  |  | $ | 8 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001137789-22-000014:notes:60]
Derivative Financial Instruments
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies.

[0001137789-22-000014:notes:61]
The Company has entered into certain interest rate swap agreements to convert the variable interest rate on its Term Loans to fixed interest rates. The objective of the interest rate swap agreements is to eliminate the variability of interest payment cash flows associated with the variable interest rate under the Term Loans. The Company designated the interest rate swaps as cash flow hedges. As of December 31, 2021, the aggregate notional amount of the Company’s interest-rate swap contracts was $1.2 billion, of which $600 million will mature in September 2025 and $600 million will mature in July 2027.

[0001137789-22-000014:notes:62]
The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives on its Condensed Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The amount of net unrealized loss on cash flow hedges was $4 million and $18 million as of December 31, 2021 and as of July 2, 2021, respectively. As of December 31, 2021, the amount of existing net losses related to cash flow hedges recorded in Accumulated other comprehensive loss included a net loss of $10 million that is expected to be reclassified to earnings within twelve months.

[0001137789-22-000014:notes:63]
The Company de-designates its cash flow hedges when the forecasted hedged transactions affect earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss on the Company’s Condensed Consolidated Balance Sheets are reclassified into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company recognized a net loss of $6 million and $3 million in Cost of revenue and Interest expense, respectively, related to the loss of hedge designation on discontinued cash flow hedges during the three months ended December 31, 2021. The Company recognized a net loss of $8 million and $4 million in Cost of revenue and Interest expense, respectively, related to the loss of hedge designation on discontinued cash flow hedges during the six months ended December 31, 2021. The Company recognized a net gain of $4 million in Cost of revenue related to the loss of hedge designation on discontinued cash flow hedges during the three and six months ended January 1, 2021. The Company recognized a net loss of $2 million and $4 million in Other, net related to the loss of hedge designation on discontinued cash flow hedges during the three and six months ended January 1, 2021, respectively.

[0001137789-22-000014:notes:64]
[same as prior period, unchanged from 0001137789-21-000128:notes:71]

[0001137789-22-000014:notes:65]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of December 31, 2021 and July 2, 2021. All of the foreign currency forward exchange contracts mature within 12 months.

[0001137789-22-000014:notes:66]
|  |  | As of December 31, 2021 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Singapore Dollar |  | $ | 170 |  |  | $ | 54 |  |
| Thai Baht |  | 130 |  |  | 42 |  |
| Chinese Renminbi |  | 84 |  |  | 22 |  |
| British Pound Sterling |  | 65 |  |  | 18 |  |
|  |  | $ | 449 |  |  | $ | 136 |  |

[0001137789-22-000014:notes:67]
[same as prior period, unchanged from 0001137789-21-000128:notes:74]

[0001137789-22-000014:notes:68]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its non-qualified deferred compensation plan: the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP’s liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP’s liabilities due to changes in the value of the investment options made by employees. As of December 31, 2021, the notional investments underlying the TRS amounted to $133 million and the contract term was through January 2022, settled on a monthly basis, limiting counterparty performance risk. As of January 25, 2022, the contract term of the TRS was extended through January 2023. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP’s liabilities.

[0001137789-22-000014:notes:69]
The following tables show the Company’s derivative instruments measured at gross fair value as reflected in the Condensed Consolidated Balance Sheets as of December 31, 2021 and July 2, 2021:

[0001137789-22-000014:notes:70]
|  |  | As of December 31, 2021 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance Sheet Location |  | Fair Value |  | Balance Sheet Location |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 1 |  |  | Accrued expenses |  | $ | (2) |  |
| Interest rate swap |  | Other current assets |  | 2 |  |  | Accrued expenses |  | (5) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 1 |  |  | Accrued expenses |  | (3) |  |
| Total derivatives |  |  |  | $ | 4 |  |  |  |  | $ | (10) |  |

[0001137789-22-000014:notes:71]
[same as prior period, unchanged from 0001137789-21-000128:notes:78]

[0001137789-22-000014:notes:72]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three and six months ended December 31, 2021:

[0001137789-22-000014:notes:73]
|  |  |  |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | For the Three Months |  | For the Six Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 2 |  |  | $ | (2) |  |
| Total return swap |  | Operating expenses |  | 7 |  |  | 6 |  |

[0001137789-22-000014:notes:74]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
|  | For the Three Months |  | For the Six Months |  |  | For the Three Months |  | For the Six Months |  |  | For the Three Months |  | For the Six Months |
| Foreign currency forward exchange contracts |  | $ | 4 |  |  | $ | (5) |  |  | Cost of revenue |  | $ | (6) |  |  | $ | (8) |  |  | Other, net |  | $ | — |  |  | $ | 1 |  |
| Interest rate swap |  | 7 |  |  | 7 |  |  | Interest expense |  | (3) |  |  | (4) |  |  | Interest expense |  | — |  |  | — |  |

[0001137789-22-000014:notes:75]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three and six months ended January 1, 2021:

[0001137789-22-000014:notes:76]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |
|  |  | For the Three Months |  | For the Six Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 6 |  |  | $ | 14 |  |
| Total return swap |  | Operating expenses |  | $ | 11 |  |  | $ | 16 |  |

[0001137789-22-000014:notes:77]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
|  | For the Three Months |  | For the Six Months |  |  | For the Three Months |  | For the Six Months |  |  | For the Three Months |  | For the Six Months |
| Foreign currency forward exchange contracts |  | $ | 11 |  |  | $ | 15 |  |  | Cost of revenue |  | $ | 4 |  |  | $ | 4 |  |  | Other, net |  | $ | 1 |  |  | $ | 1 |  |
| Interest rate swap |  | 1 |  |  | 1 |  |  | Interest expense |  | (2) |  |  | (4) |  |  | Interest expense |  | — |  |  | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001137789-22-000014:notes:78]
[same as prior period, unchanged from 0001137789-21-000128:notes:84]

[0001137789-22-000014:notes:79]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact, and it considers assumptions that market participants would use when pricing the asset or liability.

[0001137789-22-000014:notes:80]
[same as prior period, unchanged from 0001137789-21-000128:notes:86]

[0001137789-22-000014:notes:81]
[same as prior period, unchanged from 0001137789-21-000128:notes:87]

[0001137789-22-000014:notes:82]
[same as prior period, unchanged from 0001137789-21-000128:notes:88]

[0001137789-22-000014:notes:83]
[same as prior period, unchanged from 0001137789-21-000128:notes:89]

[0001137789-22-000014:notes:84]
[same as prior period, unchanged from 0001137789-21-000128:notes:90]

[0001137789-22-000014:notes:85]
The Company considers an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis and views an inactive market as one in which there are few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, the Company’s or the counterparty’s non-performance risk is considered in determining the fair values of liabilities and assets, respectively.

[0001137789-22-000014:notes:86]
[same as prior period, unchanged from 0001137789-21-000128:notes:92]

[0001137789-22-000014:notes:87]
[same as prior period, unchanged from 0001137789-21-000128:notes:93]

[0001137789-22-000014:notes:88]
|  |  | December 31, 2021 |  | July 2, 2021 |
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 434 |  |  | $ | — |  |  | $ | — |  |  | $ | 434 |  |  | $ | 551 |  |  | $ | — |  |  | $ | — |  |  | $ | 551 |  |
| Total cash equivalents |  | 434 |  |  | — |  |  | — |  |  | 434 |  |  | 551 |  |  | — |  |  | — |  |  | 551 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | — |  |  | — |  |  | 36 |  |  | 36 |  |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Derivative assets |  | — |  |  | 4 |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total assets |  | $ | 435 |  |  | $ | 5 |  |  | $ | 36 |  |  | $ | 476 |  |  | $ | 552 |  |  | $ | 5 |  |  | $ | 18 |  |  | $ | 575 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |
| Total liabilities |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |

[0001137789-22-000014:notes:89]
|  |  | December 31, 2021 |  | July 2, 2021 |
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 434 |  |  | $ | — |  |  | $ | — |  |  | $ | 434 |  |  | $ | 551 |  |  | $ | — |  |  | $ | — |  |  | $ | 551 |  |
| Other current assets |  | 1 |  |  | 5 |  |  | — |  |  | 6 |  |  | 1 |  |  | 5 |  |  | — |  |  | 6 |  |
| Other assets, net |  | — |  |  | — |  |  | 36 |  |  | 36 |  |  | — |  |  | — |  |  | 18 |  |  | 18 |  |
| Total assets |  | $ | 435 |  |  | $ | 5 |  |  | $ | 36 |  |  | $ | 476 |  |  | $ | 552 |  |  | $ | 5 |  |  | $ | 18 |  |  | $ | 575 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |
| Total liabilities |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |

[0001137789-22-000014:notes:90]
[same as prior period, unchanged from 0001137789-21-000128:notes:96]

[0001137789-22-000014:notes:91]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair value of all of its cash equivalents. For the cash equivalents in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry-standard data providers or other third-party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of December 31, 2021, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts, interest rate swaps and the TRS. The Company recognizes derivative financial instruments in its condensed consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001137789-22-000014:notes:92]
[same as prior period, unchanged from 0001137789-21-000128:notes:98]

[0001137789-22-000014:notes:93]
[same as prior period, unchanged from 0001137789-21-000128:notes:99]

[0001137789-22-000014:notes:94]
For the investments that are accounted for under the equity method, the Company recorded an immaterial gain and a net gain of $3 million for the three and six months ended December 31, 2021, respectively. The Company recorded a net gain of $1 million and an immaterial gain for the three and six months ended January 1, 2021, respectively. The adjusted carrying value of the investments accounted for under the equity method amounted to $81 million and $78 million as of December 31, 2021 and July 2, 2021, respectively.

[0001137789-22-000014:notes:95]
For the investments that are accounted for under the measurement alternative, the Company recorded a net loss of $2 million and a net gain of $4 million for the three and six months ended December 31, 2021, respectively. The Company recorded a net loss of $7 million and a net gain of $16 million for the three and six months ended January 1, 2021, respectively, related to downward and upward adjustments due to observable price changes. As of December 31, 2021 and July 2, 2021, the carrying value of the Company’s strategic investments under the measurement alternative was $88 million and $117 million, respectively.

[0001137789-22-000014:notes:96]
[same as prior period, unchanged from 0001137789-21-000128:notes:102]

[0001137789-22-000014:notes:97]
[same as prior period, unchanged from 0001137789-21-000128:notes:103]

[0001137789-22-000014:notes:98]
|  |  | December 31, 2021 |  | July 2, 2021 |
| (Dollars in millions) |  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 4.25% Senior Notes due March 2022 |  | $ | 220 |  |  | $ | 221 |  |  | $ | 220 |  |  | $ | 224 |  |
| 4.75% Senior Notes due June 2023 |  | 541 |  |  | 565 |  |  | 541 |  |  | 578 |  |
| 4.875% Senior Notes due March 2024 |  | 499 |  |  | 530 |  |  | 499 |  |  | 544 |  |
| 4.75% Senior Notes due January 2025 |  | 479 |  |  | 515 |  |  | 479 |  |  | 529 |  |
| 4.875% Senior Notes due June 2027 |  | 504 |  |  | 554 |  |  | 504 |  |  | 561 |  |
| 4.091% Senior Notes due June 2029 |  | 463 |  |  | 521 |  |  | 461 |  |  | 519 |  |
| 3.125% Senior Notes due July 2029 |  | 500 |  |  | 490 |  |  | 500 |  |  | 488 |  |
| 4.125% Senior Notes due January 2031 |  | 500 |  |  | 522 |  |  | 499 |  |  | 513 |  |
| 3.375% Senior Notes due July 2031 |  | 500 |  |  | 489 |  |  | 500 |  |  | 487 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 567 |  |  | 489 |  |  | 566 |  |
| LIBOR Based Term Loan A1 due September 2025 |  | 600 |  |  | 589 |  |  | — |  |  | — |  |
| LIBOR Based Term Loan A2 due July 2027 |  | 600 |  |  | 592 |  |  | — |  |  | — |  |
| LIBOR Based Term Loan due September 2025 |  | — |  |  | — |  |  | 481 |  |  | 478 |  |
|  |  | 5,895 |  |  | 6,155 |  |  | 5,173 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (34) |  |  | — |  |  | (34) |  |  | — |  |
| Debt, net of debt issuance costs |  | 5,861 |  |  | 6,155 |  |  | 5,139 |  |  | 5,487 |  |
| Less: current portion of debt |  | (235) |  |  | (236) |  |  | (245) |  |  | (249) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,626 |  |  | $ | 5,919 |  |  | $ | 4,894 |  |  | $ | 5,238 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001137789-22-000014:notes:99]
Equity
Share Capital

[0001137789-22-000014:notes:100]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 219,463,688 shares were outstanding as of December 31, 2021, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of December 31, 2021.

[0001137789-22-000014:notes:101]
[same as prior period, unchanged from 0001137789-21-000128:notes:108]

[0001137789-22-000014:notes:102]
[same as prior period, unchanged from 0001137789-21-000128:notes:109]

[0001137789-22-000014:notes:103]
[same as prior period, unchanged from 0001137789-21-000128:notes:110]

[0001137789-22-000014:notes:104]
[same as prior period, unchanged from 0001137789-21-000128:notes:111]

[0001137789-22-000014:notes:105]
[same as prior period, unchanged from 0001137789-21-000128:notes:112]

[0001137789-22-000014:notes:106]
On May 14, 2021, STX’s Board of Directors resolved to adopt and continue the STUC Share Repurchase Program as its own and that the STX Board of Directors be authorized to effect the repurchase of STX ordinary shares in an amount equal to the remaining STUC Share Repurchase Program amount as of the effective time of the scheme of arrangement. As of December 31, 2021, $3.3 billion remained available for repurchase under the existing repurchase authorization limit. The following table sets forth information with respect to repurchases of ordinary shares during the six months ended December 31, 2021:

[0001137789-22-000014:notes:107]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Repurchases of ordinary shares (1) |  | 10 |  |  | $ | 905 |  |
| Tax withholding related to vesting of equity awards |  | 1 |  |  | 45 |  |
| Total |  | 11 |  |  | $ | 950 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001137789-22-000014:notes:108]
[same as prior period, unchanged from 0001137789-21-000128:notes:115]

[0001137789-22-000014:notes:109]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,178 |  |  | $ | 1,741 |  |  | $ | 4,465 |  |  | $ | 3,349 |  |
| Distributors |  | 562 |  |  | 475 |  |  | 1,069 |  |  | 842 |  |
| Retailers |  | 376 |  |  | 407 |  |  | 697 |  |  | 746 |  |
| Total |  | $ | 3,116 |  |  | $ | 2,623 |  |  | $ | 6,231 |  |  | $ | 4,937 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,433 |  |  | $ | 1,306 |  |  | $ | 3,016 |  |  | $ | 2,412 |  |
| Americas |  | 1,186 |  |  | 838 |  |  | 2,265 |  |  | 1,643 |  |
| EMEA |  | 497 |  |  | 479 |  |  | 950 |  |  | 882 |  |
| Total |  | $ | 3,116 |  |  | $ | 2,623 |  |  | $ | 6,231 |  |  | $ | 4,937 |  |

[0001137789-22-000014:notes:110]
[same as prior period, unchanged from 0001137789-21-000128:notes:117]

[0001137789-22-000014:notes:111]
[same as prior period, unchanged from 0001137789-21-000128:notes:118]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001137789-22-000014:notes:112]
[same as prior period, unchanged from 0001137789-21-000128:notes:119]

[0001137789-22-000014:notes:113]
[same as prior period, unchanged from 0001137789-21-000128:notes:120]

[0001137789-22-000014:notes:114]
[same as prior period, unchanged from 0001137789-21-000128:notes:121]

[0001137789-22-000014:notes:115]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product warranty return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the six months ended December 31, 2021 and January 1, 2021 were as follows:

[0001137789-22-000014:notes:116]
|  |  | For the Six Months Ended |  |
| (Dollars in millions) |  | December 31,2021 |  | January 1,2021 |  |
| Balance, beginning of period |  | $ | 136 |  |  | $ | 151 |  |  |
| Warranties issued |  | 43 |  |  | 37 |  |  |
| Repairs and replacements |  | (43) |  |  | (42) |  |  |
| Changes in liability for pre-existing warranties, including expirations |  | 8 |  |  | (9) |  |  |
| Balance, end of period |  | $ | 144 |  |  | $ | 137 |  |  |


## us-gaap:EarningsPerShareTextBlock

[0001137789-22-000014:notes:117]
[same as prior period, unchanged from 0001137789-21-000128:notes:124]

[0001137789-22-000014:notes:118]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (In millions, except per share data) |  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 501 |  |  | $ | 280 |  |  | $ | 1,027 |  |  | $ | 503 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 221 |  |  | 249 |  |  | 224 |  |  | 253 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | 4 |  |  | 2 |  |  | 4 |  |  | 2 |  |
| Total shares for purpose of calculating diluted net income per share |  | 225 |  |  | 251 |  |  | 228 |  |  | 255 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.27 |  |  | $ | 1.12 |  |  | $ | 4.58 |  |  | $ | 1.99 |  |
| Diluted |  | 2.23 |  |  | 1.12 |  |  | 4.50 |  |  | 1.97 |  |

[0001137789-22-000014:notes:119]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share were not material for the three and six months ended December 31, 2021 and January 1, 2021.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001137789-22-000014:notes:120]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001137789-22-000014:notes:121]
Litigation

[0001137789-22-000014:notes:122]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The complaint seeks damages as well as additional relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial is scheduled to begin on April 4, 2022. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.

[0001137789-22-000014:notes:123]
Seagate Technology LLC, et al. v. NHK Spring Co. Ltd. and TDK Corporation, et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology International filed a complaint in the United States District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc., and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Company had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Company paid artificially high prices on its purchases of suspension assemblies. The Company seeks to recover the overcharges it paid for suspension assemblies, as well as additional relief permitted by law.

[0001137789-22-000014:notes:124]
Nidec Corporation v. Seagate Technology LLC, et al. On January 18, 2021, Nidec Corporation (“Nidec”) filed a complaint against Seagate Technology LLC, Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology (Netherlands) B.V. in the United States District Court for the District of Delaware, alleging infringement of the following patents: U.S. Patent No. 8,737,017, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,742,239, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,935,528, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 10,407,775, titled “Base Plate, Hard Disk Drive, and Method of Manufacturing Base Plate,” and U.S. Patent No. 10,460,767, titled “Base Member Including Information Mark and Insulating Coating Layer, and Disk Drive Apparatus Including the Same.” (the “Delaware Action”). On March 22, 2021, Seagate initiated JAMS arbitration against Nidec under the arbitration clause of the covenant agreement between Seagate and Nidec. On July 20, 2021, the court stayed the Delaware Action pending the result of arbitration between the parties. On November 9, 2021, following a five-day arbitration hearing, the JAMS arbitration panel decided in favor of Seagate on all issues and directed Nidec to dismiss the Delaware Action. On November 15, 2021, Nidec dismissed its complaint in the Delaware Action with prejudice.

[0001137789-22-000014:notes:125]
Environmental Matters

[0001137789-22-000014:notes:126]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001137789-22-000014:notes:127]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001137789-22-000014:notes:128]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001137789-22-000014:notes:129]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001137789-22-000014:notes:130]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the U.S., Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001137789-22-000014:notes:131]
Other Matters

[0001137789-22-000014:notes:132]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:CommitmentsDisclosureTextBlock

[0001137789-22-000014:notes:133]
CommitmentsUnconditional Long-Term Purchase Obligations. As of December 31, 2021, the Company had unconditional long-term purchase obligations of approximately $495 million, primarily related to purchases of minimum quarterly amounts of inventory components. The Company expects the commitment to total $259 million, $162 million, $33 million, $26 million and $15 million for fiscal years 2023, 2024, 2025, 2026 and thereafter, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001137789-22-000014:notes:134]
Dividend Declared

[0001137789-22-000014:notes:135]
On January 26, 2022, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on April 6, 2022 to shareholders of record as of the close of business on March 22, 2022.
