# STX MD&A — 0001137789-22-000014


## mdna

[0001137789-22-000014:mdna:1]
[same as prior period, unchanged from 0001137789-21-000128:mdna:1]

[0001137789-22-000014:mdna:2]
The following is a discussion of the financial condition, changes in financial condition and results of operations for our fiscal quarters ended December 31, 2021, October 1, 2021 and January 1, 2021, referred to herein as the “December 2021 quarter,” the “September 2021 quarter,” and the “December 2020 quarter,” respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The December 2021 quarter, the September 2021 quarter and the December 2020 quarter were each 13 weeks.

[0001137789-22-000014:mdna:3]
[same as prior period, unchanged from 0001137789-21-000128:mdna:3]

[0001137789-22-000014:mdna:4]
[same as prior period, unchanged from 0001137789-21-000128:mdna:4]

[0001137789-22-000014:mdna:5]
•the development and introduction of products based on new technologies and expansion into new data storage markets and market acceptance of new products;

[0001137789-22-000014:mdna:6]
[same as prior period, unchanged from 0001137789-21-000128:mdna:6]

[0001137789-22-000014:mdna:7]
•the impact of variable demand, including ongoing demand variation related to the COVID-19 pandemic, changes in market demand and an adverse pricing environment for storage products;

[0001137789-22-000014:mdna:8]
•the effects of the COVID-19 pandemic and related individual, business and government responses on the global economy and their impact on the Company’s business, operations and financial results, including impacts to the Company’s supply chain resulting from governments’ policies and approaches to containing COVID-19;

[0001137789-22-000014:mdna:9]
•the Company’s ability to effectively manage its debt obligations and comply with certain covenants in its credit facilities with respect to financial ratios and financial condition tests and its ability to maintain a favorable cash liquidity position;

[0001137789-22-000014:mdna:10]
[same as prior period, unchanged from 0001137789-21-000128:mdna:9]

[0001137789-22-000014:mdna:11]
[same as prior period, unchanged from 0001137789-21-000128:mdna:10]

[0001137789-22-000014:mdna:12]
[same as prior period, unchanged from 0001137789-21-000128:mdna:12]

[0001137789-22-000014:mdna:13]
[same as prior period, unchanged from 0001137789-21-000128:mdna:13]

[0001137789-22-000014:mdna:14]
•changes in tax laws, such as global tax developments applicable to multinational businesses; the impact of trade barriers, such as import/export duties and restrictions, sanctions, tariffs and quotas, imposed by the U.S. or other countries in which the Company conducts business; the evolving legal and regulatory, economic, environmental and administrative climate in the international markets where the Company operates; and

[0001137789-22-000014:mdna:15]
[same as prior period, unchanged from 0001137789-21-000128:mdna:15]

[0001137789-22-000014:mdna:16]
[same as prior period, unchanged from 0001137789-21-000128:mdna:16]

[0001137789-22-000014:mdna:17]
[same as prior period, unchanged from 0001137789-21-000128:mdna:17]

[0001137789-22-000014:mdna:18]
•Overview of the December 2021 quarter. Highlights of events in the December 2021 quarter that impacted our financial position.

[0001137789-22-000014:mdna:19]
•Results of Operations. Analysis of our financial results comparing the December 2021 quarter to the September 2021 quarter and the December 2020 quarter.

[0001137789-22-000014:mdna:20]
[same as prior period, unchanged from 0001137789-21-000128:mdna:20]

[0001137789-22-000014:mdna:21]
[same as prior period, unchanged from 0001137789-21-000128:mdna:21]

[0001137789-22-000014:mdna:22]
For an overview of our business, see “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies—Organization”.

[0001137789-22-000014:mdna:23]
Overview of the December 2021 quarter

[0001137789-22-000014:mdna:24]
During the December 2021 quarter, we shipped 163 exabytes of HDD storage capacity. We generated revenue of approximately $3.1 billion with a gross margin of 30% and our operating cash flow was $521 million. We borrowed $1.2 billion under our term loan facility and fully repaid the $475 million principal amount outstanding of our September 2019 Term Loan. We repurchased approximately 5 million of our ordinary shares for $471 million and paid $151 million in dividends.

[0001137789-22-000014:mdna:25]
[same as prior period, unchanged from 0001137789-21-000128:mdna:25]

[0001137789-22-000014:mdna:26]
The COVID-19 pandemic has resulted in a widespread health crisis and numerous disease control measures being taken to limit its spread, the effects of which began during our quarter ended April 3, 2020. We continued to experience certain supply chain disruptions during the December 2021 quarter, as well as higher logistics and operational costs due to the COVID-19 pandemic, including supply chain constraints, which we expect to continue at least for the remainder of fiscal year 2022. Our customers also continued to experience certain supply chain and demand disruptions during the December 2021 quarter, resulting in demand variations across certain of our end markets, which we anticipate will continue at least for the remainder of fiscal year 2022. We are continuing to actively monitor the effects and potential impacts of the COVID-19 pandemic on all aspects of our business, supply chain, liquidity and capital resources, including governmental policies that could periodically shut down an entire city where we, our suppliers or our customers operate. We are also actively working on opportunities to lower our cost structure and drive further operational efficiencies. We are complying with governmental rules and guidelines across all of our sites. Although we are unable to predict the future impact of COVID-19 on our business, results of operations, liquidity or capital resources at this time, we expect we will continue to be negatively affected if the pandemic and related public and private health measures result in substantial manufacturing or supply chain problems, substantial reductions in demand due to disruptions in the operations of our customers or partners, disruptions in local and global economies, volatility in the global financial markets, sustained reductions or volatility in overall demand trends, restrictions on the export or shipment of our products, or other unexpected ramifications from the COVID-19 pandemic. For a further discussion of the uncertainties and business risks associated with the COVID-19 pandemic, see the section entitled “Risk Factors” in Part I, Item 1A of our Annual Report on Form 10-K for the fiscal year ended July 2, 2021.

[0001137789-22-000014:mdna:27]
[same as prior period, unchanged from 0001137789-21-000128:mdna:28]

[0001137789-22-000014:mdna:28]
[same as prior period, unchanged from 0001137789-21-000128:mdna:29]

[0001137789-22-000014:mdna:29]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 31,2021 |  | October 1,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
| Revenue |  | $ | 3,116 |  |  | $ | 3,115 |  |  | $ | 2,623 |  |  | $ | 6,231 |  |  | $ | 4,937 |  |
| Cost of revenue |  | 2,168 |  |  | 2,159 |  |  | 1,927 |  |  | 4,327 |  |  | 3,645 |  |
| Gross profit |  | 948 |  |  | 956 |  |  | 696 |  |  | 1,904 |  |  | 1,292 |  |
| Product development |  | 228 |  |  | 233 |  |  | 221 |  |  | 461 |  |  | 444 |  |
| Marketing and administrative |  | 136 |  |  | 133 |  |  | 122 |  |  | 269 |  |  | 240 |  |
| Amortization of intangibles |  | 3 |  |  | 3 |  |  | 3 |  |  | 6 |  |  | 6 |  |
| Restructuring and other, net |  | 1 |  |  | 1 |  |  | 2 |  |  | 2 |  |  | 3 |  |
| Income from operations |  | 580 |  |  | 586 |  |  | 348 |  |  | 1,166 |  |  | 599 |  |
| Other expense, net |  | (66) |  |  | (53) |  |  | (57) |  |  | (119) |  |  | (87) |  |
| Income before income taxes |  | 514 |  |  | 533 |  |  | 291 |  |  | 1,047 |  |  | 512 |  |
| Provision for income taxes |  | 13 |  |  | 7 |  |  | 11 |  |  | 20 |  |  | 9 |  |
| Net income |  | $ | 501 |  |  | $ | 526 |  |  | $ | 280 |  |  | $ | 1,027 |  |  | $ | 503 |  |

[0001137789-22-000014:mdna:30]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
|  |  | December 31,2021 |  | October 1,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 70 |  |  | 69 |  |  | 73 |  |  | 69 |  |  | 74 |  |
| Gross margin |  | 30 |  |  | 31 |  |  | 27 |  |  | 31 |  |  | 26 |  |
| Product development |  | 7 |  |  | 8 |  |  | 9 |  |  | 8 |  |  | 9 |  |
| Marketing and administrative |  | 4 |  |  | 4 |  |  | 5 |  |  | 4 |  |  | 5 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Restructuring and other, net |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating margin |  | 19 |  |  | 19 |  |  | 13 |  |  | 19 |  |  | 12 |  |
| Other expense, net |  | (3) |  |  | (2) |  |  | (2) |  |  | (2) |  |  | (2) |  |
| Income before income taxes |  | 16 |  |  | 17 |  |  | 11 |  |  | 17 |  |  | 10 |  |
| Provision for income taxes |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income |  | 16 | % |  | 17 | % |  | 11 | % |  | 17 | % |  | 10 | % |

[0001137789-22-000014:mdna:31]
[same as prior period, unchanged from 0001137789-21-000128:mdna:32]

[0001137789-22-000014:mdna:32]
[same as prior period, unchanged from 0001137789-21-000128:mdna:33]

[0001137789-22-000014:mdna:33]
The following table summarizes information regarding consolidated revenues by channel, geography and market and HDD exabytes shipped by market and price per terabyte:

[0001137789-22-000014:mdna:34]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
|  |  | December 31,2021 |  | October 1,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 70 | % |  | 74 | % |  | 66 | % |  | 72 | % |  | 68 | % |
| Distributors |  | 18 | % |  | 16 | % |  | 18 | % |  | 17 | % |  | 17 | % |
| Retailers |  | 12 | % |  | 10 | % |  | 16 | % |  | 11 | % |  | 15 | % |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 46 | % |  | 51 | % |  | 50 | % |  | 48 | % |  | 49 | % |
| Americas |  | 38 | % |  | 35 | % |  | 32 | % |  | 36 | % |  | 33 | % |
| EMEA |  | 16 | % |  | 14 | % |  | 18 | % |  | 16 | % |  | 18 | % |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 66 | % |  | 65 | % |  | 58 | % |  | 65 | % |  | 58 | % |
| Legacy |  | 25 | % |  | 27 | % |  | 35 | % |  | 26 | % |  | 34 | % |
| Other |  | 9 | % |  | 8 | % |  | 7 | % |  | 9 | % |  | 8 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 137 |  |  | 132 |  |  | 97 |  |  | 269 |  |  | 183 |  |
| Legacy |  | 26 |  |  | 27 |  |  | 32 |  |  | 53 |  |  | 60 |  |
| Total |  | 163 |  |  | 159 |  |  | 129 |  |  | 322 |  |  | 243 |  |
| HDD Price per Terabyte |  | $ | 17 |  |  | $ | 18 |  |  | $ | 19 |  |  | $ | 18 |  |  | $ | 19 |  |

[0001137789-22-000014:mdna:35]
[same as prior period, unchanged from 0001137789-21-000128:mdna:36]

[0001137789-22-000014:mdna:36]
[same as prior period, unchanged from 0001137789-21-000128:mdna:37]

[0001137789-22-000014:mdna:37]
Revenue in the December 2021 quarter remained relatively flat from the September 2021 quarter primarily due to a higher demand for our non-HDD products and an increase in mass capacity storage exabytes shipped, offset by a decrease in legacy market exabytes shipped and a decrease in price per terabyte.

[0001137789-22-000014:mdna:38]
Revenue in the December 2021 quarter increased by $493 million from the December 2020 quarter primarily due to an increase in mass capacity storage exabytes shipped, partially offset by a decrease in legacy market exabytes shipped.

[0001137789-22-000014:mdna:39]
Revenue for the six months ended December 31, 2021 increased by $1,294 million from the six months ended January 1, 2021 primarily due to an increase in mass capacity storage exabytes shipped, partially offset by a decrease in legacy market exabytes shipped.

[0001137789-22-000014:mdna:40]
30

[0001137789-22-000014:mdna:41]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 14% of gross revenue for the December 2021 quarter, 13% for the September 2021 quarter and 15% for the December 2020 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-22-000014:mdna:42]
[same as prior period, unchanged from 0001137789-21-000128:mdna:41]

[0001137789-22-000014:mdna:43]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 31,2021 |  | October 1,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
| Cost of revenue |  | $ | 2,168 |  |  | $ | 2,159 |  |  | $ | 1,927 |  |  | $ | 4,327 |  |  | $ | 3,645 |  |
| Gross profit |  | 948 |  |  | 956 |  |  | 696 |  |  | 1,904 |  |  | 1,292 |  |
| Gross margin |  | 30 | % |  | 31 | % |  | 27 | % |  | 31 | % |  | 26 | % |

[0001137789-22-000014:mdna:44]
Gross margin for the December 2021 quarter decreased compared to the September 2021 quarter primarily due to a decrease in price per terabyte and higher component and logistics costs resulting from the pandemic, partially offset by favorable mix in HDD products.

[0001137789-22-000014:mdna:45]
Gross margin for the December 2021 quarter increased compared to the December 2020 quarter primarily due to improved product mix, partially offset by higher component and logistics costs resulting from the pandemic.

[0001137789-22-000014:mdna:46]
Gross margin for the six months ended December 31, 2021 increased compared to the six months ended January 1, 2021 primarily driven by improved product mix, partially offset by higher component and logistics costs resulting from the pandemic.

[0001137789-22-000014:mdna:47]
In the December 2021 quarter, total warranty cost was 0.8% of revenue and included an unfavorable change in estimates of prior warranty accruals of 0.1% of revenue primarily due to changes to our estimated future product return rates. Warranty cost related to new shipments was 0.7%, 0.7% and 0.7% of revenue for the December 2021 quarter, September 2021 quarter and December 2020 quarter, respectively.

[0001137789-22-000014:mdna:48]
[same as prior period, unchanged from 0001137789-21-000128:mdna:46]

[0001137789-22-000014:mdna:49]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 31,2021 |  | October 1,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
| Product development |  | $ | 228 |  |  | $ | 233 |  |  | $ | 221 |  |  | $ | 461 |  |  | $ | 444 |  |
| Marketing and administrative |  | 136 |  |  | 133 |  |  | 122 |  |  | 269 |  |  | 240 |  |
| Amortization of intangibles |  | 3 |  |  | 3 |  |  | 3 |  |  | 6 |  |  | 6 |  |
| Restructuring and other, net |  | 1 |  |  | 1 |  |  | 2 |  |  | 2 |  |  | 3 |  |
| Operating expenses |  | $ | 368 |  |  | $ | 370 |  |  | $ | 348 |  |  | $ | 738 |  |  | $ | 693 |  |

[0001137789-22-000014:mdna:50]
Product development expense. Product development expense for the December 2021 quarter decreased by $5 million compared to the September 2021 quarter primarily due to a $6 million decrease in variable compensation expense and a $3 million decrease in compensation and other employee benefits, partially offset by a $4 million increase in materials expense.

[0001137789-22-000014:mdna:51]
Product development expense increased by $7 million in the December 2021 quarter compared to the December 2020 quarter primarily due to a $7 million increase in materials expense and a $3 million increase in compensation and other employee benefits, partially offset by a $5 million decrease in outside services.

[0001137789-22-000014:mdna:52]
Product development expense increased by $17 million for the six months ended December 31, 2021 compared to the six months ended January 1, 2021 primarily due to a $10 million increase in materials expense, an $8 million increase in variable compensation expense and a $3 million increase in compensation and other employee benefits, partially offset by an $8 million decrease in outside services.

[0001137789-22-000014:mdna:53]
[same as prior period, unchanged from 0001137789-21-000128:mdna:59]

[0001137789-22-000014:mdna:54]
Marketing and administrative expense. Marketing and administrative expense increased by $3 million for the December 2021 quarter compared to the September 2021 quarter primarily due to a $3 million increase in advertising costs and a $2 million increase in compensation and other employee benefits, partially offset by a $3 million decrease in variable compensation expense.

[0001137789-22-000014:mdna:55]
Marketing and administrative expense increased by $14 million in the December 2021 quarter compared to the December 2020 quarter primarily due to a $5 million increase in compensation and other employee benefits, a $4 million increase in advertising costs and a $2 million increase in travel expenses.

[0001137789-22-000014:mdna:56]
Marketing and administrative expense increased by $29 million for the six months ended December 31, 2021 compared to the six months ended January 1, 2021 primarily due to a $7 million increase in compensation and other employee benefits, a $6 million increase in variable compensation expense, a $5 million increase in advertising costs and a $4 million increase in outside services.

[0001137789-22-000014:mdna:57]
Amortization of intangibles. Amortization of intangibles for the December 2021 quarter remained flat compared to the September 2021 quarter.

[0001137789-22-000014:mdna:58]
Amortization of intangibles for the three and six months ended December 31, 2021 remained flat, compared to the three and six months ended January 1, 2021, respectively.

[0001137789-22-000014:mdna:59]
Restructuring and other, net. Restructuring and other, net was not material for any periods presented.

[0001137789-22-000014:mdna:60]
[same as prior period, unchanged from 0001137789-21-000128:mdna:55]

[0001137789-22-000014:mdna:61]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 31,2021 |  | October 1,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
| Other expense, net |  | $ | (66) |  |  | $ | (53) |  |  | $ | (57) |  |  | $ | (119) |  |  | $ | (87) |  |

[0001137789-22-000014:mdna:62]
Other expense, net. Other expense, net for the December 2021 quarter increased by $13 million from the September 2021 quarter primarily due to a non-recurring gain of $9 million from our strategic investments in the September 2021 quarter and a $3 million increase in interest expense from the net issuance of long-term debt in the December 2021 quarter.

[0001137789-22-000014:mdna:63]
Other expense, net for the December 2021 quarter increased by $9 million compared to the December 2020 quarter primarily due to a $10 million increase in interest expense from the issuance of long-term debt and a $2 million decrease in gain from foreign exchange transactions and remeasurements, net of cash flow hedges, partially offset by a $5 million decrease in losses from our strategic investments.

[0001137789-22-000014:mdna:64]
Other expense, net for the six months ended December 31, 2021 increased by $32 million compared to the six months ended January 1, 2021 primarily due to a $19 million increase in interest expense from the issuance of long-term debt and a $17 million net decrease in gains from our strategic investments, partially offset by a $5 million decrease in losses from foreign exchange transactions and remeasurements, net of cash flow hedges.

[0001137789-22-000014:mdna:65]
[same as prior period, unchanged from 0001137789-21-000128:mdna:60]

[0001137789-22-000014:mdna:66]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 31,2021 |  | October 1,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
| Provision for income taxes |  | $ | 13 |  |  | $ | 7 |  |  | $ | 11 |  |  | $ | 20 |  |  | $ | 9 |  |

[0001137789-22-000014:mdna:67]
We recorded income tax provisions of $13 million and $20 million for the three and six months ended December 31, 2021, respectively. The discrete items in the income tax provision were not material for the three months ended December 31, 2021. The income tax provision for the six months ended December 31, 2021 included approximately $9 million of net discrete tax benefit, primarily associated with net excess tax benefits related to share-based compensation expense.

[0001137789-22-000014:mdna:68]
32

[0001137789-22-000014:mdna:69]
During the six months ended December 31, 2021, our unrecognized tax benefits excluding interest and penalties increased by approximately $7 million to $115 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. During the twelve months beginning January 1, 2022, we expect that our unrecognized tax benefits could be reduced by an immaterial amount, as a result of the expiration of certain statutes of limitation.

[0001137789-22-000014:mdna:70]
We recorded income tax provisions of $11 million and $9 million for the three and six months ended January 1, 2021. The discrete items in the income tax provision were not material for the three months ended January 1, 2021. The income tax provision for the six months ended January 1, 2021 included approximately $11 million of net discrete tax benefits, primarily associated with net excess tax benefits related to share-based compensation expense and postponement of the previously enacted United Kingdom tax rate change in the quarter ended October 2, 2020.

[0001137789-22-000014:mdna:71]
Our income tax provision recorded for the three and six months ended December 31, 2021 and January 1, 2021 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-22-000014:mdna:72]
[same as prior period, unchanged from 0001137789-21-000128:mdna:66]

[0001137789-22-000014:mdna:73]
[same as prior period, unchanged from 0001137789-21-000128:mdna:67]

[0001137789-22-000014:mdna:74]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of December 31, 2021.

[0001137789-22-000014:mdna:75]
[same as prior period, unchanged from 0001137789-21-000128:mdna:69]

[0001137789-22-000014:mdna:76]
| (Dollars in millions) |  | December 31,2021 |  | July 2,2021 |  | Change |
| Cash and cash equivalents |  | $ | 1,535 |  |  | $ | 1,209 |  |  | $ | 326 |  |

[0001137789-22-000014:mdna:77]
Our cash and cash equivalents as of December 31, 2021 increased by $326 million from July 2, 2021 primarily as a result of net proceeds of $1.2 billion from the issuance of long-term debt and net cash of $1.0 billion provided by operating activities, partially offset by the repurchases of our ordinary shares of $896 million, repayment of long-term debt of $481 million, dividends paid to our shareholders of $304 million and payments for capital expenditures of $212 million.

[0001137789-22-000014:mdna:78]
[same as prior period, unchanged from 0001137789-21-000128:mdna:72]

[0001137789-22-000014:mdna:79]
Cash provided by operating activities for the six months ended December 31, 2021 was $1.0 billion and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-22-000014:mdna:80]
•an increase of $241 million in accounts receivable, primarily due to linearity of sales in the December 2021 quarter;

[0001137789-22-000014:mdna:81]
•an increase of $83 million in inventories, primarily due to timing of shipments and an increase in materials purchased for increased production of higher capacity drives; and

[0001137789-22-000014:mdna:82]
•a decrease in accrued employee compensation of $54 million, primarily due to cash paid to our employees as part of our discretionary spending plans;

[0001137789-22-000014:mdna:83]
•partially offset by an increase of $63 million in accounts payable, primarily due to an increase in material purchased.

[0001137789-22-000014:mdna:84]
33

[0001137789-22-000014:mdna:85]
[same as prior period, unchanged from 0001137789-21-000128:mdna:78]

[0001137789-22-000014:mdna:86]
Cash used in investing activities for the six months ended December 31, 2021 was $196 million, primarily attributable to the following activities:

[0001137789-22-000014:mdna:87]
•payments for the purchase of property, equipment and leasehold improvements of $212 million; and

[0001137789-22-000014:mdna:88]
[same as prior period, unchanged from 0001137789-21-000128:mdna:81]

[0001137789-22-000014:mdna:89]
•partially offset by proceeds from the sale of investments of $34 million.

[0001137789-22-000014:mdna:90]
[same as prior period, unchanged from 0001137789-21-000128:mdna:83]

[0001137789-22-000014:mdna:91]
Cash used in financing activities of $495 million for the six months ended December 31, 2021 was primarily attributable to the following activities:

[0001137789-22-000014:mdna:92]
•payments for the repurchase of our ordinary shares of $896 million;

[0001137789-22-000014:mdna:93]
•payments for the repurchase of long-term debt of $481 million;

[0001137789-22-000014:mdna:94]
•payments for dividends of $304 million; and

[0001137789-22-000014:mdna:95]
•payments for taxes related to net share settlement of equity awards of $45 million;

[0001137789-22-000014:mdna:96]
•partially offset by net proceeds from the issuance of long-term debt of $1.2 billion; and

[0001137789-22-000014:mdna:97]
•proceeds from the issuance of ordinary shares under employee share plans of $37 million.

[0001137789-22-000014:mdna:98]
[same as prior period, unchanged from 0001137789-21-000128:mdna:90]

[0001137789-22-000014:mdna:99]
Our primary sources of liquidity as of December 31, 2021 consist of: (1) approximately $1.5 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.75 billion available for borrowing under our senior unsecured revolving credit facility (“Revolving Credit Facility”), which is part of our credit agreement (the “Credit Agreement”).

[0001137789-22-000014:mdna:100]
On October 14, 2021, our subsidiary Seagate HDD Cayman entered into an amendment to the Credit Agreement (“Fifth Amendment”), which provides for a new term loan facility in the aggregate principal amount of $1.2 billion that was extended in two tranches of $600 million each. The Term Loans were drawn in full on October 14, 2021. The proceeds of the Term Loans may be used for general corporate purposes, to refinance or repay our September 2019 Term Loan and to refinance or repay our 4.25% notes due March 1, 2022. On October 14, 2021, we utilized part of the proceeds of Term Loan A1 to fully repay the $475 million principal amount outstanding of our September 2019 Term Loan.

[0001137789-22-000014:mdna:101]
In addition, pursuant to the Fifth Amendment, the maturity date for the revolving loan commitments was extended until October 14, 2026, the revolving commitments were increased to $1.75 billion and the interest rate margins for the Revolving Credit Facility was amended to LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of our Company. See “Part I, Item 1. Financial Statements—Note 3. Debt” for information regarding our amended Credit Agreement.

[0001137789-22-000014:mdna:102]
As of December 31, 2021, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-22-000014:mdna:103]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount.

[0001137789-22-000014:mdna:104]
[same as prior period, unchanged from 0001137789-21-000128:mdna:95]

[0001137789-22-000014:mdna:105]
[same as prior period, unchanged from 0001137789-21-000128:mdna:96]

[0001137789-22-000014:mdna:106]
From time to time, we may repurchase any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase outstanding senior notes pursuant to the terms of the applicable indenture.

[0001137789-22-000014:mdna:107]
34

[0001137789-22-000014:mdna:108]
During the December 2021 quarter, our Board of Directors declared dividends of $0.70 per share, totaling $154 million, which were paid on January 5, 2022. On January 26, 2022, our Board of Directors declared a quarterly cash dividend of $0.70 per share, payable on April 6, 2022 to shareholders of record at the close of business on March 22, 2022.

[0001137789-22-000014:mdna:109]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker-assisted purchases, tender offers, or other means, including through the use of derivative transactions. As of December 31, 2021, $3.3 billion remained available for repurchases under our existing repurchase authorization. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-22-000014:mdna:110]
Contractual Obligations and Commitments

[0001137789-22-000014:mdna:111]
Our contractual cash obligations and commitments as of December 31, 2021, are summarized in the table below:

[0001137789-22-000014:mdna:112]
|  |  |  |  | Fiscal Year(s) |
| (Dollars in millions) |  | Total |  | 2022 |  | 2023-2024 |  | 2025-2026 |  | Thereafter |
| Contractual Cash Obligations: |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | $ | 5,935 |  |  | $ | 220 |  |  | $ | 1,145 |  |  | $ | 1,125 |  |  | $ | 3,445 |  |
| Interest payments on debt |  | 1,477 |  |  | 133 |  |  | 430 |  |  | 325 |  |  | 589 |  |
| Purchase obligations (1) |  | 1,920 |  |  | 1,425 |  |  | 421 |  |  | 59 |  |  | 15 |  |
| Operating leases, including imputed interest (2) |  | 64 |  |  | 8 |  |  | 23 |  |  | 12 |  |  | 21 |  |
| Capital expenditures |  | 267 |  |  | 113 |  |  | 149 |  |  | 5 |  |  | — |  |
| Subtotal |  | 9,663 |  |  | 1,899 |  |  | 2,168 |  |  | 1,526 |  |  | 4,070 |  |
| Commitments: |  |  |  |  |  |  |  |  |  |  |
| Letters of credit or bank guarantees |  | 27 |  |  | 5 |  |  | 13 |  |  | — |  |  | 9 |  |
| Total |  | $ | 9,690 |  |  | $ | 1,904 |  |  | $ | 2,181 |  |  | $ | 1,526 |  |  | $ | 4,079 |  |

[0001137789-22-000014:mdna:113]
___________________________________

[0001137789-22-000014:mdna:114]
(1)Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms.

[0001137789-22-000014:mdna:115]
(2)Includes total future minimum rent expense under non-cancelable leases for both occupied and vacated facilities (rent expense is shown net of sublease income).

[0001137789-22-000014:mdna:116]
[same as prior period, unchanged from 0001137789-21-000128:mdna:100]

[0001137789-22-000014:mdna:117]
[same as prior period, unchanged from 0001137789-21-000128:mdna:101]

[0001137789-22-000014:mdna:118]
[same as prior period, unchanged from 0001137789-21-000128:mdna:102]

[0001137789-22-000014:mdna:119]
[same as prior period, unchanged from 0001137789-21-000128:mdna:103]

[0001137789-22-000014:mdna:120]
[same as prior period, unchanged from 0001137789-21-000128:mdna:104]

[0001137789-22-000014:mdna:121]
35
