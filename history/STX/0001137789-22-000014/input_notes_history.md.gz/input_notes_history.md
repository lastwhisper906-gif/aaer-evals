# STX note change history — 0001137789-21-000128 → 0001137789-22-000014


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2022-01-27):
[0001137789-22-000014:note_history:1]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The complaint seeks damages as well as additional relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial is scheduled to begin on April 4, 2022. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.

- changed (2022-01-27):
[0001137789-22-000014:note_history:2]
Nidec Corporation v. Seagate Technology LLC, et al. On January 18, 2021, Nidec Corporation (“Nidec”) filed a complaint against Seagate Technology LLC, Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology (Netherlands) B.V. in the United States District Court for the District of Delaware, alleging infringement of the following patents: U.S. Patent No. 8,737,017, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,742,239, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,935,528, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 10,407,775, titled “Base Plate, Hard Disk Drive, and Method of Manufacturing Base Plate,” and U.S. Patent No. 10,460,767, titled “Base Member Including Information Mark and Insulating Coating Layer, and Disk Drive Apparatus Including the Same.” (the “Delaware Action”). On March 22, 2021, Seagate initiated JAMS arbitration against Nidec under the arbitration clause of the covenant agreement between Seagate and Nidec. On July 20, 2021, the court stayed the Delaware Action pending the result of arbitration between the parties. On November 9, 2021, following a five-day arbitration hearing, the JAMS arbitration panel decided in favor of Seagate on all issues and directed Nidec to dismiss the Delaware Action. On November 15, 2021, Nidec dismissed its complaint in the Delaware Action with prejudice.
  (was, 2021-10-28, similarity 0.614):
[0001137789-21-000128:note_history:2]
Nidec Corporation v. Seagate Technology LLC, et al. On January 18, 2021, Nidec Corporation filed a complaint against Seagate Technology LLC, Seagate Singapore International Headquarters Pte. Ltd., and Seagate Technology (Netherlands) B.V. in the United States District Court for the District of Delaware, alleging infringement of the following patents: U.S. Patent No. 8,737,017, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,742,239, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 9,935,528, titled “Spindle Motor and Disk Drive Apparatus,” U.S. Patent No. 10,407,775, titled “Base Plate, Hard Disk Drive, and Method of Manufacturing Base Plate,” and U.S. Patent No. 10,460,767, titled “Base Member Including Information Mark and Insulating Coating Layer, and Disk Drive Apparatus Including the Same.” The complaint seeks unspecified compensatory damages and other relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. On July 20, 2021, the court stayed the case pending the result of an arbitration between the parties. The arbitration hearing commenced on October 18, 2021. The Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- removed (2022-01-27):
[0001137789-21-000128:note_history:3]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial is scheduled to begin on February 7, 2022. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-01-27):
[0001137789-22-000014:note_history:4]
The unaudited Condensed Consolidated Financial Statements of the Company and the accompanying notes were prepared in accordance with United States (“U.S.”) Generally Accepted Accounting Principles (“GAAP”). The Company’s unaudited condensed consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.
  (was, 2021-10-28, similarity 0.9675):
[0001137789-21-000128:note_history:4]
The unaudited Condensed Consolidated Financial Statements of the Company were prepared in accordance with United States (“U.S.”) Generally Accepted Accounting Principles (“GAAP”). The Company’s unaudited condensed consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

- changed (2022-01-27):
[0001137789-22-000014:note_history:5]
The Company’s consolidated financial statements for the fiscal year ended July 2, 2021 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 6, 2021. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 2, 2021, and the notes thereto, are adequate to make the information presented not misleading. The results of operations and the cash flows for the three and six months ended December 31, 2021 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending July 1, 2022.
  (was, 2021-10-28, similarity 0.9704):
[0001137789-21-000128:note_history:5]
The Company’s consolidated financial statements for the fiscal year ended July 2, 2021 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 6, 2021. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 2, 2021, and the notes thereto, are adequate to make the information presented not misleading. The results of operations and the cash flows for the three months ended October 1, 2021 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending July 1, 2022.

- added (2022-01-27):
[0001137789-22-000014:note_history:6]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three and six months ended December 31, 2021 consisted of 13 and 26 weeks, respectively, and the three and six months ended January 1, 2021 consisted of 13 and 26 weeks, respectively. Fiscal year 2022, which ends on July 1, 2022, is comprised of 52 weeks and fiscal year 2021, which ended on July 2, 2021, was comprised of 52 weeks. The fiscal quarters ended December 31, 2021, October 1, 2021 and January 1, 2021, are also referred to herein as the “December 2021 quarter”, the “September 2021 quarter” and the “December 2020 quarter”, respectively.

- added (2022-01-27):
[0001137789-22-000014:note_history:7]
Recently Issued Accounting Pronouncements

- removed (2022-01-27):
[0001137789-21-000128:note_history:8]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three months ended October 1, 2021 and October 2, 2020 consisted of 13 weeks. Fiscal year 2022, which ends on July 1, 2022, is comprised of 52 weeks and fiscal year 2021, which ended on July 2, 2021, was comprised of 52 weeks. The fiscal quarters ended October 1, 2021, July 2, 2021 and October 2, 2020, are also referred to herein as the “September 2021 quarter”, the “June 2021 quarter” and the “September 2020 quarter”, respectively.

- removed (2022-01-27):
[0001137789-21-000128:note_history:9]
Recently Issued Accounting Pronouncements
In March 2020, the FASB issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. Adoption of the expedients and exceptions is permitted upon issuance of this update through December 31, 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-01-27):
[0001137789-22-000014:note_history:10]
During the six months ended January 1, 2021, $9 million aggregate principal amount of the 2022 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. 
2023 Notes. During the six months ended January 1, 2021, $5 million aggregate principal amount of the 2023 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss of $1 million on repurchases during the six months ended January 1, 2021, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- added (2022-01-27):
[0001137789-22-000014:note_history:11]
Credit Agreement

- changed (2022-01-27):
[0001137789-22-000014:note_history:12]
Prior to the October 14, 2021 amendment, the Credit Agreement provided a term loan facility in an aggregate principal amount of $500 million and a $1.725 billion senior unsecured revolving credit facility (“Revolving Credit Facility”). The September 2019 Term Loan had a final maturity date of September 16, 2025 and the Revolving Credit Facility had a final maturity of February 20, 2024. On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the September 2019 Term Loan.
  (was, 2021-10-28, similarity 0.831):
[0001137789-21-000128:note_history:12]
Prior to the October 14, 2021 amendment, the Credit Agreement provided a term loan facility in an aggregate principal amount of $500 million and a $1.725 billion senior unsecured revolving credit facility (“Revolving Credit Facility”). The September 2019 Term Loan has a final maturity date of September 16, 2025 and the Revolving Credit Facility has a final maturity of February 20, 2024. On September 17, 2019, Seagate HDD Cayman borrowed the $500 million principal amount under the September 2019 Term Loan. The Company repaid $6 million principal amount of the September 2019 Term Loan during the three months ended October 1, 2021 and had a remaining principal balance of $475 million as of October 1, 2021.

- added (2022-01-27):
[0001137789-22-000014:note_history:13]
On October 14, 2021, STX and Seagate HDD Cayman entered into an amendment to the Credit Agreement (“Fifth Amendment”), which provides for a new term loan facility in the aggregate principal amount of $1.2 billion that was extended in two tranches of $600 million each (“Term Loan A1” and “Term Loan A2” and together the “Term Loans”). Term Loan A1 and Term Loan A2 were each drawn in full on the closing date for the Fifth Amendment. The proceeds of the Term Loans may be used for general corporate purposes, to refinance or repay the September 2019 Term Loan and to refinance or repay the 2022 Notes. Term Loan A1 bears interest at a rate of LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company. Term Loan A1 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of September 16, 2025. Term Loan A2 bears interest at a rate of LIBOR plus a variable margin ranging from 1.25% to 2.5% that will be determined based on the corporate credit rating of the Company. Term Loan A2 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of July 30, 2027. On October 14, 2021, Seagate HDD Cayman utilized part of the proceeds of Term Loan A1 to fully repay the $475 million principal amount outstanding of the September 2019 Term Loan.

- changed (2022-01-27):
[0001137789-22-000014:note_history:14]
In addition, pursuant to the Fifth Amendment, the maturity date for the revolving loan commitments under the Revolving Credit Facility was extended until October 14, 2026, the revolving commitments were increased to $1.75 billion and the interest rate margins for the revolving loans were amended to LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company.
  (was, 2021-10-28, similarity 0.955):
[0001137789-21-000128:note_history:14]
In addition, pursuant to the Fifth Amendment, the maturity date for the revolving loan commitments was extended until October 14, 2026, the revolving commitments were increased to $1.75 billion and the interest rate margins for the revolving loans were amended to LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company.

- changed (2022-01-27):
[0001137789-22-000014:note_history:15]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of December 31, 2021 and expects to be in compliance for the next 12 months. As of December 31, 2021, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility.
  (was, 2021-10-28, similarity 0.9798):
[0001137789-21-000128:note_history:15]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of October 1, 2021 and expects to be in compliance for the next 12 months. As of October 1, 2021, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility.

- removed (2022-01-27):
[0001137789-21-000128:note_history:16]
Debt
The following table provides details of the Company’s debt as of October 1, 2021 and July 2, 2021:

- removed (2022-01-27):
[0001137789-21-000128:note_history:17]
| (Dollars in millions) |  | October 1,2021 |  | July 2,2021 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $750 issued on February 3, 2017 at 4.25% due March 1, 2022 (the “2022 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | $ | 220 |  |  | $ | 220 |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 541 |  |  | 541 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 462 |  |  | 461 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 499 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loan |  |  |  |  |
| $500 borrowed on September 17, 2019 at London Interbank Offered Rate (“LIBOR”), (the “September 2019 Term Loan”), repayable in quarterly installments of 1.25% of the original principal amount beginning on December 31, 2020, with a final maturity date of September 16, 2025(2). |  | 475 |  |  | 481 |  |
|  |  | 5,169 |  |  | 5,173 |  |
| Less: unamortized debt issuance costs |  | (33) |  |  | (34) |  |
| Debt, net of debt issuance costs |  | 5,136 |  |  | 5,139 |  |
| Less: current portion of long-term debt |  | (245) |  |  | (245) |  |
| Long-term debt, less current portion |  | $ | 4,891 |  |  | $ | 4,894 |  |

- removed (2022-01-27):
[0001137789-21-000128:note_history:18]
__________________________________

- removed (2022-01-27):
[0001137789-21-000128:note_history:19]
(1) All unsecured senior notes are issued by Seagate HDD Cayman, and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and, pursuant to a supplemental indenture dated as of May 18, 2021, STX.

- removed (2022-01-27):
[0001137789-21-000128:note_history:20]
(2) The Term Loan was fully repaid on October 14, 2021. See Credit Agreement (including subsequent event) below for more information.

- removed (2022-01-27):
[0001137789-21-000128:note_history:21]
Unsecured Senior Notes

- removed (2022-01-27):
[0001137789-21-000128:note_history:22]
2022 Notes. During the three months ended October 2, 2020, $9 million aggregate principal amount of the 2022 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest.

- removed (2022-01-27):
[0001137789-21-000128:note_history:23]
2023 Notes. During the three months ended October 2, 2020, $5 million aggregate principal amount of the 2023 Notes were repurchased for cash at a premium to their principal amount, plus accrued and unpaid interest, of which $2 million remained unsettled as of October 2, 2020. The Company recorded a loss of $1 million, on repurchases during the three months ended October 2, 2020, which is included in Other, net in the Company’s Condensed Consolidated Statements of Operations.

- removed (2022-01-27):
[0001137789-21-000128:note_history:24]
Credit Agreement (including subsequent event)

- removed (2022-01-27):
[0001137789-21-000128:note_history:25]
On October 14, 2021, STX and Seagate HDD Cayman entered into an amendment to the Credit Agreement (“Fifth Amendment”), which provides for a new term loan facility in the aggregate principal amount of $1.2 billion that was extended in two tranches of $600 million each (“Term Loan A1” and “Term Loan A2” and together the “Term Loans”). The proceeds of the Term Loan A1 and Term Loan A2 may be used for general corporate purposes, to refinance or repay the September 2019 Term Loan and to refinance or repay the 2022 Notes. Term Loan A1 and Term Loan A2 were each drawn in full on the closing date for the Fifth Amendment. Term Loan A1 will bear interest at a rate of LIBOR plus a variable margin ranging from 1.125% to 2.375% that will be determined based on the corporate credit rating of the Company. Term Loan A1 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of September 16, 2025. Term Loan A2 will bear interest at a rate of LIBOR plus a variable margin ranging from 1.25% to 2.5% that will be determined based on the corporate credit rating of the Company. Term Loan A2 is repayable in quarterly installments beginning on December 31, 2022 and has a final maturity date of July 30, 2027. On October 14, 2021, Seagate HDD Cayman utilized part of the proceeds of Term Loan A1 to fully repay the $475 million principal amount outstanding of the September 2019 Term Loan.

- removed (2022-01-27):
[0001137789-21-000128:note_history:26]
Future Principal Payments on Long-term Debt

- removed (2022-01-27):
[0001137789-21-000128:note_history:27]
At October 1, 2021, future principal payments on long-term debt were as follows (in millions):

- removed (2022-01-27):
[0001137789-21-000128:note_history:28]
| Fiscal Year |  | Amount |
| Remainder of 2022 |  | $ | 239 |  |
| 2023 |  | 566 |  |
| 2024 |  | 525 |  |
| 2025 |  | 504 |  |
| 2026 |  | 381 |  |
| Thereafter |  | 2,995 |  |
| Total |  | $ | 5,210 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-01-27):
[0001137789-22-000014:note_history:29]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of December 31, 2021 and July 2, 2021:
  (was, 2021-10-28, similarity 0.9789):
[0001137789-21-000128:note_history:29]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of October 1, 2021 and July 2, 2021:

- changed (2022-01-27):
[0001137789-22-000014:note_history:30]
|  |  | December 31,2021 |  | July 2,2021 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 435 |  |  | $ | — |  |  | $ | 435 |  |  | $ | 552 |  |  | $ | — |  |  | $ | 552 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 36 |  |  | — |  |  | 36 |  |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 472 |  |  | $ | — |  |  | $ | 472 |  |  | $ | 571 |  |  | $ | — |  |  | $ | 571 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 434 |  |  |  |  |  |  | $ | 551 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 36 |  |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 472 |  |  |  |  |  |  | $ | 571 |  |
  (was, 2021-10-28, similarity 0.9947):
[0001137789-21-000128:note_history:30]
|  |  | October 1,2021 |  | July 2,2021 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 423 |  |  | $ | — |  |  | $ | 423 |  |  | $ | 552 |  |  | $ | — |  |  | $ | 552 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 36 |  |  | — |  |  | 36 |  |  | 18 |  |  | — |  |  | 18 |  |
| Total |  | $ | 460 |  |  | $ | — |  |  | $ | 460 |  |  | $ | 571 |  |  | $ | — |  |  | $ | 571 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 422 |  |  |  |  |  |  | $ | 551 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 36 |  |  |  |  |  |  | 18 |  |
| Total |  |  |  |  |  | $ | 460 |  |  |  |  |  |  | $ | 571 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-01-27):
[0001137789-22-000014:note_history:31]
At December 31, 2021, future principal payments on long-term debt were as follows (in millions):
  (was, 2021-10-28, similarity 0.9609):
[0001137789-21-000128:note_history:31]
At October 1, 2021, future principal payments on long-term debt were as follows (in millions):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-01-27):
[0001137789-22-000014:note_history:32]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,178 |  |  | $ | 1,741 |  |  | $ | 4,465 |  |  | $ | 3,349 |  |
| Distributors |  | 562 |  |  | 475 |  |  | 1,069 |  |  | 842 |  |
| Retailers |  | 376 |  |  | 407 |  |  | 697 |  |  | 746 |  |
| Total |  | $ | 3,116 |  |  | $ | 2,623 |  |  | $ | 6,231 |  |  | $ | 4,937 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,433 |  |  | $ | 1,306 |  |  | $ | 3,016 |  |  | $ | 2,412 |  |
| Americas |  | 1,186 |  |  | 838 |  |  | 2,265 |  |  | 1,643 |  |
| EMEA |  | 497 |  |  | 479 |  |  | 950 |  |  | 882 |  |
| Total |  | $ | 3,116 |  |  | $ | 2,623 |  |  | $ | 6,231 |  |  | $ | 4,937 |  |
  (was, 2021-10-28, similarity 0.6357):
[0001137789-21-000128:note_history:32]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | October 1,2021 |  | October 2,2020 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,288 |  |  | $ | 1,608 |  |  |  |  |  |
| Distributors |  | 507 |  |  | 367 |  |  |  |  |  |
| Retailers |  | 320 |  |  | 339 |  |  |  |  |  |
| Total |  | $ | 3,115 |  |  | $ | 2,314 |  |  |  |  |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,583 |  |  | $ | 1,106 |  |  |  |  |  |
| Americas |  | 1,079 |  |  | 805 |  |  |  |  |  |
| EMEA |  | 453 |  |  | 403 |  |  |  |  |  |
| Total |  | $ | 3,115 |  |  | $ | 2,314 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-01-27):
[0001137789-22-000014:note_history:33]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 31,2021 |  | January 1,2021 |  | December 31,2021 |  | January 1,2021 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,178 |  |  | $ | 1,741 |  |  | $ | 4,465 |  |  | $ | 3,349 |  |
| Distributors |  | 562 |  |  | 475 |  |  | 1,069 |  |  | 842 |  |
| Retailers |  | 376 |  |  | 407 |  |  | 697 |  |  | 746 |  |
| Total |  | $ | 3,116 |  |  | $ | 2,623 |  |  | $ | 6,231 |  |  | $ | 4,937 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,433 |  |  | $ | 1,306 |  |  | $ | 3,016 |  |  | $ | 2,412 |  |
| Americas |  | 1,186 |  |  | 838 |  |  | 2,265 |  |  | 1,643 |  |
| EMEA |  | 497 |  |  | 479 |  |  | 950 |  |  | 882 |  |
| Total |  | $ | 3,116 |  |  | $ | 2,623 |  |  | $ | 6,231 |  |  | $ | 4,937 |  |
  (was, 2021-10-28, similarity 0.6357):
[0001137789-21-000128:note_history:33]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | October 1,2021 |  | October 2,2020 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,288 |  |  | $ | 1,608 |  |  |  |  |  |
| Distributors |  | 507 |  |  | 367 |  |  |  |  |  |
| Retailers |  | 320 |  |  | 339 |  |  |  |  |  |
| Total |  | $ | 3,115 |  |  | $ | 2,314 |  |  |  |  |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 1,583 |  |  | $ | 1,106 |  |  |  |  |  |
| Americas |  | 1,079 |  |  | 805 |  |  |  |  |  |
| EMEA |  | 453 |  |  | 403 |  |  |  |  |  |
| Total |  | $ | 3,115 |  |  | $ | 2,314 |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2022-01-27):
[0001137789-22-000014:note_history:34]
On January 26, 2022, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on April 6, 2022 to shareholders of record as of the close of business on March 22, 2022.

- removed (2022-01-27):
[0001137789-21-000128:note_history:35]
On October 22, 2021, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on January 5, 2022 to shareholders of record as of the close of business on December 22, 2021.

- removed (2022-01-27):
[0001137789-21-000128:note_history:36]
Credit Agreement

- removed (2022-01-27):
[0001137789-21-000128:note_history:37]
On October 14, 2021, STX and its subsidiary Seagate HDD Cayman entered into an amendment to the Credit Agreement, dated as of February 20, 2019. See “Note 3. Debt” for information regarding the amended credit agreement. On October 19, 2021, the Company entered into an additional interest rate swap contract. See “Note 6. Derivative Financial Instruments” for more information.
