# STX note change history — 0001137789-23-000128 → 0001137789-24-000010


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-01-26):
[0001137789-24-000010:note_history:1]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgement in favor of Seagate on April 19, 2022, following a jury trial. The parties filed post-trial motions with the district court, which were denied. An appeal to the Federal Circuit is pending. The Company believes the asserted claims are without merit and intends to vigorously defend this case.
  (was, 2023-10-27, similarity 0.6551):
[0001137789-23-000128:note_history:1]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgement in favor of Seagate on April 19, 2022. The parties filed post-trial motions with the district court in May 2022. On November 22, 2022, the court denied all pending post-trial motions. Lambeth Magnetic Structures LLC filed a notice of appeal to the Federal Circuit on December 20, 2022. A hearing date has not been set. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

- changed (2024-01-26):
[0001137789-24-000010:note_history:2]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the U.S. District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendant misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies and additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 8, 2022, the court entered an Amended Stipulation and Order of Dismissal with Prejudice to dismiss all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment Regarding Foreign Commerce and on October 14, 2022, the Seagate Entities filed their corresponding opposition. On May 15, 2023, the court issued a ruling that Seagate’s antitrust claims can proceed as to suspension assemblies that enter the United States but not as to suspension assembles that do not enter the United States. On July 28, 2023, the judge initiated a reconsideration of this ruling and requested further briefing. On November 17, 2023, the Court granted NHK’s Motion for Partial Summary Judgment regarding the Foreign Trade Antitrust Improvements Act (“FTAIA”) and denied Seagate’s Motion for Leave to Amend the Complaint. Seagate plans to appeal the Court’s ruling and filed a motion on December 15, 2023 for the Court to certify interlocutory review of its ruling. A trial date has not been set.
  (was, 2023-10-27, similarity 0.9123):
[0001137789-23-000128:note_history:2]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the U.S. District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendant misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, as well as additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 8, 2022, the court entered an Amended Stipulation and Order of Dismissal with Prejudice to dismiss all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment Regarding Foreign Commerce and on October 14, 2022, the Seagate Entities filed their corresponding opposition. On May 15, 2023, the court issued a ruling that Seagate’s antitrust claims can proceed as to suspension assemblies that enter the United States but not as to suspension assembles that do not enter the United States. On July 28, 2023, the judge initiated a reconsideration of this ruling and requested further briefing. A trial date has not been set.

- changed (2024-01-26):
[0001137789-24-000010:note_history:3]
In re Seagate Technology Holdings plc Securities Litigation. A putative class action lawsuit alleging violations of the federal securities laws, UA Local 38 Defined Contribution Pension Plan, et al. v. Seagate Technology Holdings PLC, et al., was filed on July 10, 2023, in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The complaint alleged that it was a securities class action on behalf of all purchasers of Seagate common stock between September 15, 2020 and October 25, 2022, inclusive, and asserted claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b5-1. The complaint sought unspecified monetary damages and other relief. A second action, Public Employees’ Retirement System of Mississippi v. Seagate Technology Holdings plc, William David Mosley, and Gianluca Romano, was filed on July 26, 2023, asserting similar claims. The cases were consolidated on September 25, 2023.  On October 19, 2023, plaintiffs filed an amended complaint asserting similar claims with a putative class period of September 14, 2020 through April 19, 2023. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint, which is currently pending before the court. The Company believes that the asserted claims are without merit and intends to vigorously defend the case.
  (was, 2023-10-27, similarity 0.7023):
[0001137789-23-000128:note_history:3]
In re Seagate Technology Holdings plc Securities Litigation. A putative class action lawsuit alleging violations of the federal securities laws, UA Local 38 Defined Contribution Pension Plan, et al. v. Seagate Technology Holdings PLC, et al., was filed on July 10, 2023, in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The complaint alleges that it is a securities class action on behalf of all purchasers of Seagate common stock between September 15, 2020 and October 25, 2022, inclusive, and asserts claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b5-1. The complaint seeks unspecified monetary damages and other relief. A second action, Public Employees’ Retirement System of Mississippi v. Seagate Technology Holdings plc, William David Mosley, and Gianluca Romano, was filed on July 26, 2023, asserting similar claims. The cases were consolidated on September 25, 2023. An amended complaint was filed on October 19, 2023. The Company believes that the asserted claims are without merit and intends to vigorously defend these cases.

- changed (2024-01-26):
[0001137789-24-000010:note_history:4]
While Seagate believed that it complied with all relevant export control laws at the time it made the hard disk drive sales at issue, Seagate determined that engaging with BIS and settling this matter was in the best interest of the Company, its customers, and its shareholders. In determining to engage with BIS and resolve this matter through a settlement agreement, the Company considered a number of factors, including the risks and cost of protracted litigation involving the U.S. government, and the size of the potential penalty and the Company’s desire to focus on current business challenges and long-term business strategy. The Settlement Agreement includes a finding that the Company incorrectly interpreted the regulation at issue to require evaluation of only the last stage of Seagate’s hard disk drive manufacturing process rather than the entire process. As part of this settlement, Seagate has agreed not to contest BIS’ determination that the sales in question did not comply with the U.S. EAR.
  (was, 2023-10-27, similarity 0.9946):
[0001137789-23-000128:note_history:4]
While Seagate believed that it complied with all relevant export control laws at the time it made the hard disk drive sales at issue, Seagate determined that engaging with BIS and settling this matter was in the best interest of the Company, its customers, and its shareholders. In determining to engage with BIS and resolve this matter through a settlement agreement, the Company considered a number of factors, including the risks and cost of protracted litigation involving the U.S. government, as well as the size of the potential penalty and the Company’s desire to focus on current business challenges and long-term business strategy. The Settlement Agreement includes a finding that the Company incorrectly interpreted the regulation at issue to require evaluation of only the last stage of Seagate’s hard disk drive manufacturing process rather than the entire process. As part of this settlement, Seagate has agreed not to contest BIS’ determination that the sales in question did not comply with the U.S. EAR.

- changed (2024-01-26):
[0001137789-24-000010:note_history:5]
The Company accrued a charge of $300 million during fiscal year 2023, of which  $60 million and $225 million were included in Accrued expense and Other non-current liabilities, respectively, on its Condensed Consolidated Balance Sheets as of December 29, 2023. During the December 2023 quarter, $15 million was paid and reported as an outflow from operating activities on its Condensed Consolidated Statements of Cash Flows.
  (was, 2023-10-27, similarity 0.7427):
[0001137789-23-000128:note_history:5]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $240 million were included in Accrued expense and Other non-current liabilities, respectively, on its Condensed Consolidated Balance Sheets as of September 29, 2023.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-01-26):
[0001137789-24-000010:note_history:6]
In January 2024, the Company established Singapore as its principal executive offices to better align its operational footprint.

- changed (2024-01-26):
[0001137789-24-000010:note_history:7]
The Company’s Consolidated Financial Statements for the fiscal year ended June 30, 2023 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 4, 2023. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 30, 2023, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and six months ended December 29, 2023 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 28, 2024.
  (was, 2023-10-27, similarity 0.971):
[0001137789-23-000128:note_history:7]
The Company’s Consolidated Financial Statements for the fiscal year ended June 30, 2023 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 4, 2023. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 30, 2023, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three months ended September 29, 2023 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 28, 2024.

- added (2024-01-26):
[0001137789-24-000010:note_history:8]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and six months ended December 29, 2023 and December 30, 2022 consisted of 13 and 26 weeks, respectively. Fiscal years 2024 and 2023 both comprise 52 weeks and end on June 28, 2024 and June 30, 2023, respectively. The fiscal quarters ended December 29, 2023, September 29, 2023 and December 30, 2022, are also referred to herein as the “December 2023 quarter”, the “September 2023 quarter” and the “December 2022 quarter”, respectively.

- changed (2024-01-26):
[0001137789-24-000010:note_history:9]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. Effective from the first quarter of fiscal year 2024, the Company changed the useful lives of certain manufacturing equipment from a range of three to seven years to a range of three to ten years based on its review of technology product roadmap. The effect of this change in estimate increased the net income by approximately $30 million and $40 million for three and six months ended December 29, 2023, respectively. Loss per share decreased by $0.14 and $0.19 for three and six months ended December 29, 2023, respectively.
  (was, 2023-10-27, similarity 0.8045):
[0001137789-23-000128:note_history:9]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. Effective from the first quarter of fiscal year 2024, the Company changed the useful lives of certain manufacturing equipment from a range of three to seven years to a range of three to ten years based on its review of technology product roadmap. The effect of this change in estimate increased the net income and diluted earnings per share by approximately $10 million and $0.05, respectively, for the three months ended September 29, 2023.

- added (2024-01-26):
[0001137789-24-000010:note_history:10]
Recently Adopted Accounting Pronouncements

- changed (2024-01-26):
[0001137789-24-000010:note_history:11]
In September 2022, the Financial Accounting Standards Board (FASB) issued ASU 2022-04 (ASC Subtopic 405-50), Disclosure of Supplier Finance Program Obligations. This ASU requires disclosure of key terms of the outstanding supplier finance programs and a roll forward of the related obligations. The Company adopted this guidance in the quarter ended September 29, 2023. The adoption of this ASU did not have a material impact on the Company’s Condensed Consolidated Financial Statements.
  (was, 2023-10-27, similarity 0.8644):
[0001137789-23-000128:note_history:11]
Recently Adopted Accounting Pronouncements
In September 2022, the FASB issued ASU 2022-04 (ASC Subtopic 405-50), Disclosure of Supplier Finance Program Obligations. This ASU requires disclosure of key terms of the outstanding supplier finance programs and a roll forward of the related obligations. The Company adopted this guidance in the quarter ended September 29, 2023. The adoption of this ASU did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

- added (2024-01-26):
[0001137789-24-000010:note_history:12]
Recently Issued Accounting Pronouncements

- added (2024-01-26):
[0001137789-24-000010:note_history:13]
In November 2023, the FASB issued ASU 2023-07 (ASC Topic 280), Improvements to Reportable Segment Disclosures. This ASU improves reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The Company is required to adopt this guidance for its annual reporting in fiscal year 2025 and for interim period reporting beginning the first quarter of fiscal year 2026 on a retrospective basis. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have impact on its Condensed Consolidated Financial Statements.

- added (2024-01-26):
[0001137789-24-000010:note_history:14]
In December 2023, the FASB issued ASU 2023-09 (ASC Topic 740), Improvements to Income Tax Disclosures. This ASU requires disaggregated income tax disclosures on the rate reconciliation and income taxes paid. The Company is required to adopt this guidance in the first quarter of the fiscal year 2026. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have impact on its Condensed Consolidated Financial Statements.

- removed (2024-01-26):
[0001137789-23-000128:note_history:15]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three months ended September 29, 2023 and September 30, 2022 consisted of 13 weeks. Fiscal years 2024 and 2023 both comprise 52 weeks and end on June 28, 2024 and June 30, 2023, respectively. The fiscal quarters ended September 29, 2023, June 30, 2023 and September 30, 2022, are also referred to herein as the “September 2023 quarter”, the “June 2023 quarter” and the “September 2022 quarter”, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-01-26):
[0001137789-24-000010:note_history:16]
Debt
The following table provides details of the Company’s debt as of December 29, 2023 and June 30, 2023:
  (was, 2023-10-27, similarity 0.9741):
[0001137789-23-000128:note_history:16]
Debt
The following table provides details of the Company’s debt as of September 29, 2023 and June 30, 2023:

- changed (2024-01-26):
[0001137789-24-000010:note_history:17]
| (Dollars in millions) |  | December 29, 2023 |  | June 30, 2023 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | $ | 479 |  |  | $ | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 469 |  |  | 465 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | — |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | — |  |  | 430 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
|  |  | 5,701 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (32) |  |  | (36) |  |
| Debt, net of debt issuance costs |  | 5,669 |  |  | 5,451 |  |
| Less: current portion of long-term debt |  | — |  |  | (63) |  |
| Long-term debt, less current portion |  | $ | 5,669 |  |  | $ | 5,388 |  |
  (was, 2023-10-27, similarity 0.9957):
[0001137789-23-000128:note_history:17]
| (Dollars in millions) |  | September 29, 2023 |  | June 30, 2023 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | $ | 479 |  |  | $ | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 467 |  |  | 465 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Convertible Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | — |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | — |  |  | 430 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
|  |  | 5,699 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (33) |  |  | (36) |  |
| Debt, net of debt issuance costs |  | 5,666 |  |  | 5,451 |  |
| Less: current portion of long-term debt |  | — |  |  | (63) |  |
| Long-term debt, less current portion |  | $ | 5,666 |  |  | $ | 5,388 |  |

- changed (2024-01-26):
[0001137789-24-000010:note_history:18]
(1) All unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX.
  (was, 2023-10-27, similarity 0.9693):
[0001137789-23-000128:note_history:18]
(1) All unsecured senior notes and convertible senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX.

- changed (2024-01-26):
[0001137789-24-000010:note_history:19]
2028 Exchangeable Senior Notes and related Capped Call Transactions
  (was, 2023-10-27, similarity 0.8819):
[0001137789-23-000128:note_history:19]
2028 Convertible Senior Notes and related Capped Call Transactions

- changed (2024-01-26):
[0001137789-24-000010:note_history:20]
2028 Notes. On September 13, 2023, Seagate HDD, in a private placement, issued $1.5 billion in aggregate principal amount of 3.50% exchangeable Senior Notes due 2028 (the “2028 Notes”), which includes $200 million aggregate principal amount pursuant to the over-allotment option of the initial purchasers to purchase additional notes. The 2028 Notes will mature on June 1, 2028, with interest payable semi-annually on March 1 and September 1 of each year, commencing March 1, 2024.
  (was, 2023-10-27, similarity 0.9809):
[0001137789-23-000128:note_history:20]
2028 Notes. On September 13, 2023, Seagate HDD, in a private placement, issued $1.5 billion in aggregate principal amount of 3.50% Convertible Senior Notes due 2028 (the “2028 Notes”), which includes $200 million aggregate principal amount pursuant to the over-allotment option of the initial purchasers to purchase additional notes. The 2028 Notes will mature on June 1, 2028, with interest payable semi-annually on March 1 and September 1 of each year, commencing March 1, 2024.

- changed (2024-01-26):
[0001137789-24-000010:note_history:21]
The entire outstanding principal amount of Term Loans A1, A2 and A3 were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in the Net loss recognized from early redemption of debt in the Company’s Condensed Consolidated Statements of Operations for the six months ended December 29, 2023. In connection with the repayment of Term Loans, the Company terminated its interest rate swap agreements. Refer to “Note 6. Derivative Financial Instruments” for more details.
  (was, 2023-10-27, similarity 0.9528):
[0001137789-23-000128:note_history:21]
The entire outstanding principal amount of Term Loans A1, A2 and A3 were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in the Net loss recognized from early redemption of debt in the Company’s Condensed Consolidated Statements of Operations for the first quarter of fiscal year 2024. In connection with the repayment of Term Loans, the Company terminated its interest rate swap agreements. Refer to “Note 6. Derivative Financial Instruments” for more details.

- added (2024-01-26):
[0001137789-24-000010:note_history:22]
Prior to March 1, 2028, the 2028 Notes are exchangeable at the option of the holders only under certain circumstances as set forth in the indenture with respect to the 2028 Notes. On or after March 1, 2028, the 2028 Notes are exchangeable at any time at the option of the holders until the close of business on the second scheduled trading day immediately preceding the maturity date, unless the 2028 Notes have been previously redeemed or repurchased by Seagate HDD. Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The initial exchange rate for the 2028 Notes is 12.1253 ordinary shares per $1,000 principal amount of 2028 Notes.

- changed (2024-01-26):
[0001137789-24-000010:note_history:23]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The cap price of the capped call transactions will initially be $107.848 per share, which represents a premium of approximately 70% over the last reported sale price of the ordinary shares of $63.44 per share on the Nasdaq Global Market on September 7, 2023. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets.
  (was, 2023-10-27, similarity 0.9846):
[0001137789-23-000128:note_history:23]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The cap price of the capped call transactions will initially be $107.848 per share, which represents a premium of approximately 70% over the last reported sale price of the ordinary shares of $63.44 per share on the Nasdaq Global Market on September 7, 2023. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets as of September 29, 2023.

- added (2024-01-26):
[0001137789-24-000010:note_history:24]
The credit agreement dated as of February 20, 2019, by and among, Seagate Technology Holdings plc, Seagate HDD, The Bank of Nova Scotia, as administrative agent, and the lenders party thereto (as amended from time to time, the “Credit Agreement”) includes two financial covenants: (1) interest coverage ratio and (2) total net leverage ratio. The maximum permitted total net leverage ratio did not apply for the fiscal quarter ended December 29, 2023 and will not apply for the fiscal quarter ending March 29, 2024. For the fiscal quarters ending June 28, 2024 until the end of the covenant relief period, which terminates on June 27, 2025, the maximum permitted total net leverage ratio is 6.75 to 1.00, and applies only to the extent that the aggregate outstanding amount of revolving loans, swing line loans and the aggregate face amount of certain letters of credit exceeds 25% of the then outstanding revolving commitments in effect (the “Testing Condition”) as of the last day of the fiscal quarter. The maximum permitted total leverage ratio for each fiscal quarter ending after June 27, 2025 is 4.00 to 1.00.

- added (2024-01-26):
[0001137789-24-000010:note_history:25]
The minimum interest coverage ratio did not apply for the fiscal quarter ended December 29, 2023 and will not apply for the fiscal quarter ending March 29, 2024. For the fiscal quarters ending June 28, 2024 until June 27, 2025, the minimum interest coverage ratio is 2.25 to 1.00, and applies only to the extent that the Testing Condition is satisfied as of the last day of the fiscal quarter. The minimum interest coverage ratio is 3.25 to 1.00 for each fiscal quarter ending after June 27, 2025.

- changed (2024-01-26):
[0001137789-24-000010:note_history:26]
At December 29, 2023, future principal payments on long-term debt were as follows (in millions):
  (was, 2023-10-27, similarity 0.9724):
[0001137789-23-000128:note_history:26]
At September 29, 2023, future principal payments on long-term debt were as follows (in millions):

- removed (2024-01-26):
[0001137789-23-000128:note_history:27]
Prior to March 1, 2028, the 2028 Notes are convertible at the option of the holders only under certain circumstances as set forth in the indenture with respect to the 2028 Notes. On or after March 1, 2028, the 2028 Notes are convertible at any time at the option of the holders until the close of business on the second scheduled trading day immediately preceding the maturity date, unless the 2028 Notes have been previously redeemed or repurchased by Seagate HDD. Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The initial exchange rate for the 2028 Notes is 12.1253 ordinary shares per $1,000 principal amount of 2028 Notes.

- removed (2024-01-26):
[0001137789-23-000128:note_history:28]
On September 27, 2023, Seagate Technology Holdings plc and Seagate HDD entered into an amendment to its credit agreement, dated September 20, 2019 (the “Tenth Amendment”). Under the Tenth Amendment, the maximum permitted total net leverage ratio is 6.75 to 1.00 for the fiscal quarter ending September 29, 2023. For the fiscal quarters ending December 29, 2023 and March 29, 2024, the total net leverage ratio covenant will not apply. For the fiscal quarters ending June 28, 2024 until the end of the covenant relief period, which terminates on June 27, 2025, the maximum permitted total net leverage ratio is 6.75 to 1.00, and applies only to the extent that the aggregate outstanding amount of revolving loans, swing line loans and the aggregate face amount of certain letters of credit exceeds 25% of the then outstanding revolving commitments in effect (the “Testing Condition”) as of the last day of the fiscal quarter. The maximum permitted total leverage ratio for each fiscal quarter ending after June 27, 2025 is 4.00 to 1.00.

- removed (2024-01-26):
[0001137789-23-000128:note_history:29]
The minimum interest coverage ratio is 2.25 to 1.00 for the fiscal quarter ending September 29, 2023. For the fiscal quarters ending December 29, 2023 and March 29, 2024, the minimum interest coverage ratio covenant will not apply. For the fiscal quarters ending June 28, 2024 until June 27, 2025, the minimum interest coverage ratio is 2.25 to 1.00, and applies only to the extent that the Testing Condition is satisfied as of the last day of the fiscal quarter. The minimum interest coverage ratio is 3.25 to 1.00 for each fiscal quarter ending after June 27, 2025.

- removed (2024-01-26):
[0001137789-23-000128:note_history:30]
The Tenth Amendment also removed the minimum liquidity covenant of $700 million. As of September 29, 2023, the Tenth Amendment includes two financial covenants: (1) interest coverage ratio and (2) total net leverage ratio. The Company was in compliance with the covenants as of September 29, 2023.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-01-26):
[0001137789-24-000010:note_history:31]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of December 29, 2023 and June 30, 2023:
  (was, 2023-10-27, similarity 0.985):
[0001137789-23-000128:note_history:31]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of September 29, 2023 and June 30, 2023:

- changed (2024-01-26):
[0001137789-24-000010:note_history:32]
|  |  | December 29, 2023 |  | June 30, 2023 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 90 |  |  | $ | — |  |  | $ | 90 |  |  | $ | 73 |  |  | $ | — |  |  | $ | 73 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 15 |  |  | — |  |  | 15 |  |  | 16 |  |  | — |  |  | 16 |  |
| Total |  | $ | 106 |  |  | $ | — |  |  | $ | 106 |  |  | $ | 90 |  |  | $ | — |  |  | $ | 90 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 89 |  |  |  |  |  |  | $ | 72 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 15 |  |  |  |  |  |  | 16 |  |
| Total |  |  |  |  |  | $ | 106 |  |  |  |  |  |  | $ | 90 |  |
  (was, 2023-10-27, similarity 0.9959):
[0001137789-23-000128:note_history:32]
|  |  | September 29, 2023 |  | June 30, 2023 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 121 |  |  | $ | — |  |  | $ | 121 |  |  | $ | 73 |  |  | $ | — |  |  | $ | 73 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 15 |  |  | — |  |  | 15 |  |  | 16 |  |  | — |  |  | 16 |  |
| Total |  | $ | 137 |  |  | $ | — |  |  | $ | 137 |  |  | $ | 90 |  |  | $ | — |  |  | $ | 90 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 120 |  |  |  |  |  |  | $ | 72 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 15 |  |  |  |  |  |  | 16 |  |
| Total |  |  |  |  |  | $ | 137 |  |  |  |  |  |  | $ | 90 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-01-26):
[0001137789-24-000010:note_history:33]
The following table provides details of the Company’s debt as of December 29, 2023 and June 30, 2023:
  (was, 2023-10-27, similarity 0.9727):
[0001137789-23-000128:note_history:33]
The following table provides details of the Company’s debt as of September 29, 2023 and June 30, 2023:

- changed (2024-01-26):
[0001137789-24-000010:note_history:34]
| (Dollars in millions) |  | December 29, 2023 |  | June 30, 2023 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | $ | 479 |  |  | $ | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 469 |  |  | 465 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | — |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | — |  |  | 430 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
|  |  | 5,701 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (32) |  |  | (36) |  |
| Debt, net of debt issuance costs |  | 5,669 |  |  | 5,451 |  |
| Less: current portion of long-term debt |  | — |  |  | (63) |  |
| Long-term debt, less current portion |  | $ | 5,669 |  |  | $ | 5,388 |  |
  (was, 2023-10-27, similarity 0.9957):
[0001137789-23-000128:note_history:34]
| (Dollars in millions) |  | September 29, 2023 |  | June 30, 2023 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | $ | 479 |  |  | $ | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 467 |  |  | 465 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Convertible Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | — |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | — |  |  | 430 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
|  |  | 5,699 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (33) |  |  | (36) |  |
| Debt, net of debt issuance costs |  | 5,666 |  |  | 5,451 |  |
| Less: current portion of long-term debt |  | — |  |  | (63) |  |
| Long-term debt, less current portion |  | $ | 5,666 |  |  | $ | 5,388 |  |

- changed (2024-01-26):
[0001137789-24-000010:note_history:35]
(1) All unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX.
  (was, 2023-10-27, similarity 0.9693):
[0001137789-23-000128:note_history:35]
(1) All unsecured senior notes and convertible senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-01-26):
[0001137789-24-000010:note_history:36]
At December 29, 2023, future principal payments on long-term debt were as follows (in millions):
  (was, 2023-10-27, similarity 0.9724):
[0001137789-23-000128:note_history:36]
At September 29, 2023, future principal payments on long-term debt were as follows (in millions):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-01-26):
[0001137789-24-000010:note_history:37]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | December 29, 2023 |  | December 30, 2022 |  | December 29, 2023 |  | December 30, 2022 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,140 |  |  | $ | 1,365 |  |  | $ | 2,172 |  |  | $ | 2,910 |  |  |  |  |  |
| Distributors |  | 218 |  |  | 297 |  |  | 484 |  |  | 596 |  |  |  |  |  |
| Retailers |  | 197 |  |  | 225 |  |  | 353 |  |  | 416 |  |  |  |  |  |
| Total |  | $ | 1,555 |  |  | $ | 1,887 |  |  | $ | 3,009 |  |  | $ | 3,922 |  |  |  |  |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 777 |  |  | $ | 760 |  |  | $ | 1,588 |  |  | $ | 1,561 |  |  |  |  |  |
| Americas |  | 544 |  |  | 853 |  |  | 999 |  |  | 1,789 |  |  |  |  |  |
| EMEA |  | 234 |  |  | 274 |  |  | 422 |  |  | 572 |  |  |  |  |  |
| Total |  | $ | 1,555 |  |  | $ | 1,887 |  |  | $ | 3,009 |  |  | $ | 3,922 |  |  |  |  |  |

- removed (2024-01-26):
[0001137789-23-000128:note_history:38]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | September 29, 2023 |  | September 30, 2022 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,032 |  |  | $ | 1,545 |  |  |  |  |  |
| Distributors |  | 266 |  |  | 299 |  |  |  |  |  |
| Retailers |  | 156 |  |  | 191 |  |  |  |  |  |
| Total |  | $ | 1,454 |  |  | $ | 2,035 |  |  |  |  |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 811 |  |  | $ | 801 |  |  |  |  |  |
| Americas |  | 455 |  |  | 936 |  |  |  |  |  |
| EMEA |  | 188 |  |  | 298 |  |  |  |  |  |
| Total |  | $ | 1,454 |  |  | $ | 2,035 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-01-26):
[0001137789-24-000010:note_history:39]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | December 29, 2023 |  | December 30, 2022 |  | December 29, 2023 |  | December 30, 2022 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,140 |  |  | $ | 1,365 |  |  | $ | 2,172 |  |  | $ | 2,910 |  |  |  |  |  |
| Distributors |  | 218 |  |  | 297 |  |  | 484 |  |  | 596 |  |  |  |  |  |
| Retailers |  | 197 |  |  | 225 |  |  | 353 |  |  | 416 |  |  |  |  |  |
| Total |  | $ | 1,555 |  |  | $ | 1,887 |  |  | $ | 3,009 |  |  | $ | 3,922 |  |  |  |  |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 777 |  |  | $ | 760 |  |  | $ | 1,588 |  |  | $ | 1,561 |  |  |  |  |  |
| Americas |  | 544 |  |  | 853 |  |  | 999 |  |  | 1,789 |  |  |  |  |  |
| EMEA |  | 234 |  |  | 274 |  |  | 422 |  |  | 572 |  |  |  |  |  |
| Total |  | $ | 1,555 |  |  | $ | 1,887 |  |  | $ | 3,009 |  |  | $ | 3,922 |  |  |  |  |  |

- removed (2024-01-26):
[0001137789-23-000128:note_history:40]
|  |  | For the Three Months Ended |  |  |
| (Dollars in millions) |  | September 29, 2023 |  | September 30, 2022 |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,032 |  |  | $ | 1,545 |  |  |  |  |  |
| Distributors |  | 266 |  |  | 299 |  |  |  |  |  |
| Retailers |  | 156 |  |  | 191 |  |  |  |  |  |
| Total |  | $ | 1,454 |  |  | $ | 2,035 |  |  |  |  |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 811 |  |  | $ | 801 |  |  |  |  |  |
| Americas |  | 455 |  |  | 936 |  |  |  |  |  |
| EMEA |  | 188 |  |  | 298 |  |  |  |  |  |
| Total |  | $ | 1,454 |  |  | $ | 2,035 |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2024-01-26):
[0001137789-24-000010:note_history:41]
On January 24, 2024, the Board of Directors of the Company declared a quarterly cash dividend of $0.70 per share, which will be payable on April 4, 2024 to shareholders of record as of the close of business on March 21, 2024.

- removed (2024-01-26):
[0001137789-23-000128:note_history:42]
On October 26, 2023, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on January 9, 2024 to shareholders of record as of the close of business on December 21, 2023.
