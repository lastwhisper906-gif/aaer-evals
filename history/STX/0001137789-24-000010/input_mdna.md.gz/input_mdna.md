# STX MD&A — 0001137789-24-000010


## mdna

[0001137789-24-000010:mdna:1]
[same as prior period, unchanged from 0001137789-23-000128:mdna:1]

[0001137789-24-000010:mdna:2]
The following is a discussion of the financial condition, changes in financial condition and results of operations for our fiscal quarters ended December 29, 2023, September 29, 2023 and December 30, 2022, referred to herein as the “December 2023 quarter”, the “September 2023 quarter” and the “December 2022 quarter”, respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The December 2023 quarter, September 2023 quarter and December 2022 quarter were each 13 weeks.

[0001137789-24-000010:mdna:3]
You should read this discussion in conjunction with financial information and related notes included in this Quarterly Report on Form 10-Q, as well as our Annual Report on Form 10-K for the fiscal year ended June 30, 2023. Unless the context indicates otherwise, as used herein, the terms “we,” “us,” “Seagate,” the “Company” and “our” refer collectively to Seagate Technology Holdings plc, an Irish public limited company, and its subsidiaries. References to “$” or “dollars” are to United States dollars.

[0001137789-24-000010:mdna:4]
[same as prior period, unchanged from 0001137789-23-000128:mdna:4]

[0001137789-24-000010:mdna:5]
•Overview of the December 2023 quarter. Highlights of events in the December 2023 quarter that impacted our financial position.

[0001137789-24-000010:mdna:6]
•Results of Operations. Analysis of our financial results comparing the December 2023 quarter to the September 2023 quarter and the December 2022 quarter.

[0001137789-24-000010:mdna:7]
•Liquidity and Capital Resources. Analysis of changes in our balance sheet and cash flows, and discussion of our financial condition including potential sources of liquidity, material cash requirements and their general purpose.

[0001137789-24-000010:mdna:8]
[same as prior period, unchanged from 0001137789-23-000128:mdna:8]

[0001137789-24-000010:mdna:9]
[same as prior period, unchanged from 0001137789-23-000128:mdna:9]

[0001137789-24-000010:mdna:10]
Overview of the December 2023 quarter

[0001137789-24-000010:mdna:11]
During the December 2023 quarter, we shipped 95 exabytes of HDD storage capacity. We generated revenue of approximately $1.6 billion with a gross margin of 23%. Our operating cash flow was $169 million and we paid $146 million in dividends. Additionally, we recorded a net loss of $43 million from equity investments and recognized a gain of $30 million from the sale and leaseback of certain property.

[0001137789-24-000010:mdna:12]
[same as prior period, unchanged from 0001137789-23-000128:mdna:12]

[0001137789-24-000010:mdna:13]
During the December 2023 quarter, we experienced gradual recovery within the U.S. cloud market, reflecting progress in customer inventory adjustments along with more stable end-market demand, although the data storage industry and our business continued to be impacted by macroeconomic headwinds. As a result of these market dynamics, we continued to execute cost discipline, manage our factory production levels in light of the lower demand and implement pricing actions to improve operational efficiencies and profitability. We expect the dynamic macroeconomic environment will continue to moderate our business and results of operations in what we believe is the early stage of industry-wide demand recovery.

[0001137789-24-000010:mdna:14]
[same as prior period, unchanged from 0001137789-23-000128:mdna:14]

[0001137789-24-000010:mdna:15]
[same as prior period, unchanged from 0001137789-23-000128:mdna:15]

[0001137789-24-000010:mdna:16]
[same as prior period, unchanged from 0001137789-23-000128:mdna:16]

[0001137789-24-000010:mdna:17]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 29, 2023 |  | September 29, 2023 |  | December 30, 2022 |  | December 29,2023 |  | December 30,2022 |
| Revenue |  | $ | 1,555 |  |  | $ | 1,454 |  |  | $ | 1,887 |  |  | $ | 3,009 |  |  | $ | 3,922 |  |
| Cost of revenue |  | 1,193 |  |  | 1,305 |  |  | 1,641 |  |  | 2,498 |  |  | 3,194 |  |
| Gross profit |  | 362 |  |  | 149 |  |  | 246 |  |  | 511 |  |  | 728 |  |
| Product development |  | 161 |  |  | 171 |  |  | 200 |  |  | 332 |  |  | 434 |  |
| Marketing and administrative |  | 108 |  |  | 105 |  |  | 125 |  |  | 213 |  |  | 254 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |
| Restructuring and other, net |  | (31) |  |  | 2 |  |  | 81 |  |  | (29) |  |  | 90 |  |
| Income (loss) from operations |  | 124 |  |  | (129) |  |  | (160) |  |  | (5) |  |  | (53) |  |
| Other (expense) income, net |  | (128) |  |  | (18) |  |  | 122 |  |  | (146) |  |  | 42 |  |
| Loss before income taxes |  | (4) |  |  | (147) |  |  | (38) |  |  | (151) |  |  | (11) |  |
| Provision for (Benefit from) income taxes |  | 15 |  |  | 37 |  |  | (5) |  |  | 52 |  |  | (7) |  |
| Net loss |  | $ | (19) |  |  | $ | (184) |  |  | $ | (33) |  |  | $ | (203) |  |  | $ | (4) |  |

[0001137789-24-000010:mdna:18]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
|  |  | December 29, 2023 |  | September 29, 2023 |  | December 30, 2022 |  | December 29,2023 |  | December 30,2022 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 77 |  |  | 90 |  |  | 87 |  |  | 83 |  |  | 81 |  |
| Gross margin |  | 23 |  |  | 10 |  |  | 13 |  |  | 17 |  |  | 19 |  |
| Product development |  | 10 |  |  | 12 |  |  | 11 |  |  | 11 |  |  | 11 |  |
| Marketing and administrative |  | 7 |  |  | 7 |  |  | 7 |  |  | 7 |  |  | 7 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Restructuring and other, net |  | (2) |  |  | — |  |  | 4 |  |  | (1) |  |  | 2 |  |
| Operating margin |  | 8 |  |  | (9) |  |  | (9) |  |  | — |  |  | (1) |  |
| Other (expense) income, net |  | (8) |  |  | (1) |  |  | 6 |  |  | (5) |  |  | 1 |  |
| Loss before income taxes |  | — |  |  | (10) |  |  | (3) |  |  | (5) |  |  | — |  |
| Provision for income taxes |  | 1 |  |  | 3 |  |  | — |  |  | 2 |  |  | — |  |
| Net loss |  | (1 | %) |  | (13 | %) |  | (3 | %) |  | (7 | %) |  | — | % |

[0001137789-24-000010:mdna:19]
30

[0001137789-24-000010:mdna:20]
[same as prior period, unchanged from 0001137789-23-000128:mdna:20]

[0001137789-24-000010:mdna:21]
[same as prior period, unchanged from 0001137789-23-000128:mdna:21]

[0001137789-24-000010:mdna:22]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
|  |  | December 29, 2023 |  | September 29, 2023 |  | December 30, 2022 |  | December 29,2023 |  | December 30,2022 |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 73 | % |  | 71 | % |  | 72 | % |  | 72 | % |  | 74 | % |
| Distributors |  | 14 | % |  | 18 | % |  | 16 | % |  | 16 | % |  | 15 | % |
| Retailers |  | 13 | % |  | 11 | % |  | 12 | % |  | 12 | % |  | 11 | % |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 50 | % |  | 56 | % |  | 40 | % |  | 53 | % |  | 40 | % |
| Americas |  | 35 | % |  | 31 | % |  | 45 | % |  | 33 | % |  | 46 | % |
| EMEA |  | 15 | % |  | 13 | % |  | 15 | % |  | 14 | % |  | 14 | % |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 68 | % |  | 70 | % |  | 66 | % |  | 69 | % |  | 67 | % |
| Legacy |  | 21 | % |  | 19 | % |  | 22 | % |  | 20 | % |  | 21 | % |
| Other |  | 11 | % |  | 11 | % |  | 12 | % |  | 11 | % |  | 12 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 83 |  |  | 79 |  |  | 97 |  |  | 162 |  |  | 201 |  |
| Legacy |  | 12 |  |  | 11 |  |  | 16 |  |  | 23 |  |  | 30 |  |
| Total |  | 95 |  |  | 90 |  |  | 113 |  |  | 185 |  |  | 231 |  |
| HDD Price per Terabyte |  | $ | 14 |  |  | $ | 14 |  |  | $ | 15 |  |  | $ | 14 |  |  | $ | 15 |  |

[0001137789-24-000010:mdna:23]
[same as prior period, unchanged from 0001137789-23-000128:mdna:23]

[0001137789-24-000010:mdna:24]
[same as prior period, unchanged from 0001137789-23-000128:mdna:24]

[0001137789-24-000010:mdna:25]
Revenue in the December 2023 quarter increased by $101 million compared to the September 2023 quarter, primarily due to an increase in mass capacity and legacy storage exabytes shipped, as we experienced gradual recovery within the U.S. cloud market and positive seasonality within the consumer market.

[0001137789-24-000010:mdna:26]
Revenue for the three and six months ended December 29, 2023 decreased by $332 million and $913 million from the three and six months ended December 30, 2022, respectively, primarily due to a decrease in exabytes shipped, reflecting broad-based demand slowdown resulting from weaker macroeconomic conditions.

[0001137789-24-000010:mdna:27]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 18% of gross revenue for the December 2023 quarter, 20% for the September 2023 quarter and 17% for the December 2022 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 3% of quarterly gross revenue in all periods presented.

[0001137789-24-000010:mdna:28]
[same as prior period, unchanged from 0001137789-23-000128:mdna:28]

[0001137789-24-000010:mdna:29]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 29, 2023 |  | September 29, 2023 |  | December 30, 2022 |  | December 29,2023 |  | December 30,2022 |
| Cost of revenue |  | $ | 1,193 |  |  | $ | 1,305 |  |  | $ | 1,641 |  |  | $ | 2,498 |  |  | $ | 3,194 |  |
| Gross profit |  | 362 |  |  | 149 |  |  | 246 |  |  | 511 |  |  | 728 |  |
| Gross margin |  | 23 | % |  | 10 | % |  | 13 | % |  | 17 | % |  | 19 | % |

[0001137789-24-000010:mdna:30]
[same as prior period, unchanged from 0001137789-23-000128:mdna:45]

[0001137789-24-000010:mdna:31]
Gross margin for the December 2023 quarter increased compared to the September 2023 quarter, primarily driven by $118 million of order cancellation fees for the September 2023 quarter that did not recur, a $23 million reduction in factory underutilization charges, a $20 million decrease in depreciation expense due to the extension of useful lives of certain manufacturing equipment, $13 million of accelerated depreciation expense for certain capital equipment that did not recur, and favorable pricing actions undertaken by the Company.

[0001137789-24-000010:mdna:32]
Gross margin for the December 2023 quarter increased compared to the December 2022 quarter, primarily driven by $108 million of order cancellation fees for the December 2022 quarter that did not recur, a $43 million reduction in factory underutilization charges which included the decrease in depreciation expense due to the extension of useful lives of certain manufacturing equipment, and $39 million of accelerated depreciation expense for certain capital equipment that did not recur.

[0001137789-24-000010:mdna:33]
Gross margin for the six months ended December 29, 2023 decreased compared to the six months ended December 30, 2022 primarily driven by an increase of $6 million in order cancellation fees and less favorable product mix, partially offset by a $40 million reduction in factory underutilization charges which included the decrease in depreciation expense due to the extension of useful lives of certain manufacturing equipment, a decrease of $26 million in accelerated depreciation expense for certain capital equipment, and pandemic-related lockdown in one of our factories in fiscal year 2023 that did not recur.

[0001137789-24-000010:mdna:34]
In the December 2023 quarter, total warranty cost was 0.8% of revenue and included an unfavorable change in estimates of prior warranty accruals of 0.1% of revenue primarily due to changes to our estimated future product return rates. Warranty cost related to new shipments was 0.9%, 0.9% and 0.7% of revenue for the December 2023 quarter, September 2023 quarter and December 2022 quarter, respectively.

[0001137789-24-000010:mdna:35]
[same as prior period, unchanged from 0001137789-23-000128:mdna:33]

[0001137789-24-000010:mdna:36]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 29, 2023 |  | September 29, 2023 |  | December 30, 2022 |  | December 29,2023 |  | December 30,2022 |
| Product development |  | 161 |  |  | $ | 171 |  |  | $ | 200 |  |  | $ | 332 |  |  | $ | 434 |  |
| Marketing and administrative |  | 108 |  |  | 105 |  |  | 125 |  |  | 213 |  |  | 254 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |
| Restructuring and other, net |  | (31) |  |  | 2 |  |  | 81 |  |  | (29) |  |  | 90 |  |
| Operating expenses |  | $ | 238 |  |  | $ | 278 |  |  | $ | 406 |  |  | $ | 516 |  |  | $ | 781 |  |

[0001137789-24-000010:mdna:37]
Product development expense. Product development expenses decreased by $10 million in the December 2023 quarter compared to the September 2023 quarter, primarily due to a $7 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our restructuring plans.

[0001137789-24-000010:mdna:38]
Product development expenses decreased by $39 million in the December 2023 quarter compared to the December 2022 quarter, primarily due to a $36 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our restructuring plans and temporary salary reduction and an $8 million decrease in depreciation expense, partially offset by $7 million increase in lease expense as we sold and leased back certain properties.

[0001137789-24-000010:mdna:39]
Product development expenses decreased by $102 million for the six months ended December 29, 2023 compared to the six months ended December 30, 2022, primarily due to a $75 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our restructuring plans and temporary salary reduction and a $37 million decrease in depreciation expense, partially offset by a $13 million increase in lease expense as we sold and leased back certain properties.

[0001137789-24-000010:mdna:40]
Marketing and administrative expense. Marketing and administrative expenses increased by $3 million in the December 2023 quarter compared to the September 2023 quarter primarily due to a $2 million increase in advertising costs and a $1 million increase in compensation and other employee benefits due to the completion of the temporary salary reduction during the December 2023 quarter.

[0001137789-24-000010:mdna:41]
Marketing and administrative expenses decreased by $17 million in the December 2023 quarter compared to the December 2022 quarter primarily due to a $23 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our restructuring plans and temporary salary reduction and a $3 million decrease in advertising costs, partially offset by a $7 million recovery in the December 2022 quarter of an accounts receivable previously written off in prior years.

[0001137789-24-000010:mdna:42]
Marketing and administrative expenses decreased by $41 million for the six months ended December 29, 2023 compared to the six months ended December 30, 2022 primarily due to a $26 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our restructuring plans and temporary salary reduction, a $9 million decrease in advertising costs, an $8 million decrease in outside services expense, a $5 million decrease in legal costs and a $4 million decrease in travel expenses, partially offset by a $7 million recovery in the December 2022 quarter of an accounts receivable previously written off in prior years.

[0001137789-24-000010:mdna:43]
Restructuring and other, net. Restructuring and other, net for the three and six months ended December 29, 2023 was a $31 million benefit and $29 million benefit, respectively, primarily due to the net gain of $30 million from the sale and leaseback transaction during the December 2023 quarter.

[0001137789-24-000010:mdna:44]
Other (Expense) Income, Net

[0001137789-24-000010:mdna:45]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 29, 2023 |  | September 29, 2023 |  | December 30, 2022 |  | December 29, 2023 |  | December 30, 2022 |
| Other (Expense) Income, net |  | $ | (128) |  |  | $ | (18) |  |  | $ | 122 |  |  | $ | (146) |  |  | $ | 42 |  |

[0001137789-24-000010:mdna:46]
Other (expense) income, net. Other expense increased by $110 million for the December 2023 quarter compared to the September 2023 quarter primarily due to $104 million of net gain recognized from the termination of interest rate swaps associated with the repayment of term loans in the September 2023 quarter, partially offset by $29 million of net loss recognized from early redemption of debt in the September 2023 quarter and $43 million of net loss from equity investments in the December 2023 quarter.

[0001137789-24-000010:mdna:47]
Other expense increased by $250 million for the December 2023 quarter compared to the December 2022 quarter primarily due to $204 million of net gain recognized from the early redemption of debt in the December 2022 quarter and $43 million of net loss from equity investments in the December 2023 quarter.

[0001137789-24-000010:mdna:48]
Other expense increased by $188 million for the six months ended December 2023 compared to the six months ended December 2022 primarily due to $204 million of net gain recognized from the early redemption of debt in the six months ended December 2022, a $43 million net loss from equity investments and a $29 million net loss recognized from early redemption of debt in the six months ended December 2023 and a $20 million increase in interest expense. The increase is partially offset by $104 million of net gain recognized from the termination of interest rate swaps associated with the repayment of term loans in the six months ended December 2023.

[0001137789-24-000010:mdna:49]
[same as prior period, unchanged from 0001137789-23-000128:mdna:47]

[0001137789-24-000010:mdna:50]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 29, 2023 |  | September 29, 2023 |  | December 30, 2022 |  | December 29,2023 |  | December 30,2022 |
| Provision for (benefit from) income taxes |  | $ | 15 |  |  | $ | 37 |  |  | $ | (5) |  |  | $ | 52 |  |  | $ | (7) |  |

[0001137789-24-000010:mdna:51]
We recorded income tax provisions of $15 million and $52 million for the three and six months ended December 29, 2023, respectively. The discrete items in the income tax provision were not material for the three months ended December 29, 2023. The income tax provision for the six months ended December 29, 2023 included approximately $36 million of net discrete expense, primarily associated with an increase in our valuation allowance to account for the impacts of new tax guidance which clarifies the treatment of specified research and experimental expenditures issued by the U.S. Treasury Department under Internal Revenue Code Section 174 during the September 2023 quarter, partially offset by net excess tax benefits related to share-based compensation expense. Additional guidance issued by the U.S. Treasury Department in December 2023 did not result in any impacts. We will have income taxes payable based on profits generated in various jurisdictions.

[0001137789-24-000010:mdna:52]
During the six months ended December 29, 2023, our unrecognized tax benefits, excluding interest and penalties decreased by approximately $8 million to $108 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. We do not expect material changes to our unrecognized tax benefits in the next twelve months beginning December 30, 2023.

[0001137789-24-000010:mdna:53]
We recorded income tax benefits of $5 million and $7 million for the three and six months ended December 30, 2022, respectively. The discrete items in the income tax benefit were not material for the three months ended December 30, 2022. The income tax benefit for the six months ended December 30, 2022 included approximately $5 million of net discrete tax benefit, primarily associated with excess tax benefits related to share-based compensation expense.

[0001137789-24-000010:mdna:54]
[same as prior period, unchanged from 0001137789-23-000128:mdna:82]

[0001137789-24-000010:mdna:55]
Our income tax provision recorded for the three and six months ended December 29, 2023 and December 30, 2022 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) increases in valuation allowance, and/or (iii) the generation of research credits during the current fiscal year.

[0001137789-24-000010:mdna:56]
[same as prior period, unchanged from 0001137789-23-000128:mdna:54]

[0001137789-24-000010:mdna:57]
[same as prior period, unchanged from 0001137789-23-000128:mdna:55]

[0001137789-24-000010:mdna:58]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of December 29, 2023. For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, see “Part II, Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q.

[0001137789-24-000010:mdna:59]
[same as prior period, unchanged from 0001137789-23-000128:mdna:57]

[0001137789-24-000010:mdna:60]
| (Dollars in millions) |  | December 29, 2023 |  | June 30, 2023 |  | Change |
| Cash and cash equivalents |  | $ | 787 |  |  | $ | 786 |  |  | $ | 1 |  |

[0001137789-24-000010:mdna:61]
Our cash and cash equivalents as of December 29, 2023 increased by $1 million from June 30, 2023 primarily as a result of net cash of $296 million provided by operating activities and net proceeds of $1.5 billion from the issuance of exchangeable senior notes, partially offset by $1.3 billion redemption of term loans, dividends paid to our shareholders of $291 million, $128 million debt fees relating to issuance of long-term exchangeable debt and capped call transaction and payments for capital expenditures of $140 million.

[0001137789-24-000010:mdna:62]
[same as prior period, unchanged from 0001137789-23-000128:mdna:60]

[0001137789-24-000010:mdna:63]
Cash provided by operating activities for the six months ended December 29, 2023 was $296 million and includes the effects of net loss adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-24-000010:mdna:64]
•a decrease of $150 million in accounts receivable, primarily due to lower revenue and higher accounts receivable factoring;

[0001137789-24-000010:mdna:65]
•a decrease of $87 million in inventories, primarily due to a decrease in units built to align with the prevailing demand environment;

[0001137789-24-000010:mdna:66]
•an increase of $54 million in accounts payable, primarily due to timing of payments; and

[0001137789-24-000010:mdna:67]
[same as prior period, unchanged from 0001137789-23-000128:mdna:64]

[0001137789-24-000010:mdna:68]
•a decrease of $28 million in accrued expenses primarily due to restructuring activities and BIS settlement penalty payment; and

[0001137789-24-000010:mdna:69]
•a decrease of $14 million in accrued employee compensation, primarily due to timing of payments.

[0001137789-24-000010:mdna:70]
[same as prior period, unchanged from 0001137789-23-000128:mdna:68]

[0001137789-24-000010:mdna:71]
Net cash used in investing activities for the six months ended December 29, 2023 was $105 million, primarily attributable to payments of $140 million for the purchase of property, equipment and leasehold improvements, offset by proceeds of $35 million from the sale of assets, which included $34 million from the sale and leaseback transaction during the December 2023 quarter.

[0001137789-24-000010:mdna:72]
[same as prior period, unchanged from 0001137789-23-000128:mdna:70]

[0001137789-24-000010:mdna:73]
Net cash used in financing activities of $191 million for the six months ended December 29, 2023 was primarily attributable to the following activities:

[0001137789-24-000010:mdna:74]
[same as prior period, unchanged from 0001137789-23-000128:mdna:72]

[0001137789-24-000010:mdna:75]
•$291 million in dividend payments;

[0001137789-24-000010:mdna:76]
•$128 million debt fees relating to issuance of long-term debt and capped call transaction; and

[0001137789-24-000010:mdna:77]
•$28 million taxes paid related to net share settlement of equity awards; partially offset by

[0001137789-24-000010:mdna:78]
[same as prior period, unchanged from 0001137789-23-000128:mdna:76]

[0001137789-24-000010:mdna:79]
•$44 million proceeds from issuance of ordinary shares under employee stock purchase plans.

[0001137789-24-000010:mdna:80]
[same as prior period, unchanged from 0001137789-23-000128:mdna:78]

[0001137789-24-000010:mdna:81]
Our primary sources of liquidity as of December 29, 2023 consist of: (1) approximately $787 million in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.5 billion available for borrowing under the revolving credit facility of the Credit Agreement (the “Revolving Credit Facility”).

[0001137789-24-000010:mdna:82]
As of December 29, 2023, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-24-000010:mdna:83]
As of December 29, 2023, the existing Credit Agreement includes two financial covenants: (1) interest coverage ratio and (2) total net leverage ratio. The interest coverage ratio and total net leverage ratio covenants did not apply for the fiscal quarter ended December 29, 2023 and will not apply for the fiscal quarter ending March 29, 2024. Refer to “Part I, Item 1. Financial Statements—Note 3. Debt” for details of the financial covenants which will apply for the fiscal quarter ending June 28, 2024 and thereafter.

[0001137789-24-000010:mdna:84]
We believe that our sources of cash will be sufficient to fund our operations and meet our cash requirements for at least the next 12 months. Our ability to fund liquidity requirements beyond 12 months will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, see “Part II, Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q.

[0001137789-24-000010:mdna:85]
[same as prior period, unchanged from 0001137789-23-000128:mdna:84]

[0001137789-24-000010:mdna:86]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness and to fund our quarterly dividend and any future strategic investments. As of December 29, 2023, our contractual cash requirements have not changed materially since our Annual Report on Form 10-K for the fiscal year ended June 30, 2023, except for the purchase obligations and long-term debt obligations.

[0001137789-24-000010:mdna:87]
[same as prior period, unchanged from 0001137789-23-000128:mdna:86]

[0001137789-24-000010:mdna:88]
Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. From time to time, we enter into long-term, non-cancelable purchase commitments or make large up-front investments with certain suppliers in order to secure certain components or technologies for the production of our products or to supplement our internal manufacturing capacity for certain components. As of December 29, 2023, we had unconditional purchase obligations of approximately $3.7 billion primarily related to purchases of inventory components with our suppliers. We expect $1.1 billion of these short-term commitments to be paid within one year and expect $2.6 billion of these long-term commitments to be paid thereafter.

[0001137789-24-000010:mdna:89]
The Company recorded order cancellation fees to terminate certain purchase commitments related to the purchase of inventory components and equipment. During the six months ended December 29, 2023, we recorded order cancellation fees of $114 million, which were reflected under Cost of revenue on our Condensed Consolidated Statements of Operations. As of December 29, 2023, cumulative unpaid order cancellation fees on the Condensed Consolidated Balance Sheets were $144 million, with $127 million in Accrued expenses and $17 million in Accounts payable, all of which is expected to be paid within one year.

[0001137789-24-000010:mdna:90]
35

[0001137789-24-000010:mdna:91]
[same as prior period, unchanged from 0001137789-23-000128:mdna:89]

[0001137789-24-000010:mdna:92]
On September 13, 2023, we issued the 2028 Notes of $1.5 billion and repaid Term Loans A1, A2 and A3 of $1.3 billion. The exchange was accounted for as a debt extinguishment and resulted in a net loss of $29 million for the six months ended December 29, 2023.

[0001137789-24-000010:mdna:93]
As of December 29, 2023, the future principal payment obligation on our long-term debt was $5.7 billion, which will mature in more than one year. As of December 29, 2023, future interest payments on this outstanding debt are estimated to be approximately $2.2 billion, of which $325 million is expected to be paid within one year. From time to time, we may repurchase any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 1. Financial Statements—Note 3. Debt” for more details.

[0001137789-24-000010:mdna:94]
[same as prior period, unchanged from 0001137789-23-000128:mdna:92]

[0001137789-24-000010:mdna:95]
We accrued a settlement penalty of $300 million in the quarter ended March 31, 2023, related to BIS’ allegations of violations of the U.S. EAR, which were subsequently resolved by the Settlement Agreement in April 2023. As part of the Settlement Agreement with BIS, quarterly payments of $15 million are made over the course of five years beginning October 31, 2023, of which $60 million is expected to be paid within one year and $225 million thereafter. Refer to “Item 1. Financial Statements—Note 12. Legal, Environmental and Other Contingencies” for more details.

[0001137789-24-000010:mdna:96]
[same as prior period, unchanged from 0001137789-23-000128:mdna:94]

[0001137789-24-000010:mdna:97]
During the six months ended December 29, 2023, we made cash payments of $110 million related to the workforce reduction costs under the restructuring plans.

[0001137789-24-000010:mdna:98]
As of December 29, 2023, the future cash payments related to our remaining active restructuring plans were $10 million, of which $9 million is expected to be paid within one year.

[0001137789-24-000010:mdna:99]
[same as prior period, unchanged from 0001137789-23-000128:mdna:97]

[0001137789-24-000010:mdna:100]
During the December 2023 quarter, we declared dividends of $0.70 per share, totaling $147 million, which was paid on January 9, 2024. On January 24, 2024, we declared a quarterly cash dividend of $0.70 per share, payable on April 4, 2024 to shareholders of record at the close of business on March 21, 2024. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-24-000010:mdna:101]
[same as prior period, unchanged from 0001137789-23-000128:mdna:99]

[0001137789-24-000010:mdna:102]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker-assisted purchases, tender offers, or other means, including through the use of derivative transactions. As of December 29, 2023, $1.9 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-24-000010:mdna:103]
[same as prior period, unchanged from 0001137789-23-000128:mdna:101]

[0001137789-24-000010:mdna:104]
[same as prior period, unchanged from 0001137789-23-000128:mdna:102]

[0001137789-24-000010:mdna:105]
[same as prior period, unchanged from 0001137789-23-000128:mdna:103]

[0001137789-24-000010:mdna:106]
[same as prior period, unchanged from 0001137789-23-000128:mdna:104]

[0001137789-24-000010:mdna:107]
[same as prior period, unchanged from 0001137789-23-000128:mdna:105]

[0001137789-24-000010:mdna:108]
[same as prior period, unchanged from 0001137789-23-000128:mdna:106]

[0001137789-24-000010:mdna:109]
[same as prior period, unchanged from 0001137789-23-000128:mdna:107]
