# STX notes — 0001137789-23-000010


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001137789-23-000010:notes:1]
[same as prior period, unchanged from 0001137789-22-000123:notes:1]

[0001137789-23-000010:notes:2]
[same as prior period, unchanged from 0001137789-22-000123:notes:2]

[0001137789-23-000010:notes:3]
[same as prior period, unchanged from 0001137789-22-000123:notes:3]

[0001137789-23-000010:notes:4]
[same as prior period, unchanged from 0001137789-22-000123:notes:4]

[0001137789-23-000010:notes:5]
[same as prior period, unchanged from 0001137789-22-000123:notes:5]

[0001137789-23-000010:notes:6]
[same as prior period, unchanged from 0001137789-22-000123:notes:6]

[0001137789-23-000010:notes:7]
[same as prior period, unchanged from 0001137789-22-000123:notes:7]

[0001137789-23-000010:notes:8]
[same as prior period, unchanged from 0001137789-22-000123:notes:8]

[0001137789-23-000010:notes:9]
[same as prior period, unchanged from 0001137789-22-000123:notes:9]

[0001137789-23-000010:notes:10]
The Company’s consolidated financial statements for the fiscal year ended July 1, 2022 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 5, 2022. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 1, 2022, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and six months ended December 30, 2022 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 30, 2023.

[0001137789-23-000010:notes:11]
[same as prior period, unchanged from 0001137789-22-000123:notes:11]

[0001137789-23-000010:notes:12]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and six months ended December 30, 2022 and the three and six months ended December 31, 2021 consisted of 13 and 26 weeks, respectively. Fiscal years 2023 and 2022 both comprise of 52 weeks and end on June 30, 2023 and July 1, 2022, respectively. The fiscal quarters ended December 30, 2022, September 30, 2022 and December 31, 2021, are also referred to herein as the “December 2022 quarter”, the “September 2022 quarter” and the “December 2021 quarter”, respectively.

[0001137789-23-000010:notes:13]
[same as prior period, unchanged from 0001137789-22-000123:notes:13]

[0001137789-23-000010:notes:14]
[same as prior period, unchanged from 0001137789-22-000123:notes:14]

[0001137789-23-000010:notes:15]
Recently Adopted Accounting Pronouncements

[0001137789-23-000010:notes:16]
In March 2020, the Financial Accounting Standards Board (“FASB”) issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. In December 2022, FASB issued ASU 2022-06 (ASC Topic 848) and deferred the sunset date from December 31, 2022 to December 31, 2024. The Company adopted the guidance in the quarter ended September 30, 2022 on a prospective basis and is transitioning from an interest rate based on London Interbank Offered Rate (“LIBOR”) to Secured Overnight Financing Rate (“SOFR”). The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.

[0001137789-23-000010:notes:17]
In November 2021, the FASB issued ASU 2021-10 (ASC Topic 832), Disclosures by Business Entities about Government Assistance. This ASU requires annual disclosures that increase the transparency of transactions involving government grants, including (1) the type of transactions, (2) the accounting for those transactions and (3) the effect of those transactions on an entity’s financial statements. The Company adopted the guidance in the quarter ended September 30, 2022.

[0001137789-23-000010:notes:18]
Recently Issued Accounting Pronouncements

[0001137789-23-000010:notes:19]
In September 2022, the FASB issued ASU 2022-04 (ASC Subtopic 405-50), Disclosure of Supplier Finance Program Obligations. This ASU requires disclosure of key terms of the outstanding supplier finance programs and a rollforward of the related obligations. The Company is required to adopt this guidance in the first quarter of fiscal year 2024. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its condensed consolidated financial statements.

[0001137789-23-000010:notes:20]
In June 2022, the FASB issued ASU 2022-03 (ASC Topic 820), Fair Value Measurement of Equity Securities Subject to Contractual Sale Restrictions. This ASU clarifies that a contractual restriction on the sale of equity security is not considered when measuring its fair value and requires new disclosures for equity securities subject to contractual sale restriction. The Company is required to adopt this guidance in the first quarter of fiscal year 2025. The Company does not expect the adoption of this ASU to have a material impact on its condensed consolidated financial statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001137789-23-000010:notes:21]
[same as prior period, unchanged from 0001137789-22-000123:notes:21]

[0001137789-23-000010:notes:22]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of December 30, 2022 and July 1, 2022:

[0001137789-23-000010:notes:23]
|  |  | December 30,2022 |  | July 1,2022 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 173 |  |  | $ | — |  |  | $ | 173 |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 16 |  |  | — |  |  | 16 |  |  | 23 |  |  | — |  |  | 23 |  |
| Total |  | $ | 190 |  |  | $ | — |  |  | $ | 190 |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 172 |  |  |  |  |  |  | $ | 59 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 16 |  |  |  |  |  |  | 23 |  |
| Total |  |  |  |  |  | $ | 190 |  |  |  |  |  |  | $ | 84 |  |

[0001137789-23-000010:notes:24]
As of December 30, 2022 and July 1, 2022, the Company’s Other current assets included $2 million in restricted cash equivalents held as collateral at banks for various performance obligations.

[0001137789-23-000010:notes:25]
As of December 30, 2022 and July 1, 2022, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no impairment related to credit losses for available-for-sale debt securities as of December 30, 2022.

[0001137789-23-000010:notes:26]
The fair value and amortized cost of the Company’s investments classified as available-for-sale debt securities as of December 30, 2022, by remaining contractual maturity were as follows:

[0001137789-23-000010:notes:27]
| (Dollars in millions) |  | Amortized Cost |  | Fair Value |
| Due in less than 1 year |  | $ | 174 |  |  | $ | 174 |  |
| Due in 1 to 5 years |  | 15 |  |  | 15 |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | 1 |  |  | 1 |  |
| Total |  | $ | 190 |  |  | $ | 190 |  |

[0001137789-23-000010:notes:28]
[same as prior period, unchanged from 0001137789-22-000123:notes:28]

[0001137789-23-000010:notes:29]
[same as prior period, unchanged from 0001137789-22-000123:notes:29]

[0001137789-23-000010:notes:30]
| (Dollars in millions) |  | December 30,2022 |  |  |  | July 1,2022 |  | December 31,2021 |  |  |  | July 2,2021 |
| Cash and cash equivalents |  | $ | 770 |  |  |  |  | $ | 615 |  |  | $ | 1,535 |  |  |  |  | $ | 1,209 |  |
| Restricted cash included in Other current assets |  | 2 |  |  |  |  | 2 |  |  | 2 |  |  |  |  | 2 |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  | $ | 772 |  |  |  |  | $ | 617 |  |  | $ | 1,537 |  |  |  |  | $ | 1,211 |  |

[0001137789-23-000010:notes:31]
[same as prior period, unchanged from 0001137789-22-000123:notes:31]

[0001137789-23-000010:notes:32]
In connection with the Company’s factoring agreements, from time to time the Company sells trade receivables to a third party for cash proceeds less a discount. During the three and six months ended December 30, 2022, the Company sold trade receivables without recourse for cash proceeds of $211 million and $411 million, respectively. As of December 30, 2022, the total amount that remained subject to servicing by the Company was $287 million. The discounts on receivables sold were not material for the three and six months ended December 30, 2022. During the three and six months ended December 31, 2021, the company did not sell any trade receivables to a third party.

[0001137789-23-000010:notes:33]
[same as prior period, unchanged from 0001137789-22-000123:notes:33]

[0001137789-23-000010:notes:34]
[same as prior period, unchanged from 0001137789-22-000123:notes:34]

[0001137789-23-000010:notes:35]
| (Dollars in millions) |  | December 30,2022 |  | July 1,2022 |
| Raw materials and components |  | $ | 624 |  |  | $ | 601 |  |
| Work-in-process |  | 305 |  |  | 414 |  |
| Finished goods |  | 265 |  |  | 550 |  |
| Total inventories |  | $ | 1,194 |  |  | $ | 1,565 |  |

[0001137789-23-000010:notes:36]
[same as prior period, unchanged from 0001137789-22-000123:notes:36]

[0001137789-23-000010:notes:37]
[same as prior period, unchanged from 0001137789-22-000123:notes:37]

[0001137789-23-000010:notes:38]
| (Dollars in millions) |  | December 30,2022 |  | July 1,2022 |
| Property, equipment and leasehold improvements |  | $ | 10,743 |  |  | $ | 10,659 |  |
| Accumulated depreciation and amortization |  | (8,621) |  |  | (8,420) |  |
| Property, equipment and leasehold improvements, net |  | $ | 2,122 |  |  | $ | 2,239 |  |

[0001137789-23-000010:notes:39]
[same as prior period, unchanged from 0001137789-22-000123:notes:39]

[0001137789-23-000010:notes:40]
[same as prior period, unchanged from 0001137789-22-000123:notes:40]

[0001137789-23-000010:notes:41]
| (Dollars in millions) |  | December 30,2022 |  | July 1,2022 |
| Dividends payable |  | $ | 145 |  |  | $ | 147 |  |
| Other accrued expenses |  | 684 |  |  | 449 |  |
| Total |  | $ | 829 |  |  | $ | 596 |  |

[0001137789-23-000010:notes:42]
[same as prior period, unchanged from 0001137789-22-000123:notes:42]

[0001137789-23-000010:notes:43]
[same as prior period, unchanged from 0001137789-22-000123:notes:43]

[0001137789-23-000010:notes:44]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  |  |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at July 1, 2022 |  | $ | 51 |  |  |  |  | $ | (14) |  |  | $ | (1) |  |  | $ | 36 |  |
| Other comprehensive income before reclassifications |  | 51 |  |  |  |  | — |  |  | — |  |  | 51 |  |
| Amounts reclassified from AOCI |  | 11 |  |  |  |  | 1 |  |  | — |  |  | 12 |  |
| Other comprehensive income |  | 62 |  |  |  |  | 1 |  |  | — |  |  | 63 |  |
| Balance at December 30, 2022 |  | $ | 113 |  |  |  |  | $ | (13) |  |  | $ | (1) |  |  | $ | 99 |  |
| Balance at July 2, 2021 |  | $ | (18) |  |  |  |  | $ | (22) |  |  | $ | (1) |  |  | $ | (41) |  |
| Other comprehensive income before reclassifications |  | 2 |  |  |  |  | 1 |  |  | — |  |  | 3 |  |
| Amounts reclassified from AOCI |  | 12 |  |  |  |  | 1 |  |  | — |  |  | 13 |  |
| Other comprehensive income |  | 14 |  |  |  |  | 2 |  |  | — |  |  | 16 |  |
| Balance at December 31, 2021 |  | $ | (4) |  |  |  |  | $ | (20) |  |  | $ | (1) |  |  | $ | (25) |  |


## us-gaap:DebtDisclosureTextBlock

[0001137789-23-000010:notes:45]
Debt
The following table provides details of the Company’s debt as of December 30, 2022 and July 1, 2022:

[0001137789-23-000010:notes:46]
| (Dollars in millions) |  | December 30,2022 |  | July 1,2022 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | $ | 540 |  |  | $ | 540 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 469 |  |  | 466 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 164 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 295 |  |  | 500 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 77 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | — |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 600 |  |  | 600 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | 600 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | — |  |
|  |  | 6,066 |  |  | 5,677 |  |
| Less: unamortized debt issuance costs |  | (37) |  |  | (31) |  |
| Debt, net of debt issuance costs |  | 6,029 |  |  | 5,646 |  |
| Less: current portion of long-term debt |  | (636) |  |  | (584) |  |
| Long-term debt, less current portion |  | $ | 5,393 |  |  | $ | 5,062 |  |

[0001137789-23-000010:notes:47]
______________________________

[0001137789-23-000010:notes:48]
(1) All unsecured senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX.

[0001137789-23-000010:notes:49]
Debt Exchange

[0001137789-23-000010:notes:50]
2032 Notes. On November 30, 2022, Seagate HDD issued, in a private placement, $750 million in aggregate principal amount of 9.625% Senior Notes due on December 1, 2032, in connection with Seagate HDD’s exchange offers to certain eligible holders of Seagate HDD’s outstanding existing senior notes as set forth below:

[0001137789-23-000010:notes:51]
| (Dollars in millions) |  |  |  |  |  |  |  |  |
| Existing Notes |  | Principal Amount Outstanding as of September 30, 2022 |  | Principal Amount Exchanged |  | Remaining Principal Amount as of December 30, 2022 |  | Net Gain Recognized From Early Redemption |
| July 2031 Notes |  | $ | 500 |  |  | $ | 423 |  |  | $ | 77 |  |  | $ | 95 |  |
| July 2029 Notes |  | 500 |  | 336 |  |  | 164 |  |  | 70 |  |
| January 2031 Notes |  | 500 |  | 205 |  |  | 295 |  |  | 39 |  |
| Total |  | $ | 1,500 |  |  | $ | 964 |  |  | $ | 536 |  |  | $ | 204 |  |

[0001137789-23-000010:notes:52]
The exchange was accounted for as a debt extinguishment and the Company recorded a net gain of $204 million, in the Company’s Condensed Consolidated Statements of Operations.

[0001137789-23-000010:notes:53]
At any time prior to December 1, 2027, Seagate HDD may redeem the 2032 Notes at its option, in whole or in part, at any time and from time to time, at a “make-whole” redemption price. The “make-whole” redemption price will be equal to the greater of: (1) (a) the sum of the present values at such redemption date of the redemption price of the 2032 Notes that would apply if the new 2032 Notes were redeemed on December 1, 2027 plus the remaining scheduled payments of interest thereon to and including December 1, 2027 discounted to the redemption date on a semi-annual basis at the Treasury Rate plus 50 basis points less (b) interest accrued to the date of redemption, and (2) 100% of the principal amount of the 2032 Notes to be redeemed plus, in either case, accrued and unpaid interest thereon, if any, to, but excluding, the redemption date. At any time on or after December 1, 2027, Seagate HDD may redeem some or all of the 2032 Notes at the prices specified in the Indenture, plus accrued and unpaid interest to, but excluding, the redemption date. In addition, Seagate HDD may redeem with the net cash proceeds from one or more equity offerings up to 40% of the 2032 Notes before December 1, 2025, at a redemption price of 109.625% plus accrued and unpaid interest to, but excluding, the redemption date.

[0001137789-23-000010:notes:54]
Credit Agreement

[0001137789-23-000010:notes:55]
On August 18, 2022, Seagate Technology Holdings plc and Seagate HDD (the “Borrower”) entered into an amendment to its Credit Agreement (the “Sixth Amendment”), which provided for a new term loan facility in the aggregate principal amount of $600 million (“Term Loan A3”). Term Loan A3 was borrowed in full at the closing of the Sixth Amendment. The Sixth Amendment to the Credit Agreement also replaced the LIBOR interest rates plus variable margin for the Term Loans A1 and A2 with the SOFR interest rates plus a variable margin that will be determined based on the corporate credit rating of the Borrower or one of its parent entities. The Sixth Amendment also permits the Borrower to increase the revolving loan commitments or obtain new term loans of up to $100 million in aggregate (the “Incremental facility”), subject to the satisfaction of certain terms and conditions.

[0001137789-23-000010:notes:56]
On November 8, 2022, Seagate Technology Holdings plc and the Borrower entered into an amendment to its Credit Agreement (the “Seventh Amendment”), to increase the maximum permitted total leverage ratio the Company must comply with during the covenant relief period that ends on June 28, 2024 and prohibit the Company from pursuing the use of the Incremental Facility during the covenant relief period. The maximum permitted total leverage ratio is 5.0 to 1.0 from the fiscal quarters ending December 30, 2022 to June 30, 2023. For the fiscal quarter ending September 29, 2023, the maximum permitted total leverage ratio is 4.75 to 1.0 and then steps down to 4.5 to 1.0 from the fiscal quarters ending December 29, 2023 to June 28, 2024. The maximum permitted leverage ratio will return to 4.0 to 1.0 for any fiscal quarter ending after June 28, 2024.

[0001137789-23-000010:notes:57]
The Credit Agreement provides a term loan facility in an aggregate principal amount of $1.8 billion that is extended in three tranches of $600 million each for Term Loans A1, A2 and A3, and a $1.75 billion senior unsecured revolving credit facility (“Revolving Credit Facility”). As of December 30, 2022, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. STX and certain of its material subsidiaries, including STUC, fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loans A1, A2 and A3 (the “Term Loans”). The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of December 30, 2022.

[0001137789-23-000010:notes:58]
Future Principal Payments on Long-term Debt

[0001137789-23-000010:notes:59]
At December 30, 2022, future principal payments on long-term debt were as follows (in millions):

[0001137789-23-000010:notes:60]
| Fiscal Year |  | Amount |
| Remainder of 2023 |  | $ | 608 |  |
| 2024 |  | 586 |  |
| 2025 |  | 617 |  |
| 2026 |  | 667 |  |
| 2027 |  | 649 |  |
| Thereafter |  | 2,973 |  |
| Total |  | $ | 6,100 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001137789-23-000010:notes:61]
Income Taxes
The Company recorded income tax benefits of $5 million and $7 million for the three and six months ended December 30, 2022, respectively. The discrete items in the income tax provision were not material for the three months ended December 30, 2022. The income tax benefit for the six months ended December 30, 2022 included approximately $5 million of net discrete tax benefit, primarily associated with the excess tax benefits related to share-based compensation expense.

[0001137789-23-000010:notes:62]
During the six months ended December 30, 2022, the Company’s unrecognized tax benefits excluding interest and penalties decreased by approximately $4 million to $110 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. The Company is not expecting material changes to its unrecognized tax benefits in the next twelve months beginning December 31, 2022.

[0001137789-23-000010:notes:63]
The Company recorded income tax provisions of $13 million and $20 million for the three and six months ended December 31, 2021, respectively. The discrete items in the income tax provision were not material for the three months ended December 31, 2021. The income tax provision for the six months ended December 31, 2021 included approximately $9 million of net discrete tax benefit, primarily associated with net excess tax benefits related to share-based compensation expense.

[0001137789-23-000010:notes:64]
The Company’s income tax provision recorded for the three and six months ended December 30, 2022 and the three and six months ended December 31, 2021 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001137789-23-000010:notes:65]
Restructuring and Exit Costs
 The Company recorded restructuring charges of $81 million and $90 million, for the three and six months ended December 30, 2022, respectively. For the three and six months ended December 31, 2021, the Company recorded restructuring charges of $1 million and $2 million, respectively. The Company’s restructuring plans are comprised primarily of charges related to workforce reduction costs, including severance and other one-time termination benefits, and facilities and other exit costs. All restructuring charges are reported in Restructuring and other, net on the Company’s Condensed Consolidated Statements of Operations.

[0001137789-23-000010:notes:66]
October 2022 Plan - On October 24, 2022, the Company’s Board of Directors approved and committed to an October 2022 restructuring plan (the “October 2022 Plan”) to reduce its cost structure to better align the Company’s operational needs to current economic conditions while continuing to support the long-term business strategy. The October 2022 Plan includes reducing its worldwide headcount by approximately 3,000 employees, or 8% of the global workforce, along with other cost saving measures.

[0001137789-23-000010:notes:67]
[same as prior period, unchanged from 0001137789-22-000123:notes:64]

[0001137789-23-000010:notes:68]
|  |  | October 2022 Plan |  | Other Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at July 1, 2022 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5 |  |  | $ | 5 |  |
| Restructuring charges |  | 77 |  |  | 3 |  |  | 10 |  |  | — |  |  | 90 |  |
| Cash payments |  | (29) |  |  | — |  |  | (8) |  |  | (1) |  |  | (38) |  |
| Accrual balances at December 30, 2022 |  | $ | 48 |  |  | $ | 3 |  |  | $ | 2 |  |  | $ | 4 |  |  | $ | 57 |  |
| Total costs incurred inception to date as of December 30, 2022 |  | $ | 77 |  |  | $ | 3 |  |  | $ | 73 |  |  | $ | 24 |  |  | $ | 177 |  |
| Total expected charges to be incurred as of December 30, 2022 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001137789-23-000010:notes:69]
Derivative Financial Instruments
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies.

[0001137789-23-000010:notes:70]
The Company enters into certain interest rate swap agreements to convert the variable interest rate on its Term Loans to fixed interest rates. The objective of the interest rate swap agreements is to eliminate the variability of interest payment cash flows associated with the variable interest rate under the Term Loans. The Company designates the interest rate swaps as cash flow hedges. On September 26, 2022, the Company terminated its then existing interest rate swap agreements relating to Term Loans A1 and A2 and received cash proceeds of $110 million from the counterparty. The cash proceeds are reported within Net cash provided by operating activities in the Company’s Condensed Consolidated Statement of Cash Flows. The Company discontinued the related hedge accounting prospectively and as a result the realized gain of $110 million was accounted and reported in AOCI and is amortized to Interest expense in the Condensed Consolidated Statement of Operations over the remaining period of the Term Loans A1 and A2. During the three and six months ended December 30, 2022, $7 million of the gains were amortized to interest expense in the Company’s Condensed Consolidated Statement of Operations.

[0001137789-23-000010:notes:71]
On September 26, 2022, the Company entered into new interest swap agreements with a notional amount of $1.6 billion, to convert the variable interest rate on certain principal amounts of the Term Loans drawn under its Credit Agreement. As of December 30, 2022, the aggregate notional amount of the Company’s interest-rate swap contracts was $1.6 billion, of which $600 million will mature in September 2025 and $1.0 billion will mature in July 2027.

[0001137789-23-000010:notes:72]
The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives on its Condensed Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in AOCI until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The amount of net unrealized gain on cash flow hedges was $10 million and $51 million as of December 30, 2022 and as of July 1, 2022, respectively. As of December 30, 2022, the amount of existing net gains related to cash flow hedges recorded in AOCI included a net gain of $39 million that is expected to be reclassified to earnings within twelve months.

[0001137789-23-000010:notes:73]
The Company de-designates its cash flow hedges when the forecasted hedged transactions affect earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in AOCI on the Company’s Condensed Consolidated Balance Sheets are reclassified into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company recognized a net loss of $12 million and a net gain of $6 million in Cost of revenue and Interest expense, respectively, related to the loss of hedge designation on discontinued cash flow hedges during the three months ended December 30, 2022. The Company recognized a net loss of $19 million and a net gain of $8 million in Cost of revenue and Interest expense, respectively, related to the loss of hedge designation on discontinued cash flow hedges during the six months ended December 30, 2022. The Company recognized a net loss of $6 million and $3 million in Cost of revenue and Interest expense, respectively, related to the loss of hedge designation on discontinued cash flow hedges during the three months ended December 31, 2021. The Company recognized a net loss of $8 million and $4 million in Cost of revenue and Interest expense, net related to the loss of hedge designation on discontinued cash flow hedges during the six months ended December 31, 2021, respectively.

[0001137789-23-000010:notes:74]
[same as prior period, unchanged from 0001137789-22-000123:notes:72]

[0001137789-23-000010:notes:75]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of December 30, 2022 and July 1, 2022. All of the foreign currency forward exchange contracts mature within 12 months.

[0001137789-23-000010:notes:76]
|  |  | As of December 30, 2022 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Singapore Dollar |  | $ | 173 |  |  | $ | 45 |  |
| Thai Baht |  | 127 |  |  | 23 |  |
| Chinese Renminbi |  | 78 |  |  | 15 |  |
| British Pound Sterling |  | 64 |  |  | 17 |  |
| Total |  | $ | 442 |  |  | $ | 100 |  |

[0001137789-23-000010:notes:77]
[same as prior period, unchanged from 0001137789-22-000123:notes:75]

[0001137789-23-000010:notes:78]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its non-qualified deferred compensation plan: the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP’s liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP’s liabilities due to changes in the value of the investment options made by employees. As of December 30, 2022, the notional investments underlying the TRS amounted to $102 million and the contract term is through January 2023, settled on a monthly basis, limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP’s liabilities.

[0001137789-23-000010:notes:79]
The following tables show the Company’s derivative instruments measured at gross fair value as reflected in the Condensed Consolidated Balance Sheets as of December 30, 2022 and July 1, 2022:

[0001137789-23-000010:notes:80]
|  |  | As of December 30, 2022 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance Sheet Location |  | Fair Value |  | Balance Sheet Location |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 5 |  |  | Accrued expenses |  | $ | (2) |  |
| Interest rate swap |  | Other current assets |  | 9 |  |  | Accrued expenses |  | (2) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 1 |  |  | Accrued expenses |  | (1) |  |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 15 |  |  |  |  | $ | (5) |  |

[0001137789-23-000010:notes:81]
[same as prior period, unchanged from 0001137789-22-000123:notes:79]

[0001137789-23-000010:notes:82]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three and six months ended December 30, 2022:

[0001137789-23-000010:notes:83]
|  |  |  |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | For the Three Months |  | For the Six Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 4 |  |  | $ | (6) |  |
| Total return swap |  | Operating expenses |  | — |  |  | (8) |  |

[0001137789-23-000010:notes:84]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
|  | For the Three Months |  | For the Six Months |  |  | For the Three Months |  | For the Six Months |  |  | For the Three Months |  | For the Six Months |
| Foreign currency forward exchange contracts |  | $ | 19 |  |  | $ | (1) |  |  | Cost of revenue |  | $ | (12) |  |  | $ | (19) |  |  | Other, net |  | $ | — |  |  | $ | (1) |  |
| Interest rate swap |  | — |  |  | 52 |  |  | Interest expense |  | 6 |  |  | 8 |  |  | Interest expense |  | — |  |  | — |  |

[0001137789-23-000010:notes:85]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statements of Comprehensive Income and the Condensed Consolidated Statements of Operations for the three and six months ended December 31, 2021:

[0001137789-23-000010:notes:86]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |
|  |  | For the Three Months |  | For the Six Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 2 |  |  | $ | (2) |  |
| Total return swap |  | Operating expenses |  | 7 |  |  | 6 |  |

[0001137789-23-000010:notes:87]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
|  | For the Three Months |  | For the Six Months |  |  | For the Three Months |  | For the Six Months |  |  | For the Three Months |  | For the Six Months |
| Foreign currency forward exchange contracts |  | $ | 4 |  |  | $ | (5) |  |  | Cost of revenue |  | $ | (6) |  |  | $ | (8) |  |  | Other, net |  | $ | — |  |  | $ | 1 |  |
| Interest rate swap |  | 7 |  |  | 7 |  |  | Interest expense |  | (3) |  |  | (4) |  |  | Interest expense |  | — |  |  | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001137789-23-000010:notes:88]
[same as prior period, unchanged from 0001137789-22-000123:notes:86]

[0001137789-23-000010:notes:89]
[same as prior period, unchanged from 0001137789-22-000123:notes:87]

[0001137789-23-000010:notes:90]
[same as prior period, unchanged from 0001137789-22-000123:notes:88]

[0001137789-23-000010:notes:91]
[same as prior period, unchanged from 0001137789-22-000123:notes:89]

[0001137789-23-000010:notes:92]
Level 1 — Quoted prices in active markets that are unadjusted and accessible at the measurement date for identical, unrestricted assets or liabilities;

[0001137789-23-000010:notes:93]
Level 2 — Quoted prices for identical assets and liabilities in markets that are inactive; quoted prices for similar assets and liabilities in active markets or financial instruments for which significant inputs are observable, either directly or indirectly; or

[0001137789-23-000010:notes:94]
Level 3 — Prices or valuations that require inputs that are both unobservable and significant to the fair value measurement.

[0001137789-23-000010:notes:95]
[same as prior period, unchanged from 0001137789-22-000123:notes:93]

[0001137789-23-000010:notes:96]
[same as prior period, unchanged from 0001137789-22-000123:notes:94]

[0001137789-23-000010:notes:97]
[same as prior period, unchanged from 0001137789-22-000123:notes:95]

[0001137789-23-000010:notes:98]
|  |  | December 30, 2022 |  | July 1, 2022 |
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 172 |  |  | $ | — |  |  | $ | — |  |  | $ | 172 |  |  | $ | 59 |  |  | $ | — |  |  | $ | — |  |  | $ | 59 |  |
| Total cash equivalents |  | 172 |  |  | — |  |  | — |  |  | 172 |  |  | 59 |  |  | — |  |  | — |  |  | 59 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | — |  |  | — |  |  | 16 |  |  | 16 |  |  | — |  |  | — |  |  | 23 |  |  | 23 |  |
| Derivative assets |  | — |  |  | 15 |  |  | — |  |  | 15 |  |  | — |  |  | 65 |  |  | — |  |  | 65 |  |
| Total assets |  | $ | 173 |  |  | $ | 16 |  |  | $ | 16 |  |  | $ | 205 |  |  | $ | 60 |  |  | $ | 66 |  |  | $ | 23 |  |  | $ | 149 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |
| Total liabilities |  | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |

[0001137789-23-000010:notes:99]
|  |  | December 30, 2022 |  | July 1, 2022 |
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |  | Quoted Prices in Active Markets for Identical Instruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Total Balance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 172 |  |  | $ | — |  |  | $ | — |  |  | $ | 172 |  |  | $ | 59 |  |  | $ | — |  |  | $ | — |  |  | $ | 59 |  |
| Other current assets |  | 1 |  |  | 16 |  |  | — |  |  | 17 |  |  | 1 |  |  | 66 |  |  | — |  |  | 67 |  |
| Other assets, net |  | — |  |  | — |  |  | 16 |  |  | 16 |  |  | — |  |  | — |  |  | 23 |  |  | 23 |  |
| Total assets |  | $ | 173 |  |  | $ | 16 |  |  | $ | 16 |  |  | $ | 205 |  |  | $ | 60 |  |  | $ | 66 |  |  | $ | 23 |  |  | $ | 149 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |
| Total liabilities |  | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |

[0001137789-23-000010:notes:100]
[same as prior period, unchanged from 0001137789-22-000123:notes:98]

[0001137789-23-000010:notes:101]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair value of all of its cash equivalents. For the cash equivalents in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry-standard data providers or other third-party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of December 30, 2022, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts, interest rate swaps and the TRS. The Company recognizes derivative financial instruments in its condensed consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001137789-23-000010:notes:102]
[same as prior period, unchanged from 0001137789-22-000123:notes:100]

[0001137789-23-000010:notes:103]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives, which are accounted for either under the equity method or the measurement alternative. Investments under the measurement alternative are recorded at cost, less impairment and adjusted for qualifying observable price changes on a prospective basis. If measured at fair value in the Condensed Consolidated Balance Sheets, these investments would generally be classified in Level 3 of the fair value hierarchy.

[0001137789-23-000010:notes:104]
For the investments that are accounted for under the equity method, the Company recorded an immaterial gain and a net loss of $3 million for the three and six months ended December 30, 2022, respectively. The Company recorded an immaterial gain and a net gain of $3 million for the three and six months ended December 31, 2021, respectively. The adjusted carrying value of the investments accounted for under the equity method amounted to $57 million and $61 million as of December 30, 2022 and July 1, 2022, respectively.

[0001137789-23-000010:notes:105]
For the investments that are accounted for under the measurement alternative, the Company recorded an immaterial loss and a net gain of $3 million for the three and six months ended December 30, 2022, respectively, related to downward and upward adjustments due to observable price changes. The Company recorded a net loss of $2 million and a net gain of $4 million for the three and six months ended December 31, 2021, respectively, related to downward and upward adjustments due to observable price changes. As of December 30, 2022 and July 1, 2022, the carrying value of the Company’s strategic investments under the measurement alternative was $99 million and $88 million, respectively.

[0001137789-23-000010:notes:106]
[same as prior period, unchanged from 0001137789-22-000123:notes:104]

[0001137789-23-000010:notes:107]
[same as prior period, unchanged from 0001137789-22-000123:notes:105]

[0001137789-23-000010:notes:108]
|  |  | December 30, 2022 |  | July 1, 2022 |
| (Dollars in millions) |  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 4.750% Senior Notes due June 2023 |  | $ | 540 |  |  | $ | 538 |  |  | $ | 540 |  |  | $ | 538 |  |
| 4.875% Senior Notes due March 2024 |  | 499 |  |  | 493 |  |  | 499 |  |  | 494 |  |
| 4.750% Senior Notes due January 2025 |  | 479 |  |  | 469 |  |  | 479 |  |  | 471 |  |
| 4.875% Senior Notes due June 2027 |  | 504 |  |  | 473 |  |  | 504 |  |  | 483 |  |
| 4.091% Senior Notes due June 2029 |  | 469 |  |  | 417 |  |  | 466 |  |  | 427 |  |
| 3.125% Senior Notes due July 2029 |  | 164 |  |  | 127 |  |  | 500 |  |  | 396 |  |
| 4.125% Senior Notes due January 2031 |  | 295 |  |  | 233 |  |  | 500 |  |  | 410 |  |
| 3.375% Senior Notes due July 2031 |  | 77 |  |  | 59 |  |  | 500 |  |  | 393 |  |
| 9.625% Senior Notes due December 2032 |  | 750 |  |  | 825 |  |  | — |  |  | — |  |
| 5.750% Senior Notes due December 2034 |  | 489 |  |  | 423 |  |  | 489 |  |  | 433 |  |
| SOFR Based Term Loan A1 due September 2025 (1) |  | 600 |  |  | 584 |  |  | 600 |  |  | 588 |  |
| SOFR Based Term Loan A2 due July 2027 (1) |  | 600 |  |  | 566 |  |  | 600 |  |  | 586 |  |
| SOFR Based Term Loan A3 due July 2027 |  | 600 |  |  | 562 |  |  | — |  |  | — |  |
|  |  | $ | 6,066 |  |  | $ | 5,769 |  |  | $ | 5,677 |  |  | $ | 5,219 |  |
| Less: unamortized debt issuance costs |  | (37) |  |  | — |  |  | (31) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 6,029 |  |  | $ | 5,769 |  |  | $ | 5,646 |  |  | $ | 5,219 |  |
| Less: current portion of debt, net of debt issuance costs |  | (636) |  |  | (629) |  |  | (584) |  |  | (582) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,393 |  |  | $ | 5,140 |  |  | $ | 5,062 |  |  | $ | 4,637 |  |

[0001137789-23-000010:notes:109]
[same as prior period, unchanged from 0001137789-22-000123:notes:107]

[0001137789-23-000010:notes:110]
(1) On August 18, 2022, the Company amended the Credit Agreement and replaced the LIBOR interest rates plus variable margin of Term Loans A1 and A2 with the SOFR interest rates plus a variable margin. Refer to “Note 3. Debt” for more details.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001137789-23-000010:notes:111]
it
Share Capital

[0001137789-23-000010:notes:112]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 206,477,388 shares were outstanding as of December 30, 2022, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of December 30, 2022.

[0001137789-23-000010:notes:113]
[same as prior period, unchanged from 0001137789-22-000123:notes:111]

[0001137789-23-000010:notes:114]
[same as prior period, unchanged from 0001137789-22-000123:notes:112]

[0001137789-23-000010:notes:115]
[same as prior period, unchanged from 0001137789-22-000123:notes:113]

[0001137789-23-000010:notes:116]
[same as prior period, unchanged from 0001137789-22-000123:notes:114]

[0001137789-23-000010:notes:117]
[same as prior period, unchanged from 0001137789-22-000123:notes:115]

[0001137789-23-000010:notes:118]
As of December 30, 2022, $1.9 billion remained available for repurchase under the existing repurchase authorization limit. The following table sets forth information with respect to repurchases of the Company’s ordinary shares during the six months ended December 30, 2022:

[0001137789-23-000010:notes:119]
[same as prior period, unchanged from 0001137789-22-000123:notes:118]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001137789-23-000010:notes:120]
[same as prior period, unchanged from 0001137789-22-000123:notes:120]

[0001137789-23-000010:notes:121]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,365 |  |  | $ | 2,178 |  |  | $ | 2,910 |  |  | $ | 4,465 |  |
| Distributors |  | 297 |  |  | 562 |  |  | 596 |  |  | 1,069 |  |
| Retailers |  | 225 |  |  | 376 |  |  | 416 |  |  | 697 |  |
| Total |  | $ | 1,887 |  |  | $ | 3,116 |  |  | $ | 3,922 |  |  | $ | 6,231 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 760 |  |  | $ | 1,433 |  |  | $ | 1,561 |  |  | $ | 3,016 |  |
| Americas |  | 853 |  |  | 1,186 |  |  | 1,789 |  |  | 2,265 |  |
| EMEA |  | 274 |  |  | 497 |  |  | 572 |  |  | 950 |  |
| Total |  | $ | 1,887 |  |  | $ | 3,116 |  |  | $ | 3,922 |  |  | $ | 6,231 |  |

[0001137789-23-000010:notes:122]
[same as prior period, unchanged from 0001137789-22-000123:notes:122]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001137789-23-000010:notes:123]
Indemnification Obligations

[0001137789-23-000010:notes:124]
[same as prior period, unchanged from 0001137789-22-000123:notes:124]

[0001137789-23-000010:notes:125]
[same as prior period, unchanged from 0001137789-22-000123:notes:125]

[0001137789-23-000010:notes:126]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product warranty return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the six months ended December 30, 2022 and December 31, 2021 were as follows:

[0001137789-23-000010:notes:127]
|  |  | For the Six Months Ended |  |
| (Dollars in millions) |  | December 30,2022 |  | December 31,2021 |  |
| Balance, beginning of period |  | $ | 148 |  |  | $ | 136 |  |  |
| Warranties issued |  | 27 |  |  | 43 |  |  |
| Repairs and replacements |  | (48) |  |  | (43) |  |  |
| Changes in liability for pre-existing warranties, including expirations |  | 26 |  |  | 8 |  |  |
| Balance, end of period |  | $ | 153 |  |  | $ | 144 |  |  |


## us-gaap:EarningsPerShareTextBlock

[0001137789-23-000010:notes:128]
Basic (loss) earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period. Diluted earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period and the number of additional shares that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding options, unvested restricted share units and performance-based share units and shares to be purchased under the Employee Stock Purchase Plan. The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in fair market value of the Company’s share price can result in a greater dilutive effect from potentially dilutive securities. The following table sets forth the computation of basic and diluted net (loss) income per share attributable to the shareholders of the Company:

[0001137789-23-000010:notes:129]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (In millions, except per share data) |  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net (loss) income |  | $ | (33) |  |  | $ | 501 |  |  | $ | (4) |  |  | $ | 1,027 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net (loss) income per share |  | 206 |  |  | 221 |  |  | 207 |  |  | 224 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Total shares for purposes of calculating diluted net (loss) income per share |  | 206 |  |  | 225 |  |  | 207 |  |  | 228 |  |
| Net (loss) income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.16) |  |  | $ | 2.27 |  |  | $ | (0.02) |  |  | $ | 4.58 |  |
| Diluted |  | $ | (0.16) |  |  | $ | 2.23 |  |  | $ | (0.02) |  |  | $ | 4.50 |  |

[0001137789-23-000010:notes:130]
For the three and six months ended December 30, 2022, the Company recorded a net loss, and as such, all potentially dilutive securities related to the employee equity award plans have been excluded for those periods as including them would be anti-dilutive. The anti-dilutive shares that were excluded from the computation of diluted net (loss) income per share were 2 million for both the three and six months ended December 30, 2022, respectively, and were not material for the three and six months ended December 31, 2021.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001137789-23-000010:notes:131]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001137789-23-000010:notes:132]
Litigation

[0001137789-23-000010:notes:133]
Lambeth Magnetic Structures LLC, v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgement in favor of Seagate on April 19, 2022. The parties filed post-trial motions with the district court in May 2022. On November 22, 2022, the court denied all pending post-trial motions. Lambeth Magnetic Structures LLC filed a notice of appeal to the Federal Circuit on December 20, 2022. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

[0001137789-23-000010:notes:134]
Seagate Technology LLC, et al. v. Headway Technologies, Inc, et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the United States District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendants misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, as well as additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 1, 2022, the Seagate Entities and TDK filed a Stipulation for Dismissal with Prejudice to dismiss with prejudice all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment Regarding Foreign Commerce and on October 14, 2022, Seagate Entities’ filed its corresponding opposition. A trial date has not been set.

[0001137789-23-000010:notes:135]
Environmental Matters

[0001137789-23-000010:notes:136]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001137789-23-000010:notes:137]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001137789-23-000010:notes:138]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001137789-23-000010:notes:139]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001137789-23-000010:notes:140]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the U.S., Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001137789-23-000010:notes:141]
Other Matters

[0001137789-23-000010:notes:142]
On August 29, 2022, the Company received a proposed charging letter (“PCL”) from the U.S. Commerce Department’s Bureau of Industry and Security (“BIS”), alleging violations of the U.S. Export Administration Regulations (“EAR”). The PCL alleges the Company acted in violation of the EAR by providing its HDDs to a customer and its affiliates listed on the BIS Entity List between August 2020 and September 2021. The Company believes these allegations are without merit. The Company has responded to the PCL, setting forth its position that it did not engage in prohibited conduct as alleged by BIS, because, among other reasons, Seagate’s HDDs are not subject to the EAR.

[0001137789-23-000010:notes:143]
The matters raised by the PCL remain unresolved at this time, and there can be no assurance as to the timing or terms of any final outcome. The Company is unable at this time to estimate the range of loss and/or penalty, if any, although it is possible that the outcome could have a material impact on its business, results of operations, financial condition, and cash flows. The Company has committed to compliance through its global team of international trade compliance and legal professionals and by maintaining robust trade controls, compliance policies and procedures. The Company has been cooperating with BIS and engaging in discussions with BIS to seek a resolution of this matter. If the Company is not able to reach a resolution, the Company believes that this matter will result in litigation between the Company and BIS. The Company believes that it has complied with all relevant export control laws and regulations and will defend itself vigorously.

[0001137789-23-000010:notes:144]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:CommitmentsDisclosureTextBlock

[0001137789-23-000010:notes:145]
Unconditional Long-Term Purchase Obligations. As of December 30, 2022, the Company had unconditional long-term purchase obligations of approximately $3.1 billion, primarily related to purchases of inventory components. The Company expects the commitment to total $677 million, $595 million, $666 million, $745 million and $393 million for fiscal years 2024, 2025, 2026, 2027 and thereafter, respectively.

[0001137789-23-000010:notes:146]
During the three months ended December 30, 2022, the Company recorded order cancellation fees of $108 million to terminate certain purchase commitments related to purchase of inventory components and equipment. The Company expects these amounts to be paid within one year.


## us-gaap:SubsequentEventsTextBlock

[0001137789-23-000010:notes:147]
Dividend Declared

[0001137789-23-000010:notes:148]
On January 25, 2023, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on April 6, 2023 to shareholders of record as of the close of business on March 22, 2023.
