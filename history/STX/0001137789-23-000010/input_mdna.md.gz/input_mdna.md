# STX MD&A — 0001137789-23-000010


## mdna

[0001137789-23-000010:mdna:1]
[same as prior period, unchanged from 0001137789-22-000123:mdna:1]

[0001137789-23-000010:mdna:2]
The following is a discussion of the financial condition, changes in financial condition and results of operations for our fiscal quarters ended December 30, 2022, September 30, 2022 and December 31, 2021, referred to herein as the “December 2022 quarter,” the “September 2022 quarter,” and the “December 2021 quarter,” respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The December 2022 quarter, the September 2022 quarter and the December 2021 quarter were each 13 weeks.

[0001137789-23-000010:mdna:3]
[same as prior period, unchanged from 0001137789-22-000123:mdna:3]

[0001137789-23-000010:mdna:4]
[same as prior period, unchanged from 0001137789-22-000123:mdna:19]

[0001137789-23-000010:mdna:5]
•Overview of the December 2022 quarter. Highlights of events in the December 2022 quarter that impacted our financial position.

[0001137789-23-000010:mdna:6]
•Results of Operations. Analysis of our financial results comparing the December 2022 quarter to the September 2022 quarter and the December 2021 quarter.

[0001137789-23-000010:mdna:7]
•Liquidity and Capital Resources. An analysis of changes in our balance sheet and cash flows, and discussion of our financial condition including potential sources of liquidity.

[0001137789-23-000010:mdna:8]
•Critical Accounting Policies. Accounting policies and estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001137789-23-000010:mdna:9]
[same as prior period, unchanged from 0001137789-22-000123:mdna:24]

[0001137789-23-000010:mdna:10]
Overview of the December 2022 quarter

[0001137789-23-000010:mdna:11]
During the December 2022 quarter, we shipped 113 exabytes of HDD storage capacity. We generated revenue of approximately $1.9 billion with a gross margin of 13%. Our operating cash flow was $251 million and we paid $145 million in dividends. We exchanged $964 million of certain senior notes with $750 million of new senior notes and recorded a net gain of $204 million as the result of debt extinguishment.

[0001137789-23-000010:mdna:12]
[same as prior period, unchanged from 0001137789-22-000123:mdna:30]

[0001137789-23-000010:mdna:13]
[same as prior period, unchanged from 0001137789-22-000123:mdna:27]

[0001137789-23-000010:mdna:14]
During the December 2022 quarter, the data storage industry and our business continued to be impacted by macroeconomic headwinds. We continued to experience broad-based delay in customers’ purchase plans, particularly in the mass capacity market, given overall macroeconomic slowdowns. The ongoing economic slowdown in China due to the pandemic-related governmental lockdown measures, as well as the negative impact from the higher inflationary pressures in the consumer markets continued to impact our business during the December 2022 quarter. Additionally, our customers continued to experience demand disruptions, resulting in demand variations across certain of our end markets. These reductions in demand have required us to reduce manufacturing production plans, incur order cancellation fees to terminate certain purchase commitments that were made with our suppliers, recognize manufacturing underutilization charges and accelerate depreciation of certain capital equipment that would not be utilized as part of our operations. We expect these factors will continue to impact our business and results of operations over the near-term.

[0001137789-23-000010:mdna:15]
Additionally, during the December 2022 quarter, our Board of Directors approved and committed to the October 2022 Plan to reduce our cost structure to better align our operational needs to current economic conditions while continuing to support the long-term business strategy. The October 2022 Plan included reducing our worldwide headcount by approximately 3,000 employees, or 8% of the global workforce, along with other cost saving measures.

[0001137789-23-000010:mdna:16]
We continue to actively monitor the effects and potential impacts of the macroeconomic conditions, pandemic and other factors on all aspects of our business, supply chain, liquidity and capital resources. We are also actively working on opportunities to lower our cost structure, drive further operational efficiencies and maintain supply chain discipline including adjusting our manufacturing production plans, annual capital expenditure plans and other meaningful cost savings measures in response to these business conditions. For a further discussion of the uncertainties and business risks associated with the COVID-19 pandemic, see the section entitled “Risk Factors” in Part II, Item 1A of our Quarterly Report on Form 10-Q for the fiscal quarter ended September 30, 2022.

[0001137789-23-000010:mdna:17]
[same as prior period, unchanged from 0001137789-22-000123:mdna:35]

[0001137789-23-000010:mdna:18]
[same as prior period, unchanged from 0001137789-22-000123:mdna:31]

[0001137789-23-000010:mdna:19]
[same as prior period, unchanged from 0001137789-22-000123:mdna:32]

[0001137789-23-000010:mdna:20]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 30,2022 |  | September 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
| Revenue |  | $ | 1,887 |  |  | $ | 2,035 |  |  | $ | 3,116 |  |  | $ | 3,922 |  |  | $ | 6,231 |  |
| Cost of revenue |  | 1,641 |  |  | 1,553 |  |  | 2,168 |  |  | 3,194 |  |  | 4,327 |  |
| Gross profit |  | 246 |  |  | 482 |  |  | 948 |  |  | 728 |  |  | 1,904 |  |
| Product development |  | 200 |  |  | 234 |  |  | 228 |  |  | 434 |  |  | 461 |  |
| Marketing and administrative |  | 125 |  |  | 129 |  |  | 136 |  |  | 254 |  |  | 269 |  |
| Amortization of intangibles |  | — |  |  | 3 |  |  | 3 |  |  | 3 |  |  | 6 |  |
| Restructuring and other, net |  | 81 |  |  | 9 |  |  | 1 |  |  | 90 |  |  | 2 |  |
| (Loss) income from operations |  | (160) |  |  | 107 |  |  | 580 |  |  | (53) |  |  | 1,166 |  |
| Other income (expense), net |  | 122 |  |  | (80) |  |  | (66) |  |  | 42 |  |  | (119) |  |
| (Loss) income before income taxes |  | (38) |  |  | 27 |  |  | 514 |  |  | (11) |  |  | 1,047 |  |
| (Benefit from) provision for income taxes |  | (5) |  |  | (2) |  |  | 13 |  |  | (7) |  |  | 20 |  |
| Net (loss) income |  | $ | (33) |  |  | $ | 29 |  |  | $ | 501 |  |  | $ | (4) |  |  | $ | 1,027 |  |

[0001137789-23-000010:mdna:21]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
|  |  | December 30,2022 |  | September 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 87 |  |  | 76 |  |  | 70 |  |  | 81 |  |  | 69 |  |
| Gross margin |  | 13 |  |  | 24 |  |  | 30 |  |  | 19 |  |  | 31 |  |
| Product development |  | 11 |  |  | 12 |  |  | 7 |  |  | 11 |  |  | 8 |  |
| Marketing and administrative |  | 7 |  |  | 7 |  |  | 4 |  |  | 6 |  |  | 4 |  |
| Amortization of intangibles |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Restructuring and other, net |  | 4 |  |  | — |  |  | — |  |  | 2 |  |  | — |  |
| Operating margin |  | (8) |  |  | 5 |  |  | 19 |  |  | (1) |  |  | 19 |  |
| Other income (expense), net |  | 6 |  |  | (4) |  |  | (3) |  |  | 1 |  |  | (2) |  |
| (Loss) income before income taxes |  | (2) |  |  | 1 |  |  | 16 |  |  | — |  |  | 17 |  |
| (Benefit from) provision for income taxes |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net (loss) income |  | (2) | % |  | 1 | % |  | 16 | % |  | — | % |  | 17 | % |

[0001137789-23-000010:mdna:22]
[same as prior period, unchanged from 0001137789-22-000123:mdna:46]

[0001137789-23-000010:mdna:23]
[same as prior period, unchanged from 0001137789-22-000123:mdna:36]

[0001137789-23-000010:mdna:24]
[same as prior period, unchanged from 0001137789-22-000123:mdna:37]

[0001137789-23-000010:mdna:25]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
|  |  | December 30,2022 |  | September 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 72 | % |  | 76 | % |  | 70 | % |  | 74 | % |  | 72 | % |
| Distributors |  | 16 | % |  | 15 | % |  | 18 | % |  | 15 | % |  | 17 | % |
| Retailers |  | 12 | % |  | 9 | % |  | 12 | % |  | 11 | % |  | 11 | % |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 40 | % |  | 39 | % |  | 46 | % |  | 40 | % |  | 48 | % |
| Americas |  | 45 | % |  | 46 | % |  | 38 | % |  | 46 | % |  | 36 | % |
| EMEA |  | 15 | % |  | 15 | % |  | 16 | % |  | 14 | % |  | 16 | % |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 66 | % |  | 68 | % |  | 66 | % |  | 67 | % |  | 65 | % |
| Legacy |  | 22 | % |  | 19 | % |  | 25 | % |  | 21 | % |  | 26 | % |
| Other |  | 12 | % |  | 13 | % |  | 9 | % |  | 12 | % |  | 9 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |  |  |  |  |  |  |
| Mass capacity |  | 97 |  |  | 104 |  |  | 137 |  |  | 201 |  |  | 269 |  |
| Legacy |  | 16 |  |  | 14 |  |  | 26 |  |  | 30 |  |  | 53 |  |
| Total |  | 113 |  |  | 118 |  |  | 163 |  |  | 231 |  |  | 322 |  |
| HDD Price per Terabyte |  | $ | 15 |  |  | $ | 15 |  |  | $ | 17 |  |  | $ | 15 |  |  | $ | 18 |  |

[0001137789-23-000010:mdna:26]
[same as prior period, unchanged from 0001137789-22-000123:mdna:39]

[0001137789-23-000010:mdna:27]
[same as prior period, unchanged from 0001137789-22-000123:mdna:40]

[0001137789-23-000010:mdna:28]
Revenue in the December 2022 quarter decreased by $148 million from the September 2022 quarter primarily due to the decrease in exabytes shipped as a result of lower market demand in mass capacity markets that were impacted by macroeconomic conditions and pandemic-related headwinds, partially offset by seasonal increase in legacy market exabytes shipped.

[0001137789-23-000010:mdna:29]
Revenue for the three and six months ended December 30, 2022 decreased by $1.2 billion and $2.3 billion from the three and six months ended December 31, 2021, respectively, primarily due to the decrease in exabytes shipped as a result of lower market demand in mass capacity and legacy markets that were impacted by macroeconomic conditions and pandemic-related headwinds. We expect the challenging macroeconomic environment and the pandemic-related impacts will continue to persist into at least the third quarter of fiscal year 2023.

[0001137789-23-000010:mdna:30]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 17% of gross revenue for the December 2022 quarter, 18% for the September 2022 quarter and 14% for the December 2021 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-23-000010:mdna:31]
[same as prior period, unchanged from 0001137789-22-000123:mdna:43]

[0001137789-23-000010:mdna:32]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 30,2022 |  | September 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
| Cost of revenue |  | $ | 1,641 |  |  | $ | 1,553 |  |  | $ | 2,168 |  |  | $ | 3,194 |  |  | $ | 4,327 |  |
| Gross profit |  | 246 |  |  | 482 |  |  | 948 |  |  | 728 |  |  | 1,904 |  |
| Gross margin |  | 13 | % |  | 24 | % |  | 30 | % |  | 19 | % |  | 31 | % |

[0001137789-23-000010:mdna:33]
Gross margin for the December 2022 quarter decreased compared to both the September 2022 quarter and the December 2021 quarter primarily driven by $108 million of order cancellation fees, $79 million of factory underutilization charges associated with lower production levels, price erosion and acceleration of depreciation expense for certain capital equipment.

[0001137789-23-000010:mdna:34]
Gross margin for the six months ended December 30, 2022 decreased compared to the six months ended December 31, 2021 primarily driven by $139 million of factory underutilization charges associated with lower production levels and pandemic-related lockdown in one of our factories, $108 million of order cancellation fees, price erosion and acceleration of depreciation expense for certain capital equipment.

[0001137789-23-000010:mdna:35]
In the December 2022 quarter, total warranty cost was 1.5% of revenue and included an unfavorable change in estimates of prior warranty accruals of 0.7% of revenue primarily due to changes to our estimated future product return rates. Warranty cost related to new shipments was 0.7%, 0.6% and 0.7% of revenue for the December 2022 quarter, September 2022 quarter and December 2021 quarter, respectively.

[0001137789-23-000010:mdna:36]
[same as prior period, unchanged from 0001137789-22-000123:mdna:48]

[0001137789-23-000010:mdna:37]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 30,2022 |  | September 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
| Product development |  | $ | 200 |  |  | $ | 234 |  |  | $ | 228 |  |  | $ | 434 |  |  | $ | 461 |  |
| Marketing and administrative |  | 125 |  |  | 129 |  |  | 136 |  |  | 254 |  |  | 269 |  |
| Amortization of intangibles |  | — |  |  | 3 |  |  | 3 |  |  | 3 |  |  | 6 |  |
| Restructuring and other, net |  | 81 |  |  | 9 |  |  | 1 |  |  | 90 |  |  | 2 |  |
| Operating expenses |  | $ | 406 |  |  | $ | 375 |  |  | $ | 368 |  |  | $ | 781 |  |  | $ | 738 |  |

[0001137789-23-000010:mdna:38]
Product development expense. Product development expenses decreased by $34 million in the December 2022 quarter compared to the September 2022 quarter primarily due to a $22 million decrease in depreciation expense and a $12 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our October 2022 restructuring plan.

[0001137789-23-000010:mdna:39]
Product development expenses decreased by $28 million in the December 2022 quarter compared to the December 2021 quarter primarily due to an $18 million decrease in variable compensation and related benefit expense, a $4 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our October 2022 restructuring plan and a $4 million decrease in materials expense.

[0001137789-23-000010:mdna:40]
Product development expenses decreased by $27 million for the six months ended December 30, 2022 compared to the six months ended December 31, 2021 primarily due to a $40 million decrease in variable compensation and related benefit expense, a $3 million decrease in compensation and other employee benefits from the reduction in headcount as a result of our October 2022 restructuring plan and a $3 million decrease in equipment expense, partially offset by a $23 million increase in depreciation expense.

[0001137789-23-000010:mdna:41]
Marketing and administrative expense. Marketing and administrative expenses decreased by $4 million in the December 2022 quarter compared to the September 2022 quarter primarily due to a $7 million recovery of an accounts receivable previously written-off in prior years and a $4 million decrease in travel expenses, partially offset by a $6 million increase in compensation and other employee benefits as a result of increase in share-based compensation.

[0001137789-23-000010:mdna:42]
Marketing and administrative expenses decreased by $11 million in the December 2022 quarter compared to the December 2021 quarter primarily due to an $11 million decrease in variable compensation and related benefit expense and a $7 million recovery of an accounts receivable previously written-off in prior years, partially offset by a $2 million increase in advertising costs.

[0001137789-23-000010:mdna:43]
Marketing and administrative expenses decreased by $15 million for the six months ended December 30, 2022 compared to the six months ended December 31, 2021 primarily due to a $24 million decrease in variable compensation and related benefit expense and a $7 million recovery of an accounts receivable previously written-off in prior years, partially offset by a $5 million increase in travel expenses as a result of the easing of pandemic-related travel restrictions in the prior quarter, a $4 million increase in advertising costs and a $3 million increase in outside services expense.

[0001137789-23-000010:mdna:44]
Amortization of intangibles. Amortization of intangibles decreased by $3 million in the December 2022 quarter compared to the September 2022 quarter and also for the three and six months ended December 30, 2022 compared to the three and six months ended December 31, 2021, due to certain intangible assets that reached the end of their useful lives.

[0001137789-23-000010:mdna:45]
Restructuring and other, net. Restructuring and other, net for the three and six months ended December 30, 2022 was $81 million and $90 million, respectively, and primarily comprised of cost incurred related to the restructuring plan we committed to on October 24, 2022 to reduce our workforce by approximately 3,000 employees to better align our operational needs to current macroeconomic conditions while continuing to support the long-term business strategy.

[0001137789-23-000010:mdna:46]
Other Income (Expense), Net

[0001137789-23-000010:mdna:47]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 30,2022 |  | September 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
| Other income (expense), net |  | $ | 122 |  |  | $ | (80) |  |  | $ | (66) |  |  | $ | 42 |  |  | $ | (119) |  |

[0001137789-23-000010:mdna:48]
Other income (expense), net. Other income, net increased by $202 million for the December 2022 quarter compared to the September 2022 quarter primarily due to a $204 million net gain recognized from early redemption and extinguishment of $964 million of debt from the July 2029 Notes, January 2031 Notes and July 2031 Notes in exchange with issuance of the new December 2032 Notes of $750 million.

[0001137789-23-000010:mdna:49]
Other income, net increased by $188 million for the December 2022 quarter compared to the December 2021 quarter primarily due to a $204 million net gain recognized from early redemption and extinguishment of $964 million of debt from the July 2029 Notes, January 2031 Notes and July 2031 Notes in exchange with issuance of the new December 2032 Notes of $750 million, partially offset by a $14 million increase in interest expense.

[0001137789-23-000010:mdna:50]
Other income, net increased by $161 million for the six months ended December 30, 2022 compared to the six months ended December 31, 2021 primarily due to a $204 million net gain recognized from early redemption and extinguishment of $964 million of debt from the July 2029 Notes, January 2031 Notes and July 2031 Notes in exchange with issuance of the new December 2032 Notes of $750 million, partially offset by a $26 million increase in interest expense and a $7 million higher non-recurring gain from our strategic investments in the prior comparable period.

[0001137789-23-000010:mdna:51]
[same as prior period, unchanged from 0001137789-22-000123:mdna:60]

[0001137789-23-000010:mdna:52]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 30,2022 |  | September 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
| (Benefit from) provision for income taxes |  | $ | (5) |  |  | $ | (2) |  |  | $ | 13 |  |  | $ | (7) |  |  | $ | 20 |  |

[0001137789-23-000010:mdna:53]
We recorded income tax benefits of $5 million and $7 million for the three and six months ended December 30, 2022, respectively. The discrete items in the income tax provision were not material for the three months ended December 30, 2022. The income tax benefit for the six months ended December 30, 2022 included approximately $5 million of net discrete tax benefit, primarily associated with the excess tax benefits related to share-based compensation expense.

[0001137789-23-000010:mdna:54]
[same as prior period, unchanged from 0001137789-22-000123:mdna:63]

[0001137789-23-000010:mdna:55]
During the six months ended December 30, 2022, our unrecognized tax benefits excluding interest and penalties decreased by approximately $4 million to $110 million, substantially all of which would impact the effective tax rate, if recognized, subject to certain future valuation allowance reversals. We do not expect material changes to our unrecognized tax benefits in the next twelve months beginning December 31, 2022.

[0001137789-23-000010:mdna:56]
We recorded income tax provisions of $13 million and $20 million for the three and six months ended December 31, 2021. The discrete items in the income tax provision were not material for the three months ended December 31, 2021. The income tax provision for the six months ended December 31, 2021 included approximately $9 million of net discrete tax benefit, primarily associated with net excess tax benefits related to share-based compensation expense.

[0001137789-23-000010:mdna:57]
Our income tax provision recorded for the three and six months ended December 30, 2022 and December 31, 2021 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of tax benefits related to (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-23-000010:mdna:58]
[same as prior period, unchanged from 0001137789-22-000123:mdna:67]

[0001137789-23-000010:mdna:59]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash will continue to be sufficient to fund our operations and meet our cash requirements for the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs and capital expenditures, will allow us to manage the ongoing impacts of macroeconomic and pandemic-related headwinds including higher inflationary pressures, inventory adjustments by our customers and the overall market demand disruptions on our business operations for the foreseeable future. However, some challenges to our industry and to our business continue to remain uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to the global economic factors and the pandemic.

[0001137789-23-000010:mdna:60]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of December 30, 2022.

[0001137789-23-000010:mdna:61]
[same as prior period, unchanged from 0001137789-22-000123:mdna:70]

[0001137789-23-000010:mdna:62]
| (Dollars in millions) |  | December 30,2022 |  | July 1,2022 |  | Change |
| Cash and cash equivalents |  | $ | 770 |  |  | $ | 615 |  |  | $ | 155 |  |

[0001137789-23-000010:mdna:63]
Our cash and cash equivalents as of December 30, 2022 increased by $155 million from July 1, 2022 primarily as a result of net proceeds of $600 million from the issuance of long-term debt and net cash of $496 million provided by operating activities partially offset by the repurchases of our ordinary shares of $408 million, dividends paid to our shareholders of $292 million and payments for capital expenditures of $212 million.

[0001137789-23-000010:mdna:64]
[same as prior period, unchanged from 0001137789-22-000123:mdna:73]

[0001137789-23-000010:mdna:65]
Cash provided by operating activities for the six months ended December 30, 2022 was $496 million and includes the effects of net loss adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-23-000010:mdna:66]
•a decrease of $692 million in accounts receivable, primarily due to lower revenue and timing of collections;

[0001137789-23-000010:mdna:67]
•a decrease of $371 million in inventories, primarily due to a decrease in units built to align with the prevailing demand environment;

[0001137789-23-000010:mdna:68]
[same as prior period, unchanged from 0001137789-22-000123:mdna:76]

[0001137789-23-000010:mdna:69]
•a decrease of $919 million in accounts payable, primarily due to a decrease in materials purchased; and

[0001137789-23-000010:mdna:70]
•a decrease of $145 million in accrued employee compensation, primarily due to cash paid to our employees as part of our discretionary spending plans.

[0001137789-23-000010:mdna:71]
[same as prior period, unchanged from 0001137789-22-000123:mdna:80]

[0001137789-23-000010:mdna:72]
Cash used in investing activities for the six months ended December 30, 2022 was $210 million, primarily attributable to payments for the purchase of property, equipment and leasehold improvements.

[0001137789-23-000010:mdna:73]
[same as prior period, unchanged from 0001137789-22-000123:mdna:82]

[0001137789-23-000010:mdna:74]
Net cash used in financing activities of $131 million for the six months ended December 30, 2022 was primarily attributable to the following activities:

[0001137789-23-000010:mdna:75]
•$408 million in payments for repurchases of our ordinary shares; and

[0001137789-23-000010:mdna:76]
•$292 million in dividend payments; partially offset by

[0001137789-23-000010:mdna:77]
•$600 million in net proceeds from the issuance of Term Loan A3.

[0001137789-23-000010:mdna:78]
[same as prior period, unchanged from 0001137789-22-000123:mdna:89]

[0001137789-23-000010:mdna:79]
Our primary sources of liquidity as of December 30, 2022 consist of: (1) approximately $770 million in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.75 billion available for borrowing under our Revolving Credit Facility, which is part of the Credit Agreement.

[0001137789-23-000010:mdna:80]
As of December 30, 2022, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-23-000010:mdna:81]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The term of the Revolving Credit Facility is through October 14, 2026. As of December 30, 2022, we were in compliance with all of the covenants under our debt agreements. On November 8, 2022, we entered into the Seventh Amendment to our Credit Agreement to increase the maximum permitted total leverage ratio we must comply with during the covenant relief period which ends on June 28, 2024. We continue to evaluate our debt portfolio and structure to comply with our financial debt covenants.

[0001137789-23-000010:mdna:82]
[same as prior period, unchanged from 0001137789-22-000123:mdna:93]

[0001137789-23-000010:mdna:83]
[same as prior period, unchanged from 0001137789-22-000123:mdna:94]

[0001137789-23-000010:mdna:84]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness and to fund our quarterly dividend and any future strategic investments. As of December 30, 2022, our contractual cash requirements have not changed materially since our Annual Report on Form 10-K for the fiscal year ended July 1, 2022, except for the purchase obligations, long-term debt obligations and restructuring.

[0001137789-23-000010:mdna:85]
Purchase obligations

[0001137789-23-000010:mdna:86]
Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. From time to time, we enter into long-term, non-cancelable purchase commitments or make large up-front investments with certain suppliers in order to secure certain components or technologies for the production of our products or to supplement our internal manufacturing capacity for certain components. As of December 30, 2022, we had unconditional purchase obligations of approximately $4.3 billion primarily related to purchases of inventory components with our suppliers. We expect $1.2 billion of these commitments to be paid during the remainder of fiscal year 2023.

[0001137789-23-000010:mdna:87]
During the December 2022 quarter, we recorded order cancellation fees of $108 million to terminate certain purchase commitments related to purchase of inventory component and equipment. We expect these amounts to be paid within one year.

[0001137789-23-000010:mdna:88]
36

[0001137789-23-000010:mdna:89]
[same as prior period, unchanged from 0001137789-22-000123:mdna:96]

[0001137789-23-000010:mdna:90]
On August 18, 2022, we amended our credit agreement and borrowed a new Term Loan A3 in the aggregate principal amount of $600 million. Term Loan A3 bears interest at a rate of SOFR plus a variable margin of 1.25% to 2.5%, in each case with such margin being determined based on the corporate credit rating of the Borrower or one of its parent entities. Term Loan A3 is repayable in quarterly installments beginning on December 31, 2022 and is scheduled to mature on July 30, 2027.

[0001137789-23-000010:mdna:91]
On November 30, 2022, the Company completed an exchange offer in which $964 million principal amount in aggregate of the July 2029 Notes, January 2031 Notes and July 2031 Notes were exchanged for $750 million principal amount of 9.625% Senior Notes due on December 1, 2032. The exchange was accounted for as a debt extinguishment and resulted in a net gain of $204 million.

[0001137789-23-000010:mdna:92]
As of December 30, 2022, the future principal payment obligation on our long-term debt was $6.1 billion, of which $636 million will mature within one year. As of December 30, 2022, future interest payments on this outstanding debt is estimated to be approximately $1.9 billion, of which $282 million is expected to be paid within one year. From time to time, we may repurchase any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 1. Financial Statements—Note 3. Debt” for more details.

[0001137789-23-000010:mdna:93]
Restructuring

[0001137789-23-000010:mdna:94]
On October 24, 2022, our Board of Directors approved and committed to the October 2022 Plan to reduce its cost structure to better align our operational needs to current economic conditions while continuing to support the long-term business strategy. The October 2022 Plan includes reducing our worldwide headcount by approximately 3,000 employees, or 8% of the global workforce, along with other cost saving measures. During the December 2022 quarter, we recorded restructuring charges of $81 million, primarily related to the October 2022 Plan, and made cash payments of $34 million for all active restructuring plans.

[0001137789-23-000010:mdna:95]
As of December 30, 2022, the future cash payments related to the Company’s remaining active restructuring plans were $57 million, of which $54 million is expected to be paid during the remainder of fiscal year 2023 and $3 million thereafter.

[0001137789-23-000010:mdna:96]
[same as prior period, unchanged from 0001137789-22-000123:mdna:99]

[0001137789-23-000010:mdna:97]
During the December 2022 quarter, our Board of Directors declared dividends of $0.70 per share, totaling $145 million, which was paid on January 5, 2022. On January 25, 2023, our Board of Directors declared a quarterly cash dividend of $0.70 per share, payable on April 6, 2023 to shareholders of record at the close of business on March 22, 2023. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-23-000010:mdna:98]
[same as prior period, unchanged from 0001137789-22-000123:mdna:101]

[0001137789-23-000010:mdna:99]
From time to time, at the Company’s discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker-assisted purchases, tender offers, or other means, including through the use of derivative transactions. As of December 30, 2022, $1.9 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-23-000010:mdna:100]
[same as prior period, unchanged from 0001137789-22-000123:mdna:103]

[0001137789-23-000010:mdna:101]
[same as prior period, unchanged from 0001137789-22-000123:mdna:104]

[0001137789-23-000010:mdna:102]
[same as prior period, unchanged from 0001137789-22-000123:mdna:108]

[0001137789-23-000010:mdna:103]
[same as prior period, unchanged from 0001137789-22-000123:mdna:109]

[0001137789-23-000010:mdna:104]
[same as prior period, unchanged from 0001137789-22-000123:mdna:111]

[0001137789-23-000010:mdna:105]
[same as prior period, unchanged from 0001137789-22-000123:mdna:112]

[0001137789-23-000010:mdna:106]
[same as prior period, unchanged from 0001137789-22-000123:mdna:113]
