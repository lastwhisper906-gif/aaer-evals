# STX note change history — 0001137789-22-000123 → 0001137789-23-000010


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-01-25):
[0001137789-23-000010:note_history:1]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.
  (was, 2022-10-27, similarity 0.9798):
[0001137789-22-000123:note_history:1]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually, or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

- added (2023-01-25):
[0001137789-23-000010:note_history:2]
Lambeth Magnetic Structures LLC, v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgement in favor of Seagate on April 19, 2022. The parties filed post-trial motions with the district court in May 2022. On November 22, 2022, the court denied all pending post-trial motions. Lambeth Magnetic Structures LLC filed a notice of appeal to the Federal Circuit on December 20, 2022. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

- changed (2023-01-25):
[0001137789-23-000010:note_history:3]
On August 29, 2022, the Company received a proposed charging letter (“PCL”) from the U.S. Commerce Department’s Bureau of Industry and Security (“BIS”), alleging violations of the U.S. Export Administration Regulations (“EAR”). The PCL alleges the Company acted in violation of the EAR by providing its HDDs to a customer and its affiliates listed on the BIS Entity List between August 2020 and September 2021. The Company believes these allegations are without merit. The Company has responded to the PCL, setting forth its position that it did not engage in prohibited conduct as alleged by BIS, because, among other reasons, Seagate’s HDDs are not subject to the EAR.
  (was, 2022-10-27, similarity 0.9748):
[0001137789-22-000123:note_history:3]
On August 29, 2022, the Company received a proposed charging letter (“PCL”) from the U.S. Commerce Department’s Bureau of Industry and Security (“BIS”), alleging violations of the U.S. Export Administration Regulations (“EAR”). The PCL alleges the Company acted in violation of the EAR by providing its HDDs to a customer and its affiliates listed on the BIS Entity List between August 2020 and September 2021. The Company believes these allegations are without merit and will defend itself vigorously. The Company has responded to the PCL, setting forth its position that it did not engage in prohibited conduct as alleged by BIS, because, among other reasons, Seagate’s HDDs are not subject to the EAR.

- changed (2023-01-25):
[0001137789-23-000010:note_history:4]
The matters raised by the PCL remain unresolved at this time, and there can be no assurance as to the timing or terms of any final outcome. The Company is unable at this time to estimate the range of loss and/or penalty, if any, although it is possible that the outcome could have a material impact on its business, results of operations, financial condition, and cash flows. The Company has committed to compliance through its global team of international trade compliance and legal professionals and by maintaining robust trade controls, compliance policies and procedures. The Company has been cooperating with BIS and engaging in discussions with BIS to seek a resolution of this matter. If the Company is not able to reach a resolution, the Company believes that this matter will result in litigation between the Company and BIS. The Company believes that it has complied with all relevant export control laws and regulations and will defend itself vigorously.
  (was, 2022-10-27, similarity 0.7595):
[0001137789-22-000123:note_history:4]
The matters raised by the PCL remain unresolved at this time, and there can be no assurance as to the timing or terms of any final outcome. The Company is unable at this time to estimate the range of loss and/or penalty, if any, although it is possible that the outcome could have a material impact on its business, results of operations, financial condition, and cash flows. The Company believes that it has complied with all relevant export control laws and regulations. The Company has committed to compliance through its global team of international trade compliance and legal professionals and by maintaining robust trade controls, compliance policies and procedures. The Company has been cooperating with BIS and intends to continue to engage with BIS to seek a resolution of this matter.

- removed (2023-01-25):
[0001137789-22-000123:note_history:5]
Lambeth Magnetic Structures LLC, v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods”. The complaint seeks damages as well as additional relief. The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. The trial began on April 4, 2022. On April 14, 2022, the jury returned a verdict of non-infringement for Seagate finding that Seagate had not infringed any of the asserted claims. The district court entered judgement in favor of Seagate on April 19, 2022. The parties filed post-trial motions with the district court in May 2022. The court has not yet set a hearing date for these motions.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-01-25):
[0001137789-23-000010:note_history:6]
The Company’s consolidated financial statements for the fiscal year ended July 1, 2022 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 5, 2022. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 1, 2022, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and six months ended December 30, 2022 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 30, 2023.
  (was, 2022-10-27, similarity 0.8271):
[0001137789-22-000123:note_history:6]
The Company’s consolidated financial statements for the fiscal year ended July 1, 2022 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 5, 2022. The Company believes that the disclosures included in these unaudited condensed consolidated financial statements, when read in conjunction with its consolidated financial statements as of July 1, 2022, and the notes thereto, are adequate to make the information presented not misleading. The results of operations and the cash flows for the three months ended September 30, 2022 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending June 30, 2023.

- changed (2023-01-25):
[0001137789-23-000010:note_history:7]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. Both the three and six months ended December 30, 2022 and the three and six months ended December 31, 2021 consisted of 13 and 26 weeks, respectively. Fiscal years 2023 and 2022 both comprise of 52 weeks and end on June 30, 2023 and July 1, 2022, respectively. The fiscal quarters ended December 30, 2022, September 30, 2022 and December 31, 2021, are also referred to herein as the “December 2022 quarter”, the “September 2022 quarter” and the “December 2021 quarter”, respectively.
  (was, 2022-10-27, similarity 0.611):
[0001137789-22-000123:note_history:7]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three months ended September 30, 2022 and October 1, 2021 consisted of 13 weeks. Fiscal years 2023 and 2022 both comprise of 52 weeks and end on June 30, 2023 and July 1, 2022, respectively. The fiscal quarters ended September 30, 2022, July 1, 2022 and October 1, 2021, are also referred to herein as the “September 2022 quarter”, the “June 2022 quarter” and the “September 2021 quarter”, respectively.

- changed (2023-01-25):
[0001137789-23-000010:note_history:8]
In March 2020, the Financial Accounting Standards Board (“FASB”) issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. In December 2022, FASB issued ASU 2022-06 (ASC Topic 848) and deferred the sunset date from December 31, 2022 to December 31, 2024. The Company adopted the guidance in the quarter ended September 30, 2022 on a prospective basis and is transitioning from an interest rate based on London Interbank Offered Rate (“LIBOR”) to Secured Overnight Financing Rate (“SOFR”). The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.
  (was, 2022-10-27, similarity 0.9222):
[0001137789-22-000123:note_history:8]
In March 2020, the Financial Accounting Standards Board (“FASB”) issued ASU 2020-04 (ASC Topic 848), Reference Rate Reform. This ASU provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by reference rate reform if certain criteria are met. The Company adopted the guidance in the quarter ended September 30, 2022 on a prospective basis and is transitioning from an interest rate based on London Interbank Offered Rate (“LIBOR”) to Secured Overnight Financing Rate (“SOFR”). The adoption of this ASU did not have a material impact on the Company’s condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-01-25):
[0001137789-23-000010:note_history:9]
Debt
The following table provides details of the Company’s debt as of December 30, 2022 and July 1, 2022:
  (was, 2022-10-27, similarity 0.9741):
[0001137789-22-000123:note_history:9]
Debt
The following table provides details of the Company’s debt as of September 30, 2022 and July 1, 2022:

- changed (2023-01-25):
[0001137789-23-000010:note_history:10]
| (Dollars in millions) |  | December 30,2022 |  | July 1,2022 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | $ | 540 |  |  | $ | 540 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 469 |  |  | 466 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 164 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 295 |  |  | 500 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 77 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | — |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 600 |  |  | 600 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | 600 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | — |  |
|  |  | 6,066 |  |  | 5,677 |  |
| Less: unamortized debt issuance costs |  | (37) |  |  | (31) |  |
| Debt, net of debt issuance costs |  | 6,029 |  |  | 5,646 |  |
| Less: current portion of long-term debt |  | (636) |  |  | (584) |  |
| Long-term debt, less current portion |  | $ | 5,393 |  |  | $ | 5,062 |  |
  (was, 2022-10-27, similarity 0.8754):
[0001137789-22-000123:note_history:10]
| (Dollars in millions) |  | September 30,2022 |  | July 1,2022 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | $ | 540 |  |  | $ | 540 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 468 |  |  | 466 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 600 |  |  | 600 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | 600 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | — |  |
|  |  | 6,279 |  |  | 5,677 |  |
| Less: unamortized debt issuance costs |  | (30) |  |  | (31) |  |
| Debt, net of debt issuance costs |  | 6,249 |  |  | 5,646 |  |
| Less: current portion of long-term debt |  | (636) |  |  | (584) |  |
| Long-term debt, less current portion |  | $ | 5,613 |  |  | $ | 5,062 |  |

- changed (2023-01-25):
[0001137789-23-000010:note_history:11]
______________________________
  (was, 2022-10-27, similarity 0.9375):
[0001137789-22-000123:note_history:11]
__________________________________

- added (2023-01-25):
[0001137789-23-000010:note_history:12]
(1) All unsecured senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX.

- added (2023-01-25):
[0001137789-23-000010:note_history:13]
Debt Exchange

- added (2023-01-25):
[0001137789-23-000010:note_history:14]
2032 Notes. On November 30, 2022, Seagate HDD issued, in a private placement, $750 million in aggregate principal amount of 9.625% Senior Notes due on December 1, 2032, in connection with Seagate HDD’s exchange offers to certain eligible holders of Seagate HDD’s outstanding existing senior notes as set forth below:

- added (2023-01-25):
[0001137789-23-000010:note_history:15]
| (Dollars in millions) |  |  |  |  |  |  |  |  |
| Existing Notes |  | Principal Amount Outstanding as of September 30, 2022 |  | Principal Amount Exchanged |  | Remaining Principal Amount as of December 30, 2022 |  | Net Gain Recognized From Early Redemption |
| July 2031 Notes |  | $ | 500 |  |  | $ | 423 |  |  | $ | 77 |  |  | $ | 95 |  |
| July 2029 Notes |  | 500 |  | 336 |  |  | 164 |  |  | 70 |  |
| January 2031 Notes |  | 500 |  | 205 |  |  | 295 |  |  | 39 |  |
| Total |  | $ | 1,500 |  |  | $ | 964 |  |  | $ | 536 |  |  | $ | 204 |  |

- added (2023-01-25):
[0001137789-23-000010:note_history:16]
The exchange was accounted for as a debt extinguishment and the Company recorded a net gain of $204 million, in the Company’s Condensed Consolidated Statements of Operations.

- added (2023-01-25):
[0001137789-23-000010:note_history:17]
At any time prior to December 1, 2027, Seagate HDD may redeem the 2032 Notes at its option, in whole or in part, at any time and from time to time, at a “make-whole” redemption price. The “make-whole” redemption price will be equal to the greater of: (1) (a) the sum of the present values at such redemption date of the redemption price of the 2032 Notes that would apply if the new 2032 Notes were redeemed on December 1, 2027 plus the remaining scheduled payments of interest thereon to and including December 1, 2027 discounted to the redemption date on a semi-annual basis at the Treasury Rate plus 50 basis points less (b) interest accrued to the date of redemption, and (2) 100% of the principal amount of the 2032 Notes to be redeemed plus, in either case, accrued and unpaid interest thereon, if any, to, but excluding, the redemption date. At any time on or after December 1, 2027, Seagate HDD may redeem some or all of the 2032 Notes at the prices specified in the Indenture, plus accrued and unpaid interest to, but excluding, the redemption date. In addition, Seagate HDD may redeem with the net cash proceeds from one or more equity offerings up to 40% of the 2032 Notes before December 1, 2025, at a redemption price of 109.625% plus accrued and unpaid interest to, but excluding, the redemption date.

- added (2023-01-25):
[0001137789-23-000010:note_history:18]
On August 18, 2022, Seagate Technology Holdings plc and Seagate HDD (the “Borrower”) entered into an amendment to its Credit Agreement (the “Sixth Amendment”), which provided for a new term loan facility in the aggregate principal amount of $600 million (“Term Loan A3”). Term Loan A3 was borrowed in full at the closing of the Sixth Amendment. The Sixth Amendment to the Credit Agreement also replaced the LIBOR interest rates plus variable margin for the Term Loans A1 and A2 with the SOFR interest rates plus a variable margin that will be determined based on the corporate credit rating of the Borrower or one of its parent entities. The Sixth Amendment also permits the Borrower to increase the revolving loan commitments or obtain new term loans of up to $100 million in aggregate (the “Incremental facility”), subject to the satisfaction of certain terms and conditions.

- added (2023-01-25):
[0001137789-23-000010:note_history:19]
On November 8, 2022, Seagate Technology Holdings plc and the Borrower entered into an amendment to its Credit Agreement (the “Seventh Amendment”), to increase the maximum permitted total leverage ratio the Company must comply with during the covenant relief period that ends on June 28, 2024 and prohibit the Company from pursuing the use of the Incremental Facility during the covenant relief period. The maximum permitted total leverage ratio is 5.0 to 1.0 from the fiscal quarters ending December 30, 2022 to June 30, 2023. For the fiscal quarter ending September 29, 2023, the maximum permitted total leverage ratio is 4.75 to 1.0 and then steps down to 4.5 to 1.0 from the fiscal quarters ending December 29, 2023 to June 28, 2024. The maximum permitted leverage ratio will return to 4.0 to 1.0 for any fiscal quarter ending after June 28, 2024.

- added (2023-01-25):
[0001137789-23-000010:note_history:20]
The Credit Agreement provides a term loan facility in an aggregate principal amount of $1.8 billion that is extended in three tranches of $600 million each for Term Loans A1, A2 and A3, and a $1.75 billion senior unsecured revolving credit facility (“Revolving Credit Facility”). As of December 30, 2022, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. STX and certain of its material subsidiaries, including STUC, fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loans A1, A2 and A3 (the “Term Loans”). The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of December 30, 2022.

- changed (2023-01-25):
[0001137789-23-000010:note_history:21]
At December 30, 2022, future principal payments on long-term debt were as follows (in millions):
  (was, 2022-10-27, similarity 0.9724):
[0001137789-22-000123:note_history:21]
At September 30, 2022, future principal payments on long-term debt were as follows (in millions):

- removed (2023-01-25):
[0001137789-22-000123:note_history:22]
(1) All unsecured senior notes are issued by Seagate HDD Cayman, and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and, pursuant to a supplemental indenture dated as of May 18, 2021, STX.

- removed (2023-01-25):
[0001137789-22-000123:note_history:23]
The Company’s subsidiary, Seagate HDD Cayman, has a credit agreement, which was most recently amended on August 18, 2022 (the “Credit Agreement”).

- removed (2023-01-25):
[0001137789-22-000123:note_history:24]
Prior to the August 18, 2022 amendment, the Credit Agreement provided a term loan facility in an aggregate principal amount of $1.2 billion that was extended in two tranches of $600 million each for Term Loans A1 and A2 and a $1.75 billion senior unsecured revolving credit facility (“Revolving Credit Facility”). Term Loans A1 and A2 were drawn in full on October 14, 2021.

- removed (2023-01-25):
[0001137789-22-000123:note_history:25]
On August 18, 2022, Seagate Technology Holdings plc and Seagate HDD Cayman (the “Borrower”) entered into an amendment to the Credit Agreement (the “Sixth Amendment”), which provides for a new term loan facility in the aggregate principal amount of $600 million (“Term Loan A3”). Term Loan A3 was borrowed in full at the closing of the Sixth Amendment. Term Loan A3 bears interest at a rate of SOFR plus a variable margin of 1.25% to 2.5%, in each case with such margin being determined based on the corporate credit rating of the Borrower or one of its parent entities. Term Loan A3 is repayable in quarterly installments beginning on December 31, 2022 and is scheduled to mature on July 30, 2027.

- removed (2023-01-25):
[0001137789-22-000123:note_history:26]
The Sixth Amendment to the Credit Agreement also replaced the LIBOR interest rates plus variable margin for the Term Loans A1 and A2 with the SOFR interest rates plus a variable margin that will be determined based on the corporate credit rating of the Borrower or one of its parent entities. The Sixth Amendment also permits the Borrower to increase the revolving loan commitments or obtain new term loans of up to $100 million in aggregate, subject to the satisfaction of certain terms and conditions.

- removed (2023-01-25):
[0001137789-22-000123:note_history:27]
STX and certain of its material subsidiaries, including STUC, fully and unconditionally guarantee both the Revolving Credit Facility and the Term Loans A1, A2 and A3 (the “Term Loans”).

- removed (2023-01-25):
[0001137789-22-000123:note_history:28]
The Credit Agreement includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of September 30, 2022. As of September 30, 2022, no borrowings (including swingline loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-01-25):
[0001137789-23-000010:note_history:29]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of December 30, 2022 and July 1, 2022:
  (was, 2022-10-27, similarity 0.985):
[0001137789-22-000123:note_history:29]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s available-for-sale debt investments as of September 30, 2022 and July 1, 2022:

- changed (2023-01-25):
[0001137789-23-000010:note_history:30]
|  |  | December 30,2022 |  | July 1,2022 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 173 |  |  | $ | — |  |  | $ | 173 |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 16 |  |  | — |  |  | 16 |  |  | 23 |  |  | — |  |  | 23 |  |
| Total |  | $ | 190 |  |  | $ | — |  |  | $ | 190 |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 172 |  |  |  |  |  |  | $ | 59 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 16 |  |  |  |  |  |  | 23 |  |
| Total |  |  |  |  |  | $ | 190 |  |  |  |  |  |  | $ | 84 |  |
  (was, 2022-10-27, similarity 0.9959):
[0001137789-22-000123:note_history:30]
|  |  | September 30,2022 |  | July 1,2022 |
| (Dollars in millions) |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 159 |  |  | $ | — |  |  | $ | 159 |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |
| Time deposits and certificates of deposit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | 16 |  |  | — |  |  | 16 |  |  | 23 |  |  | — |  |  | 23 |  |
| Total |  | $ | 176 |  |  | $ | — |  |  | $ | 176 |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |
| Included in Cash and cash equivalents |  |  |  |  |  | $ | 158 |  |  |  |  |  |  | $ | 59 |  |
| Included in Other current assets |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 16 |  |  |  |  |  |  | 23 |  |
| Total |  |  |  |  |  | $ | 176 |  |  |  |  |  |  | $ | 84 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2023-01-25):
[0001137789-22-000123:note_history:31]
The following table presents the fair value and amortized cost of the Company’s debt in order of maturity:

- removed (2023-01-25):
[0001137789-22-000123:note_history:32]
|  |  | September 30, 2022 |  | July 1, 2022 |
| (Dollars in millions) |  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 4.750% Senior Notes due June 2023 |  | $ | 540 |  |  | $ | 537 |  |  | $ | 540 |  |  | $ | 538 |  |
| 4.875% Senior Notes due March 2024 |  | 499 |  |  | 489 |  |  | 499 |  |  | 494 |  |
| 4.750% Senior Notes due January 2025 |  | 479 |  |  | 457 |  |  | 479 |  |  | 471 |  |
| 4.875% Senior Notes due June 2027 |  | 504 |  |  | 457 |  |  | 504 |  |  | 483 |  |
| 4.091% Senior Notes due June 2029 |  | 468 |  |  | 396 |  |  | 466 |  |  | 427 |  |
| 3.125% Senior Notes due July 2029 |  | 500 |  |  | 368 |  |  | 500 |  |  | 396 |  |
| 4.125% Senior Notes due January 2031 |  | 500 |  |  | 375 |  |  | 500 |  |  | 410 |  |
| 3.375% Senior Notes due July 2031 |  | 500 |  |  | 350 |  |  | 500 |  |  | 393 |  |
| 5.750% Senior Notes due December 2034 |  | 489 |  |  | 386 |  |  | 489 |  |  | 433 |  |
| SOFR Based Term Loan A1 due September 2025 (1) |  | 600 |  |  | 589 |  |  | 600 |  |  | 588 |  |
| SOFR Based Term Loan A2 due July 2027 (1) |  | 600 |  |  | 581 |  |  | 600 |  |  | 586 |  |
| SOFR Based Term Loan A3 due July 2027 |  | 600 |  |  | 584 |  |  | — |  |  | — |  |
|  |  | $ | 6,279 |  |  | $ | 5,569 |  |  | $ | 5,677 |  |  | $ | 5,219 |  |
| Less: unamortized debt issuance costs |  | (30) |  |  | — |  |  | (31) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 6,249 |  |  | $ | 5,569 |  |  | $ | 5,646 |  |  | $ | 5,219 |  |
| Less: current portion of debt, net of debt issuance costs |  | (636) |  |  | (630) |  |  | (584) |  |  | (582) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,613 |  |  | $ | 4,939 |  |  | $ | 5,062 |  |  | $ | 4,637 |  |

- removed (2023-01-25):
[0001137789-22-000123:note_history:33]
_________________________________

- removed (2023-01-25):
[0001137789-22-000123:note_history:34]
(1) On August 18, 2022, the Sixth Amendment to the Credit Agreement replaced the LIBOR interest rates plus variable margin of Term Loans A1 and A2 with the SOFR interest rates plus a variable margin. Refer to “Note 3. Debt” for more details.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-01-25):
[0001137789-23-000010:note_history:35]
| (Dollars in millions) |  | December 30,2022 |  | July 1,2022 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | $ | 540 |  |  | $ | 540 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 469 |  |  | 466 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 164 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 295 |  |  | 500 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 77 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | — |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 600 |  |  | 600 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | 600 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | — |  |
|  |  | 6,066 |  |  | 5,677 |  |
| Less: unamortized debt issuance costs |  | (37) |  |  | (31) |  |
| Debt, net of debt issuance costs |  | 6,029 |  |  | 5,646 |  |
| Less: current portion of long-term debt |  | (636) |  |  | (584) |  |
| Long-term debt, less current portion |  | $ | 5,393 |  |  | $ | 5,062 |  |
  (was, 2022-10-27, similarity 0.8754):
[0001137789-22-000123:note_history:35]
| (Dollars in millions) |  | September 30,2022 |  | July 1,2022 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 22, 2013 at 4.75% due June 1, 2023 (the “2023 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | $ | 540 |  |  | $ | 540 |  |
| $500 issued on February 3, 2017 at 4.875% due March 1, 2024 (the “2024 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 499 |  |  | 499 |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 504 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 468 |  |  | 466 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | 600 |  |  | 600 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | 600 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | 600 |  |  | — |  |
|  |  | 6,279 |  |  | 5,677 |  |
| Less: unamortized debt issuance costs |  | (30) |  |  | (31) |  |
| Debt, net of debt issuance costs |  | 6,249 |  |  | 5,646 |  |
| Less: current portion of long-term debt |  | (636) |  |  | (584) |  |
| Long-term debt, less current portion |  | $ | 5,613 |  |  | $ | 5,062 |  |

- changed (2023-01-25):
[0001137789-23-000010:note_history:36]
______________________________
  (was, 2022-10-27, similarity 0.9375):
[0001137789-22-000123:note_history:36]
__________________________________

- added (2023-01-25):
[0001137789-23-000010:note_history:37]
(1) All unsecured senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX.

- removed (2023-01-25):
[0001137789-22-000123:note_history:38]
The following table provides details of the Company’s debt as of September 30, 2022 and July 1, 2022:

- removed (2023-01-25):
[0001137789-22-000123:note_history:39]
(1) All unsecured senior notes are issued by Seagate HDD Cayman, and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and, pursuant to a supplemental indenture dated as of May 18, 2021, STX.


## us-gaap:ScheduleOfExtinguishmentOfDebtTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2023-01-25):
[0001137789-23-000010:note_history:40]
On November 30, 2022, Seagate HDD issued, in a private placement, $750 million in aggregate principal amount of 9.625% Senior Notes due on December 1, 2032, in connection with Seagate HDD’s exchange offers to certain eligible holders of Seagate HDD’s outstanding existing senior notes as set forth below:

- added (2023-01-25):
[0001137789-23-000010:note_history:41]
| (Dollars in millions) |  |  |  |  |  |  |  |  |
| Existing Notes |  | Principal Amount Outstanding as of September 30, 2022 |  | Principal Amount Exchanged |  | Remaining Principal Amount as of December 30, 2022 |  | Net Gain Recognized From Early Redemption |
| July 2031 Notes |  | $ | 500 |  |  | $ | 423 |  |  | $ | 77 |  |  | $ | 95 |  |
| July 2029 Notes |  | 500 |  | 336 |  |  | 164 |  |  | 70 |  |
| January 2031 Notes |  | 500 |  | 205 |  |  | 295 |  |  | 39 |  |
| Total |  | $ | 1,500 |  |  | $ | 964 |  |  | $ | 536 |  |  | $ | 204 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-01-25):
[0001137789-23-000010:note_history:42]
At December 30, 2022, future principal payments on long-term debt were as follows (in millions):
  (was, 2022-10-27, similarity 0.9724):
[0001137789-22-000123:note_history:42]
At September 30, 2022, future principal payments on long-term debt were as follows (in millions):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-01-25):
[0001137789-23-000010:note_history:43]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,365 |  |  | $ | 2,178 |  |  | $ | 2,910 |  |  | $ | 4,465 |  |
| Distributors |  | 297 |  |  | 562 |  |  | 596 |  |  | 1,069 |  |
| Retailers |  | 225 |  |  | 376 |  |  | 416 |  |  | 697 |  |
| Total |  | $ | 1,887 |  |  | $ | 3,116 |  |  | $ | 3,922 |  |  | $ | 6,231 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 760 |  |  | $ | 1,433 |  |  | $ | 1,561 |  |  | $ | 3,016 |  |
| Americas |  | 853 |  |  | 1,186 |  |  | 1,789 |  |  | 2,265 |  |
| EMEA |  | 274 |  |  | 497 |  |  | 572 |  |  | 950 |  |
| Total |  | $ | 1,887 |  |  | $ | 3,116 |  |  | $ | 3,922 |  |  | $ | 6,231 |  |

- removed (2023-01-25):
[0001137789-22-000123:note_history:44]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 30,2022 |  | October 1,2021 |
| Revenues by Channel |  |  |  |  |
| OEMs |  | $ | 1,545 |  |  | $ | 2,288 |  |
| Distributors |  | 299 |  |  | 507 |  |
| Retailers |  | 191 |  |  | 320 |  |
| Total |  | $ | 2,035 |  |  | $ | 3,115 |  |
| Revenues by Geography (1) |  |  |  |  |
| Asia Pacific |  | $ | 801 |  |  | $ | 1,583 |  |
| Americas |  | 936 |  |  | 1,079 |  |
| EMEA |  | 298 |  |  | 453 |  |
| Total |  | $ | 2,035 |  |  | $ | 3,115 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-01-25):
[0001137789-23-000010:note_history:45]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | December 30,2022 |  | December 31,2021 |  | December 30,2022 |  | December 31,2021 |
| Revenues by Channel |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,365 |  |  | $ | 2,178 |  |  | $ | 2,910 |  |  | $ | 4,465 |  |
| Distributors |  | 297 |  |  | 562 |  |  | 596 |  |  | 1,069 |  |
| Retailers |  | 225 |  |  | 376 |  |  | 416 |  |  | 697 |  |
| Total |  | $ | 1,887 |  |  | $ | 3,116 |  |  | $ | 3,922 |  |  | $ | 6,231 |  |
| Revenues by Geography (1) |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 760 |  |  | $ | 1,433 |  |  | $ | 1,561 |  |  | $ | 3,016 |  |
| Americas |  | 853 |  |  | 1,186 |  |  | 1,789 |  |  | 2,265 |  |
| EMEA |  | 274 |  |  | 497 |  |  | 572 |  |  | 950 |  |
| Total |  | $ | 1,887 |  |  | $ | 3,116 |  |  | $ | 3,922 |  |  | $ | 6,231 |  |

- removed (2023-01-25):
[0001137789-22-000123:note_history:46]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | September 30,2022 |  | October 1,2021 |
| Revenues by Channel |  |  |  |  |
| OEMs |  | $ | 1,545 |  |  | $ | 2,288 |  |
| Distributors |  | 299 |  |  | 507 |  |
| Retailers |  | 191 |  |  | 320 |  |
| Total |  | $ | 2,035 |  |  | $ | 3,115 |  |
| Revenues by Geography (1) |  |  |  |  |
| Asia Pacific |  | $ | 801 |  |  | $ | 1,583 |  |
| Americas |  | 936 |  |  | 1,079 |  |
| EMEA |  | 298 |  |  | 453 |  |
| Total |  | $ | 2,035 |  |  | $ | 3,115 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2023-01-25):
[0001137789-23-000010:note_history:47]
Dividend Declared
  (was, 2022-10-27, similarity 0.6538):
[0001137789-22-000123:note_history:47]
Subsequent Events
Dividend Declared

- added (2023-01-25):
[0001137789-23-000010:note_history:48]
On January 25, 2023, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on April 6, 2023 to shareholders of record as of the close of business on March 22, 2023.

- removed (2023-01-25):
[0001137789-22-000123:note_history:49]
On October 26, 2022, the Company’s Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on January 5, 2023 to shareholders of record as of the close of business on December 21, 2022.

- removed (2023-01-25):
[0001137789-22-000123:note_history:50]
Restructuring Plan

- removed (2023-01-25):
[0001137789-22-000123:note_history:51]
On October 24, 2022, the Company’s Board of Directors approved and committed to a plan to reduce its cost structure to better align the Company’s operational needs to current economic conditions while continuing to support the long-term business strategy. See “Note 5. Restructuring and Exit Costs” for more information.
