# STX note change history — 0001193125-19-027007 → 0001193125-19-129284


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-04-30):
[0001193125-19-129284:note_history:1]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.
  (was, 2019-02-04, similarity 0.9959):
[0001193125-19-027007:note_history:1]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-04-30):
[0001193125-19-129284:note_history:2]
The results of operations for the three and nine months ended March 29, 2019 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending June 28, 2019. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three and nine months ended March 29, 2019 and March 30, 2018 consisted of 13 weeks and 39 weeks, respectively. Fiscal year 2019, which ends on June 28, 2019, and fiscal year 2018, which ended on June 29, 2018, are both comprised of 52 weeks. The fiscal quarters ended March 29, 2019, December 28, 2018, September 28, 2018 and March 30, 2018, are also referred to herein as the “March 2019 quarter”, the “December 2018 quarter”, the "September 2018 quarter" and the “March 2018 quarter”, respectively.
  (was, 2019-02-04, similarity 0.7883):
[0001193125-19-027007:note_history:2]
The results of operations for the three and six months ended December 28, 2018 are not necessarily indicative of the results of operations to be expected for any subsequent interim period or for the Company’s fiscal year ending June 28, 2019. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Both the three and six months ended December 28, 2018 and the three and six months ended December 29, 2017 consisted of 13 weeks and 26 weeks, respectively. Fiscal year 2019, which ends on June 28, 2019, and fiscal year 2018, which ended on June 29, 2018, are both comprised of 52 weeks. The fiscal quarters ended December 28, 2018, September 28, 2018, and December 29, 2017, are also referred to herein as the “December 2018 quarter”, the “September 2018 quarter” and the “December 2017 quarter”, respectively.

- changed (2019-04-30):
[0001193125-19-129284:note_history:3]
The Company records estimated variable consideration at the time of revenue recognition as a reduction to net revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer’s volume of purchases from Seagate or other agreed upon rebate programs. For the distribution and retailing channel, these sales incentive programs typically involve estimating the most likely amount of rebates related to a customer’s level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Marketing development program costs are accrued and recorded as a reduction to revenue at the same time that the related revenue is recognized.
  (was, 2019-02-04, similarity 0.9919):
[0001193125-19-027007:note_history:3]
The Company records estimated variable consideration at the time of revenue recognition as a reduction to net revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer’s volume of purchases from Seagate or other agreed upon rebate programs. For the distribution and retailing channel, these programs typically involve estimating the most likely amount of rebates related to a customer’s level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Marketing development program costs are accrued and recorded as a reduction to revenue at the same time that the related revenue is recognized.

- changed (2019-04-30):
[0001193125-19-129284:note_history:4]
The impact of applying the new accounting standard on the Company's condensed consolidated financial statements for the three and nine months ended March 29, 2019 was not material.
  (was, 2019-02-04, similarity 0.9602):
[0001193125-19-027007:note_history:4]
The impact of applying the new accounting standard on the Company's condensed consolidated financial statements for the three and six months ended December 28, 2018 was not material.

- removed (2019-04-30):
[0001193125-19-027007:note_history:5]
Practical Expedient and Exemptions


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-04-30):
[0001193125-19-129284:note_history:6]
Revolving Credit Facility

- added (2019-04-30):
[0001193125-19-129284:note_history:7]
On February 20, 2019, the Company terminated its senior unsecured revolving credit facility scheduled to expire on January 15, 2020, under which the Company was able to draw up to $700 million. Upon termination, the Company and its subsidiary Seagate HDD Cayman entered into a new credit agreement (the "2019 Revolving Credit Facility") which provides the Company with a $1.3 billion senior unsecured revolving credit facility. The term of the 2019 Revolving Credit Facility is through February 20, 2024. The loans made under the 2019 Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain other material subsidiaries of the Company fully and unconditionally guarantee the revolving credit facility. The 2019 Revolving Credit Facility also allows the Company to increase the facility by up to an aggregate of $300 million, provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at least $25 million, and (iii) the existing commitments under the facility receive 0.50% most favored nation protection. An aggregate amount of up to $75 million of the facility is available for the issuance of letters of credit, and an aggregate amount of up to $50 million of the facility is also available for swing line loans.

- added (2019-04-30):
[0001193125-19-129284:note_history:8]
The 2019 Revolving Credit Facility includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio, and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of March 29, 2019 and expects to be in compliance for the next 12 months.

- changed (2019-04-30):
[0001193125-19-129284:note_history:9]
As of March 29, 2019, $200 million had been drawn and no letters of credit or swing line loans had been utilized under the 2019 Revolving Credit Facility.
  (was, 2019-02-04, similarity 0.7549):
[0001193125-19-027007:note_history:9]
As of December 28, 2018, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

- added (2019-04-30):
[0001193125-19-129284:note_history:10]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The Company recorded a loss of approximately $1 million and $3 million on repurchases during the three and nine months ended March 30, 2018, respectively, which is included in Other, net on the Company's Condensed Consolidated Statements of Operations. On November 15, 2018, the 2018 Notes matured and the Company repaid the entire outstanding principal amount of $499 million, plus accrued and unpaid interest.

- changed (2019-04-30):
[0001193125-19-129284:note_history:11]
At March 29, 2019, future principal payments on long-term debt were as follows (in millions):
  (was, 2019-02-04, similarity 0.9492):
[0001193125-19-027007:note_history:11]
At December 28, 2018, future principal payments on long-term debt were as follows (in millions):

- removed (2019-04-30):
[0001193125-19-027007:note_history:12]
Short-Term Borrowings

- removed (2019-04-30):
[0001193125-19-027007:note_history:13]
The credit agreement entered into by the Company and its subsidiary Seagate HDD Cayman on January 18, 2011 and subsequently amended (the "Revolving Credit Facility") provides the Company with a $700 million senior secured revolving credit facility. The term of the Revolving Credit Facility is through January 15, 2020. The loans made under the Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing, and for the issuance of letters of credit up to a sub-limit of $75 million.

- removed (2019-04-30):
[0001193125-19-027007:note_history:14]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. The Company was in compliance with the modified covenants as of December 28, 2018 and expects to be in compliance for the next 12 months.

- removed (2019-04-30):
[0001193125-19-027007:note_history:15]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes was payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes was Seagate HDD Cayman, and the obligations under the 2018 Notes were fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the three and six months ended December 29, 2017, the Company repurchased $128 million and $150 million aggregate principal amount of the 2018 Notes, respectively, for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss of approximately $2 million on repurchases during the three and six months ended December 29, 2017 which is included in Other, net on the Company's Condensed Consolidated Statements of Operations. On November 15, 2018, the 2018 Notes matured and the Company repaid the entire outstanding principal amount of $499 million, plus accrued and unpaid interest.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-04-30):
[0001193125-19-129284:note_history:16]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of March 29, 2019:
  (was, 2019-02-04, similarity 0.9647):
[0001193125-19-027007:note_history:16]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of December 28, 2018:


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-04-30):
[0001193125-19-129284:note_history:17]
orded at amortized cost and its fair value approximated the carrying value at June 29, 2018. As of

- removed (2019-04-30):
[0001193125-19-027007:note_history:18]
The following table presents the fair value and amortized cost of the Company’s debt in order of maturity:

- removed (2019-04-30):
[0001193125-19-027007:note_history:19]
|  |  | December 28, 2018 |  | June 29, 2018 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | — |  |  | $ | — |  |  | $ | 499 |  |  | $ | 501 |  |
| 4.25% Senior Notes due March 2022 |  | 749 |  |  | 720 |  |  | 749 |  |  | 743 |  |
| 4.75% Senior Notes due June 2023 |  | 951 |  |  | 897 |  |  | 951 |  |  | 942 |  |
| 4.875% Senior Notes due March 2024 |  | 497 |  |  | 460 |  |  | 497 |  |  | 489 |  |
| 4.75% Senior Notes due January 2025 |  | 975 |  |  | 881 |  |  | 975 |  |  | 936 |  |
| 4.875% Senior Notes due June 2027 |  | 695 |  |  | 590 |  |  | 695 |  |  | 650 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 385 |  |  | 489 |  |  | 441 |  |
|  |  | $ | 4,356 |  |  | $ | 3,933 |  |  | $ | 4,855 |  |  | $ | 4,702 |  |
| Less: debt issuance costs |  | (32 | ) |  | — |  |  | (36 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 4,324 |  |  | $ | 3,933 |  |  | $ | 4,819 |  |  | $ | 4,702 |  |
| Less: current portion of long-term debt, net of debt issuance costs |  | — |  |  | — |  |  | (499 | ) |  | (501 | ) |
| Long-term debt, less current portion |  | $ | 4,324 |  |  | $ | 3,933 |  |  | $ | 4,320 |  |  | $ | 4,201 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-04-30):
[0001193125-19-129284:note_history:20]
At March 29, 2019, future principal payments on long-term debt were as follows (in millions):
  (was, 2019-02-04, similarity 0.9492):
[0001193125-19-027007:note_history:20]
At December 28, 2018, future principal payments on long-term debt were as follows (in millions):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-04-30):
[0001193125-19-129284:note_history:21]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in million) |  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,568 |  |  | $ | 1,971 |  |  | $ | 5,571 |  |  | $ | 5,801 |  |
| Distributors |  | 411 |  |  | 477 |  |  | 1,388 |  |  | 1,406 |  |
| Retailers |  | 334 |  |  | 355 |  |  | 1,060 |  |  | 1,142 |  |
| Total |  | $ | 2,313 |  |  | $ | 2,803 |  |  | $ | 8,019 |  |  | $ | 8,349 |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |
| Americas |  | $ | 796 |  |  | $ | 912 |  |  | $ | 2,533 |  |  | $ | 2,700 |  |
| EMEA |  | 448 |  |  | 522 |  |  | 1,563 |  |  | 1,561 |  |
| Asia Pacific |  | 1,069 |  |  | 1,369 |  |  | 3,923 |  |  | 4,088 |  |
| Total |  | $ | 2,313 |  |  | $ | 2,803 |  |  | $ | 8,019 |  |  | $ | 8,349 |  |
  (was, 2019-02-04, similarity 0.9139):
[0001193125-19-027007:note_history:21]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in million) |  | December 28, 2018 |  | December 29, 2017 |  | December 28, 2018 |  | December 29, 2017 |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,865 |  |  | $ | 1,996 |  |  | $ | 4,003 |  |  | $ | 3,830 |  |
| Distributors |  | 443 |  |  | 495 |  |  | 977 |  |  | 929 |  |
| Retailers |  | 407 |  |  | 423 |  |  | 726 |  |  | 787 |  |
| Total |  | $ | 2,715 |  |  | $ | 2,914 |  |  | $ | 5,706 |  |  | $ | 5,546 |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |
| Americas |  | $ | 731 |  |  | $ | 913 |  |  | $ | 1,737 |  |  | $ | 1,788 |  |
| EMEA |  | 598 |  |  | 567 |  |  | 1,115 |  |  | 1,039 |  |
| Asia Pacific |  | 1,386 |  |  | 1,434 |  |  | 2,854 |  |  | 2,719 |  |
| Total |  | $ | 2,715 |  |  | $ | 2,914 |  |  | $ | 5,706 |  |  | $ | 5,546 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-04-30):
[0001193125-19-129284:note_history:22]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in million) |  | March 29, 2019 |  | March 30, 2018 |  | March 29, 2019 |  | March 30, 2018 |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,568 |  |  | $ | 1,971 |  |  | $ | 5,571 |  |  | $ | 5,801 |  |
| Distributors |  | 411 |  |  | 477 |  |  | 1,388 |  |  | 1,406 |  |
| Retailers |  | 334 |  |  | 355 |  |  | 1,060 |  |  | 1,142 |  |
| Total |  | $ | 2,313 |  |  | $ | 2,803 |  |  | $ | 8,019 |  |  | $ | 8,349 |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |
| Americas |  | $ | 796 |  |  | $ | 912 |  |  | $ | 2,533 |  |  | $ | 2,700 |  |
| EMEA |  | 448 |  |  | 522 |  |  | 1,563 |  |  | 1,561 |  |
| Asia Pacific |  | 1,069 |  |  | 1,369 |  |  | 3,923 |  |  | 4,088 |  |
| Total |  | $ | 2,313 |  |  | $ | 2,803 |  |  | $ | 8,019 |  |  | $ | 8,349 |  |
  (was, 2019-02-04, similarity 0.9139):
[0001193125-19-027007:note_history:22]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in million) |  | December 28, 2018 |  | December 29, 2017 |  | December 28, 2018 |  | December 29, 2017 |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 1,865 |  |  | $ | 1,996 |  |  | $ | 4,003 |  |  | $ | 3,830 |  |
| Distributors |  | 443 |  |  | 495 |  |  | 977 |  |  | 929 |  |
| Retailers |  | 407 |  |  | 423 |  |  | 726 |  |  | 787 |  |
| Total |  | $ | 2,715 |  |  | $ | 2,914 |  |  | $ | 5,706 |  |  | $ | 5,546 |  |
| Revenues by Geography(1) |  |  |  |  |  |  |  |  |
| Americas |  | $ | 731 |  |  | $ | 913 |  |  | $ | 1,737 |  |  | $ | 1,788 |  |
| EMEA |  | 598 |  |  | 567 |  |  | 1,115 |  |  | 1,039 |  |
| Asia Pacific |  | 1,386 |  |  | 1,434 |  |  | 2,854 |  |  | 2,719 |  |
| Total |  | $ | 2,715 |  |  | $ | 2,914 |  |  | $ | 5,706 |  |  | $ | 5,546 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-04-30):
[0001193125-19-129284:note_history:23]
The Company records estimated variable consideration at the time of revenue recognition as a reduction to net revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer’s volume of purchases from Seagate or other agreed upon rebate programs. For the distribution and retailing channel, these sales incentive programs typically involve estimating the most likely amount of rebates related to a customer’s level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Marketing development program costs are accrued and recorded as a reduction to revenue at the same time that the related revenue is recognized.
  (was, 2019-02-04, similarity 0.9919):
[0001193125-19-027007:note_history:23]
The Company records estimated variable consideration at the time of revenue recognition as a reduction to net revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer’s volume of purchases from Seagate or other agreed upon rebate programs. For the distribution and retailing channel, these programs typically involve estimating the most likely amount of rebates related to a customer’s level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Marketing development program costs are accrued and recorded as a reduction to revenue at the same time that the related revenue is recognized.

- removed (2019-04-30):
[0001193125-19-027007:note_history:24]
Practical Expedient and Exemptions


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2019-04-30):
[0001193125-19-129284:note_history:25]
On April 30, 2019, the Company’s Board of Directors declared a quarterly cash dividend of $0.63 per share, which will be payable on July 3, 2019 to shareholders of record as of the close of business on June 19, 2019.

- removed (2019-04-30):
[0001193125-19-027007:note_history:26]
On February 4, 2019, the Company’s Board of Directors declared a quarterly cash dividend of $0.63 per share, which will be payable on April 3, 2019 to shareholders of record as of the close of business on March 20, 2019.
