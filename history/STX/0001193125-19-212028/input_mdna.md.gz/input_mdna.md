# STX MD&A — 0001193125-19-212028


## mdna

[0001193125-19-212028:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001193125-19-212028:mdna:2]
The following is a discussion of the Company’s financial condition, changes in financial condition and results of operations for the fiscal years
ended June 28, 2019, June 29, 2018 and June 30, 2017.

[0001193125-19-212028:mdna:3]
You should read this discussion in conjunction with “Item 6.
Selected Financial Data” and “Item 8. Financial Statements and Supplementary Data” included elsewhere in this Annual Report on Form 10-K. Except as noted, references to any fiscal year mean
the twelve-month period ending on the Friday closest to June 30 of that year. Accordingly, fiscal year 2019 comprised 52 weeks and ended on June 28, 2019. Fiscal year 2018 comprised 52 weeks and ended on June 29, 2018. Fiscal
year 2017 comprised 52 weeks and ended on June 30, 2017. Fiscal year 2020 will be comprised of 53 weeks and will end on July 3, 2020. Fiscal year 2026 will also be comprised of 53 weeks and will end on July 3, 2026.

[0001193125-19-212028:mdna:4]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is provided in addition to the
accompanying consolidated financial statements and notes to assist readers in understanding our results of operations, financial condition and cash flows. Our MD&A is organized as follows:

[0001193125-19-212028:mdna:5]
|  | • |  | Fiscal Year 2019 Summary. Overview of financial and other highlights affecting us in fiscal year 2019. |

[0001193125-19-212028:mdna:6]
|  | • |  | Results of Operations. Analysis of our financial results comparing fiscal years 2019 and 2018 to the prior-year periods. |

[0001193125-19-212028:mdna:7]
|  | • |  | Liquidity and Capital Resources. Analysis of changes in our balance sheets and cash flows, and discussion of our financial condition including potential sources of liquidity. |

[0001193125-19-212028:mdna:8]
|  | • |  | Contractual Obligations and Off-Balance Sheet Arrangements. Overview of contractual obligations and contingent liabilities and commitments outstanding as of June 28, 2019 and an explanation of off-balance sheet arrangements. |

[0001193125-19-212028:mdna:9]
|  | • |  | Critical Accounting Estimates. Accounting estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results. |

[0001193125-19-212028:mdna:10]
|  | • |  | For an overview of our business, see “Part I—Item 1. Business—Overview.” |

[0001193125-19-212028:mdna:11]
Fiscal Year 2019 Summary

[0001193125-19-212028:mdna:12]
During fiscal year 2019, we shipped
347 exabytes of HDD storage capacity. We generated revenue of $10.4 billion and gross margins of 28% and our operating cash flow was $1.8 billion. We received $1.3 billion from Toshiba Memory Holdings Corporation (“TMHC”,
formerly known as “K.K. Pangea”) for the redemption of all of the outstanding shares of non-convertible preferred stock of TMHC held by us. We repurchased approximately 21 million of our
ordinary shares for $963 million, paid $819 million for the repurchase of certain of our outstanding debt and paid $713 million in dividends. We entered into a new senior unsecured revolving credit facility (the “2019 Revolving
Credit Facility”) and have $1.5 billion available as of June 28, 2019.

[0001193125-19-212028:mdna:13]
Results of Operations

[0001193125-19-212028:mdna:14]
We list in the tables below summarized information from our Consolidated Statements of Operations by dollar amounts and as a percentage of revenue:

[0001193125-19-212028:mdna:15]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 28,2019 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| Revenue |  | $ | 10,390 |  |  | $ | 11,184 |  |  | $ | 10,771 |  |
| Cost of revenue |  |  | 7,458 |  |  |  | 7,820 |  |  |  | 7,597 |  |
| Gross margin |  |  | 2,932 |  |  |  | 3,364 |  |  |  | 3,174 |  |
| Product development |  |  | 991 |  |  |  | 1,026 |  |  |  | 1,232 |  |
| Marketing and administrative |  |  | 453 |  |  |  | 562 |  |  |  | 606 |  |
| Amortization of intangibles |  |  | 23 |  |  |  | 53 |  |  |  | 104 |  |
| Restructuring and other, net |  |  | (22 | ) |  |  | 89 |  |  |  | 178 |  |
| Income from operations |  |  | 1,487 |  |  |  | 1,634 |  |  |  | 1,054 |  |
| Other expense, net |  |  | (115 | ) |  |  | (216 | ) |  |  | (239 | ) |
| Income before income taxes |  |  | 1,372 |  |  |  | 1,418 |  |  |  | 815 |  |
| (Benefit) provision for income taxes |  |  | (640 | ) |  |  | 236 |  |  |  | 43 |  |
| Net income |  | $ | 2,012 |  |  | $ | 1,182 |  |  | $ | 772 |  |

[0001193125-19-212028:mdna:16]
|  |  | Fiscal Years Ended |  |
|  |  | June 28,2019 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| Revenue |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |
| Cost of revenue |  |  | 72 |  |  |  | 70 |  |  |  | 71 |  |
| Gross margin |  |  | 28 |  |  |  | 30 |  |  |  | 29 |  |
| Product development |  |  | 10 |  |  |  | 9 |  |  |  | 11 |  |
| Marketing and administrative |  |  | 4 |  |  |  | 5 |  |  |  | 5 |  |
| Amortization of intangibles |  |  | — |  |  |  | — |  |  |  | 1 |  |
| Restructuring and other, net |  |  | — |  |  |  | 1 |  |  |  | 2 |  |
| Income from operations |  |  | 14 |  |  |  | 15 |  |  |  | 10 |  |
| Other expense, net |  |  | (1 | ) |  |  | (2 | ) |  |  | (2 | ) |
| Income before income taxes |  |  | 13 |  |  |  | 13 |  |  |  | 8 |  |
| (Benefit) provision for income taxes |  |  | (6 | ) |  |  | 2 |  |  |  | 1 |  |
| Net income |  |  | 19 | % |  |  | 11 | % |  |  | 7 | % |

[0001193125-19-212028:mdna:17]
The following table summarizes information regarding consolidated revenue by channel and geography, HDD
price per terabyte and HDD exabytes shipped:

[0001193125-19-212028:mdna:18]
|  |  | Fiscal Years Ended |  |
|  |  | June 28,2019 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| Revenue by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  |  | 70 | % |  |  | 70 | % |  |  | 70 | % |
| Distributors |  |  | 17 | % |  |  | 17 | % |  |  | 17 | % |
| Retailers |  |  | 13 | % |  |  | 13 | % |  |  | 13 | % |
| Revenue by Geography (%) (1) |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  |  | 32 | % |  |  | 33 | % |  |  | 33 | % |
| EMEA |  |  | 19 | % |  |  | 18 | % |  |  | 20 | % |
| Asia Pacific |  |  | 49 | % |  |  | 49 | % |  |  | 47 | % |
| HDD Price per Terabyte |  | $ | 30 |  |  | $ | 33 |  |  | $ | 41 |  |
| HDD Exabytes Shipped |  |  | 347 |  |  |  | 338 |  |  |  | 263 |  |

[0001193125-19-212028:mdna:19]
| (1) | Revenue is attributed to countries based on the bill from location. |

[0001193125-19-212028:mdna:20]
Fiscal Year 2019 Compared to Fiscal Year 2018

[0001193125-19-212028:mdna:21]
Revenue

[0001193125-19-212028:mdna:22]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 28,2019 |  |  | June 29,2018 |  |  | Change |  |  | %Change |  |
| Revenue |  | $ | 10,390 |  |  | $ | 11,184 |  |  | $ | (794 | ) |  |  | (7 | )% |

[0001193125-19-212028:mdna:23]
Revenue in fiscal year 2019 decreased approximately 7% or $0.8 billion, from fiscal year 2018, primarily due to less
favorable market conditions during the first half of the fiscal year and price erosion, partially offset by an increase in exabytes shipped.

[0001193125-19-212028:mdna:24]
Cost of
Revenue and Gross Margin

[0001193125-19-212028:mdna:25]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 28,2019 |  |  | June 29,2018 |  |  | Change |  |  | %Change |  |
| Cost of revenue |  | $ | 7,458 |  |  | $ | 7,820 |  |  | $ | (362 | ) |  |  | (5 | )% |
| Gross margin |  |  | 2,932 |  |  |  | 3,364 |  |  |  | (432 | ) |  |  | (13 | )% |
| Gross margin percentage |  |  | 28 | % |  |  | 30 | % |  |  |  |  |  |  |  |  |

[0001193125-19-212028:mdna:26]
For fiscal year 2019, gross margin as a percentage of revenue decreased compared to the prior fiscal year due to price
erosion partially offset by improved product mix.

[0001193125-19-212028:mdna:27]
Operating Expenses

[0001193125-19-212028:mdna:28]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 28,2019 |  |  | June 29,2018 |  |  | Change |  |  | %Change |  |
| Product development |  | $ | 991 |  |  | $ | 1,026 |  |  | $ | (35 | ) |  |  | (3 | )% |
| Marketing and administrative |  |  | 453 |  |  |  | 562 |  |  |  | (109 | ) |  |  | (19 | )% |
| Amortization of intangibles |  |  | 23 |  |  |  | 53 |  |  |  | (30 | ) |  |  | (57 | )% |
| Restructuring and other, net |  |  | (22 | ) |  |  | 89 |  |  |  | (111 | ) |  |  | (125 | )% |
| Operating expenses |  | $ | 1,445 |  |  | $ | 1,730 |  |  | $ | (285 | ) |  |  |  |  |

[0001193125-19-212028:mdna:29]
Product Development Expense. Product development expenses for fiscal year 2019 decreased by $35 million from
fiscal year 2018 primarily due to a $38 million decrease in variable compensation expense, partially offset by a $5 million increase in other employee benefits.

[0001193125-19-212028:mdna:30]
Marketing and Administrative Expense. Marketing and administrative expenses for fiscal year 2019 decreased by $109 million from fiscal year
2018 primarily due to a $27 million decrease in salaries and related benefits as a result of the restructuring of our workforce in prior periods, a $44 million decrease in other general expenses due to related operational efficiencies, a
$24 million decrease in variable compensation expense and a $14 million decrease in share-based compensation expense.

[0001193125-19-212028:mdna:31]
Amortization of
Intangibles. Amortization of intangibles for fiscal year 2019 decreased by $30 million, as compared to fiscal year 2018, due to certain intangible assets reaching the end of their useful lives.

[0001193125-19-212028:mdna:32]
Restructuring and Other, net. Restructuring and other, net for fiscal year 2019 was comprised primarily of a $75 million net gain from the
sale of a certain property partially offset by charges related to a voluntary early exit program.

[0001193125-19-212028:mdna:33]
Restructuring and other, net for fiscal year 2018
was comprised primarily of restructuring charges to reduce our workforce by approximately 1,100 employees. Restructuring and other, net also included a gain of $25 million from the sale of certain properties during fiscal year 2018.

[0001193125-19-212028:mdna:34]
Other expense, net

[0001193125-19-212028:mdna:35]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 28,2019 |  |  | June 29,2018 |  |  | Change |  |  | %Change |  |
| Other expense, net |  | $ | (115 | ) |  | $ | (216 | ) |  | $ | 101 |  |  |  | (47 | )% |

[0001193125-19-212028:mdna:36]
Other expense, net for fiscal year 2019 decreased by $101 million, as compared to fiscal year 2018 mainly due to a
$56 million increase in interest income on our investment in a debt security, a $37 million net increase in gains on settlement of derivatives and a $13 million net decrease in interest expense due to the repayment of certain
long-term debt.

[0001193125-19-212028:mdna:37]
Income Taxes

[0001193125-19-212028:mdna:38]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 28,2019 |  |  | June 29,2018 |  |  | Change |  |  | %Change |  |
| (Benefit) provision for income taxes |  | $ | (640 | ) |  | $ | 236 |  |  | $ | (876 | ) |  |  | (371 | )% |

[0001193125-19-212028:mdna:39]
We recorded an income tax benefit of $640 million for fiscal year 2019 compared to an income tax provision of
$236 million for fiscal year 2018. Our fiscal year 2019 income tax benefit included a net tax benefit of $761 million primarily

[0001193125-19-212028:mdna:40]
associated with the release of valuation allowance on deferred tax assets driven by improvements in our profitability outlook in the U.S., including our efforts to structurally and operationally
align our EDS business with the rest of the Company. Our fiscal year 2018 income tax provision included approximately $204 million of tax expense associated with the revaluation of U.S. deferred tax assets as a result of the enactment of the
U.S. Tax Cuts and Jobs Act (“the Tax Act”) on December 22, 2017, offset by the reversal of previously recorded unrecognized tax benefits of $7 million, and certain non-recurring items.

[0001193125-19-212028:mdna:41]
Our Irish tax resident parent holding company owns various U.S. and non-U.S. subsidiaries that operate in
multiple non-Irish income tax jurisdictions. Our worldwide operating income is either subject to varying rates of income tax or is exempt from income tax due to tax incentive programs we operate under in
Malaysia, Singapore and Thailand. These tax incentives are scheduled to expire in whole or in part at various dates through 2025. Certain tax incentives may be extended if specific conditions are met.

[0001193125-19-212028:mdna:42]
Our income tax benefit recorded for fiscal year 2019 differed from the provision for income taxes that would be derived by applying the Irish statutory
rate of 25% to income before income taxes, primarily due to the net effect of (i) a decrease in valuation allowance for certain deferred tax assets, primarily driven by improvements in our profitability outlook in the U.S.; and (ii) tax
benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland. Our income tax provision recorded for
fiscal year 2018 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland; and (ii) a reduction in the net U.S. deferred tax assets
associated with revaluation to a lower U.S. tax rate.

[0001193125-19-212028:mdna:43]
Based on our non-U.S. ownership structure and subject
to (i) potential future increases in our valuation allowance for deferred tax assets; and (ii) a future change in our intention to indefinitely reinvest earnings from our subsidiaries outside of Ireland, we anticipate that our effective
tax rate in future periods will generally be less than the Irish statutory rate.

[0001193125-19-212028:mdna:44]
The Tax Act significantly revised U.S. corporate income tax law by,
among other things, lowering U.S. corporate income tax rates from 35% to 21%, implementing a territorial tax system, and imposing a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries.

[0001193125-19-212028:mdna:45]
The U.S. tax law changes, including limitations on various business deductions such as
executive compensation under Internal Revenue Code §162(m), will not materially impact our current tax expense in the short-term due to our large net operating loss and tax credit carryovers. The Tax Act’s new international rules,
including Global Intangible Low-Taxed Income (“GILTI”), Foreign Derived Intangible Income (“FDII”) and Base Erosion Anti-Avoidance Tax (“BEAT”), are effective beginning in fiscal
year 2019. For fiscal year 2019, we have included these effects of the Tax Act in our financial statements and concluded the impact is not material.

[0001193125-19-212028:mdna:46]
As of the quarter ended September 28, 2018, pursuant to SEC Staff Accounting Bulletin (“SAB”) 118 (regarding the application of Accounting
Standards Codification (“ASC”) 740—Income Taxes associated with the enactment of the Tax Act), we had considered SAB 118 and concluded our accounting under ASC 740 for the provisions of the Tax Act was complete. There were no
adjustments deemed necessary in fiscal year 2019.

[0001193125-19-212028:mdna:47]
Fiscal Year 2018 Compared to Fiscal Year 2017

[0001193125-19-212028:mdna:48]
Revenue

[0001193125-19-212028:mdna:49]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 29,2018 |  |  | June 30,2017 |  |  | Change |  |  | %Change |  |
| Revenue |  | $ | 11,184 |  |  | $ | 10,771 |  |  | $ | 413 |  |  |  | 4% |  |

[0001193125-19-212028:mdna:50]
Revenue in fiscal year 2018 increased approximately 4% or $0.4 billion, from fiscal year 2017, as a result of an
increase in exabytes shipped driven primarily by higher demand for our high capacity HDD product portfolio, partially offset by price erosion.

[0001193125-19-212028:mdna:51]
Cost of Revenue and Gross Margin

[0001193125-19-212028:mdna:52]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 29,2018 |  |  | June 30,2017 |  |  | Change |  |  | %Change |  |
| Cost of revenue |  | $ | 7,820 |  |  | $ | 7,597 |  |  | $ | 223 |  |  |  | 3% |  |
| Gross margin |  |  | 3,364 |  |  |  | 3,174 |  |  |  | 190 |  |  |  | 6% |  |
| Gross margin percentage |  |  | 30 | % |  |  | 29 | % |  |  |  |  |  |  |  |  |

[0001193125-19-212028:mdna:53]
For fiscal year 2018, gross margin as a percentage of revenue increased by 100 basis points compared to the prior fiscal
year due to favorable product mix and improved factory utilization as a result of higher demand for our high capacity HDD product portfolio, partially offset by price erosion.

[0001193125-19-212028:mdna:54]
Operating Expenses

[0001193125-19-212028:mdna:55]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 29,2018 |  |  | June 30,2017 |  |  | Change |  |  | %Change |  |
| Product development |  | $ | 1,026 |  |  | $ | 1,232 |  |  | $ | (206 | ) |  |  | (17)% |  |
| Marketing and administrative |  |  | 562 |  |  |  | 606 |  |  |  | (44 | ) |  |  | (7)% |  |
| Amortization of intangibles |  |  | 53 |  |  |  | 104 |  |  |  | (51 | ) |  |  | (49)% |  |
| Restructuring and other, net |  |  | 89 |  |  |  | 178 |  |  |  | (89 | ) |  |  | (50)% |  |
| Operating expenses |  | $ | 1,730 |  |  | $ | 2,120 |  |  | $ | (390 | ) |  |  |  |  |

[0001193125-19-212028:mdna:56]
Product Development Expense. Product development expenses for fiscal year 2018 decreased by $206 million from
fiscal year 2017 primarily due to a $97 million decrease in salaries and related benefits as a result of the restructuring of our workforce in prior periods, an $83 million decrease due to related operational efficiencies and a
$26 million decrease due to impairment charges related to the closure of our Korea design center in fiscal year 2017, which did not recur in fiscal year 2018.

[0001193125-19-212028:mdna:57]
Marketing and Administrative Expense. Marketing and administrative expenses for fiscal year 2018 decreased by $44 million from fiscal year
2017 primarily due to a $54 million decrease in salaries and related benefits as a result of the restructuring of our workforce in prior periods, partially offset by an increase in other general expenses.

[0001193125-19-212028:mdna:58]
Amortization of Intangibles. Amortization of intangibles for fiscal year 2018 decreased by $51 million, as compared to fiscal year 2017,
due to certain intangible assets reaching the end of their useful lives.

[0001193125-19-212028:mdna:59]
Restructuring and Other, net. Restructuring and other, net for
fiscal year 2018 was comprised primarily of restructuring charges recorded during the fiscal quarters ended September 29, 2017 and December 29, 2017 to reduce our workforce by approximately 1,100 employees. Restructuring and other, net
also included a gain of $25 million from the sale of certain properties previously classified as held for sale.

[0001193125-19-212028:mdna:60]
Restructuring and other, net
for fiscal year 2017 was comprised of restructuring charges recorded during the fiscal quarters ended September 30, 2016 and March 31, 2017 to reduce our workforce by approximately 6,800 employees, as we continue to consolidate our global
footprint across Asia, EMEA and the Americas.

[0001193125-19-212028:mdna:61]
Other expense, net

[0001193125-19-212028:mdna:62]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 29,2018 |  |  | June 30,2017 |  |  | Change |  |  | %Change |  |
| Other expense, net |  | $ | (216 | ) |  | $ | (239 | ) |  | $ | 23 |  |  |  | (10 | )% |

[0001193125-19-212028:mdna:63]
Other expense, net for fiscal year 2018 decreased by $23 million, as compared to fiscal year 2017
due to a $26 million increase in interest income primarily driven by higher interest rates, a $9 million net decrease in losses related to strategic investments and a $6 million net decrease in losses due to favorable changes in
foreign currency exchange rates, partially offset by an $18 million net increase in interest expense due to the issuance of $1.25 billion of Senior Notes in fiscal year 2017 and reduced by the subsequent repurchase of certain debt.

[0001193125-19-212028:mdna:64]
Income Taxes

[0001193125-19-212028:mdna:65]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 29,2018 |  |  | June 30,2017 |  |  | Change |  |  | %Change |  |
| Provision for income taxes |  | $ | 236 |  |  | $ | 43 |  |  | $ | 193 |  |  |  | 449 | % |

[0001193125-19-212028:mdna:66]
We recorded an income tax provision of $236 million for fiscal year 2018 compared to an income tax provision of
$43 million for fiscal year 2017. Our fiscal year 2018 income tax provision included approximately $204 million of tax expense associated with the revaluation of U.S. deferred tax assets as a result of the enactment of the Tax Act on
December 22, 2017, offset by the reversal of previously recorded unrecognized tax benefits of $7 million, and certain non-recurring items. Our fiscal year 2017 income tax provision included
approximately $2 million of net tax expense associated with various non-recurring items.

[0001193125-19-212028:mdna:67]
Our income tax
provision recorded for fiscal year 2018 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland; and (ii) a reduction in the net U.S. deferred
tax assets associated with revaluation to a lower U.S. tax rate. Our income tax provision recorded for fiscal year 2017 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before
income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax incentive programs and are considered
indefinitely reinvested outside of Ireland; (ii) a decrease in valuation allowance for certain deferred tax assets; and (iii) permanent differences.

[0001193125-19-212028:mdna:68]
Liquidity and Capital Resources

[0001193125-19-212028:mdna:69]
The following sections discuss
our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of
purchase. Our short-term investments consist primarily of money market funds, time deposits and certificates of deposit. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our
cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of
cash have been and will continue to be sufficient to meet our cash needs for the next 12 months. We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term
investments and we do not believe the fair value of our short-term investments has significantly changed from the values reported as of June 28, 2019.

[0001193125-19-212028:mdna:70]
Cash and Cash Equivalents

[0001193125-19-212028:mdna:71]
|  |  | As of |  |
| (Dollars in millions) |  | June 28,2019 |  |  | June 29,2018 |  |  | Change |  |
| Cash and cash equivalents |  | $ | 2,220 |  |  | $ | 1,853 |  |  | $ | 367 |  |

[0001193125-19-212028:mdna:72]
Our cash and cash equivalents increased by $367 million from June 29, 2018 as a result of net cash flow of
$1.8 billion provided by operating activities and $1.3 billion cash inflows from the redemption of investment in non-convertible preferred stock of TMHC, offset by payments for capital expenditures
of $602 million, net cash outflows for repurchase of our ordinary

[0001193125-19-212028:mdna:73]
shares of $963 million, dividends paid out to shareholders of $713 million and net repayment of long-term debt of $574 million. The following table summarizes results from the
Consolidated Statement of Cash Flows for the periods indicated:

[0001193125-19-212028:mdna:74]
|  |  | Fiscal Years Ended |  |
| (Dollars in millions) |  | June 28,2019 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| Net cash flow provided by (used in): |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating activities |  | $ | 1,761 |  |  | $ | 2,113 |  |  | $ | 1,916 |  |
| Investing activities |  |  | 846 |  |  |  | (1,588 | ) |  |  | (459 | ) |
| Financing activities |  |  | (2,212 | ) |  |  | (1,211 | ) |  |  | (46 | ) |
| Effect of foreign currency exchange rates |  |  | (1 | ) |  |  | — |  |  |  | — |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 394 |  |  | $ | (686 | ) |  | $ | 1,411 |  |

[0001193125-19-212028:mdna:75]
Cash Provided by Operating Activities

[0001193125-19-212028:mdna:76]
Cash provided by operating activities for fiscal year 2019 was approximately $1.8 billion and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, a release of valuation allowance related to our U.S. deferred tax assets and:

[0001193125-19-212028:mdna:77]
|  | • |  | a decrease of $204 million in accounts receivable, primarily due to lower revenue; and |

[0001193125-19-212028:mdna:78]
|  | • |  | a decrease of $80 million in inventories, primarily due to a decrease in units built; partially offset by |

[0001193125-19-212028:mdna:79]
|  | • |  | a decrease of $268 million in accounts payable, primarily due to a decrease in direct material purchases; and |

[0001193125-19-212028:mdna:80]
|  | • |  | a decrease of $84 million in accrued employee compensation, primarily due to a decrease in our variable compensation expense. |

[0001193125-19-212028:mdna:81]
Cash provided by operating activities for fiscal year 2018 was approximately $2.1 billion and includes the effects
of net income adjusted for non-cash items including depreciation and amortization, deferred income taxes primarily due to the remeasurement of our U.S. deferred tax assets at the lower corporate tax rate,
share-based compensation and:

[0001193125-19-212028:mdna:82]
|  | • |  | an increase of $65 million in accounts payable, primarily due to timing of payments of capital expenditures; and |

[0001193125-19-212028:mdna:83]
|  | • |  | a decrease of $71 million in vendor receivables, primarily due to improved collections; partially offset by |

[0001193125-19-212028:mdna:84]
|  | • |  | an increase of $71 million in inventories, primarily due to an increase in units built. |

[0001193125-19-212028:mdna:85]
Cash provided by operating activities for fiscal year 2017 was approximately $1.9 billion and includes the effects of net income adjusted for non-cash items including depreciation and amortization, share-based compensation and:

[0001193125-19-212028:mdna:86]
|  | • |  | a decrease of $122 million in accounts receivable, primarily due to a decrease in revenue and improved collections; and |

[0001193125-19-212028:mdna:87]
|  | • |  | an increase of $121 million in accounts payable, primarily due to timing of payments for material purchases; partially offset by |

[0001193125-19-212028:mdna:88]
|  | • |  | an increase of $114 million in inventories, primarily due to an increase in units built in connection with our manufacturing footprint consolidating activities. |

[0001193125-19-212028:mdna:89]
Cash Provided by (Used in) Investing Activities

[0001193125-19-212028:mdna:90]
In fiscal year 2019, we received $0.8 billion for net cash investing activities, which was primarily due to proceeds of $1.3 billion from the
redemption of an investment in non-convertible preferred stock of TMHC and the proceeds of $144 million primarily from the sale of certain properties, partially offset by the payments for the purchase of
property, equipment and leasehold improvements of approximately $602 million.

[0001193125-19-212028:mdna:91]
In fiscal year 2018, we used $1.6 billion for net cash investing activities, which was primarily
due to our investment in the TMHC debt security of $1.3 billion and the payments for the purchase of property, equipment and leasehold improvements of approximately $366 million, partially offset by the proceeds of $69 million from
the sale of properties.

[0001193125-19-212028:mdna:92]
In fiscal year 2017, we used $459 million for net cash investing activities, which was primarily due to payments for
the purchase of property, equipment and leasehold improvements of approximately $434 million.

[0001193125-19-212028:mdna:93]
Cash Used in Financing Activities

[0001193125-19-212028:mdna:94]
Net cash used in financing activities of $2.2 billion for fiscal year 2019 was primarily attributable to the following activities:

[0001193125-19-212028:mdna:95]
|  | • |  | $963 million in payments for repurchases of ordinary shares; |

[0001193125-19-212028:mdna:96]
|  | • |  | $713 million in dividend payments; and |

[0001193125-19-212028:mdna:97]
|  | • |  | $574 million net repayment of long-term debt. |

[0001193125-19-212028:mdna:98]
Net cash used in financing activities of $1.2 billion for fiscal year 2018 was primarily attributable to the following activities:

[0001193125-19-212028:mdna:99]
|  | • |  | $726 million in dividend payments; |

[0001193125-19-212028:mdna:100]
|  | • |  | $361 million in payments for repurchases of ordinary shares; and |

[0001193125-19-212028:mdna:101]
|  | • |  | $214 million of repayments of long-term debt; offset by |

[0001193125-19-212028:mdna:102]
|  | • |  | $113 million in proceeds from the issuance of ordinary shares under employee stock plans. |

[0001193125-19-212028:mdna:103]
Net cash used in financing activities of $46 million for fiscal year 2017 was primarily attributable to the following activities:

[0001193125-19-212028:mdna:104]
|  | • |  | net proceeds of $1.2 billion received from issuance of $750 million of 4.25% Senior Notes due 2022 and $500 million of 4.875% Senior Notes due 2024; |

[0001193125-19-212028:mdna:105]
|  | • |  | $86 million in proceeds from the issuance of ordinary shares under employee stock plans; offset by |

[0001193125-19-212028:mdna:106]
|  | • |  | $561 million in dividend payments; |

[0001193125-19-212028:mdna:107]
|  | • |  | $460 million in payments for repurchases of ordinary shares; and |

[0001193125-19-212028:mdna:108]
|  | • |  | $316 million of redemption and repurchase of long-term debt. |

[0001193125-19-212028:mdna:109]
Liquidity Sources

[0001193125-19-212028:mdna:110]
Our primary sources of
liquidity as of June 28, 2019, consist of: (1) approximately $2.2 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.5 billion available for borrowing from our 2019 Revolving
Credit Facility.

[0001193125-19-212028:mdna:111]
On February 20, 2019, we terminated our senior unsecured revolving credit facility scheduled to expire on January 15,
2020, under which we were able to draw up to $700 million. Upon termination, we and our subsidiary Seagate HDD Cayman entered into the 2019 Revolving Credit Facility, which provides us with a $1.3 billion senior unsecured revolving credit
facility. On May 28, 2019, we increased our 2019 Revolving Credit Facility from $1.3 billion to $1.5 billion. The 2019 Revolving Credit Facility also allows us to increase the facility by up to an aggregate of $100 million
provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at least $25 million and (iii) the existing commitments under the facility receive 0.50% most favored nation
protection.

[0001193125-19-212028:mdna:112]
As of June 28, 2019, no borrowings were drawn and no letters of credit or swing line loans had been utilized under the 2019
Revolving Credit Facility.

[0001193125-19-212028:mdna:113]
The 2019 Revolving Credit Facility includes three financial covenants: (1) interest coverage ratio, (2) total
leverage ratio and (3) a minimum liquidity amount. The 2019 Revolting Credit Facility has a final maturity of February 20, 2024.

[0001193125-19-212028:mdna:114]
As of June 28, 2019, cash and cash equivalents held by
non-Irish subsidiaries was $2.2 billion. This amount is potentially subject to taxation in Ireland upon repatriation by means of a dividend into our Irish parent. However, it is our intent to
indefinitely reinvest earnings of non-Irish subsidiaries outside of Ireland and our current plans do not demonstrate a need to repatriate such earnings by means of a taxable Irish dividend. Should funds be
needed in the Irish parent company and should we be unable to fund parent company activities through means other than a taxable Irish dividend, we would be required to accrue and pay Irish taxes on such dividend.

[0001193125-19-212028:mdna:115]
We believe that our sources of cash will be sufficient to fund our operations and meet our cash requirements for at least the next 12 months.

[0001193125-19-212028:mdna:116]
Cash Requirements and Commitments

[0001193125-19-212028:mdna:117]
Our liquidity
requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend and any future strategic
investments. Our ability to fund these requirements will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other
factors, some of which are beyond our control.

[0001193125-19-212028:mdna:118]
On July 30, 2019, our Board of Directors declared a quarterly cash dividend of $0.63 per share,
which will be payable on October 9, 2019 to shareholders of record as of the close of business on September 25, 2019.

[0001193125-19-212028:mdna:119]
As of June 28,
2019, we were in compliance with all of the covenants under our debt agreements. Based on our current outlook, we expect to be in compliance with the covenants in our debt agreements over the next 12 months.

[0001193125-19-212028:mdna:120]
The carrying value of our debt as of June 28, 2019 and June 29, 2018 was $4.3 billion and $4.8 billion, respectively. The table below
presents the principal amounts of our outstanding debt:

[0001193125-19-212028:mdna:121]
|  |  | As of |  |
| (Dollars in millions) |  | June 28,2019 |  |  | June 29,2018 |  |  | Change |  |
| 3.75% Senior Notes due November 2018 |  | $ | — |  |  | $ | 499 |  |  | $ | (499 | ) |
| 4.25% Senior Notes due March 2022 |  |  | 750 |  |  |  | 750 |  |  |  | — |  |
| 4.75% Senior Notes due June 2023 |  |  | 941 |  |  |  | 951 |  |  |  | (10 | ) |
| 4.875% Senior Notes due March 2024 |  |  | 500 |  |  |  | 500 |  |  |  | — |  |
| 4.75% Senior Notes due January 2025 |  |  | 920 |  |  |  | 975 |  |  |  | (55 | ) |
| 4.875% Senior Notes due June 2027 |  |  | 690 |  |  |  | 697 |  |  |  | (7 | ) |
| 5.75% Senior Notes due December 2034 |  |  | 490 |  |  |  | 490 |  |  |  | — |  |
|  |  | $ | 4,291 |  |  | $ | 4,862 |  |  | $ | (571 | ) |

[0001193125-19-212028:mdna:122]
From time to time, we may repurchase any of our outstanding ordinary shares through private, open market, or broker
assisted purchases, tender offers, or other means. During fiscal year 2019, we repurchased approximately 22 million of our ordinary shares including shares withheld for statutory tax withholdings related to vesting of employee equity awards.
See “Item 5. Market for Registrant’s Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities-Repurchases of Our Equity Securities.” As of June 28, 2019, $2.2 billion remained available
for repurchase under our existing repurchase authorization limit. All repurchases are effected as redemptions in accordance with our Articles of Association.

[0001193125-19-212028:mdna:123]
For fiscal year 2020, we expect capital expenditures to be within our long-term targeted range of 6% to 8% of revenue. We require substantial amounts of
cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We will continue to evaluate and manage the retirement and replacement
of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market
purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001193125-19-212028:mdna:124]
Contractual Obligations and Commitments

[0001193125-19-212028:mdna:125]
Our contractual cash obligations and commitments as of June 28, 2019, are summarized in the table below:

[0001193125-19-212028:mdna:126]
|  |  |  |  |  | Fiscal Year(s) |  |
| (Dollars in millions) |  | Total |  |  | 2020 |  |  | 2021-2022 |  |  | 2023-2024 |  |  | Thereafter |  |
| Contractual Cash Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | $ | 4,291 |  |  | $ | — |  |  | $ | 750 |  |  | $ | 1,441 |  |  | $ | 2,100 |  |
| Interest payments on debt |  |  | 1,364 |  |  |  | 206 |  |  |  | 412 |  |  |  | 305 |  |  |  | 441 |  |
| Purchase obligations (1) |  |  | 1,382 |  |  |  | 1,170 |  |  |  | 35 |  |  |  | 53 |  |  |  | 124 |  |
| Operating leases (2) |  |  | 125 |  |  |  | 20 |  |  |  | 26 |  |  |  | 13 |  |  |  | 66 |  |
| Capital expenditures |  |  | 322 |  |  |  | 299 |  |  |  | 23 |  |  |  | — |  |  |  | — |  |
| Other funding requirements (3) |  |  | 12 |  |  |  | 11 |  |  |  | 1 |  |  |  | — |  |  |  | — |  |
| Subtotal |  |  | 7,496 |  |  |  | 1,706 |  |  |  | 1,247 |  |  |  | 1,812 |  |  |  | 2,731 |  |
| Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit or bank guarantees |  |  | 105 |  |  |  | 93 |  |  |  | 1 |  |  |  | — |  |  |  | 11 |  |
| Total |  | $ | 7,601 |  |  | $ | 1,799 |  |  | $ | 1,248 |  |  | $ | 1,812 |  |  | $ | 2,742 |  |

[0001193125-19-212028:mdna:127]
| (1) | Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. |

[0001193125-19-212028:mdna:128]
| (2) | Includes total future minimum rent expense under non-cancelable leases for both occupied and vacated facilities (rent expense is shown net of sublease income). |

[0001193125-19-212028:mdna:129]
| (3) | Consists of funding requirements related to strategic commitments. |

[0001193125-19-212028:mdna:130]
As of June 28, 2019, we had a liability for unrecognized tax benefits and an accrual for the payment of related interest totaling $4 million,
none of which is expected to be settled within one year. Outside of one year, we are unable to make a reasonably reliable estimate of when cash settlement with a taxing authority will occur.

[0001193125-19-212028:mdna:131]
Off-Balance Sheet Arrangements

[0001193125-19-212028:mdna:132]
As of June 28, 2019, we did not have any material off-balance sheet arrangements (as defined in
Item 303(a)(4)(ii) of Regulation S-K).

[0001193125-19-212028:mdna:133]
Critical Accounting Policies and Estimates

[0001193125-19-212028:mdna:134]
The methods, estimates and judgments we use in applying our most critical accounting policies have a significant impact on the results we report in our
consolidated financial statements. The SEC has defined the most critical accounting policies as the ones that are most important to the portrayal of our financial condition and operating results, and require us to make our most difficult and
subjective judgments, often as a result of the need to make estimates of matters that are highly uncertain at the time of estimation. Based on this definition, our most critical accounting policies include: Revenue—Sales Program Accruals,
Warranty, Income taxes and Assessing Goodwill and Other Long-lived Assets for Impairment. Below, we discuss these policies further, as well as the estimates and judgments involved. We also have other accounting policies and accounting estimates
relating to uncollectible customer accounts, valuation of inventories, valuation of share-based payments and restructuring. We believe that these other accounting policies and accounting estimates either do not generally require us to make estimates
and judgments that are as difficult or as subjective, or it is less likely that they would have a material impact on our reported results of operations for a given period.

[0001193125-19-212028:mdna:135]
Revenue—Sales Program Accruals. We record estimated variable consideration at the time of revenue recognition as a reduction to revenue.
Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of
consideration expected to be received based on an OEM customer’s volume of purchases from us or other agreed upon rebate programs. For the distribution and retail channel, these sales incentive programs typically involve

[0001193125-19-212028:mdna:136]
estimating the most likely amount of rebates related to a customer’s level of sales, order size, advertising or point of sale activity as well as the expected value of price protection
adjustments based on historical analysis and forecasted pricing environment. In fiscal years 2019, 2018 and 2017, total sales programs were approximately 11% of gross revenue. Adjustments to revenues due to under or over accruals for sales programs
related to revenues reported in prior quarterly periods were less than 1% of gross revenue in fiscal years 2019, 2018 and 2017.

[0001193125-19-212028:mdna:137]
Warranty. We estimate probable product warranty costs at the time revenue is recognized. We generally provide a warranty on our products for
a period of 1 to 5 years. Our warranty provision considers estimated product failure rates and trends (including the timing of product returns during the warranty periods), and estimated repair or replacement costs related to product quality issues,
if any. We also exercise judgment in estimating our ability to sell refurbished products. Our judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited experience with those products upon
which to base our warranty estimates.

[0001193125-19-212028:mdna:138]
Income Taxes. We make certain estimates and judgments in determining income tax expense for financial
statement purposes. These estimates and judgments occur in the calculation of tax credits, recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of
revenue and expense for income tax and financial statement purposes, as well as tax liabilities associated with uncertain tax positions. The calculation of tax liabilities involves uncertainties in the application of complex tax rules and the
potential for future adjustment of our uncertain tax positions by the Internal Revenue Service or other tax jurisdictions. If estimates of these tax liabilities are greater or less than actual results, an additional tax provision or benefit will
result. The deferred tax assets we record each period depend primarily on our ability to generate future taxable income in the United States and certain non-U.S. jurisdictions. Each period, we evaluate the
need for a valuation allowance for our deferred tax assets and, if necessary, adjust the valuation allowance so that net deferred tax assets are recorded only to the extent we conclude it is more likely than not that these deferred tax assets will
be realized. If our outlook for future taxable income changes significantly, our assessment of the need for, and the amount of, a valuation allowance may also change.

[0001193125-19-212028:mdna:139]
Assessing Goodwill and Other Long-lived Assets for Impairment. We perform a qualitative assessment in the fourth quarter of each fiscal year,
or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than
not reduce the fair value of a reporting unit below its carrying amount. Based on the qualitative assessment, if it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, then the Company is not
required to perform the quantitative goodwill impairment test. If it is determined in the qualitative assessment that the fair value of a reporting unit is more likely than not below its carrying amount, including goodwill, then we perform a
quantitative impairment test. The quantitative goodwill impairment test is performed by comparing the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit’s goodwill over its fair value
is recognized as an impairment loss, limited to the total amount of goodwill allocated to that reporting unit.

[0001193125-19-212028:mdna:140]
We evaluate other long-lived assets,
including property, equipment and leasehold improvements and other intangible assets subject to amortization, for recoverability whenever events or changes in circumstances indicate that the carrying values of those assets may not be recoverable. We
assess the recoverability of an asset group by determining if the carrying value of the asset group exceeds the sum of the projected undiscounted cash flows expected to result from the use and eventual disposition of the assets over the remaining
economic life of the primary asset in the asset group. If the recoverability assessment indicates that the carrying value of the asset group is not recoverable, we will estimate the fair value of the asset group and compare it to its carrying value.
The excess of the carrying value over the fair value is allocated pro rata to derive the adjusted carrying value of each asset in the asset group. The adjusted carrying value of each asset in the asset group is not reduced below its fair value.

[0001193125-19-212028:mdna:141]
Recent Accounting Pronouncements

[0001193125-19-212028:mdna:142]
See “Item 8. Financial
Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.
