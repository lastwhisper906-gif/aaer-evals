# STX notes — 0001193125-19-212028


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001193125-19-212028:notes:1]
Activity in the allowances for doubtful accounts is as follows:

[0001193125-19-212028:notes:2]
| (Dollars in millions) |  | Balance atBeginning ofPeriod |  | Charges(Credit) toOperations |  | Deductions (a) |  | Balance atEnd ofPeriod |
| Fiscal year ended June 30, 2017 |  | $ | 9 |  |  | (4 | ) |  | — |  |  | $ | 5 |  |
| Fiscal year ended June 29, 2018 |  | $ | 5 |  |  | — |  |  | (1 | ) |  | $ | 4 |  |
| Fiscal year ended June 28, 2019 |  | $ | 4 |  |  | — |  |  | — |  |  | $ | 4 |  |

[0001193125-19-212028:notes:3]
______________________________________________

[0001193125-19-212028:notes:4]
(a)	Uncollectible accounts written off, net of recoveries.


## stx:AssetsHeldForSalePolicyTextBlock

[0001193125-19-212028:notes:5]
Assets Held for Sale. The Company classifies its long-lived assets to be sold as held for sale in the period (i) it has approved and committed to a plan to sell the asset, (ii) the asset is available for immediate sale in its present condition, (iii) an active program to locate a buyer and other actions required to sell the asset have been initiated, (iv) the sale of the asset is probable, (v) the asset is being actively marketed for sale at a price that is reasonable in relation to its current fair value and (vi) it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn. The Company initially measures a long-lived asset that is classified as held for sale at the lower of its carrying value or fair value less any costs to sell. Any loss resulting from this measurement is recognized in the period in which the held for sale criteria are met. Conversely, gains are not recognized on the sale of a long-lived asset until the date of sale. Upon designation as an asset held for sale, the Company stops recording depreciation expense on the asset. The Company assesses the fair value of a long-lived asset less any costs to sell at each reporting period and until the asset is no longer classified as held for sale.


## stx:ScheduleOfShareBasedPaymentAwardStockOptionAndEmployeeStockPurchasePlanValuationAssumptionsAndFairValueDisclosuresTableTextBlock

[0001193125-19-212028:notes:6]
The fair value of the Company's shares related to options and RSU granted to employees, shares issued from the ESPP and  PSUs subject to TSR/ROIC or AEPS conditions for fiscal years 2019, 2018 and 2017 were estimated using the following assumptions:

[0001193125-19-212028:notes:7]
|  | Fiscal Years |
|  | 2019 |  | 2018 |  | 2017 |
| Options |  |  |  |  |  |  |  |  |
| Expected term (in years) | 4.2 |  |  | 4.2 |  |  | 4.2 |  |
| Volatility | 39 - 40% |  |  | 38 - 42% |  |  | 38 - 42% |  |
| Weighted-average volatility | 39 | % |  | 40 | % |  | 39 | % |
| Expected dividend rate | 4.6 - 5.0% |  |  | 3.8 - 7.4% |  |  | 4.9 - 6.4% |  |
| Weighted-average expected dividend rate | 4.7 | % |  | 6.8 | % |  | 6.3 | % |
| Risk-free interest rate | 2.5 - 2.8% |  |  | 1.5 - 2.7% |  |  | 1.1 - 1.8% |  |
| Weighted-average fair value | $ | 11.49 |  |  | $ | 6.56 |  |  | $ | 6.83 |  |
| RSU |  |  |  |  |  |
| Expected term (in years) | 4.2 |  |  | 4.2 |  |  | 4.2 |  |
| Expected dividend rate | 4.1 - 6.4% |  |  | 3.5 - 7.4% |  |  | 4.6 - 7.7% |  |
| Weighted-average expected dividend rate | 4.68 | % |  | 7.11 | % |  | 6.4 | % |
| Weighted-average fair value | $ | 44.37 |  |  | $ | 26.69 |  |  | $ | 30.85 |  |
| ESPP |  |  |  |  |  |  |  |  |
| Expected term (in years) | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Volatility | 34 - 42% |  |  | 37 - 38% |  |  | 36 - 49% |  |
| Weighted-average volatility | 38 | % |  | 37 | % |  | 43 | % |
| Expected dividend rate | 4.8 - 5.6% |  |  | 4.6 - 7.6% |  |  | 5.6 - 7.8% |  |
| Weighted-average expected dividend rate | 5.2 | % |  | 6.5 | % |  | 6.8 | % |
| Risk-free interest rate | 2.2 - 2.4% |  |  | 1.1 - 1.6% |  |  | 0.4 - 0.6% |  |
| Weighted-average fair value | $ | 12.18 |  |  | $ | 10.10 |  |  | $ | 9.78 |  |
| PSUs subject to market condition |  |  |  |  |  |  |  |  |
| Expected term (in years) | 3.0 |  |  | 3.0 |  |  | 3.0 |  |
| Volatility | 46 | % |  | 45 | % |  | 41 - 42% |  |
| Weighted-average volatility | 46 | % |  | 45 | % |  | 41 | % |
| Expected dividend rate | 5.0 | % |  | 8.1 | % |  | 6.3 - 7.0% |  |
| Weighted-average expected dividend rate | 5.0 | % |  | 8.1 | % |  | 7.0 | % |
| Risk-free interest rate | 2.8 | % |  | 1.4 | % |  | 0.9 - 1.3% |  |
| Weighted-average fair value | $ | 46.38 |  |  | $ | 25.90 |  |  | $ | 32.41 |  |
| PSUs subject to an AEPS condition |  |  |  |  |  |
| Expected term (in years) | 4.2 |  |  | 4.2 |  |  | 4.2 |  |
| Expected dividend rate | 4.6 - 5.0% |  |  | 5.8 - 7.2% |  |  | 5.9 - 6.4% |  |
| Weighted-average expected dividend rate | 4.7 | % |  | 7.0 | % |  | 6.2 | % |
| Weighted-average fair value | $ | 43.92 |  |  | $ | 27.10 |  |  | $ | 31.61 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001193125-19-212028:notes:8]
Advertising Expense. The cost of advertising is expensed as incurred. Advertising costs were approximately $22 million, $28 million and $16 million in fiscal years 2019, 2018 and 2017, respectively.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001193125-19-212028:notes:9]
Summary of Significant Accounting Policies

[0001193125-19-212028:notes:10]
Cash and Cash Equivalents. The Company considers all highly liquid investments with a remaining maturity of 90 days or less at the time of purchase to be cash equivalents. Cash equivalents are carried at cost, which approximates fair value.

[0001193125-19-212028:notes:11]
Restricted Cash and Cash Equivalents. Restricted cash and cash equivalents represent cash and cash equivalents that are restricted as to withdrawal or use for other than current operations.

[0001193125-19-212028:notes:12]
Short-Term Investments. The Company has short-term investments that are primarily comprised of money market funds, time deposits and certificates of deposits. The Company has classified its marketable securities as available-for-sale and they are stated at fair value with unrealized gains and losses included in Accumulated other comprehensive loss, which is a component of Shareholders' Equity. The Company evaluates the available-for sale securities in an unrealized loss position for other-than-temporary impairment. Realized gains and losses are included in Other, net on the Company's Consolidated Statements of Operations. The cost of securities sold is based on the specific identification method.


## us-gaap:CommitmentsDisclosureTextBlock

[0001193125-19-212028:notes:13]
Commitments

[0001193125-19-212028:notes:14]
Unconditional Long-Term Purchase Obligations. As of June 28, 2019, the Company had unconditional long-term purchase obligations of approximately $212 million, primarily related to purchase minimum quarterly amounts of inventory components at fixed contractual prices. The Company expects the commitment to total $22 million, $13 million, $2 million, $51 million, $48 million and $76 million for fiscal years 2021, 2022, 2023, 2024, 2025 and thereafter, respectively.

[0001193125-19-212028:notes:15]
Leases. The Company leases certain property, facilities and equipment under non-cancelable lease agreements. Land and facility leases expire at various dates through 2082 and contain various provisions for rental adjustments including, in certain cases, a provision based on increases in the Consumer Price Index. In addition, certain leases provide for renewal of the lease at the Company's option at expiration of the lease. The lease term begins on the date of initial possession of the leased property for purposes of recognizing lease expense on a straight-line basis over the term of the lease. The Company does not assume renewals in its determination of the lease term unless the renewals are deemed to be reasonably assured at lease inception. All of the leases require the Company to pay property taxes, insurance and normal maintenance costs, which are expensed as incurred.

[0001193125-19-212028:notes:16]
Future minimum lease payments for operating leases (including accrued lease payments relating to restructuring plans) with initial or remaining terms of one year or more were as follows at June 28, 2019 (lease payments are shown net of sublease income):

[0001193125-19-212028:notes:17]
| Fiscal Years Ending |  | Operating Leases (Dollars in millions) |
| 2020 |  | $ | 20 |  |
| 2021 |  | 17 |  |
| 2022 |  | 9 |  |
| 2023 |  | 8 |  |
| 2024 |  | 5 |  |
| Thereafter |  | 66 |  |
| Total |  | $ | 125 |  |

[0001193125-19-212028:notes:18]
Total rent expense for all land, facility and equipment operating leases, net of sublease income, was $18 million, $22 million and $29 million for fiscal years 2019, 2018 and 2017, respectively.

[0001193125-19-212028:notes:19]
Unconditional Long-term Capital Expenditures.  As of June 28, 2019, the Company had $23 million unconditional long-term commitment primarily related to purchases of equipment.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001193125-19-212028:notes:20]
Comprehensive Income. The Company presents comprehensive income in a separate statement. Comprehensive income is comprised of net income and other gains and losses affecting equity that are excluded from net income.


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-19-212028:notes:21]
Basis of Presentation and Consolidation

[0001193125-19-212028:notes:22]
The consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

[0001193125-19-212028:notes:23]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its consolidated financial statements.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0001193125-19-212028:notes:24]
Restructuring Costs. The timing of recognition for severance costs depends on whether employees are required to render service until they are terminated in order to receive the termination benefits. If employees are required to render service until they are terminated in order to receive the termination benefits, a liability is recognized ratably over the future service period. Otherwise, a liability is recognized when management has committed to a restructuring plan and has communicated those actions to employees. Employee termination benefit costs covered by existing benefit arrangements are recognized when management has committed to a restructuring plan and the severance costs are probable and estimable.


## us-gaap:DebtDisclosureTextBlock

[0001193125-19-212028:notes:25]
Debt

[0001193125-19-212028:notes:26]
Revolving Credit Facility

[0001193125-19-212028:notes:27]
On February 20, 2019, the Company terminated its senior unsecured revolving credit facility scheduled to expire on January 15, 2020, under which the Company was able to draw up to $700 million. Upon termination, the Company and its subsidiary Seagate HDD Cayman entered into a new credit agreement (the “2019 Revolving Credit Facility”) which provides the Company with a $1.3 billion senior unsecured revolving credit facility. The term of the 2019 Revolving Credit Facility is through February 20, 2024. The loans made under the 2019 Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain other material subsidiaries of the Company fully and unconditionally guarantee the revolving credit facility. On May 28, 2019, the Company increased the 2019 Revolving Credit Facility from $1.3 billion to $1.5 billion primarily through the addition of two lenders under the facility. The 2019 Revolving Credit Facility also allows the Company to increase the facility by an additional $100 million, provided that (i) there has been, and will be after giving effect to such increase, no default, (ii) the increase is at least $25 million and (iii) the existing commitments under the facility receive 0.50% most favored nation protection. An aggregate amount of up to $75 million of the facility is available for the issuance of letters of credit, and an aggregate amount of up to $50 million of the facility is also available for swing line loans.

[0001193125-19-212028:notes:28]
The 2019 Revolving Credit Facility includes three financial covenants: (1) interest coverage ratio, (2) total leverage ratio and (3) a minimum liquidity amount. The Company was in compliance with the covenants as of June 28, 2019 and expects to be in compliance for the next 12 months.

[0001193125-19-212028:notes:29]
As of June 28, 2019, no borrowings were drawn and no letters of credit or swing line loans have been utilized under the 2019 Revolving Credit Facility.

[0001193125-19-212028:notes:30]
Long-Term Debt

[0001193125-19-212028:notes:31]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). On November 5, 2013, Seagate HDD Cayman, issued $800 million in aggregate principal amount of 3.75% Senior Notes. The Notes were fully and unconditionally guaranteed by the Company on a senior unsecured basis. The interest on the Notes was payable semi-annually on May 15 and November 15 of each year.  During fiscal years 2018 and 2017, the Company repurchased $211 million and $90 million, respectively, aggregate principal amount of the 2018 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. For fiscal years 2018 and 2017 the Company recorded a loss on the repurchase of approximately $4 million and $3 million, respectively, which is included in Other, net in the Company's Consolidated Statements of Operations. On November 15, 2018, the 2018 Notes matured and the Company repaid the entire outstanding principal amount of $499 million, plus accrued and unpaid interest.

[0001193125-19-212028:notes:32]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). On May 18, 2011, the Company’s subsidiary, Seagate HDD Cayman, completed the sale of $600 million aggregate principal amount of the 2021 Notes, in a private placement exempt from the registration requirements of the Securities Act of 1933, as amended. The obligations under the 2021 Notes were fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. The interest on the 2021 Notes was payable semi-annually on January 1 and July 1 of each year. During fiscal year 2017, the 2021 Notes were fully extinguished through redemption for cash at a premium to their principal amount of $158 million, plus accrued and unpaid interest. For fiscal year 2017, the Company recorded a loss on the redemption of approximately $5 million, which was included in Other, net in the Company’s Consolidated Statement of Operations.

[0001193125-19-212028:notes:33]
$750 million Aggregate Principal Amount of 4.25% Senior Notes due March 2022 (the “2022 Notes”). On February 3, 2017, Seagate HDD Cayman issued, in a private placement, $750 million in aggregate principal amount of 4.25% Senior Notes which will mature on March 1, 2022. The interest on the 2022 Notes is payable semi-annually on March 1 and September 1 of each year, commencing on September 1, 2017. At any time before February 1, 2022, Seagate HDD Cayman may redeem some or all of the 2022 Notes at a "make whole" redemption price, plus accrued and unpaid interest, if any. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the 2022 Notes redeemed, plus (2) the excess, if any, of (a) the sum of the present values of the remaining scheduled payments of principal and interest on the 2022 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 40 basis points, minus accrued and unpaid interest, if any, on the 2022 Notes being redeemed to, but excluding, the redemption date over (b) the principal amount of the 2022 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the 2022 Notes being redeemed to, but excluding, the redemption date. The issuer under the 2022 Notes is Seagate HDD Cayman, and the obligations under the 2022 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-19-212028:notes:34]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). On May 22, 2013, Seagate HDD Cayman, issued $1 billion in aggregate principal amount of 4.75% Senior Notes, which will mature on June 1, 2023, in a private placement. The obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The 2023 Notes are redeemable at the option of the Company in whole or in part, on not less than 30, nor more than 60 days' notice, at a "make-whole" premium redemption price. The "make-whole" redemption price will be equal to the greater of (1) 100% of the principal amount of the notes being redeemed, or (2) the sum of the present values of the remaining scheduled payments of principal and interest on the 2023 Notes being redeemed, discounted at the redemption date on a semi-annual basis at a rate equal to the sum of the applicable Treasury Rate plus 50 basis points. Accrued and unpaid interest, if any, will be paid to, but excluding, the redemption date. During fiscal years 2019 and 2017, the Company repurchased $10 million and $39 million, respectively, aggregate principal amount of its 2023 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The loss recorded on the repurchases in fiscal years 2019 and 2017 were immaterial, which is included in Other, net in the Company's Consolidated Statement of Operations.

[0001193125-19-212028:notes:35]
$500 million Aggregate Principal Amount of 4.875% Senior Notes due March 2024 (the “2024 Notes”). On February 3, 2017, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 4.875% Senior Notes which will mature on March 1, 2024. The interest on the 2024 Notes is payable semi-annually on March 1 and September 1 of each year, commencing on September 1, 2017. At any time before January 1, 2024, Seagate HDD Cayman may redeem some or all of the 2024 Notes at a "make whole" redemption price, plus accrued and unpaid interest, if any. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the 2024 Notes redeemed, plus (2) the excess, if any, of (a) the sum of the present values of the remaining scheduled payments of principal and interest on the 2024 Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 45 basis points, minus accrued and unpaid interest, if any, on the 2024 Notes being redeemed to, but excluding, the redemption date over (b) the principal amount of the 2024 Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the 2024 Notes being redeemed to, but excluding, the redemption date. The issuer under the 2024 Notes is Seagate HDD Cayman, and the obligations under the 2024 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001193125-19-212028:notes:36]
$1 billion Aggregate Principal amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). On May 28, 2014, Seagate HDD Cayman issued, in a private placement, $1 billion in aggregate principal amount of 4.75% Senior Notes due 2025, which will mature on January 1, 2025. The interest on the Notes will be payable in cash semiannually on January 1 and July 1 of each year, commencing on January 1, 2015. At any time, upon not less than 30 nor more than 60 days’ notice, Seagate HDD may redeem some or all of the Notes at a ‘‘make-whole’’ redemption price. The ‘‘make-whole’’ redemption price will be equal to the greater of (1) 100% of the principal amount of the Notes redeemed, and (2) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points. Accrued and unpaid interest, if any, will be paid to, but excluding, the redemption date. The Notes are fully and unconditionally guaranteed by the Company on a senior unsecured basis. During fiscal years 2019 and 2017, the Company repurchased $55 million and $20 million, respectively, aggregate principal amount of the 2025 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. For fiscal years 2019 and 2017 the Company recorded a gain on the repurchase of approximately $1 million and $1 million, respectively, which is included in Other, net in the Company's Consolidated Statements of Operations.

[0001193125-19-212028:notes:37]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June, 2027 (the “2027 Notes”). On May 14, 2015, Seagate HDD Cayman issued, in a private placement, $700 million in aggregate principal amount of 4.875% Senior Notes, which mature on June 1, 2027. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on December 1, 2015. At any time before March 1, 2027, Seagate HDD Cayman may redeem some or all of the Notes at a “make-whole” redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 40 basis points, minus accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date. At any time on or after March 1, 2027, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During fiscal year 2017, the Company repurchased $4 million aggregate principal amount of the 2027 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded an immaterial gain on the repurchase, which is included in Other, net in the Company's Consolidated Statements of Operations. During fiscal year 2019, the Company repurchased $6 million aggregate principal amount of the 2027 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded an immaterial gain on the repurchase, which is included in Other, net in the Company's Consolidated Statements of Operations.

[0001193125-19-212028:notes:38]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December, 2034 (the “2034 Notes”). On December 2, 2014, Seagate HDD Cayman issued, in a private placement, $500 million in aggregate principal amount of 5.75% Senior Notes, which will mature on December 1, 2034. The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, commencing on June 1, 2015. At any time before June 1, 2034, Seagate HDD Cayman may redeem some or all of the Notes at a “make-whole” redemption price. The ‘‘make-whole’’ redemption price will be equal to (1) 100% of the principal amount of the Notes redeemed, plus (2) the excess, if any of (x) the sum of the present values of the remaining scheduled payments of principal and interest on the Notes being redeemed, discounted to the redemption date on a semi-annual basis at a rate equal to the sum of the Treasury Rate plus 50 basis points, minus accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date over (y) the principal amount of the Notes being redeemed, plus (3) accrued and unpaid interest, if any, on the Notes being redeemed to, but excluding, the redemption date. At any time on or after June 1, 2034, the Company may redeem some or all of the Notes at a redemption price equal to 100% of the principal amount of the Notes redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During fiscal year 2016, the Company repurchased $10 million aggregate principal amount of its 2034 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded a gain on the repurchase of approximately $3 million, which was included in Other, net in the Company's Consolidated Statement of Operations.

[0001193125-19-212028:notes:39]
At June 28, 2019, future Principal payments on long-term debt were as follows (in millions):

[0001193125-19-212028:notes:40]
| Fiscal Year |  | Amount |
| 2020 |  | $ | — |  |
| 2021 |  | — |  |
| 2022 |  | 750 |  |
| 2023 |  | 941 |  |
| 2024 |  | 500 |  |
| Thereafter |  | 2,100 |  |
| Total |  | $ | 4,291 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0001193125-19-212028:notes:41]
The following table summarizes, by major type, the fair value and amortized cost of the Company's investments as of June 29, 2018:

[0001193125-19-212028:notes:42]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 621 |  |  | $ | — |  |  | $ | 621 |  |
| Time deposits and certificates of deposits |  | 395 |  |  | — |  |  | 395 |  |
| Total |  | $ | 1,016 |  |  | $ | — |  |  | $ | 1,016 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  | $ | 1,012 |  |
| Included in Other current assets |  |  |  |  |  |  | 4 |  |
| Total |  |  |  |  |  |  | $ | 1,016 |  |

[0001193125-19-212028:notes:43]
The following table summarizes, by major type, the fair value and amortized cost of the Company's investments as of June 28, 2019:

[0001193125-19-212028:notes:44]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale debt securities: |  |  |  |  |  |  |
| Money market funds |  | $ | 417 |  |  | $ | — |  |  | $ | 417 |  |
| Time deposits and certificates of deposit |  | 133 |  |  | — |  |  | 133 |  |
| Other debt securities |  | 7 |  |  | — |  |  | 7 |  |
| Total |  | $ | 557 |  |  | $ | — |  |  | $ | 557 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  | $ | 548 |  |
| Included in Other current assets |  |  |  |  |  |  | 2 |  |
| Included in Other assets, net |  |  |  |  |  | 7 |  |
| Total |  |  |  |  |  |  | $ | 557 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-19-212028:notes:45]
Derivative Financial Instruments

[0001193125-19-212028:notes:46]
The Company is exposed to foreign currency exchange rate, interest rate and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies. The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives in the Consolidated Balance Sheets at fair value. The changes in the fair value of highly effective designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments or are not assessed to be highly effective are adjusted to fair value through earnings. The amount of net unrealized gain and loss on cash flow hedges was not material as of June 28, 2019 and the amount of net unrealized gain on cash flow hedges was less than $1 million as of June 29, 2018.

[0001193125-19-212028:notes:47]
The Company de-designates its cash flow hedges when the forecasted hedged transactions affects earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company did not recognize any material amounts related to the loss of hedge designation on discontinued cash flow hedges during fiscal years 2019, 2018 and 2017.

[0001193125-19-212028:notes:48]
Other derivatives not designated as hedging instruments consist of foreign currency forward exchange contracts that the Company uses to hedge the foreign currency exposure on the investment in debt security and forecasted expenditures denominated in currency other than the U.S. dollar. The Company recognizes gains and losses on these contracts, as well as the related costs in Other, net on its Consolidated Statement of Operations along with foreign currency gains and losses on investment in debt security, deferred gains of derivatives in Other current assets and deferred losses of derivatives in Accrued expenses on its Consolidated Balance Sheet.

[0001193125-19-212028:notes:49]
The following table shows the total notional value of the Company's outstanding foreign currency forward exchange contracts as of June 28, 2019. All these foreign currency forward contracts mature within 12 months.

[0001193125-19-212028:notes:50]
|  |  | As of June 28, 2019 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Singapore Dollar |  | $ | 60 |  |  | $ | 40 |  |
| Chinese Renminbi |  | 79 |  |  | 20 |  |
| British Pound Sterling |  | 6 |  |  | 12 |  |
|  |  | $ | 145 |  |  | $ | 72 |  |

[0001193125-19-212028:notes:51]
The following table shows the total notional value of the Company's outstanding foreign currency forward exchange contracts as of June 29, 2018.

[0001193125-19-212028:notes:52]
|  |  | As of June 29, 2018 |
| (Dollars in millions) |  | Contracts Designated as Hedges |  | Contracts Not Designated as Hedges |
| Japanese Yen (a) |  | $ | 66 |  |  | $ | 1,310 |  |

[0001193125-19-212028:notes:53]
_____________________________________________________

[0001193125-19-212028:notes:54]
(a)  Pertains to our investment in TMHC.

[0001193125-19-212028:notes:55]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plans—the Seagate Deferred Compensation Plans (the “SDCPs”). The Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCPs liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCPs liabilities due to changes in the value of the investment options made by employees. As of June 28, 2019, the notional investments underlying the TRS amounted to $117 million. The contract term of the TRS is through January 2020 and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company does not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCPs liabilities.

[0001193125-19-212028:notes:56]
The following table shows the Company's derivative instruments measured at gross fair value as reflected in the Consolidated Balance Sheet as of June 28, 2019:

[0001193125-19-212028:notes:57]
|  |  | As of June 28, 2019 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 1 |  |  | Accrued expenses |  | (1 | ) |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 1 |  |  |  |  | $ | (1 | ) |

[0001193125-19-212028:notes:58]
The following table shows the Company's derivative instruments measured at gross fair value as reflected in the Consolidated Balance Sheet as of as of June 29, 2018:

[0001193125-19-212028:notes:59]
|  |  | As of June 29, 2018 |
|  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | 10 |  |  | Accrued expenses |  | — |  |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 10 |  |  |  |  | $ | — |  |

[0001193125-19-212028:notes:60]
The amount of gain or loss recognized in the Consolidated Statement of Comprehensive Income on derivatives designated as cash flow hedges was not material for fiscal years 2019 and 2018. The amount of gain or loss recognized in income related to the ineffective portion of the hedging relationships and to the amount excluded from the assessment of hedge ineffectiveness was not material for the fiscal years 2019 and 2018.

[0001193125-19-212028:notes:61]
The following table shows the effect of the Company's derivative instruments on the Consolidated Statements of Comprehensive Income and Consolidated Statement of Operations for the fiscal year ended June 28, 2019:

[0001193125-19-212028:notes:62]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized inIncome on Derivatives |  | Amount of Gain/(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 20 |  |
| Total return swap |  | Operating expenses |  | $ | 3 |  |

[0001193125-19-212028:notes:63]
The following tables show the effect of the Company's derivative instruments on the Consolidated Statement of Operations for the fiscal year ended June 29, 2018:

[0001193125-19-212028:notes:64]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized inIncome on Derivatives |  | Amount of Gain/(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 10 |  |
| Total return swap |  | Operating expenses |  | $ | 6 |  |


## us-gaap:DerivativesPolicyTextBlock

[0001193125-19-212028:notes:65]
Derivative Financial Instruments. The Company records all derivatives on the balance sheet at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company continues to exclude the change in forward points from the assessment of hedge effectiveness and recognizes the excluded component in Other, net in the Consolidated Statements of Operations. Foreign currency forward exchange contracts not designated as hedge instruments are used to economically hedge the foreign currency exposure in the value of an investment denominated in currency other than U.S. dollar. The Company recognizes the unrealized gains and losses due to the changes in the fair value of these contracts in Other, net in the Consolidated Statements of Operations along with the foreign currency gains and losses on remeasurement of such investment.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001193125-19-212028:notes:66]
|  |  | Fiscal Years Ended |
| (Dollars in million) |  | June 28, 2019 |  | June 29, 2018 |  | June 30, 2017 |
| Revenues by Channel |  |  |  |  |  |  |  |
| OEMs |  | $ | 7,261 |  |  | $ | 7,863 |  |  | $ | 7,478 |  |
| Distributors |  | 1,780 |  |  | 1,906 |  |  | 1,866 |  |
| Retailers |  | 1,349 |  |  | 1,415 |  |  | 1,427 |  |
| Total |  | $ | 10,390 |  |  | $ | 11,184 |  |  | $ | 10,771 |  |
| Revenues by Geography(1) |  |  |  |  |  |  |
| Americas |  | $ | 3,310 |  |  | $ | 3,719 |  |  | $ | 3,531 |  |
| EMEA |  | 1,965 |  |  | 1,983 |  |  | 2,119 |  |
| Asia Pacific |  | 5,115 |  |  | 5,482 |  |  | 5,121 |  |
| Total |  | $ | 10,390 |  |  | $ | 11,184 |  |  | $ | 10,771 |  |

[0001193125-19-212028:notes:67]
____________________________________________________


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-19-212028:notes:68]
Share-Based Compensation

[0001193125-19-212028:notes:69]
Share-Based Compensation Plans

[0001193125-19-212028:notes:70]
The Company's share-based compensation plans have been established to promote the Company's long-term growth and financial success by providing incentives to its employees, directors and consultants through grants of share-based awards. The provisions of the Company's share-based benefit plans, which allow for the grant of various types of equity-based awards, are also intended to provide greater flexibility to maintain the Company's competitive ability to attract, retain and motivate participants for the benefit of the Company and its shareholders.

[0001193125-19-212028:notes:71]
Seagate Technology plc 2012 Equity Incentive Plan (the “EIP”). On October 26, 2011, the shareholders approved the EIP and authorized the issuance of up to a total of approximately 27.0 million ordinary shares, par value $0.00001 per share, plus any shares remaining available for grant under the Seagate Technology plc 2004 Share Compensation Plan (the "SCP") as of the effective date of the EIP (which was equal to approximately 11.0 million ordinary shares as of the effective date of the EIP and which will increase by such additional number of shares as will be returned to the share reserve in respect of awards previously granted under the SCP) (together, the “Share Reserve”). On October 22, 2014, the shareholders authorized the issuance from the EIP of an additional 25 million ordinary shares, par value $0.00001 per share. Any shares that are subject to options or share appreciation rights granted under the EIP will be counted against the Share Reserve as one share for every one share granted, and any shares that are subject to restricted share bonus awards, restricted share units, performance share bonus awards or performance share awards (collectively, “Full-Value Share Awards”) will generally be counted against the Share Reserve as 2.5 shares for every one share granted. On October 19, 2016, the shareholders authorized the issuance from the EIP of an additional 7.5 million ordinary shares, par value $0.00001 per share. As of June 28, 2019, there were approximately 19.7 million ordinary shares available for issuance of Full-Value Share Awards under the EIP.

[0001193125-19-212028:notes:72]
Dot Hill Systems 2009 Equity Incentive Plan (the "DHEIP"). Seagate Technology plc acquired the Dot Hill Systems 2009 Equity Incentive Plan effective October 6, 2015. The Company assumed the remaining authorized but unused share reserve of approximately 2 million shares, based on the conversion ratio, from the DHEIP on the acquisition date. Effective April 24, 2019, the Company terminated the DHEIP and thus, no further grants will be made under the DHEIP. Outstanding awards granted under the DHEIP will remain subject to the terms of the DHEIP.

[0001193125-19-212028:notes:73]
Seagate Technology plc Employee Stock Purchase Plan (the "ESPP"). There are 60.0 million ordinary shares authorized to be issued under the ESPP. The ESPP consists of a six-month offering period with a maximum issuance of 1.5 million ordinary shares per offering period. The ESPP permits eligible employees to purchase ordinary shares through payroll deductions generally at 85% of the fair market value of the ordinary shares. As of June 28, 2019, there were approximately 11.4 million ordinary shares available for issuance under the ESPP.

[0001193125-19-212028:notes:74]
Equity Awards

[0001193125-19-212028:notes:75]
Full-Value Share Awards (e.g. restricted share units, "RSU") generally vest over a period of three to four years, with cliff vesting of a portion of each award occurring annually, subject to continuous employment with the Company through the vesting date. Options generally vest as follows: 25% of the options will vest on the first anniversary of the vesting commencement date and the remaining 75% will vest ratably each month thereafter over the next 36 months. Options granted under the EIP and SCP have an exercise price equal to the fair market value of the Company's ordinary shares on the grant date. Fair market value is defined as the closing price of the Company's ordinary shares on NASDAQ on the grant date.

[0001193125-19-212028:notes:76]
The Company granted awards of performance-based share units ("PSU") to its senior executive officers under the SCP and the EIP where vesting is subject to both the continued employment of the participant by the Company and the achievement of certain performance goals established by the Compensation Committee of the Company's Board of Directors, including market-based performance goals. A single PSU represents the right to receive a single ordinary share of the Company. During fiscal years 2019, 2018 and 2017, the Company granted 0.4 million, 0.4 million and 0.6 million PSUs, respectively, where performance is measured based on a three-year average return on invested capital ("ROIC") goal and a relative total shareholder return ("TSR") goal, which is based on the Company's ordinary shares measured against a benchmark TSR of a peer group over the same three-year period (the "TSR/ROIC" awards). These awards vest after the end of the performance period of three years from the grant date. A percentage of these units may vest only if at least the minimum ROIC goal is met regardless of whether the TSR goal is met. The number of share units to vest will range from 0% to 200% of the targeted units. In evaluating the fair value of these units, the Company used a Monte Carlo simulation on the grant date, taking the market-based TSR goal into consideration. Compensation expense related to these units is only recorded in a period if it is probable that the ROIC goal will be met, and it is to be recorded at the expected level of achievement.

[0001193125-19-212028:notes:77]
The Company also granted 0.1 million, 0.2 million and 0.2 million PSUs during fiscal years 2019, 2018 and 2017, respectively, to its senior executive officers which are subject to a performance goal related to the Company's adjusted earnings per share (the "AEPS" awards). These awards have a maximum seven-year vesting period, with 25% annual vesting starting on the first anniversary of the grant date. If the performance goal is not achieved, vesting is delayed to a following year in which the AEPS goal is achieved. Any unvested awards from prior years may vest cumulatively in a future year within the seven-year vesting period if the annual AEPS goal is achieved during a subsequent year. If the AEPS goal has not been met by the end of the seven year period, any unvested shares will be forfeited.

[0001193125-19-212028:notes:78]
Determining Fair Value of Seagate Technology Stock Plans

[0001193125-19-212028:notes:79]
Valuation and amortization method - The Company estimates the fair value of stock options, RSU and performance awards subject to an AEPS condition granted using the Black-Scholes-Merton valuation model and a single share award approach. This fair value is then amortized on a straight-line basis over the requisite service periods of the awards, which is generally the vesting period or the remaining service (vesting) period.

[0001193125-19-212028:notes:80]
Expected Term - Expected term represents the period that the Company's share-based awards are expected to be outstanding and was determined based on historical experience of similar awards, giving consideration to the contractual terms of the share-based awards, vesting schedules and expectations of future employee behavior as influenced by changes to the terms of its share-based awards.

[0001193125-19-212028:notes:81]
Expected Volatility - The Company uses a combination of the implied volatility of its traded options and historical volatility of its share price.

[0001193125-19-212028:notes:82]
Expected Dividend - The Black-Scholes-Merton valuation model calls for a single expected dividend yield as an input. The dividend yield is determined by dividing the expected per share dividend during the coming year by the grant date share price. The expected dividend assumption is based on the Company's current expectations about its anticipated dividend policy. Also, because the expected dividend yield should reflect marketplace participants' expectations, the Company does not incorporate changes in dividends anticipated by management unless those changes have been communicated to or otherwise are anticipated by marketplace participants.

[0001193125-19-212028:notes:83]
Risk-Free Interest Rate - The Company bases the risk-free interest rate used in the Black-Scholes-Merton valuation model on the implied yield currently available on U.S. Treasury zero-coupon issues with an equivalent remaining term. Where the expected term of the Company's share-based awards do not correspond with the terms for which interest rates are quoted, the Company performed a straight-line interpolation to determine the rate from the available term maturities.

[0001193125-19-212028:notes:84]
Share-based Compensation Expense

[0001193125-19-212028:notes:85]
The Company recorded $99 million, $112 million and $137 million of share-based compensation during fiscal years 2019, 2018 and 2017, respectively. Management has made an estimate of expected forfeitures and is recognizing compensation costs only for those equity awards expected to vest. When estimating forfeitures, the Company considers voluntary termination behavior as well as the historical analysis of actual forfeited awards.

[0001193125-19-212028:notes:86]
Stock Option Activity

[0001193125-19-212028:notes:87]
The Company issues new ordinary shares upon exercise of stock options. The following is a summary of option activities:

[0001193125-19-212028:notes:88]
| Options |  | Number ofShares |  | Weighted-AverageExercisePrice |  | Weighted-AverageRemainingContractualTerm |  | AggregateIntrinsicValue |
|  |  | (In millions) |  |  |  | (In years) |  | (Dollars in millions) |
| Outstanding at June 29, 2018 |  | 4.0 |  |  | $ | 39.00 |  |  | 5.0 |  | $72 |
| Granted |  | 0.4 |  |  | $ | 48.99 |  |  |  |  |  |
| Exercised |  | (0.4 | ) |  | $ | 33.55 |  |  |  |  |  |
| Forfeitures |  | (0.5 | ) |  | $ | 35.71 |  |  |  |  |  |
| Expirations |  | — |  |  | $ | — |  |  |  |  |  |
| Outstanding at June 28, 2019 |  | 3.5 |  |  | $ | 41.04 |  |  | 4.2 |  | $29 |
| Vested and expected to vest at June 28, 2019 |  | 3.4 |  |  | $ | 41.06 |  |  | 4.2 |  | $29 |
| Exercisable at June 28, 2019 |  | 2.1 |  |  | $ | 42.11 |  |  | 3.6 |  | $16 |

[0001193125-19-212028:notes:89]
The aggregate intrinsic value is calculated as the difference between the exercise price of the underlying awards and the quoted price of the Company's ordinary shares for the options that were in-the-money at June 28, 2019. During fiscal years 2019, 2018 and 2017, the aggregate intrinsic value of options exercised under the Company's stock option plans was $5 million, $34 million and $29 million, respectively, determined as of the date of option exercise. The aggregate fair value of options vested during fiscal years 2019, 2018 and 2017 were approximately $9 million, $12 million and $15 million, respectively.

[0001193125-19-212028:notes:90]
At June 28, 2019, the total compensation cost related to options granted to employees but not yet recognized was approximately $10 million, net of estimated forfeitures of approximately $2 million. This cost is being amortized on a straight-line basis over a weighted-average remaining term of approximately 2.2 years and will be adjusted for subsequent changes in estimated forfeitures.

[0001193125-19-212028:notes:91]
Nonvested Awards Activity

[0001193125-19-212028:notes:92]
The following is a summary of nonvested award activities which do not contain a performance condition:

[0001193125-19-212028:notes:93]
| Nonvested Awards |  | Number ofShares |  | Weighted-AverageGrant-DateFair Value |
|  |  | (In millions) |  |  |
| Nonvested at June 29, 2018 |  | 5.2 |  |  | $ | 30.74 |  |
| Granted |  | 2.5 |  |  | $ | 44.37 |  |
| Forfeitures |  | (0.6 | ) |  | $ | 33.45 |  |
| Vested |  | (1.7 | ) |  | $ | 32.72 |  |
| Nonvested at June 28, 2019 |  | 5.4 |  |  | $ | 36.01 |  |

[0001193125-19-212028:notes:94]
At June 28, 2019, the total compensation cost related to nonvested awards granted to employees but not yet recognized was approximately $129 million, net of estimated forfeitures of approximately $12 million. This cost is being amortized on a straight-line basis over a weighted-average remaining term of 2.3 years and will be adjusted for subsequent changes in estimated forfeitures. The aggregate fair value of nonvested awards vested during fiscal years 2019, 2018 and 2017 were approximately $57 million, $76 million and $73 million, respectively.

[0001193125-19-212028:notes:95]
Performance Awards

[0001193125-19-212028:notes:96]
The following is a summary of nonvested award activities which contain a performance condition:

[0001193125-19-212028:notes:97]
| Performance Awards |  | Number ofShares |  | Weighted-AverageGrant-DateFair Value |
|  |  | (In millions) |  |  |
| Performance units at June 29, 2018 |  | 1.2 |  |  | $ | 33.34 |  |
| Granted |  | 0.5 |  |  | $ | 45.74 |  |
| Forfeitures |  | (0.4 | ) |  | $ | 27.11 |  |
| Vested |  | (0.3 | ) |  | $ | 43.85 |  |
| Performance units at June 28, 2019 |  | 1.0 |  |  | $ | 43.81 |  |

[0001193125-19-212028:notes:98]
At June 28, 2019, the total compensation cost related to performance awards granted to employees but not yet recognized was approximately $18 million, net of estimated forfeitures of approximately $1 million. This cost is being amortized on a straight-line basis over a weighted-average remaining term of 1.6 years. The aggregate fair value of performance awards vested during fiscal years 2019, 2018 and 2017 were approximately $12 million, $11 million and $17 million, respectively.

[0001193125-19-212028:notes:99]
ESPP

[0001193125-19-212028:notes:100]
During fiscal years 2019, 2018 and 2017, the aggregate intrinsic value of shares purchased under the Company's ESPP was approximately $10 million, $31 million and $24 million, respectively. At June 28, 2019, the total compensation cost related to options to purchase the Company's ordinary shares under the ESPP but not yet recognized was approximately $1.6 million. This cost will be amortized on a straight-line basis over a weighted-average period of approximately one month. During fiscal year 2019, the Company issued 1.4 million ordinary shares with a weighted-average exercise price of $40.85 per share.

[0001193125-19-212028:notes:101]
Tax-Deferred Savings Plan

[0001193125-19-212028:notes:102]
The Company has a tax-deferred savings plan, the Seagate 401(k) Plan (the "401(k) plan"), for the benefit of qualified employees. The 401(k) plan is designed to provide employees with an accumulation of funds at retirement. Qualified employees may elect to make contributions to the 401(k) plan on a bi-weekly basis. Pursuant to the 401(k) plan, the Company matches 50% of employee contributions, up to 6% of compensation, subject to maximum annual contributions of $6,000 per participating employee. During fiscal years 2019, 2018 and 2017, the Company made matching contributions of $16 million, $16 million and $18 million, respectively.

[0001193125-19-212028:notes:103]
Deferred Compensation Plans

[0001193125-19-212028:notes:104]
The Company has adopted the SDCPs for the benefit of eligible employees. These plans are designed to permit certain discretionary employer contributions, in excess of the tax limits applicable to the 401(k) plan and to permit employee deferrals in excess of certain tax limits. During fiscal year 2014, the Company entered into a TRS in order to manage the equity market risks associated with the SDCPs liabilities. See Note 8. Derivative Financial Instruments contained in this report for additional information about the TRS.


## us-gaap:EarningsPerShareTextBlock

[0001193125-19-212028:notes:105]
Earnings Per Share

[0001193125-19-212028:notes:106]
Basic earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period. Diluted earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period and the number of additional shares that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding options, unvested restricted stock units and performance-based share units and shares to be purchased under the ESPP. The dilutive effect of potentially dilutive securities is reflected in diluted earnings per share by application of the treasury stock method. Under the treasury stock method, an increase in fair market value of the Company’s share price can result in a greater dilutive effect from potentially dilutive securities. The following table sets forth the computation of basic and diluted net income per share attributable to the shareholders of the Company:

[0001193125-19-212028:notes:107]
|  |  | Fiscal Years Ended |
| (In millions, except per share data) |  | June 28, 2019 |  | June 29, 2018 |  | June 30, 2017 |
| Numerator: |  |  |  |  |  |  |
| Net income |  | $ | 2,012 |  |  | $ | 1,182 |  |  | $ | 772 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share |  | 282 |  |  | 288 |  |  | 296 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |
| Employee equity award plans |  | 3 |  |  | 4 |  |  | 3 |  |
| Total shares for purposes of calculating diluted net income per share |  | 285 |  |  | 292 |  |  | 299 |  |
| Net income per share |  |  |  |  |  |  |
| Basic |  | $ | 7.13 |  |  | $ | 4.10 |  |  | $ | 2.61 |  |
| Diluted |  | $ | 7.06 |  |  | $ | 4.05 |  |  | $ | 2.58 |  |

[0001193125-19-212028:notes:108]
The following potential shares were excluded from the computation of diluted net income per share as their effect would have been anti-dilutive:

[0001193125-19-212028:notes:109]
|  |  | Fiscal Years Ended |
| (In millions) |  | June 28, 2019 |  | June 29, 2018 |  | June 30, 2017 |
| Employee equity award plans |  | — |  |  | 1 |  |  | 1 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001193125-19-212028:notes:110]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 416 |  |  | $ | 132 |  |  | $ | — |  |  | $ | 548 |  |
| Other current assets |  | 1 |  |  | 2 |  |  | — |  |  | 3 |  |
| Other assets, net |  | — |  |  | — |  |  | 7 |  |  | 7 |  |
| Total assets |  | $ | 417 |  |  | $ | 134 |  |  | $ | 7 |  |  | $ | 558 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Total liabilities |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |

[0001193125-19-212028:notes:111]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 620 |  |  | $ | 392 |  |  | $ | — |  |  | $ | 1,012 |  |
| Other current assets |  | 1 |  |  | 13 |  |  | — |  |  | 14 |  |
| Total assets |  | $ | 621 |  |  | $ | 405 |  |  | $ | — |  | — |  | $ | 1,026 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-19-212028:notes:112]
Fair Value

[0001193125-19-212028:notes:113]
Measurement of Fair Value

[0001193125-19-212028:notes:114]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact and it considers assumptions that market participants would use when pricing the asset or liability.

[0001193125-19-212028:notes:115]
Fair Value Hierarchy

[0001193125-19-212028:notes:116]
A fair value hierarchy is based on whether the market participant assumptions used in determining fair value are obtained from independent sources (observable inputs) or reflects the Company's own assumptions of market participant valuation (unobservable inputs). A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The three levels of inputs that may be used to measure fair value are:

[0001193125-19-212028:notes:117]
Level 1 - Quoted prices in active markets that are unadjusted and accessible at the measurement date for identical, unrestricted assets or liabilities;

[0001193125-19-212028:notes:118]
Level 2 - Quoted prices for identical assets and liabilities in markets that are inactive; quoted prices for similar assets and liabilities in active markets or financial instruments for which significant inputs are observable, either directly or indirectly; or

[0001193125-19-212028:notes:119]
Level 3 - Prices or valuations that require inputs that are both unobservable and significant to the fair value measurement.

[0001193125-19-212028:notes:120]
The Company considers an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and views an inactive market as one in which there are few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, the Company's or the counterparty's non-performance risk is considered in determining the fair values of liabilities and assets, respectively.

[0001193125-19-212028:notes:121]
Items Measured at Fair Value on a Recurring Basis

[0001193125-19-212028:notes:122]
The following table presents the Company's assets and liabilities that are measured at fair value on a recurring basis, excluding accrued interest components, as of June 28, 2019:

[0001193125-19-212028:notes:123]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 416 |  |  | $ | — |  |  | $ | — |  |  | $ | 416 |  |
| Time deposits and certificates of deposit |  | — |  |  | 132 |  |  | — |  |  | 132 |  |
| Total cash equivalents |  | 416 |  |  | 132 |  |  | — |  |  | 548 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | — |  |  | — |  |  | 7 |  | 7 |  | 7 |  |
| Derivative assets |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total assets |  | $ | 417 |  |  | $ | 134 |  |  | $ | 7 |  |  | $ | 558 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Total liabilities |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |

[0001193125-19-212028:notes:124]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of June 29, 2018:

[0001193125-19-212028:notes:125]
|  |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 620 |  |  | $ | — |  |  | $ | — |  |  | $ | 620 |  |
| Time deposits and certificates of deposit |  | — |  |  | 392 |  |  | — |  |  | 392 |  |
| Total cash equivalents |  | 620 |  |  | 392 |  |  | — |  |  | 1,012 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |
| Money market funds |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Derivative assets |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Total assets |  | $ | 621 |  |  | $ | 405 |  |  | $ | — |  |  | $ | 1,026 |  |

[0001193125-19-212028:notes:126]
The Company classifies items in Level 1 if the financial assets consist of securities for which quoted prices are available in an active market.

[0001193125-19-212028:notes:127]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries, time deposits and certificates of deposit. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair values of all of its cash equivalents and short-term investments. For the cash equivalents and short-term investments in the Company's portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry standard data providers or other third party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of June 28, 2019, has not found it necessary to make any adjustments to the prices obtained. The Company's derivative financial instruments are also classified within Level 2. The Company's derivative financial instruments consist of foreign currency forward exchange contracts and the TRS. The Company recognizes derivative financial instruments in its consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001193125-19-212028:notes:128]
Items Measured at Fair Value on a Non-Recurring Basis

[0001193125-19-212028:notes:129]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives. These strategic investments primarily include cost basis investments representing those where the Company does have the ability to exercise significant influence but does not have control. These investments are included in Other assets, net in the Company's Consolidated Balance Sheets and are periodically analyzed to determine whether or not there are indicators of impairment.

[0001193125-19-212028:notes:130]
As of June 28, 2019 and June 29, 2018, the carrying value of the Company’s strategic investments were $114 million and $118 million, respectively. During fiscal years 2018 and 2017, the Company determined that certain of its equity investments accounted for under the cost method were other-than-temporarily impaired, and recognized charges of $11 million and $25 million, respectively, in order to write down the carrying amount of the investments to its estimated fair value. For fiscal year 2019, there were no upward or downward adjustments on equity investments as a result of adoption of the measurement alternative.

[0001193125-19-212028:notes:131]
As of June 28, 2019 and June 29, 2018, the Company had $23 million and $26 million, respectively, of held for sale land and building (collectively, the "properties") included in Other current assets on its Consolidated Balance Sheets. During fiscal year 2019, the Company completed the sale of certain property in the Americas and recorded a gain of approximately $78 million. Additionally, the Company accepted an offer to sell certain property in Asia and thereafter, recorded an impairment charge of approximately $3 million. The gain and the impairment charge were recorded in Restructuring and other, net in the Company's Consolidated Statement of Operations. The sale of the property was subsequently completed in the beginning of fiscal year 2020. Please refer to Note 17. Subsequent Events for more details. During fiscal year 2018, the Company completed the sale of certain properties and recorded a gain of approximately $25 million, which was included in Restructuring and other, net in the Consolidated Statements of Operations. No impairment was identified during fiscal year 2018. During fiscal year 2017, the Company recorded impairment charges of $35 million in order to write down the carrying amount of certain properties to their estimated fair values less costs to sell. The impairment charges were recorded in Operating expenses in the Consolidated Statements of Operations.

[0001193125-19-212028:notes:132]
Other Fair Value Disclosures

[0001193125-19-212028:notes:133]
On June 17, 2019, the Company received approximately $1.3 billion in cash from TMHC for the redemption of all of the outstanding shares of non-convertible preferred stock of TMHC held by the Company. The debt security was recorded at amortized cost and its fair value approximates the carrying value at June 29, 2018. The fair value was determined utilizing Level 2 inputs such as discount rates and yield terms of similar types of securities issued by comparable companies. Please refer to Note 2. Balance Sheet Information for more details.

[0001193125-19-212028:notes:134]
The Company's debt is carried at amortized cost. The fair value of the Company's debt is derived using the closing price of the same debt instruments as of the date of valuation, which takes into account the yield curve, interest rates and other observable inputs. Accordingly, these fair value measurements are categorized as Level 2. The following table presents the fair value and amortized cost of the Company's debt in order of maturity:

[0001193125-19-212028:notes:135]
|  |  | June 28, 2019 |  | June 29, 2018 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | — |  |  | $ | — |  |  | $ | 499 |  |  | $ | 501 |  |
| 4.250% Senior Notes due March 2022 |  | 749 |  |  | 763 |  |  | 749 |  |  | 743 |  |
| 4.75% Senior Notes due June 2023 |  | 941 |  |  | 973 |  |  | 951 |  |  | 942 |  |
| 4.875% Senior Notes due March 2024 |  | 498 |  |  | 514 |  |  | 497 |  |  | 489 |  |
| 4.75% Senior Notes due January 2025 |  | 920 |  |  | 929 |  |  | 975 |  |  | 936 |  |
| 4.875% Senior Notes due June 2027 |  | 689 |  |  | 688 |  |  | 695 |  |  | 650 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 482 |  |  | 489 |  |  | 441 |  |
|  |  | $ | 4,286 |  |  | $ | 4,349 |  |  | $ | 4,855 |  |  | $ | 4,702 |  |
| Less: debt issuance costs |  | (33 | ) |  | — |  |  | (36 | ) |  | — |  |
| Long-term debt, net of debt issuance costs |  | $ | 4,253 |  |  | $ | 4,349 |  |  | $ | 4,819 |  |  | $ | 4,702 |  |
| Less: current portion of long-term debt, net of debt issuance costs |  | — |  |  | — |  |  | (499 | ) |  | (501 | ) |
| Long-term debt, less current portion |  | $ | 4,253 |  |  | $ | 4,349 |  |  | $ | 4,320 |  |  | $ | 4,201 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001193125-19-212028:notes:136]
Foreign Currency Remeasurement and Translation. The U.S. dollar is the functional currency for the majority of the Company's foreign operations. Monetary assets and liabilities denominated in foreign currencies are remeasured into the functional currency of the subsidiary at the balance sheet date. The gains and losses from the remeasurement of foreign currency denominated balances into the functional currency of the subsidiary are included in Other, net on the Company's Consolidated Statements of Operations. The Company’s subsidiaries that use the U.S. dollar as their functional currency remeasure monetary assets and liabilities at exchange rates in effect at the end of each period, and nonmonetary assets and liabilities at historical rates.

[0001193125-19-212028:notes:137]
The Company translates the assets and liabilities of its non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recognized in foreign currency translation included in Accumulated other comprehensive loss, which is a component of Shareholders’ Equity.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-19-212028:notes:138]
Goodwill and Other Intangible Assets

[0001193125-19-212028:notes:139]
Goodwill

[0001193125-19-212028:notes:140]
The changes in the carrying amount of goodwill are as follows:

[0001193125-19-212028:notes:141]
| (Dollars in millions) | Amount |
| As of June 30, 2017 | $ | 1,238 |  |
| Goodwill acquired | — |  |
| Goodwill disposed | (1 | ) |
| Foreign currency translation effect | — |  |
| As of June 29, 2018 | $ | 1,237 |  |
| Goodwill acquired | — |  |
| Goodwill disposed | — |  |
| Foreign currency translation effect | — |  |
| As of June 28, 2019 | $ | 1,237 |  |

[0001193125-19-212028:notes:142]
Other Intangible Assets

[0001193125-19-212028:notes:143]
Other intangible assets consist primarily of existing technology, customer relationships and trade names acquired in business combinations. Intangibles are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization is charged to Operating expenses in the Consolidated Statements of Operations.

[0001193125-19-212028:notes:144]
In fiscal years 2019, 2018 and 2017, amortization expense for other intangible assets was $77 million, $111 million and $168 million, respectively.

[0001193125-19-212028:notes:145]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of June 28, 2019, is set forth in the following table:

[0001193125-19-212028:notes:146]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 201 |  |  | $ | (143 | ) |  | $ | 58 |  |  | 1.9 years |
| Customer relationships |  | 71 |  |  | (38 | ) |  | 33 |  |  | 3.3 years |
| Trade name |  | 3 |  |  | (2 | ) |  | 1 |  |  | 1.2 years |
| Other intangible assets |  | 41 |  |  | (22 | ) |  | 19 |  |  | 2.9 years |
| Total amortizable other intangible assets |  | $ | 316 |  |  | $ | (205 | ) |  | $ | 111 |  |  | 2.5 years |

[0001193125-19-212028:notes:147]
The carrying value of other intangible assets subject to amortization, excluding fully amortized intangible assets, as of June 29, 2018 is set forth in the following table:

[0001193125-19-212028:notes:148]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 256 |  |  | $ | (145 | ) |  | $ | 111 |  |  | 2.5 years |
| Customer relationships |  | 89 |  |  | (42 | ) |  | 47 |  |  | 4.0 years |
| Trade name |  | 17 |  |  | (13 | ) |  | 4 |  |  | 1.3 years |
| Other intangible assets |  | 45 |  |  | (19 | ) |  | 26 |  |  | 3.0 years |
| Total amortizable other intangible assets |  | $ | 407 |  |  | $ | (219 | ) |  | $ | 188 |  |  | 2.9 years |

[0001193125-19-212028:notes:149]
As of June 28, 2019, expected amortization expense for other intangible assets for each of the next five years and thereafter is as follows:

[0001193125-19-212028:notes:150]
| (Dollars in millions) |  | Amount |
| 2020 |  | $ | 54 |  |
| 2021 |  | 29 |  |
| 2022 |  | 20 |  |
| 2023 |  | 8 |  |
| 2024 |  | — |  |
| Thereafter |  | — |  |
| Total |  | $ | 111 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001193125-19-212028:notes:151]
Goodwill. The Company performs a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. If it is determined in the qualitative assessment that the fair value of a reporting unit is more likely than not below its carrying amount, including goodwill, then the Company will perform a quantitative impairment test. The quantitative goodwill impairment test is performed by comparing the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit's goodwill over its fair value is recognized as an impairment loss, limited to the total amount of goodwill allocated to that reporting unit.

[0001193125-19-212028:notes:152]
Other Long-lived Assets. The Company tests other long-lived assets, including property, equipment and leasehold improvements and other intangible assets subject to amortization, for recoverability whenever events or changes in circumstances indicate that the carrying value of those assets may not be recoverable. The Company performs a recoverability test to assess the recoverability of an asset group. If the recoverability test indicates that the carrying value of the asset group is not recoverable, the Company will estimate the fair value of the asset group and the excess of the carrying value over the fair value is allocated pro rata to derive the adjusted carrying value of assets in the asset group. The adjusted carrying value of each asset in the asset group is not reduced below its fair value.

[0001193125-19-212028:notes:153]
The Company tests other intangible assets not subject to amortization whenever events occur or circumstances change, such as declining financial performance, deterioration in the environment in which the entity operates or deteriorating macroeconomic conditions that have a negative effect on future expected earnings and cash flows that could affect significant inputs used to determine the fair value of the indefinite-lived intangible asset.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-19-212028:notes:154]
Income Taxes

[0001193125-19-212028:notes:155]
Income (loss) before income taxes consisted of the following:

[0001193125-19-212028:notes:156]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28, 2019 |  | June 29, 2018 |  | June 30, 2017 |
| U.S. |  | $ | 275 |  |  | $ | (29 | ) |  | $ | (22 | ) |
| Non-U.S. |  | 1,097 |  |  | 1,447 |  |  | 837 |  |
|  |  | $ | 1,372 |  |  | $ | 1,418 |  |  | $ | 815 |  |

[0001193125-19-212028:notes:157]
The (benefit) provision for income taxes consisted of the following:

[0001193125-19-212028:notes:158]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28, 2019 |  | June 29, 2018 |  | June 30, 2017 |
| Current income tax expense: |  |  |  |  |  |  |
| U.S. Federal |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| U.S. State |  | — |  |  | 5 |  |  | 1 |  |
| Non-U.S. |  | 45 |  |  | 38 |  |  | 39 |  |
| Total Current |  | 45 |  |  | 43 |  |  | 40 |  |
| Deferred income tax (benefit) expense: |  |  |  |  |  |  |
| U.S. Federal |  | (690 | ) |  | 201 |  |  | (5 | ) |
| U.S. State |  | 12 |  |  | — |  |  | — |  |
| Non-U.S. |  | (7 | ) |  | (8 | ) |  | 8 |  |
| Total Deferred |  | (685 | ) |  | 193 |  |  | 3 |  |
| (Benefit) provision for income taxes |  | $ | (640 | ) |  | $ | 236 |  |  | $ | 43 |  |

[0001193125-19-212028:notes:159]
On December 22, 2017, the Tax Act was enacted into law in the United States. The Tax Act significantly revised U.S. corporate income tax law by, among other things, lowering U.S. corporate income tax rates from 35% to 21%, implementing a territorial tax system and imposing a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries.

[0001193125-19-212028:notes:160]
The U.S. tax law changes, including limitations on various business deductions such as executive compensation under Internal Revenue Code §162(m), will not materially impact the Company’s current tax expense in the short-term due to the Company's large net operating loss and tax credit carryovers. The Tax Act’s new international rules, including Global Intangible Low-Taxed Income (“GILTI”), Foreign Derived Intangible Income (“FDII”) and Base Erosion Anti-Avoidance Tax (“BEAT”), are effective beginning in fiscal year 2019. For fiscal year 2019, the Company has included the effects of the Tax Act in its financial statements and has concluded the impact is not material.

[0001193125-19-212028:notes:161]
As of the fiscal quarter ended September 28, 2018, pursuant to SEC Staff Accounting Bulletin (“SAB”) 118 (regarding the application of ASC 740 associated with the enactment of the Tax Act), the Company had considered SAB 118 and concluded its accounting under ASC 740 for the provisions of the Tax Act was complete. There were no adjustments deemed necessary in fiscal year 2019.

[0001193125-19-212028:notes:162]
The significant components of the Company’s deferred tax assets and liabilities were as follows (in millions):

[0001193125-19-212028:notes:163]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28, 2019 |  | June 29, 2018 |
| Deferred tax assets |  |  |  |  |
| Accrued warranty |  | $ | 46 |  |  | $ | 55 |  |
| Inventory carrying value adjustments |  | 34 |  |  | 30 |  |
| Receivable allowances |  | 10 |  |  | 13 |  |
| Accrued compensation and benefits |  | 53 |  |  | 64 |  |
| Depreciation |  | 89 |  |  | 96 |  |
| Restructuring accruals |  | 4 |  |  | 5 |  |
| Other accruals and deferred items |  | 15 |  |  | 34 |  |
| Net operating losses |  | 743 |  |  | 812 |  |
| Tax credit carryforwards |  | 582 |  |  | 549 |  |
| Other assets |  | 7 |  |  | 10 |  |
| Gross: Deferred tax assets |  | 1,583 |  |  | 1,668 |  |
| Less: Valuation allowance |  | (460 | ) |  | (1,221 | ) |
| Net: Deferred tax assets |  | 1,123 |  |  | 447 |  |
| Deferred tax liabilities |  |  |  |  |
| Unremitted earnings of certain non-U.S. entities |  | (16 | ) |  | (7 | ) |
| Acquisition-related items |  | (13 | ) |  | (30 | ) |
| Net: Deferred tax liabilities |  | (29 | ) |  | (37 | ) |
| Total net deferred tax assets |  | $ | 1,094 |  |  | $ | 410 |  |

[0001193125-19-212028:notes:164]
At June 28, 2019, the Company recorded $1.1 billion of net deferred tax assets. The realization of most of these deferred tax assets is primarily dependent on the Company's ability to generate sufficient U.S. and certain non-U.S. taxable income in future periods. Although realization is not assured, the Company's management believes it is more likely than not that these deferred tax assets will be realized. The amount of deferred tax assets considered realizable, however, may increase or decrease in subsequent periods when the Company re-evaluates the underlying basis for its estimates of future U.S. and certain non-U.S. taxable income.

[0001193125-19-212028:notes:165]
The deferred tax asset valuation allowance decreased by $761 million in fiscal year 2019. The decrease in valuation allowance during fiscal year 2019 was primarily related to a valuation allowance release driven by improvements in the Company’s profitability outlook in the U.S., including its efforts to structurally and operationally align its EDS business with the rest of the Company. The Company continues to maintain a valuation allowance related to specific net deferred tax assets where it is not more likely than not that the deferred tax assets will be realized. This includes certain U.S. federal, U.S. state and non-U.S. tax attributes that have limited lives, or, indefinite lived deferred tax assets that the Company does not expect to utilize in the foreseeable future.

[0001193125-19-212028:notes:166]
At June 28, 2019, the Company had U.S. federal, U.S. state and non-U.S. tax net operating loss carryforwards of approximately $3.1 billion, $1.8 billion and $43.5 million, respectively, which will expire at various dates beginning in fiscal year 2020, if not utilized. Net operating loss carryforwards of approximately $42 million are scheduled to expire in fiscal year 2020. At June 28, 2019, the Company had U.S. federal and state tax credit carryforwards of $533 million and $143 million, respectively, which will expire at various dates beginning in fiscal year 2020 if not utilized.

[0001193125-19-212028:notes:167]
As of June 28, 2019, approximately $373 million and $98 million of the Company's total U.S. net operating loss and tax credit carryforwards, respectively, are subject to annual limitations ranging from $1 million to $45 million pursuant to U.S. tax law.

[0001193125-19-212028:notes:168]
For purposes of the reconciliation between the (benefit) provision for income taxes at the statutory rate and the effective tax rate, the Irish statutory rate of 25% was applied as follows:

[0001193125-19-212028:notes:169]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28, 2019 |  | June 29, 2018 |  | June 30, 2017 |
| Provision at statutory rate |  | $ | 343 |  |  | $ | 355 |  |  | $ | 204 |  |
| Permanent differences |  | 3 |  |  | (2 | ) |  | 19 |  |
| Effect of U.S. corporate tax rate change |  | — |  |  | 524 |  |  | — |  |
| Valuation allowance |  | (742 | ) |  | (297 | ) |  | 2 |  |
| Non-U.S. losses with no tax benefits |  | — |  |  | — |  |  | 17 |  |
| Earnings taxed at other than statutory rate |  | (234 | ) |  | (317 | ) |  | (185 | ) |
| Research credit |  | (38 | ) |  | (25 | ) |  | (14 | ) |
| Tax expense (benefit) related to intercompany transactions |  | 23 |  |  | — |  |  | (2 | ) |
| Other individually immaterial items |  | 5 |  |  | (2 | ) |  | 2 |  |
| (Benefit) provision for income taxes |  | $ | (640 | ) |  | $ | 236 |  |  | $ | 43 |  |

[0001193125-19-212028:notes:170]
A substantial portion of the Company's operations in Malaysia, Singapore and Thailand operate under various tax incentive programs, which expire in whole or in part at various dates through 2025. Certain tax incentives may be extended if specific conditions are met. The net impact of these tax incentive programs was to increase the Company's net income by approximately $194 million in fiscal year 2019 ($0.68 per share, diluted), to increase the Company's net income by approximately $269 million in fiscal year 2018 ($0.92 per share, diluted) and to increase the Company's net income by approximately $163 million in fiscal year 2017 ($0.54 per share, diluted).

[0001193125-19-212028:notes:171]
The Company consists of an Irish tax resident parent holding company with various U.S. and non-U.S. subsidiaries that operate in multiple non-Irish taxing jurisdictions. The amount of temporary differences (including undistributed earnings) related to outside basis differences in the stock of non-Irish resident subsidiaries considered indefinitely reinvested outside of Ireland for which Irish income taxes have not been provided as of June 28, 2019, was approximately $2.3 billion. If such amounts were remitted to Ireland as a dividend, it is likely that tax at 25%, or approximately $575 million would result.

[0001193125-19-212028:notes:172]
As of June 28, 2019 and June 29, 2018, the Company had approximately $83 million and $60 million, respectively, of unrecognized tax benefits excluding interest and penalties. These amounts, if recognized, would impact the effective tax rate subject to certain future valuation allowance offsets.

[0001193125-19-212028:notes:173]
The following table summarizes the activity related to the Company's gross unrecognized tax benefits:

[0001193125-19-212028:notes:174]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28, 2019 |  | June 29, 2018 |  | June 30, 2017 |
| Balance of unrecognized tax benefits at the beginning of the year |  | $ | 60 |  |  | $ | 74 |  |  | $ | 76 |  |
| Gross increase for tax positions of prior years |  | 22 |  |  | 2 |  |  | 2 |  |
| Gross decrease for tax positions of prior years |  | (9 | ) |  | (3 | ) |  | (7 | ) |
| Gross increase for tax positions of current year |  | 16 |  |  | 7 |  |  | 16 |  |
| Gross decrease for tax positions of current year |  | — |  |  | — |  |  | — |  |
| Settlements |  | — |  |  | — |  |  | — |  |
| Lapse of statutes of limitation |  | (6 | ) |  | (20 | ) |  | (13 | ) |
| Non-U.S. exchange gain |  | — |  |  | — |  |  | — |  |
| Balance of unrecognized tax benefits at the end of the year |  | $ | 83 |  |  | $ | 60 |  |  | $ | 74 |  |

[0001193125-19-212028:notes:175]
It is the Company's policy to include interest and penalties related to unrecognized tax benefits in the provision for income taxes on the Consolidated Statements of Operations. During fiscal years 2019 and 2018, the Company recognized net income tax benefit for interest and penalties of $2 million, as compared to net tax benefit of $1 million during fiscal year 2017. As of June 28, 2019, the Company had $1 million of accrued interest and penalties related to unrecognized tax benefits compared to $2 million in fiscal year 2018.

[0001193125-19-212028:notes:176]
During the 12 months beginning June 29, 2019, the Company expects that its unrecognized tax benefits could be reduced by less than $1 million as a result of the expiration of certain statutes of limitation.

[0001193125-19-212028:notes:177]
The Company is required to file U.S. federal, U.S. state and non-U.S. income tax returns. The Company is no longer subject to examination of its U.S. federal income tax returns for years prior to fiscal year 2016. With respect to U.S. state and non-U.S. income tax returns, the Company is generally no longer subject to tax examination for years ending prior to fiscal year 2008.


## us-gaap:IncomeTaxPolicyTextBlock

[0001193125-19-212028:notes:178]
Accounting for Income Taxes. The Company makes certain estimates and judgments in determining income tax expense for financial statement purposes. These estimates and judgments occur in the calculation of tax credits, recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for income tax and financial statement purposes, as well as tax liabilities associated with uncertain tax positions. The calculation of tax liabilities involves uncertainties in the application of complex tax rules and the potential for future adjustment of the Company’s uncertain tax positions by the Internal Revenue Service or other tax jurisdictions. If estimates of these tax liabilities are greater or less than actual results, an additional tax provision or benefit will result. The deferred tax assets the Company records each period depend primarily on the Company’s ability to generate future taxable income in the United States and certain non-U.S. jurisdictions. Each period, the Company evaluates the need for a valuation allowance for its deferred tax assets and, if necessary, adjusts the valuation allowance so that net deferred tax assets are recorded only to the extent the Company concludes it is more likely than not that these deferred tax assets will be realized. If the Company’s outlook for future taxable income changes significantly, the Company’s assessment of the need for, and the amount of, a valuation allowance may also change.


## us-gaap:InventoryPolicyTextBlock

[0001193125-19-212028:notes:179]
Inventories. Inventories are valued at the lower of cost (using the first-in, first-out method) and net realizable value. Net realizable value is based upon the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. Adjustments to reduce cost of inventories to its net realizable value are made, if required, for estimated excess or obsolescence determined primarily by future demand forecasts.


## us-gaap:InvestmentPolicyTextBlock

[0001193125-19-212028:notes:180]
Investment in Debt Security and Payment-in-Kind (“PIK”) Income. The Company had a debt investment in non-convertible preferred stock of Toshiba Memory Holdings Corporation ("TMHC", formerly known as "K.K. Pangea") that was fully redeemed by TMHC in June 2019. The Company classified the investment as held-to-maturity as it had the positive intent and ability to hold the security until maturity. This held-to-maturity investment was carried at amortized cost and recorded as Investment in debt security on the Consolidated Balance Sheets.

[0001193125-19-212028:notes:181]
Transaction costs incurred by the Company to acquire this investment were capitalized and amortized as a reduction of interest income on the Consolidated Statements of Operations over the respective term of the investment. The investment contained a PIK income provision, which represented contractual interest that was due upon redemption, and was accrued and recorded as Interest income each reporting period and added to the carrying value of the Investment in debt security.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-19-212028:notes:182]
The fair value and amortized cost of the Company's investments classified as available-for-sale at June 28, 2019 by remaining contractual maturity were as follows:

[0001193125-19-212028:notes:183]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 550 |  |  | $ | 550 |  |
| Due in 1 to 5 years |  | 3 |  |  | 3 |  |
| Due in 6 to 10 years |  | — |  |  | — |  |
| Thereafter |  | 4 |  |  | 4 |  |
| Total |  | $ | 557 |  |  | $ | 557 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001193125-19-212028:notes:184]
Legal, Environmental and Other Contingencies

[0001193125-19-212028:notes:185]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001193125-19-212028:notes:186]
Intellectual Property Litigation

[0001193125-19-212028:notes:187]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al. On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent No. 4,916,635 (the “‘635 patent”) and U.S. Patent No. 5,638,267 (the “‘267 patent”), misappropriation of trade secrets, breach of contract and other claims. On January 16, 2002, Convolve filed an amended complaint, alleging defendants were infringing U.S. Patent No. 6,314,473 (the “‘473 patent”). The district court ruled in 2010 that the ‘267 patent was out of the case.

[0001193125-19-212028:notes:188]
On August 16, 2011, the district court granted in part and denied in part the Company’s motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the ‘635 patent are invalid; 2) reversed and vacated the district court’s summary judgment of non-infringement with respect to the ‘473 patent; and 3) remanded the case for further proceedings on the ‘473 patent. On July 11, 2014, the district court granted the Company’s further summary judgment motion regarding the ‘473 patent. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001193125-19-212028:notes:189]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods.” The Company believes the claims asserted in the complaint are without merit and intends to vigorously defend this case. The court issued its claim construction ruling on October 18, 2017. No trial date has been set. On June 25, 2019, the court stayed and administratively closed the case for a period of 60 days, ending on August 26, 2019, for the purpose of facilitating settlement of the case at mediation. The court indicated that if the action has not settled as of August 27, 2019, the court will issue an order scheduling trial and setting pretrial deadlines. While the possible range of loss for this matter remains uncertain, the Company estimates the amount of loss to be immaterial to the financial statements.

[0001193125-19-212028:notes:190]
Environmental Matters

[0001193125-19-212028:notes:191]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001193125-19-212028:notes:192]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001193125-19-212028:notes:193]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001193125-19-212028:notes:194]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001193125-19-212028:notes:195]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001193125-19-212028:notes:196]
Other Matters

[0001193125-19-212028:notes:197]
The Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company may be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-19-212028:notes:198]
Recently Issued Accounting Pronouncements

[0001193125-19-212028:notes:199]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") 2016-02 (ASC Topic 842), Leases and subsequently issued certain interpretive clarifications on this new guidance which amends a number of aspects of lease accounting, including requiring lessee to recognize a right-of-use ("ROU") asset and corresponding lease liability for operating leases and enhanced disclosures. The lease liability is measured at the present value of the remaining lease payments and the ROU asset will be based on the lease liability and is adjusted for lease prepayments, lease incentives received and the lessee's initial direct costs.

[0001193125-19-212028:notes:200]
The Company will adopt this ASU effective June 29, 2019 using the modified retrospective method. The Company will elect the practical expedients which allows for not reassessing whether existing contracts contain leases, the classifications of existing leases and whether the existing initial direct costs meet the new definition. In addition, the Company will elect to combine lease and non-lease components for facility leases and to keep leases with an initial term of 12 months or less off the balance sheet.

[0001193125-19-212028:notes:201]
While the Company will continue to evaluate the effect of adopting this guidance on its consolidated financial statements and related disclosures, the Company expects to recognize ROU assets and corresponding lease liabilities of approximately $114 million and $74 million, respectively, on the Consolidated Balance Sheet, primarily relating to real estate operating leases. The Company does not expect the adoption of this ASU to have a material impact on its other consolidated financial statements.

[0001193125-19-212028:notes:202]
In June 2016, the FASB issued ASU 2016-13 (ASC Topic 326), Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments. This ASU amends the requirement on the measurement and recognition of expected credit losses for financial assets held. The Company is required to adopt this guidance in the first quarter of fiscal year 2021. Early adoption in the first quarter of fiscal year 2020 is permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

[0001193125-19-212028:notes:203]
In February 2018, the FASB issued ASU 2018-02 (ASC Topic 220), Income Statement—Reporting Comprehensive Income: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 ("the Tax Act”) and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. The Company is required to adopt the guidance in the first quarter of fiscal 2020. The adoption of ASU 2018-02 is not expected to have a material effect on its consolidated financial statements.

[0001193125-19-212028:notes:204]
In August 2018, the FASB issued ASU 2018-15 (ASC Subtopic 350-40), Intangibles - Goodwill and Other - Internal-Use Software - Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This ASU aligns the accounting for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the accounting for implementation costs incurred to develop or obtain internal-use software. The Company is required to adopt the guidance in the first quarter of fiscal year 2021. Early adoption is permitted. The Company is in the process of assessing the impact of this ASU on its consolidated financial statements.

[0001193125-19-212028:notes:205]
Recently Adopted Accounting Pronouncements

[0001193125-19-212028:notes:206]
In May 2014, the FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, and FASB also issued certain interpretive clarifications on this new guidance which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes the revenue recognition guidance under ASC 605. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. This ASU became effective and was adopted by the Company in the quarter ended September 28, 2018 under the modified retrospective approach with a cumulative adjustment to accumulated deficit at the date of adoption. The Company has completed the adoption and implemented policies, processes and controls to support the new standard’s measurement and disclosure requirements.

[0001193125-19-212028:notes:207]
The Company applied ASC 606 using a modified retrospective transition approach to all contracts that were not completed as of June 29, 2018. Results for reporting periods beginning June 30, 2018 are presented under ASC 606, while prior period amounts were not adjusted and continue to be reported under the historical accounting standard. As a result of the adoption, the Company identified a change in revenue recognition timing on its product sales made to certain retail customers and started to recognize revenue when the Company transfers control to the applicable customers rather than deferring recognition until those customers sell the products. In addition, the Company established accruals for the variable consideration related to customer incentives on these arrangements. On the date of initial adoption, the Company removed the related deferred income on the product sales made to these customers and recorded estimates of the accrual for variable consideration through a cumulative adjustment to accumulated deficit. The cumulative effect of the change to the Company's Consolidated Balance Sheet from the adoption of ASC 606 was as follows:

[0001193125-19-212028:notes:208]
| (Dollars in millions) |  | As of June 29, 2018 |  | Effect of adoption of ASC 606 |  | As of June 30, 2018 |
| Accounts receivable, net |  | $ | 1,184 |  |  | $ | 9 |  |  | $ | 1,193 |  |
| Inventories |  | $ | 1,053 |  |  | $ | (9 | ) |  | $ | 1,044 |  |
| Accrued expenses |  | $ | 598 |  |  | $ | (34 | ) |  | $ | 564 |  |
| Accumulated deficit |  | $ | (4,696 | ) |  | $ | 34 |  |  | $ | (4,662 | ) |

[0001193125-19-212028:notes:209]
The impact of applying the new accounting standard on the Company's consolidated financial statements for the year ended June 28, 2019 was not material.

[0001193125-19-212028:notes:210]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments—Overall Recognition and Measurement of Financial Assets and Financial Liabilities, as amended by ASU 2018-03, Financial Instruments—Overall: Technical Correction and Improvements, issued in February 2018. The amendments in these ASUs require entities to measure all equity investments at fair value with changes recognized through net income. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. These ASUs became effective and were adopted by the Company in the quarter ended September 28, 2018. For equity investments without readily determinable fair value, the Company elected the measurement method as cost, less impairments, and adjusted up or down based on observable price changes in orderly transactions for an identical or similar investment in the same issuer. The adoption of this guidance had no impact on the Company's consolidated financial statements and disclosures.

[0001193125-19-212028:notes:211]
In January 2017, the FASB issued ASU 2017-01 (ASC Topic 805), Business Combination: Clarifying the Definition of a Business. The amendments in this ASU change the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company adopted the guidance in the quarter ended September 28, 2018. The adoption of this guidance had no impact on the Company's consolidated financial statements and disclosures.

[0001193125-19-212028:notes:212]
In May 2017, the FASB issued ASU 2017-09 (ASC Topic 718), Stock Compensation: Scope of Modification Accounting. The amendments in this ASU provide guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting. The Company adopted the guidance in the quarter ended September 28, 2018. The adoption of this guidance had no impact on its consolidated financial statements and disclosures.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001193125-19-212028:notes:213]
Basis of Presentation and Summary of Significant Accounting Policies

[0001193125-19-212028:notes:214]
Organization

[0001193125-19-212028:notes:215]
Seagate Technology plc (the “Company”) is a leading provider of data storage technology and solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”), solid state hybrid drives ("SSHDs") and storage subsystems.

[0001193125-19-212028:notes:216]
Fiscal Year

[0001193125-19-212028:notes:217]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Accordingly, fiscal years 2019, 2018 and 2017 were comprised of 52 weeks ended on June 28, 2019, June 29, 2018 and June 30, 2017, respectively. All references to years in these Notes to Consolidated Financial Statements represent fiscal years unless otherwise noted. Fiscal year 2020 will be comprised of 53 weeks and will end on July 3, 2020. Fiscal year 2026 will also be comprised of 53 weeks and will end on July 3, 2026.

[0001193125-19-212028:notes:218]
Allowances for Doubtful Accounts. The Company maintains allowances for uncollectible accounts receivable based upon expected collectability. This reserve is established based upon historical trends, global macroeconomic conditions and an analysis of specific exposures. The provision for doubtful accounts is recorded as a charge to Marketing and administrative expense on the Company's Consolidated Statements of Operations.

[0001193125-19-212028:notes:219]
Property, Equipment and Leasehold Improvements. Property, equipment and leasehold improvements are stated at cost. Equipment and buildings are depreciated using the straight-line method over the estimated useful lives of the assets. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated life of the asset or the remaining term of the lease. The costs of additions and substantial improvements to property, equipment and leasehold improvements, which extend the economic life of the underlying assets, are capitalized. The cost of maintenance and repairs to property, equipment and leasehold improvements is expensed as incurred.

[0001193125-19-212028:notes:220]
Warranty. The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally provides warranty on its products for a period of 1 to 5 years. The Company's warranty provision considers estimated product failure rates and trends (including the timing of product returns during the warranty periods), and estimated repair or replacement costs related to product quality issues, if any. The Company also exercises judgment in estimating its ability to sell refurbished products. The Company's judgment is subject to a greater degree of subjectivity with respect to newly introduced products because of limited experience with those products upon which to base our warranty estimates.

[0001193125-19-212028:notes:221]
Revenue Recognition, Sales Returns and Allowances, and Sales Incentive Programs. Effective June 30, 2018, the Company adopted a new revenue recognition policy in accordance with Accounting Standard Codification (“ASC”) 606, Revenue from Contracts with Customers, using the modified retrospective transition approach as discussed in the section titled Recently Adopted Accounting Pronouncements in this Note 1. Prior to fiscal year 2019, the revenue recognition policy was in accordance with ASC 605, Revenue Recognition. Under ASC 606, the Company determines revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, the Company satisfies a performance obligation.

[0001193125-19-212028:notes:222]
Revenue from sales of products is generally recognized upon transfer of control to customers in an amount that reflects the consideration the Company expects to receive in exchange for those products, net of sales taxes. This typically occurs upon shipment from the Company. When applicable, the Company includes shipping charges billed to customers in Revenue and includes the related shipping costs in Cost of revenue on the Company's Consolidated Statements of Operations.

[0001193125-19-212028:notes:223]
The Company records estimated variable consideration at the time of revenue recognition as a reduction to revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer’s volume of purchases from Seagate or other agreed upon rebate programs. For the distribution and retail channel, these programs typically involve estimating the most likely amount of rebates related to a customer’s level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Marketing development program costs are accrued and recorded as a reduction to revenue at the same time that the related revenue is recognized.

[0001193125-19-212028:notes:224]
The Company elected a practical expedient to expense sales commissions as incurred because the amortization period would have been one year or less. These costs are recorded as Marketing and administrative on the Company's Consolidated Statements of Operations.

[0001193125-19-212028:notes:225]
Share-Based Compensation. The Company has elected to apply the with-and-without method to assess the realization of related excess tax benefits. The Company also elected to continue to account for share-based compensation expense net of estimated forfeitures.

[0001193125-19-212028:notes:226]
Financial Instruments Remeasurement. Effective June 30, 2018, the Company adopted ASU 2016-01, Financial Instruments, which changed the way the Company accounts for equity investments that do not qualify for the equity method of accounting. Prior to fiscal year 2019, the Company's investments in privately-held companies without readily determinable fair value were accounted for under the cost method and were recorded at historical cost at the time of investment, with adjustments to the balance only when impairment occur. Upon adoption of ASU 2016-01, the Company's equity investment in privately-held companies without readily determinable fair values are now measured using the measurement alternative method as cost, less impairments, and adjusted up or down based on observable price changes in orderly transactions for identical or similar investments of the same issuer. Any adjustments resulting from impairments and/or observable price changes are recorded as Other, net in the Company's Consolidated Statements of Operations.

[0001193125-19-212028:notes:227]
Concentrations

[0001193125-19-212028:notes:228]
Concentration of Credit Risk. The Company's customer base for disk drive products is concentrated with a small number of customers. The Company does not generally require collateral or other security to support accounts receivable. To reduce credit risk, the Company performs ongoing credit evaluations on its customers' financial condition. The Company establishes allowances for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information. Dell Inc. accounted for more than 10% of the Company's accounts receivable as of June 28, 2019 and June 29, 2018.

[0001193125-19-212028:notes:229]
Financial instruments that potentially subject the Company to concentrations of credit risk consist primarily of cash equivalents, investments and foreign currency forward exchange contracts. The Company mitigates concentrations of credit risk in its investments through diversifications, by investing in highly-rated securities and/or major multinational companies.

[0001193125-19-212028:notes:230]
In entering into foreign currency forward exchange contracts, the Company assumes the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial and investment banks, and the Company has not incurred and does not expect any losses as a result of counterparty defaults.

[0001193125-19-212028:notes:231]
Supplier Concentration. Certain of the raw materials, components and equipment used by the Company in the manufacture of its products are available from single-sourced vendors. Shortages could occur in these essential materials and components due to an interruption of supply or increased demand in the industry. If the Company were unable to procure certain materials, components or equipment at acceptable prices, it would be required to reduce its manufacturing operations, which could have a material adverse effect on its results of operations. In addition, the Company may make prepayments to certain suppliers or enter into minimum volume commitment agreements. Should these suppliers be unable to deliver on their obligations or experience financial difficulty, the Company may not be able to recover these prepayments.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-19-212028:notes:232]
Guarantees

[0001193125-19-212028:notes:233]
Indemnifications of Officers and Directors

[0001193125-19-212028:notes:234]
On May 4, 2009, Seagate Technology, an exempted company incorporated with limited liability under the laws of the Cayman Islands (“Seagate-Cayman”), then the parent company, entered into a new form of indemnification agreement (the “Revised Indemnification Agreement”) with its officers and directors of Seagate-Cayman and its subsidiaries (each, an “Indemnitee”). The Revised Indemnification Agreement provides indemnification in addition to any of Indemnitee's indemnification rights under Seagate-Cayman's Articles of Association, applicable law or otherwise, and indemnifies an Indemnitee for certain expenses (including attorneys' fees), judgments, fines and settlement amounts actually and reasonably incurred by him or her in any action or proceeding, including any action by or in the right of Seagate-Cayman or any of its subsidiaries, arising out of his or her service as a director, officer, employee or agent of Seagate-Cayman or any of its subsidiaries or of any other entity to which he or she provides services at Seagate-Cayman's request. However, an Indemnitee shall not be indemnified under the Revised Indemnification Agreement for (i) any fraud or dishonesty in the performance of Indemnitee's duty to Seagate-Cayman or the applicable subsidiary of Seagate-Cayman or (ii) Indemnitee's conscious, intentional or willful failure to act honestly, lawfully and in good faith with a view to the best interests of Seagate-Cayman or the applicable subsidiary of Seagate-Cayman. In addition, the Revised Indemnification Agreement provides that Seagate-Cayman will advance expenses incurred by an Indemnitee in connection with enforcement of the Revised Indemnification Agreement or with the investigation, settlement or appeal of any action or proceeding against him or her as to which he or she could be indemnified.

[0001193125-19-212028:notes:235]
On July 3, 2010, pursuant to a corporate reorganization, the common shareholders of Seagate-Cayman became ordinary shareholders of Seagate Technology plc (the "Company") and Seagate-Cayman became a wholly owned subsidiary of the Company, as described more fully in the Current Report on Form 8-K filed by the Company on July 6, 2010 (the “Redomestication”). On July 27, 2010, in connection with the Redomestication, the Company, as sole shareholder of Seagate-Cayman, approved a form of deed of indemnity (the “Deed of Indemnity”), which provides for the indemnification by Seagate-Cayman of any director, officer, employee or agent of the Company, Seagate-Cayman or any subsidiary of the Company (each, a “Deed Indemnitee”), in addition to any indemnification rights of a Deed Indemnitee under the Company's Articles of Association, applicable law or otherwise, with a similar scope to the Revised Indemnification Agreement. Seagate-Cayman entered into Deeds of Indemnity with certain Deed Indemnitees effective as of July 3, 2010 and continues to enter into Deeds of Indemnity with additional Deed Indemnitees from time to time.

[0001193125-19-212028:notes:236]
The nature of these indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay on behalf of its officers and directors. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the Company's consolidated financial statements with respect to these indemnification obligations.

[0001193125-19-212028:notes:237]
Intellectual Property Indemnification Obligations

[0001193125-19-212028:notes:238]
The Company has entered into agreements with customers and suppliers that include limited intellectual property indemnification obligations that are customary in the industry. These guarantees generally require the Company to compensate the other party for certain damages and costs incurred as a result of third party intellectual property claims arising from these transactions. The nature of the intellectual property indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay to its customers and suppliers. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the Company's consolidated financial statements with respect to these indemnification obligations.

[0001193125-19-212028:notes:239]
Product Warranty

[0001193125-19-212028:notes:240]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally provides warranty on its products for a period of 1 to 5 years. The Company's warranty provision considers estimated product failure rate and trends, estimated repair and replacement cost, and uses statistical modeling to estimate product return rates in order to determine its warranty obligation.  As of June 28, 2019, the Company’s reserve for product warranty was $195 million as compared to $237 million as of June 29, 2018. This decrease of $42 million was primarily driven by a continued decline in cost to repair and a decrease in the Company's warranty return rate as compared to prior year.

[0001193125-19-212028:notes:241]
Changes in the Company's product warranty liability during the fiscal years ended June 28, 2019, June 29, 2018 and June 30, 2017 were as follows:

[0001193125-19-212028:notes:242]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28, 2019 |  | June 29, 2018 |  | June 30, 2017 |
| Balance, beginning of period |  | $ | 237 |  |  | $ | 233 |  |  | $ | 206 |  |
| Warranties issued |  | 112 |  |  | 147 |  |  | 131 |  |
| Repairs and replacements |  | (99 | ) |  | (106 | ) |  | (114 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | (55 | ) |  | (37 | ) |  | 10 |  |
| Balance, end of period |  | $ | 195 |  |  | $ | 237 |  |  | $ | 233 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-19-212028:notes:243]
The components of property, equipment and leasehold improvements, net were as follows:

[0001193125-19-212028:notes:244]
| (Dollars in millions) |  | Useful Lifein Years |  | June 28, 2019 |  | June 29, 2018 |
| Land and land improvements |  |  |  | $ | 48 |  |  | $ | 55 |  |
| Equipment |  | 3 – 5 |  | 7,726 |  |  | 7,472 |  |
| Buildings and leasehold improvements |  | Up to 30 |  | 1,795 |  |  | 1,805 |  |
| Construction in progress |  |  |  | 266 |  |  | 193 |  |
|  |  |  |  | 9,835 |  |  | 9,525 |  |
| Less: accumulated depreciation and amortization |  |  |  | (7,966 | ) |  | (7,733 | ) |
| Property, equipment and leasehold improvements, net |  |  |  | $ | 1,869 |  |  | $ | 1,792 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-19-212028:notes:245]
Restructuring and Exit Costs

[0001193125-19-212028:notes:246]
During fiscal year 2019, the Company recorded a net gain of $22 million comprised primarily of a gain from sales of a property. During fiscal years 2018 and 2017 the Company recorded restructuring charges of  $89 million and $178 million, respectively, comprised primarily of charges related to workforce reduction costs and facilities and other exit costs associated with the restructuring of its workforce. The Company’s significant restructuring plans are described below. All restructuring charges are reported in Restructuring and other, net on the Consolidated Statements of Operations.

[0001193125-19-212028:notes:247]
December 2017 Plan - On December 8, 2017, the Company committed to a restructuring plan (the “December 2017 Plan”) to reduce its cost structure. The December 2017 Plan included reducing the Company's global headcount by approximately 500 employees. The December 2017 Plan was substantially completed by the end of fiscal year 2018.

[0001193125-19-212028:notes:248]
July 2017 Plan - On July 25, 2017, the Company committed to a restructuring plan (the “July 2017 Plan”) to reduce its cost structure. The July 2017 Plan included reducing the Company’s global headcount by approximately 600 employees. The July 2017 Plan was substantially completed during fiscal year 2018.

[0001193125-19-212028:notes:249]
March 2017 Plan - On March 9, 2017, the Company committed to a restructuring plan (the “March 2017 Plan”) in connection with the continued consolidation of its global footprint. The Company closed its design center in Korea, resulting in the reduction of the Company’s headcount by approximately 300 employees. The March 2017 Plan was substantially completed by the end of fiscal year 2017.

[0001193125-19-212028:notes:250]
July 2016 Plan - On July 11, 2016, the Company committed to a restructuring plan (the “July 2016 Plan”) for continued consolidation of its global footprint across Asia, EMEA and the Americas. The July 2016 Plan included reducing worldwide headcount by approximately 6,500 employees. The July 2016 Plan was substantially completed during fiscal year 2018.

[0001193125-19-212028:notes:251]
The following table summarizes the Company's restructuring activities under all of the Company’s active restructuring plans for fiscal years 2019, 2018 and 2017:

[0001193125-19-212028:notes:252]
|  |  | December 2017 Plan |  | July 2017 Plan |  | March 2017 Plan |  | July 2016 Plan |  | Other Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual balances at July 1, 2016 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 50 |  |  | $ | 13 |  |  | $ | 63 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | — |  |  | 28 |  |  | 3 |  |  | 72 |  |  | 20 |  |  | 31 |  |  | 13 |  |  | 167 |  |
| Cash payments |  | — |  |  | — |  |  | — |  |  | — |  |  | (29 | ) |  | (3 | ) |  | (57 | ) |  | (18 | ) |  | (74 | ) |  | (17 | ) |  | (198 | ) |
| Adjustments |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 7 |  |  | — |  |  | (1 | ) |  | 4 |  |  | 11 |  |
| Accrual balances at June 30, 2017 |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 22 |  |  | 2 |  |  | 6 |  |  | 13 |  |  | 43 |  |
| Restructuring charges |  | 28 |  |  | 6 |  |  | 38 |  |  | 4 |  |  | — |  |  | — |  |  | 1 |  |  | 15 |  |  | 13 |  |  | — |  |  | 105 |  |
| Cash payments |  | (21 | ) |  | (2 | ) |  | (37 | ) |  | (3 | ) |  | (1 | ) |  | — |  |  | (23 | ) |  | (16 | ) |  | (9 | ) |  | (3 | ) |  | (115 | ) |
| Adjustments |  | (2 | ) |  | — |  |  | (1 | ) |  | — |  |  | 2 |  |  | — |  |  | 2 |  |  | (1 | ) |  | 1 |  |  | 8 |  |  | 9 |  |
| Accrual balances at June 29, 2018 |  | 5 |  |  | 4 |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 2 |  |  | — |  |  | 11 |  |  | 18 |  |  | 42 |  |
| Restructuring charges |  | — |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 6 |  |  | 41 |  |  | 4 |  |  | 54 |  |
| Cash payments |  | (5 | ) |  | (5 | ) |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |  | (6 | ) |  | (41 | ) |  | (6 | ) |  | (65 | ) |
| Adjustments |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | 2 |  |  | — |  |  | (1 | ) |
| Accrual balances at June 28, 2019 |  | — |  |  | 1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 13 |  |  | 16 |  |  | 30 |  |
| Total costs incurred to date as of June 28, 2019 |  | $ | 26 |  |  | $ | 8 |  |  | $ | 37 |  |  | $ | 3 |  |  | $ | 31 |  |  | $ | 3 |  |  | $ | 81 |  |  | $ | 40 |  |  | $ | 283 |  |  | $ | 63 |  |  | $ | 575 |  |
| Total expected costs to be incurred as of June 28, 2019 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |

[0001193125-19-212028:notes:253]
Of the accrued restructuring balance of $30 million at June 28, 2019, $16 million is included in Accrued expenses and $14 million is included in Other non-current liabilities in the Company's Consolidated Balance Sheet. Of the accrued restructuring balance of $42 million at June 29, 2018, $26 million is included in Accrued expenses and $16 million is included in Other non-current liabilities in the Company's Consolidated Balance Sheet.

[0001193125-19-212028:notes:254]
During fiscal years 2019 and 2018, the Company sold certain properties, which were previously classified as assets held for sale and recognized a gain of approximately $78 million and $25 million, respectively. The Company also recorded an impairment charge of $3 million on its held for sale land and building during fiscal year 2019. The gain and impairment charge were included in Restructuring and other, net in the Company's Consolidated Statements of Operations. Please refer to Note 9. - Fair Value for more details.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-19-212028:notes:255]
Revenue

[0001193125-19-212028:notes:256]
The following table provides information about disaggregated revenue by sales channel and geographical region for the Company’s single reportable segment:

[0001193125-19-212028:notes:257]
(1) Revenue is attributed to countries based on bill from locations.


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001193125-19-212028:notes:258]
The following table provides details of the accounts receivable, net balance sheet item:

[0001193125-19-212028:notes:259]
| (Dollars in millions) |  | June 28, 2019 |  | June 29, 2018 |
| Accounts receivable |  | $ | 993 |  |  | $ | 1,188 |  |
| Allowances for doubtful accounts |  | (4 | ) |  | (4 | ) |
| Account receivable, net |  | $ | 989 |  |  | $ | 1,184 |  |


## us-gaap:ScheduleOfAccountsPayableAndAccruedLiabilitiesTableTextBlock

[0001193125-19-212028:notes:260]
The following table provides details of the accrued expenses balance sheet item:

[0001193125-19-212028:notes:261]
| (Dollars in millions) |  | June 28, 2019 |  | June 29, 2018 |
| Dividends payable |  | $ | 170 |  |  | $ | 181 |  |
| Other accrued expenses |  | 382 |  |  | 417 |  |
| Total |  | $ | 552 |  |  | $ | 598 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-19-212028:notes:262]
The components of AOCI, net of tax, were as follows:

[0001193125-19-212028:notes:263]
| (Dollars in millions) |  | UnrealizedGains/(Losses)on Cash FlowHedges |  | UnrealizedGains/(Losses) on Available-for-Sale Debt Securities |  | UnrealizedGains/(Losses)on Post-Retirement Plans |  | ForeignCurrencyTranslationAdjustments |  | Total |
| Balance at June 30, 2017 |  | $ | — |  |  | $ | — |  |  | $ | (5 | ) |  | $ | (12 | ) |  | $ | (17 | ) |
| Other comprehensive income (loss) before reclassifications |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Amounts reclassified from AOCI |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Balance at June 29, 2018 |  | — |  |  | — |  |  | (4 | ) |  | (12 | ) |  | (16 | ) |
| Other comprehensive income (loss) before reclassifications |  | — |  |  | — |  |  | (16 | ) |  | (2 | ) |  | (18 | ) |
| Amounts reclassified from AOCI |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) |  | — |  |  | — |  |  | (16 | ) |  | (2 | ) |  | (18 | ) |
| Balance at June 28, 2019 |  | $ | — |  |  | $ | — |  |  | $ | (20 | ) |  | $ | (14 | ) |  | $ | (34 | ) |


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001193125-19-212028:notes:264]
The following table provides a summary of cash, cash equivalents and restricted cash reported within the Consolidated Balance Sheets that reconciles to the corresponding amount in the Consolidated Statements of Cash Flows:

[0001193125-19-212028:notes:265]
| (Dollars in millions) |  | June 28, 2019 |  | June 29, 2018 |  | June 30, 2017 |  | July 1, 2016 |
| Cash and cash equivalents |  | $ | 2,220 |  |  | $ | 1,853 |  |  | $ | 2,539 |  |  | $ | 1,125 |  |
| Restricted cash included in Other current assets |  | 31 |  |  | 4 |  |  | 4 |  |  | 7 |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  | $ | 2,251 |  |  | $ | 1,857 |  |  | $ | 2,543 |  |  | $ | 1,132 |  |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001193125-19-212028:notes:266]
June 29, 2018:


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-19-212028:notes:267]
The following table provides details of the inventory balance sheet item:

[0001193125-19-212028:notes:268]
| (Dollars in millions) |  | June 28, 2019 |  | June 29, 2018 |
| Raw materials and components |  | $ | 336 |  |  | $ | 329 |  |
| Work-in-process |  | 217 |  |  | 347 |  |
| Finished goods |  | 417 |  |  | 377 |  |
| Total inventories |  | $ | 970 |  |  | $ | 1,053 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-19-212028:notes:269]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28, 2019 |  | June 29, 2018 |  | June 30, 2017 |
| Revenue from external customers (a): |  |  |  |  |  |  |
| Singapore |  | $ | 5,085 |  |  | $ | 5,445 |  |  | $ | 5,070 |  |
| United States |  | 3,310 |  |  | 3,719 |  |  | 3,535 |  |
| The Netherlands |  | 1,630 |  |  | 1,598 |  |  | 1,501 |  |
| Other |  | 365 |  |  | 422 |  |  | 665 |  |
| Consolidated |  | $ | 10,390 |  |  | $ | 11,184 |  |  | $ | 10,771 |  |
| Long-lived assets: |  |  |  |  |  |  |
| Thailand |  | $ | 558 |  |  | $ | 426 |  |  | $ | 414 |  |
| Singapore |  | 556 |  |  | 600 |  |  | 570 |  |
| United States |  | 523 |  |  | 565 |  |  | 643 |  |
| China |  | 62 |  |  | 45 |  |  | 58 |  |
| Other |  | 224 |  |  | 212 |  |  | 248 |  |
| Consolidated |  | $ | 1,923 |  |  | $ | 1,848 |  |  | $ | 1,933 |  |

[0001193125-19-212028:notes:270]
___________________________________

[0001193125-19-212028:notes:271]
| (a) | Revenue is attributed to countries based on the bill from location. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-19-212028:notes:272]
Business Segment and Geographic Information

[0001193125-19-212028:notes:273]
The Company’s manufacturing operations are based on technology platforms that are used to produce various data storage and systems solutions that serve multiple applications and markets. The Company has determined that its Chief Operating Decision Maker (“CODM”), the Chief Executive Officer, evaluates performance of the Company and makes decisions regarding investments in the Company’s technology platforms and manufacturing infrastructure based on the Company’s consolidated results. As a result, the Company has concluded that its manufacture and distribution of storage solutions constitutes one reporting segment.

[0001193125-19-212028:notes:274]
In fiscal years 2019 and 2018, no customer accounted for more than 10% of consolidated revenue. In fiscal year 2017, only Dell Inc. accounted for approximately 10% of consolidated revenue.

[0001193125-19-212028:notes:275]
The following table summarizes the Company's operations by geographic area:


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-19-212028:notes:276]
Shareholders' Equity

[0001193125-19-212028:notes:277]
Share Capital

[0001193125-19-212028:notes:278]
The Company's authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 269,097,971 shares were outstanding as of June 28, 2019, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of June 28, 2019.

[0001193125-19-212028:notes:279]
Ordinary shares - Holders of ordinary shares are entitled to receive dividends when and as declared by the Company's board of directors (the "Board of Directors"). Upon any liquidation, dissolution, or winding up of the Company, after required payments are made to holders of preferred shares, any remaining assets of the Company will be distributed ratably to holders of the preferred and ordinary shares. Holders of shares are entitled to one vote per share on all matters upon which the ordinary shares are entitled to vote, including the election of directors.

[0001193125-19-212028:notes:280]
Preferred shares - The Company may issue preferred shares in one or more series, up to the authorized amount, without shareholder approval. The Board of Directors is authorized to establish from time to time the number of shares to be included in each series, and to fix the rights, preferences and privileges of the shares of each wholly unissued series and any of its qualifications, limitations or restrictions. The Board of Directors can also increase or decrease the number of shares of a series, but not below the number of shares of that series then outstanding, without any further vote or action by the shareholders.

[0001193125-19-212028:notes:281]
The Board of Directors may authorize the issuance of preferred shares with voting or conversion rights that could harm the voting power or other rights of the holders of the ordinary shares. The issuance of preferred shares, while providing flexibility in connection with possible acquisitions and other corporate purposes, could, among other things, have the effect of delaying, deferring or preventing a change in control of the Company and might harm the market price of its ordinary shares and the voting and other rights of the holders of ordinary shares.

[0001193125-19-212028:notes:282]
Repurchases of Equity Securities

[0001193125-19-212028:notes:283]
All repurchases are effected as redemptions in accordance with the Company's Articles of Association.

[0001193125-19-212028:notes:284]
On October 29, 2018, the Company’s Board of Directors authorized the repurchase of an additional $2.3 billion of its outstanding ordinary shares and as a result, the Company had an aggregate authority to repurchase approximately $3.0 billion of its ordinary shares. As of June 28, 2019, $2.2 billion remained available for repurchase under the existing repurchase authorization limit.

[0001193125-19-212028:notes:285]
The following table sets forth information with respect to repurchases of the Company's ordinary shares during fiscal years 2019, 2018 and 2017:

[0001193125-19-212028:notes:286]
| (In millions) |  | Number ofSharesRepurchased |  | Dollar Valueof SharesRepurchased |
| Cumulative repurchased through July 1, 2016 |  | 328 |  |  | $ | 9,631 |  |
| Repurchased in fiscal year 2017(a) |  | 13 |  |  | 487 |  |
| Cumulative repurchased through June 30, 2017 |  | 341 |  |  | 10,118 |  |
| Repurchased in fiscal year 2018(a) |  | 11 |  |  | 384 |  |
| Cumulative repurchased through June 29, 2018 |  | 352 |  |  | 10,502 |  |
| Repurchased in fiscal year 2019(a) |  | 22 |  |  | 997 |  |
| Cumulative repurchased through June 28, 2019 |  | 374 |  |  | $ | 11,499 |  |

[0001193125-19-212028:notes:287]
___________________________________________________

[0001193125-19-212028:notes:288]
(a)	For fiscal years 2019, 2018 and 2017, includes net share settlements of $31 million, $23 million, and $27 million for 1 million, 1 million and 1 million shares in connection with tax withholding related to vesting of restricted stock units, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001193125-19-212028:notes:289]
Subsequent Events

[0001193125-19-212028:notes:290]
Dividend Declared

[0001193125-19-212028:notes:291]
On July 30, 2019, the Company's Board of Directors declared a quarterly cash dividend of $0.63 per share, which will be payable on October 9, 2019 to shareholders of record as of the close of business on September 25, 2019.

[0001193125-19-212028:notes:292]
Sale of Certain Property

[0001193125-19-212028:notes:293]
In July 2019, the Company sold certain property in Asia previously classified as held for sale land and building of $23 million at June 28, 2019. No additional impairment loss or gain was incurred in the first quarter of fiscal year 2020.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-19-212028:notes:294]
Balance Sheet Information

[0001193125-19-212028:notes:295]
Available-for-sale Debt Securities

[0001193125-19-212028:notes:296]
As of June 28, 2019, the Company's Other current assets included $2 million in restricted cash equivalents held as collateral at banks for various performance obligations.

[0001193125-19-212028:notes:297]
As of June 28, 2019, the Company had no material available-for-sale debt securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale debt securities were other-than-temporarily impaired as of June 28, 2019.

[0001193125-19-212028:notes:298]
As of June 29, 2018, the Company's Other current assets included $4 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001193125-19-212028:notes:299]
As of June 29, 2018, the Company had no available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale securities were other-than-temporarily impaired as of June 29, 2018.

[0001193125-19-212028:notes:300]
Cash, Cash Equivalents and Restricted Cash

[0001193125-19-212028:notes:301]
As of June 28, 2019, the Company's Other current assets included $31 million in restricted cash and cash equivalents in an escrow account for the sale of certain properties and cash equivalents held as collateral at banks for various performance obligations.

[0001193125-19-212028:notes:302]
Accounts Receivable, net

[0001193125-19-212028:notes:303]
Inventories

[0001193125-19-212028:notes:304]
Property, Equipment and Leasehold Improvements, net

[0001193125-19-212028:notes:305]
Depreciation expense, which includes amortization of leasehold improvements, was $464 million, $487 million and $581 million for fiscal years 2019, 2018 and 2017, respectively. Interest on borrowings related to eligible capital expenditures is capitalized as part of the cost of the qualified assets and amortized over the estimated useful lives of the assets. During fiscal years 2019, 2018 and 2017, the Company capitalized interest of $3 million, $1 million and $4 million, respectively.

[0001193125-19-212028:notes:306]
In fiscal year 2019, the Company did not have any material write-offs or accelerated depreciation of fixed assets. In fiscal year 2018, the Company recognized a charge of $7 million from the write-off and accelerated depreciation of certain fixed assets, of which $1 million, $4 million and $2 million was recorded to Cost of revenue, Product development and Marketing and administrative, respectively, in the Consolidated Statement of Operations. In fiscal year 2017, the Company determined it would discontinue the use of certain manufacturing property and equipment in the short-term, and that certain other buildings, land and manufacturing property and equipment were permanently impaired. As a result, the Company recognized charges of $72 million in fiscal year 2017 from the write-off and accelerated depreciation of these fixed assets, including $35 million impairment on land and buildings classified as held for sale under Other current assets in the Consolidated Balance Sheet. Please refer to Note 9. Fair Value for more details.

[0001193125-19-212028:notes:307]
Investment in Debt Security

[0001193125-19-212028:notes:308]
On May 31, 2018, the Company invested approximately $1.3 billion in non-convertible preferred stock of  Toshiba Memory Corporation ("TMC", formerly known as "K.K. Pangea"), a subsidiary of Toshiba Memory Holdings Corporation (“TMHC”), with a consortium of investors led by Bain Capital Private Equity. The Company’s investment in TMC was subsequently transferred to TMHC. On June 17, 2019, the Company received approximately $1.3 billion in cash from TMHC for the redemption of all the outstanding shares of non-convertible preferred stock of TMHC held by the Company. The proceeds from the redemption include the original principal and accrued PIK income. As of June 29, 2018, no impairment was identified and the fair value of the investment was determined to approximate its carrying value at amortized cost. In fiscal years 2019 and 2018, the PIK income earned was $61 million and $5 million, respectively.

[0001193125-19-212028:notes:309]
Accrued Expenses

[0001193125-19-212028:notes:310]
Accumulated Other Comprehensive Income (Loss) (“AOCI”)
