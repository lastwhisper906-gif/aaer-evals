# STX 8-K — 0001104659-16-115593 filed 2016-04-29

## item codes, every 8-K on or before 2016-04-29

- 2016-04-29 0001104659-16-115593 — 2.02, 7.01, 9.01
- 2016-04-13 0001104659-16-111266 — 2.02, 9.01
- 2016-01-29 0001104659-16-092323 — 2.02, 7.01, 9.01
- 2016-01-04 0001104659-16-087730 — 5.02, 9.01
- 2015-10-30 0001104659-15-074350 — 2.02, 7.01, 9.01
- 2015-10-21 0001104659-15-071908 — 5.02, 9.01
- 2015-10-21 0001104659-15-071906 — 5.07, 7.01, 9.01
- 2015-10-15 0001104659-15-070776 — 2.02, 9.01
- 2015-09-21 0001104659-15-066273 — 5.02
- 2015-09-10 0001104659-15-064389 — 2.05
- 2015-08-06 0001104659-15-057159 — 5.02
- 2015-07-31 0001104659-15-055040 — 2.02, 7.01, 9.01
- 2015-07-22 0001104659-15-052507 — 5.02, 9.01
- 2015-07-13 0001104659-15-050755 — 2.02, 9.01
- 2015-05-14 0001104659-15-038166 — 1.01, 2.03, 9.01
- 2015-05-12 0001104659-15-036968 — 8.01, 9.01
- 2015-05-11 0001104659-15-036533 — 8.01, 9.01
- 2015-05-01 0001104659-15-033202 — 5.02
- 2015-04-23 0001104659-15-029483 — 8.01, 9.01
- 2015-04-17 0001104659-15-028152 — 2.02, 7.01, 9.01
- 2015-04-07 0001104659-15-026148 — 7.01
- 2015-01-26 0001104659-15-004316 — 2.02, 7.01, 9.01
- 2015-01-16 0001104659-15-002732 — 1.01, 9.01
- 2015-01-02 0001104659-15-000147 — 8.01
- 2014-12-02 0001104659-14-084370 — 1.01, 2.03, 9.01
- 2014-11-25 0001104659-14-083066 — 8.01, 9.01
- 2014-11-24 0001104659-14-082837 — 8.01, 9.01
- 2014-10-27 0001104659-14-073832 — 2.02, 7.01, 9.01
- 2014-10-24 0001104659-14-073609 — 5.02, 5.07, 9.01
- 2014-10-22 0001104659-14-073104 — 7.01, 9.01
- 2014-10-08 0001104659-14-070767 — 8.01
- 2014-09-12 0001104659-14-066107 — 5.02
- 2014-09-12 0001104659-14-066101 — 7.01
- 2014-07-23 0001104659-14-052995 — 5.02
- 2014-07-17 0001104659-14-052019 — 2.02, 7.01, 9.01
- 2014-06-18 0001104659-14-046714 — 8.01, 9.01
- 2014-06-09 0001104659-14-044575 — 7.01
- 2014-06-04 0001104659-14-043897 — 8.01
- 2014-05-28 0001104659-14-041862 — 1.01, 2.03, 8.01, 9.01
- 2014-05-20 0001104659-14-040454 — 8.01, 9.01
- 2014-05-20 0001104659-14-040220 — 8.01, 9.01
- 2014-04-29 0001104659-14-031916 — 2.02, 7.01, 9.01
- 2014-04-22 0001104659-14-029197 — 5.02
- 2014-02-24 0001104659-14-012465 — 5.02, 7.01, 9.01
- 2014-01-27 0001104659-14-004298 — 2.02, 7.01, 9.01
- 2014-01-23 0001104659-14-003803 — 5.02
- 2013-12-23 0001104659-13-091738 — 1.01, 8.01, 9.01
- 2013-11-05 0001104659-13-081194 — 1.01, 2.03, 9.01
- 2013-11-04 0001104659-13-080161 — 5.02, 5.03, 5.07, 9.01
- 2013-10-31 0001104659-13-079635 — 8.01, 9.01
- 2013-10-31 0001104659-13-079438 — 8.01, 9.01
- 2013-10-28 0001104659-13-078341 — 2.02, 7.01, 9.01
- 2013-10-28 0001104659-13-078316 — 5.02, 7.01, 9.01
- 2013-10-08 0001104659-13-074454 — 1.01, 1.02, 9.01
- 2013-09-20 0001104659-13-071413 — 5.02
- 2013-07-24 0001104659-13-056053 — 5.02, 7.01
- 2013-07-24 0001104659-13-056052 — 2.02, 7.01, 9.01
- 2013-06-14 0001104659-13-049436 — 8.01, 9.01
- 2013-05-31 0001104659-13-045928 — 8.01, 9.01
- 2013-05-22 0001104659-13-043876 — 1.01, 2.03, 9.01
- 2013-05-16 0001104659-13-042180 — 7.01, 9.01
- 2013-05-15 0001104659-13-042028 — 8.01, 9.01
- 2013-05-15 0001104659-13-041695 — 8.01, 9.01
- 2013-05-07 0001104659-13-038226 — 5.02
- 2013-05-01 0001104659-13-036004 — 2.02, 9.01
- 2013-03-15 0001104659-13-021156 — 7.01
- 2013-01-28 0001104659-13-005180 — 2.02, 9.01
- 2013-01-08 0001104659-13-001291 — 2.02, 9.01
- 2012-11-29 0001104659-12-080911 — 8.01, 9.01
- 2012-10-31 0001104659-12-072476 — 2.02, 9.01
- 2012-10-25 0001104659-12-071208 — 5.07
- 2012-10-16 0001104659-12-069238 — 7.01
- 2012-09-28 0001104659-12-066105 — 7.01
- 2012-09-21 0001104659-12-064869 — 7.01
- 2012-08-02 0001104659-12-053775 — 5.02
- 2012-07-30 0001104659-12-052298 — 2.02, 5.02, 8.01, 9.01
- 2012-07-05 0001104659-12-047737 — 2.02, 9.01
- 2012-04-26 0001104659-12-029099 — 5.02, 8.01, 9.01
- 2012-04-17 0001104659-12-025931 — 2.02, 9.01
- 2012-01-31 0001104659-12-005522 — 2.02, 9.01
- 2012-01-27 0001104659-12-004299 — 8.01, 9.01
- 2012-01-04 0001104659-12-000411 — 2.02, 9.01
- 2011-12-20 0001104659-11-070207 — 2.01, 3.02, 9.01
- 2011-12-12 0001104659-11-069005 — 8.01
- 2011-12-05 0001104659-11-067679 — 5.02, 9.01
- 2011-11-29 0001104659-11-066436 — 7.01, 9.01
- 2011-11-22 0001104659-11-065589 — 7.01, 9.01
- 2011-11-03 0001104659-11-060307 — 7.01
- 2011-10-21 0001104659-11-056997 — 2.02, 8.01, 9.01
- 2011-10-12 0001104659-11-055849 — 7.01, 9.01
- 2011-07-29 0001104659-11-041897 — 5.02
- 2011-07-20 0001104659-11-039922 — 2.02, 9.01
- 2011-06-01 0001104659-11-032473 — 8.01
- 2011-05-23 0001104659-11-030867 — 8.01
- 2011-05-18 0001104659-11-029869 — 1.01, 2.03, 9.01
- 2011-05-04 0001104659-11-025801 — 8.01, 9.01
- 2011-05-04 0001104659-11-025462 — 8.01, 9.01
- 2011-04-19 0001104659-11-020787 — 1.01, 2.02, 3.02, 9.01
- 2011-04-08 0001104659-11-019316 — 5.02, 9.01
- 2011-04-07 0001104659-11-019141 — 2.02, 8.01, 9.01
- 2011-03-09 0001104659-11-013084 — 5.02
- 2011-02-18 0001104659-11-008419 — 8.01
- 2011-02-01 0001104659-11-004106 — 5.02, 9.01
- 2011-01-19 0001104659-11-002037 — 1.01, 2.02, 2.03, 5.07, 9.01
- 2010-12-14 0001104659-10-062647 — 1.01, 2.03, 9.01
- 2010-12-08 0001104659-10-061747 — 8.01, 9.01
- 2010-12-08 0001104659-10-061643 — 7.01, 8.01, 9.01
- 2010-11-29 0001104659-10-060338 — 7.01, 9.01
- 2010-10-20 0001104659-10-052966 — 2.02, 9.01
- 2010-10-15 0001104659-10-052362 — 8.01, 9.01
- 2010-09-13 0001104659-10-048317 — 5.02, 9.01
- 2010-08-16 0001104659-10-044431 — 5.02
- 2010-07-29 0001104659-10-040519 — 5.02, 9.01
- 2010-07-20 0001104659-10-038670 — 2.02, 9.01
- 2010-07-06 0001104659-10-036996 — 1.01, 2.03, 3.01, 3.03, 5.01, 5.02, 8.01, 9.01
- 2010-06-25 0001104659-10-035630 — 8.01, 9.01
- 2010-05-26 0001104659-10-030931 — 5.02
- 2010-05-14 0001104659-10-028664 — 1.01, 2.03, 9.01
- 2010-04-30 0001104659-10-023493 — 8.01, 9.01
- 2010-04-29 0001104659-10-022773 — 1.02, 8.01, 9.01
- 2010-04-20 0001104659-10-020750 — 2.02, 9.01
- 2010-04-16 0001104659-10-020113 — 5.07
- 2010-03-22 0001104659-10-015668 — 1.01, 9.01
- 2010-03-03 0001104659-10-011870 — 1.01, 2.03, 9.01
- 2010-01-20 0001104659-10-002269 — 2.02, 9.01
- 2009-10-29 0001104659-09-060949 — 5.02, 7.01
- 2009-10-20 0001104659-09-059594 — 2.02, 9.01
- 2009-10-01 0001104659-09-057311 — 1.01, 2.03, 2.06, 9.01
- 2009-09-22 0001104659-09-055716 — 7.01, 9.01
- 2009-08-04 0001193125-09-163032 — 2.05
- 2009-07-31 0001193125-09-160678 — 5.02, 9.01
- 2009-07-21 0001193125-09-152269 — 2.02, 9.01
- 2009-07-09 0001193125-09-146452 — 5.02
- 2009-06-24 0001193125-09-136674 — 7.01, 9.01
- 2009-06-01 0001193125-09-122549 — 1.01, 2.03, 9.01
- 2009-05-14 0001193125-09-110016 — 8.01, 9.01
- 2009-05-13 0001193125-09-109216 — 2.05, 7.01, 9.01
- 2009-05-05 0001193125-09-099861 — 1.01, 2.03, 9.01
- 2009-04-21 0001193125-09-083544 — 2.02, 9.01
- 2009-04-17 0001193125-09-081018 — 8.01, 9.01
- 2009-04-13 0001193125-09-077471 — 2.02, 9.01
- 2009-04-13 0001193125-09-077470 — 8.01, 9.01
- 2009-04-06 0001193125-09-073113 — 1.01, 2.03, 9.01
- 2009-03-09 0001193125-09-048538 — 5.02
- 2009-03-04 0001193125-09-044916 — 5.02, 8.01
- 2009-02-06 0001193125-09-021262 — 5.02
- 2009-02-04 0001193125-09-018804 — 5.02, 8.01
- 2009-02-02 0001193125-09-016478 — 2.06 — amendment, the index does not say of what
- 2009-01-27 0001193125-09-012058 — 5.02
- 2009-01-21 0001193125-09-009019 — 2.02, 5.02, 9.01
- 2009-01-14 0001193125-09-005721 — 2.05, 7.01
- 2009-01-12 0001193125-09-004420 — 5.02, 7.01, 9.01
- 2008-12-24 0001193125-08-259972 — 2.06
- 2008-12-12 0001193125-08-252765 — 2.03
- 2008-12-10 0001193125-08-250840 — 7.01
- 2008-11-12 0001193125-08-233906 — 5.02
- 2008-10-22 0001193125-08-214482 — 2.02, 9.01
- 2008-09-19 0001193125-08-198664 — 2.05
- 2008-09-12 0001193125-08-195206 — 1.01
- 2008-08-27 0001193125-08-185448 — 1.02, 3.01, 5.02, 9.01
- 2008-07-15 0001193125-08-151292 — 2.02, 9.01
- 2008-07-11 0001193125-08-149749 — 2.05
- 2008-07-03 0001193125-08-146791 — 5.02
- 2008-04-29 0001193125-08-094835 — 5.02, 9.01
- 2008-04-15 0001193125-08-081743 — 2.02, 9.01
- 2008-03-12 0001193125-08-054331 — 8.01, 9.01
- 2008-03-04 0001193125-08-045657 — 7.01
- 2008-02-04 0001193125-08-019262 — 8.01, 9.01
- 2008-01-18 0001193125-08-008849 — 8.01, 9.01
- 2008-01-17 0001193125-08-008120 — 2.02, 9.01
- 2007-12-21 0001193125-07-269469 — 2.05
- 2007-12-05 0001193125-07-259675 — 5.02
- 2007-10-17 0001193125-07-220376 — 8.01, 9.01
- 2007-10-16 0001193125-07-219386 — 2.02, 9.01
- 2007-09-18 0000950134-07-020112 — 5.02, 9.01
- 2007-08-29 0000950134-07-019145 — 1.01, 2.02, 9.01
- 2007-07-20 0001193125-07-159001 — 8.01, 9.01
- 2007-07-19 0001193125-07-158214 — 2.02, 9.01
- 2007-04-18 0001193125-07-083845 — 8.01, 9.01
- 2007-04-17 0001193125-07-082824 — 2.02, 9.01
- 2007-04-10 0001193125-07-077251 — 2.02, 9.01
- 2007-02-27 0001193125-07-040081 — 5.02, 7.01
- 2007-01-24 0001193125-07-011834 — 8.01, 9.01
- 2007-01-23 0001193125-07-010955 — 2.02, 9.01
- 2006-12-21 0001193125-06-257603 — 8.01, 9.01
- 2006-12-07 0001193125-06-247897 — 5.02
- 2006-11-07 0001193125-06-225545 — 2.02, 7.01, 8.01, 9.01
- 2006-11-01 0001193125-06-220706 — 1.01, 9.01
- 2006-10-25 0001193125-06-214798 — 8.01, 9.01
- 2006-10-24 0001193125-06-213813 — 2.02, 9.01
- 2006-10-11 0001193125-06-206304 — 5.02
- 2006-10-03 0001193125-06-201845 — 5.02, 9.01
- 2006-09-21 0001193125-06-194878 — 1.01, 1.02, 2.03, 2.04, 8.01, 9.01
- 2006-09-19 0001193125-06-192726 — 8.01, 9.01
- 2006-09-12 0001193125-06-189437 — 5.02, 8.01, 9.01
- 2006-08-24 0001193125-06-179258 — 1.01
- 2006-08-09 0001193125-06-167961 — 8.01, 9.01
- 2006-08-08 0001193125-06-165853 — 2.02, 9.01
- 2006-06-01 0001193125-06-122124 — 7.01, 9.01
- 2006-05-25 0001193125-06-119646 — 1.01, 2.01, 2.03, 5.02, 9.01
- 2006-05-17 0001193125-06-114760 — 8.01, 9.01
- 2006-05-04 0001193125-06-099262 — 8.01, 9.01
- 2006-05-03 0001193125-06-098229 — 5.05, 9.01
- 2006-04-27 0001193125-06-090749 — 8.01
- 2006-04-20 0001193125-06-084566 — 8.01, 9.01
- 2006-04-18 0001193125-06-082414 — 2.02, 9.01
- 2006-04-13 0001193125-06-079690 — 8.01
- 2006-04-03 0001193125-06-071956 — 8.01
- 2006-03-13 0001193125-06-051798 — 8.01
- 2006-02-14 0001193125-06-030829 — 8.01, 9.01
- 2006-01-26 0001193125-06-012909 — 8.01, 9.01
- 2006-01-25 0001193125-06-011608 — 8.01, 9.01
- 2006-01-19 0001193125-06-008770 — 8.01, 9.01
- 2006-01-18 0001193125-06-007939 — 2.02, 9.01
- 2005-12-22 0001193125-05-247782 — 1.01, 5.02, 9.01
- 2005-12-22 0001193125-05-247766 — 1.01, 9.01
- 2005-12-21 0001193125-05-246701 — 8.01, 9.01
- 2005-12-01 0001193125-05-234733 — 7.01
- 2005-11-23 0001193125-05-231674 — 1.01, 1.02, 7.01, 9.01
- 2005-10-19 0001193125-05-203955 — 2.02, 9.01
- 2005-10-18 0001193125-05-203356 — 2.02, 7.01, 9.01
- 2005-09-08 0001193125-05-181893 — 7.01, 9.01
- 2005-09-07 0001193125-05-181605 — 1.01
- 2005-08-04 0001193125-05-157913 — 8.01, 9.01
- 2005-08-03 0001193125-05-156407 — 1.01, 8.01, 9.01
- 2005-07-19 0001193125-05-144591 — 2.02, 9.01
- 2005-06-08 0001193125-05-121880 — 7.01
- 2005-05-17 0001193125-05-109518 — 7.01
- 2005-04-19 0001193125-05-079453 — 2.02, 9.01
- 2005-03-22 0001193125-05-057519 — 1.01
- 2005-03-16 0001193125-05-052560 — 7.01
- 2005-03-07 0001193125-05-043752 — 7.01, 9.01
- 2005-02-08 0001193125-05-022340 — 1.01, 7.01
- 2005-01-18 0001193125-05-007666 — 2.02, 9.01
- 2004-12-13 0001193125-04-211590 — 7.01, 8.01, 9.01
- 2004-12-07 0001193125-04-208768 — 7.01, 9.01
- 2004-10-29 0001193125-04-181463 — 1.01, 5.02, 9.01
- 2004-10-19 0001193125-04-173795 — 2.02, 9.01
- 2004-09-23 0001193125-04-160889 — 8.01, 9.01
- 2004-09-21 0001193125-04-159593 — 8.01, 9.01
- 2004-09-07 0001193125-04-152868 — 7.01, 9.01
- 2004-07-28 0001193125-04-126152 — 5, 7
- 2004-07-20 0001193125-04-121017 — 12, 7
- 2004-06-02 0001193125-04-097697 — 7, 9
- 2004-04-30 0001193125-04-075386 — 5, 7
- 2004-04-20 0001193125-04-065621 — 12, 7
- 2004-04-06 0001193125-04-057855 — 12, 7
- 2004-03-16 0001193125-04-042542 — 5
- 2004-03-03 0001193125-04-033653 — 7, 9
- 2004-01-21 0001193125-04-006388 — 12, 5, 7
- 2003-10-31 0001193125-03-070294 — 5, 7
- 2003-10-27 0001193125-03-067685 — 5, 7
- 2003-10-22 0001193125-03-065398 — 12, 5, 7
- 2003-07-16 0001193125-03-019880 — 7, 9
- 2003-07-10 0001193125-03-018043 — 5
- 2003-07-07 0001193125-03-016864 — 5
- 2003-06-27 0001193125-03-014262 — 5, 7
- 2003-04-16 0001012870-03-001799 — 7, 9

## late-filing notifications on or before 2016-04-29

- none on or before 2016-04-29

## item 2.02 — earnings release, exhibit 99.1

[0001104659-16-115593:8k_2_02:1]
EX-99.1
2
a16-9885_1ex99d1.htm
PRESS RELEASE DATED APRIL 29, 2016

[0001104659-16-115593:8k_2_02:2]
Exhibit 99.1

[0001104659-16-115593:8k_2_02:3]
Press Release

[0001104659-16-115593:8k_2_02:4]
Media Relations Contact:

[0001104659-16-115593:8k_2_02:5]
Eric DeRitis (408) 658-1561

[0001104659-16-115593:8k_2_02:6]
eric.deritis@seagate.com

[0001104659-16-115593:8k_2_02:7]
SEAGATE

[0001104659-16-115593:8k_2_02:8]
SEAGATE TECHNOLOGY REPORTS FISCAL THIRD QUARTER 2016 FINANCIAL RESULTS

[0001104659-16-115593:8k_2_02:9]
CUPERTINO, CA — April 29, 2016 — Seagate Technology plc (NASDAQ: STX) (the “Company” or “Seagate”) today reported financial results for the third quarter of fiscal year 2016 ended April 1, 2016. For the third quarter, the Company reported revenue of approximately $2.6 billion, gross margin of 20.2%, net loss of $21 million and diluted loss per share of $0.07.  On a non-GAAP basis, which excludes the net impact of certain items, Seagate reported gross margin of 22.7%, net income of $66 million and diluted earnings per share of $0.22. For a detailed reconciliation of GAAP to non-GAAP results, see the accompanying financial tables.

[0001104659-16-115593:8k_2_02:10]
During the third quarter, the Company generated approximately $205 million in operating cash flow and paid cash dividends of $188 million. There were 298 million ordinary shares issued and outstanding as of the end of the quarter. Cash, cash equivalents and short-term investments totaled approximately $1.2 billion at the end of the quarter.

[0001104659-16-115593:8k_2_02:11]
“Our quarterly results fell short of our expectations as a result of several near-term demand factors.  Despite these challenges, we believe we have the product portfolio, technology roadmap and operational leverage to ensure we are well-positioned for long-term success,” said Steve Luczo, Seagate’s chairman and chief executive officer. “Accordingly, we are aggressively working to position Seagate to respond to new demand levels and are committed to ongoing financial discipline.”

[0001104659-16-115593:8k_2_02:12]
Luczo continued, “Although the short-term dynamics of our industry are challenging, we continue to see significant and growing Exabyte demand, particularly as enterprise applications shift to cloud environments.  As we look forward, our strategic focus is unchanged — we are broadening our storage portfolio to meet the needs of our growing global customer base, building upon our strong competitive position and optimizing our business for continued financial performance.  These focus areas will enable us to build lasting value for shareholders.”

[0001104659-16-115593:8k_2_02:13]
Seagate has issued a Supplemental Financial Information document, which is available on Seagate’s Investors website at www.seagate.com/investors.

[0001104659-16-115593:8k_2_02:14]
Quarterly Cash Dividend

[0001104659-16-115593:8k_2_02:15]
The Company’s Board of Directors has approved a quarterly cash dividend of $0.63 per share, which will be payable on May 24, 2016 to shareholders of record as of the close of business on May 10, 2016. The payment of any future quarterly dividends will be at the discretion of the Board and will be dependent upon Seagate’s financial position, results of operations, available cash, cash flow, capital requirements and other factors deemed relevant by the Board of Directors.

[0001104659-16-115593:8k_2_02:16]
Investor Communications

[0001104659-16-115593:8k_2_02:17]
Seagate management will hold a public webcast today at 6:00 a.m. Pacific Time that can be accessed on its Investors website at www.seagate.com/investors. During today’s webcast, the Company will provide an outlook for its fourth fiscal quarter of 2016 including key underlying assumptions.

[0001104659-16-115593:8k_2_02:18]
Replay

[0001104659-16-115593:8k_2_02:19]
A replay will be available beginning today at approximately 9:00 a.m. Pacific Time at http://www.seagate.com/investors.

[0001104659-16-115593:8k_2_02:20]
About Seagate

[0001104659-16-115593:8k_2_02:21]
To learn more about the company’s products and services, visit www.seagate.com and follow us on Twitter, Facebook, LinkedIn, Spiceworks, YouTube and subscribe to our blog. The contents of our website and social media channels are not a part of this release.

[0001104659-16-115593:8k_2_02:22]
Cautionary Note Regarding Forward-Looking Statements

[0001104659-16-115593:8k_2_02:23]
The inclusion of Seagate’s website address in this press release is intended to be an inactive textual reference only and not an active hyperlink. The information contained in, or that can be accessed through, Seagate’s website is not part of this press release.

[0001104659-16-115593:8k_2_02:24]
SEAGATE TECHNOLOGY PLC

[0001104659-16-115593:8k_2_02:25]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-16-115593:8k_2_02:26]
(In millions)

[0001104659-16-115593:8k_2_02:27]
(Unaudited)

[0001104659-16-115593:8k_2_02:28]
|  |  | April 1, 2016 |  | July 3, 2015 (a) |  |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,193 |  | $ | 2,479 |  |
| Short-term investments |  | 6 |  | 6 |  |
| Accounts receivable, net |  | 1,250 |  | 1,735 |  |
| Inventories |  | 928 |  | 993 |  |
| Deferred income taxes |  | — |  | 122 |  |
| Other current assets |  | 223 |  | 233 |  |
| Total current assets |  | 3,600 |  | 5,568 |  |
| Property, equipment and leasehold improvements, net |  | 2,165 |  | 2,278 |  |
| Goodwill |  | 1,238 |  | 874 |  |
| Other intangible assets, net |  | 492 |  | 370 |  |
| Deferred income taxes |  | 619 |  | 496 |  |
| Other assets, net |  | 260 |  | 259 |  |
| Total Assets |  | $ | 8,374 |  | $ | 9,845 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |
| Accounts payable |  | $ | 1,504 |  | $ | 1,540 |  |
| Accrued employee compensation |  | 170 |  | 256 |  |
| Accrued warranty |  | 108 |  | 135 |  |
| Accrued expenses |  | 477 |  | 412 |  |
| Total current liabilities |  | 2,259 |  | 2,343 |  |
| Long-term accrued warranty |  | 97 |  | 113 |  |
| Long-term accrued income taxes |  | 28 |  | 33 |  |
| Other non-current liabilities |  | 177 |  | 183 |  |
| Long-term debt |  | 4,130 |  | 4,155 |  |
| Total Liabilities |  | 6,691 |  | 6,827 |  |
| Equity: |  |  |  |  |  |
| Total Equity |  | 1,683 |  | 3,018 |  |
| Total Liabilities and Equity |  | $ | 8,374 |  | $ | 9,845 |  |

[0001104659-16-115593:8k_2_02:29]
(a) The information as of July 3, 2015 was derived from the Company’s audited Consolidated Balance Sheet as of July 3, 2015.

[0001104659-16-115593:8k_2_02:30]
SEAGATE TECHNOLOGY PLC

[0001104659-16-115593:8k_2_02:31]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-16-115593:8k_2_02:32]
(In millions, except per share data)

[0001104659-16-115593:8k_2_02:33]
(Unaudited)

[0001104659-16-115593:8k_2_02:34]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |
|  |  | April 1, 2016 |  | April 3, 2015 |  | April 1, 2016 |  | April 3, 2015 |  |
| Revenue |  | $ | 2,595 |  | $ | 3,330 |  | $ | 8,506 |  | $ | 10,811 |  |
| Cost of revenue |  | 2,071 |  | 2,375 |  | 6,553 |  | 7,778 |  |
| Product development |  | 298 |  | 346 |  | 930 |  | 1,029 |  |
| Marketing and administrative |  | 150 |  | 219 |  | 491 |  | 654 |  |
| Amortization of intangibles |  | 29 |  | 33 |  | 94 |  | 95 |  |
| Restructuring and other, net |  | 20 |  | 14 |  | 95 |  | 24 |  |
| Gain on arbitration award, net |  | — |  | — |  | — |  | (620 | ) |
| Total operating expenses |  | 2,568 |  | 2,987 |  | 8,163 |  | 8,960 |  |
| Income from operations |  | 27 |  | 343 |  | 343 |  | 1,851 |  |
| Interest income |  | 1 |  | 1 |  | 2 |  | 4 |  |
| Interest expense |  | (47 | ) | (48 | ) | (142 | ) | (152 | ) |
| Other, net |  | 28 |  | 8 |  | 18 |  | 118 |  |
| Other (expense) income, net |  | (18 | ) | (39 | ) | (122 | ) | (30 | ) |
| Income before income taxes |  | 9 |  | 304 |  | 221 |  | 1,821 |  |
| Provision for income taxes |  | 30 |  | 13 |  | 43 |  | 216 |  |
| Net income (loss) |  | $ | (21 | ) | $ | 291 |  | $ | 178 |  | $ | 1,605 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.07 | ) | $ | 0.90 |  | $ | 0.59 |  | $ | 4.92 |  |
| Diluted |  | (0.07 | ) | 0.88 |  | 0.59 |  | 4.81 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |  |
| Basic |  | 298 |  | 323 |  | 300 |  | 326 |  |
| Diluted |  | 298 |  | 330 |  | 303 |  | 334 |  |
| Cash dividends declared per ordinary share |  | $ | 0.63 |  | $ | 0.54 |  | $ | 1.80 |  | $ | 1.51 |  |

[0001104659-16-115593:8k_2_02:35]
SEAGATE TECHNOLOGY PLC

[0001104659-16-115593:8k_2_02:36]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001104659-16-115593:8k_2_02:37]
(In millions)

[0001104659-16-115593:8k_2_02:38]
(Unaudited)

[0001104659-16-115593:8k_2_02:39]
|  |  | For the Nine Months Ended |  |
|  |  | April 1, 2016 |  | April 3, 2015 |  |
| OPERATING ACTIVITIES |  |  |  |  |  |
| Net income |  | $ | 178 |  | $ | 1,605 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |
| Depreciation and amortization |  | 615 |  | 629 |  |
| Share-based compensation |  | 95 |  | 106 |  |
| Impairment of long-lived assets |  | 25 |  | — |  |
| Deferred income taxes |  | 1 |  | (3 | ) |
| Loss on sale of property and equipment |  | — |  | 1 |  |
| (Gain) loss on redemption and repurchase of debt |  | (3 | ) | 52 |  |
| Other non-cash operating activities, net |  | 13 |  | (9 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |
| Accounts receivable, net |  | 531 |  | (36 | ) |
| Inventories |  | 85 |  | (61 | ) |
| Accounts payable |  | (31 | ) | 149 |  |
| Accrued employee compensation |  | (92 | ) | (40 | ) |
| Accrued expenses, income taxes and warranty |  | 1 |  | (9 | ) |
| Vendor non-trade receivables |  | 17 |  | 30 |  |
| Other assets and liabilities |  | (24 | ) | 5 |  |
| Net cash provided by operating activities |  | 1,411 |  | 2,419 |  |
| INVESTING ACTIVITIES |  |  |  |  |  |
| Acquisition of property, equipment and leasehold improvements |  | (441 | ) | (546 | ) |
| Purchases of short-term investments |  | — |  | (5 | ) |
| Sales of short-term investments |  | — |  | 4 |  |
| Maturities of short-term investments |  | — |  | 19 |  |
| Cash used in acquisition of business, net of cash acquired |  | (634 | ) | (450 | ) |
| Other investing activities, net |  | 10 |  | (90 | ) |
| Net cash used in investing activities |  | (1,065 | ) | (1,068 | ) |
| FINANCING ACTIVITIES |  |  |  |  |  |
| Redemption and repurchase of debt |  | (22 | ) | (536 | ) |
| Net proceeds from issuance of long-term debt |  | — |  | 498 |  |
| Taxes paid related to net share settlement of equity awards |  | (55 | ) | — |  |
| Repurchases of ordinary shares |  | (1,090 | ) | (907 | ) |
| Dividends to shareholders |  | (539 | ) | (493 | ) |
| Proceeds from issuance of ordinary shares under employee stock plans |  | 78 |  | 91 |  |
| Other financing activities, net |  | (4 | ) | (12 | ) |
| Net cash used in financing activities |  | (1,632 | ) | (1,359 | ) |
| Effect of foreign currency exchange rate changes on cash and cash equivalents |  | — |  | (22 | ) |
| (Decrease) in cash and cash equivalents |  | (1,286 | ) | (30 | ) |
| Cash and cash equivalents at the beginning of the period |  | 2,479 |  | 2,634 |  |
| Cash and cash equivalents at the end of the period |  | $ | 1,193 |  | $ | 2,604 |  |

[0001104659-16-115593:8k_2_02:40]
Use of non-GAAP financial information

[0001104659-16-115593:8k_2_02:41]
To supplement the condensed consolidated financial statements presented in accordance with generally accepted accounting principles (GAAP), the Company provides non-GAAP measures of net income, diluted net earnings per share and gross margin, which are adjusted from results based on GAAP to exclude certain expenses, gains and losses. These non-GAAP financial measures are provided to enhance the user’s overall understanding of the Company’s current financial performance and our prospects for the future. Specifically, the Company believes non-GAAP results provide useful information to both management and investors as these non-GAAP results exclude certain expenses, gains and losses that we believe are not indicative of our core operating results and because it is consistent with the financial models and estimates published by financial analysts who follow the Company.

[0001104659-16-115593:8k_2_02:42]
These non-GAAP results are some of the primary measurements management uses to assess the Company’s performance, allocate resources and plan for future periods. Reported non-GAAP results should only be considered as supplemental to results prepared in accordance with GAAP, and not considered as a substitute for, or superior to, GAAP results. These non-GAAP measures may differ from the non-GAAP measures reported by other companies in our industry.

[0001104659-16-115593:8k_2_02:43]
SEAGATE TECHNOLOGY PLC

[0001104659-16-115593:8k_2_02:44]
ADJUSTMENTS TO GAAP NET INCOME (LOSS) AND DILUTED NET INCOME PER SHARE

[0001104659-16-115593:8k_2_02:45]
(In millions, except per share amounts)

[0001104659-16-115593:8k_2_02:46]
(Unaudited)

[0001104659-16-115593:8k_2_02:47]
|  |  |  | For the Three Months Ended April 1, 2016 |  | For the Nine Months Ended April 1, 2016 |  |
| GAAP net income (loss) |  |  | $ | (21 | ) | $ | 178 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |
| Revenue | A |  | (4 | ) | (3 | ) |
| Cost of revenue | B |  | 67 |  | 107 |  |
| Product development | C |  | 2 |  | 11 |  |
| Marketing and administrative | D |  | 9 |  | 23 |  |
| Amortization of intangibles | E |  | 27 |  | 89 |  |
| Restructuring and other, net | F |  | 20 |  | 96 |  |
| Other expense (income), net | G |  | (34 | ) | (24 | ) |
| Non-GAAP net income |  |  | $ | 66 |  | $ | 477 |  |
| Diluted net income (loss) per share: |  |  |  |  |  |  |
| GAAP |  |  | $ | (0.07 | ) | $ | 0.59 |  |
| Non-GAAP |  |  | $ | 0.22 |  | $ | 1.57 |  |
| Shares used in diluted net income (loss) per share calculation |  |  |  |  |  |  |
| GAAP |  |  | 298 |  | 303 |  |
| Non-GAAP |  |  | 299 |  | 303 |  |

[0001104659-16-115593:8k_2_02:48]
A For the three and nine months ended April 1, 2016, Revenue has been adjusted on a non-GAAP basis to exclude sales return provision for certain products that will be discontinued and revenue associated with our disposed data services business.

[0001104659-16-115593:8k_2_02:49]
B For the three and nine months ended April 1, 2016, Cost of revenue has been adjusted on a non-GAAP basis to exclude amortization of intangibles associated with acquisitions, recognition of certain terminated contracts and write down of inventory, other acquisition related expenses, and write off of certain fixed assets.

[0001104659-16-115593:8k_2_02:50]
C For the three and nine months ended April 1, 2016, Product development expenses have been adjusted on a non-GAAP basis to exclude the impact of integration costs associated with acquisitions.

[0001104659-16-115593:8k_2_02:51]
D For the three and nine months ended April 1, 2016, Marketing and administrative expenses have been adjusted on a non-GAAP basis to exclude the write off of certain fixed assets, the impact of integration costs associated with acquisitions, and marketing and administrative expenses of our disposed data services business.

[0001104659-16-115593:8k_2_02:52]
E For three and nine months ended April 1, 2016, Amortization of intangibles primarily related to our acquisitions has been excluded on a non-GAAP basis.

[0001104659-16-115593:8k_2_02:53]
F For three and nine months ended April 1, 2016, Restructuring and other net, primarily related to a reduction in our work force as a result of our ongoing focus on cost efficiencies in all areas of our business, has been excluded on a non-GAAP basis.

[0001104659-16-115593:8k_2_02:54]
G For three and nine months ended April 1, 2016, Other expense (income), net has been adjusted on a non-GAAP basis to exclude the payment of the unpaid interest of $33 million on the final arbitration award amount in the Company’s case against Western Digital, the net impact of gains recognized on the early repurchase of debt, and the impairment of certain strategic investments.
