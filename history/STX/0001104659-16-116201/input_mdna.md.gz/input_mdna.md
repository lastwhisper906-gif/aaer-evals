# STX MD&A — 0001104659-16-116201


## mdna

[0001104659-16-116201:mdna:1]
ITEM 2.            MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001104659-16-116201:mdna:2]
The following is a discussion of the financial condition, changes in financial condition, and results of operations for our fiscal quarters ended April 1, 2016, January 1, 2016 and  April 3, 2015, referred to herein as the “March 2016 quarter,” the “December 2015 quarter,” and the “March 2015 quarter,” respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The March 2016, December 2015, and March 2015 quarters were 13 weeks.

[0001104659-16-116201:mdna:3]
[same as prior period, unchanged from 0001104659-16-092467:mdna:3]

[0001104659-16-116201:mdna:4]
[same as prior period, unchanged from 0001104659-16-092467:mdna:4]

[0001104659-16-116201:mdna:5]
·                  Our Company. Overview of our business.

[0001104659-16-116201:mdna:6]
·                  Overview of the March 2016 quarter. Highlights of events in the March 2016 quarter that impacted our financial position.

[0001104659-16-116201:mdna:7]
·                  Results of Operations. An analysis of our financial results comparing the March 2016 quarter to the December 2015 quarter and the March 2015 quarter and the nine months ended March 2016 to the nine months ended March 2015.

[0001104659-16-116201:mdna:8]
·                  Liquidity and Capital Resources. An analysis of changes in our balance sheets and cash flows, and discussion of our financial condition including the credit quality of our investment portfolio and potential sources of liquidity.

[0001104659-16-116201:mdna:9]
·                  Critical Accounting Policies. Accounting policies and estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001104659-16-116201:mdna:10]
[same as prior period, unchanged from 0001104659-16-092467:mdna:11]

[0001104659-16-116201:mdna:11]
[same as prior period, unchanged from 0001104659-16-092467:mdna:12]

[0001104659-16-116201:mdna:12]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and most SSDs use NAND-based flash memory. In addition to HDDs and SSDs, SSHDs combine the features of SSDs

[0001104659-16-116201:mdna:13]
30

[0001104659-16-116201:mdna:14]
and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed data.

[0001104659-16-116201:mdna:15]
[same as prior period, unchanged from 0001104659-16-092467:mdna:14]

[0001104659-16-116201:mdna:16]
[same as prior period, unchanged from 0001104659-16-092467:mdna:15]

[0001104659-16-116201:mdna:17]
Overview of the March 2016 Quarter

[0001104659-16-116201:mdna:18]
During the quarter ended March 2016, the industry experienced accelerated declines in drive unit shipments primarily as demand decreased for mission critical and client compute hard drives. During the March 2016 quarter, we shipped 39 million drive units totaling 56 exabytes of storage capacity, generating revenue of approximately $2.6 billion and gross margin of 20%. Our operating cash flow was $205 million. We paid $188 million for dividends to shareholders.

[0001104659-16-116201:mdna:19]
[same as prior period, unchanged from 0001104659-16-092467:mdna:18]

[0001104659-16-116201:mdna:20]
[same as prior period, unchanged from 0001104659-16-092467:mdna:19]

[0001104659-16-116201:mdna:21]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | April 1, 2016 |  | January 1, 2016 |  | April 3, 2015 |  | April 1, 2016 |  | April 3, 2015 |  |
| Revenue |  | $ | 2,595 |  | $ | 2,986 |  | $ | 3,330 |  | $ | 8,506 |  | $ | 10,811 |  |
| Cost of revenue |  | 2,071 |  | 2,245 |  | 2,375 |  | 6,553 |  | 7,778 |  |
| Gross margin |  | 524 |  | 741 |  | 955 |  | 1,953 |  | 3,033 |  |
| Product development |  | 298 |  | 304 |  | 346 |  | 930 |  | 1,029 |  |
| Marketing and administrative |  | 150 |  | 160 |  | 219 |  | 491 |  | 654 |  |
| Amortization of intangibles |  | 29 |  | 31 |  | 33 |  | 94 |  | 95 |  |
| Restructuring and other, net |  | 20 |  | 17 |  | 14 |  | 95 |  | 24 |  |
| Gain on litigation settlement, net |  | — |  | — |  | — |  | — |  | (620 | ) |
| Income from operations |  | 27 |  | 229 |  | 343 |  | 343 |  | 1,851 |  |
| Other income (expense), net |  | (18 | ) | (49 | ) | (39 | ) | (122 | ) | (30 | ) |
| Income before income taxes |  | 9 |  | 180 |  | 304 |  | 221 |  | 1,821 |  |
| Provision for income taxes |  | 30 |  | 15 |  | 13 |  | 43 |  | 216 |  |
| Net income (loss) |  | $ | (21 | ) | $ | 165 |  | $ | 291 |  | $ | 178 |  | $ | 1,605 |  |

[0001104659-16-116201:mdna:22]
31

[0001104659-16-116201:mdna:23]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |
|  |  | April 1, 2016 |  | January 1, 2016 |  | April 3, 2015 |  | April 1, 2016 |  | April 3, 2015 |  |
| Revenue |  | 100 | % | 100 | % | 100 | % | 100 | % | 100 | % |
| Cost of revenue |  | 80 |  | 75 |  | 71 |  | 77 |  | 72 |  |
| Gross margin |  | 20 |  | 25 |  | 29 |  | 23 |  | 28 |  |
| Product development |  | 11 |  | 10 |  | 10 |  | 11 |  | 10 |  |
| Marketing and administrative |  | 6 |  | 5 |  | 7 |  | 6 |  | 6 |  |
| Amortization of intangibles |  | 1 |  | 1 |  | 1 |  | 1 |  | 1 |  |
| Restructuring and other, net |  | 1 |  | 1 |  | — |  | 1 |  | — |  |
| Gain on litigation settlement, net |  | — |  | — |  | — |  | — |  | (6 | ) |
| Income from operations |  | 1 |  | 8 |  | 11 |  | 4 |  | 17 |  |
| Other (expense) income, net |  | (1 | ) | (2 | ) | (1 | ) | (1 | ) | — |  |
| Income before income taxes |  | — |  | 6 |  | 10 |  | 3 |  | 17 |  |
| Provision for income taxes |  | 1 |  | 1 |  | — |  | 1 |  | 2 |  |
| Net income (loss) |  | (1 | )% | 6 | % | 10 | % | 2 | % | 15 | % |

[0001104659-16-116201:mdna:24]
[same as prior period, unchanged from 0001104659-16-092467:mdna:23]

[0001104659-16-116201:mdna:25]
[same as prior period, unchanged from 0001104659-16-092467:mdna:24]

[0001104659-16-116201:mdna:26]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |
| (In millions, except percentages, exabytes and ASPs) |  | April 1, 2016 |  | January 1, 2016 |  | April 3, 2015 |  | April 1, 2016 |  | April 3, 2015 |  |
| Unit Shipments: |  |  |  |  |  |  |  |  |  |  |  |
| Enterprise |  | 8 |  | 8 |  | 9 |  | 23 |  | 27 |  |
| Client Compute |  | 21 |  | 25 |  | 31 |  | 76 |  | 106 |  |
| Client Non-Compute |  | 10 |  | 13 |  | 10 |  | 33 |  | 34 |  |
| Total Units Shipped |  | 39 |  | 46 |  | 50 |  | 132 |  | 167 |  |
| ASPs (per unit) |  | $ | 60 |  | $ | 59 |  | $ | 62 |  | $ | 59 |  | $ | 61 |  |
| Exabytes Shipped |  | 56 |  | 61 |  | 55 |  | 171 |  | 176 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 69 | % | 69 | % | 70 | % | 69 | % | 70 | % |
| Distributors |  | 16 | % | 16 | % | 18 | % | 17 | % | 18 | % |
| Retailers |  | 15 | % | 15 | % | 12 | % | 14 | % | 12 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | 30 | % | 26 | % | 29 | % | 28 | % | 27 | % |
| EMEA |  | 17 | % | 19 | % | 16 | % | 18 | % | 17 | % |
| Asia Pacific |  | 53 | % | 55 | % | 55 | % | 54 | % | 56 | % |

[0001104659-16-116201:mdna:27]
Revenue in the March 2016 quarter decreased by $0.4 billion from the December 2015 quarter as a result of a decrease in shipments by 7 million units due to lower demand and seasonality declines.

[0001104659-16-116201:mdna:28]
Revenue in the March 2016 quarter and the nine months then ended decreased by $0.7 billion and $2.3 billion, respectively, as compared to the March 2015 quarter and the nine months then ended due to a decrease in unit shipments and price erosion, partially offset by improved product mix and the consolidation of Dot Hill. The decrease in unit shipments of 11 million and 35 million units as compared to the three and nine months ended March 2015, respectively, was primarily the result of decreased demand in the client compute market and reduced demand for mission critical HDD enterprise products in the December 2015 quarter.

[0001104659-16-116201:mdna:29]
We maintain various sales programs such as channel rebates and price masking. Price masking rebates are primarily a function of OEM enterprise revenue and contributed to a higher proportion of the sales programs as a percentage of revenue in the March 2016 quarter. Sales programs were approximately 14%, 14% and 11% of gross drive revenue for the March 2016 quarter, December 2015 quarter and March 2015 quarter, respectively. Adjustments to revenues due to under or over

[0001104659-16-116201:mdna:30]
[same as prior period, unchanged from 0001104659-16-092467:mdna:10]

[0001104659-16-116201:mdna:31]
accruals for sales programs related to revenues reported in prior quarterly periods were less than 1.0% of quarterly gross revenue in the March 2016 quarter.

[0001104659-16-116201:mdna:32]
[same as prior period, unchanged from 0001104659-16-092467:mdna:29]

[0001104659-16-116201:mdna:33]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | April 1, 2016 |  | January 1, 2016 |  | April 3, 2015 |  | April 1, 2016 |  | April 3, 2015 |  |
| Cost of revenue |  | $ | 2,071 |  | $ | 2,245 |  | $ | 2,375 |  | $ | 6,553 |  | $ | 7,778 |  |
| Gross margin |  | 524 |  | 741 |  | 955 |  | 1,953 |  | 3,033 |  |
| Gross margin percentage |  | 20 | % | 25 | % | 29 | % | 23 | % | 28 | % |

[0001104659-16-116201:mdna:34]
Gross margin as a percentage of revenue for the March 2016 quarter decreased by 460 basis points compared to the December 2015 quarter. This decrease was primarily due to approximately 100 basis points of change in gross margin from reduced demand in legacy hard drives and new adjacencies and focused inventory reductions resulting in underutilization of certain factories, 80 basis points decrease associated with costs from certain terminated contracts and write down of inventory, and 100 basis points decrease from the write off of certain fixed assets. Price erosion was offset by improved product mix.

[0001104659-16-116201:mdna:35]
Compared to the March 2015 quarter, gross margin in the March 2016 quarter decreased by 850 basis points. This decrease was due to approximately 230 basis points of change in gross margin from reduced demand in legacy hard drives and new adjacencies resulting in underutilization of certain factories, 80 basis points decrease associated with costs from certain terminated contracts and write down of inventory, 100 basis points decrease associated with the write off of certain fixed assets, with the remainder primarily due to price erosion that was partially offset by improved product mix and cost savings due to work force reductions.

[0001104659-16-116201:mdna:36]
Compared to the nine months ended in the March 2015 quarter, gross margin in the nine month ended in the March 2016 quarter decreased by 510 basis points. This decrease was due to approximately 110 basis points of change in gross margin from reduced demand in legacy hard drives and new adjacencies resulting in underutilization of certain factories, with the remainder primarily due to price erosion that was partially offset by cost savings due to work force reductions and improved product mix.

[0001104659-16-116201:mdna:37]
In the March 2016 quarter, total warranty cost was 0.7% of revenue and included favorable changes in estimates of prior warranty accruals of approximately 0.4% of revenue primarily due to improvements in return rates on newer generation products. Warranty cost related to new unit shipments was 1.1% of revenue for each of the March 2016, December 2015 and March 2015 quarters, respectively.

[0001104659-16-116201:mdna:38]
[same as prior period, unchanged from 0001104659-16-092467:mdna:33]

[0001104659-16-116201:mdna:39]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | April 1, 2016 |  | January 1, 2016 |  | April 3, 2015 |  | April 1, 2016 |  | April 3, 2015 |  |
| Product development |  | $ | 298 |  | $ | 304 |  | $ | 346 |  | $ | 930 |  | $ | 1,029 |  |
| Marketing and administrative |  | 150 |  | 160 |  | 219 |  | 491 |  | 654 |  |
| Amortization of intangibles |  | 29 |  | 31 |  | 33 |  | 94 |  | 95 |  |
| Restructuring and other, net |  | 20 |  | 17 |  | 14 |  | 95 |  | 24 |  |
| Gain on litigation settlement, net |  | — |  | — |  | — |  | — |  | (620 | ) |
| Operating expenses |  | $ | 497 |  | $ | 512 |  | $ | 612 |  | $ | 1,610 |  | $ | 1,182 |  |

[0001104659-16-116201:mdna:40]
Product development expense.  Product development expense for the March 2016 quarter decreased by $6 million from the December 2015 quarter due to increased operational efficiencies in our business and a decrease in variable compensation, partially offset by an increased use of vacation in the December 2015 quarter. Compared to the March 2015 quarter, product development expense decreased by $48 million due to a decrease in salaries and other employee benefits of $20 million as a result of a restructuring of our work force in the September 2015 quarter, an $11 million decrease in variable compensation, and other cost reduction efforts, partially offset by the consolidation of Dot Hill in the December 2015 quarter.

[0001104659-16-116201:mdna:41]
Product development expense for the nine months ended March 2016 decreased by $99 million as compared to the corresponding period in the prior year due to a decrease in salaries and other employee benefits of  $46 million as a result of a restructuring of our work force in the September 2015 quarter, a $41 million decrease in variable compensation, and other cost reduction efforts, partially offset by the consolidation of Dot Hill in the December 2015 quarter.

[0001104659-16-116201:mdna:42]
Marketing and administrative expense. Marketing and administrative expense for the March 2016 quarter decreased by $10 million from the December 2015 quarter due to a $9 million reduction in advertising from the completion of certain promotional and

[0001104659-16-116201:mdna:43]
33

[0001104659-16-116201:mdna:44]
branding activities in the December 2015 quarter and a decrease in variable compensation. Compared to the March 2015 quarter, marketing and administrative expense decreased by $69 million due to a decrease in salaries and other employee benefits of $24 million as a result of a restructuring of our work force in the September 2015 quarter, a $17 million reduction in advertising from the completion of certain promotional and branding activities in the December 2015 quarter, and a decrease in variable compensation, partially offset by the consolidation of Dot Hill in the December 2015 quarter.

[0001104659-16-116201:mdna:45]
Marketing and administrative expense for the nine months ended March 2016 decreased by $163 million as compared to the corresponding period in the prior year due to a decrease in salaries and other employee benefits of $60 million as a result of a restructuring of our work force in the September 2015 quarter, a $43  million decrease in variable compensation and stock based compensation, a $21 million reduction in advertising from the completion of certain promotional and branding activities in the December 2015 quarter, and increased operational efficiencies in our business.

[0001104659-16-116201:mdna:46]
Amortization of intangibles. Amortization of intangibles for the March 2016 quarter decreased from the December 2015 quarter and March 2015 quarter by $2 million and $4 million, respectively, due to certain intangible assets reaching the end of their useful life, partially offset by the intangibles acquired in the acquisition of Dot Hill.

[0001104659-16-116201:mdna:47]
Amortization of intangibles for the nine months ended March  2016 decreased by $1 million as compared to the corresponding period in the prior year as a result certain intangible assets reaching the end of their useful life, partially offset by the amortization of intangibles acquired with LSI Corporation’s Accelerated Solutions Division and Flash Components Division in September of 2014 and Dot Hill in the December 2015 quarter.

[0001104659-16-116201:mdna:48]
Restructuring and other, net. Restructuring and other, net for the March 2016 quarter was comprised primarily of a restructuring charge recorded during the March 2016 quarter to reduce our work force by approximately 2,000 employees to align our manufacturing footprint with current macroeconomic conditions. The December 2015 quarter and the March 2015 quarter was comprised primarily of charges related to employee termination costs and facility exit costs associated with restructuring of our work force.

[0001104659-16-116201:mdna:49]
Restructuring and other, net for the nine months ended March  2016 was comprised primarily of restructuring charges recorded during the September 2015 quarter and the March 2016 quarter to reduce our work force. Restructuring and other, net for the nine months ended March 2015 was due to charges to reduce our work force as a result of our ongoing focus on cost efficiencies in all areas of our business.

[0001104659-16-116201:mdna:50]
Gain on arbitration award, net. Gain on arbitration award, net for the nine months then ended March 2015 was related to the final award amount of $630 million, less litigation and other related costs of $10 million, in the Company’s case against Western Digital for the misappropriation of the Company’s trade secrets.

[0001104659-16-116201:mdna:51]
[same as prior period, unchanged from 0001104659-16-092467:mdna:45]

[0001104659-16-116201:mdna:52]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | April 1, 2016 |  | January 1, 2016 |  | April 3, 2015 |  | April 1, 2016 |  | April 3, 2015 |  |
| Other (expense) income, net |  | $ | (18 | ) | $ | (49 | ) | $ | (39 | ) | $ | (122 | ) | $ | (30 | ) |

[0001104659-16-116201:mdna:53]
Other (expense) income, net decreased by $31 million from the December 2015 quarter primarily due to the $33 million final payment of unpaid interest on the final arbitration award amount in the Company’s case against Western Digital. Compared to the March 2015 quarter, other (expense) income, net decreased by $21 million due to the $33 million final payment of unpaid interest from Western Digital, partially offset by a $16 million change in foreign currency remeasurement related to changes in foreign exchange rates.

[0001104659-16-116201:mdna:54]
Other (expense) income, net for the nine months ended March 2016 increased $92 million as compared to the corresponding period in the prior year due to the partial payment of $143 million for interest accrued on the final arbitration award amount in the Company’s case against Western Digital in the December 2014 quarter compared to $33 million in the March 2016 quarter, and a $35 million change in foreign currency remeasurement related to net gains and losses from changes in foreign exchange rates, which were more pronounced in the prior year, partially offset by a $52 million increase in losses from the early redemption and repurchases of debt in the nine months ended March 2015.

[0001104659-16-116201:mdna:55]
[same as prior period, unchanged from 0001104659-16-092467:mdna:49]

[0001104659-16-116201:mdna:56]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |
| (Dollars in millions) |  | April 1, 2016 |  | January 1, 2016 |  | April 3, 2015 |  | April 1, 2016 |  | April 3, 2015 |  |
| Provision for income taxes |  | $ | 30 |  | $ | 15 |  | $ | 13 |  | $ | 43 |  | $ | 216 |  |

[0001104659-16-116201:mdna:57]
[same as prior period, unchanged from 0001104659-16-092467:mdna:22]

[0001104659-16-116201:mdna:58]
Our effective tax rate for the March 2016 quarter and for the first nine months of fiscal year 2016 is higher than normal due to a drop in earnings for the year. Our lower earnings resulted in greater tax expense related to the first nine months of fiscal year 2016 being recorded in the March 2016 quarter.  Our 2016 income tax provision included approximately $2 million of net discrete tax provision associated with prior year tax adjustments offset by the release of tax reserves due to the expiration of certain statutes of limitation.

[0001104659-16-116201:mdna:59]
Our income tax provision recorded for the March 2016 quarter and for the first nine months of fiscal year 2016 differed from the provision from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets. The acquisition of Dot Hill Systems Corporation is not expected to have a material impact on our effective tax rate in fiscal year 2016

[0001104659-16-116201:mdna:60]
Consistent with the intent of ASU 2015-17 to simplify the presentation of deferred income taxes, we elected to adopt ASU 2015-17 on a prospective basis as of the second quarter, fiscal year 2016. Prior periods were not retrospectively adjusted. As a result of this change in accounting principle, $120 million of our deferred tax assets were reclassified from current to non-current.

[0001104659-16-116201:mdna:61]
During the nine months ended April 1, 2016, our unrecognized tax benefits excluding interest and penalties decreased by approximately $4 million to $79 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate was $79 million at April 1, 2016, subject to certain future valuation allowance reversals. During the 12 months beginning January 2, 2016, we expect that our unrecognized tax benefits could be reduced by approximately $24 million primarily as a result of the expiration of certain statutes of limitation.

[0001104659-16-116201:mdna:62]
We are subject to taxation in many jurisdictions globally and we are required to file U.S. federal, U.S. state and non-U.S. income tax returns. On April 4, 2016, the IRS approved the audit settlement reached in December 2015 regarding all disputed issues associated with our U.S. federal income tax returns for fiscal years 2008, 2009 and 2010. This audit settlement did not have a material impact on our financial statements. As a result of this settlement and the expiration of certain statutes of limitation, we are no longer subject to tax examination of U.S. federal income tax returns for years prior to fiscal year 2012.

[0001104659-16-116201:mdna:63]
Our income tax provision recorded for the first nine months of fiscal year 2015 included approximately $181 million of net tax expense due to the final audit assessment received from the Jiangsu Province State Tax Bureau of the People’s Republic of China (China assessment) for calendar years 2007 through 2013.

[0001104659-16-116201:mdna:64]
Our income tax provision recorded for the March 2015 quarter and for the first nine months of fiscal year 2015 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) tax expense associated with the China assessment recorded during the December 2014 quarter, and (iii) a decrease in valuation allowance for certain U.S. deferred tax assets. The acquisition of LSI’s Flash Business did not have a material impact on our effective tax rate in fiscal year 2015.

[0001104659-16-116201:mdna:65]
[same as prior period, unchanged from 0001104659-16-092467:mdna:59]

[0001104659-16-116201:mdna:66]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist primarily of money market funds, certificates of deposits, and other interest-bearing bank deposits. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, these restrictions have not impeded our ability to conduct our business, nor do we expect them to in the next 12 months. We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term investments and we do not believe the fair value of our short-term investments has significantly changed from the values reported as of April 1, 2016.

[0001104659-16-116201:mdna:67]
[same as prior period, unchanged from 0001104659-16-092467:mdna:61]

[0001104659-16-116201:mdna:68]
| (Dollars in millions) |  | April 1, 2016 |  | July 3, 2015 |  | Change |  |
| Cash and cash equivalents |  | $ | 1,193 |  | $ | 2,479 |  | $ | (1,286 | ) |
| Short-term investments |  | 6 |  | 6 |  | — |  |
| Total |  | $ | 1,199 |  | $ | 2,485 |  | $ | (1,286 | ) |

[0001104659-16-116201:mdna:69]
[same as prior period, unchanged from 0001104659-16-092467:mdna:63]

[0001104659-16-116201:mdna:70]
[same as prior period, unchanged from 0001104659-16-092467:mdna:64]

[0001104659-16-116201:mdna:71]
Cash provided by operating activities for the nine months ended April 1, 2016 of $1,411 million includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, and:

[0001104659-16-116201:mdna:72]
·                  a decrease of $531 million in accounts receivable, primarily due to the decrease in revenue

[0001104659-16-116201:mdna:73]
[same as prior period, unchanged from 0001104659-16-092467:mdna:68]

[0001104659-16-116201:mdna:74]
Cash used for investing activities for the nine months ended April 1, 2016 was $1,065 million and primarily attributable to the following activities:

[0001104659-16-116201:mdna:75]
·      $634 million paid for the acquisition of Dot Hill, net of cash acquired; and

[0001104659-16-116201:mdna:76]
·      $441 million used to acquire property, equipment and leasehold improvements

[0001104659-16-116201:mdna:77]
[same as prior period, unchanged from 0001104659-16-092467:mdna:72]

[0001104659-16-116201:mdna:78]
Cash used in financing activities of $1,632 million for the nine months ended April 1, 2016 was primarily attributable to the following activities:

[0001104659-16-116201:mdna:79]
·                  $1,090 million paid to repurchase ordinary shares; and

[0001104659-16-116201:mdna:80]
·                  $539 million in dividend payments to shareholders.

[0001104659-16-116201:mdna:81]
[same as prior period, unchanged from 0001104659-16-092467:mdna:76]

[0001104659-16-116201:mdna:82]
Our primary sources of liquidity as of April 1, 2016 consisted of: (1) approximately $1.2 billion in cash, cash equivalents, and short-term investments, (2) cash we expect to generate from operations and (3) a $700 million senior revolving credit facility.

[0001104659-16-116201:mdna:83]
The line of credit is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.  As of April 1, 2016, no borrowings had been drawn under the revolving credit facility or had been utilized for letters of credit issued under this credit facility.

[0001104659-16-116201:mdna:84]
The credit agreement that governs our revolving credit facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio.  On April 28, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to adjust for our current financial liquidity position.  We were in compliance with the modified covenants as of April 1, 2016 and expect to be in compliance for the next 12 months.

[0001104659-16-116201:mdna:85]
[same as prior period, unchanged from 0001104659-16-092467:mdna:80]

[0001104659-16-116201:mdna:86]
[same as prior period, unchanged from 0001104659-16-092467:mdna:81]

[0001104659-16-116201:mdna:87]
From time to time we may repurchase any of our outstanding notes in open market or privately negotiated purchases or otherwise, or may repurchase outstanding notes pursuant to the terms of the applicable indenture.

[0001104659-16-116201:mdna:88]
The Company’s Board of Directors declared a quarterly cash dividend of $0.63 per share on April 29, 2016, which is payable on May 24, 2016 to shareholders of record at the close of business on May 10, 2016.

[0001104659-16-116201:mdna:89]
From time to time we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases. As of April 1, 2016, $1.8 billion remained available for repurchase under our existing repurchase authorization limit.  All repurchases are effected as redemptions in accordance with the Company’s Articles of Association.

[0001104659-16-116201:mdna:90]
[same as prior period, unchanged from 0001104659-16-092467:mdna:85]

[0001104659-16-116201:mdna:91]
[same as prior period, unchanged from 0001104659-16-092467:mdna:86]

[0001104659-16-116201:mdna:92]
[same as prior period, unchanged from 0001104659-16-092467:mdna:87]

[0001104659-16-116201:mdna:93]
[same as prior period, unchanged from 0001104659-16-092467:mdna:88]

[0001104659-16-116201:mdna:94]
[same as prior period, unchanged from 0001104659-16-092467:mdna:89]
