# STX notes — 0001104659-16-116201


## invest:InvestmentTableTextBlock

[0001104659-16-116201:notes:1]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of July 3, 2015:

[0001104659-16-116201:notes:2]
[same as prior period, unchanged from 0001104659-16-092467:notes:1]

[0001104659-16-116201:notes:3]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of April 1, 2016:

[0001104659-16-116201:notes:4]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 705 |  |  | $ | — |  |  | $ | 705 |  |
| Certificates of deposit |  | 5 |  |  | — |  |  | 5 |  |
| Corporate bonds |  | 6 |  |  | — |  |  | 6 |  |
|  |  | $ | 716 |  |  | $ | — |  |  | $ | 716 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 703 |  |
| Included in Short-term investments |  |  |  |  |  |  |  | 6 |  |
| Included in Other current assets |  |  |  |  |  |  |  | 7 |  |
| Total |  |  |  |  |  |  |  | $ | 716 |  |


## stx:ScheduleOfShareRepurchasesTableTextBlock

[0001104659-16-116201:notes:5]
The following table sets forth information with respect to repurchases of the Company’s shares during the nine months ended April 1, 2016:

[0001104659-16-116201:notes:6]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Repurchases of Ordinary Shares |  | 23 |  |  | $ | 1,090 |  |
| Tax Withholding Related to Vesting of Equity Awards |  | 1 |  |  | 55 |  |
| Total |  | 24 |  |  | $ | 1,145 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001104659-16-116201:notes:7]
[same as prior period, unchanged from 0001104659-16-092467:notes:4]

[0001104659-16-116201:notes:8]
[same as prior period, unchanged from 0001104659-16-092467:notes:5]

[0001104659-16-116201:notes:9]
[same as prior period, unchanged from 0001104659-16-092467:notes:6]

[0001104659-16-116201:notes:10]
[same as prior period, unchanged from 0001104659-16-092467:notes:7]

[0001104659-16-116201:notes:11]
[same as prior period, unchanged from 0001104659-16-092467:notes:8]

[0001104659-16-116201:notes:12]
[same as prior period, unchanged from 0001104659-16-092467:notes:9]

[0001104659-16-116201:notes:13]
[same as prior period, unchanged from 0001104659-16-092467:notes:10]

[0001104659-16-116201:notes:14]
[same as prior period, unchanged from 0001104659-16-092467:notes:11]

[0001104659-16-116201:notes:15]
The expenses related to the acquisition of Dot Hill in for the nine months ended April 1, 2016, which are included within Marketing and administrative expense on the Consolidated Statement of Operations, are not significant.

[0001104659-16-116201:notes:16]
The amounts of revenue and earnings of Dot Hill included in the Company's Consolidated Statement of Operations from the acquisition date were not significant.

[0001104659-16-116201:notes:17]
[same as prior period, unchanged from 0001104659-16-092467:notes:14]

[0001104659-16-116201:notes:18]
[same as prior period, unchanged from 0001104659-16-092467:notes:15]

[0001104659-16-116201:notes:19]
[same as prior period, unchanged from 0001104659-16-092467:notes:16]

[0001104659-16-116201:notes:20]
[same as prior period, unchanged from 0001104659-16-092467:notes:17]

[0001104659-16-116201:notes:21]
| (Dollars in millions) |  | Fair Value |  | Weighted-AverageAmortizationPeriod |
| Existing technology |  | $ | 84 |  |  | 3.5 years |
| Customer relationships |  | 40 |  |  | 3.8 years |
| Trade names |  | 17 |  |  | 4.5 years |
| Total acquired identifiable intangible assets |  | $ | 141 |  |  | 3.7 years |

[0001104659-16-116201:notes:22]
[same as prior period, unchanged from 0001104659-16-092467:notes:19]

[0001104659-16-116201:notes:23]
The Company incurred approximately $1 million of expenses related to the acquisition of LSI's Flash Business during the nine months ended April 3, 2015, which were included within Marketing and administrative expense on the Company's Condensed Consolidated Statement of Operations.

[0001104659-16-116201:notes:24]
The amounts of revenue and earnings of LSI's Flash Business included in the Company's Consolidated Statement of Operations from the acquisition date through April 3, 2015 were not significant.

[0001104659-16-116201:notes:25]
[same as prior period, unchanged from 0001104659-16-092467:notes:22]

[0001104659-16-116201:notes:26]
[same as prior period, unchanged from 0001104659-16-092467:notes:23]

[0001104659-16-116201:notes:27]
[same as prior period, unchanged from 0001104659-16-092467:notes:24]

[0001104659-16-116201:notes:28]
[same as prior period, unchanged from 0001104659-16-092467:notes:25]

[0001104659-16-116201:notes:29]
[same as prior period, unchanged from 0001104659-16-092467:notes:26]


## us-gaap:ConsolidationPolicyTextBlock

[0001104659-16-116201:notes:30]
[same as prior period, unchanged from 0001104659-16-092467:notes:28]

[0001104659-16-116201:notes:31]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income (loss), cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature. Certain prior period amounts in the condensed consolidated financial statements and notes to the condensed consolidated financial statements have been reclassified to conform to the current period’s presentation.

[0001104659-16-116201:notes:32]
[same as prior period, unchanged from 0001104659-16-092467:notes:30]


## us-gaap:DebtDisclosureTextBlock

[0001104659-16-116201:notes:33]
Debt

[0001104659-16-116201:notes:34]
Short-Term Borrowings

[0001104659-16-116201:notes:35]
The credit agreement entered into by the Company and its subsidiary Seagate HDD Cayman on January 18, 2011 and subsequently amended (the "Revolving Credit Facility") provides the Company with a $700 million senior secured revolving credit facility. The term of the Revolving Credit Facility is through January 15, 2020, provided that if the Company does not have Investment Grade Ratings (as defined in the Revolving Credit Facility) on August 15, 2018, then the maturity date will be August 16, 2018 unless certain extension conditions have been satisfied. The loans made under the Revolving Credit Facility will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing, and for the issuance of letters of credit up to a sub-limit of $75 million.

[0001104659-16-116201:notes:36]
The Revolving Credit Facility, as amended, includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio.  On April 27, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to adjust for our current financial liquidity position.  We were in compliance with the modified covenants as of April 1, 2016 and expect to be in compliance for the next 12 months.

[0001104659-16-116201:notes:37]
As of April 1, 2016, no borrowings had been drawn or letters of credit utilized under the Revolving Credit Facility.

[0001104659-16-116201:notes:38]
Long-Term Debt

[0001104659-16-116201:notes:39]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman, and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-16-116201:notes:40]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman, and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-16-116201:notes:41]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman, and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-16-116201:notes:42]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”). The interest on the 2025 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2025 Notes is Seagate HDD Cayman, and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-16-116201:notes:43]
$700 million Aggregate Principal Amount of 4.875% Senior Notes due June 2027 (the “2027 Notes”). The interest on the Notes is payable semi-annually on June 1 and December 1 of each year, which commenced on December 1, 2015. The issuer under the 2027 Notes is Seagate HDD Cayman, and the obligations under the 2027 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-16-116201:notes:44]
$500 million Aggregate Principal Amount of 5.75% Senior Notes due December 2034 (the “2034 Notes”). The interest on the 2034 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2034 Notes is Seagate HDD Cayman, and the obligations under the 2034 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2016 quarter, the Company repurchased $10 million aggregate principal amount of its 2034 Notes for cash at a discount to their principal amount, plus accrued and unpaid interest. The Company recorded a gain on the repurchase of approximately $3 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

[0001104659-16-116201:notes:45]
At April 1, 2016, future principal payments on long-term debt were as follows (in millions):

[0001104659-16-116201:notes:46]
| Fiscal Year | Amount |
| Remainder of 2016 | $ | — |  |
| 2017 | — |  |
| 2018 | — |  |
| 2019 | 800 |  |
| 2020 | — |  |
| Thereafter | 3,333 |  |
|  | $ | 4,133 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001104659-16-116201:notes:47]
The Company is exposed to foreign currency exchange rate, interest rate, and to a lesser extent, equity price risks relating to its ongoing business operations.  The Company enters into foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses denominated in foreign currencies and to mitigate the remeasurement risk of certain foreign currency denominated liabilities. The Company's accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments.  The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value.  The changes in the fair value of the effective portions of designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings.  Derivatives that are not designated as hedging instruments and the ineffective portions of cash flow hedges are adjusted to fair value through earnings. The amounts of net unrealized gain or loss on cash flow hedges were immaterial as of April 1, 2016 and July 3, 2015.

[0001104659-16-116201:notes:48]
The Company de-designates its cash flow hedges when the forecasted hedged transactions are realized or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive income (loss) are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company did not recognize any net gains or losses related to the loss of hedge designation on discontinued cash flow hedges during the three and nine months ended April 1, 2016. As of April 1, 2016, the Company’s existing foreign currency forward exchange contracts mature within 12 months. The deferred amount currently recorded in Accumulated other comprehensive loss expected to be recognized into earnings over the next 12 months is immaterial.

[0001104659-16-116201:notes:49]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of April 1, 2016 and July 3, 2015:

[0001104659-16-116201:notes:50]
|  |  | As of April 1, 2016 |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| British Pound Sterling |  | $ | 20 |  |  | $ | 7 |  |
|  |  | $ | 20 |  |  | $ | 7 |  |

[0001104659-16-116201:notes:51]
[same as prior period, unchanged from 0001104659-16-092467:notes:48]

[0001104659-16-116201:notes:52]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plan—the Seagate Deferred Compensation Plan (the “SDCP”). In fiscal year 2014, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees. As of April 1, 2016, the notional investments underlying the TRS amounted to $94 million. The contract term of the TRS was through January 2016, and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company renewed the contract term through January 2017 under materially the same terms. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001104659-16-116201:notes:53]
The following tables show the Company’s derivative instruments measured at fair value as reflected in the Condensed Consolidated Balance Sheet as of April 1, 2016 and July 3, 2015:

[0001104659-16-116201:notes:54]
|  |  | As of April 1, 2016 |
|  |  | Asset Derivatives |  | Liability Derivatives |
| (Dollars in millions) |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (1 | ) |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | — |  |  |  |  | $ | (1 | ) |

[0001104659-16-116201:notes:55]
[same as prior period, unchanged from 0001104659-16-092467:notes:52]

[0001104659-16-116201:notes:56]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statement of Comprehensive Income (Loss) and the Condensed Consolidated Statement of Operations for the three and nine months ended April 1, 2016:

[0001104659-16-116201:notes:57]
[same as prior period, unchanged from 0001104659-16-092467:notes:54]

[0001104659-16-116201:notes:58]
| Derivatives Designated as Hedging Instruments |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  |  |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
|  |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | $ | (1 | ) |  | $ | (3 | ) |  | Cost of revenue |  | $ | — |  |  | $ | (2 | ) |  | Cost of revenue |  | $ | — |  |  | $ | — |  |

[0001104659-16-116201:notes:59]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivative |  | Amount of Gain or(Loss) Recognized inIncome on Derivative |
|  |  |  |  | For the Three Months | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | — |  | $ | (4 | ) |
| Total return swap |  | Operating expenses |  | 1 |  | (3 | ) |

[0001104659-16-116201:notes:60]
[same as prior period, unchanged from 0001104659-16-092467:notes:57]

[0001104659-16-116201:notes:61]
| (a) | The amount of gain or (loss) recognized in income represents $0 related to the ineffective portion of the hedging relationships and $0 related to the amount excluded from the assessment of hedge effectiveness for the three and nine months ended April 1, 2016, respectively. |

[0001104659-16-116201:notes:62]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statement of Comprehensive Income (Loss) and the Condensed Consolidated Statement of Operations for the three and nine months April 3, 2015:

[0001104659-16-116201:notes:63]
[same as prior period, unchanged from 0001104659-16-092467:notes:60]

[0001104659-16-116201:notes:64]
| Derivatives Designated as Hedging Instruments |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
|  |  | For the Three Months |  | For the Nine Months |  |  |  | For the Three Months |  | For the Nine Months |  |  |  | For the Three Months |  | For the Nine Months |
| Foreign currency forward exchange contracts |  | $ | (3 | ) |  | $ | (13 | ) |  | Cost of revenue |  | $ | (7 | ) |  | $ | (9 | ) |  | Cost of revenue |  | $ | 1 |  |  | $ | 1 |  |

[0001104659-16-116201:notes:65]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
|  |  |  |  | For the Three Months | For the Nine Months |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 1 |  | $ | (4 | ) |
| Total return swap |  | Operating expenses |  | 2 |  | 2 |  |

[0001104659-16-116201:notes:66]
| (a) | The amount of gain or (loss) recognized in income represents $0 related to the ineffective portion of the hedging relationships and $1 million related to the amount excluded from the assessment of hedge effectiveness for the three and nine months April 3, 2015, respectively. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-16-116201:notes:67]
[same as prior period, unchanged from 0001104659-16-092467:notes:64]

[0001104659-16-116201:notes:68]
The Company recorded approximately $30 million and $95 million of stock-based compensation expense during the three and nine months ended April 1, 2016, respectively. The Company recorded approximately $33 million and $106 million of stock-based compensation expense during the three and nine months ended April 3, 2015, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001104659-16-116201:notes:69]
[same as prior period, unchanged from 0001104659-16-092467:notes:66]

[0001104659-16-116201:notes:70]
[same as prior period, unchanged from 0001104659-16-092467:notes:67]

[0001104659-16-116201:notes:71]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (In millions, except per share data) |  | April 1, 2016 |  | April 3, 2015 |  | April 1, 2016 |  | April 3, 2015 |
| Numerator: |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (21 | ) |  | $ | 291 |  |  | $ | 178 |  |  | $ | 1,605 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income (loss) per share |  | 298 |  |  | 323 |  |  | 300 |  |  | 326 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Employee equity award plans |  | — |  |  | 7 |  |  | 3 |  |  | 8 |  |
| Total shares for purpose of calculating diluted net income (loss) per share |  | 298 |  |  | 330 |  |  | 303 |  |  | 334 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.07 | ) |  | $ | 0.90 |  |  | $ | 0.59 |  |  | $ | 4.92 |  |
| Diluted |  | (0.07 | ) |  | 0.88 |  |  | 0.59 |  |  | 4.81 |  |

[0001104659-16-116201:notes:72]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income (loss) were 4 million and 2 million for the three and nine months ended April 1, 2016, respectively, and immaterial for the three and nine months ended April 3, 2015.


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001104659-16-116201:notes:73]
[same as prior period, unchanged from 0001104659-16-092467:notes:70]

[0001104659-16-116201:notes:74]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 703 |  |  | $ | — |  |  | $ | — |  |  | $ | 703 |  |
| Short-term investments | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Other current assets | 2 |  |  | 5 |  |  | — |  |  | 7 |  |
| Total assets | $ | 705 |  |  | $ | 11 |  |  | $ | — |  |  | $ | 716 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued expenses | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |
| Total liabilities | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-16-116201:notes:75]
[same as prior period, unchanged from 0001104659-16-092467:notes:72]

[0001104659-16-116201:notes:76]
[same as prior period, unchanged from 0001104659-16-092467:notes:73]

[0001104659-16-116201:notes:77]
[same as prior period, unchanged from 0001104659-16-092467:notes:74]

[0001104659-16-116201:notes:78]
[same as prior period, unchanged from 0001104659-16-092467:notes:75]

[0001104659-16-116201:notes:79]
[same as prior period, unchanged from 0001104659-16-092467:notes:76]

[0001104659-16-116201:notes:80]
[same as prior period, unchanged from 0001104659-16-092467:notes:77]

[0001104659-16-116201:notes:81]
[same as prior period, unchanged from 0001104659-16-092467:notes:78]

[0001104659-16-116201:notes:82]
[same as prior period, unchanged from 0001104659-16-092467:notes:79]

[0001104659-16-116201:notes:83]
[same as prior period, unchanged from 0001104659-16-092467:notes:80]

[0001104659-16-116201:notes:84]
[same as prior period, unchanged from 0001104659-16-092467:notes:81]

[0001104659-16-116201:notes:85]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of April 1, 2016:

[0001104659-16-116201:notes:86]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 703 |  |  | $ | — |  |  | $ | — |  |  | $ | 703 |  |
| Certificates of deposit | — |  |  | — |  |  | — |  |  | — |  |
| Corporate bonds | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total cash equivalents and short-term investments | 703 |  |  | 6 |  |  | — |  |  | 709 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |
| Money market funds | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Certificates of deposit | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Total assets | $ | 705 |  |  | $ | 11 |  |  | $ | — |  |  | $ | 716 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |
| Total liabilities | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |

[0001104659-16-116201:notes:87]
[same as prior period, unchanged from 0001104659-16-092467:notes:84]

[0001104659-16-116201:notes:88]
[same as prior period, unchanged from 0001104659-16-092467:notes:85]

[0001104659-16-116201:notes:89]
[same as prior period, unchanged from 0001104659-16-092467:notes:86]

[0001104659-16-116201:notes:90]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs.  The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities.  Level 2 assets include:  agency bonds, corporate bonds, commercial paper, municipal bonds, U.S. Treasuries and certificates of deposits. These debt investments are priced using observable inputs and valuation models which vary by asset class.  The Company uses a pricing service to assist in determining the fair values of all of its cash equivalents and short-term investments.  For the cash equivalents and short-term investments in the Company's portfolio, multiple pricing sources are generally available.  The pricing service uses inputs from multiple industry standard data providers or other third party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date.  The Company corroborates the prices obtained from the pricing service against other independent sources and, as of April 1, 2016, has not found it necessary to make any adjustments to the prices obtained.  The Company's derivative financial instruments are also classified within Level 2.  The Company's derivative financial instruments consist of foreign currency forward exchange contracts and the TRS.  The Company recognizes derivative financial instruments in its consolidated financial statements at fair value.  The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001104659-16-116201:notes:91]
As of April 1, 2016 and July 3, 2015, the Company had no Level 3 assets or liabilities measured at fair value on a recurring basis.

[0001104659-16-116201:notes:92]
[same as prior period, unchanged from 0001104659-16-092467:notes:89]

[0001104659-16-116201:notes:93]
The Company enters into certain strategic investments for the achievement of business and strategic objectives. Strategic investments in equity securities where the Company does not have the ability to exercise significant influence over the investees are recorded at cost and are included in Other assets, net in the Condensed Consolidated Balance Sheets, and are periodically analyzed to determine whether or not there are indicators of impairment. The carrying value of the Company’s strategic investments at April 1, 2016 and July 3, 2015 totaled $112 million and $120 million, respectively, and consisted primarily of privately held equity securities without a readily determinable fair value.

[0001104659-16-116201:notes:94]
In the three and nine months ended April 1, 2016, the Company determined that certain equity investments accounted for under the cost method were other-than-temporarily impaired, and recognized a charge of $2 million and $12 million, respectively, in order to write down the carrying amount of the investments to zero.  Since there was no active market for the equity securities of the investee, the Company estimated fair value of the investee by analyzing the underlying cash flows and future prospects of the investee. These amounts were recorded in Other, net in the Condensed Consolidated Statement of Operations for the three and nine months ended April 1, 2016. The Company did not record any material impairment charges in the three and nine months ended April 3, 2015.

[0001104659-16-116201:notes:95]
[same as prior period, unchanged from 0001104659-16-092467:notes:92]

[0001104659-16-116201:notes:96]
[same as prior period, unchanged from 0001104659-16-092467:notes:93]

[0001104659-16-116201:notes:97]
|  |  | April 1, 2016 |  | July 3, 2015 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 3.75% Senior Notes due November 2018 |  | $ | 800 |  |  | $ | 804 |  |  | $ | 800 |  |  | $ | 828 |  |
| 7.00% Senior Notes due November 2021 |  | 158 |  |  | 164 |  |  | 158 |  |  | 170 |  |
| 4.75% Senior Notes due June 2023 |  | 990 |  |  | 826 |  |  | 1,000 |  |  | 1,016 |  |
| 4.75% Senior Notes due January 2025 |  | 995 |  |  | 787 |  |  | 1,000 |  |  | 995 |  |
| 4.875% Senior Notes due June 2027 |  | 698 |  |  | 518 |  |  | 698 |  |  | 675 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 356 |  |  | 499 |  |  | 491 |  |
| Long-term debt |  | $ | 4,130 |  |  | $ | 3,455 |  |  | $ | 4,155 |  |  | $ | 4,175 |  |
| Less short-term borrowings and current portion of long-term debt |  | — |  |  | — |  |  | — |  |  | — |  |
| Long-term debt, less current portion |  | $ | 4,130 |  |  | $ | 3,455 |  |  | $ | 4,155 |  |  | $ | 4,175 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-16-116201:notes:98]
Goodwill and Other Intangible Assets

[0001104659-16-116201:notes:99]
[same as prior period, unchanged from 0001104659-16-092467:notes:96]

[0001104659-16-116201:notes:100]
The changes in the carrying amount of goodwill for the nine months ended April 1, 2016, are as follows:

[0001104659-16-116201:notes:101]
| (Dollars in millions) | Amount |
| Balance at July 3, 2015 | $ | 874 |  |
| Goodwill acquired (a) | 364 |  |
| Foreign currency translation effect | — |  |
| Balance at April 1, 2016 | $ | 1,238 |  |

[0001104659-16-116201:notes:102]
(a) Amount represents goodwill recognized from the Dot Hill acquisition.

[0001104659-16-116201:notes:103]
[same as prior period, unchanged from 0001104659-16-092467:notes:99]

[0001104659-16-116201:notes:104]
[same as prior period, unchanged from 0001104659-16-092467:notes:100]

[0001104659-16-116201:notes:105]
The carrying value of other intangible assets subject to amortization as of April 1, 2016, is set forth in the following table:

[0001104659-16-116201:notes:106]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 311 |  |  | $ | (75 | ) |  | $ | 236 |  |  | 4.3 years |
| Customer relationships |  | 511 |  |  | (306 | ) |  | 205 |  |  | 3.3 years |
| Trade names |  | 29 |  |  | (12 | ) |  | 17 |  |  | 2.8 years |
| Other intangible assets |  | 28 |  |  | (8 | ) |  | 20 |  |  | 3.4 years |
| Total amortizable other intangible assets |  | $ | 879 |  |  | $ | (401 | ) |  | $ | 478 |  |  | 3.8 years |

[0001104659-16-116201:notes:107]
The carrying value of in-process research and development not subject to amortization was $14 million as of April 1, 2016.

[0001104659-16-116201:notes:108]
[same as prior period, unchanged from 0001104659-16-092467:notes:104]

[0001104659-16-116201:notes:109]
[same as prior period, unchanged from 0001104659-16-092467:notes:105]

[0001104659-16-116201:notes:110]
For the three and nine months ended April 1, 2016, amortization expense of other intangible assets was $44 million and $131 million, respectively. For the three and nine months ended April 3, 2015, amortization expense of other intangible assets was $40 million and $112 million.  As of April 1, 2016, expected amortization expense for other intangible assets for each of the next five fiscal years and thereafter is as follows:

[0001104659-16-116201:notes:111]
| (Dollars in millions) | Amount |
| Remainder of 2016 | $ | 43 |  |
| 2017 | 166 |  |
| 2018 | 108 |  |
| 2019 | 68 |  |
| 2020 | 50 |  |
| Thereafter | 43 |  |
|  | $ | 478 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-16-116201:notes:112]
[same as prior period, unchanged from 0001104659-16-092467:notes:108]

[0001104659-16-116201:notes:113]
The Company recorded an income tax provision of $30 million and $43 million in the three and nine months ended April 1, 2016, respectively. The income tax provision for the nine months ended April 1, 2016 included approximately $2 million of net discrete tax provision associated with prior year tax adjustments offset by the release of tax reserves due to the expiration of certain statutes of limitation.

[0001104659-16-116201:notes:114]
The Company's income tax provision recorded for the three and nine months ended April 1, 2016 differed from the provision from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets.

[0001104659-16-116201:notes:115]
Consistent with the intent of ASU 2015-17 to simplify the presentation of deferred income taxes, the Company elected to adopt ASU 2015-17 on a prospective basis as of the second quarter, fiscal year 2016.  Prior periods were not retrospectively adjusted. As a result of this change in accounting principle, $120 million of the Company’s deferred tax assets were reclassified from current to non-current.

[0001104659-16-116201:notes:116]
During the nine months ended April 1, 2016, the Company’s unrecognized tax benefits excluding interest and penalties decreased by approximately $4 million to $79 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate was $79 million at April 1, 2016, subject to certain future valuation allowance reversals. During the 12 months beginning April 2, 2016, the Company expects that its unrecognized tax benefits could be reduced by approximately $24 million primarily as a result of the expiration of certain statutes of limitation.

[0001104659-16-116201:notes:117]
The Company is subject to taxation in many jurisdictions globally and is required to file U.S. federal, U.S. state and non-U.S. income tax returns. On April 4, 2016, the IRS approved the audit settlement reached in December 2015 regarding all disputed issues associated with the Company’s U.S. federal income tax returns for fiscal years 2008, 2009 and 2010. This audit settlement did not have a material impact on the Company’s financial statements.  As a result of this settlement and the expiration of certain statutes of limitation, the Company is no longer subject to tax examination of U.S. federal income tax returns for years prior to fiscal year 2012.

[0001104659-16-116201:notes:118]
The Company recorded an income tax provision of $13 million and $216 million in the three and nine months ended April 3, 2015, respectively. The income tax provision for the nine months ended April 3, 2015 included approximately $181 million of net tax expense due to the final audit assessment received from the Jiangsu Province State Tax Bureau of the People's Republic of China (China assessment) for calendar years 2007 through 2013.

[0001104659-16-116201:notes:119]
The Company’s income tax provision recorded for the three and nine months ended April 3, 2015 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland, (ii) tax expense associated with the China assessment recorded in the three months ended January 2, 2015, and (iii) a decrease in valuation allowance for certain U.S. deferred tax assets.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001104659-16-116201:notes:120]
The fair value and amortized cost of the Company’s investments classified as available-for-sale at April 1, 2016, by remaining contractual maturity were as follows:

[0001104659-16-116201:notes:121]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 710 |  |  | $ | 710 |  |
| Due in 1 to 5 years |  | 6 |  |  | 6 |  |
| Thereafter |  | — |  |  | — |  |
| Total |  | $ | 716 |  |  | $ | 716 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001104659-16-116201:notes:122]
Legal, Environmental and Other Contingencies

[0001104659-16-116201:notes:123]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001104659-16-116201:notes:124]
Intellectual Property Litigation

[0001104659-16-116201:notes:125]
Convolve, Inc. ("Convolve") and Massachusetts Institute of Technology ("MIT") v. Seagate Technology LLC, et al. - On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent Nos. 4,916,635 (the "'635 patent") and U.S. Patent No. 5,638,267 (the "'267 patent"), misappropriation of trade secrets, breach of contract, and other claims. In the complaint, the plaintiffs requested injunctive relief, $800 million in compensatory damages and unspecified punitive damages, including for willful infringement. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe US Patent No. 6,314,473 (the "'473 patent"). The district court ruled in 2010 that the '267 patent was out of the case.

[0001104659-16-116201:notes:126]
On August 16, 2011, the district court granted in part and denied in part the Company's motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court's summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court's summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent. On July 11, 2014, the district court granted the Company's summary judgment motion regarding Convolve's only remaining cause of action, which alleged infringement of the '473 patent. The district court entered judgment in favor of the Company on July 14, 2014. Convolve filed a notice of appeal on August 13, 2014. On February 10, 2016, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court’s summary judgment of no direct infringement by Seagate because Seagate’s ATA/SCSI disk drives do not meet the “user interface” limitation of the asserted claims of the ‘473 patent; 2) affirmed the district court’s summary judgment of non-infringement by Compaq’s products as to claims 1, 3, and 5 of the ‘473 patent because Compaq’s F10 BIOS interface does not meet the “commands” limitation of those claims; 3) vacated the district court’s summary judgment of non-infringement by Compaq’s accused products as to claims 7-15 of the ‘473 patent; 4) reversed the district court’s summary judgment of non-infringement based on intervening rights; and 5) remanded the case to the district court for further proceedings on the ‘473 patent. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-16-116201:notes:127]
Alexander Shukh v. Seagate Technology - On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. On March 31, 2014, the district court granted Seagate's summary judgment motion and entered judgment in favor of Seagate. Mr. Shukh filed a notice of appeal on April 7, 2014. On October 2, 2015, the court of appeals vacated and remanded the district court’s grant of summary judgment on Mr. Shukh’s claim for correction of inventorship and affirmed the district court’s grant of summary judgment as to all other claims. On October 29, 2015, Mr. Shukh filed a petition for rehearing en banc with the court of appeals; the petition was denied on December 17, 2015. On March 16, 2016, Shukh filed a petition for writ of certiorari to the U.S. Supreme Court. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-16-116201:notes:128]
LEAP Co., Ltd. v. Seagate Singapore International Headquarters Pte. Ltd. and Nippon Seagate Inc. - On July 4, 2012, LEAP Co., Ltd. filed a lawsuit in the Tokyo District Court of Japan against Seagate Singapore International Headquarters Pte. Ltd., Nippon Seagate Inc. and Buffalo Inc. alleging wrongful termination of purchase agreements and other claims, and seeking approximately $38 million in damages. On March 16, 2016, the Company and LEAP reached a settlement.  As a result of the settlement, this litigation between the Company and LEAP has ended.  There is no damage or loss to the Company related to this matter.

[0001104659-16-116201:notes:129]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation ("Enova") filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995, "Cryptographic Device," and U.S. Patent No. 7,900,057, "Cryptographic Serial ATA Apparatus and Method." The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys' fees, and other relief. On April 27, 2015, the district court ordered a stay of the case, in view of proceedings regarding the '995 and '057 Patents before the Patent Trial and Appeal Board (“PTAB”) of the U.S. Patent and Trademark Office. The Company believes the claims are without merit and intends to vigorously defend this case. On September 2, 2015, PTAB issued its final written decision that claims 1-15 of the ‘995 Patent are held unpatentable. On December 18, 2015, PTAB issued its final written decisions that claims 1-32 and 40-53 of the ’057 Patent are held unpatentable. On February 4, 2016, PTAB issued its final written decision that claims 33-39 of the ‘057 Patent are held unpatentable. Enova has appealed PTAB’s decisions on the ‘995 Patent and the 057 Patent to the U.S. Court of Appeals for the Federal Circuit. A hearing before the court of appeals has not yet been scheduled. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-16-116201:notes:130]
Seagate Technology LLC v. Western Digital Corp.  On October 8, 2014, the Minnesota Supreme Court ruled that the arbitration award in favor of the Company in its case against Western Digital for the misappropriation of the Company’s trade secrets should be confirmed. In the arbitration award, issued on January 23, 2012, the arbitrator determined that Western Digital and its former employee had misappropriated the Company’s trade secrets. The arbitrator awarded the Company $525 million in compensatory damages and, after adding interest, issued a final award of $630 million. Interest on the final award has been accruing at 10%. On October 14, 2014, the Company received a partial payment from Western Digital in the amount of $773 million. During the quarter ended January 2, 2015, the amount of the final award, less litigation and other related costs, was recorded by the Company in Gain on arbitration award, net, and the remaining amount received was recorded in Other, net. On April 7, 2015, the Hennepin County District Court of Minnesota (“district court”) denied Seagate’s motion for entry of judgment for an amount of additional interest owing on the arbitration award.  On January 25, 2016, the Minnesota Court of Appeals reversed and remanded the district court’s order regarding the unpaid interest. On January 27, 2016, the Company received a further payment from Western Digital in the amount of $33 million, which was the remaining balance of interest owed on the final award. This amount was recorded in Other, net in the Condensed Consolidated Statement of Operations for the three and nine months ended April 1, 2016. On January 29, 2016, the parties filed a stipulation of dismissal with the district court, ending the litigation.

[0001104659-16-116201:notes:131]
Environmental Matters

[0001104659-16-116201:notes:132]
The Company's operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company's operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001104659-16-116201:notes:133]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001104659-16-116201:notes:134]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the "Superfund" law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001104659-16-116201:notes:135]
While the Company's ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001104659-16-116201:notes:136]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union ("EU") enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern ("SVHCs") in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.

[0001104659-16-116201:notes:137]
Other Matters

[0001104659-16-116201:notes:138]
The Company is involved in a number of other judicial and administrative proceedings incidental to its business, and the Company may be involved in various legal proceedings arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001104659-16-116201:notes:139]
In May 2014, August 2015, and April 2016, the FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers, ASU 2015-14 (ASC Topic 606) Revenue from Contracts with Customers, Deferral of the Effective Date, and ASU 2016-10 (ASC Topic 606) Revenue from Contracts with Customers, Identifying Performance Obligations and Licensing, respectively. ASC Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The amendments in these ASUs are effective for fiscal years, and interim periods within those years, beginning after December 15, 2017. Early adoption is permitted for annual periods beginning after December 15, 2016. The Company is in the process of assessing the impact, if any, on its consolidated financial statements.

[0001104659-16-116201:notes:140]
In April 2015 and August 2015, the FASB issued ASU 2015-03 (ASC Subtopic 835-30), Interest-Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs and ASU 2015-15 (ASC Subtopic 835-30), Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements- Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting, respectively. The ASUs require that debt issuance costs related to a recognized debt liability, with the exception of those related to line-of-credit arrangements, be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability. The amendments in these ASUs are effective for fiscal years, and interim periods within those years, beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued. The adoption of this new guidance is not expected to have a material impact on the Company’s consolidated financial statements and disclosures.

[0001104659-16-116201:notes:141]
In July 2015, the FASB issued ASU 2015-11 (ASC Topic 330), Inventory: Simplifying the Measurement of Inventory. The amendments in this ASU require inventory measurement at the lower of cost and net realizable value. The amendments in this ASU are effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company is in the process of assessing the impact, if any, of this ASU on its consolidated financial statements.

[0001104659-16-116201:notes:142]
In September 2015, the FASB issued ASU 2015-16 (ASC Topic 805), Business Combinations Simplifying the Accounting for Measurement-Period Adjustments. The amendments in this update require that an acquirer recognize measurement period adjustments in the period in which the adjustments are determined. The income effects of such measurement period adjustments are to be recorded in the same period’s financial statements but calculated as if the accounting had been completed as of the acquisition date. The impact of measurement period adjustments to earnings that relate to prior period financial statements are to be presented separately on the income statement or disclosed by line item. The amendments in this update are for fiscal years, including interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted for public business entities for reporting periods for which financial statements have not yet been issued. The adoption of this new guidance is not expected to have a material impact on the Company’s consolidated financial statements and disclosures.

[0001104659-16-116201:notes:143]
In November 2015, the FASB issued ASU 2015-17 (ASC Topic 740), Income Taxes Balance Sheet Classification of Deferred Taxes. The amendments in this Update are effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. Early adoption is permitted by all entities as of the beginning of an interim or annual reporting period. The Company early adopted this ASU for the December 2015 quarter on a prospective basis. See footnote 4 for disclosure of the financial statement impact of this adoption.

[0001104659-16-116201:notes:144]
In January 2016, the FASB issued ASU 2016-01 (ASC Subtopic 825-10), Financial Instruments- Overall Recognition and Measurement of Financial Assets and Financial Liabilities. The amendments in this ASU require entities to measure all investments in equity securities at fair value with changes recognized through net income. This requirement does not apply to investments that qualify for the equity method of accounting, to those that result in consolidation of the investee, or for which the entity meets a practicability exception to fair value measurement. Additionally, the amendments eliminate certain disclosure requirements related to financial instruments measured at amortized cost and add disclosures related to the measurement categories of financial assets and financial liabilities. The amendments in this ASU are effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. Early adoption is permitted for only certain portions of the ASU. The Company is in the process of assessing the impact, if any, on its consolidated financial statements.

[0001104659-16-116201:notes:145]
In February 2016, the FASB issued ASU 2016-02 (ASC Topic 842), Leases.  The ASU amends a number of aspects of lease accounting, including requiring lessees to recognize operating leases with a term greater than one year on their balance sheet as a right-of-use asset and corresponding lease liability, measured at the present value of the lease payments. The amendments in this ASU are effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted.  The Company is in the process of assessing the impact on its consolidated financial statements.

[0001104659-16-116201:notes:146]
In March 2016, the FASB issued ASU 2016-09 (ASC Topic 718), Stock Compensation  - Improvements to Employee Share-Based Payment Accounting. The amendments in this ASU are intended to simplify several areas of accounting for share based compensation arrangements, including the income tax consequences, classification on the consolidated statement of cash flows and treatment of forfeitures.  The amendments in this ASU are effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted.  The Company is in the process of assessing the impact, if any, of this ASU on its consolidated financial statements.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001104659-16-116201:notes:147]
[same as prior period, unchanged from 0001104659-16-092467:notes:141]

[0001104659-16-116201:notes:148]
[same as prior period, unchanged from 0001104659-16-092467:notes:142]

[0001104659-16-116201:notes:149]
[same as prior period, unchanged from 0001104659-16-092467:notes:143]

[0001104659-16-116201:notes:150]
[same as prior period, unchanged from 0001104659-16-092467:notes:144]

[0001104659-16-116201:notes:151]
[same as prior period, unchanged from 0001104659-16-092467:notes:145]

[0001104659-16-116201:notes:152]
[same as prior period, unchanged from 0001104659-16-092467:notes:146]

[0001104659-16-116201:notes:153]
Basis of Presentation and Consolidation

[0001104659-16-116201:notes:154]
The results of operations for the three and nine months ended April 1, 2016, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending July 1, 2016. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three and nine months ended April 1, 2016 consisted of 13 weeks and 39 weeks, respectively. The three and nine months ended April 3, 2015 consisted of 13 weeks and 40 weeks, respectively.  Fiscal year 2016 will be comprised of 52 weeks and will end on July 1, 2016. The fiscal quarters ended April 1, 2016, January 1, 2016, and April 3, 2015, are also referred to herein as the “March 2016 quarter”, the “December 2015 quarter”, and the “March 2015 quarter”, respectively.

[0001104659-16-116201:notes:155]
[same as prior period, unchanged from 0001104659-16-092467:notes:148]

[0001104659-16-116201:notes:156]
[same as prior period, unchanged from 0001104659-16-092467:notes:149]

[0001104659-16-116201:notes:157]
Recently Issued Accounting Pronouncements


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001104659-16-116201:notes:158]
Guarantees

[0001104659-16-116201:notes:159]
[same as prior period, unchanged from 0001104659-16-092467:notes:153]

[0001104659-16-116201:notes:160]
[same as prior period, unchanged from 0001104659-16-092467:notes:154]

[0001104659-16-116201:notes:161]
[same as prior period, unchanged from 0001104659-16-092467:notes:155]

[0001104659-16-116201:notes:162]
[same as prior period, unchanged from 0001104659-16-092467:notes:156]

[0001104659-16-116201:notes:163]
[same as prior period, unchanged from 0001104659-16-092467:notes:157]

[0001104659-16-116201:notes:164]
[same as prior period, unchanged from 0001104659-16-092467:notes:158]

[0001104659-16-116201:notes:165]
[same as prior period, unchanged from 0001104659-16-092467:notes:159]

[0001104659-16-116201:notes:166]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5  years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the three and nine months ended April 1, 2016 and April 3, 2015 were as follows:

[0001104659-16-116201:notes:167]
|  |  | For the Three Months Ended |  | For the Nine Months Ended |
| (Dollars in millions) |  | April 1, 2016 |  | April 3, 2015 |  | April 1, 2016 |  | April 3, 2015 |
| Balance, beginning of period |  | $ | 223 |  |  | $ | 282 |  |  | $ | 248 |  |  | $ | 273 |  |
| Warranties issued |  | 30 |  |  | 36 |  |  | 96 |  |  | 116 |  |
| Repairs and replacements |  | (37 | ) |  | (45 | ) |  | (118 | ) |  | (145 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | (11 | ) |  | — |  |  | (23 | ) |  | 21 |  |
| Warranty liability assumed from business acquisitions |  | — |  |  | — |  |  | 2 |  |  | 8 |  |
| Balance, end of period |  | $ | 205 |  |  | $ | 273 |  |  | $ | 205 |  |  | $ | 273 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001104659-16-116201:notes:168]
The components of property, equipment and leasehold improvements, net, were as follows:

[0001104659-16-116201:notes:169]
| (Dollars in millions) |  | April 1, 2016 |  | July 3, 2015 |
| Property, equipment and leasehold improvements |  | $ | 9,808 |  |  | $ | 9,630 |  |
| Accumulated depreciation and amortization |  | (7,643 | ) |  | (7,352 | ) |
|  |  | $ | 2,165 |  |  | $ | 2,278 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001104659-16-116201:notes:170]
Restructuring and Exit Costs

[0001104659-16-116201:notes:171]
For the three and nine months ended April 1, 2016, the Company recorded restructuring charges of approximately $20 million and $95 million, respectively, comprised primarily of charges related to employee termination costs and facility exit costs associated with restructuring of our work force during the fiscal year.  The Company's significant restructuring plans are described below.  All restructuring charges are reported in Restructuring and other, net on the Condensed Consolidated Statements of Operations.

[0001104659-16-116201:notes:172]
September 2015 Plan -  On September 4, 2015, the Company committed to a restructuring plan (the “September 2015 Plan”) intended to realign its cost structure with the current macroeconomic business environment. The September 2015 Plan included reducing worldwide headcount by approximately 1,000 employees. The September 2015 Plan was largely completed by the fiscal quarter ended January 1, 2016. For the nine months ended April 1, 2016, the Company recorded total restructuring charges of approximately $65 million related to the September 2015 Plan, comprised of approximately $57 million for employee termination costs and $8 million facility exit costs, respectively.  The Company did not record any material restructuring charges related to the September 2015 Plan in the three months ended April 1, 2016.  For the three and nine months ended April 1, 2016, the Company made cash payments of $7 million and $53 million, respectively, comprised primarily of employee termination costs related to the September 2015 Plan.

[0001104659-16-116201:notes:173]
February 2016 Plan -  On February 15, 2016, the Company committed to a restructuring plan (the “February 2016 Plan”) intended to align our manufacturing footprint with current macroeconomic conditions. The February 2016 Plan included reducing worldwide headcount by approximately 2,000 employees. The February 2016 Plan was largely completed by the fiscal quarter ended April 1, 2016. For the three and nine months ended April 1, 2016, the Company recorded total restructuring charges of approximately $15 million related to the February 2016 Plan, comprised of approximately $14 million for employee termination costs and $1 million facility exit costs, respectively. For the three and nine months ended April 1, 2016, the Company made cash payments of $14 million, comprised primarily of employee termination costs related to the February 2016 Plan.

[0001104659-16-116201:notes:174]
Other Restructuring and Exit Costs -  For the three and nine months ended April 1, 2016, the Company recorded restructuring charges of approximately $5 million and $15 million, respectively, and made cash payments of $8 million and $26 million, respectively, related to other restructuring plans.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001104659-16-116201:notes:175]
The components of AOCI, net of tax, were as follows:

[0001104659-16-116201:notes:176]
| (Dollars in millions) |  | Unrealized Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Marketable Securities (a) |  | Unrealized Gains (Losses) on post-retirement plans |  | Foreign currency translation adjustments |  | Total |
| Balance at July 3, 2015 |  | $ | 1 |  |  | $ | — |  |  | $ | (15 | ) |  | $ | (16 | ) |  | $ | (30 | ) |
| Other comprehensive income (loss) before reclassifications |  | (3 | ) |  | — |  |  | 1 |  |  | 2 |  |  | — |  |
| Amounts reclassified from AOCI |  | 2 |  |  | — |  |  | — |  |  | — |  |  | 2 |  |
| Other comprehensive income (loss) |  | (1 | ) |  | — |  |  | 1 |  |  | 2 |  |  | 2 |  |
| Balance at April 1, 2016 |  | $ | — |  |  | $ | — |  |  | $ | (14 | ) |  | $ | (14 | ) |  | $ | (28 | ) |
| Balance at June 27, 2014 |  | $ | (1 | ) |  | $ | — |  |  | $ | (10 | ) |  | $ | 9 |  |  | $ | (2 | ) |
| Other comprehensive income (loss) before reclassifications |  | (12 | ) |  | — |  |  | — |  |  | (28 | ) |  | (40 | ) |
| Amounts reclassified from AOCI |  | 9 |  |  | — |  |  | — |  |  | — |  |  | 9 |  |
| Other comprehensive income (loss) |  | (3 | ) |  | — |  |  | — |  |  | (28 | ) |  | (31 | ) |
| Balance at April 3, 2015 |  | $ | (4 | ) |  | $ | — |  |  | $ | (10 | ) |  | $ | (19 | ) |  | $ | (33 | ) |

[0001104659-16-116201:notes:177]
[same as prior period, unchanged from 0001104659-16-092467:notes:168]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001104659-16-116201:notes:178]
The following table provides details of the inventory balance sheet item:

[0001104659-16-116201:notes:179]
| (Dollars in millions) |  | April 1, 2016 |  | July 3, 2015 |
| Raw materials and components |  | $ | 353 |  |  | $ | 352 |  |
| Work-in-process |  | 243 |  |  | 239 |  |
| Finished goods |  | 332 |  |  | 402 |  |
|  |  | $ | 928 |  |  | $ | 993 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-16-116201:notes:180]
[same as prior period, unchanged from 0001104659-16-092467:notes:170]

[0001104659-16-116201:notes:181]
[same as prior period, unchanged from 0001104659-16-092467:notes:171]

[0001104659-16-116201:notes:182]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 298,459,787 shares were outstanding as of April 1, 2016, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of April 1, 2016.

[0001104659-16-116201:notes:183]
[same as prior period, unchanged from 0001104659-16-092467:notes:173]

[0001104659-16-116201:notes:184]
[same as prior period, unchanged from 0001104659-16-092467:notes:174]

[0001104659-16-116201:notes:185]
[same as prior period, unchanged from 0001104659-16-092467:notes:175]

[0001104659-16-116201:notes:186]
[same as prior period, unchanged from 0001104659-16-092467:notes:176]

[0001104659-16-116201:notes:187]
[same as prior period, unchanged from 0001104659-16-092467:notes:177]

[0001104659-16-116201:notes:188]
[same as prior period, unchanged from 0001104659-16-092467:notes:178]

[0001104659-16-116201:notes:189]
[same as prior period, unchanged from 0001104659-16-092467:notes:179]

[0001104659-16-116201:notes:190]
As of April 1, 2016, $1.8 billion remained available for repurchase under the existing repurchase authorization limit.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001104659-16-116201:notes:191]
[same as prior period, unchanged from 0001104659-16-092467:notes:182]

[0001104659-16-116201:notes:192]
[same as prior period, unchanged from 0001104659-16-092467:notes:183]

[0001104659-16-116201:notes:193]
As of April 1, 2016, the Company’s Other current assets included $7 million in restricted cash and investments held as collateral at banks for various performance obligations.

[0001104659-16-116201:notes:194]
As of April 1, 2016, the Company had no material available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined that no available-for-sale securities were other-than-temporarily impaired as of April 1, 2016.

[0001104659-16-116201:notes:195]
[same as prior period, unchanged from 0001104659-16-092467:notes:189]

[0001104659-16-116201:notes:196]
[same as prior period, unchanged from 0001104659-16-092467:notes:190]

[0001104659-16-116201:notes:197]
[same as prior period, unchanged from 0001104659-16-092467:notes:191]

[0001104659-16-116201:notes:198]
[same as prior period, unchanged from 0001104659-16-092467:notes:193]

[0001104659-16-116201:notes:199]
In the three and nine months ended April 1, 2016, the Company determined it would discontinue the use of certain manufacturing property and equipment in the short-term, and that certain other manufacturing property and equipment was permanently impaired, and as a result recognized a charge of $32 million from the write-off and accelerated depreciation of of these fixed assets. This amount was recorded in Cost of revenue in the Condensed Consolidated Statement of Operations. In the three and nine months ended April 3, 2015, the Company did not record any material impairment charges.

[0001104659-16-116201:notes:200]
[same as prior period, unchanged from 0001104659-16-092467:notes:195]
