# STX MD&A — 0001193125-17-019732


## mdna

[0001193125-17-019732:mdna:1]
[same as prior period, unchanged from 0001193125-16-751593:mdna:1]

[0001193125-17-019732:mdna:2]
The following is a discussion of the financial condition, changes in financial condition, and results of operations for our fiscal quarters
ended December 30, 2016, September 30, 2016 and January 1, 2016, referred to herein as the “December 2016 quarter,” the “September 2016 quarter,” and the “December 2015 quarter,” respectively. We
operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The December 2016, September 2016, and December 2015 quarters were 13 weeks.

[0001193125-17-019732:mdna:3]
[same as prior period, unchanged from 0001193125-16-751593:mdna:3]

[0001193125-17-019732:mdna:4]
[same as prior period, unchanged from 0001193125-16-751593:mdna:4]

[0001193125-17-019732:mdna:5]
[same as prior period, unchanged from 0001193125-16-751593:mdna:5]

[0001193125-17-019732:mdna:6]
|  | • |  | Overview of the December 2016 quarter. Highlights of events in the December 2016 quarter that impacted our financial position. |

[0001193125-17-019732:mdna:7]
|  | • |  | Results of Operations. An analysis of our financial results comparing the December 2016 quarter to the September 2016 quarter and the December 2015 quarter. |

[0001193125-17-019732:mdna:8]
[same as prior period, unchanged from 0001193125-16-751593:mdna:8]

[0001193125-17-019732:mdna:9]
[same as prior period, unchanged from 0001193125-16-751593:mdna:9]

[0001193125-17-019732:mdna:10]
[same as prior period, unchanged from 0001193125-16-751593:mdna:10]

[0001193125-17-019732:mdna:11]
We are a leading provider of
electronic data storage technology and solutions. Our principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, we produce a broad range of electronic data storage products including
solid state drives (“SSD”) in our Enterprise market portfolio and solid state hybrid drives (“SSHD”). Our storage technology portfolio also includes storage subsystems, and high performance computing (“HPC”) solutions.

[0001193125-17-019732:mdna:12]
Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to
be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness.

[0001193125-17-019732:mdna:13]
[same as prior period, unchanged from 0001193125-16-751593:mdna:23]

[0001193125-17-019732:mdna:14]
Complementing existing data center storage architecture, solid-state storage devices use integrated circuit assemblies as memory to store data, and most SSDs use NAND-based flash memory. In
addition to HDDs and SSDs, SSHDs combine the features of SSDs and HDDs in the same unit, containing a large hard disk drive and an SSD cache to improve performance of frequently accessed data.

[0001193125-17-019732:mdna:15]
[same as prior period, unchanged from 0001193125-16-751593:mdna:15]

[0001193125-17-019732:mdna:16]
Our Cloud Systems and
Solutions product portfolio builds on the Seagate legacy to extend innovation from the device into the information infrastructure, onsite and in the cloud. This product portfolio includes HPC storage solutions, modular original equipment
manufacturers (“OEM”) storage systems and scale-out storage systems.

[0001193125-17-019732:mdna:17]
Overview of the December 2016 Quarter

[0001193125-17-019732:mdna:18]
During the December 2016 quarter, we shipped 40 million drive units totaling 68 exabytes of storage capacity, generating revenue of
approximately $2.9 billion and gross margin of 31%. Our operating cash flow was $656 million. We repurchased 4 million ordinary shares for $147 million and paid dividends of $188 million.

[0001193125-17-019732:mdna:19]
[same as prior period, unchanged from 0001193125-16-751593:mdna:19]

[0001193125-17-019732:mdna:20]
[same as prior period, unchanged from 0001193125-16-751593:mdna:20]

[0001193125-17-019732:mdna:21]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (Dollars in millions) |  | December 30,2016 |  |  | September 30,2016 |  |  | January 1,2016 |  |  | December 30,2016 |  |  | January 1,2016 |  |
| Revenue |  | $ | 2,894 |  |  | $ | 2,797 |  |  | $ | 2,986 |  |  | $ | 5,691 |  |  | $ | 5,911 |  |
| Cost of revenue |  |  | 2,003 |  |  |  | 1,996 |  |  |  | 2,245 |  |  |  | 3,999 |  |  |  | 4,482 |  |
| Gross margin |  |  | 891 |  |  |  | 801 |  |  |  | 741 |  |  |  | 1,692 |  |  |  | 1,429 |  |
| Product development |  |  | 305 |  |  |  | 315 |  |  |  | 304 |  |  |  | 620 |  |  |  | 632 |  |
| Marketing and administrative |  |  | 155 |  |  |  | 155 |  |  |  | 160 |  |  |  | 308 |  |  |  | 341 |  |
| Amortization of intangibles |  |  | 28 |  |  |  | 28 |  |  |  | 31 |  |  |  | 57 |  |  |  | 65 |  |
| Restructuring and other, net |  |  | 33 |  |  |  | 82 |  |  |  | 17 |  |  |  | 115 |  |  |  | 76 |  |
| Income from operations |  |  | 370 |  |  |  | 221 |  |  |  | 229 |  |  |  | 592 |  |  |  | 315 |  |
| Other expense, net |  |  | (60 | ) |  |  | (48 | ) |  |  | (49 | ) |  |  | (109 | ) |  |  | (104 | ) |
| Income before income taxes |  |  | 310 |  |  |  | 173 |  |  |  | 180 |  |  |  | 483 |  |  |  | 211 |  |
| Provision for income taxes |  |  | 13 |  |  |  | 6 |  |  |  | 15 |  |  |  | 19 |  |  |  | 13 |  |
| Net income |  | $ | 297 |  |  | $ | 167 |  |  | $ | 165 |  |  | $ | 464 |  |  | $ | 198 |  |

[0001193125-17-019732:mdna:22]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
|  |  | December 30,2016 |  |  | September 30,2016 |  |  | January 1,2016 |  |  | December 30,2016 |  |  | January 1,2016 |  |
| Revenue |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |
| Cost of revenue |  |  | 69 |  |  |  | 71 |  |  |  | 75 |  |  |  | 70 |  |  |  | 76 |  |
| Gross margin |  |  | 31 |  |  |  | 29 |  |  |  | 25 |  |  |  | 30 |  |  |  | 24 |  |
| Product development |  |  | 11 |  |  |  | 11 |  |  |  | 10 |  |  |  | 11 |  |  |  | 11 |  |
| Marketing and administrative |  |  | 5 |  |  |  | 6 |  |  |  | 5 |  |  |  | 6 |  |  |  | 6 |  |
| Amortization of intangibles |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |
| Restructuring and other, net |  |  | 1 |  |  |  | 3 |  |  |  | 1 |  |  |  | 2 |  |  |  | 1 |  |
| Income from operations |  |  | 13 |  |  |  | 8 |  |  |  | 8 |  |  |  | 10 |  |  |  | 5 |  |
| Other expense, net |  |  | (2 | ) |  |  | (2 | ) |  |  | (2 | ) |  |  | (2 | ) |  |  | (2 | ) |
| Income before income taxes |  |  | 11 |  |  |  | 6 |  |  |  | 6 |  |  |  | 8 |  |  |  | 3 |  |
| Provision for income taxes |  |  | 1 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net income |  |  | 10 | % |  |  | 6 | % |  |  | 6 | % |  |  | 8 | % |  |  | 3 | % |

[0001193125-17-019732:mdna:23]
30

[0001193125-17-019732:mdna:24]
[same as prior period, unchanged from 0001193125-16-751593:mdna:24]

[0001193125-17-019732:mdna:25]
[same as prior period, unchanged from 0001193125-16-751593:mdna:25]

[0001193125-17-019732:mdna:26]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (In millions, except percentages, exabytes and ASPs) |  | December 30,2016 |  |  | September 30,2016 |  |  | January 1,2016 |  |  | December 30,2016 |  |  | January 1,2016 |  |
| Unit Shipments (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Enterprise |  |  | 8 |  |  |  | 9 |  |  |  | 8 |  |  |  | 17 |  |  |  | 16 |  |
| Client Compute |  |  | 18 |  |  |  | 16 |  |  |  | 25 |  |  |  | 34 |  |  |  | 53 |  |
| Client Non-Compute |  |  | 14 |  |  |  | 14 |  |  |  | 13 |  |  |  | 28 |  |  |  | 24 |  |
| Total Units Shipped |  |  | 40 |  |  |  | 39 |  |  |  | 46 |  |  |  | 79 |  |  |  | 93 |  |
| ASPs (per unit) |  | $ | 66 |  |  | $ | 67 |  |  | $ | 59 |  |  | $ | 67 |  |  | $ | 59 |  |
| Exabytes Shipped |  |  | 68 |  |  |  | 67 |  |  |  | 61 |  |  |  | 135 |  |  |  | 117 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OEMs |  |  | 66 | % |  |  | 71 | % |  |  | 69 | % |  |  | 68 | % |  |  | 69 | % |
| Distributors |  |  | 18 | % |  |  | 17 | % |  |  | 16 | % |  |  | 18 | % |  |  | 17 | % |
| Retailers |  |  | 16 | % |  |  | 12 | % |  |  | 15 | % |  |  | 14 | % |  |  | 14 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  |  | 30 | % |  |  | 34 | % |  |  | 26 | % |  |  | 32 | % |  |  | 27 | % |
| EMEA |  |  | 19 | % |  |  | 15 | % |  |  | 19 | % |  |  | 17 | % |  |  | 18 | % |
| Asia Pacific |  |  | 51 | % |  |  | 51 | % |  |  | 55 | % |  |  | 51 | % |  |  | 55 | % |

[0001193125-17-019732:mdna:27]
[same as prior period, unchanged from 0001193125-16-751593:mdna:27]

[0001193125-17-019732:mdna:28]
Revenue in the December 2016 quarter increased by $97 million from the September 2016 quarter as a result of an increase in unit shipments
driven primarily by better seasonal demand and improved product mix offset by price erosion. Additionally, our revenue has become less heavily weighted towards OEMs.

[0001193125-17-019732:mdna:29]
Revenue in the December 2016 quarter and the six months then ended decreased by $92 million and $220 million, respectively, as compared to the
December 2015 quarter and the six months then ended due to a decrease in unit shipments and the impact of price erosion, partially offset by improved product mix. The decrease in unit shipments of 6 million and 14 million as compared to
the December 2015 quarter and the six months then ended, respectively, was the result of decreased demand for client compute devices, which generally have lower ASPs. Additionally, our revenue has become less heavily weighted towards OEMs.

[0001193125-17-019732:mdna:30]
We maintain various sales programs such as channel rebates and price masking. Sales programs were approximately at 11%, 10% and 14% of gross
drive revenue for the December 2016 quarter, September 2016 quarter and December 2015 quarter, respectively. Adjustments to revenues due to under or over accruals for sales programs related to revenues reported in prior quarterly periods were less
than 1% of quarterly gross revenue in all periods presented.

[0001193125-17-019732:mdna:31]
[same as prior period, unchanged from 0001193125-16-751593:mdna:30]

[0001193125-17-019732:mdna:32]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (Dollars in millions) |  | December 30,2016 |  |  | September 30,2016 |  |  | January 1,2016 |  |  | December 30,2016 |  |  | January 1,2016 |  |
| Cost of revenue |  | $ | 2,003 |  |  | $ | 1,996 |  |  | $ | 2,245 |  |  | $ | 3,999 |  |  | $ | 4,482 |  |
| Gross margin |  |  | 891 |  |  |  | 801 |  |  |  | 741 |  |  |  | 1,692 |  |  |  | 1,429 |  |
| Gross margin percentage |  |  | 31 | % |  |  | 29 | % |  |  | 25 | % |  |  | 30 | % |  |  | 24 | % |

[0001193125-17-019732:mdna:33]
Gross margin as a percentage of revenue for the December 2016 quarter increased by 200 and 600 basis points
compared to the September 2016 quarter and December 2015 quarter, respectively, driven by favorable product mix and improved utilization of factories resulting from cost savings due to our ongoing workforce reductions and manufacturing consolidation
activities, partially offset by price erosion.

[0001193125-17-019732:mdna:34]
[same as prior period, unchanged from 0001193125-16-751593:mdna:44]

[0001193125-17-019732:mdna:35]
Compared to the six months ended in the December 2015 quarter, gross margin for the six months
then ended in the December 2016 quarter increased by 600 basis points due to a favorable product mix and improved utilization of factories resulting from cost savings due to our ongoing workforce reductions and manufacturing consolidation
activities, partially offset by price erosion.

[0001193125-17-019732:mdna:36]
In the December 2016 quarter, total warranty cost was in the historical range of 1% to
1.5% of revenue and included an unfavorable change in estimates of prior warranty accruals of less than 0.5% of revenue. Warranty cost related to new unit shipments was 1.2%, 1.1%, and 1.1% of revenue for each of the December 2016, September
2016 and December 2015 quarters, respectively.

[0001193125-17-019732:mdna:37]
[same as prior period, unchanged from 0001193125-16-751593:mdna:35]

[0001193125-17-019732:mdna:38]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (Dollars in millions) |  | December 30,2016 |  |  | September 30,2016 |  |  | January 1,2016 |  |  | December 30,2016 |  |  | January 1,2016 |  |
| Product development |  | $ | 305 |  |  | $ | 315 |  |  | $ | 304 |  |  | $ | 620 |  |  | $ | 632 |  |
| Marketing and administrative |  |  | 155 |  |  |  | 155 |  |  |  | 160 |  |  |  | 308 |  |  |  | 341 |  |
| Amortization of intangibles |  |  | 28 |  |  |  | 28 |  |  |  | 31 |  |  |  | 57 |  |  |  | 65 |  |
| Restructuring and other, net |  |  | 33 |  |  |  | 82 |  |  |  | 17 |  |  |  | 115 |  |  |  | 76 |  |
| Operating expenses |  | $ | 521 |  |  | $ | 580 |  |  | $ | 512 |  |  | $ | 1,100 |  |  | $ | 1,114 |  |

[0001193125-17-019732:mdna:39]
Product development expense. Product development expense for the December 2016 quarter decreased
by $10 million from the September 2016 quarter due to a $10 million decrease in salaries and related benefits as a result of the restructuring of our workforce in the prior periods and an increase in operational efficiencies in our business,
partially offset by an increase in variable compensation driven by improved financial performance. Compared to the December 2015 quarter, product development expense remained flat due to a $25 million increase in variable compensation driven by
improved financial performance, offset by a $16 million decrease in salaries and related benefits as a result of the restructuring of our workforce in prior periods and an increase in operational efficiencies.

[0001193125-17-019732:mdna:40]
Product development expense for the six months ended December 2016 quarter decreased by $12 million as compared to the corresponding period in
the prior year due to a decrease in salaries and related benefits of $58 million as a result of the restructuring of our workforce in the prior periods, and an increase in operational efficiencies in our business, offset by an increase in variable
compensation and share-based compensation of $69 million driven by better financial performance.

[0001193125-17-019732:mdna:41]
Marketing and administrative
expense. Marketing and administrative expense for the December 2016 quarter remained flat from the September 2016 quarter. Compared to the December 2015 quarter, marketing and administrative expense decreased by $5 million due to a $13
million decrease in salaries and related benefits as a result of the restructuring of our workforce in prior periods and, a $9 million reduction in advertising and marketing expenses in the December 2016 quarter. The decrease was partially offset by
a $15 million increase in variable compensation driven by better financial performance in the December 2016 quarter.

[0001193125-17-019732:mdna:42]
Marketing and
administrative expense for the six months ended December 2016 quarter decreased by $33 million compared to the corresponding period in the prior year due to a decrease in salaries and related benefits of $42 million as a result of the restructuring
of our workforce in prior periods, a $24 million reduction resulting from the completion of certain promotional and branding activities in fiscal year 2016 and other cost reduction efforts, partially offset by a $33 million increase in variable
compensation and share-based compensation driven by better financial performance.

[0001193125-17-019732:mdna:43]
Amortization of intangibles. Amortization
of intangibles for the December 2016 quarter remained flat from the September 2016 quarter. Compared to the December 2015 quarter, amortization of intangibles decreased by $3 million due to certain intangible assets reaching the end of their useful
life.

[0001193125-17-019732:mdna:44]
Amortization of intangibles for the six months ended December 2016 decreased by $8 million as compared to the corresponding
period in the prior year due to certain intangible assets reaching the end of their useful life, partially offset by the amortization of intangible assets acquired in the acquisition of Dot Hill in the December 2015 quarter.

[0001193125-17-019732:mdna:45]
Restructuring and other, net. Restructuring and other, net for the September 2016 quarter and the six months ended December 2016 was
comprised primarily of restructuring charges to reduce our global workforce by 6,500 employees as we continue to consolidate our global footprint across Asia, EMEA and the Americas.

[0001193125-17-019732:mdna:46]
Restructuring and other, net for three and six months ended December 2015 was comprised primarily of a restructuring charge recorded for
September 2015 Plan to reduce our workforce by approximately 1,000 employees as a result of our ongoing focus on cost efficiencies in all areas of our business. See “Part I, Item 1. Financial Statements-Note 7. Restructuring
and Exit Costs” for more details.

[0001193125-17-019732:mdna:47]
32

[0001193125-17-019732:mdna:48]
Other Expense, Net

[0001193125-17-019732:mdna:49]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (Dollars in millions) |  | December 30,2016 |  |  | September 30,2016 |  |  | January 1,2016 |  |  | December 30,2016 |  |  | January 1,2016 |  |
| Other expense, net |  | $ | (60 | ) |  | $ | (48 | ) |  | $ | (49 | ) |  | $ | (109 | ) |  | $ | (104 | ) |

[0001193125-17-019732:mdna:50]
Other expense, net increased by $12 million and $11 million from the September 2016 and December 2015
quarters, respectively, due to a $25 million charge related to the impairment of a strategic investment in the December 2016 quarter, partially offset by $16 million and $14 million, in the September 2016 and December 2015 quarters, respectively,
from favorable foreign currency changes in foreign exchange rates.

[0001193125-17-019732:mdna:51]
Other expense, net for the six months ended December 2016 increased by
$5 million from the prior six month period ended December 2015, due to a $25 million charge related to the impairment of a strategic investment, partially offset by $11 million from favorable foreign currency changes in foreign exchange rates and a
$10 million loss related to the impairment of a strategic investment in the prior six month period ended December 2015.

[0001193125-17-019732:mdna:52]
[same as prior period, unchanged from 0001193125-16-751593:mdna:45]

[0001193125-17-019732:mdna:53]
|  |  | For the Three Months Ended |  |  | For the Six Months Ended |  |
| (Dollars in millions) |  | December 30,2016 |  |  | September 30,2016 |  |  | January 1,2016 |  |  | December 30,2016 |  |  | January 1,2016 |  |
| Provision for income taxes |  | $ | 13 |  |  | $ | 6 |  |  | $ | 15 |  |  | $ | 19 |  |  | $ | 13 |  |

[0001193125-17-019732:mdna:54]
Our income tax provision of $13 million and $19 million in the three and six months ended December 30,
2016 included less than $1 million of net discrete tax expense and approximately $4 million of net discrete tax benefits, respectively. These discrete items are primarily associated with the release of tax reserves due to the expiration of certain
statutes of limitation and prior year tax adjustments.

[0001193125-17-019732:mdna:55]
Our income tax provision recorded for the December 2016 quarter and for the first
half of fiscal year 2017 differed from the provision from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S.
earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain deferred tax assets.

[0001193125-17-019732:mdna:56]
During the six months ended December 30, 2016, our unrecognized tax benefits excluding interest and penalties decreased by approximately
$4 million to $66 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate were $66 million at December 30, 2016, subject to certain future valuation allowance reversals. During the 12 months beginning
December 31, 2016, we expect that our unrecognized tax benefits could be reduced by approximately $12 million, primarily as a result of the expiration of certain statutes of limitation.

[0001193125-17-019732:mdna:57]
Our income tax provision recorded for the first half of fiscal year 2016 included approximately $3 million of net discrete tax benefits,
primarily for the release of tax reserves due to the expiration of certain statutes of limitation.

[0001193125-17-019732:mdna:58]
Our income tax provision recorded for
the December 2015 quarter and for the first half of fiscal year 2016 differed from the provision from income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of
(i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance
for certain U.S. deferred tax assets. The acquisition of Dot Hill Systems Corporation did not have a material impact on our effective tax rate in fiscal year 2016.

[0001193125-17-019732:mdna:59]
[same as prior period, unchanged from 0001193125-16-751593:mdna:52]

[0001193125-17-019732:mdna:60]
The
following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days
or less at the time of purchase. Our short-term investments consist primarily of money market funds, and certificates of deposit. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We
believe our cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have

[0001193125-17-019732:mdna:61]
[same as prior period, unchanged from 0001193125-16-751593:mdna:79]

[0001193125-17-019732:mdna:62]
restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash have been and will continue to be sufficient to meet our
cash needs for the next 12 months unimpeded by any restrictive regulations. We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term investments and we do
not believe the fair value of our short-term investments has significantly changed from the values reported as of December 30, 2016.

[0001193125-17-019732:mdna:63]
Cash and
Cash Equivalents and Short-term Investments

[0001193125-17-019732:mdna:64]
| (Dollars in millions) |  | December 30,2016 |  |  | July 1,2016 |  |  | Change |  |
| Cash and cash equivalents |  | $ | 1,716 |  |  | $ | 1,125 |  |  | $ | 591 |  |
| Short-term investments |  |  | — |  |  |  | 6 |  |  |  | (6 | ) |
| Total |  | $ | 1,716 |  |  | $ | 1,131 |  |  | $ | 585 |  |

[0001193125-17-019732:mdna:65]
Our cash and cash equivalents and short-term investments increased from July 1, 2016 as a result of an
increase in net cash provided by operating activities, partially offset by net cash outflows for capital expenditures, repurchases of our ordinary shares and dividends paid to our shareholders.

[0001193125-17-019732:mdna:66]
[same as prior period, unchanged from 0001193125-16-751593:mdna:57]

[0001193125-17-019732:mdna:67]
Cash provided by operating activities for the six months ended December 30, 2016 of $1,247 million includes the effects of net income
adjusted for non-cash items including depreciation, amortization, share-based compensation, and:

[0001193125-17-019732:mdna:68]
|  | • |  | a decrease of $110 million in accounts receivable, primarily due to a change in channel mix and improved in-quarter linearity of shipments; and |

[0001193125-17-019732:mdna:69]
|  | • |  | an increase of $170 million in accounts payable, primarily due to the timing of payments of material purchases and an increase in units built; offset by |

[0001193125-17-019732:mdna:70]
|  | • |  | an increase in inventory of $140 million primarily due to an increase in units built in anticipation of adjustments to our manufacturing footprint. |

[0001193125-17-019732:mdna:71]
[same as prior period, unchanged from 0001193125-16-751593:mdna:60]

[0001193125-17-019732:mdna:72]
Cash used for investing activities for the six months ended December 30, 2016 was $234 million and primarily attributable to the following
activities:

[0001193125-17-019732:mdna:73]
|  | • |  | $235 million used to acquire property, equipment and leasehold improvements |

[0001193125-17-019732:mdna:74]
[same as prior period, unchanged from 0001193125-16-751593:mdna:63]

[0001193125-17-019732:mdna:75]
Cash used in financing activities of $413 million for the six months ended December 30, 2016 was primarily
attributable to the following activities:

[0001193125-17-019732:mdna:76]
|  | • |  | $248 million paid to repurchase ordinary shares; |

[0001193125-17-019732:mdna:77]
|  | • |  | $188 million in dividend payments; and |

[0001193125-17-019732:mdna:78]
|  | • |  | $24 million paid for taxes related to net share settlement of equity awards; offset by |

[0001193125-17-019732:mdna:79]
|  | • |  | $47 million in proceeds from issuance of ordinary shares under employee stock plans |

[0001193125-17-019732:mdna:80]
[same as prior period, unchanged from 0001193125-16-751593:mdna:68]

[0001193125-17-019732:mdna:81]
Our primary sources of liquidity as of December 30, 2016 consisted of:
(1) approximately $1.7 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) a $700 million senior revolving credit facility.

[0001193125-17-019732:mdna:82]
As of December 30, 2016, no borrowings had been drawn under the revolving credit facility or had been utilized for letters of credit
issued under this credit facility. The line of credit is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001193125-17-019732:mdna:83]
The credit agreement that governs our revolving credit facility, as amended, includes three financial covenants: (1) minimum cash, cash
equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. On April 28, 2016, the Revolving Credit Agreement was amended in order to increase the allowable net leverage ratio to adjust for
our current financial liquidity position. We were in compliance with the modified covenants as of December 30, 2016 and expect to be in compliance for the next 12 months.

[0001193125-17-019732:mdna:84]
34

[0001193125-17-019732:mdna:85]
Our liquidity requirements are primarily to meet our working capital, product development and
capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend. Our ability to fund these requirements will depend on our future cash flows, which are determined by future
operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control. However, we believe our sources of cash will continue to be
sufficient to meet our cash needs for the next 12 months

[0001193125-17-019732:mdna:86]
For fiscal year 2017, we expect capital expenditures to be less than
5% of revenue.

[0001193125-17-019732:mdna:87]
From time to time we may repurchase any of our outstanding notes in open market or privately negotiated purchases or
otherwise, or may repurchase outstanding notes pursuant to the terms of the applicable indenture.

[0001193125-17-019732:mdna:88]
Dividends declared in the December 2016
quarter of $186 million were subsequently paid on January 4, 2017. The Company’s Board of Directors declared a quarterly cash dividend of $0.63 per share on January 24, 2017, which is payable on April 5, 2017 to shareholders of
record at the close of business on March 22, 2017.

[0001193125-17-019732:mdna:89]
From time to time we may repurchase any of our outstanding ordinary shares
through private, open market, or broker assisted purchases. As of December 30, 2016, $1.5 billion remained available for repurchase under our existing repurchase authorization limit. All repurchases are effected as redemptions in
accordance with the Company’s Articles of Association.

[0001193125-17-019732:mdna:90]
Contractual Obligations and Commitments

[0001193125-17-019732:mdna:91]
Our contractual cash obligations and commitments as of December 30, 2016, have been summarized in the table below:

[0001193125-17-019732:mdna:92]
|  |  |  |  |  | Fiscal Year(s) |  |
| (Dollars in millions) |  | Total |  |  | Remainder of 2017 |  |  | 2018-2019 |  |  | 2020-2021 |  |  | Thereafter |  |
| Contractual Cash Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt |  | $ | 4,133 |  |  | $ | — |  |  | $ | 800 |  |  | $ | — |  |  | $ | 3,333 |  |
| Interest payments on debt |  |  | 1,692 |  |  |  | 99 |  |  |  | 381 |  |  |  | 334 |  |  |  | 878 |  |
| Purchase obligations (2) |  |  | 1,801 |  |  |  | 901 |  |  |  | 725 |  |  |  | 175 |  |  |  | — |  |
| Operating leases (1) |  |  | 148 |  |  |  | 12 |  |  |  | 37 |  |  |  | 20 |  |  |  | 79 |  |
| Capital expenditures |  |  | 128 |  |  |  | 128 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other funding requirements (3) |  |  | 40 |  |  |  | 8 |  |  |  | 24 |  |  |  | 8 |  |  |  | — |  |
| Subtotal |  |  | 7,942 |  |  |  | 1,148 |  |  |  | 1,967 |  |  |  | 537 |  |  |  | 4,290 |  |
| Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit or bank guarantees |  |  | 105 |  |  |  | 105 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 8,047 |  |  | $ | 1,253 |  |  | $ | 1,967 |  |  | $ | 537 |  |  | $ | 4,290 |  |

[0001193125-17-019732:mdna:93]
| (1) | Includes total future minimum rent expense under non-cancelable leases for both occupied and vacated facilities (rent expense is shown net of sublease income). |

[0001193125-17-019732:mdna:94]
| (2) | Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. |

[0001193125-17-019732:mdna:95]
| (3) | Consists of funding requirements related to strategic commitments. |

[0001193125-17-019732:mdna:96]
As of December 30,
2016, we had a liability for unrecognized tax benefits and an accrual for the payment of related interest totaling $11 million, none of which is expected to be settled within one year. Outside of one year, we are unable to make a reasonably reliable
estimate of when cash settlement with a taxing authority will occur.

[0001193125-17-019732:mdna:97]
[same as prior period, unchanged from 0001193125-16-751593:mdna:77]

[0001193125-17-019732:mdna:98]
Our discussion and analysis of financial condition and results of operations are based upon our Condensed Consolidated Financial Statements,
which have been prepared in accordance with U.S. generally accepted accounting principles. The preparation of such statements requires us to make estimates and assumptions that affect the reported amounts of revenues and expenses during the
reporting period and the reported amounts of assets and liabilities as of the date of the financial statements. Our estimates are based on historical experience and other assumptions that we consider to be appropriate in the circumstances. However,
actual future results may vary from our estimates.

[0001193125-17-019732:mdna:99]
Since our fiscal year ended July 1, 2016, there have been no material changes in
our critical accounting policies and estimates. Refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Part II, Item 7 of our Annual Report on Form 10-K
for the fiscal year ended July 1, 2016, as filed with the SEC on August 5, 2016, for a discussion of our critical accounting policies and estimates.

[0001193125-17-019732:mdna:100]
Recent Accounting Pronouncements

[0001193125-17-019732:mdna:101]
See “Part I, Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting
Policies” for information regarding the effect of new accounting pronouncements on our financial statements.
