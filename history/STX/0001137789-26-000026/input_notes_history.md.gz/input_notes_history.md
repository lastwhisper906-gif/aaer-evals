# STX note change history — 0001137789-25-000317 → 0001137789-26-000026


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001137789-26-000026:note_history:1]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC and certain of its affiliates, (collectively, the “Seagate Entities”) filed a complaint alleging violations of federal and state antitrust laws as well as breach of contract in the U.S. District Court for the Northern District of California against suppliers of HDD suspension assemblies, including NHK Spring Co. Ltd., TDK Corporation (“TDK”) and Hutchinson Technology Inc (“HTI”). The Seagate Entities seek to recover damages suffered as a result of the suspension assembly suppliers’ conduct, and additional relief permitted by law. On April 8, 2022, the court dismissed with prejudice all claims against TDK and HTI after the Seagate Entities settled with those defendants. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment under the Foreign Trade Antitrust Improvement Act (“FTAIA Motion”). On November 17, 2023, the Court granted NHK’s FTAIA Motion on reconsideration, denying the majority of Seagate’s antitrust claims. On January 8, 2026, the Ninth Circuit reserved the District Court’s decision and remanded the case to the District Court, allowing Seagate’s antitrust claims to proceed.
  (was, 2025-10-31, similarity 0.9105):
[0001137789-25-000317:note_history:1]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC and certain of its affiliates, (collectively, the “Seagate Entities”) filed a complaint alleging violations of federal and state antitrust laws as well as breach of contract in the U.S. District Court for the Northern District of California against suppliers of HDD suspension assemblies, including NHK Spring Co. Ltd., TDK Corporation (“TDK”) and Hutchinson Technology Inc (“HTI”). The Seagate Entities seek to recover damages suffered as a result of the suspension assembly suppliers’ conduct, and additional relief permitted by law. On April 8, 2022, the court dismissed with prejudice all claims against TDK and HTI after the Seagate Entities settled with those defendants. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment under the Foreign Trade Antitrust Improvement Act (“FTAIA Motion”). On November 17, 2023, the Court granted NHK’s FTAIA Motion on reconsideration, denying the majority of Seagate’s antitrust claims. The Court’s FTAIA decision is now on appeal with the Ninth Circuit.

- changed (2026-01-30):
[0001137789-26-000026:note_history:2]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $105 million were included in Accrued expense and Other non-current liabilities, respectively, on the Condensed Consolidated Balance Sheets as of January 2, 2026. For the six months ended January 2, 2026, $30 million was paid and reported as an outflow from operating activities in its Condensed Consolidated Statements of Cash Flows.
  (was, 2025-10-31, similarity 0.8902):
[0001137789-25-000317:note_history:2]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $120 million were included in Accrued expense and Other non-current liabilities, respectively, on the Condensed Consolidated Balance Sheets as of October 3, 2025. For the three months ended October 3, 2025, $15 million was paid and reported as an outflow from operating activities in its Condensed Consolidated Statements of Cash Flows.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001137789-26-000026:note_history:3]
The Company’s Consolidated Financial Statements for the fiscal year ended June 27, 2025 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 1, 2025. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 27, 2025, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three and six months ended January 2, 2026 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending July 3, 2026.
  (was, 2025-10-31, similarity 0.966):
[0001137789-25-000317:note_history:3]
The Company’s Consolidated Financial Statements for the fiscal year ended June 27, 2025 are included in its Annual Report on Form 10-K, as filed with the U.S. Securities and Exchange Commission (“SEC”) on August 1, 2025. The Company believes that the disclosures included in these unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 27, 2025, and the notes thereto, are adequate to make the information presented not misleading. The results of operations for the three months ended October 3, 2025 are not necessarily indicative of the results to be expected for any subsequent interim period or for the Company’s fiscal year ending July 3, 2026.

- added (2026-01-30):
[0001137789-26-000026:note_history:4]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three and six months ended January 2, 2026 consisted of 13 weeks and 27 weeks, respectively, and the three and six months ended December 27, 2024 consisted of 13 weeks and 26 weeks, respectively. Fiscal years 2026 and 2025 comprise 53 and 52 weeks and end on July 3, 2026 and June 27, 2025, respectively. The fiscal quarters ended January 2, 2026, October 3, 2025 and December 27, 2024, are also referred to herein as the “December 2025 quarter”, the “September 2025 quarter” and the “December 2024 quarter”, respectively.

- changed (2026-01-30):
[0001137789-26-000026:note_history:5]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued ASU 2023-07 (ASC Topic 280), Improvements to Reportable Segment Disclosures. This ASU improves reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The Company adopted the disclosure requirement for its annual reporting in fiscal year 2025 and adopted the guidance for interim period reporting beginning the first quarter of fiscal year 2026 on a retrospective basis. Refer to “Note 7. Business Segment”.
  (was, 2025-10-31, similarity 0.9536):
[0001137789-25-000317:note_history:5]
In November 2023, the FASB issued ASU 2023-07 (ASC Topic 280), Improvements to Reportable Segment Disclosures. This ASU improves reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The Company adopted the disclosure requirement for its annual reporting in fiscal year 2025 and adopted the guidance for interim period reporting beginning the first quarter of fiscal year 2026 on a retrospective basis. Refer to “Note 7. Business Segment”.

- added (2026-01-30):
[0001137789-26-000026:note_history:6]
In November 2024, the FASB issued ASU 2024-04 (ASC Subtopic 470-20), Induced Conversions of Convertible Debt Instruments. This ASU clarifies the requirements for determining whether certain settlements of convertible debt instruments should be accounted for as an induced conversion. The guidance is effective for fiscal years beginning after December 15, 2025, with early adoption permitted. The Company adopted the guidance on a prospective basis in fiscal year 2026 and applied the amendments in the ASU to the exchange of the 2028 Notes. Refer to “Note 3. Debt”.

- removed (2026-01-30):
[0001137789-25-000317:note_history:7]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. In fiscal years with 53 weeks, the first quarter consists of 14 weeks and the remaining quarters consist of 13 weeks each. The three months ended October 3, 2025 consisted of 14 weeks and the three months ended September 27, 2024 consisted of 13 weeks, respectively. Fiscal years 2026 and 2025 comprise 53 and 52 weeks and end on July 3, 2026 and June 27, 2025, respectively. The fiscal quarters ended October 3, 2025, June 27, 2025 and September 27, 2024, are also referred to herein as the “September 2025 quarter”, the “June 2025 quarter” and the “September 2024 quarter”, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001137789-26-000026:note_history:8]
Debt
The following table provides details of the Company’s debt as of January 2, 2026 and June 27, 2025:
  (was, 2025-10-31, similarity 0.9368):
[0001137789-25-000317:note_history:8]
Debt
The following table provides details of the Company’s debt as of October 3, 2025 and June 27, 2025:

- changed (2026-01-30):
[0001137789-26-000026:note_history:9]
| (Dollars in millions) |  | January 2, 2026 |  | June 27, 2025 |
| Unsecured Senior Notes issued by Seagate HDD Cayman (1) |  |  |  |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “Old June 2029 Notes”) (3) |  | $ | 38 |  |  | $ | 452 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “Old July 2029 Notes”) (4) |  | 38 |  |  | 138 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “Old December 2029 Notes”) (5) |  | 8 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “Old January 2031 Notes”) (4) |  | 23 |  |  | 237 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “Old July 2031 Notes”) (4) |  | 16 |  |  | 61 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “Old 8.50% July 2031 Notes”) (4) |  | 29 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “Old 2032 Notes”) (3) |  | 19 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “Old 2034 Notes”) (3) |  | 162 |  |  | 489 |  |
| Unsecured Senior Notes issued by Seagate Data Storage Technology Pte. Ltd. (2) |  |  |  |  |
| $400 issued on May 27, 2025 at 5.875% due July 15, 2030 (the “2030 Notes”) (4) |  | 400 |  |  | 400 |  |
| $431 issued on June 30, 2025 at 4.091% due June 1, 2029 (the “New June 2029 Notes”) (3) |  | 417 |  |  | — |  |
| $100 issued on June 30, 2025 at 3.125% due July 15, 2029 (the “New July 2029 Notes”) (4) |  | 100 |  |  | — |  |
| $492 issued on June 30, 2025 at 8.25% due December 15, 2029 (the “New December 2029 Notes”) (5) |  | 492 |  |  | — |  |
| $213 issued on June 30, 2025 at 4.125% due January 15, 2031 (the “New January 2031 Notes”) (4) |  | 213 |  |  | — |  |
| $45 issued on June 30, 2025 at 3.375% due July 15, 2031 (the “New July 2031 Notes”) (4) |  | 45 |  |  | — |  |
| $471 issued on June 30, 2025 at 8.50% due July 15, 2031 (the “New 8.50% July 2031 Notes”) (4) |  | 471 |  |  | — |  |
| $731 issued on June 30, 2025 at 9.625% due December 1, 2032 (the “New 2032 Notes”) (3) |  | 731 |  |  | — |  |
| $328 issued on June 30, 2025 at 5.75% due December 1, 2034 (the “New 2034 Notes”) (3) |  | 327 |  |  | — |  |
| Exchangeable Senior Notes (1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”) (6) |  | 1,000 |  |  | 1,500 |  |
|  |  | 4,529 |  |  | 5,027 |  |
| Less: unamortized debt issuance costs |  | (30) |  |  | (32) |  |
| Debt, net of debt issuance costs |  | 4,499 |  |  | 4,995 |  |
| Less: current portion of long-term debt, net of debt issuance costs |  | (998) |  |  | — |  |
| Long-term debt, less current portion |  | $ | 3,501 |  |  | $ | 4,995 |  |
  (was, 2025-10-31, similarity 0.9927):
[0001137789-25-000317:note_history:9]
| (Dollars in millions) |  | October 3, 2025 |  | June 27, 2025 |
| Unsecured Senior Notes issued by Seagate HDD Cayman (1) |  |  |  |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “Old June 2029 Notes”) (3) |  | 38 |  |  | 452 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “Old July 2029 Notes”) (4) |  | 38 |  |  | 138 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “Old December 2029 Notes”) (5) |  | 8 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “Old January 2031 Notes”) (4) |  | 23 |  |  | 237 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “Old July 2031 Notes”) (4) |  | 16 |  |  | 61 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “Old 8.50% July 2031 Notes”) (4) |  | 29 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “Old 2032 Notes”) (3) |  | 19 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “Old 2034 Notes”) (3) |  | 162 |  |  | 489 |  |
| Unsecured Senior Notes issued by Seagate Data Storage Technology Pte. Ltd. (2) |  |  |  |  |
| $400 issued on May 27, 2025 at 5.875% due July 15, 2030 (the “2030 Notes”) (4) |  | 400 |  |  | 400 |  |
| $431 issued on June 30, 2025 at 4.091% due June 1, 2029 (the “New June 2029 Notes”) (3) |  | 415 |  |  | — |  |
| $100 issued on June 30, 2025 at 3.125% due July 15, 2029 (the “New July 2029 Notes”) (4) |  | 100 |  |  | — |  |
| $492 issued on June 30, 2025 at 8.25% due December 15, 2029 (the “New December 2029 Notes”) (5) |  | 492 |  |  | — |  |
| $213 issued on June 30, 2025 at 4.125% due January 15, 2031 (the “New January 2031 Notes”) (4) |  | 213 |  |  | — |  |
| $45 issued on June 30, 2025 at 3.375% due July 15, 2031 (the “New July 2031 Notes”) (4) |  | 45 |  |  | — |  |
| $471 issued on June 30, 2025 at 8.50% due July 15, 2031 (the “New 8.50% July 2031 Notes”) (4) |  | 471 |  |  | — |  |
| $731 issued on June 30, 2025 at 9.625% due December 1, 2032 (the “New 2032 Notes”) (3) |  | 731 |  |  | — |  |
| $328 issued on June 30, 2025 at 5.75% due December 1, 2034 (the “New 2034 Notes”) (3) |  | 327 |  |  | — |  |
| Exchangeable Senior Notes (1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”) (6) |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,027 |  |  | 5,027 |  |
| Less: unamortized debt issuance costs |  | (33) |  |  | (32) |  |
| Debt, net of debt issuance costs |  | 4,994 |  |  | 4,995 |  |
| Less: current portion of long-term debt, net of debt issuance costs |  | (1,496) |  |  | — |  |
| Long-term debt, less current portion |  | $ | 3,498 |  |  | $ | 4,995 |  |

- added (2026-01-30):
[0001137789-26-000026:note_history:10]
On November 12, 2025, the Company completed separate, privately-negotiated exchange agreements with certain holders of the 2028 Notes and exchanged $500 million total principal amount for consideration of $500 million cash and approximately 4.3 million shares of the Company’s common stock. The Company accounted for these exchange transactions as an induced conversion and recognized a non-cash induced conversion expense of $61 million within Net loss from debt transactions in the Company’s Condensed Consolidated Statement of Operations in the three and six months ended January 2, 2026. There was no corresponding change to the $1.5 billion notional value of the capped call transactions.

- added (2026-01-30):
[0001137789-26-000026:note_history:11]
As of January 2, 2026, the effective interest rate for the 3.50% Exchangeable Senior Notes due 2028 (the “2028 Notes”) was 3.94%, with contractual interest expense of $11 million and $25 million for the three and six months ended January 2, 2026, respectively, and immaterial amortization of debt issuance costs. As of December 27, 2024, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $13 million and $26 million for the three and six months ended December 27, 2024, respectively, and immaterial amortization of debt issuance costs.

- changed (2026-01-30):
[0001137789-26-000026:note_history:12]
Prior to March 1, 2028, the 2028 Notes are exchangeable at the option of the holders only under certain circumstances as set out in the indenture for the 2028 Notes. As of the calendar quarter ended December 31, 2025, the sale price conditional conversion option of the 2028 Notes was triggered. Accordingly, the 2028 Notes are exchangeable through March 31, 2026. The Company has classified the total balance of the 2028 Notes as the Current portion of long-term debt within Current liabilities in the Company’s Condensed Consolidated Balance Sheets as of January 2, 2026.
  (was, 2025-10-31, similarity 0.961):
[0001137789-25-000317:note_history:12]
Prior to March 1, 2028, the 2028 Notes are exchangeable at the option of the holders only under certain circumstances as set out in the indenture for the 2028 Notes. As of the calendar quarter ended September 30, 2025, the sale price conditional conversion option of the 2028 Notes was triggered. Accordingly, the 2028 Notes are exchangeable through December 31, 2025. The Company has classified the total balance of the 2028 Notes as the Current portion of long-term debt within Current liabilities in the Company’s Condensed Consolidated Balance Sheets as of October 3, 2025.

- changed (2026-01-30):
[0001137789-26-000026:note_history:13]
Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The exchange rate for the 2028 Notes as of January 2, 2026 is 12.1352 ordinary shares per $1,000 principal amount of 2028 Notes, which is equivalent to an exchange price of approximately $82.40 per share as of January 2, 2026. The exchange rate was adjusted from 12.1335 ordinary shares per $1,000 principal amount of 2028 Notes on December 24, 2025, and is subject to further adjustment pursuant to the terms of the Exchangeable Notes indenture.
  (was, 2025-10-31, similarity 0.7057):
[0001137789-25-000317:note_history:13]
Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The exchange rate for the 2028 Notes as of October 3, 2025 is 12.1335 ordinary shares per $1,000 principal amount of 2028 Notes, which is equivalent to an exchange price of approximately $82.42 per share as of October 3, 2025. The exchange rate was adjusted from 12.1324 ordinary shares per $1,000 principal amount of 2028 Notes on September 30, 2025, and is subject to further adjustment pursuant to the terms of the Exchangeable Notes indenture.

- changed (2026-01-30):
[0001137789-26-000026:note_history:14]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The current cap price of the capped call transactions, which was adjusted on December 24, 2025 in accordance with the applicable capped call confirmations, is $107.760 per share. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets.
  (was, 2025-10-31, similarity 0.9941):
[0001137789-25-000317:note_history:14]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The current cap price of the capped call transactions, which was adjusted on September 30, 2025 in accordance with the applicable capped call confirmations, is $107.775 per share. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Condensed Consolidated Balance Sheets.

- changed (2026-01-30):
[0001137789-26-000026:note_history:15]
On January 30, 2025, the Company and its subsidiary Seagate HDD Cayman (the “Borrower”), the Bank of Nova Scotia, as administrative agent, and the lenders thereto entered into a Credit Agreement (the “Credit Agreement”) which provides for a $1.3 billion senior unsecured revolving credit facility (“Revolving Credit Facility”), the term of which is through January 30, 2030. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing. An aggregate amount of up to $150 million of the facility shall also be available for the issuance of letters of credit, and an aggregate amount of up to $50 million of the facility shall also be available for swing line loans. On January 2, 2026, no borrowings were outstanding under the Credit Agreement.
  (was, 2025-10-31, similarity 0.9914):
[0001137789-25-000317:note_history:15]
On January 30, 2025, the Company and its subsidiary Seagate HDD Cayman (the “Borrower”), the Bank of Nova Scotia, as administrative agent, and the lenders thereto entered into a Credit Agreement (the “Credit Agreement”) which provides for a $1.3 billion senior unsecured revolving credit facility (“Revolving Credit Facility”), the term of which is through January 30, 2030. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing. An aggregate amount of up to $150 million of the facility shall also be available for the issuance of letters of credit, and an aggregate amount of up to $50 million of the facility shall also be available for swing line loans. On October 3, 2025, no borrowings were outstanding under the Credit Agreement.

- changed (2026-01-30):
[0001137789-26-000026:note_history:16]
At January 2, 2026, future principal payments on long-term debt were as follows (in millions):
  (was, 2025-10-31, similarity 0.9326):
[0001137789-25-000317:note_history:16]
At October 3, 2025, future principal payments on long-term debt were as follows (in millions):

- changed (2026-01-30):
[0001137789-26-000026:note_history:17]
| Fiscal Year |  | Amount |
| Remainder of 2026 |  | $ | — |  |
| 2027 |  | — |  |
| 2028 |  | 1,000 |  |
| 2029 |  | 470 |  |
| 2030 |  | 638 |  |
| Thereafter |  | 2,438 |  |
| Total |  | $ | 4,546 |  |
  (was, 2025-10-31, similarity 0.9872):
[0001137789-25-000317:note_history:17]
| Fiscal Year |  | Amount |
| Remainder of 2026 |  | — |  |
| 2027 |  | — |  |
| 2028 |  | 1,500 |  |
| 2029 |  | 470 |  |
| 2030 |  | 638 |  |
| Thereafter |  | 2,438 |  |
| Total |  | $ | 5,046 |  |

- removed (2026-01-30):
[0001137789-25-000317:note_history:18]
For the three months ended October 3, 2025, the effective interest rate for the 3.50% Exchangeable Senior Notes due 2028 (the “2028 Notes”) was 3.94%, with contractual interest expense of $14 million and immaterial amortization of debt issuance costs. For the three months ended September 27, 2024, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $13 million and immaterial amortization of debt issuance costs.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001137789-26-000026:note_history:19]
|  |  | January 2, 2026 |  | June 27, 2025 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| Exchangeable Senior Notes |  |  |  |  |  |  |  |  |
| 3.50% Exchangeable Senior Notes due June 2028 |  | $ | 1,000 |  |  | $ | 3,370 |  |  | $ | 1,500 |  |  | $ | 2,654 |  |
| Unsecured Senior Notes Issued by Seagate HDD Cayman |  |  |  |  |  |  |  |  |
| 4.091% Senior Notes due June 2029 |  | 38 |  |  | 38 |  |  | 452 |  |  | 453 |  |
| 3.125% Senior Notes due July 2029 |  | 38 |  |  | 35 |  |  | 138 |  |  | 125 |  |
| 8.25% Senior Notes due December 2029 |  | 8 |  |  | 9 |  |  | 500 |  |  | 535 |  |
| 4.125% Senior Notes due January 2031 |  | 23 |  |  | 21 |  |  | 237 |  |  | 218 |  |
| 3.375% Senior Notes due July 2031 |  | 16 |  |  | 14 |  |  | 61 |  |  | 52 |  |
| 8.50% Senior Notes due July 2031 |  | 29 |  |  | 31 |  |  | 500 |  |  | 538 |  |
| 9.625% Senior Notes due December 2032 |  | 19 |  |  | 22 |  |  | 750 |  |  | 854 |  |
| 5.75% Senior Notes due December 2034 |  | 162 |  |  | 166 |  |  | 489 |  |  | 482 |  |
| Unsecured Senior Notes issued by Seagate Data Storage Technology Pte. Ltd. |  |  |  |  |  |  |  |  |
| 4.091% Senior Notes due June 2029 |  | 417 |  |  | 422 |  |  | — |  |  | — |  |
| 3.125% Senior Notes due July 2029 |  | 100 |  |  | 88 |  |  | — |  |  | — |  |
| 8.25% Senior Notes due December 2029 |  | 492 |  |  | 522 |  |  | — |  |  | — |  |
| 5.875% Senior Notes due July 2030 |  | 400 |  |  | 413 |  |  | 400 |  |  | 407 |  |
| 4.125% Senior Notes due January 2031 |  | 213 |  |  | 203 |  |  | — |  |  | — |  |
| 3.375% Senior Notes due July 2031 |  | 45 |  |  | 39 |  |  | — |  |  | — |  |
| 8.50% Senior Notes due July 2031 |  | 471 |  |  | 500 |  |  | — |  |  | — |  |
| 9.625% Senior Notes due December 2032 |  | 731 |  |  | 830 |  |  | — |  |  | — |  |
| 5.75% Senior Notes due December 2034 |  | 327 |  |  | 335 |  |  | — |  |  | — |  |
|  |  | $ | 4,529 |  |  | $ | 7,058 |  |  | $ | 5,027 |  |  | $ | 6,318 |  |
| Less: unamortized debt issuance costs |  | (30) |  |  | — |  |  | (32) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 4,499 |  |  | $ | 7,058 |  |  | $ | 4,995 |  |  | $ | 6,318 |  |
| Less: current portion of debt, net of debt issuance costs |  | (998) |  |  | — |  |  | — |  |  | — |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 3,501 |  |  | $ | 7,058 |  |  | $ | 4,995 |  |  | $ | 6,318 |  |
  (was, 2025-10-31, similarity 0.8736):
[0001137789-25-000317:note_history:19]
|  |  | October 3, 2025 |  | June 27, 2025 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| Exchangeable Senior Notes |  |  |  |  |  |  |  |  |
| 3.50% Exchangeable Senior Notes due June 2028 |  | 1,500 |  |  | 4,739 |  |  | 1,500 |  |  | 2,654 |  |
| Unsecured Senior Notes Issued by Seagate HDD Cayman |  |  |  |  |  |  |  |  |
| 4.091% Senior Notes due June 2029 |  | 38 |  |  | 38 |  |  | 452 |  |  | 453 |  |
| 3.125% Senior Notes due July 2029 |  | 38 |  |  | 33 |  |  | 138 |  |  | 125 |  |
| 8.25% Senior Notes due December 2029 |  | 8 |  |  | 8 |  |  | 500 |  |  | 535 |  |
| 4.125% Senior Notes due January 2031 |  | 23 |  |  | 22 |  |  | 237 |  |  | 218 |  |
| 3.375% Senior Notes due July 2031 |  | 16 |  |  | 14 |  |  | 61 |  |  | 52 |  |
| 8.50% Senior Notes due July 2031 |  | 29 |  |  | 31 |  |  | 500 |  |  | 538 |  |
| 9.625% Senior Notes due December 2032 |  | 19 |  |  | 22 |  |  | 750 |  |  | 854 |  |
| 5.75% Senior Notes due December 2034 |  | 162 |  |  | 163 |  |  | 489 |  |  | 482 |  |
| Unsecured Senior Notes issued by Seagate Data Storage Technology Pte. Ltd. |  |  |  |  |  |  |  |  |
| 4.091% Senior Notes due June 2029 |  | 415 |  |  | 419 |  |  | — |  |  | — |  |
| 3.125% Senior Notes due July 2029 |  | 100 |  |  | 86 |  |  | — |  |  | — |  |
| 8.25% Senior Notes due December 2029 |  | 492 |  |  | 522 |  |  | — |  |  | — |  |
| 5.875% Senior Notes due July 2030 |  | 400 |  |  | 409 |  |  | 400 |  |  | 407 |  |
| 4.125% Senior Notes due January 2031 |  | 213 |  |  | 199 |  |  | — |  |  | — |  |
| 3.375% Senior Notes due July 2031 |  | 45 |  |  | 38 |  |  | — |  |  | — |  |
| 8.50% Senior Notes due July 2031 |  | 471 |  |  | 501 |  |  | — |  |  | — |  |
| 9.625% Senior Notes due December 2032 |  | 731 |  |  | 830 |  |  | — |  |  | — |  |
| 5.75% Senior Notes due December 2034 |  | 327 |  |  | 329 |  |  | — |  |  | — |  |
|  |  | $ | 5,027 |  |  | $ | 8,403 |  |  | $ | 5,027 |  |  | $ | 6,318 |  |
| Less: unamortized debt issuance costs |  | (33) |  |  | — |  |  | (32) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 4,994 |  |  | $ | 8,403 |  |  | $ | 4,995 |  |  | $ | 6,318 |  |
| Less: current portion of debt, net of debt issuance costs |  | (1,496) |  |  | — |  |  | — |  |  | — |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 3,498 |  |  | $ | 8,403 |  |  | $ | 4,995 |  |  | $ | 6,318 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001137789-26-000026:note_history:20]
The following table provides details of the Company’s debt as of January 2, 2026 and June 27, 2025:
  (was, 2025-10-31, similarity 0.9333):
[0001137789-25-000317:note_history:20]
The following table provides details of the Company’s debt as of October 3, 2025 and June 27, 2025:

- changed (2026-01-30):
[0001137789-26-000026:note_history:21]
| (Dollars in millions) |  | January 2, 2026 |  | June 27, 2025 |
| Unsecured Senior Notes issued by Seagate HDD Cayman (1) |  |  |  |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “Old June 2029 Notes”) (3) |  | $ | 38 |  |  | $ | 452 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “Old July 2029 Notes”) (4) |  | 38 |  |  | 138 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “Old December 2029 Notes”) (5) |  | 8 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “Old January 2031 Notes”) (4) |  | 23 |  |  | 237 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “Old July 2031 Notes”) (4) |  | 16 |  |  | 61 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “Old 8.50% July 2031 Notes”) (4) |  | 29 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “Old 2032 Notes”) (3) |  | 19 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “Old 2034 Notes”) (3) |  | 162 |  |  | 489 |  |
| Unsecured Senior Notes issued by Seagate Data Storage Technology Pte. Ltd. (2) |  |  |  |  |
| $400 issued on May 27, 2025 at 5.875% due July 15, 2030 (the “2030 Notes”) (4) |  | 400 |  |  | 400 |  |
| $431 issued on June 30, 2025 at 4.091% due June 1, 2029 (the “New June 2029 Notes”) (3) |  | 417 |  |  | — |  |
| $100 issued on June 30, 2025 at 3.125% due July 15, 2029 (the “New July 2029 Notes”) (4) |  | 100 |  |  | — |  |
| $492 issued on June 30, 2025 at 8.25% due December 15, 2029 (the “New December 2029 Notes”) (5) |  | 492 |  |  | — |  |
| $213 issued on June 30, 2025 at 4.125% due January 15, 2031 (the “New January 2031 Notes”) (4) |  | 213 |  |  | — |  |
| $45 issued on June 30, 2025 at 3.375% due July 15, 2031 (the “New July 2031 Notes”) (4) |  | 45 |  |  | — |  |
| $471 issued on June 30, 2025 at 8.50% due July 15, 2031 (the “New 8.50% July 2031 Notes”) (4) |  | 471 |  |  | — |  |
| $731 issued on June 30, 2025 at 9.625% due December 1, 2032 (the “New 2032 Notes”) (3) |  | 731 |  |  | — |  |
| $328 issued on June 30, 2025 at 5.75% due December 1, 2034 (the “New 2034 Notes”) (3) |  | 327 |  |  | — |  |
| Exchangeable Senior Notes (1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”) (6) |  | 1,000 |  |  | 1,500 |  |
|  |  | 4,529 |  |  | 5,027 |  |
| Less: unamortized debt issuance costs |  | (30) |  |  | (32) |  |
| Debt, net of debt issuance costs |  | 4,499 |  |  | 4,995 |  |
| Less: current portion of long-term debt, net of debt issuance costs |  | (998) |  |  | — |  |
| Long-term debt, less current portion |  | $ | 3,501 |  |  | $ | 4,995 |  |
  (was, 2025-10-31, similarity 0.9927):
[0001137789-25-000317:note_history:21]
| (Dollars in millions) |  | October 3, 2025 |  | June 27, 2025 |
| Unsecured Senior Notes issued by Seagate HDD Cayman (1) |  |  |  |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “Old June 2029 Notes”) (3) |  | 38 |  |  | 452 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “Old July 2029 Notes”) (4) |  | 38 |  |  | 138 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “Old December 2029 Notes”) (5) |  | 8 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “Old January 2031 Notes”) (4) |  | 23 |  |  | 237 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “Old July 2031 Notes”) (4) |  | 16 |  |  | 61 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “Old 8.50% July 2031 Notes”) (4) |  | 29 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “Old 2032 Notes”) (3) |  | 19 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “Old 2034 Notes”) (3) |  | 162 |  |  | 489 |  |
| Unsecured Senior Notes issued by Seagate Data Storage Technology Pte. Ltd. (2) |  |  |  |  |
| $400 issued on May 27, 2025 at 5.875% due July 15, 2030 (the “2030 Notes”) (4) |  | 400 |  |  | 400 |  |
| $431 issued on June 30, 2025 at 4.091% due June 1, 2029 (the “New June 2029 Notes”) (3) |  | 415 |  |  | — |  |
| $100 issued on June 30, 2025 at 3.125% due July 15, 2029 (the “New July 2029 Notes”) (4) |  | 100 |  |  | — |  |
| $492 issued on June 30, 2025 at 8.25% due December 15, 2029 (the “New December 2029 Notes”) (5) |  | 492 |  |  | — |  |
| $213 issued on June 30, 2025 at 4.125% due January 15, 2031 (the “New January 2031 Notes”) (4) |  | 213 |  |  | — |  |
| $45 issued on June 30, 2025 at 3.375% due July 15, 2031 (the “New July 2031 Notes”) (4) |  | 45 |  |  | — |  |
| $471 issued on June 30, 2025 at 8.50% due July 15, 2031 (the “New 8.50% July 2031 Notes”) (4) |  | 471 |  |  | — |  |
| $731 issued on June 30, 2025 at 9.625% due December 1, 2032 (the “New 2032 Notes”) (3) |  | 731 |  |  | — |  |
| $328 issued on June 30, 2025 at 5.75% due December 1, 2034 (the “New 2034 Notes”) (3) |  | 327 |  |  | — |  |
| Exchangeable Senior Notes (1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”) (6) |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,027 |  |  | 5,027 |  |
| Less: unamortized debt issuance costs |  | (33) |  |  | (32) |  |
| Debt, net of debt issuance costs |  | 4,994 |  |  | 4,995 |  |
| Less: current portion of long-term debt, net of debt issuance costs |  | (1,496) |  |  | — |  |
| Long-term debt, less current portion |  | $ | 3,498 |  |  | $ | 4,995 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001137789-26-000026:note_history:22]
At January 2, 2026, future principal payments on long-term debt were as follows (in millions):
  (was, 2025-10-31, similarity 0.9326):
[0001137789-25-000317:note_history:22]
At October 3, 2025, future principal payments on long-term debt were as follows (in millions):

- changed (2026-01-30):
[0001137789-26-000026:note_history:23]
| Fiscal Year |  | Amount |
| Remainder of 2026 |  | $ | — |  |
| 2027 |  | — |  |
| 2028 |  | 1,000 |  |
| 2029 |  | 470 |  |
| 2030 |  | 638 |  |
| Thereafter |  | 2,438 |  |
| Total |  | $ | 4,546 |  |
  (was, 2025-10-31, similarity 0.9872):
[0001137789-25-000317:note_history:23]
| Fiscal Year |  | Amount |
| Remainder of 2026 |  | — |  |
| 2027 |  | — |  |
| 2028 |  | 1,500 |  |
| 2029 |  | 470 |  |
| 2030 |  | 638 |  |
| Thereafter |  | 2,438 |  |
| Total |  | $ | 5,046 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001137789-26-000026:note_history:24]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | January 2, 2026 |  | December 27, 2024 |  | January 2, 2026 |  | December 27, 2024 |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,302 |  |  | $ | 1,841 |  |  | $ | 4,482 |  |  | $ | 3,590 |  |  |  |
| Distributors |  | 335 |  |  | 278 |  |  | 614 |  |  | 527 |  |  |  |
| Retailers |  | 188 |  |  | 206 |  |  | 358 |  |  | 376 |  |  |  |
| Total |  | $ | 2,825 |  |  | $ | 2,325 |  |  | $ | 5,454 |  |  | $ | 4,493 |  |  |  |
  (was, 2025-10-31, similarity 0.7854):
[0001137789-25-000317:note_history:24]
|  |  | For the Three Months Ended |  |  |  |  |
| (Dollars in millions) |  | October 3, 2025 |  | September 27, 2024 |  |  |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,180 |  |  | $ | 1,749 |  |  |  |  |  |  |  |
| Distributors |  | 279 |  |  | 248 |  |  |  |  |  |  |  |
| Retailers |  | 170 |  |  | 171 |  |  |  |  |  |  |  |
| Total |  | $ | 2,629 |  |  | $ | 2,168 |  |  |  |  |  |  |  |

- added (2026-01-30):
[0001137789-26-000026:note_history:25]
| Revenue by Country (1): |  |  |  |  |  |  |  |  |  |  |
| Singapore |  | $ | 1,305 |  |  | $ | 1,034 |  |  | $ | 2,342 |  |  | $ | 1,894 |  |  |  |
| United States |  | 1,228 |  |  | 1,059 |  |  | 2,608 |  |  | 2,156 |  |  |  |
| The Netherlands |  | 291 |  |  | 231 |  |  | 502 |  |  | 441 |  |  |  |
| Other |  | 1 |  |  | 1 |  |  | 2 |  |  | 2 |  |  |  |
| Total |  | $ | 2,825 |  |  | $ | 2,325 |  |  | $ | 5,454 |  |  | $ | 4,493 |  |  |  |

- removed (2026-01-30):
[0001137789-25-000317:note_history:26]
| Revenue by Country (1): |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 1,380 |  |  | $ | 1,097 |  |  |  |  |  |  |  |
| Singapore |  | 1,037 |  |  | 860 |  |  |  |  |  |  |  |
| The Netherlands |  | 211 |  |  | 210 |  |  |  |  |  |  |  |
| Other |  | 1 |  |  | 1 |  |  |  |  |  |  |  |
| Total |  | $ | 2,629 |  |  | $ | 2,168 |  |  |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-01-30):
[0001137789-26-000026:note_history:27]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |  |
| (Dollars in millions) |  | January 2, 2026 |  | December 27, 2024 |  | January 2, 2026 |  | December 27, 2024 |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,302 |  |  | $ | 1,841 |  |  | $ | 4,482 |  |  | $ | 3,590 |  |  |  |
| Distributors |  | 335 |  |  | 278 |  |  | 614 |  |  | 527 |  |  |  |
| Retailers |  | 188 |  |  | 206 |  |  | 358 |  |  | 376 |  |  |  |
| Total |  | $ | 2,825 |  |  | $ | 2,325 |  |  | $ | 5,454 |  |  | $ | 4,493 |  |  |  |
  (was, 2025-10-31, similarity 0.7854):
[0001137789-25-000317:note_history:27]
|  |  | For the Three Months Ended |  |  |  |  |
| (Dollars in millions) |  | October 3, 2025 |  | September 27, 2024 |  |  |  |  |  |  |
| Revenues by Channel |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | $ | 2,180 |  |  | $ | 1,749 |  |  |  |  |  |  |  |
| Distributors |  | 279 |  |  | 248 |  |  |  |  |  |  |  |
| Retailers |  | 170 |  |  | 171 |  |  |  |  |  |  |  |
| Total |  | $ | 2,629 |  |  | $ | 2,168 |  |  |  |  |  |  |  |

- added (2026-01-30):
[0001137789-26-000026:note_history:28]
| Revenue by Country (1): |  |  |  |  |  |  |  |  |  |  |
| Singapore |  | $ | 1,305 |  |  | $ | 1,034 |  |  | $ | 2,342 |  |  | $ | 1,894 |  |  |  |
| United States |  | 1,228 |  |  | 1,059 |  |  | 2,608 |  |  | 2,156 |  |  |  |
| The Netherlands |  | 291 |  |  | 231 |  |  | 502 |  |  | 441 |  |  |  |
| Other |  | 1 |  |  | 1 |  |  | 2 |  |  | 2 |  |  |  |
| Total |  | $ | 2,825 |  |  | $ | 2,325 |  |  | $ | 5,454 |  |  | $ | 4,493 |  |  |  |

- removed (2026-01-30):
[0001137789-25-000317:note_history:29]
| Revenue by Country (1): |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 1,380 |  |  | $ | 1,097 |  |  |  |  |  |  |  |
| Singapore |  | 1,037 |  |  | 860 |  |  |  |  |  |  |  |
| The Netherlands |  | 211 |  |  | 210 |  |  |  |  |  |  |  |
| Other |  | 1 |  |  | 1 |  |  |  |  |  |  |  |
| Total |  | $ | 2,629 |  |  | $ | 2,168 |  |  |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2026-01-30):
[0001137789-26-000026:note_history:30]
On January 27, 2026, the Board of Directors of the Company declared a quarterly cash dividend of $0.74 per share, which will be payable on April 8, 2026 to shareholders of record as of the close of business on March 25, 2026.

- removed (2026-01-30):
[0001137789-25-000317:note_history:31]
On October 28, 2025, the Board of Directors of the Company declared a quarterly cash dividend of $0.74 per share, which will be payable on January 9, 2026 to shareholders of record as of the close of business on December 24, 2025.
