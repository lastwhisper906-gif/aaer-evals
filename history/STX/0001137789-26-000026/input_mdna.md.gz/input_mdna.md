# STX MD&A — 0001137789-26-000026


## mdna

[0001137789-26-000026:mdna:1]
[same as prior period, unchanged from 0001137789-25-000317:mdna:1]

[0001137789-26-000026:mdna:2]
The following is a discussion of the Company’s financial condition, changes in financial condition and results of operations for the fiscal quarters ended January 2, 2026, October 3, 2025 and December 27, 2024, referred to herein as the “December 2025 quarter”, the “September 2025 quarter” and the “December 2024 quarter”, respectively. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The December 2025 quarter and December 2024 quarter were each 13 weeks, while the September 2025 quarter was 14 weeks.

[0001137789-26-000026:mdna:3]
[same as prior period, unchanged from 0001137789-25-000317:mdna:3]

[0001137789-26-000026:mdna:4]
[same as prior period, unchanged from 0001137789-25-000317:mdna:4]

[0001137789-26-000026:mdna:5]
•Overview of the December 2025 quarter. Highlights of events in the December 2025 quarter that impacted our financial position.

[0001137789-26-000026:mdna:6]
•Results of Operations. Analysis of our financial results comparing the December 2025 quarter to the September 2025 quarter and the December 2024 quarter.

[0001137789-26-000026:mdna:7]
[same as prior period, unchanged from 0001137789-25-000317:mdna:7]

[0001137789-26-000026:mdna:8]
[same as prior period, unchanged from 0001137789-25-000317:mdna:8]

[0001137789-26-000026:mdna:9]
[same as prior period, unchanged from 0001137789-25-000317:mdna:9]

[0001137789-26-000026:mdna:10]
25

[0001137789-26-000026:mdna:11]
Overview of the December 2025 quarter

[0001137789-26-000026:mdna:12]
During the December 2025 quarter, we shipped 190 exabytes of HDD storage capacity. We generated revenue of approximately $2.8 billion with a gross margin of 41.6% and net income of $593 million. Our operating cash flow was $723 million, we retired $500 million principal amount of long-term debt and paid $154 million in dividends.

[0001137789-26-000026:mdna:13]
[same as prior period, unchanged from 0001137789-25-000317:mdna:13]

[0001137789-26-000026:mdna:14]
[same as prior period, unchanged from 0001137789-25-000317:mdna:14]

[0001137789-26-000026:mdna:15]
[same as prior period, unchanged from 0001137789-25-000317:mdna:15]

[0001137789-26-000026:mdna:16]
In the December 2025 quarter, we continued to operate in a strong demand environment, particularly within the data center end markets. We experienced sustained demand growth for our high capacity nearline drives across global cloud customers, as well as continued improvement from the enterprise edge deployments. Customers continue to invest in data center infrastructure to support ongoing demand from traditional workloads along with growing AI related demand. This trend reflects the ongoing adoption of AI applications which drives increased data content generation and storage needs for inferencing, training and maintaining AI model integrity. At the same time, the macroeconomic environment remains dynamic, marked by uncertainties in trade policies and increasing geopolitical tensions. These factors may impact our business and results of operations. We will continue to monitor the situation and assess plans to mitigate future risk to the business. Over the long-term we expect our hard drive storage business to benefit from growing demand for data and its increased value, particularly as AI applications continue to proliferate.

[0001137789-26-000026:mdna:17]
[same as prior period, unchanged from 0001137789-25-000317:mdna:17]

[0001137789-26-000026:mdna:18]
[same as prior period, unchanged from 0001137789-25-000317:mdna:18]

[0001137789-26-000026:mdna:19]
[same as prior period, unchanged from 0001137789-25-000317:mdna:19]

[0001137789-26-000026:mdna:20]
|  |  | For the Three Months Ended | For the Six Months Ended |
| (Dollars in millions) |  | January 2, 2026 |  | October 3, 2025 |  | December 27, 2024 |  | January 2, 2026 |  | December 27, 2024 |
| Revenue |  | $ | 2,825 |  |  | $ | 2,629 |  |  | $ | 2,325 |  |  | $ | 5,454 |  |  | $ | 4,493 |  |
| Cost of revenue |  | 1,649 |  |  | 1,592 |  |  | 1,513 |  |  | 3,241 |  |  | 2,967 |  |
| Gross profit |  | 1,176 |  |  | 1,037 |  |  | 812 |  |  | 2,213 |  |  | 1,526 |  |
| Product development |  | 187 |  |  | 186 |  |  | 184 |  |  | 373 |  |  | 365 |  |
| Marketing and administrative |  | 143 |  |  | 144 |  |  | 139 |  |  | 287 |  |  | 268 |  |
| Restructuring and other, net |  | 3 |  |  | 13 |  |  | 1 |  |  | 16 |  |  | 2 |  |
| Income from operations |  | 843 |  |  | 694 |  |  | 488 |  |  | 1,537 |  |  | 891 |  |
| Other expense, net |  | (136) |  |  | (80) |  |  | (138) |  |  | (216) |  |  | (225) |  |
| Income before income taxes |  | 707 |  |  | 614 |  |  | 350 |  |  | 1,321 |  |  | 666 |  |
| Provision for income taxes |  | 114 |  |  | 65 |  |  | 14 |  |  | 179 |  |  | 25 |  |
| Net income |  | $ | 593 |  |  | $ | 549 |  |  | $ | 336 |  |  | $ | 1,142 |  |  | $ | 641 |  |

[0001137789-26-000026:mdna:21]
26

[0001137789-26-000026:mdna:22]
|  |  | For the Three Months Ended | For the Six Months Ended |
| (As a percentage of Revenue) |  | January 2, 2026 |  | October 3, 2025 |  | December 27, 2024 |  | January 2, 2026 |  | December 27, 2024 |
| Revenue |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 58 |  |  | 61 |  |  | 65 |  |  | 59 |  |  | 66 |  |
| Gross margin |  | 42 |  |  | 39 |  |  | 35 |  |  | 41 |  |  | 34 |  |
| Product development |  | 7 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 8 |  |
| Marketing and administrative |  | 5 |  |  | 5 |  |  | 6 |  |  | 5 |  |  | 6 |  |
| Restructuring and other, net |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Operating margin |  | 30 |  |  | 27 |  |  | 21 |  |  | 29 |  |  | 20 |  |
| Other expense, net |  | (5) |  |  | (3) |  |  | (6) |  |  | (4) |  |  | (5) |  |
| Income before income taxes |  | 25 |  |  | 24 |  |  | 15 |  |  | 25 |  |  | 15 |  |
| Provision for income taxes |  | 4 |  |  | 2 |  |  | 1 |  |  | 3 |  |  | 1 |  |
| Net income |  | 21 | % |  | 22 | % |  | 14 | % |  | 22 | % |  | 14 | % |

[0001137789-26-000026:mdna:23]
[same as prior period, unchanged from 0001137789-25-000317:mdna:23]

[0001137789-26-000026:mdna:24]
The following table summarizes information regarding consolidated revenues by channel, geography, and market and HDD exabytes shipped:

[0001137789-26-000026:mdna:25]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
|  |  | January 2, 2026 |  | October 3, 2025 |  | December 27, 2024 |  | January 2, 2026 |  | December 27, 2024 |
| Revenues by Channel (%) |  |  |  |  |  |  |  |  |  |  |
| OEMs |  | 81 | % |  | 83 | % |  | 79 | % |  | 82 | % |  | 80 | % |
| Distributors |  | 12 | % |  | 11 | % |  | 12 | % |  | 11 | % |  | 12 | % |
| Retailers |  | 7 | % |  | 6 | % |  | 9 | % |  | 7 | % |  | 8 | % |
| Revenues by Geography (%) (1) |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 46 | % |  | 39 | % |  | 45 | % |  | 43 | % |  | 42 | % |
| Americas |  | 44 | % |  | 53 | % |  | 45 | % |  | 48 | % |  | 48 | % |
| EMEA |  | 10 | % |  | 8 | % |  | 10 | % |  | 9 | % |  | 10 | % |
| Revenues by Market (%) |  |  |  |  |  |  |  |  |  |  |
| Data Center |  | 79 | % |  | 80 | % |  | 75 | % |  | 80 | % |  | 74 | % |
| Edge IoT |  | 21 | % |  | 20 | % |  | 25 | % |  | 20 | % |  | 26 | % |
| HDD Exabytes Shipped |  |  |  |  |  |  |  |  |  |  |
| Nearline |  | 165.0 |  |  | 159.3 |  |  | 125.8 |  |  | 324.3 |  |  | 240.2 |  |
| Non-nearline |  | 25.0 |  |  | 22.2 |  |  | 25.0 |  |  | 47.2 |  |  | 48.1 |  |
| Total |  | 190.0 |  |  | 181.5 |  |  | 150.8 |  |  | 371.5 |  |  | 288.3 |  |

[0001137789-26-000026:mdna:26]
[same as prior period, unchanged from 0001137789-25-000317:mdna:26]

[0001137789-26-000026:mdna:27]
[same as prior period, unchanged from 0001137789-25-000317:mdna:27]

[0001137789-26-000026:mdna:28]
Revenue in the December 2025 quarter increased by $196 million compared to the September 2025 quarter, primarily due to favorable pricing actions undertaken by the Company and an increase in exabytes shipped reflecting higher demand for both nearline and non-nearline products.

[0001137789-26-000026:mdna:29]
Revenue for the three and six months ended January 2, 2026, increased by $500 million and $961 million from the three and six months ended December 27, 2024, respectively, primarily due to an increase in nearline exabytes shipped reflecting higher demand for nearline cloud products and favorable pricing actions undertaken by the Company.

[0001137789-26-000026:mdna:30]
We maintain various sales incentive programs such as channel and OEM rebates. Sales incentive programs were approximately 11% of gross revenue for the December 2025 quarter, 12% for the September 2025 quarter and 14% for the December 2024 quarter. Adjustments to revenues due to under or over accruals for sales incentive programs related to revenues reported in prior quarterly periods were less than 1% of quarterly gross revenue in all periods presented.

[0001137789-26-000026:mdna:31]
[same as prior period, unchanged from 0001137789-25-000317:mdna:82]

[0001137789-26-000026:mdna:32]
[same as prior period, unchanged from 0001137789-25-000317:mdna:32]

[0001137789-26-000026:mdna:33]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |  |  |
| (Dollars in millions) |  | January 2, 2026 |  | October 3, 2025 |  | December 27, 2024 |  | January 2, 2026 |  | December 27, 2024 |  |  |  |
| Cost of revenue |  | $ | 1,649 |  |  | $ | 1,592 |  |  | $ | 1,513 |  |  | $ | 3,241 |  |  | $ | 2,967 |  |  |  |  |
| Gross profit |  | 1,176 |  |  | 1,037 |  |  | 812 |  |  | 2,213 |  |  | 1,526 |  |  |  |  |
| Gross margin |  | 42 | % |  | 39 | % |  | 35 | % |  | 41 | % |  | 34 | % |  |  |  |

[0001137789-26-000026:mdna:34]
Gross margin for the December 2025 quarter increased by 3 percentage points compared to the September 2025 quarter primarily driven by pricing actions undertaken by the Company and favorable product mix.

[0001137789-26-000026:mdna:35]
Gross margin for the December 2025 quarter increased by 7 percentage points compared to the December 2024 quarter primarily driven by pricing actions undertaken by the Company and favorable volume and product mix.

[0001137789-26-000026:mdna:36]
Gross margin for the six months ended January 2, 2026 increased by 7 percentage points compared to the six months ended December 27, 2024 primarily driven by pricing actions undertaken by the Company and favorable volume and product mix.

[0001137789-26-000026:mdna:37]
Warranty cost related to new shipments was 0.9%, 0.8% and 0.7% of revenue for the December 2025 quarter, September 2025 quarter and December 2024 quarter, respectively.

[0001137789-26-000026:mdna:38]
[same as prior period, unchanged from 0001137789-25-000317:mdna:36]

[0001137789-26-000026:mdna:39]
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |  |  |  |
| (Dollars in millions) |  | January 2, 2026 |  | October 3, 2025 |  | December 27, 2024 |  | January 2, 2026 |  | December 27, 2024 |  |  |  |  |
| Product development |  | $ | 187 |  |  | $ | 186 |  |  | $ | 184 |  |  | $ | 373 |  |  | $ | 365 |  |  |  |  |  |
| Marketing and administrative |  | 143 |  |  | 144 |  | 139 |  |  | 287 |  |  | 268 |  |  |  |  |  |
| Restructuring and other, net |  | 3 |  |  | 13 |  |  | 1 |  |  | 16 |  |  | 2 |  |  |  |  |  |
| Operating expenses |  | $ | 333 |  |  | $ | 343 |  |  | $ | 324 |  |  | $ | 676 |  |  | $ | 635 |  |  |  |  |  |

[0001137789-26-000026:mdna:40]
Product Development Expense. Product development expenses remained relatively flat in the December 2025 quarter compared to the September 2025 quarter and the December 2024 quarter, respectively.

[0001137789-26-000026:mdna:41]
Product development expenses increased by $8 million in the six months ended January 2, 2026 compared to the six months ended December 27, 2024, primarily due to a $10 million increase in outside services costs, partially offset by a $3 million decrease in compensation and other employee benefits.

[0001137789-26-000026:mdna:42]
Marketing and Administrative Expense. Marketing and administrative expenses remained relatively flat in the December 2025 quarter compared to the September 2025 quarter and the December 2024 quarter, respectively.

[0001137789-26-000026:mdna:43]
Marketing and administrative expenses increased by $19 million in the six months ended January 2, 2026 compared to the six months ended December 27, 2024, primarily due to a $10 million increase in compensation and other employee benefits, a $4 million increase in facilities costs, a $3 million increase in information technology expenses and a $3 million increase in outside services costs.

[0001137789-26-000026:mdna:44]
Restructuring and other, net. We recorded $3 million of restructuring charges in the December 2025 quarter, primarily related to employee related termination benefits.

[0001137789-26-000026:mdna:45]
[same as prior period, unchanged from 0001137789-25-000317:mdna:43]

[0001137789-26-000026:mdna:46]
|  |  | For the Three Months Ended |  | For the Six Months Ended |
| (Dollars in millions) |  | January 2, 2026 |  | October 3, 2025 |  | December 27, 2024 |  | January 2, 2026 |  | December 27, 2024 |
| Other expense, net |  | $ | (136) |  |  | $ | (80) |  |  | $ | (138) |  |  | $ | (216) |  |  | $ | (225) |  |

[0001137789-26-000026:mdna:47]
Other expense, net. Other expense, net for the December 2025 quarter primarily related to $72 million of interest expense and $66 million net loss from debt transactions, partially offset by $7 million of interest income.

[0001137789-26-000026:mdna:48]
Other expense, net for the September 2025 quarter primarily related to $80 million of interest expense and $6 million net loss from debt transactions, partially offset by $7 million of interest income.

[0001137789-26-000026:mdna:49]
Other expense, net for the December 2024 quarter primarily related to $84 million of interest expense and $52 million net loss from certain investments, partially offset by $8 million of interest income.

[0001137789-26-000026:mdna:50]
Other expense, net for the six months ended January 2, 2026 primarily related to $152 million of interest expense and $72 million net loss from debt transactions, partially offset by $14 million of interest income.

[0001137789-26-000026:mdna:51]
Other expense, net for the six months ended December 27, 2024 primarily related to $169 million of interest expense and $53 million net loss from certain investments, partially offset by $15 million of interest income.

[0001137789-26-000026:mdna:52]
[same as prior period, unchanged from 0001137789-25-000317:mdna:48]

[0001137789-26-000026:mdna:53]
For the December 2025 quarter, September 2025 quarter and December 2024 quarter, we recorded income tax expense of $114 million, $65 million and $14 million, respectively. For the six months ended January 2, 2026 and December 27, 2024, we recorded income tax expense of $179 million and $25 million, respectively. For further discussion, refer to “Part I, Item 1. Financial Statements—Note 4. Income Taxes”.

[0001137789-26-000026:mdna:54]
[same as prior period, unchanged from 0001137789-25-000317:mdna:50]

[0001137789-26-000026:mdna:55]
[same as prior period, unchanged from 0001137789-25-000317:mdna:51]

[0001137789-26-000026:mdna:56]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of January 2, 2026. For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, see “Part II, Item 1A. Risk Factors” of this Quarterly Report on Form 10-Q.

[0001137789-26-000026:mdna:57]
[same as prior period, unchanged from 0001137789-25-000317:mdna:53]

[0001137789-26-000026:mdna:58]
|  |  | As of |  |  |
| (Dollars in millions) |  | January 2, 2026 |  | June 27, 2025 |  | Change |
| Cash and cash equivalents |  | $ | 1,046 |  |  | $ | 891 |  |  | $ | 155 |  |

[0001137789-26-000026:mdna:59]
Our cash and cash equivalents as of January 2, 2026 increased by $155 million from June 27, 2025 primarily as a result of net cash of $1.3 billion provided by operating activities, partially offset by $500 million cash paid for the partial retirement of 2028 Notes, $307 million dividends paid to our shareholders, $221 million payments for capital expenditures and $70 million taxes paid related to net share settlement of equity awards.

[0001137789-26-000026:mdna:60]
[same as prior period, unchanged from 0001137789-25-000317:mdna:56]

[0001137789-26-000026:mdna:61]
Cash provided by operating activities for the six months ended January 2, 2026 was $1.3 billion and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, and the following major working capital related movements:

[0001137789-26-000026:mdna:62]
•an increase of $197 million in accrued expenses, income taxes and warranty, primarily due to an increase in accrued income taxes and timing of interest payments on our long-term debt; and

[0001137789-26-000026:mdna:63]
•an increase of $162 million in accounts payable, primarily due to an increase in direct materials purchased; partially offset by

[0001137789-26-000026:mdna:64]
•a decrease of $108 million in accrued employee compensation, primarily due to variable compensation payments;

[0001137789-26-000026:mdna:65]
•an increase of $287 million in accounts receivable, primarily due to increased revenue; and

[0001137789-26-000026:mdna:66]
•an increase of $58 million in inventories, primarily related to an increase in work-in-process inventory.

[0001137789-26-000026:mdna:67]
29

[0001137789-26-000026:mdna:68]
[same as prior period, unchanged from 0001137789-25-000317:mdna:63]

[0001137789-26-000026:mdna:69]
Net cash used in investing activities for the six months ended January 2, 2026 was $206 million, primarily attributable to payments of $221 million for the purchase of property, equipment and leasehold improvements, partially offset by proceeds of $15 million from our business divestiture from the sale of System-on-Chip Operations during fiscal year 2024.

[0001137789-26-000026:mdna:70]
[same as prior period, unchanged from 0001137789-25-000317:mdna:65]

[0001137789-26-000026:mdna:71]
Net cash used in financing activities of $894 million for the six months ended January 2, 2026 was primarily attributable to the following activities:

[0001137789-26-000026:mdna:72]
•$500 million cash paid for the partial retirement of 2028 Notes;

[0001137789-26-000026:mdna:73]
•$307 million in dividends paid to our shareholders;

[0001137789-26-000026:mdna:74]
•$70 million taxes paid related to net share settlement of equity awards;

[0001137789-26-000026:mdna:75]
[same as prior period, unchanged from 0001137789-25-000317:mdna:69]

[0001137789-26-000026:mdna:76]
•$15 million debt fees relating to the Obligor Exchange and retirement of long-term debt; partially offset by

[0001137789-26-000026:mdna:77]
•$27 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-26-000026:mdna:78]
[same as prior period, unchanged from 0001137789-25-000317:mdna:72]

[0001137789-26-000026:mdna:79]
Our primary sources of liquidity as of January 2, 2026, consist of: (1) approximately $1.0 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.3 billion available for borrowing under our senior unsecured revolving credit facility (“Revolving Credit Facility”), which is part of our Credit Agreement (as defined within “Part I, Item 1. Financial Statements—Note 3. Debt”).

[0001137789-26-000026:mdna:80]
As of January 2, 2026, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with a financial covenant and other customary conditions to borrowing.

[0001137789-26-000026:mdna:81]
As of January 2, 2026, the Credit Agreement includes one financial covenant, net leverage ratio of less than or equal to 6.75 to 1.00, commencing with the fiscal quarter ended June 27, 2025 and declining over time so that the maximum permitted net leverage ratio for each fiscal quarter ending after July 2, 2027 is 4.25 to 1.00. As of January 2, 2026, we were in compliance with all of the covenants under our debt agreements. Refer to “Part I, Item 1. Financial Statements—Note 3. Debt” for more details. We continue to evaluate our debt portfolio and structure to comply with our financial debt covenant.

[0001137789-26-000026:mdna:82]
[same as prior period, unchanged from 0001137789-25-000317:mdna:76]

[0001137789-26-000026:mdna:83]
[same as prior period, unchanged from 0001137789-25-000317:mdna:77]

[0001137789-26-000026:mdna:84]
[same as prior period, unchanged from 0001137789-25-000317:mdna:78]

[0001137789-26-000026:mdna:85]
[same as prior period, unchanged from 0001137789-25-000317:mdna:79]

[0001137789-26-000026:mdna:86]
[same as prior period, unchanged from 0001137789-25-000317:mdna:80]

[0001137789-26-000026:mdna:87]
Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. From time to time, we enter into long-term, non-cancelable purchase commitments or make large up-front investments with certain suppliers in order to secure certain components or technologies for the production of our products or to supplement our internal manufacturing capacity for certain components. As of January 2, 2026, we had unconditional purchase obligations of approximately $1.4 billion, primarily related to purchases of inventory components with our suppliers. We expect $1.3 billion of these commitments to be paid within one year. In addition, we also had certain long-term, market share-based, non-cancellable inventory purchase commitments as of January 2, 2026.

[0001137789-26-000026:mdna:88]
30

[0001137789-26-000026:mdna:89]
Capital expenditures

[0001137789-26-000026:mdna:90]
We incur material capital expenditures to design and manufacture our products that depend on advanced technologies and manufacturing techniques. As of January 2, 2026, we had unconditional commitments of $309 million primarily related to purchases of equipment, of which approximately $296 million is expected to be paid within one year. During fiscal year 2026, supporting volume ramp of hard drives utilizing heat-assisted magnetic recording (“HAMR”) technology, we expect capital expenditures to be higher than fiscal year 2025 and still within our target range of 4-6% of revenue.

[0001137789-26-000026:mdna:91]
[same as prior period, unchanged from 0001137789-25-000317:mdna:83]

[0001137789-26-000026:mdna:92]
As of January 2, 2026, the future principal payment obligation on our long-term debt was $4.5 billion, which will mature in more than one year. As of January 2, 2026, future interest payments on this outstanding debt are estimated to be approximately $1.5 billion, of which $281 million is expected to be paid within one year. As of the calendar quarter ended December 31, 2025, the conditional conversion option of the 2028 Notes was triggered in accordance with the terms of the 2028 Notes indenture. Accordingly, the 2028 Notes are exchangeable through March 31, 2026. As a result, we have classified the 2028 Notes within Current liabilities in our Condensed Consolidated Balance Sheets as of January 2, 2026. From time to time, we may refinance, repurchase, redeem or otherwise extinguish any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase or redeem outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 1. Financial Statements—Note 3. Debt” for more details.

[0001137789-26-000026:mdna:93]
[same as prior period, unchanged from 0001137789-25-000317:mdna:85]

[0001137789-26-000026:mdna:94]
We accrued a settlement penalty of $300 million for fiscal year 2023, related to BIS’ allegations of violations of the U.S. EAR, which were subsequently resolved by the Settlement Agreement in April 2023. As part of the Settlement Agreement with BIS, quarterly payments of $15 million are made over the course of five years beginning October 31, 2023, of which $60 million is expected to be paid within one year and $105 million thereafter. Refer to “Item 1. Financial Statements—Note 11. Legal, Environmental and Other Contingencies” for more details.

[0001137789-26-000026:mdna:95]
[same as prior period, unchanged from 0001137789-25-000317:mdna:87]

[0001137789-26-000026:mdna:96]
On January 27, 2026, our Board of Directors declared a quarterly cash dividend of $0.74 per share, which will be payable on April 8, 2026 to shareholders of record as of the close of business on March 25, 2026. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-26-000026:mdna:97]
[same as prior period, unchanged from 0001137789-25-000317:mdna:89]

[0001137789-26-000026:mdna:98]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means, including through the use of derivative transactions. During the six months ended January 2, 2026, we repurchased approximately 0.6 million of our ordinary shares including approximately 0.4 million shares withheld for statutory tax withholdings related to vesting of employee equity awards. As of January 2, 2026, $5.0 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-26-000026:mdna:99]
[same as prior period, unchanged from 0001137789-25-000317:mdna:91]

[0001137789-26-000026:mdna:100]
We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-26-000026:mdna:101]
[same as prior period, unchanged from 0001137789-25-000317:mdna:93]

[0001137789-26-000026:mdna:102]
[same as prior period, unchanged from 0001137789-25-000317:mdna:94]

[0001137789-26-000026:mdna:103]
[same as prior period, unchanged from 0001137789-25-000317:mdna:95]

[0001137789-26-000026:mdna:104]
[same as prior period, unchanged from 0001137789-25-000317:mdna:96]

[0001137789-26-000026:mdna:105]
See “Item 1. Financial Statements—Note 1. Basis of Presentation and Summary of Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.
