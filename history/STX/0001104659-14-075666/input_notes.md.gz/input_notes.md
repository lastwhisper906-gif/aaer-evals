# STX notes — 0001104659-14-075666


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001104659-14-075666:notes:1]
[same as prior period, unchanged from 0001104659-14-032674:notes:1]

[0001104659-14-075666:notes:2]
LSI's Flash Business

[0001104659-14-075666:notes:3]
On September 2, 2014, the Company completed the acquisition of certain assets and liabilities of LSI Corporation's ("LSI") Accelerated Solutions Division and Flash Components Division (collectively, the "Flash Business") from Avago Technologies Limited for $450 million in cash. The transaction is expected to strengthen Seagate's strategy to deliver a full suite of storage solutions, providing Seagate with established enterprise PCIe flash and SSD controller capabilities to deliver solutions for the growing flash storage market.

[0001104659-14-075666:notes:4]
The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the acquisition date:

[0001104659-14-075666:notes:5]
| (Dollars in millions) |  | Amount |
| Inventories |  | $ | 37 |  |
| Property, plant and equipment |  | 22 |  |
| Intangible assets |  | 141 |  |
| Other assets |  | 6 |  |
| Goodwill |  | 337 |  |
| Total assets |  | 543 |  |
| Liabilities |  | (93 | ) |
| Total liabilities |  | (93 | ) |
| Total |  | $ | 450 |  |

[0001104659-14-075666:notes:6]
The following table shows the fair value of the separately identifiable intangible assets at the time of acquisition and the weighted-average period over which intangible assets within each category will be amortized:

[0001104659-14-075666:notes:7]
| (Dollars in millions) |  | Fair Value |  | Weighted-AverageAmortizationPeriod |
| Existing technology |  | $ | 84 |  |  | 3.5 years |
| Customer relationships |  | 40 |  |  | 3.8 years |
| Trade names |  | 17 |  |  | 4.5 years |
| Total acquired identifiable intangible assets |  | $ | 141 |  |  |  |

[0001104659-14-075666:notes:8]
The goodwill recognized is primarily attributable to the benefits the Company expects to derive from enhanced market opportunities, and is not deductible for income tax purposes.

[0001104659-14-075666:notes:9]
The Company incurred approximately $1 million of expenses related to the acquisition of LSI's Flash Business during the September 2014 quarter, which are included within Marketing and administrative expense on the Consolidated Statement of Operations.

[0001104659-14-075666:notes:10]
The amounts of revenue and earnings of LSI's Flash Business included in the Company's Consolidated Statement of Operations from the acquisition date are not significant.

[0001104659-14-075666:notes:11]
Xyratex Ltd

[0001104659-14-075666:notes:12]
On March 31, 2014, the Company acquired all of the outstanding shares of Xyratex Ltd (“Xyratex”), a leading provider of data storage technology.  The Company paid $13.25 per share, or approximately $376 million in cash for the acquisition.  The acquisition of Xyratex further strengthens the Company’s vertically integrated supply and manufacturing chain for disk drives and provides access to important capital requirements, as well as expands the Company’s storage solutions portfolio.

[0001104659-14-075666:notes:13]
| (Dollars in millions) |  | Amount |
| Cash and cash equivalents |  | $ | 91 |  |
| Accounts receivable, net |  | 67 |  |
| Inventories |  | 111 |  |
| Other current and non-current assets |  | 28 |  |
| Property, plant and equipment |  | 55 |  |
| Intangible assets |  | 80 |  |
| Goodwill |  | 60 |  |
| Total assets |  | 492 |  |
| Accounts payable and accrued expenses |  | (116 | ) |
| Total liabilities |  | (116 | ) |
| Total |  | $ | 376 |  |

[0001104659-14-075666:notes:14]
The accounts receivable of $67 million are net of an immaterial allowance at March 31, 2014.

[0001104659-14-075666:notes:15]
| (Dollars in millions) |  | Fair Value |  | Weighted-AverageAmortizationPeriod |
| Existing technology |  | $ | 23 |  |  | 5.5 years |
| Customer relationships |  | 18 |  |  | 3.9 years |
| Total amortizable intangible assets acquired |  | 41 |  |  | 4.8 years |
| In-process research and development |  | 39 |  |  |  |
| Total acquired identifiable intangible assets |  | $ | 80 |  |  |  |

[0001104659-14-075666:notes:16]
The goodwill recognized is primarily attributable to the synergies expected to arise from the acquisition, and is not deductible for income tax purposes.

[0001104659-14-075666:notes:17]
The Company incurred a total of $10 million of expenses related to the acquisition of Xyratex in fiscal year 2014, which are included within Marketing and administrative expense on the Consolidated Statement of Operations.

[0001104659-14-075666:notes:18]
The amounts of revenue and earnings of Xyratex included in the Company's Consolidated Statement of Operations from the acquisition date are not significant.


## us-gaap:ConsolidationPolicyTextBlock

[0001104659-14-075666:notes:19]
[same as prior period, unchanged from 0001104659-14-032674:notes:14]

[0001104659-14-075666:notes:20]
The unaudited condensed consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

[0001104659-14-075666:notes:21]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles  requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income, cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature.

[0001104659-14-075666:notes:22]
The Company’s Consolidated Financial Statements for the fiscal year ended June 27, 2014, are included in its Annual Report on Form 10-K as filed with the United States Securities and Exchange Commission (“SEC”) on August 7, 2014. The Company believes that the disclosures included in the unaudited condensed consolidated financial statements, when read in conjunction with its Consolidated Financial Statements as of June 27, 2014, and the notes thereto, are adequate to make the information presented not misleading.


## us-gaap:DebtDisclosureTextBlock

[0001104659-14-075666:notes:23]
Debt

[0001104659-14-075666:notes:24]
Short-Term Borrowings

[0001104659-14-075666:notes:25]
On January 18, 2011, the Company and its subsidiary, Seagate HDD Cayman, entered into a Credit Agreement which provided a $350 million senior secured revolving credit facility (the “Revolving Credit Facility”). On April 30, 2013, the Company and Seagate HDD Cayman entered into the Second Amendment to the Credit Agreement which increased the commitments available under the Revolving Credit Facility from $350 million to $500 million. The loans made under the Credit Agreement will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility matures in April 2018, and is available for cash borrowings and for the issuance of letters of credit up to a sub-limit of $75 million. As of October 3, 2014, no borrowings had been drawn under the Revolving Credit Facility or had been utilized for letters of credit.

[0001104659-14-075666:notes:26]
Long-Term Debt

[0001104659-14-075666:notes:27]
$600 million Aggregate Principal Amount of 6.8% Senior Notes due October 2016 (the “2016 Notes”). The interest on the 2016 Notes is payable semi-annually on April 1 and October 1 of each year. The issuer under the 2016 Notes is Seagate HDD Cayman, and the obligations under the 2016 Notes are unconditionally guaranteed by certain of the Company’s significant subsidiaries.  During the September 2014 quarter, the Company repurchased $4 million aggregate principal amount of its 2016 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest.  The Company recorded a loss on the repurchase of approximately of $0.5 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

[0001104659-14-075666:notes:28]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”).  The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-14-075666:notes:29]
$600 million Aggregate Principal Amount of 6.875% Senior Notes due May 2020 (the “2020 Notes”). The interest on the 2020 Notes is payable semi-annually on May 1 and November 1 of each year. The issuer under the 2020 Notes is Seagate HDD Cayman, and the obligations under the 2020 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2014 quarter, the Company repurchased $28 million aggregate principal amount of its 2020 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately of $2 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

[0001104659-14-075666:notes:30]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2014 quarter, the Company repurchased $79 million aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately of $11 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

[0001104659-14-075666:notes:31]
$1 billion Aggregate Principal Amount of 4.75%  Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-14-075666:notes:32]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”).  The interest on the Notes is payable in cash semiannually on January 1 and July 1 of each year, commencing on January 1, 2015. The issuer under the 2025 Notes is Seagate HDD Cayman and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

[0001104659-14-075666:notes:33]
At October 3, 2014, future principal payments on long-term debt were as follows (in millions):

[0001104659-14-075666:notes:34]
| Fiscal Year | Amount |
| Remainder of 2015 | $ | — |  |
| 2016 | — |  |
| 2017 | 331 |  |
| 2018 | — |  |
| 2019 | 800 |  |
| Thereafter | 2,678 |  |
|  | $ | 3,809 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001104659-14-075666:notes:35]
[same as prior period, unchanged from 0001104659-14-032674:notes:29]

[0001104659-14-075666:notes:36]
The Company is exposed to market risks due to the volatility of interest rates, foreign currency exchange rates, and bond markets. The Company enters into foreign currency forward exchange contracts to manage the foreign currency exchange rate risk on forecasted expenses denominated in foreign currencies and to mitigate the remeasurement risk of certain foreign currency denominated liabilities. The Company’s accounting policies for these instruments are based on whether the instruments are classified as designated or non-designated hedging instruments. The Company records all derivatives in the Condensed Consolidated Balance Sheets at fair value. The changes in the fair values of the effective portions of designated cash flow hedges are recorded in Accumulated other comprehensive loss until the hedged item is recognized in earnings. Derivatives that are not designated as hedging instruments and the ineffective portions of cash flow hedges are adjusted to fair value through earnings. The amount of net unrealized losses on cash flow hedges was $4 million and $1 million as of October 3, 2014 and June 27, 2014, respectively.

[0001104659-14-075666:notes:37]
The Company dedesignates its cash flow hedges when the forecasted hedged transactions are realized or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in Accumulated other comprehensive loss are reclassified immediately into earnings and any subsequent changes in the fair value of such derivative instruments are immediately reflected in earnings. The Company did not recognize any net gains or losses related to the loss of hedge designation on discontinued cash flow hedges during the three months ended October 3, 2014. As of October 3, 2014, the Company’s existing foreign currency forward exchange contracts mature within 12 months. The deferred amount currently recorded in Accumulated other comprehensive income expected to be recognized into earnings over the next 12 months is immaterial.

[0001104659-14-075666:notes:38]
The following tables show the total notional value of the Company’s outstanding foreign currency forward exchange contracts as of October 3, 2014 and June 27, 2014:

[0001104659-14-075666:notes:39]
|  |  | As of October 3, 2014 |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| Thai Baht |  | $ | — |  |  | $ | 169 |  |
| Singapore Dollars |  | 142 |  |  | 16 |  |
| Chinese Renminbi |  | 77 |  |  | — |  |
| British Pound Sterling |  | 12 |  |  | — |  |
| Malaysian Ringgit |  | 4 |  |  | — |  |
|  |  | $ | 235 |  |  | $ | 185 |  |

[0001104659-14-075666:notes:40]
|  |  | As of June 27, 2014 |
| (Dollars in millions) |  | ContractsDesignated asHedges |  | Contracts NotDesignated asHedges |
| Thai Baht |  | $ | — |  |  | $ | 143 |  |
| British Pound Sterling |  | 25 |  |  | — |  |
| Malaysian Ringgit |  | 9 |  |  | — |  |
|  |  | $ | 34 |  |  | $ | 143 |  |

[0001104659-14-075666:notes:41]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its Non-qualified Deferred Compensation Plan—the Seagate Deferred Compensation Plan (the “SDCP”). In the quarter ended December 27, 2013, the Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP liabilities. The Company pays a floating rate, based on LIBOR plus an interest rate spread, on the notional amount of the TRS. The TRS is designed to substantially offset changes in the SDCP liability due to changes in the value of the investment options made by employees. As of October 3, 2014, the notional investments underlying the TRS amounted to $91 million. The contract term of the TRS is approximately one year and is settled on a monthly basis, therefore limiting counterparty performance risk. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP liabilities.

[0001104659-14-075666:notes:42]
The following tables show the Company’s derivative instruments measured at fair value as reflected in the Condensed Consolidated Balance Sheet as of October 3, 2014 and June 27, 2014:

[0001104659-14-075666:notes:43]
|  |  | As of October 3, 2014 |
|  |  | Asset Derivatives |  | Liability Derivatives |
| (Dollars in millions) |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 1 |  |  | Accrued expenses |  | $ | (4 | ) |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (4 | ) |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 1 |  |  |  |  | $ | (8 | ) |

[0001104659-14-075666:notes:44]
|  |  | As of June 27, 2014 |
|  |  | Asset Derivatives |  | Liability Derivatives |
| (Dollars in millions) |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 3 |  |  | Accrued expenses |  | $ | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | Other current assets |  | $ | 2 |  |  | Accrued expenses |  | $ | — |  |
| Total return swap |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  |  |  | $ | 5 |  |  |  |  | $ | — |  |

[0001104659-14-075666:notes:45]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statement of Comprehensive Income and the Condensed Consolidated Statement of Operations for the three months ended October 3, 2014:

[0001104659-14-075666:notes:46]
[same as prior period, unchanged from 0001104659-14-032674:notes:40]

[0001104659-14-075666:notes:47]
| Derivatives Designated as Hedging Instruments |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
| Foreign currency forward exchange contracts |  | $ | (3 | ) |  | Cost of revenue |  | $ | — |  |  | Cost of revenue |  | $ | 1 |  |

[0001104659-14-075666:notes:48]
| Derivatives Not Designated as Hedging Instruments |  | Location ofGain or (Loss)Recognized inIncome onDerivative |  | Amount ofGain or (Loss)Recognized in Incomeon Derivative |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (4 | ) |
| Total return swap |  | Operating expenses |  | $ | (3 | ) |

[0001104659-14-075666:notes:49]
[same as prior period, unchanged from 0001104659-14-032674:notes:43]

[0001104659-14-075666:notes:50]
| (a) | The amount of gain or (loss) recognized in income represents $0 related to the ineffective portion of the hedging relationships and $1 million related to the amount excluded from the assessment of hedge effectiveness for the three months ended October 3, 2014. |

[0001104659-14-075666:notes:51]
The following tables show the effect of the Company’s derivative instruments on the Condensed Consolidated Statement of Comprehensive Income and the Condensed Consolidated Statement of Operations for the three months ended September 27, 2013:

[0001104659-14-075666:notes:52]
[same as prior period, unchanged from 0001104659-14-032674:notes:46]

[0001104659-14-075666:notes:53]
| Derivatives Designated as Hedging Instruments |  | Amount ofGain or(Loss)Recognizedin OCI onDerivatives(EffectivePortion) |  | Location ofGain or (Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Amount ofGain or(Loss)ReclassifiedfromAccumulatedOCI intoIncome(EffectivePortion) |  | Location ofGain or (Loss)Recognized inIncome onDerivatives(IneffectivePortion andAmount ExcludedfromEffectivenessTesting) |  | Amount ofGainor (Loss)Recognized inIncome(IneffectivePortion andAmountExcluded fromEffectivenessTesting) (a) |
| Foreign currency forward exchange contracts |  | $ | 1 |  |  | Cost of revenue |  | $ | — |  |  | Cost of revenue |  | $ | — |  |

[0001104659-14-075666:notes:54]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain or(Loss) Recognized inIncome on Derivatives |  | Amount of Gain or(Loss) Recognized inIncome on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | 1 |  |

[0001104659-14-075666:notes:55]
| (a) | The amount of gain or (loss) recognized in income represents $0 related to the ineffective portion of the hedging relationship and $0 related to the amount excluded from the assessment of hedge effectiveness for the three months ended September 27, 2013. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-14-075666:notes:56]
[same as prior period, unchanged from 0001104659-14-032674:notes:50]

[0001104659-14-075666:notes:57]
The Company recorded approximately $42 million and $27 million of stock-based compensation expense during the three months ended October 3, 2014 and September 27, 2013, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001104659-14-075666:notes:58]
[same as prior period, unchanged from 0001104659-14-032674:notes:52]

[0001104659-14-075666:notes:59]
[same as prior period, unchanged from 0001104659-14-032674:notes:53]

[0001104659-14-075666:notes:60]
|  |  | For the Three Months Ended |
| (In millions, except per share data) |  | October 3, 2014 |  | September 27, 2013 |
| Numerator: |  |  |  |  |  |  |
| Net income attributable to Seagate Technology plc |  | $ | 381 |  |  | $ | 427 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income per share attributable to Seagate Technology plc |  | 327 |  |  | 357 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |
| Employee equity award plans |  | 10 |  |  | 11 |  |
| Total shares for purpose of calculating diluted net income per share attributable to Seagate Technology plc |  | 337 |  |  | 368 |  |
| Net income per share attributable to Seagate Technology plc shareholders: |  |  |  |  |  |  |
| Basic |  | $ | 1.17 |  |  | $ | 1.20 |  |
| Diluted |  | $ | 1.13 |  |  | $ | 1.16 |  |

[0001104659-14-075666:notes:61]
The anti-dilutive shares related to employee equity award plans that were excluded from the computation of diluted net income per share attributable to Seagate Technology plc were immaterial for the three months ended October 3, 2014 and September 27, 2013.


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001104659-14-075666:notes:62]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 793 |  |  | $ | 1,516 |  |  | $ | — |  |  | $ | 2,309 |  |
| Short-term investments | — |  |  | 20 |  |  | — |  |  | 20 |  |
| Restricted cash and investments | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Other current assets | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Total assets | $ | 793 |  |  | $ | 1,545 |  |  | $ | — |  |  | $ | 2,338 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued expenses | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001104659-14-075666:notes:63]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 558 |  |  | $ | 1,333 |  |  | $ | — |  |  | $ | 1,891 |  |
| Short-term investments | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Restricted cash and investments | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Other current assets | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total assets | $ | 558 |  |  | $ | 1,349 |  |  | $ | — |  |  | $ | 1,907 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued expenses | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |
| Total liabilities | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-14-075666:notes:64]
[same as prior period, unchanged from 0001104659-14-032674:notes:58]

[0001104659-14-075666:notes:65]
[same as prior period, unchanged from 0001104659-14-032674:notes:59]

[0001104659-14-075666:notes:66]
[same as prior period, unchanged from 0001104659-14-032674:notes:60]

[0001104659-14-075666:notes:67]
[same as prior period, unchanged from 0001104659-14-032674:notes:61]

[0001104659-14-075666:notes:68]
[same as prior period, unchanged from 0001104659-14-032674:notes:62]

[0001104659-14-075666:notes:69]
[same as prior period, unchanged from 0001104659-14-032674:notes:63]

[0001104659-14-075666:notes:70]
[same as prior period, unchanged from 0001104659-14-032674:notes:64]

[0001104659-14-075666:notes:71]
[same as prior period, unchanged from 0001104659-14-032674:notes:65]

[0001104659-14-075666:notes:72]
[same as prior period, unchanged from 0001104659-14-032674:notes:66]

[0001104659-14-075666:notes:73]
[same as prior period, unchanged from 0001104659-14-032674:notes:67]

[0001104659-14-075666:notes:74]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item, that are measured at fair value on a recurring basis, excluding accrued interest components, as of October 3, 2014:

[0001104659-14-075666:notes:75]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 558 |  |  | $ | — |  |  | $ | — |  |  | $ | 558 |  |
| Commercial paper | — |  |  | 1,077 |  |  | — |  |  | 1,077 |  |
| Certificates of deposit | — |  |  | 256 |  |  | — |  |  | 256 |  |
| Corporate bonds | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Total cash equivalents and short-term investments | 558 |  |  | 1,344 |  |  | — |  |  | 1,902 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |
| Other securities | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Derivative assets | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total assets | $ | 558 |  |  | $ | 1,349 |  |  | $ | — |  |  | $ | 1,907 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |
| Total liabilities | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |

[0001104659-14-075666:notes:76]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item, that are measured at fair value on a recurring basis, excluding accrued interest components, as of June 27, 2014:

[0001104659-14-075666:notes:77]
|  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) | QuotedPrices inActiveMarkets forIdenticalInstruments(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 793 |  |  | $ | — |  |  | $ | — |  |  | $ | 793 |  |
| Commercial paper | — |  |  | 1,261 |  |  | — |  |  | 1,261 |  |
| Certificates of deposit | — |  |  | 269 |  |  | — |  |  | 269 |  |
| Corporate bonds | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total cash equivalents and short-term investments | 793 |  |  | 1,536 |  |  | — |  |  | 2,329 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |
| Other securities | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Derivative assets | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Total assets | $ | 793 |  |  | $ | 1,545 |  |  | $ | — |  |  | $ | 2,338 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001104659-14-075666:notes:78]
The Company classifies items in Level 1 if the financial assets consist of securities for which quoted prices are available in an active market.

[0001104659-14-075666:notes:79]
The Company classifies items in Level 2 if the financial asset or liability is valued using observable inputs. The Company uses observable inputs including quoted prices in active markets for similar assets or liabilities. Level 2 assets include: agency bonds, corporate bonds, commercial paper, municipal bonds and U.S. Treasuries. These debt investments are priced using observable inputs and valuation models which vary by asset class. The Company uses a pricing service to assist in determining the fair values of all of its cash equivalents and short-term investments. For the cash equivalents and short-term investments in the Company’s portfolio, multiple pricing sources are generally available. The pricing service uses inputs from multiple industry standard data providers or other third party sources and various methodologies, such as weighting and models, to determine the appropriate price at the measurement date. The Company corroborates the prices obtained from the pricing service against other independent sources and, as of October 3, 2014, has not found it necessary to make any adjustments to the prices obtained. The Company’s derivative financial instruments are also classified within Level 2. The Company’s derivative financial instruments consist of foreign currency forward exchange contracts and the TRS. The Company recognizes derivative financial instruments in its condensed consolidated financial statements at fair value. The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date.

[0001104659-14-075666:notes:80]
The Company enters into certain strategic investments for the achievement of business and strategic objectives. Strategic investments in equity securities where the Company does not have the ability to exercise significant influence over the investees, are included in Other assets, net in the Condensed Consolidated Balance Sheets, are recorded at cost and are periodically analyzed to determine whether or not there are indicators of impairment. The carrying value of the Company’s strategic investments at October 3, 2014 and June 27, 2014 totaled $52 million and $46 million, respectively, and consisted primarily of privately held equity securities without a readily determinable fair value.

[0001104659-14-075666:notes:81]
[same as prior period, unchanged from 0001104659-14-032674:notes:78]

[0001104659-14-075666:notes:82]
[same as prior period, unchanged from 0001104659-14-032674:notes:79]

[0001104659-14-075666:notes:83]
|  |  | October 3, 2014 |  | June 27, 2014 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 6.8% Senior Notes due October 2016 |  | $ | 331 |  |  | $ | 364 |  |  | $ | 335 |  |  | $ | 374 |  |
| 3.75% Senior Notes due November 2018 |  | 800 |  |  | 817 |  |  | 800 |  |  | 820 |  |
| 6.875% Senior Notes due May 2020 |  | 506 |  |  | 537 |  |  | 534 |  |  | 578 |  |
| 7.00% Senior Notes due November 2021 |  | 172 |  |  | 191 |  |  | 251 |  |  | 284 |  |
| 4.75% Senior Notes due June 2023 |  | 1,000 |  |  | 1,027 |  |  | 1,000 |  |  | 1,009 |  |
| 4.75% Senior Notes due January 2025 |  | 1,000 |  |  | 1,012 |  |  | 1,000 |  |  | 995 |  |
| Long-term debt |  | $ | 3,809 |  |  | $ | 3,948 |  |  | $ | 3,920 |  |  | $ | 4,060 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-14-075666:notes:84]
[same as prior period, unchanged from 0001104659-14-032674:notes:81]

[0001104659-14-075666:notes:85]
Goodwill

[0001104659-14-075666:notes:86]
The changes in the carrying amount of goodwill for the three months ended October 3, 2014, are as follows:

[0001104659-14-075666:notes:87]
| (Dollars in millions) | Amount |
| Balance at June 27, 2014 | $ | 537 |  |
| Goodwill acquired | 337 |  |
| Foreign currency translation effect | (1 | ) |
| Balance at October 3, 2014 | $ | 873 |  |

[0001104659-14-075666:notes:88]
Other Intangible Assets

[0001104659-14-075666:notes:89]
Other intangible assets consist primarily of existing technology, customer relationships, in-process research and development and trade names acquired in business combinations. With the exception of in-process research and development, acquired intangibles are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization is charged to Operating expenses in the Condensed Consolidated Statements of Operations. In-process research and development has been determined to have an indefinite useful life and is not amortized, but instead tested for impairment annually or more frequently if events or changes in circumstance indicate that the asset might be impaired. If the carrying amount of in-process research and development exceeds its fair value, an impairment loss is recognized in an amount equal to that excess. There were no impairment charges recognized for in-process research and development.  Upon completion of the in-process research and development, the related assets will be accounted for as existing technology and will be amortized over their useful life.

[0001104659-14-075666:notes:90]
The carrying value of other intangible assets subject to amortization as of October 3, 2014, is set forth in the following table:

[0001104659-14-075666:notes:91]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 152 |  |  | $ | (27 | ) |  | $ | 125 |  |  | 3.2 years |
| Customer relationships |  | 488 |  |  | (215 | ) |  | 273 |  |  | 3.1 years |
| Trade names |  | 27 |  |  | (2 | ) |  | 25 |  |  | 3.9 years |
| Other intangible assets |  | 7 |  |  | (1 | ) |  | 6 |  |  | 3.8 years |
| Total amortizable other intangible assets |  | $ | 674 |  |  | $ | (245 | ) |  | $ | 429 |  |  | 3.2 years |

[0001104659-14-075666:notes:92]
The carrying value of In-process research and development not subject to amortization was $39 million on October 3, 2014.

[0001104659-14-075666:notes:93]
The carrying value of other intangible assets subject to amortization as of June 27, 2014 is set forth in the following table:

[0001104659-14-075666:notes:94]
| (Dollars in millions) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Weighted AverageRemaining Useful Life |
| Existing technology |  | $ | 68 |  |  | $ | (18 | ) |  | $ | 50 |  |  | 2.9 years |
| Customer relationships |  | 450 |  |  | (192 | ) |  | 258 |  |  | 3.3 years |
| Trade names |  | 10 |  |  | (1 | ) |  | 9 |  |  | 3.1 years |
| Other intangible assets |  | 4 |  |  | (1 | ) |  | 3 |  |  | 4.4 years |
| Total amortizable other intangible assets |  | $ | 532 |  |  | $ | (212 | ) |  | $ | 320 |  |  | 3.2 years |

[0001104659-14-075666:notes:95]
The carrying value of In-process research and development not subject to amortization was $39 million on June 27, 2014.

[0001104659-14-075666:notes:96]
For the three months ended October 3, 2014, amortization expense of other intangible assets was $34 million.  For the three months ended September 27, 2013, amortization expense of other intangible assets was $37 million.  As of October 3, 2014, expected amortization expense for other intangible assets for each of the next five fiscal years and thereafter is as follows:

[0001104659-14-075666:notes:97]
| (Dollars in millions) | Amount |
| Remainder of 2015 | $ | 115 |  |
| 2016 | 132 |  |
| 2017 | 113 |  |
| 2018 | 52 |  |
| 2019 | 15 |  |
| Thereafter | 2 |  |
|  | $ | 429 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-14-075666:notes:98]
[same as prior period, unchanged from 0001104659-14-032674:notes:92]

[0001104659-14-075666:notes:99]
The Company's income tax provision of $11 million in the three months ended October 3, 2014 included approximately $2 million net discrete tax benefits primarily associated with the release of tax reserves associated with the expiration of certain statutes of limitation.

[0001104659-14-075666:notes:100]
The Company's income tax provision recorded for the three months ended October 3, 2014 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets.

[0001104659-14-075666:notes:101]
During the three months ended October 3, 2014, the Company’s unrecognized tax benefits excluding interest and penalties decreased by approximately $1 million to $114 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate was $114 million at October 3, 2014, subject to certain future valuation allowance reversals. During the 12 months beginning October 4, 2014, the Company expects  that its unrecognized tax benefits could be reduced anywhere from $3 million to $50 million as a result of audit settlements and the expiration of certain statutes of limitation.

[0001104659-14-075666:notes:102]
The Company is subject to taxation in many jurisdictions globally and is required to file U.S. federal, U.S. state and non-U.S. income tax returns. In June 2014, the Company received the Revenue Agent’s Report and Notices of Proposed Adjustments for its U.S. federal income tax returns for fiscal years 2008, 2009 and 2010. The Company’s China subsidiaries are under examination by the Chinese tax administration for years 2004 through 2012. These examinations may result in proposed adjustments to the income taxes as filed during these periods. The Company believes that it has adequately provided for these matters, but there is a reasonable possibility that an adverse outcome of these examinations could have a material effect on the Company’s financial results. In this case, the Company would consider pursuing all possible remedies available, including appeals, judicial review and competent authority.

[0001104659-14-075666:notes:103]
The Company's income tax provision of $13 million in the three months ended September 27, 2013 included approximately $3 million of net discrete tax expense primarily associated with enacted tax legislation.

[0001104659-14-075666:notes:104]
The Company's income tax provision recorded for the three months ended September 27, 2013 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001104659-14-075666:notes:105]
| (Dollars in millions) |  | AmortizedCost |  | FairValue |
| Due in less than 1 year |  | $ | 1,900 |  |  | $ | 1,900 |  |
| Due in 1 to 5 years |  | 6 |  |  | 6 |  |
| Thereafter |  | — |  |  | — |  |
| Total |  | $ | 1,906 |  |  | $ | 1,906 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001104659-14-075666:notes:106]
Legal, Environmental and Other Contingencies

[0001104659-14-075666:notes:107]
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims, or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss.  In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment.  In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect.  Litigation is inherently uncertain and may result in adverse rulings or decisions.  Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001104659-14-075666:notes:108]
Intellectual Property Litigation

[0001104659-14-075666:notes:109]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al.—On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent Nos. 4,916,635 (the “'635 patent”) and U.S. Patent No. 5,638,267 (the “'267 patent”), misappropriation of trade secrets, breach of contract, and other claims.  In the complaint, the plaintiffs requested injunctive relief, $800 million in compensatory damages and unspecified punitive damages, including for willful infringement.  On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe US Patent No. 6,314,473 (the “'473 patent”).  The district court ruled in 2010 that the '267 patent was out of the case.

[0001104659-14-075666:notes:110]
On August 16, 2011, the district court granted in part and denied in part the Company's motion for summary judgment.  On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court's summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court's summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent.  On July 11, 2014, the district court granted its ruling on the Company’s summary judgment motion regarding Convolve’s only remaining cause of action, which alleged infringement of the ‘473 patent. The court entered judgment in favor of the Company on July 14, 2014. Convolve filed a notice of appeal on August 13, 2014. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-14-075666:notes:111]
Alexander Shukh v. Seagate Technology—On February 12, 2010, Alexander Shukh filed a complaint against the Company in the U.S. District Court for the District of Minnesota, alleging, among other things, employment discrimination based on his Belarusian national origin and wrongful failure to name him as an inventor on several patents and patent applications. Mr. Shukh's employment was terminated as part of a company-wide reduction in force in fiscal year 2009. He seeks damages in excess of $75 million. The Company believes the claims are without merit and intends to vigorously defend this case. On March 31, 2014, the district court granted Seagate’s summary judgment motion and entered judgment in favor of Seagate.  Mr. Shukh filed a notice of appeal on April 7, 2014. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-14-075666:notes:112]
LEAP Co., Ltd. v. Seagate Singapore International Headquarters Pte. Ltd. and Nippon Seagate Inc.—On July 4, 2012, LEAP Co., Ltd. filed a lawsuit in the Tokyo District Court of Japan against Seagate Singapore International Headquarters Pte. Ltd., Nippon Seagate Inc. and Buffalo Inc. alleging wrongful termination of purchase agreements and other claims, and seeking approximately $38 million in damages. A date for the start of trial has not yet been scheduled. The Company believes the claims are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-14-075666:notes:113]
Realtek Semiconductor Corporation ITC Investigation re Certain Integrated Circuit Chips and Products Containing the Same-On September 19, 2012, Realtek Semiconductor Corporation filed a complaint with the International Trade Commission (“ITC”) seeking an investigation pursuant to Section 337 of the Tariff Act of 1930, as amended (“Section 337”). The complaint names LSI Corporation and Seagate Technology as respondents and alleges infringement of U.S. patents relating to integrated circuit chips that include bond pad structures. Realtek seeks an order to exclude entry of infringing integrated circuit chips and products containing the infringing integrated circuit chips into the U.S. and a cease and desist order. The ITC initiated an investigation on October 18, 2012. On March 21, 2014, the Administrative Law Judge (“ALJ”) issued an Initial Determination in favor of Seagate and LSI. On July 21, 2014, the Commission gave notice that it had determined to affirm in part, reverse in part and vacate in part the ALJ’s Initial Determination; the Commission found that no violation of Section 337 by Seagate or LSI has occurred based on findings that certain of the patent claims at issue were invalid, and that Realtek failed to show the existence of an industry in the U.S. that exploits the patent. Realtek filed a notice of appeal on September 18, 2014. In view of the uncertainty regarding the possible outcome of this case and the nature of the relief sought, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible loss or range of loss, or other possible adverse result, if any, that may be incurred with respect to this matter.

[0001104659-14-075666:notes:114]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995, “Cryptographic Device,” and U.S. Patent No. 7,900,057, “Cryptographic Serial ATA Apparatus and Method.”  The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys' fees, and other relief.  The trial is scheduled to begin July 11, 2016.  The Company believes the claims are without merit and intends to vigorously defend this case.  In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

[0001104659-14-075666:notes:115]
Environmental Matters

[0001104659-14-075666:notes:116]
The Company's operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company's operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001104659-14-075666:notes:117]
The Company has established environmental management systems and continually updates its environmental policies and standard operating procedures for its operations worldwide. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001104659-14-075666:notes:118]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001104659-14-075666:notes:119]
While the Company's ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001104659-14-075666:notes:120]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.

[0001104659-14-075666:notes:121]
Other Matters

[0001104659-14-075666:notes:122]
The Company is involved in a number of other judicial and administrative proceedings incidental to its business, and the Company may be involved in various legal proceedings arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001104659-14-075666:notes:123]
In May 2014, The FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers. The ASU outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The ASU will be effective for the Company's first quarter of fiscal year 2018. The Company is in the process of assessing the impact, if any, of ASU 2014-09 on its consolidated financial statements.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001104659-14-075666:notes:124]
[same as prior period, unchanged from 0001104659-14-032674:notes:121]

[0001104659-14-075666:notes:125]
[same as prior period, unchanged from 0001104659-14-032674:notes:122]

[0001104659-14-075666:notes:126]
The Company is a leading provider of electronic data storage solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives are used as the primary medium for storing electronic data. In addition to HDDs, we produce a broad range of electronic data storage products including solid state hybrid drives (“SSHD”) and solid state drives (“SSD”).

[0001104659-14-075666:notes:127]
The Company's products are designed for enterprise servers and storage systems in mission critical and nearline applications; client compute applications, where its products are designed primarily for desktop and mobile computing; and client non-compute applications, where its products are designed for a wide variety of end user devices such as digital video recorders (“DVRs”), personal data backup systems, portable external storage systems and digital media systems.

[0001104659-14-075666:notes:128]
The Company continues to make strategic investments in order to expand its storage solutions, enter new market adjacencies, and expand our technical expertise. As a result of recent acquisitions, the Company's product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and high performance computing ("HPC") data storage solutions. The Company's storage subsystems support a range of high-speed interconnect technologies to meet demanding cost and performance specifications. The Company's modular subsystem architecture allows it to support many segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.

[0001104659-14-075666:notes:129]
In addition to manufacturing and selling data storage products, the Company provides data storage services for small to medium-sized businesses, including online backup, data protection and recovery solutions.

[0001104659-14-075666:notes:130]
The results of operations for the three months ended October 3, 2014, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending July 3, 2015. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three months ended October 3, 2014 and September 27, 2013 consisted of 14 weeks and 13 weeks, respectively.  Fiscal year 2015 will be comprised of 53 weeks and will end on July 3, 2015.

[0001104659-14-075666:notes:131]
[same as prior period, unchanged from 0001104659-14-032674:notes:126]

[0001104659-14-075666:notes:132]
There have been no significant changes in our significant accounting policies. Please refer to Note 1 of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended June 27, 2014, as filed with the SEC on August 7, 2014 for a discussion of the Company’s other significant accounting policies.

[0001104659-14-075666:notes:133]
Recently Issued Accounting Pronouncements


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001104659-14-075666:notes:134]
[same as prior period, unchanged from 0001104659-14-032674:notes:129]

[0001104659-14-075666:notes:135]
[same as prior period, unchanged from 0001104659-14-032674:notes:130]

[0001104659-14-075666:notes:136]
On May 4, 2009,  Seagate Technology, an exempted company incorporated with limited liability under the laws of the Cayman Islands (“Seagate-Cayman”), then the parent company, entered into a new form of indemnification agreement (the “Revised Indemnification Agreement”) with its officers and directors of Seagate-Cayman and its subsidiaries (each, an “Indemnitee”). The Revised Indemnification Agreement provides indemnification in addition to any of Indemnitee's indemnification rights under Seagate-Cayman's Articles of Association, applicable law or otherwise, and indemnifies an Indemnitee for certain expenses (including attorneys' fees), judgments, fines and settlement amounts actually and reasonably incurred by him or her in any action or proceeding, including any action by or in the right of Seagate-Cayman or any of its subsidiaries, arising out of his or her service as a director, officer, employee or agent of Seagate-Cayman or any of its subsidiaries or of any other entity to which he or she provides services at Seagate-Caymans's request. However, an Indemnitee shall not be indemnified under the Revised Indemnification Agreement for (i) any fraud or dishonesty in the performance of Indemnitee's duty to Seagate-Cayman or the applicable subsidiary of Seagate-Cayman or (ii) Indemnitee's conscious, intentional or willful failure to act honestly, lawfully and in good faith with a view to the best interests of Seagate-Cayman or the applicable subsidiary of Seagate-Cayman. In addition, the Revised Indemnification Agreement provides that Seagate-Cayman will advance expenses incurred by an Indemnitee in connection with enforcement of the Revised Indemnification Agreement or with the investigation, settlement or appeal of any action or proceeding against him or her as to which he or she could be indemnified.

[0001104659-14-075666:notes:137]
On July 3, 2010 pursuant to a corporate reorganization, the common shareholders of Seagate-Cayman became ordinary shareholders of Seagate Technology plc (the "Company") and Seagate-Cayman became a wholly owned subsidiary of the Company, as described more fully in the Current Report on Form 8-K filed by the Company on July 6, 2010 (the “Redomestication”). On July 27, 2010, in connection with the Redomestication, the Company, as sole shareholder of Seagate-Cayman, approved a form of deed of indemnity (the “Deed of Indemnity”), which provides for the indemnification by Seagate-Cayman of any director, officer, employee or agent of the Company, Seagate-Cayman or any subsidiary of the Company (each, a “Deed Indemnitee”), in addition to any of a Deed Indemnitee's indemnification rights under the Company's Articles of Association, applicable law or otherwise, with a similar scope to the Revised Indemnification Agreement. Seagate-Cayman entered into the Deed of Indemnity with certain Deed Indemnitees effective as of July 3, 2010 and continues to enter into the Deed of Indemnity with additional Deed Indemnitees from time to time.

[0001104659-14-075666:notes:138]
The nature of these indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay on behalf of its officers and directors. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the accompanying consolidated financial statements with respect to these indemnification obligations.

[0001104659-14-075666:notes:139]
[same as prior period, unchanged from 0001104659-14-032674:notes:134]

[0001104659-14-075666:notes:140]
[same as prior period, unchanged from 0001104659-14-032674:notes:135]

[0001104659-14-075666:notes:141]
[same as prior period, unchanged from 0001104659-14-032674:notes:136]

[0001104659-14-075666:notes:142]
The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally warrants its products for a period of 1 to 5 years. The Company uses estimated repair or replacement costs and uses statistical modeling to estimate product return rates in order to determine its warranty obligation. Changes in the Company’s product warranty liability during the three months ended October 3, 2014 and September 27, 2013 were as follows:

[0001104659-14-075666:notes:143]
|  |  | For the Three Months Ended |
| (Dollars in millions) |  | October 3, 2014 |  | September 27, 2013 |
| Balance, beginning of period |  | $ | 273 |  |  | $ | 320 |  |
| Warranties issued |  | 40 |  |  | 48 |  |
| Repairs and replacements |  | (54 | ) |  | (58 | ) |
| Changes in liability for pre-existing warranties, including expirations |  | 6 |  |  | 8 |  |
| Warranty liability assumed from business acquisitions |  | 8 |  |  | — |  |
| Balance, end of period |  | $ | 273 |  |  | $ | 318 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001104659-14-075666:notes:144]
| (Dollars in millions) |  | October 3, 2014 |  | June 27, 2014 |
| Property, equipment and leasehold improvements |  | $ | 9,135 |  |  | $ | 8,979 |  |
| Accumulated depreciation and amortization |  | (6,979 | ) |  | (6,843 | ) |
|  |  | $ | 2,156 |  |  | $ | 2,136 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001104659-14-075666:notes:145]
| (Dollars in millions) |  | Unrealized Gains (Losses) on Cash Flow Hedges |  | Unrealized Gains (Losses) on Marketable Securities (a) |  | Unrealized Gains (Losses) on post-retirements |  | Foreign currency translation adjustments |  | Total |
| Balance at June 27, 2014 |  | $ | (1 | ) |  | $ | — |  |  | $ | (10 | ) |  | $ | 9 |  |  | $ | (2 | ) |
| Other comprehensive income (loss) before reclassifications |  | (3 | ) |  | — |  |  | — |  |  | (10 | ) |  | (13 | ) |
| Amounts reclassified from AOCI |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) |  | (3 | ) |  | — |  |  | — |  |  | (10 | ) |  | (13 | ) |
| Balance at October 3, 2014 |  | $ | (4 | ) |  | $ | — |  |  | $ | (10 | ) |  | $ | (1 | ) |  | $ | (15 | ) |
| Balance at June 28, 2013 |  | $ | — |  |  | $ | (3 | ) |  | $ | (11 | ) |  | $ | 1 |  |  | $ | (13 | ) |
| Other comprehensive income (loss) before reclassifications |  | 1 |  |  | 1 |  |  | — |  |  | 5 |  |  | 7 |  |
| Amounts reclassified from AOCI |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) |  | 1 |  |  | 1 |  |  | — |  |  | 5 |  |  | 7 |  |
| Balance at September 27, 2013 |  | $ | 1 |  |  | $ | (2 | ) |  | $ | (11 | ) |  | $ | 6 |  |  | $ | (6 | ) |

[0001104659-14-075666:notes:146]
[same as prior period, unchanged from 0001104659-14-032674:notes:141]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001104659-14-075666:notes:147]
| (Dollars in millions) |  | October 3, 2014 |  | June 27, 2014 |
| Raw materials and components |  | $ | 313 |  |  | $ | 324 |  |
| Work-in-process |  | 314 |  |  | 267 |  |
| Finished goods |  | 444 |  |  | 394 |  |
|  |  | $ | 1,071 |  |  | $ | 985 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-14-075666:notes:148]
[same as prior period, unchanged from 0001104659-14-032674:notes:144]

[0001104659-14-075666:notes:149]
[same as prior period, unchanged from 0001104659-14-032674:notes:145]

[0001104659-14-075666:notes:150]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 327,176,198 shares were outstanding as of October 3, 2014, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of October 3, 2014.

[0001104659-14-075666:notes:151]
[same as prior period, unchanged from 0001104659-14-032674:notes:147]

[0001104659-14-075666:notes:152]
[same as prior period, unchanged from 0001104659-14-032674:notes:148]

[0001104659-14-075666:notes:153]
[same as prior period, unchanged from 0001104659-14-032674:notes:149]

[0001104659-14-075666:notes:154]
[same as prior period, unchanged from 0001104659-14-032674:notes:150]

[0001104659-14-075666:notes:155]
[same as prior period, unchanged from 0001104659-14-032674:notes:152]

[0001104659-14-075666:notes:156]
[same as prior period, unchanged from 0001104659-14-032674:notes:153]

[0001104659-14-075666:notes:157]
As of October 3, 2014, $1.3 billion remained available for repurchase under the existing repurchase authorization limit.

[0001104659-14-075666:notes:158]
The following table sets forth information with respect to repurchases of the Company’s shares during the three months ended October 3, 2014:

[0001104659-14-075666:notes:159]
| (In millions) | Number ofSharesRepurchased |  | Dollar Valueof SharesRepurchased |
| Repurchased during the three months ended October 3, 2014 | 3 |  |  | $ | 183 |  |
| Fiscal year repurchased through October 3, 2014 | 3 |  |  | $ | 183 |  |


## us-gaap:SubsequentEventsTextBlock

[0001104659-14-075666:notes:160]
Subsequent Events

[0001104659-14-075666:notes:161]
On October 8, 2014, the Minnesota Supreme Court ruled that the arbitration award in favor of the Company in its case against Western Digital for the misappropriation of the Company trade secrets should be confirmed. In the arbitration award, issued on January 23, 2012, the arbitrator determined that Western Digital and its former employee had misappropriated the Company trade secrets. The arbitrator awarded the Company $525 million in compensatory damages and, after adding interest, issued a final award of approximately $630 million. Interest on the final award has been accruing at 10%.  On October 14, 2014, the Company received a partial payment from Western Digital in the amount of approximately $773 million.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001104659-14-075666:notes:162]
[same as prior period, unchanged from 0001104659-14-032674:notes:159]

[0001104659-14-075666:notes:163]
[same as prior period, unchanged from 0001104659-14-032674:notes:160]

[0001104659-14-075666:notes:164]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of  October 3, 2014:

[0001104659-14-075666:notes:165]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 558 |  |  | $ | — |  |  | $ | 558 |  |
| Commercial paper |  | 1,077 |  |  | — |  |  | 1,077 |  |
| Corporate bonds |  | 11 |  |  | — |  |  | 11 |  |
| Certificates of deposit |  | 260 |  |  | — |  |  | 260 |  |
|  |  | $ | 1,906 |  |  | $ | — |  |  | $ | 1,906 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 1,891 |  |
| Included in Short-term investments |  |  |  |  |  |  |  | 11 |  |
| Included in Restricted cash and investments |  |  |  |  |  |  |  | 4 |  |
| Total |  |  |  |  |  |  |  | $ | 1,906 |  |

[0001104659-14-075666:notes:166]
As of October 3, 2014, the Company’s Restricted cash and investments consisted of $4 million in cash and investments held as collateral at banks for various performance obligations.

[0001104659-14-075666:notes:167]
As of October 3, 2014, the Company had no available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale securities were other-than-temporarily impaired as of October 3, 2014.

[0001104659-14-075666:notes:168]
The fair value and amortized cost of the Company’s investments classified as available-for-sale at October 3, 2014, by remaining contractual maturity were as follows:

[0001104659-14-075666:notes:169]
The following table summarizes, by major type, the fair value and amortized cost of the Company’s investments as of June 27, 2014:

[0001104659-14-075666:notes:170]
| (Dollars in millions) |  | AmortizedCost |  | UnrealizedGain/(Loss) |  | FairValue |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 793 |  |  | $ | — |  |  | $ | 793 |  |
| Commercial paper |  | 1,261 |  |  | — |  |  | 1,261 |  |
| Corporate bonds |  | 6 |  |  | — |  |  | 6 |  |
| Certificates of deposit |  | 273 |  |  | — |  |  | 273 |  |
| Total |  | $ | 2,333 |  |  | $ | — |  |  | $ | 2,333 |  |
| Included in Cash and cash equivalents |  |  |  |  |  |  |  | $ | 2,309 |  |
| Included in Short-term investments |  |  |  |  |  |  |  | 20 |  |
| Included in Restricted cash and investments |  |  |  |  |  |  |  | 4 |  |
| Total |  |  |  |  |  |  |  | $ | 2,333 |  |

[0001104659-14-075666:notes:171]
As of June 27, 2014, the Company had no available-for-sale securities that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no available-for-sale securities were other-than-temporarily impaired as of June 27, 2014.

[0001104659-14-075666:notes:172]
[same as prior period, unchanged from 0001104659-14-032674:notes:170]

[0001104659-14-075666:notes:173]
[same as prior period, unchanged from 0001104659-14-032674:notes:171]

[0001104659-14-075666:notes:174]
[same as prior period, unchanged from 0001104659-14-032674:notes:175]

[0001104659-14-075666:notes:175]
[same as prior period, unchanged from 0001104659-14-032674:notes:176]

[0001104659-14-075666:notes:176]
[same as prior period, unchanged from 0001104659-14-032674:notes:177]

[0001104659-14-075666:notes:177]
[same as prior period, unchanged from 0001104659-14-032674:notes:178]
