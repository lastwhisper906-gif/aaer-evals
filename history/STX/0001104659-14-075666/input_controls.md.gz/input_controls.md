# STX 10-Q controls and the auditor's report


## item_4_controls

[0001104659-14-075666:item_4_controls:1]
ITEM 4.            CONTROLS AND PROCEDURES

[0001104659-14-075666:item_4_controls:2]
An evaluation was performed under the supervision and with the participation of our management, including our chief executive officer and chief financial officer, of the effectiveness of the design and operation of our disclosure controls and procedures as of the end of the period covered by this quarterly report.  Based on the evaluation, our management, including our chief executive officer and chief financial officer, concluded that our disclosure controls and procedures were effective as of October 3, 2014.  During the quarter ended October 3, 2014, there were no changes in our internal control over financial reporting that materially affected, or were reasonably likely to materially affect our internal control over financial reporting.

[0001104659-14-075666:item_4_controls:3]
33
