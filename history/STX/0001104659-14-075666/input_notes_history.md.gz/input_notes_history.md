# STX note change history — 0001104659-14-032674 → 0001104659-14-075666


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-03):
[0001104659-14-075666:note_history:1]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al.—On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent Nos. 4,916,635 (the “'635 patent”) and U.S. Patent No. 5,638,267 (the “'267 patent”), misappropriation of trade secrets, breach of contract, and other claims.  In the complaint, the plaintiffs requested injunctive relief, $800 million in compensatory damages and unspecified punitive damages, including for willful infringement.  On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe US Patent No. 6,314,473 (the “'473 patent”).  The district court ruled in 2010 that the '267 patent was out of the case.
  (was, 2014-04-30, similarity 0.839):
[0001104659-14-032674:note_history:1]
Convolve, Inc. (“Convolve”) and Massachusetts Institute of Technology (“MIT”) v. Seagate Technology LLC, et al.—On July 13, 2000, Convolve and MIT filed suit against Compaq Computer Corporation and Seagate Technology LLC in the U.S. District Court for the Southern District of New York, alleging infringement of U.S. Patent Nos. 4,916,635, “Shaping Command Inputs to Minimize Unwanted Dynamics” (the “'635 patent”) and U.S. Patent No. 5,638,267, “Method and Apparatus for Minimizing Unwanted Dynamics in a Physical System” (the “'267 patent”), misappropriation of trade secrets, breach of contract, and other claims. In the complaint, the plaintiffs requested injunctive relief, $800 million in compensatory damages and unspecified punitive damages, including for willful infringement and willful and malicious misappropriation. On January 16, 2002, Convolve filed an amended complaint, alleging defendants infringe US Patent No. 6,314,473, “System for Removing Selected Unwanted Frequencies in Accordance with Altered Settings in a User Interface of a Data Storage Device,” (the “'473patent”). The district court ruled in 2010 that the '267 patent was out of the case.

- changed (2014-11-03):
[0001104659-14-075666:note_history:2]
On August 16, 2011, the district court granted in part and denied in part the Company's motion for summary judgment.  On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court's summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court's summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent.  On July 11, 2014, the district court granted its ruling on the Company’s summary judgment motion regarding Convolve’s only remaining cause of action, which alleged infringement of the ‘473 patent. The court entered judgment in favor of the Company on July 14, 2014. Convolve filed a notice of appeal on August 13, 2014. In view of the rulings made by the district court and the Court of Appeals and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2014-04-30, similarity 0.7138):
[0001104659-14-032674:note_history:2]
On August 16, 2011, the district court granted in part and denied in part the Company's motion for summary judgment. On July 1, 2013, the U.S. Court of Appeals for the Federal Circuit: 1) affirmed the district court's summary judgment rulings that Seagate did not misappropriate any of the alleged trade secrets and that the asserted claims of the '635 patent are invalid; 2) reversed and vacated the district court's summary judgment of non-infringement with respect to the '473 patent; and 3) remanded the case for further proceedings on the '473 patent. On March 12, 2014, the district court set a schedule for resolving the remaining issues relating to the ‘473 patent; a pre-trial conference is scheduled for September 10, 2014, and trial is scheduled to begin October 6, 2014. In view of the district court's August 16, 2011 ruling and the Court of Appeals' July 1, 2013 ruling and the uncertainty regarding the amount of damages, if any, that could be awarded Convolve in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- added (2014-11-03):
[0001104659-14-075666:note_history:3]
Realtek Semiconductor Corporation ITC Investigation re Certain Integrated Circuit Chips and Products Containing the Same-On September 19, 2012, Realtek Semiconductor Corporation filed a complaint with the International Trade Commission (“ITC”) seeking an investigation pursuant to Section 337 of the Tariff Act of 1930, as amended (“Section 337”). The complaint names LSI Corporation and Seagate Technology as respondents and alleges infringement of U.S. patents relating to integrated circuit chips that include bond pad structures. Realtek seeks an order to exclude entry of infringing integrated circuit chips and products containing the infringing integrated circuit chips into the U.S. and a cease and desist order. The ITC initiated an investigation on October 18, 2012. On March 21, 2014, the Administrative Law Judge (“ALJ”) issued an Initial Determination in favor of Seagate and LSI. On July 21, 2014, the Commission gave notice that it had determined to affirm in part, reverse in part and vacate in part the ALJ’s Initial Determination; the Commission found that no violation of Section 337 by Seagate or LSI has occurred based on findings that certain of the patent claims at issue were invalid, and that Realtek failed to show the existence of an industry in the U.S. that exploits the patent. Realtek filed a notice of appeal on September 18, 2014. In view of the uncertainty regarding the possible outcome of this case and the nature of the relief sought, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible loss or range of loss, or other possible adverse result, if any, that may be incurred with respect to this matter.

- changed (2014-11-03):
[0001104659-14-075666:note_history:4]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995, “Cryptographic Device,” and U.S. Patent No. 7,900,057, “Cryptographic Serial ATA Apparatus and Method.”  The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys' fees, and other relief.  The trial is scheduled to begin July 11, 2016.  The Company believes the claims are without merit and intends to vigorously defend this case.  In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.
  (was, 2014-04-30, similarity 0.951):
[0001104659-14-032674:note_history:4]
Enova Technology Corporation v. Seagate Technology (US) Holdings, Inc., et al.-On June 5, 2013, Enova Technology Corporation filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the District of Delaware alleging infringement of U.S. Patent No. 7,136,995, “Cryptographic Device,” and U.S. Patent No. 7,900,057, “Cryptographic Serial ATA Apparatus and Method.” The complaint seeks unspecified compensatory damages, enhanced damages, injunctive relief, attorneys' fees, and other relief. A date for the start of trial has not yet been scheduled. The Company believes the claims are without merit and intends to vigorously defend this case. In view of the uncertainty regarding the amount of damages, if any, that could be awarded in this matter, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible range of loss related to this matter.

- changed (2014-11-03):
[0001104659-14-075666:note_history:5]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.
  (was, 2014-04-30, similarity 0.987):
[0001104659-14-032674:note_history:5]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment, which prohibits the use of certain substances, including lead, in certain products, including disk drives, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The European Union REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern (“SVHCs”) in products. If the Company or its suppliers fails to comply with the substance restrictions, recycle requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company's business.

- removed (2014-11-03):
[0001104659-14-032674:note_history:6]
Realtek Semiconductor Corporation ITC Investigation re Certain Integrated Circuit Chips and Products Containing the Same—On September 19, 2012, Realtek Semiconductor Corporation filed a complaint with the International Trade Commission seeking an investigation pursuant to Section 337 of the Tariff Act of 1930, as amended. The complaint names LSI Corporation and Seagate Technology as respondents and alleges infringement of U.S. patents relating to integrated circuit chips that include bond pad structures. Realtek seeks an order to exclude entry of infringing integrated circuit chips and products containing the infringing integrated circuit chips into the U.S. and a cease and desist order. The ITC initiated an investigation on October 18, 2012. The target date for completion of the investigation is July 17, 2014. On March 21, 2014, the ALJ issued an Initial Determination in favor of Seagate and LSI based on findings that the patent claims at issue are invalid, and that Realtek failed to show the existence of an industry in the U.S. that exploits the patent. In view of the uncertainty regarding the possible outcome of this case and the nature of the relief sought, the Company does not believe that it is currently possible to determine a reasonable estimate of the possible loss or range of loss, or other possible adverse result, if any, that may be incurred with respect to this matter.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-11-03):
[0001104659-14-075666:note_history:7]
The Company is a leading provider of electronic data storage solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives are used as the primary medium for storing electronic data. In addition to HDDs, we produce a broad range of electronic data storage products including solid state hybrid drives (“SSHD”) and solid state drives (“SSD”).
  (was, 2014-04-30, similarity 0.7561):
[0001104659-14-032674:note_history:7]
The Company is a leading provider of data storage products. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives are used as the primary medium for storing electronic data.

- added (2014-11-03):
[0001104659-14-075666:note_history:8]
The Company's products are designed for enterprise servers and storage systems in mission critical and nearline applications; client compute applications, where its products are designed primarily for desktop and mobile computing; and client non-compute applications, where its products are designed for a wide variety of end user devices such as digital video recorders (“DVRs”), personal data backup systems, portable external storage systems and digital media systems.

- added (2014-11-03):
[0001104659-14-075666:note_history:9]
The Company continues to make strategic investments in order to expand its storage solutions, enter new market adjacencies, and expand our technical expertise. As a result of recent acquisitions, the Company's product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and high performance computing ("HPC") data storage solutions. The Company's storage subsystems support a range of high-speed interconnect technologies to meet demanding cost and performance specifications. The Company's modular subsystem architecture allows it to support many segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.

- added (2014-11-03):
[0001104659-14-075666:note_history:10]
In addition to manufacturing and selling data storage products, the Company provides data storage services for small to medium-sized businesses, including online backup, data protection and recovery solutions.

- added (2014-11-03):
[0001104659-14-075666:note_history:11]
The unaudited condensed consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

- changed (2014-11-03):
[0001104659-14-075666:note_history:12]
The preparation of financial statements in accordance with U.S. generally accepted accounting principles  requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income, cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature.
  (was, 2014-04-30, similarity 0.6722):
[0001104659-14-032674:note_history:12]
The unaudited condensed consolidated financial statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances. The preparation of financial statements in accordance with U.S. generally accepted accounting principles also requires management to make estimates and assumptions that affect the amounts reported in the Company’s condensed consolidated financial statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its condensed consolidated financial statements. The condensed consolidated financial statements reflect, in the opinion of management, all material adjustments necessary to present fairly the condensed consolidated financial position, results of operations, comprehensive income, cash flows and shareholders’ equity for the periods presented. Such adjustments are of a normal and recurring nature. The Company’s Consolidated Financial Statements for the fiscal year ended June 28, 2013, are included in its Annual Report on Form 10-K as filed with the United States Securities and Exchange Commission (“SEC”) on August 7, 2013. The Company believes that the disclosures included in the unaudited Condensed Consolidated Financial Statements, when read in conjunction with its Consolidated Financial Statements as of June 28, 2013, and the notes thereto, are adequate to make the information presented not misleading.

- added (2014-11-03):
[0001104659-14-075666:note_history:13]
The Company’s Consolidated Financial Statements for the fiscal year ended June 27, 2014, are included in its Annual Report on Form 10-K as filed with the United States Securities and Exchange Commission (“SEC”) on August 7, 2014. The Company believes that the disclosures included in the unaudited condensed consolidated financial statements, when read in conjunction with its Consolidated Financial Statements as of June 27, 2014, and the notes thereto, are adequate to make the information presented not misleading.

- added (2014-11-03):
[0001104659-14-075666:note_history:14]
The results of operations for the three months ended October 3, 2014, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending July 3, 2015. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three months ended October 3, 2014 and September 27, 2013 consisted of 14 weeks and 13 weeks, respectively.  Fiscal year 2015 will be comprised of 53 weeks and will end on July 3, 2015.

- changed (2014-11-03):
[0001104659-14-075666:note_history:15]
There have been no significant changes in our significant accounting policies. Please refer to Note 1 of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended June 27, 2014, as filed with the SEC on August 7, 2014 for a discussion of the Company’s other significant accounting policies.
  (was, 2014-04-30, similarity 0.8851):
[0001104659-14-032674:note_history:15]
Other than the revised presentation of accumulated other comprehensive income described below, there have been no  significant changes in our significant accounting policies. Please refer to Note 1 of “Financial Statements and Supplementary Data” contained in Part II, Item 8 of the Company’s Annual Report on Form 10-K for the fiscal year ended June 28, 2013, as filed with the SEC on August 7, 2013 for a discussion of the Company’s other significant accounting policies.

- added (2014-11-03):
[0001104659-14-075666:note_history:16]
In May 2014, The FASB issued ASU 2014-09 (ASC Topic 606), Revenue from Contracts with Customers. The ASU outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. It also requires entities to disclose both quantitative and qualitative information that enable financial statements users to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The ASU will be effective for the Company's first quarter of fiscal year 2018. The Company is in the process of assessing the impact, if any, of ASU 2014-09 on its consolidated financial statements.

- removed (2014-11-03):
[0001104659-14-032674:note_history:17]
The Company produces a broad range of electronic data storage products including HDDs, solid state hybrid drives (“SSHD”) and solid state drives (“SSD”), which address enterprise applications, where its products are designed for enterprise servers, mainframes and workstations; client compute applications, where its products are designed primarily for desktop and notebook computers; and client non-compute applications, where its products are designed for a wide variety of end user devices such as digital video recorders (“DVRs”), personal data backup systems, portable external storage systems and digital media systems. In addition to manufacturing and selling data storage products, the Company provides data storage services for small to medium-sized businesses, including online backup, data protection and recovery solutions.

- removed (2014-11-03):
[0001104659-14-032674:note_history:18]
The results of operations for the three and nine months ended March 28, 2014, are not necessarily indicative of the results of operations to be expected for any subsequent interim period in the Company’s fiscal year ending June 27, 2014. The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The three and nine months ended March 28, 2014 and March 29, 2013 each consisted of 13 weeks and 39 weeks, respectively.  Fiscal year 2014 will be comprised of 52 weeks and will end on June 27, 2014.

- removed (2014-11-03):
[0001104659-14-032674:note_history:19]
In February 2013, the FASB issued ASU No. 2013-02, Comprehensive Income (ASC Topic 220) — Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income. The ASU requires an entity to report information, either on the face of the statement where net income is presented or in the notes, about the amounts reclassified out of accumulated other comprehensive income by component and to report significant amounts reclassified out of accumulated other comprehensive income by the respective line items of net income.  The ASU has been adopted by the Company effective for the first quarter of fiscal year 2014.  Other than requiring additional disclosures, the adoption of this new guidance did not have a material impact on the Company's consolidated financial statements.

- removed (2014-11-03):
[0001104659-14-032674:note_history:20]
In July, 2013, the FASB issued ASU No. 2013-11, Income Taxes (ASC Topic 740) — Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. The amendments in this ASU provide explicit guidance that an unrecognized tax benefit, or a portion of an unrecognized tax benefit, should be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward, with limited exceptions. The amendments in this ASU are effective for fiscal years, and interim periods within those years, beginning after December 15, 2013 and do not require new recurring disclosures. The adoption of this new guidance will not have a material impact on the Company's consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-03):
[0001104659-14-075666:note_history:21]
On January 18, 2011, the Company and its subsidiary, Seagate HDD Cayman, entered into a Credit Agreement which provided a $350 million senior secured revolving credit facility (the “Revolving Credit Facility”). On April 30, 2013, the Company and Seagate HDD Cayman entered into the Second Amendment to the Credit Agreement which increased the commitments available under the Revolving Credit Facility from $350 million to $500 million. The loans made under the Credit Agreement will bear interest at a rate of LIBOR plus a variable margin that will be determined based on the corporate credit rating of the Company. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility matures in April 2018, and is available for cash borrowings and for the issuance of letters of credit up to a sub-limit of $75 million. As of October 3, 2014, no borrowings had been drawn under the Revolving Credit Facility or had been utilized for letters of credit.
  (was, 2014-04-30, similarity 0.815):
[0001104659-14-032674:note_history:21]
On January 18, 2011, the Company and its subsidiary, Seagate HDD Cayman (“the Borrower”), entered into a Credit Agreement which provided a $350 million senior secured revolving credit facility (the “Revolving Credit Facility”). On April 30, 2013, the Company and Seagate HDD Cayman entered into the Second Amendment to the Credit Agreement which increased the commitments available under the Revolving Credit Facility from $350 million to $500 million. The Company and certain of its material subsidiaries fully and unconditionally guarantee the Revolving Credit Facility. The Revolving Credit Facility matures in April 2018, and is available for cash borrowings and for the issuance of letters of credit up to a sub-limit of $75 million. As of March 28, 2014, no borrowings were drawn under the Revolving Credit Facility, or were utilized for letters of credit.

- changed (2014-11-03):
[0001104659-14-075666:note_history:22]
$600 million Aggregate Principal Amount of 6.8% Senior Notes due October 2016 (the “2016 Notes”). The interest on the 2016 Notes is payable semi-annually on April 1 and October 1 of each year. The issuer under the 2016 Notes is Seagate HDD Cayman, and the obligations under the 2016 Notes are unconditionally guaranteed by certain of the Company’s significant subsidiaries.  During the September 2014 quarter, the Company repurchased $4 million aggregate principal amount of its 2016 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest.  The Company recorded a loss on the repurchase of approximately of $0.5 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.
  (was, 2014-04-30, similarity 0.6586):
[0001104659-14-032674:note_history:22]
$600 million Aggregate Principal Amount of 6.8% Senior Notes due October 2016 (the “2016 Notes”). The interest on the 2016 Notes is payable semi-annually on April 1 and October 1 of each year. The issuer under the 2016 Notes is Seagate HDD Cayman, and the obligations under the 2016 Notes are unconditionally guaranteed by certain of the Company’s significant subsidiaries.

- changed (2014-11-03):
[0001104659-14-075666:note_history:23]
$800 million Aggregate Principal Amount of 3.75% Senior Notes due November 2018 (the “2018 Notes”).  The interest on the 2018 Notes is payable semi-annually on May 15 and November 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2014-04-30, similarity 0.9536):
[0001104659-14-032674:note_history:23]
$750 million Aggregate Principal Amount of 7.75% Senior Notes due December 2018 (the “2018 Notes”). The interest on the 2018 Notes is payable semi-annually on June 15 and December 15 of each year. The issuer under the 2018 Notes is Seagate HDD Cayman and the obligations under the 2018 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2014-11-03):
[0001104659-14-075666:note_history:24]
$600 million Aggregate Principal Amount of 6.875% Senior Notes due May 2020 (the “2020 Notes”). The interest on the 2020 Notes is payable semi-annually on May 1 and November 1 of each year. The issuer under the 2020 Notes is Seagate HDD Cayman, and the obligations under the 2020 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2014 quarter, the Company repurchased $28 million aggregate principal amount of its 2020 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately of $2 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.
  (was, 2014-04-30, similarity 0.9902):
[0001104659-14-032674:note_history:24]
$600 million Aggregate Principal Amount of 6.875% Senior Notes due May 2020 (the “2020 Notes”). The interest on the 2020 Notes is payable semi-annually on May 1 and November 1 of each year. The issuer under the 2020 Notes is Seagate HDD Cayman, and the obligations under the 2020 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the March 2014 quarter, the Company repurchased $28 million aggregate principal amount of its 2020 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately of $3 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

- changed (2014-11-03):
[0001104659-14-075666:note_history:25]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company. During the September 2014 quarter, the Company repurchased $79 million aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately of $11 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.
  (was, 2014-04-30, similarity 0.9499):
[0001104659-14-032674:note_history:25]
$600 million Aggregate Principal Amount of 7.00% Senior Notes due November 2021 (the “2021 Notes”). The interest on the 2021 Notes is payable semi-annually on January 1 and July 1 of each year. The issuer under the 2021 Notes is Seagate HDD Cayman and the obligations under the 2021 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by certain of the Company’s significant subsidiaries. During the March 2014 quarter, the Company repurchased $30 million aggregate principal amount of its 2021 Notes for cash at a premium to their principal amount, plus accrued and unpaid interest. The Company recorded a loss on the repurchase of approximately of $4 million, which is included in Other, net in the Company's Condensed Consolidated Statement of Operations.

- changed (2014-11-03):
[0001104659-14-075666:note_history:26]
$1 billion Aggregate Principal Amount of 4.75%  Senior Notes due June 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.
  (was, 2014-04-30, similarity 0.9972):
[0001104659-14-032674:note_history:26]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due June 1, 2023 (the “2023 Notes”). The interest on the 2023 Notes is payable semi-annually on June 1 and December 1 of each year. The issuer under the 2023 Notes is Seagate HDD Cayman and the obligations under the 2023 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- added (2014-11-03):
[0001104659-14-075666:note_history:27]
$1 billion Aggregate Principal Amount of 4.75% Senior Notes due January 2025 (the “2025 Notes”).  The interest on the Notes is payable in cash semiannually on January 1 and July 1 of each year, commencing on January 1, 2015. The issuer under the 2025 Notes is Seagate HDD Cayman and the obligations under the 2025 Notes are fully and unconditionally guaranteed, on a senior unsecured basis, by the Company.

- changed (2014-11-03):
[0001104659-14-075666:note_history:28]
At October 3, 2014, future principal payments on long-term debt were as follows (in millions):
  (was, 2014-04-30, similarity 0.9432):
[0001104659-14-032674:note_history:28]
At March 28, 2014, future principal payments on long-term debt were as follows (in millions):

- changed (2014-11-03):
[0001104659-14-075666:note_history:29]
| Fiscal Year | Amount |
| Remainder of 2015 | $ | — |  |
| 2016 | — |  |
| 2017 | 331 |  |
| 2018 | — |  |
| 2019 | 800 |  |
| Thereafter | 2,678 |  |
|  | $ | 3,809 |  |
  (was, 2014-04-30, similarity 0.9118):
[0001104659-14-032674:note_history:29]
| Fiscal Year | Amount |
| Remainder of 2014 | $ | — |  |
| 2015 | — |  |
| 2016 | — |  |
| 2017 | 334 |  |
| 2018 | — |  |
| Thereafter | 3,180 |  |
|  | $ | 3,514 |  |

- removed (2014-11-03):
[0001104659-14-032674:note_history:30]
$800 million Aggregate Principal Amount of  3.75% Senior Notes due November 2018 (the “Notes”).  On November 5, 2013, Seagate HDD Cayman, issued $800 million in aggregate principal amount of 3.75% Senior Notes, which mature on November 15, 2018, in a private placement. The interest on the Notes is payable semi-annually on May 15 and November 15 of each year. The Notes are redeemable at the option of Seagate HDD Cayman in whole or in part, on not less than 30, nor more than 60 days' notice, at a “make-whole” premium redemption price. The “make-whole” premium redemption price will be equal to the greater of (1) 100% of the principal amount of the notes being redeemed, or (2) the sum of the present values of the remaining schedule payments of principal and interest on the Notes being redeemed, discounted at the redemption date on a semi-annual basis at a rate equal to the sum of the applicable Treasury rate plus 50 basis points basis points. Accrued and unpaid interest, if any will be paid to, but excluding, the redemption date. The Notes are fully and unconditionally guaranteed by the Company on a senior unsecured basis. Seagate HDD Cayman and the Company are required to exchange the Notes for notes registered under the Securities Act of 1933, as amended, by January 30, 2015 if the Notes have not otherwise become freely transferable by that time.

- removed (2014-11-03):
[0001104659-14-032674:note_history:31]
Other As part of our acquisition of LaCie S.A., $6 million of long-term debt was assumed. The outstanding balance was fully paid off at December 27, 2013.  The outstanding balance at June 28, 2013 was $3 million and was classified as Current portion of long-term debt.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-11-03):
[0001104659-14-075666:note_history:32]
|  |  | October 3, 2014 |  | June 27, 2014 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 6.8% Senior Notes due October 2016 |  | $ | 331 |  |  | $ | 364 |  |  | $ | 335 |  |  | $ | 374 |  |
| 3.75% Senior Notes due November 2018 |  | 800 |  |  | 817 |  |  | 800 |  |  | 820 |  |
| 6.875% Senior Notes due May 2020 |  | 506 |  |  | 537 |  |  | 534 |  |  | 578 |  |
| 7.00% Senior Notes due November 2021 |  | 172 |  |  | 191 |  |  | 251 |  |  | 284 |  |
| 4.75% Senior Notes due June 2023 |  | 1,000 |  |  | 1,027 |  |  | 1,000 |  |  | 1,009 |  |
| 4.75% Senior Notes due January 2025 |  | 1,000 |  |  | 1,012 |  |  | 1,000 |  |  | 995 |  |
| Long-term debt |  | $ | 3,809 |  |  | $ | 3,948 |  |  | $ | 3,920 |  |  | $ | 4,060 |  |

- removed (2014-11-03):
[0001104659-14-032674:note_history:33]
|  |  | March 28, 2014 |  | June 28, 2013 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 6.8% Senior Notes due October 2016 |  | $ | 334 |  |  | $ | 373 |  |  | $ | 335 |  |  | $ | 370 |  |
| 3.75% Senior Notes due November 2018 |  | 800 |  |  | 826 |  |  | — |  |  | — |  |
| 7.75% Senior Notes due December 2018 |  | 238 |  |  | 258 |  |  | 238 |  |  | 259 |  |
| 6.875% Senior Notes due May 2020 |  | 572 |  |  | 621 |  |  | 600 |  |  | 644 |  |
| 7.00% Senior Notes due November 2021 |  | 570 |  |  | 634 |  |  | 600 |  |  | 645 |  |
| 4.75% Senior Notes due June 2023 |  | 1,000 |  |  | 984 |  |  | 1,000 |  |  | 938 |  |
| Other |  | — |  |  | — |  |  | 4 |  |  | 4 |  |
|  |  | 3,514 |  |  | 3,696 |  |  | 2,777 |  |  | 2,860 |  |
| Less short-term borrowings and current portion of long-term debt |  | — |  |  | — |  |  | (3 | ) |  | (3 | ) |
| Long-term debt, less current portion |  | $ | 3,514 |  |  | $ | 3,696 |  |  | $ | 2,774 |  |  | $ | 2,857 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-03):
[0001104659-14-075666:note_history:34]
| Fiscal Year | Amount |
| Remainder of 2015 | $ | — |  |
| 2016 | — |  |
| 2017 | 331 |  |
| 2018 | — |  |
| 2019 | 800 |  |
| Thereafter | 2,678 |  |
|  | $ | 3,809 |  |
  (was, 2014-04-30, similarity 0.9118):
[0001104659-14-032674:note_history:34]
| Fiscal Year | Amount |
| Remainder of 2014 | $ | — |  |
| 2015 | — |  |
| 2016 | — |  |
| 2017 | 334 |  |
| 2018 | — |  |
| Thereafter | 3,180 |  |
|  | $ | 3,514 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2014-11-03):
[0001104659-14-075666:note_history:35]
On October 8, 2014, the Minnesota Supreme Court ruled that the arbitration award in favor of the Company in its case against Western Digital for the misappropriation of the Company trade secrets should be confirmed. In the arbitration award, issued on January 23, 2012, the arbitrator determined that Western Digital and its former employee had misappropriated the Company trade secrets. The arbitrator awarded the Company $525 million in compensatory damages and, after adding interest, issued a final award of approximately $630 million. Interest on the final award has been accruing at 10%.  On October 14, 2014, the Company received a partial payment from Western Digital in the amount of approximately $773 million.

- removed (2014-11-03):
[0001104659-14-032674:note_history:36]
On March 31, 2014, the Company acquired all of the outstanding shares of Xyratex Ltd (“Xyratex”), a leading provider of data storage technology. The Company paid $13.25 per share or approximately $376 million in cash for the acquisition. The acquisition of Xyratex further strengthens the Company's vertically integrated supply and manufacturing chain for disk drives and provides access to important capital requirements, as well as expands the Company's storage solutions portfolio. Because the initial accounting for the acquisition was incomplete at the time this Form 10-Q was filed with the Securities and Exchange Commission, certain disclosures required by ASC Topic 805 — Business Combinations have not been made herein.
