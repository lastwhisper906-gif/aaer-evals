# STX MD&A — 0001104659-14-075666


## mdna

[0001104659-14-075666:mdna:1]
[same as prior period, unchanged from 0001104659-14-032674:mdna:1]

[0001104659-14-075666:mdna:2]
The following is a discussion of the financial condition and results of operations for our fiscal quarters ended October 3, 2014, June 27, 2014, and September 27, 2013, referred to herein as the “September 2014 quarter”, the “June 2014 quarter”, and the “September 2013 quarter”, respectively. Unless the context indicates otherwise, as used herein, the terms “we,” “us,” “Seagate,” the “Company” and “our” refer to Seagate Technology plc, an Irish public limited company, and its subsidiaries. References to “$” are to United States dollars.

[0001104659-14-075666:mdna:3]
You should read this discussion in conjunction with financial information and related notes included elsewhere in this report. We operate and report financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. The September 2014 quarter was 14 weeks, and the June 2014 and September 2013 quarters were both 13 weeks. Except as noted, references to any fiscal year mean the twelve-month period ending on the Friday closest to June 30 of that year.

[0001104659-14-075666:mdna:4]
[same as prior period, unchanged from 0001104659-14-032674:mdna:4]

[0001104659-14-075666:mdna:5]
[same as prior period, unchanged from 0001104659-14-032674:mdna:5]

[0001104659-14-075666:mdna:6]
·                  Overview of the September 2014 quarter. The September 2014 quarter summary.

[0001104659-14-075666:mdna:7]
·                  Results of Operations. An analysis of our financial results comparing the September 2014 quarter to the June 2014 quarter and the September 2013 quarter.

[0001104659-14-075666:mdna:8]
[same as prior period, unchanged from 0001104659-14-032674:mdna:8]

[0001104659-14-075666:mdna:9]
[same as prior period, unchanged from 0001104659-14-032674:mdna:9]

[0001104659-14-075666:mdna:10]
[same as prior period, unchanged from 0001104659-14-032674:mdna:10]

[0001104659-14-075666:mdna:11]
We are a leading provider of electronic data storage solutions.  Our principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs.  Hard disk drives are devices that store digitally encoded data on rapidly rotating disks with magnetic surfaces. Disk drives continue to be the primary medium of mass data storage due to their performance attributes, high quality and cost effectiveness. In addition to HDDs, we produce a broad range of electronic data storage products including solid state hybrid drives (“SSHD”) and solid state drives (“SSD”).

[0001104659-14-075666:mdna:12]
Our products are designed for enterprise servers and storage systems in mission critical and nearline applications; client compute applications, where our products are designed primarily for desktop and mobile computing; and client non-compute applications, where our products are designed for a wide variety of end user devices such as digital video recorders (“DVRs”), personal data backup systems, portable external storage systems and digital media systems.

[0001104659-14-075666:mdna:13]
We continue to make strategic investments in order to expand our storage solutions, enter new market adjacencies, and expand our technical expertise.  As a result of recent acquisitions, our product and solution portfolio for the enterprise data storage industry includes storage enclosures, integrated application platforms and high performance computing (“HPC”) data storage solutions. Our storage subsystems support a range of high-speed interconnect technologies to meet demanding cost and performance specifications. Our modular subsystem architecture allows us to support many segments within the networked storage market by enabling different specifications of storage subsystem designs to be created from a standard set of interlocking technology modules.

[0001104659-14-075666:mdna:14]
In addition to our data storage products and subsystems, we provide data storage services for small to medium-sized businesses, including online backup, data protection and recovery solutions.

[0001104659-14-075666:mdna:15]
Overview of the September 2014 Quarter

[0001104659-14-075666:mdna:16]
During the September 2014 quarter, we shipped 60 million units totaling 60 exabytes, generating revenue of $3,785 million and gross margin of 28%. Our operating cash flow was $602 million.  We repurchased 3.1 million of our ordinary shares for approximately $183 million, paid dividends of $140 million, and paid $124 million for repurchase of debt.  Additionally, we completed our acquisition of certain assets and liabilities of LSI Corporation’s (“LSI”) Accelerated Solutions Division and Flash Components Division (collectively, the “Flash Business”) from Avago Technologies Limited for $450 million in cash.

[0001104659-14-075666:mdna:17]
[same as prior period, unchanged from 0001104659-14-032674:mdna:18]

[0001104659-14-075666:mdna:18]
We list in the table below summarized information from our Condensed Consolidated Statements of Operations by dollars and as a percentage of revenue:

[0001104659-14-075666:mdna:19]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | October 3, 2014 |  | June 27, 2014 |  | September 27, 2013 |  |
| Revenue |  | $ | 3,785 |  | $ | 3,301 |  | $ | 3,489 |  |
| Cost of revenue |  | 2,734 |  | 2,376 |  | 2,514 |  |
| Gross margin |  | 1,051 |  | 925 |  | 975 |  |
| Product development |  | 342 |  | 323 |  | 294 |  |
| Marketing and administrative |  | 216 |  | 161 |  | 181 |  |
| Amortization of intangibles |  | 31 |  | 27 |  | 20 |  |
| Restructuring and other, net |  | 6 |  | 4 |  | 2 |  |
| Income from operations |  | 456 |  | 410 |  | 478 |  |
| Other expense, net |  | (64 | ) | (126 | ) | (38 | ) |
| Income before income taxes |  | 392 |  | 284 |  | 440 |  |
| Provision for (benefit from) income taxes |  | 11 |  | (36 | ) | 13 |  |
| Net income |  | $ | 381 |  | $ | 320 |  | $ | 427 |  |

[0001104659-14-075666:mdna:20]
|  |  | For the Three Months Ended |  |
|  |  | October 3, 2014 |  | June 27, 2014 |  | September 27, 2013 |  |
| Revenue |  | 100 | % | 100 | % | 100 | % |
| Cost of revenue |  | 72 |  | 72 |  | 72 |  |
| Gross margin |  | 28 |  | 28 |  | 28 |  |
| Product development |  | 9 |  | 10 |  | 9 |  |
| Marketing and administrative |  | 6 |  | 5 |  | 5 |  |
| Amortization of intangibles |  | 1 |  | 1 |  | — |  |
| Restructuring and other, net |  | — |  | — |  | — |  |
| Income from operations |  | 12 |  | 12 |  | 14 |  |
| Other expense, net |  | (2 | ) | (3 | ) | (1 | ) |
| Income before income taxes |  | 10 |  | 9 |  | 13 |  |
| Provision for (benefit from) income taxes |  | — |  | (1 | ) | — |  |
| Net income |  | 10 | % | 10 | % | 13 | % |

[0001104659-14-075666:mdna:21]
[same as prior period, unchanged from 0001104659-14-032674:mdna:13]

[0001104659-14-075666:mdna:22]
[same as prior period, unchanged from 0001104659-14-032674:mdna:23]

[0001104659-14-075666:mdna:23]
The following table summarizes information regarding revenue, volume shipments, exabytes shipped, average selling prices (“ASPs”) and revenues by channel and geography:

[0001104659-14-075666:mdna:24]
|  |  | For the Three Months Ended |  |
| (In millions, except percentages, exabytes and ASPs) |  | October 3, 2014 |  | June 27, 2014 |  | September 27, 2013 |  |
| Net Revenue |  | $ | 3,785 |  | $ | 3,301 |  | $ | 3,489 |  |
| Unit Shipments: |  |  |  |  |  |  |  |
| Enterprise |  | 9 |  | 7 |  | 8 |  |
| Client Compute |  | 39 |  | 36 |  | 36 |  |
| Client Non-Compute |  | 12 |  | 9 |  | 12 |  |
| Total Units Shipped |  | 60 |  | 52 |  | 56 |  |
| ASPs (per unit) |  | $ | 60 |  | $ | 60 |  | $ | 62 |  |
| Exabytes Shipped |  | 60 |  | 50 |  | 49 |  |
| Revenues by Channel (%) |  |  |  |  |  |  |  |
| OEMs |  | 70 | % | 70 | % | 68 | % |
| Distributors |  | 18 | % | 19 | % | 21 | % |
| Retailers |  | 12 | % | 11 | % | 11 | % |
| Revenues by Geography (%) |  |  |  |  |  |  |  |
| Americas |  | 27 | % | 27 | % | 29 | % |
| EMEA |  | 17 | % | 17 | % | 18 | % |
| Asia Pacific |  | 56 | % | 56 | % | 53 | % |

[0001104659-14-075666:mdna:25]
Revenue in the September 2014 quarter increased by $0.5 billion and $0.3 billion compared to the June 2014 quarter and September 2013 quarter, respectively, as a result of an increase in shipments, partially offset by price erosion.

[0001104659-14-075666:mdna:26]
We maintain various sales programs such as point-of-sale rebates, sales price adjustments and price protection, aimed at increasing customer demand. Sales programs were approximately 9.2%, 8.1% and 7.8% of gross revenue for the September 2014 quarter, June 2014 quarter and September 2013 quarter, respectively. Adjustments to revenues due to under or over accruals for sales programs related to revenues reported in prior quarterly periods was 0.1% of quarterly gross revenue in the September 2014 quarter.

[0001104659-14-075666:mdna:27]
[same as prior period, unchanged from 0001104659-14-032674:mdna:30]

[0001104659-14-075666:mdna:28]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | October 3, 2014 |  | June 27, 2014 |  | September 27, 2013 |  |
| Cost of revenue |  | $ | 2,734 |  | $ | 2,376 |  | $ | 2,514 |  |
| Gross margin |  | 1,051 |  | 925 |  | 975 |  |
| Gross margin percentage |  | 28 | % | 28 | % | 28 | % |

[0001104659-14-075666:mdna:29]
Gross margin as a percentage of revenue for the September 2014 quarter was relatively flat when compared to the June 2014 quarter and September 2013 quarter. These margins reflect an environment where price erosion is offset by improved product mix.

[0001104659-14-075666:mdna:30]
In the September 2014 quarter, total warranty cost was 1.2% of revenue and net of unfavorable changes in estimates of prior warranty accruals of approximately 0.2% of revenue.  Warranty cost related to new shipments was 1.1%, 1.4%, and 1.4% of revenue for the September 2014 quarter, June 2014 quarter and September 2013 quarter, respectively.

[0001104659-14-075666:mdna:31]
[same as prior period, unchanged from 0001104659-14-032674:mdna:21]

[0001104659-14-075666:mdna:32]
[same as prior period, unchanged from 0001104659-14-032674:mdna:34]

[0001104659-14-075666:mdna:33]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | October 3, 2014 |  | June 27, 2014 |  | September 27, 2013 |  |
| Product development |  | $ | 342 |  | $ | 323 |  | $ | 294 |  |
| Marketing and administrative |  | 216 |  | 161 |  | 181 |  |
| Amortization of intangibles |  | 31 |  | 27 |  | 20 |  |
| Restructuring and other, net |  | 6 |  | 4 |  | 2 |  |
| Operating expenses |  | $ | 595 |  | $ | 515 |  | $ | 497 |  |

[0001104659-14-075666:mdna:34]
Product development expense.  Product development expense for the September 2014 quarter increased by $19 million, or 6% when compared to the June 2014 quarter. The increase was due to additional expenses related to a 14-week September 2014 quarter and expenses attributed to LSI’s Flash Business of $14 million. Compared to the September 2013 quarter, Product development expense increased by $48 million or 16%. The increase was due to an increase in headcount related costs of $24 million, additional expenses related to a 14-week September 2014 quarter and expenses attributed to LSI’s Flash Business of $14 million.

[0001104659-14-075666:mdna:35]
Marketing and administrative expense. Marketing and administrative expense for the September 2014 quarter increased by $55 million or 34% when compared to the June 2014 quarter. The increase was attributable to a non-recurring legal cost reimbursement received in the June 2014 quarter of $24 million, performance based compensation and headcount related expense as well as additional expenses due to a 14-week September 2014 quarter. Compared to the September 2013 quarter, Marketing and administrative expense increased by $35 million, or 19%, which was primarily due to an increase in performance based compensation and headcount related expense and additional expenses due to a 14-week September 2014 quarter.

[0001104659-14-075666:mdna:36]
Amortization of intangibles. Amortization of intangibles for the September 2014 quarter increased by $4 million or 15%, when compared to the June 2014 quarter as a result of the acquisition of LSI’s Flash Business and additional expenses due to a 14-week September 2014 quarter. Compared to the September 2013 quarter, Amortization of intangibles increased by $11 million or 55%, which was primarily due to the completion of in-process research and development and commencement of the related amortization in the December 2013 quarter and additional expense due to a 14-week September 2014 quarter.

[0001104659-14-075666:mdna:37]
Restructuring and Other, net. Restructuring and other, net for the September 2014 quarter increased due to a reduction in work force as a result of our ongoing focus on cost efficiencies in all areas of our business.

[0001104659-14-075666:mdna:38]
[same as prior period, unchanged from 0001104659-14-032674:mdna:43]

[0001104659-14-075666:mdna:39]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | October 3, 2014 |  | June 27, 2014 |  | September 27, 2013 |  |
| Other expense, net |  | $ | (64 | ) | $ | (126 | ) | $ | (38 | ) |

[0001104659-14-075666:mdna:40]
Other expense, net decreased by $62 million during the September 2014 quarter compared to the June 2014 quarter primarily due to a $61 million decrease in losses from the early redemption and repurchase of debt. Compared to the September 2013 quarter, Other expense, net increased by $26 million due to an increase of $14 million in losses from repurchase of debt and $11 million in interest expense attributable to an increase in the outstanding debt balance, partially offset by a reduction in the average interest rate in the September 2014 quarter.

[0001104659-14-075666:mdna:41]
[same as prior period, unchanged from 0001104659-14-032674:mdna:47]

[0001104659-14-075666:mdna:42]
|  |  | For the Three Months Ended |  |
| (Dollars in millions) |  | October 3, 2014 |  | June 27, 2014 |  | September 27, 2013 |  |
| Provision for (benefit from) income taxes |  | $ | 11 |  | $ | (36 | ) | $ | 13 |  |

[0001104659-14-075666:mdna:43]
Our income tax provision recorded for the September 2014 quarter included approximately $2 million net discrete tax benefits primarily associated with the release of tax reserves associated with the expiration of certain statutes of limitation. The income tax benefit in the fourth quarter of fiscal year 2014 was primarily associated with the reversal of a portion of the U.S. and non-U.S. valuation allowances recorded in prior periods.

[0001104659-14-075666:mdna:44]
Our income tax provision recorded for the September 2014 quarter differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets. The acquisition of LSI’s Flash Business is not expected to have a material impact on our effective tax rate in fiscal year 2015.

[0001104659-14-075666:mdna:45]
29

[0001104659-14-075666:mdna:46]
During the three months ended October 3, 2014, our unrecognized tax benefits excluding interest and penalties decreased by approximately $1 million to $114 million. The unrecognized tax benefits that, if recognized, would impact the effective tax rate was $114 million at October 3, 2014, subject to certain future valuation allowance reversals. During the 12 months beginning October 4, 2014, we expect that our unrecognized tax benefits could be reduced anywhere from $3 million to $50 million as a result of audit settlements and the expiration of certain statutes of limitation.

[0001104659-14-075666:mdna:47]
We are subject to taxation in many jurisdictions globally and are required to file U.S. federal, U.S. state, and non-U.S income tax returns. In June 2014, we received the Revenue Agent’s Report and Notices of Proposed Adjustments for our U.S. federal income tax returns for fiscal years 2008, 2009 and 2010. Our China subsidiaries are under examination by the Chinese tax administration for years 2004 through 2012. These examinations may result in proposed adjustments to our income taxes as filed during these periods. We believe that we have adequately provided for these matters, but there is a reasonable possibility that an adverse outcome of these examinations could have a material effect on our financial results. In this case, we would consider pursuing all possible remedies available to us, including appeals, judicial review and competent authority.

[0001104659-14-075666:mdna:48]
Our income tax provision recorded for the September 2013 quarter included approximately $3 million of net discrete tax expense primarily associated with enacted tax legislation.

[0001104659-14-075666:mdna:49]
Our income tax provision for the September 2013 quarter differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) tax benefits related to non-U.S. earnings generated in jurisdictions that are subject to tax holidays or tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) a decrease in valuation allowance for certain U.S. deferred tax assets.

[0001104659-14-075666:mdna:50]
[same as prior period, unchanged from 0001104659-14-032674:mdna:57]

[0001104659-14-075666:mdna:51]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. Our short-term investments consist of readily marketable securities with remaining maturities of more than 90 days at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We intend to maintain a highly liquid portfolio by investing only in those marketable securities that we believe have active secondary or resale markets. We believe our cash equivalents and short-term investments are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, these restrictions have not impeded our ability to conduct our business, nor do we expect them to in the next 12 months. We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents or short-term investments and accordingly, we do not believe the fair value of our short-term investments has significantly changed from the values reported as of October 3, 2014.

[0001104659-14-075666:mdna:52]
[same as prior period, unchanged from 0001104659-14-032674:mdna:59]

[0001104659-14-075666:mdna:53]
| (Dollars in millions) |  | October 3, 2014 |  | June 27, 2014 |  | Change |  |
| Cash and cash equivalents |  | $ | 2,190 |  | $ | 2,634 |  | $ | (444 | ) |
| Short-term investments |  | 11 |  | 20 |  | (9 | ) |
| Restricted cash and investments |  | 4 |  | 4 |  | — |  |
| Total |  | $ | 2,205 |  | $ | 2,658 |  | $ | (453 | ) |

[0001104659-14-075666:mdna:54]
Our cash and cash equivalents, short-term investments and restricted cash and investments decreased from June 27, 2014 as a result of the early redemption and repayments of long-term debt, repurchase of our ordinary shares, dividends paid to our shareholders, capital expenditures, and the acquisition of LSI’s Flash Business partially offset by cash provided by our operating activities.

[0001104659-14-075666:mdna:55]
[same as prior period, unchanged from 0001104659-14-032674:mdna:62]

[0001104659-14-075666:mdna:56]
Cash provided by operating activities for the three months ended October 3, 2014 of $602 million includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, and:

[0001104659-14-075666:mdna:57]
·                  an increase of $179 million in accounts receivable, net, primarily due to an increase in revenues; and

[0001104659-14-075666:mdna:58]
·                  an increase of $183 million in accounts payable due to increased direct materials purchases primarily due to an increase in drives manufactured.

[0001104659-14-075666:mdna:59]
[same as prior period, unchanged from 0001104659-14-032674:mdna:68]

[0001104659-14-075666:mdna:60]
Cash used for investing activities for the three months ended October 3, 2014 was $619 million which includes $172 million for payments for acquired property, equipment and leasehold improvements and $450 million used for the acquisition of LSI’s Flash Business.

[0001104659-14-075666:mdna:61]
[same as prior period, unchanged from 0001104659-14-032674:mdna:70]

[0001104659-14-075666:mdna:62]
Net cash used in financing activities of $420 million for the three months ended October 3, 2014 was primarily attributable to approximately $183 million paid to repurchase ordinary shares, $140 million in dividend payments, and $124 million of repayments of long-term debt, partially offset by $39 million received from issuance of ordinary shares.

[0001104659-14-075666:mdna:63]
[same as prior period, unchanged from 0001104659-14-032674:mdna:72]

[0001104659-14-075666:mdna:64]
Our primary sources of liquidity as of October 3, 2014 consisted of: (1) approximately $2.2 billion in cash, cash equivalents, and short-term investments, (2) cash we expect to generate from operations and (3) a $500 million senior revolving credit facility.

[0001104659-14-075666:mdna:65]
As of October 3, 2014, no borrowings have been drawn under the revolving credit facility or had been utilized for letters of credit. The line of credit is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowings.

[0001104659-14-075666:mdna:66]
The credit agreement that governs our revolving credit facility, as amended, contains certain covenants that we must satisfy in order to remain in compliance with the credit agreement, as amended. The agreement also includes three financial covenants: (1) minimum cash, cash equivalents and marketable securities; (2) a fixed charge coverage ratio; and (3) a net leverage ratio. As of October 3, 2014, we were in compliance with all of the covenants under our Revolving Credit Facility and debt agreements. Based on our current outlook, we expect to be in compliance with the covenants of our debt agreements over the next 12 months.

[0001104659-14-075666:mdna:67]
[same as prior period, unchanged from 0001104659-14-032674:mdna:76]

[0001104659-14-075666:mdna:68]
For fiscal year 2015, we expect capital expenditures to be within our long-term targeted range of 6% to 8% of revenue.

[0001104659-14-075666:mdna:69]
From time to time we may repurchase any of our outstanding notes in open market or privately negotiated purchases or otherwise, or may repurchase outstanding notes pursuant to the terms of the applicable indenture.

[0001104659-14-075666:mdna:70]
On October 22, 2014, the Company announced that its Board of Directors has approved cash dividend of $0.54 scheduled to be paid on November 25, 2014 to stockholders of record as of the close of business on November 11, 2014.

[0001104659-14-075666:mdna:71]
From time to time we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases.  As of October 3, 2014, $1.3 billion remained available for repurchase under our existing repurchase authorization limit.  All repurchases are effected as redemptions in accordance with the Company’s Articles of Association.

[0001104659-14-075666:mdna:72]
On October 8, 2014, the Minnesota Supreme Court ruled that the arbitration award in favor of Seagate in the company’s case against Western Digital for the misappropriation of Seagate trade secrets should be confirmed. In the arbitration award, issued on January 23, 2012, the arbitrator determined that Western Digital and its former employee had misappropriated Seagate trade secrets. The arbitrator awarded Seagate $525 million in compensatory damages and, after adding interest, issued a final award of approximately $630 million. Interest on the final award has been accruing at 10%.  On October 14, 2014, Seagate received a partial payment from Western Digital in the amount of approximately $773 million.

[0001104659-14-075666:mdna:73]
[same as prior period, unchanged from 0001104659-14-032674:mdna:82]

[0001104659-14-075666:mdna:74]
Our discussion and analysis of financial condition and results of operations are based upon our Condensed Consolidated Financial Statements, which have been prepared in accordance with U.S. generally accepted accounting principles. The preparation of such statements requires us to make estimates and assumptions that affect the reported amounts of revenues and expenses during the reporting period and the reported amounts of assets and liabilities as of the date of the financial statements. Our estimates are based on historical experience and other assumptions that we consider to be appropriate in the circumstances. However, actual future results may vary from our estimates.

[0001104659-14-075666:mdna:75]
31

[0001104659-14-075666:mdna:76]
Since our fiscal year ended June 27, 2014, there have been no material changes in our critical accounting policies and estimates. Refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended June 27, 2014, as filed with the SEC on August 7, 2014, for a discussion of our critical accounting policies and estimates.

[0001104659-14-075666:mdna:77]
[same as prior period, unchanged from 0001104659-14-032674:mdna:85]

[0001104659-14-075666:mdna:78]
[same as prior period, unchanged from 0001104659-14-032674:mdna:86]
