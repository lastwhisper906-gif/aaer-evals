# STX 8-K — 0001137789-25-000150 filed 2025-07-30

## item codes, every 8-K on or before 2025-08-01

- 2025-07-30 0001137789-25-000150 — 2.02, 7.01, 9.01
- 2025-07-29 0001137789-25-000148 — 2.02, 7.01, 9.01
- 2025-07-28 0001137789-25-000145 — 8.01, 9.01
- 2025-06-30 0001193125-25-152915 — 1.01, 2.03, 7.01, 9.01
- 2025-06-16 0001193125-25-141454 — 1.02, 2.04, 8.01, 9.01
- 2025-05-28 0001193125-25-129583 — 1.01, 2.03, 8.01, 9.01
- 2025-05-22 0001137789-25-000084 — 8.01
- 2025-05-13 0001193125-25-118923 — 1.01, 8.01, 9.01
- 2025-05-12 0001193125-25-117310 — 8.01, 9.01
- 2025-05-08 0001137789-25-000078 — 5.02
- 2025-04-29 0001137789-25-000070 — 2.02, 7.01, 9.01
- 2025-02-03 0001137789-25-000023 — 1.01, 1.02, 2.03, 9.01
- 2025-01-21 0001137789-25-000006 — 2.02, 7.01, 9.01
- 2024-12-03 0001137789-24-000194 — 7.01
- 2024-10-22 0001137789-24-000141 — 2.02, 7.01, 9.01
- 2024-10-22 0001137789-24-000138 — 5.07
- 2024-08-29 0001137789-24-000074 — 5.02
- 2024-07-23 0001137789-24-000061 — 2.02, 7.01, 9.01
- 2024-04-25 0001193125-24-114027 — 5.02, 9.01
- 2024-04-23 0001193125-24-107068 — 1.01
- 2024-04-23 0001137789-24-000030 — 2.02, 7.01, 9.01
- 2024-04-16 0001193125-24-097742 — 7.01
- 2024-01-24 0001137789-24-000004 — 2.02, 7.01, 9.01
- 2024-01-02 0001193125-24-000688 — 5.02
- 2023-10-26 0001137789-23-000125 — 2.02, 7.01, 9.01
- 2023-10-25 0001137789-23-000098 — 5.07, 9.01
- 2023-09-27 0001137789-23-000096 — 1.01
- 2023-09-13 0001193125-23-234372 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2023-09-08 0001193125-23-231165 — 1.01, 8.01, 9.01
- 2023-07-26 0001137789-23-000045 — 2.02, 7.01, 9.01
- 2023-07-24 0001193125-23-192237 — 5.02
- 2023-05-30 0001137789-23-000039 — 1.01, 2.03, 9.01
- 2023-05-25 0001137789-23-000035 — 1.01, 8.01, 9.01
- 2023-05-22 0001137789-23-000032 — 1.01, 2.03
- 2023-04-20 0001137789-23-000025 — 2.02, 2.05, 5.02, 7.01, 9.01
- 2023-04-19 0001193125-23-106624 — 1.01, 2.02, 9.01
- 2023-03-29 0001137789-23-000021 — 2.05, 5.02
- 2023-01-25 0001137789-23-000007 — 2.02, 7.01, 9.01
- 2022-11-30 0001193125-22-295386 — 1.01, 2.03, 8.01, 9.01
- 2022-11-15 0001137789-22-000137 — 8.01
- 2022-11-09 0001137789-22-000129 — 5.02, 9.01
- 2022-11-08 0001193125-22-280194 — 1.01, 2.03
- 2022-10-26 0001137789-22-000118 — 8.01, 9.01
- 2022-10-26 0001137789-22-000116 — 2.02, 2.05, 7.01, 9.01
- 2022-10-25 0001193125-22-268425 — 5.02, 9.01 — amendment of 0001193125-22-228640
- 2022-10-25 0001193125-22-268417 — 5.07, 9.01
- 2022-08-31 0001137789-22-000062 — 7.01, 9.01
- 2022-08-24 0001193125-22-228640 — 5.02, 9.01
- 2022-08-19 0001193125-22-225260 — 1.01, 2.03
- 2022-07-21 0001137789-22-000039 — 2.02, 7.01, 9.01
- 2022-04-27 0001137789-22-000028 — 2.02, 7.01, 9.01
- 2022-03-30 0001193125-22-089760 — 5.02
- 2022-02-24 0001193125-22-052046 — 5.02
- 2022-01-26 0001137789-22-000008 — 2.02, 7.01, 9.01
- 2022-01-25 0001193125-22-017071 — 5.02, 9.01
- 2021-10-26 0001193125-21-307931 — 5.07
- 2021-10-22 0001137789-21-000105 — 2.02, 7.01, 9.01
- 2021-10-15 0001193125-21-299005 — 1.01, 2.03
- 2021-07-21 0001137789-21-000041 — 2.02, 7.01, 9.01
- 2021-06-08 0001137789-21-000033 — 7.01, 9.01
- 2021-05-19 0001193125-21-165970 — 1.01, 2.03, 3.01, 3.03, 5.02, 5.03, 8.01, 9.01
- 2021-04-22 0001137789-21-000023 — 2.02, 7.01, 9.01
- 2021-04-16 0001193125-21-119304 — 5.07
- 2021-03-22 0001193125-21-089557 — 5.02, 9.01
- 2021-01-21 0001137789-21-000003 — 2.02, 7.01, 9.01
- 2021-01-13 0001193125-21-008148 — 1.01, 2.03
- 2020-12-28 0001193125-20-327026 — 5.02, 9.01
- 2020-12-09 0001193125-20-313800 — 1.01, 2.03, 9.01
- 2020-12-04 0001193125-20-310713 — 1.01, 8.01, 9.01
- 2020-10-28 0001193125-20-279868 — 5.07
- 2020-10-22 0001137789-20-000098 — 2.02, 7.01, 9.01
- 2020-07-28 0001137789-20-000055 — 2.02, 7.01, 9.01
- 2020-07-02 0001193125-20-186902 — 8.01, 9.01
- 2020-06-18 0001193125-20-172622 — 1.01, 2.03, 8.01, 9.01
- 2020-06-11 0001193125-20-166696 — 1.01, 2.03, 9.01
- 2020-06-04 0001193125-20-160796 — 1.01, 8.01, 9.01
- 2020-06-03 0001193125-20-159172 — 7.01, 8.01, 9.01
- 2020-06-02 0001193125-20-157932 — 2.05
- 2020-05-11 0001193125-20-139025 — 8.01
- 2020-04-22 0001137789-20-000028 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001137789-20-000013 — 2.02, 7.01, 9.01
- 2019-11-04 0001193125-19-283563 — 5.02, 5.07, 9.01
- 2019-11-01 0001628280-19-013012 — 2.02, 7.01, 9.01
- 2019-09-19 0001193125-19-248970 — 1.01, 2.03, 8.01, 9.01
- 2019-09-18 0001193125-19-247385 — 7.01, 9.01
- 2019-09-04 0001193125-19-237150 — 8.01, 9.01
- 2019-08-02 0001193125-19-211505 — 2.02, 7.01, 9.01
- 2019-06-26 0001193125-19-182712 — 5.02
- 2019-06-18 0001193125-19-175303 — 8.01
- 2019-04-30 0001193125-19-129480 — 5.07
- 2019-04-30 0001193125-19-127378 — 2.02, 7.01, 9.01
- 2019-02-20 0001193125-19-045470 — 1.01, 2.03
- 2019-02-04 0001193125-19-027004 — 2.02, 7.01, 9.01
- 2018-12-21 0001193125-18-356446 — 5.02, 9.01
- 2018-11-02 0001193125-18-316430 — 5.07, 8.01, 9.01
- 2018-11-02 0001193125-18-316418 — 2.02, 7.01, 9.01
- 2018-09-07 0001193125-18-268679 — 5.02 — amendment of 0001193125-18-230467
- 2018-07-30 0001193125-18-230467 — 5.02, 9.01
- 2018-07-30 0001193125-18-230452 — 2.02, 7.01, 9.01
- 2018-07-26 0001193125-18-226626 — 5.02
- 2018-06-01 0001193125-18-181093 — 8.01, 9.01
- 2018-05-01 0001193125-18-145112 — 2.02, 7.01, 9.01
- 2018-01-29 0001193125-18-022528 — 2.02, 7.01, 9.01
- 2018-01-25 0001193125-18-019820 — 5.02, 9.01
- 2018-01-09 0001137789-18-000009 — 2.02, 7.01, 9.01
- 2018-01-08 0001137789-18-000004 — 2.02, 7.01, 9.01
- 2017-12-11 0001137789-17-000101 — 2.05
- 2017-10-23 0001193125-17-316068 — 2.02, 7.01, 9.01
- 2017-10-18 0001137789-17-000068 — 5.02, 5.07, 9.01
- 2017-09-28 0001137789-17-000060 — 1.01
- 2017-07-28 0001137789-17-000046 — 5.02
- 2017-07-25 0001193125-17-234440 — 2.02, 2.05, 5.02, 7.01, 9.01
- 2017-06-02 0001193125-17-192960 — 5.02
- 2017-04-26 0001193125-17-138005 — 2.02, 7.01, 9.01
- 2017-03-10 0001193125-17-077510 — 2.05
- 2017-02-03 0001104659-17-006357 — 1.01, 2.03, 9.01
- 2017-01-31 0001104659-17-005357 — 8.01, 9.01
- 2017-01-31 0001104659-17-005173 — 8.01, 9.01
- 2017-01-27 0001104659-17-004448 — 8.01
- 2017-01-24 0001193125-17-016690 — 2.02, 7.01, 9.01
- 2017-01-20 0001193125-17-013685 — 5.02, 9.01
- 2016-10-24 0001104659-16-151422 — 5.02, 5.03, 5.07, 9.01
- 2016-10-19 0001193125-16-741277 — 2.02, 7.01, 9.01
- 2016-10-11 0001193125-16-734835 — 2.02, 9.01
- 2016-10-04 0001104659-16-148575 — 5.02
- 2016-09-27 0001104659-16-146813 — 5.02
- 2016-08-02 0001104659-16-135908 — 2.02, 7.01, 9.01
- 2016-07-28 0001104659-16-135046 — 5.02
- 2016-07-11 0001104659-16-131996 — 2.02, 2.05, 9.01
- 2016-07-08 0001104659-16-131749 — 5.02
- 2016-06-29 0001104659-16-130122 — 2.05
- 2016-06-27 0001104659-16-129505 — 5.02
- 2016-04-29 0001104659-16-115593 — 2.02, 7.01, 9.01
- 2016-04-13 0001104659-16-111266 — 2.02, 9.01
- 2016-01-29 0001104659-16-092323 — 2.02, 7.01, 9.01
- 2016-01-04 0001104659-16-087730 — 5.02, 9.01
- 2015-10-30 0001104659-15-074350 — 2.02, 7.01, 9.01
- 2015-10-21 0001104659-15-071908 — 5.02, 9.01
- 2015-10-21 0001104659-15-071906 — 5.07, 7.01, 9.01
- 2015-10-15 0001104659-15-070776 — 2.02, 9.01
- 2015-09-21 0001104659-15-066273 — 5.02
- 2015-09-10 0001104659-15-064389 — 2.05
- 2015-08-06 0001104659-15-057159 — 5.02
- 2015-07-31 0001104659-15-055040 — 2.02, 7.01, 9.01
- 2015-07-22 0001104659-15-052507 — 5.02, 9.01
- 2015-07-13 0001104659-15-050755 — 2.02, 9.01
- 2015-05-14 0001104659-15-038166 — 1.01, 2.03, 9.01
- 2015-05-12 0001104659-15-036968 — 8.01, 9.01
- 2015-05-11 0001104659-15-036533 — 8.01, 9.01
- 2015-05-01 0001104659-15-033202 — 5.02
- 2015-04-23 0001104659-15-029483 — 8.01, 9.01
- 2015-04-17 0001104659-15-028152 — 2.02, 7.01, 9.01
- 2015-04-07 0001104659-15-026148 — 7.01
- 2015-01-26 0001104659-15-004316 — 2.02, 7.01, 9.01
- 2015-01-16 0001104659-15-002732 — 1.01, 9.01
- 2015-01-02 0001104659-15-000147 — 8.01
- 2014-12-02 0001104659-14-084370 — 1.01, 2.03, 9.01
- 2014-11-25 0001104659-14-083066 — 8.01, 9.01
- 2014-11-24 0001104659-14-082837 — 8.01, 9.01
- 2014-10-27 0001104659-14-073832 — 2.02, 7.01, 9.01
- 2014-10-24 0001104659-14-073609 — 5.02, 5.07, 9.01
- 2014-10-22 0001104659-14-073104 — 7.01, 9.01
- 2014-10-08 0001104659-14-070767 — 8.01
- 2014-09-12 0001104659-14-066107 — 5.02
- 2014-09-12 0001104659-14-066101 — 7.01
- 2014-07-23 0001104659-14-052995 — 5.02
- 2014-07-17 0001104659-14-052019 — 2.02, 7.01, 9.01
- 2014-06-18 0001104659-14-046714 — 8.01, 9.01
- 2014-06-09 0001104659-14-044575 — 7.01
- 2014-06-04 0001104659-14-043897 — 8.01
- 2014-05-28 0001104659-14-041862 — 1.01, 2.03, 8.01, 9.01
- 2014-05-20 0001104659-14-040454 — 8.01, 9.01
- 2014-05-20 0001104659-14-040220 — 8.01, 9.01
- 2014-04-29 0001104659-14-031916 — 2.02, 7.01, 9.01
- 2014-04-22 0001104659-14-029197 — 5.02
- 2014-02-24 0001104659-14-012465 — 5.02, 7.01, 9.01
- 2014-01-27 0001104659-14-004298 — 2.02, 7.01, 9.01
- 2014-01-23 0001104659-14-003803 — 5.02
- 2013-12-23 0001104659-13-091738 — 1.01, 8.01, 9.01
- 2013-11-05 0001104659-13-081194 — 1.01, 2.03, 9.01
- 2013-11-04 0001104659-13-080161 — 5.02, 5.03, 5.07, 9.01
- 2013-10-31 0001104659-13-079635 — 8.01, 9.01
- 2013-10-31 0001104659-13-079438 — 8.01, 9.01
- 2013-10-28 0001104659-13-078341 — 2.02, 7.01, 9.01
- 2013-10-28 0001104659-13-078316 — 5.02, 7.01, 9.01
- 2013-10-08 0001104659-13-074454 — 1.01, 1.02, 9.01
- 2013-09-20 0001104659-13-071413 — 5.02
- 2013-07-24 0001104659-13-056053 — 5.02, 7.01
- 2013-07-24 0001104659-13-056052 — 2.02, 7.01, 9.01
- 2013-06-14 0001104659-13-049436 — 8.01, 9.01
- 2013-05-31 0001104659-13-045928 — 8.01, 9.01
- 2013-05-22 0001104659-13-043876 — 1.01, 2.03, 9.01
- 2013-05-16 0001104659-13-042180 — 7.01, 9.01
- 2013-05-15 0001104659-13-042028 — 8.01, 9.01
- 2013-05-15 0001104659-13-041695 — 8.01, 9.01
- 2013-05-07 0001104659-13-038226 — 5.02
- 2013-05-01 0001104659-13-036004 — 2.02, 9.01
- 2013-03-15 0001104659-13-021156 — 7.01
- 2013-01-28 0001104659-13-005180 — 2.02, 9.01
- 2013-01-08 0001104659-13-001291 — 2.02, 9.01
- 2012-11-29 0001104659-12-080911 — 8.01, 9.01
- 2012-10-31 0001104659-12-072476 — 2.02, 9.01
- 2012-10-25 0001104659-12-071208 — 5.07
- 2012-10-16 0001104659-12-069238 — 7.01
- 2012-09-28 0001104659-12-066105 — 7.01
- 2012-09-21 0001104659-12-064869 — 7.01
- 2012-08-02 0001104659-12-053775 — 5.02
- 2012-07-30 0001104659-12-052298 — 2.02, 5.02, 8.01, 9.01
- 2012-07-05 0001104659-12-047737 — 2.02, 9.01
- 2012-04-26 0001104659-12-029099 — 5.02, 8.01, 9.01
- 2012-04-17 0001104659-12-025931 — 2.02, 9.01
- 2012-01-31 0001104659-12-005522 — 2.02, 9.01
- 2012-01-27 0001104659-12-004299 — 8.01, 9.01
- 2012-01-04 0001104659-12-000411 — 2.02, 9.01
- 2011-12-20 0001104659-11-070207 — 2.01, 3.02, 9.01
- 2011-12-12 0001104659-11-069005 — 8.01
- 2011-12-05 0001104659-11-067679 — 5.02, 9.01
- 2011-11-29 0001104659-11-066436 — 7.01, 9.01
- 2011-11-22 0001104659-11-065589 — 7.01, 9.01
- 2011-11-03 0001104659-11-060307 — 7.01
- 2011-10-21 0001104659-11-056997 — 2.02, 8.01, 9.01
- 2011-10-12 0001104659-11-055849 — 7.01, 9.01
- 2011-07-29 0001104659-11-041897 — 5.02
- 2011-07-20 0001104659-11-039922 — 2.02, 9.01
- 2011-06-01 0001104659-11-032473 — 8.01
- 2011-05-23 0001104659-11-030867 — 8.01
- 2011-05-18 0001104659-11-029869 — 1.01, 2.03, 9.01
- 2011-05-04 0001104659-11-025801 — 8.01, 9.01
- 2011-05-04 0001104659-11-025462 — 8.01, 9.01
- 2011-04-19 0001104659-11-020787 — 1.01, 2.02, 3.02, 9.01
- 2011-04-08 0001104659-11-019316 — 5.02, 9.01
- 2011-04-07 0001104659-11-019141 — 2.02, 8.01, 9.01
- 2011-03-09 0001104659-11-013084 — 5.02
- 2011-02-18 0001104659-11-008419 — 8.01
- 2011-02-01 0001104659-11-004106 — 5.02, 9.01
- 2011-01-19 0001104659-11-002037 — 1.01, 2.02, 2.03, 5.07, 9.01
- 2010-12-14 0001104659-10-062647 — 1.01, 2.03, 9.01
- 2010-12-08 0001104659-10-061747 — 8.01, 9.01
- 2010-12-08 0001104659-10-061643 — 7.01, 8.01, 9.01
- 2010-11-29 0001104659-10-060338 — 7.01, 9.01
- 2010-10-20 0001104659-10-052966 — 2.02, 9.01
- 2010-10-15 0001104659-10-052362 — 8.01, 9.01
- 2010-09-13 0001104659-10-048317 — 5.02, 9.01
- 2010-08-16 0001104659-10-044431 — 5.02
- 2010-07-29 0001104659-10-040519 — 5.02, 9.01
- 2010-07-20 0001104659-10-038670 — 2.02, 9.01
- 2010-07-06 0001104659-10-036996 — 1.01, 2.03, 3.01, 3.03, 5.01, 5.02, 8.01, 9.01
- 2010-06-25 0001104659-10-035630 — 8.01, 9.01
- 2010-05-26 0001104659-10-030931 — 5.02
- 2010-05-14 0001104659-10-028664 — 1.01, 2.03, 9.01
- 2010-04-30 0001104659-10-023493 — 8.01, 9.01
- 2010-04-29 0001104659-10-022773 — 1.02, 8.01, 9.01
- 2010-04-20 0001104659-10-020750 — 2.02, 9.01
- 2010-04-16 0001104659-10-020113 — 5.07
- 2010-03-22 0001104659-10-015668 — 1.01, 9.01
- 2010-03-03 0001104659-10-011870 — 1.01, 2.03, 9.01
- 2010-01-20 0001104659-10-002269 — 2.02, 9.01
- 2009-10-29 0001104659-09-060949 — 5.02, 7.01
- 2009-10-20 0001104659-09-059594 — 2.02, 9.01
- 2009-10-01 0001104659-09-057311 — 1.01, 2.03, 2.06, 9.01
- 2009-09-22 0001104659-09-055716 — 7.01, 9.01
- 2009-08-04 0001193125-09-163032 — 2.05
- 2009-07-31 0001193125-09-160678 — 5.02, 9.01
- 2009-07-21 0001193125-09-152269 — 2.02, 9.01
- 2009-07-09 0001193125-09-146452 — 5.02
- 2009-06-24 0001193125-09-136674 — 7.01, 9.01
- 2009-06-01 0001193125-09-122549 — 1.01, 2.03, 9.01
- 2009-05-14 0001193125-09-110016 — 8.01, 9.01
- 2009-05-13 0001193125-09-109216 — 2.05, 7.01, 9.01
- 2009-05-05 0001193125-09-099861 — 1.01, 2.03, 9.01
- 2009-04-21 0001193125-09-083544 — 2.02, 9.01
- 2009-04-17 0001193125-09-081018 — 8.01, 9.01
- 2009-04-13 0001193125-09-077471 — 2.02, 9.01
- 2009-04-13 0001193125-09-077470 — 8.01, 9.01
- 2009-04-06 0001193125-09-073113 — 1.01, 2.03, 9.01
- 2009-03-09 0001193125-09-048538 — 5.02
- 2009-03-04 0001193125-09-044916 — 5.02, 8.01
- 2009-02-06 0001193125-09-021262 — 5.02
- 2009-02-04 0001193125-09-018804 — 5.02, 8.01
- 2009-02-02 0001193125-09-016478 — 2.06 — amendment, the index does not say of what
- 2009-01-27 0001193125-09-012058 — 5.02
- 2009-01-21 0001193125-09-009019 — 2.02, 5.02, 9.01
- 2009-01-14 0001193125-09-005721 — 2.05, 7.01
- 2009-01-12 0001193125-09-004420 — 5.02, 7.01, 9.01
- 2008-12-24 0001193125-08-259972 — 2.06
- 2008-12-12 0001193125-08-252765 — 2.03
- 2008-12-10 0001193125-08-250840 — 7.01
- 2008-11-12 0001193125-08-233906 — 5.02
- 2008-10-22 0001193125-08-214482 — 2.02, 9.01
- 2008-09-19 0001193125-08-198664 — 2.05
- 2008-09-12 0001193125-08-195206 — 1.01
- 2008-08-27 0001193125-08-185448 — 1.02, 3.01, 5.02, 9.01
- 2008-07-15 0001193125-08-151292 — 2.02, 9.01
- 2008-07-11 0001193125-08-149749 — 2.05
- 2008-07-03 0001193125-08-146791 — 5.02
- 2008-04-29 0001193125-08-094835 — 5.02, 9.01
- 2008-04-15 0001193125-08-081743 — 2.02, 9.01
- 2008-03-12 0001193125-08-054331 — 8.01, 9.01
- 2008-03-04 0001193125-08-045657 — 7.01
- 2008-02-04 0001193125-08-019262 — 8.01, 9.01
- 2008-01-18 0001193125-08-008849 — 8.01, 9.01
- 2008-01-17 0001193125-08-008120 — 2.02, 9.01
- 2007-12-21 0001193125-07-269469 — 2.05
- 2007-12-05 0001193125-07-259675 — 5.02
- 2007-10-17 0001193125-07-220376 — 8.01, 9.01
- 2007-10-16 0001193125-07-219386 — 2.02, 9.01
- 2007-09-18 0000950134-07-020112 — 5.02, 9.01
- 2007-08-29 0000950134-07-019145 — 1.01, 2.02, 9.01
- 2007-07-20 0001193125-07-159001 — 8.01, 9.01
- 2007-07-19 0001193125-07-158214 — 2.02, 9.01
- 2007-04-18 0001193125-07-083845 — 8.01, 9.01
- 2007-04-17 0001193125-07-082824 — 2.02, 9.01
- 2007-04-10 0001193125-07-077251 — 2.02, 9.01
- 2007-02-27 0001193125-07-040081 — 5.02, 7.01
- 2007-01-24 0001193125-07-011834 — 8.01, 9.01
- 2007-01-23 0001193125-07-010955 — 2.02, 9.01
- 2006-12-21 0001193125-06-257603 — 8.01, 9.01
- 2006-12-07 0001193125-06-247897 — 5.02
- 2006-11-07 0001193125-06-225545 — 2.02, 7.01, 8.01, 9.01
- 2006-11-01 0001193125-06-220706 — 1.01, 9.01
- 2006-10-25 0001193125-06-214798 — 8.01, 9.01
- 2006-10-24 0001193125-06-213813 — 2.02, 9.01
- 2006-10-11 0001193125-06-206304 — 5.02
- 2006-10-03 0001193125-06-201845 — 5.02, 9.01
- 2006-09-21 0001193125-06-194878 — 1.01, 1.02, 2.03, 2.04, 8.01, 9.01
- 2006-09-19 0001193125-06-192726 — 8.01, 9.01
- 2006-09-12 0001193125-06-189437 — 5.02, 8.01, 9.01
- 2006-08-24 0001193125-06-179258 — 1.01
- 2006-08-09 0001193125-06-167961 — 8.01, 9.01
- 2006-08-08 0001193125-06-165853 — 2.02, 9.01
- 2006-06-01 0001193125-06-122124 — 7.01, 9.01
- 2006-05-25 0001193125-06-119646 — 1.01, 2.01, 2.03, 5.02, 9.01
- 2006-05-17 0001193125-06-114760 — 8.01, 9.01
- 2006-05-04 0001193125-06-099262 — 8.01, 9.01
- 2006-05-03 0001193125-06-098229 — 5.05, 9.01
- 2006-04-27 0001193125-06-090749 — 8.01
- 2006-04-20 0001193125-06-084566 — 8.01, 9.01
- 2006-04-18 0001193125-06-082414 — 2.02, 9.01
- 2006-04-13 0001193125-06-079690 — 8.01
- 2006-04-03 0001193125-06-071956 — 8.01
- 2006-03-13 0001193125-06-051798 — 8.01
- 2006-02-14 0001193125-06-030829 — 8.01, 9.01
- 2006-01-26 0001193125-06-012909 — 8.01, 9.01
- 2006-01-25 0001193125-06-011608 — 8.01, 9.01
- 2006-01-19 0001193125-06-008770 — 8.01, 9.01
- 2006-01-18 0001193125-06-007939 — 2.02, 9.01
- 2005-12-22 0001193125-05-247782 — 1.01, 5.02, 9.01
- 2005-12-22 0001193125-05-247766 — 1.01, 9.01
- 2005-12-21 0001193125-05-246701 — 8.01, 9.01
- 2005-12-01 0001193125-05-234733 — 7.01
- 2005-11-23 0001193125-05-231674 — 1.01, 1.02, 7.01, 9.01
- 2005-10-19 0001193125-05-203955 — 2.02, 9.01
- 2005-10-18 0001193125-05-203356 — 2.02, 7.01, 9.01
- 2005-09-08 0001193125-05-181893 — 7.01, 9.01
- 2005-09-07 0001193125-05-181605 — 1.01
- 2005-08-04 0001193125-05-157913 — 8.01, 9.01
- 2005-08-03 0001193125-05-156407 — 1.01, 8.01, 9.01
- 2005-07-19 0001193125-05-144591 — 2.02, 9.01
- 2005-06-08 0001193125-05-121880 — 7.01
- 2005-05-17 0001193125-05-109518 — 7.01
- 2005-04-19 0001193125-05-079453 — 2.02, 9.01
- 2005-03-22 0001193125-05-057519 — 1.01
- 2005-03-16 0001193125-05-052560 — 7.01
- 2005-03-07 0001193125-05-043752 — 7.01, 9.01
- 2005-02-08 0001193125-05-022340 — 1.01, 7.01
- 2005-01-18 0001193125-05-007666 — 2.02, 9.01
- 2004-12-13 0001193125-04-211590 — 7.01, 8.01, 9.01
- 2004-12-07 0001193125-04-208768 — 7.01, 9.01
- 2004-10-29 0001193125-04-181463 — 1.01, 5.02, 9.01
- 2004-10-19 0001193125-04-173795 — 2.02, 9.01
- 2004-09-23 0001193125-04-160889 — 8.01, 9.01
- 2004-09-21 0001193125-04-159593 — 8.01, 9.01
- 2004-09-07 0001193125-04-152868 — 7.01, 9.01
- 2004-07-28 0001193125-04-126152 — 5, 7
- 2004-07-20 0001193125-04-121017 — 12, 7
- 2004-06-02 0001193125-04-097697 — 7, 9
- 2004-04-30 0001193125-04-075386 — 5, 7
- 2004-04-20 0001193125-04-065621 — 12, 7
- 2004-04-06 0001193125-04-057855 — 12, 7
- 2004-03-16 0001193125-04-042542 — 5
- 2004-03-03 0001193125-04-033653 — 7, 9
- 2004-01-21 0001193125-04-006388 — 12, 5, 7
- 2003-10-31 0001193125-03-070294 — 5, 7
- 2003-10-27 0001193125-03-067685 — 5, 7
- 2003-10-22 0001193125-03-065398 — 12, 5, 7
- 2003-07-16 0001193125-03-019880 — 7, 9
- 2003-07-10 0001193125-03-018043 — 5
- 2003-07-07 0001193125-03-016864 — 5
- 2003-06-27 0001193125-03-014262 — 5, 7
- 2003-04-16 0001012870-03-001799 — 7, 9

## late-filing notifications on or before 2025-08-01

- none on or before 2025-08-01

## item 2.02 — earnings release, exhibit 99.1

[0001137789-25-000150:8k_2_02:1]
EX-99.1
2
fq425consolidatedscript-8x.htm
EX-99.1

[0001137789-25-000150:8k_2_02:2]
Document

[0001137789-25-000150:8k_2_02:3]
Shanye Hudson, Senior Vice President-Investor Relations & Treasury, Seagate Technology Holdings Plc

[0001137789-25-000150:8k_2_02:4]
Thank you. Hello, everyone, and welcome to today's call. Joining me are Dave Mosley, Seagate’s Chief Executive Officer, and Gianluca Romano, our Chief Financial Officer. We've posted our earnings press release and detailed supplemental information for our June quarter and fiscal year end results on the Investors section of our website.

[0001137789-25-000150:8k_2_02:5]
During today’s call, we will refer to GAAP and non-GAAP measures. Non-GAAP figures are reconciled to GAAP figures in the earnings press release posted on our website and included in our Form 8-K. We have not reconciled certain non-GAAP outlook measures because material items that may impact these measures are out of our control and or cannot be reasonably predicted. Therefore, a reconciliation to the corresponding GAAP measures is not available without unreasonable effort.

[0001137789-25-000150:8k_2_02:6]
To learn more about the risks, uncertainties and other factors that may affect our future business results, please refer to the press release issued today and our SEC filings, including our most recent annual report on form 10-K and quarterly report on form 10-Q as well as the supplemental information all of which may be found on the Investors section of our website.

[0001137789-25-000150:8k_2_02:7]
Following our prepared remarks, we will open the call for questions. In order to provide all analysts with the opportunity to participate, we thank you in advance for asking one primary question and re-entering the queue.

[0001137789-25-000150:8k_2_02:8]
With that, I’ll hand the call over to Dave.

[0001137789-25-000150:8k_2_02:9]
William David Mosley, Chief Executive Officer & Director, Seagate Technology Holdings Plc

[0001137789-25-000150:8k_2_02:10]
Thanks Shanye, and hello everyone.

[0001137789-25-000150:8k_2_02:11]
Seagate closed out fiscal ‘25 delivering strong financial results for the June quarter, marked by 30% year over year revenue growth and record gross margins, which improved for a ninth consecutive quarter – a trend that is set to continue as HAMR adoption gains momentum. We achieved non-GAAP earnings per share near historic highs and generated strong free cash flow.

[0001137789-25-000150:8k_2_02:12]
For the fiscal year, revenue increased 39%, non-GAAP gross profit dollars nearly doubled and operating profit more than tripled, demonstrating our focus on supply / demand alignment and ongoing cost discipline. Our execution resulted in one of the most profitable fiscal years in the company’s long-storied history.

[0001137789-25-000150:8k_2_02:13]
The structural changes in our business model and strong product pipeline make Seagate well positioned to deliver improving profitability and cash generation in fiscal ‘26. Reflecting our confidence, we expect to resume share repurchases later this quarter, enhancing capital returns to shareholders.

[0001137789-25-000150:8k_2_02:14]
Operationally, in fiscal ’25 we started the high volume ramp of two new nearline platforms including the industry’s first heat assisted magnetic recording hard drive - an engineering feat more than a decade in the making. These new, cost-effective and energy-efficient platforms, aligned well with data growth driven by traditional compute workloads and increasingly from AI supported applications.

[0001137789-25-000150:8k_2_02:15]
Looking at the current end market dynamics, we see a continuation of strong global cloud demand for our nearline products. The visibility afforded by our build-to-order strategy indicates our nearline exabyte production capacity is largely spoken for through the middle of next calendar year with visibility building into the second half.

[0001137789-25-000150:8k_2_02:16]
We believe BTO contracts are also beneficial for our customers by providing predictable assurance of supply. With installed data center

[0001137789-25-000150:8k_2_02:17]
capacity expected to more than double by 2029 on a gigawatt basis, these contracts support the CSP’s efforts to keep pace with end-user demand.

[0001137789-25-000150:8k_2_02:18]
Within cloud data centers, we see an evolving diversity of workloads and applications addressed through a combination of storage media, optimized across a multitude of factors including performance, cost, floor space and energy efficiency.

[0001137789-25-000150:8k_2_02:19]
The diverse solutions that emerge are shaped by how these factors are prioritized and the scale that is required.

[0001137789-25-000150:8k_2_02:20]
For instance, one of the world’s largest cloud service providers recently developed a tiered storage solution to support an application for a widely used social media platform. Leveraging hard drives for both mass data storage in addition to a caching layer to enable fast, repeatable data access, this customer was able to realize significant cost savings and efficiency gains compared with alternative storage solutions.

[0001137789-25-000150:8k_2_02:21]
In today’s data-driven world, the growing need for mass capacity storage extends beyond the cloud to edge data centers. There are multiple trends that underpin this view. First, as more data is created at the edge, it will be replicated and retained across multiple locations to capture actionable insights through AI models. To preserve the integrity of these models, large volumes of data are being retained longer to support checkpoints and inferencing.

[0001137789-25-000150:8k_2_02:22]
Additionally, today roughly 50% of the world’s data centers are concentrated in just 4 countries.  As data sovereignty regulations evolve and proliferate around the globe we expect a growing demand for localized data storage. In this context, mass capacity hard drives will be critical from a footprint, efficiency and TCO perspective insuring data is safe, secure and compliant.

[0001137789-25-000150:8k_2_02:23]
For data centers at the edge, we expect enterprise storage demand will mirror the trends we’ve seen in the cloud, where upfront AI infrastructure investments led to increased demand for mass data storage over time.

[0001137789-25-000150:8k_2_02:24]
Supporting this point of view, a leading enterprise IT infrastructure provider is introducing new tiered storage system solutions later this year for AI

[0001137789-25-000150:8k_2_02:25]
applications designed to optimize their end customer’s TCO and data utilization requirements by integrating high-capacity hard drives based on HAMR technology.

[0001137789-25-000150:8k_2_02:26]
While momentum for our high-capacity HAMR drives builds, we have also continued to increase exabyte shipments of our PMR 24 to 28 terabyte platform to address demand. In fact, in the June quarter we achieved record quarterly sales and volume shipments for any nearline product with this platform.

[0001137789-25-000150:8k_2_02:27]
Leveraging the commonality across our PMR and HAMR platforms, we are executing the volume ramp of Mozaic 3 plus products. We are tracking to plan with shipments expanding to additional CSP’s in the September quarter. Across the board, qualifications are progressing exceedingly well, and we continue to expect the key global CSP customers to be qualified by mid-calendar 2026.

[0001137789-25-000150:8k_2_02:28]
Our progress in bringing HAMR based Mozaic drives to market at scale strongly positions Seagate to address the significant opportunities we foresee in the cloud and at the edge.

[0001137789-25-000150:8k_2_02:29]
A top priority during fiscal ‘26 is executing our 4 plus terabyte per disk qualification and volume ramp. This product will support cloud workloads with capacities of up to 44 terabytes and also supports lower capacity drives ideal for Edge workloads. As planned, we recently started qualification with a global CSP on the “4 TB per disk” platform and expect to begin volume ramp in the first half of calendar 2026. This timeline is consistent with our target for exabyte shipment crossover on HAMR based nearline drives in the second half of calendar 26.

[0001137789-25-000150:8k_2_02:30]
Ongoing investments in innovation such as granular iron platinum media and break through photonics technology are critical to delivering our areal density roadmap. We continue to make steady progress with 5 terabytes per disk technology aligning to our goal of introducing it into the market in early calendar 2028, a time frame when we also expect to demonstrate double that capacity – 10 terabytes per disk – in the lab.

[0001137789-25-000150:8k_2_02:31]
To close, I believe this is one of the most exciting periods in Seagate’s history. Recall at our investor and analyst day in May, we discussed how

[0001137789-25-000150:8k_2_02:32]
Seagate is in the right markets, with the right technology and the right execution to enhance shareholder value.

[0001137789-25-000150:8k_2_02:33]
Demand for mass data storage is expected to grow as our cloud, and Edge - IOT customers continue investing in AI-driven strategic imperatives to unlock and protect data value.

[0001137789-25-000150:8k_2_02:34]
Amid this strong demand backdrop, we are mindful of the evolving trade policy landscape. Based on our current outlook, we expect minimal tariff related impacts to the business. We will continue to closely track developments and stand ready to deploy mitigation strategies that minimize potential future impact to Seagate and our customers over the long term.

[0001137789-25-000150:8k_2_02:35]
In this dynamic environment, our HAMR-based technology roadmap makes us uniquely positioned to capture these growth opportunities in the cloud and at the edge as we push forward areal density gains to efficiently expand exabyte output, while enabling our customers to benefit from improving total cost of ownership.

[0001137789-25-000150:8k_2_02:36]
As a result, we are confident in our ability to produce compelling growth in revenue, profitability and cash generation in fiscal ‘26 and beyond.

[0001137789-25-000150:8k_2_02:37]
I’d like to thank our global teams, supply partners, and customers for your contributions to a strong fiscal year and Seagate’s ongoing success.

[0001137789-25-000150:8k_2_02:38]
Let me now turn the call over to Gianluca.

[0001137789-25-000150:8k_2_02:39]
Gianluca Romano, Chief Financial Officer & Executive Vice President, Seagate Technology Holdings Plc

[0001137789-25-000150:8k_2_02:40]
Thank you, Dave.

[0001137789-25-000150:8k_2_02:41]
We capped fiscal 2025 delivering strong double-digit top and bottom line growth and achieving record gross margin levels.

[0001137789-25-000150:8k_2_02:42]
•June quarter revenue came in at $2.44 billion, up 13% sequentially and up 30% year over year.

[0001137789-25-000150:8k_2_02:43]
•We expanded non-GAAP gross margin by 170 basis points sequentially to 37.9%

[0001137789-25-000150:8k_2_02:44]
•And we increased non-GAAP operating margin by 270 basis points to 26.2%.

[0001137789-25-000150:8k_2_02:45]
•Our resulting non-GAAP EPS was$2.59, at the high end of our guided range.

[0001137789-25-000150:8k_2_02:46]
For fiscal 2025,

[0001137789-25-000150:8k_2_02:47]
•We grew revenue by nearly 40% to $9.1 billion,

[0001137789-25-000150:8k_2_02:48]
•We achieved non-GAAP operating profit of $2.1 billion, marking one of our strongest annual performances,

[0001137789-25-000150:8k_2_02:49]
•And recorded non-GAAP EPS of $8.10.

[0001137789-25-000150:8k_2_02:50]
These results underscore our solid operational execution and the ongoing momentum for data center demand particularly among global Cloud customers.

[0001137789-25-000150:8k_2_02:51]
Strength from nearline Cloud sales along with seasonal improvements in the VIA markets led to a 14% sequential increase in Hard Drive revenue reaching $2.3 billion. Volume shipments increased to 163 exabytes from 144 exabytes in the March quarter.

[0001137789-25-000150:8k_2_02:52]
Mass Capacity revenue topped the $2.0 billion mark, up 15% sequentially and 40% year-on-year. Mass capacity shipments were 151 exabytes compared with 133 exabytes in the prior quarter.

[0001137789-25-000150:8k_2_02:53]
Nearline shipments into cloud and edge data centers made up the vast majority of mass capacity volume.

[0001137789-25-000150:8k_2_02:54]
In the June quarter, nearline represented 91% of mass capacity exabytes with shipments of 137 exabytes, up 14% sequentially and 52% year-on-year. Our 24 and 28 terabyte PMR products have been widely adopted by global cloud and enterprise data centers to support their massive data workloads. At the same time, we are ramping our HAMR based Mozaic products and continuing to build customer momentum. Three major cloud service providers are qualified on our Mozaic products with additional qualifications proceeding extremely well.

[0001137789-25-000150:8k_2_02:55]
On top of strong demand growth from cloud customers, nearline sales into the enterprise/OEM market showed a modest sequential improvement in the quarter and we expect stable demand over the next few quarters.

[0001137789-25-000150:8k_2_02:56]
The remaining 18% of revenue came from Legacy and other product lines. Sales from the Legacy markets totaled $270 million, up 6% sequentially, while revenue from our “Other” product lines, increased 3% sequentially to $163 million.

[0001137789-25-000150:8k_2_02:57]
Starting in the September quarter, we plan to adjust how we discuss our end markets. We will focus on two main areas: Datacenter and Edge - IoT. The data center markets accounted for about 75% of our fiscal 2025 revenue and include nearline products and systems sold into cloud and enterprise customers, as well as cloud based VIA applications. Edge - IoT includes consumer and client centric markets, along with network attached storage. We believe this new framework is better aligned with industry practice and reflects the AI-driven market we serve today.

[0001137789-25-000150:8k_2_02:58]
Moving onto the rest of the income statement, non-GAAP gross profit increased to $926 million, up 19% quarter over quarter and 59% compared with the prior year period.

[0001137789-25-000150:8k_2_02:59]
Our resulting non-GAAP gross margin expanded to 37.9%. We continue to benefit from a favorable mix including increased adoption of our latest generation products and ongoing pricing adjustments. These factors, combined with a strong demand environment for data center products, supported non-GAAP gross margins for the hard drive business above the corporate average.

[0001137789-25-000150:8k_2_02:60]
Non-GAAP operating expenses totaled $286 million, up 4% quarter-over-quarter and in line with our expectations.

[0001137789-25-000150:8k_2_02:61]
Other Income and Expenses decreased 9% sequentially to $73 million due in part to lower net interest expense during the quarter.

[0001137789-25-000150:8k_2_02:62]
Adjusted EBITDA was $697 million, up 24% quarter over quarter and up 73% year-on-year.

[0001137789-25-000150:8k_2_02:63]
Non-GAAP net income was $556 million, resulting in non-GAAP EPS of $2.59 per share, based on a diluted share count of approximately 215 million shares.

[0001137789-25-000150:8k_2_02:64]
Turning now to cash flows and the balance sheet…

[0001137789-25-000150:8k_2_02:65]
We invested $83 million in Capital expenditures for the June quarter and $265 million for fiscal ’25, which equates to 3% of revenue. Looking ahead to fiscal ’26, we anticipate capital expenditures to be inside our target range of 4-to-6% of revenue while we continue maintaining capital discipline.

[0001137789-25-000150:8k_2_02:66]
Free cash flow nearly doubled in the June quarter to $425 million, up from $216 million in the prior period. Based on our current outlook, we expect free cash flow generation to expand further in the second half of calendar year 2025 compared to the first half. This is even accounting for a substantial variable compensation payout in the September quarter, which is consistent with our strong performance.

[0001137789-25-000150:8k_2_02:67]
In the June quarter, we returned $153 million to shareholders through the quarterly dividends, and we returned nearly 75% of free cash flow to shareholders for the fiscal year, demonstrating a strong commitment to our capital return strategy.

[0001137789-25-000150:8k_2_02:68]
Cash and cash equivalents increased 9% sequentially to close the June quarter with ample liquidity of $2.2 billion, including our undrawn revolving credit facility of $1.3 billion.

[0001137789-25-000150:8k_2_02:69]
We reduced our debt balance by approximately $150 million during the quarter, including retiring $505 million through a new $400 million note issuance and cash on hand. We exited the quarter with gross debt of approximately $5 billion. The combination of lower debt and strong profitability resulted in net leverage ratio of 1.8 times with further reductions anticipated in the coming quarters as profits expand.

[0001137789-25-000150:8k_2_02:70]
Turning now to the September quarter outlook.

[0001137789-25-000150:8k_2_02:71]
From a demand perspective, the visibility gained through our BTO strategy instills confidence in sustained demand strength for our high capacity nearline drives and supports both revenue and margin expansion in the September quarter.

[0001137789-25-000150:8k_2_02:72]
As previously communicated, starting in fiscal 2026 we will be subject to a global minimum tax rate in the mid-teens.

[0001137789-25-000150:8k_2_02:73]
Accounting for these factors and for the 14-week period,

[0001137789-25-000150:8k_2_02:74]
•We expect September quarter revenue to be in a range of $2.5 billion plus or minus $150 million. At the midpoint this reflects a 15% improvement year-over-year.

[0001137789-25-000150:8k_2_02:75]
•Non-GAAP operating expenses are expected to be approximately $290 million, reflecting the 14th week period, partially offset by lower variable compensation as we reset the annual plan for fiscal ‘26.

[0001137789-25-000150:8k_2_02:76]
•Based on the midpoint of our revenue guidance non-GAAP operating margin is expected to expand into the mid-to-high twenties percentage range, and

[0001137789-25-000150:8k_2_02:77]
•Non-GAAP EPS is expected to be $2.30, plus or minus $0.20 based on a 16% tax rate and non-GAAP diluted share count of 221 million shares.

[0001137789-25-000150:8k_2_02:78]
Our EPS guidance reflects estimated dilution from our 2028 convertible notes and equity compensation. Dilution to non-GAAP earnings from the convertible notes occurs when the volume weighted average price of Seagate stock trades above approximately $108 during the period.

[0001137789-25-000150:8k_2_02:79]
We target to partially offset the dilutive impact of the convertible notes through share repurchases, which we expect to resume in the current quarter.

[0001137789-25-000150:8k_2_02:80]
To close, Seagate's strong June quarter performance underscores our continued focus on driving growth, enhancing profitability, and optimizing cash generation.

[0001137789-25-000150:8k_2_02:81]
We are executing our strategic objectives, underpinned by a structurally changed business model and leading technology roadmap to deliver on our financial targets and enhance value for both customers and shareholders.

[0001137789-25-000150:8k_2_02:82]
Operator, let’s open the call up for questions.
