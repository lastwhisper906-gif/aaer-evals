# STX MD&A — 0001137789-25-000157


## mdna

[0001137789-25-000157:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001137789-25-000157:mdna:2]
The following is a discussion of the Company’s financial condition, changes in financial condition and results of operations for the fiscal years ended June 27, 2025 and June 28, 2024. Discussions of year-to-year comparisons between fiscal years 2024 and 2023 are not included in this Annual Report on Form 10-K and can be found in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended June 28, 2024, which was filed with the SEC on August 2, 2024.

[0001137789-25-000157:mdna:3]
You should read this discussion in conjunction with “Item 8. Financial Statements and Supplementary Data” included elsewhere in this Annual Report on Form 10-K. Except as noted, references to any fiscal year mean the twelve-month period ending on the Friday closest to June 30 of that year. Accordingly, fiscal year 2025 and 2024 both comprised of 52 weeks and ended on June 27, 2025 and June 28, 2024, respectively. Fiscal year 2026 will be comprised of 53 weeks and will end on July 3, 2026.

[0001137789-25-000157:mdna:4]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is provided in addition to the accompanying Consolidated Financial Statements and notes to assist readers in understanding our results of operations, financial condition and cash flows. Our MD&A is organized as follows:

[0001137789-25-000157:mdna:5]
•Overview of Fiscal Year 2025. Highlights of events in fiscal year 2025 that impacted our financial position.

[0001137789-25-000157:mdna:6]
•Results of Operations. Analysis of our financial results comparing fiscal years 2025 and 2024.

[0001137789-25-000157:mdna:7]
•Liquidity and Capital Resources. Analysis of changes in our balance sheets and cash flows and discussion of our financial condition, including potential sources of liquidity, material cash requirements and their general purpose.

[0001137789-25-000157:mdna:8]
•Critical Accounting Policies and Estimates. Accounting policies and estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001137789-25-000157:mdna:9]
39

[0001137789-25-000157:mdna:10]
For an overview of our business, see “Part I, Item 1. Business.”

[0001137789-25-000157:mdna:11]
Overview of Fiscal Year 2025

[0001137789-25-000157:mdna:12]
During fiscal year 2025, we shipped 595 exabytes of HDD storage capacity. We generated revenue of approximately $9.1 billion with a gross margin of 35% and net income of $1.5 billion. Our operating cash flow was $1.1 billion and we paid $600 million in dividends. We issued $400 million principal amount of senior notes, repaid $479 million principal amount of the 2025 Notes and $505 million of the 2027 Notes, as well as repurchased $99 million principal amount of certain senior notes. Additionally, we acquired Intevac, Inc. (“Intevac”), a supplier of thin-film processing systems, for a net cash outlay of $47 million.

[0001137789-25-000157:mdna:13]
Recent Developments, Economic Conditions and Challenges

[0001137789-25-000157:mdna:14]
During fiscal year 2025, we experienced a significant increase in demand for our high capacity nearline drives primarily from cloud customers. At the same time, we have continued to operate in a dynamic macroeconomic environment marked by rapid shifts in trade policies and increasing geopolitical tensions. These factors may impact our business and results of operations. We will continue to monitor the situation and assess plans to mitigate future risk to the business. Over the long-term we expect our hard drive storage business to benefit from future growth in data demand and data value, including from the adoption of Generative AI applications.

[0001137789-25-000157:mdna:15]
For a further discussion of the uncertainties and business risks, see “Part I, Item 1A. Risk Factors” of our Annual Report.

[0001137789-25-000157:mdna:16]
Results of Operations

[0001137789-25-000157:mdna:17]
We list in the tables below summarized information from our Consolidated Statements of Operations by dollar amounts and as a percentage of revenue:

[0001137789-25-000157:mdna:18]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |
| Revenue |  | $ | 9,097 |  |  | $ | 6,551 |  |
| Cost of revenue |  | 5,897 |  |  | 5,015 |  |
| Gross profit |  | 3,200 |  |  | 1,536 |  |
| Product development |  | 724 |  |  | 654 |  |
| Marketing and administrative |  | 561 |  |  | 460 |  |
| Restructuring and other, net |  | 25 |  |  | (30) |  |
| Income from operations |  | 1,890 |  |  | 452 |  |
| Other expense, net |  | (377) |  |  | (7) |  |
| Income before income taxes |  | 1,513 |  |  | 445 |  |
| Provision for income taxes |  | 44 |  |  | 110 |  |
| Net income |  | $ | 1,469 |  |  | $ | 335 |  |

[0001137789-25-000157:mdna:19]
|  |  | Fiscal Years Ended |
|  |  | June 27,2025 |  | June 28,2024 |
| Revenue |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 65 |  |  | 77 |  |
| Gross margin |  | 35 |  |  | 23 |  |
| Product development |  | 8 |  |  | 10 |  |
| Marketing and administrative |  | 6 |  |  | 7 |  |
| Restructuring and other, net |  | — |  |  | — |  |
| Operating margin |  | 21 |  |  | 6 |  |
| Other expense, net |  | (4) |  |  | — |  |
| Income before income taxes |  | 17 |  |  | 6 |  |
| Provision for income taxes |  | 1 |  |  | 2 |  |
| Net income |  | 16 | % |  | 4 | % |

[0001137789-25-000157:mdna:20]
41

[0001137789-25-000157:mdna:21]
Revenue

[0001137789-25-000157:mdna:22]
The following table summarizes information regarding consolidated revenues by channel, geography, and market and HDD exabytes shipped by market and price per terabyte:

[0001137789-25-000157:mdna:23]
|  |  | Fiscal Years Ended |
|  |  | June 27,2025 |  | June 28,2024 |
| Revenues by Channel (%) |  |  |  |  |
| OEMs |  | 80 | % |  | 75 | % |
| Distributors |  | 12 | % |  | 15 | % |
| Retailers |  | 8 | % |  | 10 | % |
| Revenues by Geography (%) (1) |  |  |  |  |
| Asia Pacific |  | 41 | % |  | 53 | % |
| Americas |  | 49 | % |  | 35 | % |
| EMEA |  | 10 | % |  | 12 | % |
| Revenues by Market (%) |  |  |  |  |
| Mass capacity |  | 81 | % |  | 72 | % |
| Legacy |  | 12 | % |  | 18 | % |
| Other |  | 7 | % |  | 10 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |
| Mass capacity |  | 552 |  |  | 355 |  |
| Legacy |  | 43 |  |  | 43 |  |
| Total |  | 595 |  |  | 398 |  |
| HDD Price per Terabyte |  | $ | 14 |  |  | $ | 15 |  |

[0001137789-25-000157:mdna:24]
________________________________________________

[0001137789-25-000157:mdna:25]
(1) Revenue is attributed to geography based on the bill from location.

[0001137789-25-000157:mdna:26]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |  | Change |  | %Change |
| Revenue |  | $ | 9,097 |  |  | $ | 6,551 |  |  | $ | 2,546 |  |  | 39 | % |

[0001137789-25-000157:mdna:27]
Revenue in fiscal year 2025 increased approximately 39%, or $2.5 billion, from fiscal year 2024, primarily due to an increase in mass capacity exabytes shipped as we experienced higher demand in particular for our nearline cloud products and favorable pricing actions undertaken by the Company.

[0001137789-25-000157:mdna:28]
Cost of Revenue and Gross Margin

[0001137789-25-000157:mdna:29]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |  | Change |  | %Change |
| Cost of revenue |  | $ | 5,897 |  |  | $ | 5,015 |  |  | $ | 882 |  |  | 18 | % |
| Gross profit |  | 3,200 |  |  | 1,536 |  |  | 1,664 |  |  | 108 | % |
| Gross margin |  | 35 | % |  | 23 | % |  |  |  |  |

[0001137789-25-000157:mdna:30]
For fiscal year 2025, gross margin increased by 12 percentage points compared to the prior fiscal year primarily driven by favorable product mix and pricing actions undertaken by the Company, a decrease of $96 million of supply related purchase order cancellation fees, as well as $160 million of factory underutilization charges and $13 million of accelerated depreciation expense for certain capital equipment that did not recur in fiscal year 2025, partially offset by $13 million of restructuring costs related to an inventory write down due to a discontinued product line in the fiscal year 2025.

[0001137789-25-000157:mdna:31]
Warranty cost related to new shipments was 0.7%, 0.8% and 0.7% of revenue for the fiscal years 2025, 2024 and 2023, respectively.

[0001137789-25-000157:mdna:32]
Operating Expenses

[0001137789-25-000157:mdna:33]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |  | Change |  | %Change |
| Product development |  | $ | 724 |  |  | $ | 654 |  |  | $ | 70 |  |  | 11 | % |
| Marketing and administrative |  | 561 |  |  | 460 |  |  | 101 |  |  | 22 | % |
| Restructuring and other, net |  | 25 |  |  | (30) |  |  | 55 |  |  | * |
| Operating expenses |  | $ | 1,310 |  |  | $ | 1,084 |  |  | $ | 226 |  |  |  |

[0001137789-25-000157:mdna:34]
______________________________

[0001137789-25-000157:mdna:35]
*Not a meaningful figure

[0001137789-25-000157:mdna:36]
Product Development Expense. Product development expenses for fiscal year 2025 increased by $70 million from fiscal year 2024 primarily due to a $64 million increase in compensation and other employee benefits as a result of the variable compensation expense recognized in fiscal year 2025 and temporary salary reductions in fiscal year 2024, a $9 million increase in facility costs, a $5 million increase in equipment expense and a $4 million increase in outside services, partially offset by a $13 million decrease in material expenses.

[0001137789-25-000157:mdna:37]
Marketing and Administrative Expense. Marketing and administrative expenses for fiscal year 2025 increased by $101 million from fiscal year 2024 primarily due to a $84 million increase in compensation and other employee benefits as a result of the variable compensation expense recognized in fiscal year 2025 and temporary salary reductions in fiscal year 2024, a $7 million increase in travel expenses, a $7 million increase in outside services expense and a $3 million increase in advertising costs.

[0001137789-25-000157:mdna:38]
Restructuring and Other, net. We recorded $38 million of restructuring charges in fiscal year 2025, of which $13 million was recorded to Cost of revenue and $25 million recorded to Restructuring and other, net, respectively, primarily related to an inventory write down due to a discontinued product line, employee related termination benefits and right-of-use (“ROU”) asset impairment charges.

[0001137789-25-000157:mdna:39]
Other Expense, net

[0001137789-25-000157:mdna:40]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |  | Change |  | %Change |
| Other expense, net |  | $ | 377 |  |  | $ | 7 |  |  | $ | 370 |  |  | * |

[0001137789-25-000157:mdna:41]
______________________________

[0001137789-25-000157:mdna:42]
*Not a meaningful figure

[0001137789-25-000157:mdna:43]
Other expense, net for fiscal year 2025 primarily related to $321 million of interest expense and $53 million loss on investments. Other expense, net for fiscal year 2024 primarily related to $332 million of interest expense, $52 million loss on investments and $29 million net loss from debt transactions, partially offset by a $313 million gain from the sale of System-on-Chip (“SoC”) operations and $104 million net gain from termination of interest rate swap.

[0001137789-25-000157:mdna:44]
Income Taxes

[0001137789-25-000157:mdna:45]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |  | Change |  | %Change |
| Provision for income taxes |  | $ | 44 |  |  | $ | 110 |  |  | $ | (66) |  |  | (60) | % |

[0001137789-25-000157:mdna:46]
We recorded an income tax provision of $44 million for fiscal year 2025 compared to an income tax provision of $110 million for fiscal year 2024.

[0001137789-25-000157:mdna:47]
We established Singapore as our principal executive offices in fiscal year 2024. Our parent holding company owns various U.S. and non-Singaporean subsidiaries that operate in multiple non-Singaporean income tax jurisdictions. Our worldwide operating income is either subject to varying rates of income tax or is exempt from income tax due to tax incentive programs we operate under in Singapore and Thailand.

[0001137789-25-000157:mdna:48]
Our income tax provision recorded for fiscal years 2025 differed from the provision for income taxes that would be derived by applying the Singaporean statutory rate of 17% to income before income taxes, primarily due to the net effect of (i) tax benefits related to earnings generated in jurisdictions that are subject to tax incentive programs and (ii) changes in valuation allowance.

[0001137789-25-000157:mdna:49]
43

[0001137789-25-000157:mdna:50]
Our income tax provision recorded for fiscal years 2024 differed from the provision for income taxes that would be derived by applying the Singaporean statutory rate of 17% to income before income taxes, primarily due to the net effect of (i) changes in valuation allowance and (ii) current year generation of research credits.

[0001137789-25-000157:mdna:51]
On July 4, 2025 the One Big Beautiful Bill Act (“OBBBA”) was enacted in the U.S. The OBBBA includes significant provisions, such as the permanent extension of certain expiring provisions of the Tax Cuts and Jobs Act, modifications to the international tax framework, and the restoration of favorable tax treatment for certain business provisions. The legislation has multiple effective dates, with certain provisions effective in fiscal year 2026 and others implemented through fiscal year 2028. We are currently assessing its impact on our consolidated financial statements.

[0001137789-25-000157:mdna:52]
Liquidity and Capital Resources

[0001137789-25-000157:mdna:53]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash will continue to be sufficient to fund our operations and meet our cash requirements for the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs and capital expenditures, will allow us to manage the ongoing impact of market demand disruptions on our business operations for the foreseeable future. However, some challenges to our industry and to our business continue to remain uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to the global economic factors.

[0001137789-25-000157:mdna:54]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of June 27, 2025. For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements among others, see “Part I, Item 1A. Risk Factors” of our Annual Report.

[0001137789-25-000157:mdna:55]
Cash and Cash Equivalents

[0001137789-25-000157:mdna:56]
|  |  | As of |  |  |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |  | Change |
| Cash and cash equivalents |  | $ | 891 |  |  | $ | 1,358 |  |  | $ | (467) |  |

[0001137789-25-000157:mdna:57]
The following table summarizes results from the Consolidated Statements of Cash Flows for the periods indicated:

[0001137789-25-000157:mdna:58]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |
| Net cash flow provided by (used in): |  |  |  |  |
| Operating activities |  | $ | 1,083 |  |  | $ | 918 |  |
| Investing activities |  | (276) |  |  | 126 |  |
| Financing activities |  | (1,274) |  |  | (473) |  |
| Effect of foreign currency exchange rates |  | — |  |  | 1 |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  | $ | (467) |  |  | $ | 572 |  |

[0001137789-25-000157:mdna:59]
Cash Provided by Operating Activities

[0001137789-25-000157:mdna:60]
Cash provided by operating activities for fiscal year 2025 was $1.1 billion and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, and the following major working capital related movements:

[0001137789-25-000157:mdna:61]
•an increase of $513 million in accounts receivable, primarily due to higher revenue and lower accounts receivable factoring;

[0001137789-25-000157:mdna:62]
•a decrease of $242 million in accounts payable, primarily due to timing of payments; and

[0001137789-25-000157:mdna:63]
•an increase of $201 million in inventory, primarily due to an increase in purchased materials and finished goods inventory; partially offset by

[0001137789-25-000157:mdna:64]
44

[0001137789-25-000157:mdna:65]
•an increase of $207 million in accrued employee compensation, primarily due to an increase in our variable compensation expense.

[0001137789-25-000157:mdna:66]
Cash provided by operating activities for fiscal year 2024 was $918 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, net gain from business divestiture, and the following major working capital related movements:

[0001137789-25-000157:mdna:67]
•an increase of $243 million in other assets and liabilities, primarily related to the restructuring of pre-existing purchase agreements as a result of the sale of SoC operations;

[0001137789-25-000157:mdna:68]
•an increase of $227 million in accounts payable, primarily due to timing of payments;

[0001137789-25-000157:mdna:69]
•a decrease of $192 million in accounts receivable, primarily due to lower revenue and higher accounts receivable factoring; and

[0001137789-25-000157:mdna:70]
•an increase of $25 million cash proceeds received from the settlement of certain interest rate swap agreements; partially offset by

[0001137789-25-000157:mdna:71]
•a decrease of $183 million in accrued expenses primarily due to lower restructuring activities; and

[0001137789-25-000157:mdna:72]
•an increase of $99 million in inventories, primarily due to an increase in raw materials and work in progress inventory.

[0001137789-25-000157:mdna:73]
Cash Used in Investing Activities

[0001137789-25-000157:mdna:74]
In fiscal year 2025, we used $276 million net cash for investing activities, which was primarily due to payments for the purchase of property, equipment and leasehold improvements of $265 million and net cash used in the acquisition of Intevac of $47 million, which includes proceeds from the sale of Intevac’s investments post-acquisition (refer to “Item 8. Financial Statements and Supplementary Data—Note 17. Acquisition and Divestiture” for more details), offset by $10 million from the sale of equity investments, and $25 million from the proceeds of business divestiture.

[0001137789-25-000157:mdna:75]
In fiscal year 2024, we received $126 million for net cash investing activities, which was primarily due to the proceeds from the sale of SoC operations of $326 million, $40 million from the sale of assets and $14 million from the sale of investments, offset by payments for the purchase of property, equipment and leasehold improvements of $254 million.

[0001137789-25-000157:mdna:76]
Cash Used in Financing Activities

[0001137789-25-000157:mdna:77]
Net cash used in financing activities of $1.3 billion for fiscal year 2025 was primarily attributable to the following activities:

[0001137789-25-000157:mdna:78]
•$1.1 billion repurchases of long-term debt;

[0001137789-25-000157:mdna:79]
•$600 million in dividend payments;

[0001137789-25-000157:mdna:80]
•$54 million taxes paid related to net share settlement of equity awards; and

[0001137789-25-000157:mdna:81]
•$14 million debt fees relating to issuance and repurchase of long-term debt; partially offset by

[0001137789-25-000157:mdna:82]
•$400 million in net proceeds from the issuance of long-term debt; and

[0001137789-25-000157:mdna:83]
•$72 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-25-000157:mdna:84]
Net cash used in financing activities of $473 million for fiscal year 2024 was primarily attributable to the following activities:

[0001137789-25-000157:mdna:85]
•$1.3 billion repurchases of long-term debt;

[0001137789-25-000157:mdna:86]
•$585 million in dividend payments;

[0001137789-25-000157:mdna:87]
•$128 million debt fees relating to issuance of long-term debt and capped call transactions; and

[0001137789-25-000157:mdna:88]
•$38 million taxes paid related to net share settlement of equity awards; partially offset by

[0001137789-25-000157:mdna:89]
•$1.5 billion in proceeds from the issuance of long-term debt; and

[0001137789-25-000157:mdna:90]
•$66 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-25-000157:mdna:91]
Liquidity Sources

[0001137789-25-000157:mdna:92]
Our primary sources of liquidity as of June 27, 2025, consist of: (1) approximately $891 million in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.3 billion available for borrowing under our senior unsecured revolving credit facility (“Revolving Credit Facility”), which is part of our New Credit Agreement (as defined in “Item 8. Financial Statements and Supplementary Data—Note 4. Debt” for more details).

[0001137789-25-000157:mdna:93]
As of June 27, 2025, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-25-000157:mdna:94]
As of June 27, 2025, the New Credit Agreement includes one financial covenant, net leverage ratio. We continue to evaluate our debt portfolio and structure to comply with our financial debt covenants. As of June 27, 2025, we were in compliance with all of the covenants under our debt agreements. Refer to “Part II, Item 8. Financial Statements—Note 4. Debt” for more details.

[0001137789-25-000157:mdna:95]
We believe that our sources of cash will be sufficient to fund our operations and meet our cash requirements for at least the next 12 months. Our ability to fund liquidity requirements beyond 12 months will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001137789-25-000157:mdna:96]
For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, among others, see “Part I, Item 1A. Risk Factors” of this Annual Report.

[0001137789-25-000157:mdna:97]
Cash Requirements and Commitments

[0001137789-25-000157:mdna:98]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend and any future strategic investments.

[0001137789-25-000157:mdna:99]
Purchase obligations

[0001137789-25-000157:mdna:100]
Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. From time to time, we enter into long-term, non-cancelable purchase commitments or make large up-front investments with certain suppliers in order to secure certain components or technologies for the production of our products or to supplement our internal manufacturing capacity for certain components. As of June 27, 2025, we had unconditional purchase obligations of approximately $1.3 billion, primarily related to purchases of inventory components with our suppliers. We expect $1.2 billion of these commitments to be paid within one year. In addition, we also had certain long-term market share based non-cancellable inventory purchase commitments as of June 27, 2025.

[0001137789-25-000157:mdna:101]
Capital expenditures

[0001137789-25-000157:mdna:102]
We incur material capital expenditures to design and manufacture our products that depend on advanced technologies and manufacturing techniques. As of June 27, 2025, we had unconditional commitments of $151 million primarily related to purchases of equipment, of which approximately $105 million is expected to be paid within one year. For fiscal year 2026, we expect capital expenditures to be higher than fiscal year 2025.

[0001137789-25-000157:mdna:103]
Operating leases

[0001137789-25-000157:mdna:104]
We are a lessee in several operating leases related to real estate facilities for warehouse, office and lab space. As of June 27, 2025, the amount of future minimum rent expense for both occupied and vacated facilities under non-cancelable operating lease contracts was $516 million, of which $64 million is expected to be paid within one year. Refer to “Item 8. Financial Statements and Supplementary Data—Note 6. Leases” for details.

[0001137789-25-000157:mdna:105]
Long-term debt and interest payments on debt

[0001137789-25-000157:mdna:106]
As of June 27, 2025, the future principal payment obligation on our long-term debt was $5.0 billion, which will mature in more than one year. As of June 27, 2025, future interest payments on this outstanding debt is estimated to be approximately $1.8 billion, of which $313 million is expected to be paid within one year. Subsequent to our Consolidated Balance Sheet date, on June 30, 2025, the conditional conversion feature of the 2028 Notes was triggered in accordance with the terms of the 2028 Notes indenture. Accordingly, the 2028 Notes are exchangeable through September 30, 2025. From time to time, we may repurchase, redeem or otherwise extinguish any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase or redeem outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 8. Financial Statements and Supplementary Data—Note 4. Debt” for more details.

[0001137789-25-000157:mdna:107]
BIS settlement penalty

[0001137789-25-000157:mdna:108]
We accrued a settlement penalty of $300 million for fiscal year 2023, related to BIS’ allegations of violations of the U.S. EAR, which were subsequently resolved by the Settlement Agreement in April 2023. As part of the Settlement Agreement with BIS, quarterly payments of $15 million are made over the course of five years beginning October 31, 2023, of which $60 million is expected to be paid within one year and $135 million thereafter. Refer to “Item 8. Financial Statements and Supplementary Data—Note 13. Legal, Environmental and Other Contingencies” for more details.

[0001137789-25-000157:mdna:109]
Restructuring

[0001137789-25-000157:mdna:110]
During the fiscal year ended June 27, 2025, we made cash payments of $14 million, primarily related to workforce reduction costs under our restructuring plans.

[0001137789-25-000157:mdna:111]
As of June 27, 2025, the future cash payments related to our remaining active restructuring plans were immaterial.

[0001137789-25-000157:mdna:112]
Income Tax

[0001137789-25-000157:mdna:113]
As of June 27, 2025, we had an immaterial liability for unrecognized tax benefits, none of which is expected to be settled within one year. Outside of one year, we are unable to make a reasonably reliable estimate of when cash settlement with a taxing authority will occur.

[0001137789-25-000157:mdna:114]
Dividends

[0001137789-25-000157:mdna:115]
On July 29, 2025, our Board of Directors declared a quarterly cash dividend of $0.72 per share, which will be payable on October 9, 2025 to shareholders of record as of the close of business on September 30, 2025. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-25-000157:mdna:116]
Share repurchases

[0001137789-25-000157:mdna:117]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means, including through the use of derivative transactions. During fiscal year 2025, we repurchased approximately 1 million of our ordinary shares including shares withheld for statutory tax withholdings related to vesting of employee equity awards. See “Item 5. Market for Registrant’s Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities-Repurchases of Our Equity Securities.” As of June 27, 2025, $5.0 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-25-000157:mdna:118]
We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-25-000157:mdna:119]
Critical Accounting Policies and Estimates

[0001137789-25-000157:mdna:120]
The Company’s accounting policies are more fully described in “Item 8. Financial Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of Significant Accounting Policies”. The methods, estimates and judgments we use in applying our most critical accounting policies have a significant impact on the results we report in our Consolidated Financial Statements. Critical accounting estimates are those estimates that involve a significant level of estimation uncertainty and have had or are reasonably likely to have a material impact on our financial condition or results of operations. Based on this definition, our most critical accounting policies include: Revenue - Sales Program Accruals and Income Taxes. Below, we discuss these policies further, as well as the estimates and judgments involved. We also have other accounting policies and accounting estimates relating to warranty, valuation of inventories, assessing goodwill and other long-lived assets for impairment, valuation of share-based payments and restructuring. We believe that these other accounting policies and accounting estimates either do not generally require us to make estimates and judgments that are as difficult or as subjective, or it is less likely that they would have a material impact on our reported results of operations for a given period.

[0001137789-25-000157:mdna:121]
Revenue - Sales Program Accruals. We record estimated variable consideration at the time of revenue recognition as a reduction to revenue. Variable consideration generally consists of expected rebates to be provided in relation to sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer's volume of purchases from us or other agreed upon rebate programs. For the distribution and retail channel, these sales incentive programs typically involve estimating the most likely amount of rebates based on historical price incentives, known future price trends, and channel inventory level. Total sales programs were 14% and 16% of gross revenue in fiscal years 2025 and 2024, respectively. Adjustments to revenues due to under or over accruals for sales programs related to revenues reported in prior periods were less than 1% of gross revenue in fiscal years 2025 and 2024.

[0001137789-25-000157:mdna:122]
Income Taxes. We make certain estimates and judgments in determining income tax expense for financial statement purposes. These estimates and judgments occur in the calculation of tax credits, recognition of income and deductions and

[0001137789-25-000157:mdna:123]
calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for income tax and financial statement purposes, as well as tax liabilities associated with uncertain tax positions.

[0001137789-25-000157:mdna:124]
The deferred tax assets we record each period depend primarily on our ability to generate future taxable income in the United States and certain non-U.S. jurisdictions. Each period, we evaluate the need for a valuation allowance for our deferred tax assets and, if necessary, adjust the valuation allowance so that net deferred tax assets are recorded only to the extent we conclude it is more likely than not that these deferred tax assets will be realized.

[0001137789-25-000157:mdna:125]
In evaluating our ability to recover our deferred tax assets, in full or in part, we consider all available positive and negative evidence, including our past operating results, and our forecast of future earnings, future taxable income and prudent and feasible tax planning strategies. The assumptions utilized in determining future taxable income require significant judgment and are consistent with the plans and estimates we are using to manage the underlying businesses. Actual operating results in future years could differ from our current assumptions, judgments, and estimates. If our outlook for future taxable income changes significantly, our assessment of the need for, and the amount of, a valuation allowance may also change resulting in an additional tax provision or benefit.

[0001137789-25-000157:mdna:126]
Recent Accounting Pronouncements

[0001137789-25-000157:mdna:127]
See “Item 8. Financial Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.
