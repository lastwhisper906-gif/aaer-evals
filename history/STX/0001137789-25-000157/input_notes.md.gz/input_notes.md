# STX notes — 0001137789-25-000157


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001137789-25-000157:notes:1]
Portions of the definitive proxy statement to be filed with the Securities and Exchange Commission pursuant to Regulation 14A relating to the registrant’s Annual General Meeting of Shareholders, to be held on October 25, 2025, will be incorporated by reference in this Form 10-K in response to Items 10, 11, 12, 13 and 14 of Part III. The definitive proxy statement will be filed with the SEC no later than 120 days after the registrant's fiscal year ended June 27, 2025.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001137789-25-000157:notes:2]
Risk Management and Strategy

[0001137789-25-000157:notes:3]
We have implemented a cybersecurity risk management program designed to identify, assess and manage material risks from cybersecurity threats based on relevant industry standards. The cybersecurity program is reviewed at least annually by the Audit and Finance Committee (as defined below) and organizational leaders, as well as whenever there is a material change in our business practices or a change in applicable law that may reasonably affect our response procedures. In addition, we regularly assess the design and operational effectiveness of the program’s key processes and controls, including our preparedness to respond to cybersecurity incidents that may adversely affect the confidentiality, integrity or availability of our information systems or any information residing therein.

[0001137789-25-000157:notes:4]
Cybersecurity risk management is an important part of our overall risk management efforts. We conduct mandatory cybersecurity awareness training for all employees, regardless of level or title, each year and provide additional training for designated roles, such as incident response personnel and senior management, on a case-by-case basis. We perform enterprise and site tabletop exercises annually to test our incident response procedures, identify gaps and improvement opportunities and exercise team preparedness. Information about cybersecurity risks and our risk management processes is collected, analyzed and considered as part of our overall risk management program.

[0001137789-25-000157:notes:5]
We periodically engage independent security firms and other third-party experts, where appropriate, to assess, test and certify components of our cybersecurity program, and to otherwise assist with aspects of our cybersecurity processes and controls. As part of our overall risk mitigation strategy, we maintain insurance coverage that is intended to address certain aspects of cybersecurity risks, however, such insurance may not be sufficient in type or amount to cover us against claims related to security breaches and incidents, cyberattacks and other related matters.

[0001137789-25-000157:notes:6]
In addition, we maintain a third-party cyber risk management process for vendors including, among other things, a security assessment and contracting program for vendors based on our assessment of their risk profile and periodic monitoring regarding adherence to applicable cybersecurity standards. We require our third-party service providers and suppliers to implement and maintain appropriate security measures commensurate with their risk profile and the scope of work being performed. We reassess third-party risk profiles periodically, request changes as we deem necessary based on that review, and require all third parties to promptly report any suspected breach of their security measures that may affect us. 
As of the date of this report, we have not identified any cybersecurity threats that have materially affected or are reasonably likely to materially affect our business strategy, results of operations or financial condition. Despite our security measures, however, we are unable to eliminate all cybersecurity threats. Accordingly, there can be no assurance that we have not experienced undetected security breaches or incidents, or that we will not experience a security breach or incident in the future. For additional information about these risks, see Part I, Item 1A, "Risk Factors" in this Annual Report on Form 10-K.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001137789-25-000157:notes:7]
Governance

[0001137789-25-000157:notes:8]
Our Board of Directors (the “Board”) considers cybersecurity risk as part of its risk oversight function and has delegated to the Audit and Finance Committee of the Board (the “Audit and Finance Committee”) oversight of cybersecurity and other information technology risks, including our plans designed to mitigate cybersecurity risks and to respond to data breaches.

[0001137789-25-000157:notes:9]
The Audit and Finance Committee receives regular reports (at least quarterly) from our Chief Information Security Officer (“CISO”) and our Senior Vice President and Chief Information Officer (“CIO”) on cybersecurity matters. These reports include a range of topics, including, as applicable, our cybersecurity risk profile, the current cybersecurity and emerging threat landscape, the status of any ongoing cybersecurity or other enterprise security risk management initiatives, incident reports and the results of internal and external assessments of our information systems. The Audit and Finance Committee also annually reviews the adequacy and effectiveness of our information and technology security processes and the internal controls regarding information and technology security and cybersecurity, and periodically receives updates from our internal audit function on the results of our cybersecurity audits and related mitigation activities.

[0001137789-25-000157:notes:10]
The Audit and Finance Committee reports to the Board regarding its activities, including those related to cybersecurity. The Board also receives a briefing from management on our cyber risk management program at least annually. Board members receive presentations on cybersecurity matters from our CISO and CIO, information security team or external experts as part of the Board’s continuing education on topics that impact public companies.

[0001137789-25-000157:notes:11]
At the management level, our CISO leads our enterprise-wide cybersecurity program, and is responsible for assessing and managing our material risks from cybersecurity threats. In performing his role, our CISO is informed about and monitors the prevention, detection, mitigation and remediation of cybersecurity risks and incidents through various means, which may include, among other things, briefings with internal security personnel, threat intelligence and other information obtained from governmental, public or private sources, including external consultants engaged by us, and alerts and reports produced by security tools deployed in our IT environment.

[0001137789-25-000157:notes:12]
Our CISO reports to our CIO who, in turn, reports directly to our CFO. Our CISO is an experienced cybersecurity executive with more than 20 years of experience building and leading cybersecurity, risk management, and information technology teams.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001137789-25-000157:notes:13]
Basis of Presentation and Summary of Significant Accounting Policies
Organization

[0001137789-25-000157:notes:14]
Seagate Technology Holdings plc (“STX”) and its subsidiaries (collectively, unless the context otherwise indicates, the “Company”) is a leading provider of data storage technology and infrastructure solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”) and storage subsystems and offers storage solutions such as a scalable edge-to-cloud mass data platform that includes data transfer shuttles and a storage-as-a-service cloud.

[0001137789-25-000157:notes:15]
Basis of Presentation and Consolidation

[0001137789-25-000157:notes:16]
The Company’s Consolidated Financial Statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

[0001137789-25-000157:notes:17]
The preparation of financial statements in accordance with the United States (“U.S.”) generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s Consolidated Financial Statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its Consolidated Financial Statements.

[0001137789-25-000157:notes:18]
Fiscal Year

[0001137789-25-000157:notes:19]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Fiscal years 2025, 2024 and 2023 are comprised of 52 weeks and ended on June 27, 2025, June 28, 2024 and June 30, 2023, respectively. All references to years in these Notes to Consolidated Financial Statements represent fiscal years unless otherwise noted. Fiscal year 2026 will be comprised of 53 weeks and will end on July 3, 2026.

[0001137789-25-000157:notes:20]
Summary of Significant Accounting Policies

[0001137789-25-000157:notes:21]
Cash and Cash Equivalents. The Company considers all highly liquid investments with a remaining maturity of 90 days or less at the time of purchase to be cash equivalents. The Company’s highly liquid investments are primarily comprised of money market funds, time deposits and certificates of deposits.

[0001137789-25-000157:notes:22]
Restricted Cash and Cash Equivalents. Restricted cash and cash equivalents represent cash and cash equivalents held as collateral at banks for various performance obligations.

[0001137789-25-000157:notes:23]
Inventories. Inventories are valued at the lower of cost (using the first-in, first-out method) and net realizable value. Net realizable value is based upon the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. Adjustments to reduce cost of inventories to its net realizable value are made, if required, for estimated excess or obsolescence determined primarily by future demand forecasts.

[0001137789-25-000157:notes:24]
Property, Equipment and Leasehold Improvements. Property, equipment and leasehold improvements are stated at cost less accumulated depreciation and amortization. Equipment and buildings are depreciated using the straight-line method over the estimated useful lives of the assets. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated life of the asset or the remaining term of the lease. The costs of additions and substantial improvements to property, equipment and leasehold improvements, which extend the economic life of the underlying assets, are capitalized. The cost of maintenance and repairs to property, equipment and leasehold improvements is expensed as incurred.

[0001137789-25-000157:notes:25]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. Effective from the first quarter of fiscal year 2024, the Company changed the useful lives of certain manufacturing equipment from a range of three to seven years to a range of three to ten years based on a review of the technology product roadmap. The effect of this change in estimate increased the net income by $99 million and increased the diluted earnings per share by $0.47 for the fiscal year ended June 28, 2024.

[0001137789-25-000157:notes:26]
Goodwill. The Company performs a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. If it is determined in the qualitative assessment that the fair value of a reporting unit is more likely than not below its carrying amount, including goodwill, then the Company will perform a quantitative impairment test. The quantitative goodwill impairment test is performed by comparing the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit over its fair value is recognized as an impairment loss, limited to the total amount of goodwill allocated to that reporting unit.

[0001137789-25-000157:notes:27]
Leases. The Company determines if an arrangement is a lease or contains a lease at inception. Right-of-use (“ROU”) assets are included in Other assets, net and lease liabilities are included in Accrued expenses and Other non-current liabilities in the Company’s Consolidated Balance Sheets. ROU assets represent the Company’s right to use an underlying asset for the lease term and the corresponding lease liabilities represent its obligation to make lease payments arising from the lease. The Company combines lease and non-lease components for facility leases and does not recognize ROU assets and lease liabilities for leases with an initial term of 12 months or less on the Consolidated Balance Sheets.

[0001137789-25-000157:notes:28]
Lease liabilities are measured at the present value of the remaining lease payments and ROU assets are based on the lease liability, adjusted for lease prepayments, lease incentives received and the lessee’s initial direct costs. For the Company’s leases that do not provide an implicit rate, the net present value of future minimum lease payments is determined using the Company’s estimated incremental borrowing rate based on the information available at the lease commencement date. Additionally, the Company’s lease term may include options to extend or terminate the lease. These options are reflected in the ROU asset and lease liability when it is reasonably certain that the Company will exercise the option. The Company’s lease agreements do not contain any material residual value guarantees.

[0001137789-25-000157:notes:29]
The Company recognizes lease expense on a straight-line basis over the lease term. Variable lease payments not dependent on an index or a rate primarily consist of common area maintenance charges, are expensed as incurred, and are not included in the ROU asset and lease liability calculation.

[0001137789-25-000157:notes:30]
Other Long-lived Assets. The Company tests other long-lived assets, including property, equipment and leasehold improvements, ROU assets and other intangible assets subject to amortization, for recoverability whenever events or changes in circumstances indicate that the carrying value of those assets may not be recoverable. If such circumstances are identified, the Company performs a recoverability test to assess the recoverability of an asset group. If the recoverability test indicates that the carrying value of the asset group is not recoverable, the Company will estimate the fair value of the asset group and the excess of the carrying value over the fair value is allocated pro rata to derive the adjusted carrying value of assets in the asset group.

[0001137789-25-000157:notes:31]
Warranty. The Company estimates probable product warranty costs at the time revenue is recognized and records the estimated charge in Cost of revenue on the Company’s Consolidated Statements of Operations. The Company generally provides warranty on its products for a period of 1 to 5 years. The Company's warranty provision considers estimated product failure rates, trends (including the timing of product returns during the warranty periods), and estimated repair or replacement costs related to product quality issues, if any. The Company also exercises judgment in estimating its ability to sell refurbished products.

[0001137789-25-000157:notes:32]
Revenue Recognition and Sales Incentive Programs. The Company determines revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, the Company satisfies a performance obligation.

[0001137789-25-000157:notes:33]
Revenue from sales of products is generally recognized upon transfer of control to customers in an amount that reflects the consideration the Company expects to receive in exchange for those products, net of sales taxes. This typically occurs upon shipment from the Company. When applicable, the Company includes shipping charges billed to customers in Revenue and includes the related shipping costs in Cost of revenue on the Company's Consolidated Statements of Operations.

[0001137789-25-000157:notes:34]
The Company records estimated variable consideration at the time of revenue recognition as a reduction to revenue. Variable consideration generally consists of expected rebates to be provided for sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For original equipment manufacturers (“OEMs”) sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer’s volume of purchases from the Company or other agreed upon rebate programs. For the distribution and retail channel, these programs typically involve estimating the most likely amount of rebates based on actual historical price incentives, known future price trends, and channel inventory level. Marketing development program costs are accrued and recorded as a reduction to revenue at the same time that the related revenue is recognized.

[0001137789-25-000157:notes:35]
At the end of the reporting period, the Company has unfulfilled product purchase orders which represent performance obligations not delivered, or partially undelivered under existing customer contracts. Some of these purchase orders are non-cancellable in nature. As of June 27, 2025, all non-cancellable purchase orders are less than one year in duration and are expected to be fulfilled in the next twelve months. The Company applied the optional exemption to not disclose the value of these remaining performance obligations as they are part of a contract that has an original expected duration of one year or less.

[0001137789-25-000157:notes:36]
The Company expenses sales commissions as incurred because the amortization period would have been one year or less. These costs are recorded as Marketing and administrative in the Company’s Consolidated Statements of Operations.

[0001137789-25-000157:notes:37]
Restructuring Costs. The Company incurs restructuring costs in connection with workforce reductions, consolidation or closure of facilities and other exit costs. The Company records employee termination liabilities when it is probable that benefits will be paid and the amount is reasonably estimable. The rates used in determining severance accruals are based on existing plans, historical experiences and negotiated settlements. Other costs associated with a restructuring plan or exit or disposal activities are recognized in the period in which the liability is incurred or the asset is impaired.

[0001137789-25-000157:notes:38]
Advertising Expense. The cost of advertising is expensed as incurred. Advertising costs were approximately $21 million, $18 million and $30 million in fiscal years 2025, 2024 and 2023, respectively.

[0001137789-25-000157:notes:39]
Share-Based Compensation. The Company accounts for share-based compensation at fair value, net of estimated forfeitures. When estimating forfeitures, the Company considers voluntary termination behavior as well as the historical analysis of actual forfeited awards. The Company estimates the fair value of granted share options and restricted share units (“RSUs”) using the Black-Scholes-Merton valuation model and a single share award approach. The Company estimates the fair value of performance-based share units (“PSUs”) related to the Company’s return on invested capital and total shareholder return using a Monte Carlo simulation valuation model. Share-based compensation expense for share options and RSUs with only a service condition is recognized on a straight-line basis over the requisite service period. The expense for PSUs with both a service condition and a performance or market condition is recognized on a graded vesting basis.

[0001137789-25-000157:notes:40]
Accounting for Income Taxes. The Company records a provision or benefit for income taxes for the anticipated tax consequences of the reported results of operations using the asset and liability method. Under this method, the Company recognizes deferred income tax assets and liabilities for the expected future consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, as well as for loss and tax credit carryforwards. Deferred tax assets and liabilities are measured using the tax rates that are expected to apply to taxable income for the years in which those tax assets and liabilities are expected to be realized or settled. The Company recognizes the deferred income tax effects of a change in tax rates in the period of the enactment. The Company periodically reassesses the need for valuation allowances on the deferred tax assets, considering both positive and negative evidence to evaluate whether it is more likely than not that all or a portion of such assets will not be realized.

[0001137789-25-000157:notes:41]
The Company recognizes a tax benefit only if it is more likely than not the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon settlement.

[0001137789-25-000157:notes:42]
Equity Investments. From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives, which are accounted for either under equity method or the measurement alternative. These investments are included in Other assets, net in the Company's Consolidated Balance Sheets and are subsequently adjusted through Other, net in the Consolidated Statements of Operations.

[0001137789-25-000157:notes:43]
Investments are accounted for under the equity method if the Company has the ability to exercise significant influence, but does not have a controlling financial interest. These investments are measured at cost, less any impairment plus the Company's portion of investee’s income or loss. The Company uses the financial statements of investees to determine any adjustments, which are received on a one-quarter lag.

[0001137789-25-000157:notes:44]
For equity investments where the Company does not have the ability to exercise significant influence and there are no readily determinable fair values, the Company has elected to apply the measurement alternative, under which investments are measured at cost, less impairment, and adjusted for qualifying observable price changes on a prospective basis.

[0001137789-25-000157:notes:45]
The Company’s strategic investments are periodically analyzed to determine whether or not there are indicators of impairment by assessing factors such as deterioration of earnings, adverse change in market/industry conditions, the ability to operate as a going concern, and other factors which indicate that the carrying amount of the investment might not be recoverable. In such a case, the decrease in value is recognized in the period the impairment occurs in the Consolidated Statements of Operations.

[0001137789-25-000157:notes:46]
Foreign Currency Remeasurement and Translation. The U.S. dollar is the functional currency for all of the Company's foreign operations. Monetary assets and liabilities denominated in foreign currencies are remeasured into the functional currency at the balance sheet date at exchange rates in effect at the end of each period. The gains and losses from the remeasurement are included in Other, net in the Company's Consolidated Statements of Operations.

[0001137789-25-000157:notes:47]
Business Combinations. The Company includes the results of operations of acquired businesses in the Company's consolidated results prospectively from the date of acquisition. The Company allocates the fair value of purchase consideration to the assets acquired including existing technology, liabilities assumed, and non-controlling interests, if any, in the acquired entity based on their fair values at the acquisition date. The excess of the fair value of purchase consideration over the fair value of the assets acquired, liabilities assumed and non-controlling interests in the acquired entity is recorded as goodwill. The primary items that generate goodwill include the value of the synergies between the acquired company and the Company and the value of the acquired assembled workforce, neither of which qualifies for recognition as an intangible asset. Acquisition-related expenses, post-acquisition integration and restructuring costs are recognized separately from the business combination and are expensed as incurred.

[0001137789-25-000157:notes:48]
Government Incentives. The Company enters into government incentive arrangements with domestic and foreign, local, regional and national governments, which vary in size, duration and conditions. Government incentives, primarily cash grants, are recognized when there is reasonable assurance that the incentives will be received and the Company will comply with the conditions specified in the agreement. Operating-related incentives are offset against the related expense in the period the expense is incurred. Capital-related incentives are recognized as a reduction in the carrying amounts of the related Property, equipment and leasehold improvements, net within the Company’s Consolidated Balance Sheets and result in a reduction to depreciation expense over the useful lives of the assets. Government incentives received prior to being earned are recognized in current or non-current deferred income within Accrued expenses and Non-current liabilities, whereas government incentives earned prior to being received are recognized in current or non-current receivables within Other current assets or Other asset, net, respectively, in the Company's Consolidated Balance Sheets. Cash received from government incentives related to operating expenses is included as an operating activity in the Statements of Cash Flows, whereas cash received from incentives related to the acquisition of property, equipment and leasehold improvements, net is included as an investing activity.

[0001137789-25-000157:notes:49]
Incentives received from governments are subject to various confidentiality provisions. In general, they are related to manufacturing of HDDs, enhancing centers of excellence, product development and innovation capabilities. These incentives have initial terms ranging from 1 to 5 years. If conditions are not satisfied, the incentives are subject to reduction, recapture or termination.

[0001137789-25-000157:notes:50]
In fiscal year 2025, approximately $38 million, $12 million and $5 million of operating grants were recognized as reductions to Cost of revenue, Product development and Marketing and administrative, respectively, in the Consolidated Statements of Operations. Capital-related incentives reduced gross property, plant and equipment by $45 million as of June 27, 2025 and the reduction to depreciation expense was not material. As of June 27, 2025, the grant receivables of $89 million were reflected within Other current assets in the Company's Consolidated Balance Sheets.

[0001137789-25-000157:notes:51]
In fiscal year 2024, approximately $3 million of operating grants were recognized as reductions to Cost of revenue and Product development in the Consolidated Statements of Operations. The Company also received advanced cash grants of $17 million, which were reflected within Accrued expenses in the Company's Consolidated Balance Sheets as of June 28, 2024. In fiscal year 2023, approximately $13 million of operating grants were recognized as reductions to Cost of revenue and Product development in the Consolidated Statements of Operations.

[0001137789-25-000157:notes:52]
Use of Estimates

[0001137789-25-000157:notes:53]
The preparation of financial statements requires management to make estimates, judgments and assumptions that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Estimates are assessed each period and updated to reflect current information, including those related to revenue recognition, share-based compensation, restructuring accruals, provision for taxes, valuation allowance for deferred taxes, provision for expected credit losses, inventory reserves, warranty accruals, and impairment assessments of goodwill, intangible assets and other long-lived assets. The Company believes that these estimates, judgments and assumptions are reasonable under the circumstances, and are subject to significant uncertainties, some of which are beyond the Company's control. Should any of these estimates change, it could adversely affect the Company's results of operations. Actual results could differ materially from these estimates under different assumptions or conditions.

[0001137789-25-000157:notes:54]
Concentrations

[0001137789-25-000157:notes:55]
Concentration of Credit Risk. The Company’s customer base is concentrated with a small number of customers. The Company does not generally require collateral or other security to support accounts receivable. To reduce credit risk, the Company performs ongoing credit evaluations on its customers’ financial condition. The Company establishes allowances for expected credit losses based upon factors surrounding the credit risk of customers, global macroeconomic conditions and an analysis of specific exposures. One customer accounted for more than 10% of the Company’s accounts receivable as of June 27, 2025 and June 28, 2024.

[0001137789-25-000157:notes:56]
Financial instruments that potentially subject the Company to concentrations of credit risk consist primarily of cash and cash equivalents and foreign currency forward exchange contracts. The Company maintains the cash and cash equivalents with four major financial institutions and a portion of such balances exceed or are not subject to Federal Deposit Insurance Corporation, or FDIC, insurance limits. The Company mitigates concentrations of credit risk in its financial instruments through diversification, by investing in highly-rated securities and/or major multinational companies.

[0001137789-25-000157:notes:57]
In entering into foreign currency forward exchange contracts, the Company assumes the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial and investment banks, and the Company has not incurred and does not expect any losses as a result of counterparty defaults.

[0001137789-25-000157:notes:58]
Supplier Concentration. Certain of the raw materials, components and equipment used by the Company in the manufacture of its products are available from single-sourced direct and indirect vendors. Shortages could occur in these essential materials and components due to an interruption of supply or increased demand in the industry. If the Company were unable to procure certain materials, components or equipment at all or acceptable prices, it would be required to reduce its manufacturing operations, which could have a material adverse effect on its results of operations.

[0001137789-25-000157:notes:59]
Recently Adopted Accounting Pronouncements

[0001137789-25-000157:notes:60]
In September 2022, the Financial Accounting Standards Board (FASB) issued ASU 2022-04 (ASC Subtopic 405-50), Disclosure of Supplier Finance Program Obligations. This ASU requires disclosure of key terms of the outstanding supplier finance programs and a roll forward of the related obligations. The Company adopted the disclosure requirement during the first quarter of fiscal year 2025. Refer to “Note 2. Balance Sheet Information” for more details.

[0001137789-25-000157:notes:61]
In November 2023, the FASB issued ASU 2023-07 (ASC Topic 280), Improvements to Reportable Segment Disclosures. This ASU improves reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The Company adopted the disclosure requirement for its annual reporting in fiscal year 2025 and is required to adopt the guidance for interim period reporting beginning the first quarter of fiscal year 2026 on a retrospective basis. Refer to “Note 15. Business Segment and Geographic Information”.

[0001137789-25-000157:notes:62]
Recently Issued Accounting Pronouncements
In December 2023, the FASB issued ASU 2023-09 (ASC Topic 740), Improvements to Income Tax Disclosures. This ASU requires disaggregated income tax disclosures on the rate reconciliation and income taxes paid. The Company is required to adopt this guidance for its annual reporting in fiscal year 2026 on a prospective basis but have the option to apply it retrospectively. This standard is expected to impact the Company’s disclosures and will not have impact on its Consolidated Financial Statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001137789-25-000157:notes:63]
Balance Sheet Information
Cash, Cash Equivalents and Restricted Cash

[0001137789-25-000157:notes:64]
The following table provides a summary of cash, cash equivalents and restricted cash reported within the Company’s Consolidated Balance Sheets that reconciles to the corresponding amount in the Company’s Consolidated Statements of Cash Flows:

[0001137789-25-000157:notes:65]
| (Dollars in millions) |  |  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |  |  |
| Cash and cash equivalents |  |  | $ | 891 |  |  | $ | 1,358 |  |  | $ | 786 |  |  |  |
| Restricted cash included in Other current assets |  |  | 2 |  |  | 2 |  |  | 2 |  |  |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  |  | $ | 893 |  |  | $ | 1,360 |  |  | $ | 788 |  |  |  |

[0001137789-25-000157:notes:66]
Accounts Receivable, net

[0001137789-25-000157:notes:67]
The details of the accounts receivable, net were as follows:

[0001137789-25-000157:notes:68]
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |
| Accounts receivable |  | $ | 963 |  |  | $ | 433 |  |
| Allowances for expected credit losses |  | (4) |  |  | (4) |  |
| Account receivable, net |  | $ | 959 |  |  | $ | 429 |  |

[0001137789-25-000157:notes:69]
In connection with the Company’s factoring agreements, from time to time the Company sells accounts receivables to third parties for cash proceeds less a discount. During fiscal year 2025, the Company sold account receivables without recourse for cash proceeds of $692 million and no amount remained subject to servicing by the Company as of June 27, 2025. During fiscal year 2024, the Company sold accounts receivables without recourse for cash proceeds of $1.2 billion, of which $294 million remained subject to servicing by the Company as of June 28, 2024. The discounts on accounts receivables sold were immaterial for fiscal year 2025, $11 million for fiscal year 2024 and $11 million for fiscal year 2023, respectively.

[0001137789-25-000157:notes:70]
Inventories, net

[0001137789-25-000157:notes:71]
The details of the inventory, net were as follows:

[0001137789-25-000157:notes:72]
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |
| Raw materials and components |  | $ | 374 |  |  | $ | 270 |  |
| Work-in-process |  | 838 |  |  | 831 |  |
| Finished goods |  | 228 |  |  | 138 |  |
| Total inventories, net |  | $ | 1,440 |  |  | $ | 1,239 |  |

[0001137789-25-000157:notes:73]
Other Current Assets

[0001137789-25-000157:notes:74]
The details of the other current assets were as follows:

[0001137789-25-000157:notes:75]
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |
| Vendor receivables |  | $ | 121 |  |  | $ | 110 |  |
| Other current assets |  | 242 |  |  | 196 |  |
| Total |  | $ | 363 |  |  | $ | 306 |  |

[0001137789-25-000157:notes:76]
Property, Equipment and Leasehold Improvements, net

[0001137789-25-000157:notes:77]
The components of property, equipment and leasehold improvements, net were as follows:

[0001137789-25-000157:notes:78]
| (Dollars in millions) |  | Useful Life in Years |  | June 27,2025 |  | June 28,2024 |
| Land and land improvements |  |  |  | $ | 18 |  |  | $ | 18 |  |
| Equipment |  | 3 – 10 |  | 8,566 |  |  | 8,632 |  |
| Buildings and leasehold improvements |  | Up to 30 |  | 1,413 |  |  | 1,412 |  |
| Construction in progress |  |  |  | 333 |  |  | 198 |  |
| Gross property, equipment and leasehold improvements |  |  |  | 10,330 |  |  | 10,260 |  |
| Less: accumulated depreciation and amortization |  |  |  | (8,673) |  |  | (8,646) |  |
| Property, equipment and leasehold improvements, net |  |  |  | $ | 1,657 |  |  | $ | 1,614 |  |

[0001137789-25-000157:notes:79]
Depreciation expense, which includes amortization of leasehold improvements, was $251 million, $264 million and $504 million for fiscal years 2025, 2024 and 2023, respectively. In fiscal year 2025, the accelerated depreciation expense was immaterial. In fiscal year 2024, the Company recognized a charge of $13 million for the accelerated depreciation of certain fixed assets, which was recorded to Cost of revenue in the Consolidated Statements of Operations. In fiscal year 2023, the Company recognized a charge of $85 million for the accelerated depreciation of certain fixed assets, of which $60 million and $25 million was recorded to Cost of revenue and Product development, respectively, in the Consolidated Statements of Operations. Interest on borrowings related to eligible capital expenditures is capitalized as part of the cost of the qualified assets and amortized over the estimated useful lives of the assets. During fiscal years 2025, 2024 and 2023, the Company’s capitalized interest was immaterial.

[0001137789-25-000157:notes:80]
Accrued Expenses

[0001137789-25-000157:notes:81]
The details of the accrued expenses were as follows:

[0001137789-25-000157:notes:82]
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |
| Dividends payable |  | $ | 153 |  |  | $ | 147 |  |
| Other accrued expenses |  | 479 |  |  | 507 |  |
| Total |  | $ | 632 |  |  | $ | 654 |  |

[0001137789-25-000157:notes:83]
Supplier Financing Arrangements

[0001137789-25-000157:notes:84]
The Company facilitates the opportunity for suppliers to participate in a voluntary supply chain financing ("SCF") program with third-party financial institutions. This SCF program does not result in changes to the Company's contractual payment terms with the suppliers regardless of program participation. At the suppliers' election, they can receive payment of the Company's obligations prior to the scheduled due dates, at a discount price to the third-party financial institution. The Company does not determine the terms or conditions of the arrangement between suppliers and the third-party financial institution. Participating suppliers are paid directly by the third-party financial institution and the Company pays the third-party financial institution the stated amount of confirmed invoices from its designated suppliers at the original invoice amount on the agreed due dates. The Company has not pledged any assets or provided other guarantees under its SCF program.

[0001137789-25-000157:notes:85]
All outstanding amounts related to suppliers participating in the SCF Program are recorded within Accounts payable in the Company's Consolidated Balance Sheets and the associated payments are included in Net cash provided by operating activities on its Consolidated Statements of Cash Flows.

[0001137789-25-000157:notes:86]
The details of the outstanding supplier financing obligation were as follows:

[0001137789-25-000157:notes:87]
|  |  | For the Fiscal Year Ended |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |
| Outstanding at the beginning of the period |  | 50 |  |  | 51 |  |
| Added to the program during the period |  | 1,344 |  |  | 891 |  |
| Settled during the period |  | (1,374) |  |  | (892) |  |
| Outstanding at the ending of the period |  | 20 |  |  | 50 |  |

[0001137789-25-000157:notes:88]
Accumulated Other Comprehensive (Loss) Income (“AOCI”)

[0001137789-25-000157:notes:89]
The components of AOCI, net of tax, were as follows:

[0001137789-25-000157:notes:90]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at June 30, 2023 |  | $ | 103 |  |  |  | $ | (4) |  |  | $ | (1) |  |  | $ | 98 |  |
| Other comprehensive (loss) income before reclassifications |  | (13) |  |  |  | 1 |  |  | 1 |  |  | (11) |  |
| Amounts reclassified from AOCI |  | (90) |  |  |  | 1 |  |  | — |  |  | (89) |  |
| Other comprehensive (loss) income |  | (103) |  |  |  | 2 |  |  | 1 |  |  | (100) |  |
| Balance at June 28, 2024 |  | — |  |  |  | (2) |  |  | — |  |  | (2) |  |
| Other comprehensive loss before reclassifications |  | $ | — |  |  |  | $ | (7) |  |  | $ | — |  |  | $ | (7) |  |
| Amounts reclassified from AOCI |  | — |  |  |  | 1 |  |  | — |  |  | 1 |  |
| Other comprehensive loss |  | — |  |  |  | (6) |  |  | — |  |  | (6) |  |
| Balance at June 27, 2025 |  | $ | — |  |  |  | $ | (8) |  |  | $ | — |  |  | $ | (8) |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001137789-25-000157:notes:91]
Goodwill and Other Intangible Assets
Goodwill

[0001137789-25-000157:notes:92]
The carrying amount of goodwill was $1.2 billion as of June 27, 2025 and June 28, 2024. Goodwill recognized as a result of the acquisition of Intevac, Inc. during fiscal year 2025 was not material. Goodwill divested as a result of the sale of SoC business during fiscal year 2024 was $18 million. There were no other material additions to, disposals of, impairments of or translation adjustments to goodwill in fiscal years 2025, 2024 and 2023.

[0001137789-25-000157:notes:93]
Other Intangible Assets

[0001137789-25-000157:notes:94]
Other intangible assets consist primarily of existing technology acquired in business combinations and are presented in Other assets, net in the Company’s Consolidated Balance Sheets. Intangibles are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization is charged to Operating expenses in the Consolidated Statements of Operations.

[0001137789-25-000157:notes:95]
Other intangible assets recognized as a result of the acquisition of Intevac, Inc. was $19 million, with immaterial amortization expense during fiscal year 2025. The weighted average remaining useful life is three years as of June 27, 2025. Refer to Note 17. Acquisition and Divestiture for more information. 
There was no net carrying value of other intangible assets subject to amortization as of June 28, 2024, and no amortization expense for fiscal year 2024. For fiscal year 2023, amortization expense for other intangible assets was $9 million.


## us-gaap:DebtDisclosureTextBlock

[0001137789-25-000157:notes:96]
Debt
The following table provides details of the Company’s debt as of June 27, 2025 and June 28, 2024:

[0001137789-25-000157:notes:97]
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | — |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | — |  |  | 505 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 452 |  |  | 471 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 138 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $400 issued on May 27, 2025 at 5.875% due July 15, 2030 (the “2030 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 400 |  |  | — |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 237 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 61 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | 1,500 |  |
|  |  | 5,027 |  |  | 5,704 |  |
| Less: unamortized debt issuance costs |  | (32) |  |  | (30) |  |
| Debt, net of debt issuance costs |  | 4,995 |  |  | 5,674 |  |
| Less: current portion of long-term debt |  | — |  |  | (479) |  |
| Long-term debt, less current portion |  | $ | 4,995 |  |  | $ | 5,195 |  |

[0001137789-25-000157:notes:98]
___________________________________

[0001137789-25-000157:notes:99]
(1) Except for the 2030 Notes, all unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and Seagate Technology Holdings plc. The 2030 Notes are issued by Seagate Data Storage Technology Pte. Ltd. (“SDST”) and the obligations under the 2030 Notes are fully and unconditionally guaranteed on a senior unsecured basis, by STUC, Seagate Technology Holdings plc, and Seagate HDD.

[0001137789-25-000157:notes:100]
2028 Exchangeable Senior Notes and related Capped Call Transactions

[0001137789-25-000157:notes:101]
2028 Notes. On September 13, 2023, Seagate HDD, in a private placement, issued $1.5 billion in aggregate principal amount of 3.50% Exchangeable Senior Notes due 2028 (the “2028 Notes”), which includes $200 million aggregate principal amount pursuant to the over-allotment option of the initial purchasers to purchase additional notes. The 2028 Notes will mature on June 1, 2028, with interest payable semi-annually on March 1 and September 1 of each year, commencing March 1, 2024.

[0001137789-25-000157:notes:102]
For the fiscal year ended June 27, 2025, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $52 million and immaterial amortization of debt issuance costs. For the fiscal year ended June 28, 2024, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $42 million and immaterial amortization of debt issuance costs.

[0001137789-25-000157:notes:103]
The entire outstanding principal amount of certain term loans were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in the Net (loss) gain from debt transactions in the Company’s Consolidated Statements of Operations in fiscal year 2024. In connection with the repayment of these loans, the Company terminated certain interest rate swap agreements on September 13, 2023 and received cash proceeds of $25 million from the counterparty. The cash proceeds are reported within Net cash provided by operating activities in the Company’s Consolidated Statements of Cash Flows during the fiscal year ended 2024. The Company discontinued the related hedge accounting prospectively and realized a net gain of $104 million in Net gain from termination of interest rate swap in the Consolidated Statements of Operations during the fiscal year ended 2024. Additionally, $6 million of the gains were amortized to Interest expense prior to the termination of interest rate swap in the Company’s Consolidated Statements of Operations in fiscal year 2024.

[0001137789-25-000157:notes:104]
Prior to March 1, 2028, the 2028 Notes are exchangeable at the option of the holders only under the following circumstances:

[0001137789-25-000157:notes:105]
•during any calendar quarter commencing after the calendar quarter ending on December 31, 2023 (and only during such calendar quarter), if the last reported sale price of the ordinary Shares for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter is greater than or equal to 130% of the exchange price in effect on each applicable trading day;

[0001137789-25-000157:notes:106]
•during the five business day period after any ten consecutive trading day period in which the trading price per $1,000 principal amount of 2028 Notes for each trading day period was less than 98% of the product of the last reported sale price of the ordinary shares and the applicable exchange rate on such trading day; or

[0001137789-25-000157:notes:107]
•upon the occurrence of specified corporate events described in the indenture with respect to the 2028 Notes.

[0001137789-25-000157:notes:108]
On or after March 1, 2028, the 2028 Notes are exchangeable at any time at the option of the holders until the close of business on the second scheduled trading day immediately preceding the maturity date, unless the 2028 Notes have been previously redeemed or repurchased by Seagate HDD.

[0001137789-25-000157:notes:109]
Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The current exchange rate for the 2028 Notes is 12.1324 ordinary shares per $1,000 principal amount of 2028 Notes, which is equivalent to an exchange price of $82.42 per share as of June 27, 2025. The exchange price is subject to adjustment pursuant to the terms of the indenture.

[0001137789-25-000157:notes:110]
Seagate HDD may redeem the 2028 Notes at its option, in whole but not in part, if Seagate HDD or the Guarantors have, or on the next interest payment date would, become obligated to pay to the holder of any Note additional amounts as a result of certain tax-related events at a redemption price equal to 100% of the principal amount plus accrued and unpaid interest, including additional interest, if any, to, but excluding, the redemption date (a “Tax Redemption”); provided that Seagate HDD may only redeem the 2028 Notes if: (x) Seagate HDD or the relevant Guarantor cannot avoid these obligations by taking commercially reasonable measures available to Seagate HDD or such Guarantor; and (y) Seagate HDD delivers to the Trustee an opinion of outside legal counsel of recognized standing in the relevant taxing jurisdiction attesting to such tax-related event and obligation to pay additional amounts.

[0001137789-25-000157:notes:111]
Seagate HDD also may redeem the 2028 Notes at its option on or after September 8, 2026, in whole or in part, if the last reported sale price of ordinary shares of the Company has been at least 130% of the exchange price then in effect for at least 20 trading days (whether or not consecutive), including the trading day immediately preceding the date on which Seagate HDD provides notice of redemption, during any 30 consecutive trading day period ending on, and including, the trading day immediately preceding the date on which Seagate HDD provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date (a “Provisional Redemption”). If Seagate HDD redeems less than all the outstanding 2028 Notes, at least $150 million aggregate principal amount of 2028 Notes must be outstanding and not subject to redemption as of the relevant notice of redemption date.

[0001137789-25-000157:notes:112]
If Seagate HDD elects to redeem any of the 2028 Notes pursuant to a Tax Redemption or a Provisional Redemption, then a holder of any 2028 Notes called pursuant to a Tax Redemption or Provisional Redemption (the “Redemption Called Notes”) may exchange such Redemption Called Notes at any time prior to the close of business on the second scheduled trading day preceding the relevant redemption date, even if such Redemption Called Note is not otherwise exchangeable at that time. After this time, the right to exchange any Redemption Called Notes will expire unless Seagate HDD fails to pay the applicable redemption price, in which case a holder may exchange any Redemption Called Notes until the redemption price is paid.

[0001137789-25-000157:notes:113]
If a holder elects to exchange any Redemption Called Notes, Seagate HDD shall, under certain circumstances, increase the exchange rate for such Redemption Called Notes as set out in the indenture.

[0001137789-25-000157:notes:114]
As of the calendar quarter ended June 30, 2025 (subsequent to the Company’s Consolidated Balance Sheet date), the conditional conversion feature of the 2028 Notes was triggered, based on the price of the Company’s ordinary shares, as the last reported sale price of the Company’s ordinary shares was at least 130% of the then-applicable exchange price then in effect for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days which ended on June 30, 2025, the last trading day of the applicable quarter. Accordingly, the 2028 Notes are exchangeable through September 30, 2025.

[0001137789-25-000157:notes:115]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The current cap price of the capped call transactions is $107.785 per share. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Consolidated Balance Sheets.

[0001137789-25-000157:notes:116]
2025 Notes

[0001137789-25-000157:notes:117]
On January 2, 2025, the entire outstanding principal amount of $479 million was repaid at par, plus accrued and unpaid interest.

[0001137789-25-000157:notes:118]
2030 Notes and 2027 Notes

[0001137789-25-000157:notes:119]
2030 Notes. On May 27, 2025, Seagate Data Storage Technology Pte. Ltd, in a private placement, issued $400 million in aggregate principal amount of 5.875% Senior Notes due 2030 (the “2030 Notes”). The 2030 Notes will mature on July 15, 2030, with interest payable semi-annually on January 15 and July 15 of each year, commencing January 15, 2026.

[0001137789-25-000157:notes:120]
2027 Notes. On June 11, 2025, in connection with the proceeds from the offering of the 2030 Notes, together with cash on hand, the entire outstanding principal amount of the 2027 Notes was repaid. The transaction was accounted for as a debt extinguishment and the Company recorded a net loss of $5 million, which was included in Net (loss) gain from debt transactions in the Company’s Consolidated Statements of Operations for fiscal year 2025.

[0001137789-25-000157:notes:121]
Debt Repurchases

[0001137789-25-000157:notes:122]
During fiscal year 2025, $24 million principal amount of the June 2029 Notes, $25 million principal amount of the July 2029 Notes, $39 million principal amount of the January 2031 Notes and $11 million principal amount of the July 2031 Notes were repurchased for cash at a discount to their principal amounts, plus accrued and unpaid interest. The Company recorded a net gain of $7 million on these repurchases during fiscal year 2025, which was included in Net (loss) gain from debt transactions in the Company’s Consolidated Statements of Operations.

[0001137789-25-000157:notes:123]
Obligor Exchange

[0001137789-25-000157:notes:124]
On June 27, 2025, the Company completed offers to exchange (collectively, the “Exchange Offers” and each, an “Exchange Offer”) any and all outstanding notes of eight series issued by Seagate HDD (the “Old Notes”) for new notes to be issued by SDST (the “New Notes”), and related consent solicitations. The Exchange Offers commenced on May 28, 2025 and expired on June 26, 2025 (the “Expiration Time”).

[0001137789-25-000157:notes:125]
As of the Expiration Time, an aggregate of $2.8 billion principal amount of Old Notes had been validly tendered (and consents thereby validly delivered) as set forth in the table below (presented dollars in millions). Each eligible holder who validly tendered their Old Notes pursuant to an Exchange Offer was deemed to have validly delivered its consent in the corresponding consent solicitation with respect to the principal amount of such tendered Old Notes.

[0001137789-25-000157:notes:126]
| Title of Security |  | Principal Amount Outstanding (1)(In millions) |  | Principal Amount Tendered at Expiration Time(2)(In millions) |  | Approximate Percentage of Outstanding Notes Tendered at Expiration Time |
| 4.091% Senior Notes due 2029 |  | $ | 470 |  |  | $ | 431 |  |  | 91.60 | % |
| 3.125% Senior Notes due 2029 |  | 138 |  | 100 |  | 72.39 | % |
| 8.250% Senior Notes due 2029 |  | 500 |  | 492 |  | 98.40 | % |
| 4.125% Senior Notes due 2031 |  | 237 |  | 213 |  | 90.10 | % |
| 3.375% Senior Notes due 2031 |  | 61 |  | 45 |  | 73.66 | % |
| 8.500% Senior Notes due 2031 |  | 500 |  | 471 |  | 94.14 | % |
| 9.625% Senior Notes due 2032 |  | 750 |  | 731 |  | 97.43 | % |
| 5.750% Senior Notes due 2034 |  | 490 |  | 328 |  | 66.86 | % |
|  |  | $ | 3,146 |  |  | $ | 2,811 |  |  |  |

[0001137789-25-000157:notes:127]
__________________________________

[0001137789-25-000157:notes:128]
(1) Reflects the principal amount of Old Notes outstanding as of May 28, 2025.

[0001137789-25-000157:notes:129]
(2) Reflects the aggregate principal amount of Old Notes that were validly tendered prior to the Expiration Time and were therefore exchanged.

[0001137789-25-000157:notes:130]
In accordance with the terms of the Exchange Offers and consent solicitations, the Company accepted for exchange all Old Notes validly tendered and not validly withdrawn. Subsequent to the Company’s Consolidated Balance Sheet date, the Exchange Offers and the consent solicitations were settled on June 30, 2025 (the “Settlement Date”). No gain or loss was recorded as the Exchange Offers were accounted for as a debt modification. The Company incurred immaterial third party fees for the Exchange Offers as of fiscal year 2025.

[0001137789-25-000157:notes:131]
Other than the identity of SDST as the issuer and as an obligor, the terms of the New Notes are identical to the Old Notes with respect to their interest rate, interest payment dates, optional redemption prices and maturity. The New Notes were guaranteed by the same guarantors as the Old Notes, in addition to Seagate HDD (which is the issuer of the Old Notes). The New Notes have substantially the same covenants as the Old Notes and are subject to the same business and financial risks.

[0001137789-25-000157:notes:132]
Credit Agreement

[0001137789-25-000157:notes:133]
On January 30, 2025, the Company and its subsidiary Seagate HDD Cayman (the “Borrower”), the Bank of Nova Scotia, as administrative agent, and the lenders thereto entered into a Credit Agreement (the “New Credit Agreement”) and terminated their then-existing Credit Agreement, dated as of February 20, 2019 (the “Old Credit Agreement”). As a result of terminating the Old Credit Agreement, the Company recorded an $8 million non-cash loss related to the accelerated amortization of debt issuance costs, which was included in Net (loss) gain from debt transactions in the Company’s Consolidated Statements of Operations.

[0001137789-25-000157:notes:134]
The New Credit Agreement provides for a $1.3 billion senior unsecured revolving credit facility (“Revolving Credit Facility”), the term of which is through January 30, 2030. The Revolving Credit Facility is available for cash borrowings, subject to compliance with certain covenants and other customary conditions to borrowing. An aggregate amount of up to $150 million of the facility shall also be available for the issuance of letters of credit, and an aggregate amount of up to $50 million of the facility shall also be available for swing line loans. On June 27, 2025, no borrowings were outstanding under the New Credit Agreement.

[0001137789-25-000157:notes:135]
The loans made under the New Credit Agreement will bear interest at an Applicable Rate based on the secured overnight financing rate, or SOFR, plus a variable margin that will be determined based on the corporate credit rating of the Company. The Borrower’s obligations under the New Credit Agreement are guaranteed by the Company and certain material subsidiaries of the Company.

[0001137789-25-000157:notes:136]
The New Credit Agreement also contains a financial covenant that requires the Company to maintain a total net leverage ratio of less than or equal to 6.75 to 1.00, commencing with the fiscal quarter ended June 27, 2025 and declining over time so that the maximum permitted net leverage ratio for each fiscal quarter ending after July 2, 2027 is 4.25 to 1.00, in accordance with the terms of the New Credit Agreement. For each fiscal quarter until January 2, 2026, this net leverage ratio covenant applies only to the extent that there is any amount of revolving loans, swing line loans, or letters of credit outstanding as of the last day of the relevant fiscal quarter.

[0001137789-25-000157:notes:137]
Future Principal Payments on Long-term Debt

[0001137789-25-000157:notes:138]
At June 27, 2025, future principal payments on long-term debt were as follows (in millions):

[0001137789-25-000157:notes:139]
| Fiscal Year |  | Amount |
| 2026 |  | $ | — |  |
| 2027 |  | — |  |
| 2028 |  | 1,500 |  |
| 2029 |  | 470 |  |
| 2030 |  | 638 |  |
| Thereafter |  | 2,438 |  |
| Total |  | $ | 5,046 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001137789-25-000157:notes:140]
Income Taxes
Income (loss) before income taxes consisted of the following:

[0001137789-25-000157:notes:141]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |
| U.S. |  | $ | 233 |  |  | $ | 249 |  |  | $ | 300 |  |
| Non-U.S. |  | 1,280 |  |  | 196 |  |  | (796) |  |
|  |  | $ | 1,513 |  |  | $ | 445 |  |  | $ | (496) |  |

[0001137789-25-000157:notes:142]
The provision for income taxes consisted of the following:

[0001137789-25-000157:notes:143]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |
| Current income tax expense: |  |  |  |  |  |  |
| U.S. |  | $ | 16 |  |  | $ | 2 |  |  | $ | 6 |  |
| Non-U.S. |  | 32 |  |  | 30 |  |  | 17 |  |
| Total Current |  | 48 |  |  | 32 |  |  | 23 |  |
| Deferred income tax expense: |  |  |  |  |  |  |
| U.S. |  | (5) |  |  | 71 |  |  | 9 |  |
| Non-U.S. |  | 1 |  |  | 7 |  |  | 1 |  |
| Total Deferred |  | (4) |  |  | 78 |  |  | 10 |  |
| Provision for income taxes |  | $ | 44 |  |  | $ | 110 |  |  | $ | 33 |  |

[0001137789-25-000157:notes:144]
The significant components of the Company’s deferred tax assets and liabilities were as follows:

[0001137789-25-000157:notes:145]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |
| Deferred tax assets |  |  |  |  |
| Accrued warranty |  | $ | 32 |  |  | $ | 37 |  |
| Inventory carrying value adjustments |  | 37 |  |  | 32 |  |
| Receivable allowances |  | 15 |  |  | 9 |  |
| Accrued compensation and benefits |  | 66 |  |  | 36 |  |
| Capitalized research expenses |  | 110 |  |  | — |  |
| Depreciation |  | 4 |  |  | 19 |  |
| Restructuring accruals |  | — |  |  | 2 |  |
| Lease liabilities |  | 64 |  |  | 64 |  |
| Other accruals and deferred items |  | 10 |  |  | 11 |  |
| Net operating losses |  | 477 |  |  | 613 |  |
| Tax credit carryforwards |  | 598 |  |  | 593 |  |
| Capital loss carryforwards |  | 72 |  |  | 67 |  |
| Other assets |  | 55 |  |  | 40 |  |
| Gross: Deferred tax assets |  | 1,540 |  |  | 1,523 |  |
| Less: Valuation allowance |  | (423) |  |  | (430) |  |
| Net: Deferred tax assets |  | 1,117 |  |  | 1,093 |  |
| Deferred tax liabilities |  |  |  |  |
| Unremitted earnings of certain non-U.S. entities |  | (5) |  |  | (4) |  |
| Acquisition-related items |  | — |  |  | (1) |  |
| Right-of-use assets |  | (59) |  |  | (63) |  |
| Net: Deferred tax liabilities |  | (64) |  |  | (68) |  |
| Total net deferred tax assets |  | $ | 1,053 |  |  | $ | 1,025 |  |

[0001137789-25-000157:notes:146]
At June 27, 2025, the Company recorded $1.1 billion of net deferred tax assets. The realization of most of these deferred tax assets is primarily dependent on the Company’s ability to generate sufficient U.S. and certain non-U.S. taxable income in future periods. Although realization is not assured, the Company’s management believes it is more likely than not that these deferred tax assets will be realized. The amount of deferred tax assets considered realizable, however, may increase or decrease in subsequent periods when the Company re-evaluates the underlying basis for its estimates of future U.S. and certain non-U.S. taxable income.

[0001137789-25-000157:notes:147]
The deferred tax asset valuation allowance decreased by $7 million in fiscal year 2025, which primarily relates to releases in valuation allowance, partially offset with acquired deferred tax balances which are not likely to be realized.

[0001137789-25-000157:notes:148]
At June 27, 2025, the Company had U.S. tax net operating loss and credit carryforwards of approximately $3.0 billion and $726 million, respectively, of which approximately $7 million and $24 million, respectively, are scheduled to expire at various dates in fiscal year 2026, if not utilized. At June 27, 2025, the Company had non-U.S. tax net operating loss carryforwards of approximately $300 million, all of which are indefinite lived. As of June 27, 2025, the Company had gross U.S. capital loss carryforwards of $288 million, which if not utilized, will expire as of fiscal year 2029. As of June 27, 2025, the Company had gross non-U.S. capital loss carryforwards of $23 million, which have an indefinite carryforward period.

[0001137789-25-000157:notes:149]
As of June 27, 2025, approximately $102 million and $41 million of the Company’s total U.S. net operating loss and tax credit carryforwards, respectively, are subject to annual limitations due to the ownership change limitations provided by the Internal Revenue Code.

[0001137789-25-000157:notes:150]
The Company established Singapore as its principal executive offices in fiscal year 2024. The Singaporean statutory tax rate of 17% is used for purposes of the reconciliation between the provision for income taxes at the statutory rate and the effective tax rate. For fiscal year 2023, a notional Irish statutory rate of 25% was used.

[0001137789-25-000157:notes:151]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |
| Provision (benefit) at statutory rate |  | $ | 257 |  |  | $ | 76 |  |  | $ | (124) |  |
| Permanent differences |  | 4 |  |  | 5 |  |  | 8 |  |
| Valuation allowance |  | (18) |  |  | 47 |  |  | (18) |  |
| Effect of rates different than statutory |  | (190) |  |  | (2) |  |  | 178 |  |
| Research credit |  | (6) |  |  | (9) |  |  | (18) |  |
| Capital loss carryforward |  | (2) |  |  | (11) |  |  | — |  |
| Other individually immaterial items |  | (1) |  |  | 4 |  |  | 7 |  |
| Provision for income taxes |  | $ | 44 |  |  | $ | 110 |  |  | $ | 33 |  |

[0001137789-25-000157:notes:152]
A substantial portion of the Company's operations in Singapore and Thailand operate under various tax incentive programs, which expire in whole or in part at various dates into fiscal year 2036. Certain tax incentives may be extended if specific conditions are met. The net impact of these tax incentive programs was to increase the Company’s net income by approximately $285 million in fiscal year 2025 ($1.32 per share, diluted), to increase the Company's net income by approximately $40 million in fiscal year 2024 ($0.19 per share, diluted) and to decrease the Company’s net loss by approximately $14 million in fiscal year 2023 ($0.07 per share, basic).

[0001137789-25-000157:notes:153]
The Company analyzes the potential needs for deferred tax liabilities with respect to the accumulated earnings of foreign subsidiaries annually. The analysis focuses on the outside basis differences in the stock of the foreign subsidiaries as well as the withholding tax obligations those subsidiaries may have with respect to any distribution. The undistributed earnings for which taxes are not provided are permanently reinvested or can be repatriated without incremental tax liability.

[0001137789-25-000157:notes:154]
As of June 27, 2025 and June 28, 2024, the Company had approximately $107 million and $112 million, respectively, of unrecognized tax benefits excluding interest and penalties. These amounts, if recognized, would impact the effective tax rate subject to certain future valuation allowance offsets.

[0001137789-25-000157:notes:155]
The following table summarizes the activities related to the Company’s gross unrecognized tax benefits:

[0001137789-25-000157:notes:156]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |
| Balance of unrecognized tax benefits at the beginning of the year |  | $ | 112 |  |  | $ | 116 |  |  | $ | 114 |  |
| Gross increase for tax positions of prior years |  | 2 |  |  | 3 |  |  | — |  |
| Gross decrease for tax positions of prior years |  | (17) |  |  | (12) |  |  | (4) |  |
| Gross increase for tax positions of current year |  | 11 |  |  | 5 |  |  | 7 |  |
| Gross decrease for tax positions of current year |  | — |  |  | — |  |  | (1) |  |
| Balance of unrecognized tax benefits at the end of the year |  | $ | 107 |  |  | $ | 112 |  |  | $ | 116 |  |

[0001137789-25-000157:notes:157]
It is the Company’s policy to include interest and penalties related to unrecognized tax benefits in the provision for income taxes in the Consolidated Statements of Operations. Interest and penalties recorded on these tax positions were not material to any periods presented in the Consolidated Statements of Operations. As of June 27, 2025, accrued interest and penalties related to unrecognized tax benefits did not materially change compared to fiscal year 2024.

[0001137789-25-000157:notes:158]
During the 12 months beginning June 28, 2025, the Company does not expect a material change to its unrecognized tax benefits as a result of the expiration of certain statutes of limitation.
The Company is required to file U.S. and non-U.S. income tax returns. The Company is no longer subject to examination of its U.S. income tax returns for years prior to fiscal year 2020 and prior to fiscal year 2013 for non-U.S. income tax returns.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001137789-25-000157:notes:159]
Leases
The Company is a lessee in several operating leases related to real estate facilities for warehouse, office and lab space.

[0001137789-25-000157:notes:160]
The Company’s lease arrangements comprise operating leases with various expiration dates through 2068. The lease term includes the non-cancelable period of the lease, adjusted for options to extend or terminate the lease when it is reasonably certain that an option will be exercised.

[0001137789-25-000157:notes:161]
During fiscal years 2024 and 2023, the Company sold and leased back certain properties and recorded a net gain of $30 million and $156 million respectively, within Restructuring and other, net in the Consolidated Statements of Operations.

[0001137789-25-000157:notes:162]
Operating lease costs include short-term lease costs and are shown net of immaterial sublease income. The components of lease costs and other information related to leases were as follows:

[0001137789-25-000157:notes:163]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |  |  | June 30,2023 |
| Operating lease cost |  | $ | 76 |  |  | $ | 72 |  |  |  | $ | 21 |  |
| Variable lease cost |  | 5 |  |  | 3 |  |  | 3 |
| Total lease cost |  | $ | 81 |  |  | $ | 75 |  |  |  | $ | 24 |  |
| Operating cash outflows from operating leases |  | $ | 69 |  |  | $ | 63 |  |  |  | $ | 23 |  |

[0001137789-25-000157:notes:164]
During fiscal year 2025 the ROU assets obtained in exchange for new operating lease liabilities was not material. During fiscal years 2024 and 2023, the Company obtained $47 million and $353 million ROU assets in exchange for new operating lease liabilities, respectively.

[0001137789-25-000157:notes:165]
|  |  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |
| Weighted-average remaining lease term |  | 7.7 years |  | 8.6 years |  | 9.6 years |
| Weighted-average discount rate |  | 8.55 | % |  | 8.45 | % |  | 8.49 | % |

[0001137789-25-000157:notes:166]
ROU assets and lease liabilities included in the Company’s Consolidated Balance Sheets were as follows:

[0001137789-25-000157:notes:167]
| (Dollars in millions) |  | Balance Sheet Location |  | June 27,2025 |  | June 28,2024 |
| ROU assets |  | Other assets, net |  | $ | 353 |  |  | $ | 403 |  |
| Current lease liabilities |  | Accrued expenses |  | 61 |  |  | 61 |
| Non-current lease liabilities |  | Other non-current liabilities |  | 317 |  |  | 338 |

[0001137789-25-000157:notes:168]
At June 27, 2025, future lease payments included in the measurement of lease liabilities were as follows (in millions):

[0001137789-25-000157:notes:169]
| Fiscal Year |  | Amount |
| 2026 |  | $ | 64 |  |
| 2027 |  | 63 |  |
| 2028 |  | 64 |  |
| 2029 |  | 65 |  |
| 2030 |  | 64 |  |
| Thereafter |  | 196 |  |
| Total lease payments |  | 516 |  |
| Less: imputed interest |  | (138) |  |
| Present value of lease liabilities |  | $ | 378 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001137789-25-000157:notes:170]
Restructuring and Other, Net
During fiscal years 2025, 2024 and 2023, the Company recorded restructuring and other, net charge of $25 million, benefit of $30 million, and charge of $102 million, respectively, in the Company’s Consolidated Statements of Operations. The Company’s restructuring plans are comprised primarily of charges related to workforce reduction costs, including severance and other one-time termination benefits and facilities and other exit costs.

[0001137789-25-000157:notes:171]
The following table summarizes the Company’s restructuring activities for fiscal year 2025:

[0001137789-25-000157:notes:172]
| (Dollars in millions) |  |  |  |  |  |  |  |  |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual Balance at June 28, 2024 |  |  |  |  |  |  |  |  |  | 3 |  |  | 1 |  |  | 4 |  |
| Restructuring charges |  |  |  |  |  |  |  |  |  | 15 |  |  | 10 |  |  | 25 |  |
| Cash payments |  |  |  |  |  |  |  |  |  | (14) |  |  | — |  |  | (14) |  |
| Accrual Balance at June 27, 2025 |  |  |  |  |  |  |  |  |  | $ | 4 |  |  | $ | 11 |  |  | $ | 15 |  |
| Total costs incurred to date as of June 27, 2025 |  |  |  |  |  |  |  |  |  | $ | 85 |  |  | $ | 20 |  |  | $ | 105 |  |
| Total expected costs to be incurred as of June 27, 2025 |  |  |  |  |  |  |  |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |

[0001137789-25-000157:notes:173]
Of the accrued restructuring balance of $15 million at June 27, 2025, $6 million was included in Accrued expenses and $9 million was included in Other non-current liabilities in the Company’s Consolidated Balance Sheets. The accrued restructuring balance of $4 million at June 28, 2024 was included in Accrued expenses in the Company’s Consolidated Balance Sheets.

[0001137789-25-000157:notes:174]
In fiscal year 2025, the Company also recorded $13 million restructuring charges within Cost of revenue in the Company’s Consolidated Statements of Operations as the charges were related to an inventory write down due to a discontinued product line.

[0001137789-25-000157:notes:175]
During fiscal years 2024 and 2023, the Company sold certain properties and assets and recognized a net gain of $31 million and $167 million, respectively. The net gain was included in Restructuring and other, net in the Company’s Consolidated Statements of Operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001137789-25-000157:notes:176]
Fair Value
Measurement of Fair Value

[0001137789-25-000157:notes:177]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact and it considers assumptions that market participants would use when pricing the asset or liability.

[0001137789-25-000157:notes:178]
Fair Value Hierarchy

[0001137789-25-000157:notes:179]
A fair value hierarchy is based on whether the market participant assumptions used in determining fair value are obtained from independent sources (observable inputs) or reflect the Company's own assumptions of market participant valuation (unobservable inputs). A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The three levels of inputs that may be used to measure fair value are:

[0001137789-25-000157:notes:180]
Level 1 - Quoted prices in active markets that are unadjusted and accessible at the measurement date for identical, unrestricted assets or liabilities;

[0001137789-25-000157:notes:181]
Level 2 - Quoted prices for identical assets and liabilities in markets that are inactive; quoted prices for similar assets and liabilities in active markets or financial instruments for which significant inputs are observable, either directly or indirectly; or

[0001137789-25-000157:notes:182]
Level 3 - Prices or valuations that require inputs that are both unobservable and significant to the fair value measurement.

[0001137789-25-000157:notes:183]
The Company considers an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis and views an inactive market as one in which there are few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, the Company’s or the counterparty’s non-performance risk is considered in determining the fair values of liabilities and assets, respectively.

[0001137789-25-000157:notes:184]
Items Measured at Fair Value on a Recurring Basis

[0001137789-25-000157:notes:185]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of:

[0001137789-25-000157:notes:186]
|  |  |  |  | June 27, 2025 |  | June 28, 2024 |
|  |  |  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Balance SheetLocation |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | Cash and cash equivalents |  | $ | 226 |  |  | $ | — |  |  | $ | — |  |  | $ | 226 |  |  | $ | 386 |  |  | $ | — |  |  | $ | — |  |  | $ | 386 |  |
| Time deposits |  | Cash and cash equivalents |  | — |  |  | 26 |  |  | — |  |  | 26 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total cash equivalents |  | 226 |  |  | 26 |  |  | — |  |  | 252 |  |  | 386 |  |  | — |  |  | — |  |  | 386 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | Other current assets |  | 1 |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | Other current assets |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | Other assets, net |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 15 |  |  | 15 |  |
| Derivative assets |  | Other current assets |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total assets |  |  |  | $ | 227 |  |  | $ | 28 |  |  | $ | — |  |  | $ | 255 |  |  | $ | 387 |  |  | $ | 2 |  |  | $ | 15 |  |  | $ | 404 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | Accrued expenses |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (1) |  |  | $ | — |  |  | $ | (1) |  |
| Total liabilities |  |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (1) |  |  | $ | — |  |  | $ | (1) |  |

[0001137789-25-000157:notes:187]
As of June 27, 2025 and June 28, 2024, the Company’s Other current assets included $2 million in restricted cash equivalents held as collateral at banks for various performance obligations.

[0001137789-25-000157:notes:188]
As of June 27, 2025 and June 28, 2024, the Company had no material available-for-sale investments that had been in a continuous unrealized loss position for a period greater than 12 months. In fiscal year 2025, the Company sold available-for-sale investments for $41 million. The Company also recorded a net loss of $15 million on available-for-sale investments, related to downward adjustments to write down the carrying amount of certain investments to their fair value during fiscal year 2025, which was recorded to Other, net in the Company’s Consolidated Statements of Operations. The Company determined no impairment related to credit losses for available-for-sale investments for fiscal year 2024.

[0001137789-25-000157:notes:189]
The fair value and amortized cost of the Company’s available-for-sale investments as of June 27, 2025, was immaterial. The fair value and amortized cost of the Company’s available-for-sale investments as of June 28, 2024 was $15 million due in 2 years.

[0001137789-25-000157:notes:190]
Items Measured at Fair Value on a Non-Recurring Basis

[0001137789-25-000157:notes:191]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives, which are accounted for either under the equity method or the measurement alternative. Investments under the measurement alternative are recorded at cost, less impairment and adjusted for qualifying observable price changes on a prospective basis. If measured at fair value in the Consolidated Balance Sheets, these investments would generally be classified in Level 3 of the fair value hierarchy.

[0001137789-25-000157:notes:192]
For the investments that are accounted for under the equity method, the Company sold certain investments for $9 million and recorded an immaterial gain for fiscal year 2025. The Company sold certain investments for $14 million and recorded an immaterial gain for the fiscal year 2024. The Company recorded a net loss of $29 million for fiscal year 2024, which included $25 million related to downward adjustments to write down the carrying amount of certain investments to their fair value. The Company recorded an immaterial net loss in fiscal year 2023. The adjusted carrying value of the investments accounted under the equity method was immaterial and $12 million as of June 27, 2025 and June 28, 2024 respectively.

[0001137789-25-000157:notes:193]
For the investments that are accounted under the measurement alternative, the Company recorded a net loss of $39 million and $24 million for fiscal years 2025 and 2024, respectively, related to downward adjustments to write down the carrying amount of certain investments to their fair value. For fiscal year 2023, the Company recorded an immaterial net loss. As of June 27, 2025 and June 28, 2024, the carrying value of the Company’s strategic investments under the measurement alternative was $26 million and $65 million, respectively.

[0001137789-25-000157:notes:194]
Other Fair Value Disclosures

[0001137789-25-000157:notes:195]
The Company’s debt is carried at amortized cost. The estimated fair value of the Company’s debt is derived using the closing price of the same debt instruments as of the date of valuation, which takes into account the yield curve, interest rates and other observable inputs. Accordingly, these fair value measurements are categorized as Level 2. The following table presents the fair value and amortized cost of the Company’s debt in order of maturity:

[0001137789-25-000157:notes:196]
|  |  | June 27, 2025 |  | June 28, 2024 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 4.75% Senior Notes due January 2025 |  | — |  |  | — |  |  | 479 |  |  | 476 |  |
| 4.875% Senior Notes due June 2027 |  | — |  |  | — |  |  | 505 |  |  | 493 |  |
| 3.50% Exchangeable Senior Notes due June 2028 |  | 1,500 |  |  | 2,654 |  |  | 1,500 |  |  | 2,070 |  |
| 4.091% Senior Notes due June 2029 |  | 452 |  |  | 453 |  |  | 471 |  |  | 459 |  |
| 3.125% Senior Notes due July 2029 |  | 138 |  |  | 125 |  |  | 163 |  |  | 139 |  |
| 8.25% Senior Notes due December 2029 |  | 500 |  |  | 535 |  |  | 500 |  |  | 537 |  |
| 5.875% Senior Notes due July 2030 |  | 400 |  |  | 407 |  |  | — |  |  | — |  |
| 4.125% Senior Notes due January 2031 |  | 237 |  |  | 218 |  |  | 275 |  |  | 245 |  |
| 3.375% Senior Notes due July 2031 |  | 61 |  |  | 52 |  |  | 72 |  |  | 58 |  |
| 8.50% Senior Notes due July 2031 |  | 500 |  |  | 538 |  |  | 500 |  |  | 538 |  |
| 9.625% Senior Notes due December 2032 |  | 750 |  |  | 854 |  |  | 750 |  |  | 855 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 482 |  |  | 489 |  |  | 472 |  |
|  |  | $ | 5,027 |  |  | $ | 6,318 |  |  | $ | 5,704 |  |  | $ | 6,342 |  |
| Less: unamortized debt issuance costs |  | (32) |  |  | — |  |  | (30) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 4,995 |  |  | $ | 6,318 |  |  | $ | 5,674 |  |  | $ | 6,342 |  |
| Less: current portion of debt, net of debt issuance costs |  | — |  |  | — |  |  | (479) |  |  | (476) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 4,995 |  |  | $ | 6,318 |  |  | $ | 5,195 |  |  | $ | 5,866 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001137789-25-000157:notes:197]
Shareholders’ Deficit
Share Capital

[0001137789-25-000157:notes:198]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 212,668,547 shares were outstanding as of June 27, 2025, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of June 27, 2025.

[0001137789-25-000157:notes:199]
Repurchases of Equity Securities

[0001137789-25-000157:notes:200]
All repurchases are effected as redemptions in accordance with the Company’s Constitution.
The Company’s Board of Directors increased the authorization for the repurchase of its outstanding shares to $5 billion on May 21, 2025. As of June 27, 2025, $5.0 billion remained available for repurchase under the existing repurchase authorization limit approved by the Board of Directors.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001137789-25-000157:notes:201]
Share-Based Compensation
Share-Based Compensation Plans

[0001137789-25-000157:notes:202]
Seagate Technology Holdings plc 2022 Equity Incentive Plan (the “2022 EIP”): On October 20, 2021, (the “Approval Date”), shareholders of the Company approved the 2022 EIP that replaced Seagate Technology Holdings plc 2012 Equity Inventive Plan (the “2012 EIP”). The 2022 EIP provides for the grant of various types of awards including RSUs, options, PSUs and share appreciation rights. The maximum number of shares that may be delivered to the participants under the 2022 EIP shall not exceed (i) 14.1 million ordinary shares, plus (ii) any shares subject to any outstanding share awards granted under the 2012 EIP that, on or after the Approval Date expire, are cancelled or otherwise terminate, in whole or in part, without having been exercised or redeemed in full, or are settled in cash ((i) and (ii) together being the “Share Reserve”). The maximum aggregate number of shares that may be issued pursuant to RSUs or PSUs (collectively, “Full-Value Share Awards”) shall not exceed 12.3 million ordinary shares. Any shares that are subject to the 2022 EIP will be counted against the Share Reserve as one share for every one share granted. As of June 27, 2025, there were 9.5 million ordinary shares available for issuance of Full-Value Share Awards under the 2022 EIP.

[0001137789-25-000157:notes:203]
Seagate Technology Holdings plc Executive Performance Bonus Plan (the “EPB”). Beginning in fiscal year 2023, the Company implemented the EPB utilizing RSUs instead of cash payouts for senior executives. EPB RSUs are granted under the 2022 EIP, pursuant to the achievement of performance targets and individual goals under the EPB. No EPB awards were granted for fiscal years 2025, 2024 and 2023.

[0001137789-25-000157:notes:204]
Seagate Technology Holdings plc Employee Stock Purchase Plan (the “ESPP”). There are 60 million ordinary shares authorized to be issued under the ESPP. The ESPP consists of a series of six-month offering period with a maximum issuance of 1.5 million ordinary shares per offering period. The ESPP allows eligible employees to contribute up to 10% of their eligible compensation to purchase the Company’s common stock. The price of common stock purchased equals to 85% of the lesser of the fair market value on the first day or the last day of each offering period. During fiscal years 2025, 2024 and 2023, employees purchased approximately 1 million shares each year under this plan at weighted average prices of $77.87, $54.71 and $62.36 per share, respectively. As of June 27, 2025, approximately 5.2 million ordinary shares were available for future issuance.

[0001137789-25-000157:notes:205]
Share-Based Compensation Expense

[0001137789-25-000157:notes:206]
The Company recorded $163 million, $127 million and $115 million of share-based compensation with a resulting tax benefit of $21 million, $5 million and $5 million, respectively, during fiscal years 2025, 2024 and 2023. Management made an estimate of expected forfeitures and recognized compensation costs only for those equity awards expected to vest.

[0001137789-25-000157:notes:207]
Restricted Stock Units

[0001137789-25-000157:notes:208]
RSUs generally vest over a period of four years, with 25% vesting on the first anniversary of the vesting commencement date and the remaining 75% vesting ratably each quarter over the next 36 months, subject to continuous employment with the Company through the vesting date.

[0001137789-25-000157:notes:209]
The following is a summary of unvested restricted stock activities:

[0001137789-25-000157:notes:210]
| Unvested Restricted Stocks |  | Number of Shares(In millions) |  | Weighted-Average Grant-Date Fair Value |
| Unvested at June 28, 2024 |  | 3.4 |  |  | $ | 62.20 |  |
| Granted |  | 1.5 |  |  | $ | 96.59 |  |
| Forfeited |  | (0.2) |  |  | $ | 72.50 |  |
| Vested |  | (1.8) |  |  | $ | 60.66 |  |
| Unvested at June 27, 2025 |  | 2.9 |  |  | $ | 79.96 |  |

[0001137789-25-000157:notes:211]
At June 27, 2025, the total unrecognized share-based compensation cost related to unvested restricted stocks was approximately $171 million. This cost is being amortized on a straight-line basis over a weighted-average remaining term of 2.2 years and will be adjusted for subsequent changes in estimated forfeitures. The aggregate fair value of restricted stocks vested during fiscal years 2025, 2024 and 2023 were approximately $105 million, $105 million and $105 million, respectively.

[0001137789-25-000157:notes:212]
The fair value related to RSUs for fiscal years 2025, 2024 and 2023 were estimated using the following assumptions:

[0001137789-25-000157:notes:213]
|  | Fiscal Years |
|  | 2025 |  | 2024 |  | 2023 |
| RSUs |  |  |  |  |  |
| Expected term (in years) | 1 - 2.2 |  | 1 - 2.2 |  | 1 - 2.2 |
| Expected dividend rate | 2.0 - 3.3% |  | 2.4 - 4.4% |  | 3.2 - 5.5% |
| Weighted-average expected dividend rate | 2.6 | % |  | 4.0 | % |  | 3.8 | % |
| Weighted-average fair value | $ | 96.59 |  | $ | 59.96 |  | $ | 62.82 |

[0001137789-25-000157:notes:214]
The expected term represents the period that the Company’s share-based awards are expected to be outstanding and was determined based on historical experience of similar awards. The expected dividend yield is determined by dividing the expected per share dividend during the coming year by the grant date share price.

[0001137789-25-000157:notes:215]
EPB RSUs can be settled in cash, subject to certain employment conditions, and therefore classified as liability awards. The Company remeasures the fair value of these liability awards at each fiscal quarter end. Generally, EPB RSUs vest in full on the first anniversary of the vesting commencement date.

[0001137789-25-000157:notes:216]
During fiscal year 2025, the Company recognized approximately $37 million of share-based compensation expense related to EPB RSUs in the Consolidated Statements of Operations, with the corresponding liability recorded within Accrued employee compensation on the Consolidated Balance Sheets. During fiscal years 2024 and 2023, the Company did not recognize any share compensation expense related to liability awards.

[0001137789-25-000157:notes:217]
Performance-based Share Units

[0001137789-25-000157:notes:218]
The Company granted PSUs that vest on the satisfaction of continuous employment and achievement of certain financial and operational performance goals established by the Compensation Committee of the Company’s Board of Directors (the “Compensation Committee”). These awards vest after the end of the performance period of three years from the grant date. During fiscal years 2024 and 2023, the PSUs granted and outstanding were not material. Compensation expense related to these units is only recorded in a period if it is probable that the performance goals will be met, and it is to be recorded at the expected level of achievement. The expenses associated with these PSUs were not material for fiscal years 2024 and 2023, respectively.

[0001137789-25-000157:notes:219]
| Performance-based Share Units |  | Number of Shares(In millions) |  | Weighted-Average Grant-Date Fair Value |
| Unvested at June 28, 2024 |  | 0.9 |  |  | $ | 70.97 |  |
| Granted |  | 0.2 |  |  | $ | 103.53 |  |
| Forfeited |  | (0.1) |  |  | $ | 92.17 |  |
| Vested |  | (0.2) |  |  | $ | 73.64 |  |
| Unvested at June 27, 2025 |  | 0.8 |  |  | $ | 75.55 |  |

[0001137789-25-000157:notes:220]
At June 27, 2025, the total unrecognized share-based compensation cost related to unvested performance-based share units was approximately $38 million. This cost is being amortized on a straight-line basis over a weighted-average remaining term of 1.2 years and will be adjusted for subsequent changes in estimated forfeitures. The aggregate fair value of performance-based share units vested during fiscal years 2025, 2024 and 2023 were approximately $17 million, $6 million and $16 million, respectively.

[0001137789-25-000157:notes:221]
The fair value related to PSUs for fiscal years 2025, 2024 and 2023 were estimated using the following assumptions:

[0001137789-25-000157:notes:222]
|  | Fiscal Years |
|  | 2025 |  | 2024 |  | 2023 |
| PSUs subject to TSR/ROIC conditions |  |  |  |  |  |
| Expected term (in years) | 3.0 |  | 3.0 |  | 3.0 |
| Volatility | 37 | % |  | 39 | % |  | 40 | % |
| Weighted-average volatility | 37 | % |  | 39 | % |  | 40 | % |
| Expected dividend rate | 2.8 | % |  | 4.4 | % |  | 4.1 | % |
| Weighted-average expected dividend rate | 2.8 | % |  | 4.4 | % |  | 4.1 | % |
| Risk-free interest rate | 3.5 | % |  | 4.6 | % |  | 3.6 | % |
| Weighted-average fair value | $ | 75.55 |  | $ | 70.97 |  | $ | 64.38 |

[0001137789-25-000157:notes:223]
Share Options

[0001137789-25-000157:notes:224]
Options generally vest over a period of four years, with 25% vesting on the first anniversary of the vesting commencement date and the remaining 75% vesting ratably each quarter over the next 36 months, subject to continuous employment with the Company through the vesting date. The exercise price of a share option is equal to the closing price of the Company’s ordinary shares on NASDAQ on the grant date. The expenses associated with share options were not material for any of the periods presented.

[0001137789-25-000157:notes:225]
Employee Savings Plan
The Company offers various defined contribution plans for U.S. and non-U.S. employees. In the U.S., qualified employees under the Seagate 401(k) Plan (the "401(k) plan") may elect to make contributions up to 50% of their eligible earned compensation, but not more than statutory limits. Pursuant to the 401(k) plan, the Company matches 50% of employee contributions, up to 6% of compensation, subject to a maximum annual employer contribution of $6,000 per participating employee. During fiscal years 2025, 2024 and 2023, the Company made matching contributions of $67 million, $65 million and $79 million, respectively, under defined contribution plans for employees


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001137789-25-000157:notes:226]
Guarantees
Indemnifications of Officers and Directors

[0001137789-25-000157:notes:227]
The Company has entered into indemnification agreements with its directors and certain of its officers that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. The Company maintains director and officer insurance, which may cover certain liabilities arising from its obligation to indemnify its directors and officers in certain circumstances.

[0001137789-25-000157:notes:228]
The nature of these indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay on behalf of its officers and directors. Historically, the Company has not made any significant indemnification payments under such indemnification agreements and no amount has been accrued in the Company’s Consolidated Financial Statements with respect to these indemnification obligations.

[0001137789-25-000157:notes:229]
Indemnification Obligations

[0001137789-25-000157:notes:230]
The Company from time to time enters into agreements with customers, suppliers, partners and others in the ordinary course of business that provide indemnification for certain matters including, but not limited to, intellectual property infringement claims, environmental claims and breach of agreement claims. The nature of the Company’s indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the Company’s Consolidated Financial Statements with respect to these indemnification obligations.

[0001137789-25-000157:notes:231]
Product Warranty

[0001137789-25-000157:notes:232]
Changes in the Company’s product warranty liability during the fiscal years ended June 27, 2025 and June 28, 2024 were as follows:

[0001137789-25-000157:notes:233]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |  |  |
| Balance, beginning of period |  | $ | 149 |  |  | $ | 168 |  |  |  |
| Warranties issued |  | 68 |  |  | 53 |  |  |  |
| Repairs and replacements |  | (88) |  |  | (81) |  |  |  |
| Changes in liability for pre-existing warranties, including expirations |  | 8 |  |  | 9 |  |  |  |
| Balance, end of period |  | $ | 137 |  |  | $ | 149 |  |  |  |


## us-gaap:EarningsPerShareTextBlock

[0001137789-25-000157:notes:234]
(Loss) Per Share
Basic earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period. Diluted earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period and the number of additional shares that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding options, unvested restricted share units and performance-based share units and shares to be purchased under the Employee Stock Purchase Plan using the treasury stock method, as well as shares issuable in connection with the Company’s exchangeable senior notes using the “if-converted” method.

[0001137789-25-000157:notes:235]
Under the treasury stock method, the dilutive effect of potentially dilutive securities is reflected in diluted net earnings per share and an increase in fair market value of the Company’s share price can result in a greater dilutive effect from potentially dilutive securities. Under the “if-converted” method, diluted earnings per share is calculated assuming that the excess value above the principal of the exchangeable notes were converted solely into shares of common stock at the beginning of the reporting period, unless the result would be anti-dilutive, which could adversely affect our diluted earnings per share.

[0001137789-25-000157:notes:236]
The following table sets forth the computation of basic and diluted net income (loss) per share attributable to the shareholders of the Company:

[0001137789-25-000157:notes:237]
|  |  | Fiscal Years Ended |
| (In millions, except per share data) |  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |
| Numerator: |  |  |  |  |  |  |
| Net income (loss) |  | $ | 1,469 |  |  | $ | 335 |  |  | $ | (529) |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income (loss) per share |  | 212 |  |  | 209 |  |  | 207 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |
| Employee equity award plans |  | 2 |  |  | 2 |  |  | — |  |
| 2028 Notes if-converted shares |  | 3 |  |  | 1 |  |  | — |  |
| Total shares for purposes of calculating diluted net income (loss) per share |  | 217 |  |  | 212 |  |  | 207 |  |
| Net income (loss) per share |  |  |  |  |  |  |
| Basic |  | $ | 6.93 |  |  | $ | 1.60 |  |  | $ | (2.56) |  |
| Diluted |  | 6.77 |  |  | 1.58 |  |  | (2.56) |  |

[0001137789-25-000157:notes:238]
All potentially dilutive securities that could have an anti-dilutive effect on the calculation of the earnings per share have been excluded for the periods presented. The weighted average anti-dilutive shares that were excluded from the computation of diluted net income (loss) per share were not material for the fiscal years ended June 27, 2025 and June 28, 2024. The weighted average anti-dilutive shares that were excluded from the computation of diluted net loss per share were 7 million for the fiscal year ended June 30, 2023


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001137789-25-000157:notes:239]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001137789-25-000157:notes:240]
Litigation

[0001137789-25-000157:notes:241]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, seeking damages as well as additional relief. The district court entered judgment in favor of Seagate on April 19, 2022. An appeal to the Federal Circuit is pending. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

[0001137789-25-000157:notes:242]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC and certain of its affiliates, (collectively, the “Seagate Entities”) filed a complaint alleging violations of federal and state antitrust laws as well as breach of contract in the U.S. District Court for the Northern District of California against suppliers of HDD suspension assemblies, including NHK Spring Co. Ltd., TDK Corporation (“TDK”), Hutchinson Technology Inc (“HTI”). The Seagate Entities seek to recover damages suffered as a result of the suspension assembly suppliers’ conduct, and additional relief permitted by law. On April 8, 2022, the court dismissed with prejudice all claims against TDK and HTI after the Seagate Entities settled with those defendants. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment under the Foreign Trade Antitrust Improvement Act (“FTAIA Motion”). On November 17, 2023, the Court granted NHK’s FTAIA Motion on reconsideration, denying the majority of Seagate’s antitrust claims. The Court’s FTAIA decision is now on appeal with the Ninth Circuit.

[0001137789-25-000157:notes:243]
In re Seagate Technology Holdings plc Securities Litigation. On July 10, 2023 and July 26, 2023, two securities class action lawsuits were filed in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The cases were consolidated on September 25, 2023. On September 12, 2024, the plaintiffs filed the currently operative complaint, asserting claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and SEC Rule 10b-5, and a class period between September 14, 2020 and April 19, 2023, inclusive. The operative complaint seeks unspecified monetary damages and other relief. On May 12, 2025, the Court granted in part and denied in part the defendants’ motion to dismiss the operative complaint. On June 9, 2025, the defendants moved to certify the May 12, 2025 order for interlocutory appeal. The Company believes that the asserted claims are without merit and intends to vigorously defend the case.

[0001137789-25-000157:notes:244]
Godo Kaisha IP Bridge 1 v. Seagate Technology LLC, Seagate Technology (US) Holding, Inc., Seagate Technology (Thailand) Limited, Seagate Singapore International Headquarters Ltd., Seagate Technology (Netherlands) B.V. On March 15, 2024, a patent infringement action was filed by Godo Kaisha IP Bridge 1 (“IP Bridge”) against Seagate in U.S. District Court for the District of Delaware. The case was subsequently transferred to the District Court of Minnesota on September 4, 2024. The complaint alleges patent infringement by Seagate of nine U.S. patents. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

[0001137789-25-000157:notes:245]
BIS Settlement

[0001137789-25-000157:notes:246]
On April 18, 2023, the Company’s subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd (collectively, “Seagate”), entered into a settlement agreement (the “Settlement Agreement”) with the U.S. Department of Commerce’s Bureau of Industry and Security (“BIS”) that resolves BIS’ allegations regarding Seagate’s sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, Seagate has agreed to pay $300 million to BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. Seagate has also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the U.S. Export Administration Regulations (“EAR”), including one audit by an unaffiliated third-party consultant chosen by Seagate with expertise in U.S. export control laws and two internal audits.

[0001137789-25-000157:notes:247]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $135 million were included in Accrued expense and Other non-current liabilities, respectively, on the Consolidated Balance Sheets as of June 27, 2025. For the fiscal year ended 2025, $60 million was paid and reported as an outflow from operating activities in its Consolidated Statements of Cash Flows.

[0001137789-25-000157:notes:248]
Environmental Matters

[0001137789-25-000157:notes:249]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001137789-25-000157:notes:250]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001137789-25-000157:notes:251]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001137789-25-000157:notes:252]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fail to comply with the substance restrictions, recycle content requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001137789-25-000157:notes:253]
Other Matters 
From time to time, arising in the normal course of business, the Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company expects to be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:CommitmentsDisclosureTextBlock

[0001137789-25-000157:notes:254]
Commitments
Unconditional Long-Term Purchase Obligations. As of June 27, 2025, the Company had unconditional long-term purchase obligations of approximately $77 million, primarily related to purchases of inventory components. The Company expects the commitment to total $38 million, $18 million, $12 million and $9 million for fiscal years 2027, 2028, 2029 and 2030 respectively. In addition, the Company also had certain long-term market share based inventory purchase commitments as of June 27, 2025.

[0001137789-25-000157:notes:255]
Unconditional Long-Term Capital Expenditures. As of June 27, 2025, the Company had unconditional long-term commitments of approximately $46 million, primarily related to purchases of equipment. The Company expects capital expenditures of $11 million in fiscal year 2027 and $35 million for fiscal years 2028 and thereafter.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001137789-25-000157:notes:256]
Business Segment and Geographic Information
 The Company’s manufacturing operations are based on technology platforms that are used to produce various data storage and systems solutions that serve multiple applications and markets. The Company has determined that its Chief Operating Decision Maker (“CODM”), the Chief Executive Officer, evaluates performance of the Company and makes decisions regarding investments in the Company’s technology platforms and manufacturing infrastructure based on the Company’s consolidated results, including net income reported on the Consolidated Statements of Operations. As a result, the Company has concluded that its manufacture and distribution of storage solutions constitutes one operating segment.

[0001137789-25-000157:notes:257]
Significant expense categories regularly provided to and reviewed by the CODM are those presented in the Consolidated Statements of Operations.

[0001137789-25-000157:notes:258]
The following table summarizes the Company’s long-lived assets by country:

[0001137789-25-000157:notes:259]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |
| Long-lived assets: |  |  |  |  |  |  |
| United States |  | $ | 672 |  |  | $ | 658 |  |  | $ | 667 |  |
| Thailand |  | 546 |  |  | 574 |  |  | 606 |  |
| Singapore |  | 411 |  |  | 447 |  |  | 460 |  |
| Other |  | 381 |  |  | 338 |  |  | 369 |  |
| Consolidated |  | $ | 2,010 |  |  | $ | 2,017 |  |  | $ | 2,102 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001137789-25-000157:notes:260]
Revenue
The following table provides information about disaggregated revenue by sales channel and country for the Company’s single reportable segment:

[0001137789-25-000157:notes:261]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 27,2025 |  | June 28,2024 |  | June 30,2023 |
| Revenues by Channel |  |  |  |  |  |  |
| OEMs |  | $ | 7,282 |  |  | $ | 4,896 |  |  | $ | 5,448 |  |
| Distributors |  | 1,060 |  |  | 972 |  |  | 1,119 |  |
| Retailers |  | 755 |  |  | 683 |  |  | 817 |  |
| Total |  | $ | 9,097 |  |  | $ | 6,551 |  |  | $ | 7,384 |  |

[0001137789-25-000157:notes:262]
| Revenue from external customers (1): |  |  |  |  |  |  |
| Singapore |  | $ | 3,759 |  |  | $ | 3,429 |  |  | $ | 3,271 |  |
| United States |  | 4,410 |  |  | 2,308 |  |  | 3,053 |  |
| The Netherlands |  | 924 |  |  | 802 |  |  | 1,046 |  |
| Other |  | 4 |  |  | 12 |  |  | 14 |  |
| Total |  | $ | 9,097 |  |  | $ | 6,551 |  |  | $ | 7,384 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001137789-25-000157:notes:263]
The following table provides information about disaggregated revenue by sales channel and country for the Company’s single reportable segment:

[0001137789-25-000157:notes:264]
____________________________________________________ 
(1) Revenue is attributed to countries based on bill from locations.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001137789-25-000157:notes:265]
Acquisition and Divestiture
Acquisition of Intevac, Inc.

[0001137789-25-000157:notes:266]
On March 31, 2025, the Company completed the acquisition of Intevac, Inc., a supplier of thin-film processing systems for total consideration of $119 million, which primarily consisted of cash paid for all of the outstanding common stock and special dividend. The acquisition aligns with the Company's strategy to integrate important components and manufacturing processes. Pro forma results of operations for this acquisition have not been presented because they are not material to the Company’s consolidated results of operations.

[0001137789-25-000157:notes:267]
In connection with the acquisition, the Company recorded approximately $97 million of net tangible assets, primarily consisted of cash and investments, $19 million of intangible assets and $2 million of goodwill, none of which is expected to be deductible for tax purposes. The Company is amortizing the intangible assets on a straight-line basis over an estimated useful life of three years.

[0001137789-25-000157:notes:268]
Divestiture

[0001137789-25-000157:notes:269]
Sale of SoC Operations

[0001137789-25-000157:notes:270]
On April 23, 2024, the Company entered into an Asset Purchase Agreement with Avago Technologies International Sales Pte. Limited (“Purchaser”), a subsidiary of Broadcom Inc., and sold certain intellectual property, equipment and other assets related to the design, development and manufacture of its SoC products to Purchaser. Purchaser and its affiliates also offered employment to certain of the Company’s employees engaged in the SoC operations. In connection with this transaction, the Company and Purchaser have also restructured certain pre-existing purchasing agreements (collectively, the “Transaction”). Total consideration for this Transaction was $600 million, including cash proceeds of $560 million at close. The remaining $40 million relates to standard indemnification clauses, of which $25 million was received during fiscal year 2025 and $15 million is recorded in Other current assets on the Consolidated Balance Sheets as of June 27, 2025. The agreement also contains regulatory review indemnification clauses agreed to by both parties in conjunction with the transaction closing.

[0001137789-25-000157:notes:271]
Based on the valuation performed by the Company, $234 million of the consideration was attributable to the restructuring of pre-existing purchase agreements and recorded as a deferred liability within Other non-current liabilities on the Consolidated Balance Sheets as of June 28, 2024. The deferred liability is expected to be recognized ratably over the terms of the restructured purchase agreements. Estimating the fair value of the restructuring of pre-existing purchase agreements is judgmental in nature and involves the use of estimates and assumptions. The Company estimated the fair value of its restructuring of pre-existing purchase agreements using the market approach based on discounted cash flow analysis of management’s short-term and long-term forecast of purchase volume and average market price. The discount rate used is based on the weighted-average cost of capital of comparable public companies adjusted for the relevant risk associated with business specific characteristics. This deferred liability is classified in Level 3 of the fair value hierarchy.

[0001137789-25-000157:notes:272]
As a result of the Transaction, the Company recorded a pre-tax net gain of $313 million from the sale of assets and transfer of liabilities, which included $18 million of goodwill allocated to SoC operations based on its relative fair value of the Company because the disposal group constituted a business for accounting purposes. This was recorded in the Net gain from business divestiture in the Consolidated Statements of Operations during fiscal year 2024. For the fiscal year 2024, the net proceeds of $226 million, net of transaction costs paid, from this Transaction was recorded as an operating inflow and $326 million was recorded as an investing inflow on the Company’s Consolidated Statements of Cash Flows. The Transaction did not meet the criteria of discontinued operation because the disposal did not represent a strategic shift that had a major effect on the Company’s operations and financial results.


## us-gaap:SubsequentEventsTextBlock

[0001137789-25-000157:notes:273]
Subsequent Event
Dividend Declared

[0001137789-25-000157:notes:274]
On July 29, 2025, the Board of Directors of the Company declared a quarterly cash dividend of $0.72 per share, which will be payable on October 9, 2025 to shareholders of record as of the close of business on September 30, 2025.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001137789-25-000157:notes:275]
The table below summarizes the material terms of trading arrangements adopted by any of our executive officers or directors during the fiscal quarter ended June 27, 2025. All of the trading arrangements listed below are intended to satisfy the affirmative defense of Rule 10b5-1(c).

[0001137789-25-000157:notes:276]
| Name | Title | Date of Adoption | End Date¹ | Aggregate number of ordinary shares to be sold pursuant to the trading agreement |
| Dr. John C. Morris | Senior Vice President and Chief Technology Officer | June 1, 2025 | April 20, 2026 | 18,581 |

[0001137789-25-000157:notes:277]
¹ The plan will expire on the earlier of the end date or the completion of all transactions under the trading arrangement.
