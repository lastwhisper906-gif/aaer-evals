# STX MD&A — 0001137789-24-000068


## mdna

[0001137789-24-000068:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001137789-24-000068:mdna:2]
The following is a discussion of the Company’s financial condition, changes in financial condition and results of operations for the fiscal years ended June 28, 2024 and June 30, 2023. Discussions of year-to-year comparisons between fiscal years 2023 and 2022 are not included in this Annual Report on Form 10-K and can be found in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended June 30, 2023, which was filed with the SEC on August 4, 2023.

[0001137789-24-000068:mdna:3]
You should read this discussion in conjunction with “Item 8. Financial Statements and Supplementary Data” included elsewhere in this Annual Report on Form 10-K. Except as noted, references to any fiscal year mean the twelve-month period ending on the Friday closest to June 30 of that year. Accordingly, fiscal year 2024 and 2023 both comprised of 52 weeks and ended on June 28, 2024 and June 30, 2023, respectively. Fiscal year 2026 will be comprised of 53 weeks and will end on July 3, 2026.

[0001137789-24-000068:mdna:4]
Our Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) is provided in addition to the accompanying Consolidated Financial Statements and notes to assist readers in understanding our results of operations, financial condition and cash flows. Our MD&A is organized as follows:

[0001137789-24-000068:mdna:5]
•Overview of Fiscal Year 2024. Highlights of events in fiscal year 2024 that impacted our financial position.

[0001137789-24-000068:mdna:6]
•Results of Operations. Analysis of our financial results comparing fiscal years 2024 and 2023.

[0001137789-24-000068:mdna:7]
•Liquidity and Capital Resources. Analysis of changes in our balance sheets and cash flows and discussion of our financial condition, including potential sources of liquidity, material cash requirements and their general purpose.

[0001137789-24-000068:mdna:8]
•Critical Accounting Policies and Estimates. Accounting policies and estimates that we believe are important to understanding the assumptions and judgments incorporated in our reported financial results.

[0001137789-24-000068:mdna:9]
For an overview of our business, see “Part I, Item 1. Business.”

[0001137789-24-000068:mdna:10]
Overview of Fiscal Year 2024

[0001137789-24-000068:mdna:11]
During fiscal year 2024, we shipped 398 exabytes of HDD storage capacity. We generated revenue of approximately $6.6 billion with a gross margin of 23%. Our operating cash flow was $918 million and we paid $585 million in dividends. We issued $1.5 billion of exchangeable notes to primarily retire our term loans of $1.3 billion. Additionally, in April 2024, we sold certain intellectual property, equipment and other assets related to the design, development and manufacture of our System-on-Chip (“SoC”) products to Avago Technologies International Sales Pte. Limited, a subsidiary of Broadcom Inc., for $600 million and we recorded a net gain of $313 million from this business divestiture. In connection with the transaction, the Company also restructured certain pre-existing purchase agreements. Refer to “Item 8. Financial Statements and Supplementary Data—Note 18. Divestiture” for more details.

[0001137789-24-000068:mdna:12]
Recent Developments, Economic Conditions and Challenges

[0001137789-24-000068:mdna:13]
During fiscal year 2024, we experienced ongoing recovery within the global cloud market, reflecting continued improvement in end-market demand. Demand recovery for our high capacity nearline drives has been faster than anticipated, which has extended product lead times and led to tighter overall supply conditions. We continued to exercise cost discipline and implement pricing actions to improve operational efficiency and profitability. We believe that we are in the early stage of an industry-wide demand recovery and AI application deployment, however we expect the macroeconomic environment to remain dynamic and continue to impact our business and results of operations.

[0001137789-24-000068:mdna:14]
For a further discussion of the uncertainties and business risks, see “Part I, Item 1A. Risk Factors” of our Annual Report.

[0001137789-24-000068:mdna:15]
Regulatory settlement

[0001137789-24-000068:mdna:16]
On April 18, 2023, our subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd entered into the Settlement Agreement with the BIS that resolves BIS’ allegations regarding our sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, we agreed to pay $300 million to the BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. Refer to “Item 8. Financial Statements and Supplementary Data—Note 14. Legal, Environmental and Other Contingencies” for more details.

[0001137789-24-000068:mdna:17]
Results of Operations

[0001137789-24-000068:mdna:18]
We list in the tables below summarized information from our Consolidated Statements of Operations by dollar amounts and as a percentage of revenue:

[0001137789-24-000068:mdna:19]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |
| Revenue |  | $ | 6,551 |  |  | $ | 7,384 |  |
| Cost of revenue |  | 5,015 |  |  | 6,033 |  |
| Gross profit |  | 1,536 |  |  | 1,351 |  |
| Product development |  | 654 |  |  | 797 |  |
| Marketing and administrative |  | 460 |  |  | 491 |  |
| Amortization of intangibles |  | — |  |  | 3 |  |
| BIS settlement penalty |  | — |  |  | 300 |  |
| Restructuring and other, net |  | (30) |  |  | 102 |  |
| Income (loss) from operations |  | 452 |  |  | (342) |  |
| Other expense, net |  | (7) |  |  | (154) |  |
| Income (loss) before income taxes |  | 445 |  |  | (496) |  |
| Provision for income taxes |  | 110 |  |  | 33 |  |
| Net Income (loss) |  | $ | 335 |  |  | $ | (529) |  |

[0001137789-24-000068:mdna:20]
|  |  | Fiscal Years Ended |
|  |  | June 28,2024 |  | June 30,2023 |
| Revenue |  | 100 | % |  | 100 | % |
| Cost of revenue |  | 77 |  |  | 82 |  |
| Gross margin |  | 23 |  |  | 18 |  |
| Product development |  | 10 |  |  | 11 |  |
| Marketing and administrative |  | 7 |  |  | 7 |  |
| Amortization of intangibles |  | — |  |  | — |  |
| BIS settlement penalty |  | — |  |  | 4 |  |
| Restructuring and other, net |  | — |  |  | 1 |  |
| Operating margin |  | 6 |  |  | (5) |  |
| Other expense, net |  | — |  |  | (2) |  |
| Income (loss) before income taxes |  | 6 |  |  | (7) |  |
| Provision for income taxes |  | 2 |  |  | — |  |
| Net Income (loss) |  | 4 | % |  | (7) | % |

[0001137789-24-000068:mdna:21]
Revenue

[0001137789-24-000068:mdna:22]
The following table summarizes information regarding consolidated revenues by channel, geography, and market and HDD exabytes shipped by market and price per terabyte:

[0001137789-24-000068:mdna:23]
|  |  | Fiscal Years Ended |
|  |  | June 28,2024 |  | June 30,2023 |
| Revenues by Channel (%) |  |  |  |  |
| OEMs |  | 75 | % |  | 74 | % |
| Distributors |  | 15 | % |  | 15 | % |
| Retailers |  | 10 | % |  | 11 | % |
| Revenues by Geography (%) (1) |  |  |  |  |
| Asia Pacific |  | 53 | % |  | 45 | % |
| Americas |  | 35 | % |  | 41 | % |
| EMEA |  | 12 | % |  | 14 | % |
| Revenues by Market (%) |  |  |  |  |
| Mass capacity |  | 72 | % |  | 66 | % |
| Legacy |  | 18 | % |  | 21 | % |
| Other |  | 10 | % |  | 13 | % |
| HDD Exabytes Shipped by Market |  |  |  |  |
| Mass capacity |  | 355 |  |  | 380 |  |
| Legacy |  | 43 |  |  | 61 |  |
| Total |  | 398 |  |  | 441 |  |
| HDD Price per Terabyte |  | $ | 15 |  |  | $ | 15 |  |

[0001137789-24-000068:mdna:24]
________________________________________________

[0001137789-24-000068:mdna:25]
(1) Revenue is attributed to geography based on the bill from location.

[0001137789-24-000068:mdna:26]
40

[0001137789-24-000068:mdna:27]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |  | Change |  | %Change |
| Revenue |  | $ | 6,551 |  |  | $ | 7,384 |  |  | $ | (833) |  |  | (11) | % |

[0001137789-24-000068:mdna:28]
Revenue in fiscal year 2024 decreased approximately 11%, or $833 million, from fiscal year 2023, primarily due to a decrease in exabytes shipped as a result of lower broad-based market demand, slightly offset by an increase in revenue driven by favorable pricing actions undertaken by the Company.

[0001137789-24-000068:mdna:29]
Cost of Revenue and Gross Margin

[0001137789-24-000068:mdna:30]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |  | Change |  | %Change |
| Cost of revenue |  | $ | 5,015 |  |  | $ | 6,033 |  |  | $ | (1,018) |  |  | (17) | % |
| Gross profit |  | 1,536 |  |  | 1,351 |  |  | 185 |  |  | 14 | % |
| Gross margin |  | 23 | % |  | 18 | % |  |  |  |  |

[0001137789-24-000068:mdna:31]
For fiscal year 2024, gross margin increased compared to the prior fiscal year primarily driven by favorable pricing actions undertaken by the Company and product mix, a $90 million reduction in factory underutilization charges which included the decrease in depreciation expense due to the extension of useful lives of certain manufacturing equipment, a decrease of $47 million in accelerated depreciation expense for certain capital equipment, a decrease of $21 million in order cancellation fees and $7 million pandemic-related lockdown charges in one of our factories in fiscal year 2023 that did not recur in fiscal year 2024, partially offset by lower exabytes shipped.

[0001137789-24-000068:mdna:32]
In the fiscal year 2024, total warranty cost was 0.8% of revenue and included an unfavorable change in estimates of prior warranty accruals of 0.1% of revenue primarily due to changes to our estimated future product return rates. Warranty cost related to new shipments was 0.8%, 0.7% and 0.7% of revenue for the fiscal years 2024, 2023 and 2022, respectively.

[0001137789-24-000068:mdna:33]
Operating Expenses

[0001137789-24-000068:mdna:34]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |  | Change |  | %Change |
| Product development |  | $ | 654 |  |  | $ | 797 |  |  | $ | (143) |  |  | (18) | % |
| Marketing and administrative |  | 460 |  |  | 491 |  |  | (31) |  |  | (6) | % |
| Amortization of intangibles |  | — |  |  | 3 |  |  | (3) |  |  | * |
| BIS settlement penalty |  | — |  |  | 300 |  |  | (300) |  |  | * |
| Restructuring and other, net |  | (30) |  |  | 102 |  |  | (132) |  |  | (129) | % |
| Operating expenses |  | $ | 1,084 |  |  | $ | 1,693 |  |  | $ | (609) |  |  |  |

[0001137789-24-000068:mdna:35]
______________________________

[0001137789-24-000068:mdna:36]
*Not a meaningful figure

[0001137789-24-000068:mdna:37]
Product Development Expense. Product development expenses for fiscal year 2024 decreased by $143 million from fiscal year 2023 primarily due to a $112 million decrease in compensation and other employee benefits as a result of workforce and temporary salary reductions, a $49 million decrease in depreciation expense and a $7 million decrease in materials expense, partially offset by a $24 million increase in lease expense as we sold and leased back certain properties.

[0001137789-24-000068:mdna:38]
Marketing and Administrative Expense. Marketing and administrative expenses for fiscal year 2024 decreased by $31 million from fiscal year 2023 primarily due to a $17 million decrease in compensation and other employee benefits as a result of workforce and temporary salary reductions, a $12 million decrease in advertising costs, a $6 million decrease in outside services expense, a $5 million decrease in travel expense, partially offset by a $7 million recovery in the December 2022 quarter of an accounts receivable previously written off in prior years and a $3 million increase in depreciation expense.

[0001137789-24-000068:mdna:39]
Restructuring and Other, net. Restructuring and other, net for fiscal year 2024 was a benefit of $30 million primarily related to the net gain from the sale and leaseback transaction during the December 2023 quarter. The restructuring plans were substantially completed by the end of fiscal year 2023.

[0001137789-24-000068:mdna:40]
41

[0001137789-24-000068:mdna:41]
Other Expense, net

[0001137789-24-000068:mdna:42]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |  | Change |  | %Change |
| Other expense, net |  | $ | 7 |  |  | $ | 154 |  |  | $ | (147) |  |  | (95) | % |

[0001137789-24-000068:mdna:43]
Other expense, net for fiscal year 2024 decreased by $147 million compared to fiscal year 2023 primarily due to a $313 million gain from the sale of SoC operations (refer to “Item 8. Financial Statements and Supplementary Data—Note 18. Divestiture” for more details), a $104 million of net gain recognized from the termination of interest rate swaps associated with the repayment of term loans and a $5 million net increase in interest income in fiscal year 2024. The decrease is partially offset by a $190 million of net gain recognized from the early redemption of debt in fiscal year 2023, a $41 million  increase in net loss from equity investments, a $29 million net loss recognized from early redemption of debt and a $19 million net increase in interest expense in fiscal year 2024.

[0001137789-24-000068:mdna:44]
Income Taxes

[0001137789-24-000068:mdna:45]
|  |  | Fiscal Years Ended |  |  |  |  |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |  | Change |  | %Change |
| Provision for income taxes |  | $ | 110 |  |  | $ | 33 |  |  | $ | 77 |  |  | 233 | % |

[0001137789-24-000068:mdna:46]
We recorded an income tax provision of $110 million for fiscal year 2024 compared to an income tax provision of $33 million for fiscal year 2023.

[0001137789-24-000068:mdna:47]
During the third quarter of fiscal year 2024, we established Singapore as our principal executive offices. Our parent holding company owns various U.S. and non-Singaporean subsidiaries that operate in multiple non-Singaporean income tax jurisdictions. Our worldwide operating income is either subject to varying rates of income tax or is exempt from income tax due to tax incentive programs we operate under in Singapore and Thailand. These tax incentives are scheduled to expire in whole or in part at various dates through fiscal year 2036. Certain tax incentives may be extended if specific conditions are met.

[0001137789-24-000068:mdna:48]
Since we established Singapore as our principal executive offices in fiscal year 2024, the Singaporean statutory rate of 17% is used for purposes of the reconciliation between the provision for income taxes at the statutory rate and our effective tax rate. For fiscal years 2023 and 2022, a notional Irish statutory rate of 25% was used.

[0001137789-24-000068:mdna:49]
Our income tax provision recorded for fiscal years 2024 differed from the provision for income taxes that would be derived by applying the Singaporean statutory rate of 17% to income before income taxes, primarily due to the net effect of (i) changes in valuation allowance and (ii) current year generation of research credits. Our income tax provision recorded for fiscal year 2023 differed from the provision for income taxes that would be derived by applying the Irish statutory rate of 25% to income before income taxes, primarily due to the net effect of (i) non-Irish earnings generated in jurisdictions that are subject to tax incentive programs and are considered indefinitely reinvested outside of Ireland and (ii) current year generation of research credits.

[0001137789-24-000068:mdna:50]
Liquidity and Capital Resources

[0001137789-24-000068:mdna:51]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash and our liquidity and capital resources. Our cash and cash equivalents are maintained in investments with remaining maturities of 90 days or less at the time of purchase. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We believe our cash equivalents are liquid and accessible. We operate in some countries that have restrictive regulations over the movement of cash and/or foreign exchange across their borders. However, we believe our sources of cash will continue to be sufficient to fund our operations and meet our cash requirements for the next 12 months. Although there can be no assurance, we believe that our financial resources, along with controlling our costs and capital expenditures, will allow us to manage the ongoing impact of market demand disruptions on our business operations for the foreseeable future. However, some challenges to our industry and to our business continue to remain uncertain and cannot be predicted at this time. Consequently, we will continue to evaluate our financial position in light of future developments, particularly those relating to the global economic factors.

[0001137789-24-000068:mdna:52]
We are not aware of any downgrades, losses or other significant deterioration in the fair value of our cash equivalents from the values reported as of June 28, 2024. For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements among others, see “Part I, Item 1A. Risk Factors” of our Annual Report.

[0001137789-24-000068:mdna:53]
Cash and Cash Equivalents

[0001137789-24-000068:mdna:54]
|  |  | As of |  |  |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |  | Change |
| Cash and cash equivalents |  | $ | 1,358 |  |  | $ | 786 |  |  | $ | 572 |  |

[0001137789-24-000068:mdna:55]
The following table summarizes results from the Consolidated Statements of Cash Flows for the periods indicated:

[0001137789-24-000068:mdna:56]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |
| Net cash flow provided by (used in): |  |  |  |  |
| Operating activities |  | $ | 918 |  |  | $ | 942 |  |
| Investing activities |  | 126 |  |  | 217 |  |
| Financing activities |  | (473) |  |  | (988) |  |
| Effect of foreign currency exchange rates |  | 1 |  |  | — |  |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 572 |  |  | $ | 171 |  |

[0001137789-24-000068:mdna:57]
Cash Provided by Operating Activities

[0001137789-24-000068:mdna:58]
Cash provided by operating activities for fiscal year 2024 was $918 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation, net gain from business divestiture and:

[0001137789-24-000068:mdna:59]
•an increase of $243 million in other assets and liabilities, primarily related to the restructuring of pre-existing purchase agreements as a result of the sale of SoC operations. Refer to “Item 8. Financial Statements and Supplementary Data—Note 18. Divestiture” for more details;

[0001137789-24-000068:mdna:60]
•an increase of $227 million in accounts payable, primarily due to timing of payments;

[0001137789-24-000068:mdna:61]
•a decrease of $192 million in accounts receivable, primarily due to lower revenue and higher accounts receivable factoring; and

[0001137789-24-000068:mdna:62]
•an increase of $25 million cash proceeds received from the settlement of certain interest rate swap agreements; partially offset by

[0001137789-24-000068:mdna:63]
•a decrease of $183 million in accrued expenses primarily due to lower restructuring activities; and

[0001137789-24-000068:mdna:64]
•an increase of $99 million in inventories, primarily due to an increase in raw materials and work in progress inventory.

[0001137789-24-000068:mdna:65]
Cash provided by operating activities for fiscal year 2023 was $942 million and includes the effects of net income adjusted for non-cash items including depreciation, amortization, share-based compensation and:

[0001137789-24-000068:mdna:66]
•a decrease of $911 million in accounts receivable, primarily due to lower revenue and timing of collections;

[0001137789-24-000068:mdna:67]
•a decrease of $425 million in inventories, primarily due to a decrease in units built to align with the prevailing demand environment; and

[0001137789-24-000068:mdna:68]
•an increase of $110 million cash proceeds received from the settlement of certain interest rate swap agreements; partially offset by

[0001137789-24-000068:mdna:69]
•a decrease of $421 million in accounts payable, primarily due to a decrease in materials purchased; and

[0001137789-24-000068:mdna:70]
•a decrease of $152 million in accrued employee compensation, primarily due to cash paid to our employees as part of our variable compensation plans and a decrease in our variable compensation expense.

[0001137789-24-000068:mdna:71]
Cash Used in Investing Activities

[0001137789-24-000068:mdna:72]
In fiscal year 2024, we received $126 million for net cash investing activities, which was primarily due to the proceeds from the sale of SoC operations of $326 million (refer to “Item 8. Financial Statements and Supplementary Data—Note 18. Divestiture” for more details), $40 million from the sale of assets and $14 million from the sale of investments, offset by payments for the purchase of property, equipment and leasehold improvements of $254 million.

[0001137789-24-000068:mdna:73]
43

[0001137789-24-000068:mdna:74]
In fiscal year 2023, we received $217 million for net cash investing activities, which was primarily due to proceeds of $534 million from the sale of assets, offset by payments for the purchase of property, equipment and leasehold improvements of $316 million.

[0001137789-24-000068:mdna:75]
Cash Used in Financing Activities

[0001137789-24-000068:mdna:76]
Net cash used in financing activities of $473 million for fiscal year 2024 was primarily attributable to the following activities:

[0001137789-24-000068:mdna:77]
•$1.3 billion repurchases of long-term debt;

[0001137789-24-000068:mdna:78]
•$585 million in dividends paid to our shareholders;

[0001137789-24-000068:mdna:79]
•$128 million debt fees relating to issuance of long-term debt and capped call transaction; and

[0001137789-24-000068:mdna:80]
•$38 million taxes paid related to net share settlement of equity awards; partially offset by

[0001137789-24-000068:mdna:81]
•$1.5 billion in net proceeds from the issuance of long-term debt; and

[0001137789-24-000068:mdna:82]
•$66 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-24-000068:mdna:83]
Net cash used in financing activities of $988 million for fiscal year 2023 was primarily attributable to the following activities:

[0001137789-24-000068:mdna:84]
•$1.6 billion repurchases of long-term debt;

[0001137789-24-000068:mdna:85]
•$582 million in dividend payments; and

[0001137789-24-000068:mdna:86]
•$408 million in payments for repurchases of our ordinary shares; partially offset by

[0001137789-24-000068:mdna:87]
•$1.6 billion in proceeds from the issuance of long-term debt; and

[0001137789-24-000068:mdna:88]
•$68 million in proceeds from the issuance of ordinary shares under employee stock plans.

[0001137789-24-000068:mdna:89]
Liquidity Sources

[0001137789-24-000068:mdna:90]
Our primary sources of liquidity as of June 28, 2024, consist of: (1) approximately $1.4 billion in cash and cash equivalents, (2) cash we expect to generate from operations and (3) $1.5 billion available for borrowing under our senior unsecured revolving credit facility (“Revolving Credit Facility”), which is part of our Credit Agreement (as defined below).

[0001137789-24-000068:mdna:91]
As of June 28, 2024, no borrowings (including swing line loans) were outstanding and no commitments were utilized for letters of credit issued under the Revolving Credit Facility. The Revolving Credit Facility is available for borrowings, subject to compliance with financial covenants and other customary conditions to borrowing.

[0001137789-24-000068:mdna:92]
As of June 28, 2024, the Credit Agreement includes two financial covenants: (1) interest coverage ratio and (2) net leverage ratio. We continue to evaluate our debt portfolio and structure to comply with our financial debt covenants. As of June 28, 2024, we were in compliance with all of the covenants under our debt agreements. Refer to “Part II, Item 8. Financial Statements—Note 4. Debt” for more details.

[0001137789-24-000068:mdna:93]
As of June 28, 2024, cash and cash equivalents held by our subsidiaries was $1.4 billion. This amount is potentially subject to taxation in Singapore upon repatriation by means of a dividend into our parent company, unless certain exemption is given, or a special approval is granted by the Ministry of Finance in Singapore. However, it is our intent to indefinitely reinvest earnings of subsidiaries outside of Ireland and Singapore. Our current plans do not demonstrate a need to repatriate such earnings by means of a taxable dividend. Should funds be needed in the parent company and should we be unable to fund parent company activities through means other than a taxable dividend, we would be required to accrue and pay taxes on such dividend.

[0001137789-24-000068:mdna:94]
We believe that our sources of cash will be sufficient to fund our operations and meet our cash requirements for at least the next 12 months. Our ability to fund liquidity requirements beyond 12 months will depend on our future cash flows, which are determined by future operating performance, and therefore, subject to prevailing global macroeconomic conditions and financial, business and other factors, some of which are beyond our control.

[0001137789-24-000068:mdna:95]
For additional information on risks and factors that could impact our ability to fund our operations and meet our cash requirements, among others, see “Part I, Item 1A. Risk Factors” of this Annual Report.

[0001137789-24-000068:mdna:96]
Cash Requirements and Commitments

[0001137789-24-000068:mdna:97]
Our liquidity requirements are primarily to meet our working capital, product development and capital expenditure needs, to fund scheduled payments of principal and interest on our indebtedness, and to fund our quarterly dividend and any future strategic investments.

[0001137789-24-000068:mdna:98]
Purchase obligations

[0001137789-24-000068:mdna:99]
Purchase obligations are defined as contractual obligations for the purchase of goods or services, which are enforceable and legally binding on us, and that specify all significant terms. From time to time, we enter into long-term, non-cancelable purchase commitments or make large up-front investments with certain suppliers in order to secure certain components or technologies for the production of our products or to supplement our internal manufacturing capacity for certain components. As of June 28, 2024, we had unconditional purchase obligations of approximately $1.2 billion, primarily related to purchases of inventory components with our suppliers. We expect $1.2 billion of these commitments to be paid within one year. In addition, we also had certain long-term market share based non-cancellable inventory purchase commitments as of June 28, 2024.

[0001137789-24-000068:mdna:100]
We recorded order cancellation fees to terminate certain purchase commitments related to the purchase of inventory components and equipment. By the end of fiscal year 2024, the cumulative unpaid order cancellation fees on the Consolidated Balance Sheets were $93 million, with $39 million in Accrued expenses and $54 million in Accounts payable, all of which is expected to be paid within one year. In certain instances, our unpaid order cancellation fees may change based on the expected timing or ongoing negotiations with our suppliers.

[0001137789-24-000068:mdna:101]
Capital expenditures

[0001137789-24-000068:mdna:102]
We incur material capital expenditures to design and manufacture our products that depend on advanced technologies and manufacturing techniques. As of June 28, 2024, we had unconditional commitments of $161 million primarily related to purchases of equipment, of which approximately $99 million is expected to be paid within one year. For fiscal year 2025, we expect capital expenditures to be higher than fiscal year 2024.

[0001137789-24-000068:mdna:103]
Operating leases

[0001137789-24-000068:mdna:104]
We are a lessee in several operating leases related to real estate facilities for warehouse, office and lab space. As of June 28, 2024, the amount of future minimum rent expense for both occupied and vacated facilities under non-cancelable operating lease contracts was $564 million, of which $63 million is expected to be paid within one year. Refer to “Item 8. Financial Statements and Supplementary Data—Note 6. Leases” for details.

[0001137789-24-000068:mdna:105]
Long-term debt and interest payments on debt

[0001137789-24-000068:mdna:106]
As of June 28, 2024, the future principal payment obligation on our long-term debt was $5.7 billion, of which $479 million will mature within one year. As of June 28, 2024, future interest payments on this outstanding debt is estimated to be approximately $2.0 billion, of which $323 million is expected to be paid within one year. From time to time, we may repurchase, redeem or otherwise extinguish any of our outstanding senior notes in open market or privately negotiated purchases or otherwise, or we may repurchase or redeem outstanding senior notes pursuant to the terms of the applicable indenture. Refer to “Item 8. Financial Statements and Supplementary Data—Note 4. Debt” for more details.

[0001137789-24-000068:mdna:107]
BIS settlement penalty

[0001137789-24-000068:mdna:108]
We accrued a settlement penalty of $300 million for fiscal year 2023, related to BIS’ allegations of violations of the U.S. EAR, which were subsequently resolved by the Settlement Agreement in April 2023. As part of the Settlement Agreement with BIS, quarterly payments of $15 million are made over the course of five years beginning October 31, 2023, of which $60 million is expected to be paid within one year and $195 million thereafter. Refer to “Item 8. Financial Statements and Supplementary Data—Note 14. Legal, Environmental and Other Contingencies” for more details.

[0001137789-24-000068:mdna:109]
Restructuring

[0001137789-24-000068:mdna:110]
During the fiscal year ended June 28, 2024, we made cash payments of $116 million, primarily related to workforce reduction costs under our restructuring plans.

[0001137789-24-000068:mdna:111]
As of June 28, 2024, the future cash payments related to our remaining active restructuring plans were $4 million, all of which is expected to be paid within one year.

[0001137789-24-000068:mdna:112]
Income Tax

[0001137789-24-000068:mdna:113]
As of June 28, 2024, we had a liability for unrecognized tax benefits and an accrual for the payment of related interest totaling $8 million, none of which is expected to be settled within one year. Outside of one year, we are unable to make a reasonably reliable estimate of when cash settlement with a taxing authority will occur.

[0001137789-24-000068:mdna:114]
45

[0001137789-24-000068:mdna:115]
Dividends

[0001137789-24-000068:mdna:116]
On July 23, 2024, our Board of Directors declared a quarterly cash dividend of $0.70 per share, which will be payable on October 7, 2024 to shareholders of record as of the close of business on September 23, 2024. Our ability to pay dividends in the future will be subject to, among other things, general business conditions within the data storage industry, our financial results, the impact of paying dividends on our credit ratings and legal and contractual restrictions on the payment of dividends by our subsidiaries to us or by us to our ordinary shareholders, including restrictions imposed by covenants on our debt instruments.

[0001137789-24-000068:mdna:117]
Share repurchases

[0001137789-24-000068:mdna:118]
From time to time, at our discretion, we may repurchase any of our outstanding ordinary shares through private, open market, or broker assisted purchases, tender offers, or other means, including through the use of derivative transactions. During fiscal year 2024, we repurchased approximately 1 million of our ordinary shares including shares withheld for statutory tax withholdings related to vesting of employee equity awards. See “Item 5. Market for Registrant’s Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities-Repurchases of Our Equity Securities.” As of June 28, 2024, $1.9 billion remained available for repurchase under our existing repurchase authorization limit. We may limit or terminate the repurchase program at any time. All repurchases are effected as redemptions in accordance with our Constitution.

[0001137789-24-000068:mdna:119]
We require substantial amounts of cash to fund any increased working capital requirements, future capital expenditures, scheduled payments of principal and interest on our indebtedness and payments of dividends. We will continue to evaluate and manage the retirement and replacement of existing debt and associated obligations, including evaluating the issuance of new debt securities, exchanging existing debt securities for other debt securities and retiring debt pursuant to privately negotiated transactions, open market purchases, tender offers or other means or otherwise. In addition, we may selectively pursue strategic alliances, acquisitions, joint ventures and investments, which may require additional capital.

[0001137789-24-000068:mdna:120]
Critical Accounting Policies and Estimates

[0001137789-24-000068:mdna:121]
The Company’s accounting policies are more fully described in “Item 8. Financial Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of Significant Accounting Policies”. The methods, estimates and judgments we use in applying our most critical accounting policies have a significant impact on the results we report in our Consolidated Financial Statements. Critical accounting estimates are those estimates that involve a significant level of estimation uncertainty and have had or are reasonably likely to have a material impact on our financial condition or results of operations. Based on this definition, our most critical accounting policies include: Revenue - Sales Program Accruals and Income Taxes. Below, we discuss these policies further, as well as the estimates and judgments involved. We also have other accounting policies and accounting estimates relating to warranty, uncollectible customer accounts, valuation of inventories, assessing goodwill and other long-lived assets for impairment, valuation of share-based payments and restructuring. We believe that these other accounting policies and accounting estimates either do not generally require us to make estimates and judgments that are as difficult or as subjective, or it is less likely that they would have a material impact on our reported results of operations for a given period.

[0001137789-24-000068:mdna:122]
Revenue - Sales Program Accruals. We record estimated variable consideration at the time of revenue recognition as a reduction to revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For OEM sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer's volume of purchases from us or other agreed upon rebate programs. For the distribution and retail channel, these sales incentive programs typically involve estimating the most likely amount of rebates related to a customer's level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Total sales programs were 16% and 17% of gross revenue in fiscal years 2024 and 2023, respectively. Adjustments to revenues due to under or over accruals for sales programs related to revenues reported in prior periods were approximately 1% of gross revenue in fiscal years 2024 and 2023, respectively.

[0001137789-24-000068:mdna:123]
Income Taxes. We make certain estimates and judgments in determining income tax expense for financial statement purposes. These estimates and judgments occur in the calculation of tax credits, recognition of income and deductions and calculation of specific tax assets and liabilities, which arise from differences in the timing of recognition of revenue and expense for income tax and financial statement purposes, as well as tax liabilities associated with uncertain tax positions.

[0001137789-24-000068:mdna:124]
The deferred tax assets we record each period depend primarily on our ability to generate future taxable income in the United States and certain non-U.S. jurisdictions. Each period, we evaluate the need for a valuation allowance for our deferred tax assets and, if necessary, adjust the valuation allowance so that net deferred tax assets are recorded only to the extent we conclude it is more likely than not that these deferred tax assets will be realized.

[0001137789-24-000068:mdna:125]
In evaluating our ability to recover our deferred tax assets, in full or in part, we consider all available positive and negative evidence, including our past operating results, and our forecast of future earnings, future taxable income and prudent and

[0001137789-24-000068:mdna:126]
feasible tax planning strategies. The assumptions utilized in determining future taxable income require significant judgment and are consistent with the plans and estimates we are using to manage the underlying businesses. Actual operating results in future years could differ from our current assumptions, judgments, and estimates. If our outlook for future taxable income changes significantly, our assessment of the need for, and the amount of, a valuation allowance may also change resulting in an additional tax provision or benefit.

[0001137789-24-000068:mdna:127]
Recent Accounting Pronouncements

[0001137789-24-000068:mdna:128]
See “Item 8. Financial Statements and Supplementary Data—Note 1. Basis of Presentation and Summary of Significant Accounting Policies” for information regarding the effect of new accounting pronouncements on our financial statements.
