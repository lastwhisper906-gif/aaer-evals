# STX 8-K — 0001137789-24-000061 filed 2024-07-23

## item codes, every 8-K on or before 2024-08-02

- 2024-07-23 0001137789-24-000061 — 2.02, 7.01, 9.01
- 2024-04-25 0001193125-24-114027 — 5.02, 9.01
- 2024-04-23 0001193125-24-107068 — 1.01
- 2024-04-23 0001137789-24-000030 — 2.02, 7.01, 9.01
- 2024-04-16 0001193125-24-097742 — 7.01
- 2024-01-24 0001137789-24-000004 — 2.02, 7.01, 9.01
- 2024-01-02 0001193125-24-000688 — 5.02
- 2023-10-26 0001137789-23-000125 — 2.02, 7.01, 9.01
- 2023-10-25 0001137789-23-000098 — 5.07, 9.01
- 2023-09-27 0001137789-23-000096 — 1.01
- 2023-09-13 0001193125-23-234372 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2023-09-08 0001193125-23-231165 — 1.01, 8.01, 9.01
- 2023-07-26 0001137789-23-000045 — 2.02, 7.01, 9.01
- 2023-07-24 0001193125-23-192237 — 5.02
- 2023-05-30 0001137789-23-000039 — 1.01, 2.03, 9.01
- 2023-05-25 0001137789-23-000035 — 1.01, 8.01, 9.01
- 2023-05-22 0001137789-23-000032 — 1.01, 2.03
- 2023-04-20 0001137789-23-000025 — 2.02, 2.05, 5.02, 7.01, 9.01
- 2023-04-19 0001193125-23-106624 — 1.01, 2.02, 9.01
- 2023-03-29 0001137789-23-000021 — 2.05, 5.02
- 2023-01-25 0001137789-23-000007 — 2.02, 7.01, 9.01
- 2022-11-30 0001193125-22-295386 — 1.01, 2.03, 8.01, 9.01
- 2022-11-15 0001137789-22-000137 — 8.01
- 2022-11-09 0001137789-22-000129 — 5.02, 9.01
- 2022-11-08 0001193125-22-280194 — 1.01, 2.03
- 2022-10-26 0001137789-22-000118 — 8.01, 9.01
- 2022-10-26 0001137789-22-000116 — 2.02, 2.05, 7.01, 9.01
- 2022-10-25 0001193125-22-268425 — 5.02, 9.01 — amendment of 0001193125-22-228640
- 2022-10-25 0001193125-22-268417 — 5.07, 9.01
- 2022-08-31 0001137789-22-000062 — 7.01, 9.01
- 2022-08-24 0001193125-22-228640 — 5.02, 9.01
- 2022-08-19 0001193125-22-225260 — 1.01, 2.03
- 2022-07-21 0001137789-22-000039 — 2.02, 7.01, 9.01
- 2022-04-27 0001137789-22-000028 — 2.02, 7.01, 9.01
- 2022-03-30 0001193125-22-089760 — 5.02
- 2022-02-24 0001193125-22-052046 — 5.02
- 2022-01-26 0001137789-22-000008 — 2.02, 7.01, 9.01
- 2022-01-25 0001193125-22-017071 — 5.02, 9.01
- 2021-10-26 0001193125-21-307931 — 5.07
- 2021-10-22 0001137789-21-000105 — 2.02, 7.01, 9.01
- 2021-10-15 0001193125-21-299005 — 1.01, 2.03
- 2021-07-21 0001137789-21-000041 — 2.02, 7.01, 9.01
- 2021-06-08 0001137789-21-000033 — 7.01, 9.01
- 2021-05-19 0001193125-21-165970 — 1.01, 2.03, 3.01, 3.03, 5.02, 5.03, 8.01, 9.01
- 2021-04-22 0001137789-21-000023 — 2.02, 7.01, 9.01
- 2021-04-16 0001193125-21-119304 — 5.07
- 2021-03-22 0001193125-21-089557 — 5.02, 9.01
- 2021-01-21 0001137789-21-000003 — 2.02, 7.01, 9.01
- 2021-01-13 0001193125-21-008148 — 1.01, 2.03
- 2020-12-28 0001193125-20-327026 — 5.02, 9.01
- 2020-12-09 0001193125-20-313800 — 1.01, 2.03, 9.01
- 2020-12-04 0001193125-20-310713 — 1.01, 8.01, 9.01
- 2020-10-28 0001193125-20-279868 — 5.07
- 2020-10-22 0001137789-20-000098 — 2.02, 7.01, 9.01
- 2020-07-28 0001137789-20-000055 — 2.02, 7.01, 9.01
- 2020-07-02 0001193125-20-186902 — 8.01, 9.01
- 2020-06-18 0001193125-20-172622 — 1.01, 2.03, 8.01, 9.01
- 2020-06-11 0001193125-20-166696 — 1.01, 2.03, 9.01
- 2020-06-04 0001193125-20-160796 — 1.01, 8.01, 9.01
- 2020-06-03 0001193125-20-159172 — 7.01, 8.01, 9.01
- 2020-06-02 0001193125-20-157932 — 2.05
- 2020-05-11 0001193125-20-139025 — 8.01
- 2020-04-22 0001137789-20-000028 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001137789-20-000013 — 2.02, 7.01, 9.01
- 2019-11-04 0001193125-19-283563 — 5.02, 5.07, 9.01
- 2019-11-01 0001628280-19-013012 — 2.02, 7.01, 9.01
- 2019-09-19 0001193125-19-248970 — 1.01, 2.03, 8.01, 9.01
- 2019-09-18 0001193125-19-247385 — 7.01, 9.01
- 2019-09-04 0001193125-19-237150 — 8.01, 9.01
- 2019-08-02 0001193125-19-211505 — 2.02, 7.01, 9.01
- 2019-06-26 0001193125-19-182712 — 5.02
- 2019-06-18 0001193125-19-175303 — 8.01
- 2019-04-30 0001193125-19-129480 — 5.07
- 2019-04-30 0001193125-19-127378 — 2.02, 7.01, 9.01
- 2019-02-20 0001193125-19-045470 — 1.01, 2.03
- 2019-02-04 0001193125-19-027004 — 2.02, 7.01, 9.01
- 2018-12-21 0001193125-18-356446 — 5.02, 9.01
- 2018-11-02 0001193125-18-316430 — 5.07, 8.01, 9.01
- 2018-11-02 0001193125-18-316418 — 2.02, 7.01, 9.01
- 2018-09-07 0001193125-18-268679 — 5.02 — amendment of 0001193125-18-230467
- 2018-07-30 0001193125-18-230467 — 5.02, 9.01
- 2018-07-30 0001193125-18-230452 — 2.02, 7.01, 9.01
- 2018-07-26 0001193125-18-226626 — 5.02
- 2018-06-01 0001193125-18-181093 — 8.01, 9.01
- 2018-05-01 0001193125-18-145112 — 2.02, 7.01, 9.01
- 2018-01-29 0001193125-18-022528 — 2.02, 7.01, 9.01
- 2018-01-25 0001193125-18-019820 — 5.02, 9.01
- 2018-01-09 0001137789-18-000009 — 2.02, 7.01, 9.01
- 2018-01-08 0001137789-18-000004 — 2.02, 7.01, 9.01
- 2017-12-11 0001137789-17-000101 — 2.05
- 2017-10-23 0001193125-17-316068 — 2.02, 7.01, 9.01
- 2017-10-18 0001137789-17-000068 — 5.02, 5.07, 9.01
- 2017-09-28 0001137789-17-000060 — 1.01
- 2017-07-28 0001137789-17-000046 — 5.02
- 2017-07-25 0001193125-17-234440 — 2.02, 2.05, 5.02, 7.01, 9.01
- 2017-06-02 0001193125-17-192960 — 5.02
- 2017-04-26 0001193125-17-138005 — 2.02, 7.01, 9.01
- 2017-03-10 0001193125-17-077510 — 2.05
- 2017-02-03 0001104659-17-006357 — 1.01, 2.03, 9.01
- 2017-01-31 0001104659-17-005357 — 8.01, 9.01
- 2017-01-31 0001104659-17-005173 — 8.01, 9.01
- 2017-01-27 0001104659-17-004448 — 8.01
- 2017-01-24 0001193125-17-016690 — 2.02, 7.01, 9.01
- 2017-01-20 0001193125-17-013685 — 5.02, 9.01
- 2016-10-24 0001104659-16-151422 — 5.02, 5.03, 5.07, 9.01
- 2016-10-19 0001193125-16-741277 — 2.02, 7.01, 9.01
- 2016-10-11 0001193125-16-734835 — 2.02, 9.01
- 2016-10-04 0001104659-16-148575 — 5.02
- 2016-09-27 0001104659-16-146813 — 5.02
- 2016-08-02 0001104659-16-135908 — 2.02, 7.01, 9.01
- 2016-07-28 0001104659-16-135046 — 5.02
- 2016-07-11 0001104659-16-131996 — 2.02, 2.05, 9.01
- 2016-07-08 0001104659-16-131749 — 5.02
- 2016-06-29 0001104659-16-130122 — 2.05
- 2016-06-27 0001104659-16-129505 — 5.02
- 2016-04-29 0001104659-16-115593 — 2.02, 7.01, 9.01
- 2016-04-13 0001104659-16-111266 — 2.02, 9.01
- 2016-01-29 0001104659-16-092323 — 2.02, 7.01, 9.01
- 2016-01-04 0001104659-16-087730 — 5.02, 9.01
- 2015-10-30 0001104659-15-074350 — 2.02, 7.01, 9.01
- 2015-10-21 0001104659-15-071908 — 5.02, 9.01
- 2015-10-21 0001104659-15-071906 — 5.07, 7.01, 9.01
- 2015-10-15 0001104659-15-070776 — 2.02, 9.01
- 2015-09-21 0001104659-15-066273 — 5.02
- 2015-09-10 0001104659-15-064389 — 2.05
- 2015-08-06 0001104659-15-057159 — 5.02
- 2015-07-31 0001104659-15-055040 — 2.02, 7.01, 9.01
- 2015-07-22 0001104659-15-052507 — 5.02, 9.01
- 2015-07-13 0001104659-15-050755 — 2.02, 9.01
- 2015-05-14 0001104659-15-038166 — 1.01, 2.03, 9.01
- 2015-05-12 0001104659-15-036968 — 8.01, 9.01
- 2015-05-11 0001104659-15-036533 — 8.01, 9.01
- 2015-05-01 0001104659-15-033202 — 5.02
- 2015-04-23 0001104659-15-029483 — 8.01, 9.01
- 2015-04-17 0001104659-15-028152 — 2.02, 7.01, 9.01
- 2015-04-07 0001104659-15-026148 — 7.01
- 2015-01-26 0001104659-15-004316 — 2.02, 7.01, 9.01
- 2015-01-16 0001104659-15-002732 — 1.01, 9.01
- 2015-01-02 0001104659-15-000147 — 8.01
- 2014-12-02 0001104659-14-084370 — 1.01, 2.03, 9.01
- 2014-11-25 0001104659-14-083066 — 8.01, 9.01
- 2014-11-24 0001104659-14-082837 — 8.01, 9.01
- 2014-10-27 0001104659-14-073832 — 2.02, 7.01, 9.01
- 2014-10-24 0001104659-14-073609 — 5.02, 5.07, 9.01
- 2014-10-22 0001104659-14-073104 — 7.01, 9.01
- 2014-10-08 0001104659-14-070767 — 8.01
- 2014-09-12 0001104659-14-066107 — 5.02
- 2014-09-12 0001104659-14-066101 — 7.01
- 2014-07-23 0001104659-14-052995 — 5.02
- 2014-07-17 0001104659-14-052019 — 2.02, 7.01, 9.01
- 2014-06-18 0001104659-14-046714 — 8.01, 9.01
- 2014-06-09 0001104659-14-044575 — 7.01
- 2014-06-04 0001104659-14-043897 — 8.01
- 2014-05-28 0001104659-14-041862 — 1.01, 2.03, 8.01, 9.01
- 2014-05-20 0001104659-14-040454 — 8.01, 9.01
- 2014-05-20 0001104659-14-040220 — 8.01, 9.01
- 2014-04-29 0001104659-14-031916 — 2.02, 7.01, 9.01
- 2014-04-22 0001104659-14-029197 — 5.02
- 2014-02-24 0001104659-14-012465 — 5.02, 7.01, 9.01
- 2014-01-27 0001104659-14-004298 — 2.02, 7.01, 9.01
- 2014-01-23 0001104659-14-003803 — 5.02
- 2013-12-23 0001104659-13-091738 — 1.01, 8.01, 9.01
- 2013-11-05 0001104659-13-081194 — 1.01, 2.03, 9.01
- 2013-11-04 0001104659-13-080161 — 5.02, 5.03, 5.07, 9.01
- 2013-10-31 0001104659-13-079635 — 8.01, 9.01
- 2013-10-31 0001104659-13-079438 — 8.01, 9.01
- 2013-10-28 0001104659-13-078341 — 2.02, 7.01, 9.01
- 2013-10-28 0001104659-13-078316 — 5.02, 7.01, 9.01
- 2013-10-08 0001104659-13-074454 — 1.01, 1.02, 9.01
- 2013-09-20 0001104659-13-071413 — 5.02
- 2013-07-24 0001104659-13-056053 — 5.02, 7.01
- 2013-07-24 0001104659-13-056052 — 2.02, 7.01, 9.01
- 2013-06-14 0001104659-13-049436 — 8.01, 9.01
- 2013-05-31 0001104659-13-045928 — 8.01, 9.01
- 2013-05-22 0001104659-13-043876 — 1.01, 2.03, 9.01
- 2013-05-16 0001104659-13-042180 — 7.01, 9.01
- 2013-05-15 0001104659-13-042028 — 8.01, 9.01
- 2013-05-15 0001104659-13-041695 — 8.01, 9.01
- 2013-05-07 0001104659-13-038226 — 5.02
- 2013-05-01 0001104659-13-036004 — 2.02, 9.01
- 2013-03-15 0001104659-13-021156 — 7.01
- 2013-01-28 0001104659-13-005180 — 2.02, 9.01
- 2013-01-08 0001104659-13-001291 — 2.02, 9.01
- 2012-11-29 0001104659-12-080911 — 8.01, 9.01
- 2012-10-31 0001104659-12-072476 — 2.02, 9.01
- 2012-10-25 0001104659-12-071208 — 5.07
- 2012-10-16 0001104659-12-069238 — 7.01
- 2012-09-28 0001104659-12-066105 — 7.01
- 2012-09-21 0001104659-12-064869 — 7.01
- 2012-08-02 0001104659-12-053775 — 5.02
- 2012-07-30 0001104659-12-052298 — 2.02, 5.02, 8.01, 9.01
- 2012-07-05 0001104659-12-047737 — 2.02, 9.01
- 2012-04-26 0001104659-12-029099 — 5.02, 8.01, 9.01
- 2012-04-17 0001104659-12-025931 — 2.02, 9.01
- 2012-01-31 0001104659-12-005522 — 2.02, 9.01
- 2012-01-27 0001104659-12-004299 — 8.01, 9.01
- 2012-01-04 0001104659-12-000411 — 2.02, 9.01
- 2011-12-20 0001104659-11-070207 — 2.01, 3.02, 9.01
- 2011-12-12 0001104659-11-069005 — 8.01
- 2011-12-05 0001104659-11-067679 — 5.02, 9.01
- 2011-11-29 0001104659-11-066436 — 7.01, 9.01
- 2011-11-22 0001104659-11-065589 — 7.01, 9.01
- 2011-11-03 0001104659-11-060307 — 7.01
- 2011-10-21 0001104659-11-056997 — 2.02, 8.01, 9.01
- 2011-10-12 0001104659-11-055849 — 7.01, 9.01
- 2011-07-29 0001104659-11-041897 — 5.02
- 2011-07-20 0001104659-11-039922 — 2.02, 9.01
- 2011-06-01 0001104659-11-032473 — 8.01
- 2011-05-23 0001104659-11-030867 — 8.01
- 2011-05-18 0001104659-11-029869 — 1.01, 2.03, 9.01
- 2011-05-04 0001104659-11-025801 — 8.01, 9.01
- 2011-05-04 0001104659-11-025462 — 8.01, 9.01
- 2011-04-19 0001104659-11-020787 — 1.01, 2.02, 3.02, 9.01
- 2011-04-08 0001104659-11-019316 — 5.02, 9.01
- 2011-04-07 0001104659-11-019141 — 2.02, 8.01, 9.01
- 2011-03-09 0001104659-11-013084 — 5.02
- 2011-02-18 0001104659-11-008419 — 8.01
- 2011-02-01 0001104659-11-004106 — 5.02, 9.01
- 2011-01-19 0001104659-11-002037 — 1.01, 2.02, 2.03, 5.07, 9.01
- 2010-12-14 0001104659-10-062647 — 1.01, 2.03, 9.01
- 2010-12-08 0001104659-10-061747 — 8.01, 9.01
- 2010-12-08 0001104659-10-061643 — 7.01, 8.01, 9.01
- 2010-11-29 0001104659-10-060338 — 7.01, 9.01
- 2010-10-20 0001104659-10-052966 — 2.02, 9.01
- 2010-10-15 0001104659-10-052362 — 8.01, 9.01
- 2010-09-13 0001104659-10-048317 — 5.02, 9.01
- 2010-08-16 0001104659-10-044431 — 5.02
- 2010-07-29 0001104659-10-040519 — 5.02, 9.01
- 2010-07-20 0001104659-10-038670 — 2.02, 9.01
- 2010-07-06 0001104659-10-036996 — 1.01, 2.03, 3.01, 3.03, 5.01, 5.02, 8.01, 9.01
- 2010-06-25 0001104659-10-035630 — 8.01, 9.01
- 2010-05-26 0001104659-10-030931 — 5.02
- 2010-05-14 0001104659-10-028664 — 1.01, 2.03, 9.01
- 2010-04-30 0001104659-10-023493 — 8.01, 9.01
- 2010-04-29 0001104659-10-022773 — 1.02, 8.01, 9.01
- 2010-04-20 0001104659-10-020750 — 2.02, 9.01
- 2010-04-16 0001104659-10-020113 — 5.07
- 2010-03-22 0001104659-10-015668 — 1.01, 9.01
- 2010-03-03 0001104659-10-011870 — 1.01, 2.03, 9.01
- 2010-01-20 0001104659-10-002269 — 2.02, 9.01
- 2009-10-29 0001104659-09-060949 — 5.02, 7.01
- 2009-10-20 0001104659-09-059594 — 2.02, 9.01
- 2009-10-01 0001104659-09-057311 — 1.01, 2.03, 2.06, 9.01
- 2009-09-22 0001104659-09-055716 — 7.01, 9.01
- 2009-08-04 0001193125-09-163032 — 2.05
- 2009-07-31 0001193125-09-160678 — 5.02, 9.01
- 2009-07-21 0001193125-09-152269 — 2.02, 9.01
- 2009-07-09 0001193125-09-146452 — 5.02
- 2009-06-24 0001193125-09-136674 — 7.01, 9.01
- 2009-06-01 0001193125-09-122549 — 1.01, 2.03, 9.01
- 2009-05-14 0001193125-09-110016 — 8.01, 9.01
- 2009-05-13 0001193125-09-109216 — 2.05, 7.01, 9.01
- 2009-05-05 0001193125-09-099861 — 1.01, 2.03, 9.01
- 2009-04-21 0001193125-09-083544 — 2.02, 9.01
- 2009-04-17 0001193125-09-081018 — 8.01, 9.01
- 2009-04-13 0001193125-09-077471 — 2.02, 9.01
- 2009-04-13 0001193125-09-077470 — 8.01, 9.01
- 2009-04-06 0001193125-09-073113 — 1.01, 2.03, 9.01
- 2009-03-09 0001193125-09-048538 — 5.02
- 2009-03-04 0001193125-09-044916 — 5.02, 8.01
- 2009-02-06 0001193125-09-021262 — 5.02
- 2009-02-04 0001193125-09-018804 — 5.02, 8.01
- 2009-02-02 0001193125-09-016478 — 2.06 — amendment, the index does not say of what
- 2009-01-27 0001193125-09-012058 — 5.02
- 2009-01-21 0001193125-09-009019 — 2.02, 5.02, 9.01
- 2009-01-14 0001193125-09-005721 — 2.05, 7.01
- 2009-01-12 0001193125-09-004420 — 5.02, 7.01, 9.01
- 2008-12-24 0001193125-08-259972 — 2.06
- 2008-12-12 0001193125-08-252765 — 2.03
- 2008-12-10 0001193125-08-250840 — 7.01
- 2008-11-12 0001193125-08-233906 — 5.02
- 2008-10-22 0001193125-08-214482 — 2.02, 9.01
- 2008-09-19 0001193125-08-198664 — 2.05
- 2008-09-12 0001193125-08-195206 — 1.01
- 2008-08-27 0001193125-08-185448 — 1.02, 3.01, 5.02, 9.01
- 2008-07-15 0001193125-08-151292 — 2.02, 9.01
- 2008-07-11 0001193125-08-149749 — 2.05
- 2008-07-03 0001193125-08-146791 — 5.02
- 2008-04-29 0001193125-08-094835 — 5.02, 9.01
- 2008-04-15 0001193125-08-081743 — 2.02, 9.01
- 2008-03-12 0001193125-08-054331 — 8.01, 9.01
- 2008-03-04 0001193125-08-045657 — 7.01
- 2008-02-04 0001193125-08-019262 — 8.01, 9.01
- 2008-01-18 0001193125-08-008849 — 8.01, 9.01
- 2008-01-17 0001193125-08-008120 — 2.02, 9.01
- 2007-12-21 0001193125-07-269469 — 2.05
- 2007-12-05 0001193125-07-259675 — 5.02
- 2007-10-17 0001193125-07-220376 — 8.01, 9.01
- 2007-10-16 0001193125-07-219386 — 2.02, 9.01
- 2007-09-18 0000950134-07-020112 — 5.02, 9.01
- 2007-08-29 0000950134-07-019145 — 1.01, 2.02, 9.01
- 2007-07-20 0001193125-07-159001 — 8.01, 9.01
- 2007-07-19 0001193125-07-158214 — 2.02, 9.01
- 2007-04-18 0001193125-07-083845 — 8.01, 9.01
- 2007-04-17 0001193125-07-082824 — 2.02, 9.01
- 2007-04-10 0001193125-07-077251 — 2.02, 9.01
- 2007-02-27 0001193125-07-040081 — 5.02, 7.01
- 2007-01-24 0001193125-07-011834 — 8.01, 9.01
- 2007-01-23 0001193125-07-010955 — 2.02, 9.01
- 2006-12-21 0001193125-06-257603 — 8.01, 9.01
- 2006-12-07 0001193125-06-247897 — 5.02
- 2006-11-07 0001193125-06-225545 — 2.02, 7.01, 8.01, 9.01
- 2006-11-01 0001193125-06-220706 — 1.01, 9.01
- 2006-10-25 0001193125-06-214798 — 8.01, 9.01
- 2006-10-24 0001193125-06-213813 — 2.02, 9.01
- 2006-10-11 0001193125-06-206304 — 5.02
- 2006-10-03 0001193125-06-201845 — 5.02, 9.01
- 2006-09-21 0001193125-06-194878 — 1.01, 1.02, 2.03, 2.04, 8.01, 9.01
- 2006-09-19 0001193125-06-192726 — 8.01, 9.01
- 2006-09-12 0001193125-06-189437 — 5.02, 8.01, 9.01
- 2006-08-24 0001193125-06-179258 — 1.01
- 2006-08-09 0001193125-06-167961 — 8.01, 9.01
- 2006-08-08 0001193125-06-165853 — 2.02, 9.01
- 2006-06-01 0001193125-06-122124 — 7.01, 9.01
- 2006-05-25 0001193125-06-119646 — 1.01, 2.01, 2.03, 5.02, 9.01
- 2006-05-17 0001193125-06-114760 — 8.01, 9.01
- 2006-05-04 0001193125-06-099262 — 8.01, 9.01
- 2006-05-03 0001193125-06-098229 — 5.05, 9.01
- 2006-04-27 0001193125-06-090749 — 8.01
- 2006-04-20 0001193125-06-084566 — 8.01, 9.01
- 2006-04-18 0001193125-06-082414 — 2.02, 9.01
- 2006-04-13 0001193125-06-079690 — 8.01
- 2006-04-03 0001193125-06-071956 — 8.01
- 2006-03-13 0001193125-06-051798 — 8.01
- 2006-02-14 0001193125-06-030829 — 8.01, 9.01
- 2006-01-26 0001193125-06-012909 — 8.01, 9.01
- 2006-01-25 0001193125-06-011608 — 8.01, 9.01
- 2006-01-19 0001193125-06-008770 — 8.01, 9.01
- 2006-01-18 0001193125-06-007939 — 2.02, 9.01
- 2005-12-22 0001193125-05-247782 — 1.01, 5.02, 9.01
- 2005-12-22 0001193125-05-247766 — 1.01, 9.01
- 2005-12-21 0001193125-05-246701 — 8.01, 9.01
- 2005-12-01 0001193125-05-234733 — 7.01
- 2005-11-23 0001193125-05-231674 — 1.01, 1.02, 7.01, 9.01
- 2005-10-19 0001193125-05-203955 — 2.02, 9.01
- 2005-10-18 0001193125-05-203356 — 2.02, 7.01, 9.01
- 2005-09-08 0001193125-05-181893 — 7.01, 9.01
- 2005-09-07 0001193125-05-181605 — 1.01
- 2005-08-04 0001193125-05-157913 — 8.01, 9.01
- 2005-08-03 0001193125-05-156407 — 1.01, 8.01, 9.01
- 2005-07-19 0001193125-05-144591 — 2.02, 9.01
- 2005-06-08 0001193125-05-121880 — 7.01
- 2005-05-17 0001193125-05-109518 — 7.01
- 2005-04-19 0001193125-05-079453 — 2.02, 9.01
- 2005-03-22 0001193125-05-057519 — 1.01
- 2005-03-16 0001193125-05-052560 — 7.01
- 2005-03-07 0001193125-05-043752 — 7.01, 9.01
- 2005-02-08 0001193125-05-022340 — 1.01, 7.01
- 2005-01-18 0001193125-05-007666 — 2.02, 9.01
- 2004-12-13 0001193125-04-211590 — 7.01, 8.01, 9.01
- 2004-12-07 0001193125-04-208768 — 7.01, 9.01
- 2004-10-29 0001193125-04-181463 — 1.01, 5.02, 9.01
- 2004-10-19 0001193125-04-173795 — 2.02, 9.01
- 2004-09-23 0001193125-04-160889 — 8.01, 9.01
- 2004-09-21 0001193125-04-159593 — 8.01, 9.01
- 2004-09-07 0001193125-04-152868 — 7.01, 9.01
- 2004-07-28 0001193125-04-126152 — 5, 7
- 2004-07-20 0001193125-04-121017 — 12, 7
- 2004-06-02 0001193125-04-097697 — 7, 9
- 2004-04-30 0001193125-04-075386 — 5, 7
- 2004-04-20 0001193125-04-065621 — 12, 7
- 2004-04-06 0001193125-04-057855 — 12, 7
- 2004-03-16 0001193125-04-042542 — 5
- 2004-03-03 0001193125-04-033653 — 7, 9
- 2004-01-21 0001193125-04-006388 — 12, 5, 7
- 2003-10-31 0001193125-03-070294 — 5, 7
- 2003-10-27 0001193125-03-067685 — 5, 7
- 2003-10-22 0001193125-03-065398 — 12, 5, 7
- 2003-07-16 0001193125-03-019880 — 7, 9
- 2003-07-10 0001193125-03-018043 — 5
- 2003-07-07 0001193125-03-016864 — 5
- 2003-06-27 0001193125-03-014262 — 5, 7
- 2003-04-16 0001012870-03-001799 — 7, 9

## late-filing notifications on or before 2024-08-02

- none on or before 2024-08-02

## item 2.02 — earnings release, exhibit 99.1

[0001137789-24-000061:8k_2_02:1]
EX-99.1
2
stxq42024pressreleasefinan.htm
EX-99.1

[0001137789-24-000061:8k_2_02:2]
Document

[0001137789-24-000061:8k_2_02:3]
Exhibit 99.1

[0001137789-24-000061:8k_2_02:4]
Investor Relations Contact:

[0001137789-24-000061:8k_2_02:5]
Shanye Hudson, (510) 661-1600

[0001137789-24-000061:8k_2_02:6]
shanye.hudson@seagate.com

[0001137789-24-000061:8k_2_02:7]
Media Contact:

[0001137789-24-000061:8k_2_02:8]
Agnieszka Zielinska, (503) 380-0948

[0001137789-24-000061:8k_2_02:9]
agnieszka.zielinska@seagate.com

[0001137789-24-000061:8k_2_02:10]
SEAGATE TECHNOLOGY REPORTS FISCAL FOURTH QUARTER AND FISCAL YEAR 2024 FINANCIAL RESULTS

[0001137789-24-000061:8k_2_02:11]
Fiscal Q4 2024 Highlights

[0001137789-24-000061:8k_2_02:12]
▪Revenue of $1.89 billion

[0001137789-24-000061:8k_2_02:13]
▪GAAP diluted earnings per share (EPS) of $2.39; non-GAAP diluted EPS of $1.05

[0001137789-24-000061:8k_2_02:14]
▪Cash flow from operations of $434 million and free cash flow of $380 million

[0001137789-24-000061:8k_2_02:15]
▪Declared cash dividend of $0.70 per share

[0001137789-24-000061:8k_2_02:16]
Fiscal Year 2024 Highlights

[0001137789-24-000061:8k_2_02:17]
▪Revenue of $6.55 billion

[0001137789-24-000061:8k_2_02:18]
▪GAAP diluted EPS of $1.58; non-GAAP diluted EPS of $1.29

[0001137789-24-000061:8k_2_02:19]
▪Cash flow from operations of $918 million and free cash flow of $664 million

[0001137789-24-000061:8k_2_02:20]
▪Returned $585 million to shareholders through dividends

[0001137789-24-000061:8k_2_02:21]
FREMONT, CA – July 23, 2024 - Seagate Technology Holdings plc (NASDAQ: STX) (the “Company” or “Seagate”), a leading innovator of mass-capacity data storage, today reported financial results for its fiscal fourth quarter and fiscal year ended June 28, 2024.

[0001137789-24-000061:8k_2_02:22]
“Seagate delivered robust financial performance for the June quarter amid an improving cloud demand environment, capping off a fiscal year of strong execution against our financial goals. Q4 revenue grew 18% year-over-year, non-GAAP gross margin expanded to nearly 31%, and non-GAAP EPS exceeded the high end of our guidance range,” said Dave Mosley, Seagate’s chief executive officer.

[0001137789-24-000061:8k_2_02:23]
“In fiscal 2025, we are remaining focused on driving profitability and maintaining supply discipline while continuing to execute our mass capacity product roadmap, anchored by our HAMR technology. Our data storage solutions offer our cloud and enterprise customers with cost, power and space advantages that support their investments in critical AI and other data-driven initiatives,” Mosley concluded.

[0001137789-24-000061:8k_2_02:24]
Quarterly Financial Results

[0001137789-24-000061:8k_2_02:25]
|  | GAAP |  | Non-GAAP |
|  | FQ4 2024 |  | FQ4 2023 |  | FQ4 2024 |  | FQ4 2023 |
| Revenue ($M) | $ | 1,887 |  | $ | 1,602 |  | $ | 1,887 |  | $ | 1,602 |
| Gross Margin | 31.8% |  | 19.0% |  | 30.9% |  | 19.5% |
| Operating Margin | 16.6% |  | 1.6% |  | 17.3% |  | 3.4% |
| Net Income (Loss) ($M) | $ | 513 |  | $ | (92) |  | $ | 222 |  | $ | (37) |
| Diluted Earnings (Loss) Per Share | $ | 2.39 |  | $ | (0.44) |  | $ | 1.05 |  | $ | (0.18) |

[0001137789-24-000061:8k_2_02:26]
Annual Financial Results

[0001137789-24-000061:8k_2_02:27]
|  | GAAP |  | Non-GAAP |
|  | FY 2024 |  | FY 2023 |  | FY 2024 |  | FY 2023 |
| Revenue ($M) | $ | 6,551 |  | $ | 7,384 |  | $ | 6,551 |  | $ | 7,384 |
| Gross Margin | 23.4% |  | 18.3% |  | 25.5% |  | 21.1% |
| Operating Margin | 6.9% |  | (4.6)% |  | 10.3% |  | 5.6% |
| Net Income (Loss) ($M) | $ | 335 |  | $ | (529) |  | $ | 272 |  | $ | 40 |
| Diluted Earnings (Loss) Per Share | $ | 1.58 |  | $ | (2.56) |  | $ | 1.29 |  | $ | 0.19 |

[0001137789-24-000061:8k_2_02:28]
For a detailed reconciliation of GAAP to non-GAAP results, see accompanying financial tables.

[0001137789-24-000061:8k_2_02:29]
During the fiscal fourth quarter, the Company generated $434 million in cash flow from operations, $380 million in free cash flow and returned $147 million of capital to shareholders through its quarterly dividend. Additionally, the Company sold the System-on-Chip Operations for $600 million during the fiscal fourth quarter, which included cash proceeds of $560 million. The remaining $40 million is expected to be received by the end of fiscal year 2026. Of the $560 million cash proceeds, $326 million was recorded as an investing inflow and $226 million, net of transaction costs, was recorded in both cash flow from operations and in free cash flow. For fiscal year 2024, the Company generated $918 million in cash flow from operations, $664 million in free cash flow, and paid cash dividends of $585 million. As of the end of the fiscal year, cash and cash equivalents totaled approximately $1.4 billion, and there were approximately 210 million ordinary shares issued and outstanding. Additionally, during the fiscal year, the Company issued $1.5 billion of convertible notes to primarily retire its term loans in the fiscal first quarter.

[0001137789-24-000061:8k_2_02:30]
Seagate has issued a Supplemental Financial Information document, which is available on Seagate’s Investor Relations website at investors.seagate.com.

[0001137789-24-000061:8k_2_02:31]
Quarterly Cash Dividend

[0001137789-24-000061:8k_2_02:32]
The Board of Directors of the Company (the "Board") declared a quarterly cash dividend of $0.70 per share, which will be payable on October 7, 2024 to shareholders of record as of the close of business on September 23, 2024. The payment of any future quarterly dividends will be at the discretion of the Board and will be dependent upon Seagate’s financial position, results of operations, available cash, cash flow, capital requirements and other factors deemed relevant by the Board.

[0001137789-24-000061:8k_2_02:33]
Business Outlook

[0001137789-24-000061:8k_2_02:34]
The Company is providing the following guidance for its fiscal first quarter 2025:

[0001137789-24-000061:8k_2_02:35]
•Revenue of $2.10 billion, plus or minus $150 million

[0001137789-24-000061:8k_2_02:36]
•Non-GAAP diluted EPS of $1.40, plus or minus $0.20

[0001137789-24-000061:8k_2_02:37]
Guidance regarding non-GAAP diluted EPS excludes known pre-tax charges related to estimated share-based compensation expenses of $0.16 per share.

[0001137789-24-000061:8k_2_02:38]
We have not reconciled our non-GAAP diluted EPS guidance for fiscal first quarter 2025 to the most directly comparable GAAP measure, other than estimated share-based compensation expenses, because material items that may impact these measures are out of our control and/or cannot be reasonably predicted, including, but not limited to, accelerated depreciation, impairment and other charges related to cost saving efforts, net (gain) loss recognized from early redemption of debt, purchase order cancellation fees, strategic investment losses (gains) or impairment charges, income tax adjustments on these measures, and other charges or benefits that may arise. The amounts of these measures are not currently available but may be material to future results. A reconciliation of the non-GAAP diluted EPS guidance for fiscal first quarter 2025 to the corresponding GAAP measures is not available without unreasonable effort. A reconciliation of our historical non-GAAP financial measures to their nearest GAAP equivalent is contained in this release.

[0001137789-24-000061:8k_2_02:39]
Investor Communications

[0001137789-24-000061:8k_2_02:40]
Seagate management will hold a public webcast today at 2:00 PM PT / 5:00 PM ET that can be accessed on its Investor Relations website at investors.seagate.com.

[0001137789-24-000061:8k_2_02:41]
An archived audio webcast of this event will be available on Seagate’s Investor Relations website at investors.seagate.com shortly following the event conclusion.

[0001137789-24-000061:8k_2_02:42]
About Seagate

[0001137789-24-000061:8k_2_02:43]
Seagate Technology is a leading innovator of mass-capacity data storage. We create breakthrough technology so you can confidently store your data and easily unlock its value. Founded over 45 years ago, Seagate has shipped over four billion terabytes of data capacity and offers a full portfolio of storage devices, systems, and services from edge to cloud. To learn more about how Seagate leads storage innovation, visit www.seagate.com and our blog, or follow us on X, Facebook, LinkedIn, and YouTube.

[0001137789-24-000061:8k_2_02:44]
© 2024 Seagate Technology LLC. All rights reserved. Seagate, Seagate Technology, and the Spiral logo are registered trademarks of Seagate Technology LLC in the United States and/or other countries.

[0001137789-24-000061:8k_2_02:45]
Cautionary Note Regarding Forward-Looking Statements

[0001137789-24-000061:8k_2_02:46]
The inclusion of Seagate’s website addresses in this press release are provided for convenience only. The information contained in, or that can be accessed through, Seagate’s websites and social media channels are not part of this press release.

[0001137789-24-000061:8k_2_02:47]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-24-000061:8k_2_02:48]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001137789-24-000061:8k_2_02:49]
(In millions)

[0001137789-24-000061:8k_2_02:50]
|  | June 28,2024 |  | June 30,2023 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,358 |  |  | $ | 786 |  |
| Accounts receivable, net | 429 |  |  | 621 |  |
| Inventories, net | 1,239 |  |  | 1,140 |  |
| Other current assets | 306 |  |  | 358 |  |
| Total current assets | 3,332 |  |  | 2,905 |  |
| Property, equipment and leasehold improvements, net | 1,614 |  |  | 1,706 |  |
| Goodwill | 1,219 |  |  | 1,237 |  |
| Deferred income taxes | 1,037 |  |  | 1,117 |  |
| Other assets, net | 537 |  |  | 591 |  |
| Total Assets | $ | 7,739 |  |  | $ | 7,556 |  |
| LIABILITIES AND SHAREHOLDER’S DEFICIT |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 1,786 |  |  | $ | 1,603 |  |
| Accrued employee compensation | 106 |  |  | 100 |  |
| Accrued warranty | 74 |  |  | 78 |  |
| Current portion of long-term debt | 479 |  |  | 63 |  |
| Accrued expenses | 654 |  |  | 748 |  |
| Total current liabilities | 3,099 |  |  | 2,592 |  |
| Long-term accrued warranty | 75 |  |  | 90 |  |
| Other non-current liabilities | 861 |  |  | 685 |  |
| Long-term debt, less current portion | 5,195 |  |  | 5,388 |  |
| Total Liabilities | 9,230 |  |  | 8,755 |  |
| Total Shareholders’ Deficit | (1,491) |  |  | (1,199) |  |
| Total Liabilities and Shareholders’ Deficit | $ | 7,739 |  |  | $ | 7,556 |  |

[0001137789-24-000061:8k_2_02:51]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-24-000061:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001137789-24-000061:8k_2_02:53]
(In millions, except per share data)

[0001137789-24-000061:8k_2_02:54]
|  | For the Three Months Ended |  | For the Fiscal Years Ended |
|  | June 28,2024 |  | June 30,2023 |  | June 28,2024 |  | June 30,2023 |
| Revenue | $ | 1,887 |  |  | $ | 1,602 |  |  | $ | 6,551 |  |  | $ | 7,384 |  |
| Cost of revenue | 1,287 |  |  | 1,298 |  |  | 5,015 |  |  | 6,033 |  |
| Product development | 158 |  |  | 172 |  |  | 654 |  |  | 797 |  |
| Marketing and administrative | 131 |  |  | 114 |  |  | 460 |  |  | 491 |  |
| Amortization of intangibles | — |  |  | — |  |  | — |  |  | 3 |  |
| BIS settlement penalty | — |  |  | — |  |  | — |  |  | 300 |  |
| Restructuring and other, net | (3) |  |  | (8) |  |  | (30) |  |  | 102 |  |
| Total operating expenses | 1,573 |  |  | 1,576 |  |  | 6,099 |  |  | 7,726 |  |
| Income (loss) from operations | 314 |  |  | 26 |  |  | 452 |  |  | (342) |  |
| Interest income | 7 |  |  | 6 |  |  | 15 |  |  | 10 |  |
| Interest expense | (82) |  |  | (84) |  |  | (332) |  |  | (313) |  |
| Net gain from termination of interest rate swap | — |  |  | — |  |  | 104 |  |  | — |  |
| Net gain from business divestiture | 313 |  |  | — |  |  | 313 |  |  | — |  |
| Net (loss) gain from early redemption of debt | — |  |  | (17) |  |  | (29) |  |  | 190 |  |
| Other, net | (14) |  |  | (16) |  |  | (78) |  |  | (41) |  |
| Other income (expense), net | 224 |  |  | (111) |  |  | (7) |  |  | (154) |  |
| Income (loss) before income taxes | 538 |  |  | (85) |  |  | 445 |  |  | (496) |  |
| Provision for income taxes | 25 |  |  | 7 |  |  | 110 |  |  | 33 |  |
| Net income (loss) | $ | 513 |  |  | $ | (92) |  |  | $ | 335 |  |  | $ | (529) |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 2.44 |  |  | $ | (0.44) |  |  | $ | 1.60 |  |  | $ | (2.56) |  |
| Diluted | $ | 2.39 |  |  | $ | (0.44) |  |  | $ | 1.58 |  |  | $ | (2.56) |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 210 |  |  | 207 |  |  | 209 |  |  | 207 |  |
| Diluted | 215 |  |  | 207 |  |  | 212 |  |  | 207 |  |
| Cash dividends declared per ordinary share | $ | 0.70 |  |  | $ | 0.70 |  |  | $ | 2.80 |  |  | $ | 2.80 |  |

[0001137789-24-000061:8k_2_02:55]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-24-000061:8k_2_02:56]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001137789-24-000061:8k_2_02:57]
(In millions)

[0001137789-24-000061:8k_2_02:58]
|  | For the Fiscal Years Ended |
|  | June 28,2024 |  | June 30,2023 |
| OPERATING ACTIVITIES |  |  |  |
| Net income (loss) | $ | 335 |  |  | $ | (529) |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 264 |  |  | 513 |  |
| Share-based compensation | 127 |  |  | 115 |  |
| Net loss (gain) from redemption and repurchase of debt | 7 |  |  | (204) |  |
| Net gain from business divestiture | (313) |  |  | — |  |
| Deferred income taxes | 78 |  |  | 10 |  |
| Other non-cash operating activities, net | 34 |  |  | (125) |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 192 |  |  | 911 |  |
| Inventories, net | (99) |  |  | 425 |  |
| Accounts payable | 227 |  |  | (421) |  |
| Accrued employee compensation | 6 |  |  | (152) |  |
| BIS settlement penalty | (45) |  |  | — |  |
| Accrued expenses, income taxes and warranty | (138) |  |  | 101 |  |
| Other assets and liabilities | 243 |  |  | 298 |  |
| Net cash provided by operating activities | 918 |  |  | 942 |  |
| INVESTING ACTIVITIES |  |  |  |
| Acquisition of property, equipment and leasehold improvements | (254) |  |  | (316) |  |
| Proceeds from sale of assets | 40 |  |  | 534 |  |
| Purchases of investments | — |  |  | (1) |  |
| Proceeds from sale of investments | 14 |  |  | — |  |
| Proceeds from business divestiture | 326 |  |  | — |  |
| Net cash provided by (used in) investing activities | 126 |  |  | 217 |  |
| FINANCING ACTIVITIES |  |  |  |
| Redemption and repurchase of debt | (1,288) |  |  | (1,578) |  |
| Proceeds from issuance of long-term debt | 1,500 |  |  | 1,600 |  |
| Dividends to shareholders | (585) |  |  | (582) |  |
| Repurchases of ordinary shares | — |  |  | (408) |  |
| Taxes paid related to net share settlement of equity awards | (38) |  |  | (44) |  |
| Proceeds from issuance of ordinary shares under employee stock plans | 66 |  |  | 68 |  |
| Other financing activities, net | (128) |  |  | (44) |  |
| Net cash used in financing activities | (473) |  |  | (988) |  |
| Effect of foreign currency exchange rate changes on cash, cash equivalents and restricted cash | 1 |  |  | — |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | 572 |  |  | 171 |  |
| Cash, cash equivalents and restricted cash at the beginning of the year | 788 |  |  | 617 |  |
| Cash, cash equivalents and restricted cash at the end of the year | $ | 1,360 |  |  | $ | 788 |  |

[0001137789-24-000061:8k_2_02:59]
Use of non-GAAP financial information

[0001137789-24-000061:8k_2_02:60]
The Company uses non-GAAP measures of gross profit, gross margin, operating expenses, income from operations, operating margin, net income, diluted EPS, free cash flow, EBITDA, adjusted EBITDA and last twelve months adjusted EBITDA, which are adjusted from results based on GAAP to exclude certain benefits, expenses, gains and losses. These non-GAAP financial measures are used by management to evaluate the business and provided to enhance the user’s overall understanding of the Company’s current financial performance and its prospects for the future. Specifically, the Company believes non-GAAP results provide useful information to investors as these non-GAAP results exclude certain benefits, expenses, gains and losses that the Company believes are not part of the Company's ongoing operations and not indicative of its core operating results.

[0001137789-24-000061:8k_2_02:61]
These non-GAAP financial measures are some of the measurements management uses to assess the Company’s performance, allocate resources and plan for future periods. Reported non-GAAP results should only be considered as supplemental to results prepared in accordance with GAAP, and not considered as a substitute or replacement for, or superior to, GAAP results. These non-GAAP measures may differ from the non-GAAP measures reported by other companies in its industry.

[0001137789-24-000061:8k_2_02:62]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-24-000061:8k_2_02:63]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001137789-24-000061:8k_2_02:64]
(In millions, except per share amounts, gross margin and operating margin)

[0001137789-24-000061:8k_2_02:65]
(Unaudited)

[0001137789-24-000061:8k_2_02:66]
|  | For the Three Months Ended | For the Twelve Months Ended |
|  | June 28,2024 |  | June 30,2023 |  | June 28,2024 |  | June 30,2023 |
| GAAP Gross Profit | $ | 600 |  |  | $ | 304 |  |  | $ | 1,536 |  |  | $ | 1,351 |  |
| Accelerated depreciation, impairment and other charges related to cost saving efforts | — |  |  | 3 |  |  | 13 |  |  | 60 |  |
| Amortization of acquired intangible assets | — |  |  | — |  |  | — |  |  | 3 |  |
| Pandemic-related lockdown charges | — |  |  | — |  |  | — |  |  | 7 |  |
| Purchase order cancellation fees | (26) |  |  | — |  |  | 87 |  |  | 108 |  |
| Share-based compensation | 9 |  |  | 5 |  |  | 32 |  |  | 29 |  |
| Other charges | — |  |  | 1 |  |  | 2 |  |  | 3 |  |
| Non-GAAP Gross Profit | $ | 583 |  |  | $ | 313 |  |  | $ | 1,670 |  |  | $ | 1,561 |  |
| GAAP Gross Margin | 31.8% |  | 19.0% |  | 23.4% |  | 18.3% |
| Non-GAAP Gross Margin | 30.9% |  | 19.5% |  | 25.5% |  | 21.1% |
| GAAP Operating Expenses | $ | 286 |  |  | $ | 278 |  |  | $ | 1,084 |  |  | $ | 1,693 |  |
| Accelerated depreciation, impairment and other charges related to cost saving efforts | — |  |  | — |  |  | — |  |  | (25) |  |
| Amortization of acquired intangible assets | — |  |  | — |  |  | — |  |  | (3) |  |
| BIS settlement penalty | — |  |  | — |  |  | — |  |  | (300) |  |
| Restructuring and other, net | 3 |  |  | 8 |  |  | 30 |  |  | (102) |  |
| Share-based compensation | (29) |  |  | (17) |  |  | (95) |  |  | (86) |  |
| Other charges | (4) |  |  | (11) |  |  | (26) |  |  | (29) |  |
| Non-GAAP Operating Expenses | $ | 256 |  |  | $ | 258 |  |  | $ | 993 |  |  | $ | 1,148 |  |
| GAAP Income (Loss) From Operations | $ | 314 |  |  | $ | 26 |  |  | $ | 452 |  |  | $ | (342) |  |
| Accelerated depreciation, impairment and other charges related to cost saving efforts | — |  |  | 3 |  |  | 13 |  |  | 85 |  |
| Amortization of acquired intangible assets | — |  |  | — |  |  | — |  |  | 6 |  |
| BIS settlement penalty | — |  |  | — |  |  | — |  |  | 300 |  |
| Pandemic-related lockdown charges | — |  |  | — |  |  | — |  |  | 7 |  |
| Purchase order cancellation fees | (26) |  |  | — |  |  | 87 |  |  | 108 |  |
| Restructuring and other, net | (3) |  |  | (8) |  |  | (30) |  |  | 102 |  |
| Share-based compensation | 38 |  |  | 22 |  |  | 127 |  |  | 115 |  |
| Other charges | 4 |  |  | 12 |  |  | 28 |  |  | 32 |  |
| Non-GAAP Income From Operations | $ | 327 |  |  | $ | 55 |  |  | $ | 677 |  |  | $ | 413 |  |
| GAAP Operating Margin | 16.6% |  | 1.6% |  | 6.9% |  | (4.6)% |
| Non-GAAP Operating Margin | 17.3% |  | 3.4% |  | 10.3% |  | 5.6% |

[0001137789-24-000061:8k_2_02:67]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-24-000061:8k_2_02:68]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001137789-24-000061:8k_2_02:69]
(In millions, except per share amounts, gross margin and operating margin)

[0001137789-24-000061:8k_2_02:70]
(Unaudited)

[0001137789-24-000061:8k_2_02:71]
|  | For the Three Months Ended |  | For the Twelve Months Ended |
|  | June 28,2024 |  | June 30,2023 |  | June 28,2024 |  | June 30,2023 |
| GAAP Net Income (Loss) | $ | 513 |  |  | $ | (92) |  |  | $ | 335 |  |  | $ | (529) |  |
| Accelerated depreciation, impairment and other charges related to cost saving efforts | — |  |  | 3 |  |  | 13 |  |  | 85 |  |
| Amortization of acquired intangible assets | — |  |  | — |  |  | — |  |  | 6 |  |
| BIS settlement penalty | — |  |  | — |  |  | — |  |  | 300 |  |
| Net gain from business divestiture | (313) |  |  | — |  |  | (313) |  |  | — |  |
| Net gain from termination of interest rate swap | — |  |  | — |  |  | (104) |  |  | — |  |
| Net loss (gain) from early redemption of debt | — |  |  | 17 |  |  | 29 |  |  | (190) |  |
| Pandemic-related lockdown charges | — |  |  | — |  |  | — |  |  | 7 |  |
| Purchase order cancellation fees | (26) |  |  | — |  |  | 87 |  |  | 108 |  |
| Restructuring and other, net | (3) |  |  | (8) |  |  | (30) |  |  | 102 |  |
| Share-based compensation | 38 |  |  | 22 |  |  | 127 |  |  | 115 |  |
| Strategic investment losses or impairment charges | 8 |  |  | 9 |  |  | 51 |  |  | 10 |  |
| Other charges | 4 |  |  | 12 |  |  | 28 |  |  | 32 |  |
| Income tax adjustments | 1 |  |  | — |  |  | 49 |  |  | (6) |  |
| Non-GAAP Net Income (Loss) | $ | 222 |  |  | $ | (37) |  |  | $ | 272 |  |  | $ | 40 |  |

[0001137789-24-000061:8k_2_02:72]
| GAAP Diluted Net Income (Loss) Per Share | $ | 2.39 |  |  | $ | (0.44) |  |  | $ | 1.58 |  |  | $ | (2.56) |  |
| Accelerated depreciation, impairment and other charges related to cost saving efforts | — |  |  | 0.01 |  |  | 0.06 |  |  | 0.41 |  |
| Amortization of acquired intangible assets | — |  |  | — |  |  | — |  |  | 0.03 |  |
| BIS settlement penalty | — |  |  | — |  |  | — |  |  | 1.45 |  |
| Net gain from business divestiture | (1.46) |  |  | — |  |  | (1.48) |  |  | — |  |
| Net gain from termination of interest rate swap | — |  |  | — |  |  | (0.49) |  |  | — |  |
| Net loss (gain) from early redemption of debt | — |  |  | 0.08 |  |  | 0.14 |  |  | (0.91) |  |
| Pandemic-related lockdown charges | — |  |  | — |  |  | — |  |  | 0.03 |  |
| Purchase order cancellation fees | (0.12) |  |  | — |  |  | 0.41 |  |  | 0.52 |  |
| Restructuring and other, net | (0.01) |  |  | (0.04) |  |  | (0.14) |  |  | 0.49 |  |
| Share-based compensation | 0.18 |  |  | 0.11 |  |  | 0.6 |  |  | 0.56 |  |
| Strategic investment losses or impairment charges | 0.04 |  |  | 0.04 |  |  | 0.24 |  |  | 0.05 |  |
| Other charges | 0.02 |  |  | 0.06 |  |  | 0.13 |  |  | 0.15 |  |
| Income tax adjustments | — |  |  | — |  |  | 0.23 |  |  | (0.03) |  |
| Non-GAAP diluted share count adjustments1,2 | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |
| Non-GAAP Diluted Net Income (Loss) Per Share1,2 | $ | 1.05 |  |  | $ | (0.18) |  |  | $ | 1.29 |  |  | $ | 0.19 |  |
| Shares Used In Diluted Net Income (Loss) Per Share Calculation |  |  |  |  |  |  |
| GAAP | 215 |  |  | 207 |  |  | 212 |  |  | 207 |  |
| Non-GAAP diluted share count adjustments1,2 | (3) |  |  | — |  |  | (1) |  |  | 2 |  |
| Non-GAAP | 212 |  |  | 207 |  |  | 211 |  |  | 209 |  |

[0001137789-24-000061:8k_2_02:73]
SEAGATE TECHNOLOGY HOLDINGS PLC

[0001137789-24-000061:8k_2_02:74]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001137789-24-000061:8k_2_02:75]
(In millions)

[0001137789-24-000061:8k_2_02:76]
(Unaudited)

[0001137789-24-000061:8k_2_02:77]
|  |  |  | For the Three Months Ended |  | For the Twelve Months Ended |
|  |  |  | June 28,2024 |  | June 30, 2023 |  | June 28,2024 |  | June 30,2023 |
| GAAP Net Cash Provided by Operating Activities |  | $ | 434 |  |  | $ | 218 |  |  | $ | 918 |  |  | $ | 942 |  |
| Acquisition of property, equipment and leasehold improvements |  | 54 |  |  | 50 |  |  | 254 |  |  | 316 |  |
| Free Cash Flow |  | $ | 380 |  |  | $ | 168 |  |  | $ | 664 |  |  | $ | 626 |  |

[0001137789-24-000061:8k_2_02:78]
|  | For the Three Months Ended |  |  |
|  | June 28,2024 |  | March 29,2024 |  | December 29,2023 |  | September 29,2023 |  | Last Twelve Months |
| GAAP Net Income (Loss) | $ | 513 |  |  | $ | 25 |  |  | $ | (19) |  |  | $ | (184) |  |  | $ | 335 |  |
| Depreciation and amortization | 63 |  |  | 63 |  |  | 62 |  |  | 76 |  |  | 264 |  |
| Interest expense | 82 |  |  | 82 |  |  | 84 |  |  | 84 |  |  | 332 |  |
| Interest income | (7) |  |  | (3) |  |  | (3) |  |  | (2) |  |  | (15) |  |
| Income tax expense (benefit) | 25 |  |  | 33 |  |  | 15 |  |  | 37 |  |  | 110 |  |
| Non-GAAP EBITDA | 676 |  |  | 200 |  |  | 139 |  |  | 11 |  |  | 1,026 |  |
| Net gain from business divestiture | (313) |  |  | — |  |  | — |  |  | — |  |  | (313) |  |
| Net gain from termination of interest rate swap | — |  |  | — |  |  | — |  |  | (104) |  |  | (104) |  |
| Net loss from early redemption of debt | — |  |  | — |  |  | — |  |  | 29 |  |  | 29 |  |
| Purchase order cancellation fees | (26) |  |  | (1) |  |  | (4) |  |  | 118 |  |  | 87 |  |
| Restructuring and other, net | (3) |  |  | 2 |  |  | (31) |  |  | 2 |  |  | (30) |  |
| Share-based compensation | 38 |  |  | 34 |  |  | 30 |  |  | 25 |  |  | 127 |  |
| Strategic investment losses or impairment charges | 8 |  |  | — |  |  | 43 |  |  | — |  |  | 51 |  |
| Underutilization charges, net of depreciation and amortization | 20 |  |  | 38 |  |  | 31 |  |  | 51 |  |  | 140 |  |
| Other charges | 4 |  |  | 5 |  |  | 8 |  |  | 11 |  |  | 28 |  |
| Non-GAAP Adjusted EBITDA | $ | 404 |  |  | $ | 278 |  |  | $ | 216 |  |  | $ | 143 |  |  | $ | 1,041 |  |

[0001137789-24-000061:8k_2_02:79]
_____________________________________

[0001137789-24-000061:8k_2_02:80]
1 For the three months ended June 30, 2023, GAAP and non-GAAP diluted net loss per share were computed using weighted average basic shares of 207 million, as a result of the net loss reported during the period. For the twelve months ended June 30, 2023, GAAP diluted net loss per share was computed using weighted average basic shares of 207 million, as a result of the net loss reported during the period. Non-GAAP diluted net income per share was computed using weighted average diluted shares of 209 million, as a result of non-GAAP net income reported during the period.

[0001137789-24-000061:8k_2_02:81]
2 For the three months and twelve months ended June 28, 2024, non-GAAP shares used in diluted net income per share calculation excluded approximately 3 million and 1 million shares, respectively, that are issuable upon conversion of our 2028 exchangeable senior notes using the if-converted method. This is because these dilutive effects are expected to be offset partially or in full by the capped call transactions entered by the Company in conjunction with the issuance of our 2028 exchangeable senior notes in order to reduce the potential dilution to the Company's ordinary shares upon the conversion.

[0001137789-24-000061:8k_2_02:82]
The Company’s Non-GAAP measures are adjusted for the following items:

[0001137789-24-000061:8k_2_02:83]
Accelerated depreciation, impairment and other charges related to cost saving efforts

[0001137789-24-000061:8k_2_02:84]
These expenses are excluded in the non-GAAP measures due to the inconsistency in amount and frequency, and they are not normal operating expenses or indicative of the Company's operating performance. Exclusion of these amounts provides a supplemental view of the Company's operating performance to investors to enable them to evaluate the Company's current operating performance compared to the past periods' operating performance.

[0001137789-24-000061:8k_2_02:85]
Amortization of acquired intangible assets

[0001137789-24-000061:8k_2_02:86]
The Company records expense from amortization of intangible assets that were acquired in connection with its business combinations over their estimated useful lives. Such charges are inconsistent in size and are significantly impacted by the timing and magnitude of the Company’s acquisitions. The Company excludes these expenses because they are not normal operating expenses or indicative of its operating performance. Exclusion of these amounts provides a supplemental view of the Company's operating performance to investors to enable them to evaluate the Company's current operating performance compared to the past periods’ operating performance.

[0001137789-24-000061:8k_2_02:87]
BIS settlement penalty

[0001137789-24-000061:8k_2_02:88]
The Company accrued a settlement penalty of $300 million in the fiscal third quarter of 2023 related to the alleged violations of the U.S. Export Administration Regulations between August 17, 2020 and September 29, 2021 by the U.S. Department of Commerce’s Bureau of Industry and Security (“BIS”), which were subsequently resolved by a settlement agreement on April 18, 2023. This settlement penalty is excluded because it is not normal operating expense or indicative of the Company's operating performance. Exclusion of this expense provides a supplemental view to investors to evaluate the Company's current operating performance compared to the past periods' operating performance.

[0001137789-24-000061:8k_2_02:89]
Net gain from business divestiture

[0001137789-24-000061:8k_2_02:90]
The Company recorded a pre-tax net gain of $313 million in connection to the sale of System-on-Chip Operations in April 2024. The net gain is excluded in the non-GAAP measures because it is not indicative of the Company's operating performance. The Company excludes this amount to provide a supplemental view to investors to evaluate the Company's current operating performance compared to the past periods' operating performance.

[0001137789-24-000061:8k_2_02:91]
Net loss (gain) from early redemption of debt and termination of interest rate swap

[0001137789-24-000061:8k_2_02:92]
From time to time, the Company incurs gains, losses and fees from the early redemption and repurchase of certain long-term debt instruments and termination of related interest rate swap agreements. The amount of these charges may be inconsistent in size and varies depending on the timing of the early redemption of debt and/or termination of interest rate swap. The Company does not believe these are part of its normal operating performance. Exclusion of these amounts provides a supplemental view of the Company's operating performance to investors to enable them to evaluate the Company's current operating performance compared to the past periods' operating performance.

[0001137789-24-000061:8k_2_02:93]
Pandemic-related lockdown charges

[0001137789-24-000061:8k_2_02:94]
Pandemic-related lockdown charges are factory under-utilization costs incurred due to the pandemic-related lockdown measures at our factory in Wuxi, China. These charges were incurred as a result of specific lockdown measures that were unusual and infrequent and therefore, not part of the Company's normal operations. Exclusion of these amounts provides a supplemental view of the Company's operating performance to investors to enable them to evaluate the Company's current operating performance compared to the past periods’ operating performance.

[0001137789-24-000061:8k_2_02:95]
Purchase order cancellation fees

[0001137789-24-000061:8k_2_02:96]
Purchase order cancellation fees are the costs incurred to cancel certain purchase commitments made with the Company's suppliers for component and equipment purchases that will not be received due to change in forecasted demand. These charges are inconsistent in amount and frequency. The Company does not believe these are part of its normal operating expenses. Exclusion of these amounts provides a supplemental view to investors to evaluate the Company's current operating performance compared to the past periods’ operating performance.

[0001137789-24-000061:8k_2_02:97]
Restructuring and other, net

[0001137789-24-000061:8k_2_02:98]
Restructuring and other, net are costs associated with restructuring plans that are primarily related to costs associated with reduction in the Company’s workforce, exiting certain facilities and other related costs, as well as charges or gains from sale of properties. These costs or benefits do not reflect the Company’s normal or ongoing operating performance and consequently the Company excludes these expenses to provide a supplemental view to investors to evaluate the Company's current operating performance compared to the past periods’ operating performance.

[0001137789-24-000061:8k_2_02:99]
Share-based compensation

[0001137789-24-000061:8k_2_02:100]
These expenses consist primarily of expenses for employee share-based compensation. Given the variety of equity awards used by companies, the varying methodologies for determining share-based compensation expense, the subjective assumptions involved in those determinations, and the volatility in valuations that can be driven by market conditions outside the Company’s control, the Company believes excluding share-based compensation expense enhances the ability of management and investors to understand and assess the underlying performance of its business over time and compare it against the Company’s peers, a majority of whom also exclude share-based compensation expense from their non-GAAP results.

[0001137789-24-000061:8k_2_02:101]
Strategic investment gains, losses and impairment charges

[0001137789-24-000061:8k_2_02:102]
From time to time, the Company incurs gains, losses or impairment charges from strategic investments that are measured and accounted at fair value, under the equity method of accounting, as available-for-sale debt securities or adjust for downward or upward adjustments to the carrying value under the measurement alternative if an impairment or observable price adjustment is recognized in the current period that are not considered normal operating expenses or gains. The resulting expense, gain or impairment loss is inconsistent in amount and frequency and the Company excludes these amounts to provide a supplemental view to investors to evaluate the Company's current operating performance compared to the past periods’ operating performance.

[0001137789-24-000061:8k_2_02:103]
Other charges

[0001137789-24-000061:8k_2_02:104]
The other charges primarily include IT transformation costs. These charges are inconsistent in amount and frequency and are excluded to provide a supplemental view to investors to evaluate the Company's current operating performance compared to past periods’ operating performance.

[0001137789-24-000061:8k_2_02:105]
Income tax adjustments

[0001137789-24-000061:8k_2_02:106]
Provision or benefit for income taxes represents the tax effects of non-GAAP adjustments determined using a hybrid with and without method and effective tax rate for the applicable adjustment and jurisdiction.

[0001137789-24-000061:8k_2_02:107]
Free cash flow

[0001137789-24-000061:8k_2_02:108]
Free cash flow is a non-GAAP measure defined as net cash provided by operating activities less acquisition of property, equipment and leasehold improvements. Free cash flow does not reflect non-cash items, net cash used or provided by financing activities and net cash used or provided by investing activities, other than acquisition of property, equipment and leasehold improvements. This non-GAAP financial measure is used by management to assess the Company's sources of liquidity, capital structure and operating performance.

[0001137789-24-000061:8k_2_02:109]
EBITDA, adjusted EBITDA and last twelve months (LTM) adjusted EBITDA

[0001137789-24-000061:8k_2_02:110]
EBITDA is defined as net income (loss) before income tax expense, interest expense, interest income, depreciation and amortization. Adjusted EBITDA excludes certain expenses, gains and losses that the Company believes are not indicative of its core operating results. These adjustments primarily include impairment and other charges related to cost saving efforts, net loss (gain) from early redemption of debt, net gain from termination of interest rate swap, net gain from business divestiture, pandemic-related lockdown charges, purchase order cancellation fees, restructuring and other, net, share-based compensation, strategic investment losses or impairment charges, other extraordinary charges such as factory underutilization charges and BIS settlement penalty. LTM adjusted EBITDA is defined as the total of last twelve months adjusted EBITDA. These non-GAAP financial measures are used by management to evaluate the Company’s debt portfolio and structure to comply with its financial debt covenants.
