# STX notes — 0001137789-24-000068


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001137789-24-000068:notes:1]
Portions of the definitive proxy statement to be filed with the Securities and Exchange Commission pursuant to Regulation 14A relating to the registrant’s Annual General Meeting of Shareholders, to be held on October 19, 2024, will be incorporated by reference in this Form 10-K in response to Items 10, 11, 12, 13 and 14 of Part III. The definitive proxy statement will be filed with the SEC no later than 120 days after the registrant's fiscal year ended June 28, 2024.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001137789-24-000068:notes:2]
Basis of Presentation and Summary of Significant Accounting Policies
Organization

[0001137789-24-000068:notes:3]
Seagate Technology Holdings plc (“STX”) and its subsidiaries (collectively, unless the context otherwise indicates, the “Company”) is a leading provider of data storage technology and infrastructure solutions. Its principal products are hard disk drives, commonly referred to as disk drives, hard drives or HDDs. In addition to HDDs, the Company produces a broad range of data storage products including solid state drives (“SSDs”) and storage subsystems and offers storage solutions such as a scalable edge-to-cloud mass data platform that includes data transfer shuttles and a storage-as-a-service cloud.

[0001137789-24-000068:notes:4]
In January 2024, the Company established Singapore as its principal executive offices to better align its operational footprint.

[0001137789-24-000068:notes:5]
Basis of Presentation and Consolidation

[0001137789-24-000068:notes:6]
The Company’s Consolidated Financial Statements include the accounts of the Company and all its wholly-owned and majority-owned subsidiaries, after elimination of intercompany transactions and balances.

[0001137789-24-000068:notes:7]
The preparation of financial statements in accordance with the United States (“U.S.”) generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the Company’s Consolidated Financial Statements and accompanying notes. Actual results could differ materially from those estimates. The methods, estimates and judgments the Company uses in applying its most critical accounting policies have a significant impact on the results the Company reports in its Consolidated Financial Statements.

[0001137789-24-000068:notes:8]
Fiscal Year

[0001137789-24-000068:notes:9]
The Company operates and reports financial results on a fiscal year of 52 or 53 weeks ending on the Friday closest to June 30. Fiscal years 2024, 2023 and 2022 are comprised of 52 weeks and ended on June 28, 2024, June 30, 2023 and July 1, 2022, respectively. All references to years in these Notes to Consolidated Financial Statements represent fiscal years unless otherwise noted. Fiscal year 2026 will be comprised of 53 weeks and will end on July 3, 2026.

[0001137789-24-000068:notes:10]
Summary of Significant Accounting Policies

[0001137789-24-000068:notes:11]
Cash and Cash Equivalents. The Company considers all highly liquid investments with a remaining maturity of 90 days or less at the time of purchase to be cash equivalents. The Company’s highly liquid investments are primarily comprised of money market funds, time deposits and certificates of deposits.

[0001137789-24-000068:notes:12]
Restricted Cash and Cash Equivalents. Restricted cash and cash equivalents represent cash and cash equivalents held as collateral at banks for various performance obligations.

[0001137789-24-000068:notes:13]
Allowance for expected credit loss. The Company maintains an allowance for expected credit loss relating to its accounts receivable based upon expected collectability. This reserve is established based upon historical trends, global macroeconomic conditions, reasonable and supportable forecasts of future conditions and an analysis of specific exposures. The provision for expected credit loss is recorded as a charge to Marketing and administrative expense in the Company’s Consolidated Statements of Operations.

[0001137789-24-000068:notes:14]
Inventories. Inventories are valued at the lower of cost (using the first-in, first-out method) and net realizable value. Net realizable value is based upon the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. Adjustments to reduce cost of inventories to its net realizable value are made, if required, for estimated excess or obsolescence determined primarily by future demand forecasts.

[0001137789-24-000068:notes:15]
Property, Equipment and Leasehold Improvements. Property, equipment and leasehold improvements are stated at cost less accumulated depreciation and amortization. Equipment and buildings are depreciated using the straight-line method over the estimated useful lives of the assets. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated life of the asset or the remaining term of the lease. The costs of additions and substantial improvements to property, equipment and leasehold improvements, which extend the economic life of the underlying assets, are capitalized. The cost of maintenance and repairs to property, equipment and leasehold improvements is expensed as incurred.

[0001137789-24-000068:notes:16]
In accordance with its policy, the Company reviews the estimated useful lives of its fixed assets on an ongoing basis. Effective from the first quarter of fiscal year 2024, the Company changed the useful lives of certain manufacturing equipment from a range of three to seven years to a range of  three to ten years based on a review of the technology product roadmap. The

[0001137789-24-000068:notes:17]
effect of this change in estimate increased the net income by $99 million and increased the diluted earnings per share by $0.47 for the fiscal year ended June 28, 2024.

[0001137789-24-000068:notes:18]
Goodwill. The Company performs a qualitative assessment in the fourth quarter of each year, or more frequently if indicators of potential impairment exist, to determine if any events or circumstances exist, such as an adverse change in business climate or a decline in the overall industry that would indicate that it would more likely than not reduce the fair value of a reporting unit below its carrying amount, including goodwill. If it is determined in the qualitative assessment that the fair value of a reporting unit is more likely than not below its carrying amount, including goodwill, then the Company will perform a quantitative impairment test. The quantitative goodwill impairment test is performed by comparing the fair value of a reporting unit with its carrying amount. Any excess in the carrying value of a reporting unit over its fair value is recognized as an impairment loss, limited to the total amount of goodwill allocated to that reporting unit.

[0001137789-24-000068:notes:19]
Other Long-lived Assets. The Company tests other long-lived assets, including property, equipment and leasehold improvements and other intangible assets subject to amortization, for recoverability whenever events or changes in circumstances indicate that the carrying value of those assets may not be recoverable. The Company performs a recoverability test to assess the recoverability of an asset group. If the recoverability test indicates that the carrying value of the asset group is not recoverable, the Company will estimate the fair value of the asset group and the excess of the carrying value over the fair value is allocated pro rata to derive the adjusted carrying value of assets in the asset group.

[0001137789-24-000068:notes:20]
Assets Held for Sale. The Company classifies its long-lived assets to be sold as held for sale in the period (i) it has approved and committed to a plan to sell the asset, (ii) the asset is available for immediate sale in its present condition, (iii) an active program to locate a buyer and other actions required to sell the asset have been initiated, (iv) the sale of the asset is probable, (v) the asset is being actively marketed for sale at a price that is reasonable in relation to its current fair value and (vi) it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn. The Company initially measures a long-lived asset that is classified as held for sale at the lower of its carrying value or fair value less any costs to sell. Any loss resulting from this measurement is recognized in the period in which the held for sale criteria are met. Conversely, gains are not recognized on the sale of a long-lived asset until the date of sale. Upon designation as an asset held for sale, the Company stops recording depreciation expense on the asset. The Company assesses the fair value of a long-lived asset less any costs to sell at each reporting period and until the asset is no longer classified as held for sale.

[0001137789-24-000068:notes:21]
Leases. The Company determines if an arrangement is a lease or contains a lease at inception. Right-of-use (“ROU”) assets are included in Other assets, net and lease liabilities are included in Accrued expenses and Other non-current liabilities in the Company’s Consolidated Balance Sheets. ROU assets represent the Company’s right to use an underlying asset for the lease term and the corresponding lease liabilities represent its obligation to make lease payments arising from the lease. The Company combines lease and non-lease components for facility leases and does not recognize ROU assets and lease liabilities for leases with an initial term of 12 months or less on the Consolidated Balance Sheets.

[0001137789-24-000068:notes:22]
Lease liabilities are measured at the present value of the remaining lease payments and ROU assets are based on the lease liability, adjusted for lease prepayments, lease incentives received and the lessee’s initial direct costs. For the Company’s leases that do not provide an implicit rate, the net present value of future minimum lease payments is determined using the Company’s estimated incremental borrowing rate based on the information available at the lease commencement date. Additionally, the Company’s lease term may include options to extend or terminate the lease. These options are reflected in the ROU asset and lease liability when it is reasonably certain that the Company will exercise the option. The Company’s lease agreements do not contain any material residual value guarantees.

[0001137789-24-000068:notes:23]
The Company recognizes lease expense on a straight-line basis over the lease term. Variable lease payments not dependent on an index or a rate primarily consist of common area maintenance charges, are expensed as incurred, and are not included in the ROU asset and lease liability calculation.

[0001137789-24-000068:notes:24]
Derivative Financial Instruments. The Company records all derivatives on the balance sheet at fair value and establishes criteria for designation and effectiveness of hedging relationships. Foreign currency forward exchange contracts are used to economically hedge the foreign currency exposure on forecasted expenditures in currencies other than U.S. dollar. The Company also enters into foreign currency forward contracts with contractual maturities of less than one month, which are designed to mitigate the effect of changes in foreign exchange rates on monetary assets and liabilities.

[0001137789-24-000068:notes:25]
The Company determines the fair value of these instruments by considering the estimated amount it would pay or receive to terminate these agreements at the reporting date. The changes in the fair value of highly effective designated cash flow hedges are recorded in Accumulated Other Comprehensive Income (“AOCI”) until the hedged item is recognized in earnings. The Company excludes the change in forward points from the assessment of hedge effectiveness and recognizes the excluded component in Other, net in the Consolidated Statements of Operations. The Company de-designates its cash flow hedges when the forecasted hedged transactions affect earnings or it is probable the forecasted hedged transactions will not occur in the initially identified time period. At such time, the associated gains and losses deferred in AOCI on the Company’s Consolidated Balance Sheets are reclassified into earnings and any subsequent changes in the fair value of such derivative instruments are

[0001137789-24-000068:notes:26]
immediately reflected in earnings. The Company recognizes the unrealized gains and losses due to the changes in the fair value of derivatives that are not designated as hedging instruments or are not assessed to be highly effective in Other, net in the Consolidated Statements of Operations. The Company recognizes gains and losses from foreign currency forward exchange contracts within Other non-cash operating activities in the Consolidated Statements of Cash Flows.

[0001137789-24-000068:notes:27]
Warranty. The Company estimates probable product warranty costs at the time revenue is recognized. The Company generally provides warranty on its products for a period of 1 to 5 years. The Company's warranty provision considers estimated product failure rates, trends (including the timing of product returns during the warranty periods), and estimated repair or replacement costs related to product quality issues, if any. The Company also exercises judgment in estimating its ability to sell refurbished products.

[0001137789-24-000068:notes:28]
Revenue Recognition and Sales Incentive Programs. The Company determines revenue recognition through the following steps: (1) identification of the contract with a customer; (2) identification of the performance obligations in the contract; (3) determination of the transaction price; (4) allocation of the transaction price to the performance obligations in the contract; and (5) recognition of revenue when, or as, the Company satisfies a performance obligation.

[0001137789-24-000068:notes:29]
Revenue from sales of products is generally recognized upon transfer of control to customers in an amount that reflects the consideration the Company expects to receive in exchange for those products, net of sales taxes. This typically occurs upon shipment from the Company. When applicable, the Company includes shipping charges billed to customers in Revenue and includes the related shipping costs in Cost of revenue on the Company's Consolidated Statements of Operations.

[0001137789-24-000068:notes:30]
The Company records estimated variable consideration at the time of revenue recognition as a reduction to revenue. Variable consideration generally consists of sales incentive programs, such as price protection and volume incentives aimed at increasing customer demand. For original equipment manufacturers (“OEMs”) sales, rebates are typically established by estimating the most likely amount of consideration expected to be received based on an OEM customer’s volume of purchases from the Company or other agreed upon rebate programs. For the distribution and retail channel, these programs typically involve estimating the most likely amount of rebates related to a customer’s level of sales, order size, advertising or point of sale activity as well as the expected value of price protection adjustments based on historical analysis and forecasted pricing environment. Marketing development program costs are accrued and recorded as a reduction to revenue at the same time that the related revenue is recognized.

[0001137789-24-000068:notes:31]
At the end of the reporting period, the Company has unfulfilled product purchase orders which represent performance obligations not delivered, or partially undelivered under existing customer contracts. Some of these purchase orders are non-cancellable in nature. As of June 28, 2024, all non-cancellable purchase orders are less than one year in duration and are expected to be fulfilled in the next twelve months. The Company applied optional exemption to not disclose the value of these remaining performance obligations as they are part of a contract that has an original expected duration of one year or less.

[0001137789-24-000068:notes:32]
The Company expenses sales commissions as incurred because the amortization period would have been one year or less. These costs are recorded as Marketing and administrative in the Company’s Consolidated Statements of Operations.

[0001137789-24-000068:notes:33]
Restructuring Costs. The Company incurs restructuring costs in connection with workforce reductions, consolidation or closure of facilities and other exit costs. The Company records employee termination liabilities when it is probable that benefits will be paid and the amount is reasonably estimable. The rates used in determining severance accruals are based on existing plans, historical experiences and negotiated settlements. Other costs associated with a restructuring plan or exit or disposal activities are recognized in the period in which the liability is incurred or the asset is impaired.

[0001137789-24-000068:notes:34]
Advertising Expense. The cost of advertising is expensed as incurred. Advertising costs were approximately $18 million, $30 million and $34 million in fiscal years 2024, 2023 and 2022, respectively.

[0001137789-24-000068:notes:35]
Share-Based Compensation. The Company accounts for share-based compensation at fair value, net of estimated forfeitures. When estimating forfeitures, the Company considers voluntary termination behavior as well as the historical analysis of actual forfeited awards. The Company estimates the fair value of granted share options, restricted share units (“RSUs”), and performance-based share units (“PSUs”) subject to a performance goal related to the Company’s adjusted earnings per share using the Black-Scholes-Merton valuation model and a single share award approach. The Company estimates the fair value of PSUs related to the Company’s return on invested capital and total shareholder return using a Monte Carlo simulation valuation model. Share-based compensation expense for share options and RSUs with only a service condition is recognized on a straight-line basis over the requisite service period. The expense for PSUs with both a service condition and a performance or market condition is recognized on a graded vesting basis.

[0001137789-24-000068:notes:36]
Accounting for Income Taxes. The Company records a provision or benefit for income taxes for the anticipated tax consequences of the reported results of operations using the asset and liability method. Under this method, the Company recognizes deferred income tax assets and liabilities for the expected future consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, as well as for loss and tax credit carryforwards. Deferred tax assets and liabilities are measured using the tax rates that are expected to apply to taxable income for the years in which those tax assets and liabilities are expected to be realized or settled. The Company recognizes the deferred income tax effects of a change in tax rates in the period of the enactment. The Company periodically reassesses the need for valuation allowances on the deferred tax assets, considering both positive and negative evidence to evaluate whether it is more likely than not that all or a portion of such assets will not be realized.

[0001137789-24-000068:notes:37]
The Company recognizes a tax benefit only if it is more likely than not the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon settlement.

[0001137789-24-000068:notes:38]
Equity Investments. From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives, which are accounted for either under equity method or the measurement alternative. These investments are included in Other assets, net in the Company's Consolidated Balance Sheets and are subsequently adjusted through Other, net in the Consolidated Statements of Operations.

[0001137789-24-000068:notes:39]
Investments are accounted for under the equity method if the Company has the ability to exercise significant influence, but does not have a controlling financial interest. These investments are measured at cost, less any impairment plus the Company's portion of investee’s income or loss. The Company uses the financial statements of investees to determine any adjustments, which are received on a one-quarter lag.

[0001137789-24-000068:notes:40]
For equity investments where the Company does not have the ability to exercise significant influence and there are no readily determinable fair values, the Company has elected to apply the measurement alternative, under which investments are measured at cost, less impairment, and adjusted for qualifying observable price changes on a prospective basis.

[0001137789-24-000068:notes:41]
The Company’s strategic investments are periodically analyzed to determine whether or not there are indicators of impairment by assessing factors such as deterioration of earnings, adverse change in market/industry conditions, the ability to operate as a going concern, and other factors which indicate that the carrying amount of the investment might not be recoverable. In such a case, the decrease in value is recognized in the period the impairment occurs in the Consolidated Statements of Operations.

[0001137789-24-000068:notes:42]
Foreign Currency Remeasurement and Translation. The U.S. dollar is the functional currency for the majority of the Company's foreign operations. Monetary assets and liabilities denominated in foreign currencies are remeasured into the functional currency at the balance sheet date at exchange rates in effect at the end of each period. The gains and losses from the remeasurement are included in Other, net in the Company's Consolidated Statements of Operations.

[0001137789-24-000068:notes:43]
The Company translates the assets and liabilities of its non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recognized in foreign currency translation included in Accumulated other comprehensive income, which is a component of Shareholders’ Deficit.

[0001137789-24-000068:notes:44]
Government Incentives. The Company enters into government incentive arrangements with domestic and foreign, local, regional and national governments, which vary in size, duration and conditions. In fiscal year 2024, approximately $3 million of operating grants were recognized as reductions to Cost of revenue and Product development in the Consolidated Statements of Operations. As of June 28, 2024, the advanced cash grants were $17 million, which were reflected within Accrued expenses in the Company's Consolidated Balance Sheets. In fiscal year 2023, approximately $13 million of operating grants were recognized as reductions to Cost of revenue and Product development in the Consolidated Statements of Operations. The Company also received advanced cash grants of $13 million, which were reflected within Accrued expenses in the Company's Consolidated Balance Sheets as of June 30, 2023.

[0001137789-24-000068:notes:45]
Use of Estimates

[0001137789-24-000068:notes:46]
The preparation of financial statements requires management to make estimates, judgments and assumptions that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Estimates are assessed each period and updated to reflect current information, including those related to revenue recognition, share-based compensation, restructuring accruals, provision for taxes, valuation allowance for deferred taxes, provision for expected credit losses, inventory reserves, warranty accruals, and impairment assessments of goodwill, intangible assets and other long-lived assets. The Company believes that these estimates, judgments and assumptions are reasonable under the circumstances, and are subject to significant uncertainties, some of which are beyond the Company's control. Should any of these estimates change, it could adversely affect

[0001137789-24-000068:notes:47]
the Company's results of operations. Actual results could differ materially from these estimates under different assumptions or conditions.

[0001137789-24-000068:notes:48]
Concentrations

[0001137789-24-000068:notes:49]
Concentration of Credit Risk. The Company’s customer base is concentrated with a small number of customers. The Company does not generally require collateral or other security to support accounts receivable. To reduce credit risk, the Company performs ongoing credit evaluations on its customers’ financial condition. The Company establishes allowances for expected credit losses based upon factors surrounding the credit risk of customers, global macroeconomic conditions and an analysis of specific exposures. One customer and two customers accounted for more than 10% of the Company’s accounts receivable as of June 28, 2024 and June 30, 2023, respectively.

[0001137789-24-000068:notes:50]
Financial instruments that potentially subject the Company to concentrations of credit risk consist primarily of cash and cash equivalents and foreign currency forward exchange contracts. The Company maintains the cash and cash equivalents with four major financial institutions and a portion of such balances exceed or are not subject to Federal Deposit Insurance Corporation, or FDIC, insurance limits. The Company mitigates concentrations of credit risk in its financial instruments through diversification, by investing in highly-rated securities and/or major multinational companies.

[0001137789-24-000068:notes:51]
In entering into foreign currency forward exchange contracts, the Company assumes the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial and investment banks, and the Company has not incurred and does not expect any losses as a result of counterparty defaults.

[0001137789-24-000068:notes:52]
Supplier Concentration. Certain of the raw materials, components and equipment used by the Company in the manufacture of its products are available from single-sourced direct and indirect vendors. Shortages could occur in these essential materials and components due to an interruption of supply or increased demand in the industry. If the Company were unable to procure certain materials, components or equipment at all or acceptable prices, it would be required to reduce its manufacturing operations, which could have a material adverse effect on its results of operations.

[0001137789-24-000068:notes:53]
Recently Adopted Accounting Pronouncements

[0001137789-24-000068:notes:54]
In September 2022, the Financial Accounting Standards Board (FASB) issued ASU 2022-04 (ASC Subtopic 405-50), Disclosure of Supplier Finance Program Obligations. This ASU requires disclosure of key terms of the outstanding supplier finance programs and a roll forward of the related obligations. The Company adopted this guidance during the first quarter of fiscal year 2024, except for the disclosure on rollforward information which will be adopted in fiscal year 2025, in line with the effective adoption date prescribed by the FASB. The adoption of this ASU did not have a material impact on the Company’s Consolidated Financial Statements.

[0001137789-24-000068:notes:55]
Recently Issued Accounting Pronouncements

[0001137789-24-000068:notes:56]
In November 2023, the FASB issued ASU 2023-07 (ASC Topic 280), Improvements to Reportable Segment Disclosures. This ASU improves reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The Company is required to adopt this guidance for its annual reporting in fiscal year 2025 and for interim period reporting beginning the first quarter of fiscal year 2026 on a retrospective basis. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have impact on its Consolidated Financial Statements.
In December 2023, the FASB issued ASU 2023-09 (ASC Topic 740), Improvements to Income Tax Disclosures. This ASU requires disaggregated income tax disclosures on the rate reconciliation and income taxes paid. The Company is required to adopt this guidance for its annual reporting in fiscal year 2026 on a prospective basis but have the option to apply it retrospectively. Early adoption is permitted. This standard is expected to impact the Company’s disclosures and will not have impact on its Consolidated Financial Statements.


## us-gaap:DerivativesPolicyTextBlock

[0001137789-24-000068:notes:57]
The Company is exposed to foreign currency exchange rate, interest rate and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies.

[0001137789-24-000068:notes:58]
The Company entered into certain interest rate swap agreements to convert the variable interest rate on its Term Loans to fixed interest rates. The objective of the interest rate swap agreements was to eliminate the variability of interest payment cash flows associated with the variable interest rate under the Term Loans. The Company designated the interest rate swaps as cash flow hedges. On September 13, 2023, the Company terminated its then existing interest rate swap agreements as a result of the repayment of Term Loans A1, A2 and A3 and received cash proceeds of $25 million from the counterparty. The cash proceeds are reported within Net cash provided by operating activities in the Company’s Consolidated Statements of Cash Flows during the fiscal year ended 2024. The Company discontinued the related hedge accounting prospectively and realized a net gain of $104 million in Net gain from termination of interest rate swap in the Consolidated Statements of Operations during the fiscal year ended 2024. Additionally, $6 million of the gains were amortized to Interest expense prior to the termination of interest rate swap in the Company’s Consolidated Statements of Operations. Refer to “Note 4. Debt” for more details.

[0001137789-24-000068:notes:59]
As of June 28, 2024, the Company does not have any interest rate swap contracts.

[0001137789-24-000068:notes:60]
The net unrealized loss on cash flow hedges was immaterial as of June 28, 2024. The net unrealized gain on cash flow hedges was $12 million as of June 30, 2023.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001137789-24-000068:notes:61]
Balance Sheet Information
Cash, Cash Equivalents and Restricted Cash

[0001137789-24-000068:notes:62]
The following table provides a summary of cash, cash equivalents and restricted cash reported within the Company’s Consolidated Balance Sheets that reconciles to the corresponding amount in the Company’s Consolidated Statements of Cash Flows:

[0001137789-24-000068:notes:63]
| (Dollars in millions) |  |  | June 28,2024 |  | June 30,2023 |  | July 1,2022 |  |  |
| Cash and cash equivalents |  |  | $ | 1,358 |  |  | $ | 786 |  |  | $ | 615 |  |  |  |
| Restricted cash included in Other current assets |  |  | 2 |  |  | 2 |  |  | 2 |  |  |  |
| Total cash, cash equivalents and restricted cash shown in the Statements of Cash Flows |  |  | $ | 1,360 |  |  | $ | 788 |  |  | $ | 617 |  |  |  |

[0001137789-24-000068:notes:64]
Accounts Receivable, net

[0001137789-24-000068:notes:65]
The details of the accounts receivable, net were as follows:

[0001137789-24-000068:notes:66]
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |
| Accounts receivable |  | $ | 433 |  |  | $ | 625 |  |
| Allowances for expected credit losses |  | (4) |  |  | (4) |  |
| Account receivable, net |  | $ | 429 |  |  | $ | 621 |  |

[0001137789-24-000068:notes:67]
Activity in the expected credit losses accounts was as follows:

[0001137789-24-000068:notes:68]
| (Dollars in millions) |  | Balance at Beginning of Period |  | Charges (Credit) to Operations |  |  |  | Balance at End of Period |
| Fiscal year ended July 1, 2022 |  | $ | 4 |  |  | — |  |  |  |  | $ | 4 |  |
| Fiscal year ended June 30, 2023 |  | $ | 4 |  |  | — |  |  |  |  | $ | 4 |  |
| Fiscal year ended June 28, 2024 |  | $ | 4 |  |  | — |  |  |  |  | $ | 4 |  |

[0001137789-24-000068:notes:69]
In connection with the Company’s factoring agreements, from time to time the Company sells accounts receivables to third parties for cash proceeds less a discount. During fiscal year 2024, the Company sold trade receivables without recourse for cash proceeds of $1.2 billion, of which $294 million remained subject to servicing by the Company as of June 28, 2024. During fiscal year 2023, the Company sold trade receivables without recourse for cash proceeds of $876 million, of which $275 million remained subject to servicing by the Company as of June 30, 2023. The discounts on trade receivables sold were $11 million for fiscal year 2024, $11 million for fiscal year 2023 and immaterial for fiscal year 2022, respectively.

[0001137789-24-000068:notes:70]
Inventories, net

[0001137789-24-000068:notes:71]
The details of the inventory, net were as follows:

[0001137789-24-000068:notes:72]
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |
| Raw materials and components |  | $ | 270 |  |  | $ | 241 |  |
| Work-in-process |  | 831 |  |  | 682 |  |
| Finished goods |  | 138 |  |  | 217 |  |
| Total inventories, net |  | $ | 1,239 |  |  | $ | 1,140 |  |

[0001137789-24-000068:notes:73]
Other Current Assets

[0001137789-24-000068:notes:74]
The details of the other current assets were as follows:

[0001137789-24-000068:notes:75]
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |
| Vendor receivables |  | $ | 110 |  |  | $ | 167 |  |
| Other current assets |  | 196 |  |  | 191 |  |
| Total |  | $ | 306 |  |  | $ | 358 |  |

[0001137789-24-000068:notes:76]
Property, Equipment and Leasehold Improvements, net

[0001137789-24-000068:notes:77]
The components of property, equipment and leasehold improvements, net were as follows:

[0001137789-24-000068:notes:78]
| (Dollars in millions) |  | Useful Life in Years |  | June 28,2024 |  | June 30,2023 |
| Land and land improvements |  |  |  | $ | 18 |  |  | $ | 21 |  |
| Equipment |  | 3 – 10 |  | 8,632 |  |  | 8,504 |  |
| Buildings and leasehold improvements |  | Up to 30 |  | 1,412 |  |  | 1,435 |  |
| Construction in progress |  |  |  | 198 |  |  | 307 |  |
| Gross property, equipment and leasehold improvements |  |  |  | 10,260 |  |  | 10,267 |  |
| Less: accumulated depreciation and amortization |  |  |  | (8,646) |  |  | (8,561) |  |
| Property, equipment and leasehold improvements, net |  |  |  | $ | 1,614 |  |  | $ | 1,706 |  |

[0001137789-24-000068:notes:79]
Depreciation expense, which includes amortization of leasehold improvements, was $264 million, $504 million and $431 million for fiscal years 2024, 2023 and 2022, respectively. In fiscal year 2024, the Company recognized a charge of $13 million for the accelerated depreciation of certain fixed assets which was recorded to Cost of revenue in the Consolidated Statements of Operations. In fiscal year 2023, the Company recognized a charge of $85 million for the accelerated depreciation of certain fixed assets, of which $60 million and $25 million was recorded to Cost of revenue and Product development, respectively, in the Consolidated Statements of Operations. In fiscal year 2022, the accelerated depreciation charge recognized was immaterial. Interest on borrowings related to eligible capital expenditures is capitalized as part of the cost of the qualified assets and amortized over the estimated useful lives of the assets. During fiscal years 2024, 2023 and 2022, the Company capitalized interest of $9 million, $8 million and $3 million, respectively.

[0001137789-24-000068:notes:80]
Accrued Expenses

[0001137789-24-000068:notes:81]
The details of the accrued expenses were as follows:

[0001137789-24-000068:notes:82]
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |
| Dividends payable |  | $ | 147 |  |  | $ | 145 |  |
| Other accrued expenses |  | 507 |  |  | 603 |  |
| Total |  | $ | 654 |  |  | $ | 748 |  |

[0001137789-24-000068:notes:83]
Accumulated Other Comprehensive (Loss) Income (“AOCI”)

[0001137789-24-000068:notes:84]
The components of AOCI, net of tax, were as follows:

[0001137789-24-000068:notes:85]
| (Dollars in millions) |  | Unrealized Gains/(Losses) on Cash Flow Hedges |  |  | Unrealized Gains/(Losses) on Post-Retirement Plans |  | Foreign Currency Translation Adjustments |  | Total |
| Balance at July 1, 2022 |  | $ | 51 |  |  |  | $ | (14) |  |  | $ | (1) |  |  | $ | 36 |  |
| Other comprehensive income before reclassifications |  | 65 |  |  |  | 11 |  |  | — |  |  | 76 |  |
| Amounts reclassified from AOCI |  | (13) |  |  |  | (1) |  |  | — |  |  | (14) |  |
| Other comprehensive income |  | 52 |  |  |  | 10 |  |  | — |  |  | 62 |  |
| Balance at June 30, 2023 |  | 103 |  |  |  | (4) |  |  | (1) |  |  | 98 |  |
| Other comprehensive (loss) income before reclassifications |  | (13) |  |  |  | 1 |  |  | 1 |  |  | (11) |  |
| Amounts reclassified from AOCI |  | (90) |  |  |  | 1 |  |  | — |  |  | (89) |  |
| Other comprehensive (loss) income |  | (103) |  |  |  | 2 |  |  | 1 |  |  | (100) |  |
| Balance at June 28, 2024 |  | $ | — |  |  |  | $ | (2) |  |  | $ | — |  |  | $ | (2) |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001137789-24-000068:notes:86]
Goodwill and Other Intangible Assets
Goodwill

[0001137789-24-000068:notes:87]
The carrying amount of goodwill was $1.2 billion as of June 28, 2024 and June 30, 2023. Goodwill divested as a result of the sale of SoC business during fiscal year 2024 was $18 million. Refer to Note 18. Divestiture for more information. There were no other additions to, disposals of, impairments of or translation adjustments to goodwill in fiscal years 2024, 2023 and 2022.

[0001137789-24-000068:notes:88]
Other Intangible Assets

[0001137789-24-000068:notes:89]
Other intangible assets consist primarily of existing technology, customer relationships and trade names acquired in business combinations. Intangibles are amortized on a straight-line basis over the respective estimated useful lives of the assets. Amortization is charged to Operating expenses in the Consolidated Statements of Operations.

[0001137789-24-000068:notes:90]
In fiscal year 2024, there was no amortization expense for other intangible assets. For fiscal years 2023 and 2022, amortization expense for other intangible assets was $9 million and $20 million, respectively.

[0001137789-24-000068:notes:91]
There was no net carrying value of other intangible assets subject to amortization as of June 28, 2024 and June 30, 2023.


## us-gaap:DebtDisclosureTextBlock

[0001137789-24-000068:notes:92]
Debt
The following table provides details of the Company’s debt as of June 28, 2024 and June 30, 2023:

[0001137789-24-000068:notes:93]
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |
| Unsecured Senior Notes(1) |  |  |  |  |
| $1,000 issued on May 28, 2014 at 4.75% due January 1, 2025 (the “2025 Notes”), interest payable semi-annually on January 1 and July 1 of each year. |  | 479 |  |  | 479 |  |
| $700 issued on May 14, 2015 at 4.875% due June 1, 2027 (the “2027 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 505 |  |  | 504 |  |
| $500 issued on June 18, 2020 at 4.091% due June 1, 2029 (the “June 2029 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 471 |  |  | 465 |  |
| $500 issued on December 8, 2020 at 3.125% due July 15, 2029 (the “July 2029 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 163 |  |  | 163 |  |
| $500 issued on May 30, 2023 at 8.25% due December 15, 2029 (the “December 2029 Notes”), interest payable semi-annually on June 15 and December 15 of each year. |  | 500 |  |  | 500 |  |
| $500 issued on June 10, 2020 at 4.125% due January 15, 2031 (the “January 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 275 |  |  | 275 |  |
| $500 issued on December 8, 2020 at 3.375% due July 15, 2031 (the “July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 72 |  |  | 72 |  |
| $500 issued on May 30, 2023 at 8.50% due July 15, 2031 (the “8.50% July 2031 Notes”), interest payable semi-annually on January 15 and July 15 of each year. |  | 500 |  |  | 500 |  |
| $750 issued on November 30, 2022 at 9.625% due December 1, 2032 (the “2032 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 750 |  |  | 750 |  |
| $500 issued on December 2, 2014 at 5.75% due December 1, 2034 (the “2034 Notes”), interest payable semi-annually on June 1 and December 1 of each year. |  | 489 |  |  | 489 |  |
| Exchangeable Senior Notes(1) |  |  |  |  |
| $1,500 issued on September 13, 2023 at 3.50% due June 1, 2028 (the “2028 Notes”), interest payable semi-annually on March 1 and September 1 of each year. |  | 1,500 |  |  | — |  |
| Term Loans |  |  |  |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.125% to 2.375%, (the “Term Loan A1”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of September 16, 2025. |  | — |  |  | 430 |  |
| $600 borrowed on October 14, 2021 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A2”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
| $600 borrowed on August 18, 2022 at SOFR plus a variable margin ranging from 1.25% to 2.5%, (the “Term Loan A3”), repayable in quarterly installments beginning on December 31, 2022, with a final maturity date of July 30, 2027. |  | — |  |  | 430 |  |
|  |  | 5,704 |  |  | 5,487 |  |
| Less: unamortized debt issuance costs |  | (30) |  |  | (36) |  |
| Debt, net of debt issuance costs |  | 5,674 |  |  | 5,451 |  |
| Less: current portion of long-term debt |  | (479) |  |  | (63) |  |
| Long-term debt, less current portion |  | $ | 5,195 |  |  | $ | 5,388 |  |

[0001137789-24-000068:notes:94]
___________________________________

[0001137789-24-000068:notes:95]
(1) All unsecured senior notes and exchangeable senior notes are issued by Seagate HDD Cayman (“Seagate HDD”), and the obligations under these notes are fully and unconditionally guaranteed, on a senior unsecured basis, by Seagate Technology Unlimited Company (“STUC”) and STX.

[0001137789-24-000068:notes:96]
2028 Exchangeable Senior Notes and related Capped Call Transactions

[0001137789-24-000068:notes:97]
2028 Notes. On September 13, 2023, Seagate HDD, in a private placement, issued $1.5 billion in aggregate principal amount of 3.50% Exchangeable Senior Notes due 2028 (the “2028 Notes”), which includes $200 million aggregate principal amount pursuant to the over-allotment option of the initial purchasers to purchase additional notes. The 2028 Notes will mature on June 1, 2028, with interest payable semi-annually on March 1 and September 1 of each year, commencing March 1, 2024.

[0001137789-24-000068:notes:98]
For the fiscal year ended June 28, 2024, the effective interest rate for the 2028 Notes was 3.94%, with contractual interest expense of $25 million and immaterial amortization of debt issuance costs.

[0001137789-24-000068:notes:99]
The entire outstanding principal amount of Term Loans A1, A2 and A3 were repaid from the proceeds of the 2028 Notes issuance. The exchange was accounted for as a debt extinguishment and the Company recorded a net loss of $29 million, which was included in the Net (loss) gain recognized from early redemption of debt in the Company’s Consolidated Statements of Operations. In connection with the repayment of Term Loans, the Company terminated certain interest rate swap agreements. Refer to “Note 8. Derivative Financial Instruments” for more details.

[0001137789-24-000068:notes:100]
Prior to March 1, 2028, the 2028 Notes are exchangeable at the option of the holders only under the following circumstances:

[0001137789-24-000068:notes:101]
•during any calendar quarter commencing after the calendar quarter ending on December 31, 2023 (and only during such calendar quarter), if the last reported sale price of the ordinary Shares for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter is greater than or equal to 130% of the exchange price in effect on each applicable trading day;

[0001137789-24-000068:notes:102]
•during the five business day period after any ten consecutive trading day period in which the trading price per $1,000 principal amount of 2028 Notes for each trading day period was less than 98% of the product of the last reported sale price of the ordinary shares and the applicable exchange rate on such trading day; or

[0001137789-24-000068:notes:103]
•upon the occurrence of specified corporate events described in the indenture with respect to the 2028 Notes.

[0001137789-24-000068:notes:104]
On or after March 1, 2028, the 2028 Notes are exchangeable at any time at the option of the holders until the close of business on the second scheduled trading day immediately preceding the maturity date, unless the 2028 Notes have been previously redeemed or repurchased by Seagate HDD.

[0001137789-24-000068:notes:105]
Upon exchange of the 2028 Notes, Seagate HDD will pay cash up to the aggregate principal amount of 2028 Notes to be exchanged and will pay or cause to be delivered, as the case may be, cash, ordinary shares of the Company or a combination of cash and ordinary shares of the Company, at Seagate HDD’s election, in respect of any remainder of the exchange obligation in excess of such principal amount. The initial exchange rate for the 2028 Notes is 12.1253 ordinary shares per $1,000 principal amount of 2028 Notes.

[0001137789-24-000068:notes:106]
Seagate HDD may redeem the 2028 Notes at its option, in whole but not in part, if Seagate HDD or the Guarantors have, or on the next interest payment date would, become obligated to pay to the holder of any Note additional amounts as a result of certain tax-related events at a redemption price equal to 100% of the principal amount plus accrued and unpaid interest, including additional interest, if any, to, but excluding, the redemption date; provided that Seagate HDD may only redeem the 2028 Notes if: (x) Seagate HDD or the relevant Guarantor cannot avoid these obligations by taking commercially reasonable measures available to Seagate HDD or such Guarantor; and (y) Seagate HDD delivers to the Trustee an opinion of outside legal counsel of recognized standing in the relevant taxing jurisdiction attesting to such tax-related event and obligation to pay additional amounts.

[0001137789-24-000068:notes:107]
Seagate HDD also may redeem the 2028 Notes at its option on or after September 8, 2026, in whole or in part, if the last reported sale price of ordinary shares of the Company has been at least 130% of the exchange price then in effect for at least 20 trading days (whether or not consecutive), including the trading day immediately preceding the date on which Seagate HDD provides notice of redemption, during any 30 consecutive trading day period ending on, and including, the trading day immediately preceding the date on which Seagate HDD provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If Seagate HDD redeems less than all the outstanding 2028 Notes, at least $150 million aggregate principal amount of 2028 Notes must be outstanding and not subject to redemption as of the relevant notice of redemption date.

[0001137789-24-000068:notes:108]
As of June 28, 2024, the 2028 Notes were not exchangeable. Refer to “Note 13. Net Income (Loss) Per Share” for the potential dilutive impact of the 2028 Notes.

[0001137789-24-000068:notes:109]
In connection with the 2028 Notes, the Company and Seagate HDD entered into privately negotiated capped call transactions with certain financial institutions. The cap price of the capped call transactions will initially be $107.848 per share. The cost of the capped call transactions was $95 million, which met certain accounting criteria to be accounted under Additional Paid-in Capital as part of the Shareholders’ Deficit and are not accounted as derivatives in the Company’s Consolidated Balance Sheets.

[0001137789-24-000068:notes:110]
Credit Agreement

[0001137789-24-000068:notes:111]
The credit agreement dated as of February 20, 2019, by and among, Seagate Technology Holdings plc, Seagate HDD, The Bank of Nova Scotia, as administrative agent, and the lenders party thereto (as amended from time to time, the “Credit Agreement”) includes two financial covenants: (1) interest coverage ratio and (2) total net leverage ratio. For the fiscal quarter ended June 28, 2024 until the end of the covenant relief period, which terminates on June 27, 2025, the maximum permitted total net leverage ratio is 6.75 to 1.00, and applies only to the extent that the aggregate outstanding amount of revolving loans, swing line loans and the aggregate face amount of certain letters of credit exceeds 25% of the then outstanding revolving commitments in effect (the “Testing Condition”) as of the last day of the fiscal quarter. The maximum permitted total leverage ratio for each fiscal quarter ending after June 27, 2025 is 4.00 to 1.00.

[0001137789-24-000068:notes:112]
For the fiscal quarter ended June 28, 2024 until the fiscal quarter ending June 27, 2025, the minimum interest coverage ratio is 2.25 to 1.00, and applies only to the extent that the Testing Condition is satisfied as of the last day of the fiscal quarter. The minimum interest coverage ratio is 3.25 to 1.00 for each fiscal quarter ending after June 27, 2025.

[0001137789-24-000068:notes:113]
Future Principal Payments on Long-term Debt

[0001137789-24-000068:notes:114]
At June 28, 2024, future principal payments on long-term debt were as follows (in millions):

[0001137789-24-000068:notes:115]
| Fiscal Year |  | Amount |
| 2025 |  | $ | 479 |  |
| 2026 |  | — |  |
| 2027 |  | 505 |  |
| 2028 |  | 1,500 |  |
| 2029 |  | 495 |  |
| Thereafter |  | 2,750 |  |
| Total |  | $ | 5,729 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001137789-24-000068:notes:116]
Income Taxes
Income (loss) before income taxes consisted of the following:

[0001137789-24-000068:notes:117]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |  | July 1,2022 |
| U.S. |  | $ | 249 |  |  | $ | 300 |  |  | $ | 145 |  |
| Non-U.S. |  | 196 |  |  | (796) |  |  | 1,534 |  |
|  |  | $ | 445 |  |  | $ | (496) |  |  | $ | 1,679 |  |

[0001137789-24-000068:notes:118]
The provision for income taxes consisted of the following:

[0001137789-24-000068:notes:119]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |  | July 1,2022 |
| Current income tax expense: |  |  |  |  |  |  |
| U.S. |  | $ | 2 |  |  | $ | 6 |  |  | $ | 4 |  |
| Non-U.S. |  | 30 |  |  | 17 |  |  | 35 |  |
| Total Current |  | 32 |  |  | 23 |  |  | 39 |  |
| Deferred income tax expense/(benefit): |  |  |  |  |  |  |
| U.S. |  | 71 |  |  | 9 |  |  | 3 |  |
| Non-U.S. |  | 7 |  |  | 1 |  |  | (12) |  |
| Total Deferred |  | 78 |  |  | 10 |  |  | (9) |  |
| Provision for income taxes |  | $ | 110 |  |  | $ | 33 |  |  | $ | 30 |  |

[0001137789-24-000068:notes:120]
The significant components of the Company’s deferred tax assets and liabilities were as follows:

[0001137789-24-000068:notes:121]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |
| Deferred tax assets |  |  |  |  |
| Accrued warranty |  | $ | 37 |  |  | $ | 38 |  |
| Inventory carrying value adjustments |  | 32 |  |  | 40 |  |
| Receivable allowances |  | 9 |  |  | 11 |  |
| Accrued compensation and benefits |  | 36 |  |  | 43 |  |
| Capitalized research expenses |  | — |  |  | 119 |  |
| Depreciation |  | 19 |  |  | 40 |  |
| Restructuring accruals |  | 2 |  |  | 14 |  |
| Lease liabilities |  | 64 |  |  | 62 |  |
| Other accruals and deferred items |  | 11 |  |  | 14 |  |
| Net operating losses |  | 613 |  |  | 542 |  |
| Tax credit carryforwards |  | 593 |  |  | 619 |  |
| Capital loss carryforwards |  | 67 |  |  | — |  |
| Other assets |  | 40 |  |  | 1 |  |
| Gross: Deferred tax assets |  | 1,523 |  |  | 1,543 |  |
| Less: Valuation allowance |  | (430) |  |  | (370) |  |
| Net: Deferred tax assets |  | 1,093 |  |  | 1,173 |  |
| Deferred tax liabilities |  |  |  |  |
| Unremitted earnings of certain non-U.S. entities |  | (4) |  |  | (4) |  |
| Acquisition-related items |  | (1) |  |  | (1) |  |
| Right-of-use assets |  | (63) |  |  | (62) |  |
| Other liabilities |  | — |  |  | (2) |  |
| Net: Deferred tax liabilities |  | (68) |  |  | (69) |  |
| Total net deferred tax assets |  | $ | 1,025 |  |  | $ | 1,104 |  |

[0001137789-24-000068:notes:122]
At June 28, 2024, the Company recorded $1.0 billion of net deferred tax assets. The realization of most of these deferred tax assets is primarily dependent on the Company’s ability to generate sufficient U.S. and certain non-U.S. taxable income in future periods. Although realization is not assured, the Company’s management believes it is more likely than not that these deferred tax assets will be realized. The amount of deferred tax assets considered realizable, however, may increase or decrease in subsequent periods when the Company re-evaluates the underlying basis for its estimates of future U.S. and certain non-U.S. taxable income.

[0001137789-24-000068:notes:123]
The deferred tax asset valuation allowance increased by $60 million in fiscal year 2024, which primarily relates to the generation of capital loss carryforwards which are not likely to be realized.

[0001137789-24-000068:notes:124]
At June 28, 2024, the Company had U.S. tax net operating loss and credit carryforwards of approximately $3.7 billion and $709 million, respectively, of which approximately $4 million and $22 million, respectively, are scheduled to expire at various dates in fiscal year 2025, if not utilized. At June 28, 2024, the Company had non-U.S. tax net operating loss carryforwards of approximately $411 million, all of which are indefinite lived. As of June 28, 2024, the Company had gross capital loss carryforwards of $294 million, which if not utilized, will expire as of fiscal year 2029.

[0001137789-24-000068:notes:125]
As of June 28, 2024, approximately $17 million and $18 million of the Company’s total U.S. net operating loss and tax credit carryforwards, respectively, are subject to annual limitations due to the ownership change limitations provided by the Internal Revenue Code.

[0001137789-24-000068:notes:126]
We established Singapore as our principal executive offices in fiscal year 2024. The Singaporean statutory tax rate of 17% is used for purposes of the reconciliation between the provision for income taxes at the statutory rate and our effective tax rate. For fiscal years 2023 and 2022, a notional Irish statutory rate of 25% was used.

[0001137789-24-000068:notes:127]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |  | July 1,2022 |
| Provision (benefit) at statutory rate |  | $ | 76 |  |  | $ | (124) |  |  | $ | 420 |  |
| Permanent differences |  | 5 |  |  | 8 |  |  | 5 |  |
| Valuation allowance |  | 47 |  |  | (18) |  |  | 7 |  |
| Effect of rates different than statutory |  | (2) |  |  | 178 |  |  | (371) |  |
| Research credit |  | (9) |  |  | (18) |  |  | (26) |  |
| Capital loss carryforward |  | (11) |  |  | — |  |  | — |  |
| Other individually immaterial items |  | 4 |  |  | 7 |  |  | (5) |  |
| Provision for income taxes |  | $ | 110 |  |  | $ | 33 |  |  | $ | 30 |  |

[0001137789-24-000068:notes:128]
A substantial portion of the Company's operations in Singapore and Thailand operate under various tax incentive programs, which expire in whole or in part at various dates through fiscal year 2036. Certain tax incentives may be extended if specific conditions are met. The net impact of these tax incentive programs was to increase the Company’s net income by approximately $40 million in fiscal year 2024 ($0.19 per share, diluted), to decrease the Company's net loss by approximately $14 million in fiscal year 2023 ($0.07 per share, basic) and to increase the Company’s net income by approximately $290 million in fiscal year 2022 ($1.29 per share, diluted).

[0001137789-24-000068:notes:129]
The Company analyzes the potential needs for deferred tax liabilities with respect to the accumulated earnings of foreign subsidiaries annually. The analysis focuses on the outside basis differences in the stock of the foreign subsidiaries as well as the withholding tax obligations those subsidiaries may have with respect to any distribution. The undistributed earnings for which taxes are not provided are permanently reinvested or can be repatriated without incremental tax liability.

[0001137789-24-000068:notes:130]
As of June 28, 2024 and June 30, 2023, the Company had approximately $112 million and $116 million, respectively, of unrecognized tax benefits excluding interest and penalties. These amounts, if recognized, would impact the effective tax rate subject to certain future valuation allowance offsets.

[0001137789-24-000068:notes:131]
The following table summarizes the activities related to the Company’s gross unrecognized tax benefits:

[0001137789-24-000068:notes:132]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |  | July 1,2022 |
| Balance of unrecognized tax benefits at the beginning of the year |  | $ | 116 |  |  | $ | 114 |  |  | $ | 108 |  |
| Gross increase for tax positions of prior years |  | 3 |  |  | — |  |  | 1 |  |
| Gross decrease for tax positions of prior years |  | (12) |  |  | (4) |  |  | (1) |  |
| Gross increase for tax positions of current year |  | 5 |  |  | 7 |  |  | 6 |  |
| Gross decrease for tax positions of current year |  | — |  |  | (1) |  |  | — |  |
| Balance of unrecognized tax benefits at the end of the year |  | $ | 112 |  |  | $ | 116 |  |  | $ | 114 |  |

[0001137789-24-000068:notes:133]
It is the Company’s policy to include interest and penalties related to unrecognized tax benefits in the provision for income taxes in the Consolidated Statements of Operations. Interest and penalties recorded on these tax positions were not material to any periods presented in the Consolidated Statements of Operations. As of June 28, 2024, accrued interest and penalties related to unrecognized tax benefits did not materially change compared to fiscal year 2023.

[0001137789-24-000068:notes:134]
During the 12 months beginning June 29, 2024, the Company does not expect a material change to its unrecognized tax benefits as a result of the expiration of certain statutes of limitation.
The Company is required to file U.S. and non-U.S. income tax returns. The Company is no longer subject to examination of its U.S. income tax returns for years prior to fiscal year 2020 and prior to fiscal year 2013 for non-U.S. income tax returns.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001137789-24-000068:notes:135]
Leases
The Company is a lessee in several operating leases related to real estate facilities for warehouse, office and lab space.

[0001137789-24-000068:notes:136]
The Company’s lease arrangements comprise operating leases with various expiration dates through 2068. The lease term includes the non-cancelable period of the lease, adjusted for options to extend or terminate the lease when it is reasonably certain that an option will be exercised.

[0001137789-24-000068:notes:137]
During fiscal years 2024 and 2023, the Company sold and leased back certain properties and recorded a net gain of $30 million and $156 million respectively, within Restructuring and other, net in the Consolidated Statements of Operations.

[0001137789-24-000068:notes:138]
Operating lease costs include short-term lease costs and are shown net of immaterial sublease income. The components of lease costs and other information related to leases were as follows:

[0001137789-24-000068:notes:139]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |  |  | July 1,2022 |
| Operating lease cost |  | $ | 72 |  |  | $ | 21 |  |  |  | $ | 16 |  |
| Variable lease cost |  | 3 |  |  | 3 |  |  | 4 |
| Total lease cost |  | $ | 75 |  |  | $ | 24 |  |  |  | $ | 20 |  |
| Operating cash outflows from operating leases |  | $ | 63 |  |  | $ | 23 |  |  |  | $ | 20 |  |

[0001137789-24-000068:notes:140]
During fiscal years 2024 and 2023, the Company obtained $47 million and $353 million ROU assets in exchange for new operating lease liabilities, respectively. In fiscal year 2022, the ROU assets obtained in exchange for new operating lease liabilities were immaterial.

[0001137789-24-000068:notes:141]
|  |  | June 28,2024 |  | June 30,2023 |  | July 1,2022 |
| Weighted-average remaining lease term |  | 8.6 years |  | 9.6 years |  | 9.3 years |
| Weighted-average discount rate |  | 8.45 | % |  | 8.49 | % |  | 6.40 | % |

[0001137789-24-000068:notes:142]
ROU assets and lease liabilities included in the Company’s Consolidated Balance Sheets were as follows:

[0001137789-24-000068:notes:143]
| (Dollars in millions) |  | Balance Sheet Location |  | June 28,2024 |  | June 30,2023 |
| ROU assets |  | Other assets, net |  | $ | 403 |  |  | $ | 396 |  |
| Current lease liabilities |  | Accrued expenses |  | 61 |  |  | 51 |
| Non-current lease liabilities |  | Other non-current liabilities |  | 338 |  |  | 333 |

[0001137789-24-000068:notes:144]
At June 28, 2024, future lease payments included in the measurement of lease liabilities were as follows (in millions):

[0001137789-24-000068:notes:145]
| Fiscal Year |  | Amount |
| 2025 |  | $ | 63 |  |
| 2026 |  | 64 |  |
| 2027 |  | 59 |  |
| 2028 |  | 60 |  |
| 2029 |  | 62 |  |
| Thereafter |  | 256 |  |
| Total lease payments |  | 564 |  |
| Less: imputed interest |  | (165) |  |
| Present value of lease liabilities |  | $ | 399 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001137789-24-000068:notes:146]
Restructuring and Other, Net
During fiscal years 2024, 2023 and 2022, the Company recorded restructuring and other, net benefit of $30 million, and charge of $102 million and $3 million, respectively, in the Company’s Consolidated Statements of Operations. The net benefit for fiscal year 2024 was primarily due to the net gain of $30 million from the sale and leaseback of certain property. The net proceeds of $34 million from this transaction were recorded as an investing inflow in the Company’s Statements of Cash Flows for the fiscal year 2024. The Company’s restructuring plans are comprised primarily of charges related to workforce reduction costs, including severance and other one-time termination benefits and facilities and other exit costs. The Company’s significant restructuring plans are described below.

[0001137789-24-000068:notes:147]
October 2022 Plan - On October 24, 2022, the Company committed to an October 2022 restructuring plan (the “October 2022 Plan”) to reduce its cost structure to better align the Company’s operational needs to current economic conditions while continuing to support the long-term business strategy. On March 29, 2023, in light of further deteriorating economic conditions, the Company committed to an expansion of the October 2022 Plan. This expanded plan included aligning its business plan to near-term market conditions, along with other cost saving measures. The October 2022 Plan was substantially completed by the end of fiscal year 2023.

[0001137789-24-000068:notes:148]
April 2023 Plan - On April 20, 2023, the Company committed to an April 2023 restructuring plan (the “April 2023 Plan”) to further reduce its cost structure in response to changes in macroeconomic and business conditions. The April 2023 Plan was intended to align the Company’s operational needs with the near-term demand environment while continuing to support the long-term business strategy. The April 2023 Plan was substantially completed by the end of fiscal year 2023.

[0001137789-24-000068:notes:149]
The following table summarizes the Company’s restructuring activities under its active restructuring plans for fiscal years 2024, 2023 and 2022:

[0001137789-24-000068:notes:150]
|  |  | April 2023 Plan |  | October 2022 Plan |  | Other Plans |  |  |
| (Dollars in millions) |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Workforce Reduction Costs |  | Facilities and Other Exit Costs |  | Total |
| Accrual Balance at July 2, 2021 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 6 |  |  | $ | 8 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | 1 |  |  | 3 |  |
| Cash payments |  | — |  |  | — |  |  | — |  |  | — |  |  | (4) |  |  | (2) |  |  | (6) |  |
| Accrual Balance at July 1, 2022 |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5 |  |  | 5 |  |
| Restructuring charges |  | 145 |  |  | 3 |  |  | 104 |  |  | 7 |  |  | 10 |  |  | — |  |  | 269 |  |
| Cash payments |  | (37) |  |  | (3) |  |  | (103) |  |  | (1) |  |  | (10) |  |  | (1) |  |  | (155) |  |
| Adjustments |  | — |  |  | — |  |  | — |  |  | (1) |  |  | 1 |  |  | — |  |  | — |  |
| Accrual Balance at June 30, 2023 |  | 108 |  |  | — |  |  | 1 |  |  | 5 |  |  | 1 |  |  | 4 |  |  | 119 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | — |  |  | 6 |  |  | 1 |  |  | 7 |  |
| Cash payments |  | (106) |  |  | — |  |  | (1) |  |  | (3) |  |  | (5) |  |  | (1) |  |  | (116) |  |
| Adjustments |  | (1) |  |  | — |  |  | — |  |  | (1) |  |  | — |  |  | (4) |  |  | (6) |  |
| Accrual Balance at June 28, 2024 |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 4 |  |
| Total costs incurred to date as of June 28, 2024 |  | $ | 144 |  |  | $ | 3 |  |  | $ | 104 |  |  | $ | 5 |  |  | $ | 70 |  |  | $ | 10 |  |  | $ | 336 |  |
| Total expected costs to be incurred as of June 28, 2024 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001137789-24-000068:notes:151]
The accrued restructuring balance of $4 million at June 28, 2024 was included in Accrued expenses in the Company’s Consolidated Balance Sheets. Of the accrued restructuring balance of $119 million at June 30, 2023, $117 million was included in Accrued expenses and $2 million was included in Other non-current liabilities in the Company’s Consolidated Balance Sheets.

[0001137789-24-000068:notes:152]
During fiscal years 2024 and 2023, the Company sold certain properties and assets and recognized a net gain of $31 million and $167 million, respectively. The net gain was included in Restructuring and other, net in the Company’s Consolidated Statements of Operations.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001137789-24-000068:notes:153]
Derivative Financial Instruments 
The Company is exposed to foreign currency exchange rate, interest rate and to a lesser extent, equity market risks relating to its ongoing business operations. From time to time, the Company enters into cash flow hedges in the form of foreign currency forward exchange contracts in order to manage the foreign currency exchange rate risk on forecasted expenses and investments denominated in foreign currencies.

[0001137789-24-000068:notes:154]
The following tables show the effect of the Company’s derivative instruments in the Consolidated Statements of Comprehensive Income (Loss) and the Consolidated Statements of Operations for the fiscal year ended June 28, 2024.

[0001137789-24-000068:notes:155]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (8) |  |
| Total return swap |  | Operating expenses |  | 10 |  |

[0001137789-24-000068:notes:156]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
| Foreign currency forward exchange contracts |  | $ | 2 |  |  |  | Cost of revenue |  | $ | (3) |  |  |  | Other, net |  | $ | 3 |  |
| Interest rate swap |  | (15) |  |  |  | Interest expense |  | (11) |  |  |  | Net gain from termination of interest rate swap(1) |  | 104 |  |

[0001137789-24-000068:notes:157]
_____________________________

[0001137789-24-000068:notes:158]
(1)The net gain recognized into earnings as a result of the discontinuance of interest rate swap during the fiscal year ended June 28, 2024.

[0001137789-24-000068:notes:159]
The following tables show the effect of the Company’s derivative instruments in the Consolidated Statements of Comprehensive Income (Loss) and the Consolidated Statements of Operations for the fiscal year ended June 30, 2023.

[0001137789-24-000068:notes:160]
| (Dollars in millions)Derivatives Not Designated as Hedging Instruments |  | Location of Gain/(Loss) Recognized in Income on Derivatives |  | Amount of Gain/(Loss) Recognized in Income on Derivatives |
| Foreign currency forward exchange contracts |  | Other, net |  | $ | (7) |  |
| Total return swap |  | Operating expenses |  | 6 |  |

[0001137789-24-000068:notes:161]
| (Dollars in millions)Derivatives Designated as Hedging Instruments |  | Amount of Gain/(Loss) Recognized in OCI on Derivatives (Effective Portion) |  |  | Location of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  | Amount of Gain/(Loss) Reclassified from Accumulated OCI into Income (Effective Portion) |  |  | Location of Gain/(Loss) Recognized in Income on Derivatives (Ineffective Portion and Amount Excluded from Effectiveness Testing) |  | Amount of Gain/(Loss) Recognized in Income (Ineffective Portion and Amount Excluded from Effectiveness Testing) |
| Foreign currency forward exchange contracts |  | $ | (6) |  |  |  | Cost of revenue |  | $ | (16) |  |  |  | Other, net |  | $ | (4) |  |
| Interest rate swap |  | 71 |  |  |  | Interest expense |  | 29 |  |  |  | Interest expense |  | — |  |

[0001137789-24-000068:notes:162]
The Company is subject to equity market risks due to changes in the fair value of the notional investments selected by its employees as part of its non-qualified deferred compensation plan: the Seagate Deferred Compensation Plan (the “SDCP”). The Company entered into a Total Return Swap (“TRS”) in order to manage the equity market risks associated with the SDCP’s liabilities. The TRS is designed to substantially offset changes in the SDCP’s liabilities due to changes in the value of the investment options made by employees. The contract, which settles monthly and effectively mitigates counterparty risk will mature in June 2025. The Company did not designate the TRS as a hedge. Rather, the Company records all changes in the fair value of the TRS to earnings to offset the market value changes of the SDCP’s liabilities.

[0001137789-24-000068:notes:163]
The gross notional and fair value of derivative instruments in the Consolidated Balance Sheets as of June 28, 2024 and June 30, 2023 were as follows:

[0001137789-24-000068:notes:164]
|  |  |  |  | As of June 28, 2024 |
|  |  |  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Outstanding Gross Notional |  | Balance SheetLocation |  | Fair Value |  | Balance SheetLocation |  | Fair Value |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | $ | 35 |  |  | Other current assets |  | $ | — |  |  | Accrued expenses |  | $ | (1) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | 165 |  |  | Other current assets |  | 1 |  |  | Accrued expenses |  | — |  |
| Total return swap |  | 112 |  |  | Other current assets |  | — |  |  | Accrued expenses |  | — |  |
| Total derivatives |  | $ | 312 |  |  |  |  | $ | 1 |  |  |  |  | $ | (1) |  |

[0001137789-24-000068:notes:165]
|  |  |  |  | As of June 30, 2023 |
|  |  |  |  | Derivative Assets |  | Derivative Liabilities |
| (Dollars in millions) |  | Outstanding Gross Notional |  | Balance SheetLocation |  | FairValue |  | Balance SheetLocation |  | FairValue |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | $ | 445 |  |  | Other current assets |  | $ | 2 |  |  | Accrued expenses |  | $ | (10) |  |
| Interest rate swap |  | 1,288 |  |  | Other current assets |  | 20 |  |  | Accrued expenses |  | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign currency forward exchange contracts |  | 197 |  |  | Other current assets |  | — |  |  | Accrued expenses |  | (1) |  |
| Total return swap |  | 108 |  |  | Other current assets |  | 1 |  |  | Accrued expenses |  | — |  |
| Total derivatives |  | $ | 2,038 |  |  |  |  | $ | 23 |  |  |  |  | $ | (11) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001137789-24-000068:notes:166]
Fair Value
Measurement of Fair Value

[0001137789-24-000068:notes:167]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required to be recorded at fair value, the Company considers the principal or most advantageous market in which it would transact and it considers assumptions that market participants would use when pricing the asset or liability.

[0001137789-24-000068:notes:168]
Fair Value Hierarchy

[0001137789-24-000068:notes:169]
A fair value hierarchy is based on whether the market participant assumptions used in determining fair value are obtained from independent sources (observable inputs) or reflect the Company's own assumptions of market participant valuation (unobservable inputs). A financial instrument's categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The three levels of inputs that may be used to measure fair value are:

[0001137789-24-000068:notes:170]
Level 1 - Quoted prices in active markets that are unadjusted and accessible at the measurement date for identical, unrestricted assets or liabilities;

[0001137789-24-000068:notes:171]
Level 2 - Quoted prices for identical assets and liabilities in markets that are inactive; quoted prices for similar assets and liabilities in active markets or financial instruments for which significant inputs are observable, either directly or indirectly; or

[0001137789-24-000068:notes:172]
Level 3 - Prices or valuations that require inputs that are both unobservable and significant to the fair value measurement.

[0001137789-24-000068:notes:173]
The Company considers an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis and views an inactive market as one in which there are few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, the Company’s or the counterparty’s non-performance risk is considered in determining the fair values of liabilities and assets, respectively.

[0001137789-24-000068:notes:174]
Items Measured at Fair Value on a Recurring Basis

[0001137789-24-000068:notes:175]
The following tables present the Company’s assets and liabilities, by financial instrument type and balance sheet line item that are measured at fair value on a recurring basis, excluding accrued interest components, as of:

[0001137789-24-000068:notes:176]
|  |  |  |  | June 28, 2024 |  | June 30, 2023 |
|  |  |  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value Measurements at Reporting Date Using |
| (Dollars in millions) |  | Balance SheetLocation |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |  | Quoted Prices in Active Markets for Identical Instruments(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | Cash and cash equivalents |  | $ | 386 |  |  | $ | — |  |  | $ | — |  |  | $ | 386 |  |  | $ | 72 |  |  | $ | — |  |  | $ | — |  |  | $ | 72 |  |
| Total cash equivalents |  | 386 |  |  | — |  |  | — |  |  | 386 |  |  | 72 |  |  | — |  |  | — |  |  | 72 |  |
| Restricted cash and investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | Other current assets |  | 1 |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Time deposits and certificates of deposit |  | Other current assets |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other debt securities |  | Other assets, net |  | — |  |  | — |  |  | 15 |  |  | 15 |  |  | — |  |  | — |  |  | 16 |  |  | 16 |  |
| Derivative assets |  | Other current assets |  | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Total assets |  |  |  | $ | 387 |  |  | $ | 2 |  |  | $ | 15 |  |  | $ | 404 |  |  | $ | 73 |  |  | $ | 24 |  |  | $ | 16 |  |  | $ | 113 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | Accrued expenses |  | $ | — |  |  | $ | (1) |  |  | $ | — |  |  | $ | (1) |  |  | $ | — |  |  | $ | (11) |  |  | $ | — |  |  | $ | (11) |  |
| Total liabilities |  |  |  | $ | — |  |  | $ | (1) |  |  | $ | — |  |  | $ | (1) |  |  | $ | — |  |  | $ | (11) |  |  | $ | — |  |  | $ | (11) |  |

[0001137789-24-000068:notes:177]
As of June 28, 2024 and June 30, 2023, the Company’s Other current assets included $2 million in restricted cash equivalents held as collateral at banks for various performance obligations.

[0001137789-24-000068:notes:178]
As of June 28, 2024 and June 30, 2023, the Company had no material available-for-sale investments that had been in a continuous unrealized loss position for a period greater than 12 months. The Company determined no impairment related to credit losses for available-for-sale investments as of June 28, 2024 and June 30, 2023.

[0001137789-24-000068:notes:179]
The fair value and amortized cost of the Company’s available-for-sale investments as of June 28, 2024, was $15 million due in 2 years. The fair value and amortized cost of the Company’s available-for-sale investments as of June 30, 2023 was $16 million with the majority due in 3 years.

[0001137789-24-000068:notes:180]
Items Measured at Fair Value on a Non-Recurring Basis

[0001137789-24-000068:notes:181]
From time to time, the Company enters into certain strategic investments for the promotion of business and strategic objectives, which are accounted for either under the equity method or the measurement alternative. Investments under the measurement alternative are recorded at cost, less impairment and adjusted for qualifying observable price changes on a

[0001137789-24-000068:notes:182]
prospective basis. If measured at fair value in the Consolidated Balance Sheets, these investments would generally be classified in Level 3 of the fair value hierarchy.

[0001137789-24-000068:notes:183]
For the investments that are accounted for under the equity method, the Company sold certain investments for $14 million and recorded an immaterial gain for fiscal year 2024. The Company recorded a net loss of $29 million for fiscal year 2024, which included $25 million related to downward adjustments to write down the carrying amount of certain investments to their fair value. The Company recorded a net loss of $4 million in fiscal year 2023, and a net gain of $8 million in fiscal year 2022. The adjusted carrying value of the investments accounted under the equity method amounted to $12 million and $55 million as of June 28, 2024 and June 30, 2023 respectively.

[0001137789-24-000068:notes:184]
For the investments that are accounted under the measurement alternative, the Company recorded a net loss of $24 million in fiscal year 2024, related to downward adjustments to write down the carrying amount of certain investments to their fair value. For fiscal years 2023 and 2022, the Company recorded a net loss of $5 million and a net gain of $4 million, respectively. As of June 28, 2024 and June 30, 2023, the carrying value of the Company’s strategic investments under the measurement alternative was $65 million and $88 million, respectively.

[0001137789-24-000068:notes:185]
Other Fair Value Disclosures

[0001137789-24-000068:notes:186]
The Company’s debt is carried at amortized cost. The estimated fair value of the Company’s debt is derived using the closing price of the same debt instruments as of the date of valuation, which takes into account the yield curve, interest rates and other observable inputs. Accordingly, these fair value measurements are categorized as Level 2. The following table presents the fair value and amortized cost of the Company’s debt in order of maturity:

[0001137789-24-000068:notes:187]
|  |  | June 28, 2024 |  | June 30, 2023 |
| (Dollars in millions) |  | CarryingAmount |  | EstimatedFair Value |  | CarryingAmount |  | EstimatedFair Value |
| 4.75% Senior Notes due January 2025 |  | 479 |  |  | 476 |  |  | 479 |  |  | 472 |  |
| 4.875% Senior Notes due June 2027 |  | 505 |  |  | 493 |  |  | 504 |  |  | 484 |  |
| 3.50% Exchangeable Senior Notes due June 2028 |  | 1,500 |  |  | 2,070 |  |  | — |  |  | — |  |
| 4.091% Senior Notes due June 2029 |  | 471 |  |  | 459 |  |  | 465 |  |  | 436 |  |
| 3.125% Senior Notes due July 2029 |  | 163 |  |  | 139 |  |  | 163 |  |  | 126 |  |
| 8.25% Senior Notes due December 2029 |  | 500 |  |  | 537 |  |  | 500 |  |  | 522 |  |
| 4.125% Senior Notes due January 2031 |  | 275 |  |  | 245 |  |  | 275 |  |  | 227 |  |
| 3.375% Senior Notes due July 2031 |  | 72 |  |  | 58 |  |  | 72 |  |  | 53 |  |
| 8.50% Senior Notes due July 2031 |  | 500 |  |  | 538 |  |  | 500 |  |  | 524 |  |
| 9.625% Senior Notes due December 2032 |  | 750 |  |  | 855 |  |  | 750 |  |  | 830 |  |
| 5.75% Senior Notes due December 2034 |  | 489 |  |  | 472 |  |  | 489 |  |  | 438 |  |
| SOFR Based Term Loan A1 due September 2025 |  | — |  |  | — |  |  | 430 |  |  | 426 |  |
| SOFR Based Term Loan A2 due July 2027 |  | — |  |  | — |  |  | 430 |  |  | 420 |  |
| SOFR Based Term Loan A3 due July 2027 |  | — |  |  | — |  |  | 430 |  |  | 413 |  |
|  |  | $ | 5,704 |  |  | $ | 6,342 |  |  | $ | 5,487 |  |  | $ | 5,371 |  |
| Less: unamortized debt issuance costs |  | (30) |  |  | — |  |  | (36) |  |  | — |  |
| Debt, net of debt issuance costs |  | $ | 5,674 |  |  | $ | 6,342 |  |  | $ | 5,451 |  |  | $ | 5,371 |  |
| Less: current portion of debt, net of debt issuance costs |  | (479) |  |  | (476) |  |  | (63) |  |  | (62) |  |
| Long-term debt, less current portion, net of debt issuance costs |  | $ | 5,195 |  |  | $ | 5,866 |  |  | $ | 5,388 |  |  | $ | 5,309 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001137789-24-000068:notes:188]
Shareholders’ Deficit
Share Capital

[0001137789-24-000068:notes:189]
The Company’s authorized share capital is $13,500 and consists of 1,250,000,000 ordinary shares, par value $0.00001, of which 210,182,269 shares were outstanding as of June 28, 2024, and 100,000,000 preferred shares, par value $0.00001, of which none were issued or outstanding as of June 28, 2024.

[0001137789-24-000068:notes:190]
Repurchases of Equity Securities

[0001137789-24-000068:notes:191]
All repurchases are effected as redemptions in accordance with the Company’s Constitution.

[0001137789-24-000068:notes:192]
As of June 28, 2024, $1.9 billion remained available for repurchase under the existing repurchase authorization limit approved by the Board of Directors. The following table sets forth information with respect to repurchases of the Company’s ordinary shares during fiscal years 2024, 2023 and 2022:

[0001137789-24-000068:notes:193]
| (In millions) |  | Number of Shares Repurchased |  | Dollar Value of Shares Repurchased |
| Cumulative repurchased through July 2, 2021 |  | 426 |  |  | $ | 14,467 |  |
| Repurchased in fiscal year 2022(1) |  | 21 |  |  | 1,857 |  |
| Cumulative repurchased through July 1, 2022 |  | 447 |  |  | 16,324 |  |
| Repurchased in fiscal year 2023(1) |  | 6 |  |  | 444 |  |
| Cumulative repurchased through June 30, 2023 |  | 453 |  |  | 16,768 |  |
| Repurchased in fiscal year 2024(1) |  | 1 |  |  | 38 |  |
| Cumulative repurchased through June 28, 2024 |  | 454 |  |  | $ | 16,806 |  |

[0001137789-24-000068:notes:194]
___________________________________________________

[0001137789-24-000068:notes:195]
(1)     For fiscal years 2024, 2023 and 2022, includes net share settlements of $38 million, $44 million and $51 million for 1 million, 1 million and 1 million shares, respectively, in connection with tax withholding related to vesting of restricted share units.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001137789-24-000068:notes:196]
Share-Based Compensation
Share-Based Compensation Plans

[0001137789-24-000068:notes:197]
Seagate Technology Holdings plc 2022 Equity Incentive Plan (the “2022 EIP”): On October 20, 2021, (the “Approval Date”), shareholders of the Company approved the 2022 EIP that replaced Seagate Technology Holdings plc 2012 Equity Inventive Plan (the “2012 EIP”). The 2022 EIP provides for the grant of various types of awards including RSUs, options, PSUs and share appreciation rights. The maximum number of shares that may be delivered to the participants under the 2022 EIP shall not exceed (i) 14.1 million ordinary shares, plus (ii) any shares subject to any outstanding share awards granted under the 2012 EIP that, on or after the Approval Date expire, are cancelled or otherwise terminate, in whole or in part, without having been exercised or redeemed in full, or are settled in cash ((i) and (ii) together being the “Share Reserve”). The maximum aggregate number of shares that may be issued pursuant to RSUs or PSUs (collectively, “Full-Value Share Awards”) shall not exceed 12.3 million ordinary shares. Any shares that are subject to the 2022 EIP will be counted against the Share Reserve as one share for every one share granted. As of June 28, 2024, there were 9.6 million ordinary shares available for issuance of Full-Value Share Awards under the 2022 EIP.

[0001137789-24-000068:notes:198]
Seagate Technology Holdings plc Employee Stock Purchase Plan (the “ESPP”). There are 60 million ordinary shares authorized to be issued under the ESPP. The ESPP consists of a series of six-month offering period with a maximum issuance of 1.5 million ordinary shares per offering period. The ESPP allows eligible employees to contribute up to 10% of their eligible compensation to purchase the Company’s common stock. The price of common stock purchased equals to 85% of the lesser of the fair market value on the first day or the last day of each offering period. During fiscal years 2024, 2023 and 2022, employees purchased approximately 1 million shares each year under this plan at weighted average prices of $54.71, $62.36 and $64.85 per share, respectively. As of June 28, 2024, approximately 5.8 million ordinary shares were available for future issuance.

[0001137789-24-000068:notes:199]
Share-Based Compensation Expense

[0001137789-24-000068:notes:200]
The Company recorded $127 million, $115 million and $145 million of share-based compensation with a resulting tax benefit of $5 million, $5 million and $15 million, respectively, during fiscal years 2024, 2023 and 2022. Management made an estimate of expected forfeitures and recognized compensation costs only for those equity awards expected to vest.

[0001137789-24-000068:notes:201]
Restricted Stock Units

[0001137789-24-000068:notes:202]
RSUs generally vest over a period of four years, with 25% vesting on the first anniversary of the vesting commencement date and the remaining 75% vesting ratably each quarter over the next 36 months, subject to continuous employment with the Company through the vesting date.

[0001137789-24-000068:notes:203]
The following is a summary of unvested restricted stock activities:

[0001137789-24-000068:notes:204]
| Unvested Restricted Stocks |  | Number of Shares(In millions) |  | Weighted-Average Grant-Date Fair Value |
| Unvested at June 30, 2023 |  | 3.7 |  |  | $ | 62.07 |  |
| Granted |  | 2.0 |  |  | $ | 59.96 |  |
| Forfeited |  | (0.5) |  |  | $ | 62.80 |  |
| Vested |  | (1.8) |  |  | $ | 59.25 |  |
| Unvested at June 28, 2024 |  | 3.4 |  |  | $ | 62.20 |  |

[0001137789-24-000068:notes:205]
At June 28, 2024, the total unrecognized share-based compensation cost related to unvested restricted stocks was approximately $152 million. This cost is being amortized on a straight-line basis over a weighted-average remaining term of 2.3 years and will be adjusted for subsequent changes in estimated forfeitures. The aggregate fair value of restricted stocks vested during fiscal years 2024, 2023 and 2022 were approximately $105 million, $105 million and $96 million, respectively.

[0001137789-24-000068:notes:206]
The fair value related to RSUs for fiscal years 2024, 2023 and 2022 were estimated using the following assumptions:

[0001137789-24-000068:notes:207]
|  | Fiscal Years |
|  | 2024 |  | 2023 |  | 2022 |
| RSUs |  |  |  |  |  |
| Expected term (in years) | 1 - 2.2 |  | 1 - 2.2 |  | 1 - 2.5 |
| Expected dividend rate | 2.4 - 4.4% |  | 3.2 - 5.5% |  | 2.4 - 3.4% |
| Weighted-average expected dividend rate | 4.0 | % |  | 3.8 | % |  | 2.8 | % |
| Weighted-average fair value | $ | 59.96 |  | $ | 62.82 |  | $ | 82.4 |

[0001137789-24-000068:notes:208]
The expected term represents the period that the Company’s share-based awards are expected to be outstanding and was determined based on historical experience of similar awards and the expected Dividend yield is determined by dividing the expected per share dividend during the coming year by the grant date share price.

[0001137789-24-000068:notes:209]
Performance-based Share Units

[0001137789-24-000068:notes:210]
The Company granted PSUs that vest on the satisfaction of continuous employment and achievement of certain financial and operational performance goals established by the Compensation Committee of the Company’s Board of Directors (the “Compensation Committee”). These awards vest after the end of the performance period of three years from the grant date. During fiscal years 2024, 2023 and 2022, the PSUs granted and outstanding were not material. Compensation expense related to these units is only recorded in a period if it is probable that the performance goals will be met, and it is to be recorded at the expected level of achievement. The expenses associated with these PSUs were not material for any of the periods presented.

[0001137789-24-000068:notes:211]
Share Options

[0001137789-24-000068:notes:212]
Options generally vest over a period of four years, with 25% vesting on the first anniversary of the vesting commencement date and the remaining 75% vesting ratably each quarter over the next 36 months, subject to continuous employment with the Company through the vesting date. The exercise price of a share option is equal to the closing price of the Company’s ordinary shares on NASDAQ on the grant date. The expenses associated with share options were not material for any of the periods presented.

[0001137789-24-000068:notes:213]
Employee Savings Plan
The Company offers various defined contribution plans for U.S. and non-U.S. employees. In the U.S., qualified employees under the Seagate 401(k) Plan (the "401(k) plan") may elect to make contributions up to 50% of their eligible earned compensation, but not more than statutory limits. Pursuant to the 401(k) plan, the Company matches 50% of employee contributions, up to 6% of compensation, subject to a maximum annual employer contribution of $6,000 per participating employee. During fiscal years 2024, 2023 and 2022, the Company made matching contributions of $65 million, $79 million and $85 million, respectively, under defined contribution plans for employees


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001137789-24-000068:notes:214]
Guarantees
Indemnifications of Officers and Directors

[0001137789-24-000068:notes:215]
The Company has entered into indemnification agreements with its directors and certain of its officers that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their status or service as directors or officers. The Company maintains director and officer insurance, which may cover certain liabilities arising from its obligation to indemnify its directors and officers in certain circumstances.

[0001137789-24-000068:notes:216]
The nature of these indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay on behalf of its officers and directors. Historically, the Company has not made any significant indemnification payments under such indemnification agreements and no amount has been accrued in the Company’s Consolidated Financial Statements with respect to these indemnification obligations.

[0001137789-24-000068:notes:217]
Indemnification Obligations

[0001137789-24-000068:notes:218]
The Company from time to time enters into agreements with customers, suppliers, partners and others in the ordinary course of business that provide indemnification for certain matters including, but not limited to, intellectual property infringement claims, environmental claims and breach of agreement claims. The nature of the Company’s indemnification obligations prevents the Company from making a reasonable estimate of the maximum potential amount it could be required to pay. Historically, the Company has not made any significant indemnification payments under such agreements and no amount has been accrued in the Company’s Consolidated Financial Statements with respect to these indemnification obligations.

[0001137789-24-000068:notes:219]
Product Warranty

[0001137789-24-000068:notes:220]
As of June 28, 2024, the Company’s reserve for product warranty was $149 million compared to $168 million as of June 30, 2023. Changes in the Company’s product warranty liability during the fiscal years ended June 28, 2024, June 30, 2023 and July 1, 2022 were as follows:

[0001137789-24-000068:notes:221]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |  | July 1,2022 |
| Balance, beginning of period |  | $ | 168 |  |  | $ | 148 |  |  | $ | 136 |  |
| Warranties issued |  | 53 |  |  | 55 |  |  | 79 |  |
| Repairs and replacements |  | (81) |  |  | (92) |  |  | (88) |  |
| Changes in liability for pre-existing warranties, including expirations |  | 9 |  |  | 57 |  |  | 21 |  |
| Balance, end of period |  | $ | 149 |  |  | $ | 168 |  |  | $ | 148 |  |


## us-gaap:EarningsPerShareTextBlock

[0001137789-24-000068:notes:222]
(Loss) Per Share
Basic earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period. Diluted earnings per share is computed by dividing income available to shareholders by the weighted-average number of shares outstanding during the period and the number of additional shares that would have been outstanding if the potentially dilutive securities had been issued. Potentially dilutive securities include outstanding options, unvested restricted share units and performance-based share units and shares to be purchased under the Employee Stock Purchase Plan using the treasury stock method, as well as shares issuable in connection with the Company’s exchangeable senior notes using the “if-converted” method.

[0001137789-24-000068:notes:223]
Under the treasury stock method, the dilutive effect of potentially dilutive securities is reflected in diluted net earnings per share and an increase in fair market value of the Company’s share price can result in a greater dilutive effect from potentially dilutive securities. Under the “if-converted” method, diluted earnings per share is calculated assuming that the excess value above the principal of the exchangeable notes were converted solely into shares of common stock at the beginning of the reporting period, unless the result would be anti-dilutive, which could adversely affect our diluted earnings per share.

[0001137789-24-000068:notes:224]
The following table sets forth the computation of basic and diluted net (loss) income per share attributable to the shareholders of the Company:

[0001137789-24-000068:notes:225]
|  |  | Fiscal Years Ended |
| (In millions, except per share data) |  | June 28,2024 |  | June 30,2023 |  | July 1,2022 |
| Numerator: |  |  |  |  |  |  |
| Net income (loss) |  | $ | 335 |  |  | $ | (529) |  |  | $ | 1,649 |  |
| Number of shares used in per share calculations: |  |  |  |  |  |  |
| Total shares for purposes of calculating basic net income (loss) per share |  | 209 |  |  | 207 |  |  | 220 |  |
| Weighted-average effect of dilutive securities: |  |  |  |  |  |  |
| Employee equity award plans |  | 2 |  |  | — |  |  | 4 |  |
| 2028 Notes if-converted shares |  | 1 |  |  | — |  |  | — |  |
| Total shares for purposes of calculating diluted net income (loss) per share |  | 212 |  |  | 207 |  |  | 224 |  |
| Net income (loss) per share |  |  |  |  |  |  |
| Basic |  | $ | 1.60 |  |  | $ | (2.56) |  |  | $ | 7.50 |  |
| Diluted |  | 1.58 |  |  | (2.56) |  |  | 7.36 |  |

[0001137789-24-000068:notes:226]
All potentially dilutive securities that could have an anti-dilutive effect on the calculation of the earnings per share have been excluded for the periods presented. The weighted average anti-dilutive shares that were excluded from the computation of diluted net income (loss) per share were not material for the fiscal year ended June 28, 2024, 7 million for the fiscal year ended June 30, 2023, and not material for the fiscal year ended July 1, 2022.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001137789-24-000068:notes:227]
Legal, Environmental and Other Contingencies
The Company assesses the probability of an unfavorable outcome of all its material litigation, claims or assessments to determine whether a liability had been incurred and whether it is probable that one or more future events will occur confirming the fact of the loss. In the event that an unfavorable outcome is determined to be probable and the amount of the loss can be reasonably estimated, the Company establishes an accrual for the litigation, claim or assessment. In addition, in the event an unfavorable outcome is determined to be less than probable, but reasonably possible, the Company will disclose an estimate of the possible loss or range of such loss; however, when a reasonable estimate cannot be made, the Company will provide disclosure to that effect. Litigation is inherently uncertain and may result in adverse rulings or decisions. Additionally, the Company may enter into settlements or be subject to judgments that may, individually or in the aggregate, have a material adverse effect on its results of operations. Accordingly, actual results could differ materially.

[0001137789-24-000068:notes:228]
Litigation

[0001137789-24-000068:notes:229]
Lambeth Magnetic Structures LLC v. Seagate Technology (US) Holdings, Inc., et al. On April 29, 2016, Lambeth Magnetic Structures LLC filed a complaint against Seagate Technology (US) Holdings, Inc. and Seagate Technology LLC in the U.S. District Court for the Western District of Pennsylvania, alleging infringement of U.S. Patent No. 7,128,988, “Magnetic Material Structures, Devices and Methods,” seeking damages as well as additional relief. The district court entered judgment in favor of Seagate on April 19, 2022, following a jury trial. The parties filed post-trial motions with the district court, which were denied.

[0001137789-24-000068:notes:230]
An appeal to the Federal Circuit is pending. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

[0001137789-24-000068:notes:231]
Seagate Technology LLC, et al. v. Headway Technologies, Inc., et al. On February 18, 2020, Seagate Technology LLC, Seagate Technology (Thailand) Ltd., Seagate Singapore International Headquarters Pte. Ltd. and Seagate Technology International (collectively, the “Seagate Entities”) filed a complaint in the U.S. District Court for the Northern District of California against defendant suppliers of HDD suspension assemblies. Defendants include NHK Spring Co. Ltd., TDK Corporation, Hutchinson Technology Inc. and several of their subsidiaries and affiliates. The complaint includes federal and state antitrust law claims, as well as a breach of contract claim. The complaint alleges that defendants and their co-conspirators knowingly conspired for more than twelve years not to compete in the supply of suspension assemblies; that defendant misused confidential information that the Seagate Entities had provided pursuant to nondisclosure agreements, in breach of their contractual obligations; and that the Seagate Entities paid artificially high prices on purchases of suspension assemblies. The Seagate Entities seek to recover the overcharges they paid for suspension assemblies, and additional relief permitted by law. On March 22, 2022, the Seagate Entities dismissed with prejudice all claims being asserted against Defendants TDK Corporation, Hutchinson Technology Inc. and their subsidiaries and affiliates (collectively “TDK”) relating to the antitrust law claims, the breach of contract claim and other matters described in the complaint. On April 8, 2022, the court entered an Amended Stipulation and Order of Dismissal with Prejudice to dismiss all claims against TDK. On August 2, 2022, NHK Spring Co. Ltd. filed a motion for Partial Summary Judgment under the Foreign Trade Antitrust Improvement Act (“FTAIA Motion”) against Seagate’s antitrust claims, and on October 14, 2022, the Seagate Entities filed their corresponding opposition. On May 15, 2023, the court issued a ruling that Seagate’s antitrust claims can proceed as to suspension assemblies that enter the United States but not as to suspension assembles that do not enter the United States. On July 28, 2023, the District Court initiated a reconsideration of this ruling and requested further briefing. On November 17, 2023, the Court granted NHK’s FTAIA Motion and denied Seagate’s Motion for Leave to Amend the Complaint. Seagate filed a motion on December 15, 2023 for the Court to certify the ruling for interlocutory appeal. On April 22, 2024, the District Court granted in part and denied in part Seagate’s motion to certify for interlocutory appeal the Court’s ruling on NHK’s FTAIA Motion. On May 2, 2024, Seagate filed a Petition for Permission to Appeal to the Ninth Circuit. On July 18, 2024, the United States Court of Appeals for the Ninth Circuit issued an order granting Seagate’s Petition for Permission to Appeal.

[0001137789-24-000068:notes:232]
In re Seagate Technology Holdings plc Securities Litigation. A putative class action lawsuit alleging violations of the federal securities laws, UA Local 38 Defined Contribution Pension Plan, et al. v. Seagate Technology Holdings PLC, et al., was filed on July 10, 2023, in the U.S. District Court for the Northern District of California against Seagate Technology Holdings plc, Dr. William D. Mosley, and Gianluca Romano. The complaint alleged that it was a securities class action on behalf of all purchasers of Seagate common stock between September 15, 2020 and October 25, 2022, inclusive, and asserted claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 and Rule 10b5-1. The complaint sought unspecified monetary damages and other relief. A second action, Public Employees’ Retirement System of Mississippi v. Seagate Technology Holdings plc, William David Mosley, and Gianluca Romano, was filed on July 26, 2023, asserting similar claims. The cases were consolidated on September 25, 2023. On October 19, 2023, plaintiffs filed an amended complaint asserting similar claims with a putative class period of September 14, 2020 through April 19, 2023. The Company, on behalf of all defendants, filed a motion to dismiss the amended complaint, which is currently pending before the court. A hearing regarding Seagate’s motion to dismiss occurred on March 26, 2024. The Company believes that the asserted claims are without merit and intends to vigorously defend the case.

[0001137789-24-000068:notes:233]
Godo Kaisha IP Bridge 1 v. Seagate Technology LLC, Seagate Technology (US) Holding, Inc., Seagate Technology (Thailand) Limited, Seagate Singapore International Headquarters Ltd., Seagate Technology (Netherlands) B.V. On March 15, 2024, a patent infringement action was filed by Godo Kaisha IP Bridge 1 (“IP Bridge”) against Seagate in U.S. District Court for the District of Delaware. The complaint alleges patent infringement by Seagate of three U.S. patents. On June 7, 2024, Seagate filed a motion to dismiss and a motion to transfer venue to Minnesota. On July 8, 2024, IP Bridge filed a First Amended Complaint alleging patent infringement by Seagate of six additional patents. IP Bridge is seeking damages as well as additional relief. The Company believes the asserted claims are without merit and intends to vigorously defend this case.

[0001137789-24-000068:notes:234]
Environmental Matters

[0001137789-24-000068:notes:235]
The Company’s operations are subject to U.S. and foreign laws and regulations relating to the protection of the environment, including those governing discharges of pollutants into the air and water, the management and disposal of hazardous substances and wastes and the cleanup of contaminated sites. Some of the Company’s operations require environmental permits and controls to prevent and reduce air and water pollution, and these permits are subject to modification, renewal and revocation by issuing authorities.

[0001137789-24-000068:notes:236]
The Company has established an environmental management system and continually review and update environmental policies and standard operating procedures for operations worldwide as needed. The Company believes that its operations are in material compliance with applicable environmental laws, regulations and permits. The Company budgets for operating and

[0001137789-24-000068:notes:237]
capital costs on an ongoing basis to comply with environmental laws. If additional or more stringent requirements are imposed on the Company in the future, it could incur additional operating costs and capital expenditures.

[0001137789-24-000068:notes:238]
Some environmental laws, such as the Comprehensive Environmental Response Compensation and Liability Act of 1980 (as amended, the “Superfund” law) and its state equivalents, can impose liability for the cost of cleanup of contaminated sites upon any of the current or former site owners or operators or upon parties who sent waste to these sites, regardless of whether the owner or operator owned the site at the time of the release of hazardous substances or the lawfulness of the original disposal activity. The Company has been identified as a responsible or potentially responsible party at several sites. At each of these sites, the Company has an assigned portion of the financial liability based on the type and amount of hazardous substances disposed of by each party at the site and the number of financially viable parties. The Company has fulfilled its responsibilities at some of these sites and remains involved in only a few at this time.

[0001137789-24-000068:notes:239]
While the Company’s ultimate costs in connection with these sites is difficult to predict with complete accuracy, based on its current estimates of cleanup costs and its expected allocation of these costs, the Company does not expect costs in connection with these sites to be material.

[0001137789-24-000068:notes:240]
The Company may be subject to various state, federal and international laws and regulations governing the environment, including those restricting the presence of certain substances in electronic products. For example, the European Union (“EU”) enacted the Restriction of the Use of Certain Hazardous Substances in Electrical and Electronic Equipment (2011/65/EU), which prohibits the use of certain substances, including lead, in certain products, including disk drives and server storage products, put on the market after July 1, 2006. Similar legislation has been or may be enacted in other jurisdictions, including in the United States, Canada, Mexico, Taiwan, China, Japan and others. The EU REACH Directive (Registration, Evaluation, Authorization, and Restriction of Chemicals, EC 1907/2006) also restricts substances of very high concern in products. If the Company or its suppliers fail to comply with the substance restrictions, recycle content requirements or other environmental requirements as they are enacted worldwide, it could have a materially adverse effect on the Company’s business.

[0001137789-24-000068:notes:241]
BIS Settlement

[0001137789-24-000068:notes:242]
On April 18, 2023, the Company’s subsidiaries Seagate Technology LLC and Seagate Singapore International Headquarters Pte. Ltd (collectively, “Seagate”), entered into a settlement agreement (the “Settlement Agreement”) with the U.S. Department of Commerce’s Bureau of Industry and Security (“BIS”) that resolves BIS’ allegations regarding Seagate’s sales of hard disk drives to Huawei between August 17, 2020 and September 29, 2021. Under the terms of the Settlement Agreement, Seagate has agreed to pay $300 million to BIS in quarterly installments of $15 million over the course of five years beginning October 31, 2023. Seagate has also agreed to complete three audits of its compliance with the license requirements of Section 734.9 of the U.S. Export Administration Regulations (“EAR”), including one audit by an unaffiliated third-party consultant chosen by Seagate with expertise in U.S. export control laws and two internal audits. The Settlement Agreement also includes a denial order that is suspended and will be waived five years after the date of the order issued under the Settlement Agreement, provided that Seagate has made full and timely payments under the Settlement Agreement and timely completed the audit requirements. While Seagate is in compliance with and upon successful compliance in full with the terms of the Settlement Agreement, BIS has agreed it will not initiate any further administrative proceedings against Seagate in connection with any violation of the EAR arising out of the transactions detailed in the Settlement Agreement.

[0001137789-24-000068:notes:243]
While Seagate believed that it complied with all relevant export control laws at the time it made the hard disk drive sales at issue, Seagate determined that engaging with BIS and settling this matter was in the best interest of the Company, its customers, and its shareholders. In determining to engage with BIS and resolve this matter through a settlement agreement, the Company considered a number of factors, including the risks and cost of protracted litigation involving the U.S. government, and the size of the potential penalty and the Company’s desire to focus on current business challenges and long-term business strategy. The Settlement Agreement includes a finding that the Company incorrectly interpreted the regulation at issue to require evaluation of only the last stage of Seagate’s hard disk drive manufacturing process rather than the entire process. As part of this settlement, Seagate has agreed not to contest BIS’ determination that the sales in question did not comply with the U.S. EAR.

[0001137789-24-000068:notes:244]
The Company accrued a charge of $300 million during fiscal year 2023, of which $60 million and $195 million were included in Accrued expense and Other non-current liabilities, respectively, on the Consolidated Balance Sheets as of June 28, 2024. For the fiscal year ended 2024, $45 million was paid and reported as an outflow from operating activities in its Consolidated Statements of Cash Flows.

[0001137789-24-000068:notes:245]
Other Matters 
From time to time, arising in the normal course of business, the Company is involved in a number of other judicial, regulatory or administrative proceedings and investigations incidental to its business, and the Company expects to be involved in such proceedings and investigations arising in the normal course of its business in the future. Although occasional adverse decisions or settlements may occur, the Company believes that the final disposition of such matters will not have a material adverse effect on its financial position or results of operations.


## us-gaap:CommitmentsDisclosureTextBlock

[0001137789-24-000068:notes:246]
Commitments
Unconditional Long-Term Purchase Obligations. As of June 28, 2024, the Company had unconditional long-term purchase obligations of approximately $56 million, primarily related to purchases of inventory components. The Company expects the commitment to total $31 million, $15 million, $7 million and $3 million for fiscal years 2026, 2027, 2028 and 2029 respectively. In addition, the Company also had certain long-term market share based inventory purchase commitments as of June 28, 2024.

[0001137789-24-000068:notes:247]
During fiscal year 2024, the Company recorded order cancellation fees of $87 million to terminate certain purchase commitments related to the purchase of inventory components and equipment, which was reflected under Cost of revenue in its Consolidated Statements of Operations. As of June 28, 2024, cumulative unpaid order cancellation fees on the Consolidated Balance Sheets were $93 million, with $39 million in Accrued expenses and $54 million in Accounts payable, all of which is expected to be paid within one year.

[0001137789-24-000068:notes:248]
Unconditional Long-Term Capital Expenditures. As of June 28, 2024, the Company had unconditional long-term commitments of approximately $62 million, primarily related to purchases of equipment. The Company expects capital expenditures of $35 million and $27 million for fiscal years 2026 and 2027, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001137789-24-000068:notes:249]
Business Segment and Geographic Information
 The Company’s manufacturing operations are based on technology platforms that are used to produce various data storage and systems solutions that serve multiple applications and markets. The Company has determined that its Chief Operating Decision Maker, the Chief Executive Officer, evaluates performance of the Company and makes decisions regarding investments in the Company’s technology platforms and manufacturing infrastructure based on the Company’s consolidated results. As a result, the Company has concluded that its manufacture and distribution of storage solutions constitutes one operating segment.

[0001137789-24-000068:notes:250]
The following table summarizes the Company’s long-lived assets by country:

[0001137789-24-000068:notes:251]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |  | July 1,2022 |
| Long-lived assets: |  |  |  |  |  |  |
| United States |  | $ | 658 |  |  | $ | 667 |  |  | $ | 670 |  |
| Thailand |  | 574 |  |  | 606 |  |  | 679 |  |
| Singapore |  | 447 |  |  | 460 |  |  | 557 |  |
| Other |  | 338 |  |  | 369 |  |  | 426 |  |
| Consolidated |  | $ | 2,017 |  |  | $ | 2,102 |  |  | $ | 2,332 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001137789-24-000068:notes:252]
Revenue
The following table provides information about disaggregated revenue by sales channel and country for the Company’s single reportable segment:

[0001137789-24-000068:notes:253]
|  |  | Fiscal Years Ended |
| (Dollars in millions) |  | June 28,2024 |  | June 30,2023 |  | July 1,2022 |
| Revenues by Channel |  |  |  |  |  |  |
| OEMs |  | $ | 4,896 |  |  | $ | 5,448 |  |  | $ | 8,742 |  |
| Distributors |  | 972 |  |  | 1,119 |  |  | 1,676 |  |
| Retailers |  | 683 |  |  | 817 |  |  | 1,243 |  |
| Total |  | $ | 6,551 |  |  | $ | 7,384 |  |  | $ | 11,661 |  |

[0001137789-24-000068:notes:254]
| Revenue from external customers (1): |  |  |  |  |  |  |
| Singapore |  | $ | 3,429 |  |  | $ | 3,271 |  |  | $ | 5,322 |  |
| United States |  | 2,308 |  |  | 3,053 |  |  | 4,694 |  |
| The Netherlands |  | 802 |  |  | 1,046 |  |  | 1,627 |  |
| Other |  | 12 |  |  | 14 |  |  | 18 |  |
| Total |  | $ | 6,551 |  |  | $ | 7,384 |  |  | $ | 11,661 |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001137789-24-000068:notes:255]
Divestiture
Sale of System-on-Chip (“SoC”) Operations

[0001137789-24-000068:notes:256]
On April 23, 2024, the Company entered into an Asset Purchase Agreement with Avago Technologies International Sales Pte. Limited (“Purchaser”), a subsidiary of Broadcom Inc., and sold certain intellectual property, equipment and other assets related to the design, development and manufacture of its SoC products to Purchaser. Purchaser and its affiliates also offered employment to certain of the Company’s employees engaged in the SoC operations. In connection with this transaction, the Company and Purchaser have also restructured certain pre-existing purchasing agreements (collectively, the “Transaction”). Total consideration for this Transaction was $600 million, including cash proceeds of $560 million at close. The remaining $40 million relates to standard indemnification clauses and is expected to be received before the end of fiscal year 2026 upon fulfillment of certain post-close conditions. Of the held back amount, $25 million was recorded in Other current assets and $15 million in Other assets, net on the Consolidated Balance Sheets as of June 28, 2024. The agreement also contains regulatory review indemnification clauses agreed to by both parties in conjunction with the transaction closing.

[0001137789-24-000068:notes:257]
Based on the valuation performed by the Company, $234 million of the consideration was attributable to the restructuring of pre-existing purchase agreements and recorded as a deferred liability within Other non-current liabilities on the Consolidated Balance Sheets as of June 28, 2024. The deferred liability is expected to be recognized ratably over the terms of the restructured purchase agreements. Estimating the fair value of the restructuring of pre-existing purchase agreements is judgmental in nature and involves the use of estimates and assumptions. The Company estimated the fair value of its restructuring of pre-existing purchase agreements using the market approach based on discounted cash flow analysis of management’s short-term and long-term forecast of purchase volume and average market price. The discount rate used is based on the weighted-average cost of capital of comparable public companies adjusted for the relevant risk associated with business specific characteristics. This deferred liability is classified in Level 3 of the fair value hierarchy.

[0001137789-24-000068:notes:258]
As a result of the Transaction, the Company recorded a pre-tax net gain of $313 million from the sale of assets and transfer of liabilities, which included $18 million of goodwill allocated to SoC operations based on its relative fair value of the Company because the disposal group constituted a business for accounting purposes. This was recorded in the Net gain from business divestiture in the Consolidated Statements of Operations during fiscal year 2024. For the fiscal year 2024, the net proceeds of $226 million, net of transaction costs paid, from this Transaction was recorded as an operating inflow and $326 million was recorded as an investing inflow on the Company’s Consolidated Statements of Cash Flows. The Transaction did not meet the criteria of discontinued operation because the disposal did not represent a strategic shift that had a major effect on the Company’s operations and financial results.


## us-gaap:SubsequentEventsTextBlock

[0001137789-24-000068:notes:259]
Subsequent Event
Dividend Declared

[0001137789-24-000068:notes:260]
On July 23, 2024, the Board of Directors of the Company declared a quarterly cash dividend of $0.70 per share, which will be payable on October 7, 2024 to shareholders of record as of the close of business on September 23, 2024.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001137789-24-000068:notes:261]
The table below summarizes the material terms of trading arrangements adopted by any of our executive officers or directors during the fiscal quarter ended June 28, 2024. All of the trading arrangements listed below are intended to satisfy the affirmative defense of Rule 10b5-1(c).

[0001137789-24-000068:notes:262]
| Name | Title | Date of Adoption | End Date¹ | Aggregate number of ordinary shares to be sold pursuant to the trading agreement |
| Dr. William D. Mosley | Chief Executive Officer and Director | May 6, 2024 | April 30, 2025 | 476,132 |
| Gianluca Romano | Executive Vice President and Chief Financial Officer | May 1, 2024 | December 31, 2024 | 25,760 |
| Yolanda Conyers | Director | June 5, 2024 | September 30, 2025 | 3,750 |

[0001137789-24-000068:notes:263]
¹ The plan will expire on the earlier of the end date or the completion of all transactions under the trading arrangement.
