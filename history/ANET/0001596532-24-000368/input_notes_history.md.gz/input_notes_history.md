# ANET note change history — 0001596532-24-000279 → 0001596532-24-000368


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0001596532-24-000368:note_history:1]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of September 30, 2024, we had lease payment obligations, net of immaterial sublease income, of $69.8 million, with $24.1 million payable within one year.
  (was, 2024-07-31, similarity 0.9737):
[0001596532-24-000279:note_history:1]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of June 30, 2024, we had lease payment obligations, net of immaterial sublease income, of $61.6 million, with $23.5 million payable within one year.

- changed (2024-11-08):
[0001596532-24-000368:note_history:2]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2024, we had non-cancellable purchase commitments not recorded on our balance sheet of $2.4 billion, of which $2.0 billion have expected receipt dates within 12 months, and $0.4 billion have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.
  (was, 2024-07-31, similarity 0.994):
[0001596532-24-000279:note_history:2]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of June 30, 2024, we had non-cancellable purchase commitments not recorded on our balance sheet of $2.1 billion, of which $1.7 billion have expected receipt dates within 12 months, and $0.4 billion have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

- changed (2024-11-08):
[0001596532-24-000368:note_history:3]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $116.5 million and $133.3 million as of September 30, 2024 and December 31, 2023, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.
  (was, 2024-07-31, similarity 0.9795):
[0001596532-24-000279:note_history:3]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $128.0 million and $133.3 million as of June 30, 2024 and December 31, 2023, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

- changed (2024-11-08):
[0001596532-24-000368:note_history:4]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2024, provisions recorded for contingent losses related to other
  (was, 2024-07-31, similarity 0.7029):
[0001596532-24-000279:note_history:4]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of June 30, 2024, provisions recorded for contingent losses related to other claims

- changed (2024-11-08):
[0001596532-24-000368:note_history:5]
claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.
  (was, 2024-07-31, similarity 0.9956):
[0001596532-24-000279:note_history:5]
and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0001596532-24-000368:note_history:6]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP have been condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2024, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2023 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.
  (was, 2024-07-31, similarity 0.9812):
[0001596532-24-000279:note_history:6]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP have been condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2024, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2023 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

- changed (2024-11-08):
[0001596532-24-000368:note_history:7]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, valuation of inventory and contract manufacturer/supplier liabilities, accounting for income taxes, including the recognition of deferred tax assets and liabilities, valuation allowance on deferred tax assets and reserves for uncertain tax positions, revenue recognition and deferred revenue, valuation of goodwill and acquisition-related intangible assets, estimate of useful lives of long-lived assets including intangible assets, and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust these estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from these estimates.
  (was, 2024-07-31, similarity 0.9685):
[0001596532-24-000279:note_history:7]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, valuation of inventory and contract manufacturer/supplier liabilities, accounting for income taxes, including the recognition of deferred tax assets and liabilities, valuation allowance on deferred tax assets and reserves for uncertain tax positions, revenue recognition and deferred revenue, allowance for doubtful accounts, sales rebates and return reserves, valuation of goodwill and acquisition-related intangible assets, estimate of useful lives of long-lived assets including intangible assets, and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust these estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from these estimates.

- added (2024-11-08):
[0001596532-24-000368:note_history:8]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including the effects of, among other things, inflation, monetary policy shifts, recession risks, potential supply chain disruptions, and geopolitical pressures.

- changed (2024-11-08):
[0001596532-24-000368:note_history:9]
Our business is emerging from a period of unprecedented global supply chain disruptions.  Throughout this period, we made significant supply chain investments, including funding additional working capital and incremental purchase commitments in response to extended visibility to deployment plans from our customers. We have worked closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. Increased capacity has allowed us to ship products against previously committed demand/deployment plans and accelerate some deployments where needed, while trying to minimize building customer inventory, and to some extent balancing customer lead times with those currently experienced from our key suppliers. As a result, some shipments against these previously committed demand/deployment plans have extended into 2024.
  (was, 2024-07-31, similarity 0.9928):
[0001596532-24-000279:note_history:9]
Our business is emerging from a period of unprecedented global supply chain disruptions.  Throughout this period, we made significant supply chain investments, including funding additional working capital and incremental purchase commitments in response to extended visibility to deployment plans from our customers. We have worked closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. Increased capacity has allowed us to ship products against previously committed demand/deployment plans and accelerate some deployments where needed, while trying to limit building customer inventory, and to some extent balancing customer lead times with those currently experienced from our key suppliers. As a result, some shipments against these previously committed demand/deployment plans have extended into 2024.

- changed (2024-11-08):
[0001596532-24-000368:note_history:10]
As the global supply chain has experienced some improvements and as customer lead times have been reduced from their peak, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to shorter demand-planning horizons. Given these shipment and order patterns, near term revenue trends may not be solely reflective of current demand levels, but as discussed above will benefit from demand/deployment plans that had been
  (was, 2024-07-31, similarity 0.6602):
[0001596532-24-000279:note_history:10]
As the global supply chain has experienced some improvements and as customer lead times have been reduced from their peak, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual

- added (2024-11-08):
[0001596532-24-000368:note_history:11]
previously committed. We expect that our inventory and purchase commitments will remain volatile as we ramp new product introductions. The magnitude of these balances, combined with a reduction in customer demand-planning horizons and shifting customer product priorities, has resulted in increased risk that we may not be able to sell all of this inventory, which in turn has resulted in additional excess and obsolete inventory and supplier liability charges. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods.

- added (2024-11-08):
[0001596532-24-000368:note_history:12]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. In addition, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. Recent technologies, such as generative AI models, have emerged, and while they have driven increased demand for networking, the long-term trajectory is unknown. As such, demand estimates for our new products may be inaccurate and create volatility in our revenue and inventory levels. Furthermore, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial conditions discussed herein may not be indicative of future operating results and trends.

- changed (2024-11-08):
[0001596532-24-000368:note_history:13]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2024. Early adoption is permitted for annual financial statements that have not yet been issued. The amendments should be applied on a prospective basis although retrospective application is permitted. As of September 30, 2024, we have not early adopted ASU 2023-09 and we are currently evaluating the impact of future adoption on our financial disclosures.
  (was, 2024-07-31, similarity 0.9923):
[0001596532-24-000279:note_history:13]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2024. Early adoption is permitted for annual financial statements that have not yet been issued. The amendments should be applied on a prospective basis although retrospective application is permitted. As of June 30, 2024, we have not early adopted ASU 2023-09 and we are currently evaluating the impact of future adoption on our financial disclosures.

- changed (2024-11-08):
[0001596532-24-000368:note_history:14]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280)-Improvements to Reportable Segment Disclosures. The ASU requires that an entity disclose significant segment expenses impacting profit and loss that are regularly provided to the chief operating decision maker. The update is required to be applied retrospectively to prior periods presented, based on the significant segment expense categories identified and disclosed in the period of adoption. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. As of September 30, 2024, we have not early adopted ASU 2023-07 and we are currently evaluating the impact of future adoption on our financial disclosures.
  (was, 2024-07-31, similarity 0.9919):
[0001596532-24-000279:note_history:14]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280)-Improvements to Reportable Segment Disclosures. The ASU requires that an entity disclose significant segment expenses impacting profit and loss that are regularly provided to the chief operating decision maker. The update is required to be applied retrospectively to prior periods presented, based on the significant segment expense categories identified and disclosed in the period of adoption. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. As of June 30, 2024, we have not early adopted ASU 2023-07 and we are currently evaluating the impact of future adoption on our financial disclosures.

- removed (2024-11-08):
[0001596532-24-000279:note_history:15]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including inflation, monetary policy shifts, recession risks, and potential supply chain and other disruptions such as the Russia-Ukraine and Israel-Hamas conflicts, the Houthi attacks on marine vessels in the Red Sea, the U.S. trade war with China and the outcome of the upcoming U.S. presidential election.

- removed (2024-11-08):
[0001596532-24-000279:note_history:16]
return to shorter demand-planning horizons. Given these shipment and order patterns, near term revenue trends may not be solely reflective of current demand levels, but as discussed above will benefit from demand/deployment plans that had been previously committed. We expect that inventory and purchase commitments will begin to stabilize in the near term, but will remain volatile as we ramp new product introductions. The magnitude of these balances, combined with a reduction in customer demand-planning horizons and shifting customer product priorities, has resulted in increased risk that we may not be able to sell all of this inventory, which in turn has resulted in additional excess and obsolete inventory and supplier liability charges.

- removed (2024-11-08):
[0001596532-24-000279:note_history:17]
In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the Russia-Ukraine conflict, continued escalation of this conflict as well as the Israeli-Hamas conflict and Houthi movement in the Red Sea may negatively impact the global economy and our future operating results and financial condition.

- removed (2024-11-08):
[0001596532-24-000279:note_history:18]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. In addition, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that some of our customers must now consider changing technology roadmaps and priorities, including the need for the deployment of AI and related technologies, resulting in some uncertainty as to future investment plans and a more constrained approach to some forecasts and orders in the near term. In addition, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial conditions discussed herein may not be indicative of future operating results and trends.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0001596532-24-000368:note_history:19]
|  |  | September 30, 2024 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 62,724 |  |  | $ | (74) |  |  | $ | 127,869 |  |  | $ | (146) |  |  | $ | 190,593 |  |  | $ | (220) |  |
| Corporate bonds |  | 221,914 |  |  | (133) |  |  | 101,990 |  |  | (114) |  |  | 323,904 |  |  | (247) |  |
| Agency securities |  | 129,773 |  |  | (189) |  |  | 102,796 |  |  | (41) |  |  | 232,569 |  |  | (230) |  |
| Total |  | $ | 414,411 |  |  | $ | (396) |  |  | $ | 332,655 |  |  | $ | (301) |  |  | $ | 747,066 |  |  | $ | (697) |  |
  (was, 2024-07-31, similarity 0.9886):
[0001596532-24-000279:note_history:19]
|  |  | June 30, 2024 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 1,445,689 |  |  | $ | (2,660) |  |  | $ | 161,063 |  |  | $ | (724) |  |  | $ | 1,606,752 |  |  | $ | (3,384) |  |
| Corporate bonds |  | 1,408,050 |  |  | (5,076) |  |  | 184,252 |  |  | (703) |  |  | 1,592,302 |  |  | (5,779) |  |
| Agency securities |  | 339,109 |  |  | (508) |  |  | 179,258 |  |  | (571) |  |  | 518,367 |  |  | (1,079) |  |
| Total |  | $ | 3,192,848 |  |  | $ | (8,244) |  |  | $ | 524,573 |  |  | $ | (1,998) |  |  | $ | 3,717,421 |  |  | $ | (10,242) |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2024-11-08):
[0001596532-24-000368:note_history:20]
Subsequent event
         Arista’s board of directors has approved a four-for-one forward stock split to make Arista’s common stock more accessible to a broader base of investors.

- added (2024-11-08):
[0001596532-24-000368:note_history:21]
The four-for-one forward stock split will be effected through the filing of an amendment to Arista’s Amended and Restated Certificate of Incorporation that will proportionately increase the authorized shares of common stock.

- added (2024-11-08):
[0001596532-24-000368:note_history:22]
Our stockholders will receive an additional three shares of common stock for each share held as of the effective time of the filing of the amendment on December 3, 2024. Prior to market open on December 4, 2024, trading is expected to commence on a split-adjusted basis. The following table reflects basic and diluted weighted average shares and net income per share on an unaudited pro forma basis giving effect to the stock split as if it had been effective for all periods presented (in thousands, except per share amounts).

- added (2024-11-08):
[0001596532-24-000368:note_history:23]
|  |  | Pro Forma (Unaudited) |
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 747,938 |  |  | $ | 545,327 |  |  | $ | 2,051,058 |  |  | $ | 1,473,685 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Basic weighted-average shares outstanding |  | 1,257,928 |  |  | 1,240,740 |  |  | 1,254,968 |  |  | 1,234,408 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity awards |  | 23,864 |  |  | 29,784 |  |  | 25,344 |  |  | 31,848 |  |
| Diluted weighted-average shares outstanding |  | 1,281,792 |  |  | 1,270,524 |  |  | 1,280,312 |  |  | 1,266,256 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.59 |  |  | $ | 0.44 |  |  | $ | 1.63 |  |  | $ | 1.19 |  |
| Diluted |  | $ | 0.58 |  |  | $ | 0.43 |  |  | $ | 1.60 |  |  | $ | 1.16 |  |
