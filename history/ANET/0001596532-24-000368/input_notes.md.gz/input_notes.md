# ANET notes — 0001596532-24-000368


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-24-000368:notes:1]
[same as prior period, unchanged from 0001596532-24-000279:notes:1]

[0001596532-24-000368:notes:2]
[same as prior period, unchanged from 0001596532-24-000279:notes:2]

[0001596532-24-000368:notes:3]
[same as prior period, unchanged from 0001596532-24-000279:notes:3]

[0001596532-24-000368:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP have been condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2024, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2023 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

[0001596532-24-000368:notes:5]
[same as prior period, unchanged from 0001596532-24-000279:notes:5]

[0001596532-24-000368:notes:6]
[same as prior period, unchanged from 0001596532-24-000279:notes:6]

[0001596532-24-000368:notes:7]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, valuation of inventory and contract manufacturer/supplier liabilities, accounting for income taxes, including the recognition of deferred tax assets and liabilities, valuation allowance on deferred tax assets and reserves for uncertain tax positions, revenue recognition and deferred revenue, valuation of goodwill and acquisition-related intangible assets, estimate of useful lives of long-lived assets including intangible assets, and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust these estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from these estimates.

[0001596532-24-000368:notes:8]
[same as prior period, unchanged from 0001596532-24-000279:notes:8]

[0001596532-24-000368:notes:9]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including the effects of, among other things, inflation, monetary policy shifts, recession risks, potential supply chain disruptions, and geopolitical pressures.

[0001596532-24-000368:notes:10]
Our business is emerging from a period of unprecedented global supply chain disruptions.  Throughout this period, we made significant supply chain investments, including funding additional working capital and incremental purchase commitments in response to extended visibility to deployment plans from our customers. We have worked closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. Increased capacity has allowed us to ship products against previously committed demand/deployment plans and accelerate some deployments where needed, while trying to minimize building customer inventory, and to some extent balancing customer lead times with those currently experienced from our key suppliers. As a result, some shipments against these previously committed demand/deployment plans have extended into 2024.

[0001596532-24-000368:notes:11]
As the global supply chain has experienced some improvements and as customer lead times have been reduced from their peak, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to shorter demand-planning horizons. Given these shipment and order patterns, near term revenue trends may not be solely reflective of current demand levels, but as discussed above will benefit from demand/deployment plans that had been

[0001596532-24-000368:notes:12]
previously committed. We expect that our inventory and purchase commitments will remain volatile as we ramp new product introductions. The magnitude of these balances, combined with a reduction in customer demand-planning horizons and shifting customer product priorities, has resulted in increased risk that we may not be able to sell all of this inventory, which in turn has resulted in additional excess and obsolete inventory and supplier liability charges. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods.

[0001596532-24-000368:notes:13]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. In addition, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. Recent technologies, such as generative AI models, have emerged, and while they have driven increased demand for networking, the long-term trajectory is unknown. As such, demand estimates for our new products may be inaccurate and create volatility in our revenue and inventory levels. Furthermore, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial conditions discussed herein may not be indicative of future operating results and trends.

[0001596532-24-000368:notes:14]
[same as prior period, unchanged from 0001596532-24-000279:notes:15]

[0001596532-24-000368:notes:15]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2024. Early adoption is permitted for annual financial statements that have not yet been issued. The amendments should be applied on a prospective basis although retrospective application is permitted. As of September 30, 2024, we have not early adopted ASU 2023-09 and we are currently evaluating the impact of future adoption on our financial disclosures.

[0001596532-24-000368:notes:16]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280)-Improvements to Reportable Segment Disclosures. The ASU requires that an entity disclose significant segment expenses impacting profit and loss that are regularly provided to the chief operating decision maker. The update is required to be applied retrospectively to prior periods presented, based on the significant segment expense categories identified and disclosed in the period of adoption. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. As of September 30, 2024, we have not early adopted ASU 2023-07 and we are currently evaluating the impact of future adoption on our financial disclosures.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-24-000368:notes:17]
[same as prior period, unchanged from 0001596532-24-000279:notes:18]

[0001596532-24-000368:notes:18]
[same as prior period, unchanged from 0001596532-24-000279:notes:19]

[0001596532-24-000368:notes:19]
|  |  | September 30, 2024 |  | December 31, 2023 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,372,386 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,372,386 |  |  | $ | 1,015,705 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,015,705 |  |
| Commercial paper |  | — |  |  | 2,994 |  |  | — |  |  | 2,994 |  |  | — |  |  | 1,999 |  |  | — |  |  | 1,999 |  |
| U.S. government notes |  | 54,889 |  |  | — |  |  | — |  |  | 54,889 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Agency securities |  | — |  |  | 24,997 |  |  | — |  |  | 24,997 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | 1,427,275 |  |  | 27,991 |  |  | — |  |  | 1,455,266 |  |  | 1,015,705 |  |  | 1,999 |  |  | — |  |  | 1,017,704 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 25,058 |  |  | — |  |  | 25,058 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposits(1) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5,000 |  |  | — |  |  | 5,000 |  |
| U.S. government notes |  | 1,506,033 |  |  | — |  |  | — |  |  | 1,506,033 |  |  | 1,044,859 |  |  | — |  |  | — |  |  | 1,044,859 |  |
| Corporate bonds |  | — |  |  | 1,968,281 |  |  | — |  |  | 1,968,281 |  |  | — |  |  | 1,362,124 |  |  | — |  |  | 1,362,124 |  |
| Agency securities |  | — |  |  | 753,877 |  |  | — |  |  | 753,877 |  |  | — |  |  | 657,379 |  |  | — |  |  | 657,379 |  |
|  |  | 1,506,033 |  |  | 2,747,216 |  |  | — |  |  | 4,253,249 |  |  | 1,044,859 |  |  | 2,024,503 |  |  | — |  |  | 3,069,362 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 1,399 |  |  | — |  |  | — |  |  | 1,399 |  |  | 858 |  |  | — |  |  | — |  |  | 858 |  |
| Total Financial Assets |  | $ | 2,934,707 |  |  | $ | 2,775,207 |  |  | $ | — |  |  | $ | 5,709,914 |  |  | $ | 2,061,422 |  |  | $ | 2,026,502 |  |  | $ | — |  |  | $ | 4,087,924 |  |

[0001596532-24-000368:notes:20]
[same as prior period, unchanged from 0001596532-24-000279:notes:21]

[0001596532-24-000368:notes:21]
[same as prior period, unchanged from 0001596532-24-000279:notes:22]

[0001596532-24-000368:notes:22]
During the three and nine months ended September 30, 2024, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-24-000368:notes:23]
[same as prior period, unchanged from 0001596532-24-000279:notes:24]

[0001596532-24-000368:notes:24]
|  |  | September 30, 2024 |  | December 31, 2023 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 28,052 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,052 |  |  | $ | 1,999 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,999 |  |
| U.S. government |  | 1,554,054 |  |  | 7,088 |  |  | (220) |  |  | 1,560,922 |  |  | 1,043,445 |  |  | 2,874 |  |  | (1,460) |  |  | 1,044,859 |  |
| Corporate bonds |  | 1,957,674 |  |  | 10,854 |  |  | (247) |  |  | 1,968,281 |  |  | 1,361,132 |  |  | 2,810 |  |  | (1,818) |  |  | 1,362,124 |  |
| Agency securities |  | 775,636 |  |  | 3,468 |  |  | (230) |  |  | 778,874 |  |  | 657,118 |  |  | 1,143 |  |  | (882) |  |  | 657,379 |  |
| Total |  | $ | 4,315,416 |  |  | $ | 21,410 |  |  | $ | (697) |  |  | $ | 4,336,129 |  |  | $ | 3,063,694 |  |  | $ | 6,827 |  |  | $ | (4,160) |  |  | $ | 3,066,361 |  |

[0001596532-24-000368:notes:25]
For debt securities in unrealized loss positions, it is not likely that we will be required to sell such securities before recovery of their amortized cost basis nor do we have the intent to sell such securities before maturity. We invest in debt securities that have maximum maturities of two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. Given the short-term and conservative nature of our portfolio, our debt securities are generally not subject to credit risk; therefore, we did not recognize any credit losses or non-credit-related impairments related to such securities for the three and nine months ended September 30, 2024. All unrealized losses were recognized in other

[0001596532-24-000368:notes:26]
comprehensive income (loss). Realized gains or losses were immaterial for the three and nine months ended September 30, 2024.

[0001596532-24-000368:notes:27]
[same as prior period, unchanged from 0001596532-24-000279:notes:28]

[0001596532-24-000368:notes:28]
|  |  | September 30, 2024 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 62,724 |  |  | $ | (74) |  |  | $ | 127,869 |  |  | $ | (146) |  |  | $ | 190,593 |  |  | $ | (220) |  |
| Corporate bonds |  | 221,914 |  |  | (133) |  |  | 101,990 |  |  | (114) |  |  | 323,904 |  |  | (247) |  |
| Agency securities |  | 129,773 |  |  | (189) |  |  | 102,796 |  |  | (41) |  |  | 232,569 |  |  | (230) |  |
| Total |  | $ | 414,411 |  |  | $ | (396) |  |  | $ | 332,655 |  |  | $ | (301) |  |  | $ | 747,066 |  |  | $ | (697) |  |

[0001596532-24-000368:notes:29]
As of September 30, 2024, we had no marketable securities with contractual maturities that exceeded 24 months. The fair values of marketable securities by remaining contractual maturities, are as follows (in thousands):

[0001596532-24-000368:notes:30]
|  |  | September 30, 2024 |
|  |  | Fair Value |
| Due in 1 year or less |  | $ | 2,591,487 |  |
| Due in 1 to 2 years |  | 1,661,762 |  |
| Total debt securities |  | $ | 4,253,249 |  |

[0001596532-24-000368:notes:31]
The weighted-average remaining duration of our marketable securities is approximately 0.9 years as of September 30, 2024. As we view these marketable securities as available to support current operations, we classify marketable securities with maturities beyond 12 months as current assets under the caption "Marketable securities" on the condensed consolidated balance sheets.

[0001596532-24-000368:notes:32]
[same as prior period, unchanged from 0001596532-24-000279:notes:33]

[0001596532-24-000368:notes:33]
[same as prior period, unchanged from 0001596532-24-000279:notes:34]

[0001596532-24-000368:notes:34]
We have non-marketable equity securities in privately-held companies that do not have readily-determinable fair values. These equity securities are included in Other Assets on the condensed consolidated balance sheets. Their initial cost is adjusted to fair value on a non-recurring basis based on observable price changes from orderly transactions of identical or similar securities of the same issuer, or for impairment. These investments are classified within Level III of the fair value hierarchy as we estimate the value based on valuation methods using the observable transaction price at the transaction date and other significant unobservable inputs, such as volatility, rights, and obligations related to these securities. In addition, the valuation requires management judgment due to the absence of market price and lack of liquidity.

[0001596532-24-000368:notes:35]
We did not record any realized gains or losses on our non-marketable equity securities during the three and nine months ended September 30, 2024 and September 30, 2023, and we recorded immaterial amounts of unrealized gains or losses for the three and nine months ended September 30, 2024 and September 30, 2023, respectively.

[0001596532-24-000368:notes:36]
[same as prior period, unchanged from 0001596532-24-000279:notes:37]

[0001596532-24-000368:notes:37]
The following table summarizes the activity related to our non-marketable equity securities as of September 30, 2024 and December 31, 2023 (in thousands):

[0001596532-24-000368:notes:38]
|  |  | September 30, 2024 |  | December 31, 2023 |
| Cost of investments |  | $ | 38,284 |  |  | $ | 31,656 |  |
| Cumulative impairment and downward adjustment |  | — |  |  | — |  |
| Cumulative upward adjustment |  | 43,032 |  |  | 30,632 |  |
| Carrying amount of investments |  | $ | 81,316 |  |  | $ | 62,288 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-24-000368:notes:39]
[same as prior period, unchanged from 0001596532-24-000279:notes:40]

[0001596532-24-000368:notes:40]
[same as prior period, unchanged from 0001596532-24-000279:notes:41]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-24-000368:notes:41]
Financial Statements Details 
Inventories

[0001596532-24-000368:notes:42]
[same as prior period, unchanged from 0001596532-24-000279:notes:49]

[0001596532-24-000368:notes:43]
|  |  | September 30, 2024 |  | December 31, 2023 |
| Raw materials |  | $ | 652,213 |  |  | $ | 930,777 |  |
| Finished goods |  | 1,117,749 |  |  | 1,014,403 |  |
| Total inventories |  | $ | 1,769,962 |  |  | $ | 1,945,180 |  |

[0001596532-24-000368:notes:44]
Prepaid Expenses and Other Current Assets

[0001596532-24-000368:notes:45]
Prepaid expenses and other current assets consist of the following (in thousands):

[0001596532-24-000368:notes:46]
|  |  | September 30, 2024 |  | December 31, 2023 |
| Inventory deposits |  | $ | 113,705 |  |  | $ | 130,509 |  |
| Other current assets |  | 434,988 |  |  | 282,009 |  |
| Total prepaid expenses and other current assets |  | $ | 548,693 |  |  | $ | 412,518 |  |

[0001596532-24-000368:notes:47]
[same as prior period, unchanged from 0001596532-24-000279:notes:51]

[0001596532-24-000368:notes:48]
[same as prior period, unchanged from 0001596532-24-000279:notes:52]

[0001596532-24-000368:notes:49]
|  |  | September 30, 2024 |  | December 31, 2023 |
| Land |  | $ | 46,866 |  |  | $ | 44,645 |  |
| Equipment and machinery |  | 157,626 |  |  | 149,092 |  |
| Computer hardware and software |  | 62,321 |  |  | 57,761 |  |
| Leasehold improvements |  | 34,781 |  |  | 34,584 |  |
| Furniture and fixtures |  | 3,563 |  |  | 3,576 |  |
| Property and equipment, gross |  | 305,157 |  |  | 289,658 |  |
| Less: accumulated depreciation |  | (212,123) |  |  | (188,078) |  |
| Property and equipment, net |  | $ | 93,034 |  |  | $ | 101,580 |  |

[0001596532-24-000368:notes:50]
[same as prior period, unchanged from 0001596532-24-000279:notes:55]

[0001596532-24-000368:notes:51]
[same as prior period, unchanged from 0001596532-24-000279:notes:56]

[0001596532-24-000368:notes:52]
|  |  | September 30, 2024 |  | December 31, 2023 |
| Accrued compensation-related costs |  | $ | 107,545 |  |  | $ | 134,225 |  |
| Accrued supplier liability |  | 90,053 |  |  | 167,878 |  |
| Accrued manufacturing and product development costs |  | 77,574 |  |  | 62,532 |  |
| Other |  | 48,818 |  |  | 42,667 |  |
| Total accrued liabilities |  | $ | 323,990 |  |  | $ | 407,302 |  |

[0001596532-24-000368:notes:53]
[same as prior period, unchanged from 0001596532-24-000279:notes:58]

[0001596532-24-000368:notes:54]
[same as prior period, unchanged from 0001596532-24-000279:notes:59]

[0001596532-24-000368:notes:55]
[same as prior period, unchanged from 0001596532-24-000279:notes:60]

[0001596532-24-000368:notes:56]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Contract liabilities, beginning balance |  | $ | 144,130 |  |  | $ | 110,097 |  |  | $ | 133,239 |  |  | $ | 103,448 |  |
| Less: Revenue recognized from beginning balance |  | (12,693) |  |  | (10,222) |  |  | (44,678) |  |  | (33,466) |  |
| Less: Beginning balance reclassified to deferred revenue |  | (6,757) |  |  | (5,306) |  |  | (4,954) |  |  | (5,228) |  |
| Add: Contract liabilities recognized |  | 22,280 |  |  | 25,712 |  |  | 63,353 |  |  | 55,527 |  |
| Contract liabilities, ending balance |  | $ | 146,960 |  |  | $ | 120,281 |  |  | $ | 146,960 |  |  | $ | 120,281 |  |

[0001596532-24-000368:notes:57]
As of September 30, 2024 and December 31, 2023, contract liabilities included in "Other current liabilities" were $60.0 million for each period, with the remaining balances included in "Other long-term liabilities" on the condensed consolidated balance sheets.

[0001596532-24-000368:notes:58]
[same as prior period, unchanged from 0001596532-24-000279:notes:63]

[0001596532-24-000368:notes:59]
[same as prior period, unchanged from 0001596532-24-000279:notes:64]

[0001596532-24-000368:notes:60]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Deferred revenue, beginning balance |  | $ | 2,118,786 |  |  | $ | 1,084,904 |  |  | $ | 1,506,204 |  |  | $ | 1,041,246 |  |
| Less: Revenue recognized from beginning balance |  | (249,328) |  |  | (173,494) |  |  | (616,321) |  |  | (506,859) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 637,873 |  |  | 283,341 |  |  | 1,617,448 |  |  | 660,364 |  |
| Deferred revenue, ending balance |  | $ | 2,507,331 |  |  | $ | 1,194,751 |  |  | $ | 2,507,331 |  |  | $ | 1,194,751 |  |

[0001596532-24-000368:notes:61]
[same as prior period, unchanged from 0001596532-24-000279:notes:66]

[0001596532-24-000368:notes:62]
Other performance obligations totaling $626.3 million as of September 30, 2024 include unbilled multi-year PCS and service contract amounts of $514.0 million and $112.3 million of binding contractual agreements with certain customers that are primarily related to future product shipments.

[0001596532-24-000368:notes:63]
[same as prior period, unchanged from 0001596532-24-000279:notes:68]

[0001596532-24-000368:notes:64]
Total revenue from our contract liabilities, deferred revenue and other performance obligations that is expected to be recognized in future periods was $3.3 billion as of September 30, 2024. Approximately 83% of this future revenue is expected to be recognized over the next two years and the remaining 17% is expected to be recognized during the third to the fifth year.

[0001596532-24-000368:notes:65]
[same as prior period, unchanged from 0001596532-24-000279:notes:70]

[0001596532-24-000368:notes:66]
[same as prior period, unchanged from 0001596532-24-000279:notes:71]

[0001596532-24-000368:notes:67]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Interest income |  | $ | 85,374 |  |  | $ | 43,676 |  |  | $ | 220,645 |  |  | $ | 98,391 |  |
| Gain (loss) on strategic investments |  | 12,400 |  |  | (473) |  |  | 12,400 |  |  | 18,699 |  |
| Other income (expense), net |  | (114) |  |  | (1,388) |  |  | (1,902) |  |  | (6,790) |  |
| Total |  | $ | 97,660 |  |  | $ | 41,815 |  |  | $ | 231,143 |  |  | $ | 110,300 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-24-000368:notes:68]
[same as prior period, unchanged from 0001596532-24-000279:notes:73]

[0001596532-24-000368:notes:69]
[same as prior period, unchanged from 0001596532-24-000279:notes:74]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001596532-24-000368:notes:70]
[same as prior period, unchanged from 0001596532-24-000279:notes:75]

[0001596532-24-000368:notes:71]
[same as prior period, unchanged from 0001596532-24-000279:notes:76]

[0001596532-24-000368:notes:72]
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life (in years) |
|  | December 31, 2023 |  | Additions |  | September 30, 2024 |  | December 31, 2023 |  | Amortization |  | September 30, 2024 |  | December 31, 2023 |  | September 30, 2024 |  |
| Developed technology | $ | 154,930 |  |  | $ | — |  |  | $ | 154,930 |  |  | $ | (102,493) |  |  | $ | (12,583) |  |  | $ | (115,076) |  |  | $ | 52,437 |  |  | $ | 39,854 |  |  | 3.5 |
| Customer relationships | 54,620 |  |  | — |  |  | 54,620 |  |  | (21,797) |  |  | (5,777) |  |  | (27,574) |  |  | 32,823 |  |  | 27,046 |  |  | 4.1 |
| Trade name | 12,390 |  |  | — |  |  | 12,390 |  |  | (8,882) |  |  | (1,710) |  |  | (10,592) |  |  | 3,508 |  |  | 1,798 |  |  | 0.9 |
| Total | $ | 221,940 |  |  | $ | — |  |  | $ | 221,940 |  |  | $ | (133,172) |  |  | $ | (20,070) |  |  | $ | (153,242) |  |  | $ | 88,768 |  |  | $ | 68,698 |  |  | 3.7 |

[0001596532-24-000368:notes:73]
Amortization expense related to acquisition-related intangible assets was $6.7 million and $8.1 million for the three months ended September 30, 2024 and 2023, respectively, and $20.1 million and $26.7 million for the nine months ended September 30, 2024 and 2023, respectively.

[0001596532-24-000368:notes:74]
As of September 30, 2024, future estimated amortization expense related to acquisition-related intangible assets is as follows (in thousands):

[0001596532-24-000368:notes:75]
|  |  | Future Amortization Expense |
| Remainder of 2024 |  | $ | 6,690 |  |
| 2025 |  | 19,642 |  |
| 2026 |  | 17,260 |  |
| 2027 |  | 13,436 |  |
| 2028 |  | 10,037 |  |
| Thereafter |  | 1,633 |  |
| Total |  | $ | 68,698 |  |

[0001596532-24-000368:notes:76]
Goodwill 
There was no change to goodwill for the three and nine months ended September 30, 2024.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-24-000368:notes:77]
Commitments and Contingencies
Leases

[0001596532-24-000368:notes:78]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of September 30, 2024, we had lease payment obligations, net of immaterial sublease income, of $69.8 million, with $24.1 million payable within one year.

[0001596532-24-000368:notes:79]
Purchase Commitments

[0001596532-24-000368:notes:80]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2024, we had non-cancellable purchase commitments not recorded on our balance sheet of $2.4 billion, of which $2.0 billion have expected receipt dates within 12 months, and $0.4 billion have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-24-000368:notes:81]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $116.5 million and $133.3 million as of September 30, 2024 and December 31, 2023, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

[0001596532-24-000368:notes:82]
Guarantees

[0001596532-24-000368:notes:83]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-24-000368:notes:84]
Legal Proceedings

[0001596532-24-000368:notes:85]
WSOU Investments, LLC

[0001596532-24-000368:notes:86]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California.  On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement. On July 1, 2022, the court stayed the case pending the resolution of an inter partes review of one of the patents-in-suit. On May 30, 2023, the US Patent Trial and Appeal Board (“PTAB”) ruled all challenged claims in the inter partes review unpatentable. The district court case remains stayed pending appeal and/or final resolution of the PTAB ruling.

[0001596532-24-000368:notes:87]
We intend to vigorously defend against the claims brought against us by WSOU; however, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-24-000368:notes:88]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated; however, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-24-000368:notes:89]
Other matters

[0001596532-24-000368:notes:90]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-24-000368:notes:91]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2024, provisions recorded for contingent losses related to other

[0001596532-24-000368:notes:92]
claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-24-000368:notes:93]
[same as prior period, unchanged from 0001596532-24-000279:notes:97]

[0001596532-24-000368:notes:94]
In April 2024, we completed repurchases under our previous $1.0 billion stock repurchase program (the “Prior Repurchase Program”).  In May 2024, our board of directors authorized a new $1.2 billion stock repurchase program (the “New Repurchase Program” and together with the Prior Repurchase Program, the "Repurchase Programs"), which commenced in May 2024 and expires in May 2027. This authorization allows us to repurchase shares of our common stock that will be funded from working capital. Repurchases may be made at management's discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the "Exchange Act"), or a combination of the foregoing. The Repurchase Programs do not obligate us to acquire any of our common stock, and may be suspended or discontinued by the company at any time without prior notice. During the three months ended September 30, 2024, we repurchased a total of $65.2 million of our common stock under our New Repurchase Program. During the nine months ended September 30, 2024, we repurchased a total of $155.2 million of our common stock under our New Repurchase Program and $144.6 million of our common stock under our Prior Repurchase Program. As of September 30, 2024, the remaining authorized amount for stock repurchases under the New Repurchase Program was approximately $1.0 billion.

[0001596532-24-000368:notes:95]
A summary of the stock repurchase activity for the three and nine months ended September 30, 2024 is as follows (in thousands, except per share amounts):

[0001596532-24-000368:notes:96]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | September 30, 2024 |  | September 30, 2024 |
| Aggregate purchase price |  | $ | 65,157 |  |  | $ | 299,823 |  |
| Shares repurchased |  | 205 |  |  | 1,047 |  |
| Average price paid per share |  | $ | 318.14 |  |  | $ | 286.47 |  |

[0001596532-24-000368:notes:97]
[same as prior period, unchanged from 0001596532-24-000279:notes:101]

[0001596532-24-000368:notes:98]
[same as prior period, unchanged from 0001596532-24-000279:notes:102]

[0001596532-24-000368:notes:99]
[same as prior period, unchanged from 0001596532-24-000279:notes:103]

[0001596532-24-000368:notes:100]
[same as prior period, unchanged from 0001596532-24-000279:notes:104]

[0001596532-24-000368:notes:101]
The Restated Plan provides for the grant of equity-based awards, including stock options, restricted stock units, restricted stock, stock appreciation rights, and performance awards. The share pool available under the prior version of the Company's 2014 Equity Incentive Plan (the "Prior Plan") was extinguished, and the Restated Plan provides for a new share pool not to exceed (i) 13,200,000 shares of our Common Stock (“Shares”), plus (ii) any Shares subject to awards under the Prior Plan that, on or after the Effective Date, expired or otherwise terminated without having been exercised in full, or that were forfeited to or repurchased by us, including net settlement of Shares subject to restricted stock units, with the maximum number of Shares to be added to the Restated Plan as a result of clause (ii) equal to 10,039,657 Shares. The Restated Plan’s terms are substantially similar to the Prior Plan’s terms, including with respect to treatment of equity awards in the event of a “change in control” as defined under the Restated Plan, but with certain modifications, including the elimination of the automatic “evergreen” share reserve increase provided for under the Prior Plan. As of September 30, 2024, there remained approximately 13.1 million shares available for grant under the Restated Plan.

[0001596532-24-000368:notes:102]
[same as prior period, unchanged from 0001596532-24-000279:notes:106]

[0001596532-24-000368:notes:103]
In April 2014, our board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of

[0001596532-24-000368:notes:104]
our shares outstanding on the immediately preceding December 31, but not to exceed 10 million shares, unless our board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2024, our board of directors authorized an increase of 3.1 million shares to the shares available for issuance under the ESPP. During the nine months ended September 30, 2024, we issued 280,843 shares at a weighted-average purchase price of $116.31 per share under the ESPP. As of September 30, 2024, there remained approximately 26.2 million shares available for issuance under the ESPP.

[0001596532-24-000368:notes:105]
[same as prior period, unchanged from 0001596532-24-000279:notes:109]

[0001596532-24-000368:notes:106]
The following table summarizes the option activity under our stock plans and related information (in thousands, except per share amounts):

[0001596532-24-000368:notes:107]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2023 |  | 2,457 |  |  | $ | 19.83 |  |  | 1.7 |  | $ | 529,931 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (1,391) |  |  | 16.41 |  |  |  |  |  |
| Options canceled |  | (24) |  |  | 20.07 |  |  |  |  |  |
| Balance—September 30, 2024 |  | 1,042 |  |  | $ | 24.39 |  |  | 1.5 |  | $ | 374,471 |  |
| Vested and exercisable—September 30, 2024 |  | 997 |  |  | $ | 23.26 |  |  | 1.4 |  | $ | 359,633 |  |

[0001596532-24-000368:notes:108]
[same as prior period, unchanged from 0001596532-24-000279:notes:112]

[0001596532-24-000368:notes:109]
A summary of the RSU activity is presented below (in thousands, except per share amounts):

[0001596532-24-000368:notes:110]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |
| Unvested balance—December 31, 2023 |  | 7,900 |  |  | $ | 112.76 |  |
| RSUs and PRSUs granted |  | 2,307 |  |  | 277.30 |  |
| RSUs and PRSUs vested |  | (2,117) |  |  | 93.59 |  |
| RSUs and PRSUs forfeited/canceled |  | (412) |  |  | 134.80 |  |
| Unvested balance—September 30, 2024 |  | 7,678 |  |  | $ | 168.28 |  |

[0001596532-24-000368:notes:111]
[same as prior period, unchanged from 0001596532-24-000279:notes:115]

[0001596532-24-000368:notes:112]
[same as prior period, unchanged from 0001596532-24-000279:notes:116]

[0001596532-24-000368:notes:113]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cost of revenue |  | $ | 4,098 |  |  | $ | 3,717 |  |  | $ | 11,531 |  |  | $ | 9,516 |  |
| Research and development |  | 58,340 |  |  | 47,965 |  |  | 152,897 |  |  | 125,671 |  |
| Sales and marketing |  | 20,960 |  |  | 20,490 |  |  | 56,630 |  |  | 51,461 |  |
| General and administrative |  | 14,725 |  |  | 13,218 |  |  | 33,572 |  |  | 28,750 |  |
| Total stock-based compensation |  | $ | 98,123 |  |  | $ | 85,390 |  |  | $ | 254,630 |  |  | $ | 215,398 |  |

[0001596532-24-000368:notes:114]
As of September 30, 2024, there were $1.1 billion of unamortized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 4.5 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-24-000368:notes:115]
Net Income Per Share
    Basic net income per share is computed using the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed using the weighted-average number of shares of common stock outstanding during the period, including potential common shares assuming the dilutive effect of outstanding stock options,

[0001596532-24-000368:notes:116]
restricted stock units, and the employee stock purchase plan using the treasury stock method. Potential common shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share. The following table sets forth the computation of our basic and diluted net income per share (in thousands, except per share amounts):

[0001596532-24-000368:notes:117]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 747,938 |  |  | $ | 545,327 |  |  | $ | 2,051,058 |  |  | $ | 1,473,685 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Basic weighted-average shares outstanding |  | 314,482 |  |  | 310,185 |  |  | 313,742 |  |  | 308,602 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity awards |  | 5,966 |  |  | 7,446 |  |  | 6,336 |  |  | 7,962 |  |
| Diluted weighted-average shares outstanding |  | 320,448 |  |  | 317,631 |  |  | 320,078 |  |  | 316,564 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.38 |  |  | $ | 1.76 |  |  | $ | 6.54 |  |  | $ | 4.78 |  |
| Diluted |  | $ | 2.33 |  |  | $ | 1.72 |  |  | $ | 6.41 |  |  | $ | 4.66 |  |

[0001596532-24-000368:notes:118]
[same as prior period, unchanged from 0001596532-24-000279:notes:122]

[0001596532-24-000368:notes:119]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Employee equity awards |  | 54 |  |  | 29 |  |  | 82 |  |  | 341 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001596532-24-000368:notes:120]
The following table sets forth the computation of our basic and diluted net income per share (in thousands, except per share amounts):

[0001596532-24-000368:notes:121]
The following table reflects basic and diluted weighted average shares and net income per share on an unaudited pro forma basis giving effect to the stock split as if it had been effective for all periods presented (in thousands, except per share amounts).

[0001596532-24-000368:notes:122]
|  |  | Pro Forma (Unaudited) |
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 747,938 |  |  | $ | 545,327 |  |  | $ | 2,051,058 |  |  | $ | 1,473,685 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Basic weighted-average shares outstanding |  | 1,257,928 |  |  | 1,240,740 |  |  | 1,254,968 |  |  | 1,234,408 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity awards |  | 23,864 |  |  | 29,784 |  |  | 25,344 |  |  | 31,848 |  |
| Diluted weighted-average shares outstanding |  | 1,281,792 |  |  | 1,270,524 |  |  | 1,280,312 |  |  | 1,266,256 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.59 |  |  | $ | 0.44 |  |  | $ | 1.63 |  |  | $ | 1.19 |  |
| Diluted |  | $ | 0.58 |  |  | $ | 0.43 |  |  | $ | 1.60 |  |  | $ | 1.16 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-24-000368:notes:123]
[same as prior period, unchanged from 0001596532-24-000279:notes:124]

[0001596532-24-000368:notes:124]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Income before income taxes |  | $ | 882,910 |  |  | $ | 644,510 |  |  | $ | 2,376,107 |  | $ | 1,727,635 |  |
| Provision for income taxes |  | 134,972 |  |  | 99,183 |  |  | $ | 325,049 |  | 253,950 |  |
| Effective tax rate |  | 15.3 | % |  | 15.4 | % |  | 13.7 | % |  | 14.7 | % |

[0001596532-24-000368:notes:125]
The decrease in the effective tax rates in the three and nine months ended September 30, 2024, as compared to the same periods in 2023, was primarily due to a change in the jurisdictional mix of earnings.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-24-000368:notes:126]
[same as prior period, unchanged from 0001596532-24-000279:notes:127]

[0001596532-24-000368:notes:127]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Americas(1) |  | $ | 1,480,071 |  |  | $ | 1,184,717 |  |  | $ | 4,109,719 |  |  | $ | 3,454,237 |  |
| Europe, Middle East and Africa |  | 191,189 |  |  | 173,175 |  |  | 511,543 |  |  | 469,114 |  |
| Asia-Pacific |  | 139,676 |  |  | 151,564 |  |  | 451,448 |  |  | 396,380 |  |
| Total revenue |  | $ | 1,810,936 |  |  | $ | 1,509,456 |  |  | $ | 5,072,710 |  |  | $ | 4,319,731 |  |

[0001596532-24-000368:notes:128]
(1) Includes $1,465.3 million and $1,150.5 million revenue generated from the U.S. for the three months ended September 30, 2024 and September 30, 2023, respectively, and $4,060.8 million and $3,366.8 million for the nine months ended September 30, 2024 and September 30, 2023, respectively.

[0001596532-24-000368:notes:129]
[same as prior period, unchanged from 0001596532-24-000279:notes:130]

[0001596532-24-000368:notes:130]
|  |  | September 30, 2024 |  | December 31, 2023 |
| United States |  | $ | 75,556 |  |  | $ | 79,728 |  |
| International |  | 17,478 |  |  | 21,852 |  |
| Total |  | $ | 93,034 |  |  | $ | 101,580 |  |


## us-gaap:SubsequentEventsTextBlock

[0001596532-24-000368:notes:131]
Subsequent event
         Arista’s board of directors has approved a four-for-one forward stock split to make Arista’s common stock more accessible to a broader base of investors.

[0001596532-24-000368:notes:132]
The four-for-one forward stock split will be effected through the filing of an amendment to Arista’s Amended and Restated Certificate of Incorporation that will proportionately increase the authorized shares of common stock.

[0001596532-24-000368:notes:133]
Our stockholders will receive an additional three shares of common stock for each share held as of the effective time of the filing of the amendment on December 3, 2024. Prior to market open on December 4, 2024, trading is expected to commence on a split-adjusted basis. The following table reflects basic and diluted weighted average shares and net income per share on an unaudited pro forma basis giving effect to the stock split as if it had been effective for all periods presented (in thousands, except per share amounts).


## ecd:MtrlTermsOfTrdArrTextBlock

[0001596532-24-000368:notes:134]
On September 13, 2024, Yvonne Wassenaar, a member of our Board of Directors, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of 126 shares of our common stock. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until January 22, 2026, or earlier if all transactions under the trading arrangement are completed.

[0001596532-24-000368:notes:135]
On September 5, 2024, John McCool, our Chief Platform Officer, and Senior Vice President of Engineering and Operations, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to: (i) 9,479 shares of common stock; (ii) a number of shares of our common stock that may be earned in connection with grants of performance-based restricted stock units, which cannot be determined at this time; and (iii) a number of shares of our common stock that will be purchased under the 2014 ESPP during the term of the trading arrangement, which cannot be determined at this time. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until December 8, 2025, or earlier if all transactions under the trading arrangement are completed.

[0001596532-24-000368:notes:136]
On September 11, 2024, Marc Taxay, our Senior Vice President and General Counsel, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to (i) 15,129 shares of common stock; and (ii) a number of shares of our common stock that may be earned in connection with grants of performance-based restricted stock units, which cannot be determined at this time. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until December 31, 2025, or earlier if all transactions under the trading arrangement are completed.
