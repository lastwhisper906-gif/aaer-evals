# ANET MD&A — 0001596532-24-000368


## mdna

[0001596532-24-000368:mdna:1]
[same as prior period, unchanged from 0001596532-24-000279:mdna:1]

[0001596532-24-000368:mdna:2]
[same as prior period, unchanged from 0001596532-24-000279:mdna:2]

[0001596532-24-000368:mdna:3]
[same as prior period, unchanged from 0001596532-24-000279:mdna:3]

[0001596532-24-000368:mdna:4]
We generate revenue primarily from sales of our switching and routing platforms, which incorporate Arista's EOS software, and related network applications. We also generate revenue from post-contract support ("PCS"), which customers

[0001596532-24-000368:mdna:5]
typically purchase in conjunction with our products, and renewals of PCS. We sell our products through both our direct sales force and our channel partners. Our customers span a range of industries and geographies including large cloud customers or hyperscalers, other internet providers, service providers, financial services organizations, government agencies and a cross section of enterprise customers. Over time, we have diversified the types of enterprise customers we sell to and have continued to expand our presence across a wide spectrum of industries including media and entertainment, healthcare, oil and gas, education, manufacturing, industrial, and more.

[0001596532-24-000368:mdna:6]
[same as prior period, unchanged from 0001596532-24-000279:mdna:5]

[0001596532-24-000368:mdna:7]
We believe an increased focus on the deployment of AI enabled solutions by our large customers has accelerated the need for advanced technology offerings including some offerings from potential new market entrants.  This prioritization of AI related infrastructure investment has at times come in conjunction with the announcement of various cost reduction measures, including optimization and increased efficiency in non-AI related capital expenditures.  In some instances, such measures have had, and may continue to have, an impact on certain current or future projects and have reduced our visibility to customer demand and may result in a reduction or uncertainty in the timing of orders from these large customers and increase the risk of excess and obsolescence charges on our products. In addition, fiscal 2024 continues to be a year of new product introductions and expanded use cases, particularly in the AI Ethernet market, resulting in increased customer trials and contracts with acceptance periods, and an increase in the volatility and magnitude of our product deferred revenue balances, which in turn may create variability in our revenue results on a quarterly and annual basis. In addition, if we are not able to satisfy the requirements under customer trials and contracts with acceptance periods, we may be required to accept product returns from our customers, which would reduce our deferred revenue balances and prevent us from recognizing revenue on such transactions and may result in the write-down of inventory.

[0001596532-24-000368:mdna:8]
[same as prior period, unchanged from 0001596532-24-000279:mdna:7]

[0001596532-24-000368:mdna:9]
[same as prior period, unchanged from 0001596532-24-000279:mdna:8]

[0001596532-24-000368:mdna:10]
Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic with respect to the underlying merchant silicon architecture. The programmability of EOS has allowed us to expand our software applications to address the ever-increasing demands of cloud networking, including workflow automation, network visibility, analytics and network detection and response, and has further allowed us to integrate rapidly with a wide range of third-party applications for virtualization, management, automation, orchestration and network services. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We work closely with third-party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to

[0001596532-24-000368:mdna:11]
our third-party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-24-000368:mdna:12]
[same as prior period, unchanged from 0001596532-24-000279:mdna:10]

[0001596532-24-000368:mdna:13]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including the effects of, among other things, inflation, monetary policy shifts, recession risks, potential supply chain disruptions, and geopolitical pressures.

[0001596532-24-000368:mdna:14]
Our business is emerging from a period of unprecedented global supply chain disruptions.  Throughout this period, we made significant supply chain investments, including funding additional working capital and incremental purchase commitments in response to extended visibility to deployment plans from our customers. We have worked closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. Increased capacity has allowed us to ship products against previously committed demand/deployment plans and accelerate some deployments where needed, while trying to minimize building customer inventory, and to some extent balancing customer lead times with those currently experienced from our key suppliers. As a result, some shipments against these previously committed demand/deployment plans have extended into 2024.

[0001596532-24-000368:mdna:15]
As the global supply chain has experienced some improvements and as customer lead times have been reduced from their peak, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to shorter demand-planning horizons. Given these shipment and order patterns, near term revenue trends may not be solely reflective of current demand levels, but as discussed above will benefit from demand/deployment plans that had been previously committed. We expect that our inventory and purchase commitments will remain volatile as we ramp new product introductions. The magnitude of these balances, combined with a reduction in customer demand-planning horizons and shifting customer product priorities, has resulted in increased risk that we may not be able to sell all of this inventory, which in turn has resulted in additional excess and obsolete inventory and supplier liability charges. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods.

[0001596532-24-000368:mdna:16]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. In addition, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. Recent technologies, such as generative AI models, have emerged, and while they have driven increased demand for networking, the long-term trajectory is unknown. As such, demand estimates for our new products may be inaccurate and create volatility in our revenue, inventory and purchase commitment levels.  Furthermore, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial conditions discussed herein may not be indicative of future operating results and trends.

[0001596532-24-000368:mdna:17]
[same as prior period, unchanged from 0001596532-24-000279:mdna:16]

[0001596532-24-000368:mdna:18]
Three and Nine Months Ended September 30, 2024 Compared to Three and Nine Months Ended September 30, 2023

[0001596532-24-000368:mdna:19]
[same as prior period, unchanged from 0001596532-24-000279:mdna:18]

[0001596532-24-000368:mdna:20]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | Change in |  | 2024 |  | 2023 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,523,807 |  |  | $ | 1,285,548 |  |  | $ | 238,259 |  |  | 18.5 | % |  | $ | 4,275,923 |  |  | $ | 3,719,179 |  |  | $ | 556,744 |  |  | 15.0 | % |
| Service |  | 287,129 |  |  | 223,908 |  |  | 63,221 |  |  | 28.2 |  |  | 796,787 |  |  | 600,552 |  |  | 196,235 |  |  | 32.7 |  |
| Total revenue |  | 1,810,936 |  |  | 1,509,456 |  |  | 301,480 |  |  | 20.0 |  |  | 5,072,710 |  |  | 4,319,731 |  |  | 752,979 |  |  | 17.4 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 593,343 |  |  | 522,866 |  |  | 70,477 |  |  | 13.5 |  |  | 1,655,415 |  |  | 1,565,341 |  |  | 90,074 |  |  | 5.8 |  |
| Service |  | 55,876 |  |  | 44,171 |  |  | 11,705 |  |  | 26.5 |  |  | 156,986 |  |  | 123,335 |  |  | 33,651 |  |  | 27.3 |  |
| Total cost of revenue |  | 649,219 |  |  | 567,037 |  |  | 82,182 |  |  | 14.5 |  |  | 1,812,401 |  |  | 1,688,676 |  |  | 123,725 |  |  | 7.3 |  |
| Gross profit |  | $ | 1,161,717 |  |  | $ | 942,419 |  |  | $ | 219,298 |  |  | 23.3 | % |  | $ | 3,260,309 |  |  | $ | 2,631,055 |  |  | $ | 629,254 |  |  | 23.9 | % |
| Gross margin |  | 64.2 | % |  | 62.4 | % |  |  |  |  |  | 64.3 | % |  | 60.9 | % |  |  |  |  |

[0001596532-24-000368:mdna:21]
[same as prior period, unchanged from 0001596532-24-000279:mdna:20]

[0001596532-24-000368:mdna:22]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | % of Total |  | 2023 |  | % of Total |  | 2024 |  | % of Total |  | 2023 |  | % of Total |
| Americas |  | $ | 1,480,071 |  |  | 81.7 | % |  | $ | 1,184,717 |  |  | 78.5 | % |  | $ | 4,109,719 |  |  | 81.0 | % |  | $ | 3,454,237 |  |  | 79.9 | % |
| Europe, Middle East and Africa |  | 191,189 |  |  | 10.6 |  |  | 173,175 |  |  | 11.5 |  |  | 511,543 |  |  | 10.1 |  |  | 469,114 |  |  | 10.9 |  |
| Asia-Pacific |  | 139,676 |  |  | 7.7 |  |  | 151,564 |  |  | 10.0 |  |  | 451,448 |  |  | 8.9 |  |  | 396,380 |  |  | 9.2 |  |
| Total revenue |  | $ | 1,810,936 |  |  | 100.0 | % |  | $ | 1,509,456 |  |  | 100.0 | % |  | $ | 5,072,710 |  |  | 100.0 | % |  | $ | 4,319,731 |  |  | 100.0 | % |

[0001596532-24-000368:mdna:23]
[same as prior period, unchanged from 0001596532-24-000279:mdna:22]

[0001596532-24-000368:mdna:24]
[same as prior period, unchanged from 0001596532-24-000279:mdna:23]

[0001596532-24-000368:mdna:25]
Product revenue increased by $238.3 million, or 18.5%, and $556.7 million, or 15.0% for the three and nine months ended September 30, 2024, compared to the same periods in 2023. This increase reflects healthy customer demand and higher shipments of our switching and routing platforms, in particular strong contributions from our large cloud and enterprise customers. In addition, service revenue increased by $63.2 million, or 28.2%, and $196.2 million, or 32.7% for the three and nine months ended September 30, 2024, compared to the same periods in 2023, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenue represented 18.3% and 19.0% of total revenue for the three and nine months ended September 30, 2024, changing from 21.5% and 20.1% for the same periods in the prior year, which was primarily driven by changes in the geographic mix of sales to our large global customers.

[0001596532-24-000368:mdna:26]
[same as prior period, unchanged from 0001596532-24-000279:mdna:26]

[0001596532-24-000368:mdna:27]
[same as prior period, unchanged from 0001596532-24-000279:mdna:27]

[0001596532-24-000368:mdna:28]
Cost of revenue increased by $82.2 million, or 14.5%, and $123.7 million, or 7.3% for the three months and nine months ended September 30, 2024, compared to the same periods in 2023. These increases were driven by a corresponding increase in product and service revenues, partially offset by reductions of $40.3 million and $111.4 million in net excess/obsolete inventory and supplier liability charges for the three months and nine months ended September 30, 2024, compared to the same periods in 2023 respectively.

[0001596532-24-000368:mdna:29]
[same as prior period, unchanged from 0001596532-24-000279:mdna:29]

[0001596532-24-000368:mdna:30]
Gross margin increased from 62.4% to 64.2% for the three months ended September 30, 2024, and increased from 60.9% to 64.3% for the nine months ended September 30, 2024, compared to the same periods in 2023. These changes reflect an improvement in product margins of 61.1% compared to 59.3%, and 61.3% compared to 57.9%, for the three and nine months ended September 30, 2024, compared to the same periods in 2023 respectively. The improvement in product margins was driven largely by a reduction of $40.3 million and $111.4 million in net excess/obsolete inventory and supplier liability charges for the three months and nine months ended September 30, 2024, compared to the same periods in 2023 respectively.

[0001596532-24-000368:mdna:31]
[same as prior period, unchanged from 0001596532-24-000279:mdna:31]

[0001596532-24-000368:mdna:32]
[same as prior period, unchanged from 0001596532-24-000279:mdna:32]

[0001596532-24-000368:mdna:33]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | Change in |  | 2024 |  | 2023 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 235,824 |  |  | $ | 212,353 |  |  | $ | 23,471 |  |  | 11.1 | % |  | $ | 711,701 |  |  | $ | 643,437 |  |  | $ | 68,264 |  |  | 10.6 | % |
| Sales and marketing |  | 106,832 |  |  | 102,033 |  |  | 4,799 |  |  | 4.7 |  |  | 316,315 |  |  | 293,496 |  |  | 22,819 |  |  | 7.8 |  |
| General and administrative |  | 33,811 |  |  | 25,338 |  |  | 8,473 |  |  | 33.4 |  |  | 87,329 |  |  | 76,787 |  |  | 10,542 |  |  | 13.7 |  |
| Total operating expenses |  | $ | 376,467 |  |  | $ | 339,724 |  |  | $ | 36,743 |  |  | 10.8 | % |  | $ | 1,115,345 |  |  | $ | 1,013,720 |  |  | $ | 101,625 |  |  | 10.0 | % |

[0001596532-24-000368:mdna:34]
[same as prior period, unchanged from 0001596532-24-000279:mdna:34]

[0001596532-24-000368:mdna:35]
[same as prior period, unchanged from 0001596532-24-000279:mdna:35]

[0001596532-24-000368:mdna:36]
Research and development expenses increased by $23.5 million, or 11.1%, and $68.3 million, or 10.6% for the three and nine months ended September 30, 2024, compared to the same periods in 2023. The increase was mainly driven by an increase in personnel costs due to headcount growth.

[0001596532-24-000368:mdna:37]
[same as prior period, unchanged from 0001596532-24-000279:mdna:37]

[0001596532-24-000368:mdna:38]
[same as prior period, unchanged from 0001596532-24-000279:mdna:38]

[0001596532-24-000368:mdna:39]
Sales and marketing expenses increased by $4.8 million, or 4.7%, and $22.8 million, or 7.8% for the three and nine months ended September 30, 2024, compared to the same periods in 2023.

[0001596532-24-000368:mdna:40]
[same as prior period, unchanged from 0001596532-24-000279:mdna:40]

[0001596532-24-000368:mdna:41]
[same as prior period, unchanged from 0001596532-24-000279:mdna:41]

[0001596532-24-000368:mdna:42]
General and administrative expenses increased by $8.5 million, or 33.4% for the three months ended September 30, 2024 and increased by $10.5 million, or 13.7% for the nine months ended September 30, 2024, compared to the same periods in

[0001596532-24-000368:mdna:43]
2023.

[0001596532-24-000368:mdna:44]
[same as prior period, unchanged from 0001596532-24-000279:mdna:43]

[0001596532-24-000368:mdna:45]
[same as prior period, unchanged from 0001596532-24-000279:mdna:44]

[0001596532-24-000368:mdna:46]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | Change in |  | 2024 |  | 2023 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 85,374 |  |  | $ | 43,676 |  |  | $ | 41,698 |  |  | 95.5 | % |  | $ | 220,645 |  |  | $ | 98,391 |  |  | $ | 122,254 |  |  | 124.3 | % |
| Gain (loss) on strategic investments |  | 12,400 |  |  | (473) |  |  | 12,873 |  |  | 2,721.6 |  |  | 12,400 |  |  | 18,699 |  |  | (6,299) |  |  | (33.7) |  |
| Other income (expense), net |  | (114) |  |  | (1,388) |  |  | 1,274 |  |  | (91.8) |  |  | (1,902) |  |  | (6,790) |  |  | 4,888 |  |  | (72.0) |  |
| Total other income (expense), net |  | $ | 97,660 |  |  | $ | 41,815 |  |  | $ | 55,845 |  |  | 133.6 | % |  | $ | 231,143 |  |  | $ | 110,300 |  |  | $ | 120,843 |  |  | 109.6 | % |

[0001596532-24-000368:mdna:47]
The improvement in other income during the three and nine months ended September 30, 2024 compared to the same periods in 2023 was primarily driven by increased interest income of $41.7 million and $122.3 million due to an increase in our cash and investment balances coupled with higher investment yields.

[0001596532-24-000368:mdna:48]
[same as prior period, unchanged from 0001596532-24-000279:mdna:47]

[0001596532-24-000368:mdna:49]
[same as prior period, unchanged from 0001596532-24-000279:mdna:48]

[0001596532-24-000368:mdna:50]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | Change in |  | 2024 |  | 2023 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Income before income taxes |  | $ | 882,910 |  |  | $ | 644,510 |  |  | $ | 238,400 |  |  | 37.0 | % |  | $ | 2,376,107 |  |  | $ | 1,727,635 |  |  | $ | 648,472 |  |  | 37.5 | % |
| Provision for income taxes |  | 134,972 |  |  | 99,183 |  |  | 35,789 |  |  | 36.1 | % |  | 325,049 |  |  | 253,950 |  |  | 71,099 |  |  | 28.0 | % |
| Effective tax rate |  | 15.3 | % |  | 15.4 | % |  |  |  |  |  | 13.7 | % |  | 14.7 | % |  |  |  |  |

[0001596532-24-000368:mdna:51]
The decrease in the effective tax rates for the three and nine months ended September 30, 2024, as compared to the same periods in 2023, was due to a change in the jurisdictional mix of earnings.

[0001596532-24-000368:mdna:52]
[same as prior period, unchanged from 0001596532-24-000279:mdna:51]

[0001596532-24-000368:mdna:53]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of September 30, 2024, our total balance of cash, cash equivalents and marketable securities was approximately $7.4 billion, of which approximately $1.1 billion was held outside the U.S. in our foreign subsidiaries.

[0001596532-24-000368:mdna:54]
Our cash, cash equivalents and marketable securities are held for general business purposes, including the funding of working capital. Our marketable securities investment portfolio is primarily invested in highly-rated securities, with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations, will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, stock repurchases, and capital expenditures, including the planned construction of an office and lab space. If we require or elect to seek additional capital through debt or equity financing

[0001596532-24-000368:mdna:55]
in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-24-000368:mdna:56]
[same as prior period, unchanged from 0001596532-24-000279:mdna:55]

[0001596532-24-000368:mdna:57]
|  |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |
| Cash provided by operating activities |  | $ | 2,677,272 |  |  | $ | 1,507,550 |  |
| Cash used in investing activities |  | (1,147,413) |  |  | (350,497) |  |
| Cash used in financing activities |  | (291,774) |  |  | (82,421) |  |
| Effect of exchange rate changes |  | (1,011) |  |  | (934) |  |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 1,237,074 |  |  | $ | 1,073,698 |  |

[0001596532-24-000368:mdna:58]
[same as prior period, unchanged from 0001596532-24-000279:mdna:57]

[0001596532-24-000368:mdna:59]
During the nine months ended September 30, 2024, cash provided by operating activities was $2.7 billion, consisting of net income of $2.1 billion along with a net decrease in working capital requirements of $744.3 million, offset partially by non-cash adjustments to net income of $118.1 million. The decrease in working capital requirements primarily consisted of an increase in deferred revenue of $1,001.1 million resulting from an increase in customer PCS contracts and an increase in product deferred revenue related to customer contracts with acceptance terms, a $175.2 million decrease in inventory resulting from strong product shipments, and a $59.8 million increase in income tax payables, net related to timing of payments. These cash inflows were partially offset by a $226.6 million decrease in accounts payable and accrued liabilities primarily due to timing of inventory-related receipts and payments, as well as a reduction in supplier liabilities, an increase in accounts receivable of $96.5 million due to increased product and service billings, and a $173.1 million increase in other assets driven by increased deferred cost of sales associated with higher product revenue deferrals. The non-cash adjustments to net income were driven by a $376.7 million increase in deferred taxes primarily due to the increase in deferred revenue and the capitalization of research and development costs under Section 174 of the Internal Revenue Code ("IRC"), largely offset by stock-based compensation of $254.6 million and depreciation and amortization.

[0001596532-24-000368:mdna:60]
During the nine months ended September 30, 2023, cash provided by operating activities was $1,507.6 million, primarily from net income of $1,473.7 million, non-cash adjustments to net income of $26.7 million and a net decrease of $7.2 million in working capital requirements. The non-cash adjustments to net income were driven by stock-based compensation and depreciation and amortization, largely offset by an increase in deferred taxes primarily due to the capitalization of research and development costs under Section 174 of the IRC. This decrease in working capital requirements primarily consisted of a $346.2 million increase in income tax payables largely related to the tax relief issued by the Internal Revenue Service ("IRS") to extend the due date for the 2022 tax return filing, and 2023 estimated tax payments to October 16, 2023, a $151.2 million increase in accounts payable and accrued liabilities due to an increase in business volume and timing of payments, a decrease in accounts receivable of $84.4 million driven by strong collections, and an increase in deferred revenue of $153.5 million primarily resulting from an increase in customer PCS contracts. These operating cash inflows were largely offset by a $603.8 million increase in inventory and a $118.6 million increase in prepaid and other assets.

[0001596532-24-000368:mdna:61]
[same as prior period, unchanged from 0001596532-24-000279:mdna:60]

[0001596532-24-000368:mdna:62]
During the nine months ended September 30, 2024, cash used in investing activities was $1.1 billion, consisting of purchases of available-for-sale securities of $2.6 billion, partially offset by proceeds from maturities and sales of marketable securities of $1.5 billion.

[0001596532-24-000368:mdna:63]
During the nine months ended September 30, 2023, cash used in investing activities was $350.5 million, consisting of  purchases of available-for-sale securities of $1,934.2 million, and purchases of property and equipment of $28.4 million. These amounts were partially offset by proceeds from maturities and sales of marketable securities of $1,614.5 million.

[0001596532-24-000368:mdna:64]
[same as prior period, unchanged from 0001596532-24-000279:mdna:63]

[0001596532-24-000368:mdna:65]
During the nine months ended September 30, 2024, cash used in financing activities was $291.8 million, consisting of payments for repurchases of our common stock from the open market of $299.8 million, and employee taxes withheld and paid of $47.5 million upon vesting of restricted stock units, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $55.5 million.

[0001596532-24-000368:mdna:66]
During the nine months ended September 30, 2023, cash used in financing activities was $82.4 million, consisting of payments for repurchases of our common stock from the open market of $112.3 million, and employee taxes withheld and paid of $23.9 million upon vesting of restricted stock units, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $53.8 million.

[0001596532-24-000368:mdna:67]
[same as prior period, unchanged from 0001596532-24-000279:mdna:66]

[0001596532-24-000368:mdna:68]
From time to time, we repurchase shares of our common stock pursuant to the Repurchase Programs that are funded from working capital. The New Repurchase Program allows for repurchases of $1.2 billion through May 2027, but does not obligate us to acquire any of our common stock and may be suspended or discontinued by the company at any time without prior notice. During the three months ended September 30, 2024, we repurchased a total of $65.2 million worth of shares under our New Repurchase Program. As of September 30, 2024, the remaining authorized amount for repurchases under the New Repurchase Program was $1.0 billion. Refer to Note 6. Stockholders' Equity and Stock-based Compensation of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-24-000368:mdna:69]
Common Stock Split

[0001596532-24-000368:mdna:70]
Arista’s board of directors has approved a four-for-one forward stock split to make Arista’s common stock more accessible to a broader base of investors.

[0001596532-24-000368:mdna:71]
The four-for-one forward stock split will be effected through the filing of an amendment to Arista’s Amended and Restated Certificate of Incorporation that will proportionately increase the authorized shares of common stock.

[0001596532-24-000368:mdna:72]
Our stockholders will receive an additional three shares of common stock for each share held as of the effective time of the filing of the amendment on December 3, 2024. Prior to market open on December 4, 2024, trading is expected to commence on a split-adjusted basis.

[0001596532-24-000368:mdna:73]
[same as prior period, unchanged from 0001596532-24-000279:mdna:68]

[0001596532-24-000368:mdna:74]
[same as prior period, unchanged from 0001596532-24-000279:mdna:69]

[0001596532-24-000368:mdna:75]
[same as prior period, unchanged from 0001596532-24-000279:mdna:70]

[0001596532-24-000368:mdna:76]
[same as prior period, unchanged from 0001596532-24-000279:mdna:71]

[0001596532-24-000368:mdna:77]
Purchase obligations not recorded on our balance sheet represent an estimate of all non-cancellable open purchase orders and contractual obligations, made either directly by Arista or by our contract manufacturers on our behalf, in the ordinary course of business for which we have not received the goods or services. As of September 30, 2024, we had $2.4 billion of such purchase obligations, of which $2.0 billion are expected to be received within one year, and $0.4 billion are expected to be received after one year. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-24-000368:mdna:78]
[same as prior period, unchanged from 0001596532-24-000279:mdna:73]

[0001596532-24-000368:mdna:79]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of September 30, 2024, we had lease payment obligations, net of immaterial sublease income, of $69.8 million, with $24.1 million payable within one year.

[0001596532-24-000368:mdna:80]
[same as prior period, unchanged from 0001596532-24-000279:mdna:75]

[0001596532-24-000368:mdna:81]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office and lab space. The estimated capital expenditures related to this project is estimated to be approximately $15.0 million for the remainder of 2024, and $227.0 million to $252.0 million for the next two years, with construction expected to commence at the end of 2024.

[0001596532-24-000368:mdna:82]
[same as prior period, unchanged from 0001596532-24-000279:mdna:77]

[0001596532-24-000368:mdna:83]
As of September 30, 2024, we have recorded long-term tax liabilities of $116.6 million related to uncertain tax positions; however, we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-24-000368:mdna:84]
In connection with the Tax Cuts and Jobs Act of 2017 (“TCJA”), effective January 1, 2022, the TCJA eliminated the option to deduct research and development expenditures currently and requires taxpayers to capitalize and amortize them over five or fifteen years pursuant to IRC Section 174. We estimate the full year incremental cash tax impact resulting from these regulations to be approximately $210.0 million for 2024. It is anticipated that IRC Section 174 will result in cash tax outlays exceeding our income tax expense over the next two years unless the current legislation is changed. There has been no material change to our effective tax rate as a result of this legislation.

[0001596532-24-000368:mdna:85]
[same as prior period, unchanged from 0001596532-24-000279:mdna:82]

[0001596532-24-000368:mdna:86]
As of September 30, 2024, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-24-000368:mdna:87]
[same as prior period, unchanged from 0001596532-24-000279:mdna:84]

[0001596532-24-000368:mdna:88]
[same as prior period, unchanged from 0001596532-24-000279:mdna:85]

[0001596532-24-000368:mdna:89]
[same as prior period, unchanged from 0001596532-24-000279:mdna:86]

[0001596532-24-000368:mdna:90]
Refer to the subheading titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
