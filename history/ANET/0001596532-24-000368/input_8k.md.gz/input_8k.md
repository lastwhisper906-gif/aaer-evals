# ANET 8-K — 0001596532-24-000366 filed 2024-11-07

## item codes, every 8-K on or before 2024-11-08

- 2024-11-07 0001596532-24-000366 — 2.02, 8.01, 9.01
- 2024-07-30 0001596532-24-000277 — 2.02, 9.01
- 2024-06-10 0001596532-24-000233 — 5.07
- 2024-05-24 0001596532-24-000219 — 8.01
- 2024-05-07 0001596532-24-000171 — 2.02, 8.01, 9.01
- 2024-04-23 0001596532-24-000155 — 5.02, 9.01
- 2024-04-19 0001596532-24-000152 — 5.02, 8.01
- 2024-02-28 0001596532-24-000095 — 8.01
- 2024-02-12 0001596532-24-000041 — 2.02, 9.01
- 2023-12-20 0001596532-23-000349 — 5.03, 9.01
- 2023-12-01 0001596532-23-000324 — 5.02, 8.01, 9.01
- 2023-10-30 0001596532-23-000272 — 2.02, 9.01
- 2023-07-31 0001596532-23-000196 — 2.02, 5.02, 9.01
- 2023-06-16 0001596532-23-000168 — 5.07
- 2023-05-01 0001596532-23-000101 — 2.02, 9.01
- 2023-02-13 0001596532-23-000015 — 2.02, 9.01
- 2022-10-31 0001596532-22-000292 — 2.02, 9.01
- 2022-10-25 0001596532-22-000282 — 5.03, 9.01
- 2022-08-01 0001596532-22-000218 — 2.02, 9.01
- 2022-07-25 0001596532-22-000205 — 5.02
- 2022-06-03 0001596532-22-000179 — 5.07
- 2022-05-02 0001596532-22-000111 — 2.02, 9.01
- 2022-03-29 0001596532-22-000100 — 5.02
- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2024-11-08

- none on or before 2024-11-08

## item 2.02 — earnings release, exhibit 99.1

[0001596532-24-000366:8k_2_02:1]
EX-99.1
2
ex991q324-earningsrelease.htm
EX-99.1

[0001596532-24-000366:8k_2_02:2]
Document

[0001596532-24-000366:8k_2_02:3]
Exhibit 99.1

[0001596532-24-000366:8k_2_02:4]
Arista Networks, Inc. Reports Third Quarter 2024 Financial Results

[0001596532-24-000366:8k_2_02:5]
SANTA CLARA, Calif.- November 7, 2024 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus and routing environments, today announced financial results for its third quarter ended September 30, 2024.

[0001596532-24-000366:8k_2_02:6]
Third Quarter Financial Highlights

[0001596532-24-000366:8k_2_02:7]
“Arista remains at the forefront of next generation centers of data across client-to-cloud and AI focused locations,” said Jayshree Ullal, Chairperson and CEO of Arista Networks. “Our Q3 2024 results once again demonstrate our continued commitment to customer priorities as well as delivering strong financial results.”

[0001596532-24-000366:8k_2_02:8]
•Revenue of $1.811 billion, an increase of 7.1% compared to the second quarter of 2024, and an increase of 20.0% from the third quarter of 2023.

[0001596532-24-000366:8k_2_02:9]
•GAAP gross margin of 64.2%, compared to GAAP gross margin of 64.9% in the second quarter of 2024 and 62.4% in the third quarter of 2023.

[0001596532-24-000366:8k_2_02:10]
•Non-GAAP gross margin of 64.6%, compared to non-GAAP gross margin of 65.4% in the second quarter of 2024 and 63.1% in the third quarter of 2023.

[0001596532-24-000366:8k_2_02:11]
•GAAP net income of $747.9 million, or $2.33 per diluted share, compared to GAAP net income of $545.3 million, or $1.72 per diluted share in the third quarter of 2023.

[0001596532-24-000366:8k_2_02:12]
•Non-GAAP net income of $769.1 million, or $2.40 per diluted share, compared to non-GAAP net income of $581.4 million, or $1.83 per diluted share in the third quarter of 2023.

[0001596532-24-000366:8k_2_02:13]
Commenting on the company's financial results, Chantelle Breithaupt, Arista’s CFO said, "We are proud to report another quarter of strong revenue growth driven by our ability to consistently deliver innovation and value to customers and shareholders.”

[0001596532-24-000366:8k_2_02:14]
Company Highlights

[0001596532-24-000366:8k_2_02:15]
•Alabama Fiber Network Selects Arista Networks for Statewide Middle-Mile Initiative - Arista Networks announced that Alabama Fiber Network (AFN), a consortium of eight electric cooperatives, has selected Arista as its provider of routing and switching equipment for its robust middle-mile network project. This initiative delivers affordable, high-capacity and reliable internet access to last-mile providers and large enterprises throughout underserved rural areas across Alabama.

[0001596532-24-000366:8k_2_02:16]
•CloudVision Delivers Modern Network Operating Model Across the Enterprise - Arista Networks announced significant new capabilities in its CloudVision ® platform, enabling a modern network operating model for customers. Arista’s CloudVision dramatically simplifies operations with automation, observability and zero trust security capabilities across all enterprise networking domains, from campus to data center, WAN, and cloud.

[0001596532-24-000366:8k_2_02:17]
•Meta and Arista Build AI at Scale - The rise of the AI center has created greater demands on modern open networking. The Arista Etherlink portfolio delivers choices in form factor, scaling from single-chip systems to modular multi-chip, multi-tier networks that scale out to thousands of XPU ports. The 7700R4 Distributed Etherlink Switch offers simplicity and scalability with a cost-effective and power-efficient solution for the AI Center. We are thrilled with the close engineering collaboration with Meta for the new era of AI.

[0001596532-24-000366:8k_2_02:18]
Stock Split

[0001596532-24-000366:8k_2_02:19]
Arista’s board of directors has approved a four-for-one forward stock split to make Arista’s common stock more accessible to a broader base of investors.

[0001596532-24-000366:8k_2_02:20]
The four-for-one forward stock split will be effected through the filing of an amendment to Arista’s Amended and Restated Certificate of Incorporation that will proportionately increase the authorized shares of common stock.

[0001596532-24-000366:8k_2_02:21]
Our stockholders will receive an additional three shares of common stock for each share held as of the effective time of the filing of the amendment on December 3, 2024. Prior to market open on December 4, 2024, trading is expected to commence on a split-adjusted basis.

[0001596532-24-000366:8k_2_02:22]
Financial Outlook

[0001596532-24-000366:8k_2_02:23]
For the fourth quarter of 2024, we expect:

[0001596532-24-000366:8k_2_02:24]
•Revenue between $1.85 billion to $1.90 billion

[0001596532-24-000366:8k_2_02:25]
•Non-GAAP gross margin of approximately 63% - 64%; and

[0001596532-24-000366:8k_2_02:26]
•Non-GAAP operating margin of approximately 44%.

[0001596532-24-000366:8k_2_02:27]
Guidance for non-GAAP financial measures excludes certain items, including stock-based compensation expense, intangible asset amortization, and potential non-recurring charges or benefits. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis without unreasonable effort because these exclusions can be uncertain or difficult to predict, including stock-based compensation expense which is impacted by the timing of employee stock transactions, the company’s future hiring and retention needs and the future fair market value of the company’s common stock. The actual amount of these exclusions will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-24-000366:8k_2_02:28]
Prepared Materials and Conference Call Information

[0001596532-24-000366:8k_2_02:29]
Arista's executives will discuss the third quarter 2024 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-24-000366:8k_2_02:30]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-24-000366:8k_2_02:31]
Forward-Looking Statements

[0001596532-24-000366:8k_2_02:32]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the fourth quarter of 2024, statements regarding the benefits of Arista's products, statements about our ability to consistently deliver innovation and value to customers and shareholders, and statements relating to our planned forward stock split. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: large purchases by a limited number of customers who represent a substantial portion of our revenue; adverse economic and geopolitical conditions and conflicts, including inflationary pressures which result in increased component costs and reduced information technology and network infrastructure spending, geopolitical pressures and changes in the U.S. presidential administration; changes in our customers technology roadmaps and priorities including the need for the deployment of artificial intelligence (“AI”) and related technologies; the impact of sole or limited sources of supply, supply shortages and extended lead times or supply changes; volatility in our revenue growth rate; variations in our results of operations; the rapid evolution of the networking market; failure to successfully carry out new products and service offerings and expand into adjacent markets; variability in our gross margins; intense competition and industry consolidation; expansion of our

[0001596532-24-000366:8k_2_02:33]
international sales and operations; investments in or acquisitions of other businesses; seasonality and industry cyclicality; fluctuations in currency exchange rates; failure to raise additional capital on favorable terms; our inability to attract new large customers or sell additional products and services to our existing customers; sales of our switches generating most of our product revenue; large customers requiring more favorable terms; inability to increase market awareness or acceptance of our new products and services; the inclusion of any acceptance provisions in our customer contracts and any delays in acceptance, or rejection, of those products; decreases in the sales prices of our products and services; long and unpredictable sales cycles; declines in maintenance renewals by customers; product quality problems; failure to anticipate technological shifts; managing the supply of our products and product components; our dependence on third-party manufacturers to build our products; assertions by third parties of intellectual property rights infringement; failure or inability to protect or assert our intellectual property rights; defects, errors or vulnerabilities in our products, the failure of our products to detect security breaches or incidents, the misuse of our products or the risks or product liability; enhanced U.S. tax, tariff, import/export restrictions, Chinese regulations or other trade barriers; failure to comply with government law and regulations; issues in the development and use of artificial intelligence, combined with an uncertain regulatory environment; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-24-000366:8k_2_02:34]
Non-GAAP Financial Measures

[0001596532-24-000366:8k_2_02:35]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, intangible asset amortization, gains/losses on strategic investments, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-24-000366:8k_2_02:36]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-24-000366:8k_2_02:37]
3

[0001596532-24-000366:8k_2_02:38]
About Arista Networks

[0001596532-24-000366:8k_2_02:39]
Arista Networks is an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus and routing environments. Its award-winning platforms deliver availability, agility, automation, analytics, and security through an advanced network operating stack. For more information, visit www.arista.com.

[0001596532-24-000366:8k_2_02:40]
ARISTA, CloudVision and Etherlink are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-24-000366:8k_2_02:41]
ARISTA NETWORKS, INC.

[0001596532-24-000366:8k_2_02:42]
Condensed Consolidated Income Statements

[0001596532-24-000366:8k_2_02:43]
(Unaudited, in thousands, except per share amounts)

[0001596532-24-000366:8k_2_02:44]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,523,807 |  |  | $ | 1,285,548 |  |  | $ | 4,275,923 |  |  | $ | 3,719,179 |  |
| Service |  | 287,129 |  |  | 223,908 |  |  | 796,787 |  |  | 600,552 |  |
| Total revenue |  | 1,810,936 |  |  | 1,509,456 |  |  | 5,072,710 |  |  | 4,319,731 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 593,343 |  |  | 522,866 |  |  | 1,655,415 |  |  | 1,565,341 |  |
| Service |  | 55,876 |  |  | 44,171 |  |  | 156,986 |  |  | 123,335 |  |
| Total cost of revenue |  | 649,219 |  |  | 567,037 |  |  | 1,812,401 |  |  | 1,688,676 |  |
| Gross profit |  | 1,161,717 |  |  | 942,419 |  |  | 3,260,309 |  |  | 2,631,055 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 235,824 |  |  | 212,353 |  |  | 711,701 |  |  | 643,437 |  |
| Sales and marketing |  | 106,832 |  |  | 102,033 |  |  | 316,315 |  |  | 293,496 |  |
| General and administrative |  | 33,811 |  |  | 25,338 |  |  | 87,329 |  |  | 76,787 |  |
| Total operating expenses |  | 376,467 |  |  | 339,724 |  |  | 1,115,345 |  |  | 1,013,720 |  |
| Income from operations |  | 785,250 |  |  | 602,695 |  |  | 2,144,964 |  |  | 1,617,335 |  |
| Other income (expense), net |  | 97,660 |  |  | 41,815 |  |  | 231,143 |  |  | 110,300 |  |
| Income before income taxes |  | 882,910 |  |  | 644,510 |  |  | 2,376,107 |  |  | 1,727,635 |  |
| Provision for income taxes |  | 134,972 |  |  | 99,183 |  |  | 325,049 |  |  | 253,950 |  |
| Net income |  | $ | 747,938 |  |  | $ | 545,327 |  |  | $ | 2,051,058 |  |  | $ | 1,473,685 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.38 |  |  | $ | 1.76 |  |  | $ | 6.54 |  |  | $ | 4.78 |  |
| Diluted |  | $ | 2.33 |  |  | $ | 1.72 |  |  | $ | 6.41 |  |  | $ | 4.66 |  |
| Weighted-average shares used in computing net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 314,482 |  |  | 310,185 |  |  | 313,742 |  |  | 308,602 |  |
| Diluted |  | 320,448 |  |  | 317,631 |  |  | 320,078 |  |  | 316,564 |  |

[0001596532-24-000366:8k_2_02:45]
5

[0001596532-24-000366:8k_2_02:46]
ARISTA NETWORKS, INC.

[0001596532-24-000366:8k_2_02:47]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-24-000366:8k_2_02:48]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-24-000366:8k_2_02:49]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| GAAP gross profit |  | $ | 1,161,717 |  |  | $ | 942,419 |  |  | $ | 3,260,309 |  |  | $ | 2,631,055 |  |
| GAAP gross margin |  | 64.2 | % |  | 62.4 | % |  | 64.3 | % |  | 60.9 | % |
| Stock-based compensation expense |  | 4,098 |  |  | 3,717 |  |  | 11,531 |  |  | 9,516 |  |
| Intangible asset amortization |  | 4,195 |  |  | 5,622 |  |  | 12,585 |  |  | 19,262 |  |
| Non-GAAP gross profit |  | $ | 1,170,010 |  |  | $ | 951,758 |  |  | $ | 3,284,425 |  |  | $ | 2,659,833 |  |
| Non-GAAP gross margin |  | 64.6 | % |  | 63.1 | % |  | 64.7 | % |  | 61.6 | % |
| GAAP income from operations |  | $ | 785,250 |  |  | $ | 602,695 |  |  | $ | 2,144,964 |  |  | $ | 1,617,335 |  |
| Stock-based compensation expense |  | 98,123 |  |  | 85,390 |  |  | 254,630 |  |  | 215,398 |  |
| Intangible asset amortization |  | 6,690 |  |  | 8,117 |  |  | 20,070 |  |  | 26,747 |  |
| Non-GAAP income from operations |  | $ | 890,063 |  |  | $ | 696,202 |  |  | $ | 2,419,664 |  |  | $ | 1,859,480 |  |
| Non-GAAP operating margin |  | 49.1 | % |  | 46.1 | % |  | 47.7 | % |  | 43.0 | % |
| GAAP net income |  | $ | 747,938 |  |  | $ | 545,327 |  |  | $ | 2,051,058 |  |  | $ | 1,473,685 |  |
| Stock-based compensation expense |  | 98,123 |  |  | 85,390 |  |  | 254,630 |  |  | 215,398 |  |
| Intangible asset amortization |  | 6,690 |  |  | 8,117 |  |  | 20,070 |  |  | 26,747 |  |
| (Gain)/loss on strategic investments |  | (12,400) |  |  | 473 |  |  | (12,400) |  |  | (18,699) |  |
| Tax benefits on stock-based awards |  | (57,698) |  |  | (45,667) |  |  | (193,079) |  |  | (133,561) |  |
| Income tax effect on non-GAAP exclusions |  | (13,598) |  |  | (12,253) |  |  | (40,864) |  |  | (28,488) |  |
| Non-GAAP net income |  | $ | 769,055 |  |  | $ | 581,387 |  |  | $ | 2,079,415 |  |  | $ | 1,535,082 |  |
| GAAP diluted net income per share |  | $ | 2.33 |  |  | $ | 1.72 |  |  | $ | 6.41 |  |  | $ | 4.66 |  |
| Non-GAAP adjustments to net income |  | 0.07 |  |  | 0.11 |  |  | 0.09 |  |  | 0.19 |  |
| Non-GAAP diluted net income per share |  | $ | 2.40 |  |  | $ | 1.83 |  |  | $ | 6.50 |  |  | $ | 4.85 |  |
| Weighted-average shares used in computing diluted net income per share |  | 320,448 |  |  | 317,631 |  |  | 320,078 |  |  | 316,564 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 4,098 |  |  | $ | 3,717 |  |  | $ | 11,531 |  |  | $ | 9,516 |  |
| Research and development |  | 58,340 |  |  | 47,965 |  |  | 152,897 |  |  | 125,671 |  |
| Sales and marketing |  | 20,960 |  |  | 20,490 |  |  | 56,630 |  |  | 51,461 |  |
| General and administrative |  | 14,725 |  |  | 13,218 |  |  | 33,572 |  |  | 28,750 |  |
| Total |  | $ | 98,123 |  |  | $ | 85,390 |  |  | $ | 254,630 |  |  | $ | 215,398 |  |

[0001596532-24-000366:8k_2_02:50]
ARISTA NETWORKS, INC.

[0001596532-24-000366:8k_2_02:51]
Condensed Consolidated Balance Sheets

[0001596532-24-000366:8k_2_02:52]
(Unaudited, in thousands)

[0001596532-24-000366:8k_2_02:53]
|  |  | September 30, 2024 |  | December 31, 2023 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,175,139 |  |  | $ | 1,938,606 |  |
| Marketable securities |  | 4,253,249 |  |  | 3,069,362 |  |
| Accounts receivable, net |  | 1,130,897 |  |  | 1,034,398 |  |
| Inventories |  | 1,769,962 |  |  | 1,945,180 |  |
| Prepaid expenses and other current assets |  | 548,693 |  |  | 412,518 |  |
| Total current assets |  | 10,877,940 |  |  | 8,400,064 |  |
| Property and equipment, net |  | 93,034 |  |  | 101,580 |  |
| Goodwill and acquisition-related intangible assets, net |  | 337,230 |  |  | 357,299 |  |
| Deferred tax assets |  | 1,318,224 |  |  | 945,792 |  |
| Other assets |  | 220,295 |  |  | 151,900 |  |
| TOTAL ASSETS |  | $ | 12,846,723 |  |  | $ | 9,956,635 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 289,161 |  |  | $ | 435,059 |  |
| Accrued liabilities |  | 323,990 |  |  | 407,302 |  |
| Deferred revenue |  | 1,599,590 |  |  | 915,204 |  |
| Other current liabilities |  | 221,633 |  |  | 161,870 |  |
| Total current liabilities |  | 2,434,374 |  |  | 1,919,435 |  |
| Income taxes payable |  | 116,604 |  |  | 95,751 |  |
| Deferred revenue, non-current |  | 907,741 |  |  | 591,000 |  |
| Other long-term liabilities |  | 142,115 |  |  | 131,390 |  |
| TOTAL LIABILITIES |  | 3,600,834 |  |  | 2,737,576 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 31 |  |  | 31 |  |
| Additional paid-in capital |  | 2,371,010 |  |  | 2,108,331 |  |
| Retained earnings |  | 6,865,260 |  |  | 5,114,025 |  |
| Accumulated other comprehensive income (loss) |  | 9,588 |  |  | (3,328) |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 9,245,889 |  |  | 7,219,059 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 12,846,723 |  |  | $ | 9,956,635 |  |

[0001596532-24-000366:8k_2_02:54]
7

[0001596532-24-000366:8k_2_02:55]
ARISTA NETWORKS, INC.

[0001596532-24-000366:8k_2_02:56]
Condensed Consolidated Statements of Cash Flows

[0001596532-24-000366:8k_2_02:57]
(Unaudited, in thousands)

[0001596532-24-000366:8k_2_02:58]
|  |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 2,051,058 |  |  | $ | 1,473,685 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  | 46,650 |  |  | 56,233 |  |
| Stock-based compensation |  | 254,630 |  |  | 215,398 |  |
| Deferred income taxes |  | (376,726) |  |  | (217,489) |  |
| Amortization (accretion) of investment premiums (discounts) |  | (44,609) |  |  | (22,389) |  |
| Other |  | 1,921 |  |  | (5,084) |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (96,499) |  |  | 84,379 |  |
| Inventories |  | 175,218 |  |  | (603,832) |  |
| Other assets |  | (173,119) |  |  | (118,622) |  |
| Accounts payable |  | (142,005) |  |  | 33,740 |  |
| Accrued liabilities |  | (84,565) |  |  | 117,481 |  |
| Deferred revenue |  | 1,001,127 |  |  | 153,505 |  |
| Income taxes, net |  | 59,763 |  |  | 346,170 |  |
| Other liabilities |  | 4,428 |  |  | (5,625) |  |
| Net cash provided by operating activities |  | 2,677,272 |  |  | 1,507,550 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 1,427,348 |  |  | 1,564,950 |  |
| Proceeds from sales of marketable securities |  | 44,865 |  |  | 49,584 |  |
| Purchases of marketable securities |  | (2,593,418) |  |  | (1,934,156) |  |
| Purchases of property and equipment |  | (19,580) |  |  | (28,424) |  |
| Other investing activities |  | (6,628) |  |  | (2,451) |  |
| Net cash used in investing activities |  | (1,147,413) |  |  | (350,497) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 55,501 |  |  | 53,797 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (47,452) |  |  | (23,939) |  |
| Repurchases of common stock |  | (299,823) |  |  | (112,279) |  |
| Net cash used in financing activities |  | (291,774) |  |  | (82,421) |  |
| Effect of exchange rate changes |  | (1,011) |  |  | (934) |  |
| NET INCREASE IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 1,237,074 |  |  | 1,073,698 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 1,939,464 |  |  | 675,978 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 3,176,538 |  |  | $ | 1,749,676 |  |

[0001596532-24-000366:8k_2_02:59]
Investor Contacts:

[0001596532-24-000366:8k_2_02:60]
Arista Networks, Inc.

[0001596532-24-000366:8k_2_02:61]
Liz Stine, 408-547-5885

[0001596532-24-000366:8k_2_02:62]
Investor Relations

[0001596532-24-000366:8k_2_02:63]
IRevents@arista.com
