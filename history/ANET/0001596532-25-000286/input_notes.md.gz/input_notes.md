# ANET notes — 0001596532-25-000286


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-25-000286:notes:1]
[same as prior period, unchanged from 0001596532-25-000216:notes:1]

[0001596532-25-000286:notes:2]
[same as prior period, unchanged from 0001596532-25-000216:notes:2]

[0001596532-25-000286:notes:3]
[same as prior period, unchanged from 0001596532-25-000216:notes:3]

[0001596532-25-000286:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and our wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2025, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2024 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated. Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.

[0001596532-25-000286:notes:5]
[same as prior period, unchanged from 0001596532-25-000216:notes:5]

[0001596532-25-000286:notes:6]
[same as prior period, unchanged from 0001596532-25-000216:notes:6]

[0001596532-25-000286:notes:7]
[same as prior period, unchanged from 0001596532-25-000216:notes:7]

[0001596532-25-000286:notes:8]
[same as prior period, unchanged from 0001596532-25-000216:notes:8]

[0001596532-25-000286:notes:9]
[same as prior period, unchanged from 0001596532-25-000216:notes:9]

[0001596532-25-000286:notes:10]
In December 2023, the Financial Accounting Standards Board ("FASB") issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2024. Early adoption is permitted for annual financial statements that have not yet been issued. The amendments should be applied on a prospective basis although retrospective application is permitted. We will adopt the standard in our 2025 annual period using a prospective transition method.

[0001596532-25-000286:notes:11]
In November 2024, the FASB issued ASU 2024-03, Disaggregation of Income Statement Expenses (Subtopic 220-40). The ASU requires the disaggregated disclosure of specific expense categories, including purchases of inventory, employee

[0001596532-25-000286:notes:12]
compensation, depreciation, and amortization, within relevant income statement captions. This ASU also requires disclosure of the total amount of selling expenses along with the definition of selling expenses. The ASU is effective for annual periods beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027. Adoption of this ASU can either be applied prospectively to consolidated financial statements issued for reporting periods after the effective date of this ASU or retrospectively to any or all prior periods presented in the consolidated financial statements. Early adoption is also permitted. This ASU will likely result in the required additional disclosures being included in our consolidated financial statements, once adopted. We are currently evaluating the impact of future adoption on our financial statement disclosures.
In July 2025, the FASB issued ASU 2025-05 Financial Instruments - Credit Losses (Topic 326) Measurement of Credit Losses for Accounts Receivable and Contract Assets, or ASU 2025-05. The ASU provides a practical expedient that allows entities to assume that current conditions as of the balance sheet date do not change for the remaining life of the asset when estimating expected credit losses for current accounts receivable and current contract assets. The amendments of ASU 2025-05 should be applied prospectively and are effective for annual and interim periods beginning after December 15, 2025, with early adoption permitted. We do not expect the adoption of ASU 2025-05 to have a material impact on our consolidated financial statements and related disclosures.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-25-000286:notes:13]
Fair Value Measurements 
Assets measured at fair values on a recurring basis

[0001596532-25-000286:notes:14]
[same as prior period, unchanged from 0001596532-25-000216:notes:14]

[0001596532-25-000286:notes:15]
|  |  | September 30, 2025 |  | December 31, 2024 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 896.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 896.1 |  |  | $ | 1,707.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,707.5 |  |
| Commercial paper |  | — |  |  | 5.0 |  |  | — |  |  | 5.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government notes |  | 129.9 |  |  | — |  |  | — |  |  | 129.9 |  |  | 31.4 |  |  | — |  |  | — |  |  | 31.4 |  |
| Agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3.0 |  |  | — |  |  | 3.0 |  |
|  |  | 1,026.0 |  |  | 5.0 |  |  | — |  |  | 1,031.0 |  |  | 1,738.9 |  |  | 3.0 |  |  | — |  |  | 1,741.9 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 37.3 |  |  | — |  |  | 37.3 |  |  | — |  |  | 48.8 |  |  | — |  |  | 48.8 |  |
| U.S. government notes |  | 2,618.6 |  |  | — |  |  | — |  |  | 2,618.6 |  |  | 1,921.5 |  |  | — |  |  | — |  |  | 1,921.5 |  |
| Corporate bonds |  | — |  |  | 3,760.9 |  |  | — |  |  | 3,760.9 |  |  | — |  |  | 2,593.6 |  |  | — |  |  | 2,593.6 |  |
| Municipal bonds |  | — |  |  | 9.8 |  |  | — |  |  | 9.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Agency securities |  | — |  |  | 1,353.0 |  |  | — |  |  | 1,353.0 |  |  | — |  |  | 977.2 |  |  | — |  |  | 977.2 |  |
|  |  | 2,618.6 |  |  | 5,161.0 |  |  | — |  |  | 7,779.6 |  |  | 1,921.5 |  |  | 3,619.6 |  |  | — |  |  | 5,541.1 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 1.4 |  |  | — |  |  | — |  |  | 1.4 |  |  | 1.4 |  |  | — |  |  | — |  |  | 1.4 |  |
| Total Financial Assets |  | $ | 3,646.0 |  |  | $ | 5,166.0 |  |  | $ | — |  |  | $ | 8,812.0 |  |  | $ | 3,661.8 |  |  | $ | 3,622.6 |  |  | $ | — |  |  | $ | 7,284.4 |  |

[0001596532-25-000286:notes:16]
During the three and nine months ended September 30, 2025, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-25-000286:notes:17]
[same as prior period, unchanged from 0001596532-25-000216:notes:17]

[0001596532-25-000286:notes:18]
[same as prior period, unchanged from 0001596532-25-000216:notes:18]

[0001596532-25-000286:notes:19]
|  |  | September 30, 2025 |  | December 31, 2024 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 42.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 42.3 |  |  | $ | 48.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 48.8 |  |
| U.S. government |  | 2,742.0 |  |  | 7.1 |  |  | (0.6) |  |  | 2,748.5 |  |  | 1,954.8 |  |  | 2.7 |  |  | (4.6) |  |  | 1,952.9 |  |
| Corporate bonds |  | 3,748.8 |  |  | 13.7 |  |  | (1.6) |  |  | 3,760.9 |  |  | 2,595.7 |  |  | 4.4 |  |  | (6.5) |  |  | 2,593.6 |  |
| Municipal bonds |  | 9.8 |  |  | — |  |  | — |  |  | 9.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Agency securities |  | 1,351.3 |  |  | 2.3 |  |  | (0.6) |  |  | 1,353.0 |  |  | 981.0 |  |  | 1.6 |  |  | (2.4) |  |  | 980.2 |  |
| Total |  | $ | 7,894.2 |  |  | $ | 23.1 |  |  | $ | (2.8) |  |  | $ | 7,914.5 |  |  | $ | 5,580.3 |  |  | $ | 8.7 |  |  | $ | (13.5) |  |  | $ | 5,575.5 |  |

[0001596532-25-000286:notes:20]
For debt securities in unrealized loss positions, it is not likely that we will be required to sell such securities before recovery of their amortized cost basis nor do we have the intent to sell such securities before maturity. We invest in debt securities that have maximum maturities of three years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these debt securities, the more susceptible they are to changes in market interest rates and bond yields. Given the short-term and conservative nature of our portfolio, our debt securities are generally not subject to credit risk; therefore, we did not recognize any credit losses or non-credit-related impairments related to such securities for the three and nine months ended September 30, 2025. All unrealized losses were recognized in other comprehensive income (loss). Realized gains or losses were immaterial for the three and nine months ended September 30, 2025.

[0001596532-25-000286:notes:21]
[same as prior period, unchanged from 0001596532-25-000216:notes:21]

[0001596532-25-000286:notes:22]
|  |  | September 30, 2025 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| Commercial paper |  | $ | 9.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 9.8 |  |  | $ | — |  |
| U.S. government notes |  | 882.7 |  |  | (0.5) |  |  | 46.6 |  |  | (0.1) |  |  | 929.3 |  |  | (0.6) |  |
| Corporate bonds |  | 833.8 |  |  | (1.6) |  |  | 19.2 |  |  | — |  |  | 853.0 |  |  | (1.6) |  |
| Agency securities |  | 415.3 |  |  | (0.6) |  |  | 11.9 |  |  | — |  |  | 427.2 |  |  | (0.6) |  |
| Total |  | $ | 2,141.6 |  |  | $ | (2.7) |  |  | $ | 77.7 |  |  | $ | (0.1) |  |  | $ | 2,219.3 |  |  | $ | (2.8) |  |

[0001596532-25-000286:notes:23]
As of September 30, 2025, we had no marketable debt securities with contractual maturities that exceeded three years. The fair values of marketable debt securities, by remaining contractual maturities, are as follows (in millions):

[0001596532-25-000286:notes:24]
|  |  | September 30, 2025 |
|  |  | Fair Value |
| Due in 1 year or less |  | $ | 2,893.3 |  |
| Due in 1 to 3 years |  | 4,886.3 |  |
| Total debt securities |  | $ | 7,779.6 |  |

[0001596532-25-000286:notes:25]
The weighted-average remaining duration of our marketable debt securities is approximately 1.4 years as of September 30, 2025. As we view these marketable debt securities as available to support current operations, we classify marketable debt securities with maturities beyond 12 months as current assets under the caption "Marketable securities" on the condensed consolidated balance sheets.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-25-000286:notes:26]
[same as prior period, unchanged from 0001596532-25-000216:notes:26]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-25-000286:notes:27]
[same as prior period, unchanged from 0001596532-25-000216:notes:27]

[0001596532-25-000286:notes:28]
[same as prior period, unchanged from 0001596532-25-000216:notes:28]

[0001596532-25-000286:notes:29]
|  |  | September 30, 2025 |  | December 31, 2024 |
| Raw materials |  | $ | 650.6 |  |  | $ | 565.4 |  |
| Finished goods(1) |  | 1,505.1 |  |  | 1,269.2 |  |
| Total inventories |  | $ | 2,155.7 |  |  | $ | 1,834.6 |  |

[0001596532-25-000286:notes:30]
(1) The balance includes evaluation inventory totaling $427.3 million and $422.1 million as of September 30, 2025 and December 31, 2024, respectively.

[0001596532-25-000286:notes:31]
[same as prior period, unchanged from 0001596532-25-000216:notes:31]

[0001596532-25-000286:notes:32]
[same as prior period, unchanged from 0001596532-25-000216:notes:32]

[0001596532-25-000286:notes:33]
|  |  | September 30, 2025 |  | December 31, 2024 |
| Land |  | $ | 47.3 |  |  | $ | 47.2 |  |
| Equipment and machinery |  | 178.4 |  |  | 160.7 |  |
| Computer hardware and software |  | 65.9 |  |  | 63.9 |  |
| Leasehold improvements |  | 37.0 |  |  | 34.7 |  |
| Furniture and fixtures |  | 3.7 |  |  | 3.5 |  |
| Construction-in-process |  | 81.1 |  |  | 8.2 |  |
| Property and equipment, gross |  | 413.4 |  |  | 318.2 |  |
| Less: accumulated depreciation |  | (240.8) |  |  | (219.4) |  |
| Property and equipment, net |  | $ | 172.6 |  |  | $ | 98.8 |  |

[0001596532-25-000286:notes:34]
Depreciation expense was $7.4 million and $8.5 million for the three months ended September 30, 2025 and 2024, respectively, and $23.2 million and $25.6 million for the nine months ended September 30, 2025 and 2024, respectively.

[0001596532-25-000286:notes:35]
[same as prior period, unchanged from 0001596532-25-000216:notes:35]

[0001596532-25-000286:notes:36]
[same as prior period, unchanged from 0001596532-25-000216:notes:36]

[0001596532-25-000286:notes:37]
[same as prior period, unchanged from 0001596532-25-000216:notes:37]

[0001596532-25-000286:notes:38]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Contract liabilities, beginning balance |  | $ | 188.1 |  |  | $ | 144.1 |  |  | $ | 160.8 |  |  | $ | 133.2 |  |
| Less: Revenue recognized from beginning balance |  | (26.9) |  |  | (12.7) |  |  | (49.0) |  |  | (44.7) |  |
| Add: Contract liabilities recognized, net |  | 25.6 |  |  | 15.6 |  |  | 75.0 |  |  | 58.5 |  |
| Contract liabilities, ending balance |  | $ | 186.8 |  |  | $ | 147.0 |  |  | $ | 186.8 |  |  | $ | 147.0 |  |

[0001596532-25-000286:notes:39]
As of September 30, 2025 and December 31, 2024, $78.5 million and $65.7 million of our contract liabilities, respectively, were included in "Other current liabilities" with the remaining balances included in "Other long-term liabilities" on the condensed consolidated balance sheets.

[0001596532-25-000286:notes:40]
[same as prior period, unchanged from 0001596532-25-000216:notes:40]

[0001596532-25-000286:notes:41]
Deferred revenue is comprised mainly of unearned revenue related to multi-year post-contract support ("PCS") contracts and product deferrals related to contracts with acceptance clauses. The following table summarizes the activity related to our deferred revenue (in millions):

[0001596532-25-000286:notes:42]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Deferred revenue, beginning balance |  | $ | 4,061.7 |  |  | $ | 2,118.8 |  |  | $ | 2,791.4 |  |  | $ | 1,506.2 |  |
| Less: Revenue recognized from beginning balance |  | (699.7) |  |  | (249.3) |  |  | (1,094.5) |  |  | (616.3) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 1,324.2 |  |  | 637.8 |  |  | 2,989.3 |  |  | 1,617.4 |  |
| Deferred revenue, ending balance |  | $ | 4,686.2 |  |  | $ | 2,507.3 |  |  | $ | 4,686.2 |  |  | $ | 2,507.3 |  |

[0001596532-25-000286:notes:43]
[same as prior period, unchanged from 0001596532-25-000216:notes:43]

[0001596532-25-000286:notes:44]
Other performance obligations totaling $465.9 million as of September 30, 2025 include unbilled multi-year PCS and service contract amounts of $377.2 million, and $88.7 million of binding contractual agreements with certain customers that are primarily related to future product shipments.

[0001596532-25-000286:notes:45]
[same as prior period, unchanged from 0001596532-25-000216:notes:45]

[0001596532-25-000286:notes:46]
Total revenue from our contract liabilities, deferred revenue and other performance obligations that is expected to be recognized in future periods amounts to $5.3 billion as of September 30, 2025. Approximately 90% of this future revenue is expected to be recognized over the next two years and the remaining 10% is expected to be recognized during the third to the fifth year.

[0001596532-25-000286:notes:47]
[same as prior period, unchanged from 0001596532-25-000216:notes:47]

[0001596532-25-000286:notes:48]
[same as prior period, unchanged from 0001596532-25-000216:notes:48]

[0001596532-25-000286:notes:49]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Interest income |  | $ | 99.8 |  |  | $ | 85.4 |  |  | $ | 280.4 |  |  | $ | 220.6 |  |
| Other income (expense), net |  | (0.9) |  |  | 12.2 |  |  | 8.7 |  |  | 10.5 |  |
| Total |  | $ | 98.9 |  |  | $ | 97.6 |  |  | $ | 289.1 |  |  | $ | 231.1 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-25-000286:notes:50]
[same as prior period, unchanged from 0001596532-25-000216:notes:50]

[0001596532-25-000286:notes:51]
[same as prior period, unchanged from 0001596532-25-000216:notes:51]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-25-000286:notes:52]
Acquisition
On June 30, 2025, we completed the acquisition of the VeloCloud business ("VeloCloud") from Broadcom for total cash consideration of $300.0 million. VeloCloud's secure, AI-optimized cloud WAN portfolio provides seamless connectivity to customer sites of any type, complementing Arista's leading data center and campus wired/wireless portfolio. The preliminary purchase price allocation based on the estimated fair values of the assets acquired and liabilities assumed as of the acquisition date, included $268.4 million of intangible assets, $148.0 million of goodwill and $116.4 million of net tangible liabilities assumed as of June 30, 2025. A portion of the goodwill is deductible for tax purposes. The change in the carrying value of goodwill for the three months ended September 30, 2025 was not material.

[0001596532-25-000286:notes:53]
[same as prior period, unchanged from 0001596532-25-000216:notes:53]

[0001596532-25-000286:notes:54]
Acquisition-related intangible assets, included in other assets, are subject to amortization on a straight-line basis over their estimated useful lives, as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. Acquisition-related intangible assets, excluding those that are fully amortized and no longer have economic benefit, were as follows (in millions, except years):

[0001596532-25-000286:notes:55]
|  |  | September 30, 2025 |  | December 31, 2024 |
|  |  | Weighted-Average Remaining Useful Lives (in years) |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  |
| Developed technology |  | 4.3 |  | $ | 241.1 |  |  | $ | (132.0) |  |  | $ | 109.1 |  |  | $ | 154.9 |  |  | $ | (119.2) |  |  | $ | 35.7 |  |  |
| Customer relationships |  | 6.4 |  | 224.3 |  |  | (41.2) |  |  | 183.1 |  |  | 54.6 |  |  | (29.5) |  |  | 25.1 |  |  |
| Trade name |  | 4.8 |  | 24.9 |  |  | (13.0) |  |  | 11.9 |  |  | 12.4 |  |  | (11.2) |  |  | 1.2 |  |  |
| Total |  | 5.6 |  | $ | 490.3 |  |  | $ | (186.2) |  |  | $ | 304.1 |  |  | $ | 221.9 |  |  | $ | (159.9) |  |  | $ | 62.0 |  |  |

[0001596532-25-000286:notes:56]
[same as prior period, unchanged from 0001596532-25-000216:notes:56]

[0001596532-25-000286:notes:57]
|  |  | Future Amortization Expense |
| Remainder of 2025 |  | $ | 15.3 |  |
| 2026 |  | 61.3 |  |
| 2027 |  | 57.4 |  |
| 2028 |  | 54.0 |  |
| 2029 and thereafter |  | 116.1 |  |
| Total |  | $ | 304.1 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-25-000286:notes:58]
Commitments and Contingencies
Purchase Commitments

[0001596532-25-000286:notes:59]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of purchase orders to our contract manufacturers for finished products consist of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2025, we had non-cancellable purchase commitments not recorded on our balance sheet of $4.8 billion, of which $4.3 billion have expected receipt dates within 12 months, and $0.5 billion have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-25-000286:notes:60]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $50.1 million and $95.8 million as of September 30, 2025 and December 31, 2024, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

[0001596532-25-000286:notes:61]
Property Project

[0001596532-25-000286:notes:62]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office, lab and data center space. As of September 30, 2025, the estimated remaining capital expenditures related to this project are expected to be approximately $170.0 million to $200.0 million through the end of fiscal 2026 when we expect construction to be completed.

[0001596532-25-000286:notes:63]
Guarantees

[0001596532-25-000286:notes:64]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-25-000286:notes:65]
Legal Proceedings

[0001596532-25-000286:notes:66]
In the ordinary course of business, we are a party to various claims, litigation and other legal proceedings, including matters relating to intellectual property and patent disputes.

[0001596532-25-000286:notes:67]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2025, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-25-000286:notes:68]
[same as prior period, unchanged from 0001596532-25-000216:notes:73]

[0001596532-25-000286:notes:69]
In May 2025 we completed repurchases under our previous $1.2 billion stock repurchase program (the "Prior Repurchase Program") and our board of directors authorized a new $1.5 billion stock repurchase program (the “New Repurchase Program”, and together with the Prior Repurchase Program, the "Repurchase Programs"). This authorization allows us to repurchase shares of our common stock that will be funded from working capital. Repurchases may be made at management's discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the "Exchange Act"), or a combination of the foregoing. The New Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the Company at any time

[0001596532-25-000286:notes:70]
without prior notice. We did not repurchase any shares during the three months ended September 30, 2025. During the nine months ended September 30, 2025, we repurchased a total of $921.0 million of our common stock under our Prior Repurchase Program and $62.0 million of our common stock under our New Repurchase Program. As of September 30, 2025, the remaining authorized amount for repurchases under the New Repurchase Program was $1.4 billion.

[0001596532-25-000286:notes:71]
A summary of the stock repurchase activity under the Repurchase Programs for the nine months ended September 30, 2025 is as follows (in millions, except per share amounts):

[0001596532-25-000286:notes:72]
|  |  |  |  | Nine Months Ended |
|  |  |  |  | September 30, 2025 |
| Aggregate purchase price |  |  |  | $ | 983.0 |  |
| Shares repurchased |  |  |  | 11.1 |  |
| Average price paid per share |  |  |  | $ | 88.7 |  |

[0001596532-25-000286:notes:73]
[same as prior period, unchanged from 0001596532-25-000216:notes:77]

[0001596532-25-000286:notes:74]
[same as prior period, unchanged from 0001596532-25-000216:notes:78]

[0001596532-25-000286:notes:75]
[same as prior period, unchanged from 0001596532-25-000216:notes:79]

[0001596532-25-000286:notes:76]
In April 2014, our board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (“ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding on the immediately preceding December 31, but not to exceed 40 million shares, unless our board of directors, in its discretion, determines to make a smaller increase. As of September 30, 2025, there remained approximately 104.1 million shares available for issuance under the ESPP.

[0001596532-25-000286:notes:77]
[same as prior period, unchanged from 0001596532-25-000216:notes:81]

[0001596532-25-000286:notes:78]
During the nine months ended September 30, 2025, we issued 0.7 million shares at a weighted-average purchase price of $67.27 per share under the ESPP.

[0001596532-25-000286:notes:79]
[same as prior period, unchanged from 0001596532-25-000216:notes:83]

[0001596532-25-000286:notes:80]
[same as prior period, unchanged from 0001596532-25-000216:notes:84]

[0001596532-25-000286:notes:81]
The Restated Plan provides for the grant of equity-based awards, including stock options, restricted stock units, restricted stock, stock appreciation rights, and performance awards. The share pool available under the prior version of the Company's 2014 Equity Incentive Plan ("Prior Plan") was extinguished, and the Restated Plan provides for a new share pool not to exceed (i) 52.8 million shares of our Common Stock (“Shares”), plus (ii) any Shares subject to awards under the Prior Plan that, on or after the Effective Date, expired or otherwise terminated without having been exercised in full, or that were forfeited to or repurchased by us, including net settlement of Shares subject to restricted stock units, with the maximum number of Shares to be added to the Restated Plan as a result of clause (ii) equal to 40.2 million Shares. The Restated Plan’s terms are substantially similar to the Prior Plan’s terms, including with respect to treatment of equity awards in the event of a “change in control” as defined under the Restated Plan, but with certain modifications, including the elimination of the automatic “evergreen” share reserve increase provided for under the Prior Plan. As of September 30, 2025, there remained approximately 45.7 million shares available for grant under the Restated Plan.

[0001596532-25-000286:notes:82]
[same as prior period, unchanged from 0001596532-25-000216:notes:86]

[0001596532-25-000286:notes:83]
[same as prior period, unchanged from 0001596532-25-000216:notes:87]

[0001596532-25-000286:notes:84]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2024 |  | 3.1 |  |  | $ | 6.71 |  |  | 1.5 |  | $ | 320.9 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (2.1) |  |  | 3.99 |  |  |  |  |  |
| Options canceled |  | (0.1) |  |  | 14.70 |  |  |  |  |  |
| Balance—September 30, 2025 |  | 0.9 |  |  | $ | 11.74 |  |  | 2.6 |  | $ | 126.4 |  |
| Vested and exercisable—September 30, 2025 |  | 0.9 |  |  | $ | 11.74 |  |  | 2.6 |  | $ | 126.4 |  |

[0001596532-25-000286:notes:85]
[same as prior period, unchanged from 0001596532-25-000216:notes:89]

[0001596532-25-000286:notes:86]
[same as prior period, unchanged from 0001596532-25-000216:notes:90]

[0001596532-25-000286:notes:87]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |
| Unvested balance—December 31, 2024 |  | 28.6 |  |  | $ | 45.46 |  |
| RSUs and PRSUs granted |  | 9.6 |  |  | 98.29 |  |
| RSUs and PRSUs vested |  | (6.7) |  |  | 35.82 |  |
| RSUs and PRSUs forfeited/canceled |  | (2.2) |  |  | 48.65 |  |
| Unvested balance—September 30, 2025 |  | 29.3 |  |  | $ | 65.18 |  |

[0001596532-25-000286:notes:88]
[same as prior period, unchanged from 0001596532-25-000216:notes:92]

[0001596532-25-000286:notes:89]
[same as prior period, unchanged from 0001596532-25-000216:notes:93]

[0001596532-25-000286:notes:90]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Cost of revenue |  | $ | 8.0 |  |  | $ | 4.1 |  |  | $ | 19.3 |  |  | $ | 11.5 |  |
| Research and development |  | 74.6 |  |  | 58.3 |  |  | 184.8 |  |  | 152.9 |  |
| Sales and marketing |  | 32.9 |  |  | 21.0 |  |  | 71.6 |  |  | 56.6 |  |
| General and administrative |  | 12.4 |  |  | 14.7 |  |  | 30.4 |  |  | 33.6 |  |
| Total stock-based compensation |  | $ | 127.9 |  |  | $ | 98.1 |  |  | $ | 306.1 |  |  | $ | 254.6 |  |

[0001596532-25-000286:notes:91]
As of September 30, 2025, there were $1.6 billion of unamortized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 4.4 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-25-000286:notes:92]
Net Income Per Share
    Basic net income per share is computed using the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed using the weighted-average number of shares of common stock outstanding during the period, including potential common shares assuming the dilutive effect of outstanding stock options, restricted stock units, and the employee stock purchase plan using the treasury stock method. Potential common shares whose

[0001596532-25-000286:notes:93]
effect would have been antidilutive are excluded from the computation of diluted net income per share. The following table sets forth the computation of our basic and diluted net income per share (in millions, except per share amounts):

[0001596532-25-000286:notes:94]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 853.0 |  |  | $ | 748.0 |  |  | $ | 2,555.6 |  |  | $ | 2,051.1 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Basic weighted-average shares outstanding |  | 1,258.0 |  |  | 1,257.9 |  |  | 1,258.1 |  |  | 1,255.0 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity awards |  | 18.6 |  |  | 23.9 |  |  | 17.6 |  |  | 25.3 |  |
| Diluted weighted-average shares outstanding |  | 1,276.6 |  |  | 1,281.8 |  |  | 1,275.7 |  |  | 1,280.3 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.68 |  |  | $ | 0.59 |  |  | $ | 2.03 |  |  | $ | 1.63 |  |
| Diluted |  | $ | 0.67 |  |  | $ | 0.58 |  |  | $ | 2.00 |  |  | $ | 1.60 |  |

[0001596532-25-000286:notes:95]
[same as prior period, unchanged from 0001596532-25-000216:notes:98]

[0001596532-25-000286:notes:96]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Employee equity awards |  | 0.2 |  |  | 0.2 |  |  | 1.4 |  |  | 0.3 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-25-000286:notes:97]
[same as prior period, unchanged from 0001596532-25-000216:notes:100]

[0001596532-25-000286:notes:98]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Income before income taxes |  | $ | 1,077.1 |  |  | $ | 882.9 |  |  | $ | 3,112.3 |  | $ | 2,376.1 |  |
| Provision for income taxes |  | 224.1 |  |  | 134.9 |  |  | $ | 556.7 |  | 325.0 |  |
| Effective tax rate |  | 20.8 | % |  | 15.3 | % |  | 17.9 | % |  | 13.7 | % |

[0001596532-25-000286:notes:99]
On July 4, 2025, the One Big Beautiful Bill Act ("OBBB Act") was signed into law in the U.S. This legislation provides for significant tax law changes and modifications, including changes to the U.S. effective tax rates on certain foreign earnings, and permanently repeals the domestic research and development capitalization requirement.    
The increase in the effective tax rates in the three and nine months ended September 30, 2025, as compared to the same periods in 2024, was primarily associated with a one-time deferred tax provision arising from the remeasurement of our basis difference associated with the U.S. tax effect of foreign deferred tax assets resulting from the enactment of the OBBB Act, and a decrease in tax benefits attributable to equity-based compensation. While some specific provisions of the OBBB Act are not effective until our fiscal 2026 period, our deferred method of accounting policy with respect to U.S. tax on foreign earnings, known as global intangible low tax income, requires us to account for these changes in the period of enactment. In addition, we do not anticipate a material impact to our effective tax rate in future periods as a result of the OBBB Act.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-25-000286:notes:100]
[same as prior period, unchanged from 0001596532-25-000216:notes:104]

[0001596532-25-000286:notes:101]
[same as prior period, unchanged from 0001596532-25-000216:notes:105]

[0001596532-25-000286:notes:102]
[same as prior period, unchanged from 0001596532-25-000216:notes:106]

[0001596532-25-000286:notes:103]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Americas(1) |  | $ | 1,840.0 |  |  | $ | 1,480.1 |  |  | $ | 5,162.6 |  |  | $ | 4,109.7 |  |
| Europe, Middle East and Africa |  | 238.8 |  |  | 191.2 |  |  | 695.0 |  |  | 511.5 |  |
| Asia-Pacific |  | 229.5 |  |  | 139.6 |  |  | 660.3 |  |  | 451.5 |  |
| Total revenue |  | $ | 2,308.3 |  |  | $ | 1,810.9 |  |  | $ | 6,517.9 |  |  | $ | 5,072.7 |  |

[0001596532-25-000286:notes:104]
(1) Includes $1,825.7 million and $1,465.3 million revenue generated from the U.S. for the three months ended September 30, 2025 and September 30, 2024, respectively, and $5,119.3 million and $4,060.8 million for the nine months ended September 30, 2025 and September 30, 2024, respectively.

[0001596532-25-000286:notes:105]
[same as prior period, unchanged from 0001596532-25-000216:notes:109]

[0001596532-25-000286:notes:106]
|  |  | September 30, 2025 |  | December 31, 2024 |
| United States |  | $ | 155.6 |  |  | $ | 83.5 |  |
| International |  | 17.0 |  |  | 15.3 |  |
| Total |  | $ | 172.6 |  |  | $ | 98.8 |  |
