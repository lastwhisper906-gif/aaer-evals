# ANET 8-K — 0001596532-25-000284 filed 2025-11-04

## item codes, every 8-K on or before 2025-11-05

- 2025-11-04 0001596532-25-000284 — 2.02, 9.01
- 2025-09-08 0001596532-25-000258 — 5.02, 5.03, 8.01, 9.01
- 2025-08-05 0001596532-25-000214 — 2.02, 9.01
- 2025-06-16 0001596532-25-000170 — 5.02, 9.01
- 2025-06-03 0001596532-25-000148 — 5.07
- 2025-05-06 0001596532-25-000103 — 2.02, 5.02, 8.01, 9.01
- 2025-03-17 0001596532-25-000077 — 5.02, 8.01, 9.01
- 2025-02-18 0001596532-25-000018 — 2.02, 9.01
- 2024-12-03 0001596532-24-000402 — 5.03, 9.01
- 2024-11-07 0001596532-24-000366 — 2.02, 8.01, 9.01
- 2024-07-30 0001596532-24-000277 — 2.02, 9.01
- 2024-06-10 0001596532-24-000233 — 5.07
- 2024-05-24 0001596532-24-000219 — 8.01
- 2024-05-07 0001596532-24-000171 — 2.02, 8.01, 9.01
- 2024-04-23 0001596532-24-000155 — 5.02, 9.01
- 2024-04-19 0001596532-24-000152 — 5.02, 8.01
- 2024-02-28 0001596532-24-000095 — 8.01
- 2024-02-12 0001596532-24-000041 — 2.02, 9.01
- 2023-12-20 0001596532-23-000349 — 5.03, 9.01
- 2023-12-01 0001596532-23-000324 — 5.02, 8.01, 9.01
- 2023-10-30 0001596532-23-000272 — 2.02, 9.01
- 2023-07-31 0001596532-23-000196 — 2.02, 5.02, 9.01
- 2023-06-16 0001596532-23-000168 — 5.07
- 2023-05-01 0001596532-23-000101 — 2.02, 9.01
- 2023-02-13 0001596532-23-000015 — 2.02, 9.01
- 2022-10-31 0001596532-22-000292 — 2.02, 9.01
- 2022-10-25 0001596532-22-000282 — 5.03, 9.01
- 2022-08-01 0001596532-22-000218 — 2.02, 9.01
- 2022-07-25 0001596532-22-000205 — 5.02
- 2022-06-03 0001596532-22-000179 — 5.07
- 2022-05-02 0001596532-22-000111 — 2.02, 9.01
- 2022-03-29 0001596532-22-000100 — 5.02
- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2025-11-05

- none on or before 2025-11-05

## item 2.02 — earnings release, exhibit 99.1

[0001596532-25-000284:8k_2_02:1]
EX-99.1
2
ex991q325-earningsrelease.htm
EX-99.1

[0001596532-25-000284:8k_2_02:2]
Document

[0001596532-25-000284:8k_2_02:3]
Exhibit 99.1

[0001596532-25-000284:8k_2_02:4]
Arista Networks, Inc. Reports Third Quarter 2025 Financial Results

[0001596532-25-000284:8k_2_02:5]
SANTA CLARA, Calif.- November 4, 2025 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus, and routing environments, today announced financial results for its third quarter ended September 30, 2025.

[0001596532-25-000284:8k_2_02:6]
Third Quarter Financial Highlights

[0001596532-25-000284:8k_2_02:7]
"Our centers of data strategy is resonating well across customers and analysts because it delivers a superior client to campus to cloud/data and AI centers experience," said Jayshree Ullal, Chairperson and CEO of Arista Networks. “After yet another strong performance in Q3 2025, Arista is well-positioned as a strategic networking provider with continued durable execution.”

[0001596532-25-000284:8k_2_02:8]
•Revenue of $2.308 billion, an increase of 4.7% compared to the second quarter of 2025, and an increase of 27.5% from the third quarter of 2024.

[0001596532-25-000284:8k_2_02:9]
•GAAP gross margin of 64.6%, compared to GAAP gross margin of 65.2% in the second quarter of 2025 and 64.2% in the third quarter of 2024.

[0001596532-25-000284:8k_2_02:10]
•Non-GAAP gross margin of 65.2%, compared to non-GAAP gross margin of 65.6% in the second quarter of 2025 and 64.6% in the third quarter of 2024.

[0001596532-25-000284:8k_2_02:11]
•GAAP net income of $853.0 million, or $0.67 per diluted share, compared to GAAP net income of $747.9 million, or $0.58 per diluted share in the third quarter of 2024.

[0001596532-25-000284:8k_2_02:12]
•Non-GAAP net income of $962.3 million, or $0.75 per diluted share, compared to non-GAAP net income of $769.0 million, or $0.60 per diluted share in the third quarter of 2024.

[0001596532-25-000284:8k_2_02:13]
Commenting on the company's financial results, Chantelle Breithaupt, Arista’s CFO, said, "We are proud to have delivered 25% non-GAAP EPS growth in this quarter, a reflection not only of strong demand, but also of the disciplined execution of our strategic roadmap."

[0001596532-25-000284:8k_2_02:14]
Company Highlights

[0001596532-25-000284:8k_2_02:15]
•Arista Networks appointed Kenneth Duda as President and Chief Technology Officer and Tyson Lamoreaux as Senior Vice President of Cloud and AI Networking - Mr. Duda’s expanded role will oversee cloud and AI systems engineering and business development. Mr. Lamoreaux has over 25 years of experience in networking and systems. He has joined Mr. Duda’s team.

[0001596532-25-000284:8k_2_02:16]
•Arista Networks to collaborate with industry leaders to deliver Ethernet for Scale-Up Networks (ESUN) – ESUN was unveiled at the OCP Global Summit in October 2025 as an open OCP workstream committed to the goal of open standards-based solutions for scale-up, based on Ethernet, and open to all.

[0001596532-25-000284:8k_2_02:17]
•Arista Networks announced AI agents to streamline network operations – By combining the power of open standards like MCP with the robust data and programmability of Arista's EOS and NetDL, Arista is empowering network engineers to build, manage, and secure the networks of the future.

[0001596532-25-000284:8k_2_02:18]
•Arista introduced an observability blueprint for modern AI workloads - Arista CloudVision AI delivers end-to-end visibility, intelligence, and security, from the physical network and systems to job-level performance. This enables network teams to become active partners in AI success, preventing costly inefficiencies and enabling safe, autonomous operations at scale.

[0001596532-25-000284:8k_2_02:19]
Financial Outlook

[0001596532-25-000284:8k_2_02:20]
For the fourth quarter of 2025, we expect:

[0001596532-25-000284:8k_2_02:21]
•Revenue of $2.3-$2.4 billion

[0001596532-25-000284:8k_2_02:22]
•Non-GAAP gross margin of 62-63%; and

[0001596532-25-000284:8k_2_02:23]
•Non-GAAP operating margin of 47-48%.

[0001596532-25-000284:8k_2_02:24]
Guidance for non-GAAP financial measures excludes certain items, including stock-based compensation expense, intangible asset amortization, and potential non-recurring charges or benefits. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis without unreasonable effort because these exclusions can be uncertain or difficult to predict, including stock-based compensation expense, which is impacted by the timing of employee stock transactions, the company’s future hiring and retention needs and the future fair market value of the company’s common stock. The actual amount of these exclusions will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-25-000284:8k_2_02:25]
Prepared Materials and Conference Call Information

[0001596532-25-000284:8k_2_02:26]
Arista's executives will discuss the third quarter 2025 financial results on a conference call today at 1:30 PM Pacific Time. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-25-000284:8k_2_02:27]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-25-000284:8k_2_02:28]
Forward-Looking Statements

[0001596532-25-000284:8k_2_02:29]
This press release contains “forward-looking statements” regarding our future performance, including but not limited to quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin, and non-GAAP operating margin for the fourth quarter of 2025, statements regarding Arista’s products, innovation, leadership and ability to execute and succeed in data-driven, client-to-cloud networking for large AI, datacenter, campus, and routing environments. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including but not limited to risks associated with: escalated or escalating U.S. tariffs and countermeasures and retaliatory actions taken by affected countries; enhanced import/export restrictions, such as enhanced export controls the U.S. has adopted targeting trade with China, as well as countermeasures taken by affected countries; large purchases by a limited number of customers who represent a substantial portion of our revenue; adverse economic and geopolitical conditions and conflicts, continuing uncertain economic conditions or reduced information technology and network infrastructure spending; the impact of sole or limited sources of supply, supply shortages and extended lead times or supply changes; volatility in our revenue and revenue growth rates; variations in our results of operations; the rapid evolution of the networking market; failure to successfully carry out new products and service offerings and expand into adjacent markets; variability in our gross margins; intense competition and industry consolidation; expansion of our international sales and operations; investments in or acquisitions of other businesses, products or technologies; seasonality and industry cyclicality; fluctuations in currency exchange rates; failure to raise additional capital on terms satisfactory to us; our inability to attract new large customers or sell additional products and services to our existing customers; inability to grow sales of switches which generate most of our product revenue; large customers requiring more favorable terms; inability to increase market awareness or acceptance of our new products and services; decreases in the sales prices of our products and services; long and unpredictable sales cycles; inability to offer high quality support and services offerings;

[0001596532-25-000284:8k_2_02:30]
declines in maintenance renewals and support contracts by customers; product quality problems, defects, errors or vulnerabilities in our products; failure to anticipate technological shifts; insufficient component supply and inventory management; our reliance upon a predominant merchant silicon vendor; our dependence on third-party manufacturers to build our products; assertions by third parties of intellectual property rights infringement, misappropriation or other violations; failure or inability to protect or assert our intellectual property rights; cybersecurity incidents and breaches of our cybersecurity systems, or other security or privacy breaches or incidents; failure to comply with government law and regulations; issues in the development and use of artificial intelligence, combined with an uncertain regulatory environment; future decisions to reduce or discontinue repurchasing our common stock pursuant to our stock repurchase programs; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission, including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof, and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-25-000284:8k_2_02:31]
Non-GAAP Financial Measures

[0001596532-25-000284:8k_2_02:32]
This press release and accompanying table contain certain non-GAAP financial measures, including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, intangible asset amortization, (gains)/losses on strategic investments, and the income tax effect of these non-GAAP exclusions, as well as the one-time impact on our tax provision resulting from the enactment of the One Big Beautiful Bill Act (“OBBB Act”). In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-25-000284:8k_2_02:33]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are, therefore, unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-25-000284:8k_2_02:34]
About Arista Networks

[0001596532-25-000284:8k_2_02:35]
Arista Networks is an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus, and routing environments. Its award-winning platforms deliver availability, agility, automation, analytics, and security through an advanced network operating stack. For more information, visit www.arista.com.

[0001596532-25-000284:8k_2_02:36]
ARISTA, CloudVision, and Etherlink are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners. Additional information and resources can be found at www.arista.com.

[0001596532-25-000284:8k_2_02:37]
4

[0001596532-25-000284:8k_2_02:38]
ARISTA NETWORKS, INC.

[0001596532-25-000284:8k_2_02:39]
Condensed Consolidated Income Statements

[0001596532-25-000284:8k_2_02:40]
(Unaudited, in millions, except per share amounts)

[0001596532-25-000284:8k_2_02:41]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,911.7 |  |  | $ | 1,523.8 |  |  | $ | 5,481.2 |  |  | $ | 4,275.9 |  |
| Service |  | 396.6 |  |  | 287.1 |  |  | 1,036.7 |  |  | 796.8 |  |
| Total revenue |  | 2,308.3 |  |  | 1,810.9 |  |  | 6,517.9 |  |  | 5,072.7 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 745.5 |  |  | 593.3 |  |  | 2,125.5 |  |  | 1,655.4 |  |
| Service |  | 72.6 |  |  | 55.9 |  |  | 187.5 |  |  | 157.0 |  |
| Total cost of revenue |  | 818.1 |  |  | 649.2 |  |  | 2,313.0 |  |  | 1,812.4 |  |
| Gross profit |  | 1,490.2 |  |  | 1,161.7 |  |  | 4,204.9 |  |  | 3,260.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 326.0 |  |  | 235.8 |  |  | 888.9 |  |  | 711.7 |  |
| Sales and marketing |  | 151.2 |  |  | 106.8 |  |  | 394.3 |  |  | 316.3 |  |
| General and administrative |  | 34.8 |  |  | 33.8 |  |  | 98.5 |  |  | 87.3 |  |
| Total operating expenses |  | 512.0 |  |  | 376.4 |  |  | 1,381.7 |  |  | 1,115.3 |  |
| Income from operations |  | 978.2 |  |  | 785.3 |  |  | 2,823.2 |  |  | 2,145.0 |  |
| Other income (expense), net |  | 98.9 |  |  | 97.6 |  |  | 289.1 |  |  | 231.1 |  |
| Income before income taxes |  | 1,077.1 |  |  | 882.9 |  |  | 3,112.3 |  |  | 2,376.1 |  |
| Provision for income taxes |  | 224.1 |  |  | 134.9 |  |  | 556.7 |  |  | 325.0 |  |
| Net income |  | $ | 853.0 |  |  | $ | 748.0 |  |  | $ | 2,555.6 |  |  | $ | 2,051.1 |  |
| Net income per share(1): |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.68 |  |  | $ | 0.59 |  |  | $ | 2.03 |  |  | $ | 1.63 |  |
| Diluted |  | $ | 0.67 |  |  | $ | 0.58 |  |  | $ | 2.00 |  |  | $ | 1.60 |  |
| Weighted-average shares used in computing net income per share(1): |  |  |  |  |  |  |  |  |
| Basic |  | 1,258.0 |  |  | 1,257.9 |  |  | 1,258.1 |  |  | 1,255.0 |  |
| Diluted |  | 1,276.6 |  |  | 1,281.8 |  |  | 1,275.7 |  |  | 1,280.3 |  |

[0001596532-25-000284:8k_2_02:42]
(1) Prior period results have been adjusted to reflect the four-for-one stock split effected in December 2024.

[0001596532-25-000284:8k_2_02:43]
5

[0001596532-25-000284:8k_2_02:44]
ARISTA NETWORKS, INC.

[0001596532-25-000284:8k_2_02:45]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-25-000284:8k_2_02:46]
(Unaudited, in millions, except percentages and per share amounts)

[0001596532-25-000284:8k_2_02:47]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| GAAP gross profit |  | $ | 1,490.2 |  |  | $ | 1,161.7 |  |  | $ | 4,204.9 |  |  | $ | 3,260.3 |  |
| GAAP gross margin |  | 64.6 | % |  | 64.2 | % |  | 64.5 | % |  | 64.3 | % |
| Stock-based compensation expense |  | 8.0 |  |  | 4.1 |  |  | 19.3 |  |  | 11.5 |  |
| Intangible asset amortization |  | 7.0 |  |  | 4.2 |  |  | 12.8 |  |  | 12.6 |  |
| Non-GAAP gross profit |  | $ | 1,505.2 |  |  | $ | 1,170.0 |  |  | $ | 4,237.0 |  |  | $ | 3,284.4 |  |
| Non-GAAP gross margin |  | 65.2 | % |  | 64.6 | % |  | 65.0 | % |  | 64.7 | % |
| GAAP income from operations |  | $ | 978.2 |  |  | $ | 785.3 |  |  | $ | 2,823.2 |  |  | $ | 2,145.0 |  |
| GAAP operating margin |  | 42.4 | % |  | 43.4 | % |  | 43.3 | % |  | 42.3 | % |
| Stock-based compensation expense |  | 127.9 |  |  | 98.1 |  |  | 306.1 |  |  | 254.6 |  |
| Intangible asset amortization |  | 15.8 |  |  | 6.7 |  |  | 26.4 |  |  | 20.1 |  |
| Non-GAAP income from operations |  | $ | 1,121.9 |  |  | $ | 890.1 |  |  | $ | 3,155.7 |  |  | $ | 2,419.7 |  |
| Non-GAAP operating margin |  | 48.6 | % |  | 49.1 | % |  | 48.4 | % |  | 47.7 | % |
| GAAP net income |  | $ | 853.0 |  |  | $ | 747.9 |  |  | $ | 2,555.6 |  |  | $ | 2,051.1 |  |
| Stock-based compensation expense |  | 127.9 |  |  | 98.1 |  |  | 306.1 |  |  | 254.6 |  |
| Intangible asset amortization |  | 15.8 |  |  | 6.7 |  |  | 26.4 |  |  | 20.1 |  |
| (Gains)/losses on strategic investments |  | — |  |  | (12.4) |  |  | (10.9) |  |  | (12.4) |  |
| Tax impact of the OBBB Act(1) |  | 34.6 |  |  | — |  |  | 34.6 |  |  | — |  |
| Tax benefits on stock-based awards |  | (49.0) |  |  | (57.7) |  |  | (156.7) |  |  | (193.1) |  |
| Income tax effect on non-GAAP exclusions |  | (20.0) |  |  | (13.6) |  |  | (43.1) |  |  | (40.9) |  |
| Non-GAAP net income |  | $ | 962.3 |  |  | $ | 769.0 |  |  | $ | 2,712.0 |  |  | $ | 2,079.4 |  |
| GAAP diluted net income per share(2) |  | $ | 0.67 |  |  | $ | 0.58 |  |  | $ | 2.00 |  |  | $ | 1.60 |  |
| Non-GAAP adjustments to net income per share(2) |  | 0.08 |  |  | 0.02 |  |  | 0.13 |  |  | 0.02 |  |
| Non-GAAP diluted net income per share(2) |  | $ | 0.75 |  |  | $ | 0.60 |  |  | $ | 2.13 |  |  | $ | 1.62 |  |
| Weighted-average shares used in computing diluted net income per share(2) |  | 1,276.6 |  |  | 1,281.8 |  |  | 1,275.7 |  |  | 1,280.3 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 8.0 |  |  | $ | 4.1 |  |  | $ | 19.3 |  |  | $ | 11.5 |  |
| Research and development |  | 74.6 |  |  | 58.3 |  |  | 184.8 |  |  | 152.9 |  |
| Sales and marketing |  | 32.9 |  |  | 21.0 |  |  | 71.6 |  |  | 56.6 |  |
| General and administrative |  | 12.4 |  |  | 14.7 |  |  | 30.4 |  |  | 33.6 |  |
| Total |  | $ | 127.9 |  |  | $ | 98.1 |  |  | $ | 306.1 |  |  | $ | 254.6 |  |

[0001596532-25-000284:8k_2_02:48]
(1) Represents a one-time deferred tax provision arising from the remeasurement of our basis difference associated with the U.S. tax effect of foreign deferred tax assets, resulting from the enactment of the OBBB Act.

[0001596532-25-000284:8k_2_02:49]
(2) Prior period results have been adjusted to reflect the four-for-one stock split effected in December 2024.

[0001596532-25-000284:8k_2_02:50]
ARISTA NETWORKS, INC.

[0001596532-25-000284:8k_2_02:51]
Condensed Consolidated Balance Sheets

[0001596532-25-000284:8k_2_02:52]
(Unaudited, in millions)

[0001596532-25-000284:8k_2_02:53]
|  |  | September 30, 2025 |  | December 31, 2024 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,326.6 |  |  | $ | 2,762.4 |  |
| Marketable securities |  | 7,779.6 |  |  | 5,541.1 |  |
| Accounts receivable |  | 1,489.4 |  |  | 1,140.5 |  |
| Inventories |  | 2,155.7 |  |  | 1,834.6 |  |
| Prepaid expenses and other current assets |  | 1,433.5 |  |  | 632.3 |  |
| Total current assets |  | 15,184.8 |  |  | 11,910.9 |  |
| Property and equipment, net |  | 172.6 |  |  | 98.8 |  |
| Goodwill |  | 416.2 |  |  | 268.5 |  |
| Deferred tax assets |  | 1,665.4 |  |  | 1,440.4 |  |
| Other assets |  | 609.8 |  |  | 325.3 |  |
| TOTAL ASSETS |  | $ | 18,048.8 |  |  | $ | 14,043.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 481.0 |  |  | $ | 381.1 |  |
| Accrued liabilities |  | 471.0 |  |  | 435.3 |  |
| Deferred revenue |  | 3,520.7 |  |  | 1,727.3 |  |
| Other current liabilities |  | 193.9 |  |  | 188.5 |  |
| Total current liabilities |  | 4,666.6 |  |  | 2,732.2 |  |
| Deferred revenue, non-current |  | 1,165.5 |  |  | 1,064.1 |  |
| Other long-term liabilities |  | 309.6 |  |  | 252.8 |  |
| TOTAL LIABILITIES |  | 6,141.7 |  |  | 4,049.1 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital |  | 2,784.1 |  |  | 2,465.4 |  |
| Retained earnings |  | 9,115.1 |  |  | 7,542.5 |  |
| Accumulated other comprehensive income (loss) |  | 7.8 |  |  | (13.2) |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 11,907.1 |  |  | 9,994.8 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 18,048.8 |  |  | $ | 14,043.9 |  |

[0001596532-25-000284:8k_2_02:54]
7

[0001596532-25-000284:8k_2_02:55]
ARISTA NETWORKS, INC.

[0001596532-25-000284:8k_2_02:56]
Condensed Consolidated Statements of Cash Flows

[0001596532-25-000284:8k_2_02:57]
(Unaudited, in millions)

[0001596532-25-000284:8k_2_02:58]
|  |  | Nine Months Ended September 30, |
|  |  | 2025 |  | 2024 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 2,555.6 |  |  | $ | 2,051.1 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 49.8 |  |  | 46.7 |  |
| Stock-based compensation |  | 306.1 |  |  | 254.6 |  |
| Deferred income taxes |  | (202.5) |  |  | (376.7) |  |
| Other |  | (23.5) |  |  | (42.7) |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (348.9) |  |  | (96.5) |  |
| Inventories |  | (321.1) |  |  | 175.2 |  |
| Other assets |  | (683.7) |  |  | (173.1) |  |
| Accounts payable |  | 98.1 |  |  | (142.0) |  |
| Deferred revenue |  | 1,765.7 |  |  | 1,001.1 |  |
| Income taxes, net |  | (105.2) |  |  | 59.8 |  |
| Other liabilities |  | 19.6 |  |  | (80.2) |  |
| Net cash provided by operating activities |  | 3,110.0 |  |  | 2,677.3 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 2,590.3 |  |  | 1,427.3 |  |
| Proceeds from sale of marketable securities |  | 41.4 |  |  | 44.9 |  |
| Purchases of marketable securities |  | (4,816.3) |  |  | (2,593.4) |  |
| Purchases of property and equipment |  | (82.5) |  |  | (19.6) |  |
| Cash paid for business combinations, net of cash acquired |  | (300.0) |  |  | — |  |
| Other |  | (10.0) |  |  | (6.6) |  |
| Net cash used in investing activities |  | (2,577.1) |  |  | (1,147.4) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 56.9 |  |  | 55.5 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (44.3) |  |  | (47.5) |  |
| Repurchases of common stock |  | (983.0) |  |  | (299.8) |  |
| Net cash used in financing activities |  | (970.4) |  |  | (291.8) |  |
| Effect of exchange rate changes |  | 1.7 |  |  | (1.1) |  |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | (435.8) |  |  | 1,237.0 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 2,763.8 |  |  | 1,939.5 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 2,328.0 |  |  | $ | 3,176.5 |  |

[0001596532-25-000284:8k_2_02:59]
| Investor Contacts: |  |
| Arista Networks, Inc. |
| Investor Advocacy |
| Rudolph Araujo |  |
| Rod Hall |  |
| +1 (408) 547-8080 |  |
| ir@arista.com |
