# ANET MD&A — 0001596532-25-000286


## mdna

[0001596532-25-000286:mdna:1]
[same as prior period, unchanged from 0001596532-25-000216:mdna:1]

[0001596532-25-000286:mdna:2]
[same as prior period, unchanged from 0001596532-25-000216:mdna:2]

[0001596532-25-000286:mdna:3]
Arista Networks is an industry leader in data-driven, client to cloud networking for large AI, data center, campus and routing environments. Arista's platforms deliver availability, agility, automation, analytics and security through an advanced network operating stack. Since Arista’s inception, our founders have reimagined cloud networks for performance, scale and programmability with a focus on differentiating in three ways: uncompromising reliability built on the foundation of robust quality assurance capabilities with a suite of automated diagnostics, advanced open and standards-based technology and intelligent automation to decrease the manual workload on the operator. At the core of Arista’s platform is Arista EOS, a

[0001596532-25-000286:mdna:4]
modernized publish-subscribe state-sharing networking operating system. Arista EOS, combined with a set of network applications and our Ethernet switching and routing platforms using best of breed merchant silicon, provides customers with a highly competitive and diversified portfolio of products with improved price/performance and time to market.

[0001596532-25-000286:mdna:5]
[same as prior period, unchanged from 0001596532-25-000216:mdna:4]

[0001596532-25-000286:mdna:6]
The markets for cloud networking solutions are highly competitive and characterized by rapidly changing technology, changing end-customer needs, evolving industry standards, frequent introductions of new products and services, and industry consolidation. We expect competition to intensify in the future as the market for cloud networking expands and existing competitors and new market entrants introduce new products or enhance existing products. Our future success is dependent upon our ability to continue to evolve and adapt to our rapidly changing environment. We must also continue to develop market-leading products and software features that address the changing needs of our existing and new customers, and increase sales in the cloud, AI and enterprise data center Ethernet switching/routing markets, and campus workspace markets. We believe one of our greatest strengths lies in our ability to rapidly develop new features and applications. In addition, we intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new customers more effectively, increase sales to existing customers, and provide services and support. Furthermore, we expect to continue to make substantial investments to introduce new products and services and enhance the functionality of our existing cloud networking platform through investments in our research and development organization, and investments in or acquisitions of complementary companies, products and technologies to expand our product offerings and build upon our technology leadership. In June 2025, we completed the acquisition of the VeloCloud business from Broadcom. VeloCloud’s secure, AI-optimized cloud WAN portfolio provides seamless connectivity to customer sites of any type, complementing Arista’s leading data center and campus wired/wireless portfolio. We believe the combination of Arista and VeloCloud will provide modern WAN solutions for our customers globally.

[0001596532-25-000286:mdna:7]
[same as prior period, unchanged from 0001596532-25-000216:mdna:6]

[0001596532-25-000286:mdna:8]
Historically, large purchases by a relatively limited number of customers have accounted for a significant portion of our revenue. For example, sales to our end customer Microsoft represented 20%, 18% and 16% of our total revenue for the years ended 2024, 2023 and 2022, respectively. And sales to our end customer Meta Platforms represented 15%, 21% and 26% of our total revenue, respectively for the years ended 2024, 2023 and 2022. We have experienced unpredictability in the timing of orders from these large customers primarily due to the overall complexity of these large orders and changes in demand specific to these customers, including reductions in or changes in the mix of capital expenditures by these customers and the impact of cost reduction and other efficiency efforts by these customers. In addition, the variability in customer concentration is linked to the timing of new product deployments, and spending cycles with these customers, as well as the time it takes these customers to evaluate, test, qualify and accept our products and services, and we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. In addition, we typically provide pricing discounts to large customers, which reduces gross margins for the period in which such sales occur.

[0001596532-25-000286:mdna:9]
We believe an increased focus on the deployment of AI-enabled solutions by our large customers has accelerated the need for advanced technology offerings, including some offerings from potential new market entrants.  This prioritization and acceleration of AI related infrastructure investment has at times come in conjunction with a reduction or changes in the mix of previously planned purchases and various cost reduction measures by these customers, including optimization and increased efficiency in non-AI related capital expenditures. In addition, although the focus on deployment of AI-enabled solutions has driven increased demand for networking, the long-term trajectory is unknown. As such, demand estimates for our new products are difficult to forecast and can create volatility in our revenue. In some instances, such factors have had, and may continue to have, an impact on certain current or future projects and reduce our visibility to customer demand and may result in a reduction or uncertainty in the timing of orders from these large customers and increase the risk of charges for excess and obsolete

[0001596532-25-000286:mdna:10]
inventory. We remain in a period of new product introductions and expanded use cases, particularly in the AI Ethernet market. This has resulted in increased customer trials and contracts with acceptance periods, and an increase in the volatility and magnitude of our product deferred revenue balances, which in turn may create variability in our revenue results on a quarterly and annual basis. In addition, if we are not able to satisfy the requirements under customer trials or contracts with acceptance periods, we may be required to accept product returns from our customers, which would prevent us from recognizing revenue on such transactions and may result in the write-down of inventory.

[0001596532-25-000286:mdna:11]
[same as prior period, unchanged from 0001596532-25-000216:mdna:10]

[0001596532-25-000286:mdna:12]
[same as prior period, unchanged from 0001596532-25-000216:mdna:11]

[0001596532-25-000286:mdna:13]
We are working closely with our contract manufacturers and suppliers to optimize our supply chain and production efforts in response to the uncertainty around international trade policy and tariff rates to minimize the impact of the tariffs and any impact on the supply chain of components sourced from affected countries. While our supply chain has currently not experienced a significant disruption as a result of the recent trade measures, the extent of such policies and tariffs that will ultimately be implemented is unknown at this time, and the future impact to our supply chain and cost of our products is uncertain. We continue to ship products against previously committed demand/deployment plans and accelerate some deployments where needed, while trying to balance our customers' requirements and lead times with the availability of key components and products and lead times of our key suppliers and contract manufacturers. Given the timing and prioritization of customer orders and shipment patterns, as well as the timing and outcome of customer trials and contracts with acceptance periods, near term revenue trends may not be reflective of current demand levels, and could benefit from demand/deployment plans that have been previously committed. We expect that our inventory and purchase commitments will remain volatile as we ramp new product introductions. The magnitude of these balances and shifting customer product priorities, has resulted in an increased risk that we may not be able to sell all of this inventory, which in turn has resulted in excess and obsolete inventory and may result in additional charges to excess and obsolete inventory and supplier liability. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. These cost pressures may be increased if escalating tariff and non-tariff international trade measures continue to affect our supply chain. We also may not be able to fully mitigate the cost impacts of escalating tariff and non-tariff international trade measures or be able to pass on the full burden of the increase in trade-related costs to our customers, which could further negatively impact our gross margin. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing-related constraints could negatively impact our business in future periods.

[0001596532-25-000286:mdna:14]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. In addition, any continued or renewed disruption in manufacturing and supply and uncertainty about international trade policy and tariff rates could negatively impact our business, and as a result we may face challenges in implementing countermeasures and responding to these changing trading conditions. Furthermore, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial conditions discussed herein may not be indicative of future operating results and trends.

[0001596532-25-000286:mdna:15]
19

[0001596532-25-000286:mdna:16]
[same as prior period, unchanged from 0001596532-25-000216:mdna:15]

[0001596532-25-000286:mdna:17]
Three and Nine Months Ended September 30, 2025 Compared to Three and Nine Months Ended September 30, 2024

[0001596532-25-000286:mdna:18]
[same as prior period, unchanged from 0001596532-25-000216:mdna:17]

[0001596532-25-000286:mdna:19]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | Change in |  | 2025 |  | 2024 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,911.7 |  |  | $ | 1,523.8 |  |  | $ | 387.9 |  |  | 25.5 | % |  | $ | 5,481.2 |  |  | $ | 4,275.9 |  |  | $ | 1,205.3 |  |  | 28.2 | % |
| Service |  | 396.6 |  |  | 287.1 |  |  | 109.5 |  |  | 38.1 |  |  | 1,036.7 |  |  | 796.8 |  |  | 239.9 |  |  | 30.1 |  |
| Total revenue |  | 2,308.3 |  |  | 1,810.9 |  |  | 497.4 |  |  | 27.5 |  |  | 6,517.9 |  |  | 5,072.7 |  |  | 1,445.2 |  |  | 28.5 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 745.5 |  |  | 593.3 |  |  | 152.2 |  |  | 25.7 |  |  | 2,125.5 |  |  | 1,655.4 |  |  | 470.1 |  |  | 28.4 |  |
| Service |  | 72.6 |  |  | 55.9 |  |  | 16.7 |  |  | 29.9 |  |  | 187.5 |  |  | 157.0 |  |  | 30.5 |  |  | 19.4 |  |
| Total cost of revenue |  | 818.1 |  |  | 649.2 |  |  | 168.9 |  |  | 26.0 |  |  | 2,313.0 |  |  | 1,812.4 |  |  | 500.6 |  |  | 27.6 |  |
| Gross profit |  | $ | 1,490.2 |  |  | $ | 1,161.7 |  |  | $ | 328.5 |  |  | 28.3 | % |  | $ | 4,204.9 |  |  | $ | 3,260.3 |  |  | $ | 944.6 |  |  | 29.0 | % |
| Gross margin |  | 64.6 | % |  | 64.2 | % |  |  |  |  |  | 64.5 | % |  | 64.3 | % |  |  |  |  |

[0001596532-25-000286:mdna:20]
[same as prior period, unchanged from 0001596532-25-000216:mdna:19]

[0001596532-25-000286:mdna:21]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2025 |  | % of Total |  | 2024 |  | % of Total |  | 2025 |  | % of Total |  | 2024 |  | % of Total |
| Americas |  | $ | 1,840.0 |  |  | 79.8 | % |  | $ | 1,480.1 |  |  | 81.7 | % |  | $ | 5,162.6 |  |  | 79.2 | % |  | $ | 4,109.7 |  |  | 81.0 | % |
| Europe, Middle East and Africa |  | 238.8 |  |  | 10.3 |  |  | 191.2 |  |  | 10.6 |  |  | 695.0 |  |  | 10.7 |  |  | 511.5 |  |  | 10.1 |  |
| Asia-Pacific |  | 229.5 |  |  | 9.9 |  |  | 139.6 |  |  | 7.7 |  |  | 660.3 |  |  | 10.1 |  |  | 451.5 |  |  | 8.9 |  |
| Total revenue |  | $ | 2,308.3 |  |  | 100.0 | % |  | $ | 1,810.9 |  |  | 100.0 | % |  | $ | 6,517.9 |  |  | 100.0 | % |  | $ | 5,072.7 |  |  | 100.0 | % |

[0001596532-25-000286:mdna:22]
[same as prior period, unchanged from 0001596532-25-000216:mdna:21]

[0001596532-25-000286:mdna:23]
Product revenue primarily consists of sales of our switching and routing products, and related network applications. Service revenue is primarily derived from sales of post-contract support ("PCS"), which are typically purchased in conjunction with our products, and subsequent renewals of those contracts. Our revenue may vary from period to period based on, among other things, customer demand, and the timing, size, and complexity of orders, especially with respect to our large customers.

[0001596532-25-000286:mdna:24]
Product revenue increased by $387.9 million, or 25.5%, and $1,205.3 million, or 28.2% for the three and nine months ended September 30, 2025, compared to the same periods in 2024. This increase reflects increased demand for our switching and routing platforms across our customer base. In addition, service revenue increased by $109.5 million, or 38.1%, and $239.9 million, or 30.1% for the three and nine months ended September 30, 2025, compared to the same periods in 2024, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenue represented 20.2% and 20.8% of total revenue for the three and nine months ended September 30, 2025, increasing from 18.3% and 19.0% for the same periods in the prior year, which was primarily influenced by changes in the geographic mix of sales to our large global customers.

[0001596532-25-000286:mdna:25]
[same as prior period, unchanged from 0001596532-25-000216:mdna:24]

[0001596532-25-000286:mdna:26]
[same as prior period, unchanged from 0001596532-25-000216:mdna:25]

[0001596532-25-000286:mdna:27]
Cost of revenue increased by $168.9 million, or 26.0%, and $500.6 million, or 27.6% for the three and nine months ended September 30, 2025, compared to the same periods in 2024. These increases were primarily driven by a corresponding increase in product and service revenues.

[0001596532-25-000286:mdna:28]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of

[0001596532-25-000286:mdna:29]
factors, including pricing pressure on our products and services due to competition, the mix of sales to large end customers who generally receive lower pricing, the mix of products sold, manufacturing-related costs, including costs associated with managing our inventory and supply chain, merchant silicon costs, and excess/obsolete inventory and supplier liability charges. We expect our gross margin to fluctuate over time depending on the factors described above and may be adversely impacted by unpredictable international trade policy and tariff rates.

[0001596532-25-000286:mdna:30]
Gross margin increased from 64.2% to 64.6% for the three months ended September 30, 2025, and increased from 64.3% to 64.5% for the nine months ended September 30, 2025, compared to the same periods in 2024.

[0001596532-25-000286:mdna:31]
[same as prior period, unchanged from 0001596532-25-000216:mdna:29]

[0001596532-25-000286:mdna:32]
[same as prior period, unchanged from 0001596532-25-000216:mdna:30]

[0001596532-25-000286:mdna:33]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | Change in |  | 2025 |  | 2024 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 326.0 |  |  | $ | 235.8 |  |  | $ | 90.2 |  |  | 38.3 | % |  | $ | 888.9 |  |  | $ | 711.7 |  |  | $ | 177.2 |  |  | 24.9 | % |
| Sales and marketing |  | 151.2 |  |  | 106.8 |  |  | 44.4 |  |  | 41.6 |  |  | 394.3 |  |  | 316.3 |  |  | 78.0 |  |  | 24.7 |  |
| General and administrative |  | 34.8 |  |  | 33.8 |  |  | 1.0 |  |  | 3.0 |  |  | 98.5 |  |  | 87.3 |  |  | 11.2 |  |  | 12.8 |  |
| Total operating expenses |  | $ | 512.0 |  |  | $ | 376.4 |  |  | $ | 135.6 |  |  | 36.0 | % |  | $ | 1,381.7 |  |  | $ | 1,115.3 |  |  | $ | 266.4 |  |  | 23.9 | % |

[0001596532-25-000286:mdna:34]
[same as prior period, unchanged from 0001596532-25-000216:mdna:32]

[0001596532-25-000286:mdna:35]
[same as prior period, unchanged from 0001596532-25-000216:mdna:33]

[0001596532-25-000286:mdna:36]
Research and development expenses increased by $90.2 million, or 38.3%, and $177.2 million, or 24.9% for the three and nine months ended September 30, 2025, compared to the same periods in 2024. The increase for the three and nine months periods was primarily driven by $32.9 million and $70.9 million increases in personnel costs due to headcount growth, and $47.5 million and $78.6 million increases in new product introduction costs, including non-recurring engineering costs as we expand our product portfolio.

[0001596532-25-000286:mdna:37]
[same as prior period, unchanged from 0001596532-25-000216:mdna:35]

[0001596532-25-000286:mdna:38]
[same as prior period, unchanged from 0001596532-25-000216:mdna:36]

[0001596532-25-000286:mdna:39]
Sales and marketing expenses increased by $44.4 million, or 41.6%, and $78.0 million, or 24.7% for the three and nine months ended September 30, 2025, compared to the same periods in 2024, which was primarily driven by increased personnel costs due to headcount growth.

[0001596532-25-000286:mdna:40]
[same as prior period, unchanged from 0001596532-25-000216:mdna:38]

[0001596532-25-000286:mdna:41]
[same as prior period, unchanged from 0001596532-25-000216:mdna:39]

[0001596532-25-000286:mdna:42]
General and administrative expenses increased by $1.0 million, or 3.0%, and $11.2 million, or 12.8% for the three and nine months ended September 30, 2025, compared to the same periods in 2024, which was primarily driven by increased professional services and personnel costs.

[0001596532-25-000286:mdna:43]
[same as prior period, unchanged from 0001596532-25-000216:mdna:41]

[0001596532-25-000286:mdna:44]
[same as prior period, unchanged from 0001596532-25-000216:mdna:42]

[0001596532-25-000286:mdna:45]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | Change in |  | 2025 |  | 2024 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 99.8 |  |  | $ | 85.4 |  |  | $ | 14.4 |  |  | 16.9 | % |  | $ | 280.4 |  |  | $ | 220.6 |  |  | $ | 59.8 |  |  | 27.1 | % |
| Other income (expense), net |  | (0.9) |  |  | 12.2 |  |  | (13.1) |  |  | (107.4) |  |  | 8.7 |  |  | 10.5 |  |  | (1.8) |  |  | (17.1) |  |
| Total other income (expense), net |  | $ | 98.9 |  |  | $ | 97.6 |  |  | $ | 1.3 |  |  | 1.3 | % |  | $ | 289.1 |  |  | $ | 231.1 |  |  | $ | 58.0 |  |  | 25.1 | % |

[0001596532-25-000286:mdna:46]
The favorable movement in other income (expense), net, during the nine months ended September 30, 2025, compared to the same periods in 2024 was primarily driven by increased interest income of $59.8 million due to an increase in our cash and marketable securities balances.

[0001596532-25-000286:mdna:47]
[same as prior period, unchanged from 0001596532-25-000216:mdna:45]

[0001596532-25-000286:mdna:48]
[same as prior period, unchanged from 0001596532-25-000216:mdna:46]

[0001596532-25-000286:mdna:49]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | Change in |  | 2025 |  | 2024 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Income before income taxes |  | $ | 1,077.1 |  |  | $ | 882.9 |  |  | $ | 194.2 |  |  | 22.0 | % |  | $ | 3,112.3 |  |  | $ | 2,376.1 |  |  | $ | 736.2 |  |  | 31.0 | % |
| Provision for income taxes |  | 224.1 |  |  | 134.9 |  |  | 89.2 |  |  | 66.1 | % |  | 556.7 |  |  | 325.0 |  |  | 231.7 |  |  | 71.3 | % |
| Effective tax rate |  | 20.8 | % |  | 15.3 | % |  |  |  |  |  | 17.9 | % |  | 13.7 | % |  |  |  |  |

[0001596532-25-000286:mdna:50]
On July 4, 2025, the OBBB Act was signed into law in the U.S. This legislation provides for significant tax law changes and modifications including changes to the U.S. effective tax rates on certain foreign earnings and permanently repeals the domestic research and development capitalization requirement.

[0001596532-25-000286:mdna:51]
The increase in the effective tax rates in the three and nine months ended September 30, 2025, as compared to the same periods in 2024, was primarily associated with a one-time deferred tax provision arising from the remeasurement of our basis difference associated with the U.S. tax effect of foreign deferred tax assets resulting from the enactment of the OBBB Act, and a decrease in tax benefits attributable to equity-based compensation. While some specific provisions of the OBBB Act are not effective until our fiscal 2026 period, our deferred method of accounting policy with respect to U.S. tax on foreign earnings, known as global intangible low tax income, requires us to account for these changes in the period of enactment. In addition, we do not anticipate a material impact to our effective tax rate in future periods as a result of the OBBB Act.

[0001596532-25-000286:mdna:52]
[same as prior period, unchanged from 0001596532-25-000216:mdna:49]

[0001596532-25-000286:mdna:53]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of September 30, 2025, our total balance of cash, cash equivalents and marketable securities was approximately $10.1 billion, of which approximately $496.9 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-25-000286:mdna:54]
Our cash, cash equivalents and marketable securities are held for general business purposes, including the funding of working capital. Our marketable securities investment portfolio is primarily invested in highly-rated securities, with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations, will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and

[0001596532-25-000286:mdna:55]
technologies, the continued market acceptance of our products, stock repurchases, and capital expenditures, including the ongoing construction of a building for office, lab and data center space. In addition, we expect that our inventory and purchase commitments will remain volatile as we ramp new product introductions. In particular, we have increased our purchase commitments to respond to the rapid deployment of AI networks and reduce overall lead times, which may increase our working capital requirements. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-25-000286:mdna:56]
[same as prior period, unchanged from 0001596532-25-000216:mdna:53]

[0001596532-25-000286:mdna:57]
|  |  | Nine Months Ended September 30, |
|  |  | 2025 |  | 2024 |
| Cash provided by operating activities |  | $ | 3,110.0 |  |  | $ | 2,677.3 |  |
| Cash used in investing activities |  | (2,577.1) |  |  | (1,147.4) |  |
| Cash used in financing activities |  | (970.4) |  |  | (291.8) |  |
| Effect of exchange rate changes |  | 1.7 |  |  | (1.1) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | (435.8) |  |  | $ | 1,237.0 |  |

[0001596532-25-000286:mdna:58]
[same as prior period, unchanged from 0001596532-25-000216:mdna:55]

[0001596532-25-000286:mdna:59]
During the nine months ended September 30, 2025, cash provided by operating activities was $3.1 billion, consisting of net income of $2.6 billion, a net decrease of $424.5 million in working capital requirements, and non-cash adjustments to net income of $129.9 million. The decrease in working capital requirements primarily consisted of an increase in deferred revenue of $1.8 billion primarily resulting from an increase in customer PCS contracts and an increase in product deferred revenue related to customer contracts with acceptance terms and a $117.7 million increase in accounts payable and other liabilities primarily due to timing of inventory-related receipts and payments. These cash inflows were partially offset by an increase in accounts receivable of $348.9 million due to increased product and service billings, a $321.1 million increase in inventory, a $683.7 million increase in other assets driven by increased deferred cost of sales associated with higher product revenue deferrals, and a $105.2 million decrease in income tax payables related to timing of payments. The non-cash adjustments to net income were driven by stock-based compensation of $306.1 million, and offset by a $202.5 million increase in deferred taxes primarily due to the increase in deferred revenue and the capitalization of research and development costs under Section 174 of the Internal Revenue Code ("IRC").

[0001596532-25-000286:mdna:60]
During the nine months ended September 30, 2024, cash provided by operating activities was $2.7 billion, consisting of net income of $2.1 billion along with a net decrease in working capital requirements of $744.3 million, offset partially by non-cash adjustments to net income of $118.1 million. The decrease in working capital requirements primarily consisted of an increase in deferred revenue of $1.0 billion resulting from an increase in customer PCS contracts and an increase in product deferred revenue related to customer contracts with acceptance terms, a $175.2 million decrease in inventory resulting from strong product shipments, and a $59.8 million increase in income tax payables, net related to timing of payments. These cash inflows were partially offset by a $226.6 million decrease in accounts payable and accrued liabilities primarily due to timing of inventory-related receipts and payments, as well as a reduction in supplier liabilities, an increase in accounts receivable of $96.5 million due to increased product and service billings, and a $173.1 million increase in other assets driven by increased deferred cost of sales associated with higher product revenue deferrals. The non-cash adjustments to net income were driven by a $376.7 million increase in deferred taxes primarily due to the increase in deferred revenue and the capitalization of research and development costs under Section 174 of the IRC, largely offset by stock-based compensation of $254.6 million and depreciation and amortization.

[0001596532-25-000286:mdna:61]
[same as prior period, unchanged from 0001596532-25-000216:mdna:58]

[0001596532-25-000286:mdna:62]
During the nine months ended September 30, 2025, cash used in investing activities was $2.6 billion, consisting of  purchases of marketable securities of $4.8 billion and $300.0 million for the acquisition of VeloCloud. These amounts were partially offset by proceeds from maturities and sales of marketable securities of $2.6 billion.

[0001596532-25-000286:mdna:63]
During the nine months ended September 30, 2024, cash used in investing activities was $1.1 billion, consisting of purchases of available-for-sale securities of $2.6 billion, partially offset by proceeds from maturities and sales of marketable securities of $1.5 billion.

[0001596532-25-000286:mdna:64]
[same as prior period, unchanged from 0001596532-25-000216:mdna:61]

[0001596532-25-000286:mdna:65]
During the nine months ended September 30, 2025, cash used in financing activities was $970.4 million, consisting of payments for repurchases of our common stock from the open market of $983.0 million.

[0001596532-25-000286:mdna:66]
During the nine months ended September 30, 2024, cash used in financing activities was $291.8 million, consisting of payments for repurchases of our common stock from the open market of $299.8 million, and employee taxes withheld and paid of $47.5 million upon vesting of restricted stock units, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $55.5 million.

[0001596532-25-000286:mdna:67]
[same as prior period, unchanged from 0001596532-25-000216:mdna:64]

[0001596532-25-000286:mdna:68]
From time to time, we repurchase shares of our common stock pursuant to repurchase programs that are funded from working capital. The Prior Repurchase Program, which allowed for stock repurchases of up to $1.2 billion, was completed in May 2025, and the New Repurchase Program allows for repurchases of an additional $1.5 billion. The New Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the Company at any time without prior notice. We did not repurchase any shares during the three months ended September 30, 2025. During the nine months ended September 30, 2025, we repurchased a total of $921.0 million of our common stock under our Prior Repurchase Program and $62.0 million of our common stock under our New Repurchase Program. As of September 30, 2025, the remaining authorized amount for repurchases under the New Repurchase Program was $1.4 billion. Refer to Note 6. Stockholders' Equity and Stock-Based Compensation of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-25-000286:mdna:69]
[same as prior period, unchanged from 0001596532-25-000216:mdna:66]

[0001596532-25-000286:mdna:70]
[same as prior period, unchanged from 0001596532-25-000216:mdna:67]

[0001596532-25-000286:mdna:71]
[same as prior period, unchanged from 0001596532-25-000216:mdna:68]

[0001596532-25-000286:mdna:72]
[same as prior period, unchanged from 0001596532-25-000216:mdna:69]

[0001596532-25-000286:mdna:73]
Purchase obligations not recorded on our balance sheet represent an estimate of all non-cancellable open purchase orders and contractual obligations, made either directly by Arista or by our contract manufacturers on our behalf, in the ordinary course of business for which we have not received the goods or services. As of September 30, 2025, we had $4.8 billion of such purchase obligations, of which $4.3 billion are expected to be received within one year, and $0.5 billion are expected to be received after one year. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-25-000286:mdna:74]
[same as prior period, unchanged from 0001596532-25-000216:mdna:71]

[0001596532-25-000286:mdna:75]
In July 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office, lab and data center space. As of September 30, 2025, the estimated remaining capital expenditures related to this project are expected to be approximately $170.0 million to $200.0 million through the end of fiscal 2026 when construction is expected to be completed.

[0001596532-25-000286:mdna:76]
[same as prior period, unchanged from 0001596532-25-000216:mdna:73]

[0001596532-25-000286:mdna:77]
As of September 30, 2025, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-25-000286:mdna:78]
[same as prior period, unchanged from 0001596532-25-000216:mdna:75]

[0001596532-25-000286:mdna:79]
[same as prior period, unchanged from 0001596532-25-000216:mdna:76]

[0001596532-25-000286:mdna:80]
[same as prior period, unchanged from 0001596532-25-000216:mdna:77]

[0001596532-25-000286:mdna:81]
[same as prior period, unchanged from 0001596532-25-000216:mdna:78]
