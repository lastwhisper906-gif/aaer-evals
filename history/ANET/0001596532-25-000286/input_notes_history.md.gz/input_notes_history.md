# ANET note change history — 0001596532-25-000216 → 0001596532-25-000286


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-11-05):
[0001596532-25-000286:note_history:1]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of purchase orders to our contract manufacturers for finished products consist of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2025, we had non-cancellable purchase commitments not recorded on our balance sheet of $4.8 billion, of which $4.3 billion have expected receipt dates within 12 months, and $0.5 billion have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.
  (was, 2025-08-06, similarity 0.994):
[0001596532-25-000216:note_history:1]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of purchase orders to our contract manufacturers for finished products consist of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of June 30, 2025, we had non-cancellable purchase commitments not recorded on our balance sheet of $3.6 billion, of which $3.1 billion have expected receipt dates within 12 months, and $0.5 billion have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

- changed (2025-11-05):
[0001596532-25-000286:note_history:2]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $50.1 million and $95.8 million as of September 30, 2025 and December 31, 2024, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.
  (was, 2025-08-06, similarity 0.9795):
[0001596532-25-000216:note_history:2]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $66.8 million and $95.8 million as of June 30, 2025 and December 31, 2024, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

- changed (2025-11-05):
[0001596532-25-000286:note_history:3]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office, lab and data center space. As of September 30, 2025, the estimated remaining capital expenditures related to this project are expected to be approximately $170.0 million to $200.0 million through the end of fiscal 2026 when we expect construction to be completed.
  (was, 2025-08-06, similarity 0.9738):
[0001596532-25-000216:note_history:3]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office, lab and data center space. The estimated remaining capital expenditures related to this project are expected to be approximately $190.0 million to $215.0 million through the end of fiscal 2026 when we expect construction to be completed.

- changed (2025-11-05):
[0001596532-25-000286:note_history:4]
In the ordinary course of business, we are a party to various claims, litigation and other legal proceedings, including matters relating to intellectual property and patent disputes.
  (was, 2025-08-06, similarity 0.7249):
[0001596532-25-000216:note_history:4]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

- changed (2025-11-05):
[0001596532-25-000286:note_history:5]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2025, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.
  (was, 2025-08-06, similarity 0.9937):
[0001596532-25-000216:note_history:5]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of June 30, 2025, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.

- removed (2025-11-05):
[0001596532-25-000216:note_history:6]
WSOU Investments, LLC

- removed (2025-11-05):
[0001596532-25-000216:note_history:7]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California. On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement. On July 1, 2022, the court stayed the case pending the resolution of an inter partes review of one of the patents-in-suit. On May 30, 2023, the US Patent Trial and Appeal Board (“PTAB”) ruled all challenged claims in the inter partes review unpatentable. On March 10, 2025, the Federal Circuit affirmed the PTAB’s decision. The parties subsequently agreed to stay the litigation to allow WSOU to change counsel and that stay was extended pending the result of proceedings in a WSOU case against another company.

- removed (2025-11-05):
[0001596532-25-000216:note_history:8]
We intend to vigorously defend against the claims brought against us by WSOU; however, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

- removed (2025-11-05):
[0001596532-25-000216:note_history:9]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated; however, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

- removed (2025-11-05):
[0001596532-25-000216:note_history:10]
Other matters


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-11-05):
[0001596532-25-000286:note_history:11]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and our wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2025, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2024 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated. Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.
  (was, 2025-08-06, similarity 0.9807):
[0001596532-25-000216:note_history:11]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2025, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2024 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated. Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.

- changed (2025-11-05):
[0001596532-25-000286:note_history:12]
In November 2024, the FASB issued ASU 2024-03, Disaggregation of Income Statement Expenses (Subtopic 220-40). The ASU requires the disaggregated disclosure of specific expense categories, including purchases of inventory, employee
  (was, 2025-08-06, similarity 0.9698):
[0001596532-25-000216:note_history:12]
In November 2024, the FASB issued ASU No. 2024-03, Disaggregation of Income Statement Expenses (Subtopic 220-40). The ASU requires the disaggregated disclosure of specific expense categories, including purchases of inventory,

- changed (2025-11-05):
[0001596532-25-000286:note_history:13]
compensation, depreciation, and amortization, within relevant income statement captions. This ASU also requires disclosure of the total amount of selling expenses along with the definition of selling expenses. The ASU is effective for annual periods beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027. Adoption of this ASU can either be applied prospectively to consolidated financial statements issued for reporting periods after the effective date of this ASU or retrospectively to any or all prior periods presented in the consolidated financial statements. Early adoption is also permitted. This ASU will likely result in the required additional disclosures being included in our consolidated financial statements, once adopted. We are currently evaluating the impact of future adoption on our financial statement disclosures.
In July 2025, the FASB issued ASU 2025-05 Financial Instruments - Credit Losses (Topic 326) Measurement of Credit Losses for Accounts Receivable and Contract Assets, or ASU 2025-05. The ASU provides a practical expedient that allows entities to assume that current conditions as of the balance sheet date do not change for the remaining life of the asset when estimating expected credit losses for current accounts receivable and current contract assets. The amendments of ASU 2025-05 should be applied prospectively and are effective for annual and interim periods beginning after December 15, 2025, with early adoption permitted. We do not expect the adoption of ASU 2025-05 to have a material impact on our consolidated financial statements and related disclosures.
  (was, 2025-08-06, similarity 0.7005):
[0001596532-25-000216:note_history:13]
employee compensation, depreciation, and amortization, within relevant income statement captions. This ASU also requires disclosure of the total amount of selling expenses along with the definition of selling expenses. The ASU is effective for annual periods beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027. Adoption of this ASU can either be applied prospectively to consolidated financial statements issued for reporting periods after the effective date of this ASU or retrospectively to any or all prior periods presented in the consolidated financial statements. Early adoption is also permitted. This ASU will likely result in the required additional disclosures being included in our consolidated financial statements, once adopted. We are currently evaluating the impact of future adoption on our financial statement disclosures.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-11-05):
[0001596532-25-000286:note_history:14]
|  |  | September 30, 2025 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| Commercial paper |  | $ | 9.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 9.8 |  |  | $ | — |  |
| U.S. government notes |  | 882.7 |  |  | (0.5) |  |  | 46.6 |  |  | (0.1) |  |  | 929.3 |  |  | (0.6) |  |
| Corporate bonds |  | 833.8 |  |  | (1.6) |  |  | 19.2 |  |  | — |  |  | 853.0 |  |  | (1.6) |  |
| Agency securities |  | 415.3 |  |  | (0.6) |  |  | 11.9 |  |  | — |  |  | 427.2 |  |  | (0.6) |  |
| Total |  | $ | 2,141.6 |  |  | $ | (2.7) |  |  | $ | 77.7 |  |  | $ | (0.1) |  |  | $ | 2,219.3 |  |  | $ | (2.8) |  |

- removed (2025-11-05):
[0001596532-25-000216:note_history:15]
|  |  | June 30, 2025 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 925.8 |  |  | $ | (1.4) |  |  | $ | — |  |  | $ | — |  |  | $ | 925.8 |  |  | $ | (1.4) |  |
| Corporate bonds |  | 732.6 |  |  | (1.5) |  |  | — |  |  | — |  |  | 732.6 |  |  | (1.5) |  |
| Municipal bonds |  | 1.5 |  |  | — |  |  | — |  |  | — |  |  | 1.5 |  |  | — |  |
| Agency securities |  | 614.5 |  |  | (0.7) |  |  | — |  |  | — |  |  | 614.5 |  |  | (0.7) |  |
| Total |  | $ | 2,274.4 |  |  | $ | (3.6) |  |  | $ | — |  |  | $ | — |  |  | $ | 2,274.4 |  |  | $ | (3.6) |  |
