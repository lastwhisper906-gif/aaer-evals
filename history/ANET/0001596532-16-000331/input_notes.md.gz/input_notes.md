# ANET notes — 0001596532-16-000331


## anet:ScheduleofSharebasedCompensationSharesAvailableForGrantActivityTableTextBlock

[0001596532-16-000331:notes:1]
The following table presents the stock activity and the total number of shares available for grant as of September 30, 2016 (in thousands):

[0001596532-16-000331:notes:2]
|  |  | Number of Shares |
| Balance—December 31, 2015 |  | 10,495 |  |
| Authorized |  | 2,044 |  |
| Options granted |  | (440 | ) |
| RSUs granted |  | (440 | ) |
| Options canceled |  | 314 |  |
| Options repurchased |  | 5 |  |
| RSUs forfeited |  | 72 |  |
| Shares traded for taxes |  | 11 |  |
| Balance—September 30, 2016 |  | 12,061 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001596532-16-000331:notes:3]
As of September 30, 2016, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale investments, by remaining contractual maturity, are as follows (in thousands):

[0001596532-16-000331:notes:4]
|  |  | September 30, 2016 |
| Due in 1 year or less |  | $ | 171,170 |  |
| Due in 1 year through 2 years |  | 128,497 |  |
| Total marketable securities |  | $ | 299,667 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001596532-16-000331:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") and following the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by U.S. GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2016, are not necessarily indicative of the results expected for the full fiscal year.

[0001596532-16-000331:notes:6]
[same as prior period, unchanged from 0001596532-16-000291:notes:6]

[0001596532-16-000331:notes:7]
[same as prior period, unchanged from 0001596532-16-000291:notes:7]

[0001596532-16-000331:notes:8]
[same as prior period, unchanged from 0001596532-16-000291:notes:8]

[0001596532-16-000331:notes:9]
There have been no material changes to our significant accounting policies as of and for the nine months ended September 30, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2015.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-16-000331:notes:10]
Commitments and Contingencies

[0001596532-16-000331:notes:11]
Operating Leases

[0001596532-16-000331:notes:12]
We lease various operating spaces in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2024. There have been no material changes in our operating lease commitments under contractual obligation, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2015.

[0001596532-16-000331:notes:13]
We recognize rent expense under these arrangements on a straight-line basis over the term of the lease.  Rent expense for all operating leases amounted to $2.3 million, $2.0 million, $7.0 million, and $4.7 million for the three and nine months ended September 30, 2016 and 2015, respectively.

[0001596532-16-000331:notes:14]
Financing Obligation—Build-to-Suit Lease

[0001596532-16-000331:notes:15]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013.  The underlying building asset is depreciated over the building’s estimated useful life of 30 years. At the conclusion of the initial lease term, we will de-recognize both the net book values of the asset and the remaining financing obligation. There have been no material changes in our financing obligation commitments under contractual obligation, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2015.

[0001596532-16-000331:notes:16]
As of September 30, 2016 and December 31, 2015, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $41.6 million and $42.5 million, respectively. As of September 30, 2016, $1.5 million and $40.0 million were recorded as short-term and long-term financing obligations, respectively.

[0001596532-16-000331:notes:17]
Land lease expense related to our lease financing obligation is classified in rent expense in our unaudited condensed consolidated statements of income, and amounted to $0.3 million and $1.0 million for both the three and nine months ended September 30, 2016 and 2015, respectively.

[0001596532-16-000331:notes:18]
Purchase Commitments

[0001596532-16-000331:notes:19]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply.  We issue purchase orders to our contract manufacturers for finished product and a significant portion of these orders consist of firm non-cancelable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancelable, including integrated circuits, which are consigned to our contract manufacturers.   As of September 30, 2016, we had non-cancelable purchase commitments of $226.2 million.  In addition, we have provided deposits to secure our obligations to purchase inventory. We had $64.9 million and $2.3 million in deposits as of September 30, 2016 and December 31, 2015, respectively. These deposits are classified in other current and long term assets in our accompanying unaudited condensed consolidated balance sheets.

[0001596532-16-000331:notes:20]
Guarantees

[0001596532-16-000331:notes:21]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for lease facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-16-000331:notes:22]
Legal Proceedings

[0001596532-16-000331:notes:23]
OptumSoft, Inc. Matters

[0001596532-16-000331:notes:24]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies; and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-16-000331:notes:25]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft access to our software for evaluation by OptumSoft; (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches; (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers; (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us; and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors, who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dtd July 28, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.

[0001596532-16-000331:notes:26]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we assert our ownership of the software components at issue and our interpretation of the 2004 agreement.  Among other things, we assert that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components.  We ask the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also assert that, even if we are found not to own certain components, such components are licensed to us under the terms of the 2004 agreement.  However, there can be no assurance that our assertions will ultimately prevail in litigation.  On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue.  We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information.  While we believe we have meritorious defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-16-000331:notes:27]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015.  On December 16, 2015, the Court issued a Proposed Statement of Decision Following Phase 1 Trial, and on January 8, 2016, OptumSoft filed objections to that Proposed Statement of Decision.  On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I.  The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II including the application of the Court’s interpretation of the 2004 agreement as set forth in the Final Statement of Decision Following Phase I Trial to any other source code that OptumSoft claims to own following a review.  Phase II was previously scheduled to be tried in April 2016; however, that trial date has been vacated and a new trial date has not yet been set.

[0001596532-16-000331:notes:28]
We intend to vigorously defend against any claims brought against us by OptumSoft.  However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor.  For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft.  If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license.  An adverse litigation ruling could result in a significant damages award against us and injunctive relief.  In addition, OptumSoft could assert additional or different claims against us, including claims that our license from OptumSoft is invalid.

[0001596532-16-000331:notes:29]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible.  Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated.  However, the outcome of litigation is inherently uncertain.  Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-16-000331:notes:30]
Cisco Systems, Inc. (“Cisco”) Matters

[0001596532-16-000331:notes:31]
We are currently involved in several litigation matters with Cisco Systems, Inc. These matters are summarized below.

[0001596532-16-000331:notes:32]
Cisco Systems, Inc. v. Arista Networks, Inc. (Case No. 4:14-cv-05343) (“’43 Case”)

[0001596532-16-000331:notes:33]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the 875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”).  Cisco seeks, as relief for our alleged infringement in the ’43 Case, lost profits and/or reasonable royalty damages in an unspecified amount, including treble damages, attorney’s fees, and associated costs.  Cisco also seeks injunctive relief in the ’43 Case.  On February 10, 2015, the Court granted our unopposed motion to stay the ’43 Case until the proceedings before the United States International Trade Commission (“USITC”) pertaining to the same patents (as discussed below) became final.  Trial has not been scheduled in the ’43 Case.

[0001596532-16-000331:notes:34]
Cisco Systems, Inc. v. Arista Networks, Inc. (Case No. 5:14-cv-05344) (“’44 Case”)

[0001596532-16-000331:notes:35]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI” and U.S. Patent Nos.  7,047,526 and 7,953,886 (respectively, “the 526 patent” and “the 886 patent”).  As relief for our alleged patent infringement in the ’44 Case, Cisco seeks lost profits and/or reasonable royalty damages in an unspecified amount including treble damages, attorney’s fees, and associated costs as well as injunctive relief.  As relief for our alleged copyright infringement, Cisco seeks monetary damages for alleged lost profits, profits from our alleged infringement, statutory damages, attorney's fees, and associated costs.

[0001596532-16-000331:notes:36]
On February 13, 2015, we answered the complaint in the ’44 Case, denying the patent and copyright infringement allegations and raising numerous affirmative defenses.  On March 6, 2015, Cisco filed an amended complaint against us in the ’44 Case.  In response, we moved to dismiss Cisco’s allegations of willful patent infringement and pre-suit indirect patent infringement.  The Court granted the motion with leave to amend on July 2, 2015.  On July 23, 2015, Cisco filed an amended complaint. On May 25, 2016, the Patent and Trademark Appeals Board ("PTAB") issued an order initiating inter partes review of U.S. Patent No. 7,953,886 (“the ʼ886 patent).  Following that order Cisco agreed to dismiss its claims as to the ʼ886 patent with prejudice, and we dismissed our counterclaims as to the ʼ886 patent without prejudice.

[0001596532-16-000331:notes:37]
Summary judgment cross-motions in the ’44 Case were heard on August 4, 2016, and the Court denied all motions brought by both sides.  A final pre-trial conference is set for November 3, 2016 and trial has been set for November 21, 2016.

[0001596532-16-000331:notes:38]
Arista Networks, Inc. v. Cisco Systems, Inc. (Case No. 5:16-cv-00923) (“’23 Case”)

[0001596532-16-000331:notes:39]
On February 24, 2016, we filed a complaint against Cisco in the District Court for the Northern District of California alleging antitrust violations and unfair competition.  On April 13, 2016, Cisco filed a motion to stay the ’23 Case, or in the alternative, to dismiss the complaint.  On August 23, 2016, the Court granted Cisco’s motion to stay until judgment has been entered on Cisco’s copyright claims in the ’44 Case, which the Court anticipated by December 22, 2016.  Trial in the ’23 Case is set for August 3, 2018, and is not affected by the Court’s granting of the interim stay.

[0001596532-16-000331:notes:40]
Certain Network Devices, Related Software, and Components Thereof (Inv. No. 337-TA-944) (“944 Investigation”)

[0001596532-16-000331:notes:41]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we have violated Section 337 of the Tariff Act of 1930, as amended.  The USITC instituted Cisco's complaint as Investigation No. 337-TA-944. Cisco initially alleged that certain of our switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents.  Cisco subsequently dropped the ’296 patent from the 944 Investigation.  Cisco sought, among other things, a limited exclusion order barring entry into the United States of accused switch products (including our 7000 Series of switches) and components and software therein and a cease and desist order against us restricting our activities with respect to our imported accused switch products and components and software therein.  On February 11, 2015, we responded to the complaint in the 944 Investigation by, among other things, denying the patent infringement allegations and raising numerous affirmative defenses.

[0001596532-16-000331:notes:42]
The Administrative Law Judge ("ALJ") assigned to the 944 Investigation issued a procedural schedule calling for, among other events: an evidentiary hearing on September 9-11 and 15-17, 2015; issuance of an initial determination regarding our alleged violations on January 27, 2016; and a Target Date for completion of the investigation on May 27, 2016.  On January 27, 2016, the ALJ issued a revised procedural schedule extending the date for issuance of an initial determination to February 2, 2016 and extending the Target Date to June 2, 2016.

[0001596532-16-000331:notes:43]
On February 2, 2016, the ALJ issued his initial determination finding a violation of section 337 of the Tariff Act. More specifically, the ALJ found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringe asserted claims 1, 2, 8-11, and 17-19 of the ’537 patent; asserted claims 6, 7, 20, and 21 of the ’592 patent; and asserted claims 5, 7, 45, and 46 of the ’145 patent.  The ALJ did not find a violation of section 337 with respect to any asserted claims of the ’597 and ’164 patents.  On April 11, 2016, the Commission decided to review certain findings contained in the initial determination.  On June 23, 2016, the Commission issued its Final Determination, which found a violation with respect to the ’537, ’592, and ’145 patents, and found no violation with respect to the ’597 and ’164 patents.  The Commission also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software and components thereof that infringe one or more of claims 1, 2, 8-11, and 17-19 of the ’537 patent; claims 6, 7, 20, and 21 of the ’592 patent; and claims 5, 7, 45, and 46 of the ’145 patent.  On August 22, 2016, the Presidential review period for the 944 investigation expired.  The USITC orders are currently in effect.

[0001596532-16-000331:notes:44]
Both we and Cisco filed petitions for review of the USITCs Final Determination to the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”).  On August 26, 2016, the Federal Circuit consolidated the appeals and, on September 23, 2016, it issued an order setting an expedited briefing schedule.  Under this schedule, we filed our opening brief on September 23, 2016; Cisco’s opening brief is due November 2, 2016; the USITC’s brief is due on December 2, 2016; our response/reply brief is due December 19, 2016; and Cisco’s reply brief is due January 2, 2017.

[0001596532-16-000331:notes:45]
On August 26, 2016, Cisco filed an enforcement complaint under Section 337 of the Tariff Act of 1930, as amended, with the USITC.  Cisco alleges that we are violating the cease and desist order issued in the 944 Investigation by engaging in the “marketing, distribution, offering for sale, selling, advertising, and/or aiding or abetting other entities in the sale and/or distribution of products that Cisco alleges continue to infringe claims 1-2, 8-11, and 17-19 of the ’537 patent”, despite the design changes we have made to those products.  Cisco asks the USTIC to (1) enforce the cease and desist order; (2) modify the Commission’s limited exclusion order and/or cease and desist order “in any manner that would assist in the prevention of the unfair practices that were originally the basis for issuing such Order or assist in the detection of violations of such Order”; (3) impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000.00 or twice the domestic value of the articles entered or sold, whichever is higher”; (4) bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order”; and (5) impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.”  On September 28, 2016, the Commission instituted the enforcement proceeding.  The proceeding has been assigned to Administrative Law Judge Shaw, who presided over the underlying investigation.  On October 14, 2016, we responded to the complaint by, among other things, denying the patent infringement allegations and raising numerous affirmative defenses.

[0001596532-16-000331:notes:46]
Certain Network Devices, Related Software, and Components Thereof (Inv. No. 337-TA-945) (“945 Investigation”)

[0001596532-16-000331:notes:47]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated Section 337 of the Tariff Act of 1930, as amended.  The USITC instituted Cisco’s complaint as Investigation No. 337-TA-945.  Cisco alleges that certain of our switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents.  Cisco seeks, among other things, a limited exclusion order barring entry into the United States of accused switch products (including our 7000 Series of switches) and components and software therein and a cease and desist order against us restricting our activities with respect to our imported accused switch products and components and software therein.  On February 11, 2015, we responded to the notice of investigation and complaint in the 945 Investigation by, among other things, denying the patent infringement allegations and raising numerous affirmative defenses.

[0001596532-16-000331:notes:48]
The ALJ issued a procedural schedule calling for, among other events: an evidentiary hearing on November 9-20, 2015; issuance of an initial determination regarding our alleged violations on April 26, 2016; and a Target Date for completion on August 26, 2016.  On March 29, 2016, the ALJ issued a revised procedural schedule extending the deadline for issuance of an initial determination to August 26, 2016, and extending the Target Date to December 26, 2016.  On April 19, 2016, the Commission determined not to review this decision.  On August 24, 2016, the ALJ issued a revised procedural schedule extending the deadline for issuance of an initial determination to November 7, 2016, and extending the Target Date to March 7, 2016.  On September 7, 2016, the Commission determined not to review this decision.  The Initial Determination will be subject to review by the Commission, which will then issue a Final Determination and any remedial orders by March 7, 2017.  If the Final Determination finds a violation, it will be subject to Presidential review.

[0001596532-16-000331:notes:49]
Inter Partes Reviews

[0001596532-16-000331:notes:50]
We have filed petitions for Inter Partes Review (“IPR”) of the ‘597, ‘211, ‘668, ‘853, ‘537, ‘577, ‘886, and ‘526 patents.  IPRs relating to the ‘597 (IPR No. 2015-00978) and ‘211 (IPR No. 2015-00975) patents were instituted in October 2015 and hearings on these IPRs were completed in July 2016.  On September 28, 2016, the PTAB issued a final written decision finding claims 1, 14, 39-42, 71, 72, 84, and 85 of the ’597 patent unpatentable.  The PTAB also found that claims 29, 63, 64, 73, and 86 of the ’597 patent had not been shown to be unpatentable.  We filed a notice of appeal with respect to this decision regarding claims 29, 63, 64, 73, and 86 on October 11, 2016, and Cisco requested rehearing of the PTAB’s Final Written Decision on October 28, 2016.  On October 5, 2016, the PTAB issued a final written decision finding claims 1 and 12 of the ’211 patent unpatentable.  The PTAB also found that claims 2, 6-9, 13, 17-20 of the ’211 patent had not been shown to be unpatentable.

[0001596532-16-000331:notes:51]
IPRs relating to the ‘668 (IPR No. 2016-00309), ‘577 (IPR No. 2016-00303), ‘853 (IPR No. 2016-0306), and ‘537 (IPR No. 2016-0308) patents were instituted in June 2016 and are set for hearing in March 2017.  Final Written Decisions on these IPRs will be issued by June 2017.

[0001596532-16-000331:notes:52]
We intend to vigorously defend against Cisco’s lawsuits, as summarized in the preceding paragraphs.  However, we cannot be certain that any claims by Cisco would be resolved in our favor regardless of the merit of the claims.  For example, an adverse litigation ruling could result in a significant damages award against us, could further result in the above described injunctive relief, could result in a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products to the extent that we are found to infringe any valid claims asserted against us by Cisco.  Any such adverse ruling could materially adversely affect our business, prospects, reputation, results of operation and financial condition.

[0001596532-16-000331:notes:53]
In particular, in the 944 Investigation, the USITC has issued a limited exclusion order barring entry into the United States of our network devices (including our 7000 Series of switches), related software and components thereof that infringe one or more of the claims of the ʼ537, ʼ592, and ʼ145 patents specified above and a cease and desist order restricting our activities with respect to such imported products.

[0001596532-16-000331:notes:54]
In response to the USITC’s findings in the 944 Investigation, we have made design changes to our products for sale in the United States to address the features that were found to infringe the ‘537, ’592, ’145 patents.  Following the issuance of the final determination in the 944 Investigation, we submitted a Section 177 ruling request to U.S. Customs and Border Protection (“CBP”) seeking approval to import these redesigned products into the United States, and we are awaiting CBP’s decision.  If the USITC finds that we infringe any patent in the 945 Investigation, the USITC is likely to issue remedial orders in that investigation as well.  If such orders are not disapproved by the United States Trade Representative, we would need to further modify our products to take our products outside the scope of any patents we are found to have infringed in the 945 Investigation.  We may not be successful in developing technical design-arounds that do not infringe the patents or that are acceptable to our customers.  Our development efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management.  We may not be successful in our efforts to obtain clearance from CBP to import such modified products in a timely manner, or at all.  While clearance from CBP will allow us to resume importation of our redesigned products into the United States, the USITC could still determine in the enforcement action that our redesigned products continue to infringe the ‘537, ‘592 or ‘145 patents.  Any failure to effectively redesign our products to obtain timely clearance from CBP to import such redesigned products, or to address the USITC’s findings in a manner that is compliant with the limited exclusion order and cease and desist order may cause a disruption in our product shipments and materially and adversely affect our business, prospects, reputation, results of operations, and financial condition.

[0001596532-16-000331:notes:55]
We have also made certain changes to our manufacturing, importation and shipping workflows to comply with the USITC’s remedial orders. These changes have included shifting manufacturing and integration of our products to be sold in the United States to U.S. facilities. Such changes may be extremely costly, time consuming, and we may not be able to implement such changes successfully.  Any failure to successfully change our manufacturing and importation processes or shipping workflows in a manner that is compliant with the limited exclusion order and cease and desist order may cause a disruption in our product shipments and materially and adversely affect our business, prospects, reputation, results of operations, and financial condition.

[0001596532-16-000331:notes:56]
For example, if the USITC determines that our redesigned products continue to infringe the ‘537, ‘592 or ‘145 patents, the USITC may impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000.00 or twice the domestic value of the articles entered or sold, whichever is higher,” bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order” or impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.”

[0001596532-16-000331:notes:57]
Additionally, the existence of Cisco's lawsuits against us could cause concern among our customers and partners and could adversely affect our business and results of operations.  Whether or not we prevail in the lawsuit, we expect that the litigation will be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-16-000331:notes:58]
With respect to the various legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated.  However, the outcome of litigation is inherently uncertain.  Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-16-000331:notes:59]
Other Matters

[0001596532-16-000331:notes:60]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.  We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated.  Based on currently available information, management does not believe that liability relating to these other unresolved matters is probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows.  However, litigation is subject to inherent uncertainties and our view of these matters may change in the future.  Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-16-000331:notes:61]
[same as prior period, unchanged from 0001596532-16-000291:notes:48]

[0001596532-16-000331:notes:62]
[same as prior period, unchanged from 0001596532-16-000291:notes:49]

[0001596532-16-000331:notes:63]
|  | Three Months EndedSeptember 30, | Nine Months EndedSeptember 30, |
|  | 2016 |  | 2015 | 2016 |  | 2015 |
| Cost of revenue | $ | 955 |  |  | $ | 786 |  | $ | 2,616 |  |  | $ | 2,206 |  |
| Research and development | 8,010 |  |  | 7,037 |  | 23,062 |  |  | 18,344 |  |
| Sales and marketing | 3,947 |  |  | 2,864 |  | 11,374 |  |  | 8,138 |  |
| General and administrative | 2,204 |  |  | 1,591 |  | 5,656 |  |  | 3,637 |  |
| Total stock-based compensation | $ | 15,116 |  |  | $ | 12,278 |  | $ | 42,708 |  |  | $ | 32,325 |  |

[0001596532-16-000331:notes:64]
[same as prior period, unchanged from 0001596532-16-000291:notes:51]

[0001596532-16-000331:notes:65]
[same as prior period, unchanged from 0001596532-16-000291:notes:52]

[0001596532-16-000331:notes:66]
|  |  | Options and RSAs Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options and RSAs (in thousands) |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding (in thousands) |
| Outstanding—December 31, 2015 |  | 11,630 |  |  | $ | 24.49 |  |  | 7.6 |  | $ | 620,802 |  |
| Options granted |  | 440 |  |  | 56.88 |  |  |  |  |  |
| Options exercised |  | (1,583 | ) |  | 9.85 |  |  |  |  |  |
| Options canceled |  | (314 | ) |  | 30.22 |  |  |  |  |  |
| Outstanding—September 30, 2016 |  | 10,173 |  |  | $ | 28.00 |  |  | 7.1 |  | $ | 580,661 |  |
| Vested and exercisable—September 30, 2016 |  | 3,685 |  |  | $ | 14.38 |  |  | 6.3 |  | $ | 260,514 |  |
| Vested and expected to vest—September 30, 2016 |  | 9,658 |  |  | $ | 27.39 |  |  | 7.1 |  | $ | 557,170 |  |

[0001596532-16-000331:notes:67]
As of September 30, 2016, the total unrecognized stock-based compensation expense related to unvested stock options, net of expected forfeitures, was $95.4 million, which is expected to be recognized over a weighted-average period of 3.9 years.

[0001596532-16-000331:notes:68]
[same as prior period, unchanged from 0001596532-16-000291:notes:55]

[0001596532-16-000331:notes:69]
[same as prior period, unchanged from 0001596532-16-000291:notes:56]

[0001596532-16-000331:notes:70]
|  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2015 | 893 |  |  | $ | 70.14 |  |  | 1.9 |  | $ | 69,509 |  |
| RSUs granted | 440 |  |  | 63.80 |  |  |  |  |  |
| RSUs vested | (178 | ) |  | 69.66 |  |  |  |  |  |
| RSUs forfeited | (72 | ) |  | 67.06 |  |  |  |  |  |
| Unvested balance—September 30, 2016 | 1,083 |  |  | $ | 67.85 |  |  | 1.7 |  | $ | 92,120 |  |
| Vested and expected to vest—September 30, 2016 | 1,015 |  |  | $ | 67.86 |  |  | 1.7 |  | $ | 86,357 |  |

[0001596532-16-000331:notes:71]
As of September 30, 2016, there was $61.4 million of unrecognized stock-based compensation cost related to unvested RSUs, net of estimated forfeitures. This amount is expected to be recognized over a weighted-average period of 3.3 years.

[0001596532-16-000331:notes:72]
[same as prior period, unchanged from 0001596532-16-000291:notes:59]

[0001596532-16-000331:notes:73]
During the nine months ended September 30, 2016, we issued 256,223 shares at a weighted average purchase price of $40.30 under the 2014 Employee Stock Purchase Plan ("ESPP"). On February 17, 2015, the board authorized an increase to shares available for future issuance under the ESPP.  Per the ESPP, the increase is determined based on the lesser of 1% of total shares outstanding as of the first day of each fiscal year, or January 1, 2016, 2,500,000 shares or such amount as determined by our board of directors. The approved increase for 2016 amounted to 681,315 shares.  As of September 30, 2016, there remain 1,483,846 shares available for issuance under the ESPP.

[0001596532-16-000331:notes:74]
As of September 30, 2016, the total unrecognized stock-based compensation expense related to unvested ESPP options, net of expected forfeitures, was $6.1 million, which is expected to be recognized over a weighted-average period of 1.8 years.

[0001596532-16-000331:notes:75]
[same as prior period, unchanged from 0001596532-16-000291:notes:62]


## us-gaap:EarningsPerShareTextBlock

[0001596532-16-000331:notes:76]
[same as prior period, unchanged from 0001596532-16-000291:notes:63]

[0001596532-16-000331:notes:77]
[same as prior period, unchanged from 0001596532-16-000291:notes:64]

[0001596532-16-000331:notes:78]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Numerator: |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |
| Net income | $ | 51,257 |  |  | $ | 28,690 |  |  | $ | 125,406 |  |  | $ | 77,178 |  |
| Less: undistributed earnings allocated to participating securities | (295 | ) |  | (389 | ) |  | (931 | ) |  | (1,314 | ) |
| Net income available to common stockholders, basic | $ | 50,962 |  |  | $ | 28,301 |  |  | $ | 124,475 |  |  | $ | 75,864 |  |
| Diluted: |  |  |  |  |  |  |  |
| Net income attributable to common stockholders, basic | $ | 50,962 |  |  | $ | 28,301 |  |  | $ | 124,475 |  |  | $ | 75,864 |  |
| Add: undistributed earnings allocated to participating securities | 18 |  |  | 28 |  |  | 56 |  |  | $ | 103 |  |
| Net income attributable to common stockholders, diluted | $ | 50,980 |  |  | $ | 28,329 |  |  | $ | 124,531 |  |  | $ | 75,967 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 69,076 |  |  | 66,629 |  |  | 68,365 |  |  | 65,609 |  |
| Diluted: |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 69,076 |  |  | 66,629 |  |  | 68,365 |  |  | 65,609 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options and RSUs | 4,357 |  |  | 5,163 |  |  | 4,429 |  |  | 5,529 |  |
| Employee stock purchase plan | 20 |  |  | 95 |  |  | 17 |  |  | 94 |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted | 73,453 |  |  | 71,887 |  |  | 72,811 |  |  | 71,232 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 0.74 |  |  | $ | 0.42 |  |  | $ | 1.82 |  |  | $ | 1.16 |  |
| Diluted | $ | 0.69 |  |  | $ | 0.39 |  |  | $ | 1.71 |  |  | $ | 1.07 |  |

[0001596532-16-000331:notes:79]
[same as prior period, unchanged from 0001596532-16-000291:notes:66]

[0001596532-16-000331:notes:80]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Stock options and RSUs to purchase common stock | 2,688 |  |  | 2,544 |  |  | 3,215 |  |  | 2,275 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-16-000331:notes:81]
[same as prior period, unchanged from 0001596532-16-000291:notes:68]

[0001596532-16-000331:notes:82]
|  | September 30, 2016 |
|  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 304,926 |  |  | $ | — |  |  | $ | — |  |  | $ | 304,926 |  |
| Money market funds-restricted | 4,041 |  |  | — |  |  | — |  |  | 4,041 |  |
| Commercial Paper | 11,997 |  |  | — |  |  | — |  |  | 11,997 |  |
| U.S. government notes | 139,499 |  |  | — |  |  | — |  |  | 139,499 |  |
| Corporate bonds | — |  |  | 148,171 |  |  | — |  |  | 148,171 |  |
| Total financial assets | $ | 460,463 |  |  | $ | 148,171 |  |  | $ | — |  |  | $ | 608,634 |  |

[0001596532-16-000331:notes:83]
[same as prior period, unchanged from 0001596532-16-000291:notes:70]


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-16-000331:notes:84]
[same as prior period, unchanged from 0001596532-16-000291:notes:71]

[0001596532-16-000331:notes:85]
[same as prior period, unchanged from 0001596532-16-000291:notes:72]

[0001596532-16-000331:notes:86]
[same as prior period, unchanged from 0001596532-16-000291:notes:73]

[0001596532-16-000331:notes:87]
[same as prior period, unchanged from 0001596532-16-000291:notes:74]

[0001596532-16-000331:notes:88]
[same as prior period, unchanged from 0001596532-16-000291:notes:75]

[0001596532-16-000331:notes:89]
[same as prior period, unchanged from 0001596532-16-000291:notes:76]

[0001596532-16-000331:notes:90]
[same as prior period, unchanged from 0001596532-16-000291:notes:77]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-16-000331:notes:91]
[same as prior period, unchanged from 0001596532-16-000291:notes:78]

[0001596532-16-000331:notes:92]
Provision for income taxes was approximately $11.7 million and $1.9 million for the three months ended September 30, 2016 and 2015, and $39.7 million and $20.3 million for the nine months ended September 30, 2016 and 2015, respectively. The change in the provision was a result of an increase in profit before income taxes and the change in effective tax rate based on current geographical distribution of the earnings.

[0001596532-16-000331:notes:93]
[same as prior period, unchanged from 0001596532-16-000291:notes:80]

[0001596532-16-000331:notes:94]
[same as prior period, unchanged from 0001596532-16-000291:notes:81]

[0001596532-16-000331:notes:95]
Our gross unrecognized tax benefits as of September 30, 2016 were $20.2 million.  If the gross unrecognized tax benefits as of September 30, 2016 were realized in future periods, this could result in a tax benefit of $11.4 million within our provision of income taxes.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001596532-16-000331:notes:96]
[same as prior period, unchanged from 0001596532-16-000291:notes:83]

[0001596532-16-000331:notes:97]
[same as prior period, unchanged from 0001596532-16-000291:notes:84]

[0001596532-16-000331:notes:98]
As of September 30, 2016 and December 31, 2015, we held non-marketable equity investments of approximately $36.1 million and $33.6 million, respectively, in privately-held companies which are accounted for under the cost method. During the prior quarter ended June 30, 2016 we made an additional investment of $2.5 million in one of these companies, which was accounted for under the cost method. There were no impairments recognized on our investments for the nine months ended September 30, 2016.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-16-000331:notes:99]
In May 2014, the FASB issued ASU No. 2014-09, Revenue From Contracts With Customers (Topic 606), (as amended in June 2016, by ASU No. 2016-12-Revenue-Narrow-Scope Improvements and Practical Expedients), which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition.

[0001596532-16-000331:notes:100]
In July 2015, the FASB issued ASU No. 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, deferring the effective date of the new revenue standard by one year. In March 2016, the FASB issued ASU No. 2016-08, Revenue From Contracts With Customers-Principal versus Agent Considerations (Reporting Revenue Gross versus Net), and ASU No. 2016-10, Revenue From Contracts With Customers-Identifying Performance Obligations and Licensing. ASU No. 2016-08 clarifies the implementation guidance regarding principal versus agent identification and related considerations. Specifically, the guidance provides clarification around performance obligations for goods or services provided by another entity, assisting in determining whether the entity is the provider of the goods or services, the principal, or whether the entity is providing for the arrangement of the goods or services, the agent.  ASU No. 2016-10 provides guidance around identifying whether promised goods or services are distinct and separately identifiable, whether promised goods or services are material or immaterial to the contract, and whether shipping and handling is considered an activity to fulfill a promise or an additional promised service. ASU No. 2016-10 also provides guidance around an entity's promise to grant a license providing a customer with either a right to use or a right to access the license, which then determines whether the obligation is satisfied at a point in time or over time, respectively.

[0001596532-16-000331:notes:101]
In May 2016, the FASB issued ASU No. 2016-11, Revenue Recognition (Topic 605) and Derivatives and Hedging (Topic 815): Rescission of SEC Guidance Because of Accounting Standards Updates 2014-09 and 2014-16 Pursuant to Staff Announcements at the March 3, 2016 EITF Meeting (SEC Update)") ("ASU 2016-11"), which rescinds various standards codified as part of Topic 605, Revenue Recognition in relation to the future adoption of Topic 606. These rescissions include changes to topics pertaining to revenue and expense recognition including accounting for shipping and handling fees and costs and accounting for consideration given by a vendor to a customer.

[0001596532-16-000331:notes:102]
The above standards are effective for fiscal years (and interim reporting periods within those years) beginning after December 15, 2017.  The guidance is effective for us beginning in our first quarter of fiscal 2018. Early adoption would be permitted for all entities but not until the fiscal year beginning after December 15, 2016. The standard permits the use of either the retrospective or cumulative effect transition method. The retrospective method requires a retrospective approach to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance. The cumulative approach requires a retrospective approach with the cumulative effect of initially applying the guidance recognized at the date. of initial application and providing certain additional disclosures as defined per the guidance. We plan to adopt the standards our first quarter of fiscal 2018. We are currently reviewing the provisions of the standard and have not yet selected a transition method nor have we determined the effect of the standard on our consolidated financial statements.

[0001596532-16-000331:notes:103]
In January 2016, the FASB issued ASU No, 2016-01, Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities, which enhances the reporting model for financial instruments to provide users of financial statements with more decision-useful information. The guidance will address certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. The standard is effective for us for our first quarter of fiscal 2018.  The guidance may be early adopted under early application guidance. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

[0001596532-16-000331:notes:104]
In February 2016, the FASB issued ASU No, 2016-02, Leases, which addresses the classification and recognition of lease assets and liabilities formerly classified as operating leases under GAAP. The guidance will address certain aspects of recognition and measurement, and quantitative and qualitative aspects of presentation and disclosure. The guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. The standard is effective for us for our first quarter of fiscal 2019.  The guidance will be applied to the earliest period presented using a modified retrospective approach. The guidance includes practical expedients that relate to identification, classification, and initial direct costs associated with leases commencing prior to the effective date, and the ability to apply hindsight in evaluating lease options related to extensions, terminations or asset purchases.  A practical expedient also exists to treat leases entered into prior effective date under existing GAAP unless the lease has been modified. The guidance may be early adopted. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

[0001596532-16-000331:notes:105]
In March 2016, the FASB amended the existing accounting standards for stock-based compensation, ASU 2016-09, Compensation-Stock Compensation: Improvements to Employee Share-Based Payment Accounting, which impact several aspects of accounting for share-based payment transactions, including the income tax consequences, forfeitures, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The standard is effective for us for our first quarter of fiscal 2017.  The guidance may be early adopted under early application guidance. If early adoption is elected, all amendments must be adopted in the same period. The manner of application varies by the various provisions of the guidance, with certain provisions applied on a retrospective or modified retrospective approach, while others are applied prospectively.  We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

[0001596532-16-000331:notes:106]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Task Force), which addresses eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. The guidance may be adopted early as of the beginning of an annual reporting period.  The guidance will be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  The standard is effective for us for our first quarter of fiscal 2018.  We are currently assessing the impact this guidance may have on our consolidated financial statements.

[0001596532-16-000331:notes:107]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which addresses recognition of current and deferred income taxes for intra-entity asset transfers when assets are sold to an outside party. Current GAAP prohibits the recognition of current and deferred income taxes until the asset has been sold to an outside party. This prohibition on recognition is considered an exception to the principle of comprehensive recognition of current and deferred income taxes in GAAP.  The new guidance requires an entity to recognize the income tax consequences when the transfer occurs eliminating the exception.  The guidance will be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  The standard is effective for us for our first quarter of fiscal 2018, and may be early adopted under early application guidance.  We are currently assessing the impact this guidance may have on our consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-16-000331:notes:108]
[same as prior period, unchanged from 0001596532-16-000291:notes:96]

[0001596532-16-000331:notes:109]
[same as prior period, unchanged from 0001596532-16-000291:notes:97]

[0001596532-16-000331:notes:110]
[same as prior period, unchanged from 0001596532-16-000291:notes:98]

[0001596532-16-000331:notes:111]
[same as prior period, unchanged from 0001596532-16-000291:notes:99]

[0001596532-16-000331:notes:112]
[same as prior period, unchanged from 0001596532-16-000291:notes:100]

[0001596532-16-000331:notes:113]
[same as prior period, unchanged from 0001596532-16-000291:notes:101]

[0001596532-16-000331:notes:114]
[same as prior period, unchanged from 0001596532-16-000291:notes:102]

[0001596532-16-000331:notes:115]
[same as prior period, unchanged from 0001596532-16-000291:notes:103]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001596532-16-000331:notes:116]
[same as prior period, unchanged from 0001596532-16-000291:notes:104]

[0001596532-16-000331:notes:117]
|  | September 30, 2016 |  | December 31, 2015 |
| Equipment and machinery | $ | 38,269 |  |  | $ | 29,101 |  |
| Computer hardware and software | 16,840 |  |  | 12,630 |  |
| Furniture and fixtures | 2,865 |  |  | 2,380 |  |
| Leasehold improvements | 29,504 |  |  | 24,372 |  |
| Building | 35,154 |  |  | 35,154 |  |
| Construction-in-process | 304 |  |  | 6,408 |  |
| Property and equipment, gross | 122,936 |  |  | 110,045 |  |
| Less: accumulated depreciation | (44,789 | ) |  | (30,339 | ) |
| Property and equipment, net | $ | 78,147 |  |  | $ | 79,706 |  |


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001596532-16-000331:notes:118]
[same as prior period, unchanged from 0001596532-16-000291:notes:106]

[0001596532-16-000331:notes:119]
|  | September 30, 2016 |  | December 31, 2015 |
| Accounts receivable | $ | 211,783 |  |  | $ | 145,792 |  |
| Allowance for doubtful accounts | (291 | ) |  | (963 | ) |
| Sales return reserve | (1,249 | ) |  | (566 | ) |
| Accounts receivable, net | $ | 210,243 |  |  | $ | 144,263 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001596532-16-000331:notes:120]
[same as prior period, unchanged from 0001596532-16-000291:notes:108]

[0001596532-16-000331:notes:121]
|  | September 30, 2016 |  | December 31, 2015 |
| Accrued compensation costs | $ | 41,695 |  |  | $ | 39,479 |  |
| Accrued warranty costs | 5,597 |  |  | 4,718 |  |
| Accrued manufacturing costs | 14,558 |  |  | 6,397 |  |
| Accrued professional fees | 6,827 |  |  | 4,875 |  |
| Accrued taxes | 1,320 |  |  | 1,347 |  |
| Other | 7,166 |  |  | 4,155 |  |
| Total accrued liabilities | $ | 77,163 |  |  | $ | 60,971 |  |


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001596532-16-000331:notes:122]
[same as prior period, unchanged from 0001596532-16-000291:notes:110]

[0001596532-16-000331:notes:123]
|  | September 30, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper | $ | 11,941 |  |  | $ | 56 |  |  | $ | — |  |  | $ | 11,997 |  |
| U.S. government notes | 139,509 |  |  | 22 |  |  | (32 | ) |  | 139,499 |  |
| Corporate bonds | 148,123 |  |  | 153 |  |  | (105 | ) |  | 148,171 |  |
| Total marketable securities | $ | 299,573 |  |  | $ | 231 |  |  | $ | (137 | ) |  | $ | 299,667 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001596532-16-000331:notes:124]
[same as prior period, unchanged from 0001596532-16-000291:notes:112]

[0001596532-16-000331:notes:125]
|  | September 30, 2016 |  | December 31, 2015 |
| Raw materials | $ | 64,610 |  |  | $ | 29,831 |  |
| Finished goods | 97,518 |  |  | 62,298 |  |
| Total inventories | $ | 162,128 |  |  | $ | 92,129 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001596532-16-000331:notes:126]
[same as prior period, unchanged from 0001596532-16-000291:notes:114]

[0001596532-16-000331:notes:127]
|  | September 30, 2016 |  | December 31, 2015 |
| Inventory deposit | $ | 62,576 |  |  | $ | — |  |
| Prepaid income taxes | 22,817 |  |  | 14,150 |  |
| Other current assets | 55,363 |  |  | 29,270 |  |
| Other prepaid expenses and deposits | 10,903 |  |  | 7,190 |  |
| Total prepaid expenses and other current assets | $ | 151,659 |  |  | $ | 50,610 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001596532-16-000331:notes:128]
[same as prior period, unchanged from 0001596532-16-000291:notes:116]

[0001596532-16-000331:notes:129]
|  | Nine Months EndedSeptember 30, |
|  | 2016 |  | 2015 |
| Warranty accrual, beginning of period | $ | 4,718 |  |  | $ | 3,204 |  |
| Liabilities accrued for warranties issued during the period | 3,717 |  |  | 3,352 |  |
| Warranty costs incurred during the period | (2,541 | ) |  | (1,765 | ) |
| Adjustments related to change in estimate | (297 | ) |  | — |  |
| Warranty accrual, end of period | $ | 5,597 |  |  | $ | 4,791 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001596532-16-000331:notes:130]
[same as prior period, unchanged from 0001596532-16-000291:notes:118]

[0001596532-16-000331:notes:131]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| United States | $ | 233,018 |  |  | $ | 166,466 |  |  | $ | 612,852 |  |  | $ | 437,922 |  |
| Other Americas | 4,081 |  |  | 4,130 |  |  | 8,205 |  |  | 10,294 |  |
| Europe, Middle East and Africa | 37,728 |  |  | 29,457 |  |  | 124,111 |  |  | 94,329 |  |
| Asia-Pacific | 15,434 |  |  | 17,495 |  |  | 56,030 |  |  | 49,600 |  |
| Total revenue | $ | 290,261 |  |  | $ | 217,548 |  |  | $ | 801,198 |  |  | $ | 592,145 |  |

[0001596532-16-000331:notes:132]
[same as prior period, unchanged from 0001596532-16-000291:notes:120]

[0001596532-16-000331:notes:133]
|  | September 30, 2016 |  | December 31, 2015 |
| United States | $ | 70,095 |  |  | $ | 70,719 |  |
| International | 8,052 |  |  | 8,987 |  |
| Total | $ | 78,147 |  |  | $ | 79,706 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-16-000331:notes:134]
[same as prior period, unchanged from 0001596532-16-000291:notes:122]

[0001596532-16-000331:notes:135]
[same as prior period, unchanged from 0001596532-16-000291:notes:123]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-16-000331:notes:136]
[same as prior period, unchanged from 0001596532-16-000291:notes:124]

[0001596532-16-000331:notes:137]
[same as prior period, unchanged from 0001596532-16-000291:notes:125]

[0001596532-16-000331:notes:138]
As of September 30, 2016, there have been no other-than-temporary losses on our marketable securities. None of our marketable securities have been in continuous unrealized loss positions for greater than twelve months as of September 30, 2016.  We had no marketable securities as of December 31, 2015.

[0001596532-16-000331:notes:139]
[same as prior period, unchanged from 0001596532-16-000291:notes:127]

[0001596532-16-000331:notes:140]
The weighted average remaining duration of our current marketable securities is approximately 0.8 years as of September 30, 2016.  As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying consolidated balance sheets.

[0001596532-16-000331:notes:141]
[same as prior period, unchanged from 0001596532-16-000291:notes:129]

[0001596532-16-000331:notes:142]
[same as prior period, unchanged from 0001596532-16-000291:notes:130]

[0001596532-16-000331:notes:143]
[same as prior period, unchanged from 0001596532-16-000291:notes:131]

[0001596532-16-000331:notes:144]
[same as prior period, unchanged from 0001596532-16-000291:notes:132]

[0001596532-16-000331:notes:145]
Building consists of capitalized construction costs of our leased building in Santa Clara, California. Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction, such as our financial involvement in structural elements of asset construction, making decisions related to tenant improvement costs and purchasing insurance not reimbursable by the buyer-lessor (the "Landlord"), we were deemed the owner of the building (for accounting purposes only) during the construction period. We continue to maintain involvement in the property post construction completion, and lack transferability of the risks and rewards of ownership, due to our required maintenance of a $4.0 million letter of credit, in addition to our ability and option to sublease our portion of the leased building for fees substantially higher than our base rate.  Due to our continuing involvement in the property post construction and lack of transferability of related risks and rewards of ownership to the Landlord after construction completion, we account for the building as a financing obligation. See “Note 5 - Commitments and Contingencies".  Accordingly, as of September 30, 2016 and December 31, 2015, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the Landlord. The building was completed in 2014.

[0001596532-16-000331:notes:146]
Depreciation and amortization expense was $5.1 million and $3.4 million for the three months ended September 30, 2016 and 2015, respectively, and was $14.8 million, and $9.7 million for the nine months ended September 30, 2016 and 2015, respectively.

[0001596532-16-000331:notes:147]
[same as prior period, unchanged from 0001596532-16-000291:notes:135]

[0001596532-16-000331:notes:148]
[same as prior period, unchanged from 0001596532-16-000291:notes:136]

[0001596532-16-000331:notes:149]
[same as prior period, unchanged from 0001596532-16-000291:notes:137]
