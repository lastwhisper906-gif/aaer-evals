# ANET MD&A — 0001596532-16-000331


## mdna

[0001596532-16-000331:mdna:1]
[same as prior period, unchanged from 0001596532-16-000291:mdna:1]

[0001596532-16-000331:mdna:2]
[same as prior period, unchanged from 0001596532-16-000291:mdna:2]

[0001596532-16-000331:mdna:3]
[same as prior period, unchanged from 0001596532-16-000291:mdna:3]

[0001596532-16-000331:mdna:4]
We were founded in 2004 to address the limitations of legacy networking products and to create a cloud networking platform that is open and programmable. From 2004 to 2008, our activities were focused on the development of our software, which resulted in the commercial release of our first product, the 7100 Series switches based on our EOS software, in 2008. Since then, we have continued to introduce new products utilizing EOS, including our 7500 Series switch and our 7050 Series switch in 2010, the second generation of our 7500 Series switch, called the 7500E modular switch, in May 2013, our 7300 Series switch in November 2013, and our 7280E in July 2014.  In December 2014, we introduced our EOS+ software platform for networking programmability and automation, and in June 2015 we introduced CloudVision, a network-wide approach for workload orchestration and workflow automation.  In September 2015, we introduced our Macro Segmentation Services, or MSS, to provide automated insertion of security and other in-line layer 4-7 services within any software driven cloud networking infrastructure. MSS has been endorsed by many of our technology alliance ecosystem partners with whom we are currently partnering with to deliver MSS platform support. In addition, during 2015, we introduced our first 10/25/40/50/100G switches with our 7060, 7260 and 7320 series switches. In January 2016, we unveiled NetDB, the network-wide, state-oriented database that enhances the core system database (SysDB) of Arista EOS.  NetDB builds upon the SysDB architecture by adding software infrastructure improvements, including state-sharing and replication mechanisms for centrally storing network state, increased software table capacities up to 1M routes, and the ability to stream state in realtime from EOS devices. This extends the benefits of the state-based system across the entire network. During March 2016, we introduced our 7500R series, building on the 7500E series and providing 100GbE density and large table sizes in a single chassis. At up to 115 Tbps capacity, the 7500R supports up to one million routes, subsuming switching and routing functions into a Universal Spine platform for cloud-scale networks. In June 2016, we introduced our Arista 7280R Universal Leaf Network Platform, a compact form factor capable of a broad set of leaf networking use-cases, including IP storage, routing and digital media. In August 2016, we introduced our next-generation CloudVision and EOS telemetry and analytics capabilities designed for modern cloud networks.

[0001596532-16-000331:mdna:5]
As of September 30, 2016, we have shipped more than 10 million cloud networking ports worldwide.  We have experienced rapid revenue growth over the last several years, increasing our revenue at a compound annual growth rate of 56.4% from 2011 to 2015. As we have grown the functionality of our EOS software, expanded the range of our switching portfolio and increased the size of our sales force, our revenue has continued to grow rapidly. To support our customers and revenue growth, we have expanded our international presence to include 23 foreign subsidiaries as of September 30, 2016, including Australia, Canada, France, Germany, India, Ireland, Japan, South Korea and the United Kingdom. Our revenue for the three and nine months ended September 30, 2016 was $290.3 million and $801.2 million, respectively an increase of 33.4% and 35.3% compared to the same periods in 2015, respectively. We have been profitable and cash flow positive for each year since 2010.

[0001596532-16-000331:mdna:6]
[same as prior period, unchanged from 0001596532-16-000291:mdna:6]

[0001596532-16-000331:mdna:7]
[same as prior period, unchanged from 0001596532-16-000291:mdna:7]

[0001596532-16-000331:mdna:8]
[same as prior period, unchanged from 0001596532-16-000291:mdna:8]

[0001596532-16-000331:mdna:9]
Since shipping our first products in 2008, our cumulative end-customer base has grown rapidly. Between December 31, 2011 and September 30, 2016, our cumulative end-customer base grew from approximately 1,100 to over 4,100. Our end customers span a range of industries and include large Internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others.

[0001596532-16-000331:mdna:10]
[same as prior period, unchanged from 0001596532-16-000291:mdna:10]

[0001596532-16-000331:mdna:11]
[same as prior period, unchanged from 0001596532-16-000291:mdna:11]

[0001596532-16-000331:mdna:12]
[same as prior period, unchanged from 0001596532-16-000291:mdna:12]

[0001596532-16-000331:mdna:13]
We believe that our future success will depend on many factors, including our ability to expand sales to our existing customers as well as to add new end customers. While these areas present significant opportunity, they also present risks that we must manage to ensure successful results. See the section titled “Risk Factors.” Additionally, we face intense competition especially from larger, well-established companies, and we must continue to expand the capabilities of our cloud networking platform to succeed in our market. We are also currently engaged in lawsuits with Cisco, our largest competitor, whereby they claim that we have infringed their intellectual property rights.  We intend to vigorously defend against these Cisco lawsuits as summarized in the Legal Proceedings section below. However, we cannot be certain that any claims by Cisco would be resolved in our favor.  If we are unable to address these challenges, our business could be adversely affected.

[0001596532-16-000331:mdna:14]
[same as prior period, unchanged from 0001596532-16-000291:mdna:14]

[0001596532-16-000331:mdna:15]
[same as prior period, unchanged from 0001596532-16-000291:mdna:15]

[0001596532-16-000331:mdna:16]
[same as prior period, unchanged from 0001596532-16-000291:mdna:16]

[0001596532-16-000331:mdna:17]
[same as prior period, unchanged from 0001596532-16-000291:mdna:17]

[0001596532-16-000331:mdna:18]
[same as prior period, unchanged from 0001596532-16-000291:mdna:18]

[0001596532-16-000331:mdna:19]
[same as prior period, unchanged from 0001596532-16-000291:mdna:19]

[0001596532-16-000331:mdna:20]
[same as prior period, unchanged from 0001596532-16-000291:mdna:20]

[0001596532-16-000331:mdna:21]
[same as prior period, unchanged from 0001596532-16-000291:mdna:21]

[0001596532-16-000331:mdna:22]
[same as prior period, unchanged from 0001596532-16-000291:mdna:22]

[0001596532-16-000331:mdna:23]
[same as prior period, unchanged from 0001596532-16-000291:mdna:23]

[0001596532-16-000331:mdna:24]
[same as prior period, unchanged from 0001596532-16-000291:mdna:24]

[0001596532-16-000331:mdna:25]
[same as prior period, unchanged from 0001596532-16-000291:mdna:25]

[0001596532-16-000331:mdna:26]
[same as prior period, unchanged from 0001596532-16-000291:mdna:26]

[0001596532-16-000331:mdna:27]
[same as prior period, unchanged from 0001596532-16-000291:mdna:27]

[0001596532-16-000331:mdna:28]
[same as prior period, unchanged from 0001596532-16-000291:mdna:28]

[0001596532-16-000331:mdna:29]
[same as prior period, unchanged from 0001596532-16-000291:mdna:29]

[0001596532-16-000331:mdna:30]
[same as prior period, unchanged from 0001596532-16-000291:mdna:30]

[0001596532-16-000331:mdna:31]
[same as prior period, unchanged from 0001596532-16-000291:mdna:31]

[0001596532-16-000331:mdna:32]
[same as prior period, unchanged from 0001596532-16-000291:mdna:32]

[0001596532-16-000331:mdna:33]
[same as prior period, unchanged from 0001596532-16-000291:mdna:33]

[0001596532-16-000331:mdna:34]
[same as prior period, unchanged from 0001596532-16-000291:mdna:34]

[0001596532-16-000331:mdna:35]
General and administrative expenses consist primarily of personnel costs, legal and professional fees, and an allocated portion of facility and IT costs and depreciation. General and administrative personnel costs include those for our executive, finance, IT, human resources and legal functions. Our professional fees consist primarily of accounting, external legal and IT and other consulting costs. Refer to the discussion under “Legal Proceedings” subheading in Note 5. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for information related to pending litigation.

[0001596532-16-000331:mdna:36]
[same as prior period, unchanged from 0001596532-16-000291:mdna:36]

[0001596532-16-000331:mdna:37]
[same as prior period, unchanged from 0001596532-16-000291:mdna:37]

[0001596532-16-000331:mdna:38]
[same as prior period, unchanged from 0001596532-16-000291:mdna:38]

[0001596532-16-000331:mdna:39]
[same as prior period, unchanged from 0001596532-16-000291:mdna:39]

[0001596532-16-000331:mdna:40]
[same as prior period, unchanged from 0001596532-16-000291:mdna:40]

[0001596532-16-000331:mdna:41]
[same as prior period, unchanged from 0001596532-16-000291:mdna:41]

[0001596532-16-000331:mdna:42]
[same as prior period, unchanged from 0001596532-16-000291:mdna:42]

[0001596532-16-000331:mdna:43]
[same as prior period, unchanged from 0001596532-16-000291:mdna:43]

[0001596532-16-000331:mdna:44]
[same as prior period, unchanged from 0001596532-16-000291:mdna:44]

[0001596532-16-000331:mdna:45]
[same as prior period, unchanged from 0001596532-16-000291:mdna:45]

[0001596532-16-000331:mdna:46]
[same as prior period, unchanged from 0001596532-16-000291:mdna:46]

[0001596532-16-000331:mdna:47]
The following table summarizes historical results of operations for the periods presented and as a percentage of revenue for those periods.  We have derived the data for the three and nine months ended September 30, 2016 and 2015 from our unaudited condensed consolidated financial statements (in thousands, except for percentages).

[0001596532-16-000331:mdna:48]
|  | Three Months EndedSeptember 30, | Nine Months EndedSeptember 30, |
|  | 2016 |  | 2015 | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |  |
| Product | $ | 254,238 |  |  | $ | 193,339 |  | $ | 702,329 |  |  | $ | 527,552 |  |
| Service | 36,023 |  |  | 24,209 |  | 98,869 |  |  | 64,593 |  |
| Total revenue | 290,261 |  |  | 217,548 |  | 801,198 |  |  | 592,145 |  |
| Cost of revenue (1): |  |  |  |  |  |  |
| Product | 94,777 |  |  | 67,990 |  | 261,711 |  |  | 182,443 |  |
| Service | 9,064 |  |  | 7,810 |  | 26,526 |  |  | 22,310 |  |
| Total cost of revenue | 103,841 |  |  | 75,800 |  | 288,237 |  |  | 204,753 |  |
| Gross profit | 186,420 |  |  | 141,748 |  | 512,961 |  |  | 387,392 |  |
| Operating expenses (1): |  |  |  |  |  |  |
| Research and development | 70,648 |  |  | 58,748 |  | 202,183 |  |  | 152,035 |  |
| Sales and marketing | 33,216 |  |  | 26,508 |  | 92,566 |  |  | 77,776 |  |
| General and administrative | 19,535 |  |  | 25,195 |  | 52,298 |  |  | 57,670 |  |
| Total operating expenses | 123,399 |  |  | 110,451 |  | 347,047 |  |  | 287,481 |  |
| Income from operations | 63,021 |  |  | 31,297 |  | 165,914 |  |  | 99,911 |  |
| Interest expense | (735 | ) |  | (753 | ) | (2,218 | ) |  | (2,406 | ) |
| Other income (expense), net | 639 |  |  | 13 |  | 1,392 |  |  | (38 | ) |
| Total other income (expense), net | (96 | ) |  | (740 | ) | (826 | ) |  | (2,444 | ) |
| Income before provision for income taxes | 62,925 |  |  | 30,557 |  | 165,088 |  |  | 97,467 |  |
| Provision for income taxes | 11,668 |  |  | 1,867 |  | 39,682 |  |  | 20,289 |  |
| Net income | $ | 51,257 |  |  | $ | 28,690 |  | $ | 125,406 |  |  | $ | 77,178 |  |

[0001596532-16-000331:mdna:49]
[same as prior period, unchanged from 0001596532-16-000291:mdna:49]

[0001596532-16-000331:mdna:50]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (as a percentage of revenue) |
| Revenue: |  |  |  |  |  |  |  |
| Product | 87.6 | % |  | 88.9 | % |  | 87.7 | % |  | 89.1 | % |
| Service | 12.4 |  |  | 11.1 |  |  | 12.3 |  |  | 10.9 |  |
| Total revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 32.7 |  |  | 31.2 |  |  | 32.7 |  |  | 30.8 |  |
| Service | 3.1 |  |  | 3.6 |  |  | 3.3 |  |  | 3.8 |  |
| Total cost of revenue | 35.8 |  |  | 34.8 |  |  | 36.0 |  |  | 34.6 |  |
| Gross margin | 64.2 |  |  | 65.2 |  |  | 64.0 |  |  | 65.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 24.3 |  |  | 27.0 |  |  | 25.2 |  |  | 25.7 |  |
| Sales and marketing | 11.5 |  |  | 12.2 |  |  | 11.6 |  |  | 13.1 |  |
| General and administrative | 6.7 |  |  | 11.6 |  |  | 6.5 |  |  | 9.8 |  |
| Total operating expenses | 42.5 |  |  | 50.8 |  |  | 43.3 |  |  | 48.6 |  |
| Income from operations | 21.7 |  |  | 14.4 |  |  | 20.7 |  |  | 16.8 |  |
| Interest expense | (0.2 | ) |  | (0.3 | ) |  | (0.3 | ) |  | (0.4 | ) |
| Other income (expense), net | 0.2 |  |  | — |  |  | 0.2 |  |  | — |  |
| Total other income (expense), net | — |  |  | (0.3 | ) |  | (0.1 | ) |  | (0.4 | ) |
| Income before provision for income taxes | 21.7 |  |  | 14.1 |  |  | 20.6 |  |  | 16.4 |  |
| Provision for income taxes | 4.0 |  |  | 0.9 |  |  | 5.0 |  |  | 3.4 |  |
| Net income | 17.7 | % |  | 13.2 | % |  | 15.6 | % |  | 13.0 | % |

[0001596532-16-000331:mdna:51]
[same as prior period, unchanged from 0001596532-16-000291:mdna:51]

[0001596532-16-000331:mdna:52]
[same as prior period, unchanged from 0001596532-16-000291:mdna:52]

[0001596532-16-000331:mdna:53]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cost of revenue | $ | 955 |  |  | $ | 786 |  |  | $ | 2,616 |  |  | $ | 2,206 |  |
| Research and development | 8,010 |  |  | 7,037 |  |  | 23,062 |  |  | 18,344 |  |
| Sales and marketing | 3,947 |  |  | 2,864 |  |  | 11,374 |  |  | 8,138 |  |
| General and administrative | 2,204 |  |  | 1,591 |  |  | 5,656 |  |  | 3,637 |  |
| Total stock-based compensation | $ | 15,116 |  |  | $ | 12,278 |  |  | $ | 42,708 |  |  | $ | 32,325 |  |

[0001596532-16-000331:mdna:54]
[same as prior period, unchanged from 0001596532-16-000291:mdna:54]

[0001596532-16-000331:mdna:55]
Three and Nine Months Ended September 30, 2016 Compared to Three and Nine Months Ended September 30, 2015

[0001596532-16-000331:mdna:56]
[same as prior period, unchanged from 0001596532-16-000291:mdna:56]

[0001596532-16-000331:mdna:57]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2016 |  | 2015 |  | Change in |  | 2016 |  | 2015 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 254,238 |  |  | $ | 193,339 |  |  | $ | 60,899 |  |  | 31.5% |  | $ | 702,329 |  |  | $ | 527,552 |  |  | $ | 174,777 |  |  | 33.1% |
| Service | 36,023 |  |  | 24,209 |  |  | 11,814 |  |  | 48.8 |  | 98,869 |  |  | 64,593 |  |  | 34,276 |  |  | 53.1 |
| Total revenue | 290,261 |  |  | 217,548 |  |  | 72,713 |  |  | 33.4 |  | 801,198 |  |  | 592,145 |  |  | 209,053 |  |  | 35.3 |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 94,777 |  |  | 67,990 |  |  | 26,787 |  |  | 39.4 |  | 261,711 |  |  | 182,443 |  |  | 79,268 |  |  | 43.4 |
| Service | 9,064 |  |  | 7,810 |  |  | 1,254 |  |  | 16.1 |  | 26,526 |  |  | 22,310 |  |  | 4,216 |  |  | 18.9 |
| Total cost of revenue | 103,841 |  |  | 75,800 |  |  | 28,041 |  |  | 37.0 |  | 288,237 |  |  | 204,753 |  |  | 83,484 |  |  | 40.8 |
| Gross profit | $ | 186,420 |  |  | $ | 141,748 |  |  | $ | 44,672 |  |  | 31.5% |  | $ | 512,961 |  |  | $ | 387,392 |  |  | $ | 125,569 |  |  | 32.4% |
| Gross margin | 64.2 | % |  | 65.2 | % |  |  |  |  |  | 64.0 | % |  | 65.4 | % |  |  |  |  |

[0001596532-16-000331:mdna:58]
[same as prior period, unchanged from 0001596532-16-000291:mdna:58]

[0001596532-16-000331:mdna:59]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2016 |  | % of Total |  | 2015 |  | % of Total |  | 2016 |  | % of Total |  | 2015 |  | % of Total |
| Americas | $ | 237,099 |  |  | 81.7 | % |  | $ | 170,596 |  |  | 78.5 | % |  | $ | 621,057 |  |  | 77.5 | % |  | $ | 448,216 |  |  | 75.7 | % |
| Europe, Middle East and Africa | 37,728 |  |  | 13.0 |  |  | 29,457 |  |  | 13.5 |  |  | 124,111 |  |  | 15.5 |  |  | 94,329 |  |  | 15.9 |  |
| Asia-Pacific | 15,434 |  |  | 5.3 |  |  | 17,495 |  |  | 8.0 |  |  | 56,030 |  |  | 7.0 |  |  | 49,600 |  |  | 8.4 |  |
| Total revenue | $ | 290,261 |  |  | 100.0 | % |  | $ | 217,548 |  |  | 100.0 | % |  | $ | 801,198 |  |  | 100.0 | % |  | $ | 592,145 |  |  | 100.0 | % |

[0001596532-16-000331:mdna:60]
[same as prior period, unchanged from 0001596532-16-000291:mdna:60]

[0001596532-16-000331:mdna:61]
Revenue increased 33.4% in the three months ended September 30, 2016 and 35.3% in the nine months ended September 30, 2016, compared to the same periods in 2015.  The increase in each period was primarily driven by increased shipments to our existing customers as they continue to grow and expand their businesses, increasing their demand for our switch products and related accessories. The introduction of new products has contributed to our revenue growth, both with existing and new customers. As of September 30, 2016, we have shipped more than 10 million cumulative cloud networking ports worldwide and our overall customer count has exceeded 4,100.  Service revenue increased 48.8% in the three months ended September 30, 2016 and 53.1% during the nine months ended September 30, 2016 compared to the same periods in 2015, as a result of continued growth in initial and renewal support contracts as our customer installed base continues to expand.  We also continued to experience fluctuations in product and service pricing due to competitive market pressures.  However, these were more than offset by the increased demand drivers outlined above.

[0001596532-16-000331:mdna:62]
[same as prior period, unchanged from 0001596532-16-000291:mdna:62]

[0001596532-16-000331:mdna:63]
Cost of revenue increased $28.0 million in the three months ended September 30, 2016 and $83.5 million in the nine months ended September 30, 2016, compared to the same periods in 2015. The increase in cost of revenue was primarily due to an increase in product shipment volumes.  In addition, we incurred some increased costs as we added capacity to our manufacturing and operations infrastructure.  Gross margin decreased from 65.2% to 64.2% for the three months ended September 30, 2016 compared to the same period in 2015, and from 65.4% to 64.0% for the nine months ended September 30, 2016 compared to the same period in 2015, respectively.  The decrease during these periods was primarily the result of changes in customer mix as we expanded our business including increased contributions from larger customers who typically receive higher discount levels, and increased costs associated with the expansion of manufacturing and operations capacity. These unfavorable changes were partially offset by improved service margins as we scale our services business.  We expect our gross margins in the fourth quarter of 2016 will reflect some further increases in product costs as we continue to invest in new contract manufacturing and supply chain operations.

[0001596532-16-000331:mdna:64]
[same as prior period, unchanged from 0001596532-16-000291:mdna:64]

[0001596532-16-000331:mdna:65]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2016 |  | 2015 |  | Change in |  | 2016 |  | 2015 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 70,648 |  |  | $ | 58,748 |  |  | $ | 11,900 |  |  | 20.3% |  | $ | 202,183 |  |  | $ | 152,035 |  |  | $ | 50,148 |  |  | 33.0% |
| Sales and marketing | 33,216 |  |  | 26,508 |  |  | 6,708 |  |  | 25.3 |  | 92,566 |  |  | 77,776 |  |  | 14,790 |  |  | 19.0 |
| General and administrative | 19,535 |  |  | 25,195 |  |  | (5,660 | ) |  | (22.5) |  | 52,298 |  |  | 57,670 |  |  | (5,372 | ) |  | (9.3) |
| Total operating expenses | $ | 123,399 |  |  | $ | 110,451 |  |  | $ | 12,948 |  |  | 11.7% |  | $ | 347,047 |  |  | $ | 287,481 |  |  | $ | 59,566 |  |  | 20.7% |

[0001596532-16-000331:mdna:66]
[same as prior period, unchanged from 0001596532-16-000291:mdna:66]

[0001596532-16-000331:mdna:67]
Research and development expenses increased for the three and nine months ended September 30, 2016 compared to the same periods in 2015.  The increase in each period was primarily due to an increase in third-party engineering, prototype and consulting costs, which grew $9.2 million and $24.2 million in the three months and nine months ended September 30, 2016, respectively as compared to the same periods in 2015. These increases related to additional outsourced development projects, increased internal development activity related to new products and increased costs associated with litigation-related changes in product design. Personnel costs increased by $3.9 million and $22.4 million in the three and nine ended September 30, 2016, respectively as compared to the same periods in 2015.  These increases reflected additional headcount, increased stock-based compensation charges, and additional bonus expenses under our corporate bonus program.  Facilities and IT infrastructure costs increased $2.4 million in the nine months ended September 30, 2016 compared to the same period in 2015, primarily due to the expansion and support of our research and development activities.

[0001596532-16-000331:mdna:68]
[same as prior period, unchanged from 0001596532-16-000291:mdna:69]

[0001596532-16-000331:mdna:69]
Sales and marketing expenses increased for the three and nine months ended September 30, 2016 compared to the same periods in 2015. The increase in each period was primarily due to an increase in personnel costs, which grew $6.6 million and $15.3 million in the three and nine months ended September 30, 2016, respectively as compared to the same periods in 2015.  These increases reflected additional headcount, additional sales incentive compensation due to higher sales volumes, and additional bonus expenses under our corporate bonus program.  The increase in the nine-month period was partially offset by a decrease in product field demonstration costs of $1.6 million primarily related to significant costs incurred in the previous year due to several product transitions to our next generation products.

[0001596532-16-000331:mdna:70]
[same as prior period, unchanged from 0001596532-16-000291:mdna:72]

[0001596532-16-000331:mdna:71]
General and administrative expenses decreased for the three and nine months ended September 30, 2016 compared to the same periods in 2015.  The decrease in each period was primarily due to a reduction in litigation expenses of $6.8 million and $8.5 million in the three and nine months ended September 30, 2016 respectively as compared to the same periods in 2015.  These decreases were primarily related to the timing of litigation activities associated with the Cisco and OptumSoft legal matters outlined in Note 5 to the Consolidated Financial Statements.  This was partially offset by an increase in personnel costs of $0.8 million and $3.2 million in the three and nine months ended September 30, 2016 respectively as compared to the same periods in 2015.  These increases reflected additional headcount, increased stock-based compensation charges, and additional bonus expenses under our corporate bonus program.

[0001596532-16-000331:mdna:72]
[same as prior period, unchanged from 0001596532-16-000291:mdna:75]

[0001596532-16-000331:mdna:73]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2016 |  | 2015 |  | Change in |  | 2016 |  | 2015 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | $ | (735 | ) |  | $ | (753 | ) |  | $ | 18 |  |  | 2.4% |  | $ | (2,218 | ) |  | $ | (2,406 | ) |  | $ | 188 |  |  | 7.8% |
| Other income (expense), net | 639 |  |  | 13 |  |  | 626 |  |  | 4,815.4 |  | 1,392 |  |  | (38 | ) |  | 1,430 |  |  | 3,763.2 |
| Total other income (expense), net | $ | (96 | ) |  | $ | (740 | ) |  | $ | 644 |  |  | 87.0% |  | $ | (826 | ) |  | $ | (2,444 | ) |  | $ | 1,618 |  |  | 66.2% |

[0001596532-16-000331:mdna:74]
[same as prior period, unchanged from 0001596532-16-000291:mdna:77]

[0001596532-16-000331:mdna:75]
Other income (expense), net improved during the three and nine months ended September 30, 2016 compared to the same periods in 2015 primarily due to a net increase in interest income as we expanded our marketable securities portfolio during the nine months ended September 30, 2016.

[0001596532-16-000331:mdna:76]
[same as prior period, unchanged from 0001596532-16-000291:mdna:79]

[0001596532-16-000331:mdna:77]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2016 |  | 2015 |  | Change in |  | 2016 |  | 2015 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Provision for income taxes | $ | 11,668 |  |  | $ | 1,867 |  |  | $ | 9,801 |  |  | 525.0% |  | $ | 39,682 |  |  | $ | 20,289 |  |  | $ | 19,393 |  |  | 95.6% |
| Effective tax rate | 18.5 | % |  | 6.1 | % |  |  |  |  |  | 24.0 | % |  | 20.8 | % |  |  |  |  |

[0001596532-16-000331:mdna:78]
[same as prior period, unchanged from 0001596532-16-000291:mdna:81]

[0001596532-16-000331:mdna:79]
Provision for income taxes and effective tax rate increased in the three and nine months ended September 30, 2016 compared to the same periods in 2015. The increase in the provision for each period was the result of an increase in profit before income taxes and the change in effective tax rate primarily due to the geographical distribution of earnings.  In addition, the effective tax rate for the three and nine months ended 2015 and 2016 reflect the release of unrecognized tax benefits due to the statute of limitations expiring in certain domestic tax jurisdictions.

[0001596532-16-000331:mdna:80]
[same as prior period, unchanged from 0001596532-16-000291:mdna:83]

[0001596532-16-000331:mdna:81]
[same as prior period, unchanged from 0001596532-16-000291:mdna:84]

[0001596532-16-000331:mdna:82]
Our principal sources of liquidity are cash and cash equivalents, marketable securities, and cash generated from operations. As of September 30, 2016, cash and cash equivalents, and marketable securities were $800.1 million, of which approximately $74.2 million was held outside the U.S. in our foreign subsidiaries.  We have not repatriated, nor do we currently have plans to repatriate these funds, but if we were to repatriate cash held outside of the U.S. for domestic cash operations, we would be required to accrue and pay U.S. income taxes to repatriate these funds less any previously paid foreign income taxes. We consider the undistributed earnings of our foreign subsidiaries as of September 30, 2016 to be indefinitely reinvested, and, accordingly, no U.S. income taxes have been provided thereon.

[0001596532-16-000331:mdna:83]
Our cash and cash equivalents, and marketable securities are held for working capital purposes. We plan to continue to invest for long-term growth. We believe that our existing cash and cash equivalents together with cash flow from operations will be sufficient to meet our working capital requirements and our growth strategies for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs and access to outsourcing our manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and costs incurred related to outstanding litigation claims. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-16-000331:mdna:84]
[same as prior period, unchanged from 0001596532-16-000291:mdna:87]

[0001596532-16-000331:mdna:85]
|  | September 30, 2016 |  | December 31, 2015 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 500,481 |  |  | $ | 687,326 |  |

[0001596532-16-000331:mdna:86]
|  | Nine Months EndedSeptember 30, |
|  | 2016 |  | 2015 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 78,685 |  |  | $ | 84,022 |  |
| Cash (used in) provided by investing activities | (319,551 | ) |  | 39,444 |  |
| Cash provided by financing activities | 54,154 |  |  | 55,270 |  |
| Effect of exchange rate changes | (133 | ) |  | (267 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | (186,845 | ) |  | $ | 178,469 |  |

[0001596532-16-000331:mdna:87]
[same as prior period, unchanged from 0001596532-16-000291:mdna:90]

[0001596532-16-000331:mdna:88]
Our primary source of cash from operating activities has been from cash collections from our customers. We expect cash inflows from operating activities to be affected by increased sales and timing of collections. Our primary uses of cash from operating activities have been for personnel costs, inventory purchases from our contract manufacturers, investment in research and development, and litigation expenses.

[0001596532-16-000331:mdna:89]
During the nine months ended September 30, 2016, cash provided by operating activities was $78.7 million, primarily from net income of $125.4 million and net non-cash adjustments to net income of $14.7 million, partially offset by a net decrease in cash from changes in our operating assets and liabilities of $61.5 million.  The decrease in cash from changes in operating assets and liabilities was primarily due to an increase in accounts receivable of $66.0 million related to increased shipment volume, and an increase in net inventory of $70.0 million, and deposits of $62.6 million related to the expansion of our contract manufacturing and supply chain activities.  The cash outflows for inventory-related activity was primarily related to ramping production activities at our new contract manufacturer.  These cash outflows were offset by cash inflows from an increase in deferred revenue of $88.0 million mostly related to new and renewed PCS contracts and product deferrals related to contract acceptance terms and future deliverables, an increase in accounts payable of $35.5 million  primarily due to increased inventory purchases and timing of vendor payments, an increase in cash of $27.3 million from changes in income taxes payable and an increase in accrued liabilities of $15.9 million primarily from corporate bonus and compensation related accruals.

[0001596532-16-000331:mdna:90]
During the nine months ended September 30, 2015, cash provided by operating activities was $84.0 million, primarily from net income of $77.2 million, and a net increase in cash from changes in our operating assets and liabilities of $10.7 million, partially offset by net non-cash charges of $(3.8) million. The net increase in cash from changes in operating assets and liabilities was primarily due to an increase in deferred revenue of $84.2 million, largely related to short and long-term services contracts and product revenue deferrals related to contract acceptance terms and future deliverables. In addition, we experienced an increase in cash of $24.8 million from changes in income tax payable, and an increase in our accounts payable and accrued liabilities of $18.0 million due to the timing of payments. These operating liability increases were partially offset by an increase in our accounts receivable of $63.9 million resulting from an increase in sales during the period and slower collections in the three months ended September 30, 2015. In addition, inventory increased $31.9 million during the period due to higher shipment volume and prepaid expenses and current assets increased $19.4 million in the period.

[0001596532-16-000331:mdna:91]
[same as prior period, unchanged from 0001596532-16-000291:mdna:94]

[0001596532-16-000331:mdna:92]
[same as prior period, unchanged from 0001596532-16-000291:mdna:95]

[0001596532-16-000331:mdna:93]
During the nine months ended September 30, 2016, cash used in investing activities was $319.6 million, consisting of purchases of available-for-sale securities of $342.5 million, purchases of property, equipment and other assets of $16.5 million, and an additional investment in a privately-held company of $2.5 million.

[0001596532-16-000331:mdna:94]
During the nine months ended September 30, 2015, cash provided by investing activities was $39.4 million, consisting of

[0001596532-16-000331:mdna:95]
proceeds from the maturity of available-for-sale securities of $58.2 million, offset by purchases of property, equipment and other assets of $14.0 million and increase in restricted cash of $4.0 million related to a security deposit required for a facility lease.

[0001596532-16-000331:mdna:96]
[same as prior period, unchanged from 0001596532-16-000291:mdna:98]

[0001596532-16-000331:mdna:97]
[same as prior period, unchanged from 0001596532-16-000291:mdna:99]

[0001596532-16-000331:mdna:98]
During the nine months ended September 30, 2016, cash provided by financing activities was $54.2 million, consisting primarily of the excess tax benefit associated with equity incentive plans of $30.0 million, proceeds from the exercise of stock options, net of repurchases of $15.6 million, and proceeds from the issuance of common stock from our ESPP of $10.3 million.

[0001596532-16-000331:mdna:99]
During the nine months ended September 30, 2015, cash provided by financing activities was $55.3 million, consisting primarily of the excess tax benefit associated with equity incentive plans of $32.4 million, proceeds from the exercise of stock options, net of repurchases of $14.6 million and the proceeds from the issuance of common stock from our ESPP of $9.4 million.

[0001596532-16-000331:mdna:100]
[same as prior period, unchanged from 0001596532-16-000291:mdna:102]

[0001596532-16-000331:mdna:101]
As of September 30, 2016, we did not have any relationships with any unconsolidated entities or financial partnerships, including entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-16-000331:mdna:102]
[same as prior period, unchanged from 0001596532-16-000291:mdna:104]

[0001596532-16-000331:mdna:103]
As of September 30, 2016, our principal commitments consist of obligations under operating leases and purchase commitments. There have been no significant changes to these obligations during the nine months ended September 30, 2016, compared to the contractual obligations disclosed in our "Management's Discussion and Analysis of Financial Condition and Results of Operations" included in our Annual Report on Form 10-K, filed with the SEC on February 25, 2016, other than the purchase commitments described in Note 5. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements of this Quarterly Report on Form 10-Q.

[0001596532-16-000331:mdna:104]
[same as prior period, unchanged from 0001596532-16-000291:mdna:106]

[0001596532-16-000331:mdna:105]
[same as prior period, unchanged from 0001596532-16-000291:mdna:107]

[0001596532-16-000331:mdna:106]
[same as prior period, unchanged from 0001596532-16-000291:mdna:108]

[0001596532-16-000331:mdna:107]
[same as prior period, unchanged from 0001596532-16-000291:mdna:109]

[0001596532-16-000331:mdna:108]
33
