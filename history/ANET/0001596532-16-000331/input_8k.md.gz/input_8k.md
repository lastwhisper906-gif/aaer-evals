# ANET 8-K — 0001596532-16-000329 filed 2016-11-03

## item codes, every 8-K on or before 2016-11-03

- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2016-11-03

- none on or before 2016-11-03

## item 2.02 — earnings release, exhibit 99.1

[0001596532-16-000329:8k_2_02:1]
EX-99.1
2
ex991q316-earnings.htm
EXHIBIT 99.1

[0001596532-16-000329:8k_2_02:2]
Exhibit

[0001596532-16-000329:8k_2_02:3]
Exhibit 99.1

[0001596532-16-000329:8k_2_02:4]
Arista Networks, Inc. Reports Third Quarter 2016 Financial Results

[0001596532-16-000329:8k_2_02:5]
Cloud Networking Adoption Drives Record Earnings and Cumulative Shipments of 10 Million Cloud Networking Ports

[0001596532-16-000329:8k_2_02:6]
SANTA CLARA, Calif., November 3, 2016 - Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large data center and computing environments, today announced financial results for its third quarter ended September 30, 2016.

[0001596532-16-000329:8k_2_02:7]
Third Quarter Financial Highlights

[0001596532-16-000329:8k_2_02:8]
| • | Revenue of $290.3 million, an increase of 8.0% compared to the second quarter of 2016, and an increase of 33.4% from the third quarter of 2015. |

[0001596532-16-000329:8k_2_02:9]
| • | GAAP gross margin of 64.2%, compared to GAAP gross margin of 63.8% in the second quarter of 2016 and 65.2% in the third quarter of 2015. |

[0001596532-16-000329:8k_2_02:10]
| • | Non-GAAP gross margin of 64.6%, compared to non-GAAP gross margin of 64.2% in the second quarter of 2016 and 65.5% in the third quarter of 2015. |

[0001596532-16-000329:8k_2_02:11]
| • | GAAP net income of $51.3 million, or $0.69 per diluted share, compared to GAAP net income of $28.7 million, or $0.39 per diluted share, in the third quarter of 2015. |

[0001596532-16-000329:8k_2_02:12]
| • | Non-GAAP net income of $61.2 million, or $0.83 per diluted share, compared to non-GAAP net income of $42.4 million, or $0.59 per diluted share, in the third quarter of 2015. |

[0001596532-16-000329:8k_2_02:13]
"I am pleased with our record Q3 2016 earnings and our cumulative shipments of 10 million cloud networking ports,” stated Jayshree Ullal, Arista President and CEO. “These milestones highlight Arista's customer enthusiasm for our new 7000 series products and the inevitable shift from legacy to cloud networking.”

[0001596532-16-000329:8k_2_02:14]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, “We are pleased with our revenue and earnings per share performance in the third quarter which reflects broad-based customer demand for our products.”

[0001596532-16-000329:8k_2_02:15]
Company Highlights

[0001596532-16-000329:8k_2_02:16]
| • | Introduced next-generation, real-time telemetry and analytics capabilities that leverage Arista EOS(R) and CloudVision(R) to deliver deep visibility into workloads, workflows, and workstreams on a network-wide basis, accelerating completion of day-to-day tasks and reducing operational costs. |

[0001596532-16-000329:8k_2_02:17]
| • | Entered an exciting new strategic partnership with Hewlett Packard Enterprise ("HPE") that expands on the existing HPE Converged Architecture agreement announced last June. HPE customers and partners will now have the ability to purchase Arista Networks switching products directly from HPE starting November 7, 2016, helping deliver on a common vision of secure Hybrid IT solutions and experiences built on industry-leading software-defined infrastructure. |

[0001596532-16-000329:8k_2_02:18]
Financial Outlook

[0001596532-16-000329:8k_2_02:19]
For the fourth quarter of 2016, we expect:

[0001596532-16-000329:8k_2_02:20]
| • | Revenue between $310 and $320 million. |

[0001596532-16-000329:8k_2_02:21]
| • | Non-GAAP gross margin between 61% to 64%, and |

[0001596532-16-000329:8k_2_02:22]
| • | Non-GAAP operating margin of approximately 26%. |

[0001596532-16-000329:8k_2_02:23]
Guidance for non-GAAP financial measures excludes legal expenses of approximately $12 million associated with the OptumSoft and Cisco litigation, stock-based compensation and other non-recurring expenses.  A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below).

[0001596532-16-000329:8k_2_02:24]
Prepared Materials and Conference Call Information

[0001596532-16-000329:8k_2_02:25]
Arista executives will discuss third quarter 2016 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial 1-877-201-0168 in the United States or 1-647-788-4901 from outside the US. The Conference ID is 93512126.

[0001596532-16-000329:8k_2_02:26]
The financial results conference call will also be available via live webcast on our investor relations website at investors.arista.com.  Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s Investor Relations website.

[0001596532-16-000329:8k_2_02:27]
Forward-Looking Statements

[0001596532-16-000329:8k_2_02:28]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the fourth quarter of fiscal 2016, statements regarding the ongoing shift to cloud networking, and statements regarding the benefits from the introduction of next-generation telemetry and analytics capabilities. Forward-looking statements are subject to a number of uncertainties and risks that could cause actual results to differ materially from those anticipated in the forward-looking statements including risks associated with: Arista Networks’ limited operating history; risks associated with Arista Networks’ rapid growth; Arista Networks’ customer concentration; Arista Networks’ dispute with Cisco Systems, Inc.  including Arista Networks’ ability to obtain a determination that alternative product implementations are not covered by remedial orders; Arista Networks’ dispute with OptumSoft, Inc.; requests for more favorable terms and conditions from our large end customers; declines in the sales prices of our products and services; changes in customer order patterns or customer mix; increased competition in our products and service markets, including the data center market; dependence on the introduction and market acceptance of new product offerings and standards; rapid technological and market change; the evolution of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; and general market, political, economic and business conditions.  Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s Quarterly Reporting on Form 10-Q filed with the SEC on August 5, 2016, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at http://investors.arista.com and on the SEC’s website at www.sec.gov. All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-16-000329:8k_2_02:29]
Non-GAAP Financial Measures

[0001596532-16-000329:8k_2_02:30]
The company reports certain non-GAAP financial measures that exclude stock-based compensation expenses, expenses associated with the OptumSoft and Cisco litigation, and other non-recurring charges. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends.  In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-16-000329:8k_2_02:31]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP net income, net income per diluted share, gross margin, or operating margin. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-16-000329:8k_2_02:32]
The Company’s guidance for non-GAAP financial measures excludes stock-based compensation, expenses associated with the OptumSoft and Cisco litigation, and other non-recurring charges. The Company has not reconciled its non-GAAP gross margin or its non-GAAP operating margin guidance to GAAP gross margin or GAAP operating margin, because we do not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling cash and non-cash items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. Share-based compensation expense is impacted by the Company’s future hiring and retention needs, as well as the future fair market value of the Company’s common stock, all of which is difficult to predict and subject to constant change. The actual amount of share-based compensation in the fiscal fourth quarter of 2016 will have a significant impact on the Company’s GAAP gross margin and GAAP operating margin. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measure is not available without unreasonable effort.

[0001596532-16-000329:8k_2_02:33]
About Arista Networks

[0001596532-16-000329:8k_2_02:34]
Arista Networks was founded to pioneer and deliver software-driven cloud networking solutions for large data center storage and computing environments. Arista’s award-winning platforms, ranging in Ethernet speeds from 10 to 100 gigabits per second, redefine scalability, agility and resilience. Arista has shipped more than ten million cloud networking ports worldwide with CloudVision and EOS, an advanced network operating system. Committed to open standards, Arista is a founding member of the 25/50GbE consortium. Arista Networks products are available worldwide directly and through partners.

[0001596532-16-000329:8k_2_02:35]
ARISTA, EOS, CloudVision, Spline, NetDB and FlexRoute are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-16-000329:8k_2_02:36]
Additional information and resources can be found at: http://www.arista.com.

[0001596532-16-000329:8k_2_02:37]
| Media ContactAmanda JaramilloCorporate Communications(408) 547-5798amanda@arista.com |  | Investor ContactChuck ElliottProduct and Investor Advocacy(408) 547-5549chuck@arista.com |

[0001596532-16-000329:8k_2_02:38]
ARISTA NETWORKS, INC.

[0001596532-16-000329:8k_2_02:39]
Condensed Consolidated Statements of Income

[0001596532-16-000329:8k_2_02:40]
(Unaudited in thousands, except per share amounts)

[0001596532-16-000329:8k_2_02:41]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 254,238 |  |  | $ | 193,339 |  |  | $ | 702,329 |  |  | $ | 527,552 |  |
| Service | 36,023 |  |  | 24,209 |  |  | 98,869 |  |  | 64,593 |  |
| Total revenue | 290,261 |  |  | 217,548 |  |  | 801,198 |  |  | 592,145 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 94,777 |  |  | 67,990 |  |  | 261,711 |  |  | 182,443 |  |
| Service | 9,064 |  |  | 7,810 |  |  | 26,526 |  |  | 22,310 |  |
| Total cost of revenue | 103,841 |  |  | 75,800 |  |  | 288,237 |  |  | 204,753 |  |
| Gross profit | 186,420 |  |  | 141,748 |  |  | 512,961 |  |  | 387,392 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 70,648 |  |  | 58,748 |  |  | 202,183 |  |  | 152,035 |  |
| Sales and marketing | 33,216 |  |  | 26,508 |  |  | 92,566 |  |  | 77,776 |  |
| General and administrative | 19,535 |  |  | 25,195 |  |  | 52,298 |  |  | 57,670 |  |
| Total operating expenses | 123,399 |  |  | 110,451 |  |  | 347,047 |  |  | 287,481 |  |
| Income from operations | 63,021 |  |  | 31,297 |  |  | 165,914 |  |  | 99,911 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (735 | ) |  | (753 | ) |  | (2,218 | ) |  | (2,406 | ) |
| Other income (expense), net | 639 |  |  | 13 |  |  | 1,392 |  |  | (38 | ) |
| Total other income (expense), net | (96 | ) |  | (740 | ) |  | (826 | ) |  | (2,444 | ) |
| Income before provision for income taxes | 62,925 |  |  | 30,557 |  |  | 165,088 |  |  | 97,467 |  |
| Provision for income taxes | 11,668 |  |  | 1,867 |  |  | 39,682 |  |  | 20,289 |  |
| Net income | $ | 51,257 |  |  | $ | 28,690 |  |  | $ | 125,406 |  |  | $ | 77,178 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 50,962 |  |  | $ | 28,301 |  |  | $ | 124,475 |  |  | $ | 75,864 |  |
| Diluted | $ | 50,980 |  |  | $ | 28,329 |  |  | $ | 124,531 |  |  | $ | 75,967 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 0.74 |  |  | $ | 0.42 |  |  | $ | 1.82 |  |  | $ | 1.16 |  |
| Diluted | $ | 0.69 |  |  | $ | 0.39 |  |  | $ | 1.71 |  |  | $ | 1.07 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | 69,076 |  |  | 66,629 |  |  | 68,365 |  |  | 65,609 |  |
| Diluted | 73,453 |  |  | 71,887 |  |  | 72,811 |  |  | 71,232 |  |

[0001596532-16-000329:8k_2_02:42]
ARISTA NETWORKS, INC.

[0001596532-16-000329:8k_2_02:43]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-16-000329:8k_2_02:44]
(Unaudited in thousands, except percentages and per share amounts)

[0001596532-16-000329:8k_2_02:45]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| GAAP gross profit |  | $ | 186,420 |  |  | $ | 141,748 |  |  | $ | 512,961 |  |  | $ | 387,392 |  |
| GAAP gross margin |  | 64.2 | % |  | 65.2 | % |  | 64.0 | % |  | 65.4 | % |
| Stock-based compensation expense |  | 955 |  |  | 786 |  |  | 2,616 |  |  | 2,206 |  |
| Non-GAAP gross profit |  | $ | 187,375 |  |  | $ | 142,534 |  |  | $ | 515,577 |  |  | $ | 389,598 |  |
| Non-GAAP gross margin |  | 64.6 | % |  | 65.5 | % |  | 64.4 | % |  | 65.8 | % |
| GAAP income from operations |  | $ | 63,021 |  |  | $ | 31,297 |  |  | $ | 165,914 |  |  | $ | 99,911 |  |
| Stock-based compensation expense |  | 15,116 |  |  | 12,278 |  |  | 42,708 |  |  | 32,325 |  |
| Litigation expense |  | 9,025 |  |  | 15,889 |  |  | 23,624 |  |  | 32,468 |  |
| Non-GAAP income from operations |  | $ | 87,162 |  |  | $ | 59,464 |  |  | $ | 232,246 |  |  | $ | 164,704 |  |
| Non-GAAP operating margin |  | 30.0 | % |  | 27.3 | % |  | 29.0 | % |  | 27.8 | % |
| GAAP net income |  | $ | 51,257 |  |  | $ | 28,690 |  |  | $ | 125,406 |  |  | $ | 77,178 |  |
| Stock-based compensation expense |  | 15,116 |  |  | 12,278 |  |  | 42,708 |  |  | 32,325 |  |
| Litigation expense |  | 9,025 |  |  | 15,889 |  |  | 23,624 |  |  | 32,468 |  |
| Release of income tax reserve |  | (6,293 | ) |  | (6,376 | ) |  | (6,293 | ) |  | (6,376 | ) |
| Income tax effect on non-GAAP exclusions |  | (7,924 | ) |  | (8,064 | ) |  | (21,504 | ) |  | (18,868 | ) |
| Non-GAAP net income |  | $ | 61,181 |  |  | $ | 42,417 |  |  | $ | 163,941 |  |  | $ | 116,727 |  |
| Weighted-average shares used in computing diluted net income per share attributable to common stockholders |  | 73,453 |  |  | 71,887 |  |  | 72,811 |  |  | 71,232 |  |
| GAAP diluted net income per share attributable to common stockholders |  | $ | 0.69 |  |  | $ | 0.39 |  |  | $ | 1.71 |  |  | $ | 1.07 |  |
| Net income attributable to participating securities |  | — |  |  | 0.01 |  |  | 0.01 |  |  | 0.02 |  |
| Non-GAAP adjustments to net income |  | 0.14 |  |  | 0.19 |  |  | 0.53 |  |  | 0.55 |  |
| Non-GAAP adjustments to diluted shares |  | — |  |  | — |  |  | — |  |  | — |  |
| Non-GAAP diluted net income per share |  | $ | 0.83 |  |  | $ | 0.59 |  |  | $ | 2.25 |  |  | $ | 1.64 |  |
| Summary of Stock-Based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 955 |  |  | $ | 786 |  |  | $ | 2,616 |  |  | $ | 2,206 |  |
| Research and development |  | 8,010 |  |  | 7,037 |  |  | 23,062 |  |  | 18,344 |  |
| Sales and marketing |  | 3,947 |  |  | 2,864 |  |  | 11,374 |  |  | 8,138 |  |
| General and administrative |  | 2,204 |  |  | 1,591 |  |  | 5,656 |  |  | 3,637 |  |
| Total |  | $ | 15,116 |  |  | $ | 12,278 |  |  | $ | 42,708 |  |  | $ | 32,325 |  |

[0001596532-16-000329:8k_2_02:46]
ARISTA NETWORKS, INC.

[0001596532-16-000329:8k_2_02:47]
Consolidated Balance Sheets

[0001596532-16-000329:8k_2_02:48]
(Unaudited in thousands)

[0001596532-16-000329:8k_2_02:49]
|  | September 30, 2016 |  | December 31, 2015 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 500,481 |  |  | $ | 687,326 |  |
| Marketable securities | 299,667 |  |  | — |  |
| Accounts receivable | 210,243 |  |  | 144,263 |  |
| Inventories | 162,128 |  |  | 92,129 |  |
| Prepaid expenses and other current assets | 151,659 |  |  | 50,610 |  |
| Total current assets | 1,324,178 |  |  | 974,328 |  |
| Property and equipment, net | 78,147 |  |  | 79,706 |  |
| Investments | 36,136 |  |  | 36,636 |  |
| Deferred tax assets | 62,221 |  |  | 48,429 |  |
| Other assets | 18,398 |  |  | 20,791 |  |
| TOTAL ASSETS | $ | 1,519,080 |  |  | $ | 1,159,890 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 77,048 |  |  | $ | 43,966 |  |
| Accrued liabilities | 77,163 |  |  | 60,971 |  |
| Deferred revenue | 191,094 |  |  | 122,049 |  |
| Other current liabilities | 9,777 |  |  | 8,025 |  |
| Total current liabilities | 355,082 |  |  | 235,011 |  |
| Income taxes payable | 11,896 |  |  | 14,060 |  |
| Lease financing obligations, non-current | 40,041 |  |  | 41,210 |  |
| Deferred revenue, non-current | 93,741 |  |  | 74,759 |  |
| Other long-term liabilities | 6,900 |  |  | 6,698 |  |
| TOTAL LIABILITIES | 507,660 |  |  | 371,738 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 7 |  |  | 7 |  |
| Additional paid-in capital | 636,074 |  |  | 537,904 |  |
| Retained earnings | 376,322 |  |  | 250,916 |  |
| Accumulated other comprehensive loss | (983 | ) |  | (675 | ) |
| TOTAL STOCKHOLDERS’ EQUITY | 1,011,420 |  |  | 788,152 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 1,519,080 |  |  | $ | 1,159,890 |  |

[0001596532-16-000329:8k_2_02:50]
ARISTA NETWORKS, INC.

[0001596532-16-000329:8k_2_02:51]
Consolidated Statements of Cash Flows

[0001596532-16-000329:8k_2_02:52]
(Unaudited in thousands)

[0001596532-16-000329:8k_2_02:53]
|  | Nine Months EndedSeptember 30, |
|  | 2016 |  | 2015 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 125,406 |  |  | $ | 77,178 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 14,807 |  |  | 9,724 |  |
| Stock-based compensation | 42,708 |  |  | 32,325 |  |
| Deferred income taxes | (13,720 | ) |  | (15,483 | ) |
| Excess tax benefit on stock-based compensation | (30,043 | ) |  | (32,381 | ) |
| Amortization of investment premiums | 994 |  |  | 1,332 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | (65,980 | ) |  | (63,248 | ) |
| Inventories | (69,998 | ) |  | (31,915 | ) |
| Prepaid expenses and other current assets | (98,050 | ) |  | (19,352 | ) |
| Other assets | 3,208 |  |  | (3,092 | ) |
| Accounts payable | 35,510 |  |  | (145 | ) |
| Accrued liabilities | 15,913 |  |  | 18,102 |  |
| Deferred revenue | 88,027 |  |  | 84,238 |  |
| Income taxes payable | 27,275 |  |  | 24,759 |  |
| Other liabilities | 2,628 |  |  | 1,980 |  |
| Net cash provided by operating activities | 78,685 |  |  | 84,022 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Proceeds from maturity of marketable securities | 41,917 |  |  | 58,200 |  |
| Purchases of marketable securities | (342,484 | ) |  | — |  |
| Purchases of property and equipment | (15,787 | ) |  | (13,974 | ) |
| Investment in privately-held companies | (2,500 | ) |  | — |  |
| Changes in restricted cash | — |  |  | (4,039 | ) |
| Purchases of intangible assets | (697 | ) |  | (743 | ) |
| Net cash (used in) provided by investing activities | (319,551 | ) |  | 39,444 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Principal payments of lease financing obligations | (960 | ) |  | (778 | ) |
| Proceeds from issuance of common stock upon exercising options, net of repurchases | 15,556 |  |  | 14,562 |  |
| Minimum tax withholding paid on behalf of employees for net share settlement | (811 | ) |  | — |  |
| Proceeds from issuance of common stock, employee stock purchase plan | 10,326 |  |  | 9,366 |  |
| Excess tax benefit on stock-based compensation | 30,043 |  |  | 32,381 |  |
| Issuance costs from initial public offering | — |  |  | (261 | ) |
| Net cash provided by financing activities | 54,154 |  |  | 55,270 |  |
| Effect of exchange rate changes | (133 | ) |  | (267 | ) |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | (186,845 | ) |  | 178,469 |  |
| CASH AND CASH EQUIVALENTS—Beginning of year | 687,326 |  |  | 240,031 |  |
| CASH AND CASH EQUIVALENTS—End of year | $ | 500,481 |  |  | $ | 418,500 |  |
