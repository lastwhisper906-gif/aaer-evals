# ANET 8-K — 0001596532-18-000012 filed 2018-02-15

## item codes, every 8-K on or before 2018-02-20

- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2018-02-20

- none on or before 2018-02-20

## item 2.02 — earnings release, exhibit 99.1

[0001596532-18-000012:8k_2_02:1]
EX-99.1
2
ex991q417-earningsrelease.htm
EXHIBIT 99.1

[0001596532-18-000012:8k_2_02:2]
Exhibit

[0001596532-18-000012:8k_2_02:3]
Exhibit 99.1

[0001596532-18-000012:8k_2_02:4]
Arista Networks, Inc. Reports Fourth Quarter and Full Year 2017 Financial Results

[0001596532-18-000012:8k_2_02:5]
Cloud Networking Adoption Continues Across Verticals

[0001596532-18-000012:8k_2_02:6]
SANTA CLARA, Calif.-- February 15, 2018 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large datacenter and computing environments, today announced financial results for its fourth quarter and year ended December 31, 2017.

[0001596532-18-000012:8k_2_02:7]
Fourth Quarter Financial Highlights

[0001596532-18-000012:8k_2_02:8]
| • | Revenue of $467.9 million, an increase of 6.9% compared to the third quarter of 2017, and an increase of 42.7% from the fourth quarter of 2016. |

[0001596532-18-000012:8k_2_02:9]
| • | GAAP gross margin of 65.7%, compared to GAAP gross margin of 64.1% in the third quarter of 2017 and 64.1% in the fourth quarter of 2016. |

[0001596532-18-000012:8k_2_02:10]
| • | Non-GAAP gross margin of 65.9%, compared to non-GAAP gross margin of 64.4% in the third quarter of 2017 and 64.4% in the fourth quarter of 2016. |

[0001596532-18-000012:8k_2_02:11]
| • | GAAP net income of $103.8 million, or $1.29 per diluted share, compared to GAAP net income of $58.8 million, or $0.79 per diluted share, in the fourth quarter of 2016. |

[0001596532-18-000012:8k_2_02:12]
| • | Non-GAAP net income of $137.3 million, or $1.71 per diluted share, compared to non-GAAP net income of $77.5 million, or $1.04 per diluted share, in the fourth quarter of 2016. |

[0001596532-18-000012:8k_2_02:13]
Full Year Financial Highlights

[0001596532-18-000012:8k_2_02:14]
| • | Revenue of $1.6 billion, an increase of 45.8% compared to fiscal year 2016. |

[0001596532-18-000012:8k_2_02:15]
| • | GAAP gross margin of 64.5%, compared to GAAP gross margin of 64.0% in fiscal year 2016. |

[0001596532-18-000012:8k_2_02:16]
| • | Non-GAAP gross margin of 64.8%, compared to non-GAAP gross margin of 64.4% in fiscal year 2016. |

[0001596532-18-000012:8k_2_02:17]
| • | GAAP net income of $423.2 million, or $5.35 per diluted share, compared to GAAP net income of $184.2 million, or $2.50 per diluted share, in fiscal year 2016. |

[0001596532-18-000012:8k_2_02:18]
| • | Non-GAAP net income of $442.8 million or $5.61 per diluted share, compared to non-GAAP net income of $241.4 million, or $3.30 per diluted share, in fiscal year 2016. |

[0001596532-18-000012:8k_2_02:19]
"2017 represents a market tipping point with Arista’s disruptive software-driven architecture gaining mainstream acceptance as we surpassed 15 million cumulative ports of cloud networking,” stated Jayshree Ullal, Arista President and CEO.

[0001596532-18-000012:8k_2_02:20]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, “We are pleased with the strong execution underlying our 2017 financial performance with 46% revenue growth and 70% growth in non-GAAP EPS on a year-over-year basis.”

[0001596532-18-000012:8k_2_02:21]
Fourth Quarter Company Highlights

[0001596532-18-000012:8k_2_02:22]
| • | Continued expansion in cloud-grade routing with the latest Arista EOS® (Extensible Operating System) and CloudVision® software. Arista EOS version 4.20 delivers new routing and management software capabilities, helping customers evolve to modern, software-driven routing principles. |

[0001596532-18-000012:8k_2_02:23]
2017 Company Highlights

[0001596532-18-000012:8k_2_02:24]
| • | Third consecutive year Arista has been recognized as a leader and positioned the furthest for Completeness of Vision in the Leaders Quadrant of the July 2017 Gartner Magic Quadrant for Data Center Networking. |

[0001596532-18-000012:8k_2_02:25]
| • | Introduced the next generation R2 Series platforms based on merchant silicon that is twice the density and half the power of custom router silicon, delivering more than 150 Tbps of capacity for switching and routing applications with cloud-driven Arista EOS software technologies including Arista FlexRoute™ and AlgoMatch™. |

[0001596532-18-000012:8k_2_02:26]
| • | Containerized EOS (cEOS) supports alternate models of procuring, packaging and deploying Arista’s EOS across cloud, enterprises and service providers. Utilizing the industry standard container development/operations (DevOps) model, Arista extends the architectural choices beyond its own hardware to support EOS on virtual machines, containers and third-party merchant silicon-based switches. |

[0001596532-18-000012:8k_2_02:27]
| • | Arista Data AnalyZer DANZ 2017 supports the Arista R-Series Universal Leaf and Spine platforms, bringing improved visibility to 25G and 100G networks. DANZ, powered by Arista EOS and combined with Arista CloudVision for automation and telemetry, delivers the hyperscale visibility platform required to secure today’s cloud centric applications and workflows. |

[0001596532-18-000012:8k_2_02:28]
| • | Introduced Arista Any Cloud software platform, reducing operational costs and complexity for enterprises by simplifying integration and management of hybrid clouds across private cloud datacenters and public cloud providers. The new virtualized offering, Arista vEOS™ Router, combined with CloudVision and new Cloud Tracer™ functionality, provides consistent operations, orchestration, security and telemetry across multi-cloud environments. |

[0001596532-18-000012:8k_2_02:29]
Financial Outlook

[0001596532-18-000012:8k_2_02:30]
For the first quarter of 2018, we expect:

[0001596532-18-000012:8k_2_02:31]
| • | Revenue between $450 and $468 million; |

[0001596532-18-000012:8k_2_02:32]
| • | Non-GAAP gross margin between 63% to 65%, and |

[0001596532-18-000012:8k_2_02:33]
| • | Non-GAAP operating margin of approximately 32%. |

[0001596532-18-000012:8k_2_02:34]
Guidance for non-GAAP financial measures excludes estimated legal expenses of approximately $8 million associated with the Cisco and OptumSoft litigation, stock-based compensation expense, and other non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measure is not available on a forward-looking basis (see further explanation below).

[0001596532-18-000012:8k_2_02:35]
Prepared Materials and Conference Call Information

[0001596532-18-000012:8k_2_02:36]
Arista executives will discuss fourth quarter 2017 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (833) 287-7905 in the United States or (647) 689-4469 from outside the US. The Conference ID is 1592049.

[0001596532-18-000012:8k_2_02:37]
The financial results conference call will also be available via live webcast on our investor relations website at http://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s Investor Relations website.

[0001596532-18-000012:8k_2_02:38]
Forward-Looking Statements

[0001596532-18-000012:8k_2_02:39]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the first quarter of fiscal 2018, and statements regarding the benefits from the introduction of new

[0001596532-18-000012:8k_2_02:40]
products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: Arista Networks’ dispute with Cisco Systems, Inc. including the ITC remedial orders which prohibit the importation of Arista products (or components thereof) into the U.S., or the sale of previously imported products,  that are covered by those remedial orders, Arista Networks’ ability to redesign its products in a manner not covered by such remedial orders and obtain appropriate governmental approvals for those redesigned products, any penalties assessed by the ITC if Arista’s redesigned products are covered by such remedial orders, Arista’s ability to develop new redesigned products in a timely manner that are acceptable to customers if Arista’s current redesigns are not approved by the ITC, and Arista Networks’ ability to manage our manufacturing and supply chain including the sourcing of components on commercially reasonable terms; Arista Networks’ limited operating history; Arista Networks’ rapid growth; Arista Networks’ customer concentration;  our customers’ adoption of our redesigned products and services; requests for more favorable terms and conditions from our large end customers; declines in the sales prices of our products and services; changes in customer demand for our products and services, customer order patterns or customer mix; the timing of orders and manufacturing and customer lead times; increased competition in our products and service markets; dependence on the introduction and market acceptance of new product offerings and standards; rapid technological and market change; the evolution of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; Arista Networks’ dispute with OptumSoft; the impact of global and domestic tax reform, including the Tax Cuts and Jobs Act of 2017 (“the Tax Act”); and general market, political, economic and business conditions. Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s most recent Quarterly Report on Form 10-Q filed with the SEC on November 3, 2017, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at http://investors.arista.com/and on the SEC’s website at http://www.sec.gov/.  All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-18-000012:8k_2_02:41]
Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner's research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001596532-18-000012:8k_2_02:42]
Non-GAAP Financial Measures

[0001596532-18-000012:8k_2_02:43]
The company reports certain non-GAAP financial measures that exclude stock-based compensation expense and related excess tax benefits, expenses associated with the Cisco and OptumSoft litigation, discrete tax items associated with the Tax Act, other non-recurring items, and the income tax effect of these non-GAAP exclusions. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-18-000012:8k_2_02:44]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP net income, net income per diluted share, gross margin, or operating margin. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-18-000012:8k_2_02:45]
3

[0001596532-18-000012:8k_2_02:46]
The Company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, expenses associated with the Cisco and OptumSoft litigation, and other non-recurring items. The Company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. Stock-based compensation expense is impacted by the Company’s future hiring and retention needs and the future fair market value of the Company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the Company’s GAAP gross margin and GAAP operating margin. Accordingly, a reconciliation of our guidance on non-GAAP financial measures to the corresponding GAAP measures is not available without unreasonable effort.

[0001596532-18-000012:8k_2_02:47]
About Arista Networks

[0001596532-18-000012:8k_2_02:48]
Arista Networks was founded to pioneer and deliver software-driven cloud networking solutions for large datacenter storage and computing environments. Arista’s award-winning platforms, ranging in Ethernet speeds from 10 to 100 gigabits per second, redefine scalability, agility and resilience. Arista has shipped more than 15 million cloud networking ports worldwide with CloudVision and EOS, an advanced network operating system. Committed to open standards, Arista is a founding member of the 25/50GbE consortium. Arista Networks products are available worldwide directly and through partners.

[0001596532-18-000012:8k_2_02:49]
ARISTA, EOS, CloudVision, and AlgoMatch are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-18-000012:8k_2_02:50]
Additional information and resources can be found at: http://www.arista.com/

[0001596532-18-000012:8k_2_02:51]
| Investor Contacts: |
| Charles YagerProduct and Investor Advocacy(408) 547-5892cyager@arista.com |  | Chuck ElliottBusiness and Investor Development(408) 547-5549chuck@arista.com |

[0001596532-18-000012:8k_2_02:52]
ARISTA NETWORKS, INC.

[0001596532-18-000012:8k_2_02:53]
Condensed Consolidated Statements of Income

[0001596532-18-000012:8k_2_02:54]
(Unaudited in thousands, except per share amounts)

[0001596532-18-000012:8k_2_02:55]
|  |  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 407,195 |  |  | $ | 289,008 |  |  | $ | 1,432,810 |  |  | $ | 991,337 |  |
| Service |  | 60,672 |  |  | 38,961 |  |  | 213,376 |  |  | 137,830 |  |
| Total revenue |  | 467,867 |  |  | 327,969 |  |  | 1,646,186 |  |  | 1,129,167 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 147,919 |  |  | 108,057 |  |  | 538,035 |  |  | 369,768 |  |
| Service |  | 12,783 |  |  | 9,757 |  |  | 46,382 |  |  | 36,283 |  |
| Total cost of revenue |  | 160,702 |  |  | 117,814 |  |  | 584,417 |  |  | 406,051 |  |
| Total gross profit |  | 307,165 |  |  | 210,155 |  |  | 1,061,769 |  |  | 723,116 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 107,180 |  |  | 71,398 |  |  | 349,594 |  |  | 273,581 |  |
| Sales and marketing |  | 38,808 |  |  | 38,321 |  |  | 155,105 |  |  | 130,887 |  |
| General and administrative |  | 21,789 |  |  | 22,941 |  |  | 86,798 |  |  | 75,239 |  |
| Total operating expenses |  | 167,777 |  |  | 132,660 |  |  | 591,497 |  |  | 479,707 |  |
| Income from operations |  | 139,388 |  |  | 77,495 |  |  | 470,272 |  |  | 243,409 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |
| Interest expense |  | (741 | ) |  | (918 | ) |  | (2,780 | ) |  | (3,136 | ) |
| Other income (expense), net |  | 2,988 |  |  | 560 |  |  | 7,268 |  |  | 1,952 |  |
| Total other income (expense), net |  | 2,247 |  |  | (358 | ) |  | 4,488 |  |  | (1,184 | ) |
| Income before provision for income taxes |  | 141,635 |  |  | 77,137 |  |  | 474,760 |  |  | 242,225 |  |
| Provision for income taxes |  | 37,802 |  |  | 18,354 |  |  | 51,559 |  |  | 58,036 |  |
| Net income |  | $ | 103,833 |  |  | $ | 58,783 |  |  | $ | 423,201 |  |  | $ | 184,189 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 103,752 |  |  | $ | 58,527 |  |  | $ | 422,400 |  |  | $ | 182,965 |  |
| Diluted |  | $ | 103,759 |  |  | $ | 58,542 |  |  | $ | 422,468 |  |  | $ | 183,039 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.42 |  |  | $ | 0.84 |  |  | $ | 5.85 |  |  | $ | 2.66 |  |
| Diluted |  | $ | 1.29 |  |  | $ | 0.79 |  |  | $ | 5.35 |  |  | $ | 2.50 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | 73,310 |  |  | 69,980 |  |  | 72,258 |  |  | 68,771 |  |
| Diluted |  | 80,243 |  |  | 74,384 |  |  | 78,977 |  |  | 73,222 |  |

[0001596532-18-000012:8k_2_02:56]
5

[0001596532-18-000012:8k_2_02:57]
ARISTA NETWORKS, INC.

[0001596532-18-000012:8k_2_02:58]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-18-000012:8k_2_02:59]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-18-000012:8k_2_02:60]
|  |  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| GAAP gross profit |  | $ | 307,165 |  |  | $ | 210,155 |  |  | $ | 1,061,769 |  |  | $ | 723,116 |  |
| GAAP gross margin |  | 65.7 | % |  | 64.1 | % |  | 64.5 | % |  | 64.0 | % |
| Stock-based compensation expense |  | 1,129 |  |  | 1,004 |  |  | 4,353 |  |  | 3,620 |  |
| Non-GAAP gross profit |  | $ | 308,294 |  |  | $ | 211,159 |  |  | $ | 1,066,122 |  |  | $ | 726,736 |  |
| Non-GAAP gross margin |  | 65.9 | % |  | 64.4 | % |  | 64.8 | % |  | 64.4 | % |
| GAAP income from operations |  | $ | 139,388 |  |  | $ | 77,495 |  |  | $ | 470,272 |  |  | $ | 243,409 |  |
| Stock-based compensation expense |  | 20,436 |  |  | 16,324 |  |  | 75,427 |  |  | 59,032 |  |
| Litigation expense |  | 9,072 |  |  | 12,209 |  |  | 40,352 |  |  | 35,833 |  |
| Non-GAAP income from operations |  | $ | 168,896 |  |  | $ | 106,028 |  |  | $ | 586,051 |  |  | $ | 338,274 |  |
| Non-GAAP operating margin |  | 36.1 | % |  | 32.3 | % |  | 35.6 | % |  | 30.0 | % |
| GAAP net income |  | $ | 103,833 |  |  | $ | 58,783 |  |  | $ | 423,201 |  |  | $ | 184,189 |  |
| Stock-based compensation expense |  | 20,436 |  |  | 16,324 |  |  | 75,427 |  |  | 59,032 |  |
| Litigation expense |  | 9,072 |  |  | 12,209 |  |  | 40,352 |  |  | 35,833 |  |
| Impact of the U.S. Tax Cuts and Jobs Act (1) |  | 51,812 |  |  | — |  |  | 51,812 |  |  | — |  |
| Excess tax benefit on share based awards |  | (38,312 | ) |  | — |  |  | (110,007 | ) |  | — |  |
| Release of income tax reserve |  | — |  |  | — |  |  | — |  |  | (6,293 | ) |
| Income tax effect on non-GAAP exclusions |  | (9,511 | ) |  | (9,836 | ) |  | (37,956 | ) |  | (31,340 | ) |
| Non-GAAP net income |  | $ | 137,330 |  |  | $ | 77,480 |  |  | $ | 442,829 |  |  | $ | 241,421 |  |
| GAAP diluted net income per share attributable to common stockholders |  | $ | 1.29 |  |  | $ | 0.79 |  |  | $ | 5.35 |  |  | $ | 2.50 |  |
| Non-GAAP adjustments to net income |  | 0.42 |  |  | 0.25 |  |  | 0.26 |  |  | 0.80 |  |
| Non-GAAP diluted net income per share |  | $ | 1.71 |  |  | $ | 1.04 |  |  | $ | 5.61 |  |  | $ | 3.30 |  |
| Weighted-average shares used in computing diluted net income per share attributable to common stockholders |  | 80,243 |  |  | 74,384 |  |  | 78,977 |  |  | 73,222 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,129 |  |  | $ | 1,004 |  |  | $ | 4,353 |  |  | $ | 3,620 |  |
| Research and development |  | 11,207 |  |  | 8,830 |  |  | 42,184 |  |  | 31,892 |  |
| Sales and marketing |  | 5,302 |  |  | 4,292 |  |  | 17,953 |  |  | 15,666 |  |
| General and administrative |  | 2,798 |  |  | 2,198 |  |  | 10,937 |  |  | 7,854 |  |
| Total |  | $ | 20,436 |  |  | $ | 16,324 |  |  | $ | 75,427 |  |  | $ | 59,032 |  |
| ________________________________ |  |  |  |  |  |  |  |  |
| (1) During the quarter ended December 31, 2017, we recorded provisional tax amounts for the one-time transition tax on the accumulated earnings of certain foreign subsidiaries and the re-measurement of certain deferred tax assets and liabilities as a result of the enactment of the Tax Act. Our accounting for these tax effects will be completed during the one-year measurement period allowed under Staff Accounting Bulletin 118. |

[0001596532-18-000012:8k_2_02:61]
ARISTA NETWORKS, INC.

[0001596532-18-000012:8k_2_02:62]
Condensed Consolidated Balance Sheets

[0001596532-18-000012:8k_2_02:63]
(Unaudited, in thousands)

[0001596532-18-000012:8k_2_02:64]
|  |  | December 31, 2017 |  | December 31, 2016 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 859,192 |  |  | $ | 567,923 |  |
| Marketable securities |  | 676,363 |  |  | 299,910 |  |
| Accounts receivable |  | 247,346 |  |  | 253,119 |  |
| Inventories |  | 306,198 |  |  | 236,490 |  |
| Prepaid expenses and other current assets |  | 177,330 |  |  | 168,684 |  |
| Total current assets |  | 2,266,429 |  |  | 1,526,126 |  |
| Property and equipment, net |  | 74,279 |  |  | 76,961 |  |
| Investments |  | 36,136 |  |  | 36,136 |  |
| Deferred tax assets |  | 65,125 |  |  | 70,960 |  |
| Other assets |  | 18,891 |  |  | 18,824 |  |
| TOTAL ASSETS |  | $ | 2,460,860 |  |  | $ | 1,729,007 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 52,200 |  |  | $ | 79,457 |  |
| Accrued liabilities |  | 133,827 |  |  | 90,951 |  |
| Deferred revenue |  | 327,706 |  |  | 273,350 |  |
| Other current liabilities |  | 16,172 |  |  | 15,795 |  |
| Total current liabilities |  | 529,905 |  |  | 459,553 |  |
| Income taxes payable |  | 34,067 |  |  | 14,498 |  |
| Lease financing obligations, non-current |  | 37,673 |  |  | 39,593 |  |
| Deferred revenue, non-current |  | 187,556 |  |  | 99,585 |  |
| Other long-term liabilities |  | 9,745 |  |  | 7,958 |  |
| TOTAL LIABILITIES |  | 798,946 |  |  | 621,187 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 7 |  |  | 7 |  |
| Additional paid-in capital |  | 804,731 |  |  | 674,183 |  |
| Retained earnings |  | 859,114 |  |  | 435,105 |  |
| Accumulated other comprehensive loss |  | (1,938 | ) |  | (1,475 | ) |
| TOTAL STOCKHOLDERS’ EQUITY |  | 1,661,914 |  |  | 1,107,820 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 2,460,860 |  |  | $ | 1,729,007 |  |

[0001596532-18-000012:8k_2_02:65]
7

[0001596532-18-000012:8k_2_02:66]
ARISTA NETWORKS, INC.

[0001596532-18-000012:8k_2_02:67]
Condensed Consolidated Statements of Cash Flows

[0001596532-18-000012:8k_2_02:68]
(Unaudited, in thousands)

[0001596532-18-000012:8k_2_02:69]
|  |  | Twelve Months Ended December 31, |
|  |  | 2017 |  | 2016 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 423,201 |  |  | $ | 184,189 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  | 20,640 |  |  | 19,749 |  |
| Stock-based compensation |  | 75,427 |  |  | 59,032 |  |
| Deferred income taxes |  | 8,426 |  |  | (21,720 | ) |
| Amortization of investment premiums |  | 1,452 |  |  | 1,493 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | 5,773 |  |  | (108,856 | ) |
| Inventories |  | (69,708 | ) |  | (144,361 | ) |
| Prepaid expenses and other current assets |  | (11,645 | ) |  | (115,074 | ) |
| Other assets |  | 907 |  |  | 2,866 |  |
| Accounts payable |  | (30,104 | ) |  | 38,678 |  |
| Accrued liabilities |  | 43,535 |  |  | 30,629 |  |
| Deferred revenue |  | 142,327 |  |  | 176,126 |  |
| Income taxes payable |  | 19,921 |  |  | 42,650 |  |
| Other liabilities |  | 1,475 |  |  | 8,894 |  |
| Net cash provided by operating activities (1) |  | 631,627 |  |  | 174,295 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 206,332 |  |  | 137,855 |  |
| Purchases of marketable securities |  | (585,373 | ) |  | (439,711 | ) |
| Purchases of property and equipment |  | (15,279 | ) |  | (21,419 | ) |
| Proceeds from repayment of notes receivable |  | 3,000 |  |  | — |  |
| Investment in privately-held companies |  | — |  |  | (2,500 | ) |
| Change in restricted cash |  | (1,260 | ) |  | (204 | ) |
| Net cash used in investing activities |  | (392,580 | ) |  | (325,979 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Principal payments of lease financing obligations |  | (1,617 | ) |  | (1,336 | ) |
| Proceeds from issuance of common stock under equity plans |  | 57,111 |  |  | 35,181 |  |
| Minimum tax withholding paid on behalf of employees for net share settlement |  | (4,025 | ) |  | (1,100 | ) |
| Net cash provided by financing activities (1) |  | 51,469 |  |  | 32,745 |  |
| Effect of exchange rate changes |  | 753 |  |  | (464 | ) |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS |  | 291,269 |  |  | (119,403 | ) |
| CASH AND CASH EQUIVALENTS—Beginning of period |  | 567,923 |  |  | 687,326 |  |
| CASH AND CASH EQUIVALENTS—End of period |  | $ | 859,192 |  |  | $ | 567,923 |  |
| ____________________________________ |  |  |  |  |
| (1) During our first fiscal quarter of 2017, we adopted Accounting Standards Update 2016-09, "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." This adoption resulted in an increase in net cash provided by operating activities and a corresponding decrease in net cash provided by financing activities of $42.9 million for the year ended December 31, 2016. |
