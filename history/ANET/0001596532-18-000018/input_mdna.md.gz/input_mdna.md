# ANET MD&A — 0001596532-18-000018


## mdna

[0001596532-18-000018:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001596532-18-000018:mdna:2]
Overview

[0001596532-18-000018:mdna:3]
We are a leading supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation data centers for enterprise support. Our cloud networking solutions consist of our Extensible Operating System, or EOS, a set of network applications and our Ethernet switching and routing platforms. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. At the core of our cloud networking platform is EOS, which was purpose-built to be fully programmable and highly modular. The programmability of EOS has allowed us to create a set of software applications that address the requirements of cloud networking, including workflow automation, network visibility and analytics, and has also allowed us to rapidly integrate with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.

[0001596532-18-000018:mdna:4]
We believe that cloud networks will continue to replace legacy network technologies, and that our cloud networking platform addresses the large and growing cloud networking segment of data center switching, which remains in the early stage of adoption. Cloud networks are subject to increasing performance requirements due to the growing number of connected devices, as well as new enterprise and consumer applications. Computing architectures are evolving to meet the need for constant connectivity and access to data and applications. We expect to continue growing our organization to meet the needs of new and existing customers as they increasingly realize the performance and cost benefits of our cloud networking solutions and as they expand their cloud networks. Accordingly, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our rapid development of new features and applications.

[0001596532-18-000018:mdna:5]
We generate revenue primarily from sales of our switching products which incorporate our EOS software. We generate the majority of our services revenue from post contract support, or PCS, which end customers typically purchase in conjunction with our products. Our end customers span a range of industries and include large Internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others. As we have grown the functionality of our EOS software, expanded the range of our product portfolio and increased the size of our sales force, our revenue has continued to grow rapidly. We have also been profitable and operating cash flow positive for each year since 2010.

[0001596532-18-000018:mdna:6]
To continue to grow our revenue, it is important that we both obtain new customers and sell additional products to existing customers. We expect that a substantial portion of our future sales will be follow-on sales to existing customers. We intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new end customers more effectively, increase sales to existing customers, and provide services and support effectively. In order to support our strong growth, we have and may continue to accelerate our investment in infrastructure, such as enterprise resource planning software and other technologies to improve the efficiency of our operations.

[0001596532-18-000018:mdna:7]
Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic to the underlying merchant silicon architecture. Today, we combine our EOS software with merchant silicon into a family of switching and routing products. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions.

[0001596532-18-000018:mdna:8]
We currently procure certain merchant silicon components from multiple vendors, and we continue to expand our relationships with these and other vendors. We work closely with third party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-18-000018:mdna:9]
Historically, large purchases by a relatively limited number of end customers have accounted for significant portion of our revenue. We have experienced unpredictability in the timing of large orders, especially with respect to our large end customers, due to the complexity of orders, the time it takes end customers to evaluate, test, qualify and accept our products and factors specific to our end customers. Due to these factors, we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. In addition, we have provided, and may in the future provide, pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur. Our gross margins may also fluctuate as a result of the timing of such sales to large end customers.

[0001596532-18-000018:mdna:10]
Furthermore, to comply with the limited exclusion order and cease and desist order in the 945 Investigation as described in Note 5 of the Notes to the Consolidated Financial Statements under Item 8 of this Form 10-K, entitled Commitments and Contingencies, we have made design changes to our products for sale in the United States to address the features that were found to infringe the patent claims underlying the remedial orders in the 945 Investigation. We have also worked closely with our customers on the qualification and testing of our redesigned products. The timing of the completion of these qualification activities for a few of our larger customers has extended beyond year end and this has impacted our business.  We continue to work with these customers to complete these procedures and improve the redesigns in order to meet customer requirements. We will need to complete any outstanding product modifications and qualification and acceptance processes for these customers and any inability to do so in a timely manner may result in an impact to our business, our revenue and our deferred revenue balances.

[0001596532-18-000018:mdna:11]
We also filed a motion with the U.S. Court of Appeals for the Federal Circuit (the "CAFC") requesting that they stay the orders of the United States International Trade Commission (“USITC”), pending completion of the appeals of the decisions of the United States Patent Trial and Appeal Board (“PTAB”), and sought an expedited schedule for those appeals. On September 22, 2017, the CAFC denied the motion to stay, but has allowed us to import its redesigned products into the United States without being blocked by the USITC’s orders, subject to any determinations by the USITC in subsequent proceedings regarding the redesigned products. On October 27, 2017, the USITC instituted a modification proceeding to determine whether our redesigned products infringe the patent claims underlying the remedial orders in the 945 Investigation. The USITC has set a deadline of five months for the ALJ to issue a recommended determination, which may be extended by one month upon a showing of good cause. The recommended determination will be subject to review by the Commission after which the Commission will issue a final determination. The Commission has not set a target date for the final determination. The hearing was held on January 26, 2018.

[0001596532-18-000018:mdna:12]
44

[0001596532-18-000018:mdna:13]
Results of Operations

[0001596532-18-000018:mdna:14]
The following table summarizes historical results of operations for the periods presented and as a percentage of revenue for those periods.  We have derived the data for the years ended December 31, 2017, 2016 and 2015 from our consolidated financial statements included in Item 8 of this Form 10-K (in thousands, except for percentages of revenue).

[0001596532-18-000018:mdna:15]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Consolidated Statements of Operations Data: |  |  |  |  |  |  |
| Revenue |  |  |  |  |  |  |
| Product |  | $ | 1,432,810 |  |  | $ | 991,337 |  |  | $ | 744,877 |  |
| Service |  | 213,376 |  |  | 137,830 |  |  | 92,714 |  |
| Total revenue |  | 1,646,186 |  |  | 1,129,167 |  |  | 837,591 |  |
| Cost of revenue(1) |  |  |  |  |  |  |
| Product |  | 538,035 |  |  | 369,768 |  |  | 263,585 |  |
| Service |  | 46,382 |  |  | 36,283 |  |  | 30,446 |  |
| Total cost of revenue |  | 584,417 |  |  | 406,051 |  |  | 294,031 |  |
| Gross profit |  | 1,061,769 |  |  | 723,116 |  |  | 543,560 |  |
| Operating expenses(1) |  |  |  |  |  |  |
| Research and development |  | 349,594 |  |  | 273,581 |  |  | 209,448 |  |
| Sales and marketing |  | 155,105 |  |  | 130,887 |  |  | 109,084 |  |
| General and administrative |  | 86,798 |  |  | 75,239 |  |  | 75,720 |  |
| Total operating expenses |  | 591,497 |  |  | 479,707 |  |  | 394,252 |  |
| Income from operations |  | 470,272 |  |  | 243,409 |  |  | 149,308 |  |
| Other income (expense), net |  |  |  |  |  |  |
| Interest expense |  | (2,780 | ) |  | (3,136 | ) |  | (3,152 | ) |
| Other income (expense), net |  | 7,268 |  |  | 1,952 |  |  | (147 | ) |
| Total other income (expense), net |  | 4,488 |  |  | (1,184 | ) |  | (3,299 | ) |
| Income before provision for income taxes |  | 474,760 |  |  | 242,225 |  |  | 146,009 |  |
| Provision for income taxes |  | 51,559 |  |  | 58,036 |  |  | 24,907 |  |
| Net income |  | $ | 423,201 |  |  | $ | 184,189 |  |  | $ | 121,102 |  |

[0001596532-18-000018:mdna:16]
(1) Includes stock-based compensation expense as follows:

[0001596532-18-000018:mdna:17]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Stock-Based Compensation Expense: |  |  |  |  |  |  |
| Cost of revenue |  | $ | 4,353 |  |  | $ | 3,620 |  |  | $ | 3,048 |  |
| Research and development |  | 42,184 |  |  | 31,892 |  |  | 25,515 |  |
| Sales and marketing |  | 17,953 |  |  | 15,666 |  |  | 11,454 |  |
| General and administrative |  | 10,937 |  |  | 7,854 |  |  | 5,286 |  |
| Total stock-based compensation |  | $ | 75,427 |  |  | $ | 59,032 |  |  | $ | 45,303 |  |

[0001596532-18-000018:mdna:18]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
|  |  | (as a percentage of revenue) |
| Revenue |  |  |  |  |  |  |
| Product |  | 87.0 | % |  | 87.8 | % |  | 88.9 | % |
| Service |  | 13.0 |  |  | 12.2 |  |  | 11.1 |  |
| Total revenue |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of revenue |  |  |  |  |  |  |
| Product |  | 32.7 |  |  | 32.8 |  |  | 31.5 |  |
| Service |  | 2.8 |  |  | 3.2 |  |  | 3.6 |  |
| Total cost of revenue |  | 35.5 |  |  | 36.0 |  |  | 35.1 |  |
| Gross margin |  | 64.5 |  |  | 64.0 |  |  | 64.9 |  |
| Operating expenses |  |  |  |  |  |  |
| Research and development |  | 21.2 |  |  | 24.2 |  |  | 25.0 |  |
| Sales and marketing |  | 9.4 |  |  | 11.6 |  |  | 13.0 |  |
| General and administrative |  | 5.3 |  |  | 6.7 |  |  | 9.0 |  |
| Total operating expenses |  | 35.9 |  |  | 42.5 |  |  | 47.0 |  |
| Income from operations |  | 28.6 |  |  | 21.6 |  |  | 17.9 |  |
| Interest expense |  | (0.2 | ) |  | (0.3 | ) |  | (0.4 | ) |
| Other income (expense), net |  | 0.4 |  |  | 0.2 |  |  | — |  |
| Total other income (expense), net |  | 0.2 |  |  | (0.1 | ) |  | (0.4 | ) |
| Income before provision for income taxes |  | 28.8 |  |  | 21.5 |  |  | 17.5 |  |
| Provision for income taxes |  | 3.1 |  |  | 5.1 |  |  | 3.0 |  |
| Net income |  | 25.7 | % |  | 16.3 | % |  | 14.5 | % |

[0001596532-18-000018:mdna:19]
Year Ended December 31, 2017 Compared to Year Ended December 31, 2016

[0001596532-18-000018:mdna:20]
Revenue, Cost of Revenue and Gross Profit (in thousands, except percentages)

[0001596532-18-000018:mdna:21]
|  |  | Year Ended December 31, |  |  |
|  |  | 2017 |  | 2016 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,432,810 |  |  | 87.0 | % |  | $ | 991,337 |  |  | 87.8 | % |  | $ | 441,473 |  |  | 44.5 | % |
| Service |  | 213,376 |  |  | 13.0 |  |  | 137,830 |  |  | 12.2 |  |  | 75,546 |  |  | 54.8 |  |
| Total revenue |  | 1,646,186 |  |  | 100.0 |  |  | 1,129,167 |  |  | 100.0 |  |  | 517,019 |  |  | 45.8 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 538,035 |  |  | 32.7 |  |  | 369,768 |  |  | 32.8 |  |  | 168,267 |  |  | 45.5 |  |
| Service |  | 46,382 |  |  | 2.8 |  |  | 36,283 |  |  | 3.2 |  |  | 10,099 |  |  | 27.8 |  |
| Total cost of revenue |  | 584,417 |  |  | 35.5 |  |  | 406,051 |  |  | 36.0 |  |  | 178,366 |  |  | 43.9 |  |
| Gross profit |  | $ | 1,061,769 |  |  | 64.5 | % |  | $ | 723,116 |  |  | 64.0 | % |  | $ | 338,653 |  |  | 46.8 | % |
| Gross margin |  | 64.5 | % |  |  |  | 64.0 | % |  |  |  |  |  |  |

[0001596532-18-000018:mdna:22]
Revenue by Geography (in thousands, except percentages)

[0001596532-18-000018:mdna:23]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | % of Total |  | 2016 |  | % of Total |
| Americas |  | $ | 1,192,289 |  |  | 72.4 | % |  | $ | 874,740 |  |  | 77.5 | % |
| Europe, Middle East and Africa |  | 299,547 |  |  | 18.2 |  |  | 168,789 |  |  | 14.9 |  |
| Asia-Pacific |  | 154,350 |  |  | 9.4 |  |  | 85,638 |  |  | 7.6 |  |
| Total revenue |  | $ | 1,646,186 |  |  | 100.0 | % |  | $ | 1,129,167 |  |  | 100.0 | % |

[0001596532-18-000018:mdna:24]
46

[0001596532-18-000018:mdna:25]
Revenue

[0001596532-18-000018:mdna:26]
We generate revenue primarily from sales of our products. We also derive a portion of our revenue from sales of PCS, which is typically purchased in conjunction with our products, and subsequent renewals of those contracts.  We expect our revenue may vary from period to period based on, among other things, the timing and size of orders, the delivery and acceptance of products, and the impact of significant transactions with unique terms and conditions that may require deferral of revenue.

[0001596532-18-000018:mdna:27]
Product revenue increased $441.5 million, or 44.5%, in the year ended December 31, 2017 compared to 2016. The increase was primarily driven by increased product shipments to our existing customers as they continued to expand their businesses. In addition, our newer switch products have continued to gain market acceptance, which has contributed to our revenue growth.  Service revenue increased $75.5 million, or 54.8%, in the year ended December 31, 2017 compared to 2016 as a result of continued growth in initial and renewal support contracts as our customer installed base continued to expand.

[0001596532-18-000018:mdna:28]
We continue to experience pricing pressure on our products and services due to competition, but demand for our products and growth in our installed base has more than offset this pricing pressure. Deferred product revenue at December 31, 2017 remained consistent with the balance at December 31, 2016. The deferred product revenue balance at December 31, 2016 primarily included customer arrangements with new product and new customer acceptance clauses, which expired during the current year, while the balance at December 31, 2017 primarily represents arrangements with a few of our larger customers related to the ongoing qualification activities of our 945 investigation-related product redesigns. As we enter 2018, we expect to continue to work with these customers to complete their qualification activities, which may impact our business.

[0001596532-18-000018:mdna:29]
Cost of Revenue and Gross Margin

[0001596532-18-000018:mdna:30]
Cost of revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs in our manufacturing operations department, and other manufacturing-related costs associated with manufacturing our products and managing our inventory. We expect our cost of product revenue to increase as our product revenue increases. Cost of providing PCS and other services consists primarily of personnel costs for our global customer support organization.

[0001596532-18-000018:mdna:31]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including sales to large end customers who generally receive lower pricing, manufacturing-related costs including costs associated with supply chain sourcing activities, merchant silicon costs, the mix of products sold, and excess/obsolete inventory write-downs, including charges for excess/obsolete component inventory held by our contract manufacturers. We expect our gross margins to fluctuate over time, depending on the factors described above and others.

[0001596532-18-000018:mdna:32]
Cost of revenue increased $178.4 million or 43.9% for the year ended December 31, 2017 compared to the same period in 2016. The increase in cost of revenue was primarily due to an increase in product shipment volumes and the corresponding increase in product revenue. Gross margin increased from 64.0% to 64.5% for the year ended December 31, 2017 compared to the same period in 2016.  The increase in gross margin was primarily driven by improved service margins as we scaled our services business on a relatively fixed cost base and slightly better product margins due to end customer mix. This improvement was partially offset by an increase in excess and obsolete inventory-related charges as we transition to new products.

[0001596532-18-000018:mdna:33]
Operating Expenses (in thousands, except percentages)

[0001596532-18-000018:mdna:34]
Our operating expenses consist of research and development, sales and marketing and general and administrative expenses. The largest component of our operating expenses is personnel costs. Personnel costs consist of wages, benefits, bonuses and, with respect to sales and marketing expenses, sales commissions. Personnel costs also include stock-based compensation and travel expenses. We expect operating expenses to continue to increase in absolute dollars in the near term as we continue to invest in the growth of our business.

[0001596532-18-000018:mdna:35]
|  |  | Year Ended December 31, |  |  |
|  |  | 2017 |  | 2016 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 349,594 |  |  | 21.2 | % |  | $ | 273,581 |  |  | 24.2 | % |  | $ | 76,013 |  |  | 27.8 | % |
| Sales and marketing |  | 155,105 |  |  | 9.4 |  |  | 130,887 |  |  | 11.6 |  |  | 24,218 |  |  | 18.5 |  |
| General and administrative |  | 86,798 |  |  | 5.3 |  |  | 75,239 |  |  | 6.7 |  |  | 11,559 |  |  | 15.4 |  |
| Total operating expenses |  | $ | 591,497 |  |  | 35.9 | % |  | $ | 479,707 |  |  | 42.5 | % |  | $ | 111,790 |  |  | 23.3 | % |

[0001596532-18-000018:mdna:36]
Research and development.

[0001596532-18-000018:mdna:37]
Research and development expenses consist primarily of personnel costs, prototype expenses, third-party engineering and contractor support costs, and an allocated portion of facility and IT costs including depreciation. Our research and development efforts are focused on maintaining and developing additional functionality for our existing products and on new product development, including new releases and upgrades to our EOS software and applications. We expect our research and development expenses to increase in absolute

[0001596532-18-000018:mdna:38]
dollars as we continue to invest heavily in software development in order to expand the capabilities of our cloud networking platform, introduce new products and features and build upon our technology leadership.

[0001596532-18-000018:mdna:39]
Research and development expenses increased $76.0 million, or 27.8%, for the year ended December 31, 2017 compared to the same period in 2016. The increase was primarily due to a $36.9 million increase in personnel costs driven by headcount growth, resulting in additional compensation costs including stock-based compensation, and a $31.6 million increase in prototype and third-party engineering costs driven by additional outsourced development projects and costs associated with litigation-related changes in product design. In addition, facility and IT costs increase by $5.3 million due to the headcount growth.

[0001596532-18-000018:mdna:40]
Sales and marketing.

[0001596532-18-000018:mdna:41]
Sales and marketing expenses consist primarily of personnel costs, marketing and promotional activities, and an allocated portion of facility and IT costs including depreciation. We expect our sales and marketing expenses to increase in absolute dollars as we continue to expand our sales and marketing efforts worldwide.

[0001596532-18-000018:mdna:42]
Sales and marketing expenses increased $24.2 million, or 18.5% for the year ended December 31, 2017 compared to the same period in 2016. The increase included a $15.4 million increase in personnel costs, which was primarily due to increased headcount as well as higher sales volumes, driving increased compensation costs, including commissions and stock-based compensation. In addition, sales support costs increased by $8.1 million compared to 2016, reflecting increased professional services and field demonstration costs to support our sales infrastructure and expand our customer base.

[0001596532-18-000018:mdna:43]
General and administrative.

[0001596532-18-000018:mdna:44]
General and administrative expenses consist primarily of Cisco and Optumsoft litigation related expenses, personnel costs, professional services fees, and an allocated portion of facility and IT costs including depreciation. General and administrative personnel costs include those for our executive, finance, human resources and legal functions. Our professional services fees are primarily due to external legal, accounting, and tax services. We expect our general and administrative expenses to fluctuate in absolute dollars from period to period depending on the timing and progress of our litigation activities.

[0001596532-18-000018:mdna:45]
General and administrative expenses increased $11.6 million, or 15.4%, for the year ended December 31, 2017 compared to the same period in 2016. The increase was primarily due to a $4.5 million increase in the Cisco litigation related expenses, which included bond costs associated with the importation and sale of affected products and components during the presidential review period of the 945 Investigation. In addition, personnel costs increased by $3.9 million primarily due to increased stock-based compensation and higher salary related costs driven by increased headcount.

[0001596532-18-000018:mdna:46]
Other Income (Expense), Net (in thousands, except percentages)

[0001596532-18-000018:mdna:47]
Other income (expense) consists primarily of interest income from our cash equivalents and marketable securities, foreign currency transaction gains and losses, and interest expense on our lease financing obligation. We expect our interest income to grow in 2018 as we continue to grow our cash balance and invest our excess cash in marketable securities. We expect our foreign currency gains and losses to continue to fluctuate in the future due to changes in foreign currency exchange rates.

[0001596532-18-000018:mdna:48]
|  |  | Year Ended December 31, |  |  |
|  |  | 2017 |  | 2016 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | $ | (2,780 | ) |  | (0.2 | )% |  | $ | (3,136 | ) |  | (0.3 | )% |  | $ | 356 |  |  | (11.4 | )% |
| Other income (expense), net |  | 7,268 |  |  | 0.4 |  |  | 1,952 |  |  | 0.2 |  |  | 5,316 |  |  | 272.3 |  |
| Total other income (expense), net |  | $ | 4,488 |  |  | 0.2 | % |  | $ | (1,184 | ) |  | (0.1 | )% |  | $ | 5,672 |  |  | (479.1 | )% |

[0001596532-18-000018:mdna:49]
Other income (expense), net improved during the year ended December 31, 2017 compared to 2016 primarily due to an increase in interest income as we continued to generate cash and expand our marketable securities portfolio.

[0001596532-18-000018:mdna:50]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-18-000018:mdna:51]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. Earnings from our non-U.S. activities are subject to local country income tax and may be subject to U.S. income tax. Generally, our U.S. tax obligations are reduced by a credit for foreign income taxes paid on these earnings which avoids double taxation. Our tax expense to date consists of federal, state and foreign current and deferred income taxes.

[0001596532-18-000018:mdna:52]
|  |  | Year Ended December 31, |  |  |
|  |  | 2017 |  | 2016 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Provision for income taxes |  | $ | 51,559 |  |  | 3.1 | % |  | $ | 58,036 |  |  | 5.1 | % |  | $ | (6,477 | ) |  | (11.2 | ) |
| Effective tax rate |  | 10.9 | % |  |  |  | 24.0 | % |  |  |  |  |  |  |  |  |

[0001596532-18-000018:mdna:53]
Our provision for income taxes was approximately $51.6 million and $58.0 million for the year ended December 31, 2017 and 2016, respectively, which resulted in a decrease in our effective tax rate from 24.0% in 2016 to 10.9% in 2017.  The reduction in our effective tax rate was primarily due to the recognition of $110.0 million of excess tax benefits on share-based awards in the provision for income taxes as a result of our adoption of ASU 2016-09 in 2017, combined with a favorable geographical mix of our earnings towards jurisdictions with lower tax rates than the U.S.  These positive drivers were partially offset by the inclusion of provisional tax amount totaling $51.8 million resulting from the recently enacted Tax Cuts and Jobs Act (the “Tax Act”).

[0001596532-18-000018:mdna:54]
The Tax Act makes significant changes to the U.S. tax code, which include, but are not limited to, a U.S. federal corporate tax rate decrease from 35% to 21% effective January 1, 2018, and a shift to a modified territorial tax regime, which requires companies to pay a one-time transition tax on the mandatory deemed repatriation of the cumulative earnings of certain foreign subsidiaries as of December 31, 2017.  As of December 31, 2017, we had not yet completed our accounting for the tax effects of the Tax Act.  As a result, we recorded a provisional tax amount of $18.8 million for the transition tax and a provisional tax amount of $33.0 million related to the re-measurement of certain deferred tax assets and liabilities, based on the tax rates at which they are expected to reverse in the future.

[0001596532-18-000018:mdna:55]
We will continue to refine our estimates related to the impact of the Tax Act during the one year measurement period allowed under Staff Accounting Bulletin 118 (“SAB 118”).  In addition, our future effective tax rate is anticipated to fluctuate as a result of excess tax benefits to be included in the income tax provision.

[0001596532-18-000018:mdna:56]
Year Ended December 31, 2016 Compared to Year Ended December 31, 2015

[0001596532-18-000018:mdna:57]
Revenue, Cost of Revenue and Gross Profit (in thousands, except percentages)

[0001596532-18-000018:mdna:58]
|  |  | Year Ended December 31, |  |  |
|  |  | 2016 |  | 2015 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 991,337 |  |  | 87.8 | % |  | $ | 744,877 |  |  | 88.9 | % |  | $ | 246,460 |  |  | 33.1 | % |
| Service |  | 137,830 |  |  | 12.2 |  |  | 92,714 |  |  | 11.1 |  |  | 45,116 |  |  | 48.7 |  |
| Total revenue |  | 1,129,167 |  |  | 100.0 |  |  | 837,591 |  |  | 100.0 |  |  | 291,576 |  |  | 34.8 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 369,768 |  |  | 32.8 |  |  | 263,585 |  |  | 31.5 |  |  | 106,183 |  |  | 40.3 |  |
| Service |  | 36,283 |  |  | 3.2 |  |  | 30,446 |  |  | 3.6 |  |  | 5,837 |  |  | 19.2 |  |
| Total cost of revenue |  | 406,051 |  |  | 36.0 |  |  | 294,031 |  |  | 35.1 |  |  | 112,020 |  |  | 38.1 |  |
| Gross profit |  | $ | 723,116 |  |  | 64.0 | % |  | $ | 543,560 |  |  | 64.9 | % |  | $ | 179,556 |  |  | 33.0 | % |
| Gross margin |  | 64.0 | % |  |  |  | 64.9 | % |  |  |  |  |  |  |

[0001596532-18-000018:mdna:59]
Revenue by Geography (in thousands, except percentages)

[0001596532-18-000018:mdna:60]
|  |  | Year Ended December 31, |
|  |  | 2016 |  | % of Total |  | 2015 |  | % of Total |
| Americas |  | $ | 874,740 |  |  | 77.5 | % |  | $ | 646,919 |  |  | 77.3 | % |
| Europe, Middle East and Africa |  | 168,789 |  |  | 14.9 |  |  | 128,400 |  |  | 15.3 |  |
| Asia-Pacific |  | 85,638 |  |  | 7.6 |  |  | 62,272 |  |  | 7.4 |  |
| Total revenue |  | $ | 1,129,167 |  |  | 100.0 | % |  | $ | 837,591 |  |  | 100.0 | % |

[0001596532-18-000018:mdna:61]
Revenue

[0001596532-18-000018:mdna:62]
Product revenue increased $246.5 million or 33.1% in the year ended December 31, 2016 compared to 2015. The increase during the period was primarily driven by increased shipments to our existing customers as they continue to grow and expand their businesses, increasing their demand for our products and related accessories. The introduction of new products contributed to our revenue growth, both with existing and new customers.  Service revenue increased 48.7% in the year ended December 31, 2016 as a result of continued growth in initial and renewal support contracts as our customer installed base continued to expand. We also continued to experience

[0001596532-18-000018:mdna:63]
pressure in product and service pricing due to competitive market conditions. However, this pricing pressure was more than offset by the increased demand drivers outlined above.

[0001596532-18-000018:mdna:64]
Cost of Revenue and Gross Margin

[0001596532-18-000018:mdna:65]
Cost of revenue increased $112.0 million or 38.1% for the year ended December 31, 2016 compared to the same period in 2015. The increase in cost of revenue was primarily due to an increase in product shipment volumes. In addition, we incurred increased costs as we added capacity to our manufacturing and operations infrastructure. Gross margin decreased from 64.9% to 64.0% for the year ended December 31, 2016 compared to the same period in 2015. The decrease during the period was primarily the result of changes in customer mix as we expanded our business including increased contributions from larger customers who typically receive higher discount levels, and increased costs associated with the expansion of manufacturing and operations capacity. These unfavorable changes were partially offset by improved service margins as we scale our services business.

[0001596532-18-000018:mdna:66]
Operating Expenses (in thousands, except percentages)

[0001596532-18-000018:mdna:67]
|  |  | Year Ended December 31, |  |  |
|  |  | 2016 |  | 2015 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 273,581 |  |  | 24.2 | % |  | $ | 209,448 |  |  | 25.0 | % |  | $ | 64,133 |  |  | 30.6 | % |
| Sales and marketing |  | 130,887 |  |  | 11.6 |  |  | 109,084 |  |  | 13.0 |  |  | 21,803 |  |  | 20.0 |  |
| General and administrative |  | 75,239 |  |  | 6.7 |  |  | 75,720 |  |  | 9.0 |  |  | (481 | ) |  | (0.6 | ) |
| Total operating expenses |  | $ | 479,707 |  |  | 42.5 | % |  | $ | 394,252 |  |  | 47.0 | % |  | $ | 85,455 |  |  | 21.7 | % |

[0001596532-18-000018:mdna:68]
Research and development

[0001596532-18-000018:mdna:69]
Research and development expenses increased $64.1 million, or 30.6%, for the year ended December 31, 2016 compared to the same period in 2015. The increase was primarily due to an increase in personnel costs of $31.2 million resulting from an increase in compensation costs, including stock-based compensation and corporate bonus expense, primarily driven by headcount growth. Prototype spend and third-party engineering and consulting costs increased by $27.3 million, related to additional outsourced development projects, increased internal development activity related to new products and increased costs associated with litigation-related changes in product design. Facilities and IT infrastructure costs increased $3.1 million primarily due to continued expansion and support of our research and development activities.

[0001596532-18-000018:mdna:70]
Sales and marketing

[0001596532-18-000018:mdna:71]
Sales and marketing expenses increased $21.8 million, or 20.0% for the year ended December 31, 2016 compared to the same period in 2015. The increase was primarily due to an increase in personnel costs of $21.0 million, reflecting increased compensation costs, including sales incentive compensation and corporate bonus expense, primarily driven by headcount growth and higher sales volumes. In addition, sales and customer engineering consulting expenses mostly related to international expansion increased by $1.3 million, and marketing promotion, trade shows and events increased by $1.1 million, as compared to the same period in 2015. The increase was partially offset by a decrease in product field demonstration costs of $1.7 million primarily related to significant costs incurred in the previous year due to several next generation product transitions.

[0001596532-18-000018:mdna:72]
General and administrative

[0001596532-18-000018:mdna:73]
General and administrative expenses decreased $(0.5) million, or (0.6)%, for the year ended December 31, 2016 compared to the same period in 2015. The decrease was primarily due to a reduction in litigation expenses of $5.6 million during the year ended December 31, 2016 as compared to the same period in 2015. This decrease was primarily related to the timing of litigation activities associated with the Cisco and OptumSoft legal matters outlined in Note 5 to the Consolidated Financial Statements. This decrease was largely offset by an increase in personnel costs of $4.9 million in the year ended December 31, 2016 as compared to the same period in 2015. This reflects increased compensation costs, including increased stock-based compensation and corporate bonus expense, primarily driven by headcount growth.

[0001596532-18-000018:mdna:74]
Other Income (Expense), Net (in thousands, except percentages)

[0001596532-18-000018:mdna:75]
|  |  | Year Ended December 31, |  |  |
|  |  | 2016 |  | 2015 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | $ | (3,136 | ) |  | (0.3 | )% |  | $ | (3,152 | ) |  | (0.4 | )% |  | $ | 16 |  |  | (0.5 | )% |
| Other income (expense), net |  | 1,952 |  |  | 0.2 |  |  | (147 | ) |  | — |  |  | 2,099 |  |  | (1,427.9 | ) |
| Total other income (expense), net |  | $ | (1,184 | ) |  | (0.1 | )% |  | $ | (3,299 | ) |  | (0.4 | )% |  | $ | 2,115 |  |  | (64.1 | )% |

[0001596532-18-000018:mdna:76]
Other income (expense), net improved during the year ended December 31, 2016 compared to 2015 primarily due to a net increase in interest income as we expanded our marketable securities portfolio.

[0001596532-18-000018:mdna:77]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-18-000018:mdna:78]
|  |  | Year Ended December 31, |  |  |
|  |  | 2016 |  | 2015 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Provision for income taxes |  | $ | 58,036 |  |  | 5.1 | % |  | $ | 24,907 |  |  | 3.0 | % |  | $ | 33,129 |  |  | 133.0 | % |
| Effective tax rate |  | 24.0 | % |  |  |  | 17.1 | % |  |  |  |  |  |  |

[0001596532-18-000018:mdna:79]
Provision for income taxes was approximately $58.0 million and $24.9 million for the year ended December 31, 2016 and 2015, respectively. The change in our provision was primarily due to an increase in profit before income taxes. The increase in the provision was also a result of additional state and foreign taxes, non-deductible permanent differences, offset by a shift in the geographic foreign earnings mix taxed at a lower rate than the U.S. tax rate.

[0001596532-18-000018:mdna:80]
Liquidity and Capital Resources

[0001596532-18-000018:mdna:81]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of December 31, 2017, our total balance of cash, cash equivalents and marketable securities was $1.5 billion, of which approximately $118.0 million was held outside the U.S. in our foreign subsidiaries.  The Tax Act included a one-time transition tax on unremitted foreign earnings, and accordingly, we recorded tax expense of $18.8 million in the fourth quarter of 2017 related to the transition tax on the one-time mandatory deemed repatriation of all our foreign earnings as of December 31, 2017. See Note 8 of the Notes to Consolidated Financial Statements under Item 8 of this Form 10-K for additional information on income taxes.

[0001596532-18-000018:mdna:82]
Our cash, cash equivalents and securities are held for working capital purposes. Our marketable securities investment portfolio is primarily invested in highly-rated securities with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities together with cash generated from operations will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and costs incurred related to outstanding litigation claims. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-18-000018:mdna:83]
Cash Flows

[0001596532-18-000018:mdna:84]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 631,627 |  |  | $ | 174,295 |  |  | $ | 237,784 |  |
| Cash provided by (used in) investing activities |  | (392,580 | ) |  | (325,979 | ) |  | 184,170 |  |
| Cash provided by financing activities |  | 51,469 |  |  | 32,745 |  |  | 25,854 |  |
| Effect of exchange rate changes |  | 753 |  |  | (464 | ) |  | (513 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 291,269 |  |  | $ | (119,403 | ) |  | $ | 447,295 |  |

[0001596532-18-000018:mdna:85]
Cash Flows from Operating Activities

[0001596532-18-000018:mdna:86]
Our primary source of cash provided by operating activities has been cash collections from our customers. We expect cash inflows from operating activities to be affected by increased sales and timing of collections. Our primary uses of cash from operating activities have been for personnel costs, inventory purchases from our contract manufacturers, investment in research and development, and litigation expenses.

[0001596532-18-000018:mdna:87]
During the year ended December 31, 2017, cash provided by operating activities was $631.6 million, primarily from net income of $423.2 million with non-cash adjustments to net income of $105.9 million, and a net increase of $102.5 million in cash from changes in our operating assets and liabilities. Our operating cash benefited $142.3 million from increased deferred revenue reflecting ongoing growth in service and support contracts, $43.5 million from increased accrued liabilities driven by increased inventory purchases and product development activities, and $19.9 million from increased income taxes payable. These favorable changes were partially offset by a growth in inventory of $69.7 million, supporting overall growth in the business and the expansion of our manufacturing and supply chain activities, by a decline in accounts payable of $30.1 million due to timing of vendor payments primarily related to inventory purchases, and by an increase in prepaid expenses and other assets of $11.6 million primarily due to increased prepaid taxes.

[0001596532-18-000018:mdna:88]
During the year ended December 31, 2016, cash provided by operating activities was $174.3 million, primarily from net income of $184.2 million with non-cash adjustments to net income of $58.6 million, partially offset by a net decrease in cash from changes in our operating assets and liabilities of $68.4 million. The decrease in cash from changes in operating assets and liabilities was primarily due to an increase in working capital requirements with accounts receivable up $108.9 million, inventories and inventory deposits up $207.5 million, and increased prepaid expenses and current assets (excluding inventory deposits) of $54.8 million which was primarily driven by an increase in deferred cost of inventory associated with increased product revenue deferrals referenced below.  These increases reflect substantial growth in the business and the expansion of our manufacturing and supply chain activities at our new contract manufacturer. These working capital increases were partially offset by an increase in deferred revenue of $176.1 million reflecting ongoing growth in service and support contracts and a significant increase in product deferred revenue related to contract acceptance terms, as well as an increase in accounts payable and accrued liabilities of $69.3 million primarily due to timing of inventory purchases, and an increase in income taxes payable of $42.7 million.

[0001596532-18-000018:mdna:89]
During the year ended December 31, 2015, cash provided by operating activities was $237.8 million, primarily from net income of $121.1 million with non-cash adjustments to net income of $36.0 million, and a net increase in cash from changes in our operating assets and liabilities of $80.6 million. The net increase in cash from changes in operating assets and liabilities was primarily due to an increase in deferred revenue of $90.3 million, largely related to short and long-term services contracts and product revenue deferrals related to contracts with acceptance terms. In addition, we experienced an increase in cash of $32.0 million from income taxes payable and an increase in our accounts payable and accrued liabilities of $29.4 million due to the timing of payments. These operating liability increases were offset by an increase in our accounts receivable of $47.3 million and an increase in inventory of $14.1 million due to increased business volume and timing, and prepaid expenses and current assets increased $7.8 million in the period.

[0001596532-18-000018:mdna:90]
Cash Flows from Investing Activities

[0001596532-18-000018:mdna:91]
Our investing activities have consisted primarily of purchases of available for sale marketable securities, net of proceeds from maturities of marketable securities, and capital expenditures. We expect to continue investing in these activities to support the continued growth of our business.

[0001596532-18-000018:mdna:92]
During the year ended December 31, 2017, cash used in investing activities was $392.6 million, consisting of purchases of marketable securities of $585.4 million, purchases of property, equipment and other assets of $15.3 million, partially offset by proceeds of $206.3 million from maturities of marketable securities and proceeds of $3.0 million from repayment of notes receivable.

[0001596532-18-000018:mdna:93]
During the year ended December 31, 2016, cash used in investing activities was $326.0 million, consisting of purchases of marketable securities of $439.7 million, purchases of property, equipment and other assets of $21.4 million, and an additional investment in a privately held company of $2.5 million. These decreases were partially offset by proceeds from the maturity of available-for-sale securities of $137.9 million.

[0001596532-18-000018:mdna:94]
During the year ended December 31, 2015, cash provided by investing activities was $184.2 million, consisting of proceeds from the maturity of available-for-sale securities of $208.2 million, partially offset by purchases of property, equipment and other assets of $19.2 million and an increase in restricted cash of $4.0 million related to a security deposit required for a facility lease.

[0001596532-18-000018:mdna:95]
Cash Flows from Financing Activities

[0001596532-18-000018:mdna:96]
Our financing activities have consisted primarily of proceeds from the issuance of our common stock under employee equity incentive plans, offset by principal payments for lease financing obligations related to our headquarters facility.

[0001596532-18-000018:mdna:97]
During the year ended December 31, 2017, cash provided by financing activities was $51.5 million, consisting primarily of proceeds of $44.6 million from employee stock option exercises, partially offset by $4.0 million of minimum tax withheld for employees, and proceeds of $12.5 million from employee stock purchases under our ESPP, partially offset by payments of $1.6 million for lease financing obligations.

[0001596532-18-000018:mdna:98]
During the year ended December 31, 2016, cash provided by financing activities was $32.7 million, consisting primarily of proceeds from the exercise of stock options of $24.9 million and proceeds from the issuance of common stock from our ESPP of $10.3 million, partially offset by payments of $1.3 million for lease financing obligations.

[0001596532-18-000018:mdna:99]
During the year ended December 31, 2015, cash provided by financing activities was $25.9 million, consisting primarily of proceeds from the exercise of stock options of $17.8 million and the proceeds from the issuance of common stock from our ESPP of $9.4 million, partially offset by payments of $1.1 million for lease financing obligations.

[0001596532-18-000018:mdna:100]
Off-Balance Sheet Arrangements

[0001596532-18-000018:mdna:101]
As of December 31, 2017, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-18-000018:mdna:102]
Contractual Obligations and Commitments

[0001596532-18-000018:mdna:103]
Our contractual commitments will have an impact on our future liquidity. Our contractual obligations represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalent and marketable securities.

[0001596532-18-000018:mdna:104]
The following summarizes our contractual obligations and commitments as of December 31, 2017 (in thousands):

[0001596532-18-000018:mdna:105]
|  |  | Payments Due by Period |
|  |  | Total |  | Less than1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than5 Years |
| Financing lease obligation (1) |  | $ | 37,692 |  |  | $ | 6,113 |  |  | $ | 12,770 |  |  | $ | 13,545 |  |  | $ | 5,264 |  |
| Operating lease obligations |  | 51,004 |  |  | 9,127 |  |  | 16,686 |  |  | 15,318 |  |  | 9,873 |  |
| Purchase commitments with contract manufacturers and suppliers |  | 147,854 |  |  | 147,854 |  |  | — |  |  | — |  |  | — |  |
| Other non-cancellable purchase obligations |  | 47,250 |  |  | 47,250 |  |  | — |  |  | — |  |  |  |
| Total |  | $ | 283,800 |  |  | $ | 210,344 |  |  | $ | 29,456 |  |  | $ | 28,863 |  |  | $ | 15,137 |  |

[0001596532-18-000018:mdna:106]
_________________

[0001596532-18-000018:mdna:107]
(1) Includes interest and land lease.

[0001596532-18-000018:mdna:108]
The contractual obligation table above excludes tax liabilities of $37.9 million related to uncertain tax positions and the transition tax due under the Tax Act because we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-18-000018:mdna:109]
Critical Accounting Policies and Estimates

[0001596532-18-000018:mdna:110]
We have prepared our consolidated financial statements in accordance with GAAP and include our accounts and the accounts of our wholly owned subsidiaries. The preparation of these consolidated financial statements requires our management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities at the date of the financial statements, disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the applicable periods. We base our estimates, assumptions and judgments on historical experience and on various other factors that we believe to be reasonable under the circumstances. Different assumptions and judgments would change the estimates used in the preparation of our consolidated financial statements, which, in turn, could change the results from those reported. We evaluate our estimates, assumptions and judgments on an ongoing basis. Actual results may differ from these estimates. The critical accounting estimates, assumptions and judgments that we believe have the most significant impact on our consolidated financial statements are the following:

[0001596532-18-000018:mdna:111]
Revenue Recognition

[0001596532-18-000018:mdna:112]
We generate revenue from sales of our products which incorporate our EOS software and accessories such as cables and optics to direct customers and channel partners together with post contract customer support (“PCS”). We typically sell products and PCS in a single transaction. We recognize revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery or performance has occurred; the sales price is fixed or determinable; and collectability is reasonably assured.

[0001596532-18-000018:mdna:113]
We define each of the four criteria above as follows:

[0001596532-18-000018:mdna:114]
| • | Persuasive evidence of an arrangement exists. Evidence of an arrangement consists of stand-alone purchase orders or purchase orders issued pursuant to the terms and conditions of a master sales agreement. It is our practice to identify an end customer prior to shipment to a reseller or distributor. |

[0001596532-18-000018:mdna:115]
| • | Delivery or performance has occurred. We use shipping documents or written evidence of customer acceptance, when applicable, to verify delivery or performance. We recognize product revenue upon transfer of title and risk of loss, which primarily is upon shipment to customers. We generally do not have significant obligations for future performance, rights of |

[0001596532-18-000018:mdna:116]
return, or pricing credits associated with our product sales. In instances where substantive acceptance provisions are specified in the customer arrangement, revenue and deferred cost of revenue is deferred until all acceptance criteria have been met.

[0001596532-18-000018:mdna:117]
| • | The sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on payment terms and whether the sales price is subject to refund or adjustment. |

[0001596532-18-000018:mdna:118]
| • | Collectability is reasonably assured. We assess probability of collectability on a customer-by-customer basis. Our customers and channel partners are subjected to a credit review process that evaluates their financial condition and ability to pay for products and services. |

[0001596532-18-000018:mdna:119]
PCS, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract, with the related expenses recognized as incurred. PCS contracts usually have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-18-000018:mdna:120]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of goods sold.

[0001596532-18-000018:mdna:121]
Multiple-Element Arrangements

[0001596532-18-000018:mdna:122]
Most of our arrangements, other than renewals of PCS, are multiple element arrangements with a combination of products and PCS. Products and PCS generally qualify as separate units of accounting. Our hardware deliverables include EOS software, which together deliver the essential functionality of our products. For multiple element arrangements, we allocate revenue to each unit of accounting based on the relative selling price. The relative selling price for each element is based upon the following hierarchy: vendor-specific objective evidence (“VSOE”), if available; third-party evidence (“TPE”), if VSOE is not available; and best estimate of selling price (“BESP”), if neither VSOE nor TPE is available. As we have not been able to establish VSOE or TPE for our products and most of our services, we generally utilize BESP for the purposes of allocating revenue to each unit of accounting.

[0001596532-18-000018:mdna:123]
| • | VSOE—We determine VSOE based on our historical pricing and discounting practices for the specific products and services when sold separately. In determining VSOE, we require that a substantial majority of the stand-alone selling prices fall within a reasonably narrow pricing range. |

[0001596532-18-000018:mdna:124]
| • | TPE—When VSOE cannot be established for deliverables in multiple-element arrangements, we apply judgment with respect to whether we can establish a selling price based on TPE. TPE is determined based on competitor prices for interchangeable products or services when sold separately to similarly situated customers. However, as our products contain a significant element of proprietary technology and offer substantially different features and functionality, the comparable pricing of products with similar functionality typically cannot be obtained. Additionally, as we are unable to reliably determine what competitors products’ selling prices are on a stand-alone basis, we are not able to obtain reliable evidence of TPE of selling price. |

[0001596532-18-000018:mdna:125]
| • | BESP—When we are unable to establish selling price using VSOE or TPE, we use BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service was sold regularly on a stand-alone basis. BESP is based on considering multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services were sold (domestic or international) and size of the end customer. |

[0001596532-18-000018:mdna:126]
We limit the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations, or subject to customer-specific return, acceptance or refund privileges.

[0001596532-18-000018:mdna:127]
We account for multiple agreements with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single arrangement.

[0001596532-18-000018:mdna:128]
We may occasionally accept returns to address customer satisfaction issues even though there is no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period gross revenues. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-18-000018:mdna:129]
In May 2014, the Financial Accounting Standards Board (the "FASB") issued Accounting Standards Update ("ASU") 2014-09, “Revenue from Contracts with Customers,” which replaces primarily all existing revenue recognition guidance under GAAP and establishes common principles for recognizing revenue for all industries. Based on our assessment, we will adopt the new standard in our first quarter of 2018 using the modified retrospective method. We do not expect the impact from adopting the new revenue guidance to have a material impact on our results of operations or financial condition in the year of adoption. See Note 1 of the Notes to Consolidated Financial Statements under Item 8 of this Form 10-K for details.

[0001596532-18-000018:mdna:130]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-18-000018:mdna:131]
Inventories primarily consist of finished goods and strategic components, primarily integrated circuits. Inventories are stated at the lower of cost (computed using the first-in, first-out method) and net realizable value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory.  We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value.

[0001596532-18-000018:mdna:132]
Our contract manufacturers procure components and assemble products on our behalf based on our forecasts. We record a liability and a corresponding charge for non-cancellable, non-returnable purchase commitments with our contract manufacturers or suppliers for quantities in excess of our demand forecasts or that are considered obsolete due to manufacturing and engineering change orders resulting from design changes.

[0001596532-18-000018:mdna:133]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer liabilities.

[0001596532-18-000018:mdna:134]
Income Taxes

[0001596532-18-000018:mdna:135]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-18-000018:mdna:136]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-18-000018:mdna:137]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-18-000018:mdna:138]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.

[0001596532-18-000018:mdna:139]
Loss Contingencies

[0001596532-18-000018:mdna:140]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. In assessing loss contingencies, we use significant judgment and assumptions to estimate the likelihood of loss, impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. We record a provision for contingent losses when it is both probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. We will record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements and (ii) the range of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.

[0001596532-18-000018:mdna:141]
Recent Accounting Pronouncements

[0001596532-18-000018:mdna:142]
Refer to “Recent Accounting Pronouncements” in Note 1 to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K.
