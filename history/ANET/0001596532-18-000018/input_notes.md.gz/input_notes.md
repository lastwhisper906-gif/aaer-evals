# ANET notes — 0001596532-18-000018


## anet:ConcentrationRiskComponentsSupplierRiskPolicyTextBlock

[0001596532-18-000018:notes:1]
We work closely with third-party contract manufacturing suppliers to manufacture our products. As of December 31, 2017 and 2016, we had three suppliers, who provided substantially all of our electronic manufacturing services. Our contract manufacturing suppliers deliver our products to our third party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers. Our products rely on key components, including certain integrated circuit components and power supplies, some of which our contract manufacturers purchase on our behalf from a limited number of suppliers, including certain sole source providers. We generally do not have guaranteed supply contracts with our component suppliers, and our suppliers could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, or if we are unable to obtain alternative sources for these components, sales of our products could be delayed or halted entirely or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.


## anet:ScheduleofLeaseFinancingObligationsTableTextBlock

[0001596532-18-000018:notes:2]
As of December 31, 2017, the future minimum payments due under the lease financing obligation were as follows (in thousands):

[0001596532-18-000018:notes:3]
| Years Ending December 31, |  |  |
| 2018 |  | $ | 6,113 |  |
| 2019 |  | 6,293 |  |
| 2020 |  | 6,477 |  |
| 2021 |  | 6,674 |  |
| 2022 |  | 6,871 |  |
| Thereafter |  | 5,264 |  |
| Total payments |  | 37,692 |  |
| Less: interest and land lease expense |  | (21,730 | ) |
| Total payments under facility financing obligations |  | 15,962 |  |
| Property reverting to landlord |  | 23,630 |  |
| Present value of obligation |  | 39,592 |  |
| Less: current portion |  | (1,919 | ) |
| Lease financing obligations, non-current |  | $ | 37,673 |  |


## anet:ScheduleofSharebasedCompensationSharesAvailableForGrantActivityTableTextBlock

[0001596532-18-000018:notes:4]
The following table presents the stock activity and the total number of shares available for grant as of December 31, 2017 (in thousands):

[0001596532-18-000018:notes:5]
|  |  | Number of Shares |
| Balance—December 31, 2016 |  | 11,754 |  |
| Authorized |  | 2,124 |  |
| Options granted |  | (170 | ) |
| RSUs granted |  | (712 | ) |
| Options canceled, expired or repurchased |  | 399 |  |
| RSUs forfeited |  | 94 |  |
| Shares traded for taxes |  | 23 |  |
| Balance—December 31, 2017 |  | 13,512 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001596532-18-000018:notes:6]
The fair values of available-for-sale investments, by remaining contractual maturity, are as follows (in thousands):

[0001596532-18-000018:notes:7]
|  |  | December 31, 2017 |
| Due in 1 year or less |  | $ | 386,506 |  |
| Due in 1 year through 2 years |  | 289,857 |  |
| Total marketable securities |  | $ | 676,363 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001596532-18-000018:notes:8]
The accompanying consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and are prepared in accordance with U.S. generally accepted accounting principles (GAAP). All significant intercompany accounts and transactions have been eliminated.

[0001596532-18-000018:notes:9]
Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001596532-18-000018:notes:10]
We consider all highly liquid investments with maturities of three months or less at the time of purchase to be cash equivalents. Cash and cash equivalents consist of cash on deposit with various financial institutions and highly liquid investments in money market funds. Interest is accrued as earned. As of December 31, 2017, we had restricted cash of $5.5 million that primarily included $4.0 million pledged as collateral representing a security deposit required for a facility lease and $1.1 million related to a letter of credit issued to a business partner. As of December 31, 2016, we had restricted cash of $4.2 million primarily for the security deposit for a facility lease. Our restricted cash is classified as other assets in our consolidated balance sheets.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-18-000018:notes:11]
5.    Commitments and Contingencies

[0001596532-18-000018:notes:12]
Operating Leases

[0001596532-18-000018:notes:13]
We lease various operating spaces in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2025. These arrangements require us to pay certain operating expenses, such as taxes, repairs, and insurance and contain renewal and escalation clauses. We recognize rent expense under these arrangements on a straight-line basis over the term of the lease.

[0001596532-18-000018:notes:14]
As of December 31, 2017, the aggregate future minimum payments under non-cancelable operating leases consist of the following (in thousands):

[0001596532-18-000018:notes:15]
| Years Ending December 31, |  |  |
| 2018 |  | $ | 9,127 |  |
| 2019 |  | 8,336 |  |
| 2020 |  | 8,350 |  |
| 2021 |  | 7,741 |  |
| 2022 |  | 7,577 |  |
| Thereafter |  | 9,873 |  |
| Total minimum future lease payments |  | $ | 51,004 |  |

[0001596532-18-000018:notes:16]
Rent expense for all operating leases amounted to $9.4 million, $8.1 million and $5.4 million for the years ended December 31, 2017, 2016 and 2015, respectively.

[0001596532-18-000018:notes:17]
Financing Obligation—Build-to-Suit Lease

[0001596532-18-000018:notes:18]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013.  Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction, we were deemed the owner of the building (for accounting purposes only) during the construction period. Upon completion of construction in 2013, we concluded that we had forms of continued economic involvement in the facility, and therefore did not meet with the provisions for sale-leaseback accounting. We continue to maintain involvement in the property post construction and lack transferability of the risks and rewards of ownership, due to our required maintenance of a $4.0 million letter of credit, in addition to our ability and option to sublease our portion of the leased building for fees substantially higher than our base rate.  Therefore, the lease is accounted for as a financing obligation and lease payments will be attributed to (1) a reduction of the principal financing obligation; (2) imputed interest expense; and (3) land lease expense, representing an imputed cost to lease the underlying land of the building.  At the conclusion of the initial lease term, we will de-recognize both the net book values of the asset and the remaining financing obligation.

[0001596532-18-000018:notes:19]
As of December 31, 2017 and 2016, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $39.6 million and $41.2 million, respectively. As of December 31, 2017, $1.9 million and $37.7 million were recorded as short-term and long-term financing obligations, respectively.

[0001596532-18-000018:notes:20]
Land lease expense under our lease financing obligation amounted to $1.3 million for each of the years ended December 31, 2017, 2016 and 2015 respectively.

[0001596532-18-000018:notes:21]
Purchase Commitments

[0001596532-18-000018:notes:22]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished product and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of December 31, 2017, we had non-cancellable purchase commitments of $195.1 million, of which $147.9 million was to our contract manufacturers and suppliers.  In addition, we have provided deposits to secure our obligations to purchase inventory. We had $36.9 million and $63.1 million in deposits as of December 31, 2017 and 2016, respectively. These deposits are classified in 'Prepaid expenses and other current assets' and 'Other assets' in our accompanying consolidated balance sheets.

[0001596532-18-000018:notes:23]
Guarantees

[0001596532-18-000018:notes:24]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-18-000018:notes:25]
Legal Proceedings

[0001596532-18-000018:notes:26]
OptumSoft, Inc. Matters

[0001596532-18-000018:notes:27]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies; and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-18-000018:notes:28]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft access to our software for evaluation by OptumSoft; (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches; (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers; (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us; and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors, who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dated July 28, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.

[0001596532-18-000018:notes:29]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we assert our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we assert that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We ask the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also assert that, even if we are found not to own certain components, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation. On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have meritorious defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-18-000018:notes:30]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On December 16, 2015, the Court issued a Proposed Statement of Decision Following Phase 1 Trial, and on January 8, 2016, OptumSoft filed objections to that Proposed Statement of Decision. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II including the application of the Court’s interpretation of the 2004 agreement as set forth in the Final Statement of Decision Following Phase I Trial to any other source code that OptumSoft claims to own following a review. Phase II was previously scheduled to be tried in April 2016; however, that trial date has been vacated and a new trial date has not yet been set.

[0001596532-18-000018:notes:31]
We intend to vigorously defend against any claims brought against us by OptumSoft.  However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor.  For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft.  If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license.  An adverse litigation ruling could result in a significant damages award against us and injunctive relief. In addition, OptumSoft could assert additional or different claims against us, including claims that our license from OptumSoft is invalid.

[0001596532-18-000018:notes:32]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated.  However, the outcome of litigation is inherently uncertain. Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-18-000018:notes:33]
Cisco Systems, Inc. (“Cisco”) Matters

[0001596532-18-000018:notes:34]
We are currently involved in several litigation matters with Cisco Systems, Inc. These matters are summarized below.

[0001596532-18-000018:notes:35]
Cisco Systems, Inc. v. Arista Networks, Inc. (Case No. 4:14-cv-05343) (“’43 Case”)

[0001596532-18-000018:notes:36]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the 875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”). Cisco seeks, as relief for our alleged infringement in the ’43 Case, lost profits and/or reasonable royalty damages in an unspecified amount, including treble damages, attorney’s fees, and associated costs. Cisco also seeks injunctive relief in the ’43 Case. On February 10, 2015, the Court granted our unopposed motion to stay the ’43 Case until the proceedings before the United States International Trade Commission (“USITC”) pertaining to the same patents (as discussed below) became final. Trial has not been scheduled in the ’43 Case.

[0001596532-18-000018:notes:37]
Cisco Systems, Inc. v. Arista Networks, Inc. (Case No. 5:14-cv-05344) (“’44 Case”)

[0001596532-18-000018:notes:38]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI” and U.S. Patent Nos. 7,047,526 and 7,953,886 (respectively, “the ’526 patent” and “the ’886 patent”). As relief for our alleged patent infringement in the ’44 Case, Cisco seeks lost profits and/or reasonable royalty damages in an unspecified amount including treble damages, attorney’s fees, and associated costs as well as injunctive relief. As relief for our alleged copyright infringement, Cisco seeks monetary damages for alleged lost profits, profits from our alleged infringement, statutory damages, attorney’s fees, and associated costs.

[0001596532-18-000018:notes:39]
As described below, on May 25, 2016, our petition for Inter Partes Review (“IPR”) of the ’886 patent was instituted by the United States Patent Trial and Appeal Board (“PTAB”). Cisco subsequently agreed to dismiss its claims as to the ‘886 patent with prejudice.

[0001596532-18-000018:notes:40]
On December 14, 2016, following a two-week trial, the jury found that we had proven our copyright defense of scenes a faire and that Cisco had failed to prove infringement of the ’526 patent, and on that basis, judgment was entered in our favor on all claims on December 19, 2016.

[0001596532-18-000018:notes:41]
On January 17, 2017, Cisco filed a motion for judgment as a matter of law, challenging the sufficiency of the evidence in support of our scenes a faire defense. Cisco did not file any post-trial motion regarding the ’526 patent, nor did it file a motion for a new trial. We also filed a conditional motion for judgment as a matter of law and/or for a new trial on several grounds, which would be at issue only if the court granted Cisco’s motion. The hearing on both parties’ motions was held on April 27, 2017. On May 10, 2017, the court denied Cisco’s motion and denied our motions as moot.

[0001596532-18-000018:notes:42]
Cisco filed a notice of appeal on June 6, 2017, and the parties have submitted their appeal briefs to the U.S. Court of Appeals of the Federal Circuit. A hearing date has not yet been set.

[0001596532-18-000018:notes:43]
Arista Networks, Inc. v. Cisco Systems, Inc. (Case No. 5:16-cv-00923) (“’23 Case”)

[0001596532-18-000018:notes:44]
On February 24, 2016, we filed a complaint against Cisco in the District Court for the Northern District of California alleging antitrust violations and unfair competition. On August 23, 2016, the Court granted Cisco’s motion to stay the ’23 Case until judgment was entered on Cisco’s copyright claims in the ’44 Case. On March 2, 2017, the Court lifted the stay and trial is set for August 3, 2018.

[0001596532-18-000018:notes:45]
On March 23, 2017, Cisco filed a motion to dismiss our complaint in the ’23 Case. On October 10, 2017, the Court issued an order granting in part and denying in part Cisco’s motion to dismiss, with leave for us to amend to cure any deficiencies as to the claims that were dismissed.

[0001596532-18-000018:notes:46]
Certain Network Devices, Related Software, and Components Thereof (Inv. No. 337-TA-944) (“944 Investigation”)

[0001596532-18-000018:notes:47]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated 19 U.S.C. § 1337 (“Section 337”). The USITC instituted Cisco’s complaint as Investigation No. 337-TA-944. Cisco initially alleged that certain of our switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents. Cisco subsequently dropped the ’296 patent from the 944 Investigation. Cisco sought, among other things, a limited exclusion order barring entry into the United States of accused switch products (including our 7000 Series of switches) and components and software therein and a cease and desist order against us restricting our activities with respect to our imported accused switch products and components and software therein.

[0001596532-18-000018:notes:48]
On February 2, 2016, the Administrative Law Judge (“ALJ”) issued his initial determination finding a violation of Section 337. More specifically, the ALJ found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringed asserted claims 1, 2, 8-11, and 17-19 of the ’537 patent; asserted claims 6, 7, 20, and 21 of the ’592 patent; and asserted claims 5, 7, 45, and 46 of the ’145 patent. The ALJ did not find a violation of Section 337 with respect to any asserted claims of the ’597 and ’164 patents. On June 23, 2016, the Commission issued its Final Determination, which found a violation with respect to the ’537, ’592, and ’145 patents, and found no violation with respect to the ’597 and ’164 patents. The Commission also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software and components thereof that infringe one or more of claims 1, 2, 8-11, and 17-19 of the ’537 patent; claims 6, 7, 20, and 21 of the ’592 patent; and claims 5, 7, 45, and 46 of the ’145 patent. On August 22, 2016, the Presidential review period for the 944 Investigation expired. The USITC orders will be in effect until the expiration of the ’537, ’592, and ’145 patents.

[0001596532-18-000018:notes:49]
Both we and Cisco filed petitions for review of the USITC’s Final Determination to the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”). The appeal was fully briefed and oral argument was held on June 6, 2017. On September 27, 2017, the Federal Circuit affirmed the USITC’s Final Determination.

[0001596532-18-000018:notes:50]
On August 26, 2016, Cisco filed an enforcement complaint under Section 337 with the USITC. Cisco alleges that we are violating the cease and desist and limited exclusion orders issued in the 944 Investigation by engaging in the “marketing, distribution, offering for sale, selling, advertising, and/or aiding or abetting other entities in the sale and/or distribution of products that Cisco alleges continue to infringe claims 1-2, 8-11, and 17-19 of the ’537 patent,” despite the design changes we have made to those products. Cisco asks the USITC to (1) enforce the cease and desist order; (2) modify the Commission’s limited exclusion order and/or cease and desist order “in any manner that would assist in the prevention of the unfair practices that were originally the basis for issuing such Order or assist in the detection of violations of such Order”; (3) impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000 or twice the domestic value of the articles entered or sold, whichever is higher”; (4) bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order”; and (5) impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.” On September 28, 2016, the Commission instituted the enforcement proceeding. The proceeding has been assigned to ALJ Shaw, who presided over the underlying investigation. The target date for the investigation was initially set for September 20, 2017. On June 20, 2017, the ALJ issued his initial determination finding that we did not violate the June 23, 2016 cease and desist order. The initial determination also recommended a civil penalty of $307 million if the Commission decided to overturn the finding of no violation. On July 3, 2017, the parties filed petitions for review of certain findings in the initial determination.

[0001596532-18-000018:notes:51]
On August 4, 2017, the Commission issued an order remanding the investigation to the ALJ to make additional findings on certain issues and issue a remand initial determination. The Commission ordered the ALJ to set a schedule for completion of any necessary remand proceedings and a new target date for the enforcement action. On August 25, 2017 the ALJ issued an Initial Determination setting a June 4, 2018 deadline for the remand initial determination and September 4, 2018 as the new target date for the enforcement action. On September 18, 2017, the Commission determined not to review the Initial Determination setting the target date.  The ALJ held a hearing on February 1, 2018.

[0001596532-18-000018:notes:52]
Certain Network Devices, Related Software, and Components Thereof (Inv. No. 337-TA-945) (“945 Investigation”)

[0001596532-18-000018:notes:53]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated Section 337. The USITC instituted Cisco’s complaint as Investigation No. 337-TA-945. Cisco alleged that certain of our switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents. Cisco sought, among other things, a limited exclusion order barring entry into the United States of accused switch products (including our 7000 Series of switches) related software, and components therein and a cease and desist order against us restricting our activities with respect to our imported accused switch products and components and software therein.

[0001596532-18-000018:notes:54]
On December 9, 2016, the ALJ issued her initial determination finding a violation of Section 337. More specifically, the ALJ found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringe asserted claims 1, 7, 9, 10, and 15 of the ’577 patent and asserted claims 1, 2, 4, 5, 7, 8, 10, 13, 19, 56, and 64 of the ’668 patent. The ALJ did not find a violation of Section 337 with respect to asserted claim 2 of the ’577 patent or any asserted claims of the ’853, ’492, ’875, and ’211 patents.

[0001596532-18-000018:notes:55]
On May 4, 2017, the Commission issued its Final Determination, which found a violation with respect to the ’577 and ’668 patents, and found no violation with respect to the ’211, ’853, ’875 and ’492 patents. The Commission also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software and components thereof that infringe one or more of claims 1, 7, 9, 10, and 15 of the ’577 patent and 1, 2, 4, 5, 7, 8, 10, 13, 18, 56, and 64 of the ’668 patent. On July 4, 2017, the 60-day Presidential review period for the 945 Investigation expired. During the 60-day Presidential review period, the USITC Orders permitted Arista to continue importing and selling products covered by the orders so long as we paid a 5% bond. Because the United States Trade Representative did not disapprove the USITC’s final determination, the limited exclusion order and cease and desist order are now in full effect.

[0001596532-18-000018:notes:56]
On May 25, 2017 and June 1, 2017, the PTAB issued final written decisions finding all claims of the ’577 and ’668 patents that we were found to have infringed in the 945 Investigation unpatentable. On June 1, 2017 and June 2, 2017, we filed emergency petitions to suspend the remedial orders in the 945 Investigation. On July 20, 2017, the Commission issued a notice denying our petition to suspend the remedial orders. On July 21, 2017, we filed a motion to stay the remedial orders in the 945 Investigation pending disposition of the relevant appeals and sought expedited consideration of our motion. On September 11, 2017, the Commission denied our motion to stay.

[0001596532-18-000018:notes:57]
On June 30, 2017, Cisco filed a petition for review of the USITC’s Final Determination to the Federal Circuit regarding the ’853, ’492, ’875 and ’211 patents. On July 21, 2017, we filed a petition for review of the Final Determination to the Federal Circuit.

[0001596532-18-000018:notes:58]
On August 25, 2017 we filed a motion with the Federal Circuit requesting that the Federal Circuit stay the remedial orders pending the completion of the appeal of the 945 Investigation. On September 22, 2017, the Federal Circuit issued an order denying our motion to stay, but ordered that our redesigned products be allowed to enter the country “unless and until Commission proceedings are initiated and completed to produce an enforceable determination that such a redesign is barred” by a Commission remedial order.

[0001596532-18-000018:notes:59]
On September 27, 2017, Cisco filed a petition with the USITC requesting that the Commission institute a modification proceeding to determine whether our redesigned products infringe the patent claims underlying the remedial orders in the 945 Investigation. On October 27, 2017, the Commission instituted the modification proceeding. The proceeding has been assigned to ALJ McNamara, who presided over the underlying investigation. The Commission has set a deadline of five months for the ALJ to issue a recommended determination on what, if any, modifications to the remedial orders issued in the 945 Investigation are appropriate. This deadline may be extended by one month upon a showing of good cause. The recommended determination will be subject to review by the Commission after which the Commission will issue a final determination. The Commission has not set a target date for the final determination. The hearing was held on January 26, 2018.

[0001596532-18-000018:notes:60]
Inter Partes Reviews

[0001596532-18-000018:notes:61]
We have filed petitions for Inter Partes Review of the ’597, ’211, ’668, ’853, ’537, ’577, ’886, and ’526 patents. IPRs relating to the ’597 (IPR No. 2015-00978) and ’211 (IPR No. 2015-00975) patents were instituted in October 2015 and hearings on these IPRs were completed in July 2016. On September 28, 2016, the PTAB issued a final written decision finding claims 1, 14, 39-42, 71, 72, 84, and 85 of the ’597 patent unpatentable. The PTAB also found that claims 29, 63, 64, 73, and 86 of the ’597 patent had not been shown to be unpatentable. On October 5, 2016, the PTAB issued a final written decision finding claims 1 and 12 of the ’211 patent unpatentable. The PTAB also found that claims 2, 6-9, 13, 17-20 of the ’211 patent had not been shown to be unpatentable. Both parties have appealed the final written decisions on the ’211 and ’537 patent IPRs.  The hearing for the ’211 IPR appeal is set for March 2018.

[0001596532-18-000018:notes:62]
The IPR relating to the ’886 patent was instituted on May 25, 2016. Following that decision, Cisco agreed to dismiss its claims as to the ʼ886 patent with prejudice, and we dismissed our counterclaims as to the ʼ886 patent without prejudice.

[0001596532-18-000018:notes:63]
IPRs relating to the ’668 (IPR No. 2016-00309), ’577 (IPR No. 2016-00303), ’853 (IPR No. 2016-0306), and ’537 (IPR No. 2016-0308) patents were instituted in June 2016 and hearings were held on March 7, 2017. On May 25, 2017, the PTAB issued final written decisions finding claims 1, 7-10, 12-16, 18-22, 25, and 28-31 of ’577 patent unpatentable, and that claim 2 of the ’577 patent, claim 63 of the ’853 patent, and claims 1, 10, 19, and 21 of the ’537 patent had not been shown to be unpatentable. On June 1, 2017, the PTAB issued a final written decision finding claims 1-10, 12-13, 15-28, 30-31, 33-36, 55-64, 66-67, and 69-72 of the ’668 patent unpatentable. We filed a Notice of Appeal concerning the ’577 patent on July 21, 2017, and Notices of Appeal concerning the ‘853 and ’537 patents on July 26, 2017. Cisco cross-appealed concerning the ’577 patent on July 26, 2017 and filed a Notice of Appeal concerning the ’668 patent on August 1, 2017. For the appeals of the IPRs on the ’668 and ’577 patents, the Federal Circuit granted our motion for an expedited briefing schedule, and the hearings were held on February 9, 2018. On February 14, 2018, the Federal Circuit affirmed the PTAB’s final written decision on the ’668 patent.

[0001596532-18-000018:notes:64]
* * * * *

[0001596532-18-000018:notes:65]
We intend to vigorously defend against each of the Cisco lawsuits, as summarized in the preceding paragraphs. However, we cannot be certain that any claims by Cisco will be resolved in our favor regardless of the merit of the claims. Any adverse litigation ruling could result in injunctive relief and USITC remedial orders, including the above described injunctive relief, could lead to significant penalties assessed or damages awarded against us or a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products.

[0001596532-18-000018:notes:66]
For example, in the 944 Investigation, the USITC issued a limited exclusion order barring entry into the United States of our network devices (including our 7000 Series of switches), related software, and components thereof that infringe one or more of the claims of the ’537, ʼ592, and ʼ145 patents specified above and a cease and desist order restricting our activities with respect to such imported products. In the 945 Investigation, the USITC issued a limited exclusion order barring entry into the United States of our network devices, related software, and components thereof that infringe one or more of the claims of the ’577 and ’668 patents specified above and a cease and desist order restricting our activities with respect to such imported products.

[0001596532-18-000018:notes:67]
To comply with these orders, we have sought to develop technical redesigns that no longer infringe the patents that are the subject of the orders. In any efforts to develop these technical redesigns for our products, we may be unable to do so in a manner that does not continue to infringe the patents or that is acceptable to our customers. Our redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management. Moreover, our ability to import redesigned products into the United States is based on rulings from U.S. Customs and Border Protection (“CBP”) and the Federal Circuit. While these favorable rulings currently allow us to import our redesigned products into the United States, the USITC could determine in an enforcement action or modification proceeding that our redesigned products continue to infringe the patents that are the subject of any USITC orders. In addition, the Federal Circuit or CBP could decide to withdraw or alter their rulings based on a change in circumstances. Any failure to effectively redesign our products, obtain customer acceptance of those redesigned products, retain authorization to import those redesigned products, or address the USITC findings in a manner that complies with the USITC orders, may cause a disruption to our product shipments, a rejection or return of our redesigned products by (or a delay or loss of sales to) customers, subject us to penalties or damage awards, and materially and adversely affect our business, revenues, prospects, reputation, results of operations, and financial condition.

[0001596532-18-000018:notes:68]
Specifically, in response to the USITC’s findings in the 944 Investigation, we have made design changes to our products for sale in the United States to address the features that were found to infringe the ’537, ’592, and ’145 patents. Following the issuance of the final determination in the 944 Investigation, we submitted a Section 177 ruling request to CBP seeking approval to import these redesigned products into the United States. On November 18, 2016, we received a 177 ruling from CBP finding that our redesigned products did not infringe the relevant claims of the ʼ537, ’592, and ʼ145 patents, and approving the importation of those redesigned products into the United States. On January 13, 2017, at the request of Cisco and without our input, CBP issued a letter to us revoking its prior November 18 ruling. CBP subsequently conducted an inter partes proceeding between Arista and Cisco to determine whether our redesigned products infringe and whether to approve them for importation into the United States. On April 7, 2017, following the inter partes proceeding, CBP again ruled that our redesigned products do not infringe the relevant claims of the ’537, ’592, and ’145 patents and again approved those redesigns for importation into the United States. On September 12, 2017, Cisco filed a second request with CBP seeking to revoke our approval to import our redesigns relating to the 944 Investigation. We have opposed Cisco’s request, and CBP has not yet ruled on Cisco’s request.

[0001596532-18-000018:notes:69]
Similarly, on May 4, 2017, the USITC issued a limited exclusion order and cease and desist order in the 945 Investigation with respect to the ’668 and ’577 patents. We have made design changes to our products for sale in the United States to address the features that were found to infringe the ’577 and ’668 patents. We are making ongoing modifications to our products to also ensure that they continue to meet customer requirements, and we are working with our customers to qualify those modified products for use in our customers’ networks. In particular, the ’577 patent was directed to a feature that is implemented in the merchant silicon chips that we purchase from third-party suppliers. Because we do not design, build or manufacture these merchant silicon chips, we are limited in further modifications that we can make to our products for this patent. Our redesign efforts therefore consisted of removing the feature found to infringe the ’577 patent in all of our products until this patent expires on June 30, 2018, and providing an alternative feature to address the ‘577 patent for a subset of those products. The redesign and qualification efforts to address the 945 Investigation findings could be extremely costly and time consuming for us and our customers as well as disruptive to our other development activities and distracting to management. We may not be able to complete, and our customers may not be able to qualify these redesigned products in a timely fashion, if at all. For example, some of our customers continue to test and qualify our redesigned products which address the ’577 and ’668 patents to ensure that they meet their network requirements. This could result in a delay or cancellation of purchases by some customers until the redesigned products are qualified or accepted by such customers, a rejection or return of our redesigned products by some customers or a loss of sales to some customers who are unable to qualify or accept the redesigned products, any of which could materially and adversely affect our business, revenues, deferred revenue balances, prospects, reputation, results of operations or financial condition.

[0001596532-18-000018:notes:70]
Because the USITC did not suspend its orders in the 945 Investigation, despite a PTAB finding that every relevant claim of the ’668 and ’577 patents is unpatentable, we were barred from importing our redesigned products into the United States until we received approval from CBP. On July 21, 2017, we submitted a Part 177 request to CBP seeking approval to import our redesigned products into the United States. Following the Federal Circuit’s order on September 22, 2017, allowing us to import our redesigned products, we withdrew our request. On October 12, 2017, CBP, over Cisco’s objection, terminated the Part 177 proceedings, and confirmed that it will permit entry of our redesigns pursuant to the Federal Circuit’s September 22, 2017 order.

[0001596532-18-000018:notes:71]
In either the 944 enforcement action or the 945 modification proceeding, if the USITC determines that our redesigned products infringe any of the patents that are the subject of USITC remedial orders, those redesigned products will also be barred from import into the United States, or sale after importation. In addition, the USITC may impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000 or twice the domestic value of the articles entered or sold, whichever is higher,” bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order,” or impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.” In the 944 enforcement action, the ALJ recommended a civil penalty of $307 million if the Commission were to reverse the ALJ’s finding of no violation. Any such finding by the USITC in either the 944 enforcement action or the 945 modification proceeding could materially and adversely affect our business, prospects, reputation, results of operations and financial condition.

[0001596532-18-000018:notes:72]
An adverse finding in the 944 enforcement action or the 945 modification proceeding would take effect immediately upon USITC’s issuance of the final determination, without any Presidential review period. To address such a finding, we would have to further redesign our products to make them non-infringing, and until we made such changes we would not be able to import or ship our products to customers. Our further redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management.  We may not be able to further redesign the products in a manner that does not continue to infringe the patents or that is acceptable to customers. We may not be able to complete, and our customers may not be able to qualify, such further redesigned products in a timely fashion, if at all, following the issuance of an adverse final determination, leading to a delay or cancellation of purchases by some customers until those redesigned products are qualified or accepted by such customers, a rejection or return of our redesigned products by some customers or a loss of sales to some customers who are unable to qualify or accept the redesigned products. Our redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management.

[0001596532-18-000018:notes:73]
For example, in the 944 enforcement action, although the ALJ issued an initial determination finding that our redesigned products did not violate the June 23, 2016 cease and desist order, if the ALJ modifies the initial determination during the remand proceeding, or if the Commission finds a violation in its final determination on September 4, 2018, we will no longer be able to import or ship our products in the U.S. until we make further changes to address those findings, which could materially and adversely affect our business, revenues, prospects, reputation, results of operations or financial condition. We would also need to obtain USITC or CBP approval to resume importation of such redesigned products into the United States. In addition, the USITC would not provide a service and support exception for our previously redesigned products, and customers may be required to upgrade to new products to obtain service and support. If we are unable to obtain such approvals or provide such service and support exception, our business, prospects, reputation, results of operations or financial condition could be materially and adversely affected. In addition, if we are found to have violated the USITC’s orders while those orders remain in effect, we may be subject to the penalties described above.

[0001596532-18-000018:notes:74]
In the 945 modification proceeding, while the USITC orders are based upon patent claims that the PTAB has found to be invalid, these orders will remain in effect unless and until the PTAB decisions are affirmed on appeal and the United States Patent and Trademark Office ("PTO") cancels the patents or the patents expire. If the Commission finds a violation in its final determination for the 945 modification proceeding, we will no longer be able to import or ship our products in the U.S. until we make further changes to address those findings and/or until the PTAB decisions are so affirmed and the PTO cancels the patents or the patents expire, which could materially and adversely affect our business, revenues, prospects, reputation, results of operations or financial condition. We would also need to obtain USITC or CBP approval to resume importation of any such redesigned products into the United States. In addition, the USITC would not provide a service and support exception for our previously redesigned products, and customers may be required to upgrade to new products to obtain service and support. If we are unable to obtain such approvals or provide such service and support exception, our business, revenues, prospects, reputation, results of operations or financial condition could be materially and adversely affected. In light of the Federal Circuit’s February 14, 2018 ruling affirming the PTAB’s invalidity findings on the ’668 patent, we plan to seek a stay of the ITC’s remedial orders as they relate to the ’668 patent. If our motion is denied, we would continue to be subject to the ITC’s remedial orders on the ’668 patent until all appeals have been fully resolved in our favor and the claims cancelled by the PTO. We may not prevail on this appeal in a timely manner, if at all.  In addition, even if the PTAB decisions are ultimately affirmed on appeal and the patent claims are canceled, if we are found to have violated the USITC’s orders while those orders remain in effect, we may be subject to the penalties described above.

[0001596532-18-000018:notes:75]
To comply with the USITC’s remedial orders, we have also made certain changes to our manufacturing, importation and shipping workflows. These changes have included shifting manufacturing and integration of our products to be sold in the United States to U.S. facilities. Such changes may be extremely costly, time consuming, and we may not be able to implement such changes successfully. Any failure to successfully change our manufacturing and importation processes or shipping workflows in a manner that is compliant with the limited exclusion orders and cease and desist orders may cause a disruption in our product shipments and materially and adversely affect our business, prospects, reputation, results of operations, and financial condition.

[0001596532-18-000018:notes:76]
In connection with these changes, to the extent that we are required to make further modifications to our supply chain to obtain alternative U.S. sources for subcomponents, we may be unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, if at all, which could delay or halt entirely production of our products or require us to make further modifications to our products to incorporate new components that are available in the United States. Any of these events could result in lost sales, reduced gross margins or damage to our end-customer relationships, which would materially and adversely impact our business, financial condition, results of operations and prospects.

[0001596532-18-000018:notes:77]
Additionally, the existence of Ciscoʼs lawsuits against us could cause concern among our customers and partners and could adversely affect our business and results of operations. Many of our customers and partners require us to indemnify and defend them against third party infringement claims and pay damages in the case of adverse rulings. These claims could harm our relationships with our customers or channel partners, cause them to delay or defer purchasing decisions or deter them from doing business with us. From time to time, we may also be required to provide additional assurances beyond our standard terms. Whether or not we prevail in the lawsuit, we expect that the litigation will be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-18-000018:notes:78]
With respect to the various legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated.  However, the outcome of litigation is inherently uncertain. Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-18-000018:notes:79]
In the Matter of Certain Semiconductor Devices, Semiconductor Device Packages, and Products Containing Same (U.S. International Trade Commission Investigation No. 337-TA-1010) (the “1010 Investigation”)

[0001596532-18-000018:notes:80]
On May 23, 2016, Tessera Technologies, Inc., Tessera, Inc., and Invensas Corp. (“Tessera”) filed a complaint in the USITC alleging that Broadcom Limited, Broadcom Corporation, Avago Technologies Limited, and Avago Technologies U.S. Inc. (“Broadcom”) and certain of Broadcom's customers violated 19 U.S.C. § 1337 (“Section 337”). On June 20, 2016, the USITC instituted Tessera’s complaint as Investigation No. 337-TA-1010.

[0001596532-18-000018:notes:81]
Tessera alleged that certain Broadcom semiconductor devices infringe U.S. Patent Nos. 6,856,007; 6,849,946; and 6,133,136. Tessera further alleges that Broadcom’s downstream customers, Arista Networks, Inc.; ARRIS International plc; ARRIS Group, Inc.; ARRIS Technology, Inc.; ARRIS Enterprises LLC; ARRIS Solutions, Inc.; Pace Ltd.; Pace Americas, LLC; Pace USA; LLC, ASUSteK Computer Inc.; ASUS Computer International; Comcast Cable Communications, LLC; Comcast Cable Communications Management, LLC; Comcast Business Communications, LLC; HTC Corporation; HTC America, Inc.; NETGEAR, Inc.; Technicolor S.A.; Technicolor USA, Inc.; and Technicolor Connected Home USA LLC (“Downstream Respondents”) are violating Section 337 by importing, selling after importation, or selling for importation products that incorporate the accused Broadcom semiconductor devices. The accused products included certain models of our switching products.

[0001596532-18-000018:notes:82]
Tessera sought the following relief: (1) a permanent limited exclusion order excluding from importation into the U.S. all of Broadcom’s semiconductor devices and semiconductor device packages, as well as Downstream Respondents’ products containing Broadcom’s semiconductor devices that infringe one or more of the three patents-in-suit and (2) a permanent cease and desist order prohibiting Broadcom and the Downstream Respondents and related companies from importing, marketing, advertising, demonstrating, warehousing inventory for distribution, offering for sale, selling, qualifying for use in the products of others, distributing, or using the accused Broadcom semiconductor devices and Downstream Respondents’ products containing Respondents’ semiconductor devices and semiconductor device packages that infringe one or more of the three patents subject to the USITC Investigation.

[0001596532-18-000018:notes:83]
Tessera, Broadcom and the Downstream Respondents settled the 1010 Investigation on December 18, 2017 and all claims have been dismissed.

[0001596532-18-000018:notes:84]
Other Matters

[0001596532-18-000018:notes:85]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of December 31, 2017, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001596532-18-000018:notes:86]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. In assessing loss contingencies, we use significant judgment and assumptions to estimate the likelihood of loss, impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. We record a provision for contingent losses when it is both probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. We will record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements and (ii) the range of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001596532-18-000018:notes:87]
Comprehensive income is comprised of net income and other comprehensive income (loss). Unrealized gains and losses on available-for-sale investments and foreign currency translation adjustments are included in our other comprehensive income or loss.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-18-000018:notes:88]
6.    Equity Award Plan Activities

[0001596532-18-000018:notes:89]
2014 Equity Incentive Plan

[0001596532-18-000018:notes:90]
In April 2014, the board of directors and stockholders approved the 2014 Equity Incentive Plan (the “2014 Plan”), effective on the first day that our common stock was publicly traded. Our board of directors has terminated the 2004 and 2011 equity plans as to future grants.  However, these plans will continue to govern the terms and conditions of the outstanding options previously granted thereunder.

[0001596532-18-000018:notes:91]
Awards granted under the 2014 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Awards (“RSAs”), Stock Appreciation Rights (“SARs”) or Restricted Stock Units (“RSUs”).  The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of the outstanding shares of our common stock on the immediately preceding December 31, but not to exceed 12,500,000 shares, unless the board of directors, in its discretion, determines to make a smaller increase. As of December 31, 2017, there remained approximately 22.1 million shares available for issuance under the 2014 Plan.

[0001596532-18-000018:notes:92]
On February 12, 2018, our board of directors authorized an increase to the shares available for issuance under the 2014 Plan of 3% of the total shares of common stock outstanding on December 31, 2017 effective January 1, 2018.  The increase amounted to 2,211,176 shares.

[0001596532-18-000018:notes:93]
2014 Employee Stock Purchase Plan

[0001596532-18-000018:notes:94]
In April 2014, the board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded.  The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding immediately preceding December 31, but not to exceed 2,500,000 shares, unless the board of directors, in its discretion, determines to make a smaller increase.

[0001596532-18-000018:notes:95]
Under our 2014 ESPP eligible employees are permitted to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the exercise date. Each offering period will be approximately two years starting on the first trading date after February 15 and August 15 of each year. Participants may purchase shares of common stock through payroll deductions up to 10% of their eligible compensation, subject to Internal Revenue Service mandated purchase limits. As of December 31, 2017, there remained 1,987,039 shares available for issuance under the ESPP.

[0001596532-18-000018:notes:96]
On February 12, 2018, our board of directors authorized an increase to shares available for issuance under the ESPP of 1% of the total shares outstanding on December 31, 2017 effective January 1, 2018.  The increase amounted to 737,058 shares.

[0001596532-18-000018:notes:97]
Stock Option Activities

[0001596532-18-000018:notes:98]
The following table summarizes the option activity under our stock plans and related information (in thousands, except years and per share amounts):

[0001596532-18-000018:notes:99]
|  |  | Options Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding |
| Balance—December 31, 2016 |  | 9,509 |  |  | $ | 28.79 |  |  | 6.9 |  | $ | 646,394 |  |
| Options granted |  | 170 |  |  | 96.60 |  |  |  |  |  |
| Options exercised |  | (2,260 | ) |  | 19.73 |  |  |  |  |  |
| Options canceled or expired |  | (395 | ) |  | 34.04 |  |  |  |  |  |
| Balance—December 31, 2017 |  | 7,024 |  |  | $ | 33.05 |  |  | 6.1 |  | $ | 1,422,637 |  |
| Vested and exercisable—December 31, 2017 |  | 2,992 |  |  | $ | 20.70 |  |  | 5.4 |  | $ | 643,012 |  |
| Vested and expected to vest—December 31, 2017 |  | 7,024 |  |  | $ | 33.05 |  |  | 6.1 |  | $ | 1,422,637 |  |

[0001596532-18-000018:notes:100]
The weighted-average grant-date fair value of options granted during the year ended December 31, 2017, 2016 and 2015 was $40.17, $23.66 and $29.20 per share, respectively. The aggregate intrinsic value of options exercised during the year ended December 31, 2017, 2016 and 2015 was $307.7 million, $147.6 million and $152.4 million.

[0001596532-18-000018:notes:101]
Restricted Stock Unit (RSU) Activities

[0001596532-18-000018:notes:102]
A summary of the activity under our 2014 Plan and changes during the reporting period and a summary of information related to RSUs are presented below (in thousands, except years and per share amounts):

[0001596532-18-000018:notes:103]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2016 |  | 1,375 |  |  | $ | 74.23 |  |  | 1.8 |  | $ | 133,081 |  |
| RSUs granted |  | 712 |  |  | 141.97 |  |  |  |  |  |
| RSUs vested |  | (456 | ) |  | 77.33 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (94 | ) |  | 80.58 |  |  |  |  |  |
| Unvested balance—December 31, 2017 |  | 1,537 |  |  | $ | 104.29 |  |  | 1.6 |  | $ | 362,119 |  |

[0001596532-18-000018:notes:104]
Employee Stock Purchase Plan Activities

[0001596532-18-000018:notes:105]
During the year ended December 31, 2017, we issued 204,918 shares at an average purchase price of $61.15 under our ESPP.  Shares available for future issuance under our ESPP, subsequent to the increase authorized by our board of directors, are approximately 2.7 million.

[0001596532-18-000018:notes:106]
Shares Available for Grant

[0001596532-18-000018:notes:107]
Stock-Based Compensation Expense

[0001596532-18-000018:notes:108]
Total stock-based compensation expense related to options, RSAs, ESPP and RSUs granted were charged to the department to which the associated employee reported as follow (in thousands):

[0001596532-18-000018:notes:109]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Cost of revenue |  | $ | 4,353 |  |  | $ | 3,620 |  |  | $ | 3,048 |  |
| Research and development |  | 42,184 |  |  | 31,892 |  |  | 25,515 |  |
| Sales and marketing |  | 17,953 |  |  | 15,666 |  |  | 11,454 |  |
| General and administrative |  | 10,937 |  |  | 7,854 |  |  | 5,286 |  |
| Total stock-based compensation |  | $ | 75,427 |  |  | $ | 59,032 |  |  | $ | 45,303 |  |

[0001596532-18-000018:notes:110]
Determination of Fair Value

[0001596532-18-000018:notes:111]
We record stock-based compensation awards based on fair value as of the grant date. We value RSUs at the market close price of our common stock on the date of grant. For option awards and ESPP offerings we use the Black-Scholes option pricing model to determine fair value. We recognize such costs as compensation expense generally on a straight-line basis over the requisite service period of the award.

[0001596532-18-000018:notes:112]
Stock Options

[0001596532-18-000018:notes:113]
For the years ended December 31, 2017, 2016 and 2015, the fair value of each stock option granted under our plans was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001596532-18-000018:notes:114]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Expected term (in years) |  | 6.3 |  |  | 6.7 |  |  | 6.2 |  |
| Risk-free interest rate |  | 2.1 | % |  | 1.5 | % |  | 1.6 | % |
| Expected volatility |  | 38.9 | % |  | 38.9 | % |  | 42.9 | % |
| Dividend rate |  | — | % |  | — | % |  | — | % |

[0001596532-18-000018:notes:115]
As of December 31, 2017, the total unrecognized stock-based compensation expense for unvested stock options was $67.6 million, which is expected to be recognized over a weighted-average period of 3.6 years. The total fair value of options vested for the year ended December 31, 2017, 2016 and 2015 was approximately $30.7 million, $28.6 million and $22.8 million.

[0001596532-18-000018:notes:116]
As of December 31, 2017, there was $147.3 million of unrecognized stock-based compensation expense related to unvested RSUs. This amount is expected to be recognized over a weighted-average period of 3.4 years. The total fair value of RSUs vested for the year ended December 31, 2017 was approximately $35.4 million.

[0001596532-18-000018:notes:117]
ESPP

[0001596532-18-000018:notes:118]
The following table summarizes the assumptions relating to our ESPP:

[0001596532-18-000018:notes:119]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Expected term (in years) |  | 1.2 |  |  | 1.2 |  |  | 1.4 |  |
| Risk-free interest rate |  | 1.1 | % |  | 0.6 | % |  | 0.3 | % |
| Expected volatility |  | 31.7 | % |  | 31.8 | % |  | 34.8 | % |
| Dividend rate |  | — | % |  | — | % |  | — | % |

[0001596532-18-000018:notes:120]
As of December 31, 2017, total unrecognized stock-based compensation expense related to unvested ESPP options was $1.8 million, which is expected to be recognized over a weighted-average period of 1.2 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001596532-18-000018:notes:121]
Basic and diluted net income per share attributable to common stockholders is calculated in conformity with the two-class method required for participating securities. Our shares of common stock subject to repurchase are considered participating securities. In addition, our convertible preferred stock prior to conversion to common shares upon our initial public offering in June 2014, were also considered to be participating securities. Under the two-class method, net income attributable to common stockholders is calculated as net income less earnings attributable to participating securities. In computing diluted net income attributable to common stockholders, undistributed earnings are re-allocated to reflect the potential impact of dilutive securities. Basic net income per common share is computed by dividing the net income attributable to common stockholders by the weighted-average number of common shares outstanding during the period. Diluted net income per share attributable to common stockholders is computed by dividing the net income attributable to common stockholders by the weighted-average number of common shares outstanding, including potential dilutive common shares assuming the dilutive effect of outstanding stock options, restricted stock units, and employee stock purchase plan using the treasury stock method. For purposes of this calculation, these amounts are excluded from the calculation of diluted net income per share of common stock if their effect is antidilutive.


## us-gaap:EarningsPerShareTextBlock

[0001596532-18-000018:notes:122]
7.    Net Income Per Share Available to Common Stock

[0001596532-18-000018:notes:123]
The following table sets forth the computation of our basic and diluted net income per share available to common stock (in thousands, except per share amounts):

[0001596532-18-000018:notes:124]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Numerator: |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |
| Net income |  | $ | 423,201 |  |  | $ | 184,189 |  |  | $ | 121,102 |  |
| Less: undistributed earnings allocated to participating securities |  | (801 | ) |  | (1,224 | ) |  | (1,987 | ) |
| Net income available to common stockholders, basic |  | $ | 422,400 |  |  | $ | 182,965 |  |  | $ | 119,115 |  |
| Diluted: |  |  |  |  |  |  |
| Net income attributable to common stockholders, basic |  | $ | 422,400 |  |  | $ | 182,965 |  |  | $ | 119,115 |  |
| Add: undistributed earnings allocated to participating securities |  | 68 |  |  | 74 |  |  | 149 |  |
| Net income attributable to common stockholders, diluted |  | $ | 422,468 |  |  | $ | 183,039 |  |  | $ | 119,264 |  |
| Denominator: |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 72,258 |  |  | 68,771 |  |  | 65,964 |  |
| Diluted: |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 72,258 |  |  | 68,771 |  |  | 65,964 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |
| Stock options, RSUs and RSAs |  | 6,599 |  |  | 4,408 |  |  | 5,363 |  |
| Employee stock purchase plan |  | 120 |  |  | 43 |  |  | 84 |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted |  | 78,977 |  |  | 73,222 |  |  | 71,411 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |
| Basic |  | $ | 5.85 |  |  | $ | 2.66 |  |  | $ | 1.81 |  |
| Diluted |  | $ | 5.35 |  |  | $ | 2.50 |  |  | $ | 1.67 |  |

[0001596532-18-000018:notes:125]
The following weighted-average outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share available to common stockholders for the periods presented because including them would have been anti-dilutive (in thousands):

[0001596532-18-000018:notes:126]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Stock options and RSUs to purchase common stock |  | 58 |  |  | 2,594 |  |  | 2,427 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-18-000018:notes:127]
The following table set forth the fair value of our financial assets by level within the fair value hierarchy (in thousands):

[0001596532-18-000018:notes:128]
|  |  | December 31, 2017 |
|  |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 701,145 |  |  | $ | — |  |  | $ | — |  |  | $ | 701,145 |  |
| Money market funds - restricted |  | 5,505 |  |  | — |  |  | — |  |  | 5,505 |  |
| Commercial Paper |  | — |  |  | 11,924 |  |  | — |  |  | 11,924 |  |
| U.S. government notes |  | 136,647 |  |  | — |  |  | — |  |  | 136,647 |  |
| Corporate bonds |  | — |  |  | 312,484 |  |  | — |  |  | 312,484 |  |
| Agency securities |  | — |  |  | 228,036 |  |  | — |  |  | 228,036 |  |
| Total financial assets |  | $ | 843,297 |  |  | $ | 552,444 |  |  | $ | — |  |  | $ | 1,395,741 |  |

[0001596532-18-000018:notes:129]
|  |  | December 31, 2016 |
|  |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 305,182 |  |  | $ | — |  |  | $ | — |  |  | $ | 305,182 |  |
| Money market funds - restricted |  | 4,245 |  |  | — |  |  | — |  |  | 4,245 |  |
| Commercial Paper |  | — |  |  | 5,962 |  |  | — |  |  | 5,962 |  |
| U.S. government notes |  | 110,756 |  |  | — |  |  | — |  |  | 110,756 |  |
| Corporate bonds |  | — |  |  | 183,192 |  |  | — |  |  | 183,192 |  |
| Total financial assets |  | $ | 420,183 |  |  | $ | 189,154 |  |  | $ | — |  |  | $ | 609,337 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-18-000018:notes:130]
2.    Fair Value Measurements

[0001596532-18-000018:notes:131]
We measure and report our cash equivalents, restricted cash, and available-for-sale marketable securities at fair value. The following table set forth the fair value of our financial assets by level within the fair value hierarchy (in thousands):


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001596532-18-000018:notes:132]
Fair value is defined as the exchange price that would be received for an asset or an exit price that would be paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. These assets and liabilities include cash and cash equivalents, marketable securities, accounts receivable, accounts payable, and accrued liabilities. Cash equivalents, accounts receivable, accounts payable and accrued liabilities are stated at carrying amounts as reported in the consolidated financial statements, which approximate fair value due to their short-term nature.

[0001596532-18-000018:notes:133]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value.  We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs.  The three-tiers of the fair value hierarchy are as follows:

[0001596532-18-000018:notes:134]
Level I—Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date;

[0001596532-18-000018:notes:135]
Level II—Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities; and

[0001596532-18-000018:notes:136]
Level III—Unobservable inputs that are supported by little or no market data for the related assets or liabilities and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001596532-18-000018:notes:137]
The functional currency of our foreign subsidiaries is either the U.S. dollar or their local currency.

[0001596532-18-000018:notes:138]
Transaction re-measurement - Assets and liabilities denominated in a currency other than a subsidiary’s functional currency are re-measured into the subsidiary's functional currency using exchange rates in effect at the end of the reporting period, with gains and losses recorded in other income (expense), net in the consolidated statements of income. We recognized $0.5 million, $0.7 million, and $0.5 million in transaction losses for the years ended December 31, 2017, 2016 and 2015, respectively.

[0001596532-18-000018:notes:139]
Translation - Assets and liabilities of subsidiaries denominated in foreign functional currencies are translated into U.S. dollars at the closing exchange rate on the balance sheet date and equity related balances are translated at historical exchange rates.  Revenues, costs and expenses in foreign functional currencies are translated using average exchange rates that approximate those in effect during the period. Translation adjustments are accumulated as a separate component of accumulated other comprehensive income within stockholders’ equity.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001596532-18-000018:notes:140]
The carrying amounts of our long-lived assets, including property and equipment and investments in privately held companies, are periodically reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. Recoverability of these assets is measured by comparison of the carrying amount of each asset to the future undiscounted cash flows the asset is expected to generate over their remaining lives. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. No impairment of any long-lived assets or investments was identified for any of the periods presented.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-18-000018:notes:141]
8.    Income Taxes

[0001596532-18-000018:notes:142]
The geographical breakdown of income before provision for income taxes is as follows (in thousands):

[0001596532-18-000018:notes:143]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Domestic |  | $ | 373,221 |  |  | $ | 196,202 |  |  | $ | 129,240 |  |
| Foreign |  | 101,539 |  |  | 46,023 |  |  | 16,769 |  |
| Income before provision for income taxes |  | $ | 474,760 |  |  | $ | 242,225 |  |  | $ | 146,009 |  |

[0001596532-18-000018:notes:144]
The components of the provision for income taxes are as follows (in thousands):

[0001596532-18-000018:notes:145]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Current provision for income taxes: |  |  |  |  |  |  |
| Federal |  | $ | 36,862 |  |  | $ | 67,253 |  |  | $ | 43,706 |  |
| State |  | 3,645 |  |  | 10,529 |  |  | 5,500 |  |
| Foreign |  | 2,395 |  |  | 2,016 |  |  | 1,588 |  |
| Total current |  | 42,902 |  |  | 79,798 |  |  | 50,794 |  |
| Deferred taxes: |  |  |  |  |  |  |
| Federal |  | 12,795 |  |  | (18,579 | ) |  | (23,896 | ) |
| State |  | (3,404 | ) |  | (3,564 | ) |  | (2,300 | ) |
| Foreign |  | (734 | ) |  | 381 |  |  | 309 |  |
| Total deferred |  | 8,657 |  |  | (21,762 | ) |  | (25,887 | ) |
| Total provision for income taxes |  | $ | 51,559 |  |  | $ | 58,036 |  |  | $ | 24,907 |  |

[0001596532-18-000018:notes:146]
The reconciliation of the statutory federal income tax and our effective income tax is as follows:

[0001596532-18-000018:notes:147]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| U.S. federal statutory income tax |  | 35.00 | % |  | 35.00 | % |  | 35.00 | % |
| State tax, net of federal benefit |  | (1.70 | ) |  | (0.03 | ) |  | (1.35 | ) |
| Foreign tax differential |  | (7.62 | ) |  | (3.24 | ) |  | (2.16 | ) |
| Tax credits |  | (3.84 | ) |  | (4.24 | ) |  | (6.72 | ) |
| Change in valuation allowance |  | 1.95 |  |  | 1.71 |  |  | 2.84 |  |
| Permanent items |  | (1.10 | ) |  | (1.02 | ) |  | (1.32 | ) |
| Uncertain tax positions and associated interest |  | 0.77 |  |  | (1.46 | ) |  | (3.95 | ) |
| Stock-based compensation |  | (23.74 | ) |  | (2.81 | ) |  | (5.29 | ) |
| Tax Cuts and Jobs Act |  | 11.14 |  |  | — |  |  | — |  |
| Other, net |  | — |  |  | 0.05 |  |  | 0.01 |  |
| Total provision for income taxes |  | 10.86 | % |  | 23.96 | % |  | 17.06 | % |

[0001596532-18-000018:notes:148]
We have operations and a taxable presence in numerous jurisdictions outside the U.S.  In 2017, all of these countries have a lower tax rate than the U.S. The significant jurisdictions in which we have a presence include Cayman Islands, Ireland, and the United Kingdom.

[0001596532-18-000018:notes:149]
The large increase in the stock-based compensation benefit in the current year is due to the recognition of excess tax benefits generated from stock awards as a component of the provision for income taxes attributable to the adoption of ASU 2016-09 in the first fiscal quarter of 2017. Prior to the adoption, these benefits were recorded as a component of shareholders’ equity.

[0001596532-18-000018:notes:150]
On December 22, 2017, the U.S. government enacted comprehensive tax legislation commonly referred to as the Tax Cuts and Jobs Act (the “Tax Act”). The Tax Act makes broad and complex changes to the U.S. tax code, including, but not limited to, (1) reducing the U.S. federal corporate tax rate from 35 percent to 21 percent; (2) requiring companies to pay a one-time transition tax on certain unrepatriated earnings of foreign subsidiaries; (3) generally eliminating U.S. federal income taxes on dividends from foreign subsidiaries; (4) requiring a current inclusion in U.S. federal taxable income of certain earnings of controlled foreign corporations; and (5) creating the base erosion anti-abuse tax (“BEAT”), a new minimum tax.

[0001596532-18-000018:notes:151]
As of December 31, 2017, we had not yet completed our accounting for the tax effects of the enactment of the Tax Act.  However, for the amounts that we were able to reasonably estimate, we recognized a provisional tax amount of $51.8 million, which consisted of the following:

[0001596532-18-000018:notes:152]
| • | $18.8 million for the transition tax liability. We have not yet completed the calculation of the total post-1986 foreign earnings and profit (“E&P”) and the income tax pools for all foreign subsidiaries. Further, the transition tax is based in part on the amount of those earnings held in cash and other specified assets. This amount may change when we finalize the calculation of post-1986 foreign E&P previously deferred from U.S. federal and state governments and regulatory organizations, which may result in a change to the provisional tax liability. |

[0001596532-18-000018:notes:153]
| • | $33.0 million to re-measure certain deferred tax assets and liabilities, based on the rates at which they are expected to reverse in the future. We are still analyzing certain aspects of the Tax Act and refining the estimate of the expected reversal of our deferred tax balances. This can potentially affect the measurement of these balances and potentially result in a change to the provisional amount. |

[0001596532-18-000018:notes:154]
The Tax Act also includes provisions for Global Intangible Low-Taxed Income (“GILTI”) wherein taxes on foreign income are imposed in excess of a deemed return on tangible assets of foreign corporations. This income will effectively be taxed at a 10.5% tax rate in general. As a result, our deferred tax assets and liabilities are being evaluated to determine if they should be recognized for the basis differences expected to reverse as a result of GILTI provisions that are effective for us after the calendar year ending December 31, 2017, or whether the tax on GILTI provisions be recognized in the period the Tax Act was signed into law. Because of the complexity of the new provisions, we are continuing to evaluate how the provisions will be accounted for under the U.S. generally accepted accounting principles wherein companies are allowed to make an accounting policy election of either (i) account for GILTI as a component of tax expense in the period in which we are subject to the rules (the “period cost method”), or (ii) account for GILTI in our measurement of deferred taxes (the “deferred method”). Currently, we have not elected a method and will only do so after our completion of the analysis of the GILTI provisions and our election method will depend, in part, on analyzing our global income to determine whether we expect to have future U.S. inclusions in our taxable income related to GILTI and, if so, the impact that is expected.

[0001596532-18-000018:notes:155]
The tax effects of temporary differences that give rise to significant portions of deferred tax assets (liabilities) are as follows (in thousands):

[0001596532-18-000018:notes:156]
|  |  | December 31, |
|  |  | 2017 |  | 2016 |
| Deferred tax assets: |  |  |  |  |
| Property and equipment |  | $ | 1,942 |  |  | $ | 473 |  |
| Stock-based compensation |  | 22,050 |  |  | 23,071 |  |
| Reserves and accruals not currently deductible |  | 41,024 |  |  | 49,436 |  |
| Net operating losses |  | 2,432 |  |  | 1,140 |  |
| Tax credits |  | 30,831 |  |  | 15,015 |  |
| Other |  | 2,115 |  |  | 194 |  |
| Gross deferred tax assets |  | 100,394 |  |  | 89,329 |  |
| Valuation allowance |  | (35,132 | ) |  | (16,894 | ) |
| Total deferred tax assets |  | 65,262 |  |  | 72,435 |  |
| Deferred tax liabilities: |  |  |  |  |
| Property and equipment |  | — |  |  | (198 | ) |
| Accrued liabilities |  | (2,006 | ) |  | (2,555 | ) |
| Other |  | (9 | ) |  | (3 | ) |
| Total deferred tax liabilities |  | (2,015 | ) |  | (2,756 | ) |
| Net deferred tax assets |  | $ | 63,247 |  |  | $ | 69,679 |  |

[0001596532-18-000018:notes:157]
The following table presents the breakdown between non-current deferred tax assets and liabilities (in thousands):

[0001596532-18-000018:notes:158]
|  |  | December 31, |
|  |  | 2017 |  | 2016 |
| Deferred tax assets, non-current |  | $ | 65,125 |  |  | $ | 70,960 |  |
| Deferred tax liabilities, non-current |  | (1,878 | ) |  | (1,281 | ) |
| Total net deferred tax assets |  | $ | 63,247 |  |  |  | $69,679 |  |

[0001596532-18-000018:notes:159]
Recognition of deferred tax assets is appropriate when realization of these assets is more likely than not. We believe that all of the deferred tax assets were realizable with the exception of California and Canada deferred tax assets. Therefore, a valuation allowance of $35.1 million and $16.9 million was recorded as of December 31, 2017 and 2016, respectively, against the California and Canadian deferred tax assets as it was not more likely than not that these assets will be recognized. The net valuation allowance increased by $18.2 million and $4.2 million as of December 31, 2017 and 2016, respectively.

[0001596532-18-000018:notes:160]
As of December 31, 2017, we had no net operating loss carryforwards for federal and state income tax purposes. For foreign jurisdictions, we had combined foreign net operating loss carryforwards of $12.8 million which do not expire.

[0001596532-18-000018:notes:161]
As of December 31, 2017, we had U.S. federal credit carryforwards of $0.2 million, which begin to expire in 2038.  We had state credit carryforwards of $59.5 million, which can be carried over indefinitely. For foreign jurisdictions, we had $1.2 million of Canadian scientific research and experimental development tax credit carry-forwards, which begin to expire in 2034.

[0001596532-18-000018:notes:162]
Utilization of the net operating losses and tax credit carryforwards may be subject to limitations due to ownership changes limitations provided in the Internal Revenue code and similar state or foreign provisions. In all years up to December 31, 2017, such limitations had no impact to our deferred tax assets.

[0001596532-18-000018:notes:163]
Our policy with respect to our undistributed foreign subsidiaries earnings is to consider those earnings to be indefinitely reinvested. As discussed above the Tax Act required a one-time transition tax on previously untaxed accumulated and current E&P.  Correspondingly, all undistributed earnings were deemed to be taxed in the current year and distribution of the unremitted earnings will not have any significant U.S. federal and state income tax impact.  We are still in process of assessing our cash needs and the associated state and foreign income tax effects of ultimate cash repatriation.  As of December 31, 2017, 2016 and 2015, the undistributed earnings approximated $82.3 million, $36.4 million and $16.4 million, respectively. The determination of the future tax consequences of the remittance of these earnings is not practicable.

[0001596532-18-000018:notes:164]
Uncertain Tax Positions

[0001596532-18-000018:notes:165]
We recognize uncertain tax positions only to the extent that management believes that it is more likely than not the position will be sustained. The reconciliation of the beginning and ending amount of gross unrecognized tax benefits as of December 31, 2017, 2016 and 2015 was as follows (in thousands):

[0001596532-18-000018:notes:166]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Gross unrecognized tax benefits—beginning balance |  | $ | 26,915 |  |  | $ | 22,239 |  |  | $ | 21,322 |  |
| Increases related to tax positions taken in a prior year |  | 1,243 |  |  | 46 |  |  | 346 |  |
| Increases related to tax positions taken during current year |  | 22,202 |  |  | 11,359 |  |  | 7,385 |  |
| Decreases related to tax positions taken in a prior year |  | (21 | ) |  | (426 | ) |  | (228 | ) |
| Decreases related to settlements with taxing authorities |  | — |  |  | (432 | ) |  | — |  |
| Decreases related to lapse of statute of limitations |  | (1,504 | ) |  | (5,871 | ) |  | (6,586 | ) |
| Gross unrecognized tax benefits—ending balance |  | $ | 48,835 |  |  | $ | 26,915 |  |  | $ | 22,239 |  |

[0001596532-18-000018:notes:167]
As of December 31, 2017, 2016 and 2015, the total amount of gross unrecognized tax benefits was $48.8 million, $26.9 million and $22.2 million of which $23.5 million, $13.9 million and $13.0 million would affect our effective tax rate if recognized, respectively.

[0001596532-18-000018:notes:168]
Our policy is to recognize interest and penalties accrued on any unrecognized tax benefits as a component of income tax expense. We have recorded a net expense for interest and penalties of $0.4 million and a net benefit of $0.5 million in the years ended December 31, 2017 and 2016, respectively. As of December 31, 2017 and 2016, we recognized a liability for interest and penalties of $1.0 million and $0.6 million, respectively.

[0001596532-18-000018:notes:169]
We have been selected for examination by the Internal Revenue Service ("IRS") for our 2014 tax year.  It is difficult to determine when the examinations will be settled or their final outcomes in the foreseeable future. We believe that we have adequately provided reserves for any reasonably foreseeable adjustment to our tax returns.

[0001596532-18-000018:notes:170]
The statute of limitations for Federal remains open for 2014 and forward.  Because of the net operating loss and tax credit carryforwards, all tax years remain open to state tax examination. The majority of our foreign tax returns are open to audit under the statute of limitations of the respective foreign countries, in which the subsidiaries are located. It is possible that the amount of existing unrecognized tax benefits may decrease within the next 12 months as a result of statute of limitation lapses in some of the jurisdictions and the settlement of the aforementioned IRS examination, however, an estimate of the range cannot be made.


## us-gaap:IncomeTaxPolicyTextBlock

[0001596532-18-000018:notes:171]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-18-000018:notes:172]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-18-000018:notes:173]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-18-000018:notes:174]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.


## us-gaap:InventoryPolicyTextBlock

[0001596532-18-000018:notes:175]
Inventories primarily consist of finished goods and strategic components, primarily integrated circuits. Inventories are stated at the lower of cost (computed using the first-in, first-out method) and net realizable value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory.  We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value. For the years ended December 31, 2017, 2016 and 2015, we recorded charges of $28.1 million, $12.1 million and $9.0 million, respectively, within cost of product revenue for inventory write-downs.

[0001596532-18-000018:notes:176]
Our contract manufacturers procure components and assemble products on our behalf based on our forecasts. We record a liability and a corresponding charge for non-cancellable, non-returnable purchase commitments with our contract manufacturers or suppliers for quantities in excess of our demand forecasts or that are considered obsolete due to manufacturing and engineering change orders resulting from design changes. For the years ended December 31, 2017, 2016 and 2015, we recorded charges of $21.2 million, $6.2 million and $3.9 million, respectively, within cost of product revenue for such liabilities with our contract manufacturers and suppliers.

[0001596532-18-000018:notes:177]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer liabilities.


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-18-000018:notes:178]
4.    Investments

[0001596532-18-000018:notes:179]
Investments in Privately Held Companies

[0001596532-18-000018:notes:180]
As of December 31, 2017 and 2016, we held non-marketable equity investments of approximately $36.1 million and $36.1 million, respectively, in privately held companies which are accounted for under the cost method. To date, we have not recognized any impairment losses on our investments.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-18-000018:notes:181]
Improvements to Share-Based Payment Accounting

[0001596532-18-000018:notes:182]
In March 2016, the Financial Accounting Standards Board (the “FASB”) amended the existing accounting standard for stock-based compensation, issuing Accounting Standards Update (“ASU”) 2016-09, Compensation-Stock Compensation: Improvements to Employee Share-Based Payment Accounting, which impacts several aspects of accounting for share-based payment transactions, including the income tax consequences, forfeitures, classification of awards as either equity or liabilities, and classification on the statement of cash flows. We adopted this standard during our first fiscal quarter of 2017. The impact of the adoption was as follows:

[0001596532-18-000018:notes:183]
| • | Income tax accounting - The standard eliminates additional paid-in-capital (“APIC”) pools and requires excess tax benefits and tax deficiencies on share-based awards to be recognized in the income statement prospectively as discrete items upon exercise or vesting of such awards. The standard also requires excess tax benefits to be recognized regardless of whether the benefit reduces taxes payable. We adopted the guidance related to the timing of previously unrecognized excess tax benefits on a modified retrospective basis, which resulted in the recognition of a cumulative effect adjustment of $1.8 million that increased retained earnings and increased our long-term deferred income tax as of January 1, 2017. |

[0001596532-18-000018:notes:184]
| • | Earnings per share - Because excess tax benefits are no longer recognized in APIC, the assumed proceeds from applying the treasury stock method when calculating dilutive shares was amended to exclude the amount of excess tax benefits that would be recognized upon exercise or vesting of such awards. As a result, this reduces the assumed shares to be repurchased under the treasury stock method, thereby increasing the amount of dilutive shares used to compute earnings per share. We adopted the guidance related to the exclusion of excess tax benefits in calculating earnings per share on a prospective basis. |

[0001596532-18-000018:notes:185]
| • | Forfeitures of stock options and awards - Under the new standard, we can make an accounting policy election to either estimate the number of share-based awards that are expected to vest, or account for forfeitures when they occur. We elected to account for forfeitures when they occur and adopted this change on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as a $1.0 million decrease to retained earnings as of January 1, 2017. |

[0001596532-18-000018:notes:186]
| • | Cash flow presentation of excess tax benefits - Prior to the new standard, we were required to present excess tax benefits on share-based awards as a cash inflow from financing activities with a corresponding cash outflow from operating activities. The new standard required that these excess tax benefits be classified with other income tax cash flows as an operating activity. We elected to adopt the guidance related to the presentation of excess tax benefits in our consolidated statements of cash flows on a retrospective basis. This resulted in an increase in net cash provided by operating activities and a corresponding decrease in net cash provided by financing activities of $42.9 million and $37.3 million for the years ended December 31, 2016 and 2015, respectively. |

[0001596532-18-000018:notes:187]
Simplifying the Measurement of Inventory

[0001596532-18-000018:notes:188]
In July 2015, the FASB issued ASU 2015-11, Inventory: Simplifying the Measurement of Inventory, which simplifies the measurement of inventory to be measured at the lower of cost and net realizable value. The guidance is effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. We adopted this standard in our first quarter of fiscal 2017 on a prospective basis, and the adoption did not have a material impact on our consolidated financial statements.

[0001596532-18-000018:notes:189]
Recent Accounting Pronouncements Not Yet Effective

[0001596532-18-000018:notes:190]
Revenue Recognition

[0001596532-18-000018:notes:191]
During May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606). In 2016, the FASB issued ASU No. 2016-08, ASU No. 2016-10 and ASU No. 2016-12, which provide interpretive clarifications on the new guidance in Topic 606 (collectively, “the new standard”). The new standard replaces primarily all existing revenue recognition guidance under GAAP and establishes common principles for recognizing revenue for all industries. It also provides guidance on the accounting for costs to fulfill or obtain a customer contract. Under the new standard, the recognition of revenue is based on consideration expected to be entitled from the transfer of goods or services to a customer. The new standard is effective for interim and annual periods beginning after December 15, 2017 and permits the use of either the retrospective or cumulative effect transition method. The retrospective method requires a retrospective approach to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance. The cumulative approach requires a retrospective approach with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance.

[0001596532-18-000018:notes:192]
We have finalized our assessment of the new standard, including completing our contract reviews and our evaluation of the costs of obtaining a contract.  We will adopt the new standard in our first quarter of 2018 using the modified retrospective method. Based on our assessment, the impact of the new standard on the date of adoption is not material and is primarily related to the deferral of incremental commission costs of obtaining customer service contracts, which are currently expensed as incurred. Under the new standard, we will defer all such costs and amortize them over the expected period of benefit. The new standard also requires companies to account for termination clauses at the onset of an arrangement. While there is limited history of cancellations, our prepaid subscription offerings are generally cancellable by customers with 30 days’ notice. While these prepaid amounts are currently recorded to deferred revenue, the new standard requires that we record these amounts as other liabilities.  In addition, the new standard may impact the amount and timing of revenue recognition of certain sales arrangements and the related disclosures on our consolidated financial statements.  However, we do not expect the impact from any of these changes to have a material impact on our results of operations or financial condition in the year of adoption.

[0001596532-18-000018:notes:193]
Financial Instruments

[0001596532-18-000018:notes:194]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities, which enhances the reporting model for financial instruments to provide users of financial statements with more decision-useful information. The guidance addresses certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. The standard is effective for us for our first quarter of fiscal 2018 and we will adopt it utilizing the modified retrospective transition method. Based on the composition of our investment portfolio, we do not expect the adoption of this guidance to have a material impact on our consolidated financial statements.

[0001596532-18-000018:notes:195]
Leases

[0001596532-18-000018:notes:196]
In February 2016, the FASB issued ASU No, 2016-02, Leases, which addresses the classification and recognition of lease assets and liabilities formerly classified as operating leases under GAAP. The guidance will address certain aspects of recognition and measurement, and quantitative and qualitative aspects of presentation and disclosure. The guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. The guidance may be early adopted.  We plan to adopt this guidance at the beginning of 2019. The guidance will be applied to the earliest period presented using a modified retrospective approach. The guidance includes practical expedients that relate to identification, classification, and initial direct costs associated with leases commencing prior to the effective date, and the ability to apply hindsight in evaluating lease options related to extensions, terminations or asset purchases. A practical expedient also exists to treat leases entered into prior effective date under existing GAAP unless the lease has been modified. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

[0001596532-18-000018:notes:197]
Credit Losses of Financial Instruments

[0001596532-18-000018:notes:198]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. Credit losses relating to available-for-sale debt securities should be recorded through an allowance for credit losses. This standard is effective for us for our first quarter of 2020. We are currently assessing the impact this guidance may have on our consolidated financial statements.

[0001596532-18-000018:notes:199]
Classification of Cash Flow Elements

[0001596532-18-000018:notes:200]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Task Force), which addresses eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. The guidance will be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. The standard is effective for us for our first quarter of fiscal 2018.  We do not expect the guidance to have a material impact on our consolidated financial statements.

[0001596532-18-000018:notes:201]
Income Taxes on Intra-Entity Transfers of Assets

[0001596532-18-000018:notes:202]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which addresses recognition of current and deferred income taxes for intra-entity asset transfers when assets are sold to an outside party. Current GAAP prohibits the recognition of current and deferred income taxes until the asset has been sold to an outside party. This prohibition on recognition is considered an exception to the principle of comprehensive recognition of current and deferred income taxes in GAAP. The new guidance requires an entity to recognize the income tax consequences when the transfer occurs eliminating the exception. The guidance will be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. The standard is effective for us for our first quarter of fiscal 2018. We do not expect the adoption of this guidance to have a material impact on our consolidated financial statements.

[0001596532-18-000018:notes:203]
Restricted Cash in Statement of Cash Flows

[0001596532-18-000018:notes:204]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force, which requires that amounts generally described as restricted cash or restricted cash equivalents be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows.  This standard should be applied using a retrospective transition method to each period presented.  This standard is effective for us for our first quarter of fiscal 2018. We do not anticipate this standard will have a material impact on our consolidated financial statements.

[0001596532-18-000018:notes:205]
Scope of Modification Accounting in Stock Compensation

[0001596532-18-000018:notes:206]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (Topic 718) Scope of Modification Accounting which addresses providing clarity to reduce diversity in practice, cost and complexity in the application of modification accounting when there is a change in terms or conditions of a share-based payment award. The guidance will be applied on a prospective basis to awards modified on or after the adoption date. This standard is effective for us for our first quarter of fiscal 2018. We do not anticipate this standard will have a material impact on our consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-18-000018:notes:207]
1.    Organization and Summary of Significant Accounting Policies

[0001596532-18-000018:notes:208]
Organization

[0001596532-18-000018:notes:209]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our” or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System, a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-18-000018:notes:210]
Basis of Presentation and Principles of Consolidation

[0001596532-18-000018:notes:211]
Use of Estimates

[0001596532-18-000018:notes:212]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; valuation of inventory and contract manufacturer/supplier liabilities; recognition and measurement of contingent liabilities; determination of fair value for stock-based awards; and valuation of warranty accruals. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.

[0001596532-18-000018:notes:213]
Concentrations of Business and Credit Risk

[0001596532-18-000018:notes:214]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, marketable securities, restricted cash, and accounts receivable. Our cash, cash equivalents, restricted cash and marketable securities are invested in high quality financial instruments with banks and financial institutions. Such deposits may be in excess of insured limits provided on such deposits.

[0001596532-18-000018:notes:215]
Our accounts receivable are unsecured and represent amounts due to us based on contractual obligations of our customers. We mitigate credit risk in respect to accounts receivable by performing ongoing credit evaluations of our customers to assess the probability of accounts receivable collection based on a number of factors, including past transaction experience with the customer, evaluation of their credit history, the credit limits extended and review of the invoicing terms of the arrangement. In situations where a customer may be thinly capitalized and we have limited payment history with it, we will either establish a small credit limit or require it to prepay its purchases. We generally do not require our customers to provide collateral to support accounts receivable. We have recorded an allowance for doubtful accounts for those receivables that we have determined not to be collectible. We mitigate credit risk in respect to the notes receivable by performing ongoing credit evaluations of the borrower to assess the probability of collecting all amounts due to us under the existing contractual terms.

[0001596532-18-000018:notes:216]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators and original equipment manufacturer (“OEM”) partners and in conjunction with various technology partners.  Significant customers are those which represent more than 10% of our total net revenue during the period or net accounts receivable balance at each respective balance sheet date. As of December 31, 2017, we had two customers who represented 30% and 18% of total accounts receivable, respectively. As of December 31, 2016, we had one customer who represented 36% of total accounts receivable. For the year ended December 31, 2017, 2016 and 2015, there was one customer who represented 16%, 16% and 12% of our total revenue, respectively.

[0001596532-18-000018:notes:217]
Comprehensive Income

[0001596532-18-000018:notes:218]
Cash and Cash Equivalents

[0001596532-18-000018:notes:219]
Marketable Securities

[0001596532-18-000018:notes:220]
We classify all highly liquid investments in debt and equity securities with maturities of greater than three months at the date of purchase as marketable securities. We have classified and accounted for our marketable securities as available-for-sale. We determine the appropriate classification of these investments at the time of purchase and reevaluate such designation at each balance sheet date. We may or may not hold securities with stated maturities greater than 12 months until maturity. After consideration of our risk versus reward objectives, as well as our liquidity requirements, we may sell these securities prior to their stated maturities. As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying consolidated balance sheets. We carry these securities at fair value, and report the unrealized gains and losses, net of taxes, as a component of stockholders’ equity, except for unrealized losses determined to be other-than-temporary, which we record as other income (expense), net. We determine any realized gains or losses on the sale of marketable securities on a specific identification method, and we record such gains and losses as a component of interest and other income, net.

[0001596532-18-000018:notes:221]
Accounts Receivable

[0001596532-18-000018:notes:222]
Accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts, and sales rebates and returns reserves. We estimate our allowance for doubtful accounts based upon the collectability of the receivables in light of historical trends, adverse situations that may affect our customers’ ability to pay and prevailing economic conditions. This evaluation is done in order to identify issues which may impact the collectability of receivables and related estimated required allowance. Revisions to the allowance are recorded as an adjustment to bad debt expense. After appropriate collection efforts are exhausted, specific accounts receivable deemed to be uncollectible are charged against the allowance in the period they are deemed uncollectible. Recoveries of accounts receivable previously written-off are recorded as credits to bad debt expense. We primarily estimate our sales rebates and returns reserves based on historical rates applied against current period gross revenues. Specific customer returns, rebates and allowances are considered when determining our estimates. Revisions to the reserves are recorded as adjustments to revenue.

[0001596532-18-000018:notes:223]
Fair Value Measurements

[0001596532-18-000018:notes:224]
Foreign Currency

[0001596532-18-000018:notes:225]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-18-000018:notes:226]
Property and Equipment

[0001596532-18-000018:notes:227]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is calculated using the straight-line method over the estimated useful lives of the related assets, generally from three to five years.  Our building is depreciated over 30 years and leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term. The leased building under our build-to-suit lease is capitalized and included in property and equipment as we were involved in the construction funding and did not meet the “sale-leaseback” criteria.

[0001596532-18-000018:notes:228]
Investments

[0001596532-18-000018:notes:229]
Our investments in privately held companies are accounted for under the cost method and are included in investments, non-current in the accompanying consolidated balance sheets. Our investments under the cost method are recorded at historical cost at the time of investment.

[0001596532-18-000018:notes:230]
Impairment of Long-Lived Assets and Investments

[0001596532-18-000018:notes:231]
Loss Contingencies

[0001596532-18-000018:notes:232]
We generate revenue from sales of our products which incorporate our EOS software and accessories such as cables and optics to direct customers and channel partners together with post contract customer support (“PCS”). We typically sell products and PCS in a single transaction. We recognize revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery or performance has occurred; the sales price is fixed or determinable; and collectability is reasonably assured.

[0001596532-18-000018:notes:233]
We define each of the four criteria above as follows:

[0001596532-18-000018:notes:234]
| • | Persuasive evidence of an arrangement exists. Evidence of an arrangement consists of stand-alone purchase orders or purchase orders issued pursuant to the terms and conditions of a master sales agreement. It is our practice to identify an end customer prior to shipment to a reseller or distributor. |

[0001596532-18-000018:notes:235]
| • | Delivery or performance has occurred. We use shipping documents or written evidence of customer acceptance, when applicable, to verify delivery or performance. We recognize product revenue upon transfer of title and risk of loss, which primarily is upon shipment to customers. We generally do not have significant obligations for future performance, rights of return or pricing credits associated with our product sales. In instances where substantive acceptance provisions are specified in the customer arrangement, revenue and the related cost of revenue is deferred until all acceptance criteria have been met. |

[0001596532-18-000018:notes:236]
| • | The sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on payment terms and whether the sales price is subject to refund or adjustment. |

[0001596532-18-000018:notes:237]
| • | Collectability is reasonably assured. We assess probability of collectability on a customer-by-customer basis. Our customers and channel partners are subjected to a credit review process that evaluates their financial condition and ability to pay for products and services. |

[0001596532-18-000018:notes:238]
PCS, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract, with the related expenses recognized as incurred. PCS contracts usually have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-18-000018:notes:239]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of goods sold.

[0001596532-18-000018:notes:240]
Multiple-Element Arrangements

[0001596532-18-000018:notes:241]
Most of our arrangements, other than renewals of PCS, are multiple element arrangements with a combination of products and PCS. Products and PCS generally qualify as separate units of accounting. Our hardware deliverables include EOS software, which together deliver the essential functionality of our products. For multiple element arrangements, we allocate revenue to each unit of accounting based on the relative selling price. The relative selling price for each element is based upon the following hierarchy: vendor-specific objective evidence (“VSOE”), if available; third-party evidence (“TPE”), if VSOE is not available; and best estimate of selling price (“BESP”), if neither VSOE nor TPE is available. As we have not been able to establish VSOE or TPE for our products and most of our services, we generally utilize BESP for the purposes of allocating revenue to each unit of accounting.

[0001596532-18-000018:notes:242]
| • | VSOE—We determine VSOE based on our historical pricing and discounting practices for the specific products and services when sold separately. In determining VSOE, we require that a substantial majority of the stand-alone selling prices fall within a reasonably narrow pricing range. |

[0001596532-18-000018:notes:243]
| • | TPE—When VSOE cannot be established for deliverables in multiple-element arrangements, we apply judgment with respect to whether we can establish a selling price based on TPE. TPE is determined based on competitor prices for interchangeable products or services when sold separately to similarly situated customers. However, as our products contain a significant element of proprietary technology and offer substantially different features and functionality, the comparable pricing of products with similar functionality typically cannot be obtained. Additionally, as we are unable to reliably determine what competitors products’ selling prices are on a stand-alone basis, we are not able to obtain reliable evidence of TPE of selling price. |

[0001596532-18-000018:notes:244]
| • | BESP—When we are unable to establish selling price using VSOE or TPE, we use BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service was sold regularly on a stand-alone basis. BESP is based on considering multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services were sold (domestic or international) and size of the end customer. |

[0001596532-18-000018:notes:245]
We limit the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations, or subject to customer-specific return, acceptance or refund privileges.

[0001596532-18-000018:notes:246]
We account for multiple agreements with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single arrangement.

[0001596532-18-000018:notes:247]
We may occasionally accept returns to address customer satisfaction issues even though there is no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period gross revenues. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-18-000018:notes:248]
Research and Development Expenses

[0001596532-18-000018:notes:249]
Costs related to the research, design and development of our products are charged to research and development expenses as incurred. Software development costs are capitalized beginning when a product’s technological feasibility has been established and ending when the product is available for general release to customers. Generally, our products are released soon after technological feasibility has been established. As a result, costs incurred subsequent to achieving technological feasibility have not been significant and accordingly, all software development costs have been expensed as incurred.

[0001596532-18-000018:notes:250]
Warranty

[0001596532-18-000018:notes:251]
We offer a one-year warranty on all of our hardware products and a 90-day warranty against defects in the software embedded in the products. We use judgment and estimates when determining warranty costs based on historical costs to replace product returns within the warranty period at the time we recognize revenue. We accrue for potential warranty claims at the time of shipment as a component of cost of revenues based on historical experience and other relevant information. We reserve for specifically identified products if and when we determine we have a systemic product failure. Although we engage in extensive product quality programs, if actual product failure rates or use of materials differ from estimates, additional warranty costs may be incurred, which could reduce our gross margin. The accrued warranty liability is recorded in accrued liabilities in the accompanying consolidated balance sheets.

[0001596532-18-000018:notes:252]
Segment Reporting

[0001596532-18-000018:notes:253]
We develop, market and sell cloud networking solutions, which consist of our Gigabit Ethernet switches and related software. We have one business activity and there are no segment managers who are held accountable for operations or operating results below the Company level. Our chief operating decision maker is our Chief Executive Officer, who reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.  Accordingly, we have determined that we operate as one reportable segment.

[0001596532-18-000018:notes:254]
Stock-Based Compensation

[0001596532-18-000018:notes:255]
Compensation expense related to stock-based transactions, including stock options, restricted stock units ("RSUs"), restricted stock awards (“RSAs”), and stock purchase rights under our employee stock purchase program is measured and recognized in the financial statements based on the fair value of the equity granted on a straight-line basis over the requisite service periods of the awards, which typically ranges from two to five years. Prior to 2017, the stock-based compensation expense was recognized net of estimated forfeitures. Beginning the first quarter of fiscal 2017, upon the adoption of ASU 2016-09, Compensation-Stock Compensation: Improvements to Employee Share-Based Payment Accounting, we elected to account for forfeitures as they occur and no longer include an estimate of future forfeitures in the expense recognition. See Recently Adopted Accounting Pronouncements below for details.

[0001596532-18-000018:notes:256]
Excess tax benefits generated from stock option exercises and other equity awards are recorded as a reduction to provision for income taxes in the consolidated statements of income. Prior to 2017, before we adopted ASU 2016-09, such excess tax benefits were recognized as additional paid-in capital in the consolidated balance sheets. See Recently Adopted Accounting Pronouncements below for details. Excess tax benefits resulting from stock awards were $110.0 million, $42.1 million and $37.0 million for the years ended December 31, 2017, 2016 and 2015, respectively.

[0001596532-18-000018:notes:257]
Income Taxes

[0001596532-18-000018:notes:258]
Net Income per Share of Common Stock

[0001596532-18-000018:notes:259]
Recently Adopted Accounting Pronouncements


## us-gaap:PostemploymentBenefitsDisclosureTextBlock

[0001596532-18-000018:notes:260]
10.    Post-Employment Benefits

[0001596532-18-000018:notes:261]
We have a 401(k) Plan that covers substantially all of our employees in the U.S.  Effective January 1, 2017, we have elected to match 100% of employees' contributions up to a maximum of 3% of an employee's annual salary. Matching contributions will be immediately vested. For the year ended December 31, 2017, we contributed approximately $3.5 million for the matching contributions. For the years ended December 31, 2016 and 2015, we did not provide a discretionary company match to employee contributions.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001596532-18-000018:notes:262]
Property and equipment, net consists of the following (in thousands):

[0001596532-18-000018:notes:263]
|  |  | December 31, |
|  |  | 2017 |  | 2016 |
| Equipment and machinery |  | $ | 47,711 |  |  | $ | 40,721 |  |
| Computer hardware and software |  | 22,124 |  |  | 17,420 |  |
| Furniture and fixtures |  | 3,020 |  |  | 2,879 |  |
| Leasehold improvements |  | 30,548 |  |  | 29,498 |  |
| Building |  | 35,154 |  |  | 35,154 |  |
| Construction-in-process |  | 4,742 |  |  | 421 |  |
| Property and equipment, gross |  | 143,299 |  |  | 126,093 |  |
| Less: accumulated depreciation |  | (69,020 | ) |  | (49,132 | ) |
| Property and equipment, net |  | $ | 74,279 |  |  | $ | 76,961 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001596532-18-000018:notes:264]
11.    Selected Quarterly Financial Information (Unaudited)

[0001596532-18-000018:notes:265]
The following table sets forth selected unaudited quarterly consolidated statements of income data for each of the quarters in the years ended December 31, 2017 and 2016:

[0001596532-18-000018:notes:266]
|  |  | Three Months Ended |
|  |  | Dec. 31, 2017 |  | Sep. 30, 2017 |  | Jun. 30, 2017 |  | Mar. 31, 2017 |  | Dec. 31, 2016 |  | Sep. 30, 2016 |  | Jun. 30, 2016 |  | Mar. 31, 2016 |
|  |  | (in thousands) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 407,195 |  |  | $ | 380,344 |  |  | $ | 353,904 |  |  | $ | 291,367 |  |  | $ | 289,008 |  |  | $ | 254,238 |  |  | $ | 235,616 |  |  | $ | 212,475 |  |
| Service |  | 60,672 |  |  | 57,289 |  |  | 51,307 |  |  | 44,108 |  |  | 38,961 |  |  | 36,023 |  |  | 33,125 |  |  | 29,721 |  |
| Total revenue |  | 467,867 |  |  | 437,633 |  |  | 405,211 |  |  | 335,475 |  |  | 327,969 |  |  | 290,261 |  |  | 268,741 |  |  | 242,196 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 147,919 |  |  | 145,874 |  |  | 134,406 |  |  | 109,836 |  |  | 108,057 |  |  | 94,777 |  |  | 88,021 |  |  | 78,913 |  |
| Service |  | 12,783 |  |  | 11,142 |  |  | 11,028 |  |  | 11,429 |  |  | 9,757 |  |  | 9,064 |  |  | 9,269 |  |  | 8,193 |  |
| Total cost of revenue |  | 160,702 |  |  | 157,016 |  |  | 145,434 |  |  | 121,265 |  |  | 117,814 |  |  | 103,841 |  |  | 97,290 |  |  | 87,106 |  |
| Gross profit |  | 307,165 |  |  | 280,617 |  |  | 259,777 |  |  | 214,210 |  |  | 210,155 |  |  | 186,420 |  |  | 171,451 |  |  | 155,090 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | 107,180 |  |  | 79,610 |  |  | 81,194 |  |  | 81,610 |  |  | 71,398 |  |  | 70,648 |  |  | 69,020 |  |  | 62,515 |  |
| Sales and marketing |  | 38,808 |  |  | 40,640 |  |  | 38,630 |  |  | 37,027 |  |  | 38,321 |  |  | 33,216 |  |  | 31,744 |  |  | 27,606 |  |
| General and administrative |  | 21,789 |  |  | 19,535 |  |  | 23,319 |  |  | 22,155 |  |  | 22,941 |  |  | 19,535 |  |  | 17,529 |  |  | 15,234 |  |
| Total operating expenses |  | 167,777 |  |  | 139,785 |  |  | 143,143 |  |  | 140,792 |  |  | 132,660 |  |  | 123,399 |  |  | 118,293 |  |  | 105,355 |  |
| Income from operations |  | 139,388 |  |  | 140,832 |  |  | 116,634 |  |  | 73,418 |  |  | 77,495 |  |  | 63,021 |  |  | 53,158 |  |  | 49,735 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | (741 | ) |  | (701 | ) |  | (623 | ) |  | (715 | ) |  | (918 | ) |  | (735 | ) |  | (732 | ) |  | (751 | ) |
| Other income (expense), net |  | 2,988 |  |  | 2,136 |  |  | 1,119 |  |  | 1,025 |  |  | 560 |  |  | 639 |  |  | 416 |  |  | 337 |  |
| Total other income (expense), net |  | 2,247 |  |  | 1,435 |  |  | 496 |  |  | 310 |  |  | (358 | ) |  | (96 | ) |  | (316 | ) |  | (414 | ) |
| Income before income taxes |  | 141,635 |  |  | 142,267 |  |  | 117,130 |  |  | 73,728 |  |  | 77,137 |  |  | 62,925 |  |  | 52,842 |  |  | 49,321 |  |
| Provision for (benefit from) income taxes (1) |  | 37,802 |  |  | 8,545 |  |  | 14,445 |  |  | (9,233 | ) |  | 18,354 |  |  | 11,668 |  |  | 13,938 |  |  | 14,076 |  |
| Net income |  | $ | 103,833 |  |  | $ | 133,722 |  |  | $ | 102,685 |  |  | $ | 82,961 |  |  | $ | 58,783 |  |  | $ | 51,257 |  |  | $ | 38,904 |  |  | $ | 35,245 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.42 |  |  | $ | 1.84 |  |  | $ | 1.42 |  |  | $ | 1.16 |  |  | $ | 0.84 |  |  | $ | 0.74 |  |  | $ | 0.57 |  |  | $ | 0.52 |  |
| Diluted |  | $ | 1.29 |  |  | $ | 1.68 |  |  | $ | 1.30 |  |  | $ | 1.07 |  |  | $ | 0.79 |  |  | $ | 0.69 |  |  | $ | 0.53 |  |  | $ | 0.48 |  |
| ____________________________ |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (1) Provision for (benefit from) income taxes for the first, second, third and fourth quarter of 2017 included an excess tax benefits of $28.8 million, $19.1 million, $23.8 million and $38.3 million, respectively, resulting from the adoption of ASU 2016-09. In addition, provision for income taxes for the fourth quarter of 2017 included a provisional amount of $51.8 million in connection with the Tax Act enacted on December 22, 2017. See Note 8 for details. |


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001596532-18-000018:notes:267]
Accounts Receivable, net

[0001596532-18-000018:notes:268]
Accounts receivable, net consists of the following (in thousands):

[0001596532-18-000018:notes:269]
|  |  | December 31, |
|  |  | 2017 |  | 2016 |
| Accounts receivable |  | $ | 254,881 |  |  | $ | 254,640 |  |
| Allowance for doubtful accounts |  | (112 | ) |  | (204 | ) |
| Product sales rebate and returns reserve |  | (7,423 | ) |  | (1,317 | ) |
| Accounts receivable, net |  | $ | 247,346 |  |  | $ | 253,119 |  |

[0001596532-18-000018:notes:270]
Allowance for Doubtful Accounts

[0001596532-18-000018:notes:271]
Activity in the allowance for doubtful accounts consists of the following (in thousands):

[0001596532-18-000018:notes:272]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Balance at the beginning of year |  | $ | 204 |  |  | $ | 963 |  |  | $ | 1,063 |  |
| Additions (deductions) charged (credited) to expense |  | 17 |  |  | (292 | ) |  | 335 |  |
| Deductions/write-offs |  | (109 | ) |  | (467 | ) |  | (435 | ) |
| Balance at the end of year |  | $ | 112 |  |  | $ | 204 |  |  | $ | 963 |  |

[0001596532-18-000018:notes:273]
Product Sales Rebate and Returns Reserve

[0001596532-18-000018:notes:274]
Activity in the product sales rebate and returns reserve consists of the following (in thousands):

[0001596532-18-000018:notes:275]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Balance at the beginning of year |  | $ | 1,317 |  |  | $ | 566 |  |  | $ | 2,031 |  |
| Additions charged against revenue |  | 17,371 |  |  | 5,122 |  |  | 818 |  |
| Consumption |  | (11,265 | ) |  | (4,371 | ) |  | (2,283 | ) |
| Balance at the end of year |  | $ | 7,423 |  |  | $ | 1,317 |  |  | $ | 566 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001596532-18-000018:notes:276]
Accrued liabilities consist of the following (in thousands):

[0001596532-18-000018:notes:277]
|  |  | December 31, |
|  |  | 2017 |  | 2016 |
| Accrued payroll related costs |  | $ | 56,626 |  |  | $ | 52,854 |  |
| Accrued manufacturing costs |  | 35,703 |  |  | 14,824 |  |
| Accrued product development costs |  | 21,201 |  |  | 7,103 |  |
| Accrued warranty costs |  | 7,415 |  |  | 6,744 |  |
| Accrued professional fees |  | 7,086 |  |  | 6,829 |  |
| Accrued taxes |  | 794 |  |  | 1,098 |  |
| Other |  | 5,002 |  |  | 1,499 |  |
| Total accrued liabilities |  | $ | 133,827 |  |  | $ | 90,951 |  |


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001596532-18-000018:notes:278]
The following table summarizes the unrealized gains and losses and fair value of our available-for-sale marketable securities (in thousands):

[0001596532-18-000018:notes:279]
|  |  | December 31, 2017 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 11,924 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,924 |  |
| U.S. government notes |  | 137,025 |  |  | — |  |  | (378 | ) |  | 136,647 |  |
| Corporate bonds |  | 313,080 |  |  | 20 |  |  | (616 | ) |  | 312,484 |  |
| Agency securities |  | 215,923 |  |  | 2 |  |  | (617 | ) |  | 215,308 |  |
| Total marketable securities |  | $ | 677,952 |  |  | $ | 22 |  |  | $ | (1,611 | ) |  | $ | 676,363 |  |

[0001596532-18-000018:notes:280]
|  |  | December 31, 2016 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 5,962 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,962 |  |
| U.S. government notes |  | 110,945 |  |  | 5 |  |  | (194 | ) |  | 110,756 |  |
| Corporate bonds |  | 183,455 |  |  | 109 |  |  | (372 | ) |  | 183,192 |  |
| Total marketable securities |  | $ | 300,362 |  |  | $ | 114 |  |  | $ | (566 | ) |  | $ | 299,910 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001596532-18-000018:notes:281]
Inventories consist of the following (in thousands):

[0001596532-18-000018:notes:282]
|  |  | December 31, |
|  |  | 2017 |  | 2016 |
| Raw materials |  | $ | 69,673 |  |  | $ | 99,190 |  |
| Finished goods |  | 236,525 |  |  | 137,300 |  |
| Total inventories |  | $ | 306,198 |  |  | $ | 236,490 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001596532-18-000018:notes:283]
Prepaid expenses and other current assets consists of the following (in thousands):

[0001596532-18-000018:notes:284]
|  |  | December 31, |
|  |  | 2017 |  | 2016 |
| Inventory deposit |  | $ | 34,141 |  |  | $ | 60,315 |  |
| Prepaid income taxes |  | 38,134 |  |  | 17,383 |  |
| Other current assets |  | 96,215 |  |  | 79,140 |  |
| Other prepaid expenses and deposits |  | 8,840 |  |  | 11,846 |  |
| Total prepaid expenses and other current assets |  | $ | 177,330 |  |  | $ | 168,684 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001596532-18-000018:notes:285]
The following table summarizes the activity related to our accrued liability for estimated future warranty costs (in thousands):

[0001596532-18-000018:notes:286]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |
| Warranty accrual, beginning of year |  | $ | 6,744 |  |  | $ | 4,718 |  |
| Liabilities accrued for warranties issued during the year |  | 5,542 |  |  | 5,421 |  |
| Warranty costs incurred during the year |  | (4,871 | ) |  | (3,395 | ) |
| Warranty accrual, end of year |  | $ | 7,415 |  |  | $ | 6,744 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001596532-18-000018:notes:287]
The following table represents revenue based on the customer’s location, as determined by the customer’s shipping address (in thousands):

[0001596532-18-000018:notes:288]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| United States |  | $ | 1,174,705 |  |  | $ | 862,352 |  |  | $ | 634,413 |  |
| Other Americas |  | 17,584 |  |  | 12,388 |  |  | 12,506 |  |
| Europe, Middle East and Africa |  | 299,547 |  |  | 168,789 |  |  | 128,400 |  |
| Asia Pacific |  | 154,350 |  |  | 85,638 |  |  | 62,272 |  |
| Total revenue |  | $ | 1,646,186 |  |  | $ | 1,129,167 |  |  | $ | 837,591 |  |

[0001596532-18-000018:notes:289]
Long lived assets, excluding intercompany receivables, investments in subsidiaries, privately held equity investments and deferred tax assets, net by location are summarized as follows (in thousands):

[0001596532-18-000018:notes:290]
|  |  | December 31, |
|  |  | 2017 |  | 2016 |
| United States |  | $ | 69,128 |  |  | $ | 69,352 |  |
| International |  | 5,151 |  |  | 7,609 |  |
| Total |  | $ | 74,279 |  |  | $ | 76,961 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-18-000018:notes:291]
9.    Segment Information

[0001596532-18-000018:notes:292]
We have determined that we operate as one reportable segment. The following table represents revenue based on the customer’s location, as determined by the customer’s shipping address (in thousands):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-18-000018:notes:293]
3.    Balance Sheet Components

[0001596532-18-000018:notes:294]
We did not realize any other-than-temporary losses on our marketable securities for the year ended December 31, 2017 and 2016. We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. As interest rates increase, those marketable securities purchased at a lower yield show a mark-to-market unrealized loss. The unrealized losses are due primarily to changes in credit spreads and interest rates. We expect to realize the full value of these investments upon maturity or sale and therefore, we do not consider any of our marketable securities to be other-than-temporarily impaired as of December 31, 2017.

[0001596532-18-000018:notes:295]
As of December 31, 2017, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale investments, by remaining contractual maturity, are as follows (in thousands):

[0001596532-18-000018:notes:296]
The weighted average remaining duration of our current marketable securities is approximately 0.9 years as of December 31, 2017.  As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the consolidated balance sheets.

[0001596532-18-000018:notes:297]
The increase in activity in 2017 primarily relates to channel rebates that we began to offer in the current year.

[0001596532-18-000018:notes:298]
Inventories

[0001596532-18-000018:notes:299]
Prepaid Expenses and Other Current Assets

[0001596532-18-000018:notes:300]
Property and Equipment, net

[0001596532-18-000018:notes:301]
Depreciation expense was $20.2 million, $19.4 million and $13.4 million for the years ended December 31, 2017, 2016 and 2015, respectively.

[0001596532-18-000018:notes:302]
Accrued Liabilities

[0001596532-18-000018:notes:303]
Warranty Accrual

[0001596532-18-000018:notes:304]
There were no significant specific product warranty reserves recorded for the years ended December 31, 2017 or 2016.
