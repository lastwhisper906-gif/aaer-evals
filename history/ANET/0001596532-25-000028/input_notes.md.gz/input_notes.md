# ANET notes — 0001596532-25-000028


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001596532-25-000028:notes:1]
Portions of the registrant’s definitive Proxy Statement relating to its 2025 Annual Meeting of Stockholders to be filed pursuant to Regulation 14A within 120 days after the registrant’s fiscal year end of December 31, 2024 are incorporated by reference into Part III of this Annual Report on Form 10-K.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001596532-25-000028:notes:2]
We have developed and implemented a cybersecurity risk management program intended to protect the confidentiality, integrity, and availability of our critical systems and information. In addition, our Legal and Information Technology (IT)/Information Security (IS) teams work together to oversee our compliance with applicable laws and regulations and coordinate with subject matter experts throughout our business to identify, monitor and mitigate risk including information security risk management and cyber defense programs.

[0001596532-25-000028:notes:3]
Our cybersecurity risk management program is aligned with our overall enterprise risk management programs and shares common methodologies, reporting channels and governance processes that apply across the enterprise risk management programs to other legal, compliance, strategic, operational, and financial risk areas.

[0001596532-25-000028:notes:4]
Our cybersecurity risk management program includes:

[0001596532-25-000028:notes:5]
•an information security management systems policy, including a business continuity policy, acceptable use and physical security policies, and an incident response policy and plan for responding to cybersecurity incidents, among others;

[0001596532-25-000028:notes:6]
•risk assessments designed to help identify material cybersecurity risks to our critical systems, information, products, services, and our broader enterprise IT environment;

[0001596532-25-000028:notes:7]
•a security team principally responsible for managing (1) our cybersecurity risk assessment processes, (2) our security controls, and (3) our response to cybersecurity incidents;

[0001596532-25-000028:notes:8]
•the use of internal audit teams and external service providers, where appropriate, to assess, test or otherwise assist with aspects of our security controls;

[0001596532-25-000028:notes:9]
•cybersecurity awareness, data protection, and privacy training of our employees, incident response personnel, and senior management; and

[0001596532-25-000028:notes:10]
•a vetting and management process for third party service providers, suppliers, and vendors

[0001596532-25-000028:notes:11]
Through this program, our IT/IS team identifies and executes improvements based upon its own assessments, public cybersecurity events and the identification of new risks by third parties, including our external cybersecurity consultants. As part of these continuous improvement efforts, there may be times when the IT/IS team prioritizes certain cybersecurity fixes or program improvements over other measures, which could lead to new known or unknown risks being identified on an ongoing basis. Cybersecurity threat actors are often highly sophisticated and nimble in their attacks. Despite these efforts, we cannot guarantee that our priorities and efforts will prevent any cybersecurity incident from happening.

[0001596532-25-000028:notes:12]
We also engage in periodic testing programs, using both internal assets and external consultants, including penetration testing, and incorporate multiple layers of physical, logical and written controls into our cybersecurity risk management program. Our IT/IS team leverages centralized identity management, encryption configurations and technologies on the systems, devices, and third-party connections used in our operations.

[0001596532-25-000028:notes:13]
We also maintain cyber liability insurance coverage. While we currently hold such coverage, we cannot be certain that our insurance coverage will be adequate for liabilities actually incurred, that insurance will continue to be available to us on economically reasonable terms, or at all, or that any future claim will not be excluded or otherwise be denied coverage by any insurer.

[0001596532-25-000028:notes:14]
As of the date of this report, we have not identified any risks from cybersecurity threats, including as a result of any previous cybersecurity incidents, that we believe have, or are likely to, materially affect us, our business strategy, results of operations, or financial condition. For additional information concerning risks from cybersecurity threats, please refer to Item 1A, “Risk Factors,” in this annual report on Form 10-K, including the risk factors in the category entitled, “Risks Related to Cybersecurity and Data Privacy”.


## cyd:CybersecurityRiskManagementPositionsOrCommitteesResponsibleTextBlock

[0001596532-25-000028:notes:15]
Our Board considers cybersecurity risk as part of its risk oversight function and has delegated to the Audit Committee (Committee) oversight of cybersecurity and other information technology risks. The Committee oversees management’s implementation of our cybersecurity risk management program. The Committee receives quarterly reports from our Vice

[0001596532-25-000028:notes:16]
President and Chief Information Security Officer (CISO), in conjunction with other senior managers, on cybersecurity risks. In addition, these managers update the Committee, as necessary, regarding any material cybersecurity incidents, as well as incidents with lesser impact potential. The Committee reports to the full Board on cybersecurity no less frequently than once annually. The full Board also receives briefings from management on our cyber risk management program on a periodic basis.


## cyd:CybersecurityRiskRoleOfManagementTextBlock

[0001596532-25-000028:notes:17]
Our IS team, led by one of our Vice Presidents who also serves as our CISO, is responsible for assessing and managing risks from cybersecurity threats. The IS team has primary responsibility for our overall cybersecurity risk management program and supervises both our internal cybersecurity personnel and our external cybersecurity consultants.


## cyd:CybersecurityRiskManagementExpertiseOfManagementResponsibleTextBlock

[0001596532-25-000028:notes:18]
Our CISO has over 20 years of experience in the cybersecurity industry and has been instrumental in building several key security technologies, viz. Network Intrusion Prevention Systems (NIPS), Host Intrusion Prevention Systems (HIPS), Web Application Firewalls (WAF), Whitelisting, Endpoint/Server Host Monitoring (EDR) and Virtualization Based Security (VBS). Previously, our CISO served in senior executive and technical leadership roles in several security companies. In addition, our CISO has experience as a pen-tester and has in-depth knowledge of operating system, networking and security products. Our CISO holds a bachelor’s degree in computer science and a master’s degree in software systems. In addition, our IS team includes over 20 members each with experience in network security related roles, with the two IS leads reporting to our CISO each having more than 20 years of security experience.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-25-000028:notes:19]
Organization and Summary of Significant Accounting Policies
Organization

[0001596532-25-000028:notes:20]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus and routing environments. Our cloud networking solutions consist of our EOS, a set of network applications and our Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-25-000028:notes:21]
Basis of Presentation and Principles of Consolidation

[0001596532-25-000028:notes:22]
The accompanying consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and are prepared in accordance with accounting principles generally accepted in the United States ("GAAP"). All significant intercompany accounts and transactions have been eliminated.

[0001596532-25-000028:notes:23]
On November 7, 2024, the Company announced a four-for-one forward stock split ("Stock Split") of the Company’s common stock that was effected through the filing of an amendment to the Company's Amended and Restated Certificate of Incorporation ("Amendment") on December 3, 2024. The Stock Split proportionately increased the authorized shares of common stock, and all share and per share amounts presented herein have been retroactively adjusted to reflect the impact of the Stock Split.

[0001596532-25-000028:notes:24]
Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.

[0001596532-25-000028:notes:25]
Use of Estimates

[0001596532-25-000028:notes:26]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, valuation of inventory and contract manufacturer/supplier liabilities, accounting for income taxes, including the recognition of deferred tax assets and liabilities, valuation allowance on deferred tax assets and reserves for uncertain tax positions, revenue recognition and deferred revenue, valuation of goodwill and acquisition-related intangible assets, estimate of useful lives of long-lived assets including intangible assets, and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust these estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from these estimates.

[0001596532-25-000028:notes:27]
Concentrations of Business and Credit Risk

[0001596532-25-000028:notes:28]
We work closely with third-party contract manufacturers to manufacture our products. As of December 31, 2024, we had four primary contract manufacturing partners, who provided the vast majority of our electronic manufacturing services. Our contract manufacturing partners deliver our products to our third-party direct fulfillment facilities. We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers. Our products rely on key components, including certain integrated circuit components and power supplies, some of which our contract manufacturing partners purchase on our behalf from a limited number of suppliers, including certain sole-source providers. We generally do not have guaranteed supply contracts with our component suppliers, and our manufacturing partners could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, or if we are unable to obtain alternative sources for these components, sales of our products could be delayed or halted entirely, or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.

[0001596532-25-000028:notes:29]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, marketable securities, and accounts receivable. Our cash equivalents and marketable securities are invested in high

[0001596532-25-000028:notes:30]
quality financial instruments with banks and financial institutions. Such deposits may be in excess of insured limits provided on such deposits.

[0001596532-25-000028:notes:31]
Our accounts receivable are unsecured and represent amounts due to us based on contractual obligations of our customers. We mitigate credit risk with respect to accounts receivable by performing ongoing credit evaluations of our customers to assess the probability of collection based on a number of factors, including past transaction experience with the customer, evaluation of their credit history, the credit limits extended, review of the invoicing terms of the arrangement, and current economic conditions that may affect a customer’s ability to pay. In situations where a customer may be thinly capitalized and we have limited payment history with it, we will either establish a small credit limit or require it to prepay its purchases. We generally do not require our customers to provide collateral to support accounts receivable. We have recorded an allowance for doubtful accounts for accounts receivables that we have determined to be uncollectible. We mitigate credit risk with respect to accounts receivables by performing ongoing credit evaluations of the borrower to assess the probability of collecting all amounts due to us under the existing contractual terms.

[0001596532-25-000028:notes:32]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators and OEM partners, and in conjunction with various technology partners.  Significant customers are those that represent more than 10% of our total net revenue during the period or net accounts receivable balance at each respective balance sheet date. As of December 31, 2024, we had two resellers who represented 26% and 24% of total accounts receivable. As of December 31, 2023, we had two resellers who represented 28% and 11% of total accounts receivable.  There were two end customers who represented more than 10% of our total revenue for the years ended 2024, 2023 and 2022. Sales to one end customer represented 15%, 21% and 26% of our total revenue, and sales to the other end customer represented 20%, 18% and 16% of our total revenue for the years ended 2024, 2023 and 2022, respectively.

[0001596532-25-000028:notes:33]
Cash and Cash Equivalents

[0001596532-25-000028:notes:34]
We consider all highly liquid investments with original or remaining maturities of three months or less at the time of purchase to be cash equivalents. Cash and cash equivalents consist of cash on deposit with various financial institutions and highly liquid investments in money market funds. Interest is accrued as earned.

[0001596532-25-000028:notes:35]
Marketable Securities

[0001596532-25-000028:notes:36]
We classify all highly liquid investments in debt securities with maturities of greater than three months at the date of purchase as marketable securities. We have classified and accounted for our marketable debt securities as available-for-sale. We determine the appropriate classification of these investments at the time of purchase and reevaluate such designation at each balance sheet date. After consideration of our risk versus reward objectives, as well as our liquidity requirements, we may hold or sell these securities prior to their stated maturities. As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying consolidated balance sheets. We carry these securities at fair value. For marketable debt securities, we report the unrealized gains and losses, net of taxes, as a component of stockholders’ equity. We determine any realized gains or losses on the sale of marketable securities using the specific identification method, and record such gains and losses in other income, net in the accompanying consolidated statements of income.

[0001596532-25-000028:notes:37]
For our debt securities in an unrealized loss position, we determine whether a credit loss exists by considering, among other factors, current market conditions, credit quality of debt issuers, any changes to the rating of the security by a rating agency, and the extent to which fair value is less than cost. We would recognize an allowance for credit losses, up to the amount of the unrealized loss when appropriate, and write down the amortized cost basis of the investment if it is more likely than not we will be required to sell or we intend to sell the investment before recovery of its amortized cost basis.

[0001596532-25-000028:notes:38]
Accounts Receivable

[0001596532-25-000028:notes:39]
Accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts. We estimate our allowance for doubtful accounts based upon the collectability of the receivables in light of historical trends, reasonable and supportable information of our customers' economic conditions that may affect our customers’ ability to pay, and prevailing economic conditions. This evaluation is done in order to identify issues that may impact the collectability of receivables and related estimated required allowance. Revisions to the allowance are recorded as an adjustment to bad debt expense. After appropriate collection efforts are exhausted, specific accounts receivable deemed to be uncollectible are charged against the allowance in the period they are deemed uncollectible. Recoveries of accounts receivable previously written-off are recorded as credits to bad debt expense.

[0001596532-25-000028:notes:40]
Fair Value Measurements

[0001596532-25-000028:notes:41]
Fair value is defined as the exchange price that would be received for an asset or an exit price that would be paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. These assets and liabilities include cash and cash equivalents, marketable securities, accounts receivable, accounts payable, and accrued liabilities. Cash equivalents, accounts receivable, accounts payable and accrued liabilities are stated at carrying values in our consolidated financial statements, which approximate their fair value due to the short-term nature of these instruments.

[0001596532-25-000028:notes:42]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value. We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs. The three-tiers of the fair value hierarchy are as follows:

[0001596532-25-000028:notes:43]
Level I—Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date;

[0001596532-25-000028:notes:44]
Level II—Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities; and

[0001596532-25-000028:notes:45]
Level III—Unobservable inputs that are supported by little or no market data for the related assets or liabilities and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.

[0001596532-25-000028:notes:46]
Foreign Currency

[0001596532-25-000028:notes:47]
The functional currency of our foreign subsidiaries is either the U.S. dollar or their local currency depending on the nature of the subsidiaries’ activities.

[0001596532-25-000028:notes:48]
Transaction re-measurement - Assets and liabilities denominated in a currency other than a subsidiary’s functional currency are re-measured into the subsidiary's functional currency using exchange rates in effect at the end of the reporting period, with gains and losses recorded in other income, net in the consolidated statements of income. To date, foreign currency transaction gains and losses and exchange rate fluctuations have not been material to our consolidated financial statements.

[0001596532-25-000028:notes:49]
Translation - Assets and liabilities of subsidiaries denominated in foreign functional currencies are translated into U.S. dollars at the closing exchange rate on the balance sheet date and equity-related balances are translated at historical exchange rates. Revenues, costs and expenses in foreign functional currencies are translated using average exchange rates that approximate those in effect during the period. Translation adjustments are recorded within accumulated other comprehensive income, a separate component of total stockholders’ equity.

[0001596532-25-000028:notes:50]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-25-000028:notes:51]
Inventories primarily consist of finished goods, including evaluation inventory held at customers or partners, and strategic components, primarily integrated circuits. Inventories are stated at the lower of cost (computed using the first-in, first-out method) and net realizable value. Evaluation inventory consists of new products and/or use cases at customer or partner sites for trial purposes. Title to the inventory remains with Arista during the trial period and invoicing occurs only upon completion of the trial period and when/if the products have been accepted by the customer.  Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory. We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value. For the years ended December 31, 2024, 2023 and 2022, we recorded charges of $267.2 million, $234.4 million and $71.4 million, respectively, within cost of product revenue for inventory write-downs.

[0001596532-25-000028:notes:52]
Our contract manufacturers procure components and assemble products on our behalf and we procure strategic components from suppliers based on our forecasts. We record a liability and a corresponding charge for non-cancellable, non-returnable purchase commitments with our contract  manufacturers and suppliers for quantities in excess of our demand forecasts or that are considered obsolete due to manufacturing and engineering change orders resulting from design changes. For the years ended December 31, 2023 and 2022, we recorded charges of $113.0 million and $43.7 million, respectively, within cost of product revenue for such liabilities with our contract manufacturers and suppliers. For the year ended

[0001596532-25-000028:notes:53]
December 31, 2024, we recorded a credit of $74.3 million within cost of product revenue related to such liabilities, which was driven by a reduction in the liability due to the receipt of excess components that were previously reserved. We subsequently assessed the realizable value of such components upon inventory receipt.

[0001596532-25-000028:notes:54]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels.  In addition, when industry-wide supply chain shortages resulted in extended lead times for components, we were  required to extend the time horizon of our demand forecasts and increase our purchase commitments for long lead time components. As customer lead times reduce more broadly, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to shorter demand-planning horizons. Although the global supply chain has shown improvement, we have had to invest in inventory to address forecast uncertainty and we expect that our inventory and purchase commitments will remain volatile as we ramp new product introductions. There is, however, no guarantee that all suppliers will meet their commitments in the time frame committed or that actual customer demand will directly match our demand forecasts. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and/or outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer and supplier liabilities.

[0001596532-25-000028:notes:55]
Property and Equipment

[0001596532-25-000028:notes:56]
Property and equipment are stated at cost, less accumulated depreciation, except for land which is not depreciated. We capitalize any additions and improvements and expense maintenance and repairs as incurred. Depreciation is calculated using the straight-line method over the estimated useful lives of the related assets, generally three years. Our leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term.

[0001596532-25-000028:notes:57]
Leases

[0001596532-25-000028:notes:58]
We lease office space, data centers, and equipment under non-cancellable operating leases with various expiration dates through 2031. We determine if an arrangement contains a lease at inception. Operating leases are recorded as right-of-use (“ROU”) assets and lease liabilities, and are included in other assets and other current and non-current liabilities in our consolidated balance sheets. We do not have any finance leases in any of the periods presented.

[0001596532-25-000028:notes:59]
ROU assets and lease liabilities are recognized at the commencement date based on the present value of remaining lease payments over the lease term. The interest rate implicit in our operating leases is not readily available, and therefore, an incremental borrowing rate is estimated based on a hypothetical interest rate on a collateralized basis with similar terms, payments, and economic environments. ROU assets also include any prepaid lease payments and lease incentives.

[0001596532-25-000028:notes:60]
Our operating lease agreements may contain rent concession, rent escalation, and option to renew provisions. Lease expense is recognized on a straight-line basis over the lease term commencing on the date we have the right to use the leased property. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that the option will be exercised. In addition, certain of our operating lease agreements contain tenant improvement allowances from landlords. These allowances are accounted for as lease incentives and decrease our right-of-use asset and reduce lease expense over the lease term.

[0001596532-25-000028:notes:61]
Our lease agreements may contain lease and non-lease components, which are combined and accounted for as a single lease component. We also have elected to apply the short-term lease measurement and recognition exemption in which ROU assets and lease liabilities are not recognized for leases with terms of 12 months or less.

[0001596532-25-000028:notes:62]
Business Combinations

[0001596532-25-000028:notes:63]
We use the acquisition method to account for our business combinations in accordance with Accounting Standards Codification ("ASC") 805 - Business Combinations. We allocate the total fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the consideration transferred over the fair values of the assets acquired and liabilities assumed is recorded as goodwill. The results of operations of the acquired businesses are included in our consolidated financial statements from the date of acquisition. Acquisition-related transaction and restructuring costs are expensed as incurred.

[0001596532-25-000028:notes:64]
During the measurement period, which is not to exceed one year from the acquisition date, we may record adjustments to the acquired assets and liabilities assumed, with a corresponding offset to goodwill or the preliminary purchase price, to reflect new information obtained about facts and circumstances that existed as of the acquisition date. Upon the conclusion of the measurement period, any subsequent adjustments are recorded to earnings.

[0001596532-25-000028:notes:65]
Goodwill and Acquired Intangible Assets

[0001596532-25-000028:notes:66]
Goodwill represents the excess of the purchase price over the fair value of net assets acquired in a business combination. The Company has one reporting unit and tests goodwill for impairment at least annually in the fourth quarter or more frequently if indicators of potential impairment exist. We first perform a qualitative assessment to determine whether it is more likely than not that the fair value of our reporting unit is less than its carrying amount. If the reporting unit does not pass the qualitative assessment, a quantitative test is performed by comparing the fair value of our reporting unit with its carrying amount. We would recognize an impairment loss for the amount by which the carrying amount exceeds the fair value. There were no impairment charges in any of the periods presented in the consolidated financial statements. See Note 4. Acquisition, Goodwill and Acquisition-Related Intangible Assets for additional information.

[0001596532-25-000028:notes:67]
Acquired intangible assets are carried at cost less accumulated amortization. All acquired intangible assets have been determined to have definite lives and are amortized on a straight-line basis over their estimated useful lives, ranging from three to eight years. Acquired intangible assets are reviewed for impairment under the long-lived asset model described below. There were no impairment charges in any of the periods presented in the consolidated financial statements. See Note 4. Acquisition, Goodwill and Acquisition-Related Intangible Assets for additional information.

[0001596532-25-000028:notes:68]
Equity Investments in Privately-Held Companies

[0001596532-25-000028:notes:69]
Our equity investments in privately-held companies without readily determinable fair values are measured using the measurement alternative, defined by ASC 321 - Investments-Equity Securities as cost, less impairments, and remeasured based on observable price changes from orderly transactions of identical or similar securities of the same issuer. Any adjustments resulting from impairments and/or observable price changes are recorded within other income, net, in our consolidated statements of income. This election is reassessed each reporting period to determine whether investments in privately-held companies have a readily determinable fair value, in which case they would no longer be eligible for this election. The Company did not hold investments in privately-held companies whose fair value was readily determinable as of December 31, 2024 and 2023.

[0001596532-25-000028:notes:70]
Impairment of Long-Lived Assets and Investments in Privately-Held Companies

[0001596532-25-000028:notes:71]
The carrying amounts of our long-lived assets, including property and equipment, intangible assets, ROU assets and investments in privately-held companies, are periodically reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. Recoverability of these assets is measured by comparison of the carrying amount of each asset to the future undiscounted cash flows the asset is expected to generate over its remaining life. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. No impairment of any long-lived assets was identified for any of the periods presented in the consolidated financial statements.

[0001596532-25-000028:notes:72]
Loss Contingencies

[0001596532-25-000028:notes:73]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. In assessing loss contingencies, we use significant judgments and assumptions to estimate the likelihood of loss, impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. We record a provision for contingent losses when it is both probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. We record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements, and (ii) the range of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.

[0001596532-25-000028:notes:74]
Revenue Recognition

[0001596532-25-000028:notes:75]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with post-contract customer support (“PCS”). We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

[0001596532-25-000028:notes:76]
•Identification of the contract, or contracts, with a customer

[0001596532-25-000028:notes:77]
•Identification of the performance obligations in the contract

[0001596532-25-000028:notes:78]
•Determination of the transaction price

[0001596532-25-000028:notes:79]
•Allocation of the transaction price to the performance obligations in the contract

[0001596532-25-000028:notes:80]
•Recognition of revenue when (or as) we satisfy the performance obligation

[0001596532-25-000028:notes:81]
Post-Contract Customer Support ("PCS")

[0001596532-25-000028:notes:82]
PCS, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts. We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernible pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and address customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-25-000028:notes:83]
Contracts with Multiple Performance Obligations

[0001596532-25-000028:notes:84]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts that contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price ("SSP"). Judgment is required to determine the SSP for each distinct performance obligation. We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

[0001596532-25-000028:notes:85]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as gross margin, market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to product category, actual and expected volume, discounting policies, and customer vertical and size.

[0001596532-25-000028:notes:86]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We defer revenue recognition on customer contracts for new products or use cases, which contain customer-specified requirements that must be met prior to acceptance. We include some or all of an estimate of the related at-risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

[0001596532-25-000028:notes:87]
Most of our contracts with customers have standard payment terms of 30 to 90 days. We have determined our contracts generally do not include a significant financing component because the Company and the customer have specific business reasons other than financing for entering into such contracts. Specifically, both we and our customers seek to ensure the customer has a simplified way of purchasing Arista products and services.

[0001596532-25-000028:notes:88]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

[0001596532-25-000028:notes:89]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical return rates applied against

[0001596532-25-000028:notes:90]
current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-25-000028:notes:91]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

[0001596532-25-000028:notes:92]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

[0001596532-25-000028:notes:93]
We account for customer sales rebates as a reduction to revenue and accrue for such rebates based on the amount that is earned and expected to be claimed by customers.

[0001596532-25-000028:notes:94]
Contract Balances

[0001596532-25-000028:notes:95]
A contract asset is recognized when we have a contractual right to consideration for both completed and partially completed performance obligations that have not yet been invoiced. Contract assets are included in other current assets in the accompanying consolidated balance sheets.

[0001596532-25-000028:notes:96]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a contract that is cancellable. Contract liabilities are included in other current liabilities and other long-term liabilities in the accompanying consolidated balance sheets.

[0001596532-25-000028:notes:97]
Research and Development Expenses

[0001596532-25-000028:notes:98]
Costs related to the research, design and development of our products are charged to research and development expenses as incurred. Software development costs are capitalized beginning when a product’s technological feasibility has been established and ending when the product is available for general release to customers. Generally, our products are released soon after technological feasibility has been established. As a result, costs incurred subsequent to achieving technological feasibility have not been significant and accordingly, all software development costs have been expensed as incurred.

[0001596532-25-000028:notes:99]
Segment Reporting

[0001596532-25-000028:notes:100]
We develop, market and sell cloud networking solutions, which primarily consist of our switching and routing platforms and related network applications, and there are no segment managers who are held accountable for operations or operating results below the Company level. Our chief operating decision maker is our President, Chief Executive Officer and Chairperson of the Board, who reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance. Accordingly, we have determined that we operate as one reportable segment.

[0001596532-25-000028:notes:101]
Stock-Based Compensation

[0001596532-25-000028:notes:102]
Stock-based compensation cost for equity awards is measured at the grant-date fair value using appropriate valuation techniques and recognized as expense over the requisite service or performance period. We account for forfeitures when they occur.

[0001596532-25-000028:notes:103]
Stock-based compensation costs for stock options and restricted stock units ("RSUs") are recognized on a straight-line basis over the requisite service period, which is generally two to five years. The Company has granted RSUs that vest upon the satisfaction of both service-based and performance-based conditions ("PRSUs"). The service-based condition for these awards is generally satisfied over one to four years. The performance-based conditions are satisfied upon achieving specified performance targets, such as financial or operating metrics. We record stock-based compensation expense for performance-based equity awards on an accelerated attribution method over the requisite service period, and only if performance-based conditions are considered probable to be satisfied.

[0001596532-25-000028:notes:104]
See Note 6. Stockholders' Equity and Stock-Based Compensation for a detailed discussion of the Company’s stock plans, assumptions to the valuation techniques, and stock-based compensation expense.

[0001596532-25-000028:notes:105]
Income Taxes

[0001596532-25-000028:notes:106]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-25-000028:notes:107]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-25-000028:notes:108]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-25-000028:notes:109]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.

[0001596532-25-000028:notes:110]
The U.S. tax rules require U.S. tax on foreign earnings, known as global intangible low taxed income (“GILTI”). Under U.S. GAAP, we are allowed to make an accounting policy choice of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes (the “deferred method”). We selected the deferred method of accounting and recorded the associated basis differences anticipated to influence prospective GILTI calculations.

[0001596532-25-000028:notes:111]
Recently Adopted Accounting Pronouncements

[0001596532-25-000028:notes:112]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280)-Improvements to Reportable Segment Disclosures. The ASU requires that an entity disclose significant segment expenses impacting profit and loss that are regularly provided to the chief operating decision maker. The update is required to be applied retrospectively to prior periods presented, based on the significant segment expense categories identified and disclosed in the period of adoption. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2023. Early adoption is permitted. We have adopted ASU 2023-07 for the year ended December 31, 2024. The adoption of this new standard did not have a material impact on our consolidated financial statements. For more information regarding the adoption, see Note 9, Segment and Geographical Information for the inclusion of the new required disclosures.

[0001596532-25-000028:notes:113]
Recent Accounting Pronouncements Not Yet Effective

[0001596532-25-000028:notes:114]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2024. Early adoption is permitted for annual financial statements that have not yet been issued. The amendments should be applied on a prospective basis although retrospective application is permitted. we have

[0001596532-25-000028:notes:115]
not early adopted ASU 2023-09 for December 31, 2024. We are currently evaluating the impact of future adoption on our financial disclosures.

[0001596532-25-000028:notes:116]
In November 2024, the FASB issued ASU No. 2024-03, Disaggregation of Income Statement Expenses (Subtopic 220-40). The ASU requires the disaggregated disclosure of specific expense categories, including purchases of inventory, employee compensation, depreciation, and amortization, within relevant income statement captions. This ASU also requires disclosure of the total amount of selling expenses along with the definition of selling expenses. The ASU is effective for annual periods beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027. Adoption of this ASU can either be applied prospectively to consolidated financial statements issued for reporting periods after the effective date of this ASU or retrospectively to any or all prior periods presented in the consolidated financial statements. Early adoption is also permitted. This ASU will likely result in the required additional disclosures being included in our consolidated financial statements, once adopted. We are currently evaluating the provisions of this ASU.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-25-000028:notes:117]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280)-Improvements to Reportable Segment Disclosures. The ASU requires that an entity disclose significant segment expenses impacting profit and loss that are regularly provided to the chief operating decision maker. The update is required to be applied retrospectively to prior periods presented, based on the significant segment expense categories identified and disclosed in the period of adoption. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2023. Early adoption is permitted. We have adopted ASU 2023-07 for the year ended December 31, 2024. The adoption of this new standard did not have a material impact on our consolidated financial statements.
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2024. Early adoption is permitted for annual financial statements that have not yet been issued. The amendments should be applied on a prospective basis although retrospective application is permitted. we have


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-25-000028:notes:118]
Fair Value Measurements
Assets measured at fair values on a recurring basis

[0001596532-25-000028:notes:119]
We measure and report our cash equivalents, restricted cash, and available-for-sale marketable securities at fair value on a recurring basis. The following tables summarize the fair value of these financial assets by significant investment category and their levels within the fair value hierarchy (in thousands):

[0001596532-25-000028:notes:120]
|  |  | December 31, 2024 |  | December 31, 2023 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,707,513 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,707,513 |  |  | $ | 1,015,705 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,015,705 |  |
| Commercial paper |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,999 |  |  | — |  |  | 1,999 |  |
| Agency securities |  | — |  |  | 3,000 |  |  | — |  |  | 3,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government notes |  | 31,366 |  |  | — |  |  | — |  |  | 31,366 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | 1,738,879 |  |  | 3,000 |  |  | — |  |  | 1,741,879 |  |  | 1,015,705 |  |  | 1,999 |  |  | — |  |  | 1,017,704 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 48,815 |  |  | — |  |  | 48,815 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposits (1) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5,000 |  |  | — |  |  | 5,000 |  |
| U.S. government notes |  | 1,921,490 |  |  | — |  |  | — |  |  | 1,921,490 |  |  | 1,044,859 |  |  | — |  |  | — |  |  | 1,044,859 |  |
| Corporate bonds |  | — |  |  | 2,593,547 |  |  | — |  |  | 2,593,547 |  |  | — |  |  | 1,362,124 |  |  | — |  |  | 1,362,124 |  |
| Agency securities |  | — |  |  | 977,264 |  |  | — |  |  | 977,264 |  |  | — |  |  | 657,379 |  |  | — |  |  | 657,379 |  |
|  |  | 1,921,490 |  |  | 3,619,626 |  |  | — |  |  | 5,541,116 |  |  | 1,044,859 |  |  | 2,024,503 |  |  | — |  |  | 3,069,362 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted cash |  | 1,411 |  |  | — |  |  | — |  |  | 1,411 |  |  | 858 |  |  | — |  |  | — |  |  | 858 |  |
| Total Financial Assets |  | $ | 3,661,780 |  |  | $ | 3,622,626 |  |  | $ | — |  |  | $ | 7,284,406 |  |  | $ | 2,061,422 |  |  | $ | 2,026,502 |  |  | $ | — |  |  | $ | 4,087,924 |  |

[0001596532-25-000028:notes:121]
______________________________________

[0001596532-25-000028:notes:122]
(1) As of December 31, 2023, all of our certificates of deposits were domestic deposits.

[0001596532-25-000028:notes:123]
During the year ended on December 31, 2024, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-25-000028:notes:124]
The following table summarizes the amortized cost, unrealized gains and losses, and fair value of our debt securities measured at fair value on a recurring basis (in thousands):

[0001596532-25-000028:notes:125]
|  |  | December 31, 2024 |  | December 31, 2023 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 48,815 |  |  | $ | — |  |  | $ | — |  |  | $ | 48,815 |  |  | $ | 1,999 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,999 |  |
| U.S. government |  | 1,954,733 |  |  | 2,739 |  |  | (4,616) |  |  | 1,952,856 |  |  | 1,043,445 |  |  | 2,874 |  |  | (1,460) |  |  | 1,044,859 |  |
| Corporate bonds |  | 2,595,682 |  |  | 4,356 |  |  | (6,491) |  |  | 2,593,547 |  |  | 1,361,132 |  |  | 2,810 |  |  | (1,818) |  |  | 1,362,124 |  |
| Agency securities |  | 981,041 |  |  | 1,641 |  |  | (2,418) |  |  | 980,264 |  |  | 657,118 |  |  | 1,143 |  |  | (882) |  |  | 657,379 |  |
| Total |  | $ | 5,580,271 |  |  | $ | 8,736 |  |  | $ | (13,525) |  |  | $ | 5,575,482 |  |  | $ | 3,063,694 |  |  | $ | 6,827 |  |  | $ | (4,160) |  |  | $ | 3,066,361 |  |

[0001596532-25-000028:notes:126]
For debt securities in unrealized loss positions, it is not likely that we will be required to sell such securities before recovery of their amortized cost basis nor do we have the intent to sell such securities before maturity; we invest in debt securities that have maximum maturities of three years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. Given the short-term and conservative nature of our portfolio, the unrealized losses are not subject to credit risk; therefore, we did not recognize any credit losses or non-credit-related impairments related to our available-for-sale marketable debt securities for the years ended December 31, 2024, December 31, 2023 and December 31, 2022. All unrealized losses were recognized in other comprehensive income (loss). Realized losses were immaterial for the years ended December 31, 2024, December 31, 2023 and December 31, 2022.

[0001596532-25-000028:notes:127]
The following table is an analysis of our debt securities in unrealized loss positions (in thousands):

[0001596532-25-000028:notes:128]
|  |  | December 31, 2024 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 771,014 |  |  | $ | (4,598) |  |  | $ | 61,043 |  |  | $ | (18) |  |  | $ | 832,057 |  |  | $ | (4,616) |  |
| Corporate bonds |  | 1,027,448 |  |  | (6,463) |  |  | 62,047 |  |  | (28) |  |  | 1,089,495 |  |  | (6,491) |  |
| Agency securities |  | 500,464 |  |  | (2,418) |  |  | 9,500 |  |  | — |  |  | 509,964 |  |  | (2,418) |  |
| Total |  | $ | 2,298,926 |  |  | $ | (13,479) |  |  | $ | 132,590 |  |  | $ | (46) |  |  | $ | 2,431,516 |  |  | $ | (13,525) |  |

[0001596532-25-000028:notes:129]
As of December 31, 2024, we had no marketable debt securities with contractual maturities that exceed 36 months. The fair values of marketable debt securities, by remaining contractual maturities, are as follows (in thousands):

[0001596532-25-000028:notes:130]
|  |  | December 31, 2024 |
| Due in 1 year or less |  | $ | 2,749,020 |  |
| Due in 1 year through 3 years |  | 2,792,096 |  |
| Total marketable securities |  | $ | 5,541,116 |  |

[0001596532-25-000028:notes:131]
The weighted-average remaining duration of our marketable debt securities is approximately 1.1 years as of December 31, 2024.

[0001596532-25-000028:notes:132]
Assets measured at fair value on a non-recurring basis

[0001596532-25-000028:notes:133]
Non-Marketable Equity Securities

[0001596532-25-000028:notes:134]
We have non-marketable equity securities in privately-held companies that do not have readily-determinable fair values. Their initial cost is adjusted to fair value on a non-recurring basis based on observable price changes from orderly transactions of identical or similar securities of the same issuer, or for impairment. These investments are classified within Level III of the fair value hierarchy as we estimate the value based on valuation methods using the observable transaction price at the transaction date and other significant unobservable inputs, such as volatility, rights, and obligations related to these securities. In addition, the valuation requires management judgment due to the absence of market price and lack of liquidity.

[0001596532-25-000028:notes:135]
We did not record any realized gains for our non-marketable equity securities during the three years ended December 31, 2024, 2023 and 2022. We recorded immaterial amounts of unrealized gains, unrealized and realized losses during the three years ended December 31, 2024, 2023 and 2022. The unrealized gains were recorded on investments that were re-measured to fair value as of the date observable transactions occurred. We evaluate our non-marketable equity securities for impairment at each reporting period via a qualitative assessment with various potential impairment indicators, including, but not limited to, an assessment of a significant adverse change in the economic environment, significant adverse changes in the general market condition of the geographies and industries in which our investees operate, and other publicly-available information that may affect the value of the non-marketable equity securities.

[0001596532-25-000028:notes:136]
The following table summarizes the activity related to our non-marketable equity securities as of December 31, 2024 and December 31, 2023 (in thousands):

[0001596532-25-000028:notes:137]
|  |  | December 31, 2024 |  | December 31, 2023 |
| Cost of investments |  | $ | 38,284 |  |  | $ | 31,656 |  |
| Cumulative impairment and downward adjustments |  | — |  |  | — |  |
| Cumulative upward adjustments |  | 43,032 |  |  | 30,632 |  |
| Carrying amount of investments (included in other assets) |  | $ | 81,316 |  |  | $ | 62,288 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-25-000028:notes:138]
The following tables summarize the fair value of these financial assets by significant investment category and their levels within the fair value hierarchy (in thousands):

[0001596532-25-000028:notes:139]
(1) As of December 31, 2023, all of our certificates of deposits were domestic deposits.
The following table summarizes the amortized cost, unrealized gains and losses, and fair value of our debt securities measured at fair value on a recurring basis (in thousands):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-25-000028:notes:140]
Financial Statements Details
Inventories

[0001596532-25-000028:notes:141]
Inventories consist of the following (in thousands):

[0001596532-25-000028:notes:142]
|  |  | December 31, |
|  |  | 2024 |  | 2023 |
| Raw materials |  | $ | 565,379 |  |  | $ | 930,777 |  |
| Finished goods(1) |  | 1,269,193 |  |  | 1,014,403 |  |
| Total inventories |  | $ | 1,834,572 |  |  | $ | 1,945,180 |  |

[0001596532-25-000028:notes:143]
(1) The balance as of December 31, 2024 includes evaluation inventory held at customers or partners of $422.1 million. Evaluation inventory as of December 31, 2023 was not material.

[0001596532-25-000028:notes:144]
Property and Equipment, net

[0001596532-25-000028:notes:145]
Property and equipment, net consists of the following (in thousands):

[0001596532-25-000028:notes:146]
|  |  | December 31, |
|  |  | 2024 |  | 2023 |
| Land |  | $ | 47,189 |  |  | $ | 44,645 |  |
| Equipment and machinery |  | 160,673 |  |  | 144,850 |  |
| Computer hardware and software |  | 63,941 |  |  | 57,761 |  |
| Furniture and fixtures |  | 3,526 |  |  | 3,576 |  |
| Leasehold improvements |  | 34,712 |  |  | 34,584 |  |
| Construction-in-process |  | 8,209 |  |  | 4,242 |  |
| Property and equipment, gross |  | 318,250 |  |  | 289,658 |  |
| Less: accumulated depreciation |  | (219,405) |  |  | (188,078) |  |
| Property and equipment, net |  | $ | 98,845 |  |  | $ | 101,580 |  |

[0001596532-25-000028:notes:147]
Depreciation expense was $34.0 million, $31.7 million and $25.6 million for the years ended December 31, 2024, 2023 and 2022, respectively.

[0001596532-25-000028:notes:148]
Accrued Liabilities

[0001596532-25-000028:notes:149]
Accrued liabilities consist of the following (in thousands):

[0001596532-25-000028:notes:150]
|  |  | December 31, |
|  |  | 2024 |  | 2023 |
| Accrued compensation-related costs |  | $ | 147,847 |  |  | $ | 134,225 |  |
| Supplier liability |  | 63,786 |  |  | 167,878 |  |
| Accrued manufacturing costs |  | 110,169 |  |  | 61,491 |  |
| Other |  | 113,475 |  |  | 43,708 |  |
| Total accrued liabilities |  | $ | 435,277 |  |  | $ | 407,302 |  |

[0001596532-25-000028:notes:151]
Contract Liabilities, Deferred Revenue and Other Performance Obligations

[0001596532-25-000028:notes:152]
Contract Liabilities

[0001596532-25-000028:notes:153]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a cancellable contract. The following table summarizes the activity related to our contract liabilities (in thousands):

[0001596532-25-000028:notes:154]
|  |  | Year Ended December 31, |
|  |  | 2024 |  | 2023 |
| Contract liabilities, beginning balance |  | $ | 133,239 |  |  | $ | 103,448 |  |
| Less: Revenue recognized from beginning balance |  | (58,300) |  |  | (43,286) |  |
| Less: Beginning balance reclassified to deferred revenue |  | (3,772) |  |  | (3,185) |  |
| Add: Contract liabilities recognized |  | 89,623 |  |  | 76,262 |  |
| Contract liabilities, ending balance |  | $ | 160,790 |  |  | $ | 133,239 |  |

[0001596532-25-000028:notes:155]
As of December 31, 2024 and 2023, $65.7 million and $59.2 million, respectively, of our contract liabilities were recorded within other current liabilities with the remaining balance recorded within other long-term liabilities in the accompanying consolidated balance sheets.

[0001596532-25-000028:notes:156]
Deferred Revenue

[0001596532-25-000028:notes:157]
Deferred revenue is comprised mainly of unearned service revenue related to annual and multi-year PCS contracts, and product deferrals related to contracts with acceptance clauses. The following table summarizes the activity related to our deferred revenue (in thousands):

[0001596532-25-000028:notes:158]
|  |  | Year Ended December 31, |
|  |  | 2024 |  | 2023 |
| Deferred revenue, beginning balance |  | $ | 1,506,204 |  |  | $ | 1,041,246 |  |
| Less: Revenue recognized from beginning balance |  | (860,187) |  |  | (615,681) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 2,145,398 |  |  | 1,080,639 |  |
| Deferred revenue, ending balance |  | $ | 2,791,415 |  |  | $ | 1,506,204 |  |

[0001596532-25-000028:notes:159]
Other Performance Obligations

[0001596532-25-000028:notes:160]
Other performance obligations totaling $450.4 million as of December 31, 2024 include unbilled multi-year PCS and service contract amounts of $388.8 million and $61.6 million of binding contractual agreements with certain customers that are primarily related to future product shipments.

[0001596532-25-000028:notes:161]
Revenue from Total Remaining Performance Obligations

[0001596532-25-000028:notes:162]
Total revenue from our contract liabilities, deferred revenue and other performance obligations that is expected to be recognized in future periods was $3.4 billion as of December 31, 2024. Approximately 85% of this future revenue is expected to be recognized over the next two years and the remaining 15% is expected to be recognized during the third to the fifth year.

[0001596532-25-000028:notes:163]
Other Income, Net

[0001596532-25-000028:notes:164]
Other income, net consists of the following (in thousands):

[0001596532-25-000028:notes:165]
|  |  | Year Ended December 31, |
|  |  | 2024 |  | 2023 |  | 2022 |
| Other income (expense), net: |  |  |  |  |  |  |
| Interest income |  | $ | 310,998 |  |  | $ | 152,421 |  |  | $ | 27,556 |  |
| Other income (expense) |  | 9,420 |  |  | 12,356 |  |  | 27,134 |  |
| Total other income, net |  | $ | 320,418 |  |  | $ | 164,777 |  |  | $ | 54,690 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-25-000028:notes:166]
The following table summarizes the activity related to our contract liabilities (in thousands):

[0001596532-25-000028:notes:167]
The following table summarizes the activity related to our deferred revenue (in thousands):


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-25-000028:notes:168]
Acquisition, Goodwill and Acquisition-Related Intangible Assets 
Acquisitions and Goodwill

[0001596532-25-000028:notes:169]
We had no material business acquisitions during the years ended December 31, 2024 and 2023.

[0001596532-25-000028:notes:170]
There were no material changes to goodwill for the years ended December 31, 2024 and 2023. The Company performed an annual qualitative test for goodwill impairment in the fourth quarter of fiscal years ended December 31, 2024 and 2023 and determined that goodwill was not impaired.

[0001596532-25-000028:notes:171]
Acquisition-Related Intangible Assets

[0001596532-25-000028:notes:172]
The following table presents details of our acquisition-related intangible assets as of December 31, 2024 and 2023 (in thousands, except for years):

[0001596532-25-000028:notes:173]
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life (in years) |
|  | December 31, 2023 |  | Additions |  | December 31, 2024 |  | December 31, 2023 |  | Amortization |  | December 31, 2024 |  | December 31, 2023 |  | December 31, 2024 |  |
| Developed technology | $ | 154,930 |  |  | $ | — |  |  | $ | 154,930 |  |  | $ | (102,493) |  |  | $ | (16,780) |  |  | $ | (119,273) |  |  | $ | 52,437 |  |  | $ | 35,657 |  |  | 3.5 |
| Customer relationships | 54,620 |  |  | — |  |  | 54,620 |  |  | (21,797) |  |  | (7,701) |  |  | (29,498) |  |  | 32,823 |  |  | 25,122 |  |  | 3.9 |
| Trade name | 12,390 |  |  | — |  |  | 12,390 |  |  | (8,882) |  |  | (2,279) |  |  | (11,161) |  |  | 3,508 |  |  | 1,229 |  |  | 0.7 |
| Total | $ | 221,940 |  |  | $ | — |  |  | $ | 221,940 |  |  | $ | (133,172) |  |  | $ | (26,760) |  |  | $ | (159,932) |  |  | $ | 88,768 |  |  | $ | 62,008 |  |  | 3.6 |

[0001596532-25-000028:notes:174]
Amortization expense related to acquisition-related intangible assets was $26.8 million, $33.4 million and $33.7 million for the years ended December 31, 2024, 2023 and 2022, respectively.

[0001596532-25-000028:notes:175]
As of December 31, 2024, future estimated amortization expense related to the acquired-related intangible assets is as follows (in thousands):

[0001596532-25-000028:notes:176]
| Years Ending December 31, |  | Future Amortization Expense |
| 2025 |  | $ | 19,642 |  |
| 2026 |  | 17,260 |  |
| 2027 |  | 13,436 |  |
| 2028 |  | 10,037 |  |
| 2029 |  | 1,633 |  |
| Total |  | $ | 62,008 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-25-000028:notes:177]
Commitments and Contingencies
Operating Leases

[0001596532-25-000028:notes:178]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancellable operating lease arrangements that expire on various dates through 2031. Some of our leases include options to extend the term of such leases for a period from three months to up to 10 years and/or options to early terminate the leases. As of December 31, 2024, we did not include any such options in determining the lease terms because we were not reasonably certain that we would exercise these options.

[0001596532-25-000028:notes:179]
The following table summarizes the supplemental balance sheet information related to our operating leases (in thousands):

[0001596532-25-000028:notes:180]
|  |  | December 31, 2024 |  | December 31, 2023 |
| Right-of-use assets: |  |  |  |  |
| Operating lease right-of-use assets (included in other assets) |  | $ | 51,956 |  |  | $ | 55,890 |  |
| Lease liabilities: |  |  |  |  |
| Operating lease liabilities, current (included in other current liabilities) |  | 22,143 |  |  | 21,106 |  |
| Operating lease liabilities, non-current (included in other long-term liabilities) |  | 37,499 |  |  | 44,413 |  |
| Total operating lease liabilities |  | $ | 59,642 |  |  | $ | 65,519 |  |

[0001596532-25-000028:notes:181]
Maturities of operating lease liabilities as of December 31, 2024 are presented in the table below (in thousands):

[0001596532-25-000028:notes:182]
| Years ending December 31, |  | Amount |
| 2025 |  | $ | 24,704 |  |
| 2026 |  | 16,766 |  |
| 2027 |  | 12,238 |  |
| 2028 |  | 8,063 |  |
| 2029 |  | 2,695 |  |
| 2030 and thereafter |  | 841 |  |
| Total undiscounted operating lease payments (excluding non-lease components) |  | 65,307 |  |
| Less: imputed interest |  | (5,665) |  |
| Present value of operating lease payments as of December 31, 2024 |  | $ | 59,642 |  |

[0001596532-25-000028:notes:183]
Purchase Commitments

[0001596532-25-000028:notes:184]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of December 31, 2024, we had non-cancellable purchase commitments not recorded on our balance sheet of $3.1 billion, of which $2.8 billion have confirmed receipt dates within 12 months, and $0.3 billion have confirmed receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-25-000028:notes:185]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $95.8 million and $133.3 million as of December 31, 2024 and 2023, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the consolidated balance sheets.

[0001596532-25-000028:notes:186]
Property project

[0001596532-25-000028:notes:187]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office, lab and data center space. The estimated capital expenditures related to this project is expected to be approximately $235.0 million to $260.0 million through December 31, 2026 at which time construction is expected to be completed.

[0001596532-25-000028:notes:188]
Guarantees

[0001596532-25-000028:notes:189]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third-party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions, and our guarantee and indemnification arrangements have not had any material impact on our consolidated financial statements to date.

[0001596532-25-000028:notes:190]
Legal Proceedings

[0001596532-25-000028:notes:191]
WSOU Investments, LLC

[0001596532-25-000028:notes:192]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California.  On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement. On July 1, 2022, the court stayed the case pending the resolution of an inter partes review of one of the patents-in-suit. On May 30, 2023, the US Patent Trial and Appeal Board (“PTAB”) ruled all challenged claims in the inter partes review unpatentable. The district court case remains stayed pending appeal and/or final resolution of the PTAB ruling.

[0001596532-25-000028:notes:193]
We intend to vigorously defend against the claims brought against us by WSOU; however, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-25-000028:notes:194]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated; however, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-25-000028:notes:195]
Other matters

[0001596532-25-000028:notes:196]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-25-000028:notes:197]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of December 31, 2024, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-25-000028:notes:198]
Stockholders' Equity and Stock-Based Compensation
Stock Repurchase Program

[0001596532-25-000028:notes:199]
In April 2024, we completed repurchases under our previous $1.0 billion stock repurchase program (the “Prior Repurchase Program”).  In May 2024, our board of directors authorized a new $1.2 billion stock repurchase program (the “New Repurchase Program” and together with the Prior Repurchase Program, the "Repurchase Programs"), which expires in May 2027. This authorization allows us to repurchase shares of our common stock that will be funded from working capital. Repurchases may be made at management's discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the "Exchange Act"), or a combination of the foregoing. The Repurchase Programs do not obligate us to acquire any of our common stock, and may be suspended or discontinued by the company at any time without prior notice. During the year ended December 31, 2024, we repurchased a total of $279.0 million of our common stock under our New Repurchase Program and $144.6 million of our common stock under our Prior Repurchase Program. As of December 31, 2024, the remaining authorized amount for stock repurchases under the New Repurchase Program was approximately $921.0 million.

[0001596532-25-000028:notes:200]
A summary of the stock repurchase activities for the years ended December 31, 2024 and 2023 is as follows, as adjusted to give effect to the Stock Split (in thousands, except per share amounts):

[0001596532-25-000028:notes:201]
|  |  | Year Ended December 31, |
|  |  | 2024 |  | 2023 |
| Aggregate purchase price |  | $ | 423,619 |  |  | $ | 112,279 |  |
| Shares repurchased |  | 5,492 |  |  | 3,816 |  |
| Average price paid per share |  | $ | 77.13 |  |  | $ | 29.43 |  |

[0001596532-25-000028:notes:202]
The aggregate purchase price of repurchased shares of our common stock is recorded as a reduction to retained earnings in our consolidated statements of stockholders' equity. All shares repurchased have been retired.

[0001596532-25-000028:notes:203]
2014 Equity Incentive Plan

[0001596532-25-000028:notes:204]
On April 16, 2024, our board of directors adopted an amended and restated Arista Networks, Inc. 2014 Equity Plan ("Restated Plan"), effective April 17, 2024 ("Effective Date") subject to the approval of our stockholders, which was approved at the 2024 Annual Meeting of Stockholders on June 7, 2024.

[0001596532-25-000028:notes:205]
The Restated Plan provides for the grant of equity-based awards, including stock options, restricted stock units, restricted stock, stock appreciation rights, and performance awards. The share pool available under the prior version of the Company's 2014 Equity Incentive Plan ("Prior Plan") was extinguished, and the Restated Plan provides for a new share pool not to exceed (i) 52,800,000 shares of our Common Stock (“Shares”), plus (ii) any Shares subject to awards under the Prior Plan that, on or after the Effective Date, expired or otherwise terminated without having been exercised in full, or that were forfeited to or repurchased by us, including net settlement of Shares subject to restricted stock units, with the maximum number of Shares to be added to the Restated Plan as a result of clause (ii) equal to 40,158,628 Shares. The Restated Plan’s terms are substantially similar to the Prior Plan’s terms, including with respect to treatment of equity awards in the event of a “change in control” as defined under the Restated Plan, but with certain modifications, including the elimination of the automatic “evergreen” share reserve increase provided for under the Prior Plan. As of December 31, 2024, there remained approximately 52.4 million shares available for grant under the Restated Plan, as adjusted to give effect to the Stock Split.

[0001596532-25-000028:notes:206]
2014 Employee Stock Purchase Plan

[0001596532-25-000028:notes:207]
In April 2014, the board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (“ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding immediately preceding December 31, but not to exceed 40 million shares, unless the board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2024, our board of directors authorized an increase of 12.5 million shares, as adjusted to give effect to the Stock Split, for future issuance under the ESPP. As of December 31, 2024, there remained 104.9 million shares available for issuance under the ESPP.

[0001596532-25-000028:notes:208]
Under our ESPP, eligible employees are permitted to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the exercise date. Each offering period lasts approximately two years starting on the first trading date after February 15 and August 15 of each year, and includes purchase dates every six months on or after February 15 and August 15 of each year. Participants may purchase shares

[0001596532-25-000028:notes:209]
of common stock through payroll deductions up to 15% of their eligible compensation, subject to Internal Revenue Service mandated purchase limits.

[0001596532-25-000028:notes:210]
During the year ended December 31, 2024, we issued 1.12 million shares at an average purchase price of $29.08 per share under our ESPP, as adjusted to give effect to the Stock Split.

[0001596532-25-000028:notes:211]
Stock Option Activities

[0001596532-25-000028:notes:212]
The following table summarizes the option activities and related information, as adjusted to give effect to the Stock Split (in thousands, except years and per share amounts):

[0001596532-25-000028:notes:213]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (In Years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2023 |  | 9,828 |  |  | $ | 4.96 |  |  | 1.7 |  | $ | 529,931 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (6,642) |  |  | 4.14 |  |  |  |  |  |
| Options canceled |  | (96) |  |  | 5.02 |  |  |  |  |  |
| Balance—December 31, 2024 |  | 3,090 |  |  | $ | 6.71 |  |  | 1.5 |  | $ | 320,854 |  |
| Vested and exercisable—December 31, 2024 |  | 2,986 |  |  | $ | 6.43 |  |  | 1.5 |  | $ | 310,814 |  |

[0001596532-25-000028:notes:214]
We did not grant any stock options during the years ended December 31, 2024, 2023 and 2022. The aggregate intrinsic value of options exercised during the years ended December 31, 2024, 2023 and 2022 was $495.1 million, $525.3 million and $311.7 million, respectively. The total fair value of options vested for the years ended December 31, 2024, 2023 and 2022 was approximately $5.6 million, $8.7 million and $16.6 million, respectively.

[0001596532-25-000028:notes:215]
Restricted Stock Unit (RSU) Activities

[0001596532-25-000028:notes:216]
The following table summarizes the RSU activities and related information, as adjusted to give effect to the Stock Split (in thousands, except per share amounts):

[0001596532-25-000028:notes:217]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |
| Balance—December 31, 2023 |  | 31,600 |  |  | $ | 28.19 |  |
| RSUs and PRSUs granted |  | 10,142 |  |  | 72.61 |  |
| RSUs and PRSUs vested |  | (10,731) |  |  | 23.75 |  |
| RSUs and PRSUs forfeited/canceled |  | (2,402) |  |  | 36.11 |  |
| Unvested balance—December 31, 2024 |  | 28,609 |  |  | $ | 45.46 |  |

[0001596532-25-000028:notes:218]
The weighted-average grant-date fair value of RSUs granted during the years ended December 31, 2024, 2023 and 2022 was $72.61, $39.49 and $25.34 per share, respectively, as adjusted to give effect to the Stock Split. The total fair value of RSUs vested for the years ended December 31, 2024, 2023 and 2022 was approximately $251.8 million, $225.5 million, and $174.0 million, respectively.

[0001596532-25-000028:notes:219]
Stock-Based Compensation Expense

[0001596532-25-000028:notes:220]
The following table summarizes the stock-based compensation expense related to our equity awards (in thousands):

[0001596532-25-000028:notes:221]
|  |  | Year Ended December 31, |
|  |  | 2024 |  | 2023 |  | 2022 |
| Cost of revenue |  | $ | 15,786 |  |  | $ | 12,789 |  |  | $ | 9,688 |  |
| Research and development |  | 211,807 |  |  | 172,177 |  |  | 130,897 |  |
| Sales and marketing |  | 78,762 |  |  | 71,074 |  |  | 57,571 |  |
| General and administrative |  | 49,009 |  |  | 40,716 |  |  | 32,778 |  |
| Total stock-based compensation |  | $ | 355,364 |  |  | $ | 296,756 |  |  | $ | 230,934 |  |

[0001596532-25-000028:notes:222]
Determination of Fair Value

[0001596532-25-000028:notes:223]
We record stock-based compensation awards based on fair value as of the grant date. We value RSUs at the market close price of our common stock on the grant date. For option awards and ESPP offerings, we use the Black-Scholes option pricing model to determine fair value. We recognize such costs as compensation expense generally on a straight-line basis over the requisite service period of the award. 
As of December 31, 2024, there were $1.0 billion of unrecognized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 4.2 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-25-000028:notes:224]
Net Income Per Share 
Basic net income per share is computed using the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed using the weighted-average number of shares of common stock outstanding during the period, including potential common shares assuming the dilutive effect of outstanding stock options, restricted stock units, and the employee stock purchase plan using the treasury stock method. Potential common shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share. The following table sets forth the computation of our basic and diluted net income per share attributable to common stockholders, as adjusted to give effect to the Stock Split (in thousands, except per share amounts):

[0001596532-25-000028:notes:225]
|  |  | Year Ended December 31, |
|  |  | 2024 |  | 2023 |  | 2022 |
| Net income |  | $ | 2,852,054 |  |  | $ | 2,087,321 |  |  | $ | 1,352,446 |  |
| Basic weighted-average shares outstanding |  | 1,256,303 |  |  | 1,237,417 |  |  | 1,225,891 |  |
| Add weighted-average effects of dilutive securities: |  |  |  |  |  |  |
| Stock options and RSUs |  | 24,426 |  |  | 30,893 |  |  | 39,504 |  |
| Employee stock purchase plan |  | 348 |  |  | 228 |  |  | 440 |  |
| Diluted weighted-average shares outstanding |  | 1,281,077 |  |  | 1,268,538 |  |  | 1,265,835 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 2.27 |  |  | $ | 1.69 |  |  | $ | 1.10 |  |
| Diluted |  | $ | 2.23 |  |  | $ | 1.65 |  |  | $ | 1.07 |  |

[0001596532-25-000028:notes:226]
The following weighted-average outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share attributable to common stockholders because their effects would have been anti-dilutive for the periods presented, as adjusted to give effect to the Stock Split (in thousands):

[0001596532-25-000028:notes:227]
|  |  | Year Ended December 31, |
|  |  | 2024 |  | 2023 |  | 2022 |
| Stock options and RSUs |  | 242 |  |  | 579 |  |  | 1,209 |  |
| Employee stock purchase plan |  | 26 |  |  | 412 |  |  | 800 |  |
| Total |  | 268 |  |  | 991 |  |  | 2,009 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-25-000028:notes:228]
Income Taxes
The components of income before provision for income taxes are as follows (in thousands):

[0001596532-25-000028:notes:229]
|  |  | Year Ended December 31, |
|  |  | 2024 |  | 2023 |  | 2022 |
| Domestic |  | $ | 2,635,557 |  |  | $ | 1,977,687 |  |  | $ | 1,260,614 |  |
| Foreign |  | 629,477 |  |  | 444,339 |  |  | 321,182 |  |
| Income before income taxes |  | $ | 3,265,034 |  |  | $ | 2,422,026 |  |  | $ | 1,581,796 |  |

[0001596532-25-000028:notes:230]
The components of the provision for income taxes are as follows (in thousands):

[0001596532-25-000028:notes:231]
|  |  | Year Ended December 31, |
|  |  | 2024 |  | 2023 |  | 2022 |
| Current provision for income taxes: |  |  |  |  |  |  |
| Federal |  | $ | 751,279 |  |  | $ | 574,449 |  |  | $ | 359,158 |  |
| State |  | 114,731 |  |  | 106,866 |  |  | 76,321 |  |
| Foreign |  | 39,771 |  |  | 24,186 |  |  | 38,250 |  |
| Total current |  | 905,781 |  |  | 705,501 |  |  | 473,729 |  |
| Deferred tax expense (benefit): |  |  |  |  |  |  |
| Federal |  | (504,730) |  |  | (372,270) |  |  | (219,568) |  |
| State |  | (42,781) |  |  | (41,152) |  |  | (34,689) |  |
| Foreign |  | 54,710 |  |  | 42,626 |  |  | 9,878 |  |
| Total deferred tax expense (benefit) |  | (492,801) |  |  | (370,796) |  |  | (244,379) |  |
| Total provision for income taxes |  | $ | 412,980 |  |  | $ | 334,705 |  |  | $ | 229,350 |  |

[0001596532-25-000028:notes:232]
The reconciliation of the statutory federal income tax rate and our effective income tax rate is as follows (in percentages):

[0001596532-25-000028:notes:233]
|  |  | Year Ended December 31, |
|  |  | 2024 |  | 2023 |  | 2022 |
| U.S. federal statutory income tax rate |  | 21.00 | % |  | 21.00 | % |  | 21.00 | % |
| State tax, net of federal benefit |  | 1.75 |  |  | 2.13 |  |  | 2.09 |  |
| Taxes on foreign earnings differential |  | (2.38) |  |  | (1.96) |  |  | (2.24) |  |
| Tax credits |  | (2.79) |  |  | (2.74) |  |  | (2.24) |  |
| Stock-based compensation |  | (4.96) |  |  | (4.59) |  |  | (4.07) |  |
| Acquisition and integration costs |  | — |  |  | 0.01 |  |  | 0.05 |  |
| Other, net |  | 0.03 |  |  | (0.04) |  |  | (0.09) |  |
| Effective tax rate |  | 12.65 | % |  | 13.81 | % |  | 14.50 | % |

[0001596532-25-000028:notes:234]
The change in our effective tax rate was due to a favorable change in state taxes and tax benefits attributable to stock-based compensation. Excess tax benefits resulting from stock awards were $212.3 million, $151.2 million and $93.5 million for the years ended December 31, 2024, 2023 and 2022, respectively.

[0001596532-25-000028:notes:235]
The tax effects of temporary differences that give rise to significant portions of deferred tax assets (liabilities) are as follows (in thousands) :

[0001596532-25-000028:notes:236]
|  |  | December 31, |
|  |  | 2024 |  | 2023 |
| Deferred tax assets: |  |  |  |  |
| Intangible assets |  | $ | 273,867 |  |  | $ | 322,325 |  |
| Reserves and accruals not currently deductible |  | 135,167 |  |  | 120,973 |  |
| Deferred revenue |  | 566,273 |  |  | 295,268 |  |
| Tax credits |  | 130,188 |  |  | 118,123 |  |
| Lease financing obligation |  | 13,719 |  |  | 15,485 |  |
| Capitalized research and development expenses |  | 634,534 |  |  | 417,095 |  |
| Stock-based compensation |  | 38,631 |  |  | 28,079 |  |
| Net operating losses |  | 25,916 |  |  | 34,274 |  |
| Other |  | 3,593 |  |  | 1,328 |  |
| Gross deferred tax assets |  | 1,821,888 |  |  | 1,352,950 |  |
| Valuation allowance |  | (179,789) |  |  | (146,268) |  |
| Total deferred tax assets |  | 1,642,099 |  |  | 1,206,682 |  |
| Deferred tax liabilities: |  |  |  |  |
| US tax on foreign earnings |  | (189,823) |  |  | (245,074) |  |
| Right of use asset |  | (11,571) |  |  | (12,935) |  |
| Other |  | (287) |  |  | (2,881) |  |
| Total deferred tax liabilities |  | (201,681) |  |  | (260,890) |  |
| Net deferred tax assets |  | $ | 1,440,418 |  |  | $ | 945,792 |  |

[0001596532-25-000028:notes:237]
As of December 31, 2024 and 2023, $1.4 billion and $0.9 billion were recorded as deferred tax assets, non-current respectively. We did not have any balance related to deferred tax liabilities as of December 31, 2024 and 2023.

[0001596532-25-000028:notes:238]
As of December 31, 2024, we had $225.1 million and $120.6 million of net operating loss carryforwards for federal and state income tax purposes, respectively, from acquisitions. These federal and state losses will begin to expire in 2028 and 2029, respectively. We do not have any material foreign net operating losses.

[0001596532-25-000028:notes:239]
As of December 31, 2024, our state tax credit carryforwards for income tax purposes before valuation allowances were approximately $238.4 million, which can be carried over indefinitely. We have provided a valuation allowance of $179.8 million for deferred tax assets, primarily related to state carryforwards that we do not believe are more likely than not to be realized.

[0001596532-25-000028:notes:240]
Utilization of the net operating losses and tax credit carryforwards may be subject to limitations due to ownership change limitations provided in the Internal Revenue Code and similar state or foreign provisions.

[0001596532-25-000028:notes:241]
U.S. tax law generally requires U.S. shareholders of a controlled foreign corporation (“CFC”) to include the annual earnings of foreign subsidiaries into U.S. taxable income each year. Correspondingly, most of the undistributed earnings are deemed to be previously taxed for U.S. tax purposes and distributions of the unremitted earnings do not have any significant U.S. federal income tax impact.  We have not provided for any remaining tax effect, if any, of limited outside basis differences of our foreign subsidiaries based upon plans of future reinvestment. The determination of the future tax consequences of the remittance of these earnings is not practicable.

[0001596532-25-000028:notes:242]
Uncertain Tax Positions

[0001596532-25-000028:notes:243]
We recognize uncertain tax positions only to the extent that management believes that it is more likely than not that the position will be sustained. The reconciliation of the beginning and ending amount of gross unrecognized tax benefits as of December 31, 2024, 2023 and 2022 is as follows (in thousands):

[0001596532-25-000028:notes:244]
|  |  | Year Ended December 31, |
|  |  | 2024 |  | 2023 |  | 2022 |
| Gross unrecognized tax benefits—beginning balance |  | $ | 163,266 |  |  | $ | 137,357 |  |  | $ | 114,813 |  |
| Increases related to tax positions taken in a prior year |  | 294 |  |  | 4,690 |  |  | 1,566 |  |
| Increases related to tax positions taken during current year |  | 52,701 |  |  | 39,895 |  |  | 25,355 |  |
| Decreases related to tax positions taken in a prior year |  | (8,624) |  |  | (513) |  |  | (3,781) |  |
| Decreases related to lapse of statute of limitations |  | (26,010) |  |  | (18,163) |  |  | (596) |  |
| Decreases related to settlements with taxing authorities |  | (150) |  |  | — |  |  | — |  |
| Gross unrecognized tax benefits—ending balance |  | $ | 181,477 |  |  | $ | 163,266 |  |  | $ | 137,357 |  |

[0001596532-25-000028:notes:245]
As of December 31, 2024, 2023 and 2022, the total amount of gross unrecognized tax benefits was $181.5 million, $163.3 million and $137.4 million, respectively, of which $103.4 million, $90.0 million and $79.3 million would affect our effective tax rate if recognized.

[0001596532-25-000028:notes:246]
Our policy is to recognize interest and penalties accrued on any unrecognized tax benefits as a component of income tax expense. For the years ended December 31, 2024 and 2023, the net expense for interest and penalties and the recognized liability for interest and penalties were not material.

[0001596532-25-000028:notes:247]
The statute of limitations for Federal and most states remains open for 2021 and forward. Some states have net operating loss and tax credit carryforwards, and therefore remain open to examination. Our foreign tax returns, where the statute of limitations have not yet lapsed, are open to audit in the respective foreign countries where the subsidiaries are located. It is possible that the amount of existing gross unrecognized tax benefits may decrease within the next 12 months as a result of statute of limitation lapses or payments to tax authorities in certain jurisdictions. However, any such changes are not anticipated to be material.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-25-000028:notes:248]
Segment and Geographical Information 
We operate as one reportable segment. The accounting policies of the reportable segment are the same as those described in the summary of significant accounting policies. The financial information reviewed by the CODM reflects quarterly and year-to-date operating results, with a primary focus on revenue, gross margin, operating margin and net income as reported on the consolidated statements of income. Consolidated financial information is used by the CODM to evaluate performance and make decisions regarding resource allocation and other strategic initiatives. This consolidated financial information is also what is used to establish and approve operating budgets and forecasts. The measure of segment assets is reported on the consolidated balance sheets in total. There was no change for each of the periods presented in the measurement methods used to determine reported segment profit and loss.

[0001596532-25-000028:notes:249]
The CODM reviews the following significant segment expenses, which are presented separately on the Company’s consolidated statements of income: cost of product, cost of services, selling and marketing expenses, general and administrative expenses, and research and development expenses. Other segment items that are included in the calculation of the Company’s net income include other income (expense), net, which is further described in Note 3. Financial Statements Details and income taxes, which is further described in Note 8. Income Taxes. Other segment disclosures such as depreciation and amortization and stock-based compensation are disclosure in the Consolidated Statements of Cash Flows.

[0001596532-25-000028:notes:250]
The following table represents revenue based on customers' shipping addresses (in thousands):

[0001596532-25-000028:notes:251]
|  |  | Year Ended December 31, |
|  |  | 2024 |  | 2023 |  | 2022 |
| Americas(1) |  | $ | 5,729,039 |  |  | $ | 4,651,193 |  |  | $ | 3,462,621 |  |
| Europe, Middle East and Africa |  | 713,175 |  |  | 670,960 |  |  | 529,800 |  |
| Asia Pacific |  | 560,932 |  |  | 538,015 |  |  | 388,889 |  |
| Total revenue |  | $ | 7,003,146 |  |  | $ | 5,860,168 |  |  | $ | 4,381,310 |  |

[0001596532-25-000028:notes:252]
(1) Includes $5,663.0 million, $4,541.5 million and $3,424.8 million revenue generated from the U.S. for the three years ended December 31, 2024, 2023 and 2022, respectively

[0001596532-25-000028:notes:253]
Long-lived assets, excluding intercompany receivables, investments in subsidiaries, investments in privately-held companies and deferred tax assets, net by location are summarized as follows (in thousands):

[0001596532-25-000028:notes:254]
|  |  | December 31, |
|  |  | 2024 |  | 2023 |
| United States |  | $ | 83,520 |  |  | $ | 79,728 |  |
| International |  | 15,325 |  |  | 21,852 |  |
| Total |  | $ | 98,845 |  |  | $ | 101,580 |  |


## us-gaap:PostemploymentBenefitsDisclosureTextBlock

[0001596532-25-000028:notes:255]
Post-Employment Benefits We have a 401(k) Plan that covers substantially all of our employees in the U.S.  Effective January 1, 2017, we have elected to match 100% of employees' contributions up to a maximum of 3% of an employee's annual salary. Matching contributions are immediately vested. For the years ended December 31, 2024, 2023 and 2022, the amounts we contributed for the matching contributions were not material


## ecd:MtrlTermsOfTrdArrTextBlock

[0001596532-25-000028:notes:256]
On December 13, 2024, Jayshree Ullal, our Chairperson and Chief Executive Officer, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of: (i) up to 7,349,668 shares of our common stock; and (ii) a number of shares of our common stock that may be earned in connection with grants of performance-based restricted stock units, which cannot be determined at this time. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until April 17, 2026, or earlier if all transactions under the trading arrangement are completed.
