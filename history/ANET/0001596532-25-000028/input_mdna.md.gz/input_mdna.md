# ANET MD&A — 0001596532-25-000028


## mdna

[0001596532-25-000028:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001596532-25-000028:mdna:2]
Overview

[0001596532-25-000028:mdna:3]
Arista Networks is an industry leader in data-driven, client to cloud networking for large AI, data center, campus and routing environments. Arista's platforms deliver availability, agility, automation, analytics and security through an advanced network operating stack. Since Arista’s inception, our founders have reimagined cloud networks for performance, scale and programmability with a focus on differentiating in three ways: uncompromising reliability built on the foundation of robust quality assurance capabilities with a suite of automated diagnostics, advanced open and standards-based technology and intelligent automation to decrease the manual workload on the operator. At the core of Arista’s platform is Arista EOS, a modernized publish-subscribe state-sharing networking operating system. Arista EOS, combined with a set of network applications and our Ethernet switching and routing platforms using best of breed merchant silicon, provides customers with a highly competitive and diversified portfolio of products with improved price/performance and time to market.

[0001596532-25-000028:mdna:4]
The Company’s current portfolio of products, services and technologies are grouped into the following categories: Core (Data Center, Cloud and AI Networking), Cognitive Adjacencies (Campus and Routing), and Cognitive Network (Software and Services). The percentage of revenue derived from these product categories during the current fiscal year was approximately 65% from Core, 18% from Cognitive Adjacencies, and 17% from Networking software and services. Our customers include companies of all sizes and span a range of industries and geographies and are grouped into the following categories: Cloud and AI Titans, Enterprise and Providers.  The percentage of revenue derived from these customers during the current fiscal year was approximately 48% from Cloud and AI Titans, 35% from Enterprise and 17% from Providers.

[0001596532-25-000028:mdna:5]
Historically, large purchases by a relatively limited number of customers have accounted for a significant portion of our revenue. We have experienced unpredictability in the timing of orders from these large customers primarily due to the time it takes these customers to evaluate, test, qualify and accept our newer products, the overall complexity of these large orders and changes in demand patterns specific to these customers, including reductions in or changes in mix of capital expenditures by these customers and the impact of cost reduction and other efficiency efforts by these customers. For example, sales to our end customer Microsoft represented 20%, 18% and 16% of our total revenue for the years ended 2024, 2023 and 2022 respectively. And sales to our end customer Meta Platforms represented 15%, 21% and 26% of our total revenue, respectively for the years ended 2024, 2023 and 2022. This variability in customer concentration has been linked to the timing of new product deployments and spending cycles with these customers, and we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. In addition, we typically provide pricing discounts to large customers, which reduces gross margins for the period in which such sales occur.

[0001596532-25-000028:mdna:6]
We believe an increased focus on the deployment of AI enabled solutions by our large customers has accelerated the need for advanced technology offerings including some offerings from potential new market entrants.  This prioritization and acceleration of AI related infrastructure investment has at times come in conjunction with a reduction or changes in the mix of previously planned purchases and various cost reduction measures by these customers, including optimization and increased efficiency in non-AI related capital expenditures. In addition, although the focus on deployment of AI enabled solutions has driven increased demand for networking, the long-term trajectory is unknown. As such, demand estimates for our new products are difficult to forecast and can create volatility in our revenue. In some instances, such measures have had, and may continue to have, an impact on certain current or future projects and have reduced our visibility to customer demand and may result in a reduction or uncertainty in the timing of orders from these large customers and increase the risk of charges for excess and obsolete inventory. Fiscal 2024 was marked by a year of new product introductions and expanded use cases, particularly in the AI Ethernet market, and we expect this to continue into fiscal 2025. This has resulted in increased customer trials and contracts with acceptance periods, and an increase in the volatility and magnitude of our product deferred revenue balances, which in turn may create variability in our revenue results on a quarterly and annual basis. In addition, if we are not able to satisfy the requirements under customer trials or contracts with acceptance periods, we may be required to accept product returns from our customers, which would prevent us from recognizing revenue on such transactions and may result in the write-down of inventory.

[0001596532-25-000028:mdna:7]
We believe that cloud computing represents a fundamental shift from traditional legacy network architectures. As organizations of all sizes have moved workloads to the cloud, spending on cloud and next-generation data centers has increased rapidly, while traditional legacy IT spending has grown at a slower rate. Our cloud networking platforms are well positioned to address the growing cloud networking market, and to address increasing performance requirements driven by the growing number of connected devices, as well as the need for constant connectivity and access to data and applications.

[0001596532-25-000028:mdna:8]
The markets for cloud networking solutions are highly competitive and characterized by rapidly changing technology, changing end-customer needs, evolving industry standards, frequent introductions of new products and services, and industry consolidation. We expect competition to intensify in the future as the market for cloud networking expands and existing competitors and new market entrants introduce new products or enhance existing products. Our future success is dependent upon our ability to continue to evolve and adapt to our rapidly changing environment. We must also continue to develop market-leading products and software features that address the changing needs of our existing and new customers, and increase sales in the cloud, AI and enterprise data center ethernet switching/routing markets, and campus workspace markets. We intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new customers more effectively, increase sales to existing customers, and provide services and support. In addition, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our ability to rapidly develop new features and applications.

[0001596532-25-000028:mdna:9]
Macroeconomic Update

[0001596532-25-000028:mdna:10]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including the effects of, among other things, inflation, monetary policy shifts, recession risks, potential supply chain disruptions, changes in the U.S. administration, geopolitical pressures and escalating international trade measures.

[0001596532-25-000028:mdna:11]
Our business is emerging from a period of unprecedented global supply chain disruptions.  Throughout this period, we made significant supply chain investments, including funding additional working capital and incremental purchase commitments in response to extended visibility to deployment plans from our customers. We have worked closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. Increased capacity has allowed us to ship products against previously committed demand/deployment plans and accelerate some deployments where needed, while trying to balance our customers' requirements and lead times with the availability of key components and products and lead times of our key suppliers and contract manufacturers. As a result, some shipments against these previously committed demand/deployment plans have extended into 2025.

[0001596532-25-000028:mdna:12]
As the global supply chain has experienced some improvements and as customer lead times have been reduced from their peak, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to shorter demand-planning horizons. Given the timing and prioritization of customer orders and shipment patterns, as well as the timing and outcome of customer trials and contracts with acceptance periods, near term revenue trends may not be reflective of current demand levels, and as discussed above will also benefit from demand/deployment plans that have been previously committed. We expect that our inventory and purchase commitments will remain volatile as we ramp new product introductions. The magnitude of these balances, combined with a reduction in customer demand-planning horizons and shifting customer product priorities, has resulted in increased risk that we may not be able to sell all of this inventory, which in turn has resulted in additional excess and obsolete inventory and supplier liability charges. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. These cost pressures may be increased if escalating tariff and non-tariff international trade measures continue to proliferate in or affect our supply chain. We also may not be able to pass on the full burden of the increase in trade-related costs to our customers, which could further negatively impact our gross margin. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods.

[0001596532-25-000028:mdna:13]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. In addition, any continued or renewed disruption in manufacturing and supply and new or enhanced tariffs imposed by the U.S. and other countries resulting from these factors could negatively

[0001596532-25-000028:mdna:14]
impact our business. Furthermore, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial conditions discussed herein may not be indicative of future operating results and trends.

[0001596532-25-000028:mdna:15]
Results of Operations

[0001596532-25-000028:mdna:16]
Year Ended December 31, 2024 Compared to Year Ended December 31, 2023

[0001596532-25-000028:mdna:17]
Revenue, Cost of Revenue and Gross Margin (in thousands, except percentages)

[0001596532-25-000028:mdna:18]
|  |  | Year Ended December 31, |  |  |
|  |  | 2024 |  | 2023 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,884,021 |  |  | 84.0 | % |  | $ | 5,029,493 |  |  | 85.8 | % |  | $ | 854,528 |  |  | 17.0 | % |
| Service |  | 1,119,125 |  |  | 16.0 |  |  | 830,675 |  |  | 14.2 |  |  | 288,450 |  |  | 34.7 |  |
| Total revenue |  | 7,003,146 |  |  | 100.0 |  |  | 5,860,168 |  |  | 100.0 |  |  | 1,142,978 |  |  | 19.5 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 2,299,063 |  |  | 32.8 |  |  | 2,061,167 |  |  | 35.2 |  |  | 237,896 |  |  | 11.5 |  |
| Service |  | 212,780 |  |  | 3.1 |  |  | 168,720 |  |  | 2.9 |  |  | 44,060 |  |  | 26.1 |  |
| Total cost of revenue |  | 2,511,843 |  |  | 35.9 |  |  | 2,229,887 |  |  | 38.1 |  |  | 281,956 |  |  | 12.6 |  |
| Gross profit |  | $ | 4,491,303 |  |  | 64.1 | % |  | $ | 3,630,281 |  |  | 61.9 | % |  | $ | 861,022 |  |  | 23.7 | % |
| Gross margin |  | 64.1 | % |  |  |  | 61.9 | % |  |  |  |  |  |  |

[0001596532-25-000028:mdna:19]
Revenue by Geography (in thousands, except percentages)

[0001596532-25-000028:mdna:20]
|  |  | Year Ended December 31, |
|  |  | 2024 |  | % of Total |  | 2023 |  | % of Total |
| Americas |  | $ | 5,729,039 |  |  | 81.8 | % |  | $ | 4,651,193 |  |  | 79.4 | % |
| Europe, Middle East and Africa |  | 713,175 |  |  | 10.2 |  |  | 670,960 |  |  | 11.4 |  |
| Asia-Pacific |  | 560,932 |  |  | 8.0 |  |  | 538,015 |  |  | 9.2 |  |
| Total revenue |  | $ | 7,003,146 |  |  | 100.0 | % |  | $ | 5,860,168 |  |  | 100.0 | % |

[0001596532-25-000028:mdna:21]
Revenue

[0001596532-25-000028:mdna:22]
Product revenue primarily consists of sales of our switching and routing products, and related network applications. Service revenue is primarily derived from sales of PCS contracts, which are typically purchased in conjunction with our products, and subsequent renewals of those contracts. We expect our revenue may vary from period to period based on, among other things, the timing, size, and complexity of orders, especially with respect to our large customers.

[0001596532-25-000028:mdna:23]
Product revenue increased by $854.5 million, or 17.0%, for the year ended December 31, 2024 compared to 2023.  This increase reflects healthy customer demand and higher shipments of our switching and routing platforms, with strong contributions across our customer base. In addition, service revenue increased by $288.5 million, or 34.7%, for the year ended December 31, 2024 compared to 2023, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenues as a percentage of our total revenues decreased from 20.6% in 2023 to 18.2% in 2024, which was primarily driven by changes in the geographic mix of sales to our large global customers.

[0001596532-25-000028:mdna:24]
Cost of Revenue and Gross Margin

[0001596532-25-000028:mdna:25]
Cost of product revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs of our manufacturing operations, including freight, and other costs associated with manufacturing our products and managing our inventory and supply chain. Cost of service revenue primarily consists of

[0001596532-25-000028:mdna:26]
personnel and other costs associated with our global customer support and services organizations.

[0001596532-25-000028:mdna:27]
Cost of revenue increased by $282.0 million, or 12.6% for the year ended December 31, 2024 compared to 2023. These increases were driven by a corresponding increase in product and service revenues, partially offset by reductions of $180.4 million in net excess/obsolete inventory and supplier liability charges for the year ended December 31, 2024 compared to 2023.

[0001596532-25-000028:mdna:28]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including pricing pressure on our products and services due to competition, the mix of sales to large customers who generally receive lower pricing, the mix of products sold, manufacturing-related costs, including costs associated with supply chain sourcing activities, merchant silicon costs, and excess/obsolete inventory and supplier liability charges. For example, in order to meet customer lead times, we have, and may continue to expedite the supply of components and make incremental investments in our supply chain to increase our capacity for manufacturing products, which increases our product costs and negatively impacts our gross margin. We expect our gross margin to fluctuate over time, depending on the factors described above.

[0001596532-25-000028:mdna:29]
Gross margin increased from 61.9% for the year ended December 31, 2023 to 64.1% for the year ended December 31, 2024. These changes reflect an improvement in product margins of 60.9% in 2024 compared to 59.0% in 2023, driven by a reduction of $180.4 million in net excess/obsolete inventory-related charges. In addition, our gross margin benefited in 2024 from the leverage of relatively fixed manufacturing overhead costs on a higher revenue base of $7.0 billion in 2024 compared to $5.9 billion in 2023.

[0001596532-25-000028:mdna:30]
Operating Expenses (in thousands, except percentages)

[0001596532-25-000028:mdna:31]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. The largest component of our operating expenses is personnel costs. Personnel costs consist of wages, benefits, bonuses and, with respect to sales and marketing expenses, sales commissions. Personnel costs also include stock-based compensation and travel-related expenses.

[0001596532-25-000028:mdna:32]
|  |  | Year Ended December 31, |  |  |
|  |  | 2024 |  | 2023 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 996,717 |  |  | 14.2 | % |  | $ | 854,918 |  |  | 14.6 | % |  | $ | 141,799 |  |  | 16.6 | % |
| Sales and marketing |  | 427,264 |  |  | 6.1 |  |  | 399,034 |  |  | 6.8 |  |  | 28,230 |  |  | 7.1 |  |
| General and administrative |  | 122,706 |  |  | 1.8 |  |  | 119,080 |  |  | 2.0 |  |  | 3,626 |  |  | 3.0 |  |
| Total operating expenses |  | $ | 1,546,687 |  |  | 22.1 | % |  | $ | 1,373,032 |  |  | 23.4 | % |  | $ | 173,655 |  |  | 12.6 | % |

[0001596532-25-000028:mdna:33]
Research and development.

[0001596532-25-000028:mdna:34]
Research and development expenses consist primarily of personnel costs, prototype expenses, third-party engineering costs, and an allocated portion of facility and IT costs. Our research and development efforts are focused on new product development and maintaining and developing additional functionality for our existing products, including new releases and upgrades to our EOS software and applications. We expect our research and development expenses to increase in absolute dollars as we continue to invest in software development in order to expand the capabilities of our cloud networking platform, introduce new products and features, and continue to invest in our technology.

[0001596532-25-000028:mdna:35]
Research and development expenses increased by $141.8 million, or 16.6%, for the year ended December 31, 2024 compared to 2023. The increase was primarily due to a $64.9 million increase in personnel costs driven by an increase in headcount, and a $52.3 million increase in new product introduction costs, including non-recurring engineering costs and prototype expenses as we expand our product portfolio.

[0001596532-25-000028:mdna:36]
Sales and marketing.

[0001596532-25-000028:mdna:37]
Sales and marketing expenses consist primarily of personnel costs, marketing, trade shows, and other promotional activities, and an allocated portion of facility and IT costs. We expect our sales and marketing expenses to increase in absolute dollars as we continue to expand our sales and marketing efforts worldwide.

[0001596532-25-000028:mdna:38]
Sales and marketing expenses increased by $28.2 million, or 7.1%, for the year ended December 31, 2024 compared to 2023 primarily due to an increase in personnel costs.

[0001596532-25-000028:mdna:39]
General and administrative.

[0001596532-25-000028:mdna:40]
General and administrative expenses consist primarily of personnel costs and professional services costs for our finance, human resources, legal and certain executive functions. Our professional services costs are primarily related to external legal, accounting, and tax services.

[0001596532-25-000028:mdna:41]
General and administrative expenses increased by $3.6 million, or 3.0%, for the year ended December 31, 2024 compared to 2023.

[0001596532-25-000028:mdna:42]
Other Income, Net (in thousands, except percentages)

[0001596532-25-000028:mdna:43]
Other income (expense), net consists primarily of interest income from our cash, cash equivalents and marketable securities, and gains and losses on our strategic investments.  We expect other income (expense), net may fluctuate in the future as a result of changes in interest rates, changes in our cash, cash equivalents and marketable securities balances, and the re-measurement of our equity investments upon the occurrence of either observable price changes or impairments.

[0001596532-25-000028:mdna:44]
|  |  | Year Ended December 31, |  |  |
|  |  | 2024 |  | 2023 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 310,998 |  |  | 4.4 | % |  | $ | 152,421 |  |  | 2.6 | % |  | $ | 158,577 |  |  | 104.0 | % |
| Other income (expense), net |  | 9,420 |  |  | 0.1 |  |  | 12,356 |  |  | 0.2 |  |  | (2,936) |  |  | (23.8) |  |
| Total other income, net |  | $ | 320,418 |  |  | 4.6 | % |  | $ | 164,777 |  |  | 2.8 | % |  | $ | 155,641 |  |  | 94.5 | % |

[0001596532-25-000028:mdna:45]
The favorable movement in other income (expense), net, during the year ended December 31, 2024 as compared to 2023 was driven by an increase in interest income of $158.6 million due to an increase in our cash and marketable securities balances, coupled with higher investment yields.

[0001596532-25-000028:mdna:46]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-25-000028:mdna:47]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. Earnings from our non-U.S. activities are subject to local country income tax and may also be subject to U.S. income tax. Generally, our U.S. tax obligations are reduced by a credit for foreign income taxes paid on these foreign earnings, which avoids double taxation. Our tax expense to date consists of federal, state and foreign current and deferred income taxes.

[0001596532-25-000028:mdna:48]
|  |  | Year Ended December 31, |  |  |
|  |  | 2024 |  | 2023 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Provision for income taxes |  | $ | 412,980 |  |  | 5.9 | % |  | $ | 334,705 |  |  | 5.7 | % |  | $ | 78,275 |  |  | 23.4 | % |
| Effective tax rate |  | 12.6 | % |  |  |  | 13.8 | % |  |  |  |  |  |  |

[0001596532-25-000028:mdna:49]
Our provision for income taxes increased for the year ended December 31, 2024, as compared to 2023, while our effective tax rate decreased for the year ended December 31, 2024, as compared to 2023. The increase in our income taxes was largely due to an increase in pre-tax income, partly offset by a decrease in our effective tax rate due to favorable changes in state taxes and tax benefits attributable to stock-based compensation. For further information regarding income taxes and the impact on our results of operations and financial position, refer to Note 8. Income Taxes of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K.

[0001596532-25-000028:mdna:50]
Year Ended December 31, 2023 Compared to Year Ended December 31, 2022

[0001596532-25-000028:mdna:51]
Revenue, Cost of Revenue and Gross Margin (in thousands, except percentages)

[0001596532-25-000028:mdna:52]
|  |  | Year Ended December 31, |  |  |
|  |  | 2023 |  | 2022 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,029,493 |  |  | 85.8 | % |  | $ | 3,716,079 |  |  | 84.8 | % |  | $ | 1,313,414 |  |  | 35.3 | % |
| Service |  | 830,675 |  |  | 14.2 |  |  | 665,231 |  |  | 15.2 |  |  | 165,444 |  |  | 24.9 |  |
| Total revenue |  | 5,860,168 |  |  | 100.0 |  |  | 4,381,310 |  |  | 100.0 |  |  | 1,478,858 |  |  | 33.8 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 2,061,167 |  |  | 35.2 |  |  | 1,573,629 |  |  | 35.9 |  |  | 487,538 |  |  | 31.0 |  |
| Service |  | 168,720 |  |  | 2.9 |  |  | 131,985 |  |  | 3.0 |  |  | 36,735 |  |  | 27.8 |  |
| Total cost of revenue |  | 2,229,887 |  |  | 38.1 |  |  | 1,705,614 |  |  | 38.9 |  |  | 524,273 |  |  | 30.7 |  |
| Gross profit |  | $ | 3,630,281 |  |  | 61.9 | % |  | $ | 2,675,696 |  |  | 61.1 | % |  | $ | 954,585 |  |  | 35.7 | % |
| Gross margin |  | 61.9 | % |  |  |  | 61.1 | % |  |  |  |  |  |  |

[0001596532-25-000028:mdna:53]
Revenue by Geography (in thousands, except percentages)

[0001596532-25-000028:mdna:54]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | % of Total |  | 2022 |  | % of Total |
| Americas |  | $ | 4,651,193 |  |  | 79.4 | % |  | $ | 3,462,621 |  |  | 79.0 | % |
| Europe, Middle East and Africa |  | 670,960 |  |  | 11.4 |  |  | 529,800 |  |  | 12.1 |  |
| Asia-Pacific |  | 538,015 |  |  | 9.2 |  |  | 388,889 |  |  | 8.9 |  |
| Total revenue |  | $ | 5,860,168 |  |  | 100.0 | % |  | $ | 4,381,310 |  |  | 100.0 | % |

[0001596532-25-000028:mdna:55]
Revenue

[0001596532-25-000028:mdna:56]
Product revenue increased by $1.3 billion, or 35.3%, for the year ended December 31, 2023 compared to 2022. These increases reflect increased shipments of our switching and routing products across our customer base, including improved supply availability for our enterprise customers. In addition, service revenue increased by $165.4 million, or 24.9%, in the year ended December 31, 2023 compared to 2022, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenues as a percentage of our total revenues decreased from 21.0% in 2022 to 20.6% in 2023, which was primarily driven by changes in the geographic mix of sales to our large global customers.

[0001596532-25-000028:mdna:57]
Cost of Revenue and Gross Margin

[0001596532-25-000028:mdna:58]
Cost of revenue increased by $524.3 million, or 30.7% for the year ended December 31, 2023 compared to 2022. These increases were primarily driven by a corresponding increase in product and service revenues, combined with an increase in provisions for excess/obsolete inventory and supplier liability charges.

[0001596532-25-000028:mdna:59]
Gross margin increased from 61.1% for the year ended December 31, 2022 to 61.9% for the year ended December 31, 2023. These changes reflect an improvement in product margins driven by a lower mix of revenue from our larger customers, partly offset by an increase in excess/obsolete inventory-related charges. In addition, our gross margin benefited in 2023 from the leverage of relatively fixed overhead costs on a higher revenue base.

[0001596532-25-000028:mdna:60]
61

[0001596532-25-000028:mdna:61]
Operating Expenses (in thousands, except percentages)

[0001596532-25-000028:mdna:62]
|  |  | Year Ended December 31, |  |  |
|  |  | 2023 |  | 2022 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 854,918 |  |  | 14.6 | % |  | $ | 728,394 |  |  | 16.6 | % |  | $ | 126,524 |  |  | 17.4 | % |
| Sales and marketing |  | 399,034 |  |  | 6.8 |  |  | 326,955 |  |  | 7.5 |  |  | 72,079 |  |  | 22.0 |  |
| General and administrative |  | 119,080 |  |  | 2.0 |  |  | 93,241 |  |  | 2.1 |  |  | 25,839 |  |  | 27.7 |  |
| Total operating expenses |  | $ | 1,373,032 |  |  | 23.4 | % |  | $ | 1,148,590 |  |  | 26.2 | % |  | $ | 224,442 |  |  | 19.5 | % |

[0001596532-25-000028:mdna:63]
Research and development

[0001596532-25-000028:mdna:64]
Research and development expenses increased by $126.5 million, or 17.4%, for the year ended December 31, 2023 compared to 2022. The increase was primarily due to a $84.1 million increase in personnel costs driven by an increase in headcount, and a $40.7 million increase in new product introduction costs, including non-recurring engineering costs and prototype expenses as we expand our product portfolio.

[0001596532-25-000028:mdna:65]
Sales and marketing

[0001596532-25-000028:mdna:66]
Sales and marketing expenses increased by $72.1 million, or 22.0%, for the year ended December 31, 2023 compared to 2022. The increase was primarily caused by increased personnel costs driven by headcount growth, in addition to increased sales and marketing events and field demonstration costs.

[0001596532-25-000028:mdna:67]
General and administrative

[0001596532-25-000028:mdna:68]
General and administrative expenses increased by $25.8 million, or 27.7%, for the year ended December 31, 2023 compared to 2022. The increase was primarily caused by an increase in personnel costs driven by increased stock-based compensation, and increased legal and professional fees.

[0001596532-25-000028:mdna:69]
Other Income, Net (in thousands, except percentages)

[0001596532-25-000028:mdna:70]
|  |  | Year Ended December 31, |  |  |
|  |  | 2023 |  | 2022 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Other income, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 152,421 |  |  | 2.6 | % |  | $ | 27,556 |  |  | 0.6 | % |  | $ | 124,865 |  |  | 453.1 | % |
| Other income (expense), net |  | 12,356 |  |  | 0.2 |  |  | 27,134 |  |  | 0.6 |  |  | (14,778) |  |  | (54.5) |  |
| Total other income, net |  | $ | 164,777 |  |  | 2.8 | % |  | $ | 54,690 |  |  | 1.2 | % |  | $ | 110,087 |  |  | 201.3 | % |

[0001596532-25-000028:mdna:71]
The favorable movement in other income (expense), net, during the year ended December 31, 2023 as compared to 2022 was driven by an increase in interest income of $124.9 million due to an increase in our cash and investments balances and higher interest rates.

[0001596532-25-000028:mdna:72]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-25-000028:mdna:73]
|  |  | Year Ended December 31, |  |  |
|  |  | 2023 |  | 2022 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Provision for income taxes |  | $ | 334,705 |  |  | 5.7 | % |  | $ | 229,350 |  |  | 5.2 | % |  | $ | 105,355 |  |  | 45.9 | % |
| Effective tax rate |  | 13.8 | % |  |  |  | 14.5 | % |  |  |  |  |  |  |

[0001596532-25-000028:mdna:74]
Our provision for income taxes increased in 2023, as compared to 2022, and our effective tax rate decreased in 2023 as compared to 2022. The increase in our income taxes was largely due to an increase in pre-tax income, partly offset by an

[0001596532-25-000028:mdna:75]
increase in tax benefits attributable to stock-based compensation. The decrease in our effective tax rate was primarily due to a reduction of unrecognized tax benefits on uncertain tax positions due to the expiration of the statute of limitations. For further information regarding income taxes and the impact on our results of operations and financial position, refer to Note 8. Income Taxes of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K.

[0001596532-25-000028:mdna:76]
Liquidity and Capital Resources

[0001596532-25-000028:mdna:77]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of December 31, 2024, our total balance of cash, cash equivalents and marketable securities was $8.3 billion, of which approximately $1.4 billion was held outside the U.S. in our foreign subsidiaries.

[0001596532-25-000028:mdna:78]
Our cash, cash equivalents and marketable securities are held for general business purposes, including the funding of working capital. Our marketable securities investment portfolio is primarily invested in highly-rated securities, with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations, will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, stock repurchases, and capital expenditures, including the construction of a new building in Santa Clara, California. In addition, although the global supply chain has shown improvement, we have had to invest in inventory to address forecast uncertainty and expect that our inventory and purchase commitments will remain volatile as we ramp new product introductions. In particular, we have increased our purchase commitments to respond to the rapid deployment of AI networks and reduce overall lead times which will increase our working capital requirements. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-25-000028:mdna:79]
Cash Flows

[0001596532-25-000028:mdna:80]
|  |  | Year Ended December 31, |
|  |  | 2024 |  | 2023 |  | 2022 |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 3,708,235 |  |  | $ | 2,034,014 |  |  | $ | 492,813 |  |
| Cash provided by (used in) investing activities |  | (2,457,354) |  |  | (687,454) |  |  | 216,327 |  |
| Cash (used in) financing activities |  | (421,810) |  |  | (83,749) |  |  | (654,601) |  |
| Effect of exchange rate changes |  | (4,767) |  |  | 675 |  |  | (3,611) |  |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 824,304 |  |  | $ | 1,263,486 |  |  | $ | 50,928 |  |

[0001596532-25-000028:mdna:81]
Cash Flows from Operating Activities

[0001596532-25-000028:mdna:82]
Our operating activities consist of net income, adjusted for certain non-cash items, and changes in operating assets and liabilities.

[0001596532-25-000028:mdna:83]
During the year ended December 31, 2024, cash provided by operating activities was $3.7 billion, primarily from net income of $2.9 billion along with a net decrease in working capital requirements of $985.2 million, offset by net non-cash adjustments to net income of $129.0 million. Cash inflows consisted of an increase in deferred revenue of $1.3 billion resulting from increased customer PCS contracts and an increase in product deferred revenue related to customer contracts with acceptance terms, and a $110.6 million decrease in inventory resulting from strong product shipments. These cash inflows were partially offset by a $234.2 million increase in other assets driven by increased deferred cost of sales associated with higher product revenue deferrals, an increase in accounts receivable of $106.1 million due to increased product and service billings and a $66.5 million increase in income tax payments due to timing. Net non-cash adjustments primarily consisted of an increase in deferred income taxes of $492.9 million primarily resulting from increased deferred tax assets associated with the increase in deferred revenue and capitalization of research and development costs under IRC Section 174, which were largely offset by $355.4 million of stock-based compensation expenses.

[0001596532-25-000028:mdna:84]
During the year ended December 31, 2023, cash provided by operating activities was $2.0 billion, primarily from net income of $2.1 billion, offset by net non-cash adjustments to net income of $37.4 million, and a net change of $15.9 million in working capital requirements. Net non-cash adjustments primarily consisted of an increase in deferred income taxes of $370.8 million primarily resulting from increased deferred tax assets associated with the capitalization of research and development costs under IRC Section 174, which were largely offset by $296.8 million of stock-based compensation expenses and $70.6 million of depreciation, amortization and other expenses. The change in working capital requirements primarily consisted of a $655.5 million increase in inventory in response to a significant increase in business volume, a $101.5 million increase in accounts receivable due to the larger business volume and timing of shipments in the fourth quarter of 2023, as well as a $66.4 million increase in other assets primarily driven by increased deferred cost of sales associated with higher product revenue deferrals. These cash outflows were largely offset by a $465.0 million increase in deferred revenue driven by a growth in PCS contracts and increased product deferred revenue related to customer contracts with acceptance terms, a $322.3 million increase in accounts payable and other liabilities related to significant business volume, timing of payments, and increased supplier and contract manufacturer liability reserves and a $20.2 million increase in income taxes, net, due to timing of payments.

[0001596532-25-000028:mdna:85]
Cash Flows from Investing Activities

[0001596532-25-000028:mdna:86]
Our investing activities primarily consist of our marketable securities investments, business combinations, and capital expenditures.

[0001596532-25-000028:mdna:87]
During the year ended December 31, 2024, cash used in investing activities was $2.5 billion, consisting of purchases of available-for-sale securities of $4.5 billion, partially offset by proceeds of $2.1 billion from maturities and sales of marketable securities.

[0001596532-25-000028:mdna:88]
During the year ended December 31, 2023, cash used in investing activities was $687.5 million, consisting of purchases of available-for-sale securities of $2.6 billion, and purchases of property, equipment and intangible assets of $34.4 million, partially offset by proceeds of $1.9 billion from maturities of marketable securities, and proceeds from the sale of marketable securities of $67.3 million,

[0001596532-25-000028:mdna:89]
Cash Flows from Financing Activities

[0001596532-25-000028:mdna:90]
Our financing activities consist of proceeds from the issuance of our common stock under employee equity incentive plans, offset by repurchases of our common stock.

[0001596532-25-000028:mdna:91]
During the year ended December 31, 2024, cash used in financing activities was $421.8 million, consisting of payments for repurchases of our common stock from the open market of $423.6 million and employee taxes withheld and  paid of $58.4 million upon vesting of restricted stock units, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $60.2 million.

[0001596532-25-000028:mdna:92]
During the year ended December 31, 2023, cash used in financing activities was $83.7 million, consisting primarily of common stock repurchases of $112.3 million and taxes paid of $33.6 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $62.1 million.

[0001596532-25-000028:mdna:93]
Stock Repurchase Programs

[0001596532-25-000028:mdna:94]
From time to time, we repurchase shares of our common stock pursuant to the Repurchase Programs that are funded from working capital. In April 2024, we completed repurchases under our previous $1.0 billion stock repurchase program (“Prior Repurchase Program”).  In May 2024, our board of directors authorized a new $1.2 billion stock repurchase program (“New Repurchase Program” and together with the Prior Repurchase Program, the "Repurchase Programs"), which expires in May 2027. The Repurchase Programs do not obligate us to acquire any of our common stock, and may be suspended or discontinued by the company at any time without prior notice. During the year ended December 31, 2024, we repurchased a total of $279.0 million of our common stock under our New Repurchase Program and $144.6 million of our common stock under our Prior Repurchase Program. As of December 31, 2024, the remaining authorized amount for stock repurchases under the New Repurchase Program was approximately $921.0 million. Refer to Note 6. Stockholders' Equity and Stock-Based Compensation of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K for further discussion.

[0001596532-25-000028:mdna:95]
Material Cash Requirements

[0001596532-25-000028:mdna:96]
Our material cash requirements will have an impact on our future liquidity. Our material cash requirements represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalents and marketable securities.

[0001596532-25-000028:mdna:97]
Our material cash requirements include the following contractual and other obligations:

[0001596532-25-000028:mdna:98]
Purchase Obligations

[0001596532-25-000028:mdna:99]
Purchase obligations not recorded on our balance sheet represent an estimate of all non-cancellable open purchase orders and contractual obligations, made either directly by Arista or by our contract manufacturers on our behalf, in the ordinary course of business for which we have not received the goods or services. As of December 31, 2024, we had $3.1 billion of such purchase obligations, of which $2.8 billion are expected to be received within 12 months, and $0.3 billion are expected to be received after one year.  These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-25-000028:mdna:100]
Leases

[0001596532-25-000028:mdna:101]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of December 31, 2024, we had lease payment obligations, net of immaterial sublease income, of $65.3 million, with $24.7 million payable within 12 months.

[0001596532-25-000028:mdna:102]
Property project

[0001596532-25-000028:mdna:103]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office, lab and data center space. The estimated capital expenditures related to this project is expected to be approximately $235.0 million to $260.0 million for the next two years, with construction expected to be completed by the end of fiscal 2026.

[0001596532-25-000028:mdna:104]
Accrued Income Taxes

[0001596532-25-000028:mdna:105]
As of December 31, 2024, we have recorded long-term tax liabilities of $110.0 million related to uncertain tax positions; however, we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-25-000028:mdna:106]
In connection with the TCJA, effective from January 1st, 2022, the TCJA eliminates the option to deduct research and development expenditures currently and requires taxpayers to capitalize and amortize them over five or fifteen years pursuant to Internal Revenue Code (“IRC”) Section 174. As of December 31, 2024, the incremental cash tax impact resulting from the regulation was approximately $210.2 million for the year, of which substantially all the liability has been paid. It is anticipated that IRC Section 174 will result in cash tax outlays exceeding our income tax expense over the next three years unless the current legislation is changed. There is no material change to our effective tax rate as a result of this regulation.

[0001596532-25-000028:mdna:107]
Off-balance Sheet Arrangements

[0001596532-25-000028:mdna:108]
As of December 31, 2024, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-25-000028:mdna:109]
Critical Accounting Estimates

[0001596532-25-000028:mdna:110]
We have prepared our consolidated financial statements in accordance with accounting principles generally accepted in the United States ("GAAP" or "U.S. GAAP") and include our accounts and the accounts of our wholly owned subsidiaries. The preparation of these consolidated financial statements requires our management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities at the date of the financial statements, disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the applicable periods. Note 1, “Organization and Summary of Significant Accounting Policies,” of the Notes to Consolidated Financial Statements in Part II, Item 8 of this Form 10-K describes the significant accounting policies and methods used in the preparation of the Company’s consolidated financial statements. We base our estimates, assumptions and judgments on

[0001596532-25-000028:mdna:111]
historical experience and on various other factors that we believe to be reasonable under the circumstances. Different assumptions and judgments would change the estimates used in the preparation of our consolidated financial statements, which, in turn, could change the results from those reported. We evaluate our estimates, assumptions and judgments on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001596532-25-000028:mdna:112]
Revenue Recognition

[0001596532-25-000028:mdna:113]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with PCS. We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts which contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is required to determine the SSP for each distinct performance obligation. We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

[0001596532-25-000028:mdna:114]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information, such as gross margin objectives, market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to, product category, actual and expected volume, discounting policies, and customer vertical and size.

[0001596532-25-000028:mdna:115]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We defer revenue recognition on customer contracts for new products or use cases, which contain customer-specified requirements that must be met prior to acceptance. We include some or all of an estimate of the related at-risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

[0001596532-25-000028:mdna:116]
We have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

[0001596532-25-000028:mdna:117]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-25-000028:mdna:118]
Inventories primarily consist of finished goods, including evaluation inventory held at customers or partners, and strategic components, primarily integrated circuits. Inventories are stated at the lower of cost (computed using the first-in, first-out method) and net realizable value. Evaluation inventory consists of new products and/or use cases at customer or partner sites for trial purposes. Title to the inventory remains with Arista during the trial period and invoicing occurs only upon completion of the trial period and when/if the products have been accepted by the customer.  Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory. We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value.

[0001596532-25-000028:mdna:119]
Our contract manufacturers procure components and assemble products on our behalf and we procure strategic components from suppliers based on our forecasts. We record a liability and a corresponding charge for non-cancellable, non-returnable purchase commitments with our contract  manufacturers and suppliers for quantities in excess of our demand forecasts or that are considered obsolete due to manufacturing and engineering change orders resulting from design changes.

[0001596532-25-000028:mdna:120]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels. In addition, industry-wide supply chain shortages in prior years have resulted in extended lead times for some

[0001596532-25-000028:mdna:121]
components, and consequently we were required to extend the time horizon of our demand forecasts. We have experienced some improvements in the supply chain throughout the year, and as customer lead times reduce more broadly, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to shorter demand-planning horizons. In addition, we expect that our inventory and purchase commitments will remain volatile as we ramp new product introductions. There is however no guarantee that all suppliers will meet their commitments in the time frame committed or that actual customer demand will directly match our demand forecasts. If actual market demand conditions or supplier execution on commitments are less favorable than those projected by management, which may be caused by factors within and/or outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer and supplier liabilities.

[0001596532-25-000028:mdna:122]
Income Taxes

[0001596532-25-000028:mdna:123]
Significant management judgment is required in developing our provision for or benefit from income taxes, including the determination of deferred tax assets and liabilities and any valuation allowances that might be required against the deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results and estimates of our ability to generate sufficient future taxable income in certain foreign and state tax jurisdictions, future reversals of taxable temporary differences, and potential tax planning strategies. An adjustment to the valuation allowance will either increase or decrease our provision for or benefit from income taxes in the period such determination is made.

[0001596532-25-000028:mdna:124]
We are subject to income taxes in the U.S. and numerous foreign jurisdictions, which involves significant judgment in the interpretation of complex domestic and international tax laws and may give rise to uncertain tax positions. We recognize potential liabilities for anticipated tax audit issues in the U.S. and other tax jurisdictions based on our estimate of whether it is more likely than not that additional taxes, interest, and penalties will be due. Although management believes our unrecognized tax benefits are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our unrecognized tax benefits. Our unrecognized tax benefits are adjusted considering changing facts and circumstances, such as the closing of a tax examination or the refinement of an estimate. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on our financial condition and operating results.

[0001596532-25-000028:mdna:125]
Recent Accounting Pronouncements

[0001596532-25-000028:mdna:126]
Refer to the subheading titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K.

[0001596532-25-000028:mdna:127]
67
