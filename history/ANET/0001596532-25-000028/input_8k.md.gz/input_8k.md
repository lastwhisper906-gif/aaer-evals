# ANET 8-K — 0001596532-25-000018 filed 2025-02-18

## item codes, every 8-K on or before 2025-02-19

- 2025-02-18 0001596532-25-000018 — 2.02, 9.01
- 2024-12-03 0001596532-24-000402 — 5.03, 9.01
- 2024-11-07 0001596532-24-000366 — 2.02, 8.01, 9.01
- 2024-07-30 0001596532-24-000277 — 2.02, 9.01
- 2024-06-10 0001596532-24-000233 — 5.07
- 2024-05-24 0001596532-24-000219 — 8.01
- 2024-05-07 0001596532-24-000171 — 2.02, 8.01, 9.01
- 2024-04-23 0001596532-24-000155 — 5.02, 9.01
- 2024-04-19 0001596532-24-000152 — 5.02, 8.01
- 2024-02-28 0001596532-24-000095 — 8.01
- 2024-02-12 0001596532-24-000041 — 2.02, 9.01
- 2023-12-20 0001596532-23-000349 — 5.03, 9.01
- 2023-12-01 0001596532-23-000324 — 5.02, 8.01, 9.01
- 2023-10-30 0001596532-23-000272 — 2.02, 9.01
- 2023-07-31 0001596532-23-000196 — 2.02, 5.02, 9.01
- 2023-06-16 0001596532-23-000168 — 5.07
- 2023-05-01 0001596532-23-000101 — 2.02, 9.01
- 2023-02-13 0001596532-23-000015 — 2.02, 9.01
- 2022-10-31 0001596532-22-000292 — 2.02, 9.01
- 2022-10-25 0001596532-22-000282 — 5.03, 9.01
- 2022-08-01 0001596532-22-000218 — 2.02, 9.01
- 2022-07-25 0001596532-22-000205 — 5.02
- 2022-06-03 0001596532-22-000179 — 5.07
- 2022-05-02 0001596532-22-000111 — 2.02, 9.01
- 2022-03-29 0001596532-22-000100 — 5.02
- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2025-02-19

- none on or before 2025-02-19

## item 2.02 — earnings release, exhibit 99.1

[0001596532-25-000018:8k_2_02:1]
EX-99.1
2
ex991q424-earningsrelease.htm
EX-99.1

[0001596532-25-000018:8k_2_02:2]
Document

[0001596532-25-000018:8k_2_02:3]
Exhibit 99.1

[0001596532-25-000018:8k_2_02:4]
Arista Networks, Inc. Reports Fourth Quarter and Year End 2024 Financial Results

[0001596532-25-000018:8k_2_02:5]
SANTA CLARA, Calif.- February 18, 2025 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus and routing environments, today announced financial results for its fourth quarter and the full year ended December 31, 2024.

[0001596532-25-000018:8k_2_02:6]
"2024 was a remarkable year of momentum resulting in a record $7 billion in revenue," stated Jayshree Ullal, Chairperson and CEO for Arista Networks. "I am so proud of the team's execution in delivering the ultimate combination of superior growth and profitability. We continued to innovate for our customers with best-of-breed platforms enabling AI for networking and networking for AI."

[0001596532-25-000018:8k_2_02:7]
Full Year Financial Highlights

[0001596532-25-000018:8k_2_02:8]
•Revenue of $7.003 billion, an increase of 19.5% compared to fiscal year 2023.

[0001596532-25-000018:8k_2_02:9]
•GAAP gross margin of 64.1%, compared to GAAP gross margin of 61.9% in fiscal year 2023.

[0001596532-25-000018:8k_2_02:10]
•Non-GAAP gross margin of 64.6%, compared to non-GAAP gross margin of 62.6% in fiscal year 2023.

[0001596532-25-000018:8k_2_02:11]
•GAAP net income of $2.852 billion, or $2.23 per diluted share, compared to GAAP net income of $2.087 billion, or $1.65 per diluted share, in fiscal year 2023.

[0001596532-25-000018:8k_2_02:12]
•Non-GAAP net income of $2.910 billion or $2.27 per diluted share, compared to non-GAAP net income of $2.199 billion or $1.73 per diluted share, in fiscal year 2023.

[0001596532-25-000018:8k_2_02:13]
Fourth Quarter Financial Highlights

[0001596532-25-000018:8k_2_02:14]
•Revenue of $1.930 billion, an increase of 6.6% compared to the third quarter of 2024, and an increase of 25.3% from the fourth quarter of 2023.

[0001596532-25-000018:8k_2_02:15]
•GAAP gross margin of 63.8%, compared to GAAP gross margin of 64.2% in the third quarter of 2024 and 64.9% in the fourth quarter of 2023.

[0001596532-25-000018:8k_2_02:16]
•Non-GAAP gross margin of 64.2%, compared to non-GAAP gross margin of 64.6% in the third quarter of 2024 and 65.4% in the fourth quarter of 2023.

[0001596532-25-000018:8k_2_02:17]
•GAAP net income of $801.0 million, or $0.62 per diluted share, compared to GAAP net income of $613.6 million, or $0.48 per diluted share, in the fourth quarter of 2023.

[0001596532-25-000018:8k_2_02:18]
•Non-GAAP net income of $830.1 million, or $0.65 per diluted share, compared to non-GAAP net income of $664.3 million, or $0.52 per diluted share, in the fourth quarter of 2023.

[0001596532-25-000018:8k_2_02:19]
Commenting on the company's financial results, Chantelle Breithaupt, Arista’s CFO said, "We delivered exceptional financial performance in Q4, exceeding our guidance on all key metrics. These results generated over 95% year-over-year growth in operating cash flow for the quarter, allowing us to continue to invest in strategic initiatives such as the AI and Campus markets. Our strong balance sheet and robust cash position allow us to navigate economic uncertainties while continuing to invest in our long-term growth.”

[0001596532-25-000018:8k_2_02:20]
Fourth Quarter Company Highlights

[0001596532-25-000018:8k_2_02:21]
•Meta and Arista Build AI at Scale – Arista shared that Meta has deployed the Arista 7700R4 Distributed Etherlink™ Switch (DES) for its latest Ethernet-based AI cluster.

[0001596532-25-000018:8k_2_02:22]
•Arista Unveiled Modern Stacking for Campus Networks – Arista introduced the Switch Aggregation Group (SWAG™) capability in Arista EOS® that uses industry-standard Ethernet to group and manage individual switches via a single IP address. In addition, Arista CloudVision® Leaf Spine Stack (LSS™)

[0001596532-25-000018:8k_2_02:23]
Management allows operators to collectively manage a logical stack of switches within a single networking closet or across the entire campus.

[0001596532-25-000018:8k_2_02:24]
•Arizona State University (ASU) Announced the Partnership with Arista for its Refugee Program - In October 2024, a group of eight students that joined ASU as part of the Afghan Refugee Program completed the Technical Upskilling Program, co-created by ASU Enterprise Technology and Arista.

[0001596532-25-000018:8k_2_02:25]
•Arista Networks Completed a Four-for-One Stock Split - Arista announced a four-for-one forward stock split that was affected through the filing of an amendment to the Company's Amended and Restated Certificate of Incorporation on December 3, 2024, upon which date each Arista shareholder received an additional three shares of Arista common stock. Trading began on a split-adjusted basis on December 4, 2024.

[0001596532-25-000018:8k_2_02:26]
Full Year Company Highlights

[0001596532-25-000018:8k_2_02:27]
•Arista Unveils Etherlink AI Networking Platforms – Arista announced the Etherlink AI platforms, which support AI cluster sizes ranging from thousands to hundreds of thousands of XPUs with highly efficient one- and two-tier network topologies, offering superior application performance compared to multi-tier networks.

[0001596532-25-000018:8k_2_02:28]
•Arista Delivers Holistic AI Solutions in Collaboration with NVIDIA – Arista, in collaboration with NVIDIA, showcased its Arista EOS AI Agent, designed to align compute and network domains as a single-managed AI entity and thus help lower job completion times.

[0001596532-25-000018:8k_2_02:29]
•Arista Launched Wi-Fi 7 Access Points - The Arista C-460 is designed to help enterprises address the challenges of rapidly increasing bandwidth requirements, including AR/VR (augmented reality/virtual reality) applications, streaming multimedia, IoT proliferation, video applications and high-density deployments.

[0001596532-25-000018:8k_2_02:30]
•Arista Launches Next Generation Multi-Domain Segmentation for Zero Trust Networking – Arista announced updates to its Arista MSSⓇ (Multi-Domain Segmentation Service) offerings, designed to restrict lateral movement in campus and data center networks without the need for endpoint agents.

[0001596532-25-000018:8k_2_02:31]
•Arista Introduces Universal Network Observability – Arista launched CloudVision Universal Network Observability™ (CV UNO™) to automate network, systems, and application/workload visibility and provide AI-driven proactive analysis and prescriptive recommendations.

[0001596532-25-000018:8k_2_02:32]
•Alabama Fiber Network Selects Arista Networks for Statewide Middle-Mile Initiative - Arista announced that the Alabama Fiber Network (AFN) selected Arista as its routing and switching equipment provider to help deliver affordable, high-capacity, and reliable internet access in underserved rural areas.

[0001596532-25-000018:8k_2_02:33]
•Arista Celebrated the 20th Anniversary of the Company and the 10th Anniversary of its IPO – In that time, Arista has achieved milestones such as over 10,000 customers and 100 million ports installed globally and attained the #1 market share in data center switching.

[0001596532-25-000018:8k_2_02:34]
Financial Outlook

[0001596532-25-000018:8k_2_02:35]
For the first quarter of 2025, we expect:

[0001596532-25-000018:8k_2_02:36]
•Revenue between $1.93 billion to $1.97 billion;

[0001596532-25-000018:8k_2_02:37]
•Non-GAAP gross margin of approximately 63%; and

[0001596532-25-000018:8k_2_02:38]
•Non-GAAP operating margin of approximately 44%.

[0001596532-25-000018:8k_2_02:39]
Guidance for non-GAAP financial measures excludes certain items, including stock-based compensation expense, intangible asset amortization, and potential non-recurring charges or benefits. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis without unreasonable effort because these exclusions can be uncertain or difficult to predict, including stock-based compensation expense which is impacted by the timing of employee stock transactions, the company’s future hiring and retention needs and the future fair market value of the company’s common stock. The actual amount of these exclusions will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-25-000018:8k_2_02:40]
Prepared Materials and Conference Call Information

[0001596532-25-000018:8k_2_02:41]
Arista's executives will discuss the fourth quarter and year end 2024 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-25-000018:8k_2_02:42]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-25-000018:8k_2_02:43]
Forward-Looking Statements

[0001596532-25-000018:8k_2_02:44]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the first quarter of 2025, statements regarding the benefits of Arista's products, and statements regarding Arista's ability to navigate economic uncertainties while continuing to invest in our long-term growth. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: large purchases by a limited number of customers who represent a substantial portion of our revenue; adverse economic and geopolitical conditions and conflicts, continuing uncertain economic conditions or reduced information technology and network infrastructure spending; the impact of sole or limited sources of supply, supply shortages and extended lead times or supply changes; volatility in our revenue growth rate; variations in our results of operations; the rapid evolution of the networking market; failure to successfully carry out new products and service offerings and expand into adjacent markets; variability in our gross margins; intense competition and industry consolidation; expansion of our international sales and operations; investments in or acquisitions of other businesses; seasonality and industry cyclicality; fluctuations in currency exchange rates; failure to raise additional capital on favorable terms; our inability to attract new large customers or sell additional products and services to our existing customers; inability to grow sales of switches which generate most of our product revenue; large customers requiring more favorable terms; inability to increase market awareness or acceptance of our new products and services; decreases in the sales prices of our products and services; long and unpredictable sales cycles; inability to offer high quality support and services; declines in maintenance renewals by customers; product quality problems; failure to anticipate technological shifts; the complexity of managing the supply of our products and product components; our dependence on third-party manufacturers to build our products; assertions by third parties of intellectual property rights infringement; failure or inability to protect or assert our intellectual property rights; defects, errors or vulnerabilities in our products, the failure of our products to detect security breaches or incidents, the misuse of our products or the risks or product liability; breaches of our cybersecurity systems, or other security or privacy breaches or incidents; enhanced U.S. tax, tariff, import/export restrictions, Chinese regulations or other trade barriers; failure to comply with government law and regulations; issues in the development and use of artificial intelligence, combined with an uncertain regulatory environment; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-25-000018:8k_2_02:45]
3

[0001596532-25-000018:8k_2_02:46]
Non-GAAP Financial Measures

[0001596532-25-000018:8k_2_02:47]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, intangible asset amortization, expenses related to legal settlement, gains/losses on strategic investments, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-25-000018:8k_2_02:48]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-25-000018:8k_2_02:49]
About Arista Networks

[0001596532-25-000018:8k_2_02:50]
Arista Networks is an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus and routing environments. Its award-winning platforms deliver availability, agility, automation, analytics, and security through an advanced network operating stack. For more information, visit www.arista.com.

[0001596532-25-000018:8k_2_02:51]
ARISTA, CloudVision and Etherlink are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-25-000018:8k_2_02:52]
ARISTA NETWORKS, INC.

[0001596532-25-000018:8k_2_02:53]
Condensed Consolidated Statements of Income

[0001596532-25-000018:8k_2_02:54]
(Unaudited, in thousands, except per share amounts)

[0001596532-25-000018:8k_2_02:55]
|  |  | Three Months Ended December 31, |  | Twelve Months Ended December 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,608,098 |  |  | $ | 1,310,314 |  |  | $ | 5,884,021 |  |  | $ | 5,029,493 |  |
| Service |  | 322,338 |  |  | 230,123 |  |  | 1,119,125 |  |  | 830,675 |  |
| Total revenue |  | 1,930,436 |  |  | 1,540,437 |  |  | 7,003,146 |  |  | 5,860,168 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 643,648 |  |  | 495,826 |  |  | 2,299,063 |  |  | 2,061,167 |  |
| Service |  | 55,794 |  |  | 45,385 |  |  | 212,780 |  |  | 168,720 |  |
| Total cost of revenue |  | 699,442 |  |  | 541,211 |  |  | 2,511,843 |  |  | 2,229,887 |  |
| Total gross profit |  | 1,230,994 |  |  | 999,226 |  |  | 4,491,303 |  |  | 3,630,281 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 285,016 |  |  | 211,481 |  |  | 996,717 |  |  | 854,918 |  |
| Sales and marketing |  | 110,949 |  |  | 105,538 |  |  | 427,264 |  |  | 399,034 |  |
| General and administrative |  | 35,377 |  |  | 42,293 |  |  | 122,706 |  |  | 119,080 |  |
| Total operating expenses |  | 431,342 |  |  | 359,312 |  |  | 1,546,687 |  |  | 1,373,032 |  |
| Income from operations |  | 799,652 |  |  | 639,914 |  |  | 2,944,616 |  |  | 2,257,249 |  |
| Other income, net |  | 89,275 |  |  | 54,477 |  |  | 320,418 |  |  | 164,777 |  |
| Income before income taxes |  | 888,927 |  |  | 694,391 |  |  | 3,265,034 |  |  | 2,422,026 |  |
| Provision for income taxes |  | 87,931 |  |  | 80,755 |  |  | 412,980 |  |  | 334,705 |  |
| Net income |  | $ | 800,996 |  |  | $ | 613,636 |  |  | $ | 2,852,054 |  |  | $ | 2,087,321 |  |
| Earnings per share (1): |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.64 |  |  | $ | 0.49 |  |  | $ | 2.27 |  |  | $ | 1.69 |  |
| Diluted |  | $ | 0.62 |  |  | $ | 0.48 |  |  | $ | 2.23 |  |  | $ | 1.65 |  |
| Weighted-average common shares outstanding(1): |  |  |  |  |  |  |  |  |
| Basic |  | 1,260,309 |  |  | 1,246,446 |  |  | 1,256,303 |  |  | 1,237,417 |  |
| Diluted |  | 1,283,370 |  |  | 1,275,380 |  |  | 1,281,077 |  |  | 1,268,538 |  |
| ______________________ |  |  |  |  |  |  |  |  |
| (1) Prior period results have been adjusted to reflect the four-for-one stock split effected in December 2024. |

[0001596532-25-000018:8k_2_02:56]
5

[0001596532-25-000018:8k_2_02:57]
ARISTA NETWORKS, INC.

[0001596532-25-000018:8k_2_02:58]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-25-000018:8k_2_02:59]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-25-000018:8k_2_02:60]
|  |  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| GAAP gross profit |  | $ | 1,230,994 |  |  | $ | 999,226 |  |  | $ | 4,491,303 |  |  | $ | 3,630,281 |  |
| GAAP gross margin |  | 63.8 | % |  | 64.9 | % |  | 64.1 | % |  | 61.9 | % |
| Stock-based compensation expense |  | 4,255 |  |  | 3,273 |  |  | 15,786 |  |  | 12,789 |  |
| Intangible asset amortization |  | 4,195 |  |  | 4,195 |  |  | 16,780 |  |  | 23,457 |  |
| Non-GAAP gross profit |  | $ | 1,239,444 |  |  | $ | 1,006,694 |  |  | $ | 4,523,869 |  |  | $ | 3,666,527 |  |
| Non-GAAP gross margin |  | 64.2 | % |  | 65.4 | % |  | 64.6 | % |  | 62.6 | % |
| GAAP income from operations |  | $ | 799,652 |  |  | $ | 639,914 |  |  | $ | 2,944,616 |  |  | $ | 2,257,249 |  |
| GAAP operating margin |  | 41.4 | % |  | 41.5 | % |  | 42.0 | % |  | 38.5 | % |
| Stock-based compensation expense |  | 100,734 |  |  | 81,358 |  |  | 355,364 |  |  | 296,756 |  |
| Intangible asset amortization |  | 6,690 |  |  | 6,690 |  |  | 26,760 |  |  | 33,437 |  |
| Legal settlement (1) |  | — |  |  | 16,000 |  |  | — |  |  | 16,000 |  |
| Non-GAAP income from operations |  | $ | 907,076 |  |  | $ | 743,962 |  |  | $ | 3,326,740 |  |  | $ | 2,603,442 |  |
| Non-GAAP operating margin |  | 47.0 | % |  | 48.3 | % |  | 47.5 | % |  | 44.4 | % |
| GAAP net income |  | $ | 800,996 |  |  | $ | 613,636 |  |  | $ | 2,852,054 |  |  | $ | 2,087,321 |  |
| Stock-based compensation expense |  | 100,734 |  |  | 81,358 |  |  | 355,364 |  |  | 296,756 |  |
| Intangible asset amortization |  | 6,690 |  |  | 6,690 |  |  | 26,760 |  |  | 33,437 |  |
| Gain on strategic investments |  | — |  |  | — |  |  | (12,400) |  |  | (18,699) |  |
| Tax benefit on stock-based awards |  | (61,583) |  |  | (40,561) |  |  | (254,662) |  |  | (174,122) |  |
| Income tax effect on non-GAAP exclusions |  | (16,730) |  |  | (12,795) |  |  | (57,594) |  |  | (41,283) |  |
| Legal settlement (1) |  | — |  |  | 16,000 |  |  | — |  |  | 16,000 |  |
| Non-GAAP net income |  | $ | 830,107 |  |  | $ | 664,328 |  |  | $ | 2,909,522 |  |  | $ | 2,199,410 |  |
| GAAP diluted net income per share (2) |  | $ | 0.62 |  |  | $ | 0.48 |  |  | $ | 2.23 |  |  | $ | 1.65 |  |
| Non-GAAP adjustments to net income(2) |  | 0.03 |  |  | 0.04 |  |  | 0.04 |  |  | 0.08 |  |
| Non-GAAP diluted net income per share(2) |  | $ | 0.65 |  |  | $ | 0.52 |  |  | $ | 2.27 |  |  | $ | 1.73 |  |
| Weighted-average shares used in computing diluted net income per share(2) |  | 1,283,370 |  |  | 1,275,380 |  |  | 1,281,077 |  |  | 1,268,538 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 4,255 |  |  | $ | 3,273 |  |  | $ | 15,786 |  |  | $ | 12,789 |  |
| Research and development |  | 58,910 |  |  | 46,506 |  |  | 211,807 |  |  | 172,177 |  |
| Sales and marketing |  | 22,132 |  |  | 19,613 |  |  | 78,762 |  |  | 71,074 |  |
| General and administrative |  | 15,437 |  |  | 11,966 |  |  | 49,009 |  |  | 40,716 |  |
| Total |  | $ | 100,734 |  |  | $ | 81,358 |  |  | $ | 355,364 |  |  | $ | 296,756 |  |

[0001596532-25-000018:8k_2_02:61]
___________________

[0001596532-25-000018:8k_2_02:62]
(1) In the quarter ended December 31, 2023, we agreed to pay $16 million to settle an intellectual property dispute and we recorded this amount to general and administrative expenses.

[0001596532-25-000018:8k_2_02:63]
(2) Prior period results have been adjusted to reflect the four-for-one stock split effected in December 2024.

[0001596532-25-000018:8k_2_02:64]
ARISTA NETWORKS, INC.

[0001596532-25-000018:8k_2_02:65]
Condensed Consolidated Balance Sheets

[0001596532-25-000018:8k_2_02:66]
(Unaudited, in thousands)

[0001596532-25-000018:8k_2_02:67]
|  |  | December 31, 2024 |  | December 31, 2023 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,762,357 |  |  | $ | 1,938,606 |  |
| Marketable securities |  | 5,541,116 |  |  | 3,069,362 |  |
| Accounts receivable, net |  | 1,140,478 |  |  | 1,034,398 |  |
| Inventories |  | 1,834,572 |  |  | 1,945,180 |  |
| Prepaid expenses and other current assets |  | 632,292 |  |  | 412,518 |  |
| Total current assets |  | 11,910,815 |  |  | 8,400,064 |  |
| Property and equipment, net |  | 98,845 |  |  | 101,580 |  |
| Goodwill and acquisition-related intangible assets, net |  | 330,540 |  |  | 357,299 |  |
| Deferred tax assets |  | 1,440,418 |  |  | 945,792 |  |
| Other assets |  | 263,303 |  |  | 151,900 |  |
| TOTAL ASSETS |  | $ | 14,043,921 |  |  | $ | 9,956,635 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 381,083 |  |  | $ | 435,059 |  |
| Accrued liabilities |  | 435,277 |  |  | 407,302 |  |
| Deferred revenue |  | 1,727,280 |  |  | 915,204 |  |
| Other current liabilities |  | 188,582 |  |  | 161,870 |  |
| Total current liabilities |  | 2,732,222 |  |  | 1,919,435 |  |
| Deferred revenue, non-current |  | 1,064,135 |  |  | 591,000 |  |
| Other long-term liabilities |  | 252,757 |  |  | 227,141 |  |
| TOTAL LIABILITIES |  | 4,049,114 |  |  | 2,737,576 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock (1) |  | 126 |  |  | 125 |  |
| Additional paid-in capital (1) |  | 2,465,409 |  |  | 2,108,237 |  |
| Retained earnings |  | 7,542,460 |  |  | 5,114,025 |  |
| Accumulated other comprehensive income (loss) |  | (13,188) |  |  | (3,328) |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 9,994,807 |  |  | 7,219,059 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 14,043,921 |  |  | $ | 9,956,635 |  |
| ______________________ |  |  |  |  |
| (1) Prior period results have been adjusted to reflect the four-for-one stock split effected in December 2024. |

[0001596532-25-000018:8k_2_02:68]
7

[0001596532-25-000018:8k_2_02:69]
ARISTA NETWORKS, INC.

[0001596532-25-000018:8k_2_02:70]
Condensed Consolidated Statements of Cash Flows

[0001596532-25-000018:8k_2_02:71]
(Unaudited, in thousands)

[0001596532-25-000018:8k_2_02:72]
|  |  | Twelve Months Ended December 31, |
|  |  | 2024 |  | 2023 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 2,852,054 |  |  | $ | 2,087,321 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  | 62,038 |  |  | 70,630 |  |
| Stock-based compensation |  | 355,364 |  |  | 296,756 |  |
| Deferred income taxes |  | (492,874) |  |  | (370,796) |  |
| Amortization (accretion) of investment premiums (discount) |  | (60,468) |  |  | (33,518) |  |
| Other |  | 6,939 |  |  | (463) |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (106,080) |  |  | (105,927) |  |
| Inventories |  | 110,608 |  |  | (655,474) |  |
| Other assets |  | (234,242) |  |  | (66,401) |  |
| Accounts payable |  | (51,635) |  |  | 198,612 |  |
| Other liabilities |  | 47,823 |  |  | 128,148 |  |
| Deferred revenue |  | 1,285,211 |  |  | 464,958 |  |
| Income taxes, net |  | (66,503) |  |  | 20,168 |  |
| Net cash provided by operating activities |  | 3,708,235 |  |  | 2,034,014 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 2,058,588 |  |  | 1,887,939 |  |
| Proceeds from sale of marketable securities |  | 48,845 |  |  | 67,284 |  |
| Purchases of marketable securities |  | (4,526,127) |  |  | (2,606,878) |  |
| Purchases of property, equipment and intangible assets |  | (32,032) |  |  | (34,434) |  |
| Other Investing activities |  | (6,628) |  |  | (1,365) |  |
| Net cash used in investing activities |  | (2,457,354) |  |  | (687,454) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 60,181 |  |  | 62,093 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (58,372) |  |  | (33,563) |  |
| Repurchase of common stock |  | (423,619) |  |  | (112,279) |  |
| Net cash used in financing activities |  | (421,810) |  |  | (83,749) |  |
| Effect of exchange rate changes |  | (4,767) |  |  | 675 |  |
| NET INCREASE IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 824,304 |  |  | 1,263,486 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 1,939,464 |  |  | 675,978 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 2,763,768 |  |  | $ | 1,939,464 |  |

[0001596532-25-000018:8k_2_02:73]
| Investor Contacts: |  |
| Arista Networks, Inc. |
| Investor Advocacy |
| Rudolph Araujo |  |
| Rod Hall |  |
| +1 (408) 547-8080 |  |
| ir@arista.com |

[0001596532-25-000018:8k_2_02:74]
9
