# ANET MD&A — 0001596532-15-000013


## mdna

[0001596532-15-000013:mdna:1]
[same as prior period, unchanged from 0001596532-14-000005:mdna:1]

[0001596532-15-000013:mdna:2]
[same as prior period, unchanged from 0001596532-14-000005:mdna:2]

[0001596532-15-000013:mdna:3]
We are a leading supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation data centers for enterprises, based on market share. Our cloud networking solutions consist of our Extensible Operating System, or EOS, a set of network applications and our 10/40/100 Gigabit Ethernet switches. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. At the core of our cloud networking platform is EOS, which was purpose-built to be fully programmable and highly modular. The programmability of EOS has allowed us to create a set of software applications that address the requirements of cloud networking, including workflow automation, network visibility and analytics, and has also allowed us to rapidly integrate with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.

[0001596532-15-000013:mdna:4]
We were founded in 2004 to address the limitations of legacy networking products and to create a cloud networking platform that is open and programmable. From 2004 to 2008, our activities were focused on the development of our software, which resulted in the commercial release of our first product, the 7100 Series switches based on our EOS software, in 2008. Since then, we have continued to introduce new products utilizing EOS, including our 7500 Series switch and our 7050 Series switch in 2010, the second generation of our 7500 Series switch, called the 7500E modular switch, in May 2013, our 7300 Series switch in November 2013, our 7280E in July 2014 and in December 2014 our EOS+ software platform for networking programmability and automation. As of December 31, 2014, we have shipped more than three million switch ports. We have experienced rapid revenue growth over the last several years, increasing our revenue at a compound annual growth rate of 68.9% from 2010 to 2014. As we have grown the functionality of our EOS software, expanded the range of our switching portfolio and increased the size of our sales force, our revenue has continued to grow rapidly. To support revenue growth, we have increased our international presence to include offices in 11 countries as of March 31, 2015, including Australia, Canada, China, India, Ireland, Japan, Malaysia, Singapore, South Korea, Taiwan and the United Kingdom. Our revenue for the three months ended March 31, 2015 was $179.0 million an increase of 52.8% compared to the same period in 2014. We have been profitable and cash flow positive for each year since 2010.

[0001596532-15-000013:mdna:5]
We believe that our cloud networking platform addresses the large and growing cloud networking segment of data center switching, which remains in the early stage of adoption. We expect to continue rapidly growing our organization to meet the needs of new and existing customers as they increasingly realize the performance and cost benefits of our cloud networking solutions and as they expand their cloud networks. We intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features and build upon our technology leadership. We believe one of our greatest strengths lies in our rapid development of new features and applications. We intend to continue expanding our sales and marketing teams and programs, with a particular focus on expanding our network of international channel partners and carrying out associated marketing activities in key geographies. In order to support our strong growth, we have accelerated our investment in infrastructure, such as enterprise resource planning software and other technologies to improve the efficiency of our operations. As a result, our levels of operating profit as a percentage of revenue could decline in the short to medium term. For a description of factors that may impact our future performance, see the disclosure in the section titled "Factors Affecting Our Performance" below.

[0001596532-15-000013:mdna:6]
[same as prior period, unchanged from 0001596532-14-000005:mdna:8]

[0001596532-15-000013:mdna:7]
We derive revenue from sales of products and services. We generate revenue primarily from sales of our switching products which incorporate our EOS software. We generate the majority of our services revenue from post contract support, or PCS, which end customers typically purchase in conjunction with our products.

[0001596532-15-000013:mdna:8]
Since shipping our first products in 2008, our cumulative end-customer base has grown rapidly. Between December 31, 2010 and December 31, 2014, our cumulative end-customer base grew from approximately 570 to over 3,000. Our end customers span a range of industries and include large Internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others.

[0001596532-15-000013:mdna:9]
To continue to grow our revenue, it is important that we both obtain new customers and sell additional products to existing customers. Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic to the underlying merchant silicon architecture. Today, we combine our EOS software with merchant silicon into a family of switching products. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We currently procure certain merchant silicon components from multiple vendors, and we continue to expand our relationships with these and other vendors. We work closely with third parties to manufacture and deliver our products. Our third-party silicon vendors deliver these

[0001596532-15-000013:mdna:10]
components to one of three direct fulfillment facilities where our EOS software is installed on our products, and then delivered to us for labeling, quality assurance testing, final configuration and shipment to our customers.

[0001596532-15-000013:mdna:11]
We market and sell our products through our direct sales force and in partnership with channel partners, including distributors, value-added resellers, systems integrators, original equipment manufacturer, or OEM, partners and in conjunction with various technology partners, depending on the application. To facilitate channel coordination and increase productivity, we have created a partner program, the Arista Partner Program, to engage partners who provide value-added services and extend our reach into the marketplace. Authorized training partners provide technical training to our channel partners. Our partners commonly receive an order from an end customer prior to placing an order with us, and we confirm the identification of the end customer prior to accepting such orders. Our partners generally do not stock inventory received from us. Our sales organization is supported by systems engineers with deep technical expertise and responsibility for pre-sales technical support and engineering for our end customers. Each sales team is responsible for a geographic territory, has responsibility for a number of major direct end-customer accounts or has assigned accounts in a specific vertical market. During three months ended March 31, 2015 and 2014, 70.8% and 82.1% of our revenue was generated from the Americas, substantially all from the U.S., 22.4% and 10.0% from Europe, the Middle East and Africa and 6.8% and 8.0% from the Asia-Pacific region, respectively.

[0001596532-15-000013:mdna:12]
[same as prior period, unchanged from 0001596532-14-000005:mdna:14]

[0001596532-15-000013:mdna:13]
[same as prior period, unchanged from 0001596532-14-000005:mdna:15]

[0001596532-15-000013:mdna:14]
[same as prior period, unchanged from 0001596532-14-000005:mdna:16]

[0001596532-15-000013:mdna:15]
Expanding Sales to Existing Customer Base. We expect that a substantial portion of our future sales will be follow-on sales to existing end customers. As noted above, one of our sales strategies is to target specific projects at our current end customers because they are familiar with the operational and economic benefits of our cloud networking solutions, thereby reducing the sales cycle into these customers. We believe this opportunity with current end customers to be significant given their existing and expected infrastructure spend.  Our business and results of operations will depend on our ability to sell additional products to our growing base of customers.

[0001596532-15-000013:mdna:16]
Adding New End Customers. We believe that the cloud networking market is still in the early stages of adoption. We intend to target new end customers by continuing to invest in our field sales force and extending our relationships with channel, technology and system-level partners. To date, we have primarily targeted end customers with the largest cloud data centers. A typical initial order involves the education of prospective customers about the technical merits and capabilities and potential cost savings of our products as compared to our competitors’ products. Our results of operations will depend on our ability to continue to add new customers. We believe that customer references have been, and will continue to be, an important factor in winning new business with special emphasis on four key verticals: the cloud titans, financial services, service and internet hosting providers and high tech enterprise.

[0001596532-15-000013:mdna:17]
[same as prior period, unchanged from 0001596532-14-000005:mdna:19]

[0001596532-15-000013:mdna:18]
[same as prior period, unchanged from 0001596532-14-000005:mdna:20]

[0001596532-15-000013:mdna:19]
Investing in Research and Development for Growth. We believe that the market for cloud networking is still in the early stages of adoption and we intend to continue investing for long-term growth. We expect to continue to invest heavily in software development in order to expand the capabilities of our cloud networking platform, introduce new products including new releases and upgrades to our EOS software and new applications and build upon our technology leadership. We believe one of our greatest strengths lies in the speed of our product development efforts. By investing in research and development, we believe we will be well positioned to continue our rapid growth and take advantage of our large market opportunity. We expect that our results of operations will be impacted by the timing and size of these product development investments.

[0001596532-15-000013:mdna:20]
Customer Concentration and Timing of Large Orders. Historically, large purchases by a relatively limited number of end customers have accounted for a significant portion of our revenue. During the years ended December 31, 2014, 2013 and 2012, our largest end customer accounted for 14.9%, 21.9% and 15.3% of our revenue, respectively. We have also experienced and continue to experience customer concentration on a quarterly basis. In addition, we have experienced increases in the size of our orders, including orders from existing customers, which could result in future increased customer concentration, depending on the timing of the fulfillment of those orders. We have also experienced unpredictability in the timing of large orders, especially with respect to our large end customers, due to the complexity of orders, the time it takes end customers to evaluate, test, qualify and accept our products and factors specific to our end customers. Due to these factors, we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. In addition, we have provided, and may in the future provide, pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur. Our gross margins may also fluctuate as a result of the timing of such sales to large end customers.

[0001596532-15-000013:mdna:21]
[same as prior period, unchanged from 0001596532-14-000005:mdna:24]

[0001596532-15-000013:mdna:22]
[same as prior period, unchanged from 0001596532-14-000005:mdna:25]

[0001596532-15-000013:mdna:23]
We generate revenue primarily from sales of our switching products which incorporate our EOS software. We also derive a portion of our revenue from sales of post contract support, or PCS, and to a lesser extent subscription and professional services. We generate PCS revenue from sales of technical support services contracts that are typically purchased in conjunction with our products and subsequent renewals of those contracts. We offer PCS services under renewable, fee-based contracts, which include 24-hour technical support, hardware repair and replacement parts, bug fixes, patches and unspecified upgrades on a when-and-if available basis. We expect our revenue may vary from period to period based on, among other things, the timing and size of orders, the delivery and acceptance of products, the impact of significant transactions with unique terms and conditions that may require deferral of revenue and cyclicality of orders being placed by our customers. Additionally, we expect our PCS revenue to increase in absolute dollars as we expand our installed base. Our ability to expand our installed base and increase our revenue is subject to numerous risks and uncertainties. See the section titled “Risk Factors.” We report revenue net of sales taxes.

[0001596532-15-000013:mdna:24]
[same as prior period, unchanged from 0001596532-14-000005:mdna:27]

[0001596532-15-000013:mdna:25]
Cost of revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs in our manufacturing operations department, and other manufacturing-related costs associated with manufacturing our products and managing our inventory. We expect our cost of product revenue to increase as our product revenue increases. Cost of providing PCS and other services consists primarily of personnel costs for our global customer support organization. We expect our cost of service revenue to increase as our PCS revenue increases.

[0001596532-15-000013:mdna:26]
[same as prior period, unchanged from 0001596532-14-000005:mdna:29]

[0001596532-15-000013:mdna:27]
[same as prior period, unchanged from 0001596532-14-000005:mdna:30]

[0001596532-15-000013:mdna:28]
[same as prior period, unchanged from 0001596532-14-000005:mdna:31]

[0001596532-15-000013:mdna:29]
Our operating expenses consist of research and development, sales and marketing and general and administrative expenses. The largest component of our operating expenses is personnel costs. Personnel costs consist of wages, benefits, bonuses and, with respect to sales and marketing expenses, sales commissions. Personnel costs also include stock-based compensation and travel expenses. We expect operating expenses to continue to increase in absolute dollars in the near term as we continue to invest in the growth of our business.

[0001596532-15-000013:mdna:30]
[same as prior period, unchanged from 0001596532-14-000005:mdna:33]

[0001596532-15-000013:mdna:31]
Research and development expenses consist primarily of personnel costs, with the remainder being prototype expenses, third-party engineering and contractor support costs, and an allocated portion of facility and IT costs and depreciation. Our research and development efforts are focused on maintaining and developing additional functionality for our existing products and on new product development, including new releases and upgrades to our EOS software and applications. We expense research and development costs as incurred. We expect our research and development expenses to increase in absolute dollars as we continue to invest heavily in software development in order to expand the capabilities of our cloud networking platform, introduce new products and features and build upon our technology leadership.

[0001596532-15-000013:mdna:32]
[same as prior period, unchanged from 0001596532-14-000005:mdna:35]

[0001596532-15-000013:mdna:33]
Sales and marketing expenses consist primarily of personnel costs and also include costs related to marketing and promotional activities, with the remainder being an allocated portion of facility and IT costs and depreciation. We expect our sales and marketing expenses to increase in absolute dollars as we expand our sales and marketing efforts worldwide and expand our relationships with current and future channel partners and end customers.

[0001596532-15-000013:mdna:34]
[same as prior period, unchanged from 0001596532-14-000005:mdna:37]

[0001596532-15-000013:mdna:35]
General and administrative expenses consist primarily of personnel costs, professional fees, and an allocated portion of facility and IT costs and depreciation. General and administrative personnel costs include those for our executive, finance, IT, human resources and legal functions. Our professional fees consist primarily of accounting, external legal and IT and other consulting costs. We expect our general and administrative expenses to increase in absolute dollars to support our growing infrastructure needs and as we assume the reporting requirements and compliance obligations of a public company. In addition, we expect legal expense to increase significantly in absolute dollars for the foreseeable future due to legal costs related to ongoing IP litigation and potential future litigation claims. Refer to the discussion under “Legal Proceedings” subheading in Note 5. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for information related to pending litigation.

[0001596532-15-000013:mdna:36]
[same as prior period, unchanged from 0001596532-14-000005:mdna:40]

[0001596532-15-000013:mdna:37]
[same as prior period, unchanged from 0001596532-14-000005:mdna:41]

[0001596532-15-000013:mdna:38]
Interest expense consists of interest expense on our subordinated convertible promissory notes, including our related party subordinated convertible promissory notes which were converted during fiscal 2014 and interest expense from our lease financing obligation.

[0001596532-15-000013:mdna:39]
[same as prior period, unchanged from 0001596532-14-000005:mdna:43]

[0001596532-15-000013:mdna:40]
Other income (expense) consists of gains on investments, write-offs of debt discount on notes payable which were repaid and converted during fiscal 2014 and foreign currency exchange gains and losses. Our foreign currency exchange gains and losses relate to transactions and asset and liability balances denominated in currencies other than the U.S. dollar. We expect our foreign currency gains and losses to continue to fluctuate in the future due to changes in foreign currency exchange rates.

[0001596532-15-000013:mdna:41]
[same as prior period, unchanged from 0001596532-14-000005:mdna:45]

[0001596532-15-000013:mdna:42]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. Earnings from our non-U.S. activities are subject to local country income tax and may be subject to U.S. income tax. Generally, our U.S. tax obligations are reduced by a credit for foreign income taxes paid on these earnings which avoids double taxation. Our tax expense to date consists of federal, state and foreign current and deferred income taxes. As we expand internationally, our marginal tax rate may decrease; however, there can be no certainty that our marginal tax rate will decrease, and we may experience changes in tax rates that are not reflective of actual changes in our business or operations.

[0001596532-15-000013:mdna:43]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. We measure deferred income tax assets and liabilities using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-15-000013:mdna:44]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-15-000013:mdna:45]
[same as prior period, unchanged from 0001596532-14-000005:mdna:47]

[0001596532-15-000013:mdna:46]
The following table summarizes historical results of operations for the periods presented and as a percentage of revenue for those periods.  We have derived the data for the three months ended March 31, 2015 and 2014 from our unaudited condensed consolidated financial statements (in thousands, except for percentage of revenue).

[0001596532-15-000013:mdna:47]
|  | Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| Revenue: |  |  |  |
| Product | $ | 160,141 |  |  | $ | 106,493 |  |
| Service | 18,904 |  |  | 10,714 |  |
| Total revenue | 179,045 |  |  | 117,207 |  |
| Cost of revenue (1) : |  |  |  |
| Product | 54,439 |  |  | 33,027 |  |
| Service | 6,852 |  |  | 2,866 |  |
| Total cost of revenue | 61,291 |  |  | 35,893 |  |
| Gross profit | 117,754 |  |  | 81,314 |  |
| Operating expenses (1): |  |  |  |
| Research and development | 43,340 |  |  | 33,446 |  |
| Sales and marketing | 24,587 |  |  | 18,655 |  |
| General and administrative | 14,072 |  |  | 7,231 |  |
| Total operating expenses | 81,999 |  |  | 59,332 |  |
| Income from operations | 35,755 |  |  | 21,982 |  |
| Interest expense | (821 | ) |  | (2,543 | ) |
| Other income (expense), net | (468 | ) |  | 8 |  |
| Total other income (expense), net | (1,289 | ) |  | (2,535 | ) |
| Income before provision for income taxes | 34,466 |  |  | 19,447 |  |
| Provision for income taxes | 9,974 |  |  | 7,118 |  |
| Net income | $ | 24,492 |  |  | $ | 12,329 |  |

[0001596532-15-000013:mdna:48]
25

[0001596532-15-000013:mdna:49]
|  | Three Months Ended March 31, |
|  | 2015 |  | 2014 |
|  | (as a percentage of revenue) |
| Revenue: |  |  |  |
| Product | 89.4 | % |  | 90.9 | % |
| Service | 10.6 |  |  | 9.1 |  |
| Total revenue | 100.0 |  |  | 100.0 |  |
| Cost of revenue: |  |  |  |
| Product | 30.4 |  |  | 28.2 |  |
| Service | 3.8 |  |  | 2.4 |  |
| Total cost of revenue | 34.2 |  |  | 30.6 |  |
| Gross profit | 65.8 |  |  | 69.4 |  |
| Operating expenses: |  |  |  |
| Research and development | 24.2 |  |  | 28.5 |  |
| Sales and marketing | 13.7 |  |  | 15.9 |  |
| General and administrative | 7.9 |  |  | 6.2 |  |
| Total operating expenses | 45.8 |  |  | 50.6 |  |
| Income from operations | 20.0 |  |  | 18.8 |  |
| Interest expense | (0.5 | ) |  | (2.2 | ) |
| Other income (expense), net | (0.3 | ) |  | — |  |
| Total other income (expense), net | (0.8 | ) |  | (2.2 | ) |
| Income before provision for income taxes | 19.2 |  |  | 16.6 |  |
| Provision for income taxes | 5.6 |  |  | 6.1 |  |
| Net income | 13.6 | % |  | 10.5 | % |

[0001596532-15-000013:mdna:50]
[same as prior period, unchanged from 0001596532-14-000005:mdna:51]

[0001596532-15-000013:mdna:51]
|  | Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| Cost of revenue | $ | 636 |  |  | $ | 211 |  |
| Research and development | 4,928 |  |  | 2,467 |  |
| Sales and marketing | 2,409 |  |  | 1,428 |  |
| General and administrative | 866 |  |  | 676 |  |
| Total stock-based compensation | $ | 8,839 |  |  | $ | 4,782 |  |

[0001596532-15-000013:mdna:52]
26

[0001596532-15-000013:mdna:53]
Three Months Ended March 31, 2015 Compared to Three Months Ended March 31, 2014

[0001596532-15-000013:mdna:54]
[same as prior period, unchanged from 0001596532-14-000005:mdna:55]

[0001596532-15-000013:mdna:55]
|  | Three Months Ended March 31, |
|  | 2015 |  | 2014 |  | Change in |
|  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |
| Product | $ | 160,141 |  |  | $ | 106,493 |  |  | $ | 53,648 |  |  | 50.4 | % |
| Service | 18,904 |  |  | 10,714 |  |  | 8,190 |  |  | 76.4 |  |
| Total revenue | $ | 179,045 |  |  | $ | 117,207 |  |  | $ | 61,838 |  |  | 52.8 | % |
| Cost of Revenue |  |  |  |  |  |  |  |
| Product | $ | 54,439 |  |  | $ | 33,027 |  |  | $ | 21,412 |  |  | 64.8 | % |
| Service | 6,852 |  |  | 2,866 |  |  | 3,986 |  |  | 139.1 |  |
| Total cost of revenue | $ | 61,291 |  |  | $ | 35,893 |  |  | $ | 25,398 |  |  | 70.8 | % |
| Gross profit | $ | 117,754 |  |  | $ | 81,314 |  |  | $ | 36,440 |  |  | 44.8 | % |
| Gross margin | 65.8 | % |  | 69.4 | % |  |  |  |  |

[0001596532-15-000013:mdna:56]
[same as prior period, unchanged from 0001596532-14-000005:mdna:57]

[0001596532-15-000013:mdna:57]
Revenue increased $61.8 million, or 52.8% for the three months ended March 31, 2015 compared to the same period in 2014. The increase in revenue was predominantly due to an increase in sales of switch products and related accessories of $54.1 million, or 51.2%, primarily to existing customers, and, to a lesser extent, new customers. The increase in product revenue was largely driven by an increase in switch port shipments, which increased by 56.1% during the three months ended March 31, 2015 compared to the same period in 2014, partially offset by a reduction of 4.0% in the average selling price. Service revenue also increased by $8.2 million or 76.4%, primarily attributable to the increase of new and renewed support contracts for our switch products.

[0001596532-15-000013:mdna:58]
[same as prior period, unchanged from 0001596532-14-000005:mdna:60]

[0001596532-15-000013:mdna:59]
Cost of revenue increased $25.4 million, or 70.8%, for the three months ended March 31, 2015 compared to the same period in 2014. The increase in cost of revenue was primarily due to the corresponding increase in revenue as our shipment volume significantly increased during the three months ended March 31, 2015 resulting in an increase in product cost of revenue. In addition, cost of service revenue increased by $4.0 million for the three months ended March 31, 2015 compared to the same period in 2014, primarily attributed to an increase in support costs driven by growth in our customer install base.

[0001596532-15-000013:mdna:60]
[same as prior period, unchanged from 0001596532-14-000005:mdna:63]

[0001596532-15-000013:mdna:61]
Gross margin decreased from 69.4% for the three months ended March 31, 2014 to 65.8% for the three months ended March 31, 2015. The decrease was primarily the result of product and customer mix, combined with a $2.2 million benefit resulting from a cash settlement received from one of our suppliers due to a product defect issue that occurred during the first quarter of 2014.

[0001596532-15-000013:mdna:62]
[same as prior period, unchanged from 0001596532-14-000005:mdna:66]

[0001596532-15-000013:mdna:63]
|  | Three Months Ended March 31, |
|  | 2015 |  | 2014 |  | Change in |
|  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 43,340 |  |  | $ | 33,446 |  |  | $ | 9,894 |  |  | 29.6 | % |
| Sales and marketing | 24,587 |  |  | 18,655 |  |  | 5,932 |  |  | 31.8 |  |
| General and administrative | 14,072 |  |  | 7,231 |  |  | 6,841 |  |  | 94.6 |  |
| Total operating expenses | $ | 81,999 |  |  | $ | 59,332 |  |  | $ | 22,667 |  |  | 38.2 | % |

[0001596532-15-000013:mdna:64]
[same as prior period, unchanged from 0001596532-14-000005:mdna:68]

[0001596532-15-000013:mdna:65]
Research and development expenses increased $9.9 million, or 29.6%, for the three months ended March 31, 2015 compared to the same period in 2014. The increase was primarily due to an increase in personnel costs of $8.2 million, resulting from a 26% increase in headcount from March 31, 2014 to March 31, 2015 as well as increased bonus expense under our corporate bonus plan, an increase of $1.6 million in third-party engineering and consulting costs and an increase of $1.4 million in research and development related facilities and IT infrastructure expenses as we continued to expand and support our research and development activities. These costs were partially offset by a $1.8 million reduction in prototype spend related to project timing.

[0001596532-15-000013:mdna:66]
[same as prior period, unchanged from 0001596532-14-000005:mdna:71]

[0001596532-15-000013:mdna:67]
Sales and marketing expenses increased $5.9 million, or 31.8%, for the three months ended March 31, 2015 compared to the same period in 2014. The increase was primarily due to an increase in personnel costs of $3.9 million, resulting from a 12% increase in headcount from March 31, 2014 to March 31, 2015, as well as an increase in sales commissions resulting from higher sales volume. The increase was also due to an increase of $1.9 million in product demonstrations and other marketing activities.

[0001596532-15-000013:mdna:68]
[same as prior period, unchanged from 0001596532-14-000005:mdna:74]

[0001596532-15-000013:mdna:69]
General and administrative expenses increased $6.8 million, or 94.6%, for the three months ended March 31, 2015 compared to the same period in 2014. The increase was primarily due to an increase in litigation fees of $6.7 million primarily related to the Cisco and OptumSoft matters, as well as increased personnel costs of $0.8 million resulting from increased bonus expense under our corporate bonus plan. These costs were partially offset by a decrease in professional service fees of $1.1 million primarily attributed to accounting and consulting fees in preparation for becoming a public company that were incurred during the first quarter of 2014.

[0001596532-15-000013:mdna:70]
[same as prior period, unchanged from 0001596532-14-000005:mdna:77]

[0001596532-15-000013:mdna:71]
|  | Three Months Ended March 31, |
|  | 2015 |  | 2014 |  | Change in |
|  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (821 | ) |  | $ | (2,543 | ) |  | $ | 1,722 |  |  | (67.7 | )% |
| Other income (expense), net | (468 | ) |  | 8 |  |  | (476 | ) |  | NM |
| Total other income (expense), net | $ | (1,289 | ) |  | $ | (2,535 | ) |  | $ | 1,246 |  |  | (49.2 | )% |

[0001596532-15-000013:mdna:72]
Interest expense. Interest expense decreased during the three months ended March 31, 2015 compared to the same period in 2014 as a result of repayment and conversion of all our notes payable upon closing of our initial public offering during the first quarter of 2014.

[0001596532-15-000013:mdna:73]
Other income (expense), net. Other income (expense), net increased during the three months ended March 31, 2015, compared to the same period in 2014 due to an increase in net transactional exchange rate loss variances.

[0001596532-15-000013:mdna:74]
[same as prior period, unchanged from 0001596532-14-000005:mdna:81]

[0001596532-15-000013:mdna:75]
|  | Three Months Ended March 31, |
|  | 2015 |  | 2014 |  | Change in |
|  | $ |  | $ |  | $ |  | % |
| Provision for income taxes | $ | 9,974 |  |  | $ | 7,118 |  |  | $ | 2,856 |  |  | 40.1 | % |
| Effective tax rate | 28.9 | % |  | 36.6 | % |  |  |  |  |

[0001596532-15-000013:mdna:76]
Provision for income taxes. Provision for income taxes was approximately $10.0 million and $7.1 million for the three months ended March 31, 2015 and 2014, respectively. The change in our provision for income taxes was primarily due to increase in profit before income tax and the decrease in the effective tax rate based on our current geographical distribution of the earnings.

[0001596532-15-000013:mdna:77]
[same as prior period, unchanged from 0001596532-14-000005:mdna:85]

[0001596532-15-000013:mdna:78]
Our principal sources of liquidity are cash and cash equivalents, marketable securities, and cash generated from operations. As of March 31, 2015, cash and cash equivalents and marketable securities were $484.3 million of which approximately $100.7 million was held outside the U.S. in our foreign subsidiaries. We have not repatriated nor do we currently have plans to repatriate these funds, but if we were to repatriate cash held outside of the U.S. for domestic cash operations, we would be required to accrue and pay U.S. income taxes to repatriate these funds less any previously paid foreign income taxes. We consider the undistributed earnings of our foreign subsidiaries as of March 31, 2015 to be indefinitely reinvested, and, accordingly, no U.S. income taxes have been provided thereon.

[0001596532-15-000013:mdna:79]
Our cash and cash equivalents and marketable securities are held for working capital purposes.  We plan to continue to invest for long-term growth. We completed our initial public offering on June 6, 2014 in which we sold 6,037,500 shares of our common stock at a public offering price of $43.00 per share, netting proceeds of $238.9 million. One of the principal purposes of our initial public offering was to obtain additional capital to fund the growth of our business. We believe that our existing cash and cash equivalents together with cash flow from operations will be sufficient to meet our working capital requirements and our growth strategies for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs and access to outsourcing our manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies as well as the continued market acceptance of our products. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us. If we are required and unable to raise additional capital when desired, our business, operating results, and financial condition may be adversely affected.

[0001596532-15-000013:mdna:80]
[same as prior period, unchanged from 0001596532-14-000005:mdna:91]

[0001596532-15-000013:mdna:81]
|  | March 31, 2015 |  | December 31, 2014 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 275,186 |  |  | $ | 240,031 |  |

[0001596532-15-000013:mdna:82]
|  | Three Months Ended March 31, |
|  | 2015 |  | 2014 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 20,767 |  |  | $ | 17,689 |  |
| Cash used in investing activities | (5,803 | ) |  | (3,103 | ) |
| Cash provided by financing activities | 20,231 |  |  | 1,264 |  |
| Effect of exchange rate changes | (40 | ) |  | 10 |  |
| Net increase in cash and cash equivalents | $ | 35,155 |  |  | $ | 15,860 |  |

[0001596532-15-000013:mdna:83]
[same as prior period, unchanged from 0001596532-14-000005:mdna:94]

[0001596532-15-000013:mdna:84]
Our primary source of cash from operating activities has been from cash collections from our customers. We expect cash inflows from operating activities to be affected by increased sales and timing of collections. Our primary uses of cash from operating activities have been for personnel costs and investment in sales and marketing and research and development. We expect cash outflows from operating activities to increase as a result of further investment in sales and marketing and increases in personnel costs as we grow our business.

[0001596532-15-000013:mdna:85]
During the three months ended March 31, 2015, cash provided by operating activities was $20.8 million, primarily from net income of $24.5 million, net non-cash charges of $3.5 million and a net decrease in our operating assets and liabilities of $7.2 million. The decrease in cash was primarily due to an increase in our accounts receivable of $16.3 million resulting from the increase in sales, a decrease in our accrued liabilities of $12.4 million primarily due to payments of our corporate bonus and the payment of other accrued compensation balances, increase in inventory of $10.7 million due to increased shipment volume and an increase in other assets of $3.5 million. These decreases were partially offset by an increase in deferred revenue of $26.4 million due to an increase in our customer service install base and increases in product shipments with acceptance provisions, a net increase in our income tax payable of $9.0 million related to tax benefits from stock-based activities and a $2.6 million net decrease in prepaids and other current assets.

[0001596532-15-000013:mdna:86]
During the three months ended March 31, 2014, cash provided by operating activities was $17.7 million, primarily from net income of $12.3 million, non-cash charges of $9.2 million and a net decrease in our net operating assets and liabilities of $3.8 million. The decrease in cash was primarily due to a $5.9 million decrease in accounts payable attributable to the timing of payments, a $6.1 million increase in prepaid expenses, deposits and other assets, a $5.6 million increase in inventory for anticipated growth in our business and a decrease in deferred revenue of $2.8 million as a result of recognition of a large order previously deferred. These increases were partially

[0001596532-15-000013:mdna:87]
offset by lower accounts receivable of $15.0 million due to stronger collection efforts and a $1.5 million increase in interest payable attributable to our outstanding convertible promissory notes, including our related party convertible promissory notes.

[0001596532-15-000013:mdna:88]
[same as prior period, unchanged from 0001596532-14-000005:mdna:98]

[0001596532-15-000013:mdna:89]
[same as prior period, unchanged from 0001596532-14-000005:mdna:99]

[0001596532-15-000013:mdna:90]
During the three months ended March 31, 2015, cash used in investing activities was $5.8 million, consisting primarily of purchases of property and equipment of $5.1 million.

[0001596532-15-000013:mdna:91]
During the three months ended March 31, 2014, cash used in investing activities was $3.1 million, all of which was for purchases of property and equipment.

[0001596532-15-000013:mdna:92]
[same as prior period, unchanged from 0001596532-14-000005:mdna:102]

[0001596532-15-000013:mdna:93]
Our cash flows provided by financing activities primarily consisted of proceeds from the exercises of stock options and the excess tax benefits on stock-based compensation.

[0001596532-15-000013:mdna:94]
During the three months ended March 31, 2015, cash provided by financing activities was $20.2 million, consisting primarily of proceeds from the exercise of stock options, net of repurchases of $5.3 million, the excess tax benefit on stock-based compensation of $10.6 million and the proceeds from the issuance of common stock from our ESPP of $4.9 million.

[0001596532-15-000013:mdna:95]
During the three months ended March 31, 2014, cash provided by financing activities was $1.3 million, consisting primarily of proceeds from the exercise of stock options, net of repurchases, amounting to $1.9 million and excess tax benefits realized from our equity incentive plans amounting to $0.3 million, partially offset by payments of our initial public offering costs of $0.8 million.

[0001596532-15-000013:mdna:96]
[same as prior period, unchanged from 0001596532-14-000005:mdna:109]

[0001596532-15-000013:mdna:97]
As of March 31, 2015, we did not have any relationships with any unconsolidated entities or financial partnerships, including entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-15-000013:mdna:98]
[same as prior period, unchanged from 0001596532-14-000005:mdna:111]

[0001596532-15-000013:mdna:99]
There have been no significant changes during the three months ended March 31, 2015 impacting our contractual obligations disclosed in our "Management's Discussion and Analysis of Financial Condition and Results of Operations" included in our Annual Report on Form 10-K, filed with the SEC on March 11, 2015 and our Amended Annual Report on Form 10-K/A, filed with the SEC on May 14, 2015.

[0001596532-15-000013:mdna:100]
[same as prior period, unchanged from 0001596532-14-000005:mdna:114]

[0001596532-15-000013:mdna:101]
Our unaudited condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles. The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. We believe the critical accounting policies and estimates discussed in the "Management's Discussion and Analysis of Financial Condition and Results of Operations" section of our Annual Report on Form 10-K and Amended Annual Report on Form 10-K/A that were filed with the SEC on March 11, 2015 and May 14, 2015, respectively, reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting policies and estimates as disclosed in our Annual Report on Form 10-K and Amended Annual Report on Form 10-K/A.

[0001596532-15-000013:mdna:102]
[same as prior period, unchanged from 0001596532-14-000005:mdna:116]

[0001596532-15-000013:mdna:103]
[same as prior period, unchanged from 0001596532-14-000005:mdna:117]
