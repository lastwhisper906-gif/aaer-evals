# ANET notes — 0001596532-15-000013


## anet:ConcentrationRiskComponentsSupplierRiskPolicyTextBlock

[0001596532-15-000013:notes:1]
We work closely with third parties to manufacture and deliver our products. As of March 31, 2015 and December 31, 2014, two suppliers provided essentially all of our electronic manufacturing services. Our products rely on key components, including certain integrated circuit components and power supplies some of which our contract manufacturers purchase on our behalf from a limited number of suppliers, including certain sole source providers. We do not have guaranteed supply contracts with any of our component suppliers, and our suppliers could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, sales of our products could be delayed or halted entirely or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.


## anet:ScheduleofLeaseFinancingObligationsTableTextBlock

[0001596532-15-000013:notes:2]
As of December 31, 2014, the future minimum payments due under the lease financing obligation were as follows (in thousands):

[0001596532-15-000013:notes:3]
| Years Ending December 31, |  |  |
| 2015 |  | $ | 5,588 |  |
| 2016 |  | 5,754 |  |
| 2017 |  | 5,933 |  |
| 2018 |  | 6,113 |  |
| 2019 |  | 6,293 |  |
| Thereafter |  | 25,287 |  |
| Total payments |  | 54,968 |  |
| Less: interest and land lease expense |  | (34,770 | ) |
| Total payments under facility financing obligations |  | 20,198 |  |
| Property reverting to landlord |  | 23,436 |  |
| Present value of obligation |  | 43,634 |  |
| Less current portion |  | (1,087 | ) |
| Long-term portion of obligation |  | $ | 42,547 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001596532-15-000013:notes:4]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (" U.S. GAAP") and following the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by U.S. GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2015, are not necessarily indicative of the results expected for the full fiscal year.

[0001596532-15-000013:notes:5]
The condensed consolidated balance sheet as of December 31, 2014 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by generally accepted accounting principles for complete financial statements.

[0001596532-15-000013:notes:6]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and our wholly owned subsidiaries. All significant intercompany accounts and transactions have been eliminated.

[0001596532-15-000013:notes:7]
The accompanying unaudited condensed consolidated financial statements and related financial information should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2014, filed with the SEC on March 11, 2015 and our Amended Annual Report on Form 10-K/A for the fiscal year ended December 31, 2014, filed with the SEC on May 14, 2015.

[0001596532-15-000013:notes:8]
Commencing in the first quarter of fiscal 2015, we have disaggregated total revenue and cost of revenue into "Product" and "Service". Prior period balances have been reclassified to conform to this new presentation.

[0001596532-15-000013:notes:9]
There have been no changes in our significant accounting policies from those that were disclosed in our audited consolidated financial statements for the year ended December 31, 2014.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-15-000013:notes:10]
Commitments and Contingencies

[0001596532-15-000013:notes:11]
Operating Leases

[0001596532-15-000013:notes:12]
We lease various operating spaces in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2023. These arrangements require us to pay certain operating expenses, such as taxes, repairs, and insurance and contain renewal and escalation clauses. We recognize rent expense under these arrangements on a straight-line basis over the term of the lease.

[0001596532-15-000013:notes:13]
As of December 31, 2014, the aggregate future minimum payments under non-cancelable operating leases consist of the following (in thousands):

[0001596532-15-000013:notes:14]
| Years Ending December 31, |  |
| 2015 | $ | 2,583 |  |
| 2016 | 4,297 |  |
| 2017 | 5,155 |  |
| 2018 | 5,378 |  |
| 2019 | 5,369 |  |
| Thereafter | 22,407 |  |
| Total minimum future lease payments | $ | 45,189 |  |

[0001596532-15-000013:notes:15]
Rent expense for all operating leases amounted to $0.8 million and $0.6 million for the three months ended March 31, 2015 and 2014, respectively.

[0001596532-15-000013:notes:16]
Financing Obligation—Build-to-Suit Lease

[0001596532-15-000013:notes:17]
In August 2012, we executed a lease for a building under construction in Santa Clara, California which will serve as our new headquarters. The lease term is 120 months and commenced in August 2013.

[0001596532-15-000013:notes:18]
Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction such as our financial involvement in structural elements of asset construction, making decisions related to tenant improvement costs and purchasing insurance not reimbursable by the buyer-lessor (the Landlord), we are deemed the owner of the building (for accounting purposes only) during the construction period. We maintained continued involvement in the property after construction was completed and lack transferability of the risks and rewards of ownership, primarily due to our required maintenance of a $4.0 million letter of credit. Due to our continuing involvement in the property post construction and lack of transferability of related risks and rewards of ownership to the Landlord after construction is complete, we account for the building and related improvements as a lease financing obligation. Accordingly, as of March 31, 2015 and December 31, 2014, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $43.4 million and $43.6 million, respectively. As of March 31, 2015, $1.2 million and $42.2 million were recorded as short-term and long-term financing obligations, respectively.

[0001596532-15-000013:notes:19]
Land lease expense under our lease financing obligation amounted to $0.3 million and $0.3 million for the three months ended March 31, 2015 and 2014, respectively.

[0001596532-15-000013:notes:20]
Upon completion of construction in the third quarter of 2013, we evaluated the de-recognition of the asset and liability under the sale-leaseback accounting guidance. We concluded that we have forms of continued economic involvement in the facility, and therefore did not meet with the provisions for sale-leaseback accounting. Therefore, the lease is accounted for as a financing obligation and lease payments will be attributed to (1) a reduction of the principal financing obligation; (2) imputed interest expense; and (3) land lease expense (which is considered an operating lease and a component of cost of goods sold and operating expenses) representing an imputed cost to lease the underlying land of the building. In addition, the underlying building asset is depreciated over the building’s estimated useful life of 30 years. At the conclusion of the initial lease term, we will de-recognize both the net book values of the asset and the remaining financing obligation.

[0001596532-15-000013:notes:21]
Purchase Commitments

[0001596532-15-000013:notes:22]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. These forecasts are based on estimates of future demand for our products, historical trend analysis provided by our sales and product marketing organizations and adjusted for overall market conditions. We incur a liability when the contract manufacturer has converted the component inventory to a finished product.  However, historically we have reimbursed our contract manufacturer for component inventory purchases when this inventory has been rendered excess or obsolete due to manufacturing and engineering change orders resulting from design changes, or in cases where inventory levels greatly exceed our forecasts. As of March 31, 2015 and December 31, 2014, $0.2 million and $0.3 million related to the excess and obsolete component inventory liability to our contract manufacturers.  We have provided restricted deposits to our third-party contract manufacturers and vendors to secure our obligations to purchase inventory. We had $2.3 million in restricted deposits as of March 31, 2015 and December 31, 2014. Restricted deposits are classified in other assets in our accompanying unaudited condensed consolidated balance sheets.

[0001596532-15-000013:notes:23]
Guarantees

[0001596532-15-000013:notes:24]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers the unamortized value of the product based on its estimated useful life. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for lease facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-15-000013:notes:25]
Legal Proceedings

[0001596532-15-000013:notes:26]
OptumSoft, Inc. Matters

[0001596532-15-000013:notes:27]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-15-000013:notes:28]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft copies of certain components of our software for evaluation by OptumSoft, (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches, (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers, (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us, and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dtd July 27, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders. OptumSoft has identified in confidential documents certain software components it claims to own, which are generally applicable tools and utility subroutines and not networking specific code. We cannot assure which software components OptumSoft may ultimately claim to own in the litigation or whether such claimed components are material.

[0001596532-15-000013:notes:29]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we assert our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we assert that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We ask the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also assert that, even if we are found not to own any particular components at issue, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation. On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have strong defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-15-000013:notes:30]
The Court set a trial date for Phase I of the proceedings, relating to contract interpretation and application of the contract to certain claimed source code for September 14, 2015.  The remaining issues are currently scheduled to be tried in April 2016.

[0001596532-15-000013:notes:31]
At this stage of the litigation, we are unable to determine whether a loss is probable or estimate a possible or range of possible loss.

[0001596532-15-000013:notes:32]
We intend to vigorously defend against any action brought against us by OptumSoft. However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor. For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft. If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license. In addition, if OptumSoft were to bring actual litigation, it could assert additional or different claims against us, including claims that our license from OptumSoft is invalid. An adverse litigation ruling could result in a significant damages award against us and injunctive relief. In addition, if our license was ruled to have been terminated, and we were not able to negotiate a new license from OptumSoft on reasonable terms, we could be prohibited from selling products that incorporate OptumSoft intellectual property. Any such adverse ruling could materially adversely affect our business, prospects, results of operations and financial condition. Whether or not we prevail in a lawsuit, we expect that any litigation would be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-15-000013:notes:33]
Cisco Systems, Inc. (“Cisco”) Matters

[0001596532-15-000013:notes:34]
On December 5, 2014, Cisco filed two complaints against us in District Court for the Northern District of California, which are proceeding as Case No. 4-14-cv-05343 (“’43 Case”) and Case No. 4-14-cv-05344 (“’44 Case”).  In the ’43 Case, Cisco alleges that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the 875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”).  Cisco seeks, as relief for our alleged infringement in the ’43 Case, lost profits and/or reasonable royalty damages in an unspecified amount, including treble damages, attorney’s fees, and associated costs.  Cisco also seeks injunctive relief in the ’43 Case.  On February 10, 2015, the court granted our unopposed motion to stay the ’43 Case until the proceedings before the United States International Trade Commission (“USITC”) pertaining to the same patents (as discussed below) become final.  In the ’44 Case, Cisco’s complaint alleges that we infringe U.S. Patent Nos. 7,047,526 and 7,953,886 and further alleges that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI.”  As relief for our alleged patent infringement in the ’44 Case, Cisco seeks lost profits and/or reasonable royalty damages in an unspecified amount including treble damages, attorney’s fees, and associated costs as well as injunctive relief.  As relief from our alleged copyright infringement, Cisco seeks damages in an unspecified amount in the form of alleged lost profits, profits from our alleged infringement, statutory damages, attorney’s fees and associated costs.  Cisco also seeks injunctive relief against our alleged copyright infringement.  On February 13, 2015, we answered the complaint in the ’44 Case, denying the patent and copyright infringement allegations and also raising numerous affirmative defenses.  On March 6, 2015, Cisco filed an amended complaint against in the ’44 Case.  In response, we moved to dismiss Cisco’s allegations of willful patent infringement and pre-suit indirect patent infringement.  A hearing on our motion to dismiss is scheduled for July 2, 2015.  Trial has not been scheduled in either the ’43 or ’44 Cases.

[0001596532-15-000013:notes:35]
On December 19, 2014, Cisco filed two complaints against us in the USITC alleging that Arista has violated section 337 of the Tariff Act of 1930, as amended. The complaints have been instituted as ITC Inv. Nos. 337-TA-944 (“’944 Investigation”) and 337-TA-945 (“’945 Investigation).   In the ’944 Investigation, Cisco alleges that certain Arista switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents.  In the ’945 Investigation, Cisco alleges that certain Arista switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents.  In both the ’944 and ’945 Investigations, Cisco seeks, among other things, a limited exclusion order barring entry into the United States of accused switch products (including 7000 Series of switches) and a cease and desist order against us restricting our activities with respect to our imported accused switch products.  On January 28, 2015, the Administrative Law Judge assigned to the ’944 Investigation set May 27, 2016 as the target date for completion of the ’944 Investigation.  On February 11, 2015, we responded to the notices of investigation and complaints in the ’944 and ’945 Investigations by, among other things, denying any violation of section 337 of the Tariff Act and the patent infringement allegations, and raising numerous additional defenses.  On February 19, 2015, the Administrative Law Judge assigned to the ’945 Investigation issued a procedural schedule calling for, among other events:  issuance of an order construing the claims of the ’577, ’853, ’875, ’668, ’492, and ’211 patents tentatively on July 17, 2015; an evidentiary hearing on November 9-20, 2015; issuance of an initial determination regarding our alleged violations on April 26, 2016; and the target date for completion of the ’945 Investigation on August 26, 2016. On March 9, 2015, the Administrative Law Judge assigned to the ’944 Investigation issued a procedural schedule calling for, among other events:  an evidentiary hearing on Sept. 9-11 & 15-17, 2015 and issuance of an initial determination regarding our alleged violations on January 27, 2016.

[0001596532-15-000013:notes:36]
On April 1, 2015, we filed petitions for Inter Partes Review with the United States Patent Trial and Appeal Board (“PTAB”) seeking to invalidate Cisco’s ’597, ’211, and ’668 patents.  On April 10, 2015, we filed petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853 and ’577 patents.  On April 16, 2015, we filed additional petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853 and ’577 patents.  We expect that the PTAB will determine whether or not to institute review of the validity with respect to each of our petitions for Inter Partes Review within six months of the filing dates for those petitions.  To the extent that the PTAB grants our petitions and institutes review, the PTAB must issue its final written decision on validity within twelve months of its institution decision.

[0001596532-15-000013:notes:37]
We intend to vigorously defend against Cisco’s lawsuits, as summarized in the preceding paragraphs.  However, we cannot be certain that, if litigated, any claims by Cisco would be resolved in our favor.  For example, an adverse litigation ruling could result in a significant damages award against us, could further result in the above described injunctive relief (including, among other things, an order excluding our products from importation into the United States), could result in a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products to the extent that we are found to infringe any valid claims asserted against us by Cisco. In particular, with respect to the ‘944 and ‘945 Investigations, if our products are found to infringe any patents that are the subject of those investigations, the USITC would likely issue a limited exclusion order barring entry into the United States of accused switch products (including 7000 Series of switches) and a cease and desist order restricting our activities with respect to our imported accused switch products. In the case that we attempt to modify our manufacturing and importation processes to comply with such orders, we may not be able to do so successfully or without substantial expense. Moreover, in the case we attempt to modify our products, to the extent we are found to infringe on any valid claims asserted against us, we may not be able to successfully modify our products in a substantial manner and any modified products may not be well received in the market.  Any such adverse ruling could materially adversely affect our business, prospects, results of operation and financial condition.  To the extent that we reached a negotiated settlement with Cisco, the settlement could require payment of substantial royalties.  Additionally, the existence of this lawsuit could cause concern among our customers and potential customers and could adversely affect our business and results of operations.  Whether or not we prevail in the lawsuit, we expect that the litigation will be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-15-000013:notes:38]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. Based on currently available information, management does not believe that the ultimate outcome of these other unresolved matters is probable or estimable and not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001596532-15-000013:notes:39]
Other current liabilities consist of the following (in thousands):

[0001596532-15-000013:notes:40]
|  | March 31, 2015 |  | December 31, 2014 |
| Liability for early exercised shares subject to repurchase | $ | 3,860 |  |  | $ | 4,616 |  |
| Sales tax payable | 2,715 |  |  | 3,101 |  |
| Lease financing obligations, current portion | 1,147 |  |  | 1,087 |  |
| Other | 740 |  |  | 2,445 |  |
| Total other current liabilities | $ | 8,462 |  |  | $ | 11,249 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-15-000013:notes:41]
[same as prior period, unchanged from 0001596532-14-000005:notes:51]

[0001596532-15-000013:notes:42]
[same as prior period, unchanged from 0001596532-14-000005:notes:52]

[0001596532-15-000013:notes:43]
|  | Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| Cost of revenue | $ | 636 |  |  | $ | 211 |  |
| Research and development | 4,928 |  |  | 2,467 |  |
| Sales and marketing | 2,409 |  |  | 1,428 |  |
| General and administrative | 866 |  |  | 676 |  |
| Total stock-based compensation | $ | 8,839 |  |  | $ | 4,782 |  |

[0001596532-15-000013:notes:44]
[same as prior period, unchanged from 0001596532-14-000005:notes:69]

[0001596532-15-000013:notes:45]
The following table summarizes the option and RSA (Restricted Stock Award) activity under our equity stock plans and related information:

[0001596532-15-000013:notes:46]
|  |  |  | Options and RSAs Outstanding |  |  |  |  |
|  | Shares Available for Grant(in thousands) |  | Number of Shares UnderlyingOutstanding Options and RSAs (in thousands) |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding (in thousands) |
| Outstanding—December 31, 2014 | 11,612 |  |  | 13,654 |  |  | $ | 17.63 |  |  | 8.3 |  | $ | 598,775 |  |
| Options granted | (283 | ) |  | 283 |  |  | 66.05 |  |  |  |  |  |
| Options exercised | — |  |  | (773 | ) |  | 6.92 |  |  |  |  |  |
| Options canceled | 221 |  |  | (221 | ) |  | 20.66 |  |  |  |  |  |
| Early exercised shares repurchased | 10 |  |  | — |  |  | 3.95 |  |  |  |  |  |
| Outstanding—March 31, 2015 | 11,560 |  |  | 12,943 |  |  | $ | 19.27 |  |  | 8.1 |  | $ | 661,984 |  |
| Vested and exercisable—March 31, 2015 |  |  | 3,371 |  |  | $ | 6.29 |  |  | 7.2 |  | $ | 216,548 |  |
| Vested and expected to vest—March 31, 2015 |  |  | 11,454 |  |  | $ | 17.80 |  |  | 8.0 |  | $ | 605,313 |  |

[0001596532-15-000013:notes:47]
The weighted-average grant-date fair value of options granted during the three months ended March 31, 2015 was $29.71 per share. The aggregate intrinsic value of options exercised for the three months ended March 31, 2015 was $47.1 million.

[0001596532-15-000013:notes:48]
As of March 31, 2015, the total unrecognized stock-based compensation expense related to unvested stock options, net of expected forfeitures, was $108.4 million, which is expected to be recognized over a weighted-average period of 4.3 years. The total fair value of options vested for the three months ended March 31, 2015 was $6.1 million.

[0001596532-15-000013:notes:49]
[same as prior period, unchanged from 0001596532-14-000005:notes:76]

[0001596532-15-000013:notes:50]
A summary of the RSU activity under our stock plans during the reporting period and a summary of information related to RSUs expected to vest are presented below (in thousands, except per share and year amounts):

[0001596532-15-000013:notes:51]
|  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2014 | 108 |  |  | $ | 75.56 |  |  | 2.0 |  | $ | 6,557 |  |
| RSUs granted | 72 |  |  | 67.37 |  |  |  |  |  |
| RSUs vested | — |  |  | — |  |  |  |  |  |
| RSUs forfeited/canceled | (3 | ) |  | 73.10 |  |  |  |  |  |
| Unvested balance—March 31, 2015 | 177 |  |  | $ | 72.27 |  |  | 1.9 |  | $ | 12,480 |  |
| RSUs expected to vest—March 31, 2015 | 156 |  |  | $ | 72.27 |  |  | 1.8 |  | $ | 10,974 |  |

[0001596532-15-000013:notes:52]
As of March 31, 2015, there was $10.2 million of unrecognized stock-based compensation cost related to unvested RSUs, net of estimated forfeitures. This amount is expected to be recognized over a weighted-average period of 3.7 years.

[0001596532-15-000013:notes:53]
Employee Stock Purchase Plan Activities

[0001596532-15-000013:notes:54]
During the three months ended March 31, 2015, we issued 132,862 shares at a weighted average price of $36.55. On February 17, 2015, the board authorized the increase to shares available for issuance under the plan of 1% of the total shares outstanding on January 1, 2015. The approved increase amounted to 655,139 shares. As a result there remain 1,173,277 shares available for issuance under the 2014 Employee Stock Purchase Plan, or ESPP, as of March 31, 2015.

[0001596532-15-000013:notes:55]
As of March 31, 2015, the total unrecognized stock-based compensation expense related to unvested ESPP options, net of expected forfeitures, was $3.0 million, which is expected to be recognized over a weighted-average period of 1.6 years.

[0001596532-15-000013:notes:56]
[same as prior period, unchanged from 0001596532-14-000005:notes:84]

[0001596532-15-000013:notes:57]
For the three months ended March 31, 2015, we repurchased 9,667 shares of common stock at the original exercise price due to the termination of the holders of the unvested shares. As of March 31, 2015, shares held by employees and directors that were subject to repurchase were 1.2 million with an aggregate price of $3.9 million.


## us-gaap:EarningsPerShareTextBlock

[0001596532-15-000013:notes:58]
[same as prior period, unchanged from 0001596532-14-000005:notes:86]

[0001596532-15-000013:notes:59]
[same as prior period, unchanged from 0001596532-14-000005:notes:87]

[0001596532-15-000013:notes:60]
|  | Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| Numerator: |  |  |  |
| Basic: |  |  |  |
| Net income | $ | 24,492 |  |  | $ | 12,329 |  |
| Less: undistributed earnings allocated to participating securities | (460 | ) |  | (5,967 | ) |
| Net income available to common stockholders, basic | $ | 24,032 |  |  | $ | 6,362 |  |
| Diluted: |  |  |  |
| Net income attributable to common stockholders, basic | $ | 24,032 |  |  | $ | 6,362 |  |
| Add: undistributed earnings allocated to participating securities | 39 |  |  | 454 |  |
| Net income attributable to common stockholders, diluted | $ | 24,071 |  |  | $ | 6,816 |  |
| Denominator: |  |  |  |
| Basic: |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 64,635 |  |  | 29,124 |  |
| Diluted: |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 64,635 |  |  | 29,124 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |
| Stock options, RSUs and RSAs | 5,928 |  |  | 4,692 |  |
| Employee stock purchase plan | 159 |  |  | — |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted | 70,722 |  |  | 33,816 |  |
| Net income per share attributable to common stockholders: |  |  |  |
| Basic | $ | 0.37 |  |  | $ | 0.22 |  |
| Diluted | $ | 0.34 |  |  | $ | 0.20 |  |

[0001596532-15-000013:notes:61]
[same as prior period, unchanged from 0001596532-14-000005:notes:89]

[0001596532-15-000013:notes:62]
|  | Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| Stock options and RSUs to purchase common stock | 1,906 |  |  | 1,959 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-15-000013:notes:63]
We measure and report our cash equivalents and available-for-sale marketable securities at fair value. The following table sets forth the fair value of our financial assets by level within the fair value hierarchy (in thousands):

[0001596532-15-000013:notes:64]
|  | March 31, 2015 |
|  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 104,305 |  |  | $ | — |  |  | $ | — |  |  | $ | 104,305 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| U.S. government notes | 209,153 |  |  | — |  |  | — |  |  | 209,153 |  |
| Total financial assets | $ | 313,458 |  |  | $ | — |  |  | $ | — |  |  | $ | 313,458 |  |

[0001596532-15-000013:notes:65]
|  | December 31, 2014 |
|  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 104,216 |  |  | $ | — |  |  | $ | — |  |  | $ | 104,216 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| U.S. government notes | 209,426 |  |  | — |  |  | — |  |  | 209,426 |  |
| Total financial assets | $ | 313,642 |  |  | $ | — |  |  | $ | — |  |  | $ | 313,642 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-15-000013:notes:66]
[same as prior period, unchanged from 0001596532-14-000005:notes:96]

[0001596532-15-000013:notes:67]
Our assets and liabilities which require fair value measurement consist of cash and cash equivalents, marketable securities, accounts receivable, investments, accounts payable, and accrued liabilities. Cash equivalents, accounts receivable, accounts payable and accrued liabilities are stated at carrying amounts as reported in the condensed consolidated financial statements, which approximates fair value due to their short term nature.

[0001596532-15-000013:notes:68]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying condensed consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value. Fair value is defined as the exchange price that would be received for an asset or an exit price that would be paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. Valuation techniques used to measure fair value must maximize the use of observable inputs and minimize the use of unobservable inputs. The authoritative guidance on fair value measurements establishes a three-tier fair value hierarchy for disclosure of the inputs used to measure fair value instruments as follows:

[0001596532-15-000013:notes:69]
Level I—Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date;

[0001596532-15-000013:notes:70]
Level II—Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities; and

[0001596532-15-000013:notes:71]
Level III—Unobservable inputs that are supported by little or no market data for the related assets or liabilities and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.

[0001596532-15-000013:notes:72]
Our financial instruments recorded at fair value on a recurring basis consist of Level I assets that include highly liquid money market funds that are included in cash and cash equivalents and U.S. government notes classified as marketable securities. We did not have any Level II or Level III financial instruments recorded at fair value on a recurring basis as of March 31, 2015 and December 31, 2014 .


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-15-000013:notes:73]
[same as prior period, unchanged from 0001596532-14-000005:notes:104]

[0001596532-15-000013:notes:74]
Provision for income taxes was approximately $10.0 million and $7.1 million for the three months ended March 31, 2015 and 2014, respectively. The change in our provision for income taxes was primarily due to an increase in profit before income tax and the decrease in the effective tax rate based on our current geographical distribution of the earnings.

[0001596532-15-000013:notes:75]
The effective tax rate for the year ended December 31, 2014 included the impact of the reinstatement of the 2014 Research and Development ("R&D") tax credit as result of the passage of the Tax Increase Prevention Act of 2014. The impact of the 2014 federal R&D tax credit benefit was recorded in the fourth quarter of the year ended December 31, 2014.

[0001596532-15-000013:notes:76]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. As we expand internationally, our marginal tax rate may decrease; however, there can be no certainty that our marginal tax rate will decrease, and we may experience changes in tax rates that are not reflective of actual changes in our business or operations. Earnings from our non-U.S. activities are subject to local country income tax and may be subject to U.S. income tax. Generally, the U.S. tax obligation is reduced by a credit for foreign income taxes paid on these earnings avoiding double taxation.

[0001596532-15-000013:notes:77]
Our gross unrecognized tax benefits were $21.3 million as of March 31, 2015. If the gross unrecognized tax benefits as of March 31, 2015 were realized in future periods, this would result in a tax benefit of $15.8 million within our provision of income taxes.  Because of the net operating loss and tax credit carryforward, substantially all of our tax years remain open to federal and state tax examination.  However, it is possible that unrecognized tax benefits may decrease in the future as the statute of limitation lapses in some of the jurisdictions over the next 12 months.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001596532-15-000013:notes:78]
Investments

[0001596532-15-000013:notes:79]
Investments in Privately-held Companies

[0001596532-15-000013:notes:80]
We have equity investments of approximately $33.6 million in privately held companies which are accounted for under the cost method. There were no impairments recognized on our investments for the three months ended March 31, 2015 as there were no significant identified events or changes in circumstances that would be considered an indicator for impairment.

[0001596532-15-000013:notes:81]
[same as prior period, unchanged from 0001596532-14-000005:notes:108]

[0001596532-15-000013:notes:82]
We have a $3.0 million promissory note with a privately held company which was recorded at cost. The interest rate on the promissory note is 8.0% per annum and is payable quarterly. All unpaid principal and accrued interest on the promissory note is due and payable on the earlier of August 26, 2017, or upon default.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-15-000013:notes:83]
In May 2014, the FASB issued ASU No. 2014-09, Revenue From Contracts With Customers, which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The standard is effective for fiscal years (and interim reporting periods within those years) beginning after December 15, 2016. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. We are currently reviewing the provisions of the standard and have not yet selected a transition method nor have we determined the effect of the standard on our consolidated financial statements.

[0001596532-15-000013:notes:84]
In April 2015, the FASB issued ASU No. 2015-05, Intangibles—Goodwill and Other—Internal-Use Software, which  clarifies the circumstances under which a cloud computing customer would account for the arrangement as a license of internal-use software. A cloud computing arrangement would include a software license if (1) the customer has a contractual right to take possession of the software at any time during the hosting period without significant penalty and (2) it is feasible for the customer to either run the software on its own hardware or contract with another party unrelated to the vendor to host the software. If the arrangement does not contain a software license, it would be accounted for as a service contract. The guidance is effective for fiscal years beginning after December 15, 2015. Early adoption is permitted. The guidance can be applied retrospectively to each prior reporting period presented or prospectively to arrangements entered into, or materially modified, after the effective date. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-15-000013:notes:85]
[same as prior period, unchanged from 0001596532-14-000005:notes:114]

[0001596532-15-000013:notes:86]
[same as prior period, unchanged from 0001596532-14-000005:notes:115]

[0001596532-15-000013:notes:87]
[same as prior period, unchanged from 0001596532-14-000005:notes:116]

[0001596532-15-000013:notes:88]
Basis of Presentation

[0001596532-15-000013:notes:89]
[same as prior period, unchanged from 0001596532-14-000005:notes:124]

[0001596532-15-000013:notes:90]
[same as prior period, unchanged from 0001596532-14-000005:notes:125]

[0001596532-15-000013:notes:91]
Business Concentrations

[0001596532-15-000013:notes:92]
[same as prior period, unchanged from 0001596532-14-000005:notes:126]

[0001596532-15-000013:notes:93]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, marketable securities, accounts receivable and notes receivable. Our cash and cash equivalents are invested in high quality financial instruments with banks and financial institutions. Such deposits may be in excess of insured limits provided on such deposits.

[0001596532-15-000013:notes:94]
[same as prior period, unchanged from 0001596532-14-000005:notes:128]

[0001596532-15-000013:notes:95]
[same as prior period, unchanged from 0001596532-14-000005:notes:130]

[0001596532-15-000013:notes:96]
Recent Accounting Pronouncements


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001596532-15-000013:notes:97]
[same as prior period, unchanged from 0001596532-14-000005:notes:135]

[0001596532-15-000013:notes:98]
|  | March 31, 2015 |  | December 31, 2014 |
| Equipment and machinery | $ | 19,785 |  |  | $ | 18,265 |  |
| Computer hardware and software | 8,600 |  |  | 7,772 |  |
| Furniture and fixtures | 1,837 |  |  | 1,373 |  |
| Leasehold improvements | 21,376 |  |  | 19,420 |  |
| Building | 35,154 |  |  | 35,154 |  |
| Construction-in-process | 5,877 |  |  | 6,532 |  |
| Property and equipment, gross | 92,629 |  |  | 88,516 |  |
| Less: accumulated depreciation | (19,842 | ) |  | (16,958 | ) |
| Property and equipment, net | $ | 72,787 |  |  | $ | 71,558 |  |


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001596532-15-000013:notes:99]
[same as prior period, unchanged from 0001596532-14-000005:notes:137]

[0001596532-15-000013:notes:100]
|  | March 31, 2015 |  | December 31, 2014 |
| Accounts receivable | $ | 115,937 |  |  | $ | 100,076 |  |
| Allowance for doubtful accounts | (1,260 | ) |  | (1,063 | ) |
| Sales return reserve | (1,620 | ) |  | (2,031 | ) |
| Accounts receivable, net | $ | 113,057 |  |  | $ | 96,982 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001596532-15-000013:notes:101]
[same as prior period, unchanged from 0001596532-14-000005:notes:139]

[0001596532-15-000013:notes:102]
|  | March 31, 2015 |  | December 31, 2014 |
| Accrued payroll related costs | $ | 10,809 |  |  | $ | 30,749 |  |
| Accrued warranty costs | 3,686 |  |  | 3,204 |  |
| Accrued manufacturing costs | 2,682 |  |  | 1,089 |  |
| Accrued professional fees | 6,360 |  |  | 2,354 |  |
| Accrued taxes | 1,110 |  |  | 1,577 |  |
| Other | 4,273 |  |  | 1,396 |  |
| Total accrued liabilities | $ | 28,920 |  |  | $ | 40,369 |  |


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001596532-15-000013:notes:103]
The following table summarizes the unrealized gains and losses and fair value of our available-for-sale marketable securities (in thousands):

[0001596532-15-000013:notes:104]
|  | March 31, 2015 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| U.S. government notes—due within one year | $ | 209,232 |  |  | $ | — |  |  | $ | (79 | ) |  | $ | 209,153 |  |

[0001596532-15-000013:notes:105]
|  | December 31, 2014 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| U.S. government notes—due within one year | $ | 209,671 |  |  | $ | — |  |  | $ | (245 | ) |  | $ | 209,426 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001596532-15-000013:notes:106]
[same as prior period, unchanged from 0001596532-14-000005:notes:141]

[0001596532-15-000013:notes:107]
|  | March 31, 2015 |  | December 31, 2014 |
| Raw materials | $ | 17,237 |  |  | $ | 17,094 |  |
| Finished goods | 73,988 |  |  | 63,425 |  |
| Total inventories | $ | 91,225 |  |  | $ | 80,519 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001596532-15-000013:notes:108]
Prepaid expenses and other current assets consist of the following (in thousands):

[0001596532-15-000013:notes:109]
|  | March 31, 2015 |  | December 31, 2014 |
| Prepaid income taxes | $ | 26,412 |  |  | $ | 25,212 |  |
| Other current assets | 5,323 |  |  | 9,820 |  |
| Other prepaids and deposits | 5,887 |  |  | 5,237 |  |
| Total prepaid expenses and other current assets | $ | 37,622 |  |  | $ | 40,269 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001596532-15-000013:notes:110]
[same as prior period, unchanged from 0001596532-14-000005:notes:143]

[0001596532-15-000013:notes:111]
|  | Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| Warranty accrual, beginning of period | $ | 3,204 |  |  | $ | 5,075 |  |
| Liabilities accrued for warranties issued during the period | 783 |  |  | 488 |  |
| Warranty costs incurred during the period | (301 | ) |  | (908 | ) |
| Warranty accrual, end of period | $ | 3,686 |  |  | $ | 4,655 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001596532-15-000013:notes:112]
[same as prior period, unchanged from 0001596532-14-000005:notes:145]

[0001596532-15-000013:notes:113]
|  | Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| United States | $ | 123,153 |  |  | $ | 92,993 |  |
| Other Americas | 3,604 |  |  | 3,207 |  |
| Europe, Middle East and Africa | 40,090 |  |  | 11,714 |  |
| Asia Pacific | 12,198 |  |  | 9,293 |  |
| Total revenue | $ | 179,045 |  |  | $ | 117,207 |  |

[0001596532-15-000013:notes:114]
[same as prior period, unchanged from 0001596532-14-000005:notes:147]

[0001596532-15-000013:notes:115]
[same as prior period, unchanged from 0001596532-14-000005:notes:148]

[0001596532-15-000013:notes:116]
|  | March 31, 2015 |  | December 31, 2014 |
| United States | $ | 68,235 |  |  | $ | 67,727 |  |
| International | 4,552 |  |  | 3,831 |  |
| Total | $ | 72,787 |  |  | $ | 71,558 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-15-000013:notes:117]
[same as prior period, unchanged from 0001596532-14-000005:notes:150]

[0001596532-15-000013:notes:118]
[same as prior period, unchanged from 0001596532-14-000005:notes:151]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-15-000013:notes:119]
[same as prior period, unchanged from 0001596532-14-000005:notes:152]

[0001596532-15-000013:notes:120]
Marketable Securities

[0001596532-15-000013:notes:121]
We did not realize any other-than-temporary losses on our marketable securities for the three months ended March 31, 2015 and 2014 or the year ended December 31, 2014.  None of our marketable securities have been in continuous unrealized loss positions for greater than twelve months as of March 31, 2015.

[0001596532-15-000013:notes:122]
We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. As interest rates increase, those marketable securities purchased at a lower yield show a mark-to-market unrealized loss. The unrealized losses are due primarily to changes in credit spreads and interest rates. We expect to realize the full value of all these investments upon maturity or sale.  The weighted average remaining duration of our current marketable securities is approximately 0.6 years as of March 31, 2015.

[0001596532-15-000013:notes:123]
[same as prior period, unchanged from 0001596532-14-000005:notes:153]

[0001596532-15-000013:notes:124]
[same as prior period, unchanged from 0001596532-14-000005:notes:154]

[0001596532-15-000013:notes:125]
Finished goods inventory includes deferred cost of revenue of $11.3 million and $2.5 million as of March 31, 2015  and December 31, 2014, respectively.

[0001596532-15-000013:notes:126]
Prepaid Expenses and Other Current Assets

[0001596532-15-000013:notes:127]
[same as prior period, unchanged from 0001596532-14-000005:notes:155]

[0001596532-15-000013:notes:128]
Building consists of capitalized construction costs of our leased building in Santa Clara, California. Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction, such as our financial involvement in structural elements of asset construction, making decisions related to tenant improvement costs and purchasing insurance not reimbursable by the buyer-lessor (the Landlord), we are deemed the owner of the building (for accounting purposes only) during the construction period. We maintain continued involvement in the property after construction was completed and lack transferability of the risks and rewards of ownership, primarily due to our required maintenance of a $4.0 million letter of credit.  Due to our continuing involvement in the property post construction and lack of transferability of related risks and rewards of ownership to the Landlord after construction is complete, we account for the building as a financing obligation. See “Note 5-Commitments and Contingencies". Accordingly, as of March 31, 2015 and December 31, 2014, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the Landlord. The building was completed in 2014.

[0001596532-15-000013:notes:129]
Depreciation expense was $2.9 million and $2.3 million, for the three months ended March 31, 2015 and 2014, respectively.

[0001596532-15-000013:notes:130]
[same as prior period, unchanged from 0001596532-14-000005:notes:160]

[0001596532-15-000013:notes:131]
[same as prior period, unchanged from 0001596532-14-000005:notes:161]

[0001596532-15-000013:notes:132]
[same as prior period, unchanged from 0001596532-14-000005:notes:162]

[0001596532-15-000013:notes:133]
Other Current Liabilities
