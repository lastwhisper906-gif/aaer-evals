# ANET 8-K — 0001596532-15-000008 filed 2015-05-14

## item codes, every 8-K on or before 2015-05-15

- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2015-05-15

- none on or before 2015-05-15

## item 2.02 — earnings release, exhibit 99.1

[0001596532-15-000008:8k_2_02:1]
EX-99.1
4
ex991q12015.htm
EXHIBIT 99.1

[0001596532-15-000008:8k_2_02:2]
EX. 99.1 Q12015

[0001596532-15-000008:8k_2_02:3]
Exhibit 99.1

[0001596532-15-000008:8k_2_02:4]
Arista Networks, Inc. Reports First Quarter 2015 Financial Results

[0001596532-15-000008:8k_2_02:5]
Cloud Networking Adoption Drives Record Revenue and non-GAAP Operating Income

[0001596532-15-000008:8k_2_02:6]
SANTA CLARA, Calif., May 14, 2015 - Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large data center and computing environments, today announced financial results for its first quarter ended March 31, 2015.

[0001596532-15-000008:8k_2_02:7]
First Quarter Financial Highlights

[0001596532-15-000008:8k_2_02:8]
| • | Revenue of $179.0 million, an increase of 52.8% compared to the first quarter of 2014, and an increase of 3.2% from the fourth quarter of 2014. |

[0001596532-15-000008:8k_2_02:9]
| • | Non-GAAP gross margin of 66.1%, compared to Non-GAAP gross margin of 69.6% in the first quarter of 2014 and 67.4% in the fourth quarter of 2014. |

[0001596532-15-000008:8k_2_02:10]
| • | GAAP gross margin of 65.8%, compared to GAAP gross margin of 69.4% in the first quarter of 2014 and 67.1% in the fourth quarter of 2014. |

[0001596532-15-000008:8k_2_02:11]
| • | Non-GAAP net income of $35.5 million, or $0.50 per diluted share, compared to non-GAAP net income of $16.4 million, or $0.25 per diluted share, in the first quarter of 2014. |

[0001596532-15-000008:8k_2_02:12]
| • | GAAP net income of $24.5 million, or $0.34 per diluted share, compared to GAAP net income of $12.3 million, or $0.20 per diluted share, in the first quarter of 2014. |

[0001596532-15-000008:8k_2_02:13]
| • | Operating cash flow of $20.8 million, compared to $17.7 million of operating cash flow in the first quarter of 2014. |

[0001596532-15-000008:8k_2_02:14]
"I am pleased with our Q1 2015 results, as we made strides in our top four verticals,” stated Jayshree Ullal, Arista President and CEO. “Our customer momentum in cloud networking, combined with our profitable growth and disruptive product innovations positions us well for the year."

[0001596532-15-000008:8k_2_02:15]
Commenting on the company's financial results, Andy Bechtolsheim, Arista’s Chairman and Interim CFO, said, "We  continued to execute strongly in Q1 2015 and achieved record revenue, a record non-GAAP operating margin of 28.6%, and doubled our non-GAAP earnings per share year-over-year.”

[0001596532-15-000008:8k_2_02:16]
Company Highlights

[0001596532-15-000008:8k_2_02:17]
| • | Arista Networks has been recognized as a leader in Gartner's 2015 Magic Quadrant for Data Center Networking. |

[0001596532-15-000008:8k_2_02:18]
| • | Announced Arista EOS as a Subscription (EaaS) service, a disaggregated offering that aligns to new cloud business models. |

[0001596532-15-000008:8k_2_02:19]
| • | Converged solutions with Supermicro to deliver converged compute networking for cloud scale data centers for EVO. |

[0001596532-15-000008:8k_2_02:20]
| • | Technology alliances with Infinera to deliver high performance metro-area cloud networks, and Lawo for IP-based broadcast Infrastructure. |

[0001596532-15-000008:8k_2_02:21]
| • | Certification from ServiceNow of the Arista cloud networking portfolio, for comprehensive operations and management of the network. |

[0001596532-15-000008:8k_2_02:22]
In addition, President and CEO Jayshree Ullal will be speaking with the financial community at the William Blair Growth Stock Conference in Chicago, Illinois on Wednesday, June 10, 2015 at 8:00am CT. A live audio webcast of the event will be accessible from the "Investors" section of Arista Networks website at investors.arista.com.

[0001596532-15-000008:8k_2_02:23]
Financial Outlook

[0001596532-15-000008:8k_2_02:24]
For the second quarter of 2015, we expect:

[0001596532-15-000008:8k_2_02:25]
| • | Revenue between $183 and $191 million. |

[0001596532-15-000008:8k_2_02:26]
| • | Non-GAAP gross margin in the range of 63% to 65% and |

[0001596532-15-000008:8k_2_02:27]
| • | Non-GAAP operating margin in the range of 23% to 25%. |

[0001596532-15-000008:8k_2_02:28]
Guidance for non-GAAP financial measures excludes legal expenses associated with the OptumSoft and Cisco litigation, stock-based compensation and other non-recurring expenses. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis.

[0001596532-15-000008:8k_2_02:29]
Prepared Materials and Conference Call Information

[0001596532-15-000008:8k_2_02:30]
Arista executives will discuss first quarter 2015 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial 1-877-201-0168 in the United States or 1-647-788-4901 from outside the US. The Conference ID is 21647872.

[0001596532-15-000008:8k_2_02:31]
The financial results conference call will also be available via live webcast on our investor relations website at investors.arista.com. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s Investor Relations website.

[0001596532-15-000008:8k_2_02:32]
Forward-Looking Statements

[0001596532-15-000008:8k_2_02:33]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the second quarter of FY 2015 and statements regarding being well positioned for future periods. Forward-looking statements are subject to a number of uncertainties and risks that could cause actual results to differ materially from those anticipated in the forward-looking statements including: Arista Networks’ limited operating history; risks associated with Arista Networks’ rapid growth; Arista Networks’ customer concentration; requests for more favorable terms and conditions from our large end customers; declines in the sales prices of our products and services; changes in customer order patterns or customer mix; increased competition in our products and service markets, including the data center market; dependence on the introduction and market acceptance of new product offerings and standards; rapid technological and market change; the dispute with Cisco Systems, Inc. and OptumSoft, Inc.; the evolution of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; and general market, political, economic and business conditions. Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s Annual Report on Form 10-K that was filed with the SEC on March 12, 2015 for the year ended December 31, 2014, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at http://investors.arista.com and on the SEC’s website at www.sec.gov. All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-15-000008:8k_2_02:34]
Non-GAAP Financial Measures

[0001596532-15-000008:8k_2_02:35]
The company reports non-GAAP results for gross margins, net income and net income per share in addition to, and not as a substitute for, financial measures calculated in accordance with GAAP. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends.

[0001596532-15-000008:8k_2_02:36]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-15-000008:8k_2_02:37]
Arista Networks defines non-GAAP gross margins as total gross profit, excluding stock-based compensation expenses, divided by total revenue. Arista Networks defines non-GAAP net income as net income, excluding stock based compensation expense, expenses associated with the OptumSoft and Cisco litigation and the related income tax effect of these exclusions. Arista Networks defines non-GAAP net income per share as non-GAAP net income divided by the diluted weighted average shares outstanding on a pro forma basis. In order to evaluate per share information on a comparative basis, the company believes it is meaningful to provide a non-GAAP financial measure that gives pro forma effect to the conversion of the preferred shares and notes payable into common shares and the issuance of common shares in connection with the company’s initial public offering as if each happened at the beginning of each period presented.

[0001596532-15-000008:8k_2_02:38]
Gartner, Magic Quadrant for Data Center Networking, Mark Fabbi | Andrew Lerner, 11 May 2015 Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner's research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001596532-15-000008:8k_2_02:39]
About Arista Networks

[0001596532-15-000008:8k_2_02:40]
Arista Networks was founded to deliver software-driven cloud networking solutions for large data center and computing environments. Arista’s award-winning 10/40/100 GbE switches redefine scalability, robustness, and price-performance. At the core of Arista’s platform is EOS, an advanced network operating system. Arista Networks products are available worldwide through distribution partners, systems integrators and resellers.

[0001596532-15-000008:8k_2_02:41]
ARISTA, EOS and Spline are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-15-000008:8k_2_02:42]
Additional information and resources can be found at: http://www.arista.com.

[0001596532-15-000008:8k_2_02:43]
| Media ContactAmanda JaramilloCorporate Communications(408) 547-5798amanda@arista.com |  | Investor ContactChuck ElliottProduct and Investor Advocacy(408) 547-5549chuck@arista.com |

[0001596532-15-000008:8k_2_02:44]
ARISTA NETWORKS, INC.

[0001596532-15-000008:8k_2_02:45]
Condensed Consolidated Statements of Income

[0001596532-15-000008:8k_2_02:46]
(Unaudited in thousands, except per share amounts)

[0001596532-15-000008:8k_2_02:47]
|  | Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| Revenue: |  |  |  |
| Product | $ | 160,141 |  |  | $ | 106,493 |  |
| Service | 18,904 |  |  | 10,714 |  |
| Total Revenue | 179,045 |  |  | 117,207 |  |
| Cost of revenue: |  |  |  |
| Product | 54,439 |  |  | 33,027 |  |
| Service | 6,852 |  |  | 2,866 |  |
| Total cost of revenue | 61,291 |  |  | 35,893 |  |
| Total gross profit | 117,754 |  |  | 81,314 |  |
| Operating expenses: |  |  |  |
| Research and development | 43,340 |  |  | 33,446 |  |
| Sales and marketing | 24,587 |  |  | 18,655 |  |
| General and administrative | 14,072 |  |  | 7,231 |  |
| Total operating expenses | 81,999 |  |  | 59,332 |  |
| Income from operations | 35,755 |  |  | 21,982 |  |
| Other income (expense), net: |  |  |  |
| Interest expense—related party | — |  |  | (432 | ) |
| Interest expense | (821 | ) |  | (2,111 | ) |
| Other income (expense), net | (468 | ) |  | 8 |  |
| Total other income (expense), net | (1,289 | ) |  | (2,535 | ) |
| Income before provision for income taxes | 34,466 |  |  | 19,447 |  |
| Provision for income taxes | 9,974 |  |  | 7,118 |  |
| Net income | $ | 24,492 |  |  | $ | 12,329 |  |
| Net income attributable to common stockholders: |  |  |  |
| Basic | $ | 24,032 |  |  | $ | 6,362 |  |
| Diluted | $ | 24,071 |  |  | $ | 6,816 |  |
| Net income per share attributable to common stockholders: |  |  |  |
| Basic | $ | 0.37 |  |  | $ | 0.22 |  |
| Diluted | $ | 0.34 |  |  | $ | 0.20 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |
| Basic | 64,635 |  |  | 29,124 |  |
| Diluted | 70,722 |  |  | 33,816 |  |

[0001596532-15-000008:8k_2_02:48]
ARISTA NETWORKS, INC.

[0001596532-15-000008:8k_2_02:49]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-15-000008:8k_2_02:50]
(Unaudited in thousands, except percentages and per share amounts)

[0001596532-15-000008:8k_2_02:51]
|  | Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| GAAP gross profit | $ | 117,754 |  |  | $ | 81,314 |  |
| GAAP gross margin | 65.8 | % |  | 69.4 | % |
| Stock-based compensation expense | 636 |  |  | 211 |  |
| Non-GAAP gross profit | $ | 118,390 |  |  | $ | 81,525 |  |
| Non-GAAP gross margin | 66.1 | % |  | 69.6 | % |
| GAAP income from operations | $ | 35,755 |  |  | $ | 21,982 |  |
| Stock-based compensation expense | 8,839 |  |  | 4,782 |  |
| Litigation expense | 6,670 |  |  | — |  |
| Non-GAAP income from operations | $ | 51,264 |  |  | $ | 26,764 |  |
| Non-GAAP operating margin | 28.6 | % |  | 22.8 | % |
| GAAP net income | $ | 24,492 |  |  | $ | 12,329 |  |
| Stock-based compensation expense | 8,839 |  |  | 4,782 |  |
| Litigation expense | 6,670 |  |  | — |  |
| Income tax effect on non-GAAP exclusions | (4,469 | ) |  | (705 | ) |
| Non-GAAP net income | $ | 35,532 |  |  | $ | 16,406 |  |
| Weighted average shares used in computing GAAP diluted income per share attributable to common stockholders | 70,722 |  |  | 33,816 |  |
| Additional weighted average dilutive shares1 | — |  |  | 32,282 |  |
| Non-GAAP weighted average diluted shares | 70,722 |  |  | 66,098 |  |
| GAAP diluted net income per share attributable to common stockholders | $ | 0.34 |  |  | $ | 0.20 |  |
| Net income attributable to participating securities | — |  |  | 0.16 |  |
| Non-GAAP adjustments to net income | 0.16 |  |  | 0.12 |  |
| Non-GAAP adjustments to diluted shares | — |  |  | (0.23 | ) |
| Non-GAAP diluted net income per share | $ | 0.50 |  |  | $ | 0.25 |  |
| Summary of Stock-Based Compensation Expense |  |  |  |
| Cost of revenue | $ | 636 |  |  | $ | 211 |  |
| Research and development | 4,928 |  |  | 2,467 |  |
| Sales and marketing | 2,409 |  |  | 1,428 |  |
| General and administrative | 866 |  |  | 676 |  |
| Total | $ | 8,839 |  |  | $ | 4,782 |  |

[0001596532-15-000008:8k_2_02:52]
______________________________

[0001596532-15-000008:8k_2_02:53]
1Includes weighted average shares from the issuance of shares upon our IPO and the assumed conversion of preferred stock and notes payable at the beginning of the quarter.

[0001596532-15-000008:8k_2_02:54]
ARISTA NETWORKS, INC.

[0001596532-15-000008:8k_2_02:55]
Condensed Consolidated Balance Sheets

[0001596532-15-000008:8k_2_02:56]
(Unaudited in thousands)

[0001596532-15-000008:8k_2_02:57]
|  | March 31, 2015 |  | December 31, 2014 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 275,186 |  |  | $ | 240,031 |  |
| Marketable securities | 209,153 |  |  | 209,426 |  |
| Accounts receivable, net | 113,057 |  |  | 96,982 |  |
| Inventories | 91,225 |  |  | 80,519 |  |
| Deferred tax assets | 9,801 |  |  | 12,252 |  |
| Prepaid expenses and other current assets | 37,622 |  |  | 40,269 |  |
| Total current assets | 736,044 |  |  | 679,479 |  |
| Property and equipment, net | 72,787 |  |  | 71,558 |  |
| Investments | 36,636 |  |  | 36,636 |  |
| Deferred tax assets | 12,291 |  |  | 11,510 |  |
| Other assets | 17,334 |  |  | 11,840 |  |
| TOTAL ASSETS | $ | 875,092 |  |  | $ | 811,023 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 29,123 |  |  | $ | 32,428 |  |
| Accrued liabilities | 28,920 |  |  | 40,369 |  |
| Deferred revenue | 81,826 |  |  | 60,327 |  |
| Other current liabilities | 8,462 |  |  | 11,249 |  |
| Total current liabilities | 148,331 |  |  | 144,373 |  |
| Income taxes payable | 17,502 |  |  | 17,323 |  |
| Lease financing obligations, non-current | 42,232 |  |  | 42,547 |  |
| Deferred revenue, non-current | 50,998 |  |  | 46,141 |  |
| Other long-term liabilities | 5,558 |  |  | 4,981 |  |
| TOTAL LIABILITIES | 264,621 |  |  | 255,365 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock | 7 |  |  | 7 |  |
| Additional paid-in capital | 456,509 |  |  | 426,171 |  |
| Retained earnings | 154,306 |  |  | 129,814 |  |
| Accumulated other comprehensive loss | (351) |  |  | (334 | ) |
| TOTAL STOCKHOLDERS’ EQUITY | 610,471 |  |  | 555,658 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 875,092 |  |  | $ | 811,023 |  |

[0001596532-15-000008:8k_2_02:58]
ARISTA NETWORKS, INC.

[0001596532-15-000008:8k_2_02:59]
Condensed Consolidated Statements of Cash Flows

[0001596532-15-000008:8k_2_02:60]
(Unaudited in thousands)

[0001596532-15-000008:8k_2_02:61]
|  | Three Months Ended March 31, |
|  | 2015 |  | 2014 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 24,492 |  |  | $ | 12,329 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 2,893 |  |  | 2,285 |  |
| Stock-based compensation | 8,839 |  |  | 4,782 |  |
| Deferred income taxes | 1,670 |  |  | 2,110 |  |
| Provision for bad debts | 201 |  |  | 43 |  |
| Amortization of debt discount | — |  |  | 292 |  |
| Excess tax benefit on stock based-compensation | (10,569 | ) |  | (311 | ) |
| Other | 487 |  |  | — |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | (16,276 | ) |  | 14,950 |  |
| Inventories | (10,706 | ) |  | (5,619 | ) |
| Prepaid expenses and other current assets | 2,613 |  |  | (3,349 | ) |
| Other assets | (3,502 | ) |  | (2,794 | ) |
| Accounts payable | (1,936 | ) |  | (5,904 | ) |
| Accrued liabilities | (12,358 | ) |  | 27 |  |
| Deferred revenue | 26,356 |  |  | (2,797 | ) |
| Interest payable | — |  |  | 1,110 |  |
| Interest payable—related party | — |  |  | 370 |  |
| Income taxes payable | 8,985 |  |  | 109 |  |
| Other liabilities | (422 | ) |  | 56 |  |
| Net cash provided by operating activities | 20,767 |  |  | 17,689 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of property and equipment | (5,136 | ) |  | (3,103 | ) |
| Other investing activities | (667 | ) |  | — |  |
| Net cash used in investing activities | (5,803 | ) |  | (3,103 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Principal payments of lease financing obligations | (255 | ) |  | (133 | ) |
| Payments—offering costs | (261 | ) |  | (775 | ) |
| Proceeds from issuance of common stock upon exercising options, net of repurchases | 5,322 |  |  | 1,861 |  |
| Proceeds from issuance of common stock under employee stock purchase plan | 4,856 |  |  | — |  |
| Excess tax benefit on stock-based compensation | 10,569 |  |  | 311 |  |
| Net cash provided by financing activities | 20,231 |  |  | 1,264 |  |
| Effect of exchange rate changes | (40 | ) |  | 10 |  |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 35,155 |  |  | 15,860 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 240,031 |  |  | 113,664 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 275,186 |  |  | $ | 129,524 |  |

## item 4.02 — body, verbatim

[0001596532-15-000008:8k_body:1]
ITEM 4.02    Non-Reliance on Previously Issued Financial Statements or a Related Audit Report or Completed Interim Report.

[0001596532-15-000008:8k_body:2]
The Company has determined that an amendment to its previously filed Form 10-K is required to correct the previously reported consolidated statement of cash flows and related disclosures for the year ended December 31, 2014.

[0001596532-15-000008:8k_body:3]
The correction has no impact on the Company’s consolidated balance sheets, statements of income, comprehensive income or stockholders equity as previously reported for the year ended December 31, 2014. Furthermore, the correction does not materially impact any other previously reported periods.

[0001596532-15-000008:8k_body:4]
In the course of preparing its interim financial statements for the quarter ended March 31, 2015, the Company identified an error in its consolidated statement of cash flows for the year ended December 31, 2014. The error was due to duplicate recognition of the excess tax benefits associated with its equity incentive plans resulting in a $17.4 million understatement of cash provided by operating activities and a corresponding $17.4 million overstatement of cash provided by financing activities.  The net increase in cash and cash equivalents and the ending cash and cash equivalents balance on the consolidated statement of cash flows were unaffected by this error and there was no impact to net income. No other previously reported periods require correction.

[0001596532-15-000008:8k_body:5]
The Audit Committee of the Company’s Board of Directors concluded, on May 13, 2015, after discussion with the Company’s management and its independent registered public accounting firm, Ernst & Young LLP, that the consolidated statement of cash flows for the year ended December 31, 2014 included in the Company’s Form 10-K for the year ended December 31, 2014, originally filed with the Securities and Exchange Commission on March 11, 2015, could no longer be relied upon and should be restated.

[0001596532-15-000008:8k_body:6]
As a result of the restatement, the Company has determined that a material weakness in its internal control over financial reporting existed as of December 31, 2014, which has not yet been remediated. The Company has concluded that discussions of cash flows and existence of a material weakness in internal controls in Risk Factors, Management’s Discussion and Analysis of Financial Condition and Results of Operations, Financial Statements and Supplementary Data, and Controls and Procedures reported in the Annual Report on Form 10-K should be restated in order to correct the errors and disclosures.  The Company will file an amendment to its Form 10-K, on Form 10-K/A, to correct the errors and disclosures as described above consistent with such restatement.

## item 5.02 — body, verbatim

[0001596532-15-000008:8k_body:7]
ITEM 5.02    Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001596532-15-000008:8k_body:8]
Appointment of Chief Financial Officer; Departure of Interim Chief Financial Officer

[0001596532-15-000008:8k_body:9]
On May 14, 2015, the Company announced the appointment of Ita Brennan as Senior Vice President, Chief Financial Officer of the Company. The appointment will become effective on or before May 18, 2015. Upon commencement of her employment, Ms. Brennan will assume the duties of the Company's principal financial officer and principal accounting officer until such time as her successor is appointed, or until her earlier resignation or removal. There are no reportable family relationships or related person transactions involving the Company and Ms. Brennan.

[0001596532-15-000008:8k_body:10]
Ms. Brennan, age 48, has most recently served as Chief Financial Officer of a stealth start up firm in the energy sector from February 2014 to May 2015. Prior to that, Ms. Brennan had an eight year career at Infinera Corporation, an intelligent transport networking company, most recently as CFO from July 2010 to February 2014 and Vice President of Finance and Corporate Controller from July 2006 to July 2010.  From 1997 to 2006, Ms. Brennan held various roles at Maxtor Corporation, a multi-billion dollar information storage solutions company, including Vice President of Finance for the Company’s Worldwide Operations.

[0001596532-15-000008:8k_body:11]
The Company entered into an offer letter with Ms. Brennan to memorialize her employment. Pursuant to the terms of the offer letter, Ms. Brennan will receive an annual base salary of $300,000.  Ms. Brennan will also be eligible to participate in the Company’s corporate bonus program for executive officers. Subject to necessary corporate approvals, Ms. Brennan will receive a grant of restricted stock units covering 50,000 shares of the Company common stock (“RSUs”) under the Company’s 2014 Equity Incentive Plan (the “Plan”). Such RSUs will vest quarterly over a total of approximately five years with an annual vesting cliff, subject to Ms. Brennan’s continued service to the Company through each vesting date. Additionally, subject to necessary

[0001596532-15-000008:8k_body:12]
corporate approvals, Ms. Brennan will receive a grant of nonstatutory options to purchase 50,000 shares of the Company’s common stock (the “Option”) pursuant to the Plan.  The Option will vest monthly over a five year period with an annual vesting cliff, subject to Ms. Brennan’s continued service to the Company through each vesting date.

[0001596532-15-000008:8k_body:13]
In addition, the Company entered into a severance agreement with Ms. Brennan. The severance agreement provides that if Ms. Brennan’s employment is involuntarily terminated other than for “cause” (as defined in the severance agreement) or if Ms. Brennan resigns for “good reason” (as defined in the severance agreement) then, subject to her execution of a release of claims, Ms. Brennan will receive continuing payments of her base salary for 12 months and accelerated vesting of time-based equity awards that would have vested had Ms. Brennan remained employment with us for 12 months following her termination of employment date. If the qualified termination of employment occurred during the period beginning on, and for 12 months following a change in control, then the equity acceleration benefit would be 50% of the then-unvested equity awards, if greater than the acceleration benefit described in the previous sentence.

[0001596532-15-000008:8k_body:14]
The offer letter and severance agreement between Ms. Brennan and the Company are attached as Exhibits 10.1 and 10.2, respectively, to this Current Report and is incorporated herein by reference.

[0001596532-15-000008:8k_body:15]
Upon the effective date of Ms. Brennan’s employment, Andreas Bechtolsheim will resign from the positions of interim Chief Financial Officer and Principal Financial Officer of the Company, a position he has held since April 9, 2015.
