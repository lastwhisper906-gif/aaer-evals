# ANET note change history — 0001596532-14-000005 → 0001596532-15-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-05-15):
[0001596532-15-000013:note_history:1]
| Years Ending December 31, |  |
| 2015 | $ | 2,583 |  |
| 2016 | 4,297 |  |
| 2017 | 5,155 |  |
| 2018 | 5,378 |  |
| 2019 | 5,369 |  |
| Thereafter | 22,407 |  |
| Total minimum future lease payments | $ | 45,189 |  |
  (was, 2014-11-07, similarity 0.9316):
[0001596532-14-000005:note_history:1]
| Years Ending December 31, |  |
| 2014 | $ | 825 |  |
| 2015 | 540 |  |
| 2016 | 507 |  |
| 2017 | 411 |  |
| 2018 | 161 |  |
| Total minimum future lease payments | $ | 2,444 |  |

- changed (2015-05-15):
[0001596532-15-000013:note_history:2]
Rent expense for all operating leases amounted to $0.8 million and $0.6 million for the three months ended March 31, 2015 and 2014, respectively.
  (was, 2014-11-07, similarity 0.8571):
[0001596532-14-000005:note_history:2]
Rent expense for all operating leases amounted to $0.8 million, $2.5 million, $1.3 million and $3.0 million for the three and nine months ended September 30, 2014 and 2013, respectively.

- changed (2015-05-15):
[0001596532-15-000013:note_history:3]
Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction such as our financial involvement in structural elements of asset construction, making decisions related to tenant improvement costs and purchasing insurance not reimbursable by the buyer-lessor (the Landlord), we are deemed the owner of the building (for accounting purposes only) during the construction period. We maintained continued involvement in the property after construction was completed and lack transferability of the risks and rewards of ownership, primarily due to our required maintenance of a $4.0 million letter of credit. Due to our continuing involvement in the property post construction and lack of transferability of related risks and rewards of ownership to the Landlord after construction is complete, we account for the building and related improvements as a lease financing obligation. Accordingly, as of March 31, 2015 and December 31, 2014, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $43.4 million and $43.6 million, respectively. As of March 31, 2015, $1.2 million and $42.2 million were recorded as short-term and long-term financing obligations, respectively.
  (was, 2014-11-07, similarity 0.7924):
[0001596532-14-000005:note_history:3]
Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction such as our financial involvement in structural elements of asset construction, making decisions related to tenant improvement costs and purchasing insurance not reimbursable by the buyer-lessor (the Landlord), we are deemed the owner of the building (for accounting purposes only) during the construction period. We maintained continued involvement in the property after construction was completed and lack transferability of the risks and rewards of ownership, primarily due to our required maintenance of a $4.0 million letter of credit. Due to our continuing involvement in the property post construction and lack of transferability of related risks and rewards of ownership to the Landlord after construction is complete, we account for the building and related improvements as a lease financing obligation.

- added (2015-05-15):
[0001596532-15-000013:note_history:4]
Land lease expense under our lease financing obligation amounted to $0.3 million and $0.3 million for the three months ended March 31, 2015 and 2014, respectively.

- added (2015-05-15):
[0001596532-15-000013:note_history:5]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. These forecasts are based on estimates of future demand for our products, historical trend analysis provided by our sales and product marketing organizations and adjusted for overall market conditions. We incur a liability when the contract manufacturer has converted the component inventory to a finished product.  However, historically we have reimbursed our contract manufacturer for component inventory purchases when this inventory has been rendered excess or obsolete due to manufacturing and engineering change orders resulting from design changes, or in cases where inventory levels greatly exceed our forecasts. As of March 31, 2015 and December 31, 2014, $0.2 million and $0.3 million related to the excess and obsolete component inventory liability to our contract manufacturers.  We have provided restricted deposits to our third-party contract manufacturers and vendors to secure our obligations to purchase inventory. We had $2.3 million in restricted deposits as of March 31, 2015 and December 31, 2014. Restricted deposits are classified in other assets in our accompanying unaudited condensed consolidated balance sheets.

- changed (2015-05-15):
[0001596532-15-000013:note_history:6]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft copies of certain components of our software for evaluation by OptumSoft, (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches, (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers, (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us, and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dtd July 27, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders. OptumSoft has identified in confidential documents certain software components it claims to own, which are generally applicable tools and utility subroutines and not networking specific code. We cannot assure which software components OptumSoft may ultimately claim to own in the litigation or whether such claimed components are material.
  (was, 2014-11-07, similarity 0.8474):
[0001596532-14-000005:note_history:6]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft copies of certain components of our software for evaluation by OptumSoft, (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches, (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers, (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us, and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dtd July 27, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is our largest stockholder.

- changed (2015-05-15):
[0001596532-15-000013:note_history:7]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we assert our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we assert that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We ask the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also assert that, even if we are found not to own any particular components at issue, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation. On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have strong defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.
  (was, 2014-11-07, similarity 0.6885):
[0001596532-14-000005:note_history:7]
On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have strong defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information. The Court set a trial date for April 2016.

- added (2015-05-15):
[0001596532-15-000013:note_history:8]
The Court set a trial date for Phase I of the proceedings, relating to contract interpretation and application of the contract to certain claimed source code for September 14, 2015.  The remaining issues are currently scheduled to be tried in April 2016.

- added (2015-05-15):
[0001596532-15-000013:note_history:9]
At this stage of the litigation, we are unable to determine whether a loss is probable or estimate a possible or range of possible loss.

- added (2015-05-15):
[0001596532-15-000013:note_history:10]
Cisco Systems, Inc. (“Cisco”) Matters

- added (2015-05-15):
[0001596532-15-000013:note_history:11]
On December 5, 2014, Cisco filed two complaints against us in District Court for the Northern District of California, which are proceeding as Case No. 4-14-cv-05343 (“’43 Case”) and Case No. 4-14-cv-05344 (“’44 Case”).  In the ’43 Case, Cisco alleges that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the 875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”).  Cisco seeks, as relief for our alleged infringement in the ’43 Case, lost profits and/or reasonable royalty damages in an unspecified amount, including treble damages, attorney’s fees, and associated costs.  Cisco also seeks injunctive relief in the ’43 Case.  On February 10, 2015, the court granted our unopposed motion to stay the ’43 Case until the proceedings before the United States International Trade Commission (“USITC”) pertaining to the same patents (as discussed below) become final.  In the ’44 Case, Cisco’s complaint alleges that we infringe U.S. Patent Nos. 7,047,526 and 7,953,886 and further alleges that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI.”  As relief for our alleged patent infringement in the ’44 Case, Cisco seeks lost profits and/or reasonable royalty damages in an unspecified amount including treble damages, attorney’s fees, and associated costs as well as injunctive relief.  As relief from our alleged copyright infringement, Cisco seeks damages in an unspecified amount in the form of alleged lost profits, profits from our alleged infringement, statutory damages, attorney’s fees and associated costs.  Cisco also seeks injunctive relief against our alleged copyright infringement.  On February 13, 2015, we answered the complaint in the ’44 Case, denying the patent and copyright infringement allegations and also raising numerous affirmative defenses.  On March 6, 2015, Cisco filed an amended complaint against in the ’44 Case.  In response, we moved to dismiss Cisco’s allegations of willful patent infringement and pre-suit indirect patent infringement.  A hearing on our motion to dismiss is scheduled for July 2, 2015.  Trial has not been scheduled in either the ’43 or ’44 Cases.

- added (2015-05-15):
[0001596532-15-000013:note_history:12]
On December 19, 2014, Cisco filed two complaints against us in the USITC alleging that Arista has violated section 337 of the Tariff Act of 1930, as amended. The complaints have been instituted as ITC Inv. Nos. 337-TA-944 (“’944 Investigation”) and 337-TA-945 (“’945 Investigation).   In the ’944 Investigation, Cisco alleges that certain Arista switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents.  In the ’945 Investigation, Cisco alleges that certain Arista switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents.  In both the ’944 and ’945 Investigations, Cisco seeks, among other things, a limited exclusion order barring entry into the United States of accused switch products (including 7000 Series of switches) and a cease and desist order against us restricting our activities with respect to our imported accused switch products.  On January 28, 2015, the Administrative Law Judge assigned to the ’944 Investigation set May 27, 2016 as the target date for completion of the ’944 Investigation.  On February 11, 2015, we responded to the notices of investigation and complaints in the ’944 and ’945 Investigations by, among other things, denying any violation of section 337 of the Tariff Act and the patent infringement allegations, and raising numerous additional defenses.  On February 19, 2015, the Administrative Law Judge assigned to the ’945 Investigation issued a procedural schedule calling for, among other events:  issuance of an order construing the claims of the ’577, ’853, ’875, ’668, ’492, and ’211 patents tentatively on July 17, 2015; an evidentiary hearing on November 9-20, 2015; issuance of an initial determination regarding our alleged violations on April 26, 2016; and the target date for completion of the ’945 Investigation on August 26, 2016. On March 9, 2015, the Administrative Law Judge assigned to the ’944 Investigation issued a procedural schedule calling for, among other events:  an evidentiary hearing on Sept. 9-11 & 15-17, 2015 and issuance of an initial determination regarding our alleged violations on January 27, 2016.

- added (2015-05-15):
[0001596532-15-000013:note_history:13]
On April 1, 2015, we filed petitions for Inter Partes Review with the United States Patent Trial and Appeal Board (“PTAB”) seeking to invalidate Cisco’s ’597, ’211, and ’668 patents.  On April 10, 2015, we filed petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853 and ’577 patents.  On April 16, 2015, we filed additional petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853 and ’577 patents.  We expect that the PTAB will determine whether or not to institute review of the validity with respect to each of our petitions for Inter Partes Review within six months of the filing dates for those petitions.  To the extent that the PTAB grants our petitions and institutes review, the PTAB must issue its final written decision on validity within twelve months of its institution decision.

- added (2015-05-15):
[0001596532-15-000013:note_history:14]
At this stage of the litigation, we are unable to determine whether a loss is probable or estimate a possible or range of possible loss.

- added (2015-05-15):
[0001596532-15-000013:note_history:15]
We intend to vigorously defend against Cisco’s lawsuits, as summarized in the preceding paragraphs.  However, we cannot be certain that, if litigated, any claims by Cisco would be resolved in our favor.  For example, an adverse litigation ruling could result in a significant damages award against us, could further result in the above described injunctive relief (including, among other things, an order excluding our products from importation into the United States), could result in a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products to the extent that we are found to infringe any valid claims asserted against us by Cisco. In particular, with respect to the ‘944 and ‘945 Investigations, if our products are found to infringe any patents that are the subject of those investigations, the USITC would likely issue a limited exclusion order barring entry into the United States of accused switch products (including 7000 Series of switches) and a cease and desist order restricting our activities with respect to our imported accused switch products. In the case that we attempt to modify our manufacturing and importation processes to comply with such orders, we may not be able to do so successfully or without substantial expense. Moreover, in the case we attempt to modify our products, to the extent we are found to infringe on any valid claims asserted against us, we may not be able to successfully modify our products in a substantial manner and any modified products may not be well received in the market.  Any such adverse ruling could materially adversely affect our business, prospects, results of operation and financial condition.  To the extent that we reached a negotiated settlement with Cisco, the settlement could require payment of substantial royalties.  Additionally, the existence of this lawsuit could cause concern among our customers and potential customers and could adversely affect our business and results of operations.  Whether or not we prevail in the lawsuit, we expect that the litigation will be expensive, time-consuming and a distraction to management in operating our business.

- removed (2015-05-15):
[0001596532-14-000005:note_history:16]
On July 30, 2014, we entered into an agreement to lease additional space to expand our headquarters in Santa Clara, California. The lease is expected to commence in phases on January 1, 2015 for a portion and subsequently on January 1, 2016 for the remainder and expiring on September 30, 2023. The minimum payments will be approximately $2.6 million per year.

- removed (2015-05-15):
[0001596532-14-000005:note_history:17]
Accordingly, as of September 30, 2014 and December 31, 2013, we have recorded assets of $53.4 million and $53.3 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $43.9 million and $44.0 million, respectively. As of September 30, 2014, $1.1 million and $42.8 million were recorded as short-term and long-term financing obligations, respectively. During the construction period, we continued to increase the asset and financing obligation as additional building and improvement costs were incurred until construction was completed.

- removed (2015-05-15):
[0001596532-14-000005:note_history:18]
Our products are manufactured, assembled and tested by third-party contract manufacturers in Asia who procure components and assemble products on our behalf based on our forecasts. These forecasts are based on estimates of future demand for our products, historical trend analysis provided by our sales and product marketing organizations and adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to these third-party contract manufacturers and vendors that may not be cancelable. As of September 30, 2014 and December 31, 2013, our contract manufacturer liability was $0.9 million and $1.8 million for non-cancelable purchase commitments issued to our vendors.

- removed (2015-05-15):
[0001596532-14-000005:note_history:19]
We have provided restricted deposits to our third-party contract manufacturers and vendors to secure our obligations to purchase inventory. We had $2.3 million in restricted deposits as of September 30, 2014 and December 31, 2013. Restricted deposits are classified in deposits and other non-current assets in our accompanying unaudited condensed consolidated balance sheets.

- removed (2015-05-15):
[0001596532-14-000005:note_history:20]
OptumSoft has identified in confidential documents certain software components it claims to own, which are generally applicable tools and utility subroutines and not networking specific code. We cannot assure which software components OptumSoft may ultimately claim to own in the litigation or whether such claimed components are material.

- removed (2015-05-15):
[0001596532-14-000005:note_history:21]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we assert our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we assert that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We ask the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also assert that, even if we are found not to own any particular components at issue, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation.

- removed (2015-05-15):
[0001596532-14-000005:note_history:22]
We do not believe a loss is probable; however, it is a reasonable possibility. Due to the early stage of this matter, no estimate of the amount or range of possible amounts can be determined at this time.

- removed (2015-05-15):
[0001596532-14-000005:note_history:23]
Net Navigation LLC Matters

- removed (2015-05-15):
[0001596532-14-000005:note_history:24]
On April 23, 2014, Net Navigation LLC sued us for alleged infringement of U.S. Patent Nos. 5,901,147; 6,434,145; and 6,625,122 in U.S. District Court for the Eastern District of Texas. On June 30, 2014, we and Net Navigation LLC settled this dispute.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-05-15):
[0001596532-15-000013:note_history:25]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (" U.S. GAAP") and following the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by U.S. GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2015, are not necessarily indicative of the results expected for the full fiscal year.
  (was, 2014-11-07, similarity 0.973):
[0001596532-14-000005:note_history:25]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (" U.S. GAAP") and following the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by U.S. GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2014, are not necessarily indicative of the results expected for the full fiscal year.

- added (2015-05-15):
[0001596532-15-000013:note_history:26]
The accompanying unaudited condensed consolidated financial statements and related financial information should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2014, filed with the SEC on March 11, 2015 and our Amended Annual Report on Form 10-K/A for the fiscal year ended December 31, 2014, filed with the SEC on May 14, 2015.

- added (2015-05-15):
[0001596532-15-000013:note_history:27]
Commencing in the first quarter of fiscal 2015, we have disaggregated total revenue and cost of revenue into "Product" and "Service". Prior period balances have been reclassified to conform to this new presentation.

- changed (2015-05-15):
[0001596532-15-000013:note_history:28]
There have been no changes in our significant accounting policies from those that were disclosed in our audited consolidated financial statements for the year ended December 31, 2014.
  (was, 2014-11-07, similarity 0.8698):
[0001596532-14-000005:note_history:28]
There have been no changes in our significant accounting policies from those that were disclosed in our audited consolidated financial statements for the year ended December 31, 2013 included in the Prospectus other than the following:

- changed (2015-05-15):
[0001596532-15-000013:note_history:29]
We work closely with third parties to manufacture and deliver our products. As of March 31, 2015 and December 31, 2014, two suppliers provided essentially all of our electronic manufacturing services. Our products rely on key components, including certain integrated circuit components and power supplies some of which our contract manufacturers purchase on our behalf from a limited number of suppliers, including certain sole source providers. We do not have guaranteed supply contracts with any of our component suppliers, and our suppliers could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, sales of our products could be delayed or halted entirely or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.
  (was, 2014-11-07, similarity 0.9894):
[0001596532-14-000005:note_history:29]
We work closely with third parties to manufacture and deliver our products. As of September 30, 2014 and December 31, 2013, two suppliers provided all of our electronic manufacturing services. Our products rely on key components, including certain integrated circuit components and power supplies some of which our contract manufacturers purchase on our behalf from a limited number of suppliers, including certain sole source providers. We do not have guaranteed supply contracts with any of our component suppliers, and our suppliers could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, sales of our products could be delayed or halted entirely or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.

- added (2015-05-15):
[0001596532-15-000013:note_history:30]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, marketable securities, accounts receivable and notes receivable. Our cash and cash equivalents are invested in high quality financial instruments with banks and financial institutions. Such deposits may be in excess of insured limits provided on such deposits.

- changed (2015-05-15):
[0001596532-15-000013:note_history:31]
In May 2014, the FASB issued ASU No. 2014-09, Revenue From Contracts With Customers, which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The standard is effective for fiscal years (and interim reporting periods within those years) beginning after December 15, 2016. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. We are currently reviewing the provisions of the standard and have not yet selected a transition method nor have we determined the effect of the standard on our consolidated financial statements.
  (was, 2014-11-07, similarity 0.9473):
[0001596532-14-000005:note_history:31]
In May 2014, the FASB issued ASU No. 2014-09, Revenue From Contracts With Customers ("ASU 2014-09"), which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. ASU 2014-09 is effective for fiscal years (and interim reporting periods within those years) beginning after December 15, 2016. Early application is not permitted. ASU 2014-09 permits the use of either the retrospective or cumulative effect transition method. We are currently reviewing the provisions of ASU 2014-09 and have not yet selected a transition method nor have we determined the effect of the standard on our consolidated financial statements.

- added (2015-05-15):
[0001596532-15-000013:note_history:32]
In April 2015, the FASB issued ASU No. 2015-05, Intangibles—Goodwill and Other—Internal-Use Software, which  clarifies the circumstances under which a cloud computing customer would account for the arrangement as a license of internal-use software. A cloud computing arrangement would include a software license if (1) the customer has a contractual right to take possession of the software at any time during the hosting period without significant penalty and (2) it is feasible for the customer to either run the software on its own hardware or contract with another party unrelated to the vendor to host the software. If the arrangement does not contain a software license, it would be accounted for as a service contract. The guidance is effective for fiscal years beginning after December 15, 2015. Early adoption is permitted. The guidance can be applied retrospectively to each prior reporting period presented or prospectively to arrangements entered into, or materially modified, after the effective date. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

- removed (2015-05-15):
[0001596532-14-000005:note_history:33]
Initial Public Offering

- removed (2015-05-15):
[0001596532-14-000005:note_history:34]
On June 6, 2014, we completed our initial public offering (the “IPO”) in which we sold 6,037,500 shares of our common stock at a public offering price of $43.00 per share, which included 787,500 shares of common stock issued pursuant to the exercise in full of the over-allotment option granted to the underwriters. The IPO resulted in proceeds of $238.9 million, net of underwriting discounts and commissions of $15.6 million and other estimated issuance costs of $5.1 million. In connection with the closing of the IPO, all of our outstanding convertible preferred stock automatically converted into 24,000,000 shares of common stock on a one-to-one basis.

- removed (2015-05-15):
[0001596532-14-000005:note_history:35]
Upon the closing of our IPO, all noteholders with the exception of one noteholder converted the principal and accrued interest amount outstanding under their subordinated convertible promissory notes into shares of our common stock at the IPO price of $43.00 per share. The noteholder, who did not elect to so convert, was paid a total of $23.6 million which included principal and accrued interest less applicable withholding taxes of $1.1 million. The remainder of the noteholders converted the remaining debt balance of approximately $96.5 million including principal and accrued interest into 2.2 million shares of our common stock.

- removed (2015-05-15):
[0001596532-14-000005:note_history:36]
The accompanying unaudited condensed consolidated financial statements and related financial information should be read in conjunction with the audited consolidated financial statements and related footnotes included in our prospectus filed pursuant to Rule 424(b) under the Securities Act of 1933, as amended (the “Securities Act”), with the SEC on June 6, 2014 (the “Prospectus”).

- removed (2015-05-15):
[0001596532-14-000005:note_history:37]
New Accounting Policy

- removed (2015-05-15):
[0001596532-14-000005:note_history:38]
Investments

- removed (2015-05-15):
[0001596532-14-000005:note_history:39]
We have recorded our equity investment in a privately-held company under the cost method. Initial measurement of our investment under the cost method is recorded at historical cost which represents our initial investment in the privately-held company.  We will periodically assess and evaluate our cost method investment for impairment and perform an assessment based on evaluation of overall financial performance, industry and market conditions, and other relevant events or factors deemed necessary that may affect carrying value. If we determine that a decrease in the equity investment should be recognized given impairment that is considered “other than temporary” in nature, we will write-down the carrying amount to its revised new fair value.

- removed (2015-05-15):
[0001596532-14-000005:note_history:40]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, restricted cash, accounts receivable and notes receivable. Our cash, cash equivalents and restricted cash are invested in high quality financial instruments with banks and financial institutions. Such deposits may be in excess of insured limits provided on such deposits.

- removed (2015-05-15):
[0001596532-14-000005:note_history:41]
Our notes receivable are secured and represent amounts due to us from a private company. We mitigate credit risk in respect to the notes receivable by performing ongoing credit evaluations of the borrower to assess the probability of collecting all amounts due to us under the existing contractual terms.

- removed (2015-05-15):
[0001596532-14-000005:note_history:42]
Reclassifications

- removed (2015-05-15):
[0001596532-14-000005:note_history:43]
As a result of a change in classification, we have reclassified our spare parts inventory from inventory to other current and non-current assets as of September 30, 2014. Spare parts inventory are used to satisfy our warranty obligations, and are not available for sale or used in the production process. Prior year balances have been adjusted to conform to this new classification for comparability purposes.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2015-05-15):
[0001596532-14-000005:note_history:44]
New Accounting Policy

- removed (2015-05-15):
[0001596532-14-000005:note_history:45]
Investments

- removed (2015-05-15):
[0001596532-14-000005:note_history:46]
We have recorded our equity investment in a privately-held company under the cost method. Initial measurement of our investment under the cost method is recorded at historical cost which represents our initial investment in the privately-held company.  We will periodically assess and evaluate our cost method investment for impairment and perform an assessment based on evaluation of overall financial performance, industry and market conditions, and other relevant events or factors deemed necessary that may affect carrying value. If we determine that a decrease in the equity investment should be recognized given impairment that is considered “other than temporary” in nature, we will write-down the carrying amount to its revised new fair value.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2015-05-15):
[0001596532-14-000005:note_history:47]
Debt Obligations

- removed (2015-05-15):
[0001596532-14-000005:note_history:48]
Our debt obligations consist of the following (in thousands):

- removed (2015-05-15):
[0001596532-14-000005:note_history:49]
|  |  | December 31, 2013 |
| Convertible notes payable—related party |  | $ | 25,000 |  |
| Convertible notes payable |  | 75,000 |  |
| Total |  | 100,000 |  |
| Less: Unamortized discount on notes payable |  | 1,207 |  |
| Less: Current portion |  | 98,793 |  |
| Total long-term portion of debt |  | $ | — |  |

- removed (2015-05-15):
[0001596532-14-000005:note_history:50]
In January 2011, we sold $55.0 million aggregate principal amount of subordinated convertible promissory notes (“Convertible Notes”) to outside investors and $25.0 million aggregate principal amount of Convertible Notes to two trusts that are related to two of our co-founders.  In June 2011, we sold an additional $20.0 million in Convertible Notes to outside investors.  The Convertible Notes were convertible into shares of our common stock upon a change of control, a qualified IPO, or immediately prior to when the notes are to be voluntarily prepaid. The interest rate on the Convertible Notes was 6.0% per annum, computed on the basis of the actual number of days elapsed and a year of 365 days. All unpaid principal and accrued interest on the Convertible Notes were due and payable on the earlier of December 31, 2014 or upon the occurrence of an event of default, defined as: (i) failure to pay principal or interest when due; (ii) breaches of covenants; (iii) breaches of representations and warranties; (iv) failure to make other payment obligations resulting in the acceleration of maturity of indebtedness in excess of $10.0 million; (v) voluntary bankruptcy; (vi) involuntary bankruptcy; or (vii) certain adverse judgments. We could have voluntarily prepaid the Convertible Notes, in whole or in part, before the maturity date by giving each investor 10 days’ prior written notice. We were also required to prepay the Convertible Notes upon a change of control unless the investor elected to convert its Convertible Note immediately prior to the closing of such change of control.

- removed (2015-05-15):
[0001596532-14-000005:note_history:51]
Upon the closing of our IPO all noteholders with the exception of one noteholder converted the principal and accrued interest amount outstanding under their subordinated convertible promissory notes into shares of our common stock at the IPO price of $43.00 per share. The noteholder, who did not elect to so convert, was paid a total of $23.6 million which included principal and accrued interest less applicable withholding taxes of $1.1 million. The remainder of the noteholders converted the remaining debt balance of approximately $96.5 million including principal and accrued interest into 2.2 million shares of our common stock.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2015-05-15):
[0001596532-14-000005:note_history:52]
Our debt obligations consist of the following (in thousands):

- removed (2015-05-15):
[0001596532-14-000005:note_history:53]
|  |  | December 31, 2013 |
| Convertible notes payable—related party |  | $ | 25,000 |  |
| Convertible notes payable |  | 75,000 |  |
| Total |  | 100,000 |  |
| Less: Unamortized discount on notes payable |  | 1,207 |  |
| Less: Current portion |  | 98,793 |  |
| Total long-term portion of debt |  | $ | — |  |
