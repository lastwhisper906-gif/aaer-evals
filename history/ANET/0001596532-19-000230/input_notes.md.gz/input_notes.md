# ANET notes — 0001596532-19-000230


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-19-000230:notes:1]
[same as prior period, unchanged from 0001596532-19-000184:notes:1]

[0001596532-19-000230:notes:2]
[same as prior period, unchanged from 0001596532-19-000184:notes:2]

[0001596532-19-000230:notes:3]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” “us” or the “Company”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System (“EOS”), a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-19-000230:notes:4]
[same as prior period, unchanged from 0001596532-19-000184:notes:4]

[0001596532-19-000230:notes:5]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2019, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2018 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant intercompany accounts and transactions have been eliminated.

[0001596532-19-000230:notes:6]
[same as prior period, unchanged from 0001596532-19-000184:notes:6]

[0001596532-19-000230:notes:7]
[same as prior period, unchanged from 0001596532-19-000184:notes:7]

[0001596532-19-000230:notes:8]
[same as prior period, unchanged from 0001596532-19-000184:notes:8]

[0001596532-19-000230:notes:9]
[same as prior period, unchanged from 0001596532-19-000184:notes:9]

[0001596532-19-000230:notes:10]
Effective January 1, 2019, we adopted Accounting Standard Codification (“ASC”) 842 - Leases, as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1. As a result, we added a new significant accounting policy “Leases” as described below. There have been no other significant changes to our accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2018, filed with the SEC on February 15, 2019.

[0001596532-19-000230:notes:11]
[same as prior period, unchanged from 0001596532-19-000184:notes:11]

[0001596532-19-000230:notes:12]
[same as prior period, unchanged from 0001596532-19-000184:notes:12]

[0001596532-19-000230:notes:13]
[same as prior period, unchanged from 0001596532-19-000184:notes:13]

[0001596532-19-000230:notes:14]
[same as prior period, unchanged from 0001596532-19-000184:notes:14]

[0001596532-19-000230:notes:15]
[same as prior period, unchanged from 0001596532-19-000184:notes:15]

[0001596532-19-000230:notes:16]
Recently Adopted Accounting Pronouncements

[0001596532-19-000230:notes:17]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) No. 2016-02, Leases (“ASU 2016-02”), and in July 2018, the FASB issued ASU 2018-11, Leases (Topic 842): Targeted Improvements (“ASU 2018-11”) (collectively referred to as “ASC 842”). Under the guidance, lessees are required to recognize assets and lease liabilities on the balance sheet for most leases including operating leases and provide enhanced disclosures. Companies are required to adopt this guidance using a modified retrospective approach and apply the transition provisions under the guidance at either 1) the later of the beginning of the earliest comparative period presented in the financial statements and the commencement date of the lease, or 2) the beginning of the period of adoption (i.e. on the effective date). Under the transition method using the second application date, a company initially applies the new leases standard at the adoption date and recognizes a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption.

[0001596532-19-000230:notes:18]
[same as prior period, unchanged from 0001596532-19-000184:notes:18]

[0001596532-19-000230:notes:19]
[same as prior period, unchanged from 0001596532-19-000184:notes:19]

[0001596532-19-000230:notes:20]
[same as prior period, unchanged from 0001596532-19-000184:notes:20]

[0001596532-19-000230:notes:21]
[same as prior period, unchanged from 0001596532-19-000184:notes:21]

[0001596532-19-000230:notes:22]
[same as prior period, unchanged from 0001596532-19-000184:notes:22]

[0001596532-19-000230:notes:23]
[same as prior period, unchanged from 0001596532-19-000184:notes:23]

[0001596532-19-000230:notes:24]
[same as prior period, unchanged from 0001596532-19-000184:notes:24]

[0001596532-19-000230:notes:25]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  The proposed standard requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. For trade receivables, we will be required to estimate lifetime expected credit losses. For available-for-sale debt securities, we will be required to recognize an allowance for credit losses rather than a reduction to the carrying value of the asset. In May 2019, the FASB issued ASU 2019-05, Financial Instruments—Credit Losses, Topic 326, which allows companies to make an irrevocable one-time election upon adoption of ASU 2016-13 to elect the fair value option for certain financial assets currently measured at amortized cost (except held-to-maturity securities). The election is to be applied on an instrument-by-instrument basis. ASU 2016-13 is effective for us for our first quarter of 2020. We are currently assessing the impact this guidance may have on our consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-19-000230:notes:26]
[same as prior period, unchanged from 0001596532-19-000184:notes:26]

[0001596532-19-000230:notes:27]
[same as prior period, unchanged from 0001596532-19-000184:notes:27]

[0001596532-19-000230:notes:28]
The total fair value of consideration transferred for these acquisitions was $118.7 million, which consisted of $103.1 million in cash and $15.6 million for the fair value of 58,072 shares of our common stock issued. The following table summarizes our final purchase price allocation of the two acquisitions, in aggregate, based on the estimated fair value of the assets acquired and liabilities assumed at their respective acquisition dates (in thousands):

[0001596532-19-000230:notes:29]
|  |  | Purchase Price Allocation |
| Cash and cash equivalents |  | $ | 4,953 |  |
| Other tangible assets |  | 23,872 |  |
| Liabilities |  | (28,707 | ) |
| Intangible assets |  | 63,720 |  |
| Goodwill |  | 54,855 |  |
| Net assets acquired |  | $ | 118,693 |  |

[0001596532-19-000230:notes:30]
[same as prior period, unchanged from 0001596532-19-000184:notes:31]

[0001596532-19-000230:notes:31]
[same as prior period, unchanged from 0001596532-19-000184:notes:32]

[0001596532-19-000230:notes:32]
Goodwill of $54.9 million is primarily attributable to the expected synergies created by incorporating the solutions of the acquired businesses into our technology platform, and the value of the assembled workforce. We operate under a single reportable segment. The goodwill is not deductible for income taxes purposes.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-19-000230:notes:33]
[same as prior period, unchanged from 0001596532-19-000184:notes:34]

[0001596532-19-000230:notes:34]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying condensed consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value. We use a fair

[0001596532-19-000230:notes:35]
value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs. The three-tiers of the fair value hierarchy are as follows:

[0001596532-19-000230:notes:36]
[same as prior period, unchanged from 0001596532-19-000184:notes:36]

[0001596532-19-000230:notes:37]
[same as prior period, unchanged from 0001596532-19-000184:notes:37]

[0001596532-19-000230:notes:38]
[same as prior period, unchanged from 0001596532-19-000184:notes:38]

[0001596532-19-000230:notes:39]
[same as prior period, unchanged from 0001596532-19-000184:notes:39]

[0001596532-19-000230:notes:40]
|  |  | September 30, 2019 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 647,064 |  |  | $ | — |  |  | $ | — |  |  | $ | 647,064 |  |  | $ | 647,064 |  |  | $ | — |  |  | $ | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | 661,704 |  |  | 3,109 |  |  | (69 | ) |  | 664,744 |  |  | — |  |  | 664,744 |  |  | — |  |
| U.S. government notes |  | 368,410 |  |  | 633 |  |  | (3 | ) |  | 369,040 |  |  | 369,040 |  |  | — |  |  | — |  |
| Agency securities |  | 262,534 |  |  | 721 |  |  | (3 | ) |  | 263,252 |  |  | — |  |  | 263,252 |  |  | — |  |
| Commercial paper |  | 51,739 |  |  | — |  |  | — |  |  | 51,739 |  |  | — |  |  | 51,739 |  |  | — |  |
| Certificates of deposits (1) |  | 3,000 |  |  | — |  |  | — |  |  | 3,000 |  |  | — |  |  | 3,000 |  |  | — |  |
|  |  | 1,347,387 |  |  | 4,463 |  |  | (75 | ) |  | 1,351,775 |  |  | 369,040 |  |  | 982,735 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,226 |  |  | — |  |  | — |  |  | 4,226 |  |  | 4,226 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 1,998,677 |  |  | $ | 4,463 |  |  | $ | (75 | ) |  | $ | 2,003,065 |  |  | $ | 1,020,330 |  |  | $ | 982,735 |  |  | $ | — |  |

[0001596532-19-000230:notes:41]
[same as prior period, unchanged from 0001596532-19-000184:notes:41]

[0001596532-19-000230:notes:42]
[same as prior period, unchanged from 0001596532-19-000184:notes:42]

[0001596532-19-000230:notes:43]
(1) As of September 30, 2019 and December 31, 2018, all of our certificates of deposits were domestic deposits.

[0001596532-19-000230:notes:44]
We did not realize any other-than-temporary losses on our marketable securities for the three and nine months ended September 30, 2019 and 2018. As of September 30, 2019 and December 31, 2018, total unrealized losses of our marketable securities that had been in a continuous unrealized loss position were immaterial. We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. As interest rates increase, those marketable securities purchased at a time with lower interest rates show a mark-to-market unrealized loss. We expect to realize the full value of these investments upon maturity or sale and therefore, we do not consider any of our marketable securities to be other-than-temporarily impaired as of September 30, 2019.

[0001596532-19-000230:notes:45]
As of September 30, 2019, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale marketable securities, by remaining contractual maturity, are as follows (in thousands):

[0001596532-19-000230:notes:46]
|  |  | September 30, 2019 |
| Due in 1 year or less |  | $ | 936,777 |  |
| Due in 1 year through 2 years |  | 414,998 |  |
| Total marketable securities |  | $ | 1,351,775 |  |

[0001596532-19-000230:notes:47]
The weighted-average remaining duration of our current marketable securities is approximately 0.7 years as of September 30, 2019.  As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying unaudited condensed consolidated balance sheets.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-19-000230:notes:48]
[same as prior period, unchanged from 0001596532-19-000184:notes:48]

[0001596532-19-000230:notes:49]
[same as prior period, unchanged from 0001596532-19-000184:notes:49]

[0001596532-19-000230:notes:50]
[same as prior period, unchanged from 0001596532-19-000184:notes:50]

[0001596532-19-000230:notes:51]
|  |  | September 30, 2019 |  | September 30, 2018 |
| Cash and cash equivalents |  | $ | 1,095,265 |  |  | $ | 524,687 |  |
| Restricted cash included in other assets |  | 4,226 |  |  | 4,210 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 1,099,491 |  |  | $ | 528,897 |  |

[0001596532-19-000230:notes:52]
Restricted cash included in other assets as of September 30, 2019 and September 30, 2018 primarily included $4.0 million pledged as collateral representing a security deposit required for a facility lease.

[0001596532-19-000230:notes:53]
[same as prior period, unchanged from 0001596532-19-000184:notes:53]

[0001596532-19-000230:notes:54]
[same as prior period, unchanged from 0001596532-19-000184:notes:54]

[0001596532-19-000230:notes:55]
|  |  | September 30, 2019 |  | December 31, 2018 |
| Accounts receivable |  | $ | 453,963 |  |  | $ | 340,897 |  |
| Allowance for doubtful accounts |  | (852 | ) |  | (507 | ) |
| Product sales rebate and returns reserve |  | (5,859 | ) |  | (8,613 | ) |
| Accounts receivable, net |  | $ | 447,252 |  |  | $ | 331,777 |  |

[0001596532-19-000230:notes:56]
[same as prior period, unchanged from 0001596532-19-000184:notes:56]

[0001596532-19-000230:notes:57]
[same as prior period, unchanged from 0001596532-19-000184:notes:57]

[0001596532-19-000230:notes:58]
|  |  | September 30, 2019 |  | December 31, 2018 |
| Raw materials |  | $ | 120,236 |  |  | $ | 76,795 |  |
| Finished goods |  | 119,566 |  |  | 187,762 |  |
| Total inventories |  | $ | 239,802 |  |  | $ | 264,557 |  |

[0001596532-19-000230:notes:59]
[same as prior period, unchanged from 0001596532-19-000184:notes:59]

[0001596532-19-000230:notes:60]
[same as prior period, unchanged from 0001596532-19-000184:notes:60]

[0001596532-19-000230:notes:61]
|  |  | September 30, 2019 |  | December 31, 2018 |
| Prepaid income taxes |  | $ | 25,643 |  |  | $ | 38,636 |  |
| Inventory deposit |  | 15,090 |  |  | 14,639 |  |
| Other current assets |  | 52,800 |  |  | 95,730 |  |
| Other prepaid expenses and deposits |  | 12,793 |  |  | 13,316 |  |
| Total prepaid expenses and other current assets |  | $ | 106,326 |  |  | $ | 162,321 |  |

[0001596532-19-000230:notes:62]
[same as prior period, unchanged from 0001596532-19-000184:notes:62]

[0001596532-19-000230:notes:63]
[same as prior period, unchanged from 0001596532-19-000184:notes:63]

[0001596532-19-000230:notes:64]
|  |  | September 30, 2019 |  | December 31, 2018 |
| Equipment and machinery |  | $ | 62,233 |  |  | $ | 55,912 |  |
| Computer hardware and software |  | 35,409 |  |  | 30,566 |  |
| Leasehold improvements |  | 31,335 |  |  | 36,447 |  |
| Furniture and fixtures |  | 3,734 |  |  | 3,697 |  |
| Building |  | — |  |  | 35,154 |  |
| Construction-in-process |  | 140 |  |  | 3,591 |  |
| Property and equipment, gross |  | 132,851 |  |  | 165,367 |  |
| Less: accumulated depreciation |  | (92,663 | ) |  | (90,012 | ) |
| Property and equipment, net |  | $ | 40,188 |  |  | $ | 75,355 |  |

[0001596532-19-000230:notes:65]
[same as prior period, unchanged from 0001596532-19-000184:notes:65]

[0001596532-19-000230:notes:66]
Depreciation expense was $4.8 million and $5.4 million for the three months ended September 30, 2019 and 2018, respectively, and $14.3 million and $16.0 million for the nine months ended September 30, 2019 and 2018, respectively.

[0001596532-19-000230:notes:67]
[same as prior period, unchanged from 0001596532-19-000184:notes:67]

[0001596532-19-000230:notes:68]
[same as prior period, unchanged from 0001596532-19-000184:notes:68]

[0001596532-19-000230:notes:69]
|  |  | September 30, 2019 |  | December 31, 2018 |
| Accrued payroll related costs |  | $ | 69,522 |  |  | $ | 70,755 |  |
| Accrued manufacturing costs |  | 25,407 |  |  | 31,336 |  |
| Accrued product development costs |  | 17,534 |  |  | 6,988 |  |
| Accrued professional fees |  | 7,335 |  |  | 5,678 |  |
| Accrued warranty costs |  | 5,408 |  |  | 5,362 |  |
| Other |  | 3,724 |  |  | 3,135 |  |
| Total accrued liabilities |  | $ | 128,930 |  |  | $ | 123,254 |  |

[0001596532-19-000230:notes:70]
[same as prior period, unchanged from 0001596532-19-000184:notes:70]

[0001596532-19-000230:notes:71]
[same as prior period, unchanged from 0001596532-19-000184:notes:71]

[0001596532-19-000230:notes:72]
|  |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |
| Warranty accrual, beginning of period |  | $ | 5,362 |  |  | $ | 7,415 |  |
| Liabilities accrued for warranties issued during the period |  | 3,887 |  |  | 6,898 |  |
| Warranty costs incurred during the period |  | (3,841 | ) |  | (4,198 | ) |
| Warranty accrual, end of period |  | $ | 5,408 |  |  | $ | 10,115 |  |

[0001596532-19-000230:notes:73]
[same as prior period, unchanged from 0001596532-19-000184:notes:73]

[0001596532-19-000230:notes:74]
[same as prior period, unchanged from 0001596532-19-000184:notes:74]

[0001596532-19-000230:notes:75]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Contract assets, beginning balance |  | $ | 1,668 |  |  | $ | 6,959 |  |  | $ | 6,341 |  |  | $ | — |  |
| Contract assets, ending balance |  | 14,482 |  |  | 9,417 |  |  | 14,482 |  |  | 9,417 |  |

[0001596532-19-000230:notes:76]
[same as prior period, unchanged from 0001596532-19-000184:notes:76]

[0001596532-19-000230:notes:77]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Contract liabilities, beginning balance |  | $ | 42,026 |  |  | $ | 21,842 |  |  | $ | 32,595 |  |  | $ | 16,521 |  |
| Less: Revenue recognized from beginning balance |  | (3,700 | ) |  | (2,157 | ) |  | (10,134 | ) |  | (6,107 | ) |
| Less: Beginning balance reclassified to deferred revenue |  | (1,689 | ) |  | (970 | ) |  | (967 | ) |  | (521 | ) |
| Add: Contract liabilities recognized |  | 13,506 |  |  | 6,580 |  |  | 28,649 |  |  | 15,402 |  |
| Contract liabilities, ending balance |  | $ | 50,143 |  |  | $ | 25,295 |  |  | $ | 50,143 |  |  | $ | 25,295 |  |

[0001596532-19-000230:notes:78]
As of September 30, 2019 and December 31, 2018, $19.6 million and $13.5 million of our contract liabilities, respectively, was included in “Other current liabilities” with the remaining balances included in “Other long-term liabilities”.

[0001596532-19-000230:notes:79]
[same as prior period, unchanged from 0001596532-19-000184:notes:79]

[0001596532-19-000230:notes:80]
[same as prior period, unchanged from 0001596532-19-000184:notes:80]

[0001596532-19-000230:notes:81]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Deferred revenue, beginning balance (1) |  | $ | 502,218 |  |  | $ | 448,644 |  |  | $ | 587,227 |  |  | $ | 498,740 |  |
| Less: Revenue recognized from beginning balance |  | (84,277 | ) |  | (97,995 | ) |  | (306,909 | ) |  | (306,350 | ) |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 111,071 |  |  | 179,206 |  |  | 248,694 |  |  | 337,465 |  |
| Deferred revenue, ending balance |  | $ | 529,012 |  |  | $ | 529,855 |  |  | $ | 529,012 |  |  | $ | 529,855 |  |
| ______________________ |  |  |  |  |  |  |  |  |
| (1) The beginning balance of the nine months ended September 30, 2018 excludes $16.5 million that was reclassified to other current liabilities and other long-term liabilities at January 1, 2018 as a result of our adoption of ASC 606. |

[0001596532-19-000230:notes:82]
[same as prior period, unchanged from 0001596532-19-000184:notes:82]

[0001596532-19-000230:notes:83]
Revenue from remaining performance obligations represents contracted revenue that has not yet been recognized, which includes contract liabilities and deferred revenue that will be recognized as revenue in future periods. As of September 30, 2019, approximately $610.2 million of revenue is expected to be recognized from remaining performance obligations. We expect to

[0001596532-19-000230:notes:84]
recognize revenue on approximately 80% of these remaining performance obligations over the next two years and 20% during the third to the fifth year.

[0001596532-19-000230:notes:85]
[same as prior period, unchanged from 0001596532-19-000184:notes:84]

[0001596532-19-000230:notes:86]
[same as prior period, unchanged from 0001596532-19-000184:notes:85]

[0001596532-19-000230:notes:87]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Interest income |  | $ | 13,446 |  |  | $ | 8,585 |  |  | $ | 38,451 |  |  | $ | 21,933 |  |
| Interest expense |  | — |  |  | (673 | ) |  | — |  |  | (2,040 | ) |
| Gain (loss) on investment in privately-held companies |  | 4,277 |  |  | — |  |  | 5,427 |  |  | (9,100 | ) |
| Other income (expense), net |  | 1,446 |  |  | 707 |  |  | 1,435 |  |  | (187 | ) |
| Total |  | $ | 19,169 |  |  | $ | 8,619 |  |  | $ | 45,313 |  |  | $ | 10,606 |  |

[0001596532-19-000230:notes:88]
Upon the adoption of ASC 842 on January 1, 2019, we derecognized the lease financing obligation associated with a build-to-suit lease, and therefore did not incur interest expense in the three and nine months ended September 30, 2019. See Note 1 for further details.


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-19-000230:notes:89]
[same as prior period, unchanged from 0001596532-19-000184:notes:88]

[0001596532-19-000230:notes:90]
[same as prior period, unchanged from 0001596532-19-000184:notes:89]

[0001596532-19-000230:notes:91]
Our investments are in the equity of privately-held companies, which do not have readily determinable fair values. These non-marketable equity securities are initially recorded at cost, and subsequently remeasured to fair value on a non-recurring basis based on observable price changes in orderly transactions for similar investments of the same issuer, or for impairment. These investments are classified within Level III of the fair value hierarchy as we estimate the value based on valuation methods using the observable transaction price at the transaction date and other significant unobservable inputs, such as volatility, rights, and obligations related to those investments. In addition, the valuation requires management judgment due to the absence of market price and inherent lack of liquidity. The following table summarizes the activity related to our investments in privately-held companies held as of September 30, 2019 and December 31, 2018 (in thousands):

[0001596532-19-000230:notes:92]
|  |  | September 30, 2019 |  | December 31, 2018 |
| Cost of investment |  | $ | 18,000 |  |  | $ | 44,136 |  |
| Cumulative impairment |  | (15,000 | ) |  | (15,000 | ) |
| Cumulative upward adjustment |  | 1,150 |  |  | 1,200 |  |
| Carrying amount of investment |  | $ | 4,150 |  |  | $ | 30,336 |  |

[0001596532-19-000230:notes:93]
During the three months ended September 30, 2019, the Company recorded a realized gain of $4.3 million upon the sale of one of our investments. The realized gains are classified in "Other income (expense), net" in our accompanying unaudited condensed consolidated statements of operations.

[0001596532-19-000230:notes:94]
During the three months ended September 30, 2019 and September 30, 2018, there were no unrealized gains or losses recorded on our remaining investments. In each of the nine month periods ended September 30, 2019 and September 30, 2018, we recorded $1.2 million of unrealized gains.  These unrealized gains were recorded on investments that were re-measured to fair value as of the date observable transactions occurred. In addition, during the nine months ended September 30, 2018, we recorded an impairment of $10.3 million on one of our investments. These unrealized gains and losses are classified in "Other income (expense), net" in our accompanying unaudited condensed consolidated statements of operations.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001596532-19-000230:notes:95]
Leases
Operating Leases

[0001596532-19-000230:notes:96]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2028. Some of our leases include options to extend the term of such leases for a period from three months to up to 10 years and/or options to early terminate the leases. As of September 30, 2019, we did not include any such options in determining the lease terms because we were not reasonably certain that we would exercise those

[0001596532-19-000230:notes:97]
options. Most of our leases require us to pay certain operating expenses in addition to base rent, such as taxes, repairs, and insurance, and contain renewal and escalation clauses.

[0001596532-19-000230:notes:98]
[same as prior period, unchanged from 0001596532-19-000184:notes:97]

[0001596532-19-000230:notes:99]
[same as prior period, unchanged from 0001596532-19-000184:notes:98]

[0001596532-19-000230:notes:100]
[same as prior period, unchanged from 0001596532-19-000184:notes:99]

[0001596532-19-000230:notes:101]
The following table summarizes the supplemental balance sheet information related to our operating leases as of September 30, 2019 (in thousands).

[0001596532-19-000230:notes:102]
|  |  | Financial Statement Classification |  | September 30, 2019 |
| Right-of-use assets: |  |  |  |  |
| Operating lease right-of-use assets |  | Operating lease right-of-use assets |  | $ | 91,903 |  |
| Lease liabilities: |  |  |  |  |
| Operating lease liabilities, current |  | Other current liabilities |  | 15,545 |  |
| Operating lease liabilities, non-current |  | Operating lease liabilities, non-current |  | 87,099 |  |
| Total operating lease liabilities |  |  |  | $ | 102,644 |  |

[0001596532-19-000230:notes:103]
The following table summarizes our lease costs for the three and nine months ended September 30, 2019 (in thousands).

[0001596532-19-000230:notes:104]
|  |  | Financial Statement Classification |  | Three Months Ended September 30, 2019 |  | Nine Months Ended September 30, 2019 |
| Operating lease costs: |  |  |  |  |  |  |
| Fixed lease costs |  | Operating expenses |  | $ | 5,800 |  |  | $ | 16,898 |  |
| Variable lease costs |  | Operating expenses |  | 1,534 |  |  | 4,529 |  |
| Total operating lease costs |  |  |  | $ | 7,334 |  |  | $ | 21,427 |  |

[0001596532-19-000230:notes:105]
The operating lease costs in the table above include costs for long-term leases and short-term leases. Total short-term lease costs were immaterial. Fixed lease costs include expenses recognized for base rent payments on a straight-lined basis. Variable lease costs primarily include maintenance, utilities and operating expenses that are incremental to the fixed base rent payments, and are excluded from the calculation of operating lease liabilities and ROU assets.  For the three and nine months ended September 30, 2019, cash paid for amounts associated with our operating lease liabilities were approximately $4.7 million and $13.6 million, respectively, which were classified as operating activities in the condensed consolidated statements of cash flows.

[0001596532-19-000230:notes:106]
Prior to 2019, we recognized rent expense for our operating leases under the legacy guidance ASC 840. For the three and nine months ended September 30, 2018, rent expense for all operating leases amounted to $3.1 million and $8.9 million, respectively, and did not include maintenance, utilities and other operating expenses in accordance with ASC 840.

[0001596532-19-000230:notes:107]
The following table shows our undiscounted future fixed payment obligations under our recognized operating leases and a reconciliation to the operating lease liabilities as of September 30, 2019 (in thousands).

[0001596532-19-000230:notes:108]
|  |  | September 30, 2019 |
| Remainder of 2019 |  | $ | 4,932 |  |
| 2020 |  | 20,510 |  |
| 2021 |  | 21,271 |  |
| 2022 |  | 21,470 |  |
| 2023 |  | 17,694 |  |
| 2024 and thereafter |  | 36,008 |  |
| Total future fixed operating lease payments |  | 121,885 |  |
| Less: |  |  |
| Imputed interest |  | (19,241 | ) |
| Total operating lease liabilities |  | $ | 102,644 |  |

[0001596532-19-000230:notes:109]
|  |  | September 30, 2019 |
| Weighted-average remaining lease term — operating leases |  | 6.0 years |
| Weighted-average discount rate — operating leases |  | 5.1% |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-19-000230:notes:110]
7.    Commitments and Contingencies

[0001596532-19-000230:notes:111]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2028. See Note 6 for our future minimum payment obligations under our leases as of September 30, 2019.

[0001596532-19-000230:notes:112]
Purchase Commitments

[0001596532-19-000230:notes:113]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2019, we had non-cancellable purchase commitments of $222.4 million, of which $209.6 million was to our contract manufacturers and suppliers. In addition, we have provided deposits to secure our obligations to purchase inventory. We had $17.8 million and $17.4 million in deposits as of September 30, 2019 and December 31, 2018, respectively. These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.

[0001596532-19-000230:notes:114]
Guarantees

[0001596532-19-000230:notes:115]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-19-000230:notes:116]
Legal Proceedings

[0001596532-19-000230:notes:117]
OptumSoft, Inc. Matters

[0001596532-19-000230:notes:118]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies; and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of

[0001596532-19-000230:notes:119]
the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-19-000230:notes:120]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft access to our software for evaluation by OptumSoft; (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches; (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers; (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us; and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors, who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dated July 28, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.

[0001596532-19-000230:notes:121]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we asserted our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we asserted that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We asked the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also asserted that, even if we are found not to own certain components, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation. On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have meritorious defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-19-000230:notes:122]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial were set to be tried in Phase II, including the application of the Court’s interpretation of the 2004 agreement to any other source code that OptumSoft claims to own and the trade secret misappropriation and confidentiality claims.

[0001596532-19-000230:notes:123]
On September 24, 2019, the Company and OptumSoft entered into a settlement agreement resolving all the issues that were set to be tried in Phase II of the litigation. Under the settlement agreement, OptumSoft may still pursue its appeal of the Court’s Final Statement of Decision Following Phase I Trial, and pursue any further litigation that may result, but has granted the Company a release on all other outstanding claims.

[0001596532-19-000230:notes:124]
We intend to vigorously defend against any claims brought against us by OptumSoft.  However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor.  For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft.  If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license.  An adverse litigation ruling could result in a significant damages award against us and injunctive relief. In addition, OptumSoft could assert additional or different claims against us, including claims that our license from OptumSoft is invalid.

[0001596532-19-000230:notes:125]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated.  However, the outcome of litigation is inherently uncertain. Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-19-000230:notes:126]
GlobalFoundries Litigation

[0001596532-19-000230:notes:127]
On August 26, 2019, GlobalFoundries U.S. Inc. (“GlobalFoundries”) filed complaints in the International Trade Commission and federal court against TSMC and numerous companies that sell products incorporating semiconductor devices manufactured by TSMC, including Arista, Broadcom, NVIDIA, Apple, Asus, Cisco, and Lenovo. The complaints allege that these semiconductor devices infringe four GlobalFoundries patents relating to semiconductor manufacturing techniques. In our case, GlobalFoundries has accused the merchant silicon we purchase from Broadcom of infringement. On October 28, 2019, TSMC and GlobalFoundries entered into a cross-license agreement to settle the litigation.

[0001596532-19-000230:notes:128]
Other Matters

[0001596532-19-000230:notes:129]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-19-000230:notes:130]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2019, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-19-000230:notes:131]
[same as prior period, unchanged from 0001596532-19-000184:notes:128]

[0001596532-19-000230:notes:132]
[same as prior period, unchanged from 0001596532-19-000184:notes:129]

[0001596532-19-000230:notes:133]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the “Repurchase Program”).  This authorization allows us to repurchase shares of our common stock opportunistically and will be funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), or a combination of the foregoing. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of September 30, 2019, the remaining authorized amount for stock repurchases under this program was approximately $785.4 million.

[0001596532-19-000230:notes:134]
A summary of the stock repurchase activity under the Repurchase Program for the three and nine months ended September 30, 2019 is as follows (in thousands, except per share amounts):

[0001596532-19-000230:notes:135]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | September 30, 2019 |  | September 30, 2019 |
| Aggregate purchase price |  | $ | 114,609 |  |  | $ | 214,617 |  |
| Shares repurchased |  | 512 |  |  | 919 |  |
| Average price paid per share |  | $ | 223.99 |  |  | $ | 233.72 |  |

[0001596532-19-000230:notes:136]
[same as prior period, unchanged from 0001596532-19-000184:notes:133]

[0001596532-19-000230:notes:137]
[same as prior period, unchanged from 0001596532-19-000184:notes:134]

[0001596532-19-000230:notes:138]
[same as prior period, unchanged from 0001596532-19-000184:notes:135]

[0001596532-19-000230:notes:139]
Effective January 1, 2019, our board of directors authorized an increase of 756,679 shares to the shares available for issuance under our 2014 Employee Stock Purchase Plan (the “ESPP”).  Pursuant to the ESPP, the 2019 share increase was determined based on the lesser of 1% of the total shares of common stock outstanding on December 31, 2018, 2,500,000 shares, or such amount as determined by our board of directors. During the three and nine months ended September 30, 2019, we issued 51,600 and  97,343 shares at a weighted-average purchase price of $179.73 and $184.70 per share, respectively, under the ESPP. As of September 30, 2019, there remained 3,192,774 shares available for issuance under the ESPP.

[0001596532-19-000230:notes:140]
[same as prior period, unchanged from 0001596532-19-000184:notes:137]

[0001596532-19-000230:notes:141]
[same as prior period, unchanged from 0001596532-19-000184:notes:138]

[0001596532-19-000230:notes:142]
|  |  | Options Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding |
| Balance—December 31, 2018 |  | 5,899 |  |  | $ | 37.09 |  |  | 5.2 |  | $ | 1,027,741 |  |
| Options granted |  | 76 |  |  | 226.53 |  |  |  |  |  |
| Options exercised |  | (1,164 | ) |  | 29.37 |  |  |  |  |  |
| Options canceled |  | (64 | ) |  | 37.08 |  |  |  |  |  |
| Balance—September 30, 2019 |  | 4,747 |  |  | $ | 42.02 |  |  | 4.6 |  | $ | 935,350 |  |
| Vested and exercisable—September 30, 2019 |  | 2,700 |  |  | $ | 27.53 |  |  | 4.1 |  | $ | 570,690 |  |

[0001596532-19-000230:notes:143]
[same as prior period, unchanged from 0001596532-19-000184:notes:140]

[0001596532-19-000230:notes:144]
[same as prior period, unchanged from 0001596532-19-000184:notes:141]

[0001596532-19-000230:notes:145]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2018 |  | 1,308 |  |  | $ | 150.60 |  |  | 1.5 |  | $ | 275,638 |  |
| RSUs granted |  | 325 |  |  | 245.29 |  |  |  |  |  |
| RSUs vested |  | (386 | ) |  | 121.02 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (64 | ) |  | 179.78 |  |  |  |  |  |
| Unvested balance—September 30, 2019 |  | 1,183 |  |  | $ | 184.64 |  |  | 1.6 |  | $ | 282,612 |  |

[0001596532-19-000230:notes:146]
[same as prior period, unchanged from 0001596532-19-000184:notes:143]

[0001596532-19-000230:notes:147]
The following table presents the stock activity and the total number of shares available for grant under the 2014 Plan as of September 30, 2019 (in thousands):

[0001596532-19-000230:notes:148]
|  |  | Number of Shares |
| Balance—December 31, 2018 |  | 15,386 |  |
| Options granted |  | (76 | ) |
| RSUs granted |  | (325 | ) |
| Options canceled |  | 64 |  |
| RSUs forfeited |  | 64 |  |
| Shares traded for taxes |  | 29 |  |
| Balance—September 30, 2019 |  | 15,142 |  |

[0001596532-19-000230:notes:149]
[same as prior period, unchanged from 0001596532-19-000184:notes:146]

[0001596532-19-000230:notes:150]
[same as prior period, unchanged from 0001596532-19-000184:notes:147]

[0001596532-19-000230:notes:151]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Cost of revenue |  | $ | 1,258 |  |  | $ | 1,268 |  |  | $ | 3,384 |  |  | $ | 3,706 |  |
| Research and development |  | 13,472 |  |  | 12,010 |  |  | 39,171 |  |  | 34,700 |  |
| Sales and marketing |  | 7,832 |  |  | 6,537 |  |  | 21,463 |  |  | 18,771 |  |
| General and administrative |  | 3,695 |  |  | 3,439 |  |  | 10,827 |  |  | 9,406 |  |
| Total stock-based compensation |  | $ | 26,257 |  |  | $ | 23,254 |  |  | $ | 74,845 |  |  | $ | 66,583 |  |

[0001596532-19-000230:notes:152]
As of September 30, 2019, unrecognized stock-based compensation expenses by award type and their expected weighted-average recognition periods are summarized in the following table (in thousands, except years).

[0001596532-19-000230:notes:153]
|  |  | September 30, 2019 |
|  |  | Stock Option |  | RSU |  | ESPP |  | Restricted Stock |
| Unrecognized stock-based compensation expense |  | $ | 48,448 |  |  | $ | 194,942 |  |  | $ | 12,619 |  |  | $ | 4,298 |  |
| Weighted-average amortization period |  | 3.5 years |  |  | 3.3 years |  |  | 1.3 years |  |  | 3.0 years |  |


## us-gaap:EarningsPerShareTextBlock

[0001596532-19-000230:notes:154]
[same as prior period, unchanged from 0001596532-19-000184:notes:151]

[0001596532-19-000230:notes:155]
[same as prior period, unchanged from 0001596532-19-000184:notes:152]

[0001596532-19-000230:notes:156]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Numerator: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 208,895 |  |  | $ | 168,524 |  |  | $ | 599,175 |  |  | $ | 157,793 |  |
| Less: undistributed earnings allocated to participating securities |  | (96 | ) |  | (85 | ) |  | (314 | ) |  | (87 | ) |
| Net income available to common stockholders, basic |  | $ | 208,799 |  |  | $ | 168,439 |  |  | $ | 598,861 |  |  | $ | 157,706 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Net income attributable to common stockholders, basic |  | $ | 208,799 |  |  | $ | 168,439 |  |  | $ | 598,861 |  |  | $ | 157,706 |  |
| Add: undistributed earnings allocated to participating securities |  | 5 |  |  | 6 |  |  | 19 |  |  | 7 |  |
| Net income attributable to common stockholders, diluted |  | $ | 208,804 |  |  | $ | 168,445 |  |  | $ | 598,880 |  |  | $ | 157,713 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 76,426 |  |  | 75,011 |  |  | 76,301 |  |  | 74,506 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 76,426 |  |  | 75,011 |  |  | 76,301 |  |  | 74,506 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Stock options and RSUs |  | 4,308 |  |  | 5,967 |  |  | 4,784 |  |  | 6,298 |  |
| Employee stock purchase plan |  | 19 |  |  | 40 |  |  | 19 |  |  | 40 |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted |  | 80,753 |  |  | 81,018 |  |  | 81,104 |  |  | 80,844 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.73 |  |  | $ | 2.25 |  |  | $ | 7.85 |  |  | $ | 2.12 |  |
| Diluted |  | $ | 2.59 |  |  | $ | 2.08 |  |  | $ | 7.38 |  |  | $ | 1.95 |  |

[0001596532-19-000230:notes:157]
[same as prior period, unchanged from 0001596532-19-000184:notes:154]

[0001596532-19-000230:notes:158]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Stock options and RSUs to purchase common stock |  | 277 |  |  | 82 |  |  | 211 |  |  | 87 |  |
| Employee stock purchase plan |  | 41 |  |  | 98 |  |  | 59 |  |  | 59 |  |
| Total |  | 318 |  |  | 180 |  |  | 270 |  |  | 146 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-19-000230:notes:159]
[same as prior period, unchanged from 0001596532-19-000184:notes:156]

[0001596532-19-000230:notes:160]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Income before income taxes |  | $ | 247,775 |  |  | $ | 189,389 |  |  | $ | 675,098 |  |  | $ | 90,311 |  |
| Provision for (benefit from) income taxes |  | 38,880 |  |  | 20,865 |  |  | $ | 75,923 |  |  | $ | (67,482 | ) |
| Effective tax rate |  | 15.7 | % |  | 11.0 | % |  | 11.2 | % |  | (74.7 | )% |

[0001596532-19-000230:notes:161]
The change in the effective tax rate in the nine months ended September 30, 2019, as compared to the same period in 2018, was a result of the significant benefit on the $405 million charge related to the settlement of our litigation with Cisco recorded in the nine months ended September 30, 2018.  In addition, the increase in the effective tax rate in the three months and nine months ended September 30, 2019, as compared to the same periods in 2018, was due to the overall increase in worldwide earnings, which proportionally exceeded the increase in excess tax benefits attributable to equity compensation.
On June 7, 2019, the Court of Appeals for the Ninth Circuit issued an opinion on Altera Corporation and Subsidiaries vs. Commissioner on Internal Revenue (“Opinion”). The Opinion overturned the Tax Court decision and ruled in favor of the Commissioner validating the regulations requiring stock-based compensation to be included in a cost sharing arrangement (the “Regulations”). As a result of the Opinion, we have changed our position and determined it is more likely than not that the Regulations are valid. As such, we have accounted for the impact of the decision in the nine months ended September 30, 2019 resulting in a discrete income tax expense of $9.8 million.  Further, the estimated annual effective tax rate for the year ending December 31, 2019 includes the estimated impact of sharing stock-based compensation within our cost sharing arrangement.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-19-000230:notes:162]
[same as prior period, unchanged from 0001596532-19-000184:notes:159]

[0001596532-19-000230:notes:163]
[same as prior period, unchanged from 0001596532-19-000184:notes:160]

[0001596532-19-000230:notes:164]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Americas |  | $ | 532,318 |  |  | $ | 406,666 |  |  | $ | 1,418,325 |  |  | $ | 1,099,624 |  |
| Europe, Middle East and Africa |  | 75,439 |  |  | 92,911 |  |  | 298,768 |  |  | 316,608 |  |
| Asia-Pacific |  | 46,658 |  |  | 63,732 |  |  | 141,067 |  |  | 139,411 |  |
| Total revenue |  | $ | 654,415 |  |  | $ | 563,309 |  |  | $ | 1,858,160 |  |  | $ | 1,555,643 |  |

[0001596532-19-000230:notes:165]
[same as prior period, unchanged from 0001596532-19-000184:notes:162]

[0001596532-19-000230:notes:166]
|  |  | September 30, 2019 |  | December 31, 2018 |
| United States |  | $ | 34,225 |  |  | $ | 69,238 |  |
| International |  | 5,963 |  |  | 6,117 |  |
| Total |  | $ | 40,188 |  |  | $ | 75,355 |  |
