# ANET 8-K — 0001596532-19-000227 filed 2019-10-31

## item codes, every 8-K on or before 2019-11-01

- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2019-11-01

- none on or before 2019-11-01

## item 2.02 — earnings release, exhibit 99.1

[0001596532-19-000227:8k_2_02:1]
EX-99.1
2
ex991q319-earningsrele.htm
EXHIBIT 99.1

[0001596532-19-000227:8k_2_02:2]
Exhibit

[0001596532-19-000227:8k_2_02:3]
Exhibit 99.1

[0001596532-19-000227:8k_2_02:4]
Arista Networks, Inc. Reports Third Quarter 2019 Financial Results

[0001596532-19-000227:8k_2_02:5]
SANTA CLARA, Calif.- October 31, 2019 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large datacenter and campus environments, today announced financial results for its third quarter ended September 30, 2019.

[0001596532-19-000227:8k_2_02:6]
Third Quarter Financial Highlights

[0001596532-19-000227:8k_2_02:7]
| • | Revenue of $654.4 million, an increase of 7.6% compared to the second quarter of 2019, and an increase of 16.2% from the third quarter of 2018. |

[0001596532-19-000227:8k_2_02:8]
| • | GAAP gross margin of 63.8%, compared to GAAP gross margin of 64.1% in the second quarter of 2019 and 64.2% in the third quarter of 2018. |

[0001596532-19-000227:8k_2_02:9]
| • | Non-GAAP gross margin of 64.4%, compared to non-GAAP gross margin of 64.7% in the second quarter of 2019 and 64.6% in the third quarter of 2018. |

[0001596532-19-000227:8k_2_02:10]
| • | GAAP net income of $208.9 million, or $2.59 per diluted share, compared to GAAP net income of $168.5 million, or $2.08 per diluted share in the third quarter of 2018. |

[0001596532-19-000227:8k_2_02:11]
| • | Non-GAAP net income of $217.1 million, or $2.69 per diluted share, compared to non-GAAP net income of $171.3 million, or $2.11 per diluted share in the third quarter of 2018. |

[0001596532-19-000227:8k_2_02:12]
"In Q3 2019 we continued to see the adoption of our cloud networking technology in more diverse environments. While we expect a sudden softening in Q4 with a specific cloud titan customer, we are committed to a sustainable and strong foundation of long-term growth, innovation and profitability,” stated Jayshree Ullal, Arista President and CEO.

[0001596532-19-000227:8k_2_02:13]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, “We saw continued solid business execution in the quarter with strong earnings and cash flow generation.”

[0001596532-19-000227:8k_2_02:14]
Third Quarter Company Highlights

[0001596532-19-000227:8k_2_02:15]
| • | Arista Networks announced CloudVision 2019, building upon Arista’s cognitive management plane. The CloudVision 2019 release brings new capabilities and integrations, helping customers with operational cost reduction, risk management, and agility in network operations. |

[0001596532-19-000227:8k_2_02:16]
| • | This is the fifth consecutive year Arista Networks has been recognized in the Leaders Quadrant of the 2019 Gartner Magic Quadrant for Data Center Networking, published on 15 July 2019. |

[0001596532-19-000227:8k_2_02:17]
| • | Arista Networks announces that it is providing network platforms for SK Telecom’s 5G network. |

[0001596532-19-000227:8k_2_02:18]
| • | Vocus Group, Australia’s specialist fibre and network solutions provider announced Arista Networks has been appointed the supplier of Vocus' Layer 2 and Layer 3 network equipment. |

[0001596532-19-000227:8k_2_02:19]
Financial Outlook

[0001596532-19-000227:8k_2_02:20]
For the fourth quarter of 2019, we expect:

[0001596532-19-000227:8k_2_02:21]
| • | Revenue between $540 million and $560 million; |

[0001596532-19-000227:8k_2_02:22]
| • | Non-GAAP gross margin between 63% to 65%, and |

[0001596532-19-000227:8k_2_02:23]
| • | Non-GAAP operating margin of approximately 36% |

[0001596532-19-000227:8k_2_02:24]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below).

[0001596532-19-000227:8k_2_02:25]
Prepared Materials and Conference Call Information

[0001596532-19-000227:8k_2_02:26]
Arista executives will discuss the third quarter 2019 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (833) 287-7905 in the United States or (647) 689-4469 from outside the US. The Conference ID is 7979217.

[0001596532-19-000227:8k_2_02:27]
The financial results conference call will also be available via live webcast on our investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-19-000227:8k_2_02:28]
Forward-Looking Statements

[0001596532-19-000227:8k_2_02:29]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the fourth quarter of fiscal 2019, and statements regarding the benefits from the introduction of new products and our leadership in cloud area networking. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: the evolution and growth of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; rapid technological and market change; Arista’s customer concentration; changes in Arista's customers’ demand for our products and services; general market, political, economic and business conditions; Arista's rapid growth and our revenue growth rate; Arista's limited operating history; dependence on the introduction and market acceptance of new product offerings and standards including our 400G products as well as our campus and WiFi products; declines in the sales prices of our products and services; our ability to attract new large end customers or sell additional products and services to existing customers; competition in our products and service markets; requests for more favorable terms and conditions from our large end customers; customer order patterns or customer mix; the timing of orders and manufacturing and customer lead times; the benefits and impact of acquisitions; and Arista Networks’ dispute with OptumSoft. Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s most recent Quarterly Report on Form 10-Q filed with the SEC on August 2, 2019, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/.  All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-19-000227:8k_2_02:30]
Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner's research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001596532-19-000227:8k_2_02:31]
Non-GAAP Financial Measures

[0001596532-19-000227:8k_2_02:32]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net

[0001596532-19-000227:8k_2_02:33]
income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, litigation-related expenses, amortization of acquisition-related intangible assets, other non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-19-000227:8k_2_02:34]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-19-000227:8k_2_02:35]
The company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. The company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. A reconciliation of the non-GAAP financial measures guidance to the corresponding GAAP measures on a forward-looking basis is not available because stock-based compensation expense is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-19-000227:8k_2_02:36]
About Arista Networks

[0001596532-19-000227:8k_2_02:37]
Arista Networks pioneered software-driven, cognitive cloud networking for large-scale datacenter and campus environments. Arista’s award-winning platforms redefine and deliver availability, agility, automation, analytics, and security. Arista has shipped more than twenty million cloud networking ports worldwide with CloudVision and EOS, an advanced network operating system. Committed to open standards across private, public and hybrid cloud solutions, Arista products are supported worldwide directly and through partners.

[0001596532-19-000227:8k_2_02:38]
ARISTA, EOS, CloudVision, Cognitive WiFi and AlgoMatch are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-19-000227:8k_2_02:39]
Additional information and resources can be found at: https://www.arista.com.

[0001596532-19-000227:8k_2_02:40]
| Investor Contacts |
| Charles YagerProduct and Investor Advocacy(408) 547-5892cyager@arista.com |  | Chuck ElliottBusiness and Investor Development(408) 547-5549chuck@arista.com |

[0001596532-19-000227:8k_2_02:41]
ARISTA NETWORKS, INC.

[0001596532-19-000227:8k_2_02:42]
Condensed Consolidated Statements of Operations

[0001596532-19-000227:8k_2_02:43]
(Unaudited in thousands, except per share amounts)

[0001596532-19-000227:8k_2_02:44]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 555,066 |  |  | $ | 485,481 |  |  | $ | 1,573,652 |  |  | $ | 1,337,865 |  |
| Service |  | 99,349 |  |  | 77,828 |  |  | 284,508 |  |  | 217,778 |  |
| Total revenue |  | 654,415 |  |  | 563,309 |  |  | 1,858,160 |  |  | 1,555,643 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 218,220 |  |  | 187,764 |  |  | 616,906 |  |  | 516,077 |  |
| Service |  | 18,921 |  |  | 13,962 |  |  | 53,219 |  |  | 41,181 |  |
| Total cost of revenue |  | 237,141 |  |  | 201,726 |  |  | 670,125 |  |  | 557,258 |  |
| Total gross profit |  | 417,274 |  |  | 361,583 |  |  | 1,188,035 |  |  | 998,385 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 118,732 |  |  | 117,589 |  |  | 352,696 |  |  | 324,029 |  |
| Sales and marketing |  | 55,279 |  |  | 47,903 |  |  | 159,372 |  |  | 136,231 |  |
| General and administrative |  | 14,657 |  |  | 15,321 |  |  | 46,182 |  |  | 53,420 |  |
| Legal settlement |  | — |  |  | — |  |  | — |  |  | 405,000 |  |
| Total operating expenses |  | 188,668 |  |  | 180,813 |  |  | 558,250 |  |  | 918,680 |  |
| Income from operations |  | 228,606 |  |  | 180,770 |  |  | 629,785 |  |  | 79,705 |  |
| Other income (expense), net |  | 19,169 |  |  | 8,619 |  |  | 45,313 |  |  | 10,606 |  |
| Income before income taxes |  | 247,775 |  |  | 189,389 |  |  | 675,098 |  |  | 90,311 |  |
| Provision for (benefit from) income taxes |  | 38,880 |  |  | 20,865 |  |  | 75,923 |  |  | (67,482 | ) |
| Net income |  | $ | 208,895 |  |  | $ | 168,524 |  |  | $ | 599,175 |  |  | $ | 157,793 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 208,799 |  |  | $ | 168,439 |  |  | $ | 598,861 |  |  | $ | 157,706 |  |
| Diluted |  | $ | 208,804 |  |  | $ | 168,445 |  |  | $ | 598,880 |  |  | $ | 157,713 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.73 |  |  | $ | 2.25 |  |  | $ | 7.85 |  |  | $ | 2.12 |  |
| Diluted |  | $ | 2.59 |  |  | $ | 2.08 |  |  | $ | 7.38 |  |  | $ | 1.95 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | 76,426 |  |  | 75,011 |  |  | 76,301 |  |  | 74,506 |  |
| Diluted |  | 80,753 |  |  | 81,018 |  |  | 81,104 |  |  | 80,844 |  |

[0001596532-19-000227:8k_2_02:45]
4

[0001596532-19-000227:8k_2_02:46]
ARISTA NETWORKS, INC.

[0001596532-19-000227:8k_2_02:47]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-19-000227:8k_2_02:48]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-19-000227:8k_2_02:49]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| GAAP gross profit |  | $ | 417,274 |  |  | $ | 361,583 |  |  | $ | 1,188,035 |  |  | $ | 998,385 |  |
| GAAP gross margin |  | 63.8 | % |  | 64.2 | % |  | 63.9 | % |  | 64.2 | % |
| Stock-based compensation expense |  | 1,258 |  |  | 1,268 |  |  | 3,384 |  |  | 3,706 |  |
| Intangible asset amortization |  | 2,626 |  |  | 1,198 |  |  | 7,877 |  |  | 1,198 |  |
| Non-GAAP gross profit |  | $ | 421,158 |  |  | $ | 364,049 |  |  | $ | 1,199,296 |  |  | $ | 1,003,289 |  |
| Non-GAAP gross margin |  | 64.4 | % |  | 64.6 | % |  | 64.5 | % |  | 64.5 | % |
| GAAP income from operations |  | $ | 228,606 |  |  | $ | 180,770 |  |  | $ | 629,785 |  |  | $ | 79,705 |  |
| Stock-based compensation expense |  | 26,257 |  |  | 23,254 |  |  | 74,845 |  |  | 66,583 |  |
| Litigation expense (benefit) |  | — |  |  | (100 | ) |  | 1,962 |  |  | 10,554 |  |
| Legal settlement (1) |  | — |  |  | — |  |  | — |  |  | 405,000 |  |
| Intangible asset amortization |  | 3,293 |  |  | 1,610 |  |  | 10,291 |  |  | 1,610 |  |
| Acquisition-related costs |  | — |  |  | 3,432 |  |  | — |  |  | 3,432 |  |
| Non-GAAP income from operations |  | $ | 258,156 |  |  | $ | 208,966 |  |  | $ | 716,883 |  |  | $ | 566,884 |  |
| Non-GAAP operating margin |  | 39.4 | % |  | 37.1 | % |  | 38.6 | % |  | 36.4 | % |
| GAAP net income |  | $ | 208,895 |  |  | $ | 168,524 |  |  | $ | 599,175 |  |  | $ | 157,793 |  |
| Stock-based compensation expense |  | 26,257 |  |  | 23,254 |  |  | 74,845 |  |  | 66,583 |  |
| Litigation expense (benefit) |  | — |  |  | (100 | ) |  | 1,962 |  |  | 10,554 |  |
| Legal settlement (1) |  | — |  |  | — |  |  | — |  |  | 405,000 |  |
| Intangible asset amortization |  | 3,293 |  |  | 1,610 |  |  | 10,291 |  |  | 1,610 |  |
| Acquisition-related costs |  | — |  |  | 3,432 |  |  | — |  |  | 3,432 |  |
| Altera stock-based tax charge (2) |  | — |  |  | — |  |  | 9,781 |  |  | — |  |
| (Gain) loss on investment in privately-held companies |  | (4,277 | ) |  | — |  |  | (5,427 | ) |  | 9,100 |  |
| Acquisition-related tax expense |  | — |  |  | 5,853 |  |  | — |  |  | 5,853 |  |
| Tax benefit on stock-based awards |  | (12,674 | ) |  | (26,130 | ) |  | (73,183 | ) |  | (84,448 | ) |
| Income tax effect on non-GAAP exclusions |  | (4,391 | ) |  | (5,149 | ) |  | (14,048 | ) |  | (114,340 | ) |
| Non-GAAP net income |  | $ | 217,103 |  |  | $ | 171,294 |  |  | $ | 603,396 |  |  | $ | 461,137 |  |
| GAAP diluted net income per share attributable to common stockholders |  | $ | 2.59 |  |  | $ | 2.08 |  |  | $ | 7.38 |  |  | $ | 1.95 |  |
| Non-GAAP adjustments to net income |  | 0.10 |  |  | 0.03 |  |  | 0.06 |  |  | 3.75 |  |
| Non-GAAP diluted net income per share |  | $ | 2.69 |  |  | $ | 2.11 |  |  | $ | 7.44 |  |  | $ | 5.70 |  |
| Weighted-average shares used in computing GAAP and Non-GAAP diluted net income per share attributable to common stockholders |  | 80,753 |  |  | 81,018 |  |  | 81,104 |  |  | 80,844 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,258 |  |  | $ | 1,268 |  |  | $ | 3,384 |  |  | $ | 3,706 |  |
| Research and development |  | 13,472 |  |  | 12,010 |  |  | 39,171 |  |  | 34,700 |  |
| Sales and marketing |  | 7,832 |  |  | 6,537 |  |  | 21,463 |  |  | 18,771 |  |
| General and administrative |  | 3,695 |  |  | 3,439 |  |  | 10,827 |  |  | 9,406 |  |
| Total |  | $ | 26,257 |  |  | $ | 23,254 |  |  | $ | 74,845 |  |  | $ | 66,583 |  |

[0001596532-19-000227:8k_2_02:50]
___________________

[0001596532-19-000227:8k_2_02:51]
(1) Represents one-time charges associated with the settlement of our lawsuit with Cisco on August 6, 2018.

[0001596532-19-000227:8k_2_02:52]
(2) Represents a discrete income tax expense related to stock based compensation as a result of an opinion on Altera Corporation and Subsidiaries vs. Commissioner on Internal Revenue issued by the Court of Appeals for the Ninth Circuit on June 7, 2019.

[0001596532-19-000227:8k_2_02:53]
ARISTA NETWORKS, INC.

[0001596532-19-000227:8k_2_02:54]
Condensed Consolidated Balance Sheets

[0001596532-19-000227:8k_2_02:55]
(Unaudited, in thousands)

[0001596532-19-000227:8k_2_02:56]
|  |  | September 30, 2019 |  | December 31, 2018 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,095,265 |  |  | $ | 649,950 |  |
| Marketable securities |  | 1,351,775 |  |  | 1,306,197 |  |
| Accounts receivable |  | 447,252 |  |  | 331,777 |  |
| Inventories |  | 239,802 |  |  | 264,557 |  |
| Prepaid expenses and other current assets |  | 106,326 |  |  | 162,321 |  |
| Total current assets |  | 3,240,420 |  |  | 2,714,802 |  |
| Property and equipment, net |  | 40,188 |  |  | 75,355 |  |
| Acquisition-related intangible assets, net |  | 48,319 |  |  | 58,610 |  |
| Goodwill |  | 54,855 |  |  | 53,684 |  |
| Investments |  | 4,150 |  |  | 30,336 |  |
| Operating lease right-of-use assets |  | 91,903 |  |  | — |  |
| Deferred tax assets |  | 110,630 |  |  | 126,492 |  |
| Other assets |  | 29,360 |  |  | 22,704 |  |
| TOTAL ASSETS |  | $ | 3,619,825 |  |  | $ | 3,081,983 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 78,600 |  |  | $ | 93,757 |  |
| Accrued liabilities |  | 128,930 |  |  | 123,254 |  |
| Deferred revenue |  | 291,384 |  |  | 358,586 |  |
| Other current liabilities |  | 49,275 |  |  | 30,907 |  |
| Total current liabilities |  | 548,189 |  |  | 606,504 |  |
| Income taxes payable |  | 60,278 |  |  | 36,167 |  |
| Operating lease liabilities, non-current |  | 87,099 |  |  | — |  |
| Finance lease liabilities, non-current |  | — |  |  | 35,431 |  |
| Deferred revenue, non-current |  | 237,628 |  |  | 228,641 |  |
| Other long-term liabilities |  | 30,627 |  |  | 31,851 |  |
| TOTAL LIABILITIES |  | 963,821 |  |  | 938,594 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 8 |  |  | 8 |  |
| Additional paid-in capital |  | 1,076,732 |  |  | 956,572 |  |
| Retained earnings (1) |  | 1,579,063 |  |  | 1,190,803 |  |
| Accumulated other comprehensive income (loss) |  | 201 |  |  | (3,994 | ) |
| TOTAL STOCKHOLDERS’ EQUITY |  | 2,656,004 |  |  | 2,143,389 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 3,619,825 |  |  | $ | 3,081,983 |  |
| ______________________ |  |  |  |  |
| (1) We adopted new lease accounting guidance under ASC 842, which resulted in a cumulative-effect adjustment of $3.7 million to retained earnings as of January 1, 2019. |

[0001596532-19-000227:8k_2_02:57]
6

[0001596532-19-000227:8k_2_02:58]
ARISTA NETWORKS, INC.

[0001596532-19-000227:8k_2_02:59]
Condensed Consolidated Statements of Cash Flows

[0001596532-19-000227:8k_2_02:60]
(Unaudited, in thousands)

[0001596532-19-000227:8k_2_02:61]
|  |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 599,175 |  |  | $ | 157,793 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 24,948 |  |  | 18,440 |  |
| Stock-based compensation |  | 74,845 |  |  | 66,583 |  |
| Noncash lease expense |  | 12,007 |  |  | — |  |
| Deferred income taxes |  | 10,945 |  |  | (49,615 | ) |
| (Gain) loss on investment in privately-held companies |  | (5,427 | ) |  | 9,100 |  |
| Accretion of investment discounts |  | (6,032 | ) |  | (1,863 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (115,475 | ) |  | (68,192 | ) |
| Inventories |  | 24,951 |  |  | 98,284 |  |
| Prepaid expenses and other current assets |  | 59,388 |  |  | (50,507 | ) |
| Other assets |  | (7,009 | ) |  | (767 | ) |
| Accounts payable |  | (14,361 | ) |  | 30,515 |  |
| Accrued liabilities |  | 5,731 |  |  | (35,917 | ) |
| Deferred revenue |  | (58,216 | ) |  | 13,161 |  |
| Income taxes payable |  | 29,808 |  |  | 10,311 |  |
| Other liabilities |  | 595 |  |  | 9,974 |  |
| Net cash provided by operating activities |  | 635,873 |  |  | 207,300 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 806,519 |  |  | 366,999 |  |
| Purchases of marketable securities |  | (840,098 | ) |  | (827,198 | ) |
| Business acquisitions, net of cash acquired |  | (1,365 | ) |  | (95,640 | ) |
| Purchases of property and equipment |  | (13,319 | ) |  | (17,613 | ) |
| Proceeds from (purchases of) investments in privately-held companies |  | 28,220 |  |  | (8,000 | ) |
| Other investing activities |  | — |  |  | (2,000 | ) |
| Net cash used in investing activities |  | (20,043 | ) |  | (583,452 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Principal payments of lease financing obligations |  | — |  |  | (1,392 | ) |
| Proceeds from issuance of common stock under equity plans |  | 52,177 |  |  | 49,642 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (7,069 | ) |  | (6,914 | ) |
| Repurchase of common stock |  | (214,617 | ) |  | — |  |
| Net cash provided by (used in) financing activities |  | (169,509 | ) |  | 41,336 |  |
| Effect of exchange rate changes |  | (994 | ) |  | (984 | ) |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 445,327 |  |  | (335,800 | ) |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 654,164 |  |  | 864,697 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 1,099,491 |  |  | $ | 528,897 |  |
