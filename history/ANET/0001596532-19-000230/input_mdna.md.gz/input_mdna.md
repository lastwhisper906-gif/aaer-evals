# ANET MD&A — 0001596532-19-000230


## mdna

[0001596532-19-000230:mdna:1]
[same as prior period, unchanged from 0001596532-19-000184:mdna:1]

[0001596532-19-000230:mdna:2]
[same as prior period, unchanged from 0001596532-19-000184:mdna:2]

[0001596532-19-000230:mdna:3]
[same as prior period, unchanged from 0001596532-19-000184:mdna:3]

[0001596532-19-000230:mdna:4]
networking solutions consist of our Extensible Operating System, or EOS, a set of network applications and our ethernet switching and routing platforms. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. At the core of our cloud networking platform is EOS, which was purpose-built to be fully programmable and highly modular. The programmability of EOS has allowed us to create a set of software applications that address the requirements of cloud networking, including workflow automation, network visibility and analytics, and has also allowed us to rapidly integrate with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.

[0001596532-19-000230:mdna:5]
[same as prior period, unchanged from 0001596532-19-000184:mdna:5]

[0001596532-19-000230:mdna:6]
[same as prior period, unchanged from 0001596532-19-000184:mdna:6]

[0001596532-19-000230:mdna:7]
[same as prior period, unchanged from 0001596532-19-000184:mdna:7]

[0001596532-19-000230:mdna:8]
[same as prior period, unchanged from 0001596532-19-000184:mdna:8]

[0001596532-19-000230:mdna:9]
Historically, large purchases by a relatively limited number of end customers have accounted for significant portion of our revenue. We have experienced volatility in demand from certain of these large end customers during 2019 resulting in slower overall revenue growth.  Overall demand from these larger customers may decline in future periods including the fourth quarter of 2019, which would impact our future revenue growth. We have also experienced unpredictability in the timing of large orders, especially with respect to our large end customers, due to the complexity of orders, the time it takes end customers to evaluate, test, qualify and accept our products and other factors specific to our end customers. Due to these factors, we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. For example, our sales to Microsoft as an end-user in fiscal 2018 represented 27% of revenue for the year due to certain factors that are not expected to be repeated in fiscal 2019 or future fiscal years.  As a result, the percentage of our revenue from Microsoft in fiscal 2019 is expected to decline.

[0001596532-19-000230:mdna:10]
[same as prior period, unchanged from 0001596532-19-000184:mdna:10]

[0001596532-19-000230:mdna:11]
[same as prior period, unchanged from 0001596532-19-000184:mdna:11]

[0001596532-19-000230:mdna:12]
Three and Nine Months Ended September 30, 2019 Compared to Three and Nine Months Ended September 30, 2018

[0001596532-19-000230:mdna:13]
[same as prior period, unchanged from 0001596532-19-000184:mdna:13]

[0001596532-19-000230:mdna:14]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |  | Change in |  | 2019 |  | 2018 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 555,066 |  |  | $ | 485,481 |  |  | $ | 69,585 |  |  | 14.3 | % |  | $ | 1,573,652 |  |  | $ | 1,337,865 |  |  | $ | 235,787 |  |  | 17.6 | % |
| Service |  | 99,349 |  |  | 77,828 |  |  | 21,521 |  |  | 27.7 |  |  | 284,508 |  |  | 217,778 |  |  | 66,730 |  |  | 30.6 |  |
| Total revenue |  | 654,415 |  |  | 563,309 |  |  | 91,106 |  |  | 16.2 |  |  | 1,858,160 |  |  | 1,555,643 |  |  | 302,517 |  |  | 19.4 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 218,220 |  |  | 187,764 |  |  | 30,456 |  |  | 16.2 |  |  | 616,906 |  |  | 516,077 |  |  | 100,829 |  |  | 19.5 |  |
| Service |  | 18,921 |  |  | 13,962 |  |  | 4,959 |  |  | 35.5 |  |  | 53,219 |  |  | 41,181 |  |  | 12,038 |  |  | 29.2 |  |
| Total cost of revenue |  | 237,141 |  |  | 201,726 |  |  | 35,415 |  |  | 17.6 |  |  | 670,125 |  |  | 557,258 |  |  | 112,867 |  |  | 20.3 |  |
| Gross profit |  | $ | 417,274 |  |  | $ | 361,583 |  |  | $ | 55,691 |  |  | 15.4 | % |  | $ | 1,188,035 |  |  | $ | 998,385 |  |  | $ | 189,650 |  |  | 19.0 | % |
| Gross margin |  | 63.8 | % |  | 64.2 | % |  |  |  |  |  | 63.9% |  | 64.2% |  |  |  |  |

[0001596532-19-000230:mdna:15]
[same as prior period, unchanged from 0001596532-19-000184:mdna:15]

[0001596532-19-000230:mdna:16]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2019 |  | % of Total |  | 2018 |  | % of Total |  | 2019 |  | % of Total |  | 2018 |  | % of Total |
| Americas |  | $ | 532,318 |  |  | 81.4 | % |  | $ | 406,666 |  |  | 72.2 | % |  | $ | 1,418,325 |  |  | 76.3 | % |  | $ | 1,099,624 |  |  | 70.7 | % |
| Europe, Middle East and Africa |  | 75,439 |  |  | 11.5 |  |  | 92,911 |  |  | 16.5 |  |  | 298,768 |  |  | 16.1 |  |  | 316,608 |  |  | 20.4 |  |
| Asia-Pacific |  | 46,658 |  |  | 7.1 |  |  | 63,732 |  |  | 11.3 |  |  | 141,067 |  |  | 7.6 |  |  | 139,411 |  |  | 8.9 |  |
| Total revenue |  | $ | 654,415 |  |  | 100.0 | % |  | $ | 563,309 |  |  | 100.0 | % |  | $ | 1,858,160 |  |  | 100.0 | % |  | $ | 1,555,643 |  |  | 100.0 | % |

[0001596532-19-000230:mdna:17]
[same as prior period, unchanged from 0001596532-19-000184:mdna:17]

[0001596532-19-000230:mdna:18]
We generate revenue primarily from sales of our products. We also derive a portion of our revenue from sales of PCS, which is typically purchased in conjunction with our products, and subsequent renewals of those contracts. We expect our revenue may vary from period to period based on, among other things, the timing and size of orders, the delivery and acceptance of products, and the impact of significant transactions.

[0001596532-19-000230:mdna:19]
Product revenue increased $69.6 million, or 14.3%, and $235.8 million, or 17.6%, in the three and nine months ended September 30, 2019, respectively, compared to the same periods in 2018.  The increases in both periods were primarily driven by increased demand from both new and existing customers. Service revenue increased $21.5 million, or 27.7%, and $66.7 million, or 30.6%, in the three and nine months ended September 30, 2019, respectively, compared to the same periods in 2018 as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenues represented 18.6% and 23.7% of total revenues in the three and nine months ended September 30, 2019, respectively, down from 27.8% and 29.3% compared to the same periods in the prior year, which was primarily due to a move toward U.S. deployments by certain of our large end customers in the three and nine months ended September 30, 2019. We continue to experience pricing pressure on our products and services due to competition, but demand for our products and growth in our installed base has more than offset this pricing pressure during the period. However, we have experienced reduced demand from certain of our large end customers during the nine months ended September 30, 2019, and expect this could continue in future periods including the quarter ended December 31, 2019. In order to continue to grow our future revenue, we must continue to add new cloud data center networking customers and expand our presence and increase sales in the campus switching and WiFi networking markets.

[0001596532-19-000230:mdna:20]
[same as prior period, unchanged from 0001596532-19-000184:mdna:20]

[0001596532-19-000230:mdna:21]
Cost of product revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs in our manufacturing operations department, and other manufacturing-related costs associated with manufacturing our products and managing our inventory. Cost of providing PCS and other services consists primarily of personnel costs for our global customer support organization.

[0001596532-19-000230:mdna:22]
Cost of revenue increased $35.4 million, or 17.6%, and $112.9 million, or 20.3%, in the three and nine months ended September 30, 2019, respectively, compared to the same periods in 2018. The increases were primarily due to the corresponding increases in product and service revenues.

[0001596532-19-000230:mdna:23]
[same as prior period, unchanged from 0001596532-19-000184:mdna:24]

[0001596532-19-000230:mdna:24]
Gross margin decreased from 64.2% to 63.8% for the three months ended September 30, 2019 and from 64.2% to 63.9% for the nine months ended September 30, 2019 compared to the same periods in 2018. The decreases were primarily driven by a decrease in product margin due to increased product transition costs including some excess and obsolete inventory-related charges. The decrease in the nine month period ended September 30, 2019 was largely offset by a favorable customer mix with lower discounts on smaller volume transactions. Service margin continued to improve due to a relatively fixed services cost base and growing service revenues.

[0001596532-19-000230:mdna:25]
[same as prior period, unchanged from 0001596532-19-000184:mdna:26]

[0001596532-19-000230:mdna:26]
[same as prior period, unchanged from 0001596532-19-000184:mdna:27]

[0001596532-19-000230:mdna:27]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |  | Change in |  | 2019 |  | 2018 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 118,732 |  |  | $ | 117,589 |  |  | $ | 1,143 |  |  | 1.0 | % |  | $ | 352,696 |  |  | $ | 324,029 |  |  | $ | 28,667 |  |  | 8.8 | % |
| Sales and marketing |  | 55,279 |  |  | 47,903 |  |  | 7,376 |  |  | 15.4 |  |  | 159,372 |  |  | 136,231 |  |  | 23,141 |  |  | 17.0 |  |
| General and administrative |  | 14,657 |  |  | 15,321 |  |  | (664 | ) |  | (4.3 | ) |  | 46,182 |  |  | 53,420 |  |  | (7,238 | ) |  | (13.5 | ) |
| Legal settlement |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 405,000 |  |  | (405,000 | ) |  | (100.0 | ) |
| Total operating expenses |  | $ | 188,668 |  |  | $ | 180,813 |  |  | $ | 7,855 |  |  | 4.3 | % |  | $ | 558,250 |  |  | $ | 918,680 |  |  | $ | (360,430 | ) |  | (39.2 | )% |

[0001596532-19-000230:mdna:28]
[same as prior period, unchanged from 0001596532-19-000184:mdna:29]

[0001596532-19-000230:mdna:29]
[same as prior period, unchanged from 0001596532-19-000184:mdna:30]

[0001596532-19-000230:mdna:30]
Research and development expenses increased $1.1 million, or 1.0%, and $28.7 million, or 8.8%, for the three and nine months ended September 30, 2019 compared to the same periods in 2018. The increases in the three and nine months ended September 30, 2019 included a $3.1 million and a $21.3 million increase in personnel costs driven primarily by headcount growth, including headcount additions from the two acquisitions we completed in the third quarter of 2018, and a $2.4 million and a $6.8 million increase in development-related facilities costs due to facilities expansion and headcount growth. The increase in the three months ended September 30, 2019 was partially offset by a $3.9 million reduction in product development costs.

[0001596532-19-000230:mdna:31]
[same as prior period, unchanged from 0001596532-19-000184:mdna:32]

[0001596532-19-000230:mdna:32]
[same as prior period, unchanged from 0001596532-19-000184:mdna:33]

[0001596532-19-000230:mdna:33]
Sales and marketing expenses increased $7.4 million, or 15.4%, and $23.1 million, or 17.0%, for the three and nine months ended September 30, 2019 compared to the same periods in 2018. The increases in the three and nine months ended September 30, 2019 included a $6.9 million and a $20.1 million increase in personnel costs due to headcount growth which resulted in an increase

[0001596532-19-000230:mdna:34]
in compensation, including sales commissions.

[0001596532-19-000230:mdna:35]
[same as prior period, unchanged from 0001596532-19-000184:mdna:35]

[0001596532-19-000230:mdna:36]
General and administrative expenses consist primarily of personnel costs, professional services fees, litigation-related expenses, and an allocated portion of facility and IT costs including depreciation. General and administrative personnel costs include those for our executive, finance, human resources and legal functions. Our professional services fees are primarily due to external legal, accounting and tax services.

[0001596532-19-000230:mdna:37]
General and administrative expenses decreased $0.7 million, or 4.3%, and $7.2 million, or 13.5%, for the three and nine months ended September 30, 2019 compared to the same periods in 2018.  The decrease for the nine months ended September 30, 2019 was primarily related to a reduced level of litigation activities as a result of the settlement of our litigation with Cisco in August 2018.

[0001596532-19-000230:mdna:38]
[same as prior period, unchanged from 0001596532-19-000184:mdna:38]

[0001596532-19-000230:mdna:39]
During the three and nine months ended September 30, 2018, we recorded $405.0 million in legal settlement expenses in connection with a binding term sheet (“Term Sheet”) that was entered into on August 6, 2018 between the Company and Cisco (the “Legal Settlement”), which included a $400.0 million payment to Cisco and $5.0 million of legal fees associated with the settlement. Pursuant to the Term Sheet, the Company and Cisco obtained dismissals of all then ongoing district court and USITC litigation between us. On December 3, 2018, the parties entered into a mutual release and settlement agreement, which superseded the Term Sheet but did not substantially alter the terms.

[0001596532-19-000230:mdna:40]
[same as prior period, unchanged from 0001596532-19-000184:mdna:40]

[0001596532-19-000230:mdna:41]
[same as prior period, unchanged from 0001596532-19-000184:mdna:41]

[0001596532-19-000230:mdna:42]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |  | Change in |  | 2019 |  | 2018 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 13,446 |  |  | $ | 8,585 |  |  | $ | 4,861 |  |  | 56.6 | % |  | $ | 38,451 |  |  | $ | 21,933 |  |  | $ | 16,518 |  |  | 75.3 | % |
| Interest expense |  | — |  |  | (673 | ) |  | 673 |  |  | (100.0 | ) |  | — |  |  | (2,040 | ) |  | 2,040 |  |  | (100.0 | ) |
| Gain (loss) on investments in privately-held companies |  | 4,277 |  |  | — |  |  | 4,277 |  |  | — |  |  | 5,427 |  |  | (9,100 | ) |  | 14,527 |  |  | (159.6 | ) |
| Other income (expense), net |  | 1,446 |  |  | 707 |  |  | 739 |  |  | 104.5 |  |  | 1,435 |  |  | (187 | ) |  | 1,622 |  |  | (867.4 | ) |
| Total other income (expense), net |  | $ | 19,169 |  |  | $ | 8,619 |  |  | $ | 10,550 |  |  | 122.4 | % |  | $ | 45,313 |  |  | $ | 10,606 |  |  | $ | 34,707 |  |  | 327.2 | % |

[0001596532-19-000230:mdna:43]
The favorable increase in other income (expense), net, during the three and nine months ended September 30, 2019 as compared to the same periods of 2018 were primarily due to increases in interest income as we continued to generate cash and expand our marketable securities portfolios, and favorable changes in gain (loss) on our investments in privately-held companies.  The gain on investments of $4.3 million and $5.4 million in the three and nine months ended September 30, 2019 mainly resulted from the sale of one of our investments in the period. The loss incurred in the nine months ended September 30, 2018 primarily related to a $10.3 million impairment of our investments. See Note 5. Investments of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-19-000230:mdna:44]
[same as prior period, unchanged from 0001596532-19-000184:mdna:44]

[0001596532-19-000230:mdna:45]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. Earnings from our non-U.S. activities are subject to local country income tax and may also be subject to U.S. income

[0001596532-19-000230:mdna:46]
tax. Generally, our U.S. tax obligations are reduced by a credit for foreign income taxes paid on these foreign earnings which avoids double taxation. Our tax expense to date consists of federal, state and foreign current and deferred income taxes.

[0001596532-19-000230:mdna:47]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |  | Change in |  | 2019 |  | 2018 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Income before income taxes |  | $ | 247,775 |  |  | $ | 189,389 |  |  | $ | 58,386 |  |  | 30.8 | % |  | $ | 675,098 |  |  | $ | 90,311 |  |  | $ | 584,787 |  |  | 647.5 | % |
| Provision for (benefit from) income taxes |  | 38,880 |  |  | 20,865 |  |  | 18,015 |  |  | 86.3 | % |  | 75,923 |  |  | (67,482 | ) |  | 143,405 |  |  | (212.5 | )% |
| Effective tax rate |  | 15.7 | % |  | 11.0 | % |  |  |  |  |  | 11.2 | % |  | (74.7 | )% |  |  |  |  |

[0001596532-19-000230:mdna:48]
The income tax benefits for the 2018 periods included $99.0 million in federal and state tax benefits on the $405 million charge related to the Legal Settlement recorded in the nine months ended September 30, 2018. In addition, income taxes for the three and nine months ended September 30, 2019 included a lower benefit from the recognition of excess tax benefits on stock-based compensation.  Our income taxes in the nine months ended September 30, 2019 were also negatively impacted by a change in our position on sharing stock-based compensation within our cost sharing arrangement as a result of an opinion issued in June 2019. See Note 10. Income Taxes of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further information.  The remaining changes in the income taxes were attributable to the overall increase in worldwide earnings.

[0001596532-19-000230:mdna:49]
[same as prior period, unchanged from 0001596532-19-000184:mdna:48]

[0001596532-19-000230:mdna:50]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of September 30, 2019, our total balance of cash, cash equivalents and marketable securities was approximately $2.4 billion, of which approximately $402.2 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-19-000230:mdna:51]
Our cash, cash equivalents and marketable securities are held for working capital purposes. Our marketable securities investment portfolio is primarily invested in highly-rated securities with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities together with cash generated from operations will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, costs incurred related to outstanding litigation claims, and stock repurchases. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-19-000230:mdna:52]
[same as prior period, unchanged from 0001596532-19-000184:mdna:51]

[0001596532-19-000230:mdna:53]
|  |  | Nine Months Ended September 30, |
|  |  | 2019 |  | 2018 |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 635,873 |  |  | $ | 207,300 |  |
| Cash used in investing activities |  | (20,043 | ) |  | (583,452 | ) |
| Cash provided by (used in) financing activities |  | (169,509 | ) |  | 41,336 |  |
| Effect of exchange rate changes |  | (994 | ) |  | (984 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 445,327 |  |  | $ | (335,800 | ) |

[0001596532-19-000230:mdna:54]
[same as prior period, unchanged from 0001596532-19-000184:mdna:53]

[0001596532-19-000230:mdna:55]
During the nine months ended September 30, 2019, cash provided by operating activities was $635.9 million, primarily from net income of $599.2 million and non-cash adjustments to net income of $111.3 million driven by stock-based compensation and depreciation and amortization, partially offset by a net decrease of $74.6 million in cash from changes in our operating assets and liabilities. Cash outflows from operating activities consisted of a $58.2 million decrease in deferred revenue primarily due to

[0001596532-19-000230:mdna:56]
the recognition of product deferred revenue related to contract acceptance terms, $115.5 million increase in accounts receivable due to timing of customer shipments in the current quarter, and a $14.4 million decrease in accounts payable due to timing of production related vendor balances. These cash outflows were partially offset by cash inflows of $59.4 million in prepaid expenses and other current assets from a decrease in prepaid taxes and a decrease in deferred cost of inventory due to the recognition of product deferred revenue, $29.8 million from an increase in income taxes payable, and a $25.0 million decrease in inventories due to timing of product shipments and receipts.

[0001596532-19-000230:mdna:57]
During the nine months ended September 30, 2018, cash provided by operating activities was $207.3 million, primarily from net income of $157.8 million with non-cash adjustments to net income of $42.6 million, and a net increase of $6.9 million in cash from changes in our operating assets and liabilities. The increase in cash from changes in operating assets and liabilities was primarily due to cash inflows of $98.3 million from a decrease in inventories driven by improved inventory management and timing of receipts, $30.5 million from an increase in accounts payable due to timing of inventory receipts and payments, $13.2 million from an increase in deferred revenue primarily from growth in customer PCS contracts, $10.3 million from an increase in income taxes payable, and $10.0 million from increases in other liabilities primarily driven by increased customer prepayments under concealable contracts. These cash inflows were partially offset by cash outflows of $68.2 million from an increase in accounts receivable due to increased billing and timing of customer shipments, $50.5 million from an increase in prepaid expenses and other current assets primarily due to an income tax benefit recorded for the Cisco legal settlement charges referenced above, and $35.9 million from a decline in accrued liabilities due primarily to a decline in supplier liabilities and the completion of product development projects.

[0001596532-19-000230:mdna:58]
[same as prior period, unchanged from 0001596532-19-000184:mdna:57]

[0001596532-19-000230:mdna:59]
During the nine months ended September 30, 2019, cash used in investing activities was $20.0 million, primarily consisting of purchases of available-for-sale securities of $840.1 million, and purchases of property and equipment of $13.3 million, partially offset by proceeds of $806.5 million from maturities of marketable securities and proceeds from the sale of one of our investments in privately-held companies of $28.2 million.

[0001596532-19-000230:mdna:60]
During the nine months ended September 30, 2018, cash used in investing activities was $583.5 million, consisting of purchases of available-for-sale securities of $827.2 million, offset by proceeds of $367.0 million from maturities of marketable securities, $95.6 million for business acquisitions, and purchases of property and equipment of $17.6 million.

[0001596532-19-000230:mdna:61]
[same as prior period, unchanged from 0001596532-19-000184:mdna:60]

[0001596532-19-000230:mdna:62]
During the nine months ended September 30, 2019, cash used in financing activities was $169.5 million, consisting of payments for repurchases of our common stock from the open market of $214.6 million and taxes paid of $7.1 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $52.2 million.

[0001596532-19-000230:mdna:63]
During the nine months ended September 30, 2018, cash provided by financing activities was $41.3 million, consisting primarily of proceeds from the issuance of common stock under employee equity incentive plans of $49.6 million, offset by taxes paid of $6.9 million upon vesting of restricted stock units, and payments for lease financing obligations of $1.4 million.

[0001596532-19-000230:mdna:64]
[same as prior period, unchanged from 0001596532-19-000184:mdna:63]

[0001596532-19-000230:mdna:65]
From time to time, we repurchase stock opportunistically pursuant to our Repurchase Program authorized by our board of directors in April 2019. The repurchases are funded from working capital. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of September 30, 2019, the remaining authorized amount for stock repurchases under this program is approximately $785.4 million. Refer to Note 8. Equity Award Plan Activities of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-19-000230:mdna:66]
[same as prior period, unchanged from 0001596532-19-000184:mdna:65]

[0001596532-19-000230:mdna:67]
As of September 30, 2019, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-19-000230:mdna:68]
[same as prior period, unchanged from 0001596532-19-000184:mdna:67]

[0001596532-19-000230:mdna:69]
Our contractual obligations represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalent and marketable securities. As of September 30, 2019, our principal commitments consist primarily of obligations under operating leases for offices and data centers and purchase commitments with our contract manufacturers and suppliers. See Note 6. Leases and Note 7. Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included

[0001596532-19-000230:mdna:70]
in Part I, Item 1, of this Quarterly Report on Form 10-Q for future payment commitments under leases and our purchase commitments as of September 30, 2019, respectively.

[0001596532-19-000230:mdna:71]
[same as prior period, unchanged from 0001596532-19-000184:mdna:69]

[0001596532-19-000230:mdna:72]
[same as prior period, unchanged from 0001596532-19-000184:mdna:70]

[0001596532-19-000230:mdna:73]
[same as prior period, unchanged from 0001596532-19-000184:mdna:71]

[0001596532-19-000230:mdna:74]
Refer to the sections titled “Recently Adopted Accounting Pronouncements” and “Recent Accounting Pronouncements Not Yet Effective” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
