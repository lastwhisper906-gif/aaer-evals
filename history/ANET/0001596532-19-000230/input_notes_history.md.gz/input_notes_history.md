# ANET note change history — 0001596532-19-000184 → 0001596532-19-000230


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-11-01):
[0001596532-19-000230:note_history:1]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2028. See Note 6 for our future minimum payment obligations under our leases as of September 30, 2019.
  (was, 2019-08-02, similarity 0.9602):
[0001596532-19-000184:note_history:1]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2028. See Note 6 for our future minimum payment obligations under our leases as of June 30, 2019.

- changed (2019-11-01):
[0001596532-19-000230:note_history:2]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2019, we had non-cancellable purchase commitments of $222.4 million, of which $209.6 million was to our contract manufacturers and suppliers. In addition, we have provided deposits to secure our obligations to purchase inventory. We had $17.8 million and $17.4 million in deposits as of September 30, 2019 and December 31, 2018, respectively. These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.
  (was, 2019-08-02, similarity 0.9888):
[0001596532-19-000184:note_history:2]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of June 30, 2019, we had non-cancellable purchase commitments of $230.9 million, of which $208.8 million was to our contract manufacturers and suppliers. In addition, we have provided deposits to secure our obligations to purchase inventory. We had $17.0 million and $17.4 million in deposits as of June 30, 2019 and December 31, 2018, respectively. These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.

- changed (2019-11-01):
[0001596532-19-000230:note_history:3]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies; and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of
  (was, 2019-08-02, similarity 0.7085):
[0001596532-19-000184:note_history:3]
system pursuant to the terms of a 2004 agreement between the companies; and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

- added (2019-11-01):
[0001596532-19-000230:note_history:4]
the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

- changed (2019-11-01):
[0001596532-19-000230:note_history:5]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial were set to be tried in Phase II, including the application of the Court’s interpretation of the 2004 agreement to any other source code that OptumSoft claims to own and the trade secret misappropriation and confidentiality claims.
  (was, 2019-08-02, similarity 0.6156):
[0001596532-19-000184:note_history:5]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II, including the application of the Court’s interpretation of the 2004 agreement to any other source code that OptumSoft claims to own and the trade secret misappropriation and confidentiality claims. The Court has agreed to vacate the trial date pending the parties’ efforts to settle the issues in dispute in the Phase II trial.

- added (2019-11-01):
[0001596532-19-000230:note_history:6]
On September 24, 2019, the Company and OptumSoft entered into a settlement agreement resolving all the issues that were set to be tried in Phase II of the litigation. Under the settlement agreement, OptumSoft may still pursue its appeal of the Court’s Final Statement of Decision Following Phase I Trial, and pursue any further litigation that may result, but has granted the Company a release on all other outstanding claims.

- added (2019-11-01):
[0001596532-19-000230:note_history:7]
GlobalFoundries Litigation

- added (2019-11-01):
[0001596532-19-000230:note_history:8]
On August 26, 2019, GlobalFoundries U.S. Inc. (“GlobalFoundries”) filed complaints in the International Trade Commission and federal court against TSMC and numerous companies that sell products incorporating semiconductor devices manufactured by TSMC, including Arista, Broadcom, NVIDIA, Apple, Asus, Cisco, and Lenovo. The complaints allege that these semiconductor devices infringe four GlobalFoundries patents relating to semiconductor manufacturing techniques. In our case, GlobalFoundries has accused the merchant silicon we purchase from Broadcom of infringement. On October 28, 2019, TSMC and GlobalFoundries entered into a cross-license agreement to settle the litigation.

- changed (2019-11-01):
[0001596532-19-000230:note_history:9]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2019, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.
  (was, 2019-08-02, similarity 0.7582):
[0001596532-19-000184:note_history:9]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of June 30, 2019, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results

- removed (2019-11-01):
[0001596532-19-000184:note_history:10]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating

- removed (2019-11-01):
[0001596532-19-000184:note_history:11]
of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-11-01):
[0001596532-19-000230:note_history:12]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” “us” or the “Company”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System (“EOS”), a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.
  (was, 2019-08-02, similarity 0.9845):
[0001596532-19-000184:note_history:12]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our” or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System (“EOS”), a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

- changed (2019-11-01):
[0001596532-19-000230:note_history:13]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2019, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2018 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant intercompany accounts and transactions have been eliminated.
  (was, 2019-08-02, similarity 0.9811):
[0001596532-19-000184:note_history:13]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2019, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2018 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant intercompany accounts and transactions have been eliminated.

- changed (2019-11-01):
[0001596532-19-000230:note_history:14]
Effective January 1, 2019, we adopted Accounting Standard Codification (“ASC”) 842 - Leases, as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1. As a result, we added a new significant accounting policy “Leases” as described below. There have been no other significant changes to our accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2018, filed with the SEC on February 15, 2019.
  (was, 2019-08-02, similarity 0.9014):
[0001596532-19-000184:note_history:14]
During the six months ended June 30, 2019, we adopted ASC 842 - Leases, as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1. As a result, we added a new significant accounting policy “Leases” as described below. There have been no other significant changes to our accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2018, filed with the SEC on February 15, 2019.
