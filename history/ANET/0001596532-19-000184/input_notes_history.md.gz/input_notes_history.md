# ANET note change history — 0001596532-19-000104 → 0001596532-19-000184


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-08-02):
[0001596532-19-000184:note_history:1]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2028. See Note 6 for our future minimum payment obligations under our leases as of June 30, 2019.
  (was, 2019-05-06, similarity 0.9675):
[0001596532-19-000104:note_history:1]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2028. See Note 6 for our future minimum payment obligations under our leases as of March 31, 2019.

- changed (2019-08-02):
[0001596532-19-000184:note_history:2]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of June 30, 2019, we had non-cancellable purchase commitments of $230.9 million, of which $208.8 million was to our contract manufacturers and suppliers. In addition, we have provided deposits to secure our obligations to purchase inventory. We had $17.0 million and $17.4 million in deposits as of June 30, 2019 and December 31, 2018, respectively. These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.
  (was, 2019-05-06, similarity 0.9922):
[0001596532-19-000104:note_history:2]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of March 31, 2019, we had non-cancellable purchase commitments of $253.8 million, of which $216.2 million was to our contract manufacturers and suppliers. In addition, we have provided deposits to secure our obligations to purchase inventory. We had $22.3 million and $17.4 million in deposits as of March 31, 2019 and December 31, 2018, respectively. These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.

- added (2019-08-02):
[0001596532-19-000184:note_history:3]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating

- changed (2019-08-02):
[0001596532-19-000184:note_history:4]
system pursuant to the terms of a 2004 agreement between the companies; and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.
  (was, 2019-05-06, similarity 0.8473):
[0001596532-19-000104:note_history:4]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies; and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

- changed (2019-08-02):
[0001596532-19-000184:note_history:5]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II, including the application of the Court’s interpretation of the 2004 agreement to any other source code that OptumSoft claims to own and the trade secret misappropriation and confidentiality claims. The Court has agreed to vacate the trial date pending the parties’ efforts to settle the issues in dispute in the Phase II trial.
  (was, 2019-05-06, similarity 0.8721):
[0001596532-19-000104:note_history:5]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II, including the application of the Court’s interpretation of the 2004 agreement to any other source code that OptumSoft claims to own and the trade secret misappropriation and confidentiality claims. The Phase II Trial is set for the first date the court is available after December 2, 2019.

- changed (2019-08-02):
[0001596532-19-000184:note_history:6]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of June 30, 2019, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results
  (was, 2019-05-06, similarity 0.76):
[0001596532-19-000104:note_history:6]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2019, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.

- added (2019-08-02):
[0001596532-19-000184:note_history:7]
of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-08-02):
[0001596532-19-000184:note_history:8]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2019, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2018 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant intercompany accounts and transactions have been eliminated.
  (was, 2019-05-06, similarity 0.983):
[0001596532-19-000104:note_history:8]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2019, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2018 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant intercompany accounts and transactions have been eliminated.

- changed (2019-08-02):
[0001596532-19-000184:note_history:9]
During the six months ended June 30, 2019, we adopted ASC 842 - Leases, as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1. As a result, we added a new significant accounting policy “Leases” as described below. There have been no other significant changes to our accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2018, filed with the SEC on February 15, 2019.
  (was, 2019-05-06, similarity 0.9613):
[0001596532-19-000104:note_history:9]
During the three months ended March 31, 2019, we adopted ASC 842 - Leases, as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1. As a result, we added a new significant accounting policy "Leases" as described below. There have been no other significant changes to our accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2018, filed with the SEC on February 15, 2019.

- changed (2019-08-02):
[0001596532-19-000184:note_history:10]
We determine if a contract contains a lease at inception. The lease term represents the non-cancellable period for which we have the right to use an underlying asset, which may include periods covered by certain options to extend and/or terminate the lease. Lease liabilities and corresponding right-of-use (“ROU”) assets are recognized at the commencement date of a lease. Leases with an initial lease term of 12 months or less are not recorded on the balance sheet.
  (was, 2019-05-06, similarity 0.9957):
[0001596532-19-000104:note_history:10]
We determine if a contract contains a lease at inception. The lease term represents the non-cancellable period for which we have the right to use an underlying asset, which may include periods covered by certain options to extend and/or terminate the lease. Lease liabilities and corresponding right-of-use ("ROU") assets are recognized at the commencement date of a lease. Leases with an initial lease term of 12 months or less are not recorded on the balance sheet.

- changed (2019-08-02):
[0001596532-19-000184:note_history:11]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) No. 2016-02, Leases (“ASU 2016-02”), and in July 2018, the FASB issued ASU 2018-11, Leases (Topic 842): Targeted Improvements (“ASU 2018-11”) (collectively referred to as “ASC 842”). Under the guidance, lessees are required to recognize assets and lease liabilities on the balance sheet for most leases including operating leases and provide enhanced disclosures. Companies are required to adopt this guidance using a modified retrospective approach and apply the transition provisions under the guidance at either 1) the later of the beginning of the earliest comparative period presented in the financial statements and the commencement date of the lease, or 2) the beginning of the period of adoption (i.e. on the effective date). Under the transition method using the second application date, a company initially applies the new leases standard at the adoption date and recognizes a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption.
  (was, 2019-05-06, similarity 0.9869):
[0001596532-19-000104:note_history:11]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2016-02, Leases (“ASU 2016-02”), and in July 2018, the FASB issued ASU 2018-11, Leases (Topic 842): Targeted Improvements (“ASU 2018-11”) (collectively referred to as "ASC 842"). Under the guidance, lessees are required to recognize assets and lease liabilities on the balance sheet for most leases including operating leases and provide enhanced disclosures. Companies are required to adopt this guidance using a modified retrospective approach and apply the transition provisions under the guidance at either 1) the later of the beginning of the earliest comparative period presented in the financial statements and the commencement date of the lease, or 2) the beginning of the period of adoption (i.e. on the effective date). Under the transition method using the second application date, a company initially applies the new leases standard at the adoption date and recognizes a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption.

- added (2019-08-02):
[0001596532-19-000184:note_history:12]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  The proposed standard requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. For trade receivables, we will be required to estimate lifetime expected credit losses. For available-for-sale debt securities, we will be required to recognize an allowance for credit losses rather than a reduction to the carrying value of the asset. In May 2019, the FASB issued ASU 2019-05, Financial Instruments—Credit Losses, Topic 326, which allows companies to make an irrevocable one-time election upon adoption of ASU 2016-13 to elect the fair value option for certain financial assets currently measured at amortized cost (except held-to-maturity securities). The election is to be applied on an instrument-by-instrument basis. ASU 2016-13 is effective for us for our first quarter of 2020. We are currently assessing the impact this guidance may have on our consolidated financial statements.

- removed (2019-08-02):
[0001596532-19-000104:note_history:13]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. For trade receivables, we will be required to estimate lifetime expected credit losses. For available-for-sale debt securities, we will be required to recognize an allowance for credit losses rather than a reduction to the carrying value of the asset. This standard is effective for us for our first quarter of 2020. We are currently assessing the impact this guidance may have on our consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2019-08-02):
[0001596532-19-000104:note_history:14]
12.    Subsequent Event

- removed (2019-08-02):
[0001596532-19-000104:note_history:15]
Stock Repurchase Program

- removed (2019-08-02):
[0001596532-19-000104:note_history:16]
Subsequent to March 31, 2019, our board of directors authorized a $1.0 billion stock repurchase program (the “Repurchase Program”).  This authorization allows us to repurchase shares of our common stock opportunistically and will be funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, or a combination of the foregoing. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice.
