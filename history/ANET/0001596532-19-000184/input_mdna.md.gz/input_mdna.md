# ANET MD&A — 0001596532-19-000184


## mdna

[0001596532-19-000184:mdna:1]
[same as prior period, unchanged from 0001596532-19-000104:mdna:1]

[0001596532-19-000184:mdna:2]
[same as prior period, unchanged from 0001596532-19-000104:mdna:2]

[0001596532-19-000184:mdna:3]
We are a leading supplier of cloud networking solutions that use software innovations to address the needs of large-scale internet companies, cloud service providers and next-generation data centers and campuses for enterprise support. Our cloud

[0001596532-19-000184:mdna:4]
networking solutions consist of our Extensible Operating System, or EOS, a set of network applications and our Ethernet switching and routing platforms. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. At the core of our cloud networking platform is EOS, which was purpose-built to be fully programmable and highly modular. The programmability of EOS has allowed us to create a set of software applications that address the requirements of cloud networking, including workflow automation, network visibility and analytics, and has also allowed us to rapidly integrate with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.

[0001596532-19-000184:mdna:5]
[same as prior period, unchanged from 0001596532-19-000104:mdna:5]

[0001596532-19-000184:mdna:6]
[same as prior period, unchanged from 0001596532-19-000104:mdna:6]

[0001596532-19-000184:mdna:7]
[same as prior period, unchanged from 0001596532-19-000104:mdna:7]

[0001596532-19-000184:mdna:8]
[same as prior period, unchanged from 0001596532-19-000104:mdna:8]

[0001596532-19-000184:mdna:9]
Historically, large purchases by a relatively limited number of end customers have accounted for significant portion of our revenue. We have experienced unpredictability in the timing of large orders, especially with respect to our large end customers, due to the complexity of orders, the time it takes end customers to evaluate, test, qualify and accept our products and other factors specific to our end customers. Due to these factors, we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. For example, our sales to Microsoft as an end-user in fiscal 2018 represented 27% of revenue for the year due to certain factors that are not expected to be repeated in fiscal 2019 or future fiscal years.  As a result, the percentage of our revenue from Microsoft in fiscal 2019 is expected to decline.

[0001596532-19-000184:mdna:10]
In addition, we have provided, and may in the future provide, pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur. Our gross margins may also fluctuate as a result of the timing of such sales to large end customers.

[0001596532-19-000184:mdna:11]
[same as prior period, unchanged from 0001596532-19-000104:mdna:10]

[0001596532-19-000184:mdna:12]
Three and Six Months Ended June 30, 2019 Compared to Three and Six Months Ended June 30, 2018

[0001596532-19-000184:mdna:13]
[same as prior period, unchanged from 0001596532-19-000104:mdna:12]

[0001596532-19-000184:mdna:14]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |  | Change in |  | 2019 |  | 2018 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 513,171 |  |  | $ | 444,767 |  |  | $ | 68,404 |  |  | 15.4 | % |  | $ | 1,018,586 |  |  | $ | 852,384 |  |  | $ | 166,202 |  |  | 19.5 | % |
| Service |  | 95,150 |  |  | 75,078 |  |  | 20,072 |  |  | 26.7 |  |  | 185,159 |  |  | 139,950 |  |  | 45,209 |  |  | 32.3 |  |
| Total revenue |  | 608,321 |  |  | 519,845 |  |  | 88,476 |  |  | 17.0 |  |  | 1,203,745 |  |  | 992,334 |  |  | 211,411 |  |  | 21.3 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 200,534 |  |  | 171,622 |  |  | 28,912 |  |  | 16.8 |  |  | 398,686 |  |  | 328,313 |  |  | 70,373 |  |  | 21.4 |  |
| Service |  | 17,596 |  |  | 14,340 |  |  | 3,256 |  |  | 22.7 |  |  | 34,298 |  |  | 27,219 |  |  | 7,079 |  |  | 26.0 |  |
| Total cost of revenue |  | 218,130 |  |  | 185,962 |  |  | 32,168 |  |  | 17.3 |  |  | 432,984 |  |  | 355,532 |  |  | 77,452 |  |  | 21.8 |  |
| Gross profit |  | $ | 390,191 |  |  | $ | 333,883 |  |  | $ | 56,308 |  |  | 16.9 | % |  | $ | 770,761 |  |  | $ | 636,802 |  |  | $ | 133,959 |  |  | 21.0 | % |
| Gross margin |  | 64.1 | % |  | 64.2 | % |  |  |  |  |  | 64.0% |  | 64.2% |  |  |  |  |

[0001596532-19-000184:mdna:15]
[same as prior period, unchanged from 0001596532-19-000104:mdna:14]

[0001596532-19-000184:mdna:16]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2019 |  | % of Total |  | 2018 |  | % of Total |  | 2019 |  | % of Total |  | 2018 |  | % of Total |
| Americas |  | $ | 446,370 |  |  | 73.4 | % |  | $ | 377,460 |  |  | 72.6 | % |  | $ | 886,008 |  |  | 73.6 | % |  | $ | 692,958 |  |  | 69.8 | % |
| Europe, Middle East and Africa |  | 112,060 |  |  | 18.4 |  |  | 101,811 |  |  | 19.6 |  |  | 223,329 |  |  | 18.6 |  |  | 223,697 |  |  | 22.5 |  |
| Asia-Pacific |  | 49,891 |  |  | 8.2 |  |  | 40,574 |  |  | 7.8 |  |  | 94,408 |  |  | 7.8 |  |  | 75,679 |  |  | 7.7 |  |
| Total revenue |  | $ | 608,321 |  |  | 100.0 | % |  | $ | 519,845 |  |  | 100.0 | % |  | $ | 1,203,745 |  |  | 100.0 | % |  | $ | 992,334 |  |  | 100.0 | % |

[0001596532-19-000184:mdna:17]
[same as prior period, unchanged from 0001596532-19-000104:mdna:16]

[0001596532-19-000184:mdna:18]
[same as prior period, unchanged from 0001596532-19-000104:mdna:17]

[0001596532-19-000184:mdna:19]
Product revenue increased $68.4 million, or 15.4%, and $166.2 million, or 19.5%, in the three and six months ended June 30, 2019, respectively, compared to the same periods in 2018.  The increases were primarily driven by sales to our existing customers as they continued to expand and upgrade their cloud networks. In addition, our newer switch products have continued to gain market acceptance, which has contributed to our revenue growth.  Service revenue increased $20.1 million, or 26.7%, and $45.2 million, or 32.3%, in the three and six months ended June 30, 2019, respectively, compared to the same periods in 2018 as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. We continue to experience pricing pressure on our products and services due to competition, but demand for our products and growth in our installed base has more than offset this pricing pressure during the period. However, we experienced a slowdown in demand from certain large end customers during the second quarter of 2019, and this slowdown could continue in future periods.   In order to continue to grow our future revenue, we must continue to add new cloud data center networking customers and expand our presence in the campus switching and WiFi networking markets.

[0001596532-19-000184:mdna:20]
[same as prior period, unchanged from 0001596532-19-000104:mdna:19]

[0001596532-19-000184:mdna:21]
[same as prior period, unchanged from 0001596532-19-000104:mdna:20]

[0001596532-19-000184:mdna:22]
Cost of revenue increased $32.2 million, or 17.3%, and $77.5 million, or 21.8%, in the three and six months ended June 30,

[0001596532-19-000184:mdna:23]
2019, respectively, compared to the same periods in 2018. The increases were primarily due to the corresponding increases in product and service revenues.

[0001596532-19-000184:mdna:24]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including sales to large end customers who generally receive lower pricing, manufacturing-related costs including costs associated with supply chain sourcing activities, merchant silicon costs, the mix of products sold, and excess/obsolete inventory write-downs, including charges for excess/obsolete component inventory held by our contract manufacturers. We expect our gross margins to fluctuate over time, depending on the factors described above.

[0001596532-19-000184:mdna:25]
Gross margin decreased from 64.2% to 64.1% for the three months ended June 30, 2019 and from 64.2% to 64.0% for the six months ended June 30, 2019 compared to the same periods in 2018. The decreases were primarily driven by a decrease in product margin due to increased product transition costs including some excess and obsolete inventory-related charges, mostly offset by a favorable customer mix with lower discounts on smaller volume transactions. Service margin continued to improve due to a relatively fixed services cost base and growing service revenues.

[0001596532-19-000184:mdna:26]
[same as prior period, unchanged from 0001596532-19-000104:mdna:25]

[0001596532-19-000184:mdna:27]
[same as prior period, unchanged from 0001596532-19-000104:mdna:26]

[0001596532-19-000184:mdna:28]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |  | Change in |  | 2019 |  | 2018 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 114,295 |  |  | $ | 104,078 |  |  | $ | 10,217 |  |  | 9.8 | % |  | $ | 233,964 |  |  | $ | 206,440 |  |  | $ | 27,524 |  |  | 13.3 | % |
| Sales and marketing |  | 53,040 |  |  | 46,188 |  |  | 6,852 |  |  | 14.8 |  |  | 104,093 |  |  | 88,328 |  |  | 15,765 |  |  | 17.8 |  |
| General and administrative |  | 16,019 |  |  | 18,420 |  |  | (2,401 | ) |  | (13.0 | ) |  | 31,525 |  |  | 38,099 |  |  | (6,574 | ) |  | (17.3 | ) |
| Legal settlement |  | — |  |  | 405,000 |  |  | (405,000 | ) |  | (100.0 | ) |  | — |  |  | 405,000 |  |  | (405,000 | ) |  | (100.0 | ) |
| Total operating expenses |  | $ | 183,354 |  |  | $ | 573,686 |  |  | $ | (390,332 | ) |  | (68.0 | )% |  | $ | 369,582 |  |  | $ | 737,867 |  |  | $ | (368,285 | ) |  | (49.9 | )% |

[0001596532-19-000184:mdna:29]
[same as prior period, unchanged from 0001596532-19-000104:mdna:28]

[0001596532-19-000184:mdna:30]
[same as prior period, unchanged from 0001596532-19-000104:mdna:29]

[0001596532-19-000184:mdna:31]
Research and development expenses increased $10.2 million, or 9.8%, and $27.5 million, or 13.3%, for the three and six months ended June 30, 2019 compared to the same periods in 2018. The increases in the three and six months ended June 30, 2019 included a $6.7 million and a $17.2 million increase in personnel costs driven primarily by growth in headcount, including headcount additions from the two acquisitions we completed in the third quarter of 2018, a $2.7 million and a $5.6 million increase in new products compliance testing and certification services costs, and a $1.7 million and a $4.8 million increase in research and development-related facilities and IT costs due to headcount growth and facilities expansion.

[0001596532-19-000184:mdna:32]
[same as prior period, unchanged from 0001596532-19-000104:mdna:31]

[0001596532-19-000184:mdna:33]
[same as prior period, unchanged from 0001596532-19-000104:mdna:32]

[0001596532-19-000184:mdna:34]
Sales and marketing expenses increased $6.9 million, or 14.8%, and $15.8 million, or 17.8%, for the three and six months ended June 30, 2019 compared to the same periods in 2018. The increases in the three and six months ended June 30, 2019 included a $7.7 million and a $13.2 million increase in personnel costs due to growth in headcount and higher sales volumes, which resulted in an increase in compensation, including sales commissions.

[0001596532-19-000184:mdna:35]
[same as prior period, unchanged from 0001596532-19-000104:mdna:34]

[0001596532-19-000184:mdna:36]
General and administrative expenses consist primarily of personnel costs, professional services fees, litigation-related expenses, and an allocated portion of facility and IT costs including depreciation. General and administrative personnel costs include those for our executive, finance, human resources and legal functions. Our professional services fees are primarily due to external legal, accounting and tax services.

[0001596532-19-000184:mdna:37]
General and administrative expenses decreased $2.4 million, or 13.0%, and $6.6 million, or 17.3%, for the three and six months ended June 30, 2019 compared to the same periods in 2018. The decrease in each period was primarily due to a $3.1 million and an $8.7 million decrease in litigation fees related to a reduced level of litigation activities as a result of the settlement of our litigation with Cisco in August 2018, which was partially offset by a $0.6 million and a $1.8 million increase in personnel costs.

[0001596532-19-000184:mdna:38]
Legal settlement.

[0001596532-19-000184:mdna:39]
During the three and six months ended June 30, 2018, we recorded $405.0 million in legal settlement expenses in connection with a binding term sheet (“Term Sheet”) that was entered into on August 6, 2018 between the Company and Cisco (the “Legal Settlement”), which included a $400.0 million payment to Cisco and $5.0 million of legal fees associated with the settlement. Pursuant to the Term Sheet, the Company and Cisco obtained dismissals of all then ongoing district court and USITC litigation between us. On December 3, 2018, the parties entered into a mutual release and settlement agreement, which superseded the Term Sheet but did not substantially alter the terms.

[0001596532-19-000184:mdna:40]
[same as prior period, unchanged from 0001596532-19-000104:mdna:37]

[0001596532-19-000184:mdna:41]
[same as prior period, unchanged from 0001596532-19-000104:mdna:38]

[0001596532-19-000184:mdna:42]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |  | Change in |  | 2019 |  | 2018 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 13,107 |  |  | $ | 7,964 |  |  | $ | 5,143 |  |  | 64.6 | % |  | $ | 25,005 |  |  | $ | 13,348 |  |  | $ | 11,657 |  |  | 87.3 | % |
| Interest expense |  | — |  |  | (680 | ) |  | 680 |  |  | (100.0 | ) |  | — |  |  | (1,367 | ) |  | 1,367 |  |  | (100.0 | ) |
| Gain (loss) on investments in privately-held companies |  | — |  |  | (9,100 | ) |  | 9,100 |  |  | (100.0 | ) |  | 1,150 |  |  | (9,100 | ) |  | 10,250 |  |  | (112.6 | ) |
| Other income (expense), net |  | 704 |  |  | (353 | ) |  | 1,057 |  |  | (299.4 | ) |  | (11 | ) |  | (894 | ) |  | 883 |  |  | (98.8 | ) |
| Total other income (expense), net |  | $ | 13,811 |  |  | $ | (2,169 | ) |  | $ | 15,980 |  |  | (736.7 | )% |  | $ | 26,144 |  |  | $ | 1,987 |  |  | $ | 24,157 |  |  | 1,215.8 | % |

[0001596532-19-000184:mdna:43]
The increases in other income (expense), net, during the three and six months ended June 30, 2019 as compared to the same periods of 2018 were partially due to increases in interest income as we continued to generate cash and expand our marketable securities portfolios and favorable changes in gain (loss) on our investments in privately-held companies. See Note 5. Investments of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-19-000184:mdna:44]
[same as prior period, unchanged from 0001596532-19-000104:mdna:41]

[0001596532-19-000184:mdna:45]
[same as prior period, unchanged from 0001596532-19-000104:mdna:42]

[0001596532-19-000184:mdna:46]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |  | Change in |  | 2019 |  | 2018 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Income (loss) before income taxes |  | $ | 220,648 |  |  | $ | (241,972 | ) |  | $ | 462,620 |  |  | (191.2 | )% |  | $ | 427,323 |  |  | $ | (99,078 | ) |  | $ | 526,401 |  |  | (531.3 | )% |
| Provision for (benefit from) income taxes |  | 31,397 |  |  | (86,703 | ) |  | 118,100 |  |  | (136.2 | )% |  | 37,043 |  |  | (88,347 | ) |  | 125,390 |  |  | (141.9 | )% |
| Effective tax rate |  | 14.2 | % |  | 35.8 | % |  |  |  |  |  | 8.7 | % |  | 89.2 | % |  |  |  |  |

[0001596532-19-000184:mdna:47]
For the three and six months ended June 30, 2019, we recorded expenses of $31.4 million and $37.0 million, respectively. For the three and six months ended June 30, 2018, we recorded benefits of $86.7 million and $88.3 million, respectively. The income tax benefits for the 2018 periods included a $99.0 million federal and state tax benefit on the $405.0 million charge related to the Legal Settlement recorded in the three and six months ended June 30, 2018. In addition, the changes in our income taxes were attributable to a change in our position on sharing stock-based compensation within our cost sharing arrangement as a result of an opinion issued in June 2019. See Note 10. Income Taxes of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further information.  The remaining changes in the income taxes were attributable to the overall increase in worldwide earnings.

[0001596532-19-000184:mdna:48]
[same as prior period, unchanged from 0001596532-19-000104:mdna:45]

[0001596532-19-000184:mdna:49]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of June 30, 2019, our total balance of cash, cash equivalents and marketable securities was approximately $2.3 billion, of which approximately $318.3 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-19-000184:mdna:50]
Our cash, cash equivalents and marketable securities are held for working capital purposes. Our marketable securities investment portfolio is primarily invested in highly-rated securities with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities together with cash generated from operations will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, costs incurred related to outstanding litigation claims, and stock repurchases. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-19-000184:mdna:51]
[same as prior period, unchanged from 0001596532-19-000104:mdna:49]

[0001596532-19-000184:mdna:52]
|  |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 366,476 |  |  | $ | 326,125 |  |
| Cash used in investing activities |  | (5,510 | ) |  | (496,972 | ) |
| Cash provided by (used in) financing activities |  | (66,566 | ) |  | 23,426 |  |
| Effect of exchange rate changes |  | 72 |  |  | (607 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 294,472 |  |  | $ | (148,028 | ) |

[0001596532-19-000184:mdna:53]
[same as prior period, unchanged from 0001596532-19-000104:mdna:51]

[0001596532-19-000184:mdna:54]
During the six months ended June 30, 2019, cash provided by operating activities was $366.5 million, primarily from net income of $390.3 million and non-cash adjustments to net income of $75.8 million, offset partially by a net decrease of $99.6 million in cash from changes in our operating assets and liabilities. Our operating cash benefited primarily from a $48.9 million decrease in prepaid expenses and other current assets including a reduction in deferred cost of inventory related to recognition of product deferred revenue and a $14.4 million increase in income taxes payable.  These favorable changes were more than offset by an $85.0 million decrease in deferred revenue primarily due to the recognition of product deferred revenue related to contract acceptance terms, a $49.6 million increase in inventories primarily related to upcoming product transitions, an $11.3 million

[0001596532-19-000184:mdna:55]
increase in accounts receivable due to timing of billing and cash collections, and a $9.5 million decline in accrued liabilities due to net payments made under our corporate bonus program, and the timing of vendor payments related to product development activities and inventory purchases, partially offset by an increase in manufacturer/supplier liability accruals.

[0001596532-19-000184:mdna:56]
During the six months ended June 30, 2018, cash provided by operating activities was $326.1 million, primarily from net loss of $10.7 million with non-cash adjustments to net income of $44.7 million, and a net increase of $292.2 million in cash from changes in our operating assets and liabilities. The increase in cash from changes in operating assets and liabilities was primarily due to a $405.0 million legal settlement liability accrued in the second quarter of 2018 in connection with the Legal Settlement, a $60.8 million decrease in inventories driven by improved inventory management and timing of receipts, and a $6.7 million increase in income taxes payable. These cash inflows were partially offset by cash outflows of $72.4 million from an increase in prepaid expenses and other current assets primarily due to higher prepaid income taxes in connection with an income tax benefit associated with the Legal Settlement charges referenced above, offset partially by lower deferred costs of inventory associated with the lower product revenue deferrals referenced below, $50.1 million from a decline in deferred revenue primarily related to customer acceptance of our 945 investigation-related product redesigns, $47.2 million from a decline in accrued liabilities due to corporate bonus payments and the timing of vendor payments, and $13.6 million from an increase in accounts receivable due to timing of billing and cash collections.

[0001596532-19-000184:mdna:57]
[same as prior period, unchanged from 0001596532-19-000104:mdna:54]

[0001596532-19-000184:mdna:58]
During the six months ended June 30, 2019, cash used in investing activities was $5.5 million, consisting of purchases of available-for-sale securities of $549.4 million, offset by proceeds of $552.5 million from maturities of marketable securities, and purchases of property and equipment of $8.6 million.

[0001596532-19-000184:mdna:59]
During the six months ended June 30, 2018, cash used in investing activities was $497.0 million, consisting of purchases of available-for-sale securities of $696.7 million, offset by proceeds of $222.8 million from maturities of marketable securities, and purchases of property and equipment of $13.1 million.

[0001596532-19-000184:mdna:60]
[same as prior period, unchanged from 0001596532-19-000104:mdna:57]

[0001596532-19-000184:mdna:61]
During the six months ended June 30, 2019, cash used in financing activities was $66.6 million, consisting of payments for repurchases of our common stock from the open market of $100.0 million and minimum payroll taxes withheld of $4.7 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $38.1 million.

[0001596532-19-000184:mdna:62]
During the six months ended June 30, 2018, cash provided by financing activities was $23.4 million, consisting primarily of proceeds from the issuance of common stock under employee equity incentive plans of $28.8 million, offset by minimum tax withheld for employees of $4.5 million.

[0001596532-19-000184:mdna:63]
Stock Repurchase Program

[0001596532-19-000184:mdna:64]
From time to time, we repurchase stock opportunistically pursuant to our Repurchase Program authorized by our board of directors in April 2019. The repurchases are funded from working capital. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of June 30, 2019, the remaining authorized amount for stock repurchases under this program is approximately $900.0 million. Refer to Note 8. Equity Award Plan Activities of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-19-000184:mdna:65]
[same as prior period, unchanged from 0001596532-19-000104:mdna:60]

[0001596532-19-000184:mdna:66]
As of June 30, 2019, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-19-000184:mdna:67]
[same as prior period, unchanged from 0001596532-19-000104:mdna:62]

[0001596532-19-000184:mdna:68]
Our contractual obligations represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalent and marketable securities. As of June 30, 2019, our principal commitments consist primarily of obligations under operating leases for offices and data centers and purchase commitments with our contract manufacturers and suppliers. See Note 6. Leases and Note 7. Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for future payment commitments under leases and our purchase commitments as of June 30, 2019, respectively.

[0001596532-19-000184:mdna:69]
[same as prior period, unchanged from 0001596532-19-000104:mdna:64]

[0001596532-19-000184:mdna:70]
Our management’s discussion and analysis of financial condition and results of operations is based on our unaudited condensed consolidated financial statements, which have been prepared in accordance with GAAP.  The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. We believe the critical accounting policies and estimates discussed in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our Annual Report on Form 10-K filed with the SEC on February 15, 2019, reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting policies and estimates as disclosed in our Annual Report on Form 10-K.

[0001596532-19-000184:mdna:71]
[same as prior period, unchanged from 0001596532-19-000104:mdna:66]

[0001596532-19-000184:mdna:72]
Refer to the sections titled “Recently Adopted Accounting Pronouncements” and “Recent Accounting Pronouncements Not Yet Effective” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
