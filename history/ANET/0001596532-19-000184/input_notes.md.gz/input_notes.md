# ANET notes — 0001596532-19-000184


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-19-000184:notes:1]
[same as prior period, unchanged from 0001596532-19-000104:notes:112]

[0001596532-19-000184:notes:2]
[same as prior period, unchanged from 0001596532-19-000104:notes:113]

[0001596532-19-000184:notes:3]
[same as prior period, unchanged from 0001596532-19-000104:notes:114]

[0001596532-19-000184:notes:4]
[same as prior period, unchanged from 0001596532-19-000104:notes:115]

[0001596532-19-000184:notes:5]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2019, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2018 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant intercompany accounts and transactions have been eliminated.

[0001596532-19-000184:notes:6]
Our condensed consolidated financial statements and related financial information in this Quarterly Report on Form 10-Q should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2018, filed with the SEC on February 15, 2019.

[0001596532-19-000184:notes:7]
[same as prior period, unchanged from 0001596532-19-000104:notes:116]

[0001596532-19-000184:notes:8]
[same as prior period, unchanged from 0001596532-19-000104:notes:117]

[0001596532-19-000184:notes:9]
[same as prior period, unchanged from 0001596532-19-000104:notes:118]

[0001596532-19-000184:notes:10]
During the six months ended June 30, 2019, we adopted ASC 842 - Leases, as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1. As a result, we added a new significant accounting policy “Leases” as described below. There have been no other significant changes to our accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2018, filed with the SEC on February 15, 2019.

[0001596532-19-000184:notes:11]
Leases

[0001596532-19-000184:notes:12]
Our initial application date of ASC 842 is January 1, 2019. For the periods prior to 2019, our leases were accounted for under the legacy guidance in ASC 840.

[0001596532-19-000184:notes:13]
We determine if a contract contains a lease at inception. The lease term represents the non-cancellable period for which we have the right to use an underlying asset, which may include periods covered by certain options to extend and/or terminate the lease. Lease liabilities and corresponding right-of-use (“ROU”) assets are recognized at the commencement date of a lease. Leases with an initial lease term of 12 months or less are not recorded on the balance sheet.

[0001596532-19-000184:notes:14]
A lease liability is the present value of our future fixed lease payments. As none of our leases provides an implicit interest rate, we use our estimated incremental borrowing rate as of the lease commencement date to determine the present value of future lease payments. Our discount rates are determined and applied at a company level. An ROU asset is calculated as the lease liability, adjusted by unamortized initial direct costs, unamortized lease incentives received, cumulative deferred or prepaid lease payments, and accumulated impairment losses.

[0001596532-19-000184:notes:15]
For fixed lease payments under operating leases, lease expense is recognized on a straight-lined basis over the lease term. For variable lease payments, lease expense is recognized when incurred. For operating leases that include both lease and non-lease components, we account for lease and non-lease components as a single lease component for all classes of underlying assets and, therefore, recognize non-lease payments as lease expense.

[0001596532-19-000184:notes:16]
Recently Adopted Accounting Pronouncements

[0001596532-19-000184:notes:17]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) No. 2016-02, Leases (“ASU 2016-02”), and in July 2018, the FASB issued ASU 2018-11, Leases (Topic 842): Targeted Improvements (“ASU 2018-11”) (collectively referred to as “ASC 842”). Under the guidance, lessees are required to recognize assets and lease liabilities on the balance sheet for most leases including operating leases and provide enhanced disclosures. Companies are required to adopt this guidance using a modified retrospective approach and apply the transition provisions under the guidance at either 1) the later of the beginning of the earliest comparative period presented in the financial statements and the commencement date of the lease, or 2) the beginning of the period of adoption (i.e. on the effective date). Under the transition method using the second application date, a company initially applies the new leases standard at the adoption date and recognizes a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption.

[0001596532-19-000184:notes:18]
We adopted the guidance on January 1, 2019 using the modified retrospective transition method and initially applied the transition provisions at January 1, 2019, which allows us to continue to apply the legacy guidance in ASC 840 for periods prior to 2019. We elected the package of transition practical expedients, which, among other things, allows us to keep the historical lease classifications and not have to reassess the lease classification for any existing leases as of the date of adoption. We also made the following accounting policy elections as allowed by ASC 842:

[0001596532-19-000184:notes:19]
| • | to apply the short-term lease exception, which allows us to keep leases with an initial term of twelve months or less off the balance sheet. |

[0001596532-19-000184:notes:20]
| • | to account for each separate lease component of a contract and its associated non-lease components as a single lease component for all our leases. |

[0001596532-19-000184:notes:21]
As a result of the adoption, we recognized operating leases that were previously not recognized on the consolidated balance sheets. In addition, we derecognized the assets and the lease financing liabilities previously recorded for our headquarters building under a build-to-suit lease. Under ASC 842, this lease is recognized as an operating lease in our condensed consolidated financial statements beginning in the first quarter of 2019. The table below summarizes the impact of the adoption of ASC 842 on the condensed consolidated balance sheet as of January 1, 2019 (in thousands).

[0001596532-19-000184:notes:22]
|  |  |  |  | Adjustments for the Adoption of ASC 842 |  |  |
| Balance Sheet Line Item |  | December 31,2018 |  | Derecognition of Build-to-Suit Lease |  | Recognition of Operating Leases (1) |  | January 1,2019 |
| Property and equipment, net |  | $ | 75,355 |  |  | $ | (32,806 | ) |  | $ | — |  |  | $ | 42,549 |  |
| Operating lease right-of-use assets |  | — |  |  | — |  |  | 93,207 |  |  | 93,207 |  |
| Deferred tax assets |  | 126,492 |  |  | (1,165 | ) |  | — |  |  | 125,327 |  |
| Other current liabilities |  | 30,907 |  |  | (2,242 | ) |  | 12,391 |  |  | 41,056 |  |
| Operating lease liabilities, non-current |  | — |  |  | — |  |  | 88,230 |  |  | 88,230 |  |
| Finance lease liabilities, non-current |  | 35,431 |  |  | (35,431 | ) |  | — |  |  | — |  |
| Other long-term liabilities |  | 31,851 |  |  | — |  |  | (7,414 | ) |  | 24,437 |  |
| Retained earnings |  | 1,190,803 |  |  | 3,702 |  |  | — |  |  | 1,194,505 |  |
| __________________ |
| (1) Includes an operating lease for our corporate headquarters building under the build-to-suit arrangement, which was accounted for as a financing lease prior to 2019 and derecognized on January 1, 2019 upon the adoption of ASC 842. |

[0001596532-19-000184:notes:23]
Recent Accounting Pronouncements Not Yet Effective

[0001596532-19-000184:notes:24]
Credit Losses of Financial Instruments

[0001596532-19-000184:notes:25]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  The proposed standard requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. For trade receivables, we will be required to estimate lifetime expected credit losses. For available-for-sale debt securities, we will be required to recognize an allowance for credit losses rather than a reduction to the carrying value of the asset. In May 2019, the FASB issued ASU 2019-05, Financial Instruments—Credit Losses, Topic 326, which allows companies to make an irrevocable one-time election upon adoption of ASU 2016-13 to elect the fair value option for certain financial assets currently measured at amortized cost (except held-to-maturity securities). The election is to be applied on an instrument-by-instrument basis. ASU 2016-13 is effective for us for our first quarter of 2020. We are currently assessing the impact this guidance may have on our consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-19-000184:notes:26]
[same as prior period, unchanged from 0001596532-19-000104:notes:8]

[0001596532-19-000184:notes:27]
[same as prior period, unchanged from 0001596532-19-000104:notes:9]

[0001596532-19-000184:notes:28]
The total fair value of consideration transferred for these acquisitions was approximately $117.5 million, which consisted of $101.9 million in cash and $15.6 million for the fair value of 58,072 shares of our common stock issued. The following table summarizes our preliminary purchase price allocation of the two acquisitions, in aggregate, based on the estimated fair value of the assets acquired and liabilities assumed at their respective acquisition dates (in thousands):

[0001596532-19-000184:notes:29]
|  |  | Purchase Price Allocation |
| Cash and cash equivalents |  | $ | 4,953 |  |
| Other tangible assets |  | 23,824 |  |
| Liabilities |  | (28,706 | ) |
| Intangible assets |  | 63,720 |  |
| Goodwill |  | 53,684 |  |
| Net assets acquired |  | $ | 117,475 |  |

[0001596532-19-000184:notes:30]
[same as prior period, unchanged from 0001596532-19-000104:notes:12]

[0001596532-19-000184:notes:31]
[same as prior period, unchanged from 0001596532-19-000104:notes:13]

[0001596532-19-000184:notes:32]
[same as prior period, unchanged from 0001596532-19-000104:notes:14]

[0001596532-19-000184:notes:33]
Goodwill of $53.7 million is primarily attributable to the expected synergies created by incorporating the solutions of the acquired businesses into our technology platform, and the value of the assembled workforce. We operate under a single reportable segment. The goodwill is not deductible for income taxes purposes.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-19-000184:notes:34]
[same as prior period, unchanged from 0001596532-19-000104:notes:68]

[0001596532-19-000184:notes:35]
[same as prior period, unchanged from 0001596532-19-000104:notes:69]

[0001596532-19-000184:notes:36]
[same as prior period, unchanged from 0001596532-19-000104:notes:70]

[0001596532-19-000184:notes:37]
[same as prior period, unchanged from 0001596532-19-000104:notes:71]

[0001596532-19-000184:notes:38]
[same as prior period, unchanged from 0001596532-19-000104:notes:72]

[0001596532-19-000184:notes:39]
[same as prior period, unchanged from 0001596532-19-000104:notes:73]

[0001596532-19-000184:notes:40]
|  |  | June 30, 2019 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 518,039 |  |  | $ | — |  |  | $ | — |  |  | $ | 518,039 |  |  | $ | 518,039 |  |  | $ | — |  |  | $ | — |  |
| Agency securities |  | 3,992 |  |  | — |  |  | — |  |  | 3,992 |  |  | — |  |  | 3,992 |  |  | — |  |
| U.S. government notes |  | 3,996 |  |  | — |  |  | — |  |  | 3,996 |  |  | 3,996 |  |  | — |  |  | — |  |
|  |  | 526,027 |  |  | — |  |  | — |  |  | 526,027 |  |  | 522,035 |  |  | 3,992 |  |  | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | 658,913 |  |  | 2,863 |  |  | (33 | ) |  | 661,743 |  |  | — |  |  | 661,743 |  |  | — |  |
| U.S. government notes |  | 342,004 |  |  | 834 |  |  | (11 | ) |  | 342,827 |  |  | 342,827 |  |  | — |  |  | — |  |
| Agency securities |  | 269,193 |  |  | 864 |  |  | (28 | ) |  | 270,029 |  |  | — |  |  | 270,029 |  |  | — |  |
| Commercial paper |  | 35,790 |  |  | — |  |  | — |  |  | 35,790 |  |  | — |  |  | 35,790 |  |  | — |  |
| Certificates of deposits (1) |  | 3,000 |  |  | — |  |  | — |  |  | 3,000 |  |  | — |  |  | 3,000 |  |  | — |  |
|  |  | 1,308,900 |  |  | 4,561 |  |  | (72 | ) |  | 1,313,389 |  |  | 342,827 |  |  | 970,562 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,222 |  |  | — |  |  | — |  |  | 4,222 |  |  | 4,222 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 1,839,149 |  |  | $ | 4,561 |  |  | $ | (72 | ) |  | $ | 1,843,638 |  |  | $ | 869,084 |  |  | $ | 974,554 |  |  | $ | — |  |

[0001596532-19-000184:notes:41]
|  |  | December 31, 2018 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 322,080 |  |  | $ | — |  |  | $ | — |  |  | $ | 322,080 |  |  | $ | 322,080 |  |  | $ | — |  |  | $ | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | 660,353 |  |  | 264 |  |  | (1,399 | ) |  | 659,218 |  |  | — |  |  | 659,218 |  |  | — |  |
| U.S. government notes |  | 308,946 |  |  | 118 |  |  | (286 | ) |  | 308,778 |  |  | 308,778 |  |  | — |  |  | — |  |
| Agency securities |  | 273,993 |  |  | 240 |  |  | (511 | ) |  | 273,722 |  |  | — |  |  | 273,722 |  |  | — |  |
| Commercial paper |  | 59,479 |  |  | — |  |  | — |  |  | 59,479 |  |  | — |  |  | 59,479 |  |  | — |  |
| Certificates of deposits (1) |  | 5,000 |  |  | — |  |  | — |  |  | 5,000 |  |  | — |  |  | 5,000 |  |  | — |  |
|  |  | 1,307,771 |  |  | 622 |  |  | (2,196 | ) |  | 1,306,197 |  |  | 308,778 |  |  | 997,419 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,214 |  |  | — |  |  | — |  |  | 4,214 |  |  | 4,214 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 1,634,065 |  |  | $ | 622 |  |  | $ | (2,196 | ) |  | $ | 1,632,491 |  |  | $ | 635,072 |  |  | $ | 997,419 |  |  | $ | — |  |

[0001596532-19-000184:notes:42]
______________________

[0001596532-19-000184:notes:43]
(1) As of June 30, 2019 and December 31, 2018, all of our certificates of deposits were domestic deposits.

[0001596532-19-000184:notes:44]
We did not realize any other-than-temporary losses on our marketable securities for the three and six months ended June 30, 2019 and 2018. As of June 30, 2019 and December 31, 2018, total unrealized losses of our marketable securities that had been in a continuous unrealized loss position were immaterial. We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. As interest rates increase, those marketable securities purchased at a time with lower interest rates show a mark-to-market unrealized loss. We expect to realize the full value of these investments upon maturity or sale and therefore, we do not consider any of our marketable securities to be other-than-temporarily impaired as of June 30, 2019.

[0001596532-19-000184:notes:45]
As of June 30, 2019, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale marketable securities, by remaining contractual maturity, are as follows (in thousands):

[0001596532-19-000184:notes:46]
|  |  | June 30, 2019 |
| Due in 1 year or less |  | $ | 932,285 |  |
| Due in 1 year through 2 years |  | 381,104 |  |
| Total marketable securities |  | $ | 1,313,389 |  |

[0001596532-19-000184:notes:47]
The weighted-average remaining duration of our current marketable securities is approximately 0.8 years as of June 30, 2019.  As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying unaudited condensed consolidated balance sheets.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-19-000184:notes:48]
[same as prior period, unchanged from 0001596532-19-000104:notes:145]

[0001596532-19-000184:notes:49]
[same as prior period, unchanged from 0001596532-19-000104:notes:146]

[0001596532-19-000184:notes:50]
The following table is a reconciliation of cash, cash equivalents and restricted cash reported within the accompanying condensed consolidated balance sheets that sum to the total of the same such amounts shown in the accompanying condensed consolidated statements of cash flows (in thousands):

[0001596532-19-000184:notes:51]
|  |  | June 30, 2019 |  | June 30, 2018 |
| Cash and cash equivalents |  | $ | 944,414 |  |  | $ | 711,157 |  |
| Restricted cash included in other assets |  | 4,222 |  |  | 5,512 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 948,636 |  |  | $ | 716,669 |  |

[0001596532-19-000184:notes:52]
Restricted cash included in other assets as of June 30, 2019 and June 30, 2018 primarily included $4.0 million pledged as collateral representing a security deposit required for a facility lease.  In addition, restricted cash included in other assets as of June 30, 2018 included $1.1 million related to a letter of credit issued to a business partner.

[0001596532-19-000184:notes:53]
[same as prior period, unchanged from 0001596532-19-000104:notes:148]

[0001596532-19-000184:notes:54]
Accounts receivable, net consists of the following (in thousands):

[0001596532-19-000184:notes:55]
|  |  | June 30, 2019 |  | December 31, 2018 |
| Accounts receivable |  | $ | 350,568 |  |  | $ | 340,897 |  |
| Allowance for doubtful accounts |  | (837 | ) |  | (507 | ) |
| Product sales rebate and returns reserve |  | (6,651 | ) |  | (8,613 | ) |
| Accounts receivable, net |  | $ | 343,080 |  |  | $ | 331,777 |  |

[0001596532-19-000184:notes:56]
[same as prior period, unchanged from 0001596532-19-000104:notes:149]

[0001596532-19-000184:notes:57]
Inventories consist of the following (in thousands):

[0001596532-19-000184:notes:58]
|  |  | June 30, 2019 |  | December 31, 2018 |
| Raw materials |  | $ | 105,639 |  |  | $ | 76,795 |  |
| Finished goods |  | 208,538 |  |  | 187,762 |  |
| Total inventories |  | $ | 314,177 |  |  | $ | 264,557 |  |

[0001596532-19-000184:notes:59]
[same as prior period, unchanged from 0001596532-19-000104:notes:150]

[0001596532-19-000184:notes:60]
Prepaid expenses and other current assets consists of the following (in thousands):

[0001596532-19-000184:notes:61]
|  |  | June 30, 2019 |  | December 31, 2018 |
| Prepaid income taxes |  | $ | 43,464 |  |  | $ | 38,636 |  |
| Inventory deposit |  | 14,250 |  |  | 14,639 |  |
| Other current assets |  | 43,665 |  |  | 95,730 |  |
| Other prepaid expenses and deposits |  | 12,079 |  |  | 13,316 |  |
| Total prepaid expenses and other current assets |  | $ | 113,458 |  |  | $ | 162,321 |  |

[0001596532-19-000184:notes:62]
[same as prior period, unchanged from 0001596532-19-000104:notes:151]

[0001596532-19-000184:notes:63]
Property and equipment, net consists of the following (in thousands):

[0001596532-19-000184:notes:64]
|  |  | June 30, 2019 |  | December 31, 2018 |
| Equipment and machinery |  | $ | 59,720 |  |  | $ | 55,912 |  |
| Computer hardware and software |  | 33,229 |  |  | 30,566 |  |
| Leasehold improvements |  | 31,402 |  |  | 36,447 |  |
| Furniture and fixtures |  | 3,736 |  |  | 3,697 |  |
| Building |  | — |  |  | 35,154 |  |
| Construction-in-process |  | 959 |  |  | 3,591 |  |
| Property and equipment, gross |  | 129,046 |  |  | 165,367 |  |
| Less: accumulated depreciation |  | (88,023 | ) |  | (90,012 | ) |
| Property and equipment, net |  | $ | 41,023 |  |  | $ | 75,355 |  |

[0001596532-19-000184:notes:65]
[same as prior period, unchanged from 0001596532-19-000104:notes:152]

[0001596532-19-000184:notes:66]
Depreciation expense was $4.8 million and $5.4 million for the three months ended June 30, 2019 and 2018, respectively, and $9.5 million and $10.7 million for the six months ended June 30, 2019 and 2018, respectively.

[0001596532-19-000184:notes:67]
[same as prior period, unchanged from 0001596532-19-000104:notes:154]

[0001596532-19-000184:notes:68]
Accrued liabilities consist of the following (in thousands):

[0001596532-19-000184:notes:69]
|  |  | June 30, 2019 |  | December 31, 2018 |
| Accrued payroll related costs |  | $ | 55,957 |  |  | $ | 70,755 |  |
| Accrued manufacturing costs |  | 30,318 |  |  | 31,336 |  |
| Accrued product development costs |  | 12,189 |  |  | 6,988 |  |
| Accrued professional fees |  | 6,312 |  |  | 5,678 |  |
| Accrued warranty costs |  | 5,074 |  |  | 5,362 |  |
| Other |  | 4,048 |  |  | 3,135 |  |
| Total accrued liabilities |  | $ | 113,898 |  |  | $ | 123,254 |  |

[0001596532-19-000184:notes:70]
[same as prior period, unchanged from 0001596532-19-000104:notes:155]

[0001596532-19-000184:notes:71]
The following table summarizes the activity related to our accrued liability for estimated future warranty costs (in thousands):

[0001596532-19-000184:notes:72]
|  |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |
| Warranty accrual, beginning of period |  | $ | 5,362 |  |  | $ | 7,415 |  |
| Liabilities accrued for warranties issued during the period |  | 2,082 |  |  | 3,813 |  |
| Warranty costs incurred during the period |  | (2,370 | ) |  | (3,046 | ) |
| Warranty accrual, end of period |  | $ | 5,074 |  |  | $ | 8,182 |  |

[0001596532-19-000184:notes:73]
[same as prior period, unchanged from 0001596532-19-000104:notes:156]

[0001596532-19-000184:notes:74]
The following table summarizes the activity related to our contract assets (in thousands):

[0001596532-19-000184:notes:75]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Contract assets, beginning balance |  | $ | 5,699 |  |  | $ | — |  |  | $ | 6,341 |  |  | $ | — |  |
| Contract assets, ending balance |  | 1,668 |  |  | 6,959 |  |  | 1,668 |  |  | 6,959 |  |

[0001596532-19-000184:notes:76]
The following table summarizes the activity related to our contract liabilities (in thousands):

[0001596532-19-000184:notes:77]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Contract liabilities, beginning balance |  | $ | 37,314 |  |  | $ | 18,838 |  |  | $ | 32,595 |  |  | $ | 16,521 |  |
| Less: Revenue recognized from beginning balance |  | (3,552 | ) |  | (1,933 | ) |  | (6,766 | ) |  | (4,070 | ) |
| Less: Beginning balance reclassified to deferred revenue |  | (1,593 | ) |  | (906 | ) |  | (1,205 | ) |  | (731 | ) |
| Add: Contract liabilities recognized |  | 9,857 |  |  | 5,843 |  |  | 17,402 |  |  | 10,122 |  |
| Contract liabilities, ending balance |  | $ | 42,026 |  |  | $ | 21,842 |  |  | $ | 42,026 |  |  | $ | 21,842 |  |

[0001596532-19-000184:notes:78]
As of June 30, 2019 and December 31, 2018, $16.7 million and $13.5 million of our contract liabilities, respectively, was included in “Other current liabilities” with the remaining balances included in “Other long-term liabilities”.

[0001596532-19-000184:notes:79]
[same as prior period, unchanged from 0001596532-19-000104:notes:158]

[0001596532-19-000184:notes:80]
Deferred revenue is comprised mainly of unearned revenue related to multi-year PCS contracts, services and product deferrals related to acceptance clauses. The following table summarizes the activity related to our deferred revenue (in thousands):

[0001596532-19-000184:notes:81]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Deferred revenue, beginning balance (1) |  | $ | 536,471 |  |  | $ | 456,054 |  |  | $ | 587,227 |  |  | $ | 498,740 |  |
| Less: Revenue recognized from beginning balance |  | (119,542 | ) |  | (112,998 | ) |  | (253,616 | ) |  | (238,557 | ) |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 85,289 |  |  | 105,588 |  |  | 168,607 |  |  | 188,461 |  |
| Deferred revenue, ending balance |  | $ | 502,218 |  |  | $ | 448,644 |  |  | $ | 502,218 |  |  | $ | 448,644 |  |
| ______________________ |  |  |  |  |  |  |  |  |
| (1) The beginning balance of the six months ended June 30, 2018 excludes $16.5 million that was reclassified to other current liabilities and other long-term liabilities at January 1, 2018 as a result of our adoption of ASC 606. |

[0001596532-19-000184:notes:82]
[same as prior period, unchanged from 0001596532-19-000104:notes:159]

[0001596532-19-000184:notes:83]
Revenue from remaining performance obligations represents contracted revenue that has not yet been recognized, which includes contract liabilities and deferred revenue that will be recognized as revenue in future periods. As of June 30, 2019, approximately $545.7 million of revenue is expected to be recognized from remaining performance obligations. We expect to recognize revenue on approximately 83% of these remaining performance obligations over the next 2 years and 17% during the 3rd to the 5th year.

[0001596532-19-000184:notes:84]
[same as prior period, unchanged from 0001596532-19-000104:notes:161]

[0001596532-19-000184:notes:85]
Other income (expense), net consists of the following (in thousands):

[0001596532-19-000184:notes:86]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Interest income |  | $ | 13,107 |  |  | $ | 7,964 |  |  | $ | 25,005 |  |  | $ | 13,348 |  |
| Interest expense |  | — |  |  | (680 | ) |  | — |  |  | (1,367 | ) |
| Gain (loss) on investment in privately-held companies |  | — |  |  | (9,100 | ) |  | 1,150 |  |  | (9,100 | ) |
| Other income (expense), net |  | 704 |  |  | (353 | ) |  | (11 | ) |  | (894 | ) |
| Total |  | $ | 13,811 |  |  | $ | (2,169 | ) |  | $ | 26,144 |  |  | $ | 1,987 |  |

[0001596532-19-000184:notes:87]
Upon the adoption of ASC 842 on January 1, 2019, we derecognized the lease financing obligation associated with a build-to-suit lease, and therefore did not incur interest expense in the three and six months ended June 30, 2019. See Note 1 for further details.


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-19-000184:notes:88]
[same as prior period, unchanged from 0001596532-19-000104:notes:82]

[0001596532-19-000184:notes:89]
[same as prior period, unchanged from 0001596532-19-000104:notes:83]

[0001596532-19-000184:notes:90]
Our investments are in the equity of privately-held companies, which do not have readily determinable fair values. The following table summarizes cost, impairments and/or downward adjustments, upward adjustments, and carrying value of our investments in privately-held companies held as of June 30, 2019 and December 31, 2018 (in thousands):

[0001596532-19-000184:notes:91]
|  |  | June 30, 2019 |  | December 31, 2018 |
| Cost of investment |  | $ | 44,136 |  |  | $ | 44,136 |  |
| Cumulative impairment |  | (15,000 | ) |  | (15,000 | ) |
| Cumulative upward adjustment |  | 2,350 |  |  | 1,200 |  |
| Carrying amount of investment |  | $ | 31,486 |  |  | $ | 30,336 |  |

[0001596532-19-000184:notes:92]
As of June 30, 2019 and December 31, 2018, the portion of the carrying amount of the investments that have been remeasured to fair value as a result of impairment or observable transactions totaled $26.5 million and $22.3 million, respectively, and are classified within Level III of the fair value hierarchy.

[0001596532-19-000184:notes:93]
During the three months ended June 30, 2019, there were no realized or unrealized gains/losses recorded. During the six months ended June 30, 2019, we recorded $1.2 million of unrealized gains. During the three and six months ended June 30, 2018, we also recorded $1.2 million of unrealized gains.  These unrealized gains were recorded on investments that were re-measured to fair value as of the date observable transactions occurred. In addition, during the three and six months ended June 30, 2018, we recorded an impairment of $10.3 million on one of our investments. These unrealized gains and losses are classified in "Other income (expense), net" in our accompanying unaudited condensed consolidated statements of operations.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001596532-19-000184:notes:94]
6.    Leases

[0001596532-19-000184:notes:95]
Operating Leases

[0001596532-19-000184:notes:96]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2028. Some of our leases include options to extend the term of such leases for a period from three months to up to 10 years and/or options to early terminate the leases. As of June 30, 2019, we did not include any such options in determining the lease terms because we were not reasonably certain that we would exercise those options. Most of our leases require us to pay certain operating expenses in addition to base rent, such as taxes, repairs, and insurance and contain renewal and escalation clauses.

[0001596532-19-000184:notes:97]
Build-to-Suit Lease

[0001596532-19-000184:notes:98]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013. Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction, we were deemed the accounting owner of the building during the construction period in accordance with ASC 840. As a result, we recognized assets under construction and corresponding liabilities on the consolidated balance sheet. Upon completion of the construction in 2013, we concluded that we had forms of continued economic involvement in the facility, and therefore did not meet with the provisions for sale-leaseback accounting. Pursuant to ASC 840, we continued to carry the assets and liabilities capitalized during the construction period and accounted for the lease as a capital lease for the building and an operating lease for the underlying land.

[0001596532-19-000184:notes:99]
Upon our adoption of ASC 842 on January 1, 2019 (see Note 1), we derecognized the assets and the lease financing liabilities recorded for the building. The build-to-suit lease was re-classified as an operating lease effective January 1, 2019 in accordance with ASC 842.

[0001596532-19-000184:notes:100]
The following table summarizes the supplemental balance sheet information related to our operating leases as of June 30, 2019 (in thousands).

[0001596532-19-000184:notes:101]
|  |  | Financial Statement Classification |  | June 30, 2019 |
| Right-of-use assets: |  |  |  |  |
| Operating lease right-of-use assets |  | Operating lease right-of-use assets |  | $ | 94,203 |  |
| Lease liabilities: |  |  |  |  |
| Operating lease liabilities, current |  | Other current liabilities |  | 14,666 |  |
| Operating lease liabilities, non-current |  | Operating lease liabilities, non-current |  | 89,705 |  |
| Total operating lease liabilities |  |  |  | $ | 104,371 |  |

[0001596532-19-000184:notes:102]
The following table summarizes our lease costs for the three and six months ended June 30, 2019 (in thousands).

[0001596532-19-000184:notes:103]
|  |  | Financial Statement Classification |  | Three Months Ended June 30, 2019 |  | Six Months Ended June 30, 2019 |
| Operating lease costs: |  |  |  |  |  |  |
| Fixed lease costs |  | Operating expenses |  | $ | 5,615 |  |  | $ | 11,098 |  |
| Variable lease costs |  | Operating expenses |  | 1,531 |  |  | 2,995 |  |
| Total operating lease costs |  |  |  | $ | 7,146 |  |  | $ | 14,093 |  |

[0001596532-19-000184:notes:104]
The operating lease costs in the table above include costs for long-term leases and short-term leases. Total short-term lease costs were immaterial. Fixed lease costs include expenses recognized for base rent payments on a straight-lined basis. Variable lease costs primarily include maintenance, utilities and operating expenses that are incremental to the fixed base rent payments, and are excluded from the calculation of operating lease liabilities and ROU assets.  For the three and six months ended June 30, 2019, cash paid for amounts associated with our operating lease liabilities were approximately $4.6 million and $9.0 million, respectively, which were classified as operating activities in the condensed consolidated statements of cash flows.

[0001596532-19-000184:notes:105]
Prior to 2019, we recognized rent expense for our operating leases under the legacy guidance ASC 840. For the three and six months ended June 30, 2018, rent expense for all operating leases amounted to $2.9 million and $5.7 million, respectively, and did not include maintenance, utilities and other operating expenses in accordance with ASC 840.

[0001596532-19-000184:notes:106]
The following table shows our undiscounted future fixed payment obligations under our recognized operating leases and a reconciliation to the operating lease liabilities as of June 30, 2019 (in thousands).

[0001596532-19-000184:notes:107]
|  |  | June 30, 2019 |
| Remainder of 2019 |  | $ | 9,458 |  |
| 2020 |  | 20,042 |  |
| 2021 |  | 20,800 |  |
| 2022 |  | 21,153 |  |
| 2023 |  | 17,498 |  |
| 2024 and thereafter |  | 35,870 |  |
| Total future fixed operating lease payments |  | 124,821 |  |
| Less: |  |  |
| Imputed interest |  | (20,450 | ) |
| Total operating lease liabilities |  | $ | 104,371 |  |

[0001596532-19-000184:notes:108]
|  |  | June 30, 2019 |
| Weighted-average remaining lease term — operating leases |  | 6.2 years |
| Weighted-average discount rate — operating leases |  | 5.1% |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-19-000184:notes:109]
7.    Commitments and Contingencies

[0001596532-19-000184:notes:110]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2028. See Note 6 for our future minimum payment obligations under our leases as of June 30, 2019.

[0001596532-19-000184:notes:111]
Purchase Commitments

[0001596532-19-000184:notes:112]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of June 30, 2019, we had non-cancellable purchase commitments of $230.9 million, of which $208.8 million was to our contract manufacturers and suppliers. In addition, we have provided deposits to secure our obligations to purchase inventory. We had $17.0 million and $17.4 million in deposits as of June 30, 2019 and December 31, 2018, respectively. These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.

[0001596532-19-000184:notes:113]
Guarantees

[0001596532-19-000184:notes:114]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-19-000184:notes:115]
Legal Proceedings

[0001596532-19-000184:notes:116]
OptumSoft, Inc. Matters

[0001596532-19-000184:notes:117]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating

[0001596532-19-000184:notes:118]
system pursuant to the terms of a 2004 agreement between the companies; and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-19-000184:notes:119]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft access to our software for evaluation by OptumSoft; (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches; (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers; (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us; and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors, who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dated July 28, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.

[0001596532-19-000184:notes:120]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we asserted our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we asserted that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We asked the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also asserted that, even if we are found not to own certain components, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation. On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have meritorious defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-19-000184:notes:121]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II, including the application of the Court’s interpretation of the 2004 agreement to any other source code that OptumSoft claims to own and the trade secret misappropriation and confidentiality claims. The Court has agreed to vacate the trial date pending the parties’ efforts to settle the issues in dispute in the Phase II trial.

[0001596532-19-000184:notes:122]
We intend to vigorously defend against any claims brought against us by OptumSoft.  However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor.  For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft.  If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license.  An adverse litigation ruling could result in a significant damages award against us and injunctive relief. In addition, OptumSoft could assert additional or different claims against us, including claims that our license from OptumSoft is invalid.

[0001596532-19-000184:notes:123]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated.  However, the outcome of litigation is inherently uncertain. Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-19-000184:notes:124]
Other Matters

[0001596532-19-000184:notes:125]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-19-000184:notes:126]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of June 30, 2019, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results

[0001596532-19-000184:notes:127]
of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-19-000184:notes:128]
8.    Stockholders’ Equity

[0001596532-19-000184:notes:129]
Stock Repurchase Program

[0001596532-19-000184:notes:130]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the “Repurchase Program”).  This authorization allows us to repurchase shares of our common stock opportunistically and will be funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), or a combination of the foregoing. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of June 30, 2019, the remaining authorized amount for stock repurchases under this program was approximately $900.0 million.

[0001596532-19-000184:notes:131]
A summary of the stock repurchase activity under the Repurchase Program for the three and six months ended June 30, 2019 is as follows (in thousands, except per share amounts):

[0001596532-19-000184:notes:132]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | June 30, 2019 |  | June 30, 2019 |
| Aggregate purchase price |  | $ | 100,008 |  |  | $ | 100,008 |  |
| Shares repurchased |  | 407 |  |  | 407 |  |
| Average price paid per share |  | $ | 245.95 |  |  | $ | 245.95 |  |

[0001596532-19-000184:notes:133]
The aggregate purchase price of repurchased shares of our common stock is recorded as a reduction to retained earnings.  All shares repurchased under the Repurchase Program have been retired.

[0001596532-19-000184:notes:134]
Equity Award Plan Activities

[0001596532-19-000184:notes:135]
[same as prior period, unchanged from 0001596532-19-000104:notes:41]

[0001596532-19-000184:notes:136]
Effective January 1, 2019, our board of directors authorized an increase of 756,679 shares to shares available for issuance under our 2014 Employee Stock Purchase Plan (the “ESPP”).  Pursuant to the ESPP, the 2019 share increase was determined based the lesser of 1% of the total shares of common stock outstanding on December 31, 2018, 2,500,000 shares, or such amount as determined by our board of directors. During the three months ended June 30, 2019, we issued 45,743 shares at a weighted-average purchase price of $190.31 per share, respectively, under the ESPP. As of June 30, 2019, there remained 3,244,374 shares available for issuance under the ESPP.

[0001596532-19-000184:notes:137]
[same as prior period, unchanged from 0001596532-19-000104:notes:43]

[0001596532-19-000184:notes:138]
[same as prior period, unchanged from 0001596532-19-000104:notes:44]

[0001596532-19-000184:notes:139]
|  |  | Options Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding |
| Balance—December 31, 2018 |  | 5,899 |  |  | $ | 37.09 |  |  | 5.2 |  | $ | 1,027,741 |  |
| Options granted |  | 76 |  |  | 226.53 |  |  |  |  |  |
| Options exercised |  | (1,000 | ) |  | 29.39 |  |  |  |  |  |
| Options canceled |  | (14 | ) |  | 32.22 |  |  |  |  |  |
| Balance—June 30, 2019 |  | 4,961 |  |  | $ | 41.57 |  |  | 4.8 |  | $ | 1,081,820 |  |
| Vested and exercisable—June 30, 2019 |  | 2,628 |  |  | $ | 26.75 |  |  | 4.3 |  | $ | 612,008 |  |

[0001596532-19-000184:notes:140]
[same as prior period, unchanged from 0001596532-19-000104:notes:46]

[0001596532-19-000184:notes:141]
[same as prior period, unchanged from 0001596532-19-000104:notes:47]

[0001596532-19-000184:notes:142]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2018 |  | 1,308 |  |  | $ | 150.60 |  |  | 1.5 |  | $ | 275,638 |  |
| RSUs granted |  | 268 |  |  | 245.20 |  |  |  |  |  |
| RSUs vested |  | (266 | ) |  | 114.91 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (34 | ) |  | 184.47 |  |  |  |  |  |
| Unvested balance—June 30, 2019 |  | 1,276 |  |  | $ | 176.99 |  |  | 1.7 |  | $ | 331,178 |  |

[0001596532-19-000184:notes:143]
[same as prior period, unchanged from 0001596532-19-000104:notes:49]

[0001596532-19-000184:notes:144]
The following table presents the stock activity and the total number of shares available for grant under the 2014 Plan as of June 30, 2019 (in thousands):

[0001596532-19-000184:notes:145]
|  |  | Number of Shares |
| Balance—December 31, 2018 |  | 15,386 |  |
| Options granted |  | (76 | ) |
| RSUs granted |  | (268 | ) |
| Options canceled |  | 14 |  |
| RSUs forfeited |  | 34 |  |
| Shares traded for taxes |  | 18 |  |
| Balance—June 30, 2019 |  | 15,108 |  |

[0001596532-19-000184:notes:146]
[same as prior period, unchanged from 0001596532-19-000104:notes:50]

[0001596532-19-000184:notes:147]
[same as prior period, unchanged from 0001596532-19-000104:notes:51]

[0001596532-19-000184:notes:148]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Cost of revenue |  | $ | 1,028 |  |  | $ | 1,236 |  |  | $ | 2,126 |  |  | $ | 2,438 |  |
| Research and development |  | 12,568 |  |  | 11,745 |  |  | 25,699 |  |  | 22,690 |  |
| Sales and marketing |  | 7,097 |  |  | 6,274 |  |  | 13,631 |  |  | 12,234 |  |
| General and administrative |  | 3,604 |  |  | 3,223 |  |  | 7,132 |  |  | 5,967 |  |
| Total stock-based compensation |  | $ | 24,297 |  |  | $ | 22,478 |  |  | $ | 48,588 |  |  | $ | 43,329 |  |

[0001596532-19-000184:notes:149]
As of June 30, 2019, unrecognized stock-based compensation expenses by award type and their expected weighted-average recognition periods are summarized in the following table (in thousands, except years).

[0001596532-19-000184:notes:150]
|  |  | June 30, 2019 |
|  |  | Stock Option |  | RSU |  | ESPP |  | Restricted Stock |
| Unrecognized stock-based compensation expense |  | $ | 53,788 |  |  | $ | 203,793 |  |  | $ | 4,681 |  |  | $ | 4,665 |  |
| Weighted-average amortization period |  | 3.6 years |  |  | 3.5 years |  |  | 0.9 years |  |  | 3.2 years |  |


## us-gaap:EarningsPerShareTextBlock

[0001596532-19-000184:notes:151]
9.    Net Income (Loss) Per Share Available to Common Stock

[0001596532-19-000184:notes:152]
The following table sets forth the computation of our basic and diluted net income (loss) per share available to common stock (in thousands, except per share amounts):

[0001596532-19-000184:notes:153]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Numerator: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 189,251 |  |  | $ | (155,269 | ) |  | $ | 390,280 |  |  | $ | (10,731 | ) |
| Less: undistributed earnings allocated to participating securities |  | (99 | ) |  | 82 |  |  | (217 | ) |  | 6 |  |
| Net income (loss) available to common stockholders, basic |  | $ | 189,152 |  |  | $ | (155,187 | ) |  | $ | 390,063 |  |  | $ | (10,725 | ) |
| Diluted: |  |  |  |  |  |  |  |  |
| Net income (loss) attributable to common stockholders, basic |  | $ | 189,152 |  |  | $ | (155,187 | ) |  | $ | 390,063 |  |  | $ | (10,725 | ) |
| Add: undistributed earnings allocated to participating securities |  | 6 |  |  | — |  |  | 13 |  |  | — |  |
| Net income (loss) attributable to common stockholders, diluted |  | $ | 189,158 |  |  | $ | (155,187 | ) |  | $ | 390,076 |  |  | $ | (10,725 | ) |
| Denominator: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income (loss) per share available to common stockholders, basic |  | 76,552 |  |  | 74,503 |  |  | 76,238 |  |  | 74,250 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income (loss) per share available to common stockholders, basic |  | 76,552 |  |  | 74,503 |  |  | 76,238 |  |  | 74,250 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Stock options and RSUs |  | 4,775 |  |  | — |  |  | 5,025 |  |  | — |  |
| Employee stock purchase plan |  | 8 |  |  | — |  |  | 8 |  |  | — |  |
| Weighted-average shares used in computing net income (loss) per share available to common stockholders, diluted |  | 81,335 |  |  | 74,503 |  |  | 81,271 |  |  | 74,250 |  |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.47 |  |  | $ | (2.08 | ) |  | $ | 5.12 |  |  | $ | (0.14 | ) |
| Diluted |  | $ | 2.33 |  |  | $ | (2.08 | ) |  | $ | 4.80 |  |  | $ | (0.14 | ) |

[0001596532-19-000184:notes:154]
The following weighted-average outstanding shares of common stock equivalents were excluded from the computation of diluted net income (loss) per share available to common stockholders for the periods presented because including them would have been anti-dilutive (in thousands):

[0001596532-19-000184:notes:155]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Stock options and RSUs to purchase common stock |  | 195 |  |  | 8,011 |  |  | 179 |  |  | 8,168 |  |
| Employee stock purchase plan |  | 31 |  |  | 145 |  |  | 68 |  |  | 132 |  |
| Total |  | 226 |  |  | 8,156 |  |  | 247 |  |  | 8,300 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-19-000184:notes:156]
[same as prior period, unchanged from 0001596532-19-000104:notes:78]

[0001596532-19-000184:notes:157]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Income (loss) before income taxes |  | $ | 220,648 |  |  | $ | (241,972 | ) |  | $ | 427,323 |  |  | $ | (99,078 | ) |
| Provision for (benefit from) income taxes |  | 31,397 |  |  | (86,703 | ) |  | $ | 37,043 |  |  | $ | (88,347 | ) |
| Effective tax rate |  | 14.2 | % |  | 35.8 | % |  | 8.7 | % |  | 89.2 | % |

[0001596532-19-000184:notes:158]
The effective tax rates above reflect tax expense recorded on pre-tax income in the three and six months ended June 30, 2019 and overall tax benefits recorded on pre-tax income in the three and six months ended June 30, 2018. The change in effective tax rate in the three and six months ended June 30, 2019, as compared to the same periods in 2018, is a result of the significant benefit on the $405 million charge related to the legal settlement recorded in the three and six months ended June 30, 2018 and to the overall increase in worldwide earnings, which proportionally exceeded the increase in excess tax benefits attributable to equity compensation.
On June 7, 2019, the Court of Appeals for the Ninth Circuit issued an opinion on Altera Corporation and Subsidiaries vs. Commissioner on Internal Revenue (“Opinion”). The Opinion overturned the Tax Court decision and ruled in favor of the Commissioner validating the Regulations requiring stock-based compensation to be included in a cost sharing arrangement. As a result of the Opinion, we have changed our position and determined it is more likely than not that these Regulations are valid. As such, we have accounted for the impact of the decision in the three months ended June 30, 2019 resulting in a discrete income tax expense of $9.8 million.  Further, the estimated annual effective tax rate for the year ending December 31, 2019 includes the estimated impact of sharing stock-based compensation within our cost sharing arrangement.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-19-000184:notes:159]
[same as prior period, unchanged from 0001596532-19-000104:notes:140]

[0001596532-19-000184:notes:160]
[same as prior period, unchanged from 0001596532-19-000104:notes:141]

[0001596532-19-000184:notes:161]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Americas |  | $ | 446,370 |  |  | $ | 377,460 |  |  | $ | 886,008 |  |  | $ | 692,958 |  |
| Europe, Middle East and Africa |  | 112,060 |  |  | 101,811 |  |  | 223,329 |  |  | 223,697 |  |
| Asia-Pacific |  | 49,891 |  |  | 40,574 |  |  | 94,408 |  |  | 75,679 |  |
| Total revenue |  | $ | 608,321 |  |  | $ | 519,845 |  |  | $ | 1,203,745 |  |  | $ | 992,334 |  |

[0001596532-19-000184:notes:162]
Long-lived assets, excluding intercompany receivables, investments in subsidiaries, privately-held equity investments and deferred tax assets, net by location are summarized as follows (in thousands):

[0001596532-19-000184:notes:163]
|  |  | June 30, 2019 |  | December 31, 2018 |
| United States |  | $ | 35,108 |  |  | $ | 69,238 |  |
| International |  | 5,915 |  |  | 6,117 |  |
| Total |  | $ | 41,023 |  |  | $ | 75,355 |  |
