# ANET 8-K — 0001596532-19-000181 filed 2019-08-01

## item codes, every 8-K on or before 2019-08-02

- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2019-08-02

- none on or before 2019-08-02

## item 2.02 — earnings release, exhibit 99.1

[0001596532-19-000181:8k_2_02:1]
EX-99.1
2
ex991q219-earningsrelease.htm
EXHIBIT 99.1

[0001596532-19-000181:8k_2_02:2]
Exhibit

[0001596532-19-000181:8k_2_02:3]
Exhibit 99.1

[0001596532-19-000181:8k_2_02:4]
Arista Networks, Inc. Reports Second Quarter 2019 Financial Results

[0001596532-19-000181:8k_2_02:5]
Places in the Cloud Networking Growth Continues with Record Earnings and Revenue

[0001596532-19-000181:8k_2_02:6]
SANTA CLARA, Calif.- August 1, 2019 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven, cloud networking solutions for large datacenter and campus environments, today announced financial results for its second quarter ended June 30, 2019.

[0001596532-19-000181:8k_2_02:7]
Second Quarter Financial Highlights

[0001596532-19-000181:8k_2_02:8]
| • | Revenue of $608.3 million, an increase of 2.2% compared to the first quarter of 2019, and an increase of 17.0% from the second quarter of 2018. |

[0001596532-19-000181:8k_2_02:9]
| • | GAAP gross margin of 64.1%, compared to GAAP gross margin of 63.9% in the first quarter of 2019 and 64.2% in the second quarter of 2018. |

[0001596532-19-000181:8k_2_02:10]
| • | Non-GAAP gross margin of 64.7%, compared to non-GAAP gross margin of 64.5% in the first quarter of 2019 and 64.5% in the second quarter of 2018. |

[0001596532-19-000181:8k_2_02:11]
| • | GAAP net income of $189.3 million, or $2.33 per diluted share, compared to GAAP net loss of $155.3 million, or $2.08 per diluted share in the second quarter of 2018. |

[0001596532-19-000181:8k_2_02:12]
| • | Non-GAAP net income of $198.6 million, or $2.44 per diluted share, compared to non-GAAP net income of $155.7 million, or $1.93 per diluted share in the second quarter of 2018. |

[0001596532-19-000181:8k_2_02:13]
“In Q2 2019, Arista raised the ante with innovative products in both 400G and Cognitive Campus.  Our leadership in cloud area networking is now widely recognized by industry analysts, partners and customers.” stated Jayshree Ullal, Arista President and CEO.

[0001596532-19-000181:8k_2_02:14]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, “The business continued to demonstrate solid earnings and cash flow generation for the quarter.”

[0001596532-19-000181:8k_2_02:15]
Second Quarter Company Highlights

[0001596532-19-000181:8k_2_02:16]
| • | Arista Delivers Universal 400G Platforms for Cloud Network Transformation - Introduced the new Arista 7800R family for demanding 400G cloud networks and the next generation of the Arista 7500R, 7280R Series. The new platforms support 100G and 400G Ethernet with compelling throughput, density and price-performance and offer new telemetry and intelligence. |

[0001596532-19-000181:8k_2_02:17]
| • | Arista Enables Cloud Area Networking on Microsoft Azure - Announced the next-generation hybrid cloud architecture for the enterprise. This new offering leverages the Microsoft Azure global network, integrates Arista EOS® with Azure and Azure Stack, focusing on the delivery of a seamless hybrid computing experience for organizations of any size. |

[0001596532-19-000181:8k_2_02:18]
| • | Arista Cognitive Cloud Networking Redefines the Campus - Arista Networks announced an expansion of the cognitive campus portfolio with unified wired and wireless campus edge products designed to address transitional changes as the enterprise moves to an IoT (Internet of Things)-ready campus. |

[0001596532-19-000181:8k_2_02:19]
| • | This is the fifth consecutive year Arista Networks has been recognized in the Leaders Quadrant of the 2019 Gartner Magic Quadrant for Data Center Networking, published on 15 July 2019. |

[0001596532-19-000181:8k_2_02:20]
| • | Best Workplaces for Millennials™ 2019 - Arista Networks has been named to the "2019 Best Workplaces for Millennials" by Great Place to Work and FORTUNE. |

[0001596532-19-000181:8k_2_02:21]
Financial Outlook

[0001596532-19-000181:8k_2_02:22]
For the third quarter of 2019, we expect:

[0001596532-19-000181:8k_2_02:23]
| • | Revenue between $647 million and $657 million; |

[0001596532-19-000181:8k_2_02:24]
| • | Non-GAAP gross margin between 63% to 65%, and |

[0001596532-19-000181:8k_2_02:25]
| • | Non-GAAP operating margin of approximately 36% |

[0001596532-19-000181:8k_2_02:26]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below).

[0001596532-19-000181:8k_2_02:27]
Prepared Materials and Conference Call Information

[0001596532-19-000181:8k_2_02:28]
Arista executives will discuss the second quarter 2019 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (833) 287-7905 in the United States or (647) 689-4469 from outside the US. The Conference ID is 5568407.

[0001596532-19-000181:8k_2_02:29]
The financial results conference call will also be available via live webcast on our investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-19-000181:8k_2_02:30]
Forward-Looking Statements

[0001596532-19-000181:8k_2_02:31]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the third quarter of fiscal 2019, and statements regarding the benefits from the introduction of new products and our leadership in cloud area networking. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: Arista Networks’ limited operating history; Arista Networks’ rapid growth; Arista Networks’ customer concentration;  the evolution and growth of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; changes in our customers’ demand for our products and services; requests for more favorable terms and conditions from our large end customers; declines in the sales prices of our products and services; customer order patterns or customer mix; the timing of orders and manufacturing and customer lead times; increased competition in our products and service markets; dependence on the introduction and market acceptance of new product offerings and standards including our 400G products as well as our campus and WiFi products; the benefits and impact of acquisitions; rapid technological and market change; Arista Networks’ dispute with OptumSoft; our revenue growth rate; and general market, political, economic and business conditions. Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s most recent Quarterly Report on Form 10-Q filed with the SEC on May 6, 2019, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/.  All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-19-000181:8k_2_02:32]
Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner's research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001596532-19-000181:8k_2_02:33]
Non-GAAP Financial Measures

[0001596532-19-000181:8k_2_02:34]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, litigation-related expenses, amortization of acquisition-related intangible assets, other non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-19-000181:8k_2_02:35]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-19-000181:8k_2_02:36]
The company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. The company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. A reconciliation of the non-GAAP financial measures guidance to the corresponding GAAP measures on a forward-looking basis is not available because stock-based compensation expense is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-19-000181:8k_2_02:37]
About Arista Networks

[0001596532-19-000181:8k_2_02:38]
Arista Networks pioneered software-driven, cognitive cloud networking for large-scale datacenter and campus environments. Arista’s award-winning platforms redefine and deliver availability, agility, automation, analytics, and security. Arista has shipped more than twenty million cloud networking ports worldwide with CloudVision and EOS, an advanced network operating system. Committed to open standards across private, public and hybrid cloud solutions, Arista products are supported worldwide directly and through partners.

[0001596532-19-000181:8k_2_02:39]
ARISTA, EOS, CloudVision, Cognitive WiFi and AlgoMatch are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-19-000181:8k_2_02:40]
Additional information and resources can be found at: https://www.arista.com.

[0001596532-19-000181:8k_2_02:41]
| Investor Contacts |
| Charles YagerProduct and Investor Advocacy(408) 547-5892cyager@arista.com |  | Chuck ElliottBusiness and Investor Development(408) 547-5549chuck@arista.com |

[0001596532-19-000181:8k_2_02:42]
ARISTA NETWORKS, INC.

[0001596532-19-000181:8k_2_02:43]
Condensed Consolidated Statements of Operations

[0001596532-19-000181:8k_2_02:44]
(Unaudited in thousands, except per share amounts)

[0001596532-19-000181:8k_2_02:45]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 513,171 |  |  | $ | 444,767 |  |  | $ | 1,018,586 |  |  | $ | 852,384 |  |
| Service |  | 95,150 |  |  | 75,078 |  |  | 185,159 |  |  | 139,950 |  |
| Total revenue |  | 608,321 |  |  | 519,845 |  |  | 1,203,745 |  |  | 992,334 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 200,534 |  |  | 171,622 |  |  | 398,686 |  |  | 328,313 |  |
| Service |  | 17,596 |  |  | 14,340 |  |  | 34,298 |  |  | 27,219 |  |
| Total cost of revenue |  | 218,130 |  |  | 185,962 |  |  | 432,984 |  |  | 355,532 |  |
| Total gross profit |  | 390,191 |  |  | 333,883 |  |  | 770,761 |  |  | 636,802 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 114,295 |  |  | 104,078 |  |  | 233,964 |  |  | 206,440 |  |
| Sales and marketing |  | 53,040 |  |  | 46,188 |  |  | 104,093 |  |  | 88,328 |  |
| General and administrative |  | 16,019 |  |  | 18,420 |  |  | 31,525 |  |  | 38,099 |  |
| Legal settlement |  | — |  |  | 405,000 |  |  | — |  |  | 405,000 |  |
| Total operating expenses |  | 183,354 |  |  | 573,686 |  |  | 369,582 |  |  | 737,867 |  |
| Income (loss) from operations |  | 206,837 |  |  | (239,803 | ) |  | 401,179 |  |  | (101,065 | ) |
| Other income (expense), net |  | 13,811 |  |  | (2,169 | ) |  | 26,144 |  |  | 1,987 |  |
| Income (loss) before income taxes |  | 220,648 |  |  | (241,972 | ) |  | 427,323 |  |  | (99,078 | ) |
| Provision for (benefit from) income taxes |  | 31,397 |  |  | (86,703 | ) |  | 37,043 |  |  | (88,347 | ) |
| Net income (loss) |  | $ | 189,251 |  |  | $ | (155,269 | ) |  | $ | 390,280 |  |  | $ | (10,731 | ) |
| Net income (loss) attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 189,152 |  |  | $ | (155,187 | ) |  | $ | 390,063 |  |  | $ | (10,725 | ) |
| Diluted |  | $ | 189,158 |  |  | $ | (155,187 | ) |  | $ | 390,076 |  |  | $ | (10,725 | ) |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.47 |  |  | $ | (2.08 | ) |  | $ | 5.12 |  |  | $ | (0.14 | ) |
| Diluted |  | $ | 2.33 |  |  | $ | (2.08 | ) |  | $ | 4.80 |  |  | $ | (0.14 | ) |
| Weighted-average shares used in computing net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | 76,552 |  |  | 74,503 |  |  | 76,238 |  |  | 74,250 |  |
| Diluted |  | 81,335 |  |  | 74,503 |  |  | 81,271 |  |  | 74,250 |  |

[0001596532-19-000181:8k_2_02:46]
4

[0001596532-19-000181:8k_2_02:47]
ARISTA NETWORKS, INC.

[0001596532-19-000181:8k_2_02:48]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-19-000181:8k_2_02:49]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-19-000181:8k_2_02:50]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| GAAP gross profit |  | $ | 390,191 |  |  | $ | 333,883 |  |  | $ | 770,761 |  |  | $ | 636,802 |  |
| GAAP gross margin |  | 64.1 | % |  | 64.2 | % |  | 64.0 | % |  | 64.2 | % |
| Stock-based compensation expense |  | 1,028 |  |  | 1,236 |  |  | 2,126 |  |  | 2,438 |  |
| Intangible asset amortization |  | 2,626 |  |  | — |  |  | 5,251 |  |  | — |  |
| Non-GAAP gross profit |  | $ | 393,845 |  |  | $ | 335,119 |  |  | $ | 778,138 |  |  | $ | 639,240 |  |
| Non-GAAP gross margin |  | 64.7 | % |  | 64.5 | % |  | 64.6 | % |  | 64.4 | % |
| GAAP income (loss) from operations |  | $ | 206,837 |  |  | $ | (239,803 | ) |  | $ | 401,179 |  |  | $ | (101,065 | ) |
| Stock-based compensation expense |  | 24,297 |  |  | 22,478 |  |  | 48,588 |  |  | 43,329 |  |
| Litigation expense |  | 514 |  |  | 3,569 |  |  | 1,962 |  |  | 10,654 |  |
| Legal settlement (1) |  | — |  |  | 405,000 |  |  | — |  |  | 405,000 |  |
| Intangible asset amortization |  | 3,499 |  |  | — |  |  | 6,998 |  |  | — |  |
| Non-GAAP income from operations |  | $ | 235,147 |  |  | $ | 191,244 |  |  | $ | 458,727 |  |  | $ | 357,918 |  |
| Non-GAAP operating margin |  | 38.7 | % |  | 36.8 | % |  | 38.1 | % |  | 36.1 | % |
| GAAP net income (loss) |  | $ | 189,251 |  |  | $ | (155,269 | ) |  | $ | 390,280 |  |  | $ | (10,731 | ) |
| Stock-based compensation expense |  | 24,297 |  |  | 22,478 |  |  | 48,588 |  |  | 43,329 |  |
| Litigation expense |  | 514 |  |  | 3,569 |  |  | 1,962 |  |  | 10,654 |  |
| Legal settlement (1) |  | — |  |  | 405,000 |  |  | — |  |  | 405,000 |  |
| Intangible asset amortization |  | 3,499 |  |  | — |  |  | 6,998 |  |  | — |  |
| Altera stock-based tax charge (2) |  | 9,781 |  |  | — |  |  | 9,781 |  |  | — |  |
| (Gain) loss on investment in privately-held companies |  | — |  |  | 9,100 |  |  | (1,150 | ) |  | 9,100 |  |
| Tax benefit on stock-based awards |  | (23,455 | ) |  | (25,472 | ) |  | (60,509 | ) |  | (58,318 | ) |
| Income tax effect on non-GAAP exclusions |  | (5,324 | ) |  | (103,686 | ) |  | (9,657 | ) |  | (109,191 | ) |
| Non-GAAP net income |  | $ | 198,563 |  |  | $ | 155,720 |  |  | $ | 386,293 |  |  | $ | 289,843 |  |
| GAAP diluted net income (loss) per share attributable to common stockholders |  | $ | 2.33 |  |  | $ | (2.08 | ) |  | $ | 4.80 |  |  | $ | (0.14 | ) |
| Non-GAAP adjustments to net income (loss) |  | 0.11 |  |  | 4.01 |  |  | (0.05 | ) |  | 3.73 |  |
| Non-GAAP diluted net income per share |  | $ | 2.44 |  |  | $ | 1.93 |  |  | $ | 4.75 |  |  | $ | 3.59 |  |
| Weighted-average shares used in computing GAAP diluted net income (loss) per share attributable to common stockholders |  | 81,335 |  |  | 74,503 |  |  | 81,271 |  |  | 74,250 |  |
| Weighted-average shares used in computing Non-GAAP diluted net income per share attributable to common stockholders |  | 81,335 |  |  | 80,826 |  |  | 81,271 |  |  | 80,774 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,028 |  |  | $ | 1,236 |  |  | $ | 2,126 |  |  | $ | 2,438 |  |
| Research and development |  | 12,568 |  |  | 11,745 |  |  | 25,699 |  |  | 22,690 |  |
| Sales and marketing |  | 7,097 |  |  | 6,274 |  |  | 13,631 |  |  | 12,234 |  |
| General and administrative |  | 3,604 |  |  | 3,223 |  |  | 7,132 |  |  | 5,967 |  |
| Total |  | $ | 24,297 |  |  | $ | 22,478 |  |  | $ | 48,588 |  |  | $ | 43,329 |  |

[0001596532-19-000181:8k_2_02:51]
___________________

[0001596532-19-000181:8k_2_02:52]
(1) Represents one-time charges associated with the settlement of our lawsuit with Cisco on August 6, 2018.

[0001596532-19-000181:8k_2_02:53]
(2) Represents a discrete income tax expense related to stock based compensation as a result of an opinion on Altera Corporation and Subsidiaries vs. Commissioner on Internal Revenue issued by the Court of Appeals for the Ninth Circuit on June 7, 2019.

[0001596532-19-000181:8k_2_02:54]
ARISTA NETWORKS, INC.

[0001596532-19-000181:8k_2_02:55]
Condensed Consolidated Balance Sheets

[0001596532-19-000181:8k_2_02:56]
(Unaudited, in thousands)

[0001596532-19-000181:8k_2_02:57]
|  |  | June 30, 2019 |  | December 31, 2018 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 944,414 |  |  | $ | 649,950 |  |
| Marketable securities |  | 1,313,389 |  |  | 1,306,197 |  |
| Accounts receivable |  | 343,080 |  |  | 331,777 |  |
| Inventories |  | 314,177 |  |  | 264,557 |  |
| Prepaid expenses and other current assets |  | 113,458 |  |  | 162,321 |  |
| Total current assets |  | 3,028,518 |  |  | 2,714,802 |  |
| Property and equipment, net |  | 41,023 |  |  | 75,355 |  |
| Acquisition-related intangible assets, net |  | 51,612 |  |  | 58,610 |  |
| Goodwill |  | 53,684 |  |  | 53,684 |  |
| Investments |  | 31,486 |  |  | 30,336 |  |
| Operating lease right-of-use assets |  | 94,203 |  |  | — |  |
| Deferred tax assets |  | 113,660 |  |  | 126,492 |  |
| Other assets |  | 27,106 |  |  | 22,704 |  |
| TOTAL ASSETS |  | $ | 3,441,292 |  |  | $ | 3,081,983 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 86,134 |  |  | $ | 93,757 |  |
| Accrued liabilities |  | 113,898 |  |  | 123,254 |  |
| Deferred revenue |  | 272,366 |  |  | 358,586 |  |
| Other current liabilities |  | 52,622 |  |  | 30,907 |  |
| Total current liabilities |  | 525,020 |  |  | 606,504 |  |
| Income taxes payable |  | 45,804 |  |  | 36,167 |  |
| Operating lease liabilities, non-current |  | 89,705 |  |  | — |  |
| Finance lease liabilities, non-current |  | — |  |  | 35,431 |  |
| Deferred revenue, non-current |  | 229,852 |  |  | 228,641 |  |
| Other long-term liabilities |  | 25,351 |  |  | 31,851 |  |
| TOTAL LIABILITIES |  | 915,732 |  |  | 938,594 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 8 |  |  | 8 |  |
| Additional paid-in capital |  | 1,038,740 |  |  | 956,572 |  |
| Retained earnings (1) |  | 1,484,777 |  |  | 1,190,803 |  |
| Accumulated other comprehensive income (loss) |  | 2,035 |  |  | (3,994 | ) |
| TOTAL STOCKHOLDERS’ EQUITY |  | 2,525,560 |  |  | 2,143,389 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 3,441,292 |  |  | $ | 3,081,983 |  |
| ______________________ |  |  |  |  |
| (1) We adopted new lease accounting guidance under ASC 842, which resulted in a cumulative-effect adjustment of $3.7 million to retained earnings as of January 1, 2019. |

[0001596532-19-000181:8k_2_02:58]
6

[0001596532-19-000181:8k_2_02:59]
ARISTA NETWORKS, INC.

[0001596532-19-000181:8k_2_02:60]
Condensed Consolidated Statements of Cash Flows

[0001596532-19-000181:8k_2_02:61]
(Unaudited, in thousands)

[0001596532-19-000181:8k_2_02:62]
|  |  | Six Months Ended June 30, |
|  |  | 2019 |  | 2018 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income (loss) |  | $ | 390,280 |  |  | $ | (10,731 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 16,757 |  |  | 11,328 |  |
| Stock-based compensation |  | 48,588 |  |  | 43,329 |  |
| Noncash lease expense |  | 7,955 |  |  | — |  |
| Deferred income taxes |  | 7,914 |  |  | (18,281 | ) |
| (Gain) loss on investment in privately-held companies |  | (1,150 | ) |  | 9,100 |  |
| Accretion of investment discounts |  | (4,260 | ) |  | (783 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (11,303 | ) |  | (13,571 | ) |
| Inventories |  | (49,620 | ) |  | 60,759 |  |
| Prepaid expenses and other current assets |  | 48,864 |  |  | (72,418 | ) |
| Other assets |  | (4,635 | ) |  | 629 |  |
| Accounts payable |  | (6,783 | ) |  | 3,597 |  |
| Accrued liabilities |  | (9,476 | ) |  | (47,153 | ) |
| Accrued legal settlement |  | — |  |  | 405,000 |  |
| Deferred revenue |  | (85,009 | ) |  | (50,096 | ) |
| Income taxes payable |  | 14,399 |  |  | 6,653 |  |
| Other liabilities |  | 3,955 |  |  | (1,237 | ) |
| Net cash provided by operating activities |  | 366,476 |  |  | 326,125 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 552,512 |  |  | 222,764 |  |
| Purchases of marketable securities |  | (549,383 | ) |  | (696,665 | ) |
| Purchases of property and equipment |  | (8,639 | ) |  | (13,071 | ) |
| Investments in privately-held companies |  | — |  |  | (8,000 | ) |
| Other investing activities |  | — |  |  | (2,000 | ) |
| Net cash used in investing activities |  | (5,510 | ) |  | (496,972 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Principal payments of lease financing obligations |  | — |  |  | (921 | ) |
| Proceeds from issuance of common stock under equity plans |  | 38,104 |  |  | 28,810 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (4,662 | ) |  | (4,463 | ) |
| Repurchase of common stock |  | (100,008 | ) |  | — |  |
| Net cash provided by (used in) financing activities |  | (66,566 | ) |  | 23,426 |  |
| Effect of exchange rate changes |  | 72 |  |  | (607 | ) |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 294,472 |  |  | (148,028 | ) |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 654,164 |  |  | 864,697 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 948,636 |  |  | $ | 716,669 |  |
