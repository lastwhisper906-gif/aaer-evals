# ANET 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001596532-16-000244:item_9a:1]
Item 9A. Controls and Procedures

[0001596532-16-000244:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001596532-16-000244:item_9a:3]
Management, with the participation of our Chief Executive Officer ("CEO") and our Chief Financial Officer ("CFO"), evaluated the effectiveness of our disclosure controls and procedures as of December 31, 2015. The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act, means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported, within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the company’s management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure.

[0001596532-16-000244:item_9a:4]
Based on the evaluation of our disclosure controls and procedures as of December 31, 2015, our CEO and CFO concluded that, as of such date, our disclosure controls and procedures are designed at a reasonable assurance level and are effective to provide reasonable assurance that information we are required to disclose in reports that we file or submit under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in Securities and Exchange Commission (SEC) rules and forms, and that

[0001596532-16-000244:item_9a:5]
97

[0001596532-16-000244:item_9a:6]
such information is accumulated and communicated to our management, including our chief executive officer and chief financial officer, as appropriate, to allow timely decisions regarding required disclosure.

[0001596532-16-000244:item_9a:7]
Changes in Internal Control over Financial Reporting

[0001596532-16-000244:item_9a:8]
We have remediated the material weakness in our internal control over financial reporting related to the inadequate design and operation of review controls over the cash flow statement by implementing a number of measures designed to address the underlying causes of the material weakness. Our remediation included implementation of additional procedures surrounding the precision and accuracy of the review control over our statement of cash flows, including enhancement and segregation of duties within our accounting and finance department.  In addition, we improved and expanded our internal review procedures during our financial statement close process. We believe that these additional processes and procedures have enabled us to broaden the scope and quality of our controls related to the oversight and review of our financial statements.

[0001596532-16-000244:item_9a:9]
Except for the remediation efforts related to the controls over the cash flow statement described above, there were no changes in our internal control over financial reporting identified in connection with the evaluation required by Rule 13a-15(d) and 15d-15(d) of the Securities and Exchange Act of 1934, as amended, that occurred during the year ended December 31, 2015 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001596532-16-000244:item_9a:10]
Inherent Limitations of Internal Controls

[0001596532-16-000244:item_9a:11]
Our management, including our CEO and CFO, does not expect that our disclosure controls and procedures or our internal controls over financial reporting will prevent or detect all errors and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system are met. Because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within the Company have been detected. These inherent limitations include the realities that judgments in decision-making can be faulty, and that breakdowns can occur because of a simple error or mistake. Additionally, controls can be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls also is based in part upon certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions. Over time, controls may become inadequate because of changes in conditions, or the degree of compliance with the policies or procedures may deteriorate. Because of the inherent limitations in a cost-effective control system, misstatements due to error or fraud may occur and not be detected.

[0001596532-16-000244:item_9a:12]
Management's Report on Internal Control Over Financial Reporting

[0001596532-16-000244:item_9a:13]
The management of Arista Networks, Inc. (the “Company”) is responsible for establishing and maintaining adequate internal control over financial reporting as defined in Rules 13a-15(f) and 15d-15(f) under the Securities Exchange Act of 1934 for the Company. The Company's internal control over financial reporting is a process designed under the supervision of the Company's principal executive and principal financial officers to provide reasonable assurance regarding the reliability of financial reporting and the preparation of the Company's financial statements for external purposes in accordance with U.S. generally accepted accounting principles.

[0001596532-16-000244:item_9a:14]
The Company's internal control over financial reporting includes those policies and procedures that: (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the Company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with U.S. generally accepted accounting principles, and that receipts and expenditures of the Company are being made only in accordance with authorizations of management and directors of the Company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the Company's assets that could have a material effect on the Consolidated Financial Statements.

[0001596532-16-000244:item_9a:15]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate. Management assessed the effectiveness of the Company's internal control over financial reporting as of December 31, 2015, based on the framework set forth by the Committee of Sponsoring Organizations of the Treadway Commission (COSO) in Internal Control - Integrated Framework (2013 framework). Based on that assessment, management concluded that, as of December 31, 2015, the Company's internal control over financial reporting was effective.

[0001596532-16-000244:item_9a:16]
The effectiveness of the Company's internal control over financial reporting as of December 31, 2015, has been audited by Ernst & Young LLP, the independent registered public accounting firm that audits the Company's Consolidated Financial Statements, as stated in their report preceding this report, which expresses an unqualified opinion on the effectiveness of the Company's internal control over financial reporting as of December 31, 2015.

[0001596532-16-000244:item_9a:17]
98

[0001596532-16-000244:item_9a:18]
99
