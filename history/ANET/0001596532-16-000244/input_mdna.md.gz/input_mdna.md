# ANET MD&A — 0001596532-16-000244


## mdna

[0001596532-16-000244:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001596532-16-000244:mdna:2]
Overview

[0001596532-16-000244:mdna:3]
We are a leading supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation data centers for enterprise support. Our cloud networking solutions consist of our Extensible Operating System, or EOS, a set of network applications and our Ethernet switches. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. At the core of our cloud networking platform is EOS, which was purpose-built to be fully programmable and highly modular. The programmability of EOS has allowed us to create a set of software applications that address the requirements of cloud networking, including workflow automation, network visibility and analytics, and has also allowed us to rapidly integrate with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.

[0001596532-16-000244:mdna:4]
We were founded in 2004 to address the limitations of legacy networking products and to create a cloud networking platform that is open and programmable. From 2004 to 2008, our activities were focused on the development of our software, which resulted in the commercial release of our first product, the 7100 Series switches based on our EOS software, in 2008. Since then, we have continued to introduce new products utilizing EOS, including our 7500 Series switch and our 7050 Series switch in 2010, the second generation of our 7500 Series switch, called the 7500E modular switch, in May 2013, our 7300 Series switch in November 2013, our 7280E in July 2014. In December 2014, we introduced our EOS+ software platform for networking programmability and automation, and in June 2015 we introduced CloudVision, a network-wide approach for workload orchestration and workflow automation.  In September 2015, we introduced our Macro Segmentation Services (“MSS”) to provide automated insertion of security and other in-line layer 4-7 services within any software driven cloud networking infrastructure. MSS has been endorsed by many of our technology alliance ecosystem partners with whom we are currently partnering with to deliver MSS platform support. We also introduced our first 10/25/40/50/100G switches with our 7060, 7260 and 7320 series switches.

[0001596532-16-000244:mdna:5]
As of December 31, 2015, we have shipped more than five million switch ports. We have experienced rapid revenue growth over the last several years, increasing our revenue at a compound annual growth rate of 56.4% from 2011 to 2015. As we have grown the functionality of our EOS software, expanded the range of our switching portfolio and increased the size of our sales force, our revenue has continued to grow rapidly. To support our customers and revenue growth, we have expanded our international presence to include 20 foreign subsidiaries as of December 31, 2015 including for example Australia, Canada, France, Germany, India, Ireland, Japan, South Korea and the United Kingdom. Our revenue for the year ended December 31, 2015 was $837.6 million an increase of 43.4%, compared to the same period in 2014.  We have been profitable and cash flow positive for each year since 2010.

[0001596532-16-000244:mdna:6]
We believe that our cloud networking platform addresses the large and growing cloud networking segment of data center switching, which remains in the early stage of adoption. We expect to continue rapidly growing our organization to meet the needs of new and existing customers as they increasingly realize the performance and cost benefits of our cloud networking solutions and as they expand their cloud networks. We intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features and build upon our technology leadership. We believe one of our greatest strengths lies in our rapid development of new features and applications. We intend to continue expanding our sales and marketing teams and programs and carrying out associated marketing activities in key geographies. In order to support our strong growth, we have and may continue to accelerate our investment in infrastructure, such as enterprise resource planning software and other technologies to improve the efficiency of our operations. As a result, our levels of operating profit as a percentage of revenue could decline in the short to medium term. For a description of factors that may impact our future performance, see the disclosure in the section titled "Factors Affecting Our Performance" below.

[0001596532-16-000244:mdna:7]
Our Business Model

[0001596532-16-000244:mdna:8]
We derive revenue from sales of products and services. We generate revenue primarily from sales of our switching products which incorporate our EOS software. We generate the majority of our services revenue from post contract support, or PCS, which end customers typically purchase in conjunction with our products.

[0001596532-16-000244:mdna:9]
Since shipping our first products in 2008, our cumulative end-customer base has grown rapidly. Between December 31, 2011 and December 31, 2015, our cumulative end-customer base grew from approximately 1,100 to over 3,700. Our end customers span a range of industries and include large Internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others.

[0001596532-16-000244:mdna:10]
To continue to grow our revenue, it is important that we both obtain new customers and sell additional products to existing customers. Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic to the underlying merchant silicon architecture. Today, we combine our EOS software with merchant silicon into a family of switching products. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We currently procure certain merchant silicon components from multiple vendors, and we continue to expand our relationships with these and other vendors. We work closely with third party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third party direct fulfillment facilities where our EOS software is installed on our products.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-16-000244:mdna:11]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators, original equipment manufacturer, or “OEM”, partners and in conjunction with various technology partners. To facilitate channel coordination and increase productivity, we have created a partner program, the Arista Partner Program, to engage partners who provide value-added services and extend our reach into the marketplace. Authorized training partners provide technical training to our channel partners. Our partners commonly receive an order from an end customer prior to placing an order with us, and we confirm the identification of the end customer prior to accepting such orders. Our partners generally do not stock inventory received from us. Our sales organization is supported by systems engineers with deep technical expertise and responsibility for pre-sales technical support and engineering for our end customers. Each sales team is responsible for a geographic territory, has responsibility for a number of major direct end-customer accounts or has assigned accounts in a specific vertical market. During the years ended December 31, 2015, 2014, and 2013, 77.3%, 79.7%, and 82.9% of our revenue was generated from the Americas, substantially all from the U.S., 15.3%, 12.8%, and 11.2% from Europe, the Middle East and Africa and 7.4%, 7.5%, and 5.9% from the Asia-Pacific region, respectively.

[0001596532-16-000244:mdna:12]
Factors Affecting Our Performance

[0001596532-16-000244:mdna:13]
We believe that our future success will depend on many factors, including our ability to expand sales to our existing customers as well as to add new end customers. While these areas present significant opportunity, they also present risks that we must manage to ensure successful results. See the section titled “Risk Factors.” Additionally, we face intense competition especially from larger, well-established companies, and we must continue to expand the capabilities of our cloud networking platform to succeed in our market. We are also currently engaged in lawsuits with Cisco, our largest competitor whereby they claim that we have infringed their intellectual property rights.  We intend to vigorously defend against these Cisco lawsuits as summarized in the Legal Proceedings section below. However, we cannot be certain that any claims by Cisco would be resolved in our favor.  If we are unable to address these challenges, our business could be adversely affected.

[0001596532-16-000244:mdna:14]
Increasing Adoption of Cloud Networks. Networks are subject to increasing performance requirements due to growing numbers of connected devices as well as new enterprise and consumer applications. Computing architectures are evolving to meet the need for constant connectivity and access to data and applications. We believe that cloud networks will continue to replace legacy network technologies. Our business and results of operations will be significantly affected by the speed with which organizations implement cloud networks.

[0001596532-16-000244:mdna:15]
Expanding Sales to Existing Customer Base. We expect that a substantial portion of our future sales will be follow-on sales to existing end customers. As noted above, one of our sales strategies is to target specific projects at our current end customers because they are familiar with the operational and economic benefits of our cloud networking solutions, thereby reducing the sales cycle into these customers. We believe this opportunity with current end customers to be significant given their existing and expected infrastructure spend. We expect our business and results of operations will depend on our ability to sell additional products to our growing base of customers.

[0001596532-16-000244:mdna:16]
Adding New End Customers. We believe that the cloud networking market is still in the early stages of adoption. We intend to target new end customers by continuing to invest in our field sales force and extending our relationships with channel, technology and system-level partners. To date, we have primarily targeted end customers with the largest cloud data centers. A typical initial order involves the education of prospective customers about the technical merits and capabilities and potential cost savings of our products as compared to our competitors’ products. Our results of operations will depend on our ability to continue to add new customers. We believe that

[0001596532-16-000244:mdna:17]
customer references have been, and will continue to be, an important factor in winning new business with special emphasis on four key verticals: the cloud titans, financial services, service and internet hosting providers and high tech enterprises.

[0001596532-16-000244:mdna:18]
Selling More Complex and Higher-Performance Configurations. Our results of operations have been, and we believe will continue to be, affected by our ability to sell more complex and higher-performance configurations of our products. Our ability to sustain our revenue growth will depend, in part, upon our continued sales of these more robust configurations, and quarterly results of operations can be significantly impacted by the mix of products and product configurations sold during the period.

[0001596532-16-000244:mdna:19]
Leveraging Channel Partners. We expect to continue to derive a growing portion of our sales through our channel partners as they develop new end customers and expand sales to our existing end customers. We plan to continue to invest in our network of channel partners to enable them to reach new end customers more effectively, increase sales to existing customers and provide services and support effectively. We believe that increasing channel leverage will extend and improve our engagement with a broad set of customers.

[0001596532-16-000244:mdna:20]
Investing in Research and Development for Growth. We believe that the market for cloud networking is still in the early stages of adoption and we intend to continue investing for long-term growth. We expect to continue to invest heavily in software development in order to expand the capabilities of our cloud networking platform, introduce new products including new releases and upgrades to our EOS software and new applications building upon our technology leadership. We believe one of our greatest strengths lies in the speed of our product development efforts. By investing in research and development, we believe we will be well positioned to continue our rapid growth and take advantage of our large market opportunity. We expect that our results of operations will be impacted by the timing and size of these product development investments.

[0001596532-16-000244:mdna:21]
Customer Concentration and Timing of Large Orders. Historically, large purchases by a relatively limited number of end customers have accounted for significant portion of our revenue. During the years ended December 31, 2015, 2014, and 2013, our largest end customer accounted for 12.0%, 14.9%, and 21.9% of our revenue, respectively. We have also experienced and continue to experience customer concentration on a quarterly basis. In addition, we have experienced increases in the size of our orders, including orders from existing customers, which could result in future increased customer concentration, depending on the timing of the fulfillment of those orders. We have also experienced unpredictability in the timing of large orders, especially with respect to our large end customers, due to the complexity of orders, the time it takes end customers to evaluate, test, qualify and accept our products and factors specific to our end customers. Due to these factors, we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. In addition, we have provided, and may in the future provide, pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur. Our gross margins may also fluctuate as a result of the timing of such sales to large end customers.

[0001596532-16-000244:mdna:22]
47

[0001596532-16-000244:mdna:23]
Basis of Presentation

[0001596532-16-000244:mdna:24]
Revenue

[0001596532-16-000244:mdna:25]
We generate revenue primarily from sales of our switching products which incorporate our EOS software. We also derive a portion of our revenue from sales of post contract support, or PCS, and to a lesser extent professional services. We generate PCS revenue from sales of technical support services contracts that are typically purchased in conjunction with our products and subsequent renewals of those contracts. We offer PCS services under renewable, fee-based contracts, which include 24-hour technical support, hardware repair and replacement parts, bug fixes, patches and unspecified upgrades on a when-and-if available basis. We expect our revenue may vary from period to period based on, among other things, the timing and size of orders, the delivery and acceptance of products, the impact of significant transactions with unique terms and conditions that may require deferral of revenue and cyclicality of orders being placed by our customers. Additionally, we expect PCS revenue to increase in absolute dollars as we expand our installed base. Our ability to expand our installed base and increase our revenue is subject to numerous risks and uncertainties. See the section titled “Risk Factors.” We report revenue net of sales taxes.

[0001596532-16-000244:mdna:26]
Cost of Revenue

[0001596532-16-000244:mdna:27]
Cost of revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs in our manufacturing operations department, and other manufacturing-related costs associated with manufacturing our products and managing our inventory. We expect our cost of product revenue to increase as our product revenue increases. Cost of providing PCS and other services consists primarily of personnel costs for our global customer support organization. We expect our cost of service revenue to increase as our PCS revenue increases.

[0001596532-16-000244:mdna:28]
Gross Margin

[0001596532-16-000244:mdna:29]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including sales to large end customers who generally receive lower pricing, the average sales price of our offerings, manufacturing costs, merchant silicon costs and the mix of products sold. We expect our gross margins to fluctuate over time, depending on the factors described above and others. See the section titled “Risk Factors.”

[0001596532-16-000244:mdna:30]
Operating Expenses

[0001596532-16-000244:mdna:31]
Our operating expenses consist of research and development, sales and marketing and general and administrative expenses. The largest component of our operating expenses is personnel costs. Personnel costs consist of wages, benefits, bonuses and, with respect to sales and marketing expenses, sales commissions. Personnel costs also include stock-based compensation and travel expenses. We expect operating expenses to continue to increase in absolute dollars in the near term as we continue to invest in the growth of our business.

[0001596532-16-000244:mdna:32]
Research and Development Expenses

[0001596532-16-000244:mdna:33]
Research and development expenses consist primarily of personnel costs, with the remainder being prototype expenses, third-party engineering and contractor support costs, and an allocated portion of facility and IT costs and depreciation. Our research and development efforts are focused on maintaining and developing additional functionality for our existing products and on new product development, including new releases and upgrades to our EOS software and applications. We expense research and development costs as incurred. We expect our research and development expenses to increase in absolute dollars as we continue to invest heavily in software development in order to expand the capabilities of our cloud networking platform, introduce new products and features and build upon our technology leadership.

[0001596532-16-000244:mdna:34]
Sales and Marketing Expenses

[0001596532-16-000244:mdna:35]
Sales and marketing expenses consist primarily of personnel costs and also include costs related to marketing and promotional activities, with the remainder being an allocated portion of facility and IT costs and depreciation. We expect our sales and marketing expenses to increase in absolute dollars as we expand our sales and marketing efforts worldwide and expand our relationships with current and future channel partners and end customers.

[0001596532-16-000244:mdna:36]
General and Administrative Expenses

[0001596532-16-000244:mdna:37]
General and administrative expenses consist primarily of personnel costs, legal and professional fees, and an allocated portion of facility and IT costs and depreciation. General and administrative personnel costs include those for our executive, finance, IT, human resources and legal functions. Our professional fees consist primarily of accounting, external legal and IT and other consulting costs. Refer to the discussion under “Legal Proceedings” subheading in Note 5. Commitments and Contingencies of Notes to Consolidated Financial Statements in Part II, Item 8 of this Annual Report on Form 10-K for information related to pending litigation.

[0001596532-16-000244:mdna:38]
Other Income (Expense), Net

[0001596532-16-000244:mdna:39]
Interest Expense

[0001596532-16-000244:mdna:40]
Interest expense consists of interest expense on our subordinated convertible promissory notes, including our related party subordinated convertible promissory notes which were converted during fiscal 2014 and interest expense from our lease financing obligation.

[0001596532-16-000244:mdna:41]
Other Income (Expense)

[0001596532-16-000244:mdna:42]
Other income (expense) consists of gains on investments, write-offs of debt discount on notes payable which were repaid and converted during fiscal 2014, and foreign currency exchange gains and losses. Our foreign currency exchange gains and losses relate to transactions and asset and liability balances denominated in currencies other than the U.S. dollar. We expect our foreign currency gains and losses to continue to fluctuate in the future due to changes in foreign currency exchange rates.

[0001596532-16-000244:mdna:43]
Provision for Income Taxes

[0001596532-16-000244:mdna:44]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. Earnings from our non-U.S. activities are subject to local country income tax and may be subject to U.S. income tax. Generally, our U.S. tax obligations are reduced by a credit for foreign income taxes paid on these earnings which avoids double taxation. Our tax expense to date consists of federal, state and foreign current and deferred income taxes. As we expand internationally, our marginal tax rate may decrease; however, there can be no certainty that our marginal tax rate will decrease, and we may experience changes in tax rates that are not reflective of actual changes in our business or operations.

[0001596532-16-000244:mdna:45]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. We measure deferred income tax assets and liabilities using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-16-000244:mdna:46]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-16-000244:mdna:47]
Results of Operations

[0001596532-16-000244:mdna:48]
The following table summarizes historical results of operations for the periods presented and as a percentage of revenue for those periods.  We have derived the data for the years ended December 31, 2015, 2014 and 2013 from our consolidated financial statements included elsewhere in thus Form 10-K (in thousands, except for percentage of revenue).

[0001596532-16-000244:mdna:49]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Consolidated Statements of Operations Data: |  |  |  |  |  |
| Revenue: |  |  |  |  |  |
| Product | $ | 744,877 |  |  | $ | 531,543 |  |  | $ | 331,687 |  |
| Service | 92,714 |  |  | 52,563 |  |  | 29,537 |  |
| Total revenue | 837,591 |  |  | 584,106 |  |  | 361,224 |  |
| Cost of revenue (1): |  |  |  |  |  |
| Product | 263,585 |  |  | 174,004 |  |  | 112,958 |  |
| Service | 30,446 |  |  | 18,011 |  |  | 9,728 |  |
| Total cost of revenue | 294,031 |  |  | 192,015 |  |  | 122,686 |  |
| Gross profit | 543,560 |  |  | 392,091 |  |  | 238,538 |  |
| Operating expenses (1): |  |  |  |  |  |
| Research and development | 209,448 |  |  | 148,909 |  |  | 98,587 |  |
| Sales and marketing | 109,084 |  |  | 85,338 |  |  | 55,115 |  |
| General and administrative | 75,720 |  |  | 32,331 |  |  | 18,688 |  |
| Total operating expenses | 394,252 |  |  | 266,578 |  |  | 172,390 |  |
| Income from operations | 149,308 |  |  | 125,513 |  |  | 66,148 |  |
| Interest expense | (3,152 | ) |  | (6,280 | ) |  | (7,119 | ) |
| Other income (expense), net | (147 | ) |  | 2,275 |  |  | (754 | ) |
| Total Other income (expense), net | (3,299 | ) |  | (4,005 | ) |  | (7,873 | ) |
| Income before provision for income taxes | 146,009 |  |  | 121,508 |  |  | 58,275 |  |
| Provision for income taxes | 24,907 |  |  | 34,658 |  |  | 15,815 |  |
| Net income | $ | 121,102 |  |  | $ | 86,850 |  |  | $ | 42,460 |  |

[0001596532-16-000244:mdna:50]
(1) Includes stock-based compensation expense as follows:

[0001596532-16-000244:mdna:51]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Stock-Based Compensation Expense: |  |  |  |  |  |
| Cost of revenue | $ | 3,048 |  |  | $ | 1,535 |  |  | $ | 408 |  |
| Research and development | 25,515 |  |  | 14,986 |  |  | 5,464 |  |
| Sales and marketing | 11,454 |  |  | 7,643 |  |  | 2,985 |  |
| General and administrative | 5,286 |  |  | 3,455 |  |  | 1,302 |  |
| Total stock-based compensation | $ | 45,303 |  |  | $ | 27,619 |  |  | $ | 10,159 |  |

[0001596532-16-000244:mdna:52]
50

[0001596532-16-000244:mdna:53]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
|  | (as a percentage of revenue) |
| Revenue: |  |  |  |  |  |
| Product | 88.9 | % |  | 91.0 | % |  | 91.8 | % |
| Service | 11.1 |  |  | 9.0 |  |  | 8.2 |  |
| Total revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 31.5 |  |  | 29.8 |  |  | 31.3 |  |
| Service | 3.6 |  |  | 3.1 |  |  | 2.7 |  |
| Total cost of revenue | 35.1 |  |  | 32.9 |  |  | 34.0 |  |
| Gross margin | 64.9 |  |  | 67.1 |  |  | 66.0 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 25.0 |  |  | 25.5 |  |  | 27.3 |  |
| Sales and marketing | 13.0 |  |  | 14.6 |  |  | 15.3 |  |
| General and administrative | 9.0 |  |  | 5.5 |  |  | 5.2 |  |
| Total operating expenses | 47.0 |  |  | 45.6 |  |  | 47.8 |  |
| Income from operations | 17.9 |  |  | 21.5 |  |  | 18.2 |  |
| Interest expense | (0.4 | ) |  | (1.1 | ) |  | (2.0 | ) |
| Other income (expense), net | 0.0 |  |  | 0.4 |  |  | (0.2 | ) |
| Total other income (expense), net | (0.4 | ) |  | (0.7 | ) |  | (2.2 | ) |
| Income before provision for income taxes | 17.5 |  |  | 20.8 |  |  | 16.0 |  |
| Provision for income taxes | 3.0 |  |  | 5.9 |  |  | 4.4 |  |
| Net income | 14.5 | % |  | 14.9 | % |  | 11.6 | % |

[0001596532-16-000244:mdna:54]
51

[0001596532-16-000244:mdna:55]
Year Ended December 31, 2015 Compared to Year Ended December 31, 2014

[0001596532-16-000244:mdna:56]
Revenue, Cost of Revenue and Gross Profit (in thousands, except percentages)

[0001596532-16-000244:mdna:57]
|  | Year Ended December 31, |  |  |
|  | 2015 |  | 2014 |  | Change in |
|  | $ |  | % ofrevenue |  | $ |  | % ofrevenue |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 744,877 |  |  | 88.9 | % |  | $ | 531,543 |  |  | 91.0 | % |  | $ | 213,334 |  |  | 40.1 | % |
| Service | 92,714 |  |  | 11.1 |  |  | 52,563 |  |  | 9.0 |  |  | 40,151 |  |  | 76.4 |  |
| Total revenue | 837,591 |  |  | 100.0 |  |  | 584,106 |  |  | 100.0 |  |  | 253,485 |  |  | 43.4 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |
| Product | 263,585 |  |  | 31.5 |  |  | 174,004 |  |  | 29.8 |  |  | 89,581 |  |  | 51.5 |  |
| Service | 30,446 |  |  | 3.6 |  |  | 18,011 |  |  | 3.1 |  |  | 12,435 |  |  | 69.0 |  |
| Total cost of revenue | 294,031 |  |  | 35.1 |  |  | 192,015 |  |  | 32.9 |  |  | 102,016 |  |  | 53.1 |  |
| Gross profit | $ | 543,560 |  |  | 64.9 | % |  | $ | 392,091 |  |  | 67.1 | % |  | $ | 151,469 |  |  | 38.6 | % |
| Gross margin | 64.9 | % |  |  |  | 67.1 | % |  |  |  |  |  |  |

[0001596532-16-000244:mdna:58]
Revenue. Product revenue increased 40.1% in the year ended December 31, 2015 compared to 2014. We increased shipments to our existing customers during the year as they continued to grow their businesses and increase their demand for our switch products and related accessories. In addition, we continued to add new customers as we expanded our market presence and geographic footprint. Service revenue increased 76.4% in the year ended December 31, 2015 with growth in initial and renewal support contracts as our customer installed base continued to expand.  We also continued to experience fluctuations in product and service pricing due to competitive market pressures.  However, these were more than offset by the increased demand drivers outlined above.

[0001596532-16-000244:mdna:59]
Cost of Revenue and Gross Margin. Gross margin decreased from 67.1% to 64.9% for the year ended December 31, 2015 compared to the same period in 2014. This decrease in 2015 was primarily due to increased inventory-related obsolescence charges associated with upcoming product transitions and higher warranty costs, in addition to a greater mix of revenue from larger customers who typically receive higher discounts.

[0001596532-16-000244:mdna:60]
Operating Expenses (in thousands, except percentages)

[0001596532-16-000244:mdna:61]
|  | Year Ended December 31, |  |  |
|  | 2015 |  | 2014 |  | Change in |
|  | $ |  | % ofrevenue |  | $ |  | % ofrevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 209,448 |  |  | 25.0 | % |  | $ | 148,909 |  |  | 25.5 | % |  | $ | 60,539 |  |  | 40.7 | % |
| Sales and marketing | 109,084 |  |  | 13.0 |  |  | 85,338 |  |  | 14.6 |  |  | 23,746 |  |  | 27.8 |  |
| General and administrative | 75,720 |  |  | 9.0 |  |  | 32,331 |  |  | 5.5 |  |  | 43,389 |  |  | 134.2 |  |
| Total operating expenses | $ | 394,252 |  |  | 47.0 | % |  | $ | 266,578 |  |  | 45.6 | % |  | $ | 127,674 |  |  | 47.9 | % |

[0001596532-16-000244:mdna:62]
Research and development. Research and development expenses increased $60.5 million, or 40.7%, for the year ended December 31, 2015 compared to the same period in 2014. The increase was primarily due to an increase in personnel costs of $33.3 million, resulting from increases in headcount, stock based compensation as well as additional bonus expense under our corporate bonus plan. Prototype spend and third-party engineering and consulting costs increased by $14.2 million, and facilities and IT infrastructure costs increased $8.6 million due to new product introductions and the continued expansion and support of our research and development activities.

[0001596532-16-000244:mdna:63]
Sales and marketing. Sales and marketing expenses increased $23.7 million, or 27.8%, for the year ended December 31, 2015 compared to the same period in 2014. The increase was primarily due to an increase in personnel costs of $17.0 million, resulting from increased headcount and additional sales commissions. The increase also related to additional product field demonstration costs of $6.0 million.

[0001596532-16-000244:mdna:64]
General and administrative. General and administrative expenses increased $43.4 million, or 134.2%, for the year ended December 31, 2015 compared to the same period in 2014. The increase was due to an increase in legal fees of $39.8 million primarily related to the Cisco and OptumSoft legal matters outlined in Note 5 to the Consolidated Financial Statements.  In addition, personnel costs increased by $4.1 million reflecting additional bonus cost under our corporate bonus program and increased stock-based compensation charges during 2015.

[0001596532-16-000244:mdna:65]
Other Income (Expense), Net (in thousands, except percentages)

[0001596532-16-000244:mdna:66]
|  | Year Ended December 31, |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (3,152 | ) |  | $ | (6,280 | ) |  | $ | 3,128 |  |  | (49.8 | )% |
| Other income (expense), net | (147 | ) |  | 2,275 |  |  | (2,422 | ) |  | (106.5 | ) |
| Total other income (expense), net | $ | (3,299 | ) |  | $ | (4,005 | ) |  | $ | 706 |  |  | (17.6 | )% |

[0001596532-16-000244:mdna:67]
Interest expense. The reduction in interest expense during the year ended December 31, 2015 compared to the same period in 2014 is primarily related to repayment and conversion of our notes payable upon closing of our initial public offering during the second quarter of 2014.

[0001596532-16-000244:mdna:68]
Other income (expense), net. The unfavorable change in other income (expense), net during the year ended December 31, 2015, compared to the same period in 2014 was primarily due to a one-time gain on our notes receivable of $4.0 million in 2014, partially offset by a $0.7 million write-off related to the debt discount on notes payable during the second quarter of 2014, and a reduction in transactional exchange rate losses during 2015.

[0001596532-16-000244:mdna:69]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-16-000244:mdna:70]
|  | Year Ended December 31, |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
| Provision for income taxes | $ | 24,907 |  |  | $ | 34,658 |  |  | $ | (9,751 | ) |  | (28.1 | )% |
| Effective tax rate | 17.1 | % |  | 28.5 | % |  |  |  |  |

[0001596532-16-000244:mdna:71]
Provision for income taxes was approximately $24.9 million and $34.7 million for the year ended December 31, 2015 and 2014, respectively. The change in our provision was the result of an increase in profit before income taxes, offset by a decrease due to foreign mix earnings taxed at a lower rate than the US tax rate, release of reserves due to expiration of the statute of limitations in certain domestic jurisdictions, and reinstatement of the federal research and development ("R&D") credit.

[0001596532-16-000244:mdna:72]
The R&D credit, which was made permanent under Protecting Americans from Tax Hikes (PATH) Act, signed into law on December 18, 2015.  The impact of the 2015 federal R&D tax credit benefit was recorded in the fourth quarter of the year ended December 31, 2015.

[0001596532-16-000244:mdna:73]
Year Ended December 31, 2014 Compared to Year Ended December 31, 2013

[0001596532-16-000244:mdna:74]
Revenue, Cost of Revenue and Gross Profit (in thousands, except percentages)

[0001596532-16-000244:mdna:75]
|  | Year Ended December 31, |  |  |
|  | 2014 |  | 2013 |  | Change in |
|  | $ |  | % ofrevenue |  | $ |  | % ofrevenue |  | $ |  | % |
| Revenue | $ | 584,106 |  |  | 100.0 | % |  | $ | 361,224 |  |  | 100.0 | % |  | $ | 222,882 |  |  | 61.7 | % |
| Cost of revenue | 192,015 |  |  | 32.9 |  |  | 122,686 |  |  | 34.0 |  |  | 69,329 |  |  | 56.5 |  |
| Gross profit | $ | 392,091 |  |  | 67.1 | % |  | $ | 238,538 |  |  | 66.0 | % |  | $ | 153,553 |  |  | 64.4 | % |
| Gross margin | 67.1 | % |  |  |  | 66.0 | % |  |  |  |  |  |  |

[0001596532-16-000244:mdna:76]
Revenue. Revenue increased $222.9 million, or 61.7%, for the year ended December 31, 2014 compared to 2013.  The increase in revenue was predominately driven by increased product shipments to existing customers due to increased demand for our switch products and related accessories.  In addition, our cumulative number of customers grew approximately 33% from December 31, 2013 to December 31, 2014 as we continued to broaden our market penetration.

[0001596532-16-000244:mdna:77]
Cost of Revenue and Gross Margin. Gross margin increased from 66.0% for the year ended December 31, 2013 to 67.1% for 2014. The increase in gross margin was primarily the result of specific warranty and excess and obsolete inventory-related charges of $10.3 million recorded in 2013 that did not recur in 2014.  To a lesser extent, gross margin in 2014 was negatively impacted by a decrease in product margins due to a higher revenue mix from larger customers who typically receive higher volume discounts.

[0001596532-16-000244:mdna:78]
Operating Expenses (in thousands, except percentages)

[0001596532-16-000244:mdna:79]
|  | Year Ended December 31, |  |  |
|  | 2014 |  | 2013 |  | Change in |
|  | $ |  | % ofrevenue |  | $ |  | % ofrevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 148,909 |  |  | 25.5 | % |  | $ | 98,587 |  |  | 27.3 | % |  | $ | 50,322 |  |  | 51.0 | % |
| Sales and marketing | 85,338 |  |  | 14.6 |  |  | 55,115 |  |  | 15.3 |  |  | 30,223 |  |  | 54.8 |  |
| General and administrative | 32,331 |  |  | 5.5 |  |  | 18,688 |  |  | 5.2 |  |  | 13,643 |  |  | 73.0 |  |
| Total operating expenses | $ | 266,578 |  |  | 45.6 | % |  | $ | 172,390 |  |  | 47.8 | % |  | $ | 94,188 |  |  | 54.6 | % |

[0001596532-16-000244:mdna:80]
Research and development. Research and development expenses increased $50.3 million, or 51.0%, for the year ended December 31, 2014 compared to 2013. The increase was primarily due to an increase in personnel costs of $39.0 million, resulting from an increase of 156 employees (a 34.1% increase) from December 31, 2013 to December 31, 2014, and additional bonus expenses under our corporate bonus plan. The increase was also due to an increase of $6.6 million in research and development related facilities and IT infrastructure costs, and increases in third-party engineering costs of $5.9 million and depreciation expense of $2.0 million, as we continued to expand and support our research and development activities. These expenses were partially offset by a $4.3 million reduction in prototype spending related to project timing.

[0001596532-16-000244:mdna:81]
Sales and marketing. Sales and marketing expenses increased $30.2 million, or 54.8%, for the year ended December 31, 2014 compared to 2013. The increase was primarily due to an increase in personnel costs of $23.4 million, resulting from an increase of 45 employees (a 23.0% increase) from December 31, 2013 to December 31, 2014, as well as an increase in sales commissions resulting from higher sales volume. The increase was also due to an increase of $3.7 million in product demonstrations, expenses incurred to expand our sales engineering labs to support our growing customer base, consulting expenses.

[0001596532-16-000244:mdna:82]
General and administrative. General and administrative expenses increased $13.6 million, or 73.0%, for the year ended December 31, 2014 compared to 2013. The increase was primarily due to an increase in personnel costs of $5.7 million, resulting from an increase of 17 employees (a 29.8% increase) from December 31, 2013 to December 31, 2014, and additional expenses under our corporate bonus plan. We also incurred higher professional service fees of $3.7 million related to outside legal, accounting and consulting services to support increased business activity, litigation and public-company activities. The increase was also attributable to higher insurance expense and franchise taxes of $1.5 million associated with being a public company, and a $1.0 million charitable donation through a fund established by the Company in 2014.

[0001596532-16-000244:mdna:83]
Other Income (Expense), Net (in thousands, except percentages)

[0001596532-16-000244:mdna:84]
|  | Year Ended December 31, |  | Change in |
|  | 2014 |  | 2013 |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (6,280 | ) |  | $ | (7,119 | ) |  | $ | 839 |  |  | (11.8 | )% |
| Other income (expense), net | 2,275 |  |  | (754 | ) |  | 3,029 |  |  | NM |  |
| Total other income (expense), net | $ | (4,005 | ) |  | $ | (7,873 | ) |  | $ | 3,868 |  |  | (49.1 | )% |

[0001596532-16-000244:mdna:85]
Interest expense. Interest expense decreased during the year ended December 31, 2014 compared to the same period in 2013 as a result of repayment and conversion of our notes payable upon our IPO during the second quarter of 2014.

[0001596532-16-000244:mdna:86]
Other income (expense), net. Other income (expense), net increased for the year ended December 31, 2014, compared to 2013 due to the gain on our notes receivable of $4.0 million offset by a $0.7 million write-off related to the debt discount on notes payable upon our IPO, further offset by net transactional exchange rate losses.

[0001596532-16-000244:mdna:87]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-16-000244:mdna:88]
|  | Year Ended December 31, |  | Change in |
|  | 2014 |  | 2013 |  | $ |  | % |
| Provision for income taxes | $ | 34,658 |  |  | $ | 15,815 |  |  | $ | 18,843 |  |  | 119.1 | % |
| Effective tax rate | 28.5 | % |  | 27.1 | % |  |  |  |  |

[0001596532-16-000244:mdna:89]
Provision for income taxes was approximately $34.7 million and $15.8 million for the years ended December 31, 2014 and 2013, respectively.  Provision for income taxes increased $18.8 million, or 119.1%, for the year ended December 31, 2014 compared to 2013. The change in our provision for income taxes was primarily due to an increase in profit before income tax.  The change in the effective tax rate was a result of the geographical distribution of the earnings, the federal R&D tax credit for 2014 including only a current year benefit, as compared to a two-year federal R&D tax credit benefit for 2013, and an increase in state taxes.

[0001596532-16-000244:mdna:90]
The effective tax rate for the year ended December 31, 2014 included the impact of the reinstatement of the 2014 R&D credit.  The impact of the 2014 Federal R&D tax credit benefit was recorded in the fourth quarter of the year ended December 31, 2014. The effective tax rate for the year ended December 31, 2013 included the impact of the reinstatement of the 2013 and 2012 Federal R&D tax credits.

[0001596532-16-000244:mdna:91]
Liquidity and Capital Resources

[0001596532-16-000244:mdna:92]
Our principal sources of liquidity are cash and cash equivalents, marketable securities, and cash generated from operations. As of December 31, 2015, cash and cash equivalents were $687.3 million, of which approximately $41.6 million was held outside the U.S. in our foreign subsidiaries. We have not repatriated nor do we currently have plans to repatriate these funds, but if we were to repatriate cash held outside of the U.S. for domestic cash operations, we would be required to accrue and pay U.S. income taxes to repatriate these funds less any previously paid foreign income taxes. We consider the undistributed earnings of our foreign subsidiaries as of December 31, 2015 to be indefinitely reinvested, and, accordingly, no U.S. income taxes have been provided thereon.

[0001596532-16-000244:mdna:93]
Our cash and cash equivalents and marketable securities are held for working capital purposes.  We plan to continue to invest for long-term growth. We believe that our existing cash and cash equivalents together with cash flow from operations will be sufficient to meet our working capital requirements and our growth strategies for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs and access to outsourcing our manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and costs incurred related to outstanding litigation claims. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-16-000244:mdna:94]
Cash Flows

[0001596532-16-000244:mdna:95]
|  | December 31, |
|  | 2015 |  | 2014 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 687,326 |  |  | $ | 240,031 |  |

[0001596532-16-000244:mdna:96]
|  |  | Year Ended December 31, |
|  |  | 2015 |  | 2014 |  | 2013 |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 200,533 |  |  | $ | 131,875 |  |  | $ | 34,648 |  |
| Cash provided by (used in) investing activities |  | 184,170 |  |  | (249,362 | ) |  | (19,491 | ) |
| Cash provided by financing activities |  | 63,105 |  |  | 243,978 |  |  | 9,886 |  |
| Effect of exchange rate changes |  | (513 | ) |  | (124 | ) |  | (34 | ) |
| Net increase in cash and cash equivalents |  | $ | 447,295 |  |  | $ | 126,367 |  |  | $ | 25,009 |  |

[0001596532-16-000244:mdna:97]
Cash Flows from Operating Activities

[0001596532-16-000244:mdna:98]
Our primary source of cash from operating activities has been from cash collections from our customers. We expect cash inflows from operating activities to be affected by increased sales and timing of collections. Our primary uses of cash from operating activities have been for personnel costs, inventory purchases from our contract manufacturer, investment in research and development, and litigation expenses.

[0001596532-16-000244:mdna:99]
During the year ended December 31, 2015, cash provided by operating activities was $200.5 million, primarily from net income of $121.1 million, net non-cash charges of ($1.2) million, and a net increase in cash from changes in our operating assets and liabilities of $80.6 million.  The net increase in cash from changes in operating assets and liabilities was primarily due to an increase in deferred revenue of $90.3 million, largely related to short and long-term services contracts and product revenue deferrals related to contracts with acceptance terms. In addition, we experienced an increase in cash of $32.0 million from income taxes payable and an increase in our accounts payable and accrued liabilities of $29.4 million due to the timing of payments. These operating liability increases were offset by an increase in our accounts receivable of $47.3 million resulting from an increase in sales during the period. In addition, inventory increased $14.1 million during the period due to higher shipment volume, and prepaid expenses and current assets increased $7.8 million in the period.

[0001596532-16-000244:mdna:100]
During the year ended December 31, 2014, cash provided by operating activities was $131.9 million primarily from net income of $86.9 million, net non-cash charges of $11.0 million, and an increase of $33.2 million due to changes in our operating assets and

[0001596532-16-000244:mdna:101]
liabilities. The increase in cash from operating assets and liabilities was primarily due an increase in deferred revenue of $47.6 million resulting from the increase in sales, an increase in accrued liabilities of $18.9 million largely related to our payroll and corporate bonus plan and an increase in accounts payable of $14.0 million due to the timing of our payments, partially offset by a reduction in cash from an increase in accounts receivable of $19.0 million from higher products shipments, an increase in inventories of $13.4 million to meet our customer demand, an increase of $15.3 million in cash paid for income taxes, and supplier rebates receivable resulting from our increased inventory purchases.

[0001596532-16-000244:mdna:102]
During the year ended December 31, 2013, cash provided by operating activities was $34.6 million, primarily from net income of $42.5 million and non-cash charges of $6.6 million, partially offset by a decrease of $14.6 million due to changes in our operating assets and liabilities. The decrease in cash from operating assets and liabilities was primarily due to a $49.2 million increase in inventory for anticipated growth in our business, a $28.1 million increase in accounts receivable due to an increase in sales partially offset by an increase in cash from a $3.0 million decrease in prepaid expenses and other current assets, partially offset by an increase in cash from a $3.9 million increase in accounts payable primarily attributable to the timing of payments, a $12.0 million increase in accrued liabilities attributable to higher warranty liabilities and higher accrued personnel costs due to growth in headcount, a $34.1 million increase in deferred revenue due to increased sales and a $6.0 million increase in interest payable attributable to our outstanding convertible promissory notes, including our related party convertible promissory notes.

[0001596532-16-000244:mdna:103]
Cash Flows from Investing Activities

[0001596532-16-000244:mdna:104]
Our investing activities have consisted primarily of capital expenditures and net investment purchases of available for sale marketable securities. We expect to continue investing in these activities to support the continued growth of our business.

[0001596532-16-000244:mdna:105]
During the year ended December 31, 2015, cash provided by investing activities was $184.2 million, consisting of proceeds from the maturity of available-for-sale securities of $208.2 million, offset by purchases of property, equipment and other assets of $19.2 million and increase in restricted cash of $4.0 million related to a security deposit required for a facility lease.

[0001596532-16-000244:mdna:106]
During the year ended December 31, 2014, cash used in investing activities was $249.4 million, consisting primarily of purchases of marketable securities of $210.0 million, purchases of property and equipment of $13.1 million and other investing activities of $38.2 million largely due to a $33.6 million equity investments in privately held companies, partially offset by the proceeds of the repayments of our notes receivable of $8.0 million and the release of our restricted cash into cash and cash equivalents of $4.0 million.

[0001596532-16-000244:mdna:107]
During the year ended December 31, 2013, cash used in investing activities was $19.5 million, of which $20.3 million relates to the purchase of property and equipment offset by notes receivable repayments of $1.0 million.

[0001596532-16-000244:mdna:108]
Cash Flows from Financing Activities

[0001596532-16-000244:mdna:109]
During the year ended December 31, 2015, cash provided by financing activities was $63.1 million, consisting primarily of the excess tax benefit associated with equity incentive plans of $37.3 million, proceeds from the exercise of stock options, net of repurchases of $17.8 million and the proceeds from the issuance of common stock from our ESPP of $9.4 million.

[0001596532-16-000244:mdna:110]
During the year ended December 31, 2014, cash provided by financing activities was $244.0 million, consisting primarily of net proceeds raised from our initial public offering of $239.3 million, proceeds from the exercise of stock options, net of repurchases of $8.0 million and excess tax benefits from our equity incentive plans amounting to $17.4 million. These proceeds were partially offset by the repayment of our notes payable of $20.0 million.

[0001596532-16-000244:mdna:111]
During the year ended December 31, 2013, cash provided by financing activities was $9.9 million, consisting primarily of proceeds from the exercise of stock options, net of repurchases, amounting to $9.0 million and excess tax benefits associated with our equity incentive plans amounting to $0.9 million.

[0001596532-16-000244:mdna:112]
Off-Balance Sheet Arrangements

[0001596532-16-000244:mdna:113]
As of December 31, 2015, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-16-000244:mdna:114]
Contractual Obligations and Commitments

[0001596532-16-000244:mdna:115]
Our contractual commitments will have an impact on our future liquidity. Our contractual obligations represent material expected or contractually committed future obligations with terms in excess of one year. We believe that we will be able to fund these obligations through cash generated from operations and from our existing cash balances.

[0001596532-16-000244:mdna:116]
The following summarizes our contractual obligations and commitments as of December 31, 2015 (in thousands):

[0001596532-16-000244:mdna:117]
|  |  | Payments Due by Period |
|  |  | Total |  | Less than1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than5 Years |
| Financing lease obligation(1) |  | $ | 49,380 |  |  | $ | 5,754 |  |  | $ | 12,047 |  |  | $ | 12,769 |  |  | $ | 18,810 |  |
| Operating lease obligations |  | 52,083 |  |  | 6,307 |  |  | 12,937 |  |  | 11,389 |  |  | 21,450 |  |
| Non-cancelable purchase obligations |  | 43,902 |  |  | 43,902 |  |  | — |  |  | — |  |  |  |
| Total |  | $ | 145,365 |  |  | $ | 55,963 |  |  | $ | 24,984 |  |  | $ | 24,158 |  |  | $ | 40,260 |  |

[0001596532-16-000244:mdna:118]
_________________

[0001596532-16-000244:mdna:119]
(1) Includes interest and land lease

[0001596532-16-000244:mdna:120]
The contractual obligation table above excludes tax liabilities of $14.3 million related to uncertain tax positions because we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-16-000244:mdna:121]
Critical Accounting Policies and Estimates

[0001596532-16-000244:mdna:122]
We have prepared our consolidated financial statements in accordance with GAAP and include our accounts and the accounts of our wholly owned subsidiaries. The preparation of these consolidated financial statements requires our management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities at the date of the financial statements, disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the applicable periods. We base our estimates, assumptions and judgments on historical experience and on various other factors that we believe to be reasonable under the circumstances. Different assumptions and judgments would change the estimates used in the preparation of our consolidated financial statements, which, in turn, could change the results from those reported. We evaluate our estimates, assumptions and judgments on an ongoing basis. The critical accounting estimates, assumptions and judgments that we believe have the most significant impact on our consolidated financial statements are the following:

[0001596532-16-000244:mdna:123]
Revenue Recognition

[0001596532-16-000244:mdna:124]
We generate revenue from sales of switching products which incorporate our EOS software and accessories such as cables and optics to direct customers and channel partners together with post contract customer support (“PCS”). We typically sell products and PCS in a single transaction. We recognize revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery or performance has occurred; the sales price is fixed or determinable; and collectability is reasonably assured.

[0001596532-16-000244:mdna:125]
We define each of the four criteria above as follows:

[0001596532-16-000244:mdna:126]
| • | Persuasive evidence of an arrangement exists. Evidence of an arrangement consists of stand-alone purchase orders or purchase orders issued pursuant to the terms and conditions of a master sales agreement. It is our practice to identify an end customer prior to shipment to a reseller or distributor. |

[0001596532-16-000244:mdna:127]
| • | Delivery or performance has occurred. We use shipping documents or written evidence of customer acceptance, when applicable, to verify delivery or performance. We recognize product revenue upon transfer of title and risk of loss, which primarily is upon shipment to customers. We generally do not have significant obligations for future performance, rights of return, or pricing credits associated with our product sales. In instances where substantive acceptance provisions are specified in the customer arrangement, revenue is deferred until all acceptance criteria have been met. |

[0001596532-16-000244:mdna:128]
| • | The sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on payment terms and whether the sales price is subject to refund or adjustment. |

[0001596532-16-000244:mdna:129]
| • | Collectability is reasonably assured. We assess probability of collectability on a customer-by-customer basis. Our customers and channel partners are subjected to a credit review process that evaluates their financial condition and ability to pay for products and services. |

[0001596532-16-000244:mdna:130]
PCS is offered under renewable, fee-based contracts, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis. We initially defer PCS revenue and recognize it ratably over the life of the PCS contract, with the related expenses recognized as incurred. PCS contracts usually have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-16-000244:mdna:131]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of goods sold.

[0001596532-16-000244:mdna:132]
Multiple-Element Arrangements

[0001596532-16-000244:mdna:133]
Most of our arrangements, other than renewals of PCS, are multiple element arrangements with a combination of products and PCS. Products and PCS generally qualify as separate units of accounting. Our hardware deliverables include EOS software, which together deliver the essential functionality of our products. For multiple element arrangements, we allocate revenue to each unit of accounting based on the relative selling price. The relative selling price for each element is based upon the following hierarchy: vendor-specific

[0001596532-16-000244:mdna:134]
objective evidence (“VSOE”), if available; third-party evidence (“TPE”), if VSOE is not available; and best estimate of selling price (“BESP”), if neither VSOE nor TPE is available. As we have not been able to establish VSOE or TPE for our products and most of our services, we generally utilize BESP for the purposes of allocating revenue to each unit of accounting.

[0001596532-16-000244:mdna:135]
| • | VSOE—We determine VSOE based on our historical pricing and discounting practices for the specific products and services when sold separately. In determining VSOE, we require that a substantial majority of the stand-alone selling prices fall within a reasonably narrow pricing range. |

[0001596532-16-000244:mdna:136]
| • | TPE—When VSOE cannot be established for deliverables in multiple-element arrangements, we apply judgment with respect to whether we can establish a selling price based on TPE. TPE is determined based on competitor prices for interchangeable products or services when sold separately to similarly situated customers. However, as our products contain a significant element of proprietary technology and offer substantially different features and functionality, the comparable pricing of products with similar functionality typically cannot be obtained. Additionally, as we are unable to reliably determine what competitors products’ selling prices are on a stand-alone basis, we are not able to obtain reliable evidence of TPE of selling price. |

[0001596532-16-000244:mdna:137]
| • | BESP—When we are unable to establish selling price using VSOE or TPE, we use BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service was sold regularly on a stand-alone basis. BESP is based on considering multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services were sold (domestic or international) and size of the end customer. |

[0001596532-16-000244:mdna:138]
We limit the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations, or subject to customer-specific return, acceptance or refund privileges.

[0001596532-16-000244:mdna:139]
We account for multiple agreements with a single partner as 1 arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single arrangement.

[0001596532-16-000244:mdna:140]
We may occasionally accept returns to address customer satisfaction issues even though there is no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period gross revenues. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-16-000244:mdna:141]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-16-000244:mdna:142]
Inventories primarily consist of finished goods purchased from third party contract manufacturers and are stated at the lower of cost (computed using the first-in, first-out method) or market value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancelable, including integrated circuits, which are held by our contract manufacturers.  We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value.  We also record a liability for non-cancelable, non-returnable purchase commitments with our component inventory suppliers for quantities in excess of our demand forecasts or that are considered obsolete.

[0001596532-16-000244:mdna:143]
Our contract manufacturers procure components and assemble products on our behalf based on our forecasts.  We generally incur a liability when the contract manufacturer has converted the component inventory to a finished product.  Historically, we have reimbursed our contract manufacturer for component inventory that has been rendered excess or obsolete due to manufacturing and engineering change orders resulting from design changes, or in cases where inventory levels greatly exceed our forecasts.

[0001596532-16-000244:mdna:144]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer liabilities.

[0001596532-16-000244:mdna:145]
Warranty

[0001596532-16-000244:mdna:146]
We offer a one-year warranty on all of our hardware products and a 90-day warranty against defects in the software embedded in the products. We use judgment and estimates when determining warranty costs based on historical costs to replace product returns within the warranty period at the time we recognize revenue. We accrue for potential warranty claims at the time of shipment as a component of cost of revenues based on historical experience and other relevant information. We reserve for specifically identified products if and when we determine we have a systemic product failure. Although we engage in extensive product quality programs, if actual product failure rates or use of materials differ from estimates, additional warranty costs may be incurred, which could reduce our gross margin. The accrued warranty liability is recorded in accrued liabilities in the accompanying consolidated balance sheets.

[0001596532-16-000244:mdna:147]
Stock-Based Compensation

[0001596532-16-000244:mdna:148]
Compensation expense related to stock-based transactions, including stock options, restricted stock units ("RSUs"), restricted

[0001596532-16-000244:mdna:149]
stock awards (“RSAs”), and stock purchase rights under our employee stock purchase program is measured and recognized in the financial statements based on the estimated fair value of the equity granted. Stock-based compensation expense is generally recognized on a straight-line basis, net of estimated forfeitures, over the requisite service periods of the awards, which typically ranges from two to five years. The assumptions used in our option-pricing model represent management’s best estimates. These estimates involve inherent uncertainties and the application of management’s judgment. If factors change and different assumptions are used, our stock-based compensation expense could be materially different in the future.  These assumptions and estimates are as follows:

[0001596532-16-000244:mdna:150]
Fair Value of Common Stock

[0001596532-16-000244:mdna:151]
The fair value of each stock-based award and option is estimated on the grant date using the Black-Scholes-Merton option-pricing model. This model requires the input of subjective assumptions, including the expected term of the option, the expected volatility of the price of our common stock, risk-free interest rates and the expected dividend yield of our common stock. RSUs are measured based on the fair market values of the underlying stock on the dates of grant.  Prior to our initial public offering, we estimated the fair value of common stock, based on numerous subjective and objective factors at each grant date.

[0001596532-16-000244:mdna:152]
Expected Term

[0001596532-16-000244:mdna:153]
The expected term represents the period that our equity grants are expected to be outstanding. For option grants that are considered to be “simple,” we used the simplified method to determine the expected term which calculates the expected term as the average of the time-to-vesting and the contractual life of the options. For option grants that are not considered “simple,” the expected term is based on historical option exercise behavior and post-vesting cancellations of options by employees. For ESPP grants, the expected term is based on the length of the offering period, which is typically 24 months.

[0001596532-16-000244:mdna:154]
Expected Volatility

[0001596532-16-000244:mdna:155]
The volatility is derived from the average historical stock volatilities of a peer group of public companies within our industry that we consider to be comparable to our business over a period equivalent to the expected term of the stock-based grants. We intend to continue to consistently apply this process using the same or similar public companies until a sufficient amount of historical information regarding the volatility of our own common stock share price becomes available, or unless circumstances change such that the identified companies are no longer similar to us, in which case, more suitable companies whose share prices are publicly available would be utilized in the calculation.

[0001596532-16-000244:mdna:156]
Risk-Free Interest Rate

[0001596532-16-000244:mdna:157]
The risk-free interest rate is based on the U.S. Treasury yield curve in effect at the time of grant for zero-coupon U.S. Treasury notes with maturities approximately equal or equivalent to the option’s remaining expected term.

[0001596532-16-000244:mdna:158]
Dividend Yield

[0001596532-16-000244:mdna:159]
The expected dividend assumption is based on our current expectations about our anticipated dividend policy. We have never declared or paid any cash dividends and do not presently plan to pay cash dividends in the foreseeable future. Consequently, we used an expected dividend yield of zero.

[0001596532-16-000244:mdna:160]
In addition to the assumptions used above, we must also estimate a forfeiture rate to calculate the stock-based compensation expense for our awards. Our forfeiture rate is based on an analysis of our actual forfeitures. We continue to evaluate the appropriateness of the forfeiture rate based on actual forfeiture experience, analysis of employee turnover and other factors. Changes in the estimated forfeiture rate can have a significant impact on our stock-based compensation expense as the cumulative effect of adjusting the rate is recognized in the period the forfeiture estimate is changed. We will continue to use judgment in evaluating the assumptions related to our stock-based compensation on a prospective basis. As we continue to accumulate additional data related to our common stock, we may refine our estimates, which could materially impact our future stock-based compensation expense.

[0001596532-16-000244:mdna:161]
Income Taxes

[0001596532-16-000244:mdna:162]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-16-000244:mdna:163]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-16-000244:mdna:164]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-16-000244:mdna:165]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.

[0001596532-16-000244:mdna:166]
Loss Contingencies

[0001596532-16-000244:mdna:167]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. In assessing loss contingencies, we use significant judgment and assumptions to estimate the likelihood of loss, impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. We record a provision for contingent losses when it is both probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. We will record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements and (ii) the range of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.

[0001596532-16-000244:mdna:168]
Recent Accounting Pronouncements

[0001596532-16-000244:mdna:169]
Refer to “Recent Accounting Pronouncements” in Note 1 to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K.

[0001596532-16-000244:mdna:170]
60
