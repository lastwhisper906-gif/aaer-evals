# ANET 8-K — 0001596532-16-000240 filed 2016-02-18

## item codes, every 8-K on or before 2016-02-25

- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2016-02-25

- none on or before 2016-02-25

## item 2.02 — earnings release, exhibit 99.1

[0001596532-16-000240:8k_2_02:1]
EX-99.1
2
ex991q42015.htm
EXHIBIT 99.1

[0001596532-16-000240:8k_2_02:2]
Exhibit

[0001596532-16-000240:8k_2_02:3]
Exhibit 99.1

[0001596532-16-000240:8k_2_02:4]
Arista Networks, Inc. Reports Fourth Quarter and Full Year 2015 Financial Results

[0001596532-16-000240:8k_2_02:5]
Cloud Networking Adoption Drives Record 2015 Revenue and EPS

[0001596532-16-000240:8k_2_02:6]
SANTA CLARA, Calif., February 18, 2016 - Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large data center and computing environments, today announced financial results for its fourth quarter and year ended December 31, 2015.

[0001596532-16-000240:8k_2_02:7]
Fourth Quarter Financial Highlights

[0001596532-16-000240:8k_2_02:8]
| • | Revenue of $245.4 million, an increase of 41.5% compared to the fourth quarter of 2014, and an increase of 12.8% from the third quarter of 2015. |

[0001596532-16-000240:8k_2_02:9]
| • | Non-GAAP gross margin of 64.0%, compared to non-GAAP gross margin of 67.4% in the fourth quarter of 2014 and 65.5% in the third quarter of 2015. |

[0001596532-16-000240:8k_2_02:10]
| • | GAAP gross margin of 63.6%, compared to GAAP gross margin of 67.1% in the fourth quarter of 2014 and 65.2% in the third quarter of 2015. |

[0001596532-16-000240:8k_2_02:11]
| • | Non-GAAP net income of $57.5 million, or $0.80 per diluted share, compared to non-GAAP net income of $37.3 million, or $0.53 per diluted share, in the fourth quarter of 2014. |

[0001596532-16-000240:8k_2_02:12]
| • | GAAP net income of $43.9 million, or $0.60 per diluted share, compared to GAAP net income of $31.0 million, or $0.43 per diluted share, in the fourth quarter of 2014. |

[0001596532-16-000240:8k_2_02:13]
"Arista has delivered a spectacular 2015. I have been pleased with the rapid acceptance by our customers of Arista’s programmable cloud networking,” stated Jayshree Ullal, Arista President and CEO. “The inevitable shift from legacy enterprises to cloud workloads has fueled Arista’s strong performance of profitable revenue growth and increasing market share.”

[0001596532-16-000240:8k_2_02:14]
Full Year Financial Highlights

[0001596532-16-000240:8k_2_02:15]
| • | Revenue of $837.6 million, an increase of 43.4% compared to fiscal year 2014. |

[0001596532-16-000240:8k_2_02:16]
| • | Non-GAAP gross margin of 65.3%, compared to non-GAAP gross margin of 67.4% in fiscal year 2014. |

[0001596532-16-000240:8k_2_02:17]
| • | GAAP gross margin of 64.9%, compared to GAAP gross margin of 67.1% in fiscal year 2014. |

[0001596532-16-000240:8k_2_02:18]
| • | Non-GAAP net income of $174.2 million or $2.44 per diluted share, compared to non-GAAP net income of $105.5 million, or $1.54 per diluted share, in fiscal year 2014. |

[0001596532-16-000240:8k_2_02:19]
| • | GAAP net income of $121.1 million, or $1.67 per diluted share, compared to GAAP net income of $86.9 million, or $1.29 per diluted share, in fiscal year 2014. |

[0001596532-16-000240:8k_2_02:20]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, "We are pleased with another quarter of double digit quarter over quarter revenue growth, record EPS and enhanced free cash-flow generation.”

[0001596532-16-000240:8k_2_02:21]
Fourth Quarter Company Highlights

[0001596532-16-000240:8k_2_02:22]
| • | Introduced Cloud Connect solutions that extend its spine networking platforms to provide optimized interconnect solutions for private and public cloud data centers, leveraging the technology and operational advantages of Arista’s EOS and CloudVision(R) to reduce both capital and operational costs. |

[0001596532-16-000240:8k_2_02:23]
| • | In January 2016, the next phase of Arista EOS (Extensible Operating System) was unveiled enabling customers to focus on real-time migration from legacy enterprise silos to private, public and hybrid cloud networking, based on three powerful building blocks: Infrastructure, Hybrid Cloud and Container Support. |

[0001596532-16-000240:8k_2_02:24]
Financial Outlook

[0001596532-16-000240:8k_2_02:25]
For the first quarter of 2016, we expect:

[0001596532-16-000240:8k_2_02:26]
| • | Revenue between $232 and $240 million. |

[0001596532-16-000240:8k_2_02:27]
| • | Non-GAAP gross margin between 62% to 65%, and |

[0001596532-16-000240:8k_2_02:28]
| • | Non-GAAP operating margin of approximately 26%. |

[0001596532-16-000240:8k_2_02:29]
Guidance for non-GAAP financial measures excludes legal expenses associated with the OptumSoft and Cisco litigation, stock-based compensation and other non-recurring expenses. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis.

[0001596532-16-000240:8k_2_02:30]
Prepared Materials and Conference Call Information

[0001596532-16-000240:8k_2_02:31]
Arista executives will discuss fourth quarter and fiscal year 2015 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial 1-877-201-0168 in the United States or 1-647-788-4901 from outside the US. The Conference ID is 21363750.

[0001596532-16-000240:8k_2_02:32]
The financial results conference call will also be available via live webcast on our investor relations website at investors.arista.com.  Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s Investor Relations website.

[0001596532-16-000240:8k_2_02:33]
Forward-Looking Statements

[0001596532-16-000240:8k_2_02:34]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the first quarter of FY 2016, statements regarding the inevitable shift from legacy enterprises to cloud workloads and statements regarding the anticipated benefits from the next phase of Arista EOS. Forward-looking statements are subject to a number of uncertainties and risks that could cause actual results to differ materially from those anticipated in the forward-looking statements including risks associated with: Arista Networks’ limited operating history; risks associated with Arista Networks’ rapid growth; Arista Networks’ customer concentration; Arista Networks’ dispute with Cisco Systems, Inc.  including Arista Networks’ ability to obtain a determination that alternative product implementations are not covered by remedial orders; Arista Networks’ dispute with OptumSoft, Inc.; requests for more favorable terms and conditions from our large end customers; declines in the sales prices of our products and services; changes in customer order patterns or customer mix; increased competition in our products and service markets, including the data center market; dependence on the introduction and market acceptance of new product offerings and standards; rapid technological and market change; the evolution of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; and general market, political, economic and business conditions.  Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s Quarterly Report on Form 10-Q filed with the SEC on November 6, 2015, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at http://investors.arista.com and on the SEC’s website at www.sec.gov. All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-16-000240:8k_2_02:35]
Non-GAAP Financial Measures

[0001596532-16-000240:8k_2_02:36]
The company reports certain non-GAAP financial measures that exclude stock-based compensation expenses, expenses associated with the OptumSoft and Cisco litigation, and other non-recurring charges. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends.  In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-16-000240:8k_2_02:37]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP net income, net income per diluted share, gross margin, or operating margin. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-16-000240:8k_2_02:38]
About Arista Networks

[0001596532-16-000240:8k_2_02:39]
Arista Networks was founded to pioneer and deliver software-driven cloud networking solutions for large data center storage and computing environments. Arista’s award-winning platforms, ranging in Ethernet speeds from 10 to 100 gigabits per second, redefine scalability, agility and resilience. Arista has shipped more than five million cloud networking ports worldwide with CloudVision(R) and EOS, an advanced network operating system. Committed to open standards, Arista is a founding member of the 25/50GbE consortium. Arista Networks products are available worldwide directly and through partners.

[0001596532-16-000240:8k_2_02:40]
ARISTA, EOS, CloudVision(R) and Spline are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-16-000240:8k_2_02:41]
Additional information and resources can be found at: http://www.arista.com.

[0001596532-16-000240:8k_2_02:42]
| Media ContactAmanda JaramilloCorporate Communications(408) 547-5798amanda@arista.com |  | Investor ContactChuck ElliottProduct and Investor Advocacy(408) 547-5549chuck@arista.com |

[0001596532-16-000240:8k_2_02:43]
ARISTA NETWORKS, INC.

[0001596532-16-000240:8k_2_02:44]
Condensed Consolidated Statements of Income

[0001596532-16-000240:8k_2_02:45]
(Unaudited in thousands, except per share amounts)

[0001596532-16-000240:8k_2_02:46]
|  | Three Months Ended December 31, |  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 217,325 |  |  | $ | 157,205 |  |  | $ | 744,877 |  |  | $ | 531,543 |  |
| Service | 28,121 |  |  | 16,284 |  |  | 92,714 |  |  | 52,563 |  |
| Total revenue | 245,446 |  |  | 173,489 |  |  | 837,591 |  |  | 584,106 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 81,142 |  |  | 51,312 |  |  | 263,585 |  |  | 174,004 |  |
| Service | 8,136 |  |  | 5,737 |  |  | 30,446 |  |  | 18,011 |  |
| Total cost of revenue | 89,278 |  |  | 57,049 |  |  | 294,031 |  |  | 192,015 |  |
| Gross profit | 156,168 |  |  | 116,440 |  |  | 543,560 |  |  | 392,091 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 57,413 |  |  | 44,344 |  |  | 209,448 |  |  | 148,909 |  |
| Sales and marketing | 31,308 |  |  | 25,016 |  |  | 109,084 |  |  | 85,338 |  |
| General and administrative | 18,050 |  |  | 8,078 |  |  | 75,720 |  |  | 32,331 |  |
| Total operating expenses | 106,771 |  |  | 77,438 |  |  | 394,252 |  |  | 266,578 |  |
| Income from operations | 49,397 |  |  | 39,002 |  |  | 149,308 |  |  | 125,513 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense—related party | — |  |  | — |  |  | — |  |  | (782 | ) |
| Interest expense | (746 | ) |  | (768 | ) |  | (3,152 | ) |  | (5,498 | ) |
| Other income (expense), net | (109 | ) |  | (151 | ) |  | (147 | ) |  | 2,275 |  |
| Total other income (expense), net | (855 | ) |  | (919 | ) |  | (3,299 | ) |  | (4,005 | ) |
| Income before provision for income taxes | 48,542 |  |  | 38,083 |  |  | 146,009 |  |  | 121,508 |  |
| Provision for income taxes | 4,618 |  |  | 7,046 |  |  | 24,907 |  |  | 34,658 |  |
| Net income | $ | 43,924 |  |  | $ | 31,037 |  |  | $ | 121,102 |  |  | $ | 86,850 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 43,431 |  |  | $ | 30,251 |  |  | $ | 119,115 |  |  | $ | 68,889 |  |
| Diluted | $ | 43,464 |  |  | $ | 30,328 |  |  | $ | 119,264 |  |  | $ | 70,524 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 0.65 |  |  | $ | 0.48 |  |  | $ | 1.81 |  |  | $ | 1.42 |  |
| Diluted | $ | 0.60 |  |  | $ | 0.43 |  |  | $ | 1.67 |  |  | $ | 1.29 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | 67,111 |  |  | 63,186 |  |  | 65,964 |  |  | 48,427 |  |
| Diluted | 72,062 |  |  | 70,219 |  |  | 71,411 |  |  | 54,590 |  |

[0001596532-16-000240:8k_2_02:47]
ARISTA NETWORKS, INC.

[0001596532-16-000240:8k_2_02:48]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-16-000240:8k_2_02:49]
(Unaudited in thousands, except percentages and per share amounts)

[0001596532-16-000240:8k_2_02:50]
|  | Three Months Ended December 31, |  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| GAAP gross profit | $ | 156,168 |  |  | $ | 116,440 |  |  | $ | 543,560 |  |  | $ | 392,091 |  |
| GAAP gross margin | 63.6 | % |  | 67.1 | % |  | 64.9 | % |  | 67.1 | % |
| Stock-based compensation expense | 842 |  |  | 543 |  |  | 3,048 |  |  | 1,535 |  |
| Non-GAAP gross profit | $ | 157,010 |  |  | $ | 116,983 |  |  | $ | 546,608 |  |  | $ | 393,626 |  |
| Non-GAAP gross margin | 64.0 | % |  | 67.4 | % |  | 65.3 | % |  | 67.4 | % |
| GAAP income from operations | $ | 49,397 |  |  | $ | 39,002 |  |  | $ | 149,308 |  |  | $ | 125,513 |  |
| Stock-based compensation expense | 12,978 |  |  | 8,050 |  |  | 45,303 |  |  | 27,619 |  |
| Litigation expense | 8,956 |  |  | — |  |  | 41,424 |  |  | — |  |
| Non-GAAP income from operations | $ | 71,331 |  |  | $ | 47,052 |  |  | $ | 236,035 |  |  | $ | 153,132 |  |
| Non-GAAP operating margin | 29.1 | % |  | 27.1 | % |  | 28.2 | % |  | 26.2 | % |
| GAAP net income | $ | 43,924 |  |  | $ | 31,037 |  |  | $ | 121,102 |  |  | $ | 86,850 |  |
| Stock-based compensation expense | 12,978 |  |  | 8,050 |  |  | 45,303 |  |  | 27,619 |  |
| Litigation expense | 8,956 |  |  | — |  |  | 41,424 |  |  | — |  |
| Release of income tax reserve | (968 | ) |  | — |  |  | (7,344 | ) |  | (4,931 | ) |
| Realized gain on note receivable | — |  |  | — |  |  | — |  |  | (4,000 | ) |
| Income tax effect on non-GAAP exclusions | (7,424 | ) |  | (1,750 | ) |  | (26,292 | ) |  | — |  |
| Non-GAAP net income | $ | 57,466 |  |  | $ | 37,337 |  |  | $ | 174,193 |  |  | $ | 105,538 |  |
| Weighted average shares used in computing GAAP diluted income per share attributable to common stockholders | 72,062 |  |  | 70,219 |  |  | 71,411 |  |  | 54,590 |  |
| Additional weighted average dilutive shares1 | — |  |  | — |  |  | — |  |  | 13,797 |  |
| Non-GAAP weighted average diluted shares | 72,062 |  |  | 70,219 |  |  | 71,411 |  |  | 68,387 |  |
| GAAP diluted net income per share attributable to common stockholders | $ | 0.60 |  |  | $ | 0.43 |  |  | $ | 1.67 |  |  | $ | 1.29 |  |
| Net income attributable to participating securities | 0.01 |  |  | 0.01 |  |  | 0.03 |  |  | 0.30 |  |
| Non-GAAP adjustments to net income | 0.19 |  |  | 0.09 |  |  | 0.74 |  |  | 0.34 |  |
| Non-GAAP adjustments to diluted shares | — |  |  | — |  |  | — |  |  | (0.39 | ) |
| Non-GAAP diluted net income per share | $ | 0.80 |  |  | $ | 0.53 |  |  | $ | 2.44 |  |  | $ | 1.54 |  |
| Summary of Stock-Based Compensation Expense |  |  |  |  |  |  |  |
| Cost of revenue | $ | 842 |  |  | $ | 543 |  |  | $ | 3,048 |  |  | $ | 1,535 |  |
| Research and development | 7,171 |  |  | 4,688 |  |  | 25,515 |  |  | 14,986 |  |
| Sales and marketing | 3,316 |  |  | 1,897 |  |  | 11,454 |  |  | 7,643 |  |
| General and administrative | 1,649 |  |  | 922 |  |  | 5,286 |  |  | 3,455 |  |
| Total | $ | 12,978 |  |  | $ | 8,050 |  |  | $ | 45,303 |  |  | $ | 27,619 |  |

[0001596532-16-000240:8k_2_02:51]
______________________

[0001596532-16-000240:8k_2_02:52]
1Includes weighted average shares from the issuance of shares upon our IPO and the assumed conversion of preferred stock and notes payable at the beginning of each quarter.

[0001596532-16-000240:8k_2_02:53]
ARISTA NETWORKS, INC.

[0001596532-16-000240:8k_2_02:54]
Consolidated Balance Sheets

[0001596532-16-000240:8k_2_02:55]
(Unaudited in thousands)

[0001596532-16-000240:8k_2_02:56]
|  | December 31, |
|  | 2015 |  | 2014 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 687,326 |  |  | $ | 240,031 |  |
| Marketable securities | — |  |  | 209,426 |  |
| Accounts receivable | 144,263 |  |  | 96,982 |  |
| Inventories | 92,129 |  |  | 78,006 |  |
| Deferred tax assets | — |  |  | 12,252 |  |
| Prepaid expenses and other current assets | 50,610 |  |  | 42,782 |  |
| Total current assets | 974,328 |  |  | 679,479 |  |
| Property and equipment, net | 79,706 |  |  | 71,558 |  |
| Investments | 36,636 |  |  | 36,636 |  |
| Deferred tax assets | 48,429 |  |  | 11,510 |  |
| Other assets | 20,791 |  |  | 11,840 |  |
| TOTAL ASSETS | $ | 1,159,890 |  |  | $ | 811,023 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 43,966 |  |  | $ | 32,428 |  |
| Accrued liabilities | 60,971 |  |  | 40,369 |  |
| Deferred revenue | 122,049 |  |  | 60,327 |  |
| Other current liabilities | 8,025 |  |  | 11,249 |  |
| Total current liabilities | 235,011 |  |  | 144,373 |  |
| Income taxes payable | 14,060 |  |  | 17,323 |  |
| Lease financing obligations, non-current | 41,210 |  |  | 42,547 |  |
| Deferred revenue, non-current | 74,759 |  |  | 46,141 |  |
| Other long-term liabilities | 6,698 |  |  | 4,981 |  |
| TOTAL LIABILITIES | 371,738 |  |  | 255,365 |  |
| Commitments and contingencies |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock | 7 |  |  | 7 |  |
| Additional paid-in capital | 537,904 |  |  | 426,171 |  |
| Retained earnings | 250,915 |  |  | 129,814 |  |
| Accumulated other comprehensive loss | (674 | ) |  | (334 | ) |
| TOTAL STOCKHOLDERS’ EQUITY | 788,152 |  |  | 555,658 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 1,159,890 |  |  | $ | 811,023 |  |

[0001596532-16-000240:8k_2_02:57]
ARISTA NETWORKS, INC.

[0001596532-16-000240:8k_2_02:58]
Consolidated Statements of Cash Flows

[0001596532-16-000240:8k_2_02:59]
(Unaudited in thousands)

[0001596532-16-000240:8k_2_02:60]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 121,102 |  |  | $ | 86,850 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 13,671 |  |  | 10,021 |  |
| Stock-based compensation | 45,303 |  |  | 27,619 |  |
| Deferred income taxes | (24,409 | ) |  | (6,774 | ) |
| Amortization of investment premiums | 1,471 |  |  | 348 |  |
| Realized gain on notes receivable | — |  |  | (4,000 | ) |
| Amortization of debt discount | — |  |  | 527 |  |
| Write-off of debt discount on notes payable | — |  |  | 680 |  |
| Excess tax benefit on stock based-compensation | (37,251 | ) |  | (17,436 | ) |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | (47,281 | ) |  | (18,984 | ) |
| Inventories | (14,123 | ) |  | (13,425 | ) |
| Prepaid expenses and other current assets | (7,827 | ) |  | (15,257 | ) |
| Other assets | (3,087 | ) |  | (4,261 | ) |
| Accounts payable | 9,037 |  |  | 14,007 |  |
| Accrued liabilities | 20,398 |  |  | 18,874 |  |
| Deferred revenue | 90,340 |  |  | 47,564 |  |
| Interest payable | — |  |  | (1,630 | ) |
| Interest payable—related party | — |  |  | 670 |  |
| Income taxes payable | 32,018 |  |  | 4,377 |  |
| Other liabilities | 1,171 |  |  | 2,105 |  |
| Net cash provided by operating activities | 200,533 |  |  | 131,875 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of marketable securities | — |  |  | (210,019 | ) |
| Proceeds from marketable securities | 208,200 |  |  | — |  |
| Purchases of property and equipment | (19,238 | ) |  | (13,134 | ) |
| Proceeds from repayment of notes receivable | — |  |  | 8,000 |  |
| Change in restricted cash | (4,041 | ) |  | 4,040 |  |
| Purchases of intangible assets | (751 | ) |  | — |  |
| Other investing activities | — |  |  | (38,249 | ) |
| Net cash provided by (used) in investing activities | 184,170 |  |  | (249,362 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from initial public offering, net of issuance cost | — |  |  | 239,315 |  |
| Repayment on notes payable | — |  |  | (20,000 | ) |
| Principal payments of lease financing obligations | (1,086 | ) |  | (793 | ) |
| Payments made for deferred offering costs | (261 | ) |  | — |  |
| Excess tax benefit on stock-based compensation | 37,251 |  |  | 17,436 |  |
| Proceeds from issuance of common stock upon exercising options, net of repurchases | 17,835 |  |  | 8,020 |  |
| Proceeds from issuance of common stock, employee stock purchase plan | 9,366 |  |  | — |  |
| Net cash provided by financing activities | 63,105 |  |  | 243,978 |  |
| Effect of exchange rate changes | (513 | ) |  | (124 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 447,295 |  |  | 126,367 |  |
| CASH AND CASH EQUIVALENTS—Beginning of year | 240,031 |  |  | 113,664 |  |
| CASH AND CASH EQUIVALENTS—End of year | $ | 687,326 |  |  | $ | 240,031 |  |
