# ANET notes — 0001596532-16-000244


## anet:ConcentrationRiskComponentsSupplierRiskPolicyTextBlock

[0001596532-16-000244:notes:1]
We work closely with third-party contract manufacturing suppliers to manufacture our products. As of December 31, 2015 and December 31, 2014, two suppliers provided substantially all of our electronic manufacturing services. Our contract manufacturing suppliers deliver our products to our third party direct fulfillment facilities where our EOS software is installed on our products.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers. Our products rely on key components, including certain integrated circuit components and power supplies, some of which our contract manufacturers purchase on our behalf from a limited number of suppliers, including certain sole source providers. We do not have guaranteed supply contracts with any of our component suppliers, and our suppliers could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, sales of our products could be delayed or halted entirely or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.


## anet:ScheduleofLeaseFinancingObligationsTableTextBlock

[0001596532-16-000244:notes:2]
As of December 31, 2015, the future minimum payments due under the lease financing obligation were as follows (in thousands):

[0001596532-16-000244:notes:3]
| Years Ending December 31, |  |
| 2016 | $ | 5,754 |  |
| 2017 | 5,933 |  |
| 2018 | 6,113 |  |
| 2019 | 6,293 |  |
| 2020 | 6,477 |  |
| Thereafter | 18,810 |  |
| Total payments | 49,380 |  |
| Less: interest and land lease expense | (30,463 | ) |
| Total payments under facility financing obligations | 18,917 |  |
| Property reverting to landlord | 23,629 |  |
| Present value of obligation | 42,546 |  |
| Less current portion | (1,336 | ) |
| Long-term portion of obligation | $ | 41,210 |  |


## anet:ScheduleofSharebasedCompensationSharesAvailableForGrantActivityTableTextBlock

[0001596532-16-000244:notes:4]
The following table presents the stock activity and the total number of shares available for grant as of December 31, 2015 (in thousands):

[0001596532-16-000244:notes:5]
|  |  | Number of Shares |
| Balance—December 31, 2014 |  | 11,612 |  |
| Options granted |  | (1,235 | ) |
| RSUs granted |  | (846 | ) |
| Options canceled |  | 912 |  |
| Options repurchased |  | 17 |  |
| RSUs forfeited |  | 34 |  |
| Balance—December 31, 2015 |  | 10,494 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001596532-16-000244:notes:6]
Basis of Presentation and Principles of Consolidation

[0001596532-16-000244:notes:7]
The accompanying consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and are prepared in accordance with U.S. generally accepted accounting principles (GAAP). All significant intercompany accounts and transactions have been eliminated.

[0001596532-16-000244:notes:8]
Certain prior period amounts have been reclassified to conform with current period presentation. Commencing in the first quarter of fiscal 2015, we have disaggregated total revenue and cost of revenue into "Product" and "Service".  Commencing in the second quarter of fiscal 2015, we have reclassified deferred cost of revenue from inventories to other current assets as the balance does not represent property available for sale or used in the production process. The change resulted in a $2.5 million reclassification between inventory and other current assets retrospectively applied to our fiscal 2014 consolidated balance sheet.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001596532-16-000244:notes:9]
Cash and Cash Equivalents

[0001596532-16-000244:notes:10]
We consider all highly liquid investments with stated maturity of three months or less at the time of purchase to be cash equivalents. Cash and cash equivalents consist of cash on deposit with various financial institutions and highly liquid investments in money market funds. Interest is accrued as earned.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-16-000244:notes:11]
Commitments and Contingencies

[0001596532-16-000244:notes:12]
Operating Leases

[0001596532-16-000244:notes:13]
We lease various operating spaces in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2024. These arrangements require us to pay certain operating expenses, such as taxes, repairs, and insurance and contain renewal and escalation clauses. We recognize rent expense under these arrangements on a straight-line basis over the term of the lease.

[0001596532-16-000244:notes:14]
As of December 31, 2015, the aggregate future minimum payments under non-cancelable operating leases consist of the following (in thousands):

[0001596532-16-000244:notes:15]
| Years Ending December 31, |  |
| 2016 | $ | 6,306 |  |
| 2017 | 6,678 |  |
| 2018 | 6,260 |  |
| 2019 | 5,809 |  |
| 2020 | 5,580 |  |
| Thereafter | 21,450 |  |
| Total minimum future lease payments | $ | 52,083 |  |

[0001596532-16-000244:notes:16]
Rent expense for all operating leases amounted to $6.7 million, $3.3 million and $3.6 million for the years ended December 31, 2015, 2014 and 2013, respectively.

[0001596532-16-000244:notes:17]
Financing Obligation—Build-to-Suit Lease

[0001596532-16-000244:notes:18]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013.

[0001596532-16-000244:notes:19]
Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction such as our financial involvement in structural elements of asset construction, making decisions related to tenant improvement costs and purchasing insurance not reimbursable by the buyer-lessor (the Landlord), we were deemed the owner of the building (for accounting purposes only) during the construction period. We continue to maintain involvement in the property post construction completion and lack transferability of the risks and rewards of ownership, due to our required maintenance of a $4.0 million letter of credit, in addition to our ability and option to sublease our portion of the leased building for fees substantially higher than our base rate. Due to our continued involvement in the property and lack of transferability of related risks and rewards of ownership to the Landlord post construction, we account for the building and related improvements as a lease financing obligation. Accordingly, as of December 31, 2015 and  2014, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $42.5 million and $43.6 million, respectively. As of December 31, 2015, $1.3 million and $41.2 million were recorded as short-term and long-term financing obligations, respectively.

[0001596532-16-000244:notes:20]
Land lease expense under our lease financing obligation included in rent expense above, amounted to $1.3 million and $1.2 million for the years ended December 31, 2015 and 2014, respectively. There was no land lease expense for the year ended December 31, 2013.

[0001596532-16-000244:notes:21]
Upon completion of construction in 2013, we evaluated the de-recognition of the asset and liability under the sale-leaseback accounting guidance. We concluded that we had forms of continued economic involvement in the facility, and therefore did not meet with the provisions for sale-leaseback accounting. Therefore, the lease is accounted for as a financing obligation and lease payments will be attributed to (1) a reduction of the principal financing obligation; (2) imputed interest expense; and (3) land lease expense (which is considered an operating lease and a component of cost of goods sold and operating expenses) representing an imputed cost to lease the underlying land of the building. In addition, the underlying building asset is depreciated over the building’s estimated useful life of 30 years. At the conclusion of the initial lease term, we will de-recognize both the net book values of the asset and the remaining financing obligation.

[0001596532-16-000244:notes:22]
Purchase Commitments

[0001596532-16-000244:notes:23]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply.  We issue purchase orders to our contract manufacturers for finished product and a significant portion of these orders consist of firm non-cancelable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancelable, including integrated circuits, which are consigned to our contract manufacturers.   As of December 31, 2015, we had non-cancelable purchase commitments of $43.9 million to our contract manufacturers and suppliers.

[0001596532-16-000244:notes:24]
We have provided restricted deposits to our third-party contract manufacturers and vendors to secure our obligations to purchase inventory. We had $2.3 million in restricted deposits as of December 31, 2015 and December 31, 2014. Restricted deposits are classified in other assets in our accompanying consolidated balance sheets.

[0001596532-16-000244:notes:25]
Guarantees

[0001596532-16-000244:notes:26]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers the unamortized value of the product based on its estimated useful life. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for lease facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-16-000244:notes:27]
Legal Proceedings

[0001596532-16-000244:notes:28]
OptumSoft, Inc. Matters

[0001596532-16-000244:notes:29]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-16-000244:notes:30]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft copies of certain components of our software for evaluation by OptumSoft, (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches, (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers, (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us, and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dtd July 27, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.

[0001596532-16-000244:notes:31]
OptumSoft has identified in confidential documents certain software components it claims to own, which are generally applicable tools and utility subroutines and not networking specific code. We cannot assure which software components OptumSoft may ultimately claim to own in the litigation or whether such claimed components are material.

[0001596532-16-000244:notes:32]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we assert our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we assert that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We ask the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also assert that, even if we are found not to own any particular components at issue, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation. On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have meritorious defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-16-000244:notes:33]
The parties tried the case for Phase I of the proceedings, relating to contract interpretation and application of the contract to certain claimed source code in September 2015.  On December 16, 2015, the Court issued a Proposed Statement of Decision Following Phase 1 Trial.  In that Proposed Statement, the Court agreed with and adopted Arista’s interpretation of the 2004 agreement, and held that Arista, and not OptumSoft, owns all of the software that was put at issue in Phase 1. On January 8, 2016, OptumSoft filed its objections to the Court’s Proposed Statement of Decision.  The Court has not ruled on those objections to date, and Arista anticipates a ruling in the first calendar quarter of 2016.  The remaining issues that were not addressed in the court trial are currently scheduled to be tried in April 2016.

[0001596532-16-000244:notes:34]
We intend to vigorously defend against any action brought against us by OptumSoft. However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor. For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft. If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license. An adverse litigation ruling could result in a significant damages award against us and injunctive relief. In addition, OptumSoft could assert additional or different claims against us, including claims that our license from OptumSoft is invalid.

[0001596532-16-000244:notes:35]
Additionally, the existence of this lawsuit could cause concern among our customers and potential customers and could adversely affect our business and results of operations. An adverse litigation ruling could also result in a significant damages award against us and the injunctive relief described above. In addition, if our license was ruled to have been terminated, and we were not able to negotiate a new license from OptumSoft on reasonable terms, we could be prohibited from selling products that incorporate OptumSoft intellectual property. Any such adverse ruling could materially adversely affect our business, prospects, results of operations and financial condition. Whether or not we prevail in a lawsuit, we expect that any litigation would be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-16-000244:notes:36]
Cisco Systems, Inc. (“Cisco”) Matters

[0001596532-16-000244:notes:37]
On December 5, 2014, Cisco filed two complaints against us in District Court for the Northern District of California, which are proceeding as Case No. 4:14-cv-05343 (“’43 Case”) and Case No. 5:14-cv-05344 (“’44 Case”).  In the ’43 Case, Cisco alleges that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the 875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”).  Cisco seeks, as relief for our alleged infringement in the ’43 Case, lost profits and/or reasonable royalty damages in an unspecified amount, including treble damages, attorney’s fees, and associated costs.  Cisco also seeks injunctive relief in the ’43 Case.  On February 10, 2015, the court granted our unopposed motion to stay the ’43 Case until the proceedings before the United States International Trade Commission (“USITC”) pertaining to the same patents (as discussed below) become final.  In the ’44 Case, Cisco’s complaint alleges that we infringe U.S. Patent Nos. 7,047,526 and 7,953,886 (respectively, “the ’526 patent” and “the ’886 patent”), and further alleges that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI.”  As relief for our alleged patent infringement in the ’44 Case, Cisco seeks lost profits and/or reasonable royalty damages in an unspecified amount including treble damages, attorney’s fees, and associated costs as well as injunctive relief.  As relief for our alleged copyright infringement, Cisco seeks damages in an unspecified amount in the form of alleged lost profits, profits from our alleged infringement, statutory damages, attorney’s fees and associated costs.  Cisco also seeks injunctive relief against our alleged copyright infringement.  On February 13, 2015, we answered the complaint in the ’44 Case, denying the patent and copyright infringement allegations and also raising numerous affirmative defenses.  On March 6, 2015, Cisco filed an amended complaint against us the ’44 Case.  In response, we moved to dismiss Cisco’s allegations of willful patent infringement pre-suit indirect patent infringement. The Court granted the motion with leave to amend on July 2, 2015. On July 23, 2015, Cisco filed an amended complaint. On January 25, 2016, we sought leave to file counterclaims against Cisco in the ’44 case for antitrust and unfair competition.  Trial has been set for November 21, 2016 in the ’44 Case. Trial has not been scheduled in the ’43 Case.

[0001596532-16-000244:notes:38]
On December 19, 2014, Cisco filed two complaints against us in the USITC, alleging that Arista has violated Section 337 of the Tariff Act of 1930, as amended. The complaints have been instituted as ITC Inv. Nos. 337-TA-944 (“944 Investigation”) and 337-TA-945 (“945 Investigation”).   In the 944 Investigation, Cisco initially alleged that certain Arista switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents.  Cisco has subsequently dropped the ’296 patent from the 944 Investigation.  In the 945 Investigation, Cisco alleges that certain Arista switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents.  In both the 944 and 945 Investigations, Cisco seeks, among other things, a limited exclusion order barring entry into the United States of accused switch products (including 7000 Series of switches) and a cease and desist order against us restricting our activities with respect to our imported accused switch products.  On February 11, 2015, we responded to the notices of investigation and complaints in the 944 and 945 Investigations by, among other things, denying the patent infringement allegations and raising numerous affirmative defenses.

[0001596532-16-000244:notes:39]
The Administrative Law Judge assigned to the 944 Investigation issued a procedural schedule calling for, among other events:  an evidentiary hearing on Sept. 9-11 & 15-17, 2015; issuance of an initial determination regarding our alleged violations on January 27, 2016; and the target date for completion on May 27, 2016.  On January 27, 2016 the Administrative Law Judge issued a revised procedural schedule extending the date for issuance an initial determination to February 2, 2016 and the target date to June 2, 2016.  The final determination in the 944 Investigation is then subject to Presidential review. The hearing has been completed and all post trial briefs have been submitted to the USITC.  On February 2, 2016, the Administrative Law Judge issued his initial determination finding a violation of section 337 of the Tariff Act.  More specifically, it was found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringe asserted claims 1, 2, 8-11, and 17-19 of the ‘537 patent; asserted claims 6, 7, 20, and 21 of the ‘592 patent; and asserted claims 5, 7, 45, and 46 of the ‘145 patent.  A violation of section 337 was not found with respect to any asserted claims of the ‘597 and ‘164 patents. On February 17, 2016, we filed a request for the Commission to review certain issues, including the infringement findings in the initial determination, and the Commission must decide whether to grant the review no later than 60 days from the date of the initial determination (February 2, 2016).

[0001596532-16-000244:notes:40]
The Administrative Law Judge assigned to the 945 Investigation issued a procedural schedule calling for, among other events:  an evidentiary hearing on November 9-20, 2015; issuance of an initial determination regarding our alleged violations on April 26, 2016; and the target date for completion on August 26, 2016.  The evidentiary hearing was conducted in November 2015 and all post-hearing briefing has been completed. We are awaiting the initial determination from the Administrative Law Judge. The initial determination will be subject to review by the Commission, which will then issue a final determination and any remedial orders on August 26, 2016. If the final determination finds a violation, it will be subject to Presidential review.

[0001596532-16-000244:notes:41]
On April 1, 2015, we filed petitions for Inter Partes Review with the United States Patent Trial and Appeal Board (“PTAB”) seeking to invalidate Cisco’s ’597, ’211, and ’668 patents.  On April 10, 2015, we filed petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853 and ’577 patents.  On April 16, 2015, we filed additional petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853 and ’577 patents.  On August 11, 2015, we filed a second petition for Inter Partes Review of Cisco’s ’668 patent.  On October 6, 2015 we filed a second petition for Inter Partes Review of Cisco’s ’211 patent.  On October 6, 2015, the PTAB granted our petition for Inter Partes Review of Cisco’s ’597 patent and our first petition for Inter Partes review of Cisco’s ’211 patents, but denied one of our petitions for Inter Partes Review of Cisco’s ’668 patent. On October 19, 2015 and October 22, 2015, the PTAB denied four petitions relating to the ‘853 and ‘577 patents. On November 18, 2015, we filed a request for rehearing on one of the denied petitions related to the ’577 patent and we are awaiting a decision on the request.  On December 9, 2015, we filed a petition for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’537 patent, and additional petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853, ’577, and ’668 patents.  On February 16, 2016, the PTAB denied our second petition for Inter Partes review of the ’668 patent. We are awaiting decisions by the PTAB on our remaining petitions for Inter Partes Review of the ’537, ’853, ’577, and ’668 patents.  For those petitions that the PTAB grants, the PTAB must issue its final written decision on validity within twelve months of its institution decision.

[0001596532-16-000244:notes:42]
We intend to vigorously defend against Cisco’s lawsuits, as summarized in the preceding paragraphs.  However, we cannot be certain that any claims by Cisco would be resolved in our favor regardless of the merit of the claims.  For example, an adverse litigation ruling could result in a significant damages award against us, could further result in the above described injunctive relief, could result in a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products to the extent that we are found to infringe any valid claims asserted against us Cisco. In particular, with respect to the 944 and 945 Investigations, if our products are found to infringe any patents that are the subject of those investigations, the USITC would likely issue a limited exclusion order barring entry into the United States of our products (including 7000 Series of switches) and a cease and desist order restricting our activities with respect to our imported products. If we become subject to a limited exclusion order and it is not disapproved by the US Trade Representative, we will need to remove features or develop technical design-arounds in order to take the products outside of the scope of any patent found to have been infringed and the subject of a violation. We may not be successful in developing technical design-arounds that do not infringe the patents or that are acceptable to our customers. Our development efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management. Moreover, we may seek to obtain clearance for any such technical design-arounds from U.S. Customs and Border Patrol (“CBP”) in order to continue the importation of our products, and we may be unable to do so in a timely manner, if at all. In the case that we attempt to change our manufacturing, importation processes and shipping workflows to comply with any limited exclusion order or cease and desist order, such changes may be extremely costly, time consuming and we may not be able to implement such changes successfully. Any failure to develop effective technical design-arounds, obtain timely clearance of such technical design-arounds or successfully change our manufacturing, importation processes or shipping workflows may cause a disruption in our shipments and impact our revenues, business and reputation.  Any such adverse ruling could materially adversely affect our business, prospects, results of operation and financial condition.

[0001596532-16-000244:notes:43]
In the event that the USITC issues a limited exclusion order and cease and desist order, Cisco may also seek to enforce any limited exclusion order or cease and desist order by filing for an enforcement action at the USITC.  In such a proceeding, we would need to demonstrate that our technical design-arounds render our products non-infringing or otherwise outside the scope of the limited exclusion order or cease and desist order.  If we are unable to do so then any product shipments after the effective date of the limited exclusion order or cease and desist order (whether from existing imported inventory or from products assembled from foreign sourced components) could be subject to significant civil penalties, potential seizure of that inventory which was found to have an ineffective technical design-around, and an injunction from importing further products until we implement additional technical design-arounds.

[0001596532-16-000244:notes:44]
Additionally, the existence of this lawsuit could cause concern among our customers and partners and could adversely affect our business and results of operations.  Whether or not we prevail in the lawsuit, we expect that the litigation will be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-16-000244:notes:45]
With respect to the various legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated at this time.  However, the outcome of litigation is inherently uncertain.  Therefore, if one or more of these legal matters were resolved against us in a reporting period for amounts in excess of management’s expectations, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-16-000244:notes:46]
Other Matters

[0001596532-16-000244:notes:47]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.  We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated.  Based on currently available information, management does not believe that liability relating to these other unresolved matters is probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows.  However, litigation is subject to inherent uncertainties and our view of these matters may change in the future.  Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001596532-16-000244:notes:48]
Loss Contingencies

[0001596532-16-000244:notes:49]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. In assessing loss contingencies, we use significant judgment and assumptions to estimate the likelihood of loss, impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. We record a provision for contingent losses when it is both probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. We will record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements and (ii) the range of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001596532-16-000244:notes:50]
Comprehensive Income

[0001596532-16-000244:notes:51]
Comprehensive income is comprised of net income and other comprehensive income. Unrealized gains and losses on available-for-sale investments and foreign currency translation adjustments are included in our other comprehensive income or loss.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-16-000244:notes:52]
Equity Award Plan Activities

[0001596532-16-000244:notes:53]
2014 Equity Incentive Plan

[0001596532-16-000244:notes:54]
In April 2014, the board of directors and stockholders approved the 2014 Equity Incentive Plan (the “2014 Plan”), effective on the first day that our common stock was publicly traded. A total of 6,510,000 shares of our common stock were initially reserved for issuance under the 2014 Plan. In addition, the shares reserved for issuance under our 2014 Plan also included (a) those shares reserved but unissued under the 2011 Plan and 2004 Plan as of the effective date and (b) shares returned to our 2011 Plan and 2004 Plan as the result of expiration or termination of options (provided that the maximum number of shares that may be added to the 2014 Plan pursuant to (a) and (b) is 20,025,189 shares).  Awards granted under the 2014 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Awards (“RSAs”), Stock Appreciation Rights (“SARs”) or Restricted Stock Units (“RSUs”).  The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of our shares outstanding on the immediately preceding December 31, but not to exceed 12,500,000 shares, unless the board of directors, in its discretion, determines to make a smaller increase.

[0001596532-16-000244:notes:55]
On February 12, 2016, the board authorized the increase to shares available for issuance under the plan of 3% of the total shares outstanding on January 1, 2016.  The increase amounted to 2,043,946 shares.

[0001596532-16-000244:notes:56]
2014 Employee Stock Purchase Plan

[0001596532-16-000244:notes:57]
In April 2014, the board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. A total of 651,000 shares of our common stock were initially reserved for future issuance under the ESPP. The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year commencing with 2015 by the number of shares equal to 1% of our shares outstanding immediately preceding December 31, but not to exceed 2,500,000 shares, unless the board of directors, in its discretion, determines to make a smaller increase. As of December 31, 2015, there remain 1,058,754 shares available for issuance under the ESPP.

[0001596532-16-000244:notes:58]
On February 12, 2016, the board authorized the increase to shares available for issuance under the plan of 1% of the total shares outstanding on January 1, 2016.  The increase amounted to 681,315 shares.

[0001596532-16-000244:notes:59]
Stock Option Activities

[0001596532-16-000244:notes:60]
The following table summarizes the option and RSA (Restricted Stock Award) activity under our Plans and related information:

[0001596532-16-000244:notes:61]
|  |  | Options and RSAs Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options and RSAs (in thousands) |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding (in thousands) |
| Balance—December 31, 2014 |  | 13,654 |  |  | $ | 17.63 |  |  | 8.3 |  | $ | 598,775 |  |
| Authorized |  |  |  |  |  |  |  |  |
| Options granted |  | 1,235 |  |  | $ | 66.68 |  |  |  |  |  |
| Options exercised |  | (2,347 | ) |  | $ | 7.63 |  |  |  |  |  |
| Options canceled |  | (912 | ) |  | $ | 22.09 |  |  |  |  |  |
| Balance—December 31, 2015 |  | 11,630 |  |  | $ | 24.49 |  |  | 7.6 |  | $ | 620,802 |  |
| Vested and exercisable—December 31, 2015 |  | 3,692 |  |  | $ | 8.68 |  |  | 6.64 |  | $ | 255,392 |  |
| Vested and expected to vest—December 31, 2015 |  | 10,786 |  |  | $ | 23.57 |  |  | 7.58 |  | $ | 585,727 |  |

[0001596532-16-000244:notes:62]
_________________

[0001596532-16-000244:notes:63]
The weighted-average grant-date fair value of options granted during the year ended December 31, 2015 was $29.20 per share. The aggregate intrinsic value of options exercised during the year ended December 31, 2015 was $152.4 million.

[0001596532-16-000244:notes:64]
Restricted Stock Unit (RSU) Activities

[0001596532-16-000244:notes:65]
A summary of the activity under our stock plans and changes during the reporting period and a summary of information related to RSUs are presented below (in thousands, except years and per share amounts):

[0001596532-16-000244:notes:66]
|  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2014 | 108 |  |  | $ | 75.56 |  |  | 2 |  | $ | 6,557 |  |
| RSUs granted | 846 |  |  | 69.65 |  |  |  |  |  |
| RSUs vested | (27 | ) |  | 75.51 |  |  |  |  |  |
| RSUs forfeited/canceled | (34 | ) |  | 70.76 |  |  |  |  |  |
| Unvested balance—December 31, 2015 | 893 |  |  | $ | 70.14 |  |  | 1.93 |  | $ | 69,509 |  |
| RSUs expected to vest—December 31, 2015 | 815 |  |  | $ | 70.11 |  |  | 1.86 |  | $ | 63,443 |  |

[0001596532-16-000244:notes:67]
Employee Stock Purchase Plan Activities

[0001596532-16-000244:notes:68]
During the year ended December 31, 2015, we issued 247,385 shares at an average purchase price of $37.86 under the 2014 Employee Stock Purchase Plan, or ESPP. On February 12, 2015, the board authorized an increase to shares available for future issuance under the ESPP.  Shares available for future issuance are 1.7 million.

[0001596532-16-000244:notes:69]
Shares Available for Grant

[0001596532-16-000244:notes:70]
Early Exercise of Stock Options

[0001596532-16-000244:notes:71]
We have historically allowed our employees and directors to exercise options granted under the 2011 Plan and the 2004 Plan prior to vesting. Upon an "early exercise" of these options, the unvested shares acquired through the exercise become options subject to our repurchase right that lapse in accordance with the original option vesting schedule. Upon termination of employment prior to our repurchase rights lapsing in full, we have a right to repurchase the unvested shares at the original purchase price (or the then-current fair market value, if lower). The proceeds received from the early exercise of stock options and are initially recorded in other liabilities and are reclassified to common stock and paid-in capital as our repurchase right lapse. For the year ended December 31, 2015, we repurchased 17,000 shares of common stock at the original exercise price due to the termination of the holders of the unvested shares. As of December 31, 2015, shares held by employees and directors that were subject to repurchase were 0.7 million with an aggregate price of $2.4 million.

[0001596532-16-000244:notes:72]
Stock-Based Compensation Expense

[0001596532-16-000244:notes:73]
Total stock-based compensation expense related to options, RSAs, ESPP and RSUs granted were charged to the department to which the associated employee reported as follow (in thousands):

[0001596532-16-000244:notes:74]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Cost of revenue | $ | 3,048 |  |  | $ | 1,535 |  |  | $ | 408 |  |
| Research and development | 25,515 |  |  | 14,986 |  |  | 5,464 |  |
| Sales and marketing | 11,454 |  |  | 7,643 |  |  | 2,985 |  |
| General and administrative | 5,286 |  |  | 3,455 |  |  | 1,302 |  |
| Total stock-based compensation | $ | 45,303 |  |  | $ | 27,619 |  |  | $ | 10,159 |  |

[0001596532-16-000244:notes:75]
Determination of Fair Value

[0001596532-16-000244:notes:76]
We record stock-based compensation awards based on fair value as of the grant date. For option awards and ESPP offerings we use the Black-Scholes-Merton option-pricing model to determine fair value. We recognize such costs as compensation expense generally on a straight-line basis over the requisite service period of the award.

[0001596532-16-000244:notes:77]
Stock Options

[0001596532-16-000244:notes:78]
For the years ended December 31, 2015, 2014 and 2013 the fair value of each stock option granted under our plans was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions and fair value per share:

[0001596532-16-000244:notes:79]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Expected term (in years) | 6.2 |  |  | 7.6 |  |  | 6.5 |  |
| Risk-free interest rate | 1.6 | % |  | 2.2 | % |  | 1.7 | % |
| Expected volatility | 42.9 | % |  | 47.7 | % |  | 51.0 | % |
| Dividend rate | — | % |  | — | % |  | — | % |

[0001596532-16-000244:notes:80]
As of December 31, 2015, the total unrecognized stock-based compensation expense for unvested stock options, net of expected forfeitures, was $110.3 million, which is expected to be recognized over a weighted-average period of 4.0 years. The total fair value of options vested for the year ended December 31, 2015 was $22.8 million.

[0001596532-16-000244:notes:81]
As of December 31, 2015, there was $50.4 million of unrecognized stock-based compensation expense related to unvested RSUs, net of estimated forfeitures. This amount is expected to be recognized over a weighted-average period of 3.7.

[0001596532-16-000244:notes:82]
ESPP

[0001596532-16-000244:notes:83]
The following table summarizes the assumptions relating to our ESPP:

[0001596532-16-000244:notes:84]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Expected term (in years) | 1.4 |  |  | 1.4 |  |  | N/A |
| Risk-free interest rate | 0.3 | % |  | 0.3 | % |  | N/A |
| Expected volatility | 34.8 | % |  | 36.3 | % |  | N/A |
| Dividend rate | — | % |  | — | % |  | N/A |

[0001596532-16-000244:notes:85]
As of December 31, 2015, the total unrecognized stock-based compensation expense related to unvested ESPP options, net of expected forfeitures, was $1.2 million, which is expected to be recognized over a weighted-average period of 1.1 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001596532-16-000244:notes:86]
Net Income per Share of Common Stock

[0001596532-16-000244:notes:87]
Basic and diluted net income per share attributable to common stockholders is calculated in conformity with the two-class method required for participating securities. We considered our Series A convertible preferred stock to be participating securities. Under the two-class method, net income attributable to common stockholders is determined by allocating undistributed earnings, calculated as net income less current period convertible preferred stock non-cumulative dividends, among our common stock and convertible preferred stock. In computing diluted net income attributable to common stockholders, undistributed earnings are re-allocated to reflect the potential impact of dilutive securities. Basic net income per common share is computed by dividing the net income attributable to common stockholders by the weighted-average number of common shares outstanding during the period. Shares of common stock subject to repurchase resulting from the early exercise of employee stock options are considered participating securities. Diluted net income per share attributable to common stockholders is computed by dividing the net income attributable to common stockholders by the weighted-average number of common shares outstanding, including potential dilutive common shares assuming the dilutive effect of outstanding stock options using the treasury stock method. For purposes of this calculation, convertible preferred stock and options to purchase shares of common stock are considered to be common stock equivalents and are excluded from the calculation of diluted net income per share of common stock if their effect is antidilutive. Convertible notes payable were excluded from the calculation of diluted net income per share since such notes were convertible to common stock at the option of the holder only upon the occurrence of a contingent event, including change in control, initial public offering or prepayment of the convertible notes.


## us-gaap:EarningsPerShareTextBlock

[0001596532-16-000244:notes:88]
Net Income Per Share Available to Common Stock

[0001596532-16-000244:notes:89]
The following table sets forth the computation of our basic and diluted net income per share available to common stock (in thousands, except per share amounts):

[0001596532-16-000244:notes:90]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Numerator: |  |  |  |  |  |
| Basic: |  |  |  |  |  |
| Net income | $ | 121,102 |  |  | $ | 86,850 |  |  | $ | 42,460 |  |
| Less: undistributed earnings allocated to participating securities | (1,987 | ) |  | (17,961 | ) |  | (21,683 | ) |
| Net income available to common stockholders, basic | $ | 119,115 |  |  | $ | 68,889 |  |  | $ | 20,777 |  |
| Diluted: |  |  |  |  |  |
| Net income attributable to common stockholders, basic | $ | 119,115 |  |  | $ | 68,889 |  |  | $ | 20,777 |  |
| Add: undistributed earnings allocated to participating securities | 149 |  |  | 1,635 |  |  | 1,003 |  |
| Net income attributable to common stockholders, diluted | $ | 119,264 |  |  | $ | 70,524 |  |  | $ | 21,780 |  |
| Denominator: |  |  |  |  |  |
| Basic: |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 65,964 |  |  | 48,427 |  |  | 27,320 |  |
| Diluted: |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 65,964 |  |  | 48,427 |  |  | 27,320 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |
| Stock options, RSUs and RSAs | 5,363 |  |  | 6,059 |  |  | 2,726 |  |
| Employee stock purchase plan | 84 |  |  | 104 |  |  | — |  |
| Stock purchase rights | — |  |  | — |  |  | 5 |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted | 71,411 |  |  | 54,590 |  |  | 30,051 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |
| Basic | $ | 1.81 |  |  | $ | 1.42 |  |  | $ | 0.76 |  |
| Diluted | $ | 1.67 |  |  | $ | 1.29 |  |  | $ | 0.72 |  |

[0001596532-16-000244:notes:91]
The following outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share available to common stockholders for the periods presented because including them would have been anti-dilutive (in thousands):

[0001596532-16-000244:notes:92]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Stock options and RSUs | 2,427 |  |  | 1,263 |  |  | 3,599 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-16-000244:notes:93]
We measure and report our cash equivalents, restricted cash, available-for-sale marketable securities and notes receivable at fair value. The following table set forth the fair value of our financial assets by level within the fair value hierarchy (in thousands):

[0001596532-16-000244:notes:94]
|  | December 31, 2015 |
|  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 104,156 |  |  | $ | — |  |  | $ | — |  |  | $ | 104,156 |  |
| Other assets—Restricted cash: |  |  |  |  |  |  |  |
| Money market funds | 4,041 |  |  | — |  |  | — |  |  | 4,041 |  |
| Total financial assets | $ | 108,197 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,197 |  |

[0001596532-16-000244:notes:95]
|  | December 31, 2014 |
|  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 104,216 |  |  | $ | — |  |  | $ | — |  |  | $ | 104,216 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| U.S. government notes | 209,426 |  |  | — |  |  | — |  |  | 209,426 |  |
| Total financial assets | $ | 313,642 |  |  | $ | — |  |  | $ | — |  |  | $ | 313,642 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-16-000244:notes:96]
Fair Value Measurements


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001596532-16-000244:notes:97]
Fair value is defined as the exchange price that would be received for an asset or an exit price that would be paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, restricted cash, accounts receivable, accounts payable and accrued liabilities due to their short-term nature.  For certain investments where we have elected the fair value option, these investments are stated at fair value.

[0001596532-16-000244:notes:98]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value.  We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs.  The three-tiers of the fair value hierarchy are as follows:

[0001596532-16-000244:notes:99]
Level I—Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date;

[0001596532-16-000244:notes:100]
Level II—Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities; and

[0001596532-16-000244:notes:101]
Level III—Unobservable inputs that are supported by little or no market data for the related assets or liabilities and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.

[0001596532-16-000244:notes:102]
Our financial instruments consist of Level I and include highly liquid money market funds that are included in cash and cash equivalents and U.S. government notes classified as marketable securities.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001596532-16-000244:notes:103]
Foreign Currency

[0001596532-16-000244:notes:104]
The functional currency of our foreign subsidiaries is either the U.S. dollar or their local currency.

[0001596532-16-000244:notes:105]
Transaction re-measurement-Assets and liabilities denominated in a currency other than the foreign subsidiaries’ functional currency are re-measured into the functional currency using exchange rates in effect at the end of the reporting period, with gains and losses recorded in other income (expense), net in the consolidated statements of income. We recognized $0.5 million, $0.6 million and $0.1 million, in transaction losses for the years ended December 31, 2015, 2014 and 2013, respectively.

[0001596532-16-000244:notes:106]
Translation-Assets and liabilities of subsidiaries denominated in foreign functional currencies are translated into U.S. dollars at the closing exchange rate on the balance sheet date and equity related balances are translated at historical exchange rates.  Revenues, costs and expenses in foreign functional currencies are translated using average exchange rates that approximate those in effect during the period. Translation adjustments are accumulated as a separate component of accumulated other comprehensive income within stockholders’ equity (deficit).


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001596532-16-000244:notes:107]
Impairment of Long-Lived Assets and Investments

[0001596532-16-000244:notes:108]
The carrying amounts of our long-lived assets, including property and equipment and investments in privately-held companies, are periodically reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. Recoverability of these assets is measured by comparison of the carrying amount of each asset to the future undiscounted cash flows the asset is expected to generate over their remaining lives. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. No impairment of any long-lived assets or investments was identified for any of the periods presented.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-16-000244:notes:109]
Income Taxes

[0001596532-16-000244:notes:110]
The geographical breakdown of income before provision for income taxes is as follows (in thousands):

[0001596532-16-000244:notes:111]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Domestic | $ | 129,240 |  |  | $ | 120,838 |  |  | $ | 50,455 |  |
| Foreign | 16,769 |  |  | 670 |  |  | 7,820 |  |
| Income before provision for income taxes | $ | 146,009 |  |  | $ | 121,508 |  |  | $ | 58,275 |  |

[0001596532-16-000244:notes:112]
The components of the provision for income taxes are as follows (in thousands):

[0001596532-16-000244:notes:113]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Current provision for income taxes: |  |  |  |  |  |
| Federal | $ | 43,706 |  |  | $ | 34,314 |  |  | $ | 19,631 |  |
| State | 5,500 |  |  | 4,493 |  |  | 4,602 |  |
| Foreign | 1,588 |  |  | 3,306 |  |  | 413 |  |
| Total current | 50,794 |  |  | 42,113 |  |  | 24,646 |  |
| Deferred tax benefit: |  |  |  |  |  |
| Federal | (23,896 | ) |  | (7,105 | ) |  | (7,554 | ) |
| State | (2,300 | ) |  | 230 |  |  | (1,443 | ) |
| Foreign | 309 |  |  | (580 | ) |  | 166 |  |
| Total deferred | (25,887 | ) |  | (7,455 | ) |  | (8,831 | ) |
| Total provision for income taxes | $ | 24,907 |  |  | $ | 34,658 |  |  | $ | 15,815 |  |

[0001596532-16-000244:notes:114]
The reconciliation of the statutory federal income tax and our effective income tax is as follows:

[0001596532-16-000244:notes:115]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| U.S. federal statutory income tax | 35.00 | % |  | 35.00 | % |  | 35.00 | % |
| State tax, net of federal benefit | (1.35 | ) |  | 1.19 |  |  | 0.89 |  |
| Foreign tax differential | (2.16 | ) |  | 0.68 |  |  | (2.61 | ) |
| Tax credits | (6.72 | ) |  | (5.26 | ) |  | (10.64 | ) |
| Change in valuation allowance | 2.84 |  |  | 1.92 |  |  | 3.87 |  |
| Permanent items | (1.32 | ) |  | (0.86 | ) |  | (2.54 | ) |
| Uncertain tax positions and associated interest | (3.95 | ) |  | 0.37 |  |  | 0.58 |  |
| Stock-based compensation | (5.29 | ) |  | (4.01 | ) |  | 2.47 |  |
| Other, net | 0.01 |  |  | (0.51 | ) |  | 0.12 |  |
| Total provision for income taxes | 17.06 | % |  | 28.52 | % |  | 27.14 | % |

[0001596532-16-000244:notes:116]
We have operations and a taxable presence in numerous jurisdictions outside the U.S. All of these countries except one jurisdiction have a lower tax rate than the U.S. The significant jurisdictions in which we have a presence include Cayman Islands, Ireland, and the United Kingdom.

[0001596532-16-000244:notes:117]
The tax effects of temporary differences that give rise to significant portions of deferred tax assets (liabilities) are as follows (in thousands):

[0001596532-16-000244:notes:118]
|  | December 31, |
|  | 2015 |  | 2014 |
| Deferred tax assets: |  |  |  |
| Property and equipment | $ | 241 |  |  | $ | 504 |  |
| Stock-based compensation | 15,859 |  |  | 6,365 |  |
| Reserves and accruals not currently deductible | 33,686 |  |  | 16,160 |  |
| Net operating losses | 221 |  |  | 721 |  |
| Tax credits | 12,465 |  |  | 9,923 |  |
| State taxes | 9 |  |  | 342 |  |
| Other | 380 |  |  | 1,142 |  |
| Gross deferred tax assets | 62,861 |  |  | 35,157 |  |
| Valuation allowance | (12,655 | ) |  | (8,954 | ) |
| Total deferred tax assets | 50,206 |  |  | 26,203 |  |
| Deferred tax liabilities: |  |  |  |
| Property and equipment | (1,517 | ) |  | (2,001 | ) |
| Accrued liabilities | (728 | ) |  | (558 | ) |
| Other | (1 | ) |  | (2 | ) |
| Total deferred tax liabilities | (2,246 | ) |  | (2,561 | ) |
| Net deferred tax assets | $ | 47,960 |  |  | $ | 23,642 |  |

[0001596532-16-000244:notes:119]
The following table presents the breakdown between current and non-current deferred tax assets and liabilities (in thousands):

[0001596532-16-000244:notes:120]
|  | December 31, |
|  | 2015 |  | 2014 |
| Deferred tax assets, current | $ | — |  |  | $ | 12,252 |  |
| Deferred tax assets, non-current | 48,429 |  |  | 11,510 |  |
| Deferred tax liabilities, non-current | (469 | ) |  | (120 | ) |
| Total net deferred tax assets | $ | 47,960 |  |  |  | $23,642 |  |

[0001596532-16-000244:notes:121]
Recognition of deferred tax assets is appropriate when realization of these assets is more likely than not. We believe that all of the deferred tax assets were realizable with the exception of California and Canada deferred tax assets. Therefore, a valuation allowance of $12.7 million and $9.0 million was recorded as of December 31, 2015 and 2014, respectively, against the California and Canadian deferred tax assets as it was not more likely than not that these assets will be recognized. The net valuation allowance increased by $3.7 million, $2.7 million and $2.4 million as of December 31, 2015, 2014 and 2013, respectively.

[0001596532-16-000244:notes:122]
As of December 31, 2015 and 2014, we had no net operating loss carryforwards for federal and state income tax purposes. As of December 31, 2015 and 2014, we had combined foreign net operating loss carryforwards of $10.2 million and $7.5 million, respectively, that do not expire.

[0001596532-16-000244:notes:123]
As of December 31, 2015 and 2014, we had $2.8 million and $1.9 million, respectively, U.S. federal credit carryforwards which begin to expire in 2025. As of December 31, 2015 and 2014, we had state credit carryforwards of approximately $27.2 million and $16.4 million which can be carried over indefinitely.  As of December 31, 2015 and 2014, we had $1.9 million and $2.1 million of Canadian scientific research and experimental development tax credit carry-forwards, respectively, which begin to expire in 2033.

[0001596532-16-000244:notes:124]
Utilization of the net operating losses and tax credit carryforwards may be subject to limitations due to ownership changes limitations provided in the Internal Revenue code and similar state or foreign provisions. In all years up to December 31, 2015, such limitations had no impact to our deferred tax assets.

[0001596532-16-000244:notes:125]
Our policy with respect to our undistributed foreign subsidiaries earnings is to consider those earnings to be indefinitely reinvested and, accordingly, no related provision for U.S. federal and state income taxes has been provided. Upon distribution of those earnings’ in the form of dividends or otherwise, we may be subject to both U.S. income taxes (subject to an adjustment for foreign tax credits) and withholding taxes in the various countries. As of December 31, 2015, 2014 and 2013, the undistributed earnings approximated $16.4 million, $4.9 million and $4.9 million, respectively. The determination of the future tax consequences of the remittance of these earnings is not practicable.

[0001596532-16-000244:notes:126]
Uncertain Tax Positions

[0001596532-16-000244:notes:127]
We recognize uncertain tax positions only to the extent that management believes that it is more likely than not the position will be sustained. The reconciliation of the beginning and ending amount of gross unrecognized tax benefits as of December 31, 2015, 2014 and 2013 was as follows (in thousands):

[0001596532-16-000244:notes:128]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Gross unrecognized tax benefits—beginning balance | $ | 21,322 |  |  | $ | 16,973 |  |  | $ | 13,960 |  |
| Increases related to tax positions taken in a prior year | 346 |  |  | 425 |  |  | 70 |  |
| Increases related to tax positions taken during current year | 7,385 |  |  | 4,355 |  |  | 2,975 |  |
| Decreases related to tax positions taken in a prior year | (228 | ) |  | (431 | ) |  | (32 | ) |
| Decreases related to settlements with taxing authorities | — |  |  | — |  |  | — |  |
| Decreases related to lapse of statute of limitations | (6,586 | ) |  | — |  |  | — |  |
| Gross unrecognized tax benefits—ending balance | $ | 22,239 |  |  | $ | 21,322 |  |  | $ | 16,973 |  |

[0001596532-16-000244:notes:129]
As of December 31, 2015, 2014 and 2013 the total amount of gross unrecognized tax benefits was $22.2 million, $21.3 million and $17.0 million of which $13.0 million, $15.8 million and $13.9 million would affect our effective tax rate if recognized, respectively.

[0001596532-16-000244:notes:130]
Our policy is to recognize interest and penalties accrued on any unrecognized tax benefits as a component of income tax expense. We have recorded a net benefit for interest and penalties of $0.4 million and net expense of $0.7 million in the years ended December 31, 2015 and 2014, respectively. As of December 31, 2015 and 2014, we recognized a liability for interest and penalties of $1.1 million and $1.5 million, respectively.

[0001596532-16-000244:notes:131]
Because of the net operating loss and tax credit carryforwards, tax years remain open to federal and state tax examination. The majority of our foreign tax returns are open to audit under the statute of limitations of the respective foreign countries, in which the subsidiaries are located. It is possible that the amount of existing unrecognized tax benefits may decrease within the next 12 months as a result of statute of limitation lapses in some of the jurisdictions, however, an estimate of the range cannot be made.


## us-gaap:IncomeTaxPolicyTextBlock

[0001596532-16-000244:notes:132]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-16-000244:notes:133]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-16-000244:notes:134]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-16-000244:notes:135]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.


## us-gaap:InventoryPolicyTextBlock

[0001596532-16-000244:notes:136]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-16-000244:notes:137]
Inventories primarily consist of finished goods purchased from third party contract manufacturers and are stated at the lower of cost (computed using the first-in, first-out method) or market value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancelable, including integrated circuits, which are held by our contract manufacturers.  We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value.  We also record a liability for non-cancelable, non-returnable purchase commitments with our component inventory suppliers for quantities in excess of our demand forecasts or that are considered obsolete.

[0001596532-16-000244:notes:138]
Our contract manufacturers procure components and assemble products on our behalf based on our forecasts.  We generally incur a liability when the contract manufacturer has converted the component inventory to a finished product.  Historically, we have reimbursed our contract manufacturer for component inventory that has been rendered excess or obsolete due to manufacturing and engineering change orders resulting from design changes, or in cases where inventory levels greatly exceed our forecasts.

[0001596532-16-000244:notes:139]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer liabilities.


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-16-000244:notes:140]
Investments

[0001596532-16-000244:notes:141]
Investments in Privately-held Companies

[0001596532-16-000244:notes:142]
As of December 31, 2015 and 2014, we held equity investments of approximately $33.6 million in privately held companies which are accounted for under the cost method. There were no impairments recognized on our investments for the year ended December 31, 2015.

[0001596532-16-000244:notes:143]
Notes Receivable

[0001596532-16-000244:notes:144]
In 2014, we entered into a $3.0 million promissory note with a privately held company which was recorded at cost. The interest rate on the promissory note is 8.0% per annum and is payable quarterly. All unpaid principal and accrued interest on the promissory note is due and payable on the earlier of August 26, 2017, or upon default.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-16-000244:notes:145]
Recent Accounting Pronouncements

[0001596532-16-000244:notes:146]
In May 2014, the FASB issued ASU No. 2014-09, Revenue From Contracts With Customers, which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. In July 2015, the FASB deferred the effective date of the new revenue standard by one year. The standard is now effective for fiscal years (and interim reporting periods within those years) beginning after December 15, 2017.  The guidance is effective for us beginning in our first quarter of fiscal 2018. Early adoption would be permitted for all entities but not until the fiscal year beginning after December 15, 2016. The standard permits the use of either the retrospective or cumulative effect transition method. The retrospective method requires a retrospective approach to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance. The cumulative approach requires a retrospective approach with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. We are currently reviewing the provisions of the standard and have not yet selected a transition method nor have we determined the effect of the standard on our consolidated financial statements.

[0001596532-16-000244:notes:147]
In April 2015, the FASB issued ASU No. 2015-05, Intangibles—Goodwill and Other—Internal-Use Software, which  clarifies the circumstances under which a cloud computing customer would account for the arrangement as a license of internal-use software. A cloud computing arrangement would include a software license if (1) the customer has a contractual right to take possession of the software at any time during the hosting period without significant penalty and (2) it is feasible for the customer to either run the software on its own hardware or contract with another party unrelated to the vendor to host the software. If the arrangement does not contain a software license, it would be accounted for as a service contract. The guidance is effective for fiscal years beginning after December 15, 2015. The standard is effective for us for our first quarter of fiscal 2016. Early adoption is permitted. The guidance can be applied retrospectively to each prior reporting period presented or prospectively to arrangements entered into, or materially modified, after the effective date. We do not expect the adoption of the standard will have a material impact on our consolidated financial statements.

[0001596532-16-000244:notes:148]
In July 2015, the FASB issued ASU No, 2015-11, Inventory: Simplifying the Measurement of Inventory, which simplifies the measurement of inventory to be measured at the lower of cost or net realizable value. The guidance applies to inventory measured using First in First Out ("FIFO") or average cost. The guidance is effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. The standard is effective for us for our first quarter of fiscal 2017.  The guidance can be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

[0001596532-16-000244:notes:149]
In November 2015, the FASB issued ASU 2015-17, Income Taxes - Balance Sheet Classification of Deferred Taxes, which will require the presentation of deferred tax liabilities and asset be classified as noncurrent in a classified statement of financial position. The guidance is effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. The guidance can be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. The Company early adopted the guidance prospectively beginning in the fourth quarter of fiscal 2015. The adoption of the standard impacted presentation on the Company's Consolidated Financial Statements and related disclosures. No prior periods were retrospectively adjusted.

[0001596532-16-000244:notes:150]
In January 2016, the FASB issued ASU No, 2016-1, Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities, which enhances the reporting model for financial instruments to provide users of financial statements with more decision-useful information. The guidance will address certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. The guidance is effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. The standard is effective for us for our first quarter of fiscal 2018.  The guidance may be early adopted under early application guidance. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-16-000244:notes:151]
Organization and Summary of Significant Accounting Policies

[0001596532-16-000244:notes:152]
Organization

[0001596532-16-000244:notes:153]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our” or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System, a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switches. We were incorporated in October 2004 in the State of California under the name Arastra, Inc. In March 2008, we reincorporated in the State of Nevada and in October 2008 changed our name to Arista Networks, Inc. We reincorporated in the state of Delaware in March 2014. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-16-000244:notes:154]
Use of Estimates

[0001596532-16-000244:notes:155]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts and sales return reserve; determination of fair value for stock-based awards; accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; valuation of inventory; valuation of warranty accruals; and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions on an ongoing basis using historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. As future events and their effects cannot be determined with precision, actual results could differ from these estimates, and those differences could be material to the consolidated financial statements.

[0001596532-16-000244:notes:156]
Concentrations of Business and Credit Risk

[0001596532-16-000244:notes:157]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, marketable securities, restricted cash, and accounts receivable. Our cash, cash equivalents and restricted cash are invested in high quality financial instruments with banks and financial institutions. Such deposits may be in excess of insured limits provided on such deposits.

[0001596532-16-000244:notes:158]
Our accounts receivable are unsecured and represent amounts due to us based on contractual obligations of our customers. We mitigate credit risk in respect to accounts receivable by performing ongoing credit evaluations of our customers to assess the probability of accounts receivable collection based on a number of factors, including past transaction experience with the customer, evaluation of their credit history, the credit limits extended and review of the invoicing terms of the arrangement. In situations where a customer may be thinly capitalized and we have limited payment history with it, we will either establish a small credit limit or require it to prepay its purchases. We generally do not require our customers to provide collateral to support accounts receivable. We have recorded an allowance for doubtful accounts for those receivables that we have determined not to be collectible. We mitigate credit risk in respect to the notes receivable by performing ongoing credit evaluations of the borrower to assess the probability of collecting all amounts due to us under the existing contractual terms.

[0001596532-16-000244:notes:159]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators and original equipment manufacturer (“OEM”) partners and in conjunction with various technology partners.  Significant customers are those which represent more than 10% of our total net revenue during the period or net accounts receivable balance at each respective balance sheet date. For each significant customer, revenue as a percentage of total revenue and accounts receivable as a percentage of total accounts receivable are as follows:

[0001596532-16-000244:notes:160]
|  |  | Revenue |  | Accounts Receivable |
|  |  | Year Ended December 31, |  | December 31, |
| Customers |  | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |
| Customer A |  | 12 | % |  | 15 | % |  | 22 | % |  | 30 | % |  | 15 | % |

[0001596532-16-000244:notes:161]
We consider all highly liquid investments with stated maturity of three months or less at the time of purchase to be cash equivalents. Cash and cash equivalents consist of cash on deposit with various financial institutions and highly liquid investments in money market funds. Interest is accrued as earned. We have restricted cash pledged as collateral representing a security deposit required for a facility lease. As of December 31, 2015, we had classified the restricted cash of $4.0 million as other assets in our accompanying consolidated balance sheet. We did not have any restricted cash as of December 31, 2014.

[0001596532-16-000244:notes:162]
Marketable Securities

[0001596532-16-000244:notes:163]
We invest our excess cash primarily in money market and highly liquid debt instruments of the U.S. government. We classify all highly liquid investments with stated maturities of greater than three months as marketable securities. We determine the appropriate classification of our investments in marketable securities at the time of purchase and reevaluate such designation at each balance sheet date. We have classified and accounted for our marketable securities as available-for-sale. We may or may not hold securities with stated maturities greater than 12 months until maturity. After consideration of our risk versus reward objectives, as well as our liquidity requirements, we may sell these securities prior to their stated maturities. As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying consolidated balance sheets. We carry these securities at fair value, and report the unrealized gains and losses, net of taxes, as a component of stockholders’ equity, except for unrealized losses determined to be other-than-temporary, which we record as other income (expense), net. We determine any realized gains or losses on the sale of marketable securities on a specific identification method, and we record such gains and losses as a component of interest and other income, net.

[0001596532-16-000244:notes:164]
Accounts Receivable

[0001596532-16-000244:notes:165]
Accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts, and sales return reserves. We estimate our allowance for doubtful accounts based upon the collectability of the receivables in light of historical trends, adverse situations that may affect our customers’ ability to pay and prevailing economic conditions. This evaluation is done in order to identify issues which may impact the collectability of receivables and related estimated required allowance. Revisions to the allowance are recorded as an adjustment to bad debt expense. After appropriate collection efforts are exhausted, specific accounts receivable deemed to be uncollectible are charged against the allowance in the period they are deemed uncollectible. Recoveries of accounts receivable previously written-off are recorded as credits to bad debt expense. We estimate our sales return reserves based on historical return rates applied against current period gross revenues. Specific customer returns and allowances are considered when determining our sales return reserve estimate. Revisions to the reserve are recorded as adjustments to revenue and the sales return reserves.

[0001596532-16-000244:notes:166]
For the years ended December 31, 2015, 2014 and 2013, we recorded inventory write-downs of $9.0 million, $2.8 million and $5.3 million, respectively.  In addition, our contract manufacturer and supplier liabilities totaled $3.8 million and $0.3 million as of December 31, 2015 and 2014, respectively.

[0001596532-16-000244:notes:167]
Property and Equipment

[0001596532-16-000244:notes:168]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is calculated using the straight-line method over the shorter of the estimated useful lives of the related assets, generally from one to five years, 30 years for buildings or the lease term for leasehold improvements. The leased building under our build to suit lease is capitalized and included in property and equipment as we were involved in the construction funding and did not meet the “sale-leaseback” criteria.

[0001596532-16-000244:notes:169]
Our investments in privately-held companies are accounted for under the cost method and are included in investments, non-current in the accompanying consolidated balance sheets. Initial measurement of our investments under the cost method were recorded at historical cost which represents our initial investment in the privately-held companies.

[0001596532-16-000244:notes:170]
Our unsecured promissory note receivable investment with a privately held company was recorded at cost. Interest income is recorded in other income (expense), in the accompanying consolidated statements of income at each reporting period.

[0001596532-16-000244:notes:171]
Revenue Recognition

[0001596532-16-000244:notes:172]
We generate revenue from sales of switching products which incorporate our EOS software and accessories such as cables and optics to direct customers and channel partners together with post contract customer support (“PCS”). We typically sell products and PCS in a single transaction. We recognize revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery or performance has occurred; the sales price is fixed or determinable; and collectability is reasonably assured.

[0001596532-16-000244:notes:173]
We define each of the four criteria above as follows:

[0001596532-16-000244:notes:174]
| • | Persuasive evidence of an arrangement exists. Evidence of an arrangement consists of stand-alone purchase orders or purchase orders issued pursuant to the terms and conditions of a master sales agreement. It is our practice to identify an end customer prior to shipment to a reseller or distributor. |

[0001596532-16-000244:notes:175]
| • | Delivery or performance has occurred. We use shipping documents or written evidence of customer acceptance, when applicable, to verify delivery or performance. We recognize product revenue upon transfer of title and risk of loss, which primarily is upon shipment to customers. We generally do not have significant obligations for future performance, rights of return or pricing credits associated with our product sales. In instances where substantive acceptance provisions are specified in the customer arrangement, revenue is deferred until all acceptance criteria have been met. |

[0001596532-16-000244:notes:176]
| • | The sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on payment terms and whether the sales price is subject to refund or adjustment. |

[0001596532-16-000244:notes:177]
| • | Collectability is reasonably assured. We assess probability of collectability on a customer-by-customer basis. Our customers and channel partners are subjected to a credit review process that evaluates their financial condition and ability to pay for products and services. |

[0001596532-16-000244:notes:178]
PCS is offered under renewable, fee-based contracts, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis. We initially defer PCS revenue and recognize it ratably over the life of the PCS contract, with the related expenses recognized as incurred. PCS contracts usually have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-16-000244:notes:179]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of goods sold.

[0001596532-16-000244:notes:180]
Multiple-Element Arrangements

[0001596532-16-000244:notes:181]
Most of our arrangements, other than renewals of PCS, are multiple element arrangements with a combination of products and PCS. Products and PCS generally qualify as separate units of accounting. Our hardware deliverables include EOS software, which together deliver the essential functionality of our products. For multiple element arrangements, we allocate revenue to each unit of accounting based on the relative selling price. The relative selling price for each element is based upon the following hierarchy: vendor-specific objective evidence (“VSOE”), if available; third-party evidence (“TPE”), if VSOE is not available; and best estimate of selling price (“BESP”), if neither VSOE nor TPE is available. As we have not been able to establish VSOE or TPE for our products and most of our services, we generally utilize BESP for the purposes of allocating revenue to each unit of accounting.

[0001596532-16-000244:notes:182]
| • | VSOE—We determine VSOE based on our historical pricing and discounting practices for the specific products and services when sold separately. In determining VSOE, we require that a substantial majority of the stand-alone selling prices fall within a reasonably narrow pricing range. |

[0001596532-16-000244:notes:183]
| • | TPE—When VSOE cannot be established for deliverables in multiple-element arrangements, we apply judgment with respect to whether we can establish a selling price based on TPE. TPE is determined based on competitor prices for interchangeable products or services when sold separately to similarly situated customers. However, as our products contain a significant element of proprietary technology and offer substantially different features and functionality, the comparable pricing of products with similar functionality typically cannot be obtained. Additionally, as we are unable to reliably determine what competitors products’ selling prices are on a stand-alone basis, we are not able to obtain reliable evidence of TPE of selling price. |

[0001596532-16-000244:notes:184]
| • | BESP—When we are unable to establish selling price using VSOE or TPE, we use BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service was sold regularly on a stand-alone basis. BESP is based on considering multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services were sold (domestic or international) and size of the end customer. |

[0001596532-16-000244:notes:185]
We limit the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations, or subject to customer-specific return, acceptance or refund privileges.

[0001596532-16-000244:notes:186]
We account for multiple agreements with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single arrangement.

[0001596532-16-000244:notes:187]
We may occasionally accept returns to address customer satisfaction issues even though there is no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period gross revenues. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-16-000244:notes:188]
Research and Development Expenses

[0001596532-16-000244:notes:189]
Costs related to the research, design and development of our products are charged to research and development expenses as incurred. Software development costs are capitalized beginning when a product’s technological feasibility has been established and ending when the product is available for general release to customers. Generally, our products are released soon after technological feasibility has been established. As a result, costs incurred subsequent to achieving technological feasibility have not been significant and accordingly, all software development costs have been expensed as incurred.

[0001596532-16-000244:notes:190]
Warranty

[0001596532-16-000244:notes:191]
We offer a one-year warranty on all of our hardware products and a 90-day warranty against defects in the software embedded in the products. We use judgment and estimates when determining warranty costs based on historical costs to replace product returns within the warranty period at the time we recognize revenue. We accrue for potential warranty claims at the time of shipment as a component of cost of revenues based on historical experience and other relevant information. We reserve for specifically identified products if and when we determine we have a systemic product failure. Although we engage in extensive product quality programs, if actual product failure rates or use of materials differ from estimates, additional warranty costs may be incurred, which could reduce our gross margin. The accrued warranty liability is recorded in accrued liabilities in the accompanying consolidated balance sheets.

[0001596532-16-000244:notes:192]
Post-Employment Benefits

[0001596532-16-000244:notes:193]
We have a 401(k) Plan that covers substantially all of our employees in the U.S. For the years ended December 31, 2015, 2014 and 2013, we did not provide a discretionary company match to employee contributions.

[0001596532-16-000244:notes:194]
Segment Reporting

[0001596532-16-000244:notes:195]
We develop, market and sell cloud networking solutions, which consist of our Gigabit Ethernet switches and related software. We have one business activity and there are no segment managers who are held accountable for operations or operating results below the Company level. Our chief operating decision maker is our Chief Executive Officer. Our Chief Executive Officer reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.  Accordingly, we have determined that we operate as one reportable segment.

[0001596532-16-000244:notes:196]
Stock-Based Compensation

[0001596532-16-000244:notes:197]
Compensation expense related to stock-based transactions, including stock options, restricted stock units ("RSUs"), restricted stock awards (“RSAs”), and stock purchase rights under our employee stock purchase program is measured and recognized in the financial statements based on the fair value of the equity granted, net of estimated forfeitures. Stock-based compensation expense is generally recognized, net of forfeitures, on a straight-line basis over the requisite service periods of the awards, which typically ranges from two to five years.

[0001596532-16-000244:notes:198]
Excess tax benefits associated with stock option exercises and other equity awards are recognized in additional paid in capital. The income tax benefits resulting from stock awards that were credited to stockholders' equity were $37.0 million, $17.4 million and $0.6 million, for the years ended December 31, 2015, 2014 and 2013, respectively.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001596532-16-000244:notes:199]
Other current liabilities consist of the following (in thousands):

[0001596532-16-000244:notes:200]
|  | December 31, |
|  | 2015 |  | 2014 |
| Liability for early exercised shares subject to repurchase | $ | 2,390 |  |  | $ | 4,616 |  |
| Sales tax payable | 3,347 |  |  | 3,101 |  |
| Lease financing obligations, current portion | 1,336 |  |  | 1,087 |  |
| Other | 952 |  |  | 2,445 |  |
| Total other current liabilities | $ | 8,025 |  |  | $ | 11,249 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001596532-16-000244:notes:201]
Property and equipment, net consists of the following (in thousands):

[0001596532-16-000244:notes:202]
|  | December 31, |
|  | 2015 |  | 2014 |
| Equipment and machinery | $ | 29,101 |  |  | $ | 18,265 |  |
| Computer hardware and software | 12,630 |  |  | 7,772 |  |
| Furniture and fixtures | 2,380 |  |  | 1,373 |  |
| Leasehold improvements | 24,372 |  |  | 19,420 |  |
| Building | 35,154 |  |  | 35,154 |  |
| Construction-in-process | 6,408 |  |  | 6,532 |  |
| Property and equipment, gross | 110,045 |  |  | 88,516 |  |
| Less: accumulated depreciation | (30,339 | ) |  | (16,958 | ) |
| Property and equipment, net | $ | 79,706 |  |  | $ | 71,558 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001596532-16-000244:notes:203]
Selected Quarterly Financial Information (Unaudited)

[0001596532-16-000244:notes:204]
The following tables set forth selected unaudited quarterly consolidated statements of operations data for each of the quarters in the years ended December 31, 2015 and 2014:

[0001596532-16-000244:notes:205]
|  |  | Three Months Ended |
|  |  | Dec. 31, 2015 |  | Sep. 30, 2015 |  | Jun. 30, 2015 |  | Mar. 31, 2015 |  | Dec. 31, 2014 |  | Sep. 30, 2014 |  | Jun. 30, 2014 |  | Mar. 31, 2014 |
|  |  | (in thousands) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 217,325 |  |  | $ | 193,339 |  |  | $ | 174,072 |  |  | $ | 160,141 |  |  | $ | 157,205 |  |  | $ | 141,455 |  |  | $ | 126,390 |  |  | $ | 106,493 |  |
| Service |  | 28,121 |  |  | 24,209 |  |  | 21,480 |  |  | 18,904 |  |  | 16,284 |  |  | 14,008 |  |  | 11,557 |  |  | 10,714 |  |
| Total revenue |  | 245,446 |  |  | 217,548 |  |  | 195,552 |  |  | 179,045 |  |  | 173,489 |  |  | 155,463 |  |  | 137,947 |  |  | 117,207 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 81,142 |  |  | 67,990 |  |  | 60,014 |  |  | 54,439 |  |  | 51,312 |  |  | 49,633 |  |  | 40,032 |  |  | 33,027 |  |
| Service |  | 8,136 |  |  | 7,810 |  |  | 7,648 |  |  | 6,852 |  |  | 5,737 |  |  | 4,873 |  |  | 4,535 |  |  | 2,866 |  |
| Total cost of revenue |  | 89,278 |  |  | 75,800 |  |  | 67,662 |  |  | 61,291 |  |  | 57,049 |  |  | 54,506 |  |  | 44,567 |  |  | 35,893 |  |
| Gross profit |  | 156,168 |  |  | 141,748 |  |  | 127,890 |  |  | 117,754 |  |  | 116,440 |  |  | 100,957 |  |  | 93,380 |  |  | 81,314 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | 57,413 |  |  | 58,748 |  |  | 49,947 |  |  | 43,340 |  |  | 44,344 |  |  | 36,231 |  |  | 34,888 |  |  | 33,446 |  |
| Sales and marketing |  | 31,308 |  |  | 26,508 |  |  | 26,681 |  |  | 24,587 |  |  | 25,016 |  |  | 20,956 |  |  | 20,711 |  |  | 18,655 |  |
| General and administrative |  | 18,050 |  |  | 25,195 |  |  | 18,403 |  |  | 14,072 |  |  | 8,078 |  |  | 9,896 |  |  | 7,126 |  |  | 7,231 |  |
| Total operating expenses |  | 106,771 |  |  | 110,451 |  |  | 95,031 |  |  | 81,999 |  |  | 77,438 |  |  | 67,083 |  |  | 62,725 |  |  | 59,332 |  |
| Income from operations |  | 49,397 |  |  | 31,297 |  |  | 32,859 |  |  | 35,755 |  |  | 39,002 |  |  | 33,874 |  |  | 30,655 |  |  | 21,982 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | (746 | ) |  | (753 | ) |  | (832 | ) |  | (821 | ) |  | (768 | ) |  | (764 | ) |  | (1,435 | ) |  | (1,771 | ) |
| Other income (expense), net |  | (109 | ) |  | 13 |  |  | 417 |  |  | (468 | ) |  | (151 | ) |  | (824 | ) |  | 2,472 |  |  | (764 | ) |
| Total other income (expense), net |  | (855 | ) |  | (740 | ) |  | (415 | ) |  | (1,289 | ) |  | (919 | ) |  | (1,588 | ) |  | 1,037 |  |  | (2,535 | ) |
| Income before provision for income taxes |  | 48,542 |  |  | 30,557 |  |  | 32,444 |  |  | 34,466 |  |  | 38,083 |  |  | 32,286 |  |  | 31,692 |  |  | 19,447 |  |
| Provision for income taxes |  | 4,618 |  |  | 1,867 |  |  | 8,448 |  |  | 9,974 |  |  | 7,046 |  |  | 10,420 |  |  | 10,074 |  |  | 7,118 |  |
| Net income |  | $ | 43,924 |  |  | $ | 28,690 |  |  | $ | 23,996 |  |  | $ | 24,492 |  |  | $ | 31,037 |  |  | $ | 21,866 |  |  | $ | 21,618 |  |  | $ | 12,329 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.65 |  |  | $ | 0.42 |  |  | $ | 0.36 |  |  | $ | 0.37 |  |  | $ | 0.48 |  |  | $ | 0.34 |  |  | $ | 0.37 |  |  | $ | 0.22 |  |
| Diluted |  | $ | 0.60 |  |  | $ | 0.39 |  |  | $ | 0.33 |  |  | $ | 0.34 |  |  | $ | 0.43 |  |  | $ | 0.30 |  |  | $ | 0.34 |  |  | $ | 0.20 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001596532-16-000244:notes:206]
Other Related Party Transactions and Balances

[0001596532-16-000244:notes:207]
Certain members of our board of directors serve on the boards of our customers and one of our vendors. During the years ended December 31, 2015, 2014 and 2013, we recognized revenue of 39.4 million, $29.6 million and $11.1 million, respectively, from sales transactions with these related party customers. Amounts due from these related party customers were 9.8 million and $6.4 million as of December 31, 2015 and 2014, respectively. The amount incurred related to transactions with a related party vendor was 2.7 million during the year ended December 31, 2015.  There were no transactions with this related party vendor during the years ended December 31, 2014 and 2013.


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001596532-16-000244:notes:208]
Accounts Receivable, net

[0001596532-16-000244:notes:209]
Accounts receivable, net consists of the following (in thousands):

[0001596532-16-000244:notes:210]
|  | December 31, |
|  | 2015 |  | 2014 |
| Accounts receivable | $ | 145,792 |  |  | $ | 100,076 |  |
| Allowance for doubtful accounts | (963 | ) |  | (1,063 | ) |
| Product sales return reserve | (566 | ) |  | (2,031 | ) |
| Accounts receivable, net | $ | 144,263 |  |  | $ | 96,982 |  |

[0001596532-16-000244:notes:211]
Allowance for Doubtful Accounts

[0001596532-16-000244:notes:212]
Activity in the allowance for doubtful accounts consists of the following (in thousands):

[0001596532-16-000244:notes:213]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| Balance at the beginning of year | $ | 1,063 |  |  | $ | 810 |  |  | $ | 1,284 |  |
| Charged to expenses | 335 |  |  | 860 |  |  | 191 |  |
| Deductions (write-offs) | (435 | ) |  | (607 | ) |  | (665 | ) |
| Balance at the end of year | $ | 963 |  |  | $ | 1,063 |  |  | $ | 810 |  |

[0001596532-16-000244:notes:214]
Sales Return Reserve

[0001596532-16-000244:notes:215]
Activity in the sales return reserve consists of the following (in thousands):

[0001596532-16-000244:notes:216]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |
| Balance at the beginning of year | $ | 2,031 |  |  | $ | 1,529 |  |
| Charged against revenue | 2,798 |  |  | 4,063 |  |
| Deductions | (2,283 | ) |  | (2,943 | ) |
| Change in estimate | (1,980 | ) |  | (618 | ) |
| Balance at the end of year | $ | 566 |  |  | $ | 2,031 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001596532-16-000244:notes:217]
Accrued liabilities consist of the following (in thousands):

[0001596532-16-000244:notes:218]
|  | December 31, |
|  | 2015 |  | 2014 |
| Accrued payroll related costs | $ | 39,479 |  |  | $ | 30,749 |  |
| Accrued warranty costs | 4,718 |  |  | 3,204 |  |
| Accrued manufacturing costs | 6,397 |  |  | 1,089 |  |
| Accrued professional fees | 4,875 |  |  | 2,354 |  |
| Accrued taxes | 1,347 |  |  | 1,577 |  |
| Other | 4,155 |  |  | 1,396 |  |
| Total accrued liabilities | $ | 60,971 |  |  | $ | 40,369 |  |


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001596532-16-000244:notes:219]
The following table summarizes the unrealized gains and losses and fair value of our available-for-sale marketable securities (in thousands):

[0001596532-16-000244:notes:220]
|  | December 31, 2014 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| U.S. government notes | $ | 209,671 |  |  | $ | — |  |  | $ | (245 | ) |  | $ | 209,426 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001596532-16-000244:notes:221]
Inventories consist of the following (in thousands):

[0001596532-16-000244:notes:222]
|  | December 31, |
|  | 2015 |  | 2014 |
| Raw materials | $ | 29,831 |  |  | $ | 17,094 |  |
| Finished goods | 62,298 |  |  | 60,912 |  |
| Total inventories | $ | 92,129 |  |  | $ | 78,006 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001596532-16-000244:notes:223]
Prepaid expenses and other current assets consists of the following (in thousands):

[0001596532-16-000244:notes:224]
|  | December 31, |
|  | 2015 |  | 2014 |
| Prepaid income taxes | $ | 14,150 |  |  | $ | 25,212 |  |
| Other current assets | 29,270 |  |  | 11,512 |  |
| Other prepaid and deposits | 7,190 |  |  | 6,058 |  |
| Total prepaid expenses and other current assets | $ | 50,610 |  |  | $ | 42,782 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001596532-16-000244:notes:225]
The following table summarizes the activity related to our accrued liability for estimated future warranty costs (in thousands):

[0001596532-16-000244:notes:226]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |
| Warranty accrual, beginning of year | $ | 3,204 |  |  | $ | 5,075 |  |
| Liabilities accrued for warranties issued during the year | 3,973 |  |  | 2,611 |  |
| Warranty costs incurred during the year | (2,459 | ) |  | (2,163 | ) |
| Adjustments related to change in estimate | — |  |  | (2,319 | ) |
| Warranty accrual, end of year | $ | 4,718 |  |  | $ | 3,204 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001596532-16-000244:notes:227]
The following table represents revenue based on the customer’s location, as determined by the customer’s shipping address (in thousands):

[0001596532-16-000244:notes:228]
|  | Year Ended December 31, |
|  | 2015 |  | 2014 |  | 2013 |
| United States | $ | 634,413 |  |  | $ | 456,691 |  |  | $ | 293,579 |  |
| Other Americas | 12,506 |  |  | 8,853 |  |  | 6,040 |  |
| Europe, Middle East and Africa | 128,400 |  |  | 74,555 |  |  | 40,577 |  |
| Asia Pacific | 62,272 |  |  | 44,007 |  |  | 21,028 |  |
| Total revenue | $ | 837,591 |  |  | $ | 584,106 |  |  | $ | 361,224 |  |

[0001596532-16-000244:notes:229]
Long lived assets, excluding intercompany receivables, investments in subsidiaries, privately-held equity investments

[0001596532-16-000244:notes:230]
and deferred tax assets, net by location are summarized as follows (in thousands):

[0001596532-16-000244:notes:231]
|  | December 31, |
|  | 2015 |  | 2014 |
| United States | $ | 70,719 |  |  | $ | 67,727 |  |
| International | 8,987 |  |  | 3,831 |  |
| Total | $ | 79,706 |  |  | $ | 71,558 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-16-000244:notes:232]
Segment Information

[0001596532-16-000244:notes:233]
We have determined that we operate as one reportable segment. The following table represents revenue based on the customer’s location, as determined by the customer’s shipping address (in thousands):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-16-000244:notes:234]
Balance Sheet Components

[0001596532-16-000244:notes:235]
There were no marketable securities as of December 31, 2015. We did not realize any other-than-temporary losses on our marketable securities for the year ended December 31, 2015 and 2014. None of our marketable securities were in continuous unrealized loss positions for greater than twelve months as of December 31, 2015 and 2014.

[0001596532-16-000244:notes:236]
We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. As interest rates increase, those marketable securities purchased at a lower yield show a mark-to-market unrealized loss. The unrealized losses are due primarily to changes in credit spreads and interest rates. We realized the full value of all these investments upon maturity.

[0001596532-16-000244:notes:237]
Inventories

[0001596532-16-000244:notes:238]
Prepaid Expenses and Other Current Assets

[0001596532-16-000244:notes:239]
Property and Equipment, net

[0001596532-16-000244:notes:240]
Building consists of capitalized construction costs of our leased building in Santa Clara, California. Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction, such as our financial involvement in structural elements of asset construction, making decisions related to tenant improvement costs and purchasing insurance not reimbursable by the buyer-lessor (the Landlord), we were deemed the owner of the building (for accounting purposes only) during the construction period. We continue to maintain involvement in the property post construction completion and lack transferability of the risks and rewards of ownership, due to our required maintenance of a $4.0 million letter of credit, in addition to our ability and option to sublease our portion of the leased building for fees substantially higher than our base rate. Due to our continuing involvement in the property post construction and lack of transferability of related risks and rewards of ownership to the Landlord after construction is complete, we account for the building as a financing obligation. See “Note 5-Commitments and Contingencies”. Accordingly, as of December 31, 2015 and December 31, 2014, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the Landlord. The building was completed in 2014.

[0001596532-16-000244:notes:241]
Depreciation expense was $13.4 million, $10.0 million and $5.0 million for the years ended December 31, 2015, 2014 and 2013, respectively.

[0001596532-16-000244:notes:242]
Accrued Liabilities

[0001596532-16-000244:notes:243]
Warranty Accrual

[0001596532-16-000244:notes:244]
There were no significant specific product warranty reserves recorded for the years ended December 31, 2015 or 2014.

[0001596532-16-000244:notes:245]
Other Current Liabilities
