# ANET MD&A — 0001596532-22-000112


## mdna

[0001596532-22-000112:mdna:1]
[same as prior period, unchanged from 0001596532-21-000354:mdna:1]

[0001596532-22-000112:mdna:2]
[same as prior period, unchanged from 0001596532-21-000354:mdna:2]

[0001596532-22-000112:mdna:3]
Arista Networks pioneered data-driven, cognitive cloud networking for large-scale data center and campus workspace environments. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our Ethernet switching and routing platforms. We are a leader in cloud networking solutions delivering high performance, scalability, availability, programmability, workload orchestration, automation and visibility. In recent years, we have sought to bring the operational consistency and principles of cloud networking to the broader enterprise and campus markets with our Cognitive Cloud Networking, extending EOS across the enterprise data center and campus wired and wireless workspaces.

[0001596532-22-000112:mdna:4]
We generate revenue primarily from sales of our switching and routing platforms, which incorporate our EOS software, and related network applications. We also generate revenue from post-contract support ("PCS"), which end customers typically purchase in conjunction with our products, and renewals of PCS. We sell our products through both our direct sales force and our channel partners. As of December 31, 2021, we had delivered our cloud networking solutions to over 8,000 end customers worldwide. Our end customers span a range of industries and include large internet companies, service providers, financial services organizations, government agencies, media and entertainment companies, and others.

[0001596532-22-000112:mdna:5]
Historically, large purchases by a relatively limited number of end customers have accounted for a significant portion of our revenue. We have experienced unpredictability in the timing of orders from these large end customers primarily due to changes in demand patterns specific to these customers, the time it takes these end customers to evaluate, test, qualify and accept our products, and the overall complexity of these large orders. We expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. For example, sales to our end customers Microsoft and Meta Platforms in fiscal 2019 collectively represented 40% of our total revenue, whereas sales to our end customer Microsoft in fiscal 2020 and 2021 amounted to 21.5% and 15.0% of our revenues, respectively, with our end customer Meta Platforms representing less than 10% of our revenues in both fiscal 2020 and 2021. While we experienced some decline in overall revenue in 2020, the decline in revenue from these large end customers in 2021 was more than offset by stronger sales to our enterprise and other cloud and service provider customers. In addition, we typically provide pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur. We expect customer concentration with these large end customers to be cyclical and linked to new product introductions and customer investment cycles.

[0001596532-22-000112:mdna:6]
[same as prior period, unchanged from 0001596532-21-000354:mdna:6]

[0001596532-22-000112:mdna:7]
The markets for cloud networking solutions are highly competitive and characterized by rapidly changing technology, changing end-customer needs, evolving industry standards, frequent introductions of new products and services, and industry consolidation. We expect competition to intensify in the future as the market for cloud networking expands and existing competitors and new market entrants introduce new products or enhance existing products. Our future success is dependent upon our ability to continue to evolve and adapt to our rapidly changing environment. We must also continue to develop market-leading products and features that address the needs of our existing and new customers, and increase sales in the enterprise data center switching, and campus workspace markets. We intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order

[0001596532-22-000112:mdna:8]
to reach new end customers more effectively, increase sales to existing customers, and provide services and support. In addition, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our ability to rapidly develop new features and applications.

[0001596532-22-000112:mdna:9]
Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic with respect to the underlying merchant silicon architecture. The programmability of EOS has allowed us to expand our software applications to address the ever-increasing demands of cloud networking, including workflow automation, network visibility, analytics and network detection and response, and has further allowed us to integrate rapidly with a wide range of third-party applications for virtualization, management, automation, orchestration and network services. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We work closely with third-party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third-party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-22-000112:mdna:10]
[same as prior period, unchanged from 0001596532-21-000354:mdna:9]

[0001596532-22-000112:mdna:11]
The global coronavirus ("COVID-19") pandemic and the subsequent recovery in demand, coupled with lower COVID-19 period capital investments and reduced labor supply has led to, among other things, manufacturing disruptions, supply chain shortages, increased component and supply chain costs, increased lead times, extended demand planning horizons and increased purchase commitments, all of which have impacted our business operations.

[0001596532-22-000112:mdna:12]
We continue to monitor and evaluate developments as the situation evolves, and have prioritized the safety of our employees throughout this period. Our offices across the globe have reopened with employees returning on a voluntary basis.  Our manufacturing and supply chain operations continue to experience significant constraints, with component shortages, increased component and supply chain costs and delays broadly impacting the industry as a whole. We continue to work closely with our contract manufacturers and supply chain partners who have experienced delays in component sourcing, workforce disruptions and governmental restrictions on the production and export of their products. Although we have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, these delays have negatively impacted our ability to supply products to our customers on a timely basis. We have extended our demand planning horizon, increased our purchase commitments and expect to continue to invest in working capital to address delays in component sourcing and the risk of future supply chain disruptions, but we cannot be certain that such delays or disruptions will not occur. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and may negatively impact our gross margin. Although the overall economy continues to recover, several issues including inflation risk, supply chain bottlenecks and COVID-19 variants have and may continue to impact the pace of the recovery.

[0001596532-22-000112:mdna:13]
The extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments including the duration and spread of the pandemic and related mitigation efforts, and the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which are uncertain and cannot be predicted. However, any continued or renewed disruption in manufacturing and supply resulting from the COVID-19 pandemic or related containment measures could negatively impact our business. We also believe that any extended or renewed COVID-19 related economic disruption could have a negative impact on demand from our customers in future periods. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

[0001596532-22-000112:mdna:14]
[same as prior period, unchanged from 0001596532-21-000354:mdna:13]

[0001596532-22-000112:mdna:15]
Three Months Ended March 31, 2022 Compared to Three Months Ended March 31, 2021

[0001596532-22-000112:mdna:16]
[same as prior period, unchanged from 0001596532-21-000354:mdna:15]

[0001596532-22-000112:mdna:17]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2022 |  | 2021 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 724,718 |  |  | $ | 539,145 |  |  | $ | 185,573 |  |  | 34.4 | % |  |  |  |  |  |  |  |  |
| Service |  | 152,348 |  |  | 128,417 |  |  | 23,931 |  |  | 18.6 |  |  |  |  |  |  |  |  |  |
| Total revenue |  | 877,066 |  |  | 667,562 |  |  | 209,504 |  |  | 31.4 |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 293,809 |  |  | 218,433 |  |  | 75,376 |  |  | 34.5 |  |  |  |  |  |  |  |  |  |
| Service |  | 29,412 |  |  | 23,857 |  |  | 5,555 |  |  | 23.3 |  |  |  |  |  |  |  |  |  |
| Total cost of revenue |  | 323,221 |  |  | 242,290 |  |  | 80,931 |  |  | 33.4 |  |  |  |  |  |  |  |  |  |
| Gross profit |  | $ | 553,845 |  |  | $ | 425,272 |  |  | $ | 128,573 |  |  | 30.2 | % |  |  |  |  |  |  |  |  |
| Gross margin |  | 63.1 | % |  | 63.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001596532-22-000112:mdna:18]
[same as prior period, unchanged from 0001596532-21-000354:mdna:17]

[0001596532-22-000112:mdna:19]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2022 |  | % of Total |  | 2021 |  | % of Total |  |  |  |  |  |  |  |  |
| Americas |  | $ | 664,377 |  |  | 75.7 | % |  | $ | 501,872 |  |  | 75.2 | % |  |  |  |  |  |  |  |  |
| Europe, Middle East and Africa |  | 134,805 |  |  | 15.4 |  |  | 96,274 |  |  | 14.4 |  |  |  |  |  |  |  |  |  |
| Asia-Pacific |  | 77,884 |  |  | 8.9 |  |  | 69,416 |  |  | 10.4 |  |  |  |  |  |  |  |  |  |
| Total revenue |  | $ | 877,066 |  |  | 100.0 | % |  | $ | 667,562 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |

[0001596532-22-000112:mdna:20]
[same as prior period, unchanged from 0001596532-21-000354:mdna:19]

[0001596532-22-000112:mdna:21]
Product revenue primarily consists of sales of our switching and routing products, and software licenses.  Service revenue is primarily derived from sales of PCS contracts, which is typically purchased in conjunction with our products, and subsequent renewals of those contracts. We expect our revenue may vary from period to period based on, among other things, the timing, size, and complexity of orders, especially with respect to our large end customers.

[0001596532-22-000112:mdna:22]
Product revenue increased $185.6 million, or 34.4%, for the three months ended March 31, 2022 compared to the same period in 2021.  The increase was primarily driven by increased demand for our switching and routing products from our existing customers, with strong contributions from across our customer base. In addition, we added new customers in the period, as we continued to expand our presence in the enterprise market. Service revenue increased $23.9 million, or 18.6%, in the three months ended March 31, 2022, compared to the same period in 2021, as a result of continued growth in initial and renewal PCS contracts as our customer installed base has continued to expand. International revenues decreased slightly from 24.8% of total revenue in the three months ended March 31, 2021 to 24.3% of total revenues in the three months ended March 31, 2022, which was primarily due to reduced purchases from large global customers in the Asia-Pacific region. We continued to experience competitive pricing pressure on our products and services.

[0001596532-22-000112:mdna:23]
[same as prior period, unchanged from 0001596532-21-000354:mdna:23]

[0001596532-22-000112:mdna:24]
Cost of product revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs of our manufacturing operations including freight, and other costs associated with manufacturing our products and managing our inventory and supply chain. Cost of service revenue primarily consists of personnel and other costs associated with our global customer support and services organizations.

[0001596532-22-000112:mdna:25]
Cost of revenue increased $80.9 million, or 33.4% for the three months ended March 31, 2022 compared to the same period in 2021, which was primarily driven by a corresponding increase in product and service revenues, coupled with an increase in supply chain costs due to increased production capacity, component and other supply chain costs and higher volumes.

[0001596532-22-000112:mdna:26]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of

[0001596532-22-000112:mdna:27]
factors, including pricing pressure on our products and services due to competition, the mix of sales to large end customers who generally receive lower pricing, the mix of products sold, manufacturing-related costs, including costs associated with supply chain sourcing activities, merchant silicon costs, and excess/obsolete inventory write-downs, including charges for excess/obsolete component inventory held by our contract manufacturers. We expect our gross margin to fluctuate over time, depending on the factors described above.

[0001596532-22-000112:mdna:28]
Gross margin decreased from 63.7% to 63.1% for the three months ended March 31, 2022 compared to the same period in 2021. The decrease was primarily driven by higher supply chain costs, which were partly offset by improved product margins due to a reduced proportion of our sales to larger end customers who generally receive larger discounts.

[0001596532-22-000112:mdna:29]
[same as prior period, unchanged from 0001596532-21-000354:mdna:28]

[0001596532-22-000112:mdna:30]
[same as prior period, unchanged from 0001596532-21-000354:mdna:29]

[0001596532-22-000112:mdna:31]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2022 |  | 2021 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 172,006 |  |  | $ | 132,487 |  |  | $ | 39,519 |  |  | 29.8 | % |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 80,739 |  |  | 71,020 |  |  | 9,719 |  |  | 13.7 |  |  |  |  |  |  |  |  |  |
| General and administrative |  | 23,113 |  |  | 15,473 |  |  | 7,640 |  |  | 49.4 |  |  |  |  |  |  |  |  |  |
| Total operating expenses |  | $ | 275,858 |  |  | $ | 218,980 |  |  | $ | 56,878 |  |  | 26.0 | % |  |  |  |  |  |  |  |  |

[0001596532-22-000112:mdna:32]
[same as prior period, unchanged from 0001596532-21-000354:mdna:31]

[0001596532-22-000112:mdna:33]
Research and development expenses consist primarily of personnel costs, prototype expenses, third-party engineering costs, and an allocated portion of facility and IT costs. Our research and development efforts are focused on new product development and maintaining and developing additional functionality for our existing products, including new releases and upgrades to our EOS software and applications. We expect our research and development expenses to increase in absolute dollars as we continue to invest in software development in order to expand the capabilities of our cloud networking platform, introduce new products and features, and continue to invest in our technology.

[0001596532-22-000112:mdna:34]
Research and development expenses increased $39.5 million, or 29.8%, in the three months ended March 31, 2022 compared to the same period in 2021. The increase in the three months ended March 31, 2022 was primarily due to a $21.4 million increase in new product introduction costs, including third party engineering and other product development costs, and an $8.9 million increase in personnel costs driven by headcount growth.

[0001596532-22-000112:mdna:35]
[same as prior period, unchanged from 0001596532-21-000354:mdna:35]

[0001596532-22-000112:mdna:36]
[same as prior period, unchanged from 0001596532-21-000354:mdna:36]

[0001596532-22-000112:mdna:37]
Sales and marketing expenses increased $9.7 million, or 13.7%, for the three months ended March 31, 2022 compared to the same period in 2021. The increase in the three months ended March 31, 2022 included $11.0 million in personnel-related costs mostly driven by an increase in headcount and sales incentive compensation.

[0001596532-22-000112:mdna:38]
[same as prior period, unchanged from 0001596532-21-000354:mdna:38]

[0001596532-22-000112:mdna:39]
General and administrative expenses consist primarily of personnel costs and professional services costs. General and administrative personnel costs include those for certain executive functions, as well as finance, human resources and legal functions. Our professional services costs are primarily related to external legal, accounting and tax services.

[0001596532-22-000112:mdna:40]
General and administrative expenses increased $7.6 million, or 49.4%, in the three months ended March 31, 2022 compared to the same period in 2021.  The increase for the three months ended March 31, 2022 was primarily related to $5.3 million in personnel-related costs, which primarily consisted of increased stock-based compensation expenses.

[0001596532-22-000112:mdna:41]
[same as prior period, unchanged from 0001596532-21-000354:mdna:41]

[0001596532-22-000112:mdna:42]
Other income, net consists primarily of interest income from our cash, cash equivalents and marketable securities, gains and losses on our equity investments in privately-held companies and marketable securities, and foreign currency

[0001596532-22-000112:mdna:43]
transaction gains and losses. We expect other income, net may fluctuate in the future as a result of the re-measurement of our equity investments upon the occurrence of observable price changes and/or impairments, changes in interest rates or returns on our cash and cash equivalents and marketable securities, and foreign currency exchange rate fluctuations.

[0001596532-22-000112:mdna:44]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2022 |  | 2021 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Other income, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 2,428 |  |  | $ | 2,045 |  |  | $ | 383 |  |  | 18.7 | % |  |  |  |  |  |  |  |  |
| Unrealized gain on equity investments |  | 28,497 |  |  | — |  |  | 28,497 |  |  | 100.0 |  |  |  |  |  |  |  |  |  |
| Other income (expense), net |  | 555 |  |  | (470) |  |  | 1,025 |  |  | 218.1 |  |  |  |  |  |  |  |  |  |
| Total other income, net |  | $ | 31,480 |  |  | $ | 1,575 |  |  | $ | 29,905 |  |  | 1,898.7 | % |  |  |  |  |  |  |  |  |

[0001596532-22-000112:mdna:45]
The increase in other income, net was driven by a $28.5 million unrealized gain on our equity investments. For additional information, refer to Note 2 – Fair Value Measurement and Investments in the notes to the condensed consolidated financial statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.

[0001596532-22-000112:mdna:46]
[same as prior period, unchanged from 0001596532-21-000354:mdna:45]

[0001596532-22-000112:mdna:47]
[same as prior period, unchanged from 0001596532-21-000354:mdna:46]

[0001596532-22-000112:mdna:48]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2022 |  | 2021 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Income before income taxes |  | $ | 309,467 |  |  | $ | 207,867 |  |  | $ | 101,600 |  |  | 48.9 | % |  |  |  |  |  |  |  |  |
| Provision for income taxes |  | 37,208 |  |  | 27,501 |  |  | 9,707 |  |  | 35.3 | % |  |  |  |  |  |  |  |  |
| Effective tax rate |  | 12.0 | % |  | 13.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001596532-22-000112:mdna:49]
For the three months ended March 31, 2022 and 2021, we recorded a provision of $37.2 million and $27.5 million for income taxes, respectively. The increase in income taxes was primarily due to an overall increase in pre-tax income, combined with a favorable change in jurisdictional mix in earnings in the three months ended March 31, 2022, as compared to the same period in 2021.

[0001596532-22-000112:mdna:50]
[same as prior period, unchanged from 0001596532-21-000354:mdna:49]

[0001596532-22-000112:mdna:51]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of March 31, 2022, our total balance of cash, cash equivalents and marketable securities was approximately $3.4 billion, of which approximately $600.1 million was held outside of the U.S. in our foreign subsidiaries.

[0001596532-22-000112:mdna:52]
Our cash, cash equivalents and marketable securities are held for general business purpose including the funding of working capital. Our marketable securities investment portfolio is primarily invested in highly-rated securities, with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations, will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and stock repurchases. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-22-000112:mdna:53]
[same as prior period, unchanged from 0001596532-21-000354:mdna:52]

[0001596532-22-000112:mdna:54]
|  |  | Three Months Ended March 31, |
|  |  | 2022 |  | 2021 |
| Cash provided by operating activities |  | $ | 217,138 |  |  | $ | 254,675 |  |
| Cash used in investing activities |  | (72,615) |  |  | (217,949) |  |
| Cash used in financing activities |  | (129,809) |  |  | (85,770) |  |
| Effect of exchange rate changes |  | (481) |  |  | (838) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 14,233 |  |  | $ | (49,882) |  |

[0001596532-22-000112:mdna:55]
[same as prior period, unchanged from 0001596532-21-000354:mdna:54]

[0001596532-22-000112:mdna:56]
During the three months ended March 31, 2022, cash provided by operating activities was $217.1 million, primarily from net income of $272.3 million, reduced by non-cash adjustments to net income of $35.4 million, and a net increase of $19.7 million in working capital requirements. Cash outflows from the increase in working capital requirements primarily consisted of a $131.9 million increase in accounts receivables due to increased product and service billings, a $108.0 million increase in prepaid and other current assets primarily driven by increased inventory deposits to our contract manufacturers and product deferred cost of sales driven by higher product revenue deferrals, and a $43.5 million increase in inventory to help mitigate the impact of supply chain disruptions. These operating cash outflows were largely offset by a $187.2 million increase in deferred revenue reflecting ongoing growth from PCS contracts, and increased product deferred revenue related to contracts with acceptance terms, and a $107.0 million increase in income taxes payable due to timing of payments, the impact of IRC Section 174 and an increase in pre-tax income.

[0001596532-22-000112:mdna:57]
During the three months ended March 31, 2021, cash provided by operating activities was $254.7 million, primarily from net income of $180.4 million and non-cash adjustments to net income of $61.3 million driven by stock-based compensation and depreciation and amortization, and a net decrease of $13.0 million in working capital requirements. Cash inflows from the decrease in working capital requirements primarily consisted of a $69.2 million increase in product and service deferred revenue driven by contacts with acceptance terms and continued growth in PCS contracts, which was largely offset by cash outflows that consisted of a $20.8 million decrease in accrued liabilities, including the payment of corporate bonuses, a $15.3 million increase in prepaid expenses including increased deferred product cost of revenue, and a $10.4 million decrease in income taxes payables.

[0001596532-22-000112:mdna:58]
[same as prior period, unchanged from 0001596532-21-000354:mdna:58]

[0001596532-22-000112:mdna:59]
During the three months ended March 31, 2022, cash used in investing activities was $72.6 million, primarily consisting of purchases of available-for-sale securities of $412.6 million, a business acquisition of $37.6 million, purchases of non-marketable equity investments of $11.7 million, and purchases of property and equipment of $14.9 million, partially offset by proceeds from maturities of marketable securities of $404.2 million.

[0001596532-22-000112:mdna:60]
During the three months ended March 31, 2021, cash used in investing activities was $217.9 million, primarily consisting of purchases of available-for-sale securities of $590.5 million, and purchases of property and equipment of $5.1 million, partially offset by proceeds from maturities of marketable securities of $379.6 million.

[0001596532-22-000112:mdna:61]
[same as prior period, unchanged from 0001596532-21-000354:mdna:61]

[0001596532-22-000112:mdna:62]
During the three months ended March 31, 2022, cash used in financing activities was $129.8 million, primarily consisting of payments for repurchases of our common stock from the open market of $136.2 million, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $19.2 million.

[0001596532-22-000112:mdna:63]
During the three months ended March 31, 2021, cash used in financing activities was $85.8 million, primarily consisting of payments for repurchases of our common stock from the open market of $101.4 million, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $18.1 million.

[0001596532-22-000112:mdna:64]
Stock Repurchase Program

[0001596532-22-000112:mdna:65]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the “Repurchase Program”). This authorization allowed us to repurchase shares of our common stock over three years and we completed our repurchases under the Repurchase Program during the fourth quarter of 2021. In the fourth quarter of 2021, our board of directors authorized an additional $1.0 billion stock repurchase program (the "New Repurchase Program"). This authorization allows us to repurchase shares of our common stock and will be funded from working capital. The New Repurchase Program commenced in the fourth quarter of 2021, and expires on the three-year anniversary thereof. The New Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the company at any time without prior notice.  During the quarter ended March 31, 2022, we repurchased a total of $136.2 million of our common stock. As of

[0001596532-22-000112:mdna:66]
March 31, 2022, the remaining authorized amount for repurchases under the New Repurchase Program was $790.8 million. Refer to Note 6. Stockholders' Equity and Stock-Based Compensation of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of the Quarterly Report on Form 10-Q for further discussion.

[0001596532-22-000112:mdna:67]
Material Cash Requirements

[0001596532-22-000112:mdna:68]
Our material cash requirements will have an impact on our future liquidity. Our material cash requirements represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalents and marketable securities.

[0001596532-22-000112:mdna:69]
Our material cash requirements include the following contractual and other obligations:

[0001596532-22-000112:mdna:70]
Leases

[0001596532-22-000112:mdna:71]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of March 31, 2022, we had lease payment obligations, net of immaterial sublease income, of $88.4 million, with $18.0 million payable within 12 months.

[0001596532-22-000112:mdna:72]
Purchase Obligations

[0001596532-22-000112:mdna:73]
Purchase obligations represent an estimate of all open purchase orders and contractual obligations, made either directly by Arista or by our contract manufacturers on our behalf, in the ordinary course of business for which we have not received the goods or services. As of March 31, 2022, we had $4.3 billion of such purchase obligations, with $2.5 billion expected to be received within 12 months, and $0.8 billion with confirmed receipt dates in excess of one year.  In addition, we had $1.0 billion of purchase obligations that were placed in the current quarter for which receipt dates have yet to be confirmed. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-22-000112:mdna:74]
Accrued Income Taxes

[0001596532-22-000112:mdna:75]
In connection with the Tax Cuts and Jobs Act of 2017("TCJA"), we recorded a federal income tax payable for transition tax on the mandatory deemed repatriation of foreign earnings that will be payable over an eight-year period.  As of March 31, 2022, $6.3 million of long-term transition tax payable represents the remaining federal income tax payable due between one and three years. In addition to the long-term transition tax payable, as of March 31, 2022 we have recorded long-term tax liabilities of $68.2 million related to uncertain tax positions; however, we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-22-000112:mdna:76]
In addition, beginning in 2022, the TCJA eliminates the option to deduct research and development expenditures currently and requires taxpayers to capitalize and amortize them over five years pursuant to IRC Section 174. Although there is proposed legislation that would defer the capitalization requirement to later years, we have no assurance that the provision will be repealed or otherwise modified. Consequently, we accrued an incremental income tax liability of $49.0 million as of March 31, 2022, associated with these new regulations, and may incur up to an additional $130.0 million in tax liabilities for the remainder of 2022.

[0001596532-22-000112:mdna:77]
Off-balance Sheet Arrangements

[0001596532-22-000112:mdna:78]
As of March 31, 2022, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-22-000112:mdna:79]
Critical Accounting Estimates

[0001596532-22-000112:mdna:80]
Our management’s discussion and analysis of financial condition and results of operations are based on our unaudited condensed consolidated financial statements, which have been prepared in accordance with GAAP.  The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. We believe the critical accounting policies and estimates in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our Annual Report on Form 10-K filed with the SEC on February 15, 2022 reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting policies and estimates as disclosed in our Annual Report on Form 10-K.

[0001596532-22-000112:mdna:81]
[same as prior period, unchanged from 0001596532-21-000354:mdna:74]

[0001596532-22-000112:mdna:82]
Refer to the sections titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
