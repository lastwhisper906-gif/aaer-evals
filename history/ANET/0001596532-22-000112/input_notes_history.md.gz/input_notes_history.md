# ANET note change history — 0001596532-21-000354 → 0001596532-22-000112


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2022-05-03):
[0001596532-22-000112:note_history:1]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of March 31, 2022, we had non-cancellable purchase commitments of $4,318.9 million, with $2,427.7 million with confirmed receipt dates within 12 months, $850.2 million with confirmed receipt dates greater than 12 months and the remaining $1,041 million with the receipt dates to be confirmed. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

- added (2022-05-03):
[0001596532-22-000112:note_history:2]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $98.4 million and $49.1 million as of March 31, 2022 and December 31, 2021, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the accompanying consolidated balance sheets.

- changed (2022-05-03):
[0001596532-22-000112:note_history:3]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California; trial has been set for October 23, 2023.  On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement.
  (was, 2021-11-02, similarity 0.7339):
[0001596532-21-000354:note_history:3]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. The court has set a trial date for August 8, 2022.

- changed (2022-05-03):
[0001596532-22-000112:note_history:4]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated. However, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.
  (was, 2021-11-02, similarity 0.6622):
[0001596532-21-000354:note_history:4]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated. However, the

- added (2022-05-03):
[0001596532-22-000112:note_history:5]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. 
    We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2022, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.

- removed (2022-05-03):
[0001596532-21-000354:note_history:6]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2021, we had non-cancellable purchase commitments of $2,147.0 million, of which $2,109.5 million was to our contract manufacturers and suppliers. In addition, we had deposits to our contract manufacturers to secure our purchase commitments in the amount of $27.1 million and $21.5 million as of September 30, 2021 and December 31, 2020, respectively. These deposits are included in “Prepaid expenses and other current assets” and “Other assets” on the condensed consolidated balance sheets.

- removed (2022-05-03):
[0001596532-21-000354:note_history:7]
outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

- removed (2022-05-03):
[0001596532-21-000354:note_history:8]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

- removed (2022-05-03):
[0001596532-21-000354:note_history:9]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2021, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-05-03):
[0001596532-22-000112:note_history:10]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments of a normal recurring nature necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2022, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2021 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.
  (was, 2021-11-02, similarity 0.9796):
[0001596532-21-000354:note_history:10]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments of a normal recurring nature necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2021, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2020 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

- added (2022-05-03):
[0001596532-22-000112:note_history:11]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, valuation of inventory and contract manufacturer/supplier liabilities, accounting for income taxes, including the recognition of deferred tax assets and liabilities, valuation allowance on deferred tax assets and reserves for uncertain tax positions, revenue recognition and deferred revenue, allowance for doubtful accounts, sales rebates and return reserves, valuation of goodwill and acquisition-related intangible assets, estimate of useful lives of long-lived assets including intangible assets, and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust these estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from these estimates.

- added (2022-05-03):
[0001596532-22-000112:note_history:12]
The global coronavirus ("COVID-19") pandemic as well as the Russian-Ukrainian conflict continue to evolve and have widespread and unpredictable impacts on the global economy and business activities.

- added (2022-05-03):
[0001596532-22-000112:note_history:13]
Our contract manufacturers and suppliers have experienced workforce disruptions, delays in component sourcing, production and export of their products as well as component shortages and increased component costs, which have disrupted our supply chain and has impacted and will likely continue to impact our ability to supply products to our customers on a timely basis. While we have experienced improvements in overall demand from customers in recent quarters, we believe ongoing supply disruptions combined with other supply chain related constraints, could impact our ability to fulfill this increased demand and as a result could negatively impact our business in future periods. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and may negatively impact our gross margin. Although the overall economy continues to recover, several issues including inflation risk, supply chain bottlenecks, and COVID-19 variants have and may continue to impact the pace of the recovery.  The extent of the impact on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, the impact to our customers, partners, employees, contract manufacturers and supply chain, as well as restrictions on travel and transport, all of which continue to evolve and are unpredictable. Management

- added (2022-05-03):
[0001596532-22-000112:note_history:14]
continues to actively monitor the impact of the pandemic on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which the COVID-19 pandemic may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

- added (2022-05-03):
[0001596532-22-000112:note_history:15]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. ASU 2021-08 requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC 606. Under current GAAP, an acquirer generally recognizes assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 results in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption impact was immaterial to the condensed consolidated financial statements. The standard will not impact acquired contract assets or liabilities from business combinations occurring prior to the adoption date.

- removed (2022-05-03):
[0001596532-21-000354:note_history:16]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and accompanying notes. These estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; valuation of goodwill and acquisition-related intangible assets; accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; estimate of useful lives of long-lived assets including intangible assets; valuation of inventory and contract manufacturer/supplier liabilities; and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.

- removed (2022-05-03):
[0001596532-21-000354:note_history:17]
The global coronavirus ("COVID-19") pandemic and resulting mitigation efforts by governments around the world to contain or slow its spread have negatively impacted the global economy and disrupted business activities.

- removed (2022-05-03):
[0001596532-21-000354:note_history:18]
Our contract manufacturers and suppliers have experienced workforce disruptions, delays in component sourcing, production, and export of their products, which have disrupted our supply chain and has impacted and likely will continue to impact our ability to supply products to our customers on a timely basis. While we have experienced improvements in overall demand from customers in recent quarters, we believe ongoing COVID-19 related disruptions combined with other supply chain related constraints, could impact our ability to fulfill this increased demand and as a result could negatively impact our business in future periods. However, the extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, including the duration and spread of the pandemic and related mitigation efforts, the impact to our customers, partners, contract manufacturers and supply chain, as well as restrictions on travel and transport, all of which continue to evolve and are unpredictable. Management continues to actively monitor the impact of the pandemic on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which the COVID-19 pandemic may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

- removed (2022-05-03):
[0001596532-21-000354:note_history:19]
Income Taxes

- removed (2022-05-03):
[0001596532-21-000354:note_history:20]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in Topic 740 and amending existing guidance to improve consistent application. This new standard is effective for our interim and annual periods beginning January 1, 2021. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. We adopted this new standard on January 1, 2021 with no material impact on our condensed consolidated financial statements.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2022-05-03):
[0001596532-22-000112:note_history:21]
The following is an analysis of our marketable securities in unrealized loss positions for a period of less than twelve months. As of March 31, 2022, there are no unrealized loss positions with a duration equal to or greater than twelve months (in thousands):

- added (2022-05-03):
[0001596532-22-000112:note_history:22]
|  |  | As of March 31, 2022 |
|  |  | Unrealized Losses within 12 months |
|  |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 1,080,225 |  |  | $ | (12,549) |  |
| Corporate bonds |  | 1,223,546 |  |  | (13,088) |  |
| Agency securities |  | 262,329 |  |  | (2,355) |  |
| Total |  | $ | 2,566,100 |  |  | $ | (27,992) |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2022-05-03):
[0001596532-21-000354:note_history:23]
Subsequent event 
Common Stock Split

- removed (2022-05-03):
[0001596532-21-000354:note_history:24]
On November 1, 2021, the Company announced a four-for-one split of its common stock effected in the form of a stock dividend to shareholders of record as of the close of business on November 11, 2021. The stock dividend payment date is expected to be on or about November 17, 2021, and trading of the Company’s common stock will begin on a split-adjusted basis on or about November 18, 2021.

- removed (2022-05-03):
[0001596532-21-000354:note_history:25]
Stock Repurchases

- removed (2022-05-03):
[0001596532-21-000354:note_history:26]
Subsequent to September 30, 2021, our board of directors authorized a new $1.0 billion stock repurchase program (the “New Repurchase Program”, together with the “Existing Repurchase Program,” the “Repurchase Programs”). This authorization allows the Company to repurchase shares of its common stock and will be funded from working capital. Repurchases may be made at management's discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The New Repurchase Program commences upon the earlier of the use of all dollar amounts authorized under the Existing Repurchase Program and April 2022, and it expires on the three year anniversary thereof. The Repurchase Programs do not obligate Arista to acquire any of its common stock, and may be suspended or discontinued by the company at any time without prior notice.
