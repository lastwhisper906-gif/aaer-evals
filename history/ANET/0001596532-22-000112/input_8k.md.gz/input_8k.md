# ANET 8-K — 0001596532-22-000111 filed 2022-05-02

## item codes, every 8-K on or before 2022-05-03

- 2022-05-02 0001596532-22-000111 — 2.02, 9.01
- 2022-03-29 0001596532-22-000100 — 5.02
- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2022-05-03

- none on or before 2022-05-03

## item 2.02 — earnings release, exhibit 99.1

[0001596532-22-000111:8k_2_02:1]
EX-99.1
2
ex991q122-earningsrelease.htm
EX-99.1

[0001596532-22-000111:8k_2_02:2]
Document

[0001596532-22-000111:8k_2_02:3]
Exhibit 99.1

[0001596532-22-000111:8k_2_02:4]
Arista Networks, Inc. Reports First Quarter 2022 Financial Results

[0001596532-22-000111:8k_2_02:5]
SANTA CLARA, Calif.- May 2, 2022 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments, today announced financial results for its first quarter ended March 31, 2022.

[0001596532-22-000111:8k_2_02:6]
First Quarter Financial Highlights

[0001596532-22-000111:8k_2_02:7]
“Arista has delivered record Q1 2022 sales despite the sustained supply chain challenges. I am pleased with our enterprise execution and cloud titan strength in these uncertain times,” stated Jayshree Ullal, President and CEO of Arista Networks.

[0001596532-22-000111:8k_2_02:8]
•Revenue of $877.1 million, an increase of 6.4% compared to the fourth quarter of 2021, and an increase of 31.4% from the first quarter of 2021.

[0001596532-22-000111:8k_2_02:9]
•GAAP gross margin of 63.1%, compared to GAAP gross margin of 63.4% in the fourth quarter of 2021 and 63.7% in the first quarter of 2021.

[0001596532-22-000111:8k_2_02:10]
•Non-GAAP gross margin of 63.9%, compared to non-GAAP gross margin of 64.3% in the fourth quarter of 2021 and 64.7% in the first quarter of 2021.

[0001596532-22-000111:8k_2_02:11]
•GAAP net income of $272.3 million, or $0.85 per diluted share, compared to GAAP net income of $180.4 million, or $0.57 per diluted share in the first quarter of 2021.

[0001596532-22-000111:8k_2_02:12]
•Non-GAAP net income of $268.5 million, or $0.84 per diluted share, compared to non-GAAP net income of $198.8 million, or $0.62 per diluted share in the first quarter of 2021.

[0001596532-22-000111:8k_2_02:13]
Commenting on the company’s financial results, Ita Brennan, Arista’s CFO said, “We are pleased with the continued growth of our enterprise business in the first quarter, combined with robust next generation product qualification and deployment activity with our cloud customers.”

[0001596532-22-000111:8k_2_02:14]
Company Highlights

[0001596532-22-000111:8k_2_02:15]
•Arista and Microsoft  -  Rani Borkar, Corporate Vice President of Azure Hardware Systems and Infrastructure for Microsoft, said, “For more than a decade, Arista has provided networking solutions for Microsoft’s cloud infrastructure, enabling the scale, reliability, and performance that Microsoft Azure customers expect. As we continue to advance our offerings from the intelligent cloud to the intelligent edge and beyond, Arista continues to be a trusted and strategic partner to Microsoft."

[0001596532-22-000111:8k_2_02:16]
•The Next Frontier in AI Networking - Arista discusses the new Arista 7800R AI Spine in meeting the requirements for next generation AI Networks. The Arista 7800R flagship platform delivers low power, low latency, high performance and reliability in combination with Arista EOS’ rich features and traffic management addresses AI workload requirements across Ethernet fabrics.

[0001596532-22-000111:8k_2_02:17]
•Arista Integrates Threat Detection and Response into the Cognitive Campus - Arista announced that its 720XP series of switches for campus deliver embedded security and packet analysis. By embedding NDR (Network Detection and Response) capabilities into the Arista EOS-based switches, powered by AVA, customers derive broader visibility and threat hunting across the modern cognitive campus.

[0001596532-22-000111:8k_2_02:18]
Financial Outlook

[0001596532-22-000111:8k_2_02:19]
For the second quarter of 2022, we expect:

[0001596532-22-000111:8k_2_02:20]
•Revenue between $950 million to $1 billion;

[0001596532-22-000111:8k_2_02:21]
•Non-GAAP gross margin of 60% to 62%; and

[0001596532-22-000111:8k_2_02:22]
•Non-GAAP operating margin of approximately 37% to 38%.

[0001596532-22-000111:8k_2_02:23]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and certain non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below under “Non-GAAP Financial Measures”).

[0001596532-22-000111:8k_2_02:24]
Prepared Materials and Conference Call Information

[0001596532-22-000111:8k_2_02:25]
Arista's executives will discuss the first quarter 2022 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-22-000111:8k_2_02:26]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-22-000111:8k_2_02:27]
Forward-Looking Statements

[0001596532-22-000111:8k_2_02:28]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the second quarter of 2022, statements regarding Arista's business plans and its ability to execute such plans, and statements regarding the benefits of Arista's products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: the impact of the COVID-19 pandemic and related public health measures on our business; the impact of supply shortages and manufacturing constraints on our business including extended lead times and inventory purchase commitments, increased component costs including as a result of increasing inflation, interruptions or delays in shipments; a decline in our revenue growth rate; unpredictability of our results of operations; variability in our gross margins; the timing of orders and their fulfillment; adverse global economic and geopolitical conditions including inflationary pressures and the impact of the Russian/Ukrainian conflict; insufficient, excess or obsolete inventory; a decline in end customer demand for our products or services; variability in end customer mix or product mix; deferral, reduction or cancellation of orders from end customers; the rapid evolution of the networking market; reduced information technology and network infrastructure spending; any failure to successfully pursue new products and service offerings and expand into adjacent markets; our ability to anticipate technological shifts and develop products to meet those technological shifts; intense competition; expansion of our international sales and operations; investment or acquisition in other businesses; seasonality; our ability to attract new large end customers or sell products and services to existing end customers; our ability to increase market awareness of our company and new products and services; product quality problems; our ability to protect, defend and maintain our intellectual property rights; vulnerabilities in our products and failure of our products to detect security breaches our intellectual property rights; and tax, tariff, import/export restrictions; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-22-000111:8k_2_02:29]
Non-GAAP Financial Measures

[0001596532-22-000111:8k_2_02:30]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangible assets, certain non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-22-000111:8k_2_02:31]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-22-000111:8k_2_02:32]
The company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. The company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. A reconciliation of the non-GAAP financial measures guidance to the corresponding GAAP measures on a forward-looking basis is not available because stock-based compensation expense is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-22-000111:8k_2_02:33]
About Arista Networks

[0001596532-22-000111:8k_2_02:34]
Arista Networks is an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments. Arista’s award-winning platforms deliver availability, agility, automation, analytics and security through an advanced network operating stack. For more information, visit www.arista.com.

[0001596532-22-000111:8k_2_02:35]
ARISTA, EOS and AVA are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-22-000111:8k_2_02:36]
| Arista Networks, Inc. |  |  |  |  |
| Liz Stine, 408-547-5885 |  |  |
| Director, Investor Relations |  |  |
| liz@arista.com |  |  |  |  |

[0001596532-22-000111:8k_2_02:37]
ARISTA NETWORKS, INC.

[0001596532-22-000111:8k_2_02:38]
Condensed Consolidated Statements of Operations

[0001596532-22-000111:8k_2_02:39]
(Unaudited in thousands, except per share amounts)

[0001596532-22-000111:8k_2_02:40]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 724,718 |  |  | $ | 539,145 |  |  |  |  |  |
| Service |  | 152,348 |  |  | 128,417 |  |  |  |  |  |
| Total revenue |  | 877,066 |  |  | 667,562 |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 293,809 |  |  | 218,433 |  |  |  |  |  |
| Service |  | 29,412 |  |  | 23,857 |  |  |  |  |  |
| Total cost of revenue |  | 323,221 |  |  | 242,290 |  |  |  |  |  |
| Gross profit |  | 553,845 |  |  | 425,272 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 172,006 |  |  | 132,487 |  |  |  |  |  |
| Sales and marketing |  | 80,739 |  |  | 71,020 |  |  |  |  |  |
| General and administrative |  | 23,113 |  |  | 15,473 |  |  |  |  |  |
| Total operating expenses |  | 275,858 |  |  | 218,980 |  |  |  |  |  |
| Income from operations |  | 277,987 |  |  | 206,292 |  |  |  |  |  |
| Other income, net |  | 31,480 |  |  | 1,575 |  |  |  |  |  |
| Income before income taxes |  | 309,467 |  |  | 207,867 |  |  |  |  |  |
| Provision for income taxes |  | 37,208 |  |  | 27,501 |  |  |  |  |  |
| Net income |  | $ | 272,259 |  |  | $ | 180,366 |  |  |  |  |  |
| Net income per share (1): |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.88 |  |  | $ | 0.59 |  |  |  |  |  |
| Diluted |  | $ | 0.85 |  |  | $ | 0.57 |  |  |  |  |  |
| Weighted-average shares used in computing net income per share (1): |  |  |  |  |  |  |  |  |
| Basic |  | 308,045 |  |  | 305,224 |  |  |  |  |  |
| Diluted |  | 319,652 |  |  | 318,492 |  |  |  |  |  |

[0001596532-22-000111:8k_2_02:41]
(1) Prior period results have been adjusted to reflect the four-for-one stock split effected in the form of a stock dividend in November 2021.

[0001596532-22-000111:8k_2_02:42]
4

[0001596532-22-000111:8k_2_02:43]
ARISTA NETWORKS, INC.

[0001596532-22-000111:8k_2_02:44]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-22-000111:8k_2_02:45]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-22-000111:8k_2_02:46]
|  |  | Three Months Ended March 31, |  |  |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 553,845 |  |  | $ | 425,272 |  |  |  |  |  |  |  |
| GAAP gross margin |  | 63.1 | % |  | 63.7 | % |  |  |  |  |  |  |
| Stock-based compensation expense |  | 1,309 |  |  | 1,400 |  |  |  |  |  |  |  |
| Intangible asset amortization |  | 5,721 |  |  | 5,464 |  |  |  |  |  |  |  |
| Non-GAAP gross profit |  | $ | 560,875 |  |  | $ | 432,136 |  |  |  |  |  |  |  |
| Non-GAAP gross margin |  | 63.9 | % |  | 64.7 | % |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 277,987 |  |  | $ | 206,292 |  |  |  |  |  |  |  |
| Stock-based compensation expense |  | 50,279 |  |  | 37,553 |  |  |  |  |  |  |  |
| Intangible asset amortization |  | 7,311 |  |  | 7,430 |  |  |  |  |  |  |  |
| Non-GAAP income from operations |  | $ | 335,577 |  |  | $ | 251,275 |  |  |  |  |  |  |  |
| Non-GAAP operating margin |  | 38.3 | % |  | 37.6 | % |  |  |  |  |  |  |
| GAAP net income |  | $ | 272,259 |  |  | $ | 180,366 |  |  |  |  |  |  |  |
| Stock-based compensation expense |  | 50,279 |  |  | 37,553 |  |  |  |  |  |  |  |
| Intangible asset amortization |  | 7,311 |  |  | 7,430 |  |  |  |  |  |  |  |
| Unrealized gain on equity investments |  | (28,497) |  |  | — |  |  |  |  |  |  |  |
| Tax benefit on stock-based awards |  | (30,964) |  |  | (20,906) |  |  |  |  |  |  |  |
| Income tax effect on non-GAAP exclusions |  | (1,880) |  |  | (5,606) |  |  |  |  |  |  |  |
| Non-GAAP net income |  | $ | 268,508 |  |  | $ | 198,837 |  |  |  |  |  |  |  |
| GAAP diluted net income per share (1) |  | $ | 0.85 |  |  | $ | 0.57 |  |  |  |  |  |  |  |
| Non-GAAP adjustments to net income |  | (0.01) |  |  | 0.05 |  |  |  |  |  |  |  |
| Non-GAAP diluted net income per share |  | $ | 0.84 |  |  | $ | 0.62 |  |  |  |  |  |  |  |
| Weighted-average shares used in computing diluted net income per share (1) |  | 319,652 |  |  | 318,492 |  |  |  |  |  |  |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,309 |  |  | $ | 1,400 |  |  |  |  |  |  |  |
| Research and development |  | 27,576 |  |  | 21,982 |  |  |  |  |  |  |  |
| Sales and marketing |  | 13,109 |  |  | 10,085 |  |  |  |  |  |  |  |
| General and administrative |  | 8,285 |  |  | 4,086 |  |  |  |  |  |  |  |
| Total |  | $ | 50,279 |  |  | $ | 37,553 |  |  |  |  |  |  |  |
| (1) Prior period results have been adjusted to reflect the four-for-one stock split effected in the form of a stock dividend in November 2021. |  |  |  |  |  |  |

[0001596532-22-000111:8k_2_02:47]
ARISTA NETWORKS, INC.

[0001596532-22-000111:8k_2_02:48]
Condensed Consolidated Balance Sheets

[0001596532-22-000111:8k_2_02:49]
(Unaudited, in thousands)

[0001596532-22-000111:8k_2_02:50]
|  |  | March 31, 2022 |  | December 31, 2021 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 635,025 |  |  | $ | 620,813 |  |
| Marketable securities |  | 2,788,889 |  |  | 2,787,502 |  |
| Accounts receivable, net |  | 648,606 |  |  | 516,509 |  |
| Inventories |  | 694,217 |  |  | 650,117 |  |
| Prepaid expenses and other current assets |  | 338,437 |  |  | 237,735 |  |
| Total current assets |  | 5,105,174 |  |  | 4,812,676 |  |
| Property and equipment, net |  | 87,391 |  |  | 78,634 |  |
| Acquisition-related intangible assets, net |  | 105,244 |  |  | 93,555 |  |
| Goodwill |  | 216,915 |  |  | 188,397 |  |
| Investments |  | 38,625 |  |  | 20,247 |  |
| Operating lease right-of-use assets |  | 66,671 |  |  | 65,182 |  |
| Deferred tax assets |  | 446,347 |  |  | 442,295 |  |
| Other assets |  | 41,819 |  |  | 33,443 |  |
| TOTAL ASSETS |  | $ | 6,108,186 |  |  | $ | 5,734,429 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 204,675 |  |  | $ | 202,636 |  |
| Accrued liabilities |  | 197,063 |  |  | 226,643 |  |
| Deferred revenue |  | 778,436 |  |  | 593,578 |  |
| Other current liabilities |  | 188,831 |  |  | 86,972 |  |
| Total current liabilities |  | 1,369,005 |  |  | 1,109,829 |  |
| Income taxes payable |  | 74,497 |  |  | 69,916 |  |
| Operating lease liabilities, non-current |  | 57,474 |  |  | 56,527 |  |
| Deferred revenue, non-current |  | 345,310 |  |  | 335,734 |  |
| Deferred tax liabilities, non-current |  | 51,051 |  |  | 129,074 |  |
| Other long-term liabilities |  | 57,672 |  |  | 54,749 |  |
| TOTAL LIABILITIES |  | 1,955,009 |  |  | 1,755,829 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 31 |  | 31 |  |
| Additional paid-in capital |  | 1,590,793 |  | 1,530,046 |  |
| Retained earnings |  | 2,592,854 |  | 2,456,823 |  |
| Accumulated other comprehensive income (loss) |  | (30,501) |  | (8,300) |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 4,153,177 |  |  | 3,978,600 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 6,108,186 |  |  | $ | 5,734,429 |  |

[0001596532-22-000111:8k_2_02:51]
6

[0001596532-22-000111:8k_2_02:52]
ARISTA NETWORKS, INC.

[0001596532-22-000111:8k_2_02:53]
Condensed Consolidated Statements of Cash Flows

[0001596532-22-000111:8k_2_02:54]
(Unaudited, in thousands)

[0001596532-22-000111:8k_2_02:55]
|  |  | Three Months Ended |
|  |  | 2022 |  | 2021 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 272,259 |  |  | $ | 180,366 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 13,091 |  |  | 12,658 |  |
| Stock-based compensation |  | 50,279 |  |  | 37,553 |  |
| Noncash lease expense |  | 4,532 |  |  | 4,243 |  |
| Deferred income taxes |  | (81,822) |  |  | 1,425 |  |
| Unrealized gain on equity investments |  | (28,497) |  |  | — |  |
| Amortization of investment premiums |  | 7,033 |  |  | 5,446 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (131,861) |  |  | 9,074 |  |
| Inventories |  | (43,531) |  |  | (3,500) |  |
| Prepaid expenses and other current assets |  | (107,999) |  |  | (15,272) |  |
| Other assets |  | (640) |  |  | (3,499) |  |
| Accounts payable |  | 2,478 |  |  | 2,833 |  |
| Accrued liabilities |  | (29,666) |  |  | (20,759) |  |
| Deferred revenue |  | 187,194 |  |  | 69,204 |  |
| Income taxes payable |  | 106,992 |  |  | (10,436) |  |
| Other liabilities |  | (2,704) |  |  | (14,661) |  |
| Net cash provided by operating activities |  | 217,138 |  |  | 254,675 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 404,176 |  |  | 379,605 |  |
| Purchases of marketable securities |  | (412,614) |  |  | (590,476) |  |
| Business acquisitions, net of cash acquired |  | (37,610) |  |  | 18 |  |
| Purchases of property and equipment |  | (14,876) |  |  | (5,096) |  |
| Purchases of investments in privately-held companies |  | (11,691) |  |  | (2,000) |  |
| Net cash used in investing activities |  | (72,615) |  |  | (217,949) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 19,160 |  |  | 18,081 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (12,741) |  |  | (2,496) |  |
| Repurchase of common stock |  | (136,228) |  |  | (101,355) |  |
| Net cash used in financing activities |  | (129,809) |  |  | (85,770) |  |
| Effect of exchange rate changes |  | (481) |  |  | (838) |  |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 14,233 |  |  | (49,882) |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 625,050 |  |  | 897,454 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 639,283 |  |  | $ | 847,572 |  |
