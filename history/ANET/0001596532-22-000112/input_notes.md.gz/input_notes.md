# ANET notes — 0001596532-22-000112


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-22-000112:notes:1]
[same as prior period, unchanged from 0001596532-21-000354:notes:1]

[0001596532-22-000112:notes:2]
[same as prior period, unchanged from 0001596532-21-000354:notes:2]

[0001596532-22-000112:notes:3]
[same as prior period, unchanged from 0001596532-21-000354:notes:3]

[0001596532-22-000112:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments of a normal recurring nature necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2022, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2021 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

[0001596532-22-000112:notes:5]
Our condensed consolidated financial statements and related financial information in this Quarterly Report on Form 10-Q should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2021, filed with the SEC on February 15, 2022.

[0001596532-22-000112:notes:6]
[same as prior period, unchanged from 0001596532-21-000354:notes:6]

[0001596532-22-000112:notes:7]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, valuation of inventory and contract manufacturer/supplier liabilities, accounting for income taxes, including the recognition of deferred tax assets and liabilities, valuation allowance on deferred tax assets and reserves for uncertain tax positions, revenue recognition and deferred revenue, allowance for doubtful accounts, sales rebates and return reserves, valuation of goodwill and acquisition-related intangible assets, estimate of useful lives of long-lived assets including intangible assets, and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust these estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from these estimates.

[0001596532-22-000112:notes:8]
[same as prior period, unchanged from 0001596532-21-000354:notes:8]

[0001596532-22-000112:notes:9]
The global coronavirus ("COVID-19") pandemic as well as the Russian-Ukrainian conflict continue to evolve and have widespread and unpredictable impacts on the global economy and business activities.

[0001596532-22-000112:notes:10]
Our contract manufacturers and suppliers have experienced workforce disruptions, delays in component sourcing, production and export of their products as well as component shortages and increased component costs, which have disrupted our supply chain and has impacted and will likely continue to impact our ability to supply products to our customers on a timely basis. While we have experienced improvements in overall demand from customers in recent quarters, we believe ongoing supply disruptions combined with other supply chain related constraints, could impact our ability to fulfill this increased demand and as a result could negatively impact our business in future periods. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and may negatively impact our gross margin. Although the overall economy continues to recover, several issues including inflation risk, supply chain bottlenecks, and COVID-19 variants have and may continue to impact the pace of the recovery.  The extent of the impact on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, the impact to our customers, partners, employees, contract manufacturers and supply chain, as well as restrictions on travel and transport, all of which continue to evolve and are unpredictable. Management

[0001596532-22-000112:notes:11]
continues to actively monitor the impact of the pandemic on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which the COVID-19 pandemic may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

[0001596532-22-000112:notes:12]
Recently Adopted Accounting Pronouncements

[0001596532-22-000112:notes:13]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. ASU 2021-08 requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC 606. Under current GAAP, an acquirer generally recognizes assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 results in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption impact was immaterial to the condensed consolidated financial statements. The standard will not impact acquired contract assets or liabilities from business combinations occurring prior to the adoption date.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-22-000112:notes:14]
Fair Value Measurements 
Assets measured at fair values on a recurring basis

[0001596532-22-000112:notes:15]
We measure and report our cash equivalents, restricted cash, marketable equity securities and available-for-sale debt securities at fair value on a recurring basis. The following tables summarize the fair value of these financial assets by significant investment category and their levels within the fair value hierarchy (in thousands):

[0001596532-22-000112:notes:16]
|  |  | As of March 31, 2022 |  | As of December 31, 2021 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 201,922 |  |  | $ | — |  |  | $ | — |  |  | $ | 201,922 |  |  | $ | 221,382 |  |  | $ | — |  |  | $ | — |  |  | $ | 221,382 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 95,239 |  |  | — |  |  | 95,239 |  |  | — |  |  | 141,274 |  |  | — |  |  | 141,274 |  |
| Certificate of deposits(1) |  | — |  |  | 37,330 |  |  | — |  |  | 37,330 |  |  | — |  |  | 44,931 |  |  | — |  |  | 44,931 |  |
| U.S. government notes |  | 1,093,921 |  |  | — |  |  | — |  |  | 1,093,921 |  |  | 1,057,810 |  |  | — |  |  | — |  |  | 1,057,810 |  |
| Corporate bonds |  | — |  |  | 1,265,406 |  |  | — |  |  | 1,265,406 |  |  | — |  |  | 1,252,226 |  |  | — |  |  | 1,252,226 |  |
| Agency securities |  | — |  |  | 275,182 |  |  | — |  |  | 275,182 |  |  | — |  |  | 291,261 |  |  | — |  |  | 291,261 |  |
| Marketable equity securities(2) |  | 21,811 |  |  | — |  |  | — |  |  | 21,811 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | 1,115,732 |  |  | 1,673,157 |  |  | — |  |  | 2,788,889 |  |  | 1,057,810 |  |  | 1,729,692 |  |  | — |  |  | 2,787,502 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,258 |  |  | — |  |  | — |  |  | 4,258 |  |  | 4,237 |  |  | — |  |  | — |  |  | 4,237 |  |
| Total Financial Assets |  | $ | 1,321,912 |  |  | $ | 1,673,157 |  |  | $ | — |  |  | $ | 2,995,069 |  |  | $ | 1,283,429 |  |  | $ | 1,729,692 |  |  | $ | — |  |  | $ | 3,013,121 |  |

[0001596532-22-000112:notes:17]
______________________________________

[0001596532-22-000112:notes:18]
(1) As of March 31, 2022 and December 31, 2021, all of our certificates of deposits were domestic deposits.

[0001596532-22-000112:notes:19]
(2) The $21.8 million represents the fair value of marketable equity securities as of March 31, 2022. This amount includes $8.3 million that was reclassified from Investments on our condensed consolidated balance sheet following the commencement of public market trading of the issuer in the current quarter, in addition to unrealized gains of $13.5 million recorded during the current quarter. The unrealized gains are included in Other income, net on the Condensed Consolidated Statements of Operations. Refer to Note 3. Financial Statement Details.

[0001596532-22-000112:notes:20]
During the three months ended on March 31, 2022, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-22-000112:notes:21]
Marketable debt securities

[0001596532-22-000112:notes:22]
The following table summarizes the amortized cost, unrealized gains and losses, and fair value of our debt securities at fair value on a recurring basis (in thousands):

[0001596532-22-000112:notes:23]
|  |  | As of March 31, 2022 |  | As of December 31, 2021 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 95,239 |  |  | $ | — |  |  | $ | — |  |  | $ | 95,239 |  |  | $ | 141,274 |  |  | $ | — |  |  | $ | — |  |  | $ | 141,274 |  |
| U.S. government notes |  | 1,106,454 |  |  | 16 |  |  | (12,549) |  |  | 1,093,921 |  |  | 1,060,716 |  |  | 3 |  |  | (2,909) |  |  | 1,057,810 |  |
| Corporate bonds |  | 1,278,474 |  |  | 20 |  |  | (13,088) |  |  | 1,265,406 |  |  | 1,255,149 |  |  | 105 |  |  | (3,028) |  |  | 1,252,226 |  |
| Agency securities |  | 277,535 |  |  | 2 |  |  | (2,355) |  |  | 275,182 |  |  | 291,558 |  |  | 36 |  |  | (333) |  |  | 291,261 |  |
| Total |  | $ | 2,757,702 |  |  | $ | 38 |  |  | $ | (27,992) |  |  | $ | 2,729,748 |  |  | $ | 2,748,697 |  |  | $ | 144 |  |  | $ | (6,270) |  |  | $ | 2,742,571 |  |

[0001596532-22-000112:notes:24]
We invest in marketable securities that have maximum maturities of two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. We expect to realize the full value of these investments upon maturity and do not expect to sell the debt securities prior to maturity; therefore, we do not consider any of our marketable securities to be impaired as of March 31, 2022. We did not recognize any credit losses or non-credit-related impairments related to our available-for-sale marketable securities for the three months ended March 31, 2022.

[0001596532-22-000112:notes:25]
The following is an analysis of our marketable securities in unrealized loss positions for a period of less than twelve months. As of March 31, 2022, there are no unrealized loss positions with a duration equal to or greater than twelve months (in thousands):

[0001596532-22-000112:notes:26]
|  |  | As of March 31, 2022 |
|  |  | Unrealized Losses within 12 months |
|  |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 1,080,225 |  |  | $ | (12,549) |  |
| Corporate bonds |  | 1,223,546 |  |  | (13,088) |  |
| Agency securities |  | 262,329 |  |  | (2,355) |  |
| Total |  | $ | 2,566,100 |  |  | $ | (27,992) |  |

[0001596532-22-000112:notes:27]
As of March 31, 2022, we had no marketable debt securities with contractual maturities that exceed 24 months. The fair values of marketable debt securities, by remaining contractual maturities, are as follows (in thousands):

[0001596532-22-000112:notes:28]
|  |  | As of March 31, 2022 |
|  |  | Fair Values |
| Due in 1 year or less |  | $ | 1,765,710 |  |
| Due in 1 year through 2 years |  | 964,038 |  |
| Total debt securities |  | $ | 2,729,748 |  |

[0001596532-22-000112:notes:29]
The weighted-average remaining duration of our marketable debt securities is approximately 0.8 years as of March 31, 2022. As we view these marketable debt securities as available to support current operations, we classify marketable debt securities with maturities beyond 12 months as current assets under the caption "Marketable securities" on the condensed consolidated balance sheets.

[0001596532-22-000112:notes:30]
Assets measured at fair value on a non-recurring basis

[0001596532-22-000112:notes:31]
Non-Marketable Equity Securities

[0001596532-22-000112:notes:32]
We have non-marketable equity securities in privately-held companies that do not have readily determinable fair values. These equity securities are included in Investments on the condensed consolidated balance sheets. Their initial cost is adjusted to fair value on a non-recurring basis based on observable price changes from orderly transactions of identical or similar securities of the same issuer, or for impairment. These investments are classified within Level III of the fair value hierarchy as we estimate the value based on valuation methods using the observable transaction price at the transaction date and other significant unobservable inputs, such as volatility, rights, and obligations related to these securities. In addition, the valuation requires management judgment due to the absence of market price and lack of liquidity.

[0001596532-22-000112:notes:33]
We did not record any realized gains or losses for our non-marketable equity securities measured at fair value on a non-recurring basis during the three months ended March 31, 2022 and March 31, 2021. We recorded an unrealized gain of $15.0 million on non-marketable equity securities based on observable price changes from orderly transactions of identical or similar securities of the same issuer in the three months ended March 31, 2022, but did not record any unrealized losses or further unrealized gains in the three months ended March 31, 2022 and March 31, 2021. We evaluate our non-marketable equity securities for impairment at each reporting period via a qualitative assessment with various potential impairment indicators, including, but not limited to, an assessment of a significant adverse change in the economic environment, significant adverse changes in the general market condition of the geographies and industries in which our investees operate, and other publicly available information that affected the value of the its non-marketable equity securities.

[0001596532-22-000112:notes:34]
The following table summarizes the activity related to our non-marketable equity securities as of March 31, 2022 and December 31, 2021 (in thousands):

[0001596532-22-000112:notes:35]
|  |  | March 31, 2022 |  | December 31, 2021 |
| Cost of investments (1) |  | $ | 23,625 |  |  | $ | 14,933 |  |
| Cumulative impairment |  | — |  |  | — |  |
| Cumulative upward adjustment (1) |  | 15,000 |  |  | 5,314 |  |
| Carrying amount of investments |  | $ | 38,625 |  |  | $ | 20,247 |  |

[0001596532-22-000112:notes:36]
(1) During the three months ended March 31, 2022, $3.0 million previously included in the Cost of investments and $5.3 million previously included in the Cumulative upward adjustment, or $8.3 million in aggregate, were reclassified from Investments to Marketable securities on our condensed consolidated balance sheet following the commencement of public market trading of the issuer.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-22-000112:notes:37]
[same as prior period, unchanged from 0001596532-21-000354:notes:23]

[0001596532-22-000112:notes:38]
The reconciliation of cash, cash equivalents and restricted cash reported in the accompanying unaudited condensed consolidated balance sheets to the total of the same such amounts in the accompanying unaudited condensed consolidated statements of cash flows is as follows (in thousands):

[0001596532-22-000112:notes:39]
|  |  | March 31, 2022 |  | December 31, 2021 |
| Cash and cash equivalents |  | $ | 635,025 |  |  | $ | 620,813 |  |
| Restricted cash included in other assets |  | 4,258 |  |  | 4,237 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 639,283 |  |  | $ | 625,050 |  |

[0001596532-22-000112:notes:40]
[same as prior period, unchanged from 0001596532-21-000354:notes:26]

[0001596532-22-000112:notes:41]
[same as prior period, unchanged from 0001596532-21-000354:notes:27]

[0001596532-22-000112:notes:42]
|  |  | March 31, 2022 |  | December 31, 2021 |
| Accounts receivable |  | $ | 652,529 |  |  | $ | 521,597 |  |
| Allowance for doubtful accounts |  | (392) |  |  | (132) |  |
| Product sales rebate and returns reserve |  | (3,531) |  |  | (4,956) |  |
| Accounts receivable, net |  | $ | 648,606 |  |  | $ | 516,509 |  |

[0001596532-22-000112:notes:43]
[same as prior period, unchanged from 0001596532-21-000354:notes:29]

[0001596532-22-000112:notes:44]
[same as prior period, unchanged from 0001596532-21-000354:notes:30]

[0001596532-22-000112:notes:45]
|  |  | March 31, 2022 |  | December 31, 2021 |
| Raw materials |  | $ | 367,811 |  |  | $ | 316,737 |  |
| Finished goods |  | 326,406 |  |  | 333,380 |  |
| Total inventories |  | $ | 694,217 |  |  | $ | 650,117 |  |

[0001596532-22-000112:notes:46]
[same as prior period, unchanged from 0001596532-21-000354:notes:32]

[0001596532-22-000112:notes:47]
[same as prior period, unchanged from 0001596532-21-000354:notes:33]

[0001596532-22-000112:notes:48]
|  |  | March 31, 2022 |  | December 31, 2021 |
| Inventory deposits |  | $ | 95,608 |  |  | $ | 46,311 |  |
| Prepaid income taxes |  | 692 |  |  | 8,977 |  |
| Other current assets |  | 217,363 |  |  | 163,916 |  |
| Other prepaid expenses and deposits |  | 24,774 |  |  | 18,531 |  |
| Total prepaid expenses and other current assets |  | $ | 338,437 |  |  | $ | 237,735 |  |

[0001596532-22-000112:notes:49]
[same as prior period, unchanged from 0001596532-21-000354:notes:35]

[0001596532-22-000112:notes:50]
[same as prior period, unchanged from 0001596532-21-000354:notes:36]

[0001596532-22-000112:notes:51]
|  |  | March 31, 2022 |  | December 31, 2021 |
| Land |  | $ | 40,336 |  |  | $ | 40,145 |  |
| Equipment and machinery |  | 104,096 |  |  | 90,915 |  |
| Computer hardware and software |  | 44,792 |  |  | 44,083 |  |
| Furniture and fixtures |  | 3,638 |  |  | 3,634 |  |
| Leasehold improvements |  | 30,512 |  |  | 30,502 |  |
| Construction-in-process |  | 2,354 |  |  | 2,378 |  |
| Property and equipment, gross |  | 225,728 |  |  | 211,657 |  |
| Less: accumulated depreciation |  | (138,337) |  |  | (133,023) |  |
| Property and equipment, net |  | $ | 87,391 |  |  | $ | 78,634 |  |

[0001596532-22-000112:notes:52]
Depreciation expense was $5.6 million and $4.9 million for the three months ended March 31, 2022 and 2021, respectively.

[0001596532-22-000112:notes:53]
[same as prior period, unchanged from 0001596532-21-000354:notes:39]

[0001596532-22-000112:notes:54]
[same as prior period, unchanged from 0001596532-21-000354:notes:40]

[0001596532-22-000112:notes:55]
|  |  | March 31, 2022 |  | December 31, 2021 |
| Accrued payroll-related costs |  | $ | 47,799 |  |  | $ | 99,571 |  |
| Accrued manufacturing costs |  | 92,197 |  |  | 80,213 |  |
| Accrued product development costs |  | 28,897 |  |  | 22,188 |  |
| Accrued warranty costs |  | 12,325 |  |  | 10,414 |  |
| Other |  | 15,845 |  |  | 14,257 |  |
| Total accrued liabilities |  | $ | 197,063 |  |  | $ | 226,643 |  |

[0001596532-22-000112:notes:56]
[same as prior period, unchanged from 0001596532-21-000354:notes:42]

[0001596532-22-000112:notes:57]
[same as prior period, unchanged from 0001596532-21-000354:notes:43]

[0001596532-22-000112:notes:58]
|  |  | Three Months Ended March 31, |
|  |  | 2022 |  | 2021 |
| Warranty accrual, beginning of period |  | $ | 10,414 |  |  | $ | 9,314 |  |
| Liabilities accrued for warranties issued during the period |  | 4,392 |  |  | 3,456 |  |
| Warranty costs incurred during the period |  | (2,481) |  |  | (2,727) |  |
| Warranty accrual, end of period |  | $ | 12,325 |  |  | $ | 10,043 |  |

[0001596532-22-000112:notes:59]
[same as prior period, unchanged from 0001596532-21-000354:notes:45]

[0001596532-22-000112:notes:60]
[same as prior period, unchanged from 0001596532-21-000354:notes:46]

[0001596532-22-000112:notes:61]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Contract assets, beginning balance |  | $ | 24,388 |  |  | $ | 16,380 |  |  |  |  |  |
| Contract assets, ending balance |  | 14,051 |  |  | 9,762 |  |  |  |  |  |

[0001596532-22-000112:notes:62]
[same as prior period, unchanged from 0001596532-21-000354:notes:48]

[0001596532-22-000112:notes:63]
[same as prior period, unchanged from 0001596532-21-000354:notes:49]

[0001596532-22-000112:notes:64]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Contract liabilities, beginning balance |  | $ | 93,382 |  |  | $ | 85,957 |  |  |  |  |  |
| Less: Revenue recognized from beginning balance |  | (8,248) |  |  | (7,913) |  |  |  |  |  |
| Less: Beginning balance reclassified to deferred revenue |  | (3,837) |  |  | (12,492) |  |  |  |  |  |
| Add: Contract liabilities recognized |  | 17,125 |  |  | 14,913 |  |  |  |  |  |
| Contract liabilities, ending balance |  | $ | 98,422 |  |  | $ | 80,465 |  |  |  |  |  |

[0001596532-22-000112:notes:65]
As of March 31, 2022 and December 31, 2021, $40.8 million and $38.7 million of our contract liabilities, respectively, were included in "Other current liabilities" with the remaining balances in "Other long-term liabilities" on the condensed consolidated balance sheets.

[0001596532-22-000112:notes:66]
[same as prior period, unchanged from 0001596532-21-000354:notes:52]

[0001596532-22-000112:notes:67]
[same as prior period, unchanged from 0001596532-21-000354:notes:53]

[0001596532-22-000112:notes:68]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Deferred revenue, beginning balance |  | $ | 929,312 |  |  | $ | 650,827 |  |  |  |  |  |
| Less: Revenue recognized from beginning balance |  | (128,136) |  |  | (107,442) |  |  |  |  |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 322,570 |  |  | 176,646 |  |  |  |  |  |
| Deferred revenue, ending balance |  | $ | 1,123,746 |  |  | $ | 720,031 |  |  |  |  |  |

[0001596532-22-000112:notes:69]
[same as prior period, unchanged from 0001596532-21-000354:notes:55]

[0001596532-22-000112:notes:70]
Other performance obligations include unbilled contract revenue for services and product that will be recognized in future periods. As of March 31, 2022, other performance obligations of $180.0 million were comprised mainly of unbilled multi-year PCS contract amounts.

[0001596532-22-000112:notes:71]
[same as prior period, unchanged from 0001596532-21-000354:notes:57]

[0001596532-22-000112:notes:72]
Revenue from total remaining performance obligations represents contract liabilities, deferred revenue and other performance obligations. As of March 31, 2022, approximately $1,402.2 million of revenue is expected to be recognized from remaining performance obligations, of which approximately 83% is expected to be recognized over the next two years and approximately 17% is expected to be recognized during the third  to the fifth year.

[0001596532-22-000112:notes:73]
[same as prior period, unchanged from 0001596532-21-000354:notes:59]

[0001596532-22-000112:notes:74]
[same as prior period, unchanged from 0001596532-21-000354:notes:60]

[0001596532-22-000112:notes:75]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Interest income |  | $ | 2,428 |  |  | $ | 2,045 |  |  |  |  |  |
| Unrealized gain on equity investments |  | 28,497 |  |  | — |  |  |  |  |  |
| Other income (expense), net |  | 555 |  |  | (470) |  |  |  |  |  |
| Total |  | $ | 31,480 |  |  | $ | 1,575 |  |  |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-22-000112:notes:76]
Acquisition, Goodwill and Acquisition-Related Intangible Assets
Acquisition and Goodwill

[0001596532-22-000112:notes:77]
In January 2022, we completed an acquisition of a privately-held technology company in the United States for a total consideration of $47.0 million with both cash and common stock. The purchase price included $19.0 million of intangible assets, $28.5 million of goodwill and $0.5 million of net liabilities assumed.

[0001596532-22-000112:notes:78]
The changes in the carrying values of goodwill for the three months ended March 31, 2022 are as follows (in thousands):

[0001596532-22-000112:notes:79]
|  |  | Amount |
| Balance at December 31, 2021 |  | $ | 188,397 |  |
| Additions related to one acquisition |  | 28,518 |  |
| Balance at March 31, 2022 |  | $ | 216,915 |  |

[0001596532-22-000112:notes:80]
Acquisition-Related Intangible Assets

[0001596532-22-000112:notes:81]
The following table presents details of our acquisition-related intangible assets as of March 31, 2022 and December 31, 2021 (in thousands, except for years):

[0001596532-22-000112:notes:82]
|  |  | March 31, 2022 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life(In Years) |
| Developed technology |  | $ | 135,530 |  |  | $ | (59,384) |  |  | $ | 76,146 |  |  | 4.7 |
| Customer relationships |  | 32,920 |  |  | (8,966) |  |  | 23,954 |  |  | 5.5 |
| Trade name |  | 10,190 |  |  | (5,046) |  |  | 5,144 |  |  | 3.4 |
| Others |  | 5,720 |  |  | (5,720) |  |  | — |  |  | 0.0 |
| Total |  | $ | 184,360 |  |  | $ | (79,116) |  |  | $ | 105,244 |  |  | 4.8 |

[0001596532-22-000112:notes:83]
|  |  | December 31, 2021 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life(In Years) |
| Developed technology |  | $ | 124,730 |  |  | $ | (53,663) |  |  | $ | 71,067 |  |  | 4.5 |
| Customer relationships |  | 25,920 |  |  | (7,899) |  |  | 18,021 |  |  | 5.2 |
| Trade name |  | 8,990 |  |  | (4,693) |  |  | 4,297 |  |  | 3.8 |
| Others |  | 5,720 |  |  | (5,550) |  |  | 170 |  |  | 0.1 |
| Total |  | $ | 165,360 |  |  | $ | (71,805) |  |  | $ | 93,555 |  |  | 4.6 |

[0001596532-22-000112:notes:84]
For intangible assets acquired and purchased during the three months ended March 31, 2022, developed technology has a weighted-average useful life of 7.0 years, customer relationships has a weighted-average useful life of 7.0 years, and trade name has a weighted-average useful life of 3.0 years.

[0001596532-22-000112:notes:85]
Amortization expense related to acquisition-related intangible assets was $7.3 million, and $7.4 million for the three months ended March 31, 2022, and 2021, respectively.

[0001596532-22-000112:notes:86]
As of March 31, 2022, future estimated amortization expense related to the acquired-related intangible assets is as follows (in thousands):

[0001596532-22-000112:notes:87]
|  |  | Future Amortization Expense |
| Remainder of 2022 |  | $ | 22,161 |  |
| 2023 |  | 25,724 |  |
| 2024 |  | 19,046 |  |
| 2025 |  | 12,326 |  |
| 2026 |  | 10,280 |  |
| Thereafter |  | 15,707 |  |
| Total |  | $ | 105,244 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-22-000112:notes:88]
Commitments and Contingencies
Purchase Commitments

[0001596532-22-000112:notes:89]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of March 31, 2022, we had non-cancellable purchase commitments of $4,318.9 million, with $2,427.7 million with confirmed receipt dates within 12 months, $850.2 million with confirmed receipt dates greater than 12 months and the remaining $1,041 million with the receipt dates to be confirmed. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-22-000112:notes:90]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $98.4 million and $49.1 million as of March 31, 2022 and December 31, 2021, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the accompanying consolidated balance sheets.

[0001596532-22-000112:notes:91]
Guarantees

[0001596532-22-000112:notes:92]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-22-000112:notes:93]
Legal Proceedings

[0001596532-22-000112:notes:94]
WSOU Investments, LLC

[0001596532-22-000112:notes:95]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California; trial has been set for October 23, 2023.  On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement.

[0001596532-22-000112:notes:96]
We intend to vigorously defend against the claims brought against us by WSOU. However, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-22-000112:notes:97]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated. However, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-22-000112:notes:98]
Other matters

[0001596532-22-000112:notes:99]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. 
    We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2022, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001596532-22-000112:notes:100]
Stockholders’ Equity and Stock-Based Compensation
Stock Repurchase Program

[0001596532-22-000112:notes:101]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the "Repurchase Program").  This authorization allowed us to repurchase shares of our common stock over three years, and we completed our repurchases under the Repurchase Program during the fourth quarter of 2021. In the fourth quarter of 2021, our board of directors authorized an additional $1.0 billion stock repurchase program (the “New Repurchase Program”), which allows us to repurchase shares of our common stock to be funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Exchange Act, or a combination of the foregoing. The New Repurchase Program commenced in November 2021 and expires on the three year anniversary thereof. The New Repurchase Program does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of March 31, 2022, the remaining authorized amount for stock repurchases under this program was approximately $790.8 million.

[0001596532-22-000112:notes:102]
A summary of the stock repurchase activity under the New Repurchase Program is as follows (in thousands, except per share amounts):

[0001596532-22-000112:notes:103]
|  |  | Three Months Ended |  |  |  |  |
|  |  | March 31, 2022 |  |  |  |  |
| Aggregate purchase price |  | $ | 136,228 |  |  |  |  |  |
| Shares repurchased |  | 1,171 |  |  |  |  |  |
| Average price paid per share |  | $ | 116.30 |  |  |  |  |  |

[0001596532-22-000112:notes:104]
The aggregate purchase price of repurchased shares of our common stock is recorded as a reduction to retained earnings. All shares repurchased have been retired.

[0001596532-22-000112:notes:105]
Equity Award Plan Activities

[0001596532-22-000112:notes:106]
2014 Equity Incentive Plan

[0001596532-22-000112:notes:107]
In April 2014, our board of directors and stockholders approved the 2014 Equity Incentive Plan (the “2014 Plan”), effective on the first day that our common stock was publicly traded, and simultaneously terminated the 2004 and 2011 equity plans as to future grants. However, these plans will continue to govern the terms and conditions of the outstanding options previously granted thereunder.

[0001596532-22-000112:notes:108]
Awards granted under the 2014 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Units (“RSUs”), Restricted Stock Awards (“RSAs”) or Stock Appreciation Rights (“SARs”).  The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of the outstanding shares of our common stock on the immediately preceding December 31, but not exceed 50,000,000 shares (the “2014 Plan Evergreen Increase”), unless our board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2022, our board of directors authorized an increase of 9,230,434 shares to the shares available for issuance under the 2014 Plan. As of March 31, 2022, there remained approximately 95.7 million shares available for issuance under the 2014 Plan.

[0001596532-22-000112:notes:109]
2014 Employee Stock Purchase Plan

[0001596532-22-000112:notes:110]
In April 2014, our board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding immediately preceding December 31, but not to exceed 10,000,000 shares, unless our board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2022, our board of directors authorized an increase of 3,076,811 shares to the shares available for issuance under our 2014 Employee Stock Purchase Plan (the “ESPP”). During the three months ended March 31, 2022, we issued 240,394 shares at a weighted-average purchase price of $48.75 per share under the ESPP. As of March 31, 2022, there remained 20.8 million shares available for issuance under the ESPP.

[0001596532-22-000112:notes:111]
Stock Option Activities

[0001596532-22-000112:notes:112]
The following table summarizes the option activity under our stock plans and related information (in thousands, except years and per share amounts):

[0001596532-22-000112:notes:113]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) |  | Aggregate Intrinsic Value of Stock Options Outstanding |
| Balance—December 31, 2021 |  | 8,685 |  |  | $ | 12.45 |  |  | 2.8 |  | $ | 1,140,369 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (737) |  |  | 10.09 |  |  |  |  |  |
| Options canceled |  | (121) |  |  | 18.11 |  |  |  |  |  |
| Balance—March 31, 2022 |  | 7,827 |  |  | $ | 12.58 |  |  | 2.6 |  | $ | 989,294 |  |
| Vested and exercisable—March 31, 2022 |  | 6,304 |  |  | $ | 10.07 |  |  | 2.2 |  | $ | 812,692 |  |

[0001596532-22-000112:notes:114]
Restricted Stock Unit (RSU) Activities

[0001596532-22-000112:notes:115]
A summary of the RSU activity is presented below (in thousands, except years and per share amounts):

[0001596532-22-000112:notes:116]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2021 |  | 7,821 |  |  | $ | 70.98 |  |  | 1.7 |  | $ | 1,124,229 |  |
| RSUs granted |  | 758 |  |  | 107.79 |  |  |  |  |  |
| RSUs vested |  | (742) |  |  | 64.21 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (108) |  |  | 70.81 |  |  |  |  |  |
| Unvested balance—March 31, 2022 |  | 7,729 |  |  | $ | 75.24 |  |  | 1.6 |  | $ | 1,074,204 |  |

[0001596532-22-000112:notes:117]
Stock-Based Compensation Expense

[0001596532-22-000112:notes:118]
The following table summarizes the stock-based compensation expense related to our equity awards (in thousands):

[0001596532-22-000112:notes:119]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Cost of revenue |  | $ | 1,309 |  |  | $ | 1,400 |  |  |  |  |  |
| Research and development |  | 27,576 |  |  | 21,982 |  |  |  |  |  |
| Sales and marketing |  | 13,109 |  |  | 10,085 |  |  |  |  |  |
| General and administrative |  | 8,285 |  |  | 4,086 |  |  |  |  |  |
| Total stock-based compensation |  | $ | 50,279 |  |  | $ | 37,553 |  |  |  |  |  |

[0001596532-22-000112:notes:120]
As of March 31, 2022, there were $501.4 million of unamortized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 3.2 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-22-000112:notes:121]
[same as prior period, unchanged from 0001596532-21-000354:notes:102]

[0001596532-22-000112:notes:122]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2022 |  | 2021 (1) |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 272,259 |  |  | $ | 180,366 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share, basic |  | 308,045 |  |  | 305,224 |  |  |  |  |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Stock options and RSUs |  | 11,322 |  |  | 13,116 |  |  |  |  |  |
| Employee stock purchase plan |  | 285 |  |  | 152 |  |  |  |  |  |
| Weighted-average shares used in computing net income per share, diluted |  | 319,652 |  |  | 318,492 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.88 |  |  | $ | 0.59 |  |  |  |  |  |
| Diluted |  | $ | 0.85 |  |  | $ | 0.57 |  |  |  |  |  |

[0001596532-22-000112:notes:123]
(1) Prior periods have been adjusted to reflect the four-for-one stock split effected in the form of a stock dividend in November 2021.

[0001596532-22-000112:notes:124]
[same as prior period, unchanged from 0001596532-21-000354:notes:104]

[0001596532-22-000112:notes:125]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2022 |  | 2021 (1) |  |  |  |  |
| Stock options and RSUs |  | 64 |  |  | 520 |  |  |  |  |  |
| Employee stock purchase plan |  | 16 |  |  | 40 |  |  |  |  |  |
| Total |  | 80 |  |  | 560 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-22-000112:notes:126]
Income Taxes

[0001596532-22-000112:notes:127]
|  |  | Three Months Ended March 31, |  |  |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
|  |  | (in thousands, except percentages) |  |  |  |  |
| Income before income taxes |  | $ | 309,467 |  |  | $ | 207,867 |  |  |  |  |  |
| Provision for income taxes |  | 37,208 |  |  | 27,501 |  |  |  |  |  |
| Effective tax rate |  | 12.0 | % |  | 13.2 | % |  |  |  |  |

[0001596532-22-000112:notes:128]
The effective tax rates above reflect tax expense recorded on pre-tax income in the three months ended March 31, 2022 and March 31, 2021. The change in effective tax rate in the three months ended March 31, 2022, as compared to the same period in 2021, was primarily due to a favorable change in jurisdictional mix in earnings.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-22-000112:notes:129]
Geographical Information 
    We operate as one reportable segment. The following table represents revenue based on customers’ shipping addresses (in thousands):

[0001596532-22-000112:notes:130]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Americas |  | $ | 664,377 |  |  | $ | 501,872 |  |  |  |  |  |
| Europe, Middle East and Africa |  | 134,805 |  |  | 96,274 |  |  |  |  |  |
| Asia-Pacific |  | 77,884 |  |  | 69,416 |  |  |  |  |  |
| Total revenue |  | $ | 877,066 |  |  | $ | 667,562 |  |  |  |  |  |

[0001596532-22-000112:notes:131]
Long-lived assets, excluding intercompany receivables, investments in subsidiaries, privately-held equity investments and deferred tax assets, net by location are summarized as follows (in thousands):

[0001596532-22-000112:notes:132]
|  |  | March 31, 2022 |  | December 31, 2021 |
| United States |  | $ | 68,252 |  |  | $ | 62,163 |  |
| International |  | 19,139 |  |  | 16,471 |  |
| Total |  | $ | 87,391 |  |  | $ | 78,634 |  |
