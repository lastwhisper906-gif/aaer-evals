# ANET 8-K — 0001596532-20-000225 filed 2020-11-02

## item codes, every 8-K on or before 2020-11-03

- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2020-11-03

- none on or before 2020-11-03

## item 2.02 — earnings release, exhibit 99.1

[0001596532-20-000225:8k_2_02:1]
EX-99.1
2
ex991q320-earningsrele.htm
EX-99.1

[0001596532-20-000225:8k_2_02:2]
Document

[0001596532-20-000225:8k_2_02:3]
Exhibit 99.1

[0001596532-20-000225:8k_2_02:4]
Arista Networks, Inc. Reports Third Quarter 2020 Financial Results

[0001596532-20-000225:8k_2_02:5]
SANTA CLARA, Calif.- November 2, 2020 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in cognitive cloud networking for large datacenter and campus environments, today announced financial results for its third quarter ended September 30, 2020.

[0001596532-20-000225:8k_2_02:6]
Third Quarter Financial Highlights

[0001596532-20-000225:8k_2_02:7]
•Revenue of $605.4 million, an increase of 12.0% compared to the second quarter of 2020, and a decrease of 7.5% from the third quarter of 2019.

[0001596532-20-000225:8k_2_02:8]
•GAAP gross margin of 63.6%, compared to GAAP gross margin of 63.7% in the second quarter of 2020 and 63.8% in the third quarter of 2019.

[0001596532-20-000225:8k_2_02:9]
•Non-GAAP gross margin of 64.6%, compared to non-GAAP gross margin of 64.7% in the second quarter of 2020 and 64.4% in the third quarter of 2019.

[0001596532-20-000225:8k_2_02:10]
•GAAP net income of $168.4 million, or $2.12 per diluted share, compared to GAAP net income of $208.9 million, or $2.59 per diluted share in the third quarter of 2019.

[0001596532-20-000225:8k_2_02:11]
•Non-GAAP net income of $192.0 million, or $2.42 per diluted share, compared to non-GAAP net income of $217.1 million, or $2.69 per diluted share in the third quarter of 2019.

[0001596532-20-000225:8k_2_02:12]
"Our customers are validating our traction as we migrate from legacy to cognitive client to cloud deployments with a cumulative of 40 million cloud networking ports shipped by Q3 2020. Despite some COVID-19 turbulence, we believe Arista will only emerge stronger," stated Jayshree Ullal, President and CEO of Arista Networks.

[0001596532-20-000225:8k_2_02:13]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, “We saw continued improvement in underlying business trends in the quarter, with the Arista team working diligently with customers, supply chain and other partners to navigate the new COVID-19 operating environment.”

[0001596532-20-000225:8k_2_02:14]
Third Quarter Company Highlights

[0001596532-20-000225:8k_2_02:15]
•Arista Networks acquired Awake Security, a Network Detection and Response (NDR) platform provider that combines artificial intelligence (AI) with human expertise to autonomously hunt and respond to insider and external threats. The acquisition closed in October, 2020.

[0001596532-20-000225:8k_2_02:16]
•Arista expanded its cognitive campus portfolio with new platforms, including the 750 Series modular chassis (the first 100G ready, high density modular PoE switches), and the 720 Series 96 port fixed switch.

[0001596532-20-000225:8k_2_02:17]
•Arista announced unified edge innovations across wired and wireless networks for its Cognitive Campus Edge portfolio for Enterprise Workspaces.

[0001596532-20-000225:8k_2_02:18]
•Arista introduced a new enterprise-grade Software-as-a-Service (SaaS) offering for the flagship CloudVision® platform. Arista’s new CloudVision as-a-Service product is now available as a fully managed software.

[0001596532-20-000225:8k_2_02:19]
•Arista announced several additions to its multi-cloud and cloud-native software product family with CloudEOS Edge which is designed to integrate with native cloud networking services like Amazon Web Services Transit Gateway, with native interoperability using provisioning tools like Hashicorp Terraform and Red Hat’s Ansible.

[0001596532-20-000225:8k_2_02:20]
Financial Outlook

[0001596532-20-000225:8k_2_02:21]
For the fourth quarter of 2020, we expect:

[0001596532-20-000225:8k_2_02:22]
•Revenue between $615 million to $635 million;

[0001596532-20-000225:8k_2_02:23]
•Non-GAAP gross margin of 63% to 65%; and

[0001596532-20-000225:8k_2_02:24]
•Non-GAAP operating margin of approximately 37%

[0001596532-20-000225:8k_2_02:25]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and certain non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below under “Non-GAAP Financial Measures”).

[0001596532-20-000225:8k_2_02:26]
Prepared Materials and Conference Call Information

[0001596532-20-000225:8k_2_02:27]
Arista executives will discuss the third quarter financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (833) 968-2211 in the United States or +1 (778) 560-2896 from international locations. The Conference ID is 1469655.

[0001596532-20-000225:8k_2_02:28]
The financial results conference call will also be available via live webcast on our investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-20-000225:8k_2_02:29]
Forward-Looking Statements

[0001596532-20-000225:8k_2_02:30]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the fourth quarter of fiscal year 2020, statements regarding the benefits of the introduction of new products and our leadership in cloud networking and statements regarding our recent acquisition of Awake Security. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: the impact of the COVID-19 pandemic on our business, including as a result of continued volatility in the financial markets and global economy or disruption in our supply chain, the evolution and growth of the cloud networking market and other markets in which we compete and the adoption by end customers of our solutions; adverse economic conditions or reduced information technology and network infrastructure spending; rapid technological and market change; Arista’s customer concentration; our ability to attract new large end customers or sell additional products and services to existing customers; competition in our products and services markets; changes in Arista’s customers’ demand for our products and services; changes in customer order patterns or customer mix; requests by large end customers for more favorable terms and conditions; general market, political, economic and business conditions such as the recent U.S. trade wars with China and the impact of public health pandemics like the COVID-19 pandemic; our ability to pursue and manage, and our dependence on, the introduction and market acceptance of new product offerings and standards including our 400G products as well as our campus, WiFi and security products; declines in the sales prices of our products and services; the timing of orders and manufacturing and customer lead times; the benefits and impact of acquisitions; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent Quarterly Report on Form 10-Q filed with the SEC on August 5, 2020, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-20-000225:8k_2_02:31]
Non-GAAP Financial Measures

[0001596532-20-000225:8k_2_02:32]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangible assets, certain non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-20-000225:8k_2_02:33]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-20-000225:8k_2_02:34]
The company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and certain non-recurring items. The company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. A reconciliation of the non-GAAP financial measures guidance to the corresponding GAAP measures on a forward-looking basis is not available because stock-based compensation expense is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-20-000225:8k_2_02:35]
About Arista Networks

[0001596532-20-000225:8k_2_02:36]
Arista Networks is an industry leader in software-driven cloud networking solutions for large data center and campus environments. Arista’s award-winning platforms deliver availability, agility, automation analytics and security through CloudVision® and Arista EOS®, an advanced network operating system. For more information visit www.arista.com.

[0001596532-20-000225:8k_2_02:37]
Investor Contacts:

[0001596532-20-000225:8k_2_02:38]
Arista Networks, Inc.

[0001596532-20-000225:8k_2_02:39]
Charles Yager, 408-547-5892

[0001596532-20-000225:8k_2_02:40]
Product and Investor Advocacy

[0001596532-20-000225:8k_2_02:41]
cyager@arista.com

[0001596532-20-000225:8k_2_02:42]
or

[0001596532-20-000225:8k_2_02:43]
Curtis McKee, 408-547-5549

[0001596532-20-000225:8k_2_02:44]
Corporate and Investor Development

[0001596532-20-000225:8k_2_02:45]
curtism@arista.com

[0001596532-20-000225:8k_2_02:46]
ARISTA NETWORKS, INC.

[0001596532-20-000225:8k_2_02:47]
Condensed Consolidated Statements of Operations

[0001596532-20-000225:8k_2_02:48]
(Unaudited, in thousands, except per share amounts)

[0001596532-20-000225:8k_2_02:49]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 480,242 |  |  | $ | 555,066 |  |  | $ | 1,312,561 |  |  | $ | 1,573,652 |  |
| Service |  | 125,189 |  |  | 99,349 |  |  | 356,469 |  |  | 284,508 |  |
| Total revenue |  | 605,431 |  |  | 654,415 |  |  | 1,669,030 |  |  | 1,858,160 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 199,465 |  |  | 218,220 |  |  | 539,526 |  |  | 616,906 |  |
| Service |  | 21,004 |  |  | 18,921 |  |  | 62,202 |  |  | 53,219 |  |
| Total cost of revenue |  | 220,469 |  |  | 237,141 |  |  | 601,728 |  |  | 670,125 |  |
| Gross profit |  | 384,962 |  |  | 417,274 |  |  | 1,067,302 |  |  | 1,188,035 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 128,049 |  |  | 118,732 |  |  | 352,747 |  |  | 352,696 |  |
| Sales and marketing |  | 53,372 |  |  | 55,279 |  |  | 161,695 |  |  | 159,372 |  |
| General and administrative |  | 15,146 |  |  | 14,657 |  |  | 47,814 |  |  | 46,182 |  |
| Total operating expenses |  | 196,567 |  |  | 188,668 |  |  | 562,256 |  |  | 558,250 |  |
| Income from operations |  | 188,395 |  |  | 228,606 |  |  | 505,046 |  |  | 629,785 |  |
| Other income, net |  | 13,224 |  |  | 19,169 |  |  | 33,637 |  |  | 45,313 |  |
| Income before income taxes |  | 201,619 |  |  | 247,775 |  |  | 538,683 |  |  | 675,098 |  |
| Provision for income taxes |  | 33,244 |  |  | 38,880 |  |  | 87,084 |  |  | 75,923 |  |
| Net income |  | $ | 168,375 |  |  | $ | 208,895 |  |  | $ | 451,599 |  |  | $ | 599,175 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 168,375 |  |  | $ | 208,799 |  |  | $ | 451,599 |  |  | $ | 598,861 |  |
| Diluted |  | $ | 168,375 |  |  | $ | 208,804 |  |  | $ | 451,599 |  |  | $ | 598,880 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.22 |  |  | $ | 2.73 |  |  | $ | 5.94 |  |  | $ | 7.85 |  |
| Diluted |  | $ | 2.12 |  |  | $ | 2.59 |  |  | $ | 5.68 |  |  | $ | 7.38 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | 75,999 |  |  | 76,426 |  |  | 76,024 |  |  | 76,301 |  |
| Diluted |  | 79,313 |  |  | 80,753 |  |  | 79,519 |  |  | 81,104 |  |

[0001596532-20-000225:8k_2_02:50]
4

[0001596532-20-000225:8k_2_02:51]
ARISTA NETWORKS, INC.

[0001596532-20-000225:8k_2_02:52]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-20-000225:8k_2_02:53]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-20-000225:8k_2_02:54]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| GAAP gross profit |  | $ | 384,962 |  |  | $ | 417,274 |  |  | $ | 1,067,302 |  |  | $ | 1,188,035 |  |
| GAAP gross margin |  | 63.6 | % |  | 63.8 | % |  | 63.9 | % |  | 63.9 | % |
| Stock-based compensation expense |  | 1,806 |  |  | 1,258 |  |  | 4,718 |  |  | 3,384 |  |
| Intangible asset amortization |  | 4,178 |  |  | 2,626 |  |  | 12,016 |  |  | 7,877 |  |
| Non-GAAP gross profit |  | $ | 390,946 |  |  | $ | 421,158 |  |  | $ | 1,084,036 |  |  | $ | 1,199,296 |  |
| Non-GAAP gross margin |  | 64.6 | % |  | 64.4 | % |  | 65.0 | % |  | 64.5 | % |
| GAAP income from operations |  | $ | 188,395 |  |  | $ | 228,606 |  |  | $ | 505,046 |  |  | $ | 629,785 |  |
| Stock-based compensation expense |  | 36,469 |  |  | 26,257 |  |  | 96,947 |  |  | 74,845 |  |
| Litigation expense |  | — |  |  | — |  |  | — |  |  | 1,962 |  |
| Intangible asset amortization |  | 5,811 |  |  | 3,293 |  |  | 16,524 |  |  | 10,291 |  |
| Acquisition-related costs |  | 858 |  |  | — |  |  | 12,718 |  |  | — |  |
| Non-GAAP income from operations |  | $ | 231,533 |  |  | $ | 258,156 |  |  | $ | 631,235 |  |  | $ | 716,883 |  |
| Non-GAAP operating margin |  | 38.2 | % |  | 39.4 | % |  | 37.8 | % |  | 38.6 | % |
| GAAP net income |  | $ | 168,375 |  |  | $ | 208,895 |  |  | $ | 451,599 |  |  | $ | 599,175 |  |
| Stock-based compensation expense |  | 36,469 |  |  | 26,257 |  |  | 96,947 |  |  | 74,845 |  |
| Litigation expense |  | — |  |  | — |  |  | — |  |  | 1,962 |  |
| Intangible asset amortization |  | 5,811 |  |  | 3,293 |  |  | 16,524 |  |  | 10,291 |  |
| Acquisition-related costs (1) |  | 858 |  |  | — |  |  | 12,718 |  |  | — |  |
| Altera stock-based tax charge (2) |  | — |  |  | — |  |  | — |  |  | 9,781 |  |
| Gain on investment in privately-held companies |  | — |  |  | (4,277) |  |  | — |  |  | (5,427) |  |
| Tax benefit on stock-based awards |  | (14,894) |  |  | (12,674) |  |  | (41,078) |  |  | (73,183) |  |
| Income tax effect on non-GAAP exclusions |  | (4,624) |  |  | (4,391) |  |  | (15,975) |  |  | (14,048) |  |
| Non-GAAP net income |  | $ | 191,995 |  |  | $ | 217,103 |  |  | $ | 520,735 |  |  | $ | 603,396 |  |
| GAAP diluted net income per share attributable to common stockholders |  | $ | 2.12 |  |  | $ | 2.59 |  |  | $ | 5.68 |  |  | $ | 7.38 |  |
| Non-GAAP adjustments to net income |  | 0.30 |  |  | 0.10 |  |  | 0.87 |  |  | 0.06 |  |
| Non-GAAP diluted net income per share |  | $ | 2.42 |  |  | $ | 2.69 |  |  | $ | 6.55 |  |  | $ | 7.44 |  |
| Weighted-average shares used in computing diluted net income per share attributable to common stockholders |  | 79,313 |  |  | 80,753 |  |  | 79,519 |  |  | 81,104 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,806 |  |  | $ | 1,258 |  |  | $ | 4,718 |  |  | $ | 3,384 |  |
| Research and development |  | 21,423 |  |  | 13,472 |  |  | 56,729 |  |  | 39,171 |  |
| Sales and marketing |  | 9,083 |  |  | 7,832 |  |  | 23,756 |  |  | 21,463 |  |
| General and administrative |  | 4,157 |  |  | 3,695 |  |  | 11,744 |  |  | 10,827 |  |
| Total |  | $ | 36,469 |  |  | $ | 26,257 |  |  | $ | 96,947 |  |  | $ | 74,845 |  |

[0001596532-20-000225:8k_2_02:55]
___________________

[0001596532-20-000225:8k_2_02:56]
(1) Represents non-recurring costs associated with our acquisitions, which primarily include retention bonuses, professional and consulting fees, and restructuring costs.

[0001596532-20-000225:8k_2_02:57]
(2) Represents a discrete income tax expense related to stock-based compensation as a result of an opinion on Altera Corporation and Subsidiaries vs. Commissioner on Internal Revenue issued by the Court of Appeals for the Ninth Circuit on June 7, 2019.

[0001596532-20-000225:8k_2_02:58]
ARISTA NETWORKS, INC.

[0001596532-20-000225:8k_2_02:59]
Condensed Consolidated Balance Sheets

[0001596532-20-000225:8k_2_02:60]
(Unaudited, in thousands)

[0001596532-20-000225:8k_2_02:61]
|  |  | September 30, 2020 |  | December 31, 2019 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 970,349 |  |  | $ | 1,111,286 |  |
| Marketable securities |  | 1,875,552 |  |  | 1,613,082 |  |
| Accounts receivable |  | 300,217 |  |  | 391,987 |  |
| Inventories |  | 438,102 |  |  | 243,825 |  |
| Prepaid expenses and other current assets |  | 69,647 |  |  | 111,456 |  |
| Total current assets |  | 3,653,867 |  |  | 3,471,636 |  |
| Property and equipment, net |  | 32,670 |  |  | 39,273 |  |
| Acquisition-related intangible assets, net |  | 77,752 |  |  | 45,235 |  |
| Goodwill |  | 84,968 |  |  | 54,855 |  |
| Investments |  | 4,150 |  |  | 4,150 |  |
| Operating lease right-of-use assets |  | 79,929 |  |  | 87,770 |  |
| Deferred tax assets |  | 443,229 |  |  | 452,025 |  |
| Other assets |  | 22,807 |  |  | 30,346 |  |
| TOTAL ASSETS |  | $ | 4,399,372 |  |  | $ | 4,185,290 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 163,102 |  |  | $ | 92,105 |  |
| Accrued liabilities |  | 110,348 |  |  | 140,249 |  |
| Deferred revenue |  | 321,290 |  |  | 312,668 |  |
| Other current liabilities |  | 70,043 |  |  | 52,052 |  |
| Total current liabilities |  | 664,783 |  |  | 597,074 |  |
| Income taxes payable |  | 47,918 |  |  | 55,485 |  |
| Operating lease liabilities, non-current |  | 74,903 |  |  | 83,022 |  |
| Deferred revenue, non-current |  | 241,014 |  |  | 262,620 |  |
| Deferred tax liabilities, non-current |  | 247,712 |  |  | 254,710 |  |
| Other long-term liabilities |  | 39,165 |  |  | 37,693 |  |
| TOTAL LIABILITIES |  | 1,315,495 |  |  | 1,290,604 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 8 |  |  | 8 |  |
| Additional paid-in capital |  | 1,240,147 |  |  | 1,106,305 |  |
| Retained earnings |  | 1,844,656 |  |  | 1,788,230 |  |
| Accumulated other comprehensive income (loss) |  | (934) |  |  | 143 |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 3,083,877 |  |  | 2,894,686 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 4,399,372 |  |  | $ | 4,185,290 |  |

[0001596532-20-000225:8k_2_02:62]
6

[0001596532-20-000225:8k_2_02:63]
ARISTA NETWORKS, INC.

[0001596532-20-000225:8k_2_02:64]
Condensed Consolidated Statements of Cash Flows

[0001596532-20-000225:8k_2_02:65]
(Unaudited, in thousands)

[0001596532-20-000225:8k_2_02:66]
|  |  | Nine Months Ended September 30, |
|  |  | 2020 |  | 2019 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 451,599 |  |  | $ | 599,175 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 31,975 |  |  | 24,948 |  |
| Stock-based compensation |  | 96,947 |  |  | 74,845 |  |
| Noncash lease expense |  | 12,606 |  |  | 12,007 |  |
| Deferred income taxes |  | 3,261 |  |  | 10,945 |  |
| Gain on sale of marketable securities |  | (9,432) |  |  | — |  |
| Gain on investment in privately-held companies |  | — |  |  | (5,427) |  |
| Amortization (accretion) of investment premiums (discounts) |  | 6,030 |  |  | (6,032) |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | 98,271 |  |  | (115,475) |  |
| Inventories |  | (193,996) |  |  | 24,951 |  |
| Prepaid expenses and other current assets |  | 38,654 |  |  | 59,388 |  |
| Other assets |  | 7,850 |  |  | (7,009) |  |
| Accounts payable |  | 71,803 |  |  | (14,361) |  |
| Accrued liabilities |  | (29,811) |  |  | 5,731 |  |
| Deferred revenue |  | (34,449) |  |  | (58,216) |  |
| Income taxes payable |  | (1,667) |  |  | 29,808 |  |
| Other liabilities |  | (1,451) |  |  | 595 |  |
| Net cash provided by operating activities |  | 548,190 |  |  | 635,873 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 1,183,601 |  |  | 806,519 |  |
| Purchases of marketable securities |  | (2,216,436) |  |  | (840,098) |  |
| Business acquisitions, net of cash acquired |  | (66,317) |  |  | (1,365) |  |
| Purchases of property and equipment |  | (7,701) |  |  | (13,319) |  |
| Investments in privately-held companies |  | 3,399 |  |  | 28,220 |  |
| Proceeds from sale of marketable securities |  | 772,978 |  |  | — |  |
| Net cash used in investing activities |  | (330,476) |  |  | (20,043) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 42,704 |  |  | 52,177 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (5,932) |  |  | (7,069) |  |
| Repurchase of common stock |  | (395,173) |  |  | (214,617) |  |
| Net cash used in financing activities |  | (358,401) |  |  | (169,509) |  |
| Effect of exchange rate changes |  | (246) |  |  | (994) |  |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | (140,933) |  |  | 445,327 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 1,115,515 |  |  | 654,164 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 974,582 |  |  | $ | 1,099,491 |  |
