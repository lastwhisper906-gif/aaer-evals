# ANET notes — 0001596532-20-000226


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-20-000226:notes:1]
Organization and Summary of Significant Accounting Policies 
Organization

[0001596532-20-000226:notes:2]
[same as prior period, unchanged from 0001596532-20-000148:notes:3]

[0001596532-20-000226:notes:3]
[same as prior period, unchanged from 0001596532-20-000148:notes:4]

[0001596532-20-000226:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2020, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2019 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

[0001596532-20-000226:notes:5]
Our condensed consolidated financial statements and related financial information in this Quarterly Report on Form 10-Q should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2019, filed with the SEC on February 14, 2020.

[0001596532-20-000226:notes:6]
[same as prior period, unchanged from 0001596532-20-000148:notes:7]

[0001596532-20-000226:notes:7]
[same as prior period, unchanged from 0001596532-20-000148:notes:8]

[0001596532-20-000226:notes:8]
[same as prior period, unchanged from 0001596532-20-000148:notes:9]

[0001596532-20-000226:notes:9]
[same as prior period, unchanged from 0001596532-20-000148:notes:10]

[0001596532-20-000226:notes:10]
Our contract manufacturers and suppliers have experienced delays in the production and export of their products, which have negatively impacted our supply chain and could negatively impact our business in the future. In addition, we expect that COVID-19 related disruptions may have a negative impact on demand from our customers in future periods and contribute to an expected year-over-year decline in revenues for the year ending December 31, 2020. However, the extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, including the duration and spread of the pandemic and related mitigation efforts, as well as restrictions on travel and transport, all of which are uncertain and cannot be predicted. Management is actively monitoring the impact of the pandemic on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which the COVID-19 pandemic may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

[0001596532-20-000226:notes:11]
Recently Adopted Accounting Pronouncements

[0001596532-20-000226:notes:12]
[same as prior period, unchanged from 0001596532-20-000148:notes:13]

[0001596532-20-000226:notes:13]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. The standard requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. For trade receivables, we are required to estimate lifetime expected credit losses. For available-for-sale debt securities, we are required to recognize an allowance for credit losses rather than a reduction to the carrying value of the asset. We adopted the new guidance in our first quarter of 2020 under a modified retrospective approach, and there was no material impact to our financial statements upon adoption. In addition, we do not anticipate that it will have a material impact on our consolidated statement of operations or consolidated statements of cash flows going forward.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-20-000226:notes:14]
Business Combinations 
    On February 5, 2020, the Company completed its acquisition of Big Switch Networks, Inc. (“Big Switch”), a network monitoring and software-defined networking pioneer headquartered in Santa Clara, California. With the acquisition of Big Switch, we expect to expand our data center networking solutions and further strengthen our network monitoring and observability suite delivered through Arista’s software platform CloudVision and DANZ (DataANalyZer) capabilities.

[0001596532-20-000226:notes:15]
We paid an aggregate of $73.3 million in cash for the acquisition, of which $5.3 million in severance and other costs was accounted for as post-combination expense and was excluded from the purchase consideration. We also incurred certain acquisition-related expenses and restructuring costs of $6.6 million, which primarily consisted of retention bonuses to continuing employees, professional and consulting fees, and facilities restructuring costs. The following table summarizes the purchase consideration of $68.0 million, and the preliminary purchase price allocation based on the estimated fair value of the assets acquired and liabilities assumed at the acquisition date (in thousands):

[0001596532-20-000226:notes:16]
|  |  | Preliminary Purchase Price Allocation |
| Tangible assets |  | $ | 13,376 |  |
| Liabilities |  | (24,346) |  |
| Intangible assets |  | 49,040 |  |
| Goodwill |  | 29,926 |  |
| Net assets acquired |  | $ | 67,996 |  |

[0001596532-20-000226:notes:17]
[same as prior period, unchanged from 0001596532-20-000148:notes:19]

[0001596532-20-000226:notes:18]
The acquired intangible assets are amortized on a straight-line basis over their estimated useful lives as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. The following table shows the valuation of the intangible assets acquired (in thousands) along with their estimated useful lives:

[0001596532-20-000226:notes:19]
[same as prior period, unchanged from 0001596532-20-000148:notes:21]

[0001596532-20-000226:notes:20]
[same as prior period, unchanged from 0001596532-20-000148:notes:22]


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-20-000226:notes:21]
Fair Value Measurements 
    Assets and liabilities recorded at fair value on a recurring basis on the accompanying condensed consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value. We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs. The three-tiers of the fair value hierarchy are as follows:

[0001596532-20-000226:notes:22]
[same as prior period, unchanged from 0001596532-20-000148:notes:25]

[0001596532-20-000226:notes:23]
[same as prior period, unchanged from 0001596532-20-000148:notes:26]

[0001596532-20-000226:notes:24]
[same as prior period, unchanged from 0001596532-20-000148:notes:27]

[0001596532-20-000226:notes:25]
[same as prior period, unchanged from 0001596532-20-000148:notes:28]

[0001596532-20-000226:notes:26]
|  |  | September 30, 2020 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 478,702 |  |  | $ | — |  |  | $ | — |  |  | $ | 478,702 |  |  | $ | 478,702 |  |  | $ | — |  |  | $ | — |  |
| U.S. Treasuries |  | 73,656 |  |  | — |  |  | — |  |  | 73,656 |  |  | 73,656 |  |  | — |  |  | — |  |
|  |  | 552,358 |  |  | — |  |  | — |  |  | 552,358 |  |  | 552,358 |  |  | — |  |  | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 51,926 |  |  | — |  |  | — |  |  | 51,926 |  |  | — |  |  | 51,926 |  |  | — |  |
| Certificate of deposits(1) |  | 21,218 |  |  | — |  |  | — |  |  | 21,218 |  |  | — |  |  | 21,218 |  |  | — |  |
| U.S. government notes |  | 522,044 |  |  | 412 |  |  | (6) |  |  | 522,450 |  |  | 522,450 |  |  | — |  |  | — |  |
| Corporate bonds |  | 824,132 |  |  | 2,079 |  |  | (401) |  |  | 825,810 |  |  | — |  |  | 825,810 |  |  | — |  |
| Agency securities |  | 453,773 |  |  | 387 |  |  | (12) |  |  | 454,148 |  |  | — |  |  | 454,148 |  |  | — |  |
|  |  | 1,873,093 |  |  | 2,878 |  |  | (419) |  |  | 1,875,552 |  |  | 522,450 |  |  | 1,353,102 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,233 |  |  | — |  |  | — |  |  | 4,233 |  |  | 4,233 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 2,429,684 |  |  | $ | 2,878 |  |  | $ | (419) |  |  | $ | 2,432,143 |  |  | $ | 1,079,041 |  |  | $ | 1,353,102 |  |  | $ | — |  |

[0001596532-20-000226:notes:27]
|  |  | December 31, 2019 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 562,580 |  |  | $ | — |  |  | $ | — |  |  | $ | 562,580 |  |  | $ | 562,580 |  |  | $ | — |  |  | $ | — |  |
| Certificate of deposits(1) |  | 4,001 |  |  | — |  |  | — |  |  | 4,001 |  |  | — |  |  | 4,001 |  |  | — |  |
|  |  | 566,581 |  |  | — |  |  | — |  |  | 566,581 |  |  | 562,580 |  |  | 4,001 |  |  | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 66,717 |  |  | — |  |  | — |  |  | 66,717 |  |  | — |  |  | 66,717 |  |  | — |  |
| Certificate of deposits(1) |  | 3,000 |  |  | — |  |  | — |  |  | 3,000 |  |  | — |  |  | 3,000 |  |  | — |  |
| U.S. government notes |  | 518,884 |  |  | 414 |  |  | (20) |  |  | 519,278 |  |  | 519,278 |  |  | — |  |  | — |  |
| Corporate bonds |  | 787,741 |  |  | 2,392 |  |  | (73) |  |  | 790,060 |  |  | — |  |  | 790,060 |  |  | — |  |
| Agency securities |  | 233,491 |  |  | 577 |  |  | (41) |  |  | 234,027 |  |  | — |  |  | 234,027 |  |  | — |  |
|  |  | 1,609,833 |  |  | 3,383 |  |  | (134) |  |  | 1,613,082 |  |  | 519,278 |  |  | 1,093,804 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,229 |  |  | — |  |  | — |  |  | 4,229 |  |  | 4,229 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 2,180,643 |  |  | $ | 3,383 |  |  | $ | (134) |  |  | $ | 2,183,892 |  |  | $ | 1,086,087 |  |  | $ | 1,097,805 |  |  | $ | — |  |

[0001596532-20-000226:notes:28]
[same as prior period, unchanged from 0001596532-20-000148:notes:31]

[0001596532-20-000226:notes:29]
(1) As of September 30, 2020 and December 31, 2019, all of our certificates of deposits were domestic deposits.

[0001596532-20-000226:notes:30]
The unrealized losses associated with our marketable securities were immaterial as of September 30, 2020, and December 31, 2019. As of September 30, 2020 and December 31, 2019, we did not have any marketable securities that have been in a continuous unrealized loss position for more than twelve months. We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. We did not recognize any credit losses or non-credit-related impairments related to our available-for-sale marketable securities during the three and nine months ended September 30, 2020.

[0001596532-20-000226:notes:31]
As of September 30, 2020, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale marketable securities, by remaining contractual maturity, are as follows (in thousands):

[0001596532-20-000226:notes:32]
|  |  | September 30, 2020 |
| Due in 1 year or less |  | $ | 1,161,664 |  |
| Due in over 1 year through 2 years |  | 713,888 |  |
| Total marketable securities |  | $ | 1,875,552 |  |

[0001596532-20-000226:notes:33]
The weighted-average remaining duration of our current marketable securities is approximately 0.9 years as of September 30, 2020.  As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities on the accompanying unaudited condensed consolidated balance sheets.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-20-000226:notes:34]
Financial Statements Details 
Cash, Cash Equivalents and Restricted Cash

[0001596532-20-000226:notes:35]
[same as prior period, unchanged from 0001596532-20-000148:notes:39]

[0001596532-20-000226:notes:36]
|  |  | September 30, 2020 |  | September 30, 2019 |
| Cash and cash equivalents |  | $ | 970,349 |  |  | $ | 1,095,265 |  |
| Restricted cash included in Other assets |  | 4,233 |  |  | 4,226 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 974,582 |  |  | $ | 1,099,491 |  |

[0001596532-20-000226:notes:37]
Restricted cash, which was included in "Other assets" on the accompanying condensed consolidated balance sheets as of September 30, 2020 and September 30, 2019, primarily consisted of $4.0 million pledged as collateral representing a security deposit required for a facility lease.

[0001596532-20-000226:notes:38]
[same as prior period, unchanged from 0001596532-20-000148:notes:42]

[0001596532-20-000226:notes:39]
[same as prior period, unchanged from 0001596532-20-000148:notes:43]

[0001596532-20-000226:notes:40]
|  |  | September 30, 2020 |  | December 31, 2019 |
| Accounts receivable |  | $ | 304,543 |  |  | $ | 398,147 |  |
| Allowance for doubtful accounts |  | (541) |  |  | (638) |  |
| Product sales rebate and returns reserve |  | (3,785) |  |  | (5,522) |  |
| Accounts receivable, net |  | $ | 300,217 |  |  | $ | 391,987 |  |

[0001596532-20-000226:notes:41]
[same as prior period, unchanged from 0001596532-20-000148:notes:45]

[0001596532-20-000226:notes:42]
[same as prior period, unchanged from 0001596532-20-000148:notes:46]

[0001596532-20-000226:notes:43]
|  |  | September 30, 2020 |  | December 31, 2019 |
| Raw materials |  | $ | 223,423 |  |  | $ | 96,712 |  |
| Finished goods |  | 214,679 |  |  | 147,113 |  |
| Total inventories |  | $ | 438,102 |  |  | $ | 243,825 |  |

[0001596532-20-000226:notes:44]
[same as prior period, unchanged from 0001596532-20-000148:notes:48]

[0001596532-20-000226:notes:45]
[same as prior period, unchanged from 0001596532-20-000148:notes:49]

[0001596532-20-000226:notes:46]
|  |  | September 30, 2020 |  | December 31, 2019 |
| Prepaid income taxes |  | $ | 564 |  |  | $ | 20,153 |  |
| Inventory deposit |  | 10,024 |  |  | 13,716 |  |
| Other current assets |  | 43,311 |  |  | 64,464 |  |
| Other prepaid expenses and deposits |  | 15,748 |  |  | 13,123 |  |
| Total prepaid expenses and other current assets |  | $ | 69,647 |  |  | $ | 111,456 |  |

[0001596532-20-000226:notes:47]
[same as prior period, unchanged from 0001596532-20-000148:notes:51]

[0001596532-20-000226:notes:48]
[same as prior period, unchanged from 0001596532-20-000148:notes:52]

[0001596532-20-000226:notes:49]
|  |  | September 30, 2020 |  | December 31, 2019 |
| Equipment and machinery |  | $ | 67,978 |  |  | $ | 64,748 |  |
| Computer hardware and software |  | 39,335 |  |  | 36,627 |  |
| Leasehold improvements |  | 31,309 |  |  | 31,235 |  |
| Furniture and fixtures |  | 3,754 |  |  | 3,774 |  |
| Construction-in-process |  | 308 |  |  | 265 |  |
| Property and equipment, gross |  | 142,684 |  |  | 136,649 |  |
| Less: accumulated depreciation |  | (110,014) |  |  | (97,376) |  |
| Property and equipment, net |  | $ | 32,670 |  |  | $ | 39,273 |  |

[0001596532-20-000226:notes:50]
Depreciation expense was $4.9 million and $4.8 million for the three months ended September 30, 2020 and 2019, respectively, and $15.1 million and $14.3 million for the nine months ended September 30, 2020 and 2019, respectively.

[0001596532-20-000226:notes:51]
[same as prior period, unchanged from 0001596532-20-000148:notes:55]

[0001596532-20-000226:notes:52]
[same as prior period, unchanged from 0001596532-20-000148:notes:56]

[0001596532-20-000226:notes:53]
|  |  | September 30, 2020 |  | December 31, 2019 |
| Accrued payroll related costs |  | $ | 44,920 |  |  | $ | 80,133 |  |
| Accrued manufacturing costs |  | 30,154 |  |  | 31,920 |  |
| Accrued product development costs |  | 16,983 |  |  | 11,410 |  |
| Accrued professional fees |  | 5,152 |  |  | 6,335 |  |
| Accrued warranty costs |  | 6,732 |  |  | 6,742 |  |
| Accrued taxes |  | 1,866 |  |  | 1,716 |  |
| Other |  | 4,541 |  |  | 1,993 |  |
| Total accrued liabilities |  | $ | 110,348 |  |  | $ | 140,249 |  |

[0001596532-20-000226:notes:54]
[same as prior period, unchanged from 0001596532-20-000148:notes:58]

[0001596532-20-000226:notes:55]
[same as prior period, unchanged from 0001596532-20-000148:notes:59]

[0001596532-20-000226:notes:56]
|  |  | Nine Months Ended September 30, |
|  |  | 2020 |  | 2019 |
| Warranty accrual, beginning of period |  | $ | 6,742 |  |  | $ | 5,362 |  |
| Liabilities accrued for warranties issued during the period |  | 4,507 |  |  | 3,887 |  |
| Warranty costs incurred during the period |  | (4,517) |  |  | (3,841) |  |
| Warranty accrual, end of period |  | $ | 6,732 |  |  | $ | 5,408 |  |

[0001596532-20-000226:notes:57]
[same as prior period, unchanged from 0001596532-20-000148:notes:61]

[0001596532-20-000226:notes:58]
[same as prior period, unchanged from 0001596532-20-000148:notes:62]

[0001596532-20-000226:notes:59]
|  |  | Nine Months Ended September 30, |
|  |  | 2020 |
| Contract assets, beginning balance |  | $ | 25,565 |  |
| Contract assets, ending balance |  | 6,004 |  |

[0001596532-20-000226:notes:60]
[same as prior period, unchanged from 0001596532-20-000148:notes:64]

[0001596532-20-000226:notes:61]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Contract liabilities, beginning balance |  | $ | 67,268 |  |  | $ | 42,026 |  |  | $ | 61,050 |  |  | $ | 32,595 |  |
| Less: Revenue recognized from beginning balance |  | (6,525) |  |  | (3,700) |  |  | (17,946) |  |  | (10,134) |  |
| Less: Beginning balance reclassified to deferred revenue |  | (2,828) |  |  | (1,689) |  |  | (1,942) |  |  | (967) |  |
| Add: Contract liabilities recognized |  | 12,362 |  |  | 13,506 |  |  | 29,115 |  |  | 28,649 |  |
| Contract liabilities, ending balance |  | $ | 70,277 |  |  | $ | 50,143 |  |  | $ | 70,277 |  |  | $ | 50,143 |  |

[0001596532-20-000226:notes:62]
As of September 30, 2020 and December 31, 2019, $31.1 million and $23.4 million of our contract liabilities, respectively, were included in "Other current liabilities" with the remaining balances included in "Other long-term liabilities" on the accompanying condensed consolidated balance sheets.

[0001596532-20-000226:notes:63]
[same as prior period, unchanged from 0001596532-20-000148:notes:67]

[0001596532-20-000226:notes:64]
[same as prior period, unchanged from 0001596532-20-000148:notes:68]

[0001596532-20-000226:notes:65]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Deferred revenue, beginning balance |  | $ | 577,511 |  |  | $ | 502,218 |  |  | $ | 575,288 |  |  | $ | 587,227 |  |
| Less: Revenue recognized from beginning balance |  | (103,889) |  |  | (84,277) |  |  | (243,422) |  |  | (306,909) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 88,682 |  |  | 111,071 |  |  | 230,438 |  |  | 248,694 |  |
| Deferred revenue, ending balance |  | $ | 562,304 |  |  | $ | 529,012 |  |  | $ | 562,304 |  |  | $ | 529,012 |  |

[0001596532-20-000226:notes:66]
[same as prior period, unchanged from 0001596532-20-000148:notes:70]

[0001596532-20-000226:notes:67]
Revenue from remaining performance obligations represents contracted revenue that has not yet been recognized. This consists of contract liabilities, deferred revenue and amounts that will be invoiced in future periods. As of September 30, 2020, approximately $676.4 million of revenue is expected to be recognized from remaining performance obligations. We expect to recognize revenue on approximately 81% of these remaining performance obligations over the next two years and 19% during the third to the fifth year.

[0001596532-20-000226:notes:68]
[same as prior period, unchanged from 0001596532-20-000148:notes:72]

[0001596532-20-000226:notes:69]
[same as prior period, unchanged from 0001596532-20-000148:notes:73]

[0001596532-20-000226:notes:70]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Interest income |  | $ | 4,319 |  |  | $ | 13,446 |  |  | $ | 24,649 |  |  | $ | 38,451 |  |
| Gain on sale of marketable securities |  | 9,432 |  |  | — |  |  | 9,432 |  |  | — |  |
| Gain on investment in privately-held companies |  | — |  |  | 4,277 |  |  | — |  |  | 5,427 |  |
| Other income (expense), net |  | (527) |  |  | 1,446 |  |  | (444) |  |  | 1,435 |  |
| Total |  | $ | 13,224 |  |  | $ | 19,169 |  |  | $ | 33,637 |  |  | $ | 45,313 |  |


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-20-000226:notes:71]
Investments 
Investments in Privately-Held Companies

[0001596532-20-000226:notes:72]
Our investments are in the equity of privately-held companies, which do not have readily determinable fair values. These non-marketable equity securities are initially recorded at cost, and subsequently remeasured to fair value on a non-recurring basis based on observable price changes in orderly transactions for similar investments of the same issuer, or for impairment. These investments are classified within Level III of the fair value hierarchy as we estimate the value based on valuation methods using the observable transaction price at the transaction date and other significant unobservable inputs, such as volatility, rights, and obligations related to those investments. In addition, the valuation requires management judgment due to the absence of market price and inherent lack of liquidity. The following table summarizes the activity related to our investments in privately-held companies held as of September 30, 2020 and December 31, 2019 (in thousands):

[0001596532-20-000226:notes:73]
|  |  | September 30, 2020 |  | December 31, 2019 |
| Cost of investment |  | $ | 3,000 |  |  | $ | 3,000 |  |
| Cumulative impairment |  | — |  |  | — |  |
| Cumulative upward adjustment |  | 1,150 |  |  | 1,150 |  |
| Carrying amount of investment |  | $ | 4,150 |  |  | $ | 4,150 |  |

[0001596532-20-000226:notes:74]
During the three and nine months ended September 30, 2020, there were no realized or unrealized gains or losses recorded on investments. During the three months ended September 30, 2019, the Company recorded a realized gain of $4.3 million upon the sale of one of our investments. The realized gains were classified in "Other income, net" in the 
accompanying condensed consolidated statements of operations. During the three months ended September 30, 2019, there were no realized or unrealized gains or losses recorded on our remaining investments. During the nine months ended September 30, 2019, we recorded $1.2 million of unrealized gain on investments held as of September 30, 2020. The unrealized gain was recorded on an investment that was remeasured to fair value as of the date an observable transaction occurred.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-20-000226:notes:75]
Commitments and Contingencies
Purchase Commitments

[0001596532-20-000226:notes:76]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consists of firm non-cancellable commitments. In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2020, we had non-cancellable purchase commitments of $501.5 million, of which $484.8 million were to our contract manufacturers and suppliers. In addition, we have provided suppliers with inventory deposits to secure our obligations to purchase inventory and the amount of these deposits may increase in future periods as we work to reduce product lead times and ensure adequate component supply to meet future demand. We had $12.8 million and $16.5 million in deposits as of September 30, 2020 and December 31, 2019, respectively. These deposits are included in “Prepaid expenses and other current assets” and “Other assets” on the accompanying condensed consolidated balance sheets.

[0001596532-20-000226:notes:77]
Guarantees

[0001596532-20-000226:notes:78]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe on the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-20-000226:notes:79]
Legal Proceedings

[0001596532-20-000226:notes:80]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-20-000226:notes:81]
We record a provision for contingent losses when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2020, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-20-000226:notes:82]
Stockholders’ Equity
Stock Repurchase Program

[0001596532-20-000226:notes:83]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the “Repurchase Program”).  This authorization allows us to repurchase shares of our common stock opportunistically and will be funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), or a combination of the foregoing. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of September 30, 2020, the remaining authorized amount for stock repurchases under this program was approximately $338.7 million.

[0001596532-20-000226:notes:84]
A summary of the stock repurchase activity under the Repurchase Program for the three and nine months ended September 30, 2020 is as follows (in thousands, except per share amounts):

[0001596532-20-000226:notes:85]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | September 30, 2020 |  | September 30, 2020 |
| Aggregate purchase price |  | $ | 167,278 |  |  | $ | 395,173 |  |
| Shares repurchased |  | 803 |  |  | 2,012 |  |
| Average price paid per share |  | $ | 208.19 |  |  | $ | 196.43 |  |

[0001596532-20-000226:notes:86]
The aggregate purchase price of repurchased shares of our common stock is recorded as a reduction to retained earnings.  All shares repurchased under the Repurchase Program have been retired.

[0001596532-20-000226:notes:87]
[same as prior period, unchanged from 0001596532-20-000148:notes:94]

[0001596532-20-000226:notes:88]
[same as prior period, unchanged from 0001596532-20-000148:notes:95]

[0001596532-20-000226:notes:89]
Effective January 1, 2020, the Company's board of directors authorized an increase of 2,291,660 shares to the shares available for issuance under the 2014 Equity Incentive Plan (the “2014 Plan”).  Pursuant to the 2014 Plan, the 2020 share increase is determined based on 3% of the total shares of common stock outstanding as of December 31, 2019, but not to exceed 12,500,000 shares, unless the board of directors, in its discretion, determines to make a smaller increase. As of September 30, 2020, there remained approximately 21.9 million shares available for issuance under the 2014 Plan.

[0001596532-20-000226:notes:90]
[same as prior period, unchanged from 0001596532-20-000148:notes:97]

[0001596532-20-000226:notes:91]
Effective January 1, 2020, our board of directors authorized an increase of 763,886 shares to the shares available for issuance under our 2014 Employee Stock Purchase Plan (the “ESPP”).  Pursuant to the ESPP, the 2020 share increase was determined based on the least of 1% of the total shares of common stock outstanding on December 31, 2019, 2,500,000 shares, or such amount as determined by our board of directors. During the nine months ended September 30, 2020, we issued 105,667 shares at a weighted-average purchase price of $183.45 per share under the ESPP. As of September 30, 2020, there remained 3,850,993 shares available for issuance under the ESPP.

[0001596532-20-000226:notes:92]
[same as prior period, unchanged from 0001596532-20-000148:notes:99]

[0001596532-20-000226:notes:93]
[same as prior period, unchanged from 0001596532-20-000148:notes:100]

[0001596532-20-000226:notes:94]
|  |  | Options Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding |
| Balance—December 31, 2019 |  | 4,564 |  |  | $ | 42.50 |  |  | 4.4 |  | $ | 740,387 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (800) |  |  | 29.15 |  |  |  |  |  |
| Options canceled |  | (31) |  |  | 121.24 |  |  |  |  |  |
| Balance—September 30, 2020 |  | 3,733 |  |  | $ | 44.71 |  |  | 3.7 |  | $ | 610,580 |  |
| Vested and exercisable—September 30, 2020 |  | 2,489 |  |  | $ | 31.62 |  |  | 3.3 |  | $ | 436,617 |  |

[0001596532-20-000226:notes:95]
[same as prior period, unchanged from 0001596532-20-000148:notes:102]

[0001596532-20-000226:notes:96]
[same as prior period, unchanged from 0001596532-20-000148:notes:103]

[0001596532-20-000226:notes:97]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2019 |  | 1,070 |  |  | $ | 190.35 |  |  | 1.5 |  | $ | 217,701 |  |
| RSUs granted |  | 1,208 |  |  | 213.75 |  |  |  |  |  |
| RSUs vested |  | (375) |  |  | 158.18 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (81) |  |  | 222.27 |  |  |  |  |  |
| Unvested balance—September 30, 2020 |  | 1,822 |  |  | $ | 211.07 |  |  | 1.9 |  | $ | 377,024 |  |

[0001596532-20-000226:notes:98]
[same as prior period, unchanged from 0001596532-20-000148:notes:105]

[0001596532-20-000226:notes:99]
The following table presents the stock activity and the total number of shares available for grant under the 2014 Plan as of September 30, 2020 (in thousands):

[0001596532-20-000226:notes:100]
|  |  | Number of Shares |
| Balance—December 31, 2019 |  | 15,146 |  |
| Authorized |  | 2,292 |  |
| Options granted |  | — |  |
| RSUs granted |  | (1,208) |  |
| Options canceled |  | 31 |  |
| RSUs forfeited |  | 81 |  |
| Shares traded for taxes |  | 26 |  |
| Balance—September 30, 2020 |  | 16,368 |  |

[0001596532-20-000226:notes:101]
[same as prior period, unchanged from 0001596532-20-000148:notes:108]

[0001596532-20-000226:notes:102]
[same as prior period, unchanged from 0001596532-20-000148:notes:109]

[0001596532-20-000226:notes:103]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cost of revenue |  | $ | 1,806 |  |  | $ | 1,258 |  |  | $ | 4,718 |  |  | $ | 3,384 |  |
| Research and development |  | 21,423 |  |  | 13,472 |  |  | 56,729 |  |  | 39,171 |  |
| Sales and marketing |  | 9,083 |  |  | 7,832 |  |  | 23,756 |  |  | 21,463 |  |
| General and administrative |  | 4,157 |  |  | 3,695 |  |  | 11,744 |  |  | 10,827 |  |
| Total stock-based compensation |  | $ | 36,469 |  |  | $ | 26,257 |  |  | $ | 96,947 |  |  | $ | 74,845 |  |

[0001596532-20-000226:notes:104]
As of September 30, 2020, unrecognized stock-based compensation expenses by award type and their expected weighted-average recognition periods are summarized in the following table (in thousands, except years):

[0001596532-20-000226:notes:105]
|  |  | September 30, 2020 |
|  |  | Stock Option |  | RSU |  | ESPP |  | Restricted Stock |
| Unrecognized stock-based compensation expense |  | $ | 31,114 |  |  | $ | 338,561 |  |  | $ | 12,641 |  |  | $ | 2,839 |  |
| Weighted-average amortization period |  | 2.7 years |  | 3.4 years |  | 1.4 years |  | 2.0 years |


## us-gaap:EarningsPerShareTextBlock

[0001596532-20-000226:notes:106]
Net Income Per Share Available to Common Stock 
    The following table sets forth the computation of our basic and diluted net income per share attributable to common stockholders (in thousands, except per share amounts):

[0001596532-20-000226:notes:107]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 168,375 |  |  | $ | 208,895 |  |  | $ | 451,599 |  |  | $ | 599,175 |  |  |  |  |  |
| Less: undistributed earnings allocated to participating securities |  | — |  |  | (96) |  |  | — |  |  | (314) |  |  |  |  |  |
| Net income available to common stockholders, basic |  | $ | 168,375 |  |  | $ | 208,799 |  |  | $ | 451,599 |  |  | $ | 598,861 |  |  |  |  |  |
| Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to common stockholders, basic |  | $ | 168,375 |  |  | $ | 208,799 |  |  | $ | 451,599 |  |  | $ | 598,861 |  |  |  |  |  |
| Add: undistributed earnings allocated to participating securities |  | — |  |  | 5 |  |  | — |  |  | 19 |  |  |  |  |  |
| Net income attributable to common stockholders, diluted |  | $ | 168,375 |  |  | $ | 208,804 |  |  | $ | 451,599 |  |  | $ | 598,880 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 75,999 |  |  | 76,426 |  |  | 76,024 |  |  | 76,301 |  |  |  |  |  |
| Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 75,999 |  |  | 76,426 |  |  | 76,024 |  |  | 76,301 |  |  |  |  |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options and RSUs |  | 3,308 |  |  | 4,308 |  |  | 3,489 |  |  | 4,784 |  |  |  |  |  |
| Employee stock purchase plan |  | 6 |  |  | 19 |  |  | 6 |  |  | 19 |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted |  | 79,313 |  |  | 80,753 |  |  | 79,519 |  |  | 81,104 |  |  |  |  |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.22 |  |  | $ | 2.73 |  |  | $ | 5.94 |  |  | $ | 7.85 |  |  |  |  |  |
| Diluted |  | $ | 2.12 |  |  | $ | 2.59 |  |  | $ | 5.68 |  |  | $ | 7.38 |  |  |  |  |  |

[0001596532-20-000226:notes:108]
[same as prior period, unchanged from 0001596532-20-000148:notes:116]

[0001596532-20-000226:notes:109]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  |  |  |  |
| Stock options and RSUs to purchase common stock |  | 251 |  |  | 277 |  |  | 395 |  |  | 211 |  |  |  |  |  |
| Employee stock purchase plan |  | 17 |  |  | 41 |  |  | 84 |  |  | 59 |  |  |  |  |  |
| Total |  | 268 |  |  | 318 |  |  | 479 |  |  | 270 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-20-000226:notes:110]
Income Taxes

[0001596532-20-000226:notes:111]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |  |  |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  |  |  |  |
|  |  | (in thousands, except percentages) |  | (in thousands, except percentages) |  |  |  |  |
| Income before income taxes |  | $ | 201,619 |  |  | $ | 247,775 |  |  | $ | 538,683 |  |  | $ | 675,098 |  |  |  |  |  |
| Provision for income taxes |  | 33,244 |  |  | 38,880 |  |  | 87,084 |  |  | 75,923 |  |  |  |  |  |
| Effective tax rate |  | 16.5 | % |  | 15.7 | % |  | 16.2 | % |  | 11.2 | % |  |  |  |  |

[0001596532-20-000226:notes:112]
The effective tax rates reflect tax expense recorded on pre-tax income in the three and nine months ended September 30, 2020 and September 30, 2019, respectively. The change in the effective tax rates in the three and nine months ended September 30, 2020, as compared to the same periods in 2019, was primarily due to a decrease in tax benefits attributable to stock-based compensation.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-20-000226:notes:113]
Segment Information 
    We operate in one reportable segment. The following table represents revenue based on the customer’s location, as determined by the customer’s shipping address (in thousands):

[0001596532-20-000226:notes:114]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Americas |  | $ | 452,693 |  |  | $ | 532,318 |  |  | $ | 1,289,182 |  |  | $ | 1,418,325 |  |
| Europe, Middle East and Africa |  | 89,588 |  |  | 75,439 |  |  | 226,189 |  |  | 298,768 |  |
| Asia-Pacific |  | 63,150 |  |  | 46,658 |  |  | 153,659 |  |  | 141,067 |  |
| Total revenue |  | $ | 605,431 |  |  | $ | 654,415 |  |  | $ | 1,669,030 |  |  | $ | 1,858,160 |  |

[0001596532-20-000226:notes:115]
Long-lived assets, net, excluding intercompany receivables, investments in subsidiaries, privately-held equity investments and deferred tax assets, by location, are summarized as follows (in thousands):

[0001596532-20-000226:notes:116]
|  |  | September 30, 2020 |  | December 31, 2019 |
| United States |  | $ | 24,469 |  |  | $ | 32,565 |  |
| International |  | 8,201 |  |  | 6,708 |  |
| Total |  | $ | 32,670 |  |  | $ | 39,273 |  |


## us-gaap:SubsequentEventsTextBlock

[0001596532-20-000226:notes:117]
Subsequent Events
    On September 21, 2020, the Company entered into a Merger Agreement to acquire Awake Security, Inc. (“Awake Security”), a network detection and response (“NDR”) platform provider headquartered in Santa Clara, California, and on October 7, 2020, we completed the acquisition of Awake Security.

[0001596532-20-000226:notes:118]
The acquisition will be included in our consolidated financial statements beginning in the fourth quarter of 2020, and will be financed from our existing cash balance.
