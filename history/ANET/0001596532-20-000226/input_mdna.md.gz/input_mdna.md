# ANET MD&A — 0001596532-20-000226


## mdna

[0001596532-20-000226:mdna:1]
[same as prior period, unchanged from 0001596532-20-000148:mdna:1]

[0001596532-20-000226:mdna:2]
[same as prior period, unchanged from 0001596532-20-000148:mdna:2]

[0001596532-20-000226:mdna:3]
[same as prior period, unchanged from 0001596532-20-000148:mdna:3]

[0001596532-20-000226:mdna:4]
[same as prior period, unchanged from 0001596532-20-000148:mdna:4]

[0001596532-20-000226:mdna:5]
[same as prior period, unchanged from 0001596532-20-000148:mdna:5]

[0001596532-20-000226:mdna:6]
We believe our future success is dependent upon our ability to continue to develop market leading products and features that address the needs of our end customers and our ability to sell these products to new and existing customers, including an increase in sales in the enterprise data center switching, campus and WiFi networking markets. We intend to continue to invest in our sales activities in key geographies, as well as in our relationships with channel, technology and system-level partners in order to reach new end customers more effectively, increase sales to existing customers, and provide services and support. In addition, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our rapid development of new features and applications.

[0001596532-20-000226:mdna:7]
[same as prior period, unchanged from 0001596532-20-000148:mdna:7]

[0001596532-20-000226:mdna:8]
[same as prior period, unchanged from 0001596532-20-000148:mdna:8]

[0001596532-20-000226:mdna:9]
[same as prior period, unchanged from 0001596532-20-000148:mdna:9]

[0001596532-20-000226:mdna:10]
[same as prior period, unchanged from 0001596532-20-000148:mdna:10]

[0001596532-20-000226:mdna:11]
We have taken numerous steps, and will continue to take further actions, in our approach to address COVID-19. We have prioritized the protection of our employees during this pandemic and, as a result, have closed our offices across the globe (including our corporate headquarters) limiting access to only those employees providing essential activities, instructed employees to work from home, and implemented travel restrictions. We continue to work closely with our contract

[0001596532-20-000226:mdna:12]
manufacturers and supply chain partners who have experienced delays in component sourcing, workforce disruptions and governmental restrictions on the production and export of their products. Although we have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, these delays have negatively impacted our ability to supply products to our customers on a timely basis. We expect to continue to invest in working capital as supply availability improves in order to address the risk of future COVID-19 related supply chain disruptions, but we cannot be certain that such disruptions will not occur.

[0001596532-20-000226:mdna:13]
The extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, including the duration and spread of the pandemic, the breadth and duration of governmental containment measures such as shelter in place, travel and social distancing restrictions as well as the reauthorization of or increase in such measures in the event of spikes in COVID-19 infection rates, and the impact on our customers, partners, contract manufacturers and supply chain, all of which are uncertain and cannot be predicted. However, any continued or renewed disruption in manufacturing and supply resulting from the COVID-19 pandemic or related containment measures would negatively impact our business. We also believe that any extended or renewed COVID-19 related economic disruption could have a negative impact on demand from our customers in future periods. While we have experienced some incremental improvement in demand from our cloud titan customers and some stabilization in sales activity in our campus and enterprise markets in the period, we continue to expect a year-over-year decline in total revenue for the year ending December 31, 2020. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

[0001596532-20-000226:mdna:14]
In response to potential future COVID-19 related disruptions to our business, we have continued to carefully review our investment and spending plans, cautiously reintroducing some incremental spending beginning in the third quarter as overall customer demand began to stabilize. Although management is actively monitoring the impact of COVID-19 on the Company’s financial condition, liquidity, operations, suppliers, industry, and workforce, the full impact of the pandemic continues to evolve as of the date of this report. As such, the Company is unable to estimate the effects of COVID-19 on its future results of operations, financial condition, or liquidity.

[0001596532-20-000226:mdna:15]
Acquisitions

[0001596532-20-000226:mdna:16]
On February 5, 2020, we acquired Big Switch Networks, Inc. (“Big Switch”), a network monitoring and software-defined networking pioneer headquartered in Santa Clara, California.  With the acquisition of Big Switch, we expect to expand our data center networking solutions and further strengthen our network monitoring and observability suite delivered through Arista’s software platform CloudVision and DANZ (DataANalyZer) capabilities. In addition, on October 7, 2020, we completed the acquisition of Awake Security Inc. (“Awake Security”), a network detection and response (“NDR”) platform provider headquartered in Santa Clara, California. With the acquisition of Awake Security, we are adding an NDR platform to our product portfolio that combines artificial intelligence (AI) with human expertise to autonomously hunt for and respond to insider and external threats.

[0001596532-20-000226:mdna:17]
[same as prior period, unchanged from 0001596532-20-000148:mdna:17]

[0001596532-20-000226:mdna:18]
Three and Nine Months Ended September 30, 2020 Compared to Three and Nine Months Ended September 30, 2019

[0001596532-20-000226:mdna:19]
[same as prior period, unchanged from 0001596532-20-000148:mdna:19]

[0001596532-20-000226:mdna:20]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2020 |  | 2019 |  | Change in |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 480,242 |  |  | $ | 555,066 |  |  | $ | (74,824) |  |  | (13.5) | % |  | $ | 1,312,561 |  |  | $ | 1,573,652 |  |  | $ | (261,091) |  |  | (16.6) | % |
| Service |  | 125,189 |  |  | 99,349 |  |  | 25,840 |  |  | 26.0 |  |  | 356,469 |  |  | 284,508 |  |  | 71,961 |  |  | 25.3 |  |
| Total revenue |  | 605,431 |  |  | 654,415 |  |  | (48,984) |  |  | (7.5) |  |  | 1,669,030 |  |  | 1,858,160 |  |  | (189,130) |  |  | (10.2) |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 199,465 |  |  | 218,220 |  |  | (18,755) |  |  | (8.6) |  |  | 539,526 |  |  | 616,906 |  |  | (77,380) |  |  | (12.5) |  |
| Service |  | 21,004 |  |  | 18,921 |  |  | 2,083 |  |  | 11.0 |  |  | 62,202 |  |  | 53,219 |  |  | 8,983 |  |  | 16.9 |  |
| Total cost of revenue |  | 220,469 |  |  | 237,141 |  |  | (16,672) |  |  | (7.0) |  |  | 601,728 |  |  | 670,125 |  |  | (68,397) |  |  | (10.2) |  |
| Gross profit |  | $ | 384,962 |  |  | $ | 417,274 |  |  | $ | (32,312) |  |  | (7.7) | % |  | $ | 1,067,302 |  |  | $ | 1,188,035 |  |  | $ | (120,733) |  |  | (10.2) | % |
| Gross margin |  | 63.6 | % |  | 63.8 | % |  |  |  |  |  | 63.9 | % |  | 63.9 | % |  |  |  |  |

[0001596532-20-000226:mdna:21]
[same as prior period, unchanged from 0001596532-20-000148:mdna:21]

[0001596532-20-000226:mdna:22]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2020 |  | % of Total |  | 2019 |  | % of Total |  | 2020 |  | % of Total |  | 2019 |  | % of Total |
| Americas |  | $ | 452,693 |  |  | 74.8 | % |  | $ | 532,318 |  |  | 81.4 | % |  | $ | 1,289,182 |  |  | 77.2 | % |  | $ | 1,418,325 |  |  | 76.3 | % |
| Europe, Middle East and Africa |  | 89,588 |  |  | 14.8 |  |  | 75,439 |  |  | 11.5 |  |  | 226,189 |  |  | 13.6 |  |  | 298,768 |  |  | 16.1 |  |
| Asia-Pacific |  | 63,150 |  |  | 10.4 |  |  | 46,658 |  |  | 7.1 |  |  | 153,659 |  |  | 9.2 |  |  | 141,067 |  |  | 7.6 |  |
| Total revenue |  | $ | 605,431 |  |  | 100.0 | % |  | $ | 654,415 |  |  | 100.0 | % |  | $ | 1,669,030 |  |  | 100.0 | % |  | $ | 1,858,160 |  |  | 100.0 | % |

[0001596532-20-000226:mdna:23]
[same as prior period, unchanged from 0001596532-20-000148:mdna:23]

[0001596532-20-000226:mdna:24]
We generate revenue primarily from sales of our products. We also derive a portion of our revenue from sales of PCS, which is typically purchased in conjunction with our products, and subsequent renewals of those contracts. We expect our revenue may vary from period to period based on, among other things, the timing, size and complexity of orders, especially with respect to our large end customers.

[0001596532-20-000226:mdna:25]
Product revenue decreased $74.8 million, or 13.5%, and $261.1 million, or 16.6%, for the three and nine months ended September 30, 2020, respectively, compared to the same periods in 2019. The decrease of $74.8 million was primarily driven by reduced sales on a year-over-year basis to our larger customers, combined with some COVID-19 related supply constraints in fiscal 2020. The decrease of $261.1 million was primarily the result of the recognition of $116.8 million of deferred revenue related to customer acceptance of prior period sales transactions in the nine months ended September 30, 2019 combined with some reduction in sales to our larger customers in the period, and the impact of COVID-19 related supply constraints. Service revenue increased $25.8 million, or 26.0%, and $72.0 million, or 25.3%, in the three and nine months ended September 30, 2020, compared to the same periods in 2019, as a result of continued growth in support contracts as our customer installed base has continued to expand. International revenues represented 25.2% and 22.8% of total revenues in the three and nine months ended September 30, 2020, respectively, an increase from 18.6% and a decrease from 23.7% compared to the same periods in the prior year. International revenues generally fluctuate based on the timing of deployments by certain of our large end customers.  In addition, the increase in the current quarter was mainly due to an increase in demand in both our EMEA and Asia-Pacific regions. We continued to experience competitive pricing pressure on our products and services.

[0001596532-20-000226:mdna:26]
[same as prior period, unchanged from 0001596532-20-000148:mdna:27]

[0001596532-20-000226:mdna:27]
Cost of revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs in our manufacturing operations department, and other manufacturing-related costs associated with manufacturing our products and managing our inventory. Costs of providing PCS and other services primarily consist of personnel costs for our global customer support organization.

[0001596532-20-000226:mdna:28]
Cost of revenue decreased $16.7 million, or 7.0%, and $68.4 million, or 10.2%, for the three and nine months ended September 30, 2020, respectively, compared to the same periods in 2019. These decreases were primarily driven by a corresponding decrease in revenue.

[0001596532-20-000226:mdna:29]
[same as prior period, unchanged from 0001596532-20-000148:mdna:30]

[0001596532-20-000226:mdna:30]
Gross margin remained consistent for the three and nine months ended September 30, 2020, compared to the same periods in 2019. Gross margin in each period was unfavorably impacted by incremental COVID-19 related supply chain costs combined with some relatively fixed overhead costs on a lower revenue base.

[0001596532-20-000226:mdna:31]
[same as prior period, unchanged from 0001596532-20-000148:mdna:32]

[0001596532-20-000226:mdna:32]
[same as prior period, unchanged from 0001596532-20-000148:mdna:33]

[0001596532-20-000226:mdna:33]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2020 |  | 2019 |  | Change in |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 128,049 |  |  | $ | 118,732 |  |  | $ | 9,317 |  |  | 7.8 | % |  | $ | 352,747 |  |  | $ | 352,696 |  |  | $ | 51 |  |  | — | % |
| Sales and marketing |  | 53,372 |  |  | 55,279 |  |  | (1,907) |  |  | (3.4) |  |  | 161,695 |  |  | 159,372 |  |  | 2,323 |  |  | 1.5 |  |
| General and administrative |  | 15,146 |  |  | 14,657 |  |  | 489 |  |  | 3.3 |  |  | 47,814 |  |  | 46,182 |  |  | 1,632 |  |  | 3.5 |  |
| Total operating expenses |  | $ | 196,567 |  |  | $ | 188,668 |  |  | $ | 7,899 |  |  | 4.2 | % |  | $ | 562,256 |  |  | $ | 558,250 |  |  | $ | 4,006 |  |  | 0.7 | % |

[0001596532-20-000226:mdna:34]
[same as prior period, unchanged from 0001596532-20-000148:mdna:35]

[0001596532-20-000226:mdna:35]
Research and development expenses consist primarily of personnel costs, prototype expenses, third-party engineering and contractor support costs, and an allocated portion of facility and IT costs including depreciation. Our research and development efforts are focused on maintaining and developing additional functionality for our existing products and on new product development, including new releases and upgrades to our EOS software and applications. We plan to continue to expand the capabilities of our cloud networking platform, introduce new products and features and build upon our technology leadership.

[0001596532-20-000226:mdna:36]
Research and development expenses increased $9.3 million, or 7.8% in the three months ended September 30, 2020 compared to the same period in 2019. The increase was primarily due to an increase of $3.7 million in new product introduction costs in the current period combined with an increase of $5.6 million in personnel costs, which included an increase in stock-based compensation costs of $8.0 million, partially offset by a decrease in corporate bonus expense. For the nine months ended September 30, 2020, research and development expenses remained relatively constant compared to the same period in 2019, resulting from an increase of $5.6 million in personnel costs, an increase of $7.3 million in acquisition-related costs, and an offsetting decrease of $12.8 million in new product introduction costs in the nine months ended September 30, 2020.

[0001596532-20-000226:mdna:37]
[same as prior period, unchanged from 0001596532-20-000148:mdna:38]

[0001596532-20-000226:mdna:38]
Sales and marketing expenses consist primarily of personnel costs, marketing, trade shows, and other promotional activities, and an allocated portion of facility and IT costs, including depreciation. We continue to prudently manage our sales and marketing spend in fiscal 2020 with some targeted investment in strategic sales activities and, accordingly, expect a marginal increase in sales and marketing expenses in fiscal 2020 compared to fiscal 2019.

[0001596532-20-000226:mdna:39]
Sales and marketing expenses decreased $1.9 million, or 3.4%, for the three months ended September 30, 2020 compared to the same period in 2019. The decrease primarily resulted from COVID-19 related reductions in marketing and travel expenses, partially offset by increased salaries and stock-based compensation due to increased headcount.  The increase of $2.3 million, or 1.5%, in the nine months ended September 30, 2020 compared to the same period in 2019, was primarily driven by an increase in salaries and stock-based compensation due to increased headcount, and an increase of $3.7 million in acquisition-related expenses. This increase was partially offset by a reduction in travel expenses and other sales and marketing activities due to COVID-19.

[0001596532-20-000226:mdna:40]
[same as prior period, unchanged from 0001596532-20-000148:mdna:41]

[0001596532-20-000226:mdna:41]
[same as prior period, unchanged from 0001596532-20-000148:mdna:42]

[0001596532-20-000226:mdna:42]
General and administrative expenses increased $0.5 million, or 3.3%, in the three months ended September 30, 2020, and $1.6 million, or 3.5%, in the nine months ended September 30, 2020 compared to the same periods in 2019.  The increase in each period was primarily due to acquisition-related expenses, partially offset by lower personnel costs.  In addition, litigation-related costs decreased in the three and nine months ended September 30, 2020 due to the settlement of our litigation with Optumsoft in December 2019.

[0001596532-20-000226:mdna:43]
[same as prior period, unchanged from 0001596532-20-000148:mdna:44]

[0001596532-20-000226:mdna:44]
Other income consists primarily of interest income from our cash, cash equivalents and marketable securities, gains and losses on our investments in privately-held companies, and foreign currency transaction gains and losses. We expect that interest income from our fixed-income marketable securities will decline for the year ending December 31, 2020 as a result of lower interest rates in 2020 compared to 2019 and the sale of marketable securities in the three months ended September 30,

[0001596532-20-000226:mdna:45]
2020. In addition, we expect other income may fluctuate in the future as a result of the re-measurement of our private company equity investments upon the occurrence of observable price changes and/or impairments, changes in returns on our cash and cash equivalents and marketable securities, and foreign currency exchange rate fluctuations.

[0001596532-20-000226:mdna:46]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2020 |  | 2019 |  | Change in |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 4,319 |  |  | $ | 13,446 |  |  | $ | (9,127) |  |  | (67.9) | % |  | $ | 24,649 |  |  | $ | 38,451 |  |  | $ | (13,802) |  |  | (35.9) | % |
| Gain on sale of marketable securities |  | 9,432 |  |  | — |  |  | 9,432 |  |  | 100.0 |  |  | 9,432 |  |  | — |  |  | 9,432 |  |  | 100.0 |  |
| Gain on investments in privately-held companies |  | — |  |  | 4,277 |  |  | (4,277) |  |  | (100.0) |  |  | — |  |  | 5,427 |  |  | (5,427) |  |  | (100.0) |  |
| Other income (expense), net |  | (527) |  |  | 1,446 |  |  | (1,973) |  |  | (136.4) |  |  | (444) |  |  | 1,435 |  |  | (1,879) |  |  | (130.9) |  |
| Total other income, net |  | $ | 13,224 |  |  | $ | 19,169 |  |  | $ | (5,945) |  |  | (31.0) | % |  | $ | 33,637 |  |  | $ | 45,313 |  |  | $ | (11,676) |  |  | (25.8) | % |

[0001596532-20-000226:mdna:47]
The unfavorable change in Other income, net, during the three and nine months ended September 30, 2020 as compared to the same periods in 2019 was primarily driven by a decrease in interest income from our fixed-income marketable securities caused by reduced interest rates. In addition, we recorded a gain on our investments in privately-held companies in the nine months ended September 30, 2019, which did not recur in the current period. The decrease in each period was partially offset by a realized gain of $9.4 million from the sale of our marketable securities in the three months ended September 30, 2020.

[0001596532-20-000226:mdna:48]
[same as prior period, unchanged from 0001596532-20-000148:mdna:48]

[0001596532-20-000226:mdna:49]
[same as prior period, unchanged from 0001596532-20-000148:mdna:49]

[0001596532-20-000226:mdna:50]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2020 |  | 2019 |  | Change in |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Income before income taxes |  | $ | 201,619 |  |  | $ | 247,775 |  |  | $ | (46,156) |  |  | (18.6) | % |  | $ | 538,683 |  |  | $ | 675,098 |  |  | $ | (136,415) |  |  | (20.2) | % |
| Provision for income taxes |  | 33,244 |  |  | 38,880 |  |  | (5,636) |  |  | (14.5) | % |  | 87,084 |  |  | 75,923 |  |  | 11,161 |  |  | 14.7 | % |
| Effective tax rate |  | 16.5 | % |  | 15.7 | % |  |  |  |  |  | 16.2 | % |  | 11.2 | % |  |  |  |  |

[0001596532-20-000226:mdna:51]
For the three and nine months ended September 30, 2020, we recorded expenses of $33.2 million and $87.1 million for income taxes, respectively. For the three and nine months ended September 30, 2019, we recorded expenses of $38.9 million and $75.9 million, respectively. Income taxes for the three and nine months ended September 30, 2020 were attributable to the overall decrease in worldwide earnings offset by lower tax benefits realized from stock-based compensation.

[0001596532-20-000226:mdna:52]
[same as prior period, unchanged from 0001596532-20-000148:mdna:52]

[0001596532-20-000226:mdna:53]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of September 30, 2020, our total balance of cash, cash equivalents and marketable securities was approximately $2.8 billion, of which approximately $409.5 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-20-000226:mdna:54]
Our cash, cash equivalents and marketable securities are held for working capital purposes. Our marketable securities investment portfolio is primarily invested in highly rated securities with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash

[0001596532-20-000226:mdna:55]
equivalents and marketable securities together with cash generated from operations will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and stock repurchases. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-20-000226:mdna:56]
[same as prior period, unchanged from 0001596532-20-000148:mdna:55]

[0001596532-20-000226:mdna:57]
|  |  | Nine Months Ended September 30, |
|  |  | 2020 |  | 2019 |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 548,190 |  |  | $ | 635,873 |  |
| Cash used in investing activities |  | (330,476) |  |  | (20,043) |  |
| Cash used in financing activities |  | (358,401) |  |  | (169,509) |  |
| Effect of exchange rate changes |  | (246) |  |  | (994) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | (140,933) |  |  | $ | 445,327 |  |

[0001596532-20-000226:mdna:58]
[same as prior period, unchanged from 0001596532-20-000148:mdna:57]

[0001596532-20-000226:mdna:59]
During the nine months ended September 30, 2020, cash provided by operating activities was $548.2 million, primarily from net income of $451.6 million and non-cash adjustments to net income of $141.4 million driven by stock-based compensation and depreciation and amortization, and a net $44.8 million increase in working capital requirements. This increase in working capital primarily consisted of a $194.0 million increase in inventory to help mitigate COVID-19 related supply chain disruptions, a $34.4 million decrease in deferred revenue, and a $29.8 million decrease in accrued liabilities related to the timing of corporate bonus payouts. These working capital increases were partially offset by a $98.3 million decrease in accounts receivable due to strong collections, a $71.8 million increase in accounts payable related to the timing of production receipts, and a $38.7 million decrease in prepaid expenses.

[0001596532-20-000226:mdna:60]
During the nine months ended September 30, 2019, cash provided by operating activities was $635.9 million, primarily from net income of $599.2 million and non-cash adjustments to net income of $111.3 million driven by stock-based compensation and depreciation and amortization, partially offset by a net decrease of $74.6 million in cash from changes in our operating assets and liabilities. Cash outflows from operating activities consisted of a $58.2 million decrease in deferred revenue primarily due to the recognition of product deferred revenue of $116.0 million, which was offset by a $57.8 million increase in service deferred revenue, $115.5 million increase in accounts receivable due to timing of customer shipments in the quarter ended September 30, 2019, and a $14.4 million decrease in accounts payable due to timing of production-related vendor balances. These cash outflows were partially offset by cash inflows of $59.4 million in prepaid expenses and other current assets from a decrease in prepaid taxes and a decrease in deferred cost of inventory due to the recognition of product deferred revenue, $29.8 million from an increase in income taxes payable, and a $25.0 million decrease in inventories due to timing of product shipments and receipts.

[0001596532-20-000226:mdna:61]
[same as prior period, unchanged from 0001596532-20-000148:mdna:61]

[0001596532-20-000226:mdna:62]
During the nine months ended September 30, 2020, cash used in investing activities was $330.5 million, consisting of purchases of available-for-sale securities of $2,216.5 million, $66.3 million for the acquisition of Big Switch, and purchases of property and equipment of $7.7 million, partially offset by proceeds from maturities of marketable securities of $1,183.6 million, proceeds from the sale of marketable securities of $773.0 million and proceeds from the sale of one of our investments in privately-held companies of $3.4 million.

[0001596532-20-000226:mdna:63]
During the nine months ended September 30, 2019, cash used in investing activities was $20.0 million, primarily consisting of purchases of available-for-sale securities of $840.1 million, and purchases of property and equipment of $13.3 million, partially offset by proceeds of $806.5 million from maturities of marketable securities and proceeds from the sale of one of our investments in privately-held companies of $28.2 million.

[0001596532-20-000226:mdna:64]
[same as prior period, unchanged from 0001596532-20-000148:mdna:64]

[0001596532-20-000226:mdna:65]
During the nine months ended September 30, 2020, cash used in financing activities was $358.4 million, consisting of payments for repurchases of our common stock from the open market of $395.2 million and taxes paid of $5.9 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $42.7 million.

[0001596532-20-000226:mdna:66]
During the nine months ended September 30, 2019, cash used in financing activities was $169.5 million, consisting of payments for repurchases of our common stock from the open market of $214.6 million and taxes paid of $7.1 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $52.2 million.

[0001596532-20-000226:mdna:67]
[same as prior period, unchanged from 0001596532-20-000148:mdna:67]

[0001596532-20-000226:mdna:68]
From time to time, we repurchase our common stock opportunistically pursuant to our Repurchase Program authorized by our board of directors in April 2019. The Repurchase Program allows for stock repurchases of up to $1.0 billion and these repurchases are funded from working capital. The Repurchase Program, which expires in April 2022, may be suspended or discontinued by us at any time without prior notice. During the three months ended September 30, 2020, we repurchased a total of $167.3 million of our common stock. As of September 30, 2020, the remaining authorized amount for repurchases under the Repurchase Program was $338.7 million. Refer to Note 7. Stockholders' Equity of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-20-000226:mdna:69]
[same as prior period, unchanged from 0001596532-20-000148:mdna:69]

[0001596532-20-000226:mdna:70]
As of September 30, 2020, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-20-000226:mdna:71]
[same as prior period, unchanged from 0001596532-20-000148:mdna:71]

[0001596532-20-000226:mdna:72]
Our contractual commitments will have an impact on our future liquidity.  Our contractual obligations represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalents and marketable securities. As of September 30, 2020, our principal commitments consist primarily of obligations under operating leases for offices and data centers and purchase commitments with our contract manufacturers and suppliers. See Note 6. Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for our purchase commitments as of September 30, 2020.

[0001596532-20-000226:mdna:73]
[same as prior period, unchanged from 0001596532-20-000148:mdna:73]

[0001596532-20-000226:mdna:74]
[same as prior period, unchanged from 0001596532-20-000148:mdna:74]

[0001596532-20-000226:mdna:75]
[same as prior period, unchanged from 0001596532-20-000148:mdna:75]

[0001596532-20-000226:mdna:76]
Refer to the section(s) titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
