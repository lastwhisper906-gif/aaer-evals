# ANET 8-K — 0001596532-25-000214 filed 2025-08-05

## item codes, every 8-K on or before 2025-08-06

- 2025-08-05 0001596532-25-000214 — 2.02, 9.01
- 2025-06-16 0001596532-25-000170 — 5.02, 9.01
- 2025-06-03 0001596532-25-000148 — 5.07
- 2025-05-06 0001596532-25-000103 — 2.02, 5.02, 8.01, 9.01
- 2025-03-17 0001596532-25-000077 — 5.02, 8.01, 9.01
- 2025-02-18 0001596532-25-000018 — 2.02, 9.01
- 2024-12-03 0001596532-24-000402 — 5.03, 9.01
- 2024-11-07 0001596532-24-000366 — 2.02, 8.01, 9.01
- 2024-07-30 0001596532-24-000277 — 2.02, 9.01
- 2024-06-10 0001596532-24-000233 — 5.07
- 2024-05-24 0001596532-24-000219 — 8.01
- 2024-05-07 0001596532-24-000171 — 2.02, 8.01, 9.01
- 2024-04-23 0001596532-24-000155 — 5.02, 9.01
- 2024-04-19 0001596532-24-000152 — 5.02, 8.01
- 2024-02-28 0001596532-24-000095 — 8.01
- 2024-02-12 0001596532-24-000041 — 2.02, 9.01
- 2023-12-20 0001596532-23-000349 — 5.03, 9.01
- 2023-12-01 0001596532-23-000324 — 5.02, 8.01, 9.01
- 2023-10-30 0001596532-23-000272 — 2.02, 9.01
- 2023-07-31 0001596532-23-000196 — 2.02, 5.02, 9.01
- 2023-06-16 0001596532-23-000168 — 5.07
- 2023-05-01 0001596532-23-000101 — 2.02, 9.01
- 2023-02-13 0001596532-23-000015 — 2.02, 9.01
- 2022-10-31 0001596532-22-000292 — 2.02, 9.01
- 2022-10-25 0001596532-22-000282 — 5.03, 9.01
- 2022-08-01 0001596532-22-000218 — 2.02, 9.01
- 2022-07-25 0001596532-22-000205 — 5.02
- 2022-06-03 0001596532-22-000179 — 5.07
- 2022-05-02 0001596532-22-000111 — 2.02, 9.01
- 2022-03-29 0001596532-22-000100 — 5.02
- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2025-08-06

- none on or before 2025-08-06

## item 2.02 — earnings release, exhibit 99.1

[0001596532-25-000214:8k_2_02:1]
EX-99.1
2
ex991q225-earningsrelease.htm
EX-99.1

[0001596532-25-000214:8k_2_02:2]
Document

[0001596532-25-000214:8k_2_02:3]
Exhibit 99.1

[0001596532-25-000214:8k_2_02:4]
Arista Networks, Inc. Reports Second Quarter 2025 Financial Results

[0001596532-25-000214:8k_2_02:5]
SANTA CLARA, Calif.- August 5, 2025 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus, and routing environments, today announced financial results for its second quarter ended June 30, 2025.

[0001596532-25-000214:8k_2_02:6]
Second Quarter Financial Highlights

[0001596532-25-000214:8k_2_02:7]
"Arista is well-positioned in data-driven AI networking, from client to cloud," said Jayshree Ullal, Chairperson and CEO of Arista Networks. “Our customers are decisively standardizing on our best of breed platform to bring transformational innovation and impact to their technology endeavors.”

[0001596532-25-000214:8k_2_02:8]
•Revenue of $2.205 billion, an increase of 10.0% compared to the first quarter of 2025, and an increase of 30.4% from the second quarter of 2024.

[0001596532-25-000214:8k_2_02:9]
•GAAP gross margin of 65.2%, compared to GAAP gross margin of 63.7% in the first quarter of 2025 and 64.9% in the second quarter of 2024.

[0001596532-25-000214:8k_2_02:10]
•Non-GAAP gross margin of 65.6%, compared to non-GAAP gross margin of 64.1% in the first quarter of 2025 and 65.4% in the second quarter of 2024.

[0001596532-25-000214:8k_2_02:11]
•GAAP net income of $888.8 million, or $0.70 per diluted share, compared to GAAP net income of $665.4 million, or $0.52 per diluted share in the second quarter of 2024.

[0001596532-25-000214:8k_2_02:12]
•Non-GAAP net income of $923.5 million, or $0.73 per diluted share, compared to non-GAAP net income of $672.6 million, or $0.53 per diluted share in the second quarter of 2024.

[0001596532-25-000214:8k_2_02:13]
Commenting on the company's financial results, Chantelle Breithaupt, Arista’s CFO, said, "Non-GAAP operating income crossed $1 billion for the first time at Arista, highlighting the strength of our business model and the momentum of customer demand across our portfolio. Our ability to scale efficiently while maintaining financial discipline continues to deliver value for our shareholders."

[0001596532-25-000214:8k_2_02:14]
Upcoming 2025 Analyst Day

[0001596532-25-000214:8k_2_02:15]
Arista Networks will host its 2025 Analyst Day on Thursday, September 11, 2025, beginning at 3:00 PM PT (6:00 PM ET). Interested participants can register through the Investor Relations section of the Arista website at https://investors.arista.com/.

[0001596532-25-000214:8k_2_02:16]
Company Highlights

[0001596532-25-000214:8k_2_02:17]
•Arista Networks Expands AI-Driven Campus and Branch Networking Offerings – Arista introduced several AI-driven enterprise products that deliver an expanded set of switching, Wi-Fi 7 access point, and WAN capabilities.

[0001596532-25-000214:8k_2_02:18]
•Arista Networks Acquired the VeloCloud® SD-WAN Portfolio from Broadcom – VeloCloud expands choice and performance for Arista customers, enabling global WAN services to interconnect data centers and distributed campus/branch offices, while complementing Arista's existing CloudEOS® routing stack and high-end 7000-series WAN routers.

[0001596532-25-000214:8k_2_02:19]
•Arista Networks Recognized in the Visionaries Quadrant of the 2025 Gartner® Magic Quadrant™ for Enterprise Wired and Wireless LAN Infrastructure published on 25 June 2025 - Gartner positioned Arista Networks as the vendor with the highest Ability to Execute in the Visionaries Quadrant in the report.

[0001596532-25-000214:8k_2_02:20]
•Arista Expands Commitment to India for Enterprise Networking and AI Innovation – The ‘Make in India’ initiative drives domestic manufacturing of key campus and data center switches as well as Wi-Fi 7 access points.

[0001596532-25-000214:8k_2_02:21]
•Arista Networks appointed Todd Nightingale as President and Chief Operating Officer - Mr. Nightingale previously served as the Chief Executive Officer and member of the Board of Directors of Fastly, Inc., and before that as the Executive Vice President and General Manager of Enterprise Networking and Cloud at Cisco Systems, Inc.

[0001596532-25-000214:8k_2_02:22]
Financial Outlook

[0001596532-25-000214:8k_2_02:23]
For the third quarter of 2025, we expect:

[0001596532-25-000214:8k_2_02:24]
•Revenue of approximately $2.25 billion

[0001596532-25-000214:8k_2_02:25]
•Non-GAAP gross margin of approximately 64%; and

[0001596532-25-000214:8k_2_02:26]
•Non-GAAP operating margin of approximately 47%.

[0001596532-25-000214:8k_2_02:27]
Guidance for non-GAAP financial measures excludes certain items, including stock-based compensation expense, intangible asset amortization, and potential non-recurring charges or benefits. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis without unreasonable effort because these exclusions can be uncertain or difficult to predict, including stock-based compensation expense, which is impacted by the timing of employee stock transactions, the company’s future hiring and retention needs and the future fair market value of the company’s common stock. The actual amount of these exclusions will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-25-000214:8k_2_02:28]
Prepared Materials and Conference Call Information

[0001596532-25-000214:8k_2_02:29]
Arista's executives will discuss the second quarter 2025 financial results on a conference call today at 1:30 PM Pacific Time. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-25-000214:8k_2_02:30]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-25-000214:8k_2_02:31]
Forward-Looking Statements

[0001596532-25-000214:8k_2_02:32]
This press release contains “forward-looking statements” regarding our future performance, including but not limited to quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin, and non-GAAP operating margin for the third quarter of 2025, statements regarding Arista’s products, innovation and ability to succeed in data-driven AI networking. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including but not limited to risks associated with: escalated or escalating U.S. tariffs and countermeasures and retaliatory actions taken by affected countries; enhanced import/export restrictions, such as enhanced export controls the U.S. has adopted targeting trade with China, as well as countermeasures taken by affected countries; large purchases by a limited number of customers who represent a substantial portion of our revenue; adverse economic and geopolitical conditions and conflicts, continuing uncertain economic conditions or reduced information technology and network infrastructure spending; the impact of sole or limited sources of supply, supply shortages and extended lead times or supply changes; volatility in our revenue and revenue growth rates; variations in our results of operations; the rapid evolution of the networking market; failure to successfully carry out

[0001596532-25-000214:8k_2_02:33]
new products and service offerings and expand into adjacent markets; variability in our gross margins; intense competition and industry consolidation; expansion of our international sales and operations; investments in or acquisitions of other businesses, products or technologies; seasonality and industry cyclicality; fluctuations in currency exchange rates; failure to raise additional capital on favorable terms; our inability to attract new large customers or sell additional products and services to our existing customers; inability to grow sales of switches which generate most of our product revenue; large customers requiring more favorable terms; inability to increase market awareness or acceptance of our new products and services; decreases in the sales prices of our products and services; long and unpredictable sales cycles; inability to offer high quality support and services; declines in maintenance renewals by customers; product quality problems, defects, errors or vulnerabilities in our products; failure to anticipate technological shifts; the complexity of managing the supply of our products and product components; our reliance upon a predominant merchant silicon vendor; our dependence on third-party manufacturers to build our products; assertions by third parties of intellectual property rights infringement, misappropriation or other violations; failure or inability to protect or assert our intellectual property rights; cybersecurity incidents and breaches of our cybersecurity systems, or other security or privacy breaches or incidents; failure to comply with government law and regulations; issues in the development and use of artificial intelligence, combined with an uncertain regulatory environment; future decisions to reduce or discontinue repurchasing our common stock pursuant to our stock repurchase programs; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission, including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof, and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-25-000214:8k_2_02:34]
Non-GAAP Financial Measures

[0001596532-25-000214:8k_2_02:35]
This press release and accompanying table contain certain non-GAAP financial measures, including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, intangible asset amortization, (gains)/losses on strategic investments, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-25-000214:8k_2_02:36]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are, therefore, unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-25-000214:8k_2_02:37]
3

[0001596532-25-000214:8k_2_02:38]
Gartner®, Magic Quadrant™ for Enterprise Wired and Wireless LAN Infrastructure, Mike Leibovitz et al., 25 June 2025

[0001596532-25-000214:8k_2_02:39]
GARTNER is a registered trademark and service mark of Gartner, Inc. and/or its affiliates in the U.S. and internationally, and MAGIC QUADRANT is a registered trademark of Gartner, Inc. and/or its affiliates and are used herein with permission. All rights reserved.

[0001596532-25-000214:8k_2_02:40]
Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner’s research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001596532-25-000214:8k_2_02:41]
The Gartner content described herein (the “Gartner Content”) represents research opinion or viewpoints published, as part of a syndicated subscription service, by Gartner, Inc. ("Gartner"), and is not a representation of fact. Gartner Content speaks as of its original publication date (and not as of the date of this Earnings Press Release), and the opinions expressed in the Gartner Content are subject to change without notice.

[0001596532-25-000214:8k_2_02:42]
About Arista Networks

[0001596532-25-000214:8k_2_02:43]
Arista Networks is an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus, and routing environments. Its award-winning platforms deliver availability, agility, automation, analytics, and security through an advanced network operating stack. For more information, visit www.arista.com.

[0001596532-25-000214:8k_2_02:44]
ARISTA, CloudVision, and Etherlink are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners. Additional information and resources can be found at www.arista.com.

[0001596532-25-000214:8k_2_02:45]
ARISTA NETWORKS, INC.

[0001596532-25-000214:8k_2_02:46]
Condensed Consolidated Income Statements

[0001596532-25-000214:8k_2_02:47]
(Unaudited, in millions, except per share amounts)

[0001596532-25-000214:8k_2_02:48]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,877.0 |  |  | $ | 1,423.3 |  |  | $ | 3,569.5 |  |  | $ | 2,752.1 |  |
| Service |  | 327.8 |  |  | 267.1 |  |  | 640.1 |  |  | 509.7 |  |
| Total revenue |  | 2,204.8 |  |  | 1,690.4 |  |  | 4,209.6 |  |  | 3,261.8 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 707.3 |  |  | 540.4 |  |  | 1,380.0 |  |  | 1,062.1 |  |
| Service |  | 58.9 |  |  | 52.8 |  |  | 114.9 |  |  | 101.1 |  |
| Total cost of revenue |  | 766.2 |  |  | 593.2 |  |  | 1,494.9 |  |  | 1,163.2 |  |
| Gross profit |  | 1,438.6 |  |  | 1,097.2 |  |  | 2,714.7 |  |  | 2,098.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 296.5 |  |  | 267.5 |  |  | 562.9 |  |  | 475.9 |  |
| Sales and marketing |  | 126.5 |  |  | 104.4 |  |  | 243.1 |  |  | 209.5 |  |
| General and administrative |  | 29.4 |  |  | 25.7 |  |  | 63.7 |  |  | 53.5 |  |
| Total operating expenses |  | 452.4 |  |  | 397.6 |  |  | 869.7 |  |  | 738.9 |  |
| Income from operations |  | 986.2 |  |  | 699.6 |  |  | 1,845.0 |  |  | 1,359.7 |  |
| Other income (expense), net |  | 94.0 |  |  | 70.8 |  |  | 190.2 |  |  | 133.5 |  |
| Income before income taxes |  | 1,080.2 |  |  | 770.4 |  |  | 2,035.2 |  |  | 1,493.2 |  |
| Provision for income taxes |  | 191.4 |  |  | 105.0 |  |  | 332.6 |  |  | 190.1 |  |
| Net income |  | $ | 888.8 |  |  | $ | 665.4 |  |  | $ | 1,702.6 |  |  | $ | 1,303.1 |  |
| Net income per share (1): |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.71 |  |  | $ | 0.53 |  |  | $ | 1.35 |  |  | $ | 1.04 |  |
| Diluted |  | $ | 0.70 |  |  | $ | 0.52 |  |  | $ | 1.34 |  |  | $ | 1.02 |  |
| Weighted-average shares used in computing net income per share(1): |  |  |  |  |  |  |  |  |
| Basic |  | 1,256.3 |  |  | 1,254.8 |  |  | 1,258.2 |  |  | 1,253.5 |  |
| Diluted |  | 1,271.2 |  |  | 1,279.7 |  |  | 1,275.2 |  |  | 1,279.6 |  |

[0001596532-25-000214:8k_2_02:49]
(1) Prior period results have been adjusted to reflect the four-for-one stock split effected in December 2024.

[0001596532-25-000214:8k_2_02:50]
5

[0001596532-25-000214:8k_2_02:51]
ARISTA NETWORKS, INC.

[0001596532-25-000214:8k_2_02:52]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-25-000214:8k_2_02:53]
(Unaudited, in millions, except percentages and per share amounts)

[0001596532-25-000214:8k_2_02:54]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| GAAP gross profit |  | $ | 1,438.6 |  |  | $ | 1,097.2 |  |  | $ | 2,714.7 |  |  | $ | 2,098.6 |  |
| GAAP gross margin |  | 65.2 | % |  | 64.9 | % |  | 64.5 | % |  | 64.3 | % |
| Stock-based compensation expense |  | 5.8 |  |  | 4.0 |  |  | 11.3 |  |  | 7.4 |  |
| Intangible asset amortization |  | 2.6 |  |  | 4.2 |  |  | 5.8 |  |  | 8.4 |  |
| Non-GAAP gross profit |  | $ | 1,447.0 |  |  | $ | 1,105.4 |  |  | $ | 2,731.8 |  |  | $ | 2,114.4 |  |
| Non-GAAP gross margin |  | 65.6 | % |  | 65.4 | % |  | 64.9 | % |  | 64.8 | % |
| GAAP income from operations |  | $ | 986.2 |  |  | $ | 699.6 |  |  | $ | 1,845.0 |  |  | $ | 1,359.7 |  |
| GAAP operating margin |  | 44.7 | % |  | 41.4 | % |  | 43.8 | % |  | 41.7 | % |
| Stock-based compensation expense |  | 85.2 |  |  | 79.3 |  |  | 178.2 |  |  | 156.5 |  |
| Intangible asset amortization |  | 5.0 |  |  | 6.7 |  |  | 10.6 |  |  | 13.4 |  |
| Non-GAAP income from operations |  | $ | 1,076.4 |  |  | $ | 785.6 |  |  | $ | 2,033.8 |  |  | $ | 1,529.6 |  |
| Non-GAAP operating margin |  | 48.8 | % |  | 46.5 | % |  | 48.3 | % |  | 46.9 | % |
| GAAP net income |  | $ | 888.8 |  |  | $ | 665.4 |  |  | $ | 1,702.6 |  |  | $ | 1,303.1 |  |
| Stock-based compensation expense |  | 85.2 |  |  | 79.3 |  |  | 178.2 |  |  | 156.5 |  |
| Intangible asset amortization |  | 5.0 |  |  | 6.7 |  |  | 10.6 |  |  | 13.4 |  |
| (Gains)/losses on strategic investments |  | (5.4) |  |  | — |  |  | (10.9) |  |  | — |  |
| Tax benefits on stock-based awards |  | (41.6) |  |  | (64.6) |  |  | (107.7) |  |  | (135.3) |  |
| Income tax effect on non-GAAP exclusions |  | (8.5) |  |  | (14.2) |  |  | (23.1) |  |  | (27.3) |  |
| Non-GAAP net income |  | $ | 923.5 |  |  | $ | 672.6 |  |  | $ | 1,749.7 |  |  | $ | 1,310.4 |  |
| GAAP diluted net income per share (1) |  | $ | 0.70 |  |  | $ | 0.52 |  |  | $ | 1.34 |  |  | $ | 1.02 |  |
| Non-GAAP adjustments to net income (1) |  | 0.03 |  |  | 0.01 |  |  | 0.03 |  |  | — |  |
| Non-GAAP diluted net income per share (1) |  | $ | 0.73 |  |  | $ | 0.53 |  |  | $ | 1.37 |  |  | $ | 1.02 |  |
| Weighted-average shares used in computing diluted net income per share (1) |  | 1,271.2 |  |  | 1,279.7 |  |  | 1,275.2 |  |  | 1,279.6 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 5.8 |  |  | $ | 4.0 |  |  | $ | 11.3 |  |  | $ | 7.4 |  |
| Research and development |  | 53.2 |  |  | 50.7 |  |  | 110.2 |  |  | 94.5 |  |
| Sales and marketing |  | 18.8 |  |  | 16.8 |  |  | 38.7 |  |  | 35.7 |  |
| General and administrative |  | 7.4 |  |  | 7.8 |  |  | 18.0 |  |  | 18.9 |  |
| Total |  | $ | 85.2 |  |  | $ | 79.3 |  |  | $ | 178.2 |  |  | $ | 156.5 |  |

[0001596532-25-000214:8k_2_02:55]
(1) Prior period results have been adjusted to reflect the four-for-one stock split effected in December 2024.

[0001596532-25-000214:8k_2_02:56]
ARISTA NETWORKS, INC.

[0001596532-25-000214:8k_2_02:57]
Condensed Consolidated Balance Sheets

[0001596532-25-000214:8k_2_02:58]
(Unaudited, in millions)

[0001596532-25-000214:8k_2_02:59]
|  |  | June 30, 2025 |  | December 31, 2024 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,225.5 |  |  | $ | 2,762.4 |  |
| Marketable securities |  | 6,618.9 |  |  | 5,541.1 |  |
| Accounts receivable |  | 1,623.6 |  |  | 1,140.5 |  |
| Inventories |  | 2,059.1 |  |  | 1,834.6 |  |
| Prepaid expenses and other current assets |  | 976.4 |  |  | 632.3 |  |
| Total current assets |  | 13,503.5 |  |  | 11,910.9 |  |
| Property and equipment, net |  | 152.3 |  |  | 98.8 |  |
| Goodwill |  | 416.5 |  |  | 268.5 |  |
| Deferred tax assets |  | 1,802.5 |  |  | 1,440.4 |  |
| Other assets |  | 659.4 |  |  | 325.3 |  |
| TOTAL ASSETS |  | $ | 16,534.2 |  |  | $ | 14,043.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 543.9 |  |  | $ | 381.1 |  |
| Accrued liabilities |  | 380.7 |  |  | 435.3 |  |
| Deferred revenue |  | 2,787.6 |  |  | 1,727.3 |  |
| Other current liabilities |  | 339.2 |  |  | 188.5 |  |
| Total current liabilities |  | 4,051.4 |  |  | 2,732.2 |  |
| Deferred revenue, non-current |  | 1,274.1 |  |  | 1,064.1 |  |
| Other long-term liabilities |  | 307.1 |  |  | 252.8 |  |
| TOTAL LIABILITIES |  | 5,632.6 |  |  | 4,049.1 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital |  | 2,635.6 |  |  | 2,465.4 |  |
| Retained earnings |  | 8,262.1 |  |  | 7,542.5 |  |
| Accumulated other comprehensive income (loss) |  | 3.8 |  |  | (13.2) |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 10,901.6 |  |  | 9,994.8 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 16,534.2 |  |  | $ | 14,043.9 |  |

[0001596532-25-000214:8k_2_02:60]
7

[0001596532-25-000214:8k_2_02:61]
ARISTA NETWORKS, INC.

[0001596532-25-000214:8k_2_02:62]
Condensed Consolidated Statements of Cash Flows

[0001596532-25-000214:8k_2_02:63]
(Unaudited, in millions)

[0001596532-25-000214:8k_2_02:64]
|  |  | Six Months Ended June 30, |
|  |  | 2025 |  | 2024 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 1,702.6 |  |  | $ | 1,303.1 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 26.6 |  |  | 31.1 |  |
| Stock-based compensation |  | 178.2 |  |  | 156.5 |  |
| Deferred income taxes |  | (337.9) |  |  | (228.5) |  |
| Other |  | (21.0) |  |  | (18.5) |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (483.1) |  |  | (202.2) |  |
| Inventories |  | (224.5) |  |  | 91.4 |  |
| Other assets |  | (403.2) |  |  | (92.6) |  |
| Accounts payable |  | 160.0 |  |  | (136.2) |  |
| Deferred revenue |  | 1,141.4 |  |  | 612.6 |  |
| Income taxes, net |  | 152.4 |  |  | 74.1 |  |
| Other liabilities |  | (49.7) |  |  | (88.0) |  |
| Net cash provided by operating activities |  | 1,841.8 |  |  | 1,502.8 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 1,651.2 |  |  | 952.6 |  |
| Proceeds from sale of marketable securities |  | 15.9 |  |  | 36.8 |  |
| Purchases of marketable securities |  | (2,705.7) |  |  | (1,749.3) |  |
| Purchases of property and equipment |  | (52.4) |  |  | (12.6) |  |
| Cash paid for business combinations, net of cash acquired |  | (300.0) |  |  | — |  |
| Other |  | — |  |  | (1.0) |  |
| Net cash used in investing activities |  | (1,391.0) |  |  | (773.5) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 31.3 |  |  | 34.5 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (39.3) |  |  | (36.0) |  |
| Repurchases of common stock |  | (983.0) |  |  | (234.7) |  |
| Net cash used in financing activities |  | (991.0) |  |  | (236.2) |  |
| Effect of exchange rate changes |  | 3.3 |  |  | (2.7) |  |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | (536.9) |  |  | 490.4 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 2,763.8 |  |  | 1,939.5 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 2,226.9 |  |  | $ | 2,429.9 |  |

[0001596532-25-000214:8k_2_02:65]
| Investor Contacts: |  |
| Arista Networks, Inc. |
| Investor Advocacy |
| Rudolph Araujo |  |
| Rod Hall |  |
| +1 (408) 547-8080 |  |
| ir@arista.com |
