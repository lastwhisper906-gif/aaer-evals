# ANET MD&A — 0001596532-25-000216


## mdna

[0001596532-25-000216:mdna:1]
[same as prior period, unchanged from 0001596532-25-000106:mdna:1]

[0001596532-25-000216:mdna:2]
[same as prior period, unchanged from 0001596532-25-000106:mdna:2]

[0001596532-25-000216:mdna:3]
Arista Networks is an industry leader in data-driven, client to cloud networking for large AI, data center, campus and routing environments. Arista's platforms deliver availability, agility, automation, analytics and security through an advanced network operating stack. Since Arista’s inception, our founders have reimagined cloud networks for performance, scale and programmability with a focus on differentiating in three ways: uncompromising reliability built on the foundation of robust quality assurance capabilities with a suite of automated diagnostics, advanced open and standards-based technology and intelligent automation to decrease the manual workload on the operator. At the core of Arista’s platform is Arista EOS, a modernized publish-subscribe state-sharing networking operating system. Arista EOS, combined with a set of network applications and our Ethernet switching and routing platforms using best of breed merchant silicon, provides customers with a highly competitive and diversified portfolio of products with improved price/performance and time to market.

[0001596532-25-000216:mdna:4]
[same as prior period, unchanged from 0001596532-25-000106:mdna:5]

[0001596532-25-000216:mdna:5]
The markets for cloud networking solutions are highly competitive and characterized by rapidly changing technology, changing end-customer needs, evolving industry standards, frequent introductions of new products and services, and industry consolidation. We expect competition to intensify in the future as the market for cloud networking expands and existing competitors and new market entrants introduce new products or enhance existing products. Our future success is dependent upon our ability to continue to evolve and adapt to our rapidly changing environment. We must also continue to develop market-leading products and software features that address the changing needs of our existing and new customers, and increase sales in the cloud, AI and enterprise data center Ethernet switching/routing markets, and campus workspace markets. We believe one of our greatest strengths lies in our ability to rapidly develop new features and applications. In addition, we intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new customers more effectively, increase sales to existing customers, and provide services and support. Furthermore, we expect to continue to make substantial investments to introduce new products and services and enhance the functionality of our existing cloud networking platform through investments in our research and development organization, and investments in or acquisitions of complementary companies, products and technologies to expand our product offerings and build upon our technology leadership. During the current quarter we completed the acquisition of the VeloCloud business from Broadcom. VeloCloud’s secure, AI-optimized cloud WAN portfolio provides seamless connectivity to customer sites of any type, complementing Arista’s leading data center and campus wired/wireless portfolio. We believe the combination of Arista and VeloCloud will provide modern WAN solutions for our customers globally.

[0001596532-25-000216:mdna:6]
[same as prior period, unchanged from 0001596532-25-000106:mdna:7]

[0001596532-25-000216:mdna:7]
Historically, large purchases by a relatively limited number of customers have accounted for a significant portion of our revenue. We have experienced unpredictability in the timing of orders from these large customers primarily due to the time it takes these customers to evaluate, test, qualify and accept our newer products, the overall complexity of these large orders and changes in demand patterns specific to these customers, including reductions in or changes in mix of capital expenditures by these customers and the impact of cost reduction and other efficiency efforts by these customers. For example, sales to our end

[0001596532-25-000216:mdna:8]
customer Microsoft represented 20%, 18% and 16% of our total revenue for the years ended 2024, 2023 and 2022, respectively. And sales to our end customer Meta Platforms represented 15%, 21% and 26% of our total revenue, respectively, for the years ended 2024, 2023 and 2022. This variability in customer concentration has been linked to the timing of new product deployments and spending cycles with these customers, and we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. In addition, we typically provide pricing discounts to large customers, which reduces gross margins for the period in which such sales occur.

[0001596532-25-000216:mdna:9]
We believe an increased focus on the deployment of AI enabled solutions by our large customers has accelerated the need for advanced technology offerings, including some offerings from potential new market entrants.  This prioritization and acceleration of AI related infrastructure investment has at times come in conjunction with a reduction or changes in the mix of previously planned purchases and various cost reduction measures by these customers, including optimization and increased efficiency in non-AI related capital expenditures. In addition, although the focus on deployment of AI enabled solutions has driven increased demand for networking, the long-term trajectory is unknown. As such, demand estimates for our new products are difficult to forecast and can create volatility in our revenue. In some instances, such measures have had, and may continue to have, an impact on certain current or future projects and have reduced our visibility to customer demand and may result in a reduction or uncertainty in the timing of orders from these large customers and increase the risk of charges for excess and obsolete inventory. We remain in a period of new product introductions and expanded use cases, particularly in the AI Ethernet market. This has resulted in increased customer trials and contracts with acceptance periods, and an increase in the volatility and magnitude of our product deferred revenue balances, which in turn may create variability in our revenue results on a quarterly and annual basis. In addition, if we are not able to satisfy the requirements under customer trials or contracts with acceptance periods, we may be required to accept product returns from our customers, which would prevent us from recognizing revenue on such transactions and may result in the write-down of inventory.

[0001596532-25-000216:mdna:10]
[same as prior period, unchanged from 0001596532-25-000106:mdna:11]

[0001596532-25-000216:mdna:11]
[same as prior period, unchanged from 0001596532-25-000106:mdna:12]

[0001596532-25-000216:mdna:12]
We are working closely with our contract manufacturers and suppliers to optimize our supply chain and production efforts in response to the uncertainty around international trade policy and tariff rates to minimize the impact of the tariffs and any impact on the supply chain of components sourced from affected countries. While our supply chain has currently not experienced a significant disruption as a result of the recent trade measures, the extent of such policies and tariffs that will ultimately be implemented is unknown at this time, and the future impact to our supply chain and cost of our products is uncertain. We continue to ship products against previously committed demand/deployment plans and accelerate some deployments where needed, while trying to balance our customers' requirements and lead times with the availability of key components and products and lead times of our key suppliers and contract manufacturers. Given the timing and prioritization of customer orders and shipment patterns, as well as the timing and outcome of customer trials and contracts with acceptance periods, near term revenue trends may not be reflective of current demand levels, and could benefit from demand/deployment plans that have been previously committed. We expect that our inventory and purchase commitments will remain volatile as we ramp new product introductions. The magnitude of these balances and shifting customer product priorities, has resulted in an increased risk that we may not be able to sell all of this inventory, which in turn has resulted in excess and obsolete inventory and may result in additional charges to excess and obsolete inventory and supplier liability. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. These cost pressures may be increased if escalating tariff and non-tariff international trade measures continue to affect our supply chain. We also may not be able to fully mitigate the cost impacts of escalating tariff and non-tariff international trade measures or be able to pass on the full burden of the increase in trade-related costs to our customers, which could further negatively impact our gross margin. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods.

[0001596532-25-000216:mdna:13]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. In addition, any continued or renewed disruption in manufacturing and supply and uncertainty about international trade policy and tariff rates could negatively impact our business, and as a result we may face challenges in implementing countermeasures and responding to these changing trading conditions. Furthermore, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration.

[0001596532-25-000216:mdna:14]
Accordingly, current results and financial conditions discussed herein may not be indicative of future operating results and trends.

[0001596532-25-000216:mdna:15]
[same as prior period, unchanged from 0001596532-25-000106:mdna:16]

[0001596532-25-000216:mdna:16]
Three and Six Months Ended June 30, 2025 Compared to Three and Six Months Ended June 30, 2024

[0001596532-25-000216:mdna:17]
[same as prior period, unchanged from 0001596532-25-000106:mdna:18]

[0001596532-25-000216:mdna:18]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2025 |  | 2024 |  | Change in |  | 2025 |  | 2024 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,877.0 |  |  | $ | 1,423.3 |  |  | $ | 453.7 |  |  | 31.9 | % |  | $ | 3,569.5 |  |  | $ | 2,752.1 |  |  | $ | 817.4 |  |  | 29.7 | % |
| Service |  | 327.8 |  |  | 267.1 |  |  | 60.7 |  |  | 22.7 |  |  | 640.1 |  |  | 509.7 |  |  | 130.4 |  |  | 25.6 |  |
| Total revenue |  | 2,204.8 |  |  | 1,690.4 |  |  | 514.4 |  |  | 30.4 |  |  | 4,209.6 |  |  | 3,261.8 |  |  | 947.8 |  |  | 29.1 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 707.3 |  |  | 540.4 |  |  | 166.9 |  |  | 30.9 |  |  | 1,380.0 |  |  | 1,062.1 |  |  | 317.9 |  |  | 29.9 |  |
| Service |  | 58.9 |  |  | 52.8 |  |  | 6.1 |  |  | 11.6 |  |  | 114.9 |  |  | 101.1 |  |  | 13.8 |  |  | 13.6 |  |
| Total cost of revenue |  | 766.2 |  |  | 593.2 |  |  | 173.0 |  |  | 29.2 |  |  | 1,494.9 |  |  | 1,163.2 |  |  | 331.7 |  |  | 28.5 |  |
| Gross profit |  | $ | 1,438.6 |  |  | $ | 1,097.2 |  |  | $ | 341.4 |  |  | 31.1 | % |  | $ | 2,714.7 |  |  | $ | 2,098.6 |  |  | $ | 616.1 |  |  | 29.4 | % |
| Gross margin |  | 65.2 | % |  | 64.9 | % |  |  |  |  |  | 64.5 | % |  | 64.3 | % |  |  |  |  |

[0001596532-25-000216:mdna:19]
[same as prior period, unchanged from 0001596532-25-000106:mdna:20]

[0001596532-25-000216:mdna:20]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2025 |  | % of Total |  | 2024 |  | % of Total |  | 2025 |  | % of Total |  | 2024 |  | % of Total |
| Americas |  | $ | 1,724.1 |  |  | 78.2 | % |  | $ | 1,374.2 |  |  | 81.3 | % |  | $ | 3,322.6 |  |  | 79.0 | % |  | $ | 2,629.6 |  |  | 80.6 | % |
| Europe, Middle East and Africa |  | 281.6 |  |  | 12.8 |  |  | 178.8 |  |  | 10.6 |  |  | 456.2 |  |  | 10.8 |  |  | 320.4 |  |  | 9.8 |  |
| Asia-Pacific |  | 199.1 |  |  | 9.0 |  |  | 137.4 |  |  | 8.1 |  |  | 430.8 |  |  | 10.2 |  |  | 311.8 |  |  | 9.6 |  |
| Total revenue |  | $ | 2,204.8 |  |  | 100.0 | % |  | $ | 1,690.4 |  |  | 100.0 | % |  | $ | 4,209.6 |  |  | 100.0 | % |  | $ | 3,261.8 |  |  | 100.0 | % |

[0001596532-25-000216:mdna:21]
[same as prior period, unchanged from 0001596532-25-000106:mdna:22]

[0001596532-25-000216:mdna:22]
Product revenue primarily consists of sales of our switching and routing products, and related network applications. Service revenue is primarily derived from sales of post-contract support ("PCS"), which are typically purchased in conjunction with our products, and subsequent renewals of those contracts. We expect our revenue may vary from period to period based on, among other things, the timing, size, and complexity of orders, especially with respect to our large customers.

[0001596532-25-000216:mdna:23]
Product revenue increased by $453.7 million, or 31.9%, and $817.4 million, or 29.7% for the three and six months ended June 30, 2025, compared to the same periods in 2024. This increase reflects increased demand for our switching and routing platforms across our customer base. In addition, service revenue increased by $60.7 million, or 22.7%, and $130.4 million, or 25.6% for the three and six months ended June 30, 2025, compared to the same periods in 2024, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenue represented 21.8% and 21.0% of total revenue for the three and six months ended June 30, 2025, increasing from 18.7% and 19.4% for the same periods in the prior year, which was primarily influenced by changes in the geographic mix of sales to our large global customers.

[0001596532-25-000216:mdna:24]
[same as prior period, unchanged from 0001596532-25-000106:mdna:25]

[0001596532-25-000216:mdna:25]
[same as prior period, unchanged from 0001596532-25-000106:mdna:26]

[0001596532-25-000216:mdna:26]
Cost of revenue increased by $173.0 million, or 29.2%, and $331.7 million, or 28.5% for the three and six months ended June 30, 2025, compared to the same periods in 2024. These increases were primarily driven by a corresponding increase in product and service revenues.

[0001596532-25-000216:mdna:27]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including pricing pressure on our products and services due to competition, the mix of sales to large end customers who generally receive lower pricing, the mix of products sold, manufacturing-related costs, including costs associated with managing our inventory and supply chain, merchant silicon costs, and excess/obsolete inventory and supplier liability charges. We expect our gross margin to fluctuate over time depending on the factors described above and may be adversely impacted by unpredictable international trade policy and tariff rates.

[0001596532-25-000216:mdna:28]
Gross margin increased from 64.9% to 65.2% for the three months ended June 30, 2025, and increased from 64.3% to 64.5% for the six months ended June 30, 2025, compared to the same periods in 2024. These changes are primarily driven by improved inventory management resulting in lower excess and obsolescence charges.

[0001596532-25-000216:mdna:29]
[same as prior period, unchanged from 0001596532-25-000106:mdna:31]

[0001596532-25-000216:mdna:30]
[same as prior period, unchanged from 0001596532-25-000106:mdna:32]

[0001596532-25-000216:mdna:31]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2025 |  | 2024 |  | Change in |  | 2025 |  | 2024 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 296.5 |  |  | $ | 267.5 |  |  | $ | 29.0 |  |  | 10.8 | % |  | $ | 562.9 |  |  | $ | 475.9 |  |  | $ | 87.0 |  |  | 18.3 | % |
| Sales and marketing |  | 126.5 |  |  | 104.4 |  |  | 22.1 |  |  | 21.2 |  |  | 243.1 |  |  | 209.5 |  |  | 33.6 |  |  | 16.0 |  |
| General and administrative |  | 29.4 |  |  | 25.7 |  |  | 3.7 |  |  | 14.4 |  |  | 63.7 |  |  | 53.5 |  |  | 10.2 |  |  | 19.1 |  |
| Total operating expenses |  | $ | 452.4 |  |  | $ | 397.6 |  |  | $ | 54.8 |  |  | 13.8 | % |  | $ | 869.7 |  |  | $ | 738.9 |  |  | $ | 130.8 |  |  | 17.7 | % |

[0001596532-25-000216:mdna:32]
[same as prior period, unchanged from 0001596532-25-000106:mdna:34]

[0001596532-25-000216:mdna:33]
[same as prior period, unchanged from 0001596532-25-000106:mdna:35]

[0001596532-25-000216:mdna:34]
Research and development expenses increased by $29.0 million, or 10.8%, and $87.0 million, or 18.3% for the three and six months ended June 30, 2025, compared to the same periods in 2024. The increase for the six months period was primarily driven by a $33.9 million increase in personnel costs due to headcount growth, and a $37.0 million increase in new product introduction costs, including non-recurring engineering costs as we expand our product portfolio.

[0001596532-25-000216:mdna:35]
[same as prior period, unchanged from 0001596532-25-000106:mdna:37]

[0001596532-25-000216:mdna:36]
[same as prior period, unchanged from 0001596532-25-000106:mdna:38]

[0001596532-25-000216:mdna:37]
Sales and marketing expenses increased by $22.1 million, or 21.2%, and $33.6 million, or 16.0% for the three and six months ended June 30, 2025, compared to the same periods in 2024, which was primarily driven by increased personnel costs due to headcount growth.

[0001596532-25-000216:mdna:38]
[same as prior period, unchanged from 0001596532-25-000106:mdna:40]

[0001596532-25-000216:mdna:39]
[same as prior period, unchanged from 0001596532-25-000106:mdna:41]

[0001596532-25-000216:mdna:40]
General and administrative expenses increased by $3.7 million, or 14.4%, and $10.2 million, or 19.1% for the three and six months ended June 30, 2025, compared to the same periods in 2024, which was primarily driven by increased personnel costs.

[0001596532-25-000216:mdna:41]
[same as prior period, unchanged from 0001596532-25-000106:mdna:43]

[0001596532-25-000216:mdna:42]
[same as prior period, unchanged from 0001596532-25-000106:mdna:44]

[0001596532-25-000216:mdna:43]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2025 |  | 2024 |  | Change in |  | 2025 |  | 2024 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 90.4 |  |  | $ | 71.4 |  |  | $ | 19.0 |  |  | 26.6 | % |  | $ | 180.6 |  |  | $ | 135.3 |  |  | $ | 45.3 |  |  | 33.5 | % |
| Other income (expense), net |  | 3.6 |  |  | (0.6) |  |  | 4.2 |  |  | 700.0 |  |  | 9.6 |  |  | (1.8) |  |  | 11.4 |  |  | 633.3 |  |
| Total other income (expense), net |  | $ | 94.0 |  |  | $ | 70.8 |  |  | $ | 23.2 |  |  | 32.8 | % |  | $ | 190.2 |  |  | $ | 133.5 |  |  | $ | 56.7 |  |  | 42.5 | % |

[0001596532-25-000216:mdna:44]
The favorable movement in other income (expense), net, during the three and six months ended June 30, 2025 compared to the same periods in 2024 was primarily driven by increased interest income of $19.0 million and $45.3 million due to an increase in our cash and marketable securities balances.

[0001596532-25-000216:mdna:45]
[same as prior period, unchanged from 0001596532-25-000106:mdna:47]

[0001596532-25-000216:mdna:46]
[same as prior period, unchanged from 0001596532-25-000106:mdna:48]

[0001596532-25-000216:mdna:47]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2025 |  | 2024 |  | Change in |  | 2025 |  | 2024 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Income before income taxes |  | $ | 1,080.2 |  |  | $ | 770.4 |  |  | $ | 309.8 |  |  | 40.2 | % |  | $ | 2,035.2 |  |  | $ | 1,493.2 |  |  | $ | 542.0 |  |  | 36.3 | % |
| Provision for income taxes |  | 191.4 |  |  | 105.0 |  |  | 86.4 |  |  | 82.3 | % |  | 332.6 |  |  | 190.1 |  |  | 142.5 |  |  | 75.0 | % |
| Effective tax rate |  | 17.7 | % |  | 13.6 | % |  |  |  |  |  | 16.3 | % |  | 12.7 | % |  |  |  |  |

[0001596532-25-000216:mdna:48]
The increase in the effective tax rates in the three and six months ended June 30, 2025, as compared to the same periods in 2024, was primarily due to a decrease in tax benefits attributable to equity-based compensation.

[0001596532-25-000216:mdna:49]
[same as prior period, unchanged from 0001596532-25-000106:mdna:51]

[0001596532-25-000216:mdna:50]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of June 30, 2025, our total balance of cash, cash equivalents and marketable securities was approximately $8.8 billion, of which approximately $371.8 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-25-000216:mdna:51]
Our cash, cash equivalents and marketable securities are held for general business purposes, including the funding of working capital. Our marketable securities investment portfolio is primarily invested in highly-rated securities, with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations, will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, stock repurchases, and capital expenditures, including the ongoing construction of a building for office, lab and data center space. In addition, we expect that our inventory and purchase commitments will remain volatile as we ramp new product introductions. In particular, we have increased our purchase commitments to respond to the rapid deployment of AI networks and reduce overall lead times which may increase our working capital requirements. If we require or elect to seek additional capital through debt or equity financing in the future, we may not

[0001596532-25-000216:mdna:52]
be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-25-000216:mdna:53]
[same as prior period, unchanged from 0001596532-25-000106:mdna:54]

[0001596532-25-000216:mdna:54]
|  |  | Six Months Ended June 30, |
|  |  | 2025 |  | 2024 |
| Cash provided by operating activities |  | $ | 1,841.8 |  |  | $ | 1,502.8 |  |
| Cash used in investing activities |  | (1,391.0) |  |  | (773.5) |  |
| Cash used in financing activities |  | (991.0) |  |  | (236.2) |  |
| Effect of exchange rate changes |  | 3.3 |  |  | (2.7) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | (536.9) |  |  | $ | 490.4 |  |

[0001596532-25-000216:mdna:55]
[same as prior period, unchanged from 0001596532-25-000106:mdna:56]

[0001596532-25-000216:mdna:56]
During the six months ended June 30, 2025, cash provided by operating activities was $1.8 billion, consisting of net income of $1.7 billion along with a net decrease of $293.3 million in working capital requirements, offset by non-cash adjustments to net income of $154.1 million. The decrease in working capital requirements primarily consisted of an increase in deferred revenue of $1.1 billion primarily resulting from an increase in customer PCS contracts and an increase in product deferred revenue related to customer contracts with acceptance terms, a $152.4 million increase in income tax payables related to timing of payments, and a $110.3 million increase in accounts payable and other liabilities primarily due to timing of inventory-related receipts and payments. These cash inflows were partially offset by an increase in accounts receivable of $483.1 million due to increased product and service billings,  a $224.5 million increase in inventory and a $403.2 million increase in other assets driven by increased deferred cost of sales associated with higher product revenue deferrals. The non-cash adjustments to net income were driven by a $337.9 million increase in deferred taxes primarily due to the increase in deferred revenue and the capitalization of research and development costs under Section 174 of the Internal Revenue Code ("IRC"), largely offset by stock-based compensation of $178.2 million.

[0001596532-25-000216:mdna:57]
During the six months ended June 30, 2024, cash provided by operating activities was $1.5 billion, consisting of net income of $1.3 billion along with a net decrease in working capital requirements of $259.1 million, offset partially by non-cash adjustments to net income of $59.4 million. The decrease in working capital requirements primarily consisted of an increase in deferred revenue of $612.6 million resulting from an increase in customer PCS contracts and an increase in product deferred revenue related to customer contracts with acceptance terms, a $91.4 million decrease in inventory resulting from strong product shipments, and a $74.1 million increase in income tax payables, net related to timing of payments. These cash inflows were partially offset by a $223.3 million decrease in accounts payable and accrued liabilities primarily due to timing of inventory-related receipts and payments, as well as a reduction in other accrued liabilities, an increase in accounts receivable of $202.2 million due to increased product and service billings, and a $92.6 million increase in other assets driven by increased deferred cost of sales associated with higher product revenue deferrals and an increase in contract assets and other miscellaneous receivables. The non-cash adjustments to net income were driven by a $228.5 million increase in deferred taxes primarily due to the increase in deferred revenue and the capitalization of research and development costs under Section 174 of the Internal Revenue Code ("IRC"), largely offset by stock-based compensation of $156.5 million.

[0001596532-25-000216:mdna:58]
[same as prior period, unchanged from 0001596532-25-000106:mdna:59]

[0001596532-25-000216:mdna:59]
During the six months ended June 30, 2025, cash used in investing activities was $1.4 billion, consisting of  purchases of marketable securities of $2.7 billion and $300.0 million for the business acquisition of VeloCloud. These amounts were partially offset by proceeds from maturities and sales of marketable securities of $1.7 billion.

[0001596532-25-000216:mdna:60]
During the six months ended June 30, 2024, cash used in investing activities was $773.5 million, primarily consisting of purchases of available-for-sale securities of $1.7 billion, partly offset by proceeds from maturities and sales of marketable securities of $989.3 million.

[0001596532-25-000216:mdna:61]
[same as prior period, unchanged from 0001596532-25-000106:mdna:62]

[0001596532-25-000216:mdna:62]
During the six months ended June 30, 2025, cash used in financing activities was $991.0 million, consisting of payments for repurchases of our common stock from the open market of $983.0 million.

[0001596532-25-000216:mdna:63]
During the six months ended June 30, 2024, cash used in financing activities was $236.2 million, consisting of payments for repurchases of our common stock from the open market of $234.7 million, and employee taxes withheld and paid of $36.0 million upon vesting of restricted stock units, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $34.5 million.

[0001596532-25-000216:mdna:64]
[same as prior period, unchanged from 0001596532-25-000106:mdna:65]

[0001596532-25-000216:mdna:65]
From time to time, we repurchase shares of our common stock pursuant to repurchase programs that are funded from working capital. The Prior Repurchase Program, which allowed for stock repurchases of up to $1.2 billion, was completed in May 2025, and the New Repurchase Program allows for repurchases of an additional $1.5 billion. The New Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the Company at any time without prior notice. During the three months ended June 30, 2025, we repurchased a total of $133.9 million of our common stock under our Prior Repurchase Program and $62.0 million of our common stock under our New Repurchase Program. During the six months ended June 30, 2025, we repurchased a total of $921.0 million of our common stock under our Prior Repurchase Program and $62.0 million of our common stock under our New Repurchase Program. As of June 30, 2025, the remaining authorized amount for repurchases under the New Repurchase Program was $1.4 billion. Refer to Note 6. Stockholders' Equity and Stock-Based Compensation of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-25-000216:mdna:66]
[same as prior period, unchanged from 0001596532-25-000106:mdna:68]

[0001596532-25-000216:mdna:67]
[same as prior period, unchanged from 0001596532-25-000106:mdna:69]

[0001596532-25-000216:mdna:68]
[same as prior period, unchanged from 0001596532-25-000106:mdna:70]

[0001596532-25-000216:mdna:69]
[same as prior period, unchanged from 0001596532-25-000106:mdna:71]

[0001596532-25-000216:mdna:70]
Purchase obligations not recorded on our balance sheet represent an estimate of all non-cancellable open purchase orders and contractual obligations, made either directly by Arista or by our contract manufacturers on our behalf, in the ordinary course of business for which we have not received the goods or services. As of June 30, 2025, we had $3.6 billion of such purchase obligations, of which $3.1 billion are expected to be received within one year, and $0.5 billion are expected to be received after one year. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-25-000216:mdna:71]
Property Project

[0001596532-25-000216:mdna:72]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office, lab and data center space. The estimated remaining capital expenditures related to this project are expected to be approximately $190.0 million to $215.0 million through the end of fiscal 2026 when construction is expected to be completed.

[0001596532-25-000216:mdna:73]
[same as prior period, unchanged from 0001596532-25-000106:mdna:75]

[0001596532-25-000216:mdna:74]
As of June 30, 2025, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-25-000216:mdna:75]
[same as prior period, unchanged from 0001596532-25-000106:mdna:77]

[0001596532-25-000216:mdna:76]
[same as prior period, unchanged from 0001596532-25-000106:mdna:78]

[0001596532-25-000216:mdna:77]
[same as prior period, unchanged from 0001596532-25-000106:mdna:79]

[0001596532-25-000216:mdna:78]
[same as prior period, unchanged from 0001596532-25-000106:mdna:80]
