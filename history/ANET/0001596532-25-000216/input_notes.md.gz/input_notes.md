# ANET notes — 0001596532-25-000216


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-25-000216:notes:1]
[same as prior period, unchanged from 0001596532-25-000106:notes:1]

[0001596532-25-000216:notes:2]
[same as prior period, unchanged from 0001596532-25-000106:notes:2]

[0001596532-25-000216:notes:3]
[same as prior period, unchanged from 0001596532-25-000106:notes:3]

[0001596532-25-000216:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2025, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2024 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated. Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.

[0001596532-25-000216:notes:5]
[same as prior period, unchanged from 0001596532-25-000106:notes:5]

[0001596532-25-000216:notes:6]
[same as prior period, unchanged from 0001596532-25-000106:notes:6]

[0001596532-25-000216:notes:7]
[same as prior period, unchanged from 0001596532-25-000106:notes:7]

[0001596532-25-000216:notes:8]
[same as prior period, unchanged from 0001596532-25-000106:notes:8]

[0001596532-25-000216:notes:9]
[same as prior period, unchanged from 0001596532-25-000106:notes:9]

[0001596532-25-000216:notes:10]
In December 2023, the Financial Accounting Standards Board ("FASB") issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2024. Early adoption is permitted for annual financial statements that have not yet been issued. The amendments should be applied on a prospective basis although retrospective application is permitted. We will adopt the standard in our 2025 annual period using a prospective transition method.

[0001596532-25-000216:notes:11]
In November 2024, the FASB issued ASU No. 2024-03, Disaggregation of Income Statement Expenses (Subtopic 220-40). The ASU requires the disaggregated disclosure of specific expense categories, including purchases of inventory,

[0001596532-25-000216:notes:12]
employee compensation, depreciation, and amortization, within relevant income statement captions. This ASU also requires disclosure of the total amount of selling expenses along with the definition of selling expenses. The ASU is effective for annual periods beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027. Adoption of this ASU can either be applied prospectively to consolidated financial statements issued for reporting periods after the effective date of this ASU or retrospectively to any or all prior periods presented in the consolidated financial statements. Early adoption is also permitted. This ASU will likely result in the required additional disclosures being included in our consolidated financial statements, once adopted. We are currently evaluating the impact of future adoption on our financial statement disclosures.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-25-000216:notes:13]
[same as prior period, unchanged from 0001596532-25-000106:notes:13]

[0001596532-25-000216:notes:14]
[same as prior period, unchanged from 0001596532-25-000106:notes:14]

[0001596532-25-000216:notes:15]
|  |  | June 30, 2025 |  | December 31, 2024 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 900.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 900.5 |  |  | $ | 1,707.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,707.5 |  |
| Commercial paper |  | — |  |  | 44.4 |  |  | — |  |  | 44.4 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government notes |  | 48.9 |  |  | — |  |  | — |  |  | 48.9 |  |  | 31.4 |  |  | — |  |  | — |  |  | 31.4 |  |
| Agency securities |  | — |  |  | 44.8 |  |  | — |  |  | 44.8 |  |  | — |  |  | 3.0 |  |  | — |  |  | 3.0 |  |
|  |  | 949.4 |  |  | 89.2 |  |  | — |  |  | 1,038.6 |  |  | 1,738.9 |  |  | 3.0 |  |  | — |  |  | 1,741.9 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 32.6 |  |  | — |  |  | 32.6 |  |  | — |  |  | 48.8 |  |  | — |  |  | 48.8 |  |
| U.S. government notes |  | 2,235.4 |  |  | — |  |  | — |  |  | 2,235.4 |  |  | 1,921.5 |  |  | — |  |  | — |  |  | 1,921.5 |  |
| Corporate bonds |  | — |  |  | 3,219.5 |  |  | — |  |  | 3,219.5 |  |  | — |  |  | 2,593.6 |  |  | — |  |  | 2,593.6 |  |
| Municipal bonds |  | — |  |  | 1.5 |  |  | — |  |  | 1.5 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Agency securities |  | — |  |  | 1,129.9 |  |  | — |  |  | 1,129.9 |  |  | — |  |  | 977.2 |  |  | — |  |  | 977.2 |  |
|  |  | 2,235.4 |  |  | 4,383.5 |  |  | — |  |  | 6,618.9 |  |  | 1,921.5 |  |  | 3,619.6 |  |  | — |  |  | 5,541.1 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 1.4 |  |  | — |  |  | — |  |  | 1.4 |  |  | 1.4 |  |  | — |  |  | — |  |  | 1.4 |  |
| Total Financial Assets |  | $ | 3,186.2 |  |  | $ | 4,472.7 |  |  | $ | — |  |  | $ | 7,658.9 |  |  | $ | 3,661.8 |  |  | $ | 3,622.6 |  |  | $ | — |  |  | $ | 7,284.4 |  |

[0001596532-25-000216:notes:16]
During the three and six months ended June 30, 2025, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-25-000216:notes:17]
[same as prior period, unchanged from 0001596532-25-000106:notes:17]

[0001596532-25-000216:notes:18]
[same as prior period, unchanged from 0001596532-25-000106:notes:18]

[0001596532-25-000216:notes:19]
|  |  | June 30, 2025 |  | December 31, 2024 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 77.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 77.0 |  |  | $ | 48.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 48.8 |  |
| U.S. government |  | 2,280.4 |  |  | 5.3 |  |  | (1.4) |  |  | 2,284.3 |  |  | 1,954.8 |  |  | 2.7 |  |  | (4.6) |  |  | 1,952.9 |  |
| Corporate bonds |  | 3,210.9 |  |  | 10.1 |  |  | (1.5) |  |  | 3,219.5 |  |  | 2,595.7 |  |  | 4.4 |  |  | (6.5) |  |  | 2,593.6 |  |
| Municipal bonds |  | 1.5 |  |  | — |  |  | — |  |  | 1.5 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Agency securities |  | 1,173.8 |  |  | 1.6 |  |  | (0.7) |  |  | 1,174.7 |  |  | 981.0 |  |  | 1.6 |  |  | (2.4) |  |  | 980.2 |  |
| Total |  | $ | 6,743.6 |  |  | $ | 17.0 |  |  | $ | (3.6) |  |  | $ | 6,757.0 |  |  | $ | 5,580.3 |  |  | $ | 8.7 |  |  | $ | (13.5) |  |  | $ | 5,575.5 |  |

[0001596532-25-000216:notes:20]
For debt securities in unrealized loss positions, it is not likely that we will be required to sell such securities before recovery of their amortized cost basis nor do we have the intent to sell such securities before maturity. We invest in debt securities that have maximum maturities of three years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. Given the short-term and conservative nature of our portfolio, our debt securities are generally not subject to credit risk; therefore, we did not recognize any credit losses or non-credit-related impairments related to such securities for the three and six months ended June 30, 2025. All unrealized losses were recognized in other comprehensive income (loss). Realized gains or losses were immaterial for the three and six months ended June 30, 2025.

[0001596532-25-000216:notes:21]
[same as prior period, unchanged from 0001596532-25-000106:notes:21]

[0001596532-25-000216:notes:22]
|  |  | June 30, 2025 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 925.8 |  |  | $ | (1.4) |  |  | $ | — |  |  | $ | — |  |  | $ | 925.8 |  |  | $ | (1.4) |  |
| Corporate bonds |  | 732.6 |  |  | (1.5) |  |  | — |  |  | — |  |  | 732.6 |  |  | (1.5) |  |
| Municipal bonds |  | 1.5 |  |  | — |  |  | — |  |  | — |  |  | 1.5 |  |  | — |  |
| Agency securities |  | 614.5 |  |  | (0.7) |  |  | — |  |  | — |  |  | 614.5 |  |  | (0.7) |  |
| Total |  | $ | 2,274.4 |  |  | $ | (3.6) |  |  | $ | — |  |  | $ | — |  |  | $ | 2,274.4 |  |  | $ | (3.6) |  |

[0001596532-25-000216:notes:23]
As of June 30, 2025, we had no marketable debt securities with contractual maturities that exceeded three years. The fair values of marketable debt securities, by remaining contractual maturities, are as follows (in millions):

[0001596532-25-000216:notes:24]
|  |  | June 30, 2025 |
|  |  | Fair Value |
| Due in 1 year or less |  | $ | 2,617.0 |  |
| Due in 1 to 3 years |  | 4,001.9 |  |
| Total debt securities |  | $ | 6,618.9 |  |

[0001596532-25-000216:notes:25]
The weighted-average remaining duration of our marketable debt securities is approximately 1.3 years as of June 30, 2025. As we view these marketable debt securities as available to support current operations, we classify marketable debt securities with maturities beyond 12 months as current assets under the caption "Marketable securities" on the condensed consolidated balance sheets.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-25-000216:notes:26]
[same as prior period, unchanged from 0001596532-25-000106:notes:26]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-25-000216:notes:27]
[same as prior period, unchanged from 0001596532-25-000106:notes:27]

[0001596532-25-000216:notes:28]
[same as prior period, unchanged from 0001596532-25-000106:notes:28]

[0001596532-25-000216:notes:29]
|  |  | June 30, 2025 |  | December 31, 2024 |
| Raw materials |  | $ | 601.2 |  |  | $ | 565.4 |  |
| Finished goods(1) |  | 1,457.9 |  |  | 1,269.2 |  |
| Total inventories |  | $ | 2,059.1 |  |  | $ | 1,834.6 |  |

[0001596532-25-000216:notes:30]
(1) The balance includes evaluation inventory totaling $335.0 million and $422.1 million as of June 30, 2025 and December 31, 2024, respectively.

[0001596532-25-000216:notes:31]
[same as prior period, unchanged from 0001596532-25-000106:notes:31]

[0001596532-25-000216:notes:32]
[same as prior period, unchanged from 0001596532-25-000106:notes:32]

[0001596532-25-000216:notes:33]
|  |  | June 30, 2025 |  | December 31, 2024 |
| Land |  | $ | 47.3 |  |  | $ | 47.2 |  |
| Equipment and machinery |  | 174.1 |  |  | 160.7 |  |
| Computer hardware and software |  | 65.4 |  |  | 63.9 |  |
| Leasehold improvements |  | 37.1 |  |  | 34.7 |  |
| Furniture and fixtures |  | 3.7 |  |  | 3.5 |  |
| Construction-in-process |  | 58.1 |  |  | 8.2 |  |
| Property and equipment, gross |  | 385.7 |  |  | 318.2 |  |
| Less: accumulated depreciation |  | (233.4) |  |  | (219.4) |  |
| Property and equipment, net |  | $ | 152.3 |  |  | $ | 98.8 |  |

[0001596532-25-000216:notes:34]
Depreciation expense was $7.7 million and $8.5 million for the three months ended June 30, 2025 and 2024, respectively, and $15.7 million and $17.1 million for the six months ended June 30, 2025 and 2024, respectively.

[0001596532-25-000216:notes:35]
[same as prior period, unchanged from 0001596532-25-000106:notes:35]

[0001596532-25-000216:notes:36]
[same as prior period, unchanged from 0001596532-25-000106:notes:36]

[0001596532-25-000216:notes:37]
[same as prior period, unchanged from 0001596532-25-000106:notes:37]

[0001596532-25-000216:notes:38]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Contract liabilities, beginning balance |  | $ | 160.5 |  |  | $ | 139.6 |  |  | $ | 160.8 |  |  | $ | 133.2 |  |
| Less: Revenue recognized from beginning balance |  | (14.1) |  |  | (12.4) |  |  | (31.1) |  |  | (29.2) |  |
| Add: Contract liabilities recognized, net |  | 41.7 |  |  | 16.9 |  |  | 58.4 |  |  | 40.1 |  |
| Contract liabilities, ending balance |  | $ | 188.1 |  |  | $ | 144.1 |  |  | $ | 188.1 |  |  | $ | 144.1 |  |

[0001596532-25-000216:notes:39]
As of June 30, 2025 and December 31, 2024, $83.6 million and $65.7 million of our contract liabilities, respectively, were included in "Other current liabilities" with the remaining balances included in "Other long-term liabilities" on the condensed consolidated balance sheets.

[0001596532-25-000216:notes:40]
[same as prior period, unchanged from 0001596532-25-000106:notes:40]

[0001596532-25-000216:notes:41]
[same as prior period, unchanged from 0001596532-25-000106:notes:41]

[0001596532-25-000216:notes:42]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Deferred revenue, beginning balance |  | $ | 3,088.8 |  |  | $ | 1,663.2 |  |  | $ | 2,791.4 |  |  | $ | 1,506.2 |  |
| Less: Revenue recognized from beginning balance |  | (337.4) |  |  | (249.9) |  |  | (735.8) |  |  | (467.5) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 1,310.3 |  |  | 705.5 |  |  | 2,006.1 |  |  | 1,080.1 |  |
| Deferred revenue, ending balance |  | $ | 4,061.7 |  |  | $ | 2,118.8 |  |  | $ | 4,061.7 |  |  | $ | 2,118.8 |  |

[0001596532-25-000216:notes:43]
[same as prior period, unchanged from 0001596532-25-000106:notes:43]

[0001596532-25-000216:notes:44]
Other performance obligations totaling $442.3 million as of June 30, 2025 include unbilled multi-year PCS and service contract amounts of $385.9 million, and $56.4 million of binding contractual agreements with certain customers that are primarily related to future product shipments.

[0001596532-25-000216:notes:45]
[same as prior period, unchanged from 0001596532-25-000106:notes:45]

[0001596532-25-000216:notes:46]
Total revenue from our contract liabilities, deferred revenue and other performance obligations that is expected to be recognized in future periods amounts to $4.7 billion as of June 30, 2025. Approximately 88% of this future revenue is expected to be recognized over the next two years and the remaining 12% is expected to be recognized during the third to the fifth year.

[0001596532-25-000216:notes:47]
[same as prior period, unchanged from 0001596532-25-000106:notes:47]

[0001596532-25-000216:notes:48]
[same as prior period, unchanged from 0001596532-25-000106:notes:48]

[0001596532-25-000216:notes:49]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Interest income |  | $ | 90.4 |  |  | $ | 71.4 |  |  | $ | 180.6 |  |  | $ | 135.3 |  |
| Other income (expense), net |  | 3.6 |  |  | (0.6) |  |  | 9.6 |  |  | (1.8) |  |
| Total |  | $ | 94.0 |  |  | $ | 70.8 |  |  | $ | 190.2 |  |  | $ | 133.5 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-25-000216:notes:50]
[same as prior period, unchanged from 0001596532-25-000106:notes:50]

[0001596532-25-000216:notes:51]
[same as prior period, unchanged from 0001596532-25-000106:notes:51]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-25-000216:notes:52]
Acquisition
On June 30, 2025, we completed the acquisition of the VeloCloud business ("VeloCloud") from Broadcom for total cash consideration of $300.0 million. VeloCloud's secure, AI-optimized cloud WAN portfolio provides seamless connectivity to customer sites of any type, complementing Arista's leading data center and campus wired/wireless portfolio. The preliminary purchase price allocation based on the estimated fair values of the assets acquired and liabilities assumed as of the acquisition date, included $268.4 million of intangible assets, $148.0 million of goodwill and $116.4 million of net tangible liabilities assumed. The change in the carrying value of goodwill for the three months ended June 30, 2025 was solely related to the acquisition, and a portion of the goodwill is deductible for tax purposes.

[0001596532-25-000216:notes:53]
[same as prior period, unchanged from 0001596532-25-000106:notes:56]

[0001596532-25-000216:notes:54]
Acquisition-related intangible assets, included in other assets, are subject to amortization on a straight-line basis over their estimated useful lives, as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. Acquisition-related intangible assets, excluding those that are fully amortized, were as follows (in millions, except years):

[0001596532-25-000216:notes:55]
|  |  | June 30, 2025 |  | December 31, 2024 |
|  |  | Weighted-Average Remaining Useful Lives (in years) |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  |
| Developed technology |  | 4.5 |  | $ | 241.1 |  |  | $ | (125.0) |  |  | $ | 116.1 |  |  | $ | 154.9 |  |  | $ | (119.2) |  |  | $ | 35.7 |  |  |
| Customer relationships |  | 6.6 |  | 224.3 |  |  | (33.4) |  |  | 190.9 |  |  | 54.6 |  |  | (29.5) |  |  | 25.1 |  |  |
| Trade name |  | 4.9 |  | 24.9 |  |  | (12.1) |  |  | 12.8 |  |  | 12.4 |  |  | (11.2) |  |  | 1.2 |  |  |
| Total |  | 5.8 |  | $ | 490.3 |  |  | $ | (170.5) |  |  | $ | 319.8 |  |  | $ | 221.9 |  |  | $ | (159.9) |  |  | $ | 62.0 |  |  |

[0001596532-25-000216:notes:56]
Future estimated amortization expense related to acquisition-related intangible assets is as follows (in millions):

[0001596532-25-000216:notes:57]
|  |  | Future Amortization Expense |
| Remainder of 2025 |  | $ | 31.1 |  |
| 2026 |  | 61.2 |  |
| 2027 |  | 57.4 |  |
| 2028 |  | 54.0 |  |
| 2029 and thereafter |  | 116.1 |  |
| Total |  | $ | 319.8 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-25-000216:notes:58]
Commitments and Contingencies
Purchase Commitments

[0001596532-25-000216:notes:59]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of purchase orders to our contract manufacturers for finished products consist of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of June 30, 2025, we had non-cancellable purchase commitments not recorded on our balance sheet of $3.6 billion, of which $3.1 billion have expected receipt dates within 12 months, and $0.5 billion have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-25-000216:notes:60]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $66.8 million and $95.8 million as of June 30, 2025 and December 31, 2024, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

[0001596532-25-000216:notes:61]
Property Project

[0001596532-25-000216:notes:62]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office, lab and data center space. The estimated remaining capital expenditures related to this project are expected to be approximately $190.0 million to $215.0 million through the end of fiscal 2026 when we expect construction to be completed.

[0001596532-25-000216:notes:63]
Guarantees

[0001596532-25-000216:notes:64]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-25-000216:notes:65]
Legal Proceedings

[0001596532-25-000216:notes:66]
WSOU Investments, LLC

[0001596532-25-000216:notes:67]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California. On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement. On July 1, 2022, the court stayed the case pending the resolution of an inter partes review of one of the patents-in-suit. On May 30, 2023, the US Patent Trial and Appeal Board (“PTAB”) ruled all challenged claims in the inter partes review unpatentable. On March 10, 2025, the Federal Circuit affirmed the PTAB’s decision. The parties subsequently agreed to stay the litigation to allow WSOU to change counsel and that stay was extended pending the result of proceedings in a WSOU case against another company.

[0001596532-25-000216:notes:68]
We intend to vigorously defend against the claims brought against us by WSOU; however, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-25-000216:notes:69]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated; however, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-25-000216:notes:70]
Other matters

[0001596532-25-000216:notes:71]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-25-000216:notes:72]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of June 30, 2025, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-25-000216:notes:73]
[same as prior period, unchanged from 0001596532-25-000106:notes:77]

[0001596532-25-000216:notes:74]
In May 2025 we completed repurchases under our previous $1.2 billion stock repurchase program (the "Prior Repurchase Program") and our board of directors authorized a new $1.5 billion stock repurchase program (the “New Repurchase Program”, and together with the Prior Repurchase Program, the "Repurchase Programs"). This authorization allows us to repurchase shares of our common stock that will be funded from working capital. Repurchases may be made at management's discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the "Exchange Act"), or a combination of the foregoing. The New Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the Company at any time without prior notice. During the three months ended June 30, 2025, we repurchased a total of $133.9 million of our common stock under our Prior Repurchase Program and $62.0 million of our common stock under our New Repurchase Program. During the six months ended June 30, 2025, we repurchased a total of $921.0 million of our common stock under our Prior Repurchase Program and $62.0 million of our common stock under our New Repurchase Program. As of June 30, 2025, the remaining authorized amount for repurchases under the New Repurchase Program was $1.4 billion.

[0001596532-25-000216:notes:75]
A summary of the stock repurchase activity under the Repurchase Programs for the three and six months ended June 30, 2025 is as follows (in millions, except per share amounts):

[0001596532-25-000216:notes:76]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | June 30, 2025 |  | June 30, 2025 |
| Aggregate purchase price |  | $ | 195.9 |  |  | $ | 983.0 |  |
| Shares repurchased |  | 2.4 |  |  | 11.1 |  |
| Average price paid per share |  | $ | 80.7 |  |  | $ | 88.7 |  |

[0001596532-25-000216:notes:77]
[same as prior period, unchanged from 0001596532-25-000106:notes:81]

[0001596532-25-000216:notes:78]
[same as prior period, unchanged from 0001596532-25-000106:notes:82]

[0001596532-25-000216:notes:79]
[same as prior period, unchanged from 0001596532-25-000106:notes:86]

[0001596532-25-000216:notes:80]
In April 2014, our board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (“ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding on the immediately preceding December 31, but not to exceed 40 million shares, unless our board of directors, in its discretion, determines to make a smaller increase. As of June 30, 2025, there remained approximately 104.5 million shares available for issuance under the ESPP.

[0001596532-25-000216:notes:81]
[same as prior period, unchanged from 0001596532-25-000106:notes:89]

[0001596532-25-000216:notes:82]
During the six months ended June 30, 2025, we issued 0.4 million shares at a weighted-average purchase price of $62.31 per share under the ESPP.

[0001596532-25-000216:notes:83]
[same as prior period, unchanged from 0001596532-25-000106:notes:83]

[0001596532-25-000216:notes:84]
[same as prior period, unchanged from 0001596532-25-000106:notes:84]

[0001596532-25-000216:notes:85]
The Restated Plan provides for the grant of equity-based awards, including stock options, restricted stock units, restricted stock, stock appreciation rights, and performance awards. The share pool available under the prior version of the Company's 2014 Equity Incentive Plan ("Prior Plan") was extinguished, and the Restated Plan provides for a new share pool not to exceed (i) 52.8 million shares of our Common Stock (“Shares”), plus (ii) any Shares subject to awards under the Prior Plan that, on or after the Effective Date, expired or otherwise terminated without having been exercised in full, or that were forfeited to or repurchased by us, including net settlement of Shares subject to restricted stock units, with the maximum number of Shares to be added to the Restated Plan as a result of clause (ii) equal to 40.2 million Shares. The Restated Plan’s terms are substantially similar to the Prior Plan’s terms, including with respect to treatment of equity awards in the event of a “change in control” as defined under the Restated Plan, but with certain modifications, including the elimination of the automatic “evergreen” share reserve increase provided for under the Prior Plan. As of June 30, 2025, there remained approximately 47.7 million shares available for grant under the Restated Plan.

[0001596532-25-000216:notes:86]
[same as prior period, unchanged from 0001596532-25-000106:notes:91]

[0001596532-25-000216:notes:87]
[same as prior period, unchanged from 0001596532-25-000106:notes:92]

[0001596532-25-000216:notes:88]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2024 |  | 3.1 |  |  | $ | 6.71 |  |  | 1.5 |  | $ | 320.9 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (1.8) |  |  | 3.99 |  |  |  |  |  |
| Options canceled |  | (0.1) |  |  | 14.49 |  |  |  |  |  |
| Balance—June 30, 2025 |  | 1.2 |  |  | $ | 10.56 |  |  | 2.5 |  | $ | 109.4 |  |
| Vested and exercisable—June 30, 2025 |  | 1.1 |  |  | $ | 10.37 |  |  | 2.5 |  | $ | 105.2 |  |

[0001596532-25-000216:notes:89]
[same as prior period, unchanged from 0001596532-25-000106:notes:94]

[0001596532-25-000216:notes:90]
[same as prior period, unchanged from 0001596532-25-000106:notes:95]

[0001596532-25-000216:notes:91]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |
| Unvested balance—December 31, 2024 |  | 28.6 |  |  | $ | 45.46 |  |
| RSUs and PRSUs granted |  | 6.7 |  |  | 91.70 |  |
| RSUs and PRSUs vested |  | (4.7) |  |  | 35.13 |  |
| RSUs and PRSUs forfeited/canceled |  | (1.5) |  |  | 46.87 |  |
| Unvested balance—June 30, 2025 |  | 29.1 |  |  | $ | 58.20 |  |

[0001596532-25-000216:notes:92]
[same as prior period, unchanged from 0001596532-25-000106:notes:97]

[0001596532-25-000216:notes:93]
[same as prior period, unchanged from 0001596532-25-000106:notes:98]

[0001596532-25-000216:notes:94]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Cost of revenue |  | $ | 5.8 |  |  | $ | 4.0 |  |  | $ | 11.3 |  |  | $ | 7.4 |  |
| Research and development |  | 53.2 |  |  | 50.7 |  |  | 110.2 |  |  | 94.5 |  |
| Sales and marketing |  | 18.8 |  |  | 16.8 |  |  | 38.7 |  |  | 35.7 |  |
| General and administrative |  | 7.4 |  |  | 7.8 |  |  | 18.0 |  |  | 18.9 |  |
| Total stock-based compensation |  | $ | 85.2 |  |  | $ | 79.3 |  |  | $ | 178.2 |  |  | $ | 156.5 |  |

[0001596532-25-000216:notes:95]
As of June 30, 2025, there were $1.4 billion of unamortized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 4.6 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-25-000216:notes:96]
[same as prior period, unchanged from 0001596532-25-000106:notes:101]

[0001596532-25-000216:notes:97]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 888.8 |  |  | $ | 665.4 |  |  | $ | 1,702.6 |  |  | $ | 1,303.1 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Basic weighted-average shares outstanding |  | 1,256.3 |  |  | 1,254.8 |  |  | 1,258.2 |  |  | 1,253.5 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity awards |  | 14.9 |  |  | 24.9 |  |  | 17.0 |  |  | 26.1 |  |
| Diluted weighted-average shares outstanding |  | 1,271.2 |  |  | 1,279.7 |  |  | 1,275.2 |  |  | 1,279.6 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.71 |  |  | $ | 0.53 |  |  | $ | 1.35 |  |  | $ | 1.04 |  |
| Diluted |  | $ | 0.70 |  |  | $ | 0.52 |  |  | $ | 1.34 |  |  | $ | 1.02 |  |

[0001596532-25-000216:notes:98]
[same as prior period, unchanged from 0001596532-25-000106:notes:103]

[0001596532-25-000216:notes:99]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Employee equity awards |  | 3.2 |  |  | 0.1 |  |  | 2.0 |  |  | 0.4 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-25-000216:notes:100]
[same as prior period, unchanged from 0001596532-25-000106:notes:105]

[0001596532-25-000216:notes:101]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Income before income taxes |  | $ | 1,080.2 |  |  | $ | 770.4 |  |  | $ | 2,035.2 |  | $ | 1,493.2 |  |
| Provision for income taxes |  | 191.4 |  |  | 105.0 |  |  | $ | 332.6 |  | 190.1 |  |
| Effective tax rate |  | 17.7 | % |  | 13.6 | % |  | 16.3 | % |  | 12.7 | % |

[0001596532-25-000216:notes:102]
The increase in the effective tax rates in the three and six months ended June 30, 2025, as compared to the same periods in 2024, was primarily due to a decrease in tax benefits attributable to equity-based compensation.

[0001596532-25-000216:notes:103]
On July 4, 2025, the One Big Beautiful Bill Act ("OBBB Act") was signed into law in the U.S.. This legislation contains a broad range of tax reform provisions affecting businesses. We are evaluating the full effects of the legislation on our estimated annual effective tax rate and cash tax position. As the legislation was signed into law after the close of our second quarter, such impacts are not included in our operating results for the six months ended June 30, 2025.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-25-000216:notes:104]
[same as prior period, unchanged from 0001596532-25-000106:notes:108]

[0001596532-25-000216:notes:105]
[same as prior period, unchanged from 0001596532-25-000106:notes:109]

[0001596532-25-000216:notes:106]
[same as prior period, unchanged from 0001596532-25-000106:notes:110]

[0001596532-25-000216:notes:107]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Americas(1) |  | $ | 1,724.1 |  |  | $ | 1,374.2 |  |  | $ | 3,322.6 |  |  | $ | 2,629.6 |  |
| Europe, Middle East and Africa |  | 281.6 |  |  | 178.8 |  |  | 456.2 |  |  | 320.4 |  |
| Asia-Pacific |  | 199.1 |  |  | 137.4 |  |  | 430.8 |  |  | 311.8 |  |
| Total revenue |  | $ | 2,204.8 |  |  | $ | 1,690.4 |  |  | $ | 4,209.6 |  |  | $ | 3,261.8 |  |

[0001596532-25-000216:notes:108]
(1) Includes $1,712.1 million and $1,362.7 million revenue generated from the U.S. for the three months ended June 30, 2025 and June 30, 2024, respectively, and $3,293.6 million and $2,595.5 million for the six months ended June 30, 2025 and June 30, 2024, respectively.

[0001596532-25-000216:notes:109]
[same as prior period, unchanged from 0001596532-25-000106:notes:113]

[0001596532-25-000216:notes:110]
|  |  | June 30, 2025 |  | December 31, 2024 |
| United States |  | $ | 135.2 |  |  | $ | 83.5 |  |
| International |  | 17.1 |  |  | 15.3 |  |
| Total |  | $ | 152.3 |  |  | $ | 98.8 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001596532-25-000216:notes:111]
On June 10, 2025, Kelly Battles, a member of our Board of Directors, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of 1,688 shares of our common stock. The trading arrangement is

[0001596532-25-000216:notes:112]
intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until November 23, 2026, or earlier if all transactions under the trading arrangement are completed.

[0001596532-25-000216:notes:113]
On June 12, 2025, Charles Giancarlo, a member of our Board of Directors, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 146,000 shares of our common stock. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until September 21, 2026, or earlier if all transactions under the trading arrangement are completed.
