# ANET 8-K — 0001596532-22-000292 filed 2022-10-31

## item codes, every 8-K on or before 2022-11-01

- 2022-10-31 0001596532-22-000292 — 2.02, 9.01
- 2022-10-25 0001596532-22-000282 — 5.03, 9.01
- 2022-08-01 0001596532-22-000218 — 2.02, 9.01
- 2022-07-25 0001596532-22-000205 — 5.02
- 2022-06-03 0001596532-22-000179 — 5.07
- 2022-05-02 0001596532-22-000111 — 2.02, 9.01
- 2022-03-29 0001596532-22-000100 — 5.02
- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2022-11-01

- none on or before 2022-11-01

## item 2.02 — earnings release, exhibit 99.1

[0001596532-22-000292:8k_2_02:1]
EX-99.1
2
ex991q322-earningsrelease.htm
EX-99.1

[0001596532-22-000292:8k_2_02:2]
Document

[0001596532-22-000292:8k_2_02:3]
Exhibit 99.1

[0001596532-22-000292:8k_2_02:4]
Arista Networks, Inc. Reports Third Quarter 2022 Financial Results

[0001596532-22-000292:8k_2_02:5]
SANTA CLARA, Calif.- October 31, 2022 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments, today announced financial results for its third quarter ended September 30, 2022.

[0001596532-22-000292:8k_2_02:6]
“Arista continues to outpace our networking peers with record revenue in Q3 2022,” said Jayshree Ullal, President and CEO of Arista Networks. “Clearly, we are entering the next phase of Arista’s evolution in products, customer intimacy and new market expansion.”

[0001596532-22-000292:8k_2_02:7]
Third Quarter Financial Highlights

[0001596532-22-000292:8k_2_02:8]
•Revenue of $1.177 billion, an increase of 11.9% compared to the second quarter of 2022, and an increase of 57.2% from the third quarter of 2021.

[0001596532-22-000292:8k_2_02:9]
•GAAP gross margin of 60.3%, compared to GAAP gross margin of 61.2% in the second quarter of 2022 and 63.9% in the third quarter of 2021.

[0001596532-22-000292:8k_2_02:10]
•Non-GAAP gross margin of 61.2%, compared to non-GAAP gross margin of 61.9% in the second quarter of 2022 and 64.9% in the third quarter of 2021.

[0001596532-22-000292:8k_2_02:11]
•GAAP net income of $354.0 million, or $1.13 per diluted share, compared to GAAP net income of $224.3 million, or $0.70 per diluted share in the third quarter of 2021.

[0001596532-22-000292:8k_2_02:12]
•Non-GAAP net income of $391.9 million, or $1.25 per diluted share, compared to non-GAAP net income of $236.9 million, or $0.74 per diluted share in the third quarter of 2021.

[0001596532-22-000292:8k_2_02:13]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO said, “We are pleased with the continued strong revenue growth in the quarter, driving significant EPS upside and demonstrating the inherent operational leverage of the business model.”

[0001596532-22-000292:8k_2_02:14]
Company Highlights

[0001596532-22-000292:8k_2_02:15]
•Arista Delivers Next Generation Cloud Routing - a leader in data-driven cloud networking, announced innovations for its comprehensive cloud-grade routing platform that simplify and secure routing for the enterprise, mobile provider and cloud operators. These software and hardware innovations continue to drive down customer operational cost and complexity with a consistent and modern approach to a broad range of routing use cases.

[0001596532-22-000292:8k_2_02:16]
•Arista Introduces the Unified Cloud Fabric - Arista’s Converged Cloud Fabric (CCF)™, brings an automated fabric built with cloud networking design principles.

[0001596532-22-000292:8k_2_02:17]
•Arista is proud to be named a Best Work-Life Balance company in 2022 by Comparably and listed as a 2022 Best Place to Work Company earlier this year by the Silicon Valley Business Journal.

[0001596532-22-000292:8k_2_02:18]
Financial Outlook

[0001596532-22-000292:8k_2_02:19]
For the fourth quarter of 2022, we expect:

[0001596532-22-000292:8k_2_02:20]
•Revenue between $1.175 billion to $1.200 billion

[0001596532-22-000292:8k_2_02:21]
•Non-GAAP gross margin of approximately 60% to 62%; and

[0001596532-22-000292:8k_2_02:22]
•Non-GAAP operating margin of approximately 40%

[0001596532-22-000292:8k_2_02:23]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and certain non-recurring items. A reconciliation of non-GAAP guidance

[0001596532-22-000292:8k_2_02:24]
measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below under “Non-GAAP Financial Measures”).

[0001596532-22-000292:8k_2_02:25]
Prepared Materials and Conference Call Information

[0001596532-22-000292:8k_2_02:26]
Arista's executives will discuss the third quarter 2022 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-22-000292:8k_2_02:27]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-22-000292:8k_2_02:28]
Forward-Looking Statements

[0001596532-22-000292:8k_2_02:29]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the fourth quarter of 2022, statements regarding Arista's business plans and its ability to execute such plans, statements regarding our ability to grow our revenue and expand our market share and statements regarding the benefits of Arista's products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: interruptions or delays in shipments; the impact of supply shortages and manufacturing disruptions on our business including increased purchase commitments and extended lead times; adverse global economic and geopolitical conditions including inflationary pressures which result in increased component costs and reduced information technology and network infrastructure spending and the Russia/Ukraine conflict; the impact of the COVID-19 pandemic and related public safety measures on our business; dependence on a limited number of customers who represent a substantial portion of our revenue; the rapid evolution of the networking market; any failure to successfully pursue new products and service offerings and expand into adjacent markets; a decline in our revenue growth rate; fluctuations in our results of operations including as a result of seasonality; variability in our gross margins including as a result of changes in customer mix or product mix; intense competition; expansion of our international sales and operations; investments in or acquisitions of other businesses; fluctuations in currency exchange rates; any failure to raise any needed capital; our ability to attract new large end customers or sell products and services to existing end customers and dependence on large end customers; our ability to increase market awareness of our company and new products and services; a decline in the sales prices of our products and services; a decline in maintenance renewals by customers; product quality problems; our ability to anticipate technological shifts and develop products to meet those technological shifts; the management of the supply of our products and product components; our dependence on third-party manufacturers to build our products; our ability to protect, defend and maintain our intellectual property rights; vulnerabilities in our products and failure of our products to detect security breaches; failure to maintain effective internal control over financial reporting; tax, tariff, import/export restrictions or other trade barriers; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-22-000292:8k_2_02:30]
2

[0001596532-22-000292:8k_2_02:31]
Non-GAAP Financial Measures

[0001596532-22-000292:8k_2_02:32]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangible assets, certain non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-22-000292:8k_2_02:33]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-22-000292:8k_2_02:34]
The company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. The company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. A reconciliation of the non-GAAP financial measures guidance to the corresponding GAAP measures on a forward-looking basis is not available because stock-based compensation expense is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-22-000292:8k_2_02:35]
About Arista Networks

[0001596532-22-000292:8k_2_02:36]
Arista Networks is an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments. Arista’s award-winning platforms deliver availability, agility, automation, analytics and security through an advanced network operating stack. For more information, visit www.arista.com.

[0001596532-22-000292:8k_2_02:37]
ARISTA, EOS, CloudVision, NetDL AVA, TunnelSEC and Arista CCF  are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-22-000292:8k_2_02:38]
Investor Contacts:

[0001596532-22-000292:8k_2_02:39]
Arista Networks, Inc.

[0001596532-22-000292:8k_2_02:40]
Liz Stine, 408-547-5885

[0001596532-22-000292:8k_2_02:41]
Investor Relations

[0001596532-22-000292:8k_2_02:42]
liz@arista.com

[0001596532-22-000292:8k_2_02:43]
ARISTA NETWORKS, INC.

[0001596532-22-000292:8k_2_02:44]
Condensed Consolidated Statements of Operations

[0001596532-22-000292:8k_2_02:45]
(Unaudited, in thousands, except per share amounts)

[0001596532-22-000292:8k_2_02:46]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,008,689 |  |  | $ | 604,160 |  |  | $ | 2,619,213 |  |  | $ | 1,709,772 |  |
| Service |  | 168,112 |  |  | 144,537 |  |  | 486,545 |  |  | 413,806 |  |
| Total revenue |  | 1,176,801 |  |  | 748,697 |  |  | 3,105,758 |  |  | 2,123,578 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 432,569 |  |  | 243,342 |  |  | 1,102,012 |  |  | 687,554 |  |
| Service |  | 34,252 |  |  | 26,740 |  |  | 96,656 |  |  | 77,959 |  |
| Total cost of revenue |  | 466,821 |  |  | 270,082 |  |  | 1,198,668 |  |  | 765,513 |  |
| Gross profit |  | 709,980 |  |  | 478,615 |  |  | 1,907,090 |  |  | 1,358,065 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 187,807 |  |  | 153,093 |  |  | 537,971 |  |  | 428,873 |  |
| Sales and marketing |  | 81,401 |  |  | 69,740 |  |  | 241,512 |  |  | 211,385 |  |
| General and administrative |  | 23,425 |  |  | 22,488 |  |  | 69,420 |  |  | 58,856 |  |
| Total operating expenses |  | 292,633 |  |  | 245,321 |  |  | 848,903 |  |  | 699,114 |  |
| Income from operations |  | 417,347 |  |  | 233,294 |  |  | 1,058,187 |  |  | 658,951 |  |
| Other income (expenses), net |  | 6,817 |  |  | 1,346 |  |  | 37,764 |  |  | 4,640 |  |
| Income before income taxes |  | 424,164 |  |  | 234,640 |  |  | 1,095,951 |  |  | 663,591 |  |
| Provision for income taxes |  | 70,165 |  |  | 10,335 |  |  | 170,594 |  |  | 62,032 |  |
| Net income |  | $ | 353,999 |  |  | $ | 224,305 |  |  | $ | 925,357 |  |  | $ | 601,559 |  |
| Net income per share (1): |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.16 |  |  | $ | 0.73 |  |  | $ | 3.02 |  |  | $ | 1.96 |  |
| Diluted |  | $ | 1.13 |  |  | $ | 0.70 |  |  | $ | 2.92 |  |  | $ | 1.89 |  |
| Weighted-average shares used in computing net income per share (1): |  |  |  |  |  |  |  |  |
| Basic |  | 304,931 |  |  | 307,456 |  |  | 306,576 |  |  | 306,176 |  |
| Diluted |  | 314,401 |  |  | 319,636 |  |  | 316,745 |  |  | 318,976 |  |

[0001596532-22-000292:8k_2_02:47]
_______________________

[0001596532-22-000292:8k_2_02:48]
(1) Prior periods have been adjusted to reflect the four-for-one stock split effected in the form of a stock dividend in November 2021.

[0001596532-22-000292:8k_2_02:49]
4

[0001596532-22-000292:8k_2_02:50]
ARISTA NETWORKS, INC.

[0001596532-22-000292:8k_2_02:51]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-22-000292:8k_2_02:52]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-22-000292:8k_2_02:53]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| GAAP gross profit |  | $ | 709,980 |  |  | $ | 478,615 |  |  | $ | 1,907,090 |  |  | $ | 1,358,065 |  |
| GAAP gross margin |  | 60.3 | % |  | 63.9 | % |  | 61.4 | % |  | 64.0 | % |
| Stock-based compensation expense |  | 2,992 |  |  | 2,002 |  |  | 6,613 |  |  | 5,198 |  |
| Intangible asset amortization |  | 6,820 |  |  | 5,464 |  |  | 18,553 |  |  | 16,393 |  |
| Non-GAAP gross profit |  | $ | 719,792 |  |  | $ | 486,081 |  |  | $ | 1,932,256 |  |  | $ | 1,379,656 |  |
| Non-GAAP gross margin |  | 61.2 | % |  | 64.9 | % |  | 62.2 | % |  | 65.0 | % |
| GAAP income from operations |  | $ | 417,347 |  |  | $ | 233,294 |  |  | $ | 1,058,187 |  |  | $ | 658,951 |  |
| Stock-based compensation expense |  | 65,477 |  |  | 53,135 |  |  | 165,980 |  |  | 135,632 |  |
| Intangible asset amortization |  | 9,315 |  |  | 7,281 |  |  | 24,334 |  |  | 22,076 |  |
| Acquisition-related costs (1) |  | — |  |  | — |  |  | 4,691 |  |  | — |  |
| Non-GAAP income from operations |  | $ | 492,139 |  |  | $ | 293,710 |  |  | $ | 1,253,192 |  |  | $ | 816,659 |  |
| Non-GAAP operating margin |  | 41.8 | % |  | 39.2 | % |  | 40.4 | % |  | 38.5 | % |
| GAAP net income |  | $ | 353,999 |  |  | $ | 224,305 |  |  | $ | 925,357 |  |  | $ | 601,559 |  |
| Stock-based compensation expense |  | 65,477 |  |  | 53,135 |  |  | 165,980 |  |  | 135,632 |  |
| Intangible asset amortization |  | 9,315 |  |  | 7,281 |  |  | 24,334 |  |  | 22,076 |  |
| Acquisition-related costs (1) |  | — |  |  | — |  |  | 4,691 |  |  | — |  |
| Unrealized loss (gain) on equity investments |  | (708) |  |  | — |  |  | (24,121) |  |  | — |  |
| Tax benefit on stock-based awards |  | (27,636) |  |  | (39,665) |  |  | (76,325) |  |  | (84,684) |  |
| Income tax effect on non-GAAP exclusions |  | (8,524) |  |  | (8,137) |  |  | (16,805) |  |  | (21,999) |  |
| Non-GAAP net income |  | $ | 391,923 |  |  | $ | 236,919 |  |  | $ | 1,003,111 |  |  | $ | 652,584 |  |
| GAAP diluted net income per share (2) |  | $ | 1.13 |  |  | $ | 0.70 |  |  | $ | 2.92 |  |  | $ | 1.89 |  |
| Non-GAAP adjustments to net income |  | 0.12 |  |  | 0.04 |  |  | 0.25 |  |  | 0.16 |  |
| Non-GAAP diluted net income per share |  | $ | 1.25 |  |  | $ | 0.74 |  |  | $ | 3.17 |  |  | $ | 2.05 |  |
| Weighted-average shares used in computing diluted net income per share (2) |  | 314,401 |  |  | 319,636 |  |  | 316,745 |  |  | 318,976 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 2,992 |  |  | $ | 2,002 |  |  | $ | 6,613 |  |  | $ | 5,198 |  |
| Research and development |  | 37,698 |  |  | 27,552 |  |  | 93,723 |  |  | 72,673 |  |
| Sales and marketing |  | 16,103 |  |  | 12,680 |  |  | 42,039 |  |  | 34,133 |  |
| General and administrative |  | 8,684 |  |  | 10,901 |  |  | 23,605 |  |  | 23,628 |  |
| Total |  | $ | 65,477 |  |  | $ | 53,135 |  |  | $ | 165,980 |  |  | $ | 135,632 |  |

[0001596532-22-000292:8k_2_02:54]
___________________

[0001596532-22-000292:8k_2_02:55]
(1) Represent non-recurring costs associated with business combinations, which primarily include retention bonuses, and professional and consulting fees.

[0001596532-22-000292:8k_2_02:56]
(2) Prior periods have been adjusted to reflect the four-for-one stock split effected in the form of a stock dividend in November 2021.

[0001596532-22-000292:8k_2_02:57]
ARISTA NETWORKS, INC.

[0001596532-22-000292:8k_2_02:58]
Condensed Consolidated Balance Sheets

[0001596532-22-000292:8k_2_02:59]
(Unaudited, in thousands)

[0001596532-22-000292:8k_2_02:60]
|  |  | September 30, 2022 |  | December 31, 2021 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 716,253 |  |  | $ | 620,813 |  |
| Marketable securities |  | 2,263,818 |  |  | 2,787,502 |  |
| Accounts receivable |  | 651,512 |  |  | 516,509 |  |
| Inventories |  | 1,100,550 |  |  | 650,117 |  |
| Prepaid expenses and other current assets |  | 299,545 |  |  | 237,735 |  |
| Total current assets |  | 5,031,678 |  |  | 4,812,676 |  |
| Property and equipment, net |  | 96,449 |  |  | 78,634 |  |
| Acquisition-related intangible assets, net |  | 131,520 |  |  | 93,555 |  |
| Goodwill |  | 271,018 |  |  | 188,397 |  |
| Investments |  | 39,677 |  |  | 20,247 |  |
| Operating lease right-of-use assets |  | 58,205 |  |  | 65,182 |  |
| Deferred tax assets |  | 473,808 |  |  | 442,295 |  |
| Other assets |  | 59,655 |  |  | 33,443 |  |
| TOTAL ASSETS |  | $ | 6,162,010 |  |  | $ | 5,734,429 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 278,469 |  |  | $ | 202,636 |  |
| Accrued liabilities |  | 240,609 |  |  | 226,643 |  |
| Deferred revenue |  | 607,189 |  |  | 593,578 |  |
| Other current liabilities |  | 128,645 |  |  | 86,972 |  |
| Total current liabilities |  | 1,254,912 |  |  | 1,109,829 |  |
| Income taxes payable |  | 82,167 |  |  | 69,916 |  |
| Operating lease liabilities, non-current |  | 47,067 |  |  | 56,527 |  |
| Deferred revenue, non-current |  | 333,855 |  |  | 335,734 |  |
| Deferred tax liabilities, non-current |  | — |  |  | 129,074 |  |
| Other long-term liabilities |  | 58,791 |  |  | 54,749 |  |
| TOTAL LIABILITIES |  | 1,776,792 |  |  | 1,755,829 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 31 |  |  | 31 |  |
| Additional paid-in capital |  | 1,717,605 |  |  | 1,530,046 |  |
| Retained earnings |  | 2,714,711 |  |  | 2,456,823 |  |
| Accumulated other comprehensive income (loss) |  | (47,129) |  |  | (8,300) |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 4,385,218 |  |  | 3,978,600 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 6,162,010 |  |  | $ | 5,734,429 |  |

[0001596532-22-000292:8k_2_02:61]
6

[0001596532-22-000292:8k_2_02:62]
ARISTA NETWORKS, INC.

[0001596532-22-000292:8k_2_02:63]
Condensed Consolidated Statements of Cash Flows

[0001596532-22-000292:8k_2_02:64]
(Unaudited, in thousands)

[0001596532-22-000292:8k_2_02:65]
|  |  | Nine Months Ended September 30, |
|  |  | 2022 |  | 2021 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 925,357 |  |  | $ | 601,559 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 45,169 |  |  | 37,864 |  |
| Stock-based compensation |  | 165,980 |  |  | 135,632 |  |
| Noncash lease expense |  | 13,837 |  |  | 12,738 |  |
| Deferred income taxes |  | (148,355) |  |  | (573) |  |
| Unrealized gain on equity investments |  | (24,121) |  |  | — |  |
| Amortization of investment premiums |  | 14,167 |  |  | 19,193 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (129,947) |  |  | (6,050) |  |
| Inventories |  | (449,792) |  |  | (95,997) |  |
| Prepaid expenses and other current assets |  | (68,996) |  |  | (71,300) |  |
| Other assets |  | (17,899) |  |  | (2,915) |  |
| Accounts payable |  | 73,480 |  |  | (1,075) |  |
| Accrued liabilities |  | 14,690 |  |  | 31,316 |  |
| Deferred revenue |  | (1,245) |  |  | 149,613 |  |
| Income taxes payable |  | 41,074 |  |  | (3,565) |  |
| Other liabilities |  | (1,059) |  |  | (15,820) |  |
| Net cash provided by operating activities |  | 452,340 |  |  | 790,620 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 1,277,821 |  |  | 1,158,723 |  |
| Purchases of marketable securities |  | (973,489) |  |  | (1,974,853) |  |
| Purchases of property and equipment |  | (34,184) |  |  | (55,455) |  |
| Business acquisitions, net of cash acquired |  | (145,087) |  |  | — |  |
| Escrow receipts from past business acquisitions |  | — |  |  | 1,299 |  |
| Investments and notes receivable in privately-held companies |  | (12,691) |  |  | (10,684) |  |
| Proceeds from sale of marketable securities |  | 186,782 |  |  | 19,607 |  |
| Net cash provided by (used in) investing activities |  | 299,152 |  |  | (861,363) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 43,073 |  |  | 56,154 |  |
| Tax withholdings paid on behalf of employees for net share settlement |  | (25,542) |  |  | (10,622) |  |
| Repurchases of common stock |  | (667,470) |  |  | (235,512) |  |
| Net cash used in financing activities |  | (649,939) |  |  | (189,980) |  |
| Effect of exchange rate changes |  | (6,090) |  |  | (1,513) |  |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 95,463 |  |  | (262,236) |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 625,050 |  |  | 897,454 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 720,513 |  |  | $ | 635,218 |  |
