# ANET MD&A — 0001596532-22-000294


## mdna

[0001596532-22-000294:mdna:1]
[same as prior period, unchanged from 0001596532-22-000220:mdna:1]

[0001596532-22-000294:mdna:2]
[same as prior period, unchanged from 0001596532-22-000220:mdna:2]

[0001596532-22-000294:mdna:3]
Arista Networks pioneered data-driven, cognitive cloud networking for large-scale data center and campus workspace environments. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our Ethernet switching and routing platforms. We are a leader in cloud networking solutions delivering high performance, scalability, availability, programmability, workload orchestration, automation and visibility. In recent years, we have sought to bring the operational consistency and principles of cloud networking to the broader enterprise and campus markets with our cognitive cloud networking approach, extending EOS across the enterprise data center and campus wired and wireless workspaces.

[0001596532-22-000294:mdna:4]
[same as prior period, unchanged from 0001596532-22-000220:mdna:4]

[0001596532-22-000294:mdna:5]
Historically, large purchases by a relatively limited number of end customers have accounted for a significant portion of our revenue. We have experienced unpredictability in the timing of orders from these large end customers primarily due to changes in demand patterns specific to these customers, the time it takes these end customers to evaluate, test, qualify and accept our products, and the overall complexity of these large orders. For example, sales to our end customers Microsoft and Meta Platforms in fiscal 2019 collectively represented 40% of our total revenue, whereas sales to our end customer Microsoft in fiscal 2020 and 2021 amounted to 21.5% and 15.0% of our revenues, respectively, with our end customer Meta Platforms representing less than 10% of our revenues in both fiscal 2020 and 2021. In addition, we have experienced and expect the collective revenue contribution from these same customers to return to more elevated levels during fiscal 2022 as they broadly adopt our newer 400 GbE and related networking products. This variability in customer concentration has been linked to the timing of new product deployments and spending cycles with these customers, and we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. Furthermore, we typically provide pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur.

[0001596532-22-000294:mdna:6]
[same as prior period, unchanged from 0001596532-22-000220:mdna:6]

[0001596532-22-000294:mdna:7]
[same as prior period, unchanged from 0001596532-22-000220:mdna:7]

[0001596532-22-000294:mdna:8]
[same as prior period, unchanged from 0001596532-22-000220:mdna:8]

[0001596532-22-000294:mdna:9]
[same as prior period, unchanged from 0001596532-22-000220:mdna:9]

[0001596532-22-000294:mdna:10]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including supply chain and labor shortages, inflation and monetary supply shifts, recession risks, the ongoing global coronavirus ("COVID-19") pandemic, and potential disruptions from the Russia-Ukraine conflict and U.S. trade war with China.

[0001596532-22-000294:mdna:11]
Our manufacturing and supply chain operations continue to experience significant constraints, with component shortages, increased component and supply chain costs and delays broadly impacting the industry as a whole. We continue to work closely with our contract manufacturers and supply chain partners who have experienced delays in component sourcing, workforce disruptions and governmental restrictions on the production and export of their products. Although we have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, these delays have negatively impacted our ability to supply products to our customers on a timely basis. We have extended our demand planning horizon, increased our purchase commitments and expect to continue to invest in working capital to address delays in component sourcing and the risk of future supply chain disruptions, but we cannot be certain that such delays or disruptions will not occur. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. Our operating cash-flows have also been and may continue to be negatively impacted by increased component inventories on hand or at our contract manufacturers, awaiting supply of a limited number of scarce components necessary to build and ship the completed product. While overall demand remains strong across our customers base, we believe ongoing supply disruptions combined with other supply chain related constraints, could impact our ability to fulfill this increased demand and as a result could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the Russia-Ukraine conflict, continued escalation of the conflict may negatively impact the global economy and our future operating results and financial condition.

[0001596532-22-000294:mdna:12]
[same as prior period, unchanged from 0001596532-22-000220:mdna:12]

[0001596532-22-000294:mdna:13]
[same as prior period, unchanged from 0001596532-22-000220:mdna:13]

[0001596532-22-000294:mdna:14]
Three and Nine Months Ended September 30, 2022 Compared to Three and Nine Months Ended September 30, 2021

[0001596532-22-000294:mdna:15]
[same as prior period, unchanged from 0001596532-22-000220:mdna:15]

[0001596532-22-000294:mdna:16]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2022 |  | 2021 |  | Change in |  | 2022 |  | 2021 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,008,689 |  |  | $ | 604,160 |  |  | $ | 404,529 |  |  | 67.0 | % |  | $ | 2,619,213 |  |  | $ | 1,709,772 |  |  | $ | 909,441 |  |  | 53.2 | % |
| Service |  | 168,112 |  |  | 144,537 |  |  | 23,575 |  |  | 16.3 |  |  | 486,545 |  |  | 413,806 |  |  | 72,739 |  |  | 17.6 |  |
| Total revenue |  | 1,176,801 |  |  | 748,697 |  |  | 428,104 |  |  | 57.2 |  |  | 3,105,758 |  |  | 2,123,578 |  |  | 982,180 |  |  | 46.3 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 432,569 |  |  | 243,342 |  |  | 189,227 |  |  | 77.8 |  |  | 1,102,012 |  |  | 687,554 |  |  | 414,458 |  |  | 60.3 |  |
| Service |  | 34,252 |  |  | 26,740 |  |  | 7,512 |  |  | 28.1 |  |  | 96,656 |  |  | 77,959 |  |  | 18,697 |  |  | 24.0 |  |
| Total cost of revenue |  | 466,821 |  |  | 270,082 |  |  | 196,739 |  |  | 72.8 |  |  | 1,198,668 |  |  | 765,513 |  |  | 433,155 |  |  | 56.6 |  |
| Gross profit |  | $ | 709,980 |  |  | $ | 478,615 |  |  | $ | 231,365 |  |  | 48.3 | % |  | $ | 1,907,090 |  |  | $ | 1,358,065 |  |  | $ | 549,025 |  |  | 40.4 | % |
| Gross margin |  | 60.3 | % |  | 63.9 | % |  |  |  |  |  | 61.4 | % |  | 64.0 | % |  |  |  |  |

[0001596532-22-000294:mdna:17]
[same as prior period, unchanged from 0001596532-22-000220:mdna:17]

[0001596532-22-000294:mdna:18]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2022 |  | % of Total |  | 2021 |  | % of Total |  | 2022 |  | % of Total |  | 2021 |  | % of Total |
| Americas |  | $ | 977,674 |  |  | 83.1 | % |  | $ | 557,814 |  |  | 74.5 | % |  | $ | 2,487,106 |  |  | 80.1 | % |  | $ | 1,573,835 |  |  | 74.2 | % |
| Europe, Middle East and Africa |  | 110,793 |  |  | 9.4 |  |  | 121,722 |  |  | 16.3 |  |  | 350,136 |  |  | 11.3 |  |  | 330,044 |  |  | 15.5 |  |
| Asia-Pacific |  | 88,334 |  |  | 7.5 |  |  | 69,161 |  |  | 9.2 |  |  | 268,516 |  |  | 8.6 |  |  | 219,699 |  |  | 10.3 |  |
| Total revenue |  | $ | 1,176,801 |  |  | 100.0 | % |  | $ | 748,697 |  |  | 100.0 | % |  | $ | 3,105,758 |  |  | 100.0 | % |  | $ | 2,123,578 |  |  | 100.0 | % |

[0001596532-22-000294:mdna:19]
[same as prior period, unchanged from 0001596532-22-000220:mdna:19]

[0001596532-22-000294:mdna:20]
Product revenue primarily consists of sales of our switching and routing products, and related network applications. Service revenue is primarily derived from sales of PCS contracts, which are typically purchased in conjunction with our products, and subsequent renewals of those contracts. We expect our revenue may vary from period to period based on, among other things, the timing, size, and complexity of orders, especially with respect to our large end customers.

[0001596532-22-000294:mdna:21]
Product revenue increased $404.5 million, or 67.0%, and $909.4 million, or 53.2%, for the three and nine months ended September 30, 2022, respectively, compared to the same periods in 2021. These increases reflect strong demand for our switching and routing platforms from across our customer base, including healthy contributions from our large cloud customers. Supply chain constraints continued to impact our revenue performance in these periods and while changes in product deferred revenue impacted the timing of revenue recognition on a quarterly basis, it was not a net contributor to revenue for the nine-month period ended September 30, 2022.  In addition, service revenue increased $23.6 million, or 16.3%, and $72.7 million, or 17.6%, in the three and nine months ended September 30, 2022, compared to the same periods in 2021, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenues represented 16.9% and 19.9% of total revenues in the three and nine months ended September 30, 2022, respectively, decreasing from 25.5% and 25.8% for the same periods in the prior year, which was primarily driven by increased purchases from large global customers in our Americas region. We continued to experience competitive pricing pressure on our products and services.

[0001596532-22-000294:mdna:22]
[same as prior period, unchanged from 0001596532-22-000220:mdna:22]

[0001596532-22-000294:mdna:23]
[same as prior period, unchanged from 0001596532-22-000220:mdna:23]

[0001596532-22-000294:mdna:24]
Cost of revenue increased $196.7 million, or 72.8%, and $433.2 million, or 56.6%, for the three and nine months

[0001596532-22-000294:mdna:25]
ended September 30, 2022, respectively, compared to the same periods in 2021. These increases were primarily driven by a corresponding increase in product and service revenues, combined with an increase in material and logistics costs to mitigate supply chain constraints and to meet customer demand.

[0001596532-22-000294:mdna:26]
[same as prior period, unchanged from 0001596532-22-000220:mdna:26]

[0001596532-22-000294:mdna:27]
Gross margin decreased from 63.9% to 60.3% for the three months ended September 30, 2022, and decreased from 64.0% to 61.4% for the nine months ended September 30, 2022, compared to the same periods in 2021. The decrease in each period was primarily driven by an increased proportion of our sales to larger end customers who generally receive larger discounts and, increased material and logistics costs to mitigate supply chain constraints, partly offset by the impact of fixed overhead costs on a higher revenue base.

[0001596532-22-000294:mdna:28]
[same as prior period, unchanged from 0001596532-22-000220:mdna:28]

[0001596532-22-000294:mdna:29]
[same as prior period, unchanged from 0001596532-22-000220:mdna:29]

[0001596532-22-000294:mdna:30]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2022 |  | 2021 |  | Change in |  | 2022 |  | 2021 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 187,807 |  |  | $ | 153,093 |  |  | $ | 34,714 |  |  | 22.7 | % |  | $ | 537,971 |  |  | $ | 428,873 |  |  | $ | 109,098 |  |  | 25.4 | % |
| Sales and marketing |  | 81,401 |  |  | 69,740 |  |  | 11,661 |  |  | 16.7 |  |  | 241,512 |  |  | 211,385 |  |  | 30,127 |  |  | 14.3 |  |
| General and administrative |  | 23,425 |  |  | 22,488 |  |  | 937 |  |  | 4.2 |  |  | 69,420 |  |  | 58,856 |  |  | 10,564 |  |  | 17.9 |  |
| Total operating expenses |  | $ | 292,633 |  |  | $ | 245,321 |  |  | $ | 47,312 |  |  | 19.3 | % |  | $ | 848,903 |  |  | $ | 699,114 |  |  | $ | 149,789 |  |  | 21.4 | % |

[0001596532-22-000294:mdna:31]
[same as prior period, unchanged from 0001596532-22-000220:mdna:31]

[0001596532-22-000294:mdna:32]
[same as prior period, unchanged from 0001596532-22-000220:mdna:32]

[0001596532-22-000294:mdna:33]
Research and development expenses increased $34.7 million, or 22.7%, and $109.1 million, or 25.4%, in the three and nine months ended September 30, 2022, respectively, compared to the same periods in 2021. The increases were primarily driven by an increase in personnel costs of $25.1 million and $50.5 million for the three and nine months ended September 30, 2022, respectively, compared to the same periods in 2021 due to headcount growth. In addition, new product introduction costs increased by $5.5 million and $37.5 million for the three and nine months ended September 30, 2022, respectively, compared to the same periods in 2021.

[0001596532-22-000294:mdna:34]
[same as prior period, unchanged from 0001596532-22-000220:mdna:34]

[0001596532-22-000294:mdna:35]
[same as prior period, unchanged from 0001596532-22-000220:mdna:35]

[0001596532-22-000294:mdna:36]
Sales and marketing expenses increased $11.7 million, or 16.7%, and $30.1 million, or 14.3%, for the three and nine months ended September 30, 2022, respectively, compared to the same periods in 2021, which was primarily caused by increased personnel costs driven by headcount growth.

[0001596532-22-000294:mdna:37]
[same as prior period, unchanged from 0001596532-22-000220:mdna:37]

[0001596532-22-000294:mdna:38]
[same as prior period, unchanged from 0001596532-22-000220:mdna:38]

[0001596532-22-000294:mdna:39]
General and administrative expenses increased $0.9 million, or 4.2%, and $10.6 million, or 17.9%, in the three and nine months ended September 30, 2022 compared to the same periods in 2021. The increase in the nine months ended September 30, 2022 included an increase in personnel costs, and increased legal and professional fees, primarily driven by acquisitions during the first half of 2022.

[0001596532-22-000294:mdna:40]
[same as prior period, unchanged from 0001596532-22-000220:mdna:40]

[0001596532-22-000294:mdna:41]
[same as prior period, unchanged from 0001596532-22-000220:mdna:41]

[0001596532-22-000294:mdna:42]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2022 |  | 2021 |  | Change in |  | 2022 |  | 2021 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 6,929 |  |  | $ | 1,636 |  |  | $ | 5,293 |  |  | 323.5 | % |  | $ | 13,783 |  |  | $ | 5,553 |  |  | $ | 8,230 |  |  | 148.2 | % |
| Unrealized gain (loss) on equity investments |  | 708 |  |  | — |  |  | 708 |  |  | 100.0 |  |  | 24,121 |  |  | — |  |  | 24,121 |  |  | 100.0 |  |
| Other income (expense), net |  | (820) |  |  | (290) |  |  | (530) |  |  | 182.8 |  |  | (140) |  |  | (913) |  |  | 773 |  |  | (84.7) |  |
| Total other income (expense), net |  | $ | 6,817 |  |  | $ | 1,346 |  |  | $ | 5,471 |  |  | 406.5 | % |  | $ | 37,764 |  |  | $ | 4,640 |  |  | $ | 33,124 |  |  | 713.9 | % |

[0001596532-22-000294:mdna:43]
The movements in other income (expense), net, during the three and nine months ended September 30, 2022 as compared to the same periods in 2021 were driven by an increase in interest income due to higher interest rates. In addition, we had unrealized gains of $24.1 million in the nine months ended September 30, 2022 related to our equity investments.

[0001596532-22-000294:mdna:44]
[same as prior period, unchanged from 0001596532-22-000220:mdna:44]

[0001596532-22-000294:mdna:45]
[same as prior period, unchanged from 0001596532-22-000220:mdna:45]

[0001596532-22-000294:mdna:46]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2022 |  | 2021 |  | Change in |  | 2022 |  | 2021 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Income before income taxes |  | $ | 424,164 |  |  | $ | 234,640 |  |  | $ | 189,524 |  |  | 80.8 | % |  | $ | 1,095,951 |  |  | $ | 663,591 |  |  | $ | 432,360 |  |  | 65.2 | % |
| Provision for income taxes |  | 70,165 |  |  | 10,335 |  |  | 59,830 |  |  | 578.9 | % |  | 170,594 |  |  | 62,032 |  |  | 108,562 |  |  | 175.0 | % |
| Effective tax rate |  | 16.5 | % |  | 4.4 | % |  |  |  |  |  | 15.6 | % |  | 9.3 | % |  |  |  |  |

[0001596532-22-000294:mdna:47]
The increase in the effective tax rates in the three and nine months ended September 30, 2022, as compared to the same periods in 2021, was primarily due to a decrease in the proportion of tax benefits attributable to stock-based compensation versus total pre-tax income.

[0001596532-22-000294:mdna:48]
[same as prior period, unchanged from 0001596532-22-000220:mdna:48]

[0001596532-22-000294:mdna:49]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of September 30, 2022, our total balance of cash, cash equivalents and marketable securities was approximately $3.0 billion, of which approximately $436.8 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-22-000294:mdna:50]
[same as prior period, unchanged from 0001596532-22-000220:mdna:50]

[0001596532-22-000294:mdna:51]
[same as prior period, unchanged from 0001596532-22-000220:mdna:51]

[0001596532-22-000294:mdna:52]
|  |  | Nine Months Ended September 30, |
|  |  | 2022 |  | 2021 |
| Cash provided by operating activities |  | $ | 452,340 |  |  | $ | 790,620 |  |
| Cash provided by (used in) investing activities |  | 299,152 |  |  | (861,363) |  |
| Cash used in financing activities |  | (649,939) |  |  | (189,980) |  |
| Effect of exchange rate changes |  | (6,090) |  |  | (1,513) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 95,463 |  |  | $ | (262,236) |  |

[0001596532-22-000294:mdna:53]
[same as prior period, unchanged from 0001596532-22-000220:mdna:53]

[0001596532-22-000294:mdna:54]
During the nine months ended September 30, 2022, cash provided by operating activities was $452.3 million, primarily from net income of $925.4 million and non-cash adjustments to net income of $66.7 million driven by stock-based compensation and depreciation and amortization, and partly offset by a net increase of $539.7 million in working capital requirements. The increase in working capital requirements primarily consisted of a $449.8 million increase in inventory, $69.0 million increase in prepaid expenses and other current assets, and $17.9 million in other assets, which reflected increased inventory purchases and inventory deposits to contract manufacturers to mitigate supply chain constraints and meet customer demand. In addition, accounts receivable increased by $129.9 million due to increased product and service billings.  These operating cash outflows were partially offset by a $73.5 million increase in accounts payable, and a $41.1 million increase in income tax payables.

[0001596532-22-000294:mdna:55]
During the nine months ended September 30, 2021, cash provided by operating activities was $790.6 million, primarily from net income of $601.6 million and non-cash adjustments to net income of $204.8 million driven by stock-based compensation and depreciation and amortization, and a net increase of $15.8 million in working capital requirements. The increase in working capital requirements primarily consisted of a $96.0 million increase in inventory and a $71.3 million increase in prepaid expenses primarily due to prepaid income taxes and deferred product cost of revenue. These cash outflows were largely offset by a $149.6 million increase in product and service deferred revenue driven by customer contracts with acceptance terms and growth in PCS contracts, and a $31.3 million increase in accrued liabilities due to additional supply chain and software development costs.

[0001596532-22-000294:mdna:56]
[same as prior period, unchanged from 0001596532-22-000220:mdna:56]

[0001596532-22-000294:mdna:57]
During the nine months ended September 30, 2022, cash provided by investing activities was $299.2 million, consisting of proceeds from sales and maturities of marketable securities of $1,464.6 million. These amounts were partially offset by purchases of available-for-sale securities of $973.5 million, and purchases of property and equipment of $34.2 million.

[0001596532-22-000294:mdna:58]
During the nine months ended September 30, 2021, cash used in investing activities was $861.4 million, consisting of purchases of available-for-sale marketable securities of $1,974.9 million, and purchases of property and equipment of $55.5 million, partially offset by proceeds from maturities of marketable securities of $1,158.7 million and proceeds from sale of marketable securities of $19.6 million.

[0001596532-22-000294:mdna:59]
[same as prior period, unchanged from 0001596532-22-000220:mdna:59]

[0001596532-22-000294:mdna:60]
During the nine months ended September 30, 2022, cash used in financing activities was $649.9 million, consisting of payments for repurchases of our common stock from the open market of $667.5 million, and employee taxes withheld and paid of $25.5 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $43.1 million.

[0001596532-22-000294:mdna:61]
During the nine months ended September 30, 2021, cash used in financing activities was $190.0 million, consisting of payments for repurchases of our common stock from the open market of $235.5 million, and employee taxes withheld and paid of $10.6 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $56.1 million.

[0001596532-22-000294:mdna:62]
[same as prior period, unchanged from 0001596532-22-000220:mdna:62]

[0001596532-22-000294:mdna:63]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the “Repurchase Program”). This authorization allowed us to repurchase shares of our common stock over three years and we completed our repurchases under the Repurchase Program during the fourth quarter of 2021. In the fourth quarter of 2021, our board of directors authorized an additional $1.0 billion stock repurchase program (the "New Repurchase Program"). This authorization allows us to repurchase shares of our common stock and will be funded from working capital. The New Repurchase Program commenced in the fourth quarter of 2021, and expires on the three-year anniversary thereof. The New Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the company at any time without prior notice.  During the quarter ended September 30, 2022, we repurchased a total of $47.6 million of our common stock. As of September 30, 2022, the remaining authorized amount for repurchases under the New Repurchase Program was $259.6 million. Refer to Note 6. Stockholders' Equity and Stock-Based Compensation of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of the Quarterly Report on Form 10-Q for further discussion.

[0001596532-22-000294:mdna:64]
[same as prior period, unchanged from 0001596532-22-000220:mdna:64]

[0001596532-22-000294:mdna:65]
[same as prior period, unchanged from 0001596532-22-000220:mdna:65]

[0001596532-22-000294:mdna:66]
[same as prior period, unchanged from 0001596532-22-000220:mdna:66]

[0001596532-22-000294:mdna:67]
[same as prior period, unchanged from 0001596532-22-000220:mdna:67]

[0001596532-22-000294:mdna:68]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of September 30, 2022, we had lease payment obligations, net of immaterial sublease income, of $77.3 million, with $24.7 million payable within 12 months.

[0001596532-22-000294:mdna:69]
[same as prior period, unchanged from 0001596532-22-000220:mdna:69]

[0001596532-22-000294:mdna:70]
Purchase obligations represent an estimate of all non-cancellable open purchase orders and contractual obligations, made either directly by Arista or by our contract manufacturers on our behalf, in the ordinary course of business for which we have not received the goods or services. As of September 30, 2022, we had $4.3 billion of such purchase obligations, of which $3.1 billion are expected to be received within 12 months, and $1.2 billion are expected to be received after one year.  These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-22-000294:mdna:71]
[same as prior period, unchanged from 0001596532-22-000220:mdna:71]

[0001596532-22-000294:mdna:72]
In connection with the Tax Cuts and Jobs Act of 2017("TCJA"), we recorded a federal income tax payable for transition tax on the mandatory deemed repatriation of foreign earnings that will be payable over an eight-year period.  As of September 30, 2022, $6.3 million of long-term transition tax payable represents the remaining federal income tax payable due between one and three years. In addition to the long-term transition tax payable, as of September 30, 2022, we have recorded long-term tax liabilities of $75.8 million related to uncertain tax positions; however, we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-22-000294:mdna:73]
In addition, beginning in 2022, the TCJA eliminates the option to deduct research and development expenditures currently and requires taxpayers to capitalize and amortize them over five or fifteen years pursuant to IRC Section 174. While there is the potential for legislation that would defer the capitalization requirement to later years, we have no assurance that the provision will be repealed or otherwise modified. Consequently, we estimate the incremental cash tax impact resulting from the

[0001596532-22-000294:mdna:74]
new regulations to be approximately $188.0 million for the year, of which the liability for the first nine months of 2022 has been paid as of September 30, 2022; however, we do not anticipate any material change to our effective tax rate.

[0001596532-22-000294:mdna:75]
[same as prior period, unchanged from 0001596532-22-000220:mdna:75]

[0001596532-22-000294:mdna:76]
As of September 30, 2022, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-22-000294:mdna:77]
[same as prior period, unchanged from 0001596532-22-000220:mdna:77]

[0001596532-22-000294:mdna:78]
[same as prior period, unchanged from 0001596532-22-000220:mdna:78]

[0001596532-22-000294:mdna:79]
[same as prior period, unchanged from 0001596532-22-000220:mdna:79]

[0001596532-22-000294:mdna:80]
Refer to the subheading titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
