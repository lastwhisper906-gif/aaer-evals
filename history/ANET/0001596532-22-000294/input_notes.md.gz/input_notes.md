# ANET notes — 0001596532-22-000294


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-22-000294:notes:1]
[same as prior period, unchanged from 0001596532-22-000220:notes:1]

[0001596532-22-000294:notes:2]
[same as prior period, unchanged from 0001596532-22-000220:notes:2]

[0001596532-22-000294:notes:3]
[same as prior period, unchanged from 0001596532-22-000220:notes:3]

[0001596532-22-000294:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2022, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2021 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

[0001596532-22-000294:notes:5]
[same as prior period, unchanged from 0001596532-22-000220:notes:5]

[0001596532-22-000294:notes:6]
[same as prior period, unchanged from 0001596532-22-000220:notes:6]

[0001596532-22-000294:notes:7]
[same as prior period, unchanged from 0001596532-22-000220:notes:7]

[0001596532-22-000294:notes:8]
[same as prior period, unchanged from 0001596532-22-000220:notes:8]

[0001596532-22-000294:notes:9]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including supply chain and labor shortages, inflation and monetary policy shifts, recession risks, the ongoing global coronavirus ("COVID-19") pandemic and potential disruptions from the Russia-Ukraine conflict and the U.S. trade war with China.

[0001596532-22-000294:notes:10]
Our contract manufacturers and suppliers have experienced workforce disruptions, delays in component sourcing, production and export of their products and component shortages and increased component costs, which have disrupted our supply chain and have impacted and will likely continue to impact our ability to supply products to our customers on a timely basis. While overall demand remains strong across our customers base, we believe ongoing supply disruptions combined with other supply chain related constraints could impact our ability to fulfill this increased demand and as a result could negatively impact our business in future periods. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. Our operating cash flows have also been and may continue to be negatively impacted by increased component inventories on hand or at our contract manufacturers, awaiting supply of a limited number of scarce components necessary to build and ship the completed product. The extent of the impact on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, the impact to

[0001596532-22-000294:notes:11]
our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. Management continues to actively monitor the impact of these macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which these factors may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

[0001596532-22-000294:notes:12]
Recently Adopted Accounting Pronouncements

[0001596532-22-000294:notes:13]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. ASU 2021-08 requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC 606. Under previous GAAP, an acquirer generally recognized assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 results in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption impact was immaterial to the condensed consolidated financial statements. The standard did not impact acquired contract assets or liabilities from business combinations occurring prior to the adoption date.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-22-000294:notes:14]
[same as prior period, unchanged from 0001596532-22-000220:notes:14]

[0001596532-22-000294:notes:15]
[same as prior period, unchanged from 0001596532-22-000220:notes:15]

[0001596532-22-000294:notes:16]
|  |  | September 30, 2022 |  | December 31, 2021 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 353,987 |  |  | $ | — |  |  | $ | — |  |  | $ | 353,987 |  |  | $ | 221,382 |  |  | $ | — |  |  | $ | — |  |  | $ | 221,382 |  |
| Certificate of deposits(1) |  | — |  |  | 14,556 |  |  | — |  |  | 14,556 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government notes |  | 23,368 |  |  | — |  |  | — |  |  | 23,368 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Agency securities |  | — |  |  | 46,000 |  |  | — |  |  | 46,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | 377,355 |  |  | 60,556 |  |  | — |  |  | 437,911 |  |  | 221,382 |  |  | — |  |  | — |  |  | 221,382 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 3,487 |  |  | — |  |  | 3,487 |  |  | — |  |  | 141,274 |  |  | — |  |  | 141,274 |  |
| Certificate of deposits(1) |  | — |  |  | 11,422 |  |  | — |  |  | 11,422 |  |  | — |  |  | 44,931 |  |  | — |  |  | 44,931 |  |
| U.S. government notes |  | 1,169,899 |  |  | — |  |  | — |  |  | 1,169,899 |  |  | 1,057,810 |  |  | — |  |  | — |  |  | 1,057,810 |  |
| Corporate bonds |  | — |  |  | 883,784 |  |  | — |  |  | 883,784 |  |  | — |  |  | 1,252,226 |  |  | — |  |  | 1,252,226 |  |
| Agency securities |  | — |  |  | 179,473 |  |  | — |  |  | 179,473 |  |  | — |  |  | 291,261 |  |  | — |  |  | 291,261 |  |
| Marketable equity securities(2) |  | 15,753 |  |  | — |  |  | — |  |  | 15,753 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | 1,185,652 |  |  | 1,078,166 |  |  | — |  |  | 2,263,818 |  |  | 1,057,810 |  |  | 1,729,692 |  |  | — |  |  | 2,787,502 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,260 |  |  | — |  |  | — |  |  | 4,260 |  |  | 4,237 |  |  | — |  |  | — |  |  | 4,237 |  |
| Total Financial Assets |  | $ | 1,567,267 |  |  | $ | 1,138,722 |  |  | $ | — |  |  | $ | 2,705,989 |  |  | $ | 1,283,429 |  |  | $ | 1,729,692 |  |  | $ | — |  |  | $ | 3,013,121 |  |

[0001596532-22-000294:notes:17]
[same as prior period, unchanged from 0001596532-22-000220:notes:17]

[0001596532-22-000294:notes:18]
(1) As of September 30, 2022 and December 31, 2021, all of our certificates of deposits were domestic deposits.

[0001596532-22-000294:notes:19]
(2) The $15.8 million represents the fair value of marketable equity securities as of September 30, 2022. This amount includes $8.3 million that was reclassified from Investments on our condensed consolidated balance sheet following the commencement of public market trading of the issuer in January 2022. This publicly-traded equity investment generated an unrealized gain of $7.5 million for the nine months ended September 30, 2022, and an unrealized loss of $0.9 million for the three months ended September 30, 2022.  The unrealized gains and losses are included in Other income (expense), net on the unaudited Condensed Consolidated Statements of Operations. Refer to Note 3. Financial Statements Details.

[0001596532-22-000294:notes:20]
During the three and nine months ended on September 30, 2022, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-22-000294:notes:21]
[same as prior period, unchanged from 0001596532-22-000220:notes:21]

[0001596532-22-000294:notes:22]
[same as prior period, unchanged from 0001596532-22-000220:notes:22]

[0001596532-22-000294:notes:23]
|  |  | September 30, 2022 |  | December 31, 2021 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 3,487 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,487 |  |  | $ | 141,274 |  |  | $ | — |  |  | $ | — |  |  | $ | 141,274 |  |
| U.S. government |  | 1,187,901 |  |  | — |  |  | (18,002) |  |  | 1,169,899 |  |  | 1,060,716 |  |  | 3 |  |  | (2,909) |  |  | 1,057,810 |  |
| Corporate bonds |  | 902,133 |  |  | — |  |  | (18,349) |  |  | 883,784 |  |  | 1,255,149 |  |  | 105 |  |  | (3,028) |  |  | 1,252,226 |  |
| Agency securities |  | 182,771 |  |  | — |  |  | (3,298) |  |  | 179,473 |  |  | 291,558 |  |  | 36 |  |  | (333) |  |  | 291,261 |  |
| Total |  | $ | 2,276,292 |  |  | $ | — |  |  | $ | (39,649) |  |  | $ | 2,236,643 |  |  | $ | 2,748,697 |  |  | $ | 144 |  |  | $ | (6,270) |  |  | $ | 2,742,571 |  |

[0001596532-22-000294:notes:24]
For debt securities in unrealized loss positions, it is not likely that we will be required to sell such securities before recovery of their amortized cost basis nor do we have the intent to sell such securities before maturity; we invest in debt securities that have maximum maturities of two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. Given the short-term and conservative nature of our portfolio, the unrealized losses are not related to credit risk; therefore, we did not recognize any credit losses or non-credit-related impairments related to our available-for-sale marketable debt securities for the three and nine months ended September 30, 2022. All unrealized losses were recognized in other comprehensive income (loss). Realized losses were immaterial for the three and nine months ended September 30, 2022.

[0001596532-22-000294:notes:25]
[same as prior period, unchanged from 0001596532-22-000220:notes:25]

[0001596532-22-000294:notes:26]
|  |  | September 30, 2022 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 877,442 |  |  | $ | (13,026) |  |  | $ | 292,554 |  |  | $ | (4,976) |  |  | $ | 1,169,996 |  |  | $ | (18,002) |  |
| Corporate bonds |  | 625,577 |  |  | (13,314) |  |  | 258,208 |  |  | (5,035) |  |  | 883,785 |  |  | (18,349) |  |
| Agency securities |  | 155,296 |  |  | (2,807) |  |  | 24,176 |  |  | (491) |  |  | 179,472 |  |  | (3,298) |  |
| Total |  | $ | 1,658,315 |  |  | $ | (29,147) |  |  | $ | 574,938 |  |  | $ | (10,502) |  |  | $ | 2,233,253 |  |  | $ | (39,649) |  |

[0001596532-22-000294:notes:27]
As of September 30, 2022, we had no marketable debt securities with contractual maturities that exceed 24 months. The fair values of marketable debt securities, by remaining contractual maturities, are as follows (in thousands):

[0001596532-22-000294:notes:28]
|  |  | September 30, 2022 |
|  |  | Fair Value |
| Due in 1 year or less |  | $ | 1,773,158 |  |
| Due in 1 to 2 years |  | 463,485 |  |
| Total debt securities |  | $ | 2,236,643 |  |

[0001596532-22-000294:notes:29]
The weighted-average remaining duration of our marketable debt securities is approximately 0.6 years as of September 30, 2022. As we view these marketable debt securities as available to support current operations, we classify marketable debt securities with maturities beyond 12 months as current assets under the caption "Marketable securities" on the condensed consolidated balance sheets.

[0001596532-22-000294:notes:30]
[same as prior period, unchanged from 0001596532-22-000220:notes:30]

[0001596532-22-000294:notes:31]
[same as prior period, unchanged from 0001596532-22-000220:notes:31]

[0001596532-22-000294:notes:32]
[same as prior period, unchanged from 0001596532-22-000220:notes:32]

[0001596532-22-000294:notes:33]
We did not record any realized gains or losses for our non-marketable equity securities measured at fair value on a non-recurring basis during the three and nine months ended September 30, 2022 and September 30, 2021. We recorded unrealized gains of $1.7 million and $16.7 million on non-marketable equity securities based on observable price changes from orderly transactions of identical or similar securities in three and the nine months ended September 30, 2022. We recorded immaterial unrealized losses in the three and nine months ended September 30, 2022. We evaluate our non-marketable equity securities for impairment at each reporting period via a qualitative assessment with various potential impairment indicators, including, but not limited to, an assessment of a significant adverse change in the economic environment, significant adverse changes in the general market condition of the geographies and industries in which our investees operate, and other publicly-available information that affected the value of the its non-marketable equity securities.

[0001596532-22-000294:notes:34]
The following table summarizes the activity related to our non-marketable equity securities as of September 30, 2022 and December 31, 2021 (in thousands):

[0001596532-22-000294:notes:35]
|  |  | September 30, 2022 |  | December 31, 2021 |
| Cost of investments (1) |  | $ | 23,625 |  |  | $ | 14,933 |  |
| Cumulative impairment and downward adjustment |  | (629) |  |  | — |  |
| Cumulative upward adjustment (1) |  | 16,681 |  |  | 5,314 |  |
| Carrying amount of investments |  | $ | 39,677 |  |  | $ | 20,247 |  |

[0001596532-22-000294:notes:36]
(1) During the nine months ended September 30, 2022, $3.0 million previously included in the Cost of investments and $5.3 million previously included in the Cumulative upward adjustment, or $8.3 million in aggregate, were reclassified from Investments to Marketable securities on our condensed consolidated balance sheet following the commencement of public market trading of the issuer. There was no such activity in the three months ended September 30, 2022.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-22-000294:notes:37]
[same as prior period, unchanged from 0001596532-22-000220:notes:37]

[0001596532-22-000294:notes:38]
(1) As of September 30, 2022 and December 31, 2021, all of our certificates of deposits were domestic deposits.
(2) The $15.8 million represents the fair value of marketable equity securities as of September 30, 2022. This amount includes $8.3 million that was reclassified from Investments on our condensed consolidated balance sheet following the commencement of public market trading of the issuer in January 2022. This publicly-traded equity investment generated an unrealized gain of $7.5 million for the nine months ended September 30, 2022, and an unrealized loss of $0.9 million for the three months ended September 30, 2022.  The unrealized gains and losses are included in Other income (expense), net on the unaudited Condensed Consolidated Statements of Operations. Refer to Note 3. Financial Statements Details.The following table summarizes the amortized cost, unrealized gains and losses, and fair value of our debt securities measured at fair value on a recurring basis (in thousands):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-22-000294:notes:39]
[same as prior period, unchanged from 0001596532-22-000220:notes:39]

[0001596532-22-000294:notes:40]
[same as prior period, unchanged from 0001596532-22-000220:notes:40]

[0001596532-22-000294:notes:41]
|  |  | September 30, 2022 |  | December 31, 2021 |
| Cash and cash equivalents |  | $ | 716,253 |  |  | $ | 620,813 |  |
| Restricted cash included in other assets |  | 4,260 |  |  | 4,237 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 720,513 |  |  | $ | 625,050 |  |

[0001596532-22-000294:notes:42]
[same as prior period, unchanged from 0001596532-22-000220:notes:42]

[0001596532-22-000294:notes:43]
[same as prior period, unchanged from 0001596532-22-000220:notes:43]

[0001596532-22-000294:notes:44]
|  |  | September 30, 2022 |  | December 31, 2021 |
| Accounts receivable |  | $ | 660,108 |  |  | $ | 521,597 |  |
| Allowance for doubtful accounts |  | (215) |  |  | (132) |  |
| Product sales rebate and returns reserve |  | (8,381) |  |  | (4,956) |  |
| Accounts receivable, net |  | $ | 651,512 |  |  | $ | 516,509 |  |

[0001596532-22-000294:notes:45]
[same as prior period, unchanged from 0001596532-22-000220:notes:45]

[0001596532-22-000294:notes:46]
[same as prior period, unchanged from 0001596532-22-000220:notes:46]

[0001596532-22-000294:notes:47]
|  |  | September 30, 2022 |  | December 31, 2021 |
| Raw materials |  | $ | 629,058 |  |  | $ | 316,737 |  |
| Finished goods |  | 471,492 |  |  | 333,380 |  |
| Total inventories |  | $ | 1,100,550 |  |  | $ | 650,117 |  |

[0001596532-22-000294:notes:48]
[same as prior period, unchanged from 0001596532-22-000220:notes:48]

[0001596532-22-000294:notes:49]
[same as prior period, unchanged from 0001596532-22-000220:notes:49]

[0001596532-22-000294:notes:50]
|  |  | September 30, 2022 |  | December 31, 2021 |
| Inventory deposits |  | $ | 121,916 |  |  | $ | 46,311 |  |
| Prepaid income taxes |  | 1,409 |  |  | 8,977 |  |
| Other current assets |  | 142,627 |  |  | 163,916 |  |
| Other prepaid expenses and deposits |  | 33,593 |  |  | 18,531 |  |
| Total prepaid expenses and other current assets |  | $ | 299,545 |  |  | $ | 237,735 |  |

[0001596532-22-000294:notes:51]
[same as prior period, unchanged from 0001596532-22-000220:notes:51]

[0001596532-22-000294:notes:52]
[same as prior period, unchanged from 0001596532-22-000220:notes:52]

[0001596532-22-000294:notes:53]
|  |  | September 30, 2022 |  | December 31, 2021 |
| Land |  | $ | 40,601 |  |  | $ | 40,145 |  |
| Equipment and machinery |  | 119,379 |  |  | 90,915 |  |
| Computer hardware and software |  | 51,254 |  |  | 44,083 |  |
| Leasehold improvements |  | 30,060 |  |  | 30,502 |  |
| Furniture and fixtures |  | 3,573 |  |  | 3,634 |  |
| Construction-in-process |  | 1,997 |  |  | 2,378 |  |
| Property and equipment, gross |  | 246,864 |  |  | 211,657 |  |
| Less: accumulated depreciation |  | (150,415) |  |  | (133,023) |  |
| Property and equipment, net |  | $ | 96,449 |  |  | $ | 78,634 |  |

[0001596532-22-000294:notes:54]
Depreciation expense was $6.9 million and $4.9 million for the three months ended September 30, 2022 and 2021, respectively, and $18.7 million and $14.6 million for the nine months ended September 30, 2022 and 2021, respectively.

[0001596532-22-000294:notes:55]
[same as prior period, unchanged from 0001596532-22-000220:notes:55]

[0001596532-22-000294:notes:56]
[same as prior period, unchanged from 0001596532-22-000220:notes:56]

[0001596532-22-000294:notes:57]
|  |  | September 30, 2022 |  | December 31, 2021 |
| Accrued payroll related costs |  | $ | 82,791 |  |  | $ | 99,571 |  |
| Accrued manufacturing costs |  | 103,098 |  |  | 80,213 |  |
| Accrued product development costs |  | 25,282 |  |  | 22,188 |  |
| Accrued warranty costs |  | 14,314 |  |  | 10,414 |  |
| Other |  | 15,124 |  |  | 14,257 |  |
| Total accrued liabilities |  | $ | 240,609 |  |  | $ | 226,643 |  |

[0001596532-22-000294:notes:58]
[same as prior period, unchanged from 0001596532-22-000220:notes:58]

[0001596532-22-000294:notes:59]
[same as prior period, unchanged from 0001596532-22-000220:notes:59]

[0001596532-22-000294:notes:60]
|  |  | Nine Months Ended September 30, |
|  |  | 2022 |  | 2021 |
| Warranty accrual, beginning of period |  | $ | 10,414 |  |  | $ | 9,314 |  |
| Liabilities accrued for warranties issued during the period |  | 13,887 |  |  | 8,643 |  |
| Warranty costs incurred during the period |  | (9,987) |  |  | (8,429) |  |
| Warranty accrual, end of period |  | $ | 14,314 |  |  | $ | 9,528 |  |

[0001596532-22-000294:notes:61]
[same as prior period, unchanged from 0001596532-22-000220:notes:61]

[0001596532-22-000294:notes:62]
[same as prior period, unchanged from 0001596532-22-000220:notes:62]

[0001596532-22-000294:notes:63]
|  |  | Nine Months Ended September 30, |
|  |  | 2022 |  |  |  |  |
| Contract assets, beginning balance |  | $ | 24,388 |  |  |  |  |  |
| Contract assets, ending balance |  | 13,525 |  |  |  |  |  |

[0001596532-22-000294:notes:64]
[same as prior period, unchanged from 0001596532-22-000220:notes:64]

[0001596532-22-000294:notes:65]
[same as prior period, unchanged from 0001596532-22-000220:notes:65]

[0001596532-22-000294:notes:66]
[same as prior period, unchanged from 0001596532-22-000220:notes:66]

[0001596532-22-000294:notes:67]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Contract liabilities, beginning balance |  | $ | 101,600 |  |  | $ | 83,354 |  |  | $ | 93,382 |  |  | $ | 85,957 |  |
| Less: Revenue recognized from beginning balance |  | (9,173) |  |  | (8,763) |  |  | (29,296) |  |  | (27,251) |  |
| Less: Beginning balance reclassified to deferred revenue |  | (9,898) |  |  | (3,996) |  |  | (2,998) |  |  | (2,443) |  |
| Add: Contract liabilities recognized |  | 18,247 |  |  | 16,976 |  |  | 39,688 |  |  | 31,308 |  |
| Contract liabilities, ending balance |  | $ | 100,776 |  |  | $ | 87,571 |  |  | $ | 100,776 |  |  | $ | 87,571 |  |

[0001596532-22-000294:notes:68]
As of September 30, 2022 and December 31, 2021, $42.2 million and $38.7 million of our contract liabilities, respectively, were included in "Other current liabilities" with the remaining balances included in "Other long-term liabilities" on the condensed consolidated balance sheets.

[0001596532-22-000294:notes:69]
[same as prior period, unchanged from 0001596532-22-000220:notes:69]

[0001596532-22-000294:notes:70]
[same as prior period, unchanged from 0001596532-22-000220:notes:70]

[0001596532-22-000294:notes:71]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Deferred revenue, beginning balance |  | $ | 1,033,490 |  |  | $ | 746,090 |  |  | $ | 929,312 |  |  | $ | 650,827 |  |
| Less: Revenue recognized from beginning balance |  | (234,515) |  |  | (164,188) |  |  | (457,309) |  |  | (327,300) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 142,069 |  |  | 218,538 |  |  | 469,041 |  |  | 476,913 |  |
| Deferred revenue, ending balance |  | $ | 941,044 |  |  | $ | 800,440 |  |  | $ | 941,044 |  |  | $ | 800,440 |  |

[0001596532-22-000294:notes:72]
[same as prior period, unchanged from 0001596532-22-000220:notes:72]

[0001596532-22-000294:notes:73]
Other performance obligations include unbilled contract revenue for services and products that will be recognized in future periods. As of September 30, 2022, other performance obligations of $178.6 million were comprised mainly of unbilled multi-year PCS contract amounts that will be recognized as revenue in future periods. In addition, as of September 30, 2022 the company had entered into $844.2 million of binding contractual agreements with certain customers that are primarily related to future product shipments.

[0001596532-22-000294:notes:74]
[same as prior period, unchanged from 0001596532-22-000220:notes:74]

[0001596532-22-000294:notes:75]
Revenue from total remaining performance obligations represents contract liabilities, deferred revenue and unbilled contract revenue that will be recognized in future periods. As of September 30, 2022, approximately $1,220.5 million of revenue is expected to be recognized from remaining performance obligations, of which approximately 82% is expected to be

[0001596532-22-000294:notes:76]
recognized over the next two years and approximately 18% is expected to be recognized during the third to the fifth year. These amounts do not include the $844.2 million of binding contractual agreements related primarily to future product shipments outlined above. As of September 30, 2022, it is expected that the majority of the amounts allocated to these specific performance obligations will be recognized as revenue upon product shipment over the next two years; however, given the current uncertain supply chain environment and industry wide supply constraints, we may experience manufacturing and shipment delays or cancellations related to these performance obligations, which could impact revenue recognition.

[0001596532-22-000294:notes:77]
[same as prior period, unchanged from 0001596532-22-000220:notes:76]

[0001596532-22-000294:notes:78]
[same as prior period, unchanged from 0001596532-22-000220:notes:77]

[0001596532-22-000294:notes:79]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Interest income |  | $ | 6,929 |  |  | $ | 1,636 |  |  | $ | 13,783 |  |  | $ | 5,553 |  |
| Unrealized gain on equity investments |  | 708 |  |  | — |  |  | 24,121 |  |  | — |  |
| Other income (expense), net |  | (820) |  |  | (290) |  |  | (140) |  |  | (913) |  |
| Total |  | $ | 6,817 |  |  | $ | 1,346 |  |  | $ | 37,764 |  |  | $ | 4,640 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-22-000294:notes:80]
[same as prior period, unchanged from 0001596532-22-000220:notes:79]

[0001596532-22-000294:notes:81]
[same as prior period, unchanged from 0001596532-22-000220:notes:80]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-22-000294:notes:82]
[same as prior period, unchanged from 0001596532-22-000220:notes:81]

[0001596532-22-000294:notes:83]
During the nine months ended September 30, 2022, we completed two acquisitions of private companies for total consideration of $158.9 million including $4.0 million in common stock and the remainder in cash. The purchase prices included $62.3 million of intangible assets, $82.6 million of goodwill and $14.0 million of net tangible assets acquired. We also incurred certain acquisition-related expenses of $4.7 million, which primarily consisted of retention bonuses to continuing employees as well as professional and consulting fees.

[0001596532-22-000294:notes:84]
[same as prior period, unchanged from 0001596532-22-000220:notes:83]

[0001596532-22-000294:notes:85]
[same as prior period, unchanged from 0001596532-22-000220:notes:84]

[0001596532-22-000294:notes:86]
[same as prior period, unchanged from 0001596532-22-000220:notes:85]

[0001596532-22-000294:notes:87]
The changes in the carrying values of goodwill for the three and nine  months ended September 30, 2022 are as follows (in thousands):

[0001596532-22-000294:notes:88]
|  |  | Amount |
| Balance at December 31, 2021 |  | $ | 188,397 |  |
| Additions related to the acquisition completed in January 2022 |  | 28,518 |  |
| Balance at March 31, 2022 |  | $ | 216,915 |  |
| Additions related to the acquisition completed in June 2022 |  | 56,530 |  |
| Measurement-period adjustments |  | 49 |  |
| Balance at June 30, 2022 |  | $ | 273,494 |  |
| Measurement-period adjustments |  | (2,476) |  |
| Balance at September 30, 2022 |  | $ | 271,018 |  |

[0001596532-22-000294:notes:89]
[same as prior period, unchanged from 0001596532-22-000220:notes:88]

[0001596532-22-000294:notes:90]
[same as prior period, unchanged from 0001596532-22-000220:notes:89]

[0001596532-22-000294:notes:91]
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life (in years) |
|  | December 31, 2021 |  | Additions |  | September 30, 2022 |  | December 31, 2021 |  | Amortization |  | September 30, 2022 |  | December 31, 2021 |  | September 30, 2022 |  |
| Developed technology | $ | 124,730 |  |  | $ | 30,200 |  |  | $ | 154,930 |  |  | $ | (53,663) |  |  | $ | (18,553) |  |  | $ | (72,216) |  |  | $ | 71,067 |  |  | $ | 82,714 |  |  | 4.5 |
| Customer relationships | 25,920 |  |  | 28,700 |  |  | 54,620 |  |  | (7,899) |  |  | (4,272) |  |  | (12,171) |  |  | 18,021 |  |  | 42,449 |  |  | 5.9 |
| Trade name | 8,990 |  |  | 3,400 |  |  | 12,390 |  |  | (4,693) |  |  | (1,340) |  |  | (6,033) |  |  | 4,297 |  |  | 6,357 |  |  | 2.8 |
| Others | 5,720 |  |  | — |  |  | 5,720 |  |  | (5,550) |  |  | (170) |  |  | (5,720) |  |  | 170 |  |  | — |  |  | 0.0 |
| Total | $ | 165,360 |  |  | $ | 62,300 |  |  | $ | 227,660 |  |  | $ | (71,805) |  |  | $ | (24,335) |  |  | $ | (96,140) |  |  | $ | 93,555 |  |  | $ | 131,520 |  |  | 4.9 |

[0001596532-22-000294:notes:92]
Amortization expense related to acquisition-related intangible assets was $9.3 million, and $7.3 million for the three months ended September 30, 2022 and 2021, and $24.3 million and $22.1 million for the nine months ended September 30, 2022 and 2021, respectively.

[0001596532-22-000294:notes:93]
As of September 30, 2022, future estimated amortization expense related to the acquisition-related intangible assets is as follows (in thousands):

[0001596532-22-000294:notes:94]
|  |  | Future Amortization Expense |
| Remainder of 2022 |  | $ | 9,315 |  |
| 2023 |  | 33,438 |  |
| 2024 |  | 26,759 |  |
| 2025 |  | 19,642 |  |
| 2026 |  | 17,260 |  |
| Thereafter |  | 25,106 |  |
| Total |  | $ | 131,520 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-22-000294:notes:95]
Commitments and Contingencies
Purchase Commitments

[0001596532-22-000294:notes:96]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2022, we had non-cancellable purchase commitments of $4.3 billion, of which $3.1 billion have confirmed receipt dates within 12 months, and $1.2 billion have confirmed receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-22-000294:notes:97]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $124.7 million and $49.1 million as of September 30, 2022 and December 31, 2021, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

[0001596532-22-000294:notes:98]
Guarantees

[0001596532-22-000294:notes:99]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-22-000294:notes:100]
Legal Proceedings

[0001596532-22-000294:notes:101]
WSOU Investments, LLC

[0001596532-22-000294:notes:102]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California.  On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement.  On July 1, 2022, the court stayed the case pending the resolution of an inter partes review of one of the patents-in-suit.

[0001596532-22-000294:notes:103]
We intend to vigorously defend against the claims brought against us by WSOU; however, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-22-000294:notes:104]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated; however, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-22-000294:notes:105]
Other matters

[0001596532-22-000294:notes:106]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-22-000294:notes:107]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2022, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-22-000294:notes:108]
[same as prior period, unchanged from 0001596532-22-000220:notes:107]

[0001596532-22-000294:notes:109]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the "Repurchase Program").  This authorization allowed us to repurchase shares of our common stock over three years, and we completed our repurchases under the Repurchase Program during the fourth quarter of 2021. In the fourth quarter of 2021, our board of directors authorized an additional $1.0 billion stock repurchase program (the “New Repurchase Program”), which allows us to repurchase shares of our common stock to be funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Exchange Act, or a combination of the foregoing. The New Repurchase Program commenced in November 2021 and expires on the three-year anniversary thereof. The New Repurchase Program does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of September 30, 2022, the remaining authorized amount for stock repurchases under this program was approximately $259.6 million.

[0001596532-22-000294:notes:110]
A summary of the stock repurchase activity under the New Repurchase Program for the nine months ended September 30, 2022 is as follows (in thousands, except per share amounts):

[0001596532-22-000294:notes:111]
|  |  |  |  |  |  | Nine Months Ended |
|  |  |  |  |  |  | September 30, 2022 |
| Aggregate purchase price |  |  |  |  |  | $ | 667,470 |  |
| Shares repurchased |  |  |  |  |  | 6,433 |  |
| Average price paid per share |  |  |  |  |  | $ | 103.75 |  |

[0001596532-22-000294:notes:112]
The aggregate purchase price of repurchased shares of our common stock is recorded as a reduction to retained earnings in our unaudited condensed consolidated statements of stockholders' equity.  All shares repurchased have been retired.

[0001596532-22-000294:notes:113]
[same as prior period, unchanged from 0001596532-22-000220:notes:112]

[0001596532-22-000294:notes:114]
[same as prior period, unchanged from 0001596532-22-000220:notes:113]

[0001596532-22-000294:notes:115]
[same as prior period, unchanged from 0001596532-22-000220:notes:114]

[0001596532-22-000294:notes:116]
Awards granted under the 2014 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Units (“RSUs”), Restricted Stock Awards (“RSAs”) or Stock Appreciation Rights (“SARs”). The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of the outstanding shares of our common stock on the immediately preceding December 31, but not to exceed 50,000,000 shares (the “2014 Plan Evergreen Increase”), unless our board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2022, our board of directors authorized an increase of 9,230,434 shares to the shares available for issuance under the 2014 Plan. As of September 30, 2022, there remained approximately 93.4 million shares available for issuance under the 2014 Plan.

[0001596532-22-000294:notes:117]
[same as prior period, unchanged from 0001596532-22-000220:notes:116]

[0001596532-22-000294:notes:118]
In April 2014, our board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding on the immediately preceding December 31, but not to exceed 10,000,000 shares, unless our board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2022, our board of directors authorized an increase of 3,076,811 shares to the shares available for issuance under the ESPP. During the nine months ended September 30, 2022, we issued 485,303 shares at a weighted-average purchase price of $50.37 per share under the ESPP. As of September 30, 2022, there remained approximately 20.6 million shares available for issuance under the ESPP.

[0001596532-22-000294:notes:119]
[same as prior period, unchanged from 0001596532-22-000220:notes:118]

[0001596532-22-000294:notes:120]
[same as prior period, unchanged from 0001596532-22-000220:notes:119]

[0001596532-22-000294:notes:121]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2021 |  | 8,685 |  |  | $ | 12.45 |  |  | 2.8 |  | $ | 1,140,369 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (1,938) |  |  | 9.61 |  |  |  |  |  |
| Options canceled |  | (177) |  |  | 15.68 |  |  |  |  |  |
| Balance—September 30, 2022 |  | 6,570 |  |  | $ | 13.19 |  |  | 2.1 |  | $ | 654,987 |  |
| Vested and exercisable—September 30, 2022 |  | 5,759 |  |  | $ | 10.91 |  |  | 1.8 |  | $ | 587,246 |  |

[0001596532-22-000294:notes:122]
[same as prior period, unchanged from 0001596532-22-000220:notes:121]

[0001596532-22-000294:notes:123]
[same as prior period, unchanged from 0001596532-22-000220:notes:122]

[0001596532-22-000294:notes:124]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2021 |  | 7,821 |  |  | $ | 70.98 |  |  | 1.7 |  | $ | 1,124,229 |  |
| RSUs granted |  | 3,469 |  |  | 100.56 |  |  |  |  |  |
| RSUs vested |  | (2,006) |  |  | 64.50 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (389) |  |  | 76.53 |  |  |  |  |  |
| Unvested balance—September 30, 2022 |  | 8,895 |  |  | $ | 83.91 |  |  | 1.8 |  | $ | 1,004,214 |  |

[0001596532-22-000294:notes:125]
[same as prior period, unchanged from 0001596532-22-000220:notes:124]

[0001596532-22-000294:notes:126]
[same as prior period, unchanged from 0001596532-22-000220:notes:125]

[0001596532-22-000294:notes:127]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cost of revenue |  | $ | 2,992 |  |  | $ | 2,002 |  |  | $ | 6,613 |  |  | $ | 5,198 |  |
| Research and development |  | 37,698 |  |  | 27,552 |  |  | 93,723 |  |  | 72,673 |  |
| Sales and marketing |  | 16,103 |  |  | 12,680 |  |  | 42,039 |  |  | 34,133 |  |
| General and administrative |  | 8,684 |  |  | 10,901 |  |  | 23,605 |  |  | 23,628 |  |
| Total stock-based compensation |  | $ | 65,477 |  |  | $ | 53,135 |  |  | $ | 165,980 |  |  | $ | 135,632 |  |

[0001596532-22-000294:notes:128]
As of September 30, 2022, there were $667.1 million of unamortized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 3.4 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-22-000294:notes:129]
[same as prior period, unchanged from 0001596532-22-000220:notes:128]

[0001596532-22-000294:notes:130]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2022 |  | 2021 (1) |  | 2022 |  | 2021 (1) |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 353,999 |  |  | $ | 224,305 |  |  | $ | 925,357 |  |  | $ | 601,559 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share, basic |  | 304,931 |  |  | 307,456 |  |  | 306,576 |  |  | 306,176 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity awards |  | 9,470 |  |  | 12,180 |  |  | 10,169 |  |  | 12,800 |  |
| Weighted-average shares used in computing net income per share, diluted |  | 314,401 |  |  | 319,636 |  |  | 316,745 |  |  | 318,976 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.16 |  |  | $ | 0.73 |  |  | $ | 3.02 |  |  | $ | 1.96 |  |
| Diluted |  | $ | 1.13 |  |  | $ | 0.70 |  |  | $ | 2.92 |  |  | $ | 1.89 |  |

[0001596532-22-000294:notes:131]
[same as prior period, unchanged from 0001596532-22-000220:notes:130]

[0001596532-22-000294:notes:132]
[same as prior period, unchanged from 0001596532-22-000220:notes:131]

[0001596532-22-000294:notes:133]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |  |  |
|  |  | 2022 |  | 2021 (1) |  | 2022 |  | 2021 (1) |  |  |  |  |
| Stock options and RSUs |  | 292 |  |  | 36 |  |  | 379 |  |  | 320 |  |  |  |  |  |
| Employee stock purchase plan |  | 295 |  |  | 24 |  |  | 104 |  |  | 48 |  |  |  |  |  |
| Total |  | 587 |  |  | 60 |  |  | 483 |  |  | 368 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-22-000294:notes:134]
[same as prior period, unchanged from 0001596532-22-000220:notes:133]

[0001596532-22-000294:notes:135]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |  |  |  |  |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  |  |  |  |
| Income before income taxes |  | $ | 424,164 |  |  | $ | 234,640 |  |  | $ | 1,095,951 |  | $ | 663,591 |  |  |  |  |  |
| Provision for income taxes |  | 70,165 |  |  | 10,335 |  |  | $ | 170,594 |  | 62,032 |  |  |  |  |  |
| Effective tax rate |  | 16.5 | % |  | 4.4 | % |  | 15.6 | % |  | 9.3 | % |  |  |  |  |

[0001596532-22-000294:notes:136]
The increase in the effective tax rates in the three and nine months ended September 30, 2022, as compared to the same periods in 2021, was primarily due to a decrease in the proportion of tax benefits attributable to stock-based compensation versus total pre-tax income.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-22-000294:notes:137]
[same as prior period, unchanged from 0001596532-22-000220:notes:136]

[0001596532-22-000294:notes:138]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Americas |  | $ | 977,674 |  |  | $ | 557,814 |  |  | $ | 2,487,106 |  |  | $ | 1,573,835 |  |
| Europe, Middle East and Africa |  | 110,793 |  |  | 121,722 |  |  | 350,136 |  |  | 330,044 |  |
| Asia-Pacific |  | 88,334 |  |  | 69,161 |  |  | 268,516 |  |  | 219,699 |  |
| Total revenue |  | $ | 1,176,801 |  |  | $ | 748,697 |  |  | $ | 3,105,758 |  |  | $ | 2,123,578 |  |

[0001596532-22-000294:notes:139]
[same as prior period, unchanged from 0001596532-22-000220:notes:138]

[0001596532-22-000294:notes:140]
|  |  | September 30, 2022 |  | December 31, 2021 |
| United States |  | $ | 76,578 |  |  | $ | 62,163 |  |
| International |  | 19,871 |  |  | 16,471 |  |
| Total |  | $ | 96,449 |  |  | $ | 78,634 |  |
