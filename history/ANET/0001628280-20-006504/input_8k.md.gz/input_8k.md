# ANET 8-K — 0001628280-20-006442 filed 2020-05-05

## item codes, every 8-K on or before 2020-05-06

- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2020-05-06

- none on or before 2020-05-06

## item 2.02 — earnings release, exhibit 99.1

[0001628280-20-006442:8k_2_02:1]
EX-99.Q120 EARNINGS
2
ex991q120-earningsrelease.htm
EXHIBIT 99.Q120 EARNINGS

[0001628280-20-006442:8k_2_02:2]
Exhibit

[0001628280-20-006442:8k_2_02:3]
Exhibit 99.1

[0001628280-20-006442:8k_2_02:4]
Arista Networks, Inc. Reports First Quarter 2020 Financial Results

[0001628280-20-006442:8k_2_02:5]
SANTA CLARA, Calif.- May 5, 2020 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large datacenter and campus environments, today announced financial results for its first quarter ended March 31, 2020.

[0001628280-20-006442:8k_2_02:6]
First Quarter Financial Highlights

[0001628280-20-006442:8k_2_02:7]
| • | Revenue of $523.0 million, a decrease of 5.3% compared to the fourth quarter of 2019, and a decrease of 12.2% from the first quarter of 2019. |

[0001628280-20-006442:8k_2_02:8]
| • | GAAP gross margin of 64.7%, compared to GAAP gross margin of 64.5% in the fourth quarter of 2019 and 63.9% in the first quarter of 2019. |

[0001628280-20-006442:8k_2_02:9]
| • | Non-GAAP gross margin of 65.6%, compared to non-GAAP gross margin of 65.2% in the fourth quarter of 2019 and 64.5% in the first quarter of 2019. |

[0001628280-20-006442:8k_2_02:10]
| • | GAAP net income of $138.4 million, or $1.73 per diluted share, compared to GAAP net income of $201.0 million, or $2.47 per diluted share in the first quarter of 2019. |

[0001628280-20-006442:8k_2_02:11]
| • | Non-GAAP net income of $161.7 million, or $2.02 per diluted share, compared to non-GAAP net income of $187.7 million, or $2.31 per diluted share in the first quarter of 2019. |

[0001628280-20-006442:8k_2_02:12]
"Arista delivered solid Q1 2020 financial results despite the global pandemic that we all are experiencing. We are committed to our employees' safety while bringing value to our customers, shareholders and community in these unpredictable times and believe we will emerge stronger in the long term,” stated Jayshree Ullal, Arista’s President and CEO.

[0001628280-20-006442:8k_2_02:13]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, “We are pleased with our business execution in the quarter, with the majority of our team effectively working from home, yet continuing to engage productively with our customers, supply chain and other partners.”

[0001628280-20-006442:8k_2_02:14]
First Quarter Company Highlights

[0001628280-20-006442:8k_2_02:15]
| • | Arista Networks announced that it has acquired Big Switch Networks, a network monitoring and SDN (Software Defined Networking) pioneer. The acquisition of Big Switch further strengthens the company’s network monitoring and observability suite delivered through Arista’s software platform CloudVision and DANZ (Data ANalyZer) capabilities. |

[0001628280-20-006442:8k_2_02:16]
| • | Arista Networks Announced an Optical Line System for 400G - The Arista OSFP-LS is a highly compact, low power and cost-effective solution for increasing bandwidth between data centers without the need for external optical line systems. This pluggable OSFP form factor simplifies DWDM network deployment and reduces valuable rack space, appealing in particular to Tier2 Cloud and Internet Service Providers. |

[0001628280-20-006442:8k_2_02:17]
| • | Ciena and Arista Complete Interoperability Testing of 400GbE-Optimized Transport Solution - Ciena and Arista completed an interoperability test of the industry’s most dense and spectrally-efficient 400GbE transport solution with the industry’s highest density native 400GbE router. |

[0001628280-20-006442:8k_2_02:18]
| • | COVID-19 Response - A Letter from Our CEO - Arista plays a critical role in supporting the cloud communications and computing infrastructure that will keep the world running during these difficult times. The rapid acceleration of Covid-19 developments across the world has brought a new perspective to Arista's business, customers and community goals. |

[0001628280-20-006442:8k_2_02:19]
Financial Outlook

[0001628280-20-006442:8k_2_02:20]
For the second quarter of 2020, we expect:

[0001628280-20-006442:8k_2_02:21]
| • | Revenue between $520 million to $540 million; |

[0001628280-20-006442:8k_2_02:22]
| • | Non-GAAP gross margin of 63% to 65% and |

[0001628280-20-006442:8k_2_02:23]
| • | Non-GAAP operating margin of approximately 35% |

[0001628280-20-006442:8k_2_02:24]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below under “Non-GAAP Financial Measures”).

[0001628280-20-006442:8k_2_02:25]
Prepared Materials and Conference Call Information

[0001628280-20-006442:8k_2_02:26]
Arista executives will discuss the first quarter financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (833) 287-7905 in the United States or (647) 689-4469 from outside the US. The Conference ID is 9769576.

[0001628280-20-006442:8k_2_02:27]
The financial results conference call will also be available via live webcast on our investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001628280-20-006442:8k_2_02:28]
Forward-Looking Statements

[0001628280-20-006442:8k_2_02:29]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the second quarter of fiscal year 2020, and statements regarding the introduction of new products and the expected benefits from the acquisition of Big Switch. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: the impact of the COVID-19 pandemic on our business, the evolution and growth of the cloud networking market and the adoption by end customers of Arista’s cloud networking solutions; rapid technological and market change; Arista’s customer concentration; our ability to attract new large end customers or sell additional products and services to existing customers; competition in our products and services markets; changes in Arista’s customers’ demand for our products and services; changes in customer order patterns or customer mix; requests by large end customers for more favorable terms and conditions; general market, political, economic and business conditions such as the recent U.S. trade wars with China and the impact of public health pandemics like the COVID-19 pandemic; dependence on the introduction and market acceptance of new product offerings and standards including our 400G products as well as our campus and WiFi products; declines in the sales prices of our products and services; the timing of orders and manufacturing and customer lead times; and the benefits and impact of acquisitions; and other future events. Additional risks and uncertainties that could affect Arista can be found in our most recent Annual Report on Form 10-K filed with the SEC on February 14, 2020, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001628280-20-006442:8k_2_02:30]
Non-GAAP Financial Measures

[0001628280-20-006442:8k_2_02:31]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangible assets, other non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001628280-20-006442:8k_2_02:32]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001628280-20-006442:8k_2_02:33]
The company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. The company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. A reconciliation of the non-GAAP financial measures guidance to the corresponding GAAP measures on a forward-looking basis is not available because stock-based compensation expense is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001628280-20-006442:8k_2_02:34]
About Arista Networks

[0001628280-20-006442:8k_2_02:35]
Arista Networks pioneered software-driven, cognitive cloud networking for large-scale datacenter and campus environments. Arista’s award-winning platforms redefine and deliver availability, agility, automation, analytics, and security. Arista has shipped more than twenty million cloud networking ports worldwide with CloudVision and EOS, an advanced network operating system. Committed to open standards across private, public and hybrid cloud solutions, Arista products are supported worldwide directly and through partners.

[0001628280-20-006442:8k_2_02:36]
ARISTA, EOS, CloudEOS  and CloudVision are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners. Additional information and resources can be found at: https://www.arista.com.

[0001628280-20-006442:8k_2_02:37]
| Investor Contacts |
| Curtis McKeeCorporate and Investor Development(408) 547-5701curtism@arista.com |  | Charles YagerProduct and Investor Advocacy(408) 547-5892cyager@arista.com |

[0001628280-20-006442:8k_2_02:38]
ARISTA NETWORKS, INC.

[0001628280-20-006442:8k_2_02:39]
Condensed Consolidated Statements of Operations

[0001628280-20-006442:8k_2_02:40]
(Unaudited in thousands, except per share amounts)

[0001628280-20-006442:8k_2_02:41]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |
| Product |  | $ | 410,906 |  |  | $ | 505,415 |  |
| Service |  | 112,123 |  |  | 90,009 |  |
| Total revenue |  | 523,029 |  |  | 595,424 |  |
| Cost of revenue: |  |  |  |  |
| Product |  | 163,629 |  |  | 198,152 |  |
| Service |  | 21,149 |  |  | 16,702 |  |
| Total cost of revenue |  | 184,778 |  |  | 214,854 |  |
| Gross profit |  | 338,251 |  |  | 380,570 |  |
| Operating expenses: |  |  |  |  |
| Research and development |  | 113,154 |  |  | 119,669 |  |
| Sales and marketing |  | 57,086 |  |  | 51,053 |  |
| General and administrative |  | 18,349 |  |  | 15,506 |  |
| Total operating expenses |  | 188,589 |  |  | 186,228 |  |
| Income from operations |  | 149,662 |  |  | 194,342 |  |
| Other income, net |  | 12,157 |  |  | 12,333 |  |
| Income before income taxes |  | 161,819 |  |  | 206,675 |  |
| Provision for income taxes |  | 23,388 |  |  | 5,646 |  |
| Net income |  | $ | 138,431 |  |  | $ | 201,029 |  |
| Net income attributable to common stockholders: |  |  |  |  |
| Basic |  | $ | 138,431 |  |  | $ | 200,911 |  |
| Diluted |  | $ | 138,431 |  |  | $ | 200,918 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |
| Basic |  | $ | 1.82 |  |  | $ | 2.65 |  |
| Diluted |  | $ | 1.73 |  |  | $ | 2.47 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |
| Basic |  | 76,264 |  |  | 75,920 |  |
| Diluted |  | 79,939 |  |  | 81,201 |  |

[0001628280-20-006442:8k_2_02:42]
4

[0001628280-20-006442:8k_2_02:43]
ARISTA NETWORKS, INC.

[0001628280-20-006442:8k_2_02:44]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001628280-20-006442:8k_2_02:45]
(Unaudited, in thousands, except percentages and per share amounts)

[0001628280-20-006442:8k_2_02:46]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |
| GAAP gross profit |  | $ | 338,251 |  |  | $ | 380,570 |  |
| GAAP gross margin |  | 64.7 | % |  | 63.9 | % |
| Stock-based compensation expense |  | 1,327 |  |  | 1,098 |  |
| Intangible asset amortization |  | 3,660 |  |  | 2,625 |  |
| Non-GAAP gross profit |  | $ | 343,238 |  |  | $ | 384,293 |  |
| Non-GAAP gross margin |  | 65.6 | % |  | 64.5 | % |
| GAAP income from operations |  | $ | 149,662 |  |  | $ | 194,342 |  |
| Stock-based compensation expense |  | 27,556 |  |  | 24,291 |  |
| Litigation expense |  | — |  |  | 1,448 |  |
| Intangible asset amortization |  | 4,902 |  |  | 3,499 |  |
| Acquisition-related costs (1) |  | 11,860 |  |  | — |  |
| Non-GAAP income from operations |  | $ | 193,980 |  |  | $ | 223,580 |  |
| Non-GAAP operating margin |  | 37.1 | % |  | 37.5 | % |
| GAAP net income |  | $ | 138,431 |  |  | $ | 201,029 |  |
| Stock-based compensation expense |  | 27,556 |  |  | 24,291 |  |
| Litigation expense |  | — |  |  | 1,448 |  |
| Intangible asset amortization |  | 4,902 |  |  | 3,499 |  |
| Acquisition-related costs |  | 11,860 |  |  | — |  |
| Gain on investment in privately-held companies |  | — |  |  | (1,150 | ) |
| Tax benefit on stock-based awards |  | (14,502 | ) |  | (37,054 | ) |
| Income tax effect on non-GAAP exclusions |  | (6,555 | ) |  | (4,333 | ) |
| Non-GAAP net income |  | $ | 161,692 |  |  | $ | 187,730 |  |
| GAAP diluted net income per share attributable to common stockholders |  | $ | 1.73 |  |  | $ | 2.47 |  |
| Non-GAAP adjustments to net income |  | 0.29 |  |  | (0.16 | ) |
| Non-GAAP diluted net income per share |  | $ | 2.02 |  |  | $ | 2.31 |  |
| Weighted-average shares used in computing diluted net income per share attributable to common stockholders |  | 79,939 |  |  | 81,201 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |
| Cost of revenue |  | $ | 1,327 |  |  | $ | 1,098 |  |
| Research and development |  | 15,928 |  |  | 13,131 |  |
| Sales and marketing |  | 6,396 |  |  | 6,534 |  |
| General and administrative |  | 3,905 |  |  | 3,528 |  |
| Total |  | $ | 27,556 |  |  | $ | 24,291 |  |
| (1) Represents non-recurring costs associated with our acquisition of Big Switch, and primarily include severance, retention bonuses, professional and consulting fees, and facilities restructuring costs. |

[0001628280-20-006442:8k_2_02:47]
ARISTA NETWORKS, INC.

[0001628280-20-006442:8k_2_02:48]
Condensed Consolidated Balance Sheets

[0001628280-20-006442:8k_2_02:49]
(Unaudited, in thousands)

[0001628280-20-006442:8k_2_02:50]
|  |  | March 31, 2020 |  | December 31, 2019 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 761,333 |  |  | $ | 1,111,286 |  |
| Marketable securities |  | 1,875,660 |  |  | 1,613,082 |  |
| Accounts receivable, net |  | 352,159 |  |  | 391,987 |  |
| Inventories |  | 261,798 |  |  | 243,825 |  |
| Prepaid expenses and other current assets |  | 85,949 |  |  | 111,456 |  |
| Total current assets |  | 3,336,899 |  |  | 3,471,636 |  |
| Property and equipment, net |  | 37,806 |  |  | 39,273 |  |
| Acquisition-related intangible assets, net |  | 89,373 |  |  | 45,235 |  |
| Goodwill |  | 84,781 |  |  | 54,855 |  |
| Investments |  | 4,150 |  |  | 4,150 |  |
| Operating lease right-of-use assets |  | 83,377 |  |  | 87,770 |  |
| Deferred tax assets |  | 448,432 |  |  | 452,025 |  |
| Other assets |  | 27,027 |  |  | 30,346 |  |
| TOTAL ASSETS |  | $ | 4,111,845 |  |  | $ | 4,185,290 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |  |
| Accounts payable |  | $ | 84,815 |  |  | $ | 92,105 |  |
| Accrued liabilities |  | 100,443 |  |  | 140,249 |  |
| Deferred revenue |  | 332,175 |  |  | 312,668 |  |
| Other current liabilities |  | 55,574 |  |  | 52,052 |  |
| Total current liabilities |  | 573,007 |  |  | 597,074 |  |
| Income taxes payable |  | 58,507 |  |  | 55,485 |  |
| Operating lease liabilities, non-current |  | 78,502 |  |  | 83,022 |  |
| Deferred revenue, non-current |  | 264,600 |  |  | 262,620 |  |
| Deferred tax liabilities, non-current |  | 250,304 |  |  | 254,710 |  |
| Other long-term liabilities |  | 38,099 |  |  | 37,693 |  |
| TOTAL LIABILITIES |  | 1,263,019 |  |  | 1,290,604 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |  |
| Common stock |  | 8 |  |  | 8 |  |
| Additional paid-in capital |  | 1,149,224 |  |  | 1,106,305 |  |
| Retained earnings |  | 1,698,766 |  |  | 1,788,230 |  |
| Accumulated other comprehensive income |  | 828 |  |  | 143 |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 2,848,826 |  |  | 2,894,686 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 4,111,845 |  |  | $ | 4,185,290 |  |

[0001628280-20-006442:8k_2_02:51]
6

[0001628280-20-006442:8k_2_02:52]
ARISTA NETWORKS, INC.

[0001628280-20-006442:8k_2_02:53]
Condensed Consolidated Statements of Cash Flows

[0001628280-20-006442:8k_2_02:54]
(Unaudited, in thousands)

[0001628280-20-006442:8k_2_02:55]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 138,431 |  |  | $ | 201,029 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 10,208 |  |  | 8,362 |  |
| Stock-based compensation |  | 27,556 |  |  | 24,291 |  |
| Noncash lease expense |  | 4,073 |  |  | 3,689 |  |
| Deferred income taxes |  | 457 |  |  | (718 | ) |
| (Gain) on investments in privately-held companies |  | — |  |  | (1,150 | ) |
| Amortization (accretion) of investment premiums (discounts) |  | 1,042 |  |  | (2,069 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | 46,329 |  |  | 60,531 |  |
| Inventories |  | (17,691 | ) |  | (82,596 | ) |
| Prepaid expenses and other current assets |  | 25,751 |  |  | 30,664 |  |
| Other assets |  | 3,946 |  |  | (2,475 | ) |
| Accounts payable |  | (6,386 | ) |  | (2,391 | ) |
| Accrued liabilities |  | (39,450 | ) |  | (19,014 | ) |
| Deferred revenue |  | 21 |  |  | (50,756 | ) |
| Income taxes payable |  | 3,982 |  |  | 2,040 |  |
| Other liabilities |  | (3,422 | ) |  | 660 |  |
| Net cash provided by operating activities |  | 194,847 |  |  | 170,097 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 414,503 |  |  | 302,264 |  |
| Purchases of marketable securities |  | (674,649 | ) |  | (332,247 | ) |
| Business acquisitions, net of cash acquired |  | (66,225 | ) |  | — |  |
| Purchases of property and equipment |  | (3,107 | ) |  | (5,237 | ) |
| Net cash used in investing activities |  | (329,478 | ) |  | (35,220 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 17,082 |  |  | 26,323 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (1,740 | ) |  | (1,850 | ) |
| Repurchase of common stock |  | (227,895 | ) |  | — |  |
| Net cash provided by (used in) financing activities |  | (212,553 | ) |  | 24,473 |  |
| Effect of exchange rate changes |  | (2,691 | ) |  | 195 |  |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | (349,875 | ) |  | 159,545 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 1,115,515 |  |  | 654,164 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 765,640 |  |  | $ | 813,709 |  |
