# ANET note change history — 0001596532-19-000230 → 0001628280-20-006504


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-06):
[0001628280-20-006504:note_history:1]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of March 31, 2020, we had non-cancellable purchase commitments of $352.4 million, of which $337.6 million was to our contract manufacturers and suppliers. In addition, we have provided suppliers with inventory deposits to secure our obligations to purchase inventory and the amount of these deposits may increase in future periods as we work to reduce product lead times and ensure adequate component supply to meet future demand.  We had $15.6 million and $16.5 million in deposits as of March 31, 2020 and December 31, 2019, respectively.  These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.
  (was, 2019-11-01, similarity 0.8776):
[0001596532-19-000230:note_history:1]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2019, we had non-cancellable purchase commitments of $222.4 million, of which $209.6 million was to our contract manufacturers and suppliers. In addition, we have provided deposits to secure our obligations to purchase inventory. We had $17.8 million and $17.4 million in deposits as of September 30, 2019 and December 31, 2018, respectively. These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.

- changed (2020-05-06):
[0001628280-20-006504:note_history:2]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.
  (was, 2019-11-01, similarity 0.9989):
[0001596532-19-000230:note_history:2]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

- changed (2020-05-06):
[0001628280-20-006504:note_history:3]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2020, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in
  (was, 2019-11-01, similarity 0.8472):
[0001596532-19-000230:note_history:3]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2019, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.

- added (2020-05-06):
[0001628280-20-006504:note_history:4]
the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.

- removed (2020-05-06):
[0001596532-19-000230:note_history:5]
Leases

- removed (2020-05-06):
[0001596532-19-000230:note_history:6]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2028. See Note 6 for our future minimum payment obligations under our leases as of September 30, 2019.

- removed (2020-05-06):
[0001596532-19-000230:note_history:7]
OptumSoft, Inc. Matters

- removed (2020-05-06):
[0001596532-19-000230:note_history:8]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies; and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of

- removed (2020-05-06):
[0001596532-19-000230:note_history:9]
the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

- removed (2020-05-06):
[0001596532-19-000230:note_history:10]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft access to our software for evaluation by OptumSoft; (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches; (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers; (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us; and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors, who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dated July 28, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.

- removed (2020-05-06):
[0001596532-19-000230:note_history:11]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we asserted our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we asserted that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We asked the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also asserted that, even if we are found not to own certain components, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation. On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have meritorious defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

- removed (2020-05-06):
[0001596532-19-000230:note_history:12]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial were set to be tried in Phase II, including the application of the Court’s interpretation of the 2004 agreement to any other source code that OptumSoft claims to own and the trade secret misappropriation and confidentiality claims.

- removed (2020-05-06):
[0001596532-19-000230:note_history:13]
On September 24, 2019, the Company and OptumSoft entered into a settlement agreement resolving all the issues that were set to be tried in Phase II of the litigation. Under the settlement agreement, OptumSoft may still pursue its appeal of the Court’s Final Statement of Decision Following Phase I Trial, and pursue any further litigation that may result, but has granted the Company a release on all other outstanding claims.

- removed (2020-05-06):
[0001596532-19-000230:note_history:14]
We intend to vigorously defend against any claims brought against us by OptumSoft.  However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor.  For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft.  If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license.  An adverse litigation ruling could result in a significant damages award against us and injunctive relief. In addition, OptumSoft could assert additional or different claims against us, including claims that our license from OptumSoft is invalid.

- removed (2020-05-06):
[0001596532-19-000230:note_history:15]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated.  However, the outcome of litigation is inherently uncertain. Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

- removed (2020-05-06):
[0001596532-19-000230:note_history:16]
GlobalFoundries Litigation

- removed (2020-05-06):
[0001596532-19-000230:note_history:17]
On August 26, 2019, GlobalFoundries U.S. Inc. (“GlobalFoundries”) filed complaints in the International Trade Commission and federal court against TSMC and numerous companies that sell products incorporating semiconductor devices manufactured by TSMC, including Arista, Broadcom, NVIDIA, Apple, Asus, Cisco, and Lenovo. The complaints allege that these semiconductor devices infringe four GlobalFoundries patents relating to semiconductor manufacturing techniques. In our case, GlobalFoundries has accused the merchant silicon we purchase from Broadcom of infringement. On October 28, 2019, TSMC and GlobalFoundries entered into a cross-license agreement to settle the litigation.

- removed (2020-05-06):
[0001596532-19-000230:note_history:18]
Other Matters


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-06):
[0001628280-20-006504:note_history:19]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our 1/2.5/5/10/25/40/50/100/400 Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.
  (was, 2019-11-01, similarity 0.9638):
[0001596532-19-000230:note_history:19]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” “us” or the “Company”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System (“EOS”), a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

- changed (2020-05-06):
[0001628280-20-006504:note_history:20]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2020, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2019 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.
  (was, 2019-11-01, similarity 0.9803):
[0001596532-19-000230:note_history:20]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2019, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2018 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant intercompany accounts and transactions have been eliminated.

- changed (2020-05-06):
[0001628280-20-006504:note_history:21]
The preparation of the accompanying condensed consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; valuation of goodwill and acquisition-related intangible assets, accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; estimate of useful lives of long-lived assets including intangible assets; valuation of inventory and contract manufacturer/supplier liabilities; and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.
  (was, 2019-11-01, similarity 0.8925):
[0001596532-19-000230:note_history:21]
The preparation of the accompanying condensed consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; valuation of goodwill and acquisition-related intangible assets, accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; estimate of useful lives of long-lived assets including intangible assets; valuation of inventory and contract manufacturer/supplier liabilities; recognition and measurement of contingent liabilities; valuation of equity investments in privately-held companies; determination of fair value for stock-based awards; estimate of incremental borrowing rate for determining the present value of future lease payments; and valuation of warranty accruals. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.

- added (2020-05-06):
[0001628280-20-006504:note_history:22]
Risks and Uncertainties

- added (2020-05-06):
[0001628280-20-006504:note_history:23]
In March 2020, the World Health Organization declared COVID-19 a pandemic.  Consequently, in an effort to contain COVID-19 or slow its spread, countries around the world, including the U.S., have issued orders to quarantine residents to their homes, practice social distancing when engaging in activities deemed “essential,” close all business temporarily deemed not "essential" and place restrictions on travel and mass gatherings.  COVID-19 has negatively impacted the global economy, disrupted business, sales activities, global supply chains and workforce participation, including our own, and created significant volatility and disruption of financial markets, and it is possible that it could cause a local or global economic recession.

- added (2020-05-06):
[0001628280-20-006504:note_history:24]
Our contract manufacturers and suppliers are experiencing delays in the production and export of their products, which has negatively impacted our supply chain, and any continued disruption in manufacturing and supply would negatively impact our business in the future. In addition, we expect that COVID-19 related disruptions may have a negative impact on demand from our customers in future periods, which could result in a year-over-year decline in revenues in the second quarter of 2020, and this may continue into the third quarter or beyond.  However, the extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, including the duration and spread of the pandemic and related restrictions on travel and transport, all of which are uncertain and cannot be predicted.  Management is actively monitoring the impact of the global situation on the Company's financial condition,

- added (2020-05-06):
[0001628280-20-006504:note_history:25]
liquidity, operations, suppliers, industry, and workforce.  As of the date of issuance of these condensed consolidated financial statements, the extent to which the COVID-19 pandemic may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

- changed (2020-05-06):
[0001628280-20-006504:note_history:26]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  The standard requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. For trade receivables, we are required to estimate lifetime expected credit losses. For available-for-sale debt securities, we are required to recognize an allowance for credit losses rather than a reduction to the carrying value of the asset.  We adopted the new guidance in our first quarter of 2020 under a modified retrospective basis, and there was no material impact to our financial statements upon adoption.  In addition, we do not anticipate that it will have a material impact on our consolidated statement of operations or consolidated statements of cash flows going forward.
  (was, 2019-11-01, similarity 0.6359):
[0001596532-19-000230:note_history:26]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  The proposed standard requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. For trade receivables, we will be required to estimate lifetime expected credit losses. For available-for-sale debt securities, we will be required to recognize an allowance for credit losses rather than a reduction to the carrying value of the asset. In May 2019, the FASB issued ASU 2019-05, Financial Instruments—Credit Losses, Topic 326, which allows companies to make an irrevocable one-time election upon adoption of ASU 2016-13 to elect the fair value option for certain financial assets currently measured at amortized cost (except held-to-maturity securities). The election is to be applied on an instrument-by-instrument basis. ASU 2016-13 is effective for us for our first quarter of 2020. We are currently assessing the impact this guidance may have on our consolidated financial statements.

- removed (2020-05-06):
[0001596532-19-000230:note_history:27]
Significant Accounting Policies

- removed (2020-05-06):
[0001596532-19-000230:note_history:28]
Effective January 1, 2019, we adopted Accounting Standard Codification (“ASC”) 842 - Leases, as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1. As a result, we added a new significant accounting policy “Leases” as described below. There have been no other significant changes to our accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2018, filed with the SEC on February 15, 2019.

- removed (2020-05-06):
[0001596532-19-000230:note_history:29]
Leases

- removed (2020-05-06):
[0001596532-19-000230:note_history:30]
Our initial application date of ASC 842 is January 1, 2019. For the periods prior to 2019, our leases were accounted for under the legacy guidance in ASC 840.

- removed (2020-05-06):
[0001596532-19-000230:note_history:31]
We determine if a contract contains a lease at inception. The lease term represents the non-cancellable period for which we have the right to use an underlying asset, which may include periods covered by certain options to extend and/or terminate the lease. Lease liabilities and corresponding right-of-use (“ROU”) assets are recognized at the commencement date of a lease. Leases with an initial lease term of 12 months or less are not recorded on the balance sheet.

- removed (2020-05-06):
[0001596532-19-000230:note_history:32]
A lease liability is the present value of our future fixed lease payments. As none of our leases provides an implicit interest rate, we use our estimated incremental borrowing rate as of the lease commencement date to determine the present value of future lease payments. Our discount rates are determined and applied at a company level. An ROU asset is calculated as the lease liability, adjusted by unamortized initial direct costs, unamortized lease incentives received, cumulative deferred or prepaid lease payments, and accumulated impairment losses.

- removed (2020-05-06):
[0001596532-19-000230:note_history:33]
For fixed lease payments under operating leases, lease expense is recognized on a straight-lined basis over the lease term. For variable lease payments, lease expense is recognized when incurred. For operating leases that include both lease and non-lease components, we account for lease and non-lease components as a single lease component for all classes of underlying assets and, therefore, recognize non-lease payments as lease expense.

- removed (2020-05-06):
[0001596532-19-000230:note_history:34]
Leases

- removed (2020-05-06):
[0001596532-19-000230:note_history:35]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) No. 2016-02, Leases (“ASU 2016-02”), and in July 2018, the FASB issued ASU 2018-11, Leases (Topic 842): Targeted Improvements (“ASU 2018-11”) (collectively referred to as “ASC 842”). Under the guidance, lessees are required to recognize assets and lease liabilities on the balance sheet for most leases including operating leases and provide enhanced disclosures. Companies are required to adopt this guidance using a modified retrospective approach and apply the transition provisions under the guidance at either 1) the later of the beginning of the earliest comparative period presented in the financial statements and the commencement date of the lease, or 2) the beginning of the period of adoption (i.e. on the effective date). Under the transition method using the second application date, a company initially applies the new leases standard at the adoption date and recognizes a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption.

- removed (2020-05-06):
[0001596532-19-000230:note_history:36]
We adopted the guidance on January 1, 2019 using the modified retrospective transition method and initially applied the transition provisions at January 1, 2019, which allows us to continue to apply the legacy guidance in ASC 840 for periods prior to 2019. We elected the package of transition practical expedients, which, among other things, allows us to keep the historical lease classifications and not have to reassess the lease classification for any existing leases as of the date of adoption. We also made the following accounting policy elections as allowed by ASC 842:

- removed (2020-05-06):
[0001596532-19-000230:note_history:37]
| • | to apply the short-term lease exception, which allows us to keep leases with an initial term of twelve months or less off the balance sheet. |

- removed (2020-05-06):
[0001596532-19-000230:note_history:38]
| • | to account for each separate lease component of a contract and its associated non-lease components as a single lease component for all our leases. |

- removed (2020-05-06):
[0001596532-19-000230:note_history:39]
As a result of the adoption, we recognized operating leases that were previously not recognized on the consolidated balance sheets. In addition, we derecognized the assets and the lease financing liabilities previously recorded for our headquarters building under a build-to-suit lease. Under ASC 842, this lease is recognized as an operating lease in our condensed consolidated financial statements beginning in the first quarter of 2019. The table below summarizes the impact of the adoption of ASC 842 on the condensed consolidated balance sheet as of January 1, 2019 (in thousands).

- removed (2020-05-06):
[0001596532-19-000230:note_history:40]
|  |  |  |  | Adjustments for the Adoption of ASC 842 |  |  |
| Balance Sheet Line Item |  | December 31,2018 |  | Derecognition of Build-to-Suit Lease |  | Recognition of Operating Leases (1) |  | January 1,2019 |
| Property and equipment, net |  | $ | 75,355 |  |  | $ | (32,806 | ) |  | $ | — |  |  | $ | 42,549 |  |
| Operating lease right-of-use assets |  | — |  |  | — |  |  | 93,207 |  |  | 93,207 |  |
| Deferred tax assets |  | 126,492 |  |  | (1,165 | ) |  | — |  |  | 125,327 |  |
| Other current liabilities |  | 30,907 |  |  | (2,242 | ) |  | 12,391 |  |  | 41,056 |  |
| Operating lease liabilities, non-current |  | — |  |  | — |  |  | 88,230 |  |  | 88,230 |  |
| Finance lease liabilities, non-current |  | 35,431 |  |  | (35,431 | ) |  | — |  |  | — |  |
| Other long-term liabilities |  | 31,851 |  |  | — |  |  | (7,414 | ) |  | 24,437 |  |
| Retained earnings |  | 1,190,803 |  |  | 3,702 |  |  | — |  |  | 1,194,505 |  |
| __________________ |
| (1) Includes an operating lease for our corporate headquarters building under the build-to-suit arrangement, which was accounted for as a financing lease prior to 2019 and derecognized on January 1, 2019 upon the adoption of ASC 842. |

- removed (2020-05-06):
[0001596532-19-000230:note_history:41]
Recent Accounting Pronouncements Not Yet Effective
