# ANET MD&A — 0001628280-20-006504


## mdna

[0001628280-20-006504:mdna:1]
[same as prior period, unchanged from 0001596532-19-000230:mdna:1]

[0001628280-20-006504:mdna:2]
[same as prior period, unchanged from 0001596532-19-000230:mdna:2]

[0001628280-20-006504:mdna:3]
Arista Networks pioneered software-driven, cognitive cloud networking for large-scale data center and campus environments. Our cloud networking solutions consist of our EOS, a set of network applications and our Ethernet switching and routing platforms. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. At the core of our cloud networking platform is EOS, which was purpose-built to be fully programmable, highly modular and reliable. The programmability of EOS has allowed us to create a set of software applications that address the requirements of cloud networking, including workflow automation, network visibility and analytics, and has also allowed us to rapidly integrate with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.

[0001628280-20-006504:mdna:4]
We believe that cloud networking will continue to replace legacy network technologies across data center and campus environments. Our cloud networking platforms are well positioned to address the growing cloud networking market, and to address increasing performance requirements driven by the growing number of connected devices, as well as the need for constant connectivity and access to data and applications.

[0001628280-20-006504:mdna:5]
We generate revenue primarily from sales of our switching and routing products which incorporate our EOS software. We generate the majority of our services revenue from post contract support, or PCS, which end customers typically purchase in conjunction with our products. Our end customers span a range of industries and include large internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others. As we have grown the

[0001628280-20-006504:mdna:6]
functionality of our EOS software, expanded the range of our product portfolio and increased the size of our sales force, our revenue has grown rapidly. We have also been profitable and operating cash flow positive for each year since 2010.

[0001628280-20-006504:mdna:7]
We believe our future success is dependent upon our ability to continue to develop market leading products and features that address the needs of our end customers and our ability to sell these products to new and existing customers, including an increase in sales in the enterprise data center switching, campus and WiFi networking markets. We intend to continue to invest in our sales activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new end customers more effectively, increase sales to existing customers, and provide services and support. In addition, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our rapid development of new features and applications.

[0001628280-20-006504:mdna:8]
Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic to the underlying merchant silicon architecture. Today, we combine our EOS software with merchant silicon into a family of switching and routing products. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We work closely with third party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001628280-20-006504:mdna:9]
Historically, large purchases by a relatively limited number of end customers have accounted for a significant portion of our revenue. We have experienced unpredictability in the timing of orders from these large end customers primarily due to changes in demand patterns specific to these customers, the time it takes these end customers to evaluate, test, qualify and accept our products, and the overall complexity of these large orders. We expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. For example, our sales to Microsoft and Facebook as end users in fiscal 2019 represented 23% and 17% of our revenue, respectively, and benefited from certain factors that are not expected to repeat in fiscal 2020. Consequently, the percentage of our revenue from Microsoft and Facebook in fiscal 2020 is expected to decline, which will likely negatively impact our revenue growth.  In addition, we have provided, and may in the future provide, pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur.

[0001628280-20-006504:mdna:10]
Recent Developments

[0001628280-20-006504:mdna:11]
In December 2019, a novel strain of coronavirus (“COVID-19”) was identified in Wuhan, China. This virus has spread globally, including to the United States. In March 2020, the World Health Organization declared COVID-19 a pandemic.  Consequently, in an effort to contain COVID-19 or slow its spread, governments around the world have issued orders to isolate residents to their homes, practice social distancing when engaging in activities deemed "essential", close all business deemed not essential, and place restrictions on travel and mass gatherings.   COVID-19 has negatively impacted the global economy, disrupted business, sales activities, supply chains and workforce participation, including our own, and created significant volatility and disruption of financial markets, and we expect that the global health crisis caused by COVID-19 will continue to negatively impact business activity for the foreseeable future.

[0001628280-20-006504:mdna:12]
We have taken numerous steps, and will continue to take further actions, in our approach to address COVID-19.  As a result, we have closed our offices across the globe (including our corporate headquarters) limiting access to only those employees providing essential activities, have instructed employees to work from home, and have implemented travel restrictions.  We have also worked closely with our contract manufacturers and supply chain who have experienced delays in component sourcing, and production and export of their products, which negatively impacted our ability to supply products to our customers on a timely basis during the three months ended March 31, 2020.

[0001628280-20-006504:mdna:13]
The extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, including the duration and spread of the pandemic,  restrictions on travel, transportation and other containment measures, our compliance with these measures and the impact on our customers, partners, contract manufacturers and supply chain, all of which are uncertain and cannot be predicted.  However, any continued disruption in manufacturing and supply resulting from the COVID-19 pandemic or resulting restrictions would negatively impact our business.  We also expect that COVID-19 related disruptions may have a negative impact on demand from our customers in future periods.  While we expect to see some short-term strength in demand from our cloud titan customers, this may be more than offset by prolonged sales cycles with new prospects in the campus and enterprise markets, which could result in a year-over-year decline in revenues in the second quarter of 2020 and this may also continue into the third quarter or beyond. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

[0001628280-20-006504:mdna:14]
In anticipation of further COVID-19 related disruptions to our business, we have undertaken a comprehensive review of our investment and spending plans and expect to reduce discretionary spending in future periods while maintaining an ongoing

[0001628280-20-006504:mdna:15]
focus on key initiatives. Although management is actively monitoring the impact of COVID-19 on the Company’s financial condition, liquidity, operations, suppliers, industry, and workforce, the full impact of the pandemic continues to evolve as of the date of this report. As such, the Company is unable to estimate the effects of COVID-19 on its future results of operations, financial condition, or liquidity.

[0001628280-20-006504:mdna:16]
Acquisition

[0001628280-20-006504:mdna:17]
On February 5, 2020, we acquired Big Switch Networks, Inc. (“Big Switch”) a network monitoring and software-defined networking pioneer headquartered in Santa Clara, California.  With the acquisition of Big Switch, we expect to expand our data center networking solutions and further strengthen our network monitoring and observability suite delivered through Arista’s software platform CloudVision and DANZ (DataANalyZer) capabilities.

[0001628280-20-006504:mdna:18]
[same as prior period, unchanged from 0001596532-19-000230:mdna:11]

[0001628280-20-006504:mdna:19]
Three Months Ended March 31, 2020 Compared to Three Months Ended March 31, 2019

[0001628280-20-006504:mdna:20]
[same as prior period, unchanged from 0001596532-19-000230:mdna:13]

[0001628280-20-006504:mdna:21]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 410,906 |  |  | $ | 505,415 |  |  | $ | (94,509 | ) |  | (18.7 | )% |
| Service |  | 112,123 |  |  | 90,009 |  |  | 22,114 |  |  | 24.6 |  |
| Total revenue |  | 523,029 |  |  | 595,424 |  |  | (72,395 | ) |  | (12.2 | ) |
| Cost of revenue |  |  |  |  |  |  |  |  |
| Product |  | 163,629 |  |  | 198,152 |  |  | (34,523 | ) |  | (17.4 | ) |
| Service |  | 21,149 |  |  | 16,702 |  |  | 4,447 |  |  | 26.6 |  |
| Total cost of revenue |  | 184,778 |  |  | 214,854 |  |  | (30,076 | ) |  | (14.0 | ) |
| Gross profit |  | $ | 338,251 |  |  | $ | 380,570 |  |  | $ | (42,319 | ) |  | (11.1 | )% |
| Gross margin |  | 64.7 | % |  | 63.9 | % |  |  |  |  |

[0001628280-20-006504:mdna:22]
[same as prior period, unchanged from 0001596532-19-000230:mdna:15]

[0001628280-20-006504:mdna:23]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | % of Total |  | 2019 |  | % of Total |
| Americas |  | $ | 400,660 |  |  | 76.6 | % |  | $ | 439,638 |  |  | 73.8 | % |
| Europe, Middle East and Africa |  | 72,624 |  |  | 13.9 |  |  | 111,269 |  |  | 18.7 |  |
| Asia-Pacific |  | 49,745 |  |  | 9.5 |  |  | 44,517 |  |  | 7.5 |  |
| Total revenue |  | $ | 523,029 |  |  | 100.0 | % |  | $ | 595,424 |  |  | 100.0 | % |

[0001628280-20-006504:mdna:24]
[same as prior period, unchanged from 0001596532-19-000230:mdna:17]

[0001628280-20-006504:mdna:25]
We generate revenue primarily from sales of our products. We also derive a portion of our revenue from sales of PCS, which is typically purchased in conjunction with our products, and subsequent renewals of those contracts. We expect our revenue may vary from period to period based on, among other things, the timing, size, and complexity of orders, especially with respect to our large end customers.

[0001628280-20-006504:mdna:26]
Product revenue decreased $94.5 million, or 18.7%, for the three months ended March 31, 2020 compared to the same period in 2019.  This decrease was primarily due to the recognition of $82.9 million of deferred revenue in the three months ended March 31, 2019 which related to shipments from prior periods for which customer acceptance was required.  In addition, we experienced decreased demand from our existing customers in the current period, primarily driven by certain of our large end customers. Service revenue increased $22.1 million, or 24.6%, in three months ended March 31, 2020, compared to the same period in 2019 as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenues represented 23.4% of total revenues in the three months ended March 31, 2020, down from 26.2% compared to the same period in the prior year, which was primarily due to a move toward U.S. deployments by certain of our large end customers. We continued to experience competitive pricing pressure on our products and services.

[0001628280-20-006504:mdna:27]
[same as prior period, unchanged from 0001596532-19-000230:mdna:20]

[0001628280-20-006504:mdna:28]
Cost of revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs in our manufacturing operations department, and other manufacturing-related costs associated with manufacturing our products and managing our inventory. Cost of providing PCS and other services primarily consists of personnel costs for our global customer support organization.

[0001628280-20-006504:mdna:29]
Cost of revenue decreased $30.1 million, or 14.0% for the three months ended March 31, 2020 compared to the same period in 2019, which was driven by a corresponding decrease in revenue.

[0001628280-20-006504:mdna:30]
[same as prior period, unchanged from 0001596532-19-000230:mdna:23]

[0001628280-20-006504:mdna:31]
Gross margin increased from 63.9% to 64.7% for the three months ended March 31, 2020 compared to the same period in 2019. The increase was primarily driven by a decrease in product transition costs including some excess and obsolete inventory-related charges, which was partially offset by a reduction in service margins due to a relatively fixed services cost base on lower revenues.

[0001628280-20-006504:mdna:32]
[same as prior period, unchanged from 0001596532-19-000230:mdna:25]

[0001628280-20-006504:mdna:33]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. The largest component of our operating expenses is personnel costs. Personnel costs consist of wages, benefits, bonuses and, with respect to sales and marketing expenses, sales commissions. Personnel costs also include stock-based compensation and travel expenses.

[0001628280-20-006504:mdna:34]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 113,154 |  |  | $ | 119,669 |  |  | $ | (6,515 | ) |  | (5.4 | )% |
| Sales and marketing |  | 57,086 |  |  | 51,053 |  |  | 6,033 |  |  | 11.8 |  |
| General and administrative |  | 18,349 |  |  | 15,506 |  |  | 2,843 |  |  | 18.3 |  |
| Total operating expenses |  | $ | 188,589 |  |  | $ | 186,228 |  |  | $ | 2,361 |  |  | 1.3 | % |

[0001628280-20-006504:mdna:35]
[same as prior period, unchanged from 0001596532-19-000230:mdna:28]

[0001628280-20-006504:mdna:36]
Research and development expenses consist primarily of personnel costs, prototype expenses, third-party engineering and contractor support costs, and an allocated portion of facility and IT costs including depreciation. Our research and development efforts are focused on maintaining and developing additional functionality for our existing products and on new product development, including new releases and upgrades to our EOS software and applications. We plan to continue to expand the capabilities of our cloud networking platform, introduce new products and features and build upon our technology leadership.  However, in light of the COVID-19 outbreak, we plan to tightly manage our spending in the coming year and as a result research and development expenses in 2020 may decrease from prior year levels.

[0001628280-20-006504:mdna:37]
Research and development expenses decreased $6.5 million, or 5.4%, in the three months ended March 31, 2020 compared to the same period in 2019. The decrease in the three months ended March 31, 2020 was primarily due to $14.3 million decrease in new product introduction costs, including third party engineering and other product development costs. This decrease was partially offset by $5.9 million in severance and other acquisition-related expenses from the Big Switch acquisition, including facilities restructuring costs and retention bonuses, and $2.8 million in stock-based compensation driven by refresh grants to existing employees as well as grants to new employees acquired from Big Switch.

[0001628280-20-006504:mdna:38]
[same as prior period, unchanged from 0001596532-19-000230:mdna:31]

[0001628280-20-006504:mdna:39]
Sales and marketing expenses consist primarily of personnel costs, marketing, trade shows, and other promotional activities, and an allocated portion of facility and IT costs, including depreciation. We intend to continue to prudently manage our sales and marketing spend in 2020 with some targeted investment in strategic sales activities and, accordingly, expect sales and marketing expenses to remain relatively flat for the remainder of the year as compared to 2019.

[0001628280-20-006504:mdna:40]
Sales and marketing expenses increased $6.0 million, or 11.8%, for the  three months ended March 31, 2020 compared to the same period in 2019. The increase in the three months ended March 31, 2020 included $3.7 million in severance and other

[0001628280-20-006504:mdna:41]
acquisition-related expenses from the Big Switch acquisition, including retention bonuses, and $2.8 million in personnel-related costs mostly driven by an increase in headcount.

[0001628280-20-006504:mdna:42]
[same as prior period, unchanged from 0001596532-19-000230:mdna:35]

[0001628280-20-006504:mdna:43]
General and administrative expenses consist primarily of personnel costs and professional services fees. General and administrative personnel costs include those for our executive, finance, human resources and legal functions. Our professional services fees are primarily due to external legal, accounting and tax services.

[0001628280-20-006504:mdna:44]
General and administrative expenses increased $2.8 million, or 18.3%, in the three months ended March 31, 2020 compared to the same period in 2019.  The increase for the three months ended March 31, 2020 was primarily related to $2.2 million in severance and other acquisition-related expenses from the Big Switch acquisition.

[0001628280-20-006504:mdna:45]
[same as prior period, unchanged from 0001596532-19-000230:mdna:40]

[0001628280-20-006504:mdna:46]
Other income (expense) consists primarily of interest income from our cash, cash equivalents and marketable securities, gains and losses on our investments in privately-held companies, and foreign currency transaction gains and losses.  We expect other income (expense) may fluctuate in the future as a result of the re-measurement of our private company equity investments upon the occurrence of observable price changes and/or impairments, changes in interest rates or returns on our cash and cash equivalents and marketable securities, and foreign currency exchange rate fluctuations.

[0001628280-20-006504:mdna:47]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 11,662 |  |  | $ | 11,898 |  |  | $ | (236 | ) |  | (2.0 | )% |
| Gain (loss) on investments in privately-held companies |  | — |  |  | 1,150 |  |  | (1,150 | ) |  | (100.0 | ) |
| Other income (expense), net |  | 495 |  |  | (715 | ) |  | 1,210 |  |  | (169.2 | ) |
| Total other income (expense), net |  | $ | 12,157 |  |  | $ | 12,333 |  |  | $ | (176 | ) |  | (1.4 | )% |

[0001628280-20-006504:mdna:48]
The change in other income (expense), net, during the three months ended March 31, 2020 as compared to the same period in 2019 was primarily due to a favorable change in foreign currency gains and losses, which was largely offset by an unfavorable change in our investments in privately-held companies due to a gain recorded in the three months ended March 31, 2019.

[0001628280-20-006504:mdna:49]
[same as prior period, unchanged from 0001596532-19-000230:mdna:44]

[0001628280-20-006504:mdna:50]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. Earnings from our non-U.S. activities are subject to local country income tax and may also be subject to U.S. income tax. Generally, our U.S. tax obligations are reduced by a credit for foreign income taxes paid on these foreign earnings which avoids double taxation. Our tax expense to date consists of federal, state and foreign current and deferred income taxes.

[0001628280-20-006504:mdna:51]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |
| Income before income taxes |  | $ | 161,819 |  |  | $ | 206,675 |  |  | $ | (44,856 | ) |  | (21.7 | )% |
| Provision for (benefit from) income taxes |  | 23,388 |  |  | 5,646 |  |  | 17,742 |  |  | 314.2 | % |
| Effective tax rate |  | 14.5 | % |  | 2.7 | % |  |  |  |  |

[0001628280-20-006504:mdna:52]
For the three months ended March 31, 2020 and 2019, we recorded an expense of $23.4 million and $5.6 million for income taxes, respectively. Income taxes for the three months ended March 31, 2020 included lower tax benefits realized from tax settlements of stock-based compensation. The remaining changes in the income taxes were attributable to the overall decrease in worldwide earnings.

[0001628280-20-006504:mdna:53]
[same as prior period, unchanged from 0001596532-19-000230:mdna:49]

[0001628280-20-006504:mdna:54]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of March 31, 2020, our total balance of cash, cash equivalents and marketable securities was approximately $2.6 billion, of which approximately $397.9 million was held outside the U.S. in our foreign subsidiaries.

[0001628280-20-006504:mdna:55]
Our cash, cash equivalents and marketable securities are held for working capital purposes. Our marketable securities investment portfolio is primarily invested in highly rated securities with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities together with cash generated from operations will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months.  Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and stock repurchases. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001628280-20-006504:mdna:56]
[same as prior period, unchanged from 0001596532-19-000230:mdna:52]

[0001628280-20-006504:mdna:57]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 194,847 |  |  | $ | 170,097 |  |
| Cash used in investing activities |  | (329,478 | ) |  | (35,220 | ) |
| Cash provided by (used in) financing activities |  | (212,553 | ) |  | 24,473 |  |
| Effect of exchange rate changes |  | (2,691 | ) |  | 195 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | (349,875 | ) |  | $ | 159,545 |  |

[0001628280-20-006504:mdna:58]
[same as prior period, unchanged from 0001596532-19-000230:mdna:54]

[0001628280-20-006504:mdna:59]
During the three months ended March 31, 2020, cash provided by operating activities was $194.8 million, primarily from net income of $138.4 million and non-cash adjustments to net income of $43.3 million driven by stock-based compensation and depreciation and amortization, and a net increase of $13.1 million in cash from changes in our operating assets and liabilities. Cash inflows from working capital changes primarily included a $46.3 million decrease in accounts receivable due to strong collections and timing of customer shipments in the current quarter, and a $25.8 million decrease in prepaid expenses due to a decrease in contract receivables and prepaid taxes. These cash inflows were partially offset by cash outflows of a $39.5 million decrease in accrued liabilities primarily due to payment of corporate bonuses in the current quarter, and a $17.7 million increase in inventories due to the timing of product shipments and receipts.

[0001628280-20-006504:mdna:60]
During the three months ended March 31, 2019, cash provided by operating activities was $170.1 million, primarily from net income of $201.0 million and non-cash adjustments to net income of $28.7 million, offset partially by a net decrease of $59.6 million in cash from changes in our operating assets and liabilities. Our operating cash benefited from a $60.5 million reduction in accounts receivable resulting from strong cash collections in the quarter, and a $30.7 million decrease in prepaid expenses and other current assets including a reduction in deferred cost of inventory related to recognition of product deferred revenue. These favorable changes were more than offset by an $82.6 million increase in inventories primarily related to upcoming product transitions, a $50.8 million decrease in deferred revenue primarily due to the recognition of product deferred revenue in the quarter offset partially by an increase in deferred service revenue as our install base continues to grow, and a $19.0 million decline in accrued liabilities due to annual corporate bonus payments and timing of vendor payments related to product development activities and inventory purchases.

[0001628280-20-006504:mdna:61]
[same as prior period, unchanged from 0001596532-19-000230:mdna:58]

[0001628280-20-006504:mdna:62]
During the three months ended March 31, 2020, cash used in investing activities was $329.5 million, consisting of purchases of available-for-sale securities of $674.6 million, $66.2 million for the acquisition of Big Switch, and purchases of property and equipment of $3.1 million, partially offset by proceeds from maturities of marketable securities of $414.5 million.

[0001628280-20-006504:mdna:63]
During the three months ended March 31, 2019, cash used in investing activities was $35.2 million, consisting of purchases of available-for-sale securities of $332.2 million, offset by proceeds of $302.3 million from maturities of marketable securities, and purchases of property and equipment of $5.2 million.

[0001628280-20-006504:mdna:64]
[same as prior period, unchanged from 0001596532-19-000230:mdna:61]

[0001628280-20-006504:mdna:65]
During the three months ended March 31, 2020, cash used in financing activities was $212.6 million, consisting of payments for repurchases of our common stock from the open market of $227.9 million and taxes paid of $1.7 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $17.1 million.

[0001628280-20-006504:mdna:66]
During the three months ended March 31, 2019, cash provided by financing activities was $24.5 million, consisting of proceeds from the issuance of common stock under employee equity incentive plans of $26.3 million, offset by taxes paid of $1.9 million upon vesting of restricted stock units.

[0001628280-20-006504:mdna:67]
[same as prior period, unchanged from 0001596532-19-000230:mdna:64]

[0001628280-20-006504:mdna:68]
From time to time, we repurchase our common stock opportunistically pursuant to our Repurchase Program authorized by our board of directors in April 2019. The Repurchase Program allows for stock repurchases of up to $1.0 billion and these repurchases are funded from working capital. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice.  During the quarter ended March 31, 2020, we repurchased a total of $227.9 million of our common stock. As of March 31, 2020, the remaining authorized amount for repurchases under the Repurchase Program was $506.0 million. Refer to Note 7. Stockholders' Equity of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001628280-20-006504:mdna:69]
[same as prior period, unchanged from 0001596532-19-000230:mdna:66]

[0001628280-20-006504:mdna:70]
As of March 31, 2020, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001628280-20-006504:mdna:71]
[same as prior period, unchanged from 0001596532-19-000230:mdna:68]

[0001628280-20-006504:mdna:72]
Our contractual commitments will have an impact on our future liquidity.  Our contractual obligations represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalent and marketable securities. As of March 31, 2020, our principal commitments consist primarily of obligations under operating leases for offices and data centers and purchase commitments with our contract manufacturers and suppliers. See Note 6. Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for our purchase commitments as of March 31, 2020.

[0001628280-20-006504:mdna:73]
[same as prior period, unchanged from 0001596532-19-000230:mdna:71]

[0001628280-20-006504:mdna:74]
Our management’s discussion and analysis of financial condition and results of operations is based on our unaudited condensed consolidated financial statements, which have been prepared in accordance with GAAP.  The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. We believe the critical accounting policies and estimates discussed in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our Annual Report on Form 10-K filed with the SEC on February 14, 2020, reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting policies and estimates as disclosed in our Annual Report on Form 10-K.

[0001628280-20-006504:mdna:75]
[same as prior period, unchanged from 0001596532-19-000230:mdna:73]

[0001628280-20-006504:mdna:76]
Refer to the sections titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
