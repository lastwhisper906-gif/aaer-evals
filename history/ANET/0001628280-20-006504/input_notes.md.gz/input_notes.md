# ANET notes — 0001628280-20-006504


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001628280-20-006504:notes:1]
[same as prior period, unchanged from 0001596532-19-000230:notes:1]

[0001628280-20-006504:notes:2]
[same as prior period, unchanged from 0001596532-19-000230:notes:2]

[0001628280-20-006504:notes:3]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our 1/2.5/5/10/25/40/50/100/400 Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001628280-20-006504:notes:4]
[same as prior period, unchanged from 0001596532-19-000230:notes:4]

[0001628280-20-006504:notes:5]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2020, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2019 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

[0001628280-20-006504:notes:6]
Our condensed consolidated financial statements and related financial information in this Quarterly Report on Form 10-Q should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2019, filed with the SEC on February 14, 2020.

[0001628280-20-006504:notes:7]
[same as prior period, unchanged from 0001596532-19-000230:notes:7]

[0001628280-20-006504:notes:8]
The preparation of the accompanying condensed consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; valuation of goodwill and acquisition-related intangible assets, accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; estimate of useful lives of long-lived assets including intangible assets; valuation of inventory and contract manufacturer/supplier liabilities; and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.

[0001628280-20-006504:notes:9]
Risks and Uncertainties

[0001628280-20-006504:notes:10]
In March 2020, the World Health Organization declared COVID-19 a pandemic.  Consequently, in an effort to contain COVID-19 or slow its spread, countries around the world, including the U.S., have issued orders to quarantine residents to their homes, practice social distancing when engaging in activities deemed “essential,” close all business temporarily deemed not "essential" and place restrictions on travel and mass gatherings.  COVID-19 has negatively impacted the global economy, disrupted business, sales activities, global supply chains and workforce participation, including our own, and created significant volatility and disruption of financial markets, and it is possible that it could cause a local or global economic recession.

[0001628280-20-006504:notes:11]
Our contract manufacturers and suppliers are experiencing delays in the production and export of their products, which has negatively impacted our supply chain, and any continued disruption in manufacturing and supply would negatively impact our business in the future. In addition, we expect that COVID-19 related disruptions may have a negative impact on demand from our customers in future periods, which could result in a year-over-year decline in revenues in the second quarter of 2020, and this may continue into the third quarter or beyond.  However, the extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, including the duration and spread of the pandemic and related restrictions on travel and transport, all of which are uncertain and cannot be predicted.  Management is actively monitoring the impact of the global situation on the Company's financial condition,

[0001628280-20-006504:notes:12]
liquidity, operations, suppliers, industry, and workforce.  As of the date of issuance of these condensed consolidated financial statements, the extent to which the COVID-19 pandemic may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

[0001628280-20-006504:notes:13]
Recently Adopted Accounting Pronouncements

[0001628280-20-006504:notes:14]
[same as prior period, unchanged from 0001596532-19-000230:notes:24]

[0001628280-20-006504:notes:15]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  The standard requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. For trade receivables, we are required to estimate lifetime expected credit losses. For available-for-sale debt securities, we are required to recognize an allowance for credit losses rather than a reduction to the carrying value of the asset.  We adopted the new guidance in our first quarter of 2020 under a modified retrospective basis, and there was no material impact to our financial statements upon adoption.  In addition, we do not anticipate that it will have a material impact on our consolidated statement of operations or consolidated statements of cash flows going forward.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-20-006504:notes:16]
[same as prior period, unchanged from 0001596532-19-000230:notes:26]

[0001628280-20-006504:notes:17]
On February 5, 2020, the Company completed its acquisition of Big Switch Networks, Inc. (“Big Switch”) a network monitoring and software-defined networking pioneer headquartered in Santa Clara, California.  With the acquisition of Big Switch, we expect to expand our data center networking solutions and further strengthen our network monitoring and observability suite delivered through Arista’s software platform CloudVision and DANZ (DataANalyZer) capabilities.

[0001628280-20-006504:notes:18]
We paid an aggregate of $73.3 million in cash for the acquisition, of which $5.3 million in severance and other costs was accounted for as post-combination expense and was excluded from the purchase consideration.  We also incurred certain acquisition-related expenses and restructuring costs of $6.6 million, which primarily consisted of retention bonuses to continuing employees, professional and consulting fees, and facilities restructuring costs. The following table summarizes the purchase consideration of $68.0 million, and the preliminary purchase price allocation based on the estimated fair value of the assets acquired and liabilities assumed at the acquisition date (in thousands):

[0001628280-20-006504:notes:19]
|  |  | Preliminary Purchase Price Allocation |
| Tangible assets |  | 13,376 |  |
| Liabilities |  | (24,346 | ) |
| Intangible assets |  | 49,040 |  |
| Goodwill |  | 29,926 |  |
| Net assets acquired |  | $ | 67,996 |  |

[0001628280-20-006504:notes:20]
[same as prior period, unchanged from 0001596532-19-000230:notes:30]

[0001628280-20-006504:notes:21]
|  |  | Acquisition Date Fair Value |  | Estimated Useful Life |
| Developed technology |  | $ | 31,040 |  |  | 5 years |
| Customer relationships |  | 13,150 |  |  | 7 years |
| Non-compete agreements |  | 4,060 |  |  | 2 years |
| Trade name |  | 790 |  |  | 1 year |
| Total intangible assets acquired |  | $ | 49,040 |  |  |  |

[0001628280-20-006504:notes:22]
Goodwill of $29.9 million is primarily attributable to the expected synergies created by incorporating the solutions of the acquired businesses into our technology platform, and the value of the assembled workforce. Goodwill is not deductible for income taxes purposes. In addition, the acquisition of Big Switch did not have a material impact on our revenue and net income for the current period, and therefore pro forma financial information has not been presented.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-20-006504:notes:23]
[same as prior period, unchanged from 0001596532-19-000230:notes:33]

[0001628280-20-006504:notes:24]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying condensed consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value. We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs. The three-tiers of the fair value hierarchy are as follows:

[0001628280-20-006504:notes:25]
[same as prior period, unchanged from 0001596532-19-000230:notes:36]

[0001628280-20-006504:notes:26]
[same as prior period, unchanged from 0001596532-19-000230:notes:37]

[0001628280-20-006504:notes:27]
[same as prior period, unchanged from 0001596532-19-000230:notes:38]

[0001628280-20-006504:notes:28]
[same as prior period, unchanged from 0001596532-19-000230:notes:39]

[0001628280-20-006504:notes:29]
|  |  | March 31, 2020 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 351,469 |  |  | $ | — |  |  | $ | — |  |  | $ | 351,469 |  |  | $ | 351,469 |  |  | $ | — |  |  | $ | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 83,261 |  |  | — |  |  | — |  |  | 83,261 |  |  | — |  |  | 83,261 |  |  | — |  |
| Certificate of deposits(1) |  | 3,000 |  |  | — |  |  | — |  |  | 3,000 |  |  | — |  |  | 3,000 |  |  | — |  |
| U.S. government notes |  | 576,488 |  |  | 7,114 |  |  | — |  |  | 583,602 |  |  | 583,602 |  |  | — |  |  | — |  |
| Corporate bonds |  | 923,194 |  |  | 1,753 |  |  | (3,116 | ) |  | 921,831 |  |  | — |  |  | 921,831 |  |  | — |  |
| Agency securities |  | 283,044 |  |  | 939 |  |  | (17 | ) |  | 283,966 |  |  | — |  |  | 283,966 |  |  | — |  |
|  |  | 1,868,987 |  |  | 9,806 |  |  | (3,133 | ) |  | 1,875,660 |  |  | 583,602 |  |  | 1,292,058 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,307 |  |  | — |  |  | — |  |  | 4,307 |  |  | 4,307 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 2,224,763 |  |  | $ | 9,806 |  |  | $ | (3,133 | ) |  | $ | 2,231,436 |  |  | $ | 939,378 |  |  | $ | 1,292,058 |  |  | $ | — |  |

[0001628280-20-006504:notes:30]
|  |  | December 31, 2019 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 562,580 |  |  | $ | — |  |  | $ | — |  |  | $ | 562,580 |  |  | $ | 562,580 |  |  | $ | — |  |  | $ | — |  |
| Certificate of deposits(1) |  | $ | 4,001 |  |  |  |  |  |  | 4,001 |  |  |  |  | 4,001 |  |  |  |
|  |  | 566,581 |  |  | — |  |  | — |  |  | 566,581 |  |  | 562,580 |  |  | 4,001 |  |  | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 66,717 |  |  | — |  |  | — |  |  | 66,717 |  |  | — |  |  | 66,717 |  |  | — |  |
| Certificate of deposits(1) |  | 3,000 |  |  | — |  |  | — |  |  | 3,000 |  |  | — |  |  | 3,000 |  |  | — |  |
| U.S. government notes |  | 518,884 |  |  | 414 |  |  | (20 | ) |  | 519,278 |  |  | 519,278 |  |  | — |  |  | — |  |
| Corporate bonds |  | 787,741 |  |  | 2,392 |  |  | (73 | ) |  | 790,060 |  |  | — |  |  | 790,060 |  |  | — |  |
| Agency securities |  | 233,491 |  |  | 577 |  |  | (41 | ) |  | 234,027 |  |  | — |  |  | 234,027 |  |  | — |  |
|  |  | 1,609,833 |  |  | 3,383 |  |  | (134 | ) |  | 1,613,082 |  |  | 519,278 |  |  | 1,093,804 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,229 |  |  | — |  |  | — |  |  | 4,229 |  |  | 4,229 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 2,180,643 |  |  | $ | 3,383 |  |  | $ | (134 | ) |  | $ | 2,183,892 |  |  | $ | 1,086,087 |  |  | $ | 1,097,805 |  |  | $ | — |  |

[0001628280-20-006504:notes:31]
[same as prior period, unchanged from 0001596532-19-000230:notes:42]

[0001628280-20-006504:notes:32]
(1) As of March 31, 2020 and December 31, 2019, all of our certificates of deposits were domestic deposits.

[0001628280-20-006504:notes:33]
We did not realize any other-than-temporary losses on our marketable securities for the three months ended March 31, 2020 and December 31, 2019. As of March 31, 2020 and December 31, 2019, we did not have any marketable securities that have been in a continuous unrealized loss position for more than twelve months. We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. As interest rates increase, those marketable securities purchased at a time with lower interest rates show a mark-to-market unrealized loss. We expect to realize the full value of these investments upon maturity or sale and therefore, we do not consider any of our marketable securities to be other-than-temporarily impaired as of March 31, 2020.

[0001628280-20-006504:notes:34]
As of March 31, 2020, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale marketable securities, by remaining contractual maturity, are as follows (in thousands):

[0001628280-20-006504:notes:35]
|  |  | March 31, 2020 |
| Due in 1 year or less |  | $ | 1,173,934 |  |
| Due in 1 year through 2 years |  | 701,726 |  |
| Total marketable securities |  | $ | 1,875,660 |  |

[0001628280-20-006504:notes:36]
The weighted-average remaining duration of our current marketable securities is approximately 0.9 years as of March 31, 2020.  As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying unaudited condensed consolidated balance sheets.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-20-006504:notes:37]
[same as prior period, unchanged from 0001596532-19-000230:notes:48]

[0001628280-20-006504:notes:38]
[same as prior period, unchanged from 0001596532-19-000230:notes:49]

[0001628280-20-006504:notes:39]
[same as prior period, unchanged from 0001596532-19-000230:notes:50]

[0001628280-20-006504:notes:40]
|  |  | March 31, 2020 |  | March 31, 2019 |
| Cash and cash equivalents |  | $ | 761,333 |  |  | $ | 809,491 |  |
| Restricted cash included in other assets |  | 4,307 |  |  | 4,218 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 765,640 |  |  | $ | 813,709 |  |

[0001628280-20-006504:notes:41]
Restricted cash included in other assets as of March 31, 2020 and March 31, 2019 primarily included $4.0 million pledged as collateral representing a security deposit required for a facility lease.

[0001628280-20-006504:notes:42]
[same as prior period, unchanged from 0001596532-19-000230:notes:53]

[0001628280-20-006504:notes:43]
[same as prior period, unchanged from 0001596532-19-000230:notes:54]

[0001628280-20-006504:notes:44]
|  |  | March 31, 2020 |  | December 31, 2019 |
| Accounts receivable |  | $ | 358,220 |  |  | $ | 398,147 |  |
| Allowance for doubtful accounts |  | (424 | ) |  | (638 | ) |
| Product sales rebate and returns reserve |  | (5,637 | ) |  | (5,522 | ) |
| Accounts receivable, net |  | $ | 352,159 |  |  | $ | 391,987 |  |

[0001628280-20-006504:notes:45]
[same as prior period, unchanged from 0001596532-19-000230:notes:56]

[0001628280-20-006504:notes:46]
[same as prior period, unchanged from 0001596532-19-000230:notes:57]

[0001628280-20-006504:notes:47]
|  |  | March 31, 2020 |  | December 31, 2019 |
| Raw materials |  | $ | 130,357 |  |  | $ | 96,712 |  |
| Finished goods |  | 131,441 |  |  | 147,113 |  |
| Total inventories |  | $ | 261,798 |  |  | $ | 243,825 |  |

[0001628280-20-006504:notes:48]
[same as prior period, unchanged from 0001596532-19-000230:notes:59]

[0001628280-20-006504:notes:49]
Prepaid expenses and other current assets consist of the following (in thousands):

[0001628280-20-006504:notes:50]
|  |  | March 31, 2020 |  | December 31, 2019 |
| Prepaid income taxes |  | $ | 8,706 |  |  | $ | 20,153 |  |
| Inventory deposit |  | 12,802 |  |  | 13,716 |  |
| Other current assets |  | 50,373 |  |  | 64,464 |  |
| Other prepaid expenses and deposits |  | 14,068 |  |  | 13,123 |  |
| Total prepaid expenses and other current assets |  | $ | 85,949 |  |  | $ | 111,456 |  |

[0001628280-20-006504:notes:51]
[same as prior period, unchanged from 0001596532-19-000230:notes:62]

[0001628280-20-006504:notes:52]
[same as prior period, unchanged from 0001596532-19-000230:notes:63]

[0001628280-20-006504:notes:53]
|  |  | March 31, 2020 |  | December 31, 2019 |
| Equipment and machinery |  | $ | 63,461 |  |  | $ | 64,748 |  |
| Computer hardware and software |  | 39,061 |  |  | 36,627 |  |
| Leasehold improvements |  | 31,150 |  |  | 31,235 |  |
| Furniture and fixtures |  | 3,713 |  |  | 3,774 |  |
| Construction-in-process |  | 405 |  |  | 265 |  |
| Property and equipment, gross |  | 137,790 |  |  | 136,649 |  |
| Less: accumulated depreciation |  | (99,984 | ) |  | (97,376 | ) |
| Property and equipment, net |  | $ | 37,806 |  |  | $ | 39,273 |  |

[0001628280-20-006504:notes:54]
Depreciation expense was $5.2 million and $4.7 million for the three months ended March 31, 2020 and 2019, respectively.

[0001628280-20-006504:notes:55]
[same as prior period, unchanged from 0001596532-19-000230:notes:67]

[0001628280-20-006504:notes:56]
[same as prior period, unchanged from 0001596532-19-000230:notes:68]

[0001628280-20-006504:notes:57]
|  |  | March 31, 2020 |  | December 31, 2019 |
| Accrued payroll related costs |  | $ | 43,842 |  |  | $ | 80,133 |  |
| Accrued manufacturing costs |  | 30,998 |  |  | 31,920 |  |
| Accrued product development costs |  | 7,162 |  |  | 11,410 |  |
| Accrued professional fees |  | 5,160 |  |  | 6,335 |  |
| Accrued warranty costs |  | 6,341 |  |  | 6,742 |  |
| Accrued taxes |  | 1,843 |  |  | 1,716 |  |
| Other |  | 5,097 |  |  | 1,993 |  |
| Total accrued liabilities |  | $ | 100,443 |  |  | $ | 140,249 |  |

[0001628280-20-006504:notes:58]
[same as prior period, unchanged from 0001596532-19-000230:notes:70]

[0001628280-20-006504:notes:59]
[same as prior period, unchanged from 0001596532-19-000230:notes:71]

[0001628280-20-006504:notes:60]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |
| Warranty accrual, beginning of period |  | $ | 6,742 |  |  | $ | 5,362 |  |
| Liabilities accrued for warranties issued during the period |  | 1,070 |  |  | 932 |  |
| Warranty costs incurred during the period |  | (1,471 | ) |  | (1,168 | ) |
| Warranty accrual, end of period |  | $ | 6,341 |  |  | $ | 5,126 |  |

[0001628280-20-006504:notes:61]
[same as prior period, unchanged from 0001596532-19-000230:notes:73]

[0001628280-20-006504:notes:62]
[same as prior period, unchanged from 0001596532-19-000230:notes:74]

[0001628280-20-006504:notes:63]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |
| Contract assets, beginning balance |  | $ | 25,565 |  |  | $ | 6,341 |  |
| Contract assets, ending balance |  | 9,636 |  |  | 5,699 |  |

[0001628280-20-006504:notes:64]
[same as prior period, unchanged from 0001596532-19-000230:notes:76]

[0001628280-20-006504:notes:65]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |
| Contract liabilities, beginning balance |  | $ | 61,050 |  |  | $ | 32,595 |  |
| Less: Revenue recognized from beginning balance |  | (4,847 | ) |  | (2,826 | ) |
| Less: Beginning balance reclassified to deferred revenue |  | (2,433 | ) |  | (1,259 | ) |
| Add: Contract liabilities recognized |  | 10,555 |  |  | 8,804 |  |
| Contract liabilities, ending balance |  | $ | 64,325 |  |  | $ | 37,314 |  |

[0001628280-20-006504:notes:66]
As of March 31, 2020 and December 31, 2019, $26.3 million and $23.4 million of our contract liabilities, respectively, was included in “Other current liabilities” with the remaining balances included in “Other long-term liabilities”.

[0001628280-20-006504:notes:67]
[same as prior period, unchanged from 0001596532-19-000230:notes:79]

[0001628280-20-006504:notes:68]
[same as prior period, unchanged from 0001596532-19-000230:notes:80]

[0001628280-20-006504:notes:69]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |
| Deferred revenue, beginning balance |  | $ | 575,288 |  |  | $ | 587,227 |  |
| Less: Revenue recognized from beginning balance |  | (100,377 | ) |  | (190,597 | ) |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 121,864 |  |  | 139,841 |  |
| Deferred revenue, ending balance |  | $ | 596,775 |  |  | $ | 536,471 |  |

[0001628280-20-006504:notes:70]
[same as prior period, unchanged from 0001596532-19-000230:notes:82]

[0001628280-20-006504:notes:71]
Revenue from remaining performance obligations represents contracted revenue that has not yet been recognized, which includes contract liabilities and deferred revenue that will be recognized as revenue in future periods. As of March 31, 2020, approximately $716.5 million of revenue is expected to be recognized from remaining performance obligations. We expect to recognize revenue on approximately 80% of these remaining performance obligations over the next two years and 20% during the third to the fifth year.

[0001628280-20-006504:notes:72]
[same as prior period, unchanged from 0001596532-19-000230:notes:85]

[0001628280-20-006504:notes:73]
[same as prior period, unchanged from 0001596532-19-000230:notes:86]

[0001628280-20-006504:notes:74]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |
| Interest income |  | $ | 11,662 |  |  | $ | 11,898 |  |
| Gain (loss) on investment in privately-held companies |  | — |  |  | 1,150 |  |
| Other income (expense), net |  | 495 |  |  | (715 | ) |
| Total |  | $ | 12,157 |  |  | $ | 12,333 |  |


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001628280-20-006504:notes:75]
[same as prior period, unchanged from 0001596532-19-000230:notes:89]

[0001628280-20-006504:notes:76]
[same as prior period, unchanged from 0001596532-19-000230:notes:90]

[0001628280-20-006504:notes:77]
Our investments are in the equity of privately-held companies, which do not have readily determinable fair values. These non-marketable equity securities are initially recorded at cost, and subsequently remeasured to fair value on a non-recurring basis based on observable price changes in orderly transactions for similar investments of the same issuer, or for impairment. These investments are classified within Level III of the fair value hierarchy as we estimate the value based on valuation methods using the observable transaction price at the transaction date and other significant unobservable inputs, such as volatility, rights, and obligations related to those investments. In addition, the valuation requires management judgment due to the absence of market price and inherent lack of liquidity. The following table summarizes the activity related to our investments in privately-held companies held as of March 31, 2020 and December 31, 2019 (in thousands):

[0001628280-20-006504:notes:78]
|  |  | March 31, 2020 |  | December 31, 2019 |
| Cost of investment |  | $ | 3,000 |  |  | $ | 3,000 |  |
| Cumulative impairment |  | — |  |  | — |  |
| Cumulative upward adjustment |  | 1,150 |  |  | 1,150 |  |
| Carrying amount of investment |  | $ | 4,150 |  |  | $ | 4,150 |  |

[0001628280-20-006504:notes:79]
During the current quarter, there were no realized or unrealized gains or losses recorded on our remaining investment. During the three months ended March 31, 2019, we recorded $1.2 million of unrealized gain.  The unrealized gain was recorded on an investment that was remeasured to fair value as of the date an observable transaction occurred.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-20-006504:notes:80]
6.    Commitments and Contingencies

[0001628280-20-006504:notes:81]
Purchase Commitments

[0001628280-20-006504:notes:82]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of March 31, 2020, we had non-cancellable purchase commitments of $352.4 million, of which $337.6 million was to our contract manufacturers and suppliers. In addition, we have provided suppliers with inventory deposits to secure our obligations to purchase inventory and the amount of these deposits may increase in future periods as we work to reduce product lead times and ensure adequate component supply to meet future demand.  We had $15.6 million and $16.5 million in deposits as of March 31, 2020 and December 31, 2019, respectively.  These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.

[0001628280-20-006504:notes:83]
Guarantees

[0001628280-20-006504:notes:84]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001628280-20-006504:notes:85]
Legal Proceedings

[0001628280-20-006504:notes:86]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001628280-20-006504:notes:87]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2020, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in

[0001628280-20-006504:notes:88]
the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-20-006504:notes:89]
7.    Stockholders’ Equity

[0001628280-20-006504:notes:90]
[same as prior period, unchanged from 0001596532-19-000230:notes:132]

[0001628280-20-006504:notes:91]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the “Repurchase Program”).  This authorization allows us to repurchase shares of our common stock opportunistically and will be funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), or a combination of the foregoing. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of March 31, 2020, the remaining authorized amount for stock repurchases under this program was approximately $506.0 million.

[0001628280-20-006504:notes:92]
A summary of the stock repurchase activity under the Repurchase Program for the three months ended March 31, 2020 is as follows (in thousands, except per share amounts):

[0001628280-20-006504:notes:93]
|  |  | Three Months Ended |
|  |  | March 31, 2020 |
| Aggregate purchase price |  | $ | 227,895 |  |
| Shares repurchased |  | 1,209 |  |
| Average price paid per share |  | $ | 188.61 |  |

[0001628280-20-006504:notes:94]
[same as prior period, unchanged from 0001596532-19-000230:notes:136]

[0001628280-20-006504:notes:95]
[same as prior period, unchanged from 0001596532-19-000230:notes:137]

[0001628280-20-006504:notes:96]
2014 Equity Incentive Plan

[0001628280-20-006504:notes:97]
Effective January 1, 2020, the Company's board of directors authorized an increase of 2,291,660 shares to the shares available for issuance under the 2014 Equity Incentive Plan (the “2014 Plan”).  Pursuant to the 2014 Plan, the 2020 share increase is determined based on the lesser of 3% of total shares of common stock outstanding as of December 31, 2019, which was,12,500,000 shares, or such amount as determined by our board of directors. As of March 31, 2020, there remained approximately 22.6 million shares available for issuance under the 2014 Plan.

[0001628280-20-006504:notes:98]
[same as prior period, unchanged from 0001596532-19-000230:notes:138]

[0001628280-20-006504:notes:99]
Effective January 1, 2020, our board of directors authorized an increase of 763,886 shares to the shares available for issuance under our 2014 Employee Stock Purchase Plan (the “ESPP”).  Pursuant to the ESPP, the 2020 share increase was determined based on the lesser of 1% of the total shares of common stock outstanding on December 31, 2019, 2,500,000 shares, or such amount as determined by our board of directors. During the three months ended March 31, 2020, we issued 51,292  shares at a weighted-average purchase price of $184.19 per share under the ESPP. As of March 31, 2020, there remained 3,905,368 shares available for issuance under the ESPP.

[0001628280-20-006504:notes:100]
[same as prior period, unchanged from 0001596532-19-000230:notes:140]

[0001628280-20-006504:notes:101]
[same as prior period, unchanged from 0001596532-19-000230:notes:141]

[0001628280-20-006504:notes:102]
|  |  | Options Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding |
| Balance—December 31, 2019 |  | 4,564 |  |  | $ | 42.50 |  |  | 4.4 |  | $ | 740,387 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (309 | ) |  | 24.72 |  |  |  |  |  |
| Options canceled |  | (16 | ) |  | 199.60 |  |  |  |  |  |
| Balance—March 31, 2020 |  | 4,239 |  |  | $ | 43.23 |  |  | 4.2 |  | $ | 681,292 |  |
| Vested and exercisable—March 31, 2020 |  | 2,626 |  |  | $ | 29.64 |  |  | 3.7 |  | $ | 454,105 |  |

[0001628280-20-006504:notes:103]
[same as prior period, unchanged from 0001596532-19-000230:notes:143]

[0001628280-20-006504:notes:104]
A summary of the RSU activity under the 2014 Plan and related information are presented below (in thousands, except years and per share amounts):

[0001628280-20-006504:notes:105]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2019 |  | 1,070 |  |  | $ | 190.35 |  |  | 1.5 |  | $ | 217,701 |  |
| RSUs granted |  | 350 |  |  | 207.22 |  |  |  |  |  |
| RSUs vested |  | (122 | ) |  | 146.47 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (42 | ) |  | 229.04 |  |  |  |  |  |
| Unvested balance—March 31, 2020 |  | 1,256 |  |  | $ | 198.00 |  |  | 1.6 |  | $ | 254,386 |  |

[0001628280-20-006504:notes:106]
[same as prior period, unchanged from 0001596532-19-000230:notes:146]

[0001628280-20-006504:notes:107]
The following table presents the stock activity and the total number of shares available for grant under the 2014 Plan as of March 31, 2020 (in thousands):

[0001628280-20-006504:notes:108]
|  |  | Number of Shares |
| Balance—December 31, 2019 |  | 15,146 |  |
| Authorized |  | 2,292 |  |
| Options granted |  | — |  |
| RSUs granted |  | (350 | ) |
| Options canceled |  | 16 |  |
| RSUs forfeited |  | 42 |  |
| Shares traded for taxes |  | 7 |  |
| Balance—March 31, 2020 |  | 17,153 |  |

[0001628280-20-006504:notes:109]
[same as prior period, unchanged from 0001596532-19-000230:notes:149]

[0001628280-20-006504:notes:110]
[same as prior period, unchanged from 0001596532-19-000230:notes:150]

[0001628280-20-006504:notes:111]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |
| Cost of revenue |  | $ | 1,327 |  |  | $ | 1,098 |  |
| Research and development |  | 15,928 |  |  | 13,131 |  |
| Sales and marketing |  | 6,396 |  |  | 6,534 |  |
| General and administrative |  | 3,905 |  |  | 3,528 |  |
| Total stock-based compensation |  | $ | 27,556 |  |  | $ | 24,291 |  |

[0001628280-20-006504:notes:112]
As of March 31, 2020, unrecognized stock-based compensation expenses by award type and their expected weighted-average recognition periods are summarized in the following table (in thousands, except years).

[0001628280-20-006504:notes:113]
|  |  | March 31, 2020 |
|  |  | Stock Option |  | RSU |  | ESPP |  | Restricted Stock |
| Unrecognized stock-based compensation expense |  | $ | 38,896 |  |  | $ | 222,371 |  |  | $ | 8,560 |  |  | $ | 3,569 |  |
| Weighted-average amortization period |  | 3.0 years |  |  | 3.2 years |  |  | 1.0 years |  |  | 2.5 years |  |


## us-gaap:EarningsPerShareTextBlock

[0001628280-20-006504:notes:114]
8.    Net Income Per Share Available to Common Stock

[0001628280-20-006504:notes:115]
The following table sets forth the computation of our basic and diluted net income per share available to common stock (in thousands, except per share amounts):

[0001628280-20-006504:notes:116]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |
| Numerator: |  |  |  |  |
| Basic: |  |  |  |  |
| Net income |  | $ | 138,431 |  |  | $ | 201,029 |  |
| Less: undistributed earnings allocated to participating securities |  | — |  |  | (118 | ) |
| Net income available to common stockholders, basic |  | $ | 138,431 |  |  | $ | 200,911 |  |
| Diluted: |  |  |  |  |
| Net income attributable to common stockholders, basic |  | $ | 138,431 |  |  | $ | 200,911 |  |
| Add: undistributed earnings allocated to participating securities |  | — |  |  | 7 |  |
| Net income attributable to common stockholders, diluted |  | $ | 138,431 |  |  | $ | 200,918 |  |
| Denominator: |  |  |  |  |
| Basic: |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 76,264 |  |  | 75,920 |  |
| Diluted: |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 76,264 |  |  | 75,920 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |
| Stock options and RSUs |  | 3,675 |  |  | 5,279 |  |
| Employee stock purchase plan |  | — |  |  | 2 |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted |  | 79,939 |  |  | 81,201 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |
| Basic |  | $ | 1.82 |  |  | $ | 2.65 |  |
| Diluted |  | $ | 1.73 |  |  | $ | 2.47 |  |

[0001628280-20-006504:notes:117]
The following weighted-average outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share available to common stockholders for the periods presented because including them would have been anti-dilutive (in thousands):

[0001628280-20-006504:notes:118]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |
| Stock options and RSUs to purchase common stock |  | 601 |  |  | 162 |  |
| Employee stock purchase plan |  | — |  |  | 105 |  |
| Total |  | 601 |  |  | 267 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-20-006504:notes:119]
9.    Income Taxes

[0001628280-20-006504:notes:120]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |
| Income before income taxes |  | $ | 161,819 |  |  | $ | 206,675 |  |
| Provision for (benefit from) income taxes |  | 23,388 |  |  | 5,646 |  |
| Effective tax rate |  | 14.5 | % |  | 2.7 | % |

[0001628280-20-006504:notes:121]
The effective tax rates above reflect tax expense recorded on pre-tax income in the three months ended March 31, 2020 and March 31, 2019. The change in effective tax rate in the three months ended March 31, 2020, as compared to the same period in 2019, was primarily due to a decrease in tax benefits attributable to equity compensation settlements. 
In March 2020, the World Health Organization declared the novel strain of coronavirus a global pandemic. As a result, the U.S. government enacted Coronavirus Aid, Relief, and Economic Security Act (“CARES Act”) and is signed into law on March 27, 2020. The CARES Act includes, among other things, provisions relating to payroll tax credits and deferrals, net operating loss carryback periods, alternative minimum tax credits, and technical corrections to tax depreciation methods for qualified improvement property.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-20-006504:notes:122]
10.    Segment Information

[0001628280-20-006504:notes:123]
[same as prior period, unchanged from 0001596532-19-000230:notes:163]

[0001628280-20-006504:notes:124]
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  | 2019 |
| Americas |  | $ | 400,660 |  |  | $ | 439,638 |  |
| Europe, Middle East and Africa |  | 72,624 |  |  | 111,269 |  |
| Asia-Pacific |  | 49,745 |  |  | 44,517 |  |
| Total revenue |  | $ | 523,029 |  |  | $ | 595,424 |  |

[0001628280-20-006504:notes:125]
[same as prior period, unchanged from 0001596532-19-000230:notes:165]

[0001628280-20-006504:notes:126]
|  |  | March 31, 2020 |  | December 31, 2019 |
| United States |  | $ | 30,489 |  |  | $ | 32,565 |  |
| International |  | 7,317 |  |  | 6,708 |  |
| Total |  | $ | 37,806 |  |  | $ | 39,273 |  |
