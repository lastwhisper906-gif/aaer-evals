# ANET MD&A — 0001596532-23-000274


## mdna

[0001596532-23-000274:mdna:1]
[same as prior period, unchanged from 0001596532-23-000197:mdna:1]

[0001596532-23-000274:mdna:2]
[same as prior period, unchanged from 0001596532-23-000197:mdna:2]

[0001596532-23-000274:mdna:3]
[same as prior period, unchanged from 0001596532-23-000197:mdna:3]

[0001596532-23-000274:mdna:4]
[same as prior period, unchanged from 0001596532-23-000197:mdna:4]

[0001596532-23-000274:mdna:5]
[same as prior period, unchanged from 0001596532-23-000197:mdna:5]

[0001596532-23-000274:mdna:6]
[same as prior period, unchanged from 0001596532-23-000197:mdna:6]

[0001596532-23-000274:mdna:7]
[same as prior period, unchanged from 0001596532-23-000197:mdna:7]

[0001596532-23-000274:mdna:8]
[same as prior period, unchanged from 0001596532-23-000197:mdna:8]

[0001596532-23-000274:mdna:9]
[same as prior period, unchanged from 0001596532-23-000197:mdna:9]

[0001596532-23-000274:mdna:10]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including inflation, monetary policy shifts, the recent banking crisis, recession risks, and potential supply chain and other disruptions from the Russia-Ukraine and Israel-Hamas conflicts, and the U.S. trade war with China.

[0001596532-23-000274:mdna:11]
We have worked closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. We have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, and have begun to see some reduction in customer lead times on certain products. Over time, the recovery of capacity should allow us to ship products against previously committed deployment plans and accelerate some deployments where needed, while trying to limit building customer inventory.  On this basis, we expect some shipments against these deployment plans to extend into 2024. As customer lead times reduce more broadly, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to somewhat shorter demand-planning horizons which has resulted in lower demand levels.  Given the shipment and order patterns described above, near term revenue trends may not be reflective of current demand levels, but will benefit from deployment plans that had been previously committed. While inventory and working capital levels may continue to increase and remain elevated in the near term, we expect that purchase commitments will continue to decline as supplier lead times shorten. Although these elevated inventory positions and purchase commitments are largely related to relatively early life cycle products, the larger magnitude of these balances, combined with a reduction in customer demand-planning horizons, has resulted in increased risk that we may not be able to sell all of this inventory, which in turn has resulted, and may in the future result, in the need for us to incur excess and obsolete inventory-related charges..

[0001596532-23-000274:mdna:12]
In addition, inflation pressure in our supply chain, scarcity of some materials needed to build our products and disruptions to our manufacturing process have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. Our operating cash-flows have also been and may continue to be negatively impacted by significant component inventories on hand or at our contract manufacturers. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the recent Russia-Ukraine conflict, continued escalation of this conflict as well as the Israeli-Hamas conflict may negatively impact the global economy and our future operating results and financial condition.

[0001596532-23-000274:mdna:13]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable; however, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that some of our customers, following a year of elevated purchases, must now consider changing technology roadmaps and priorities, including the need for the rapid deployment of AI and related technologies, resulting in some uncertainty as to future investment plans and a more constrained approach to some forecasts and orders in the near term. In addition, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

[0001596532-23-000274:mdna:14]
[same as prior period, unchanged from 0001596532-23-000197:mdna:15]

[0001596532-23-000274:mdna:15]
Three and Nine Months Ended September 30, 2023 Compared to Three and Nine Months Ended September 30, 2022

[0001596532-23-000274:mdna:16]
[same as prior period, unchanged from 0001596532-23-000197:mdna:17]

[0001596532-23-000274:mdna:17]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2023 |  | 2022 |  | Change in |  | 2023 |  | 2022 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,285,548 |  |  | $ | 1,008,689 |  |  | $ | 276,859 |  |  | 27.4 | % |  | $ | 3,719,179 |  |  | $ | 2,619,213 |  |  | $ | 1,099,966 |  |  | 42.0 | % |
| Service |  | 223,908 |  |  | 168,112 |  |  | 55,796 |  |  | 33.2 |  |  | 600,552 |  |  | 486,545 |  |  | 114,007 |  |  | 23.4 |  |
| Total revenue |  | 1,509,456 |  |  | 1,176,801 |  |  | 332,655 |  |  | 28.3 |  |  | 4,319,731 |  |  | 3,105,758 |  |  | 1,213,973 |  |  | 39.1 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 522,866 |  |  | 432,569 |  |  | 90,297 |  |  | 20.9 |  |  | 1,565,341 |  |  | 1,102,012 |  |  | 463,329 |  |  | 42.0 |  |
| Service |  | 44,171 |  |  | 34,252 |  |  | 9,919 |  |  | 29.0 |  |  | 123,335 |  |  | 96,656 |  |  | 26,679 |  |  | 27.6 |  |
| Total cost of revenue |  | 567,037 |  |  | 466,821 |  |  | 100,216 |  |  | 21.5 |  |  | 1,688,676 |  |  | 1,198,668 |  |  | 490,008 |  |  | 40.9 |  |
| Gross profit |  | $ | 942,419 |  |  | $ | 709,980 |  |  | $ | 232,439 |  |  | 32.7 | % |  | $ | 2,631,055 |  |  | $ | 1,907,090 |  |  | $ | 723,965 |  |  | 38.0 | % |
| Gross margin |  | 62.4 | % |  | 60.3 | % |  |  |  |  |  | 60.9 | % |  | 61.4 | % |  |  |  |  |

[0001596532-23-000274:mdna:18]
[same as prior period, unchanged from 0001596532-23-000197:mdna:19]

[0001596532-23-000274:mdna:19]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2023 |  | % of Total |  | 2022 |  | % of Total |  | 2023 |  | % of Total |  | 2022 |  | % of Total |
| Americas |  | $ | 1,184,717 |  |  | 78.5 | % |  | $ | 977,674 |  |  | 83.1 | % |  | $ | 3,454,237 |  |  | 79.9 | % |  | $ | 2,487,106 |  |  | 80.1 | % |
| Europe, Middle East and Africa |  | 173,175 |  |  | 11.5 |  |  | 110,793 |  |  | 9.4 |  |  | 469,114 |  |  | 10.9 |  |  | 350,136 |  |  | 11.3 |  |
| Asia-Pacific |  | 151,564 |  |  | 10.0 |  |  | 88,334 |  |  | 7.5 |  |  | 396,380 |  |  | 9.2 |  |  | 268,516 |  |  | 8.6 |  |
| Total revenue |  | $ | 1,509,456 |  |  | 100.0 | % |  | $ | 1,176,801 |  |  | 100.0 | % |  | $ | 4,319,731 |  |  | 100.0 | % |  | $ | 3,105,758 |  |  | 100.0 | % |

[0001596532-23-000274:mdna:20]
[same as prior period, unchanged from 0001596532-23-000197:mdna:21]

[0001596532-23-000274:mdna:21]
[same as prior period, unchanged from 0001596532-23-000197:mdna:22]

[0001596532-23-000274:mdna:22]
Product revenue increased $276.9 million, or 27.4%, and $1,100.0 million, or 42.0% for the three and nine months ended September 30, 2023, respectively, compared to the same periods in 2022. These increases reflect increased shipments of our switching and routing platforms across our customer base, including improved supply availability for our enterprise customers. In addition, service revenue increased $55.8 million, or 33.2%, and $114.0 million, or 23.4% for the three and nine months ended September 30, 2023, respectively, compared to the same periods in 2022, as a result of continued growth in

[0001596532-23-000274:mdna:23]
initial and renewal support contracts as our customer installed base has continued to expand. International revenue represented 21.5% and 20.1% of total revenue for the three and nine months ended September 30, 2023, respectively, changing from 16.9% and 19.9% for the same periods in the prior year, which was primarily driven by changes in the geographic mix of sales to our large global customers.

[0001596532-23-000274:mdna:24]
[same as prior period, unchanged from 0001596532-23-000197:mdna:24]

[0001596532-23-000274:mdna:25]
[same as prior period, unchanged from 0001596532-23-000197:mdna:25]

[0001596532-23-000274:mdna:26]
Cost of revenue increased by $100.2 million, or 21.5%, and $490.0 million, or 40.9% for the three and nine months ended September 30, 2023, respectively, compared to the same periods in 2022. These increases were primarily driven by a corresponding increase in product and service revenues, combined with an increase in excess/obsolete inventory-related charges.

[0001596532-23-000274:mdna:27]
[same as prior period, unchanged from 0001596532-23-000197:mdna:27]

[0001596532-23-000274:mdna:28]
Gross margin increased from 60.3% to 62.4% for the three months ended September 30, 2023, compared to the same period in 2022, and decreased from 61.4% to 60.9% for the nine months ended September 30, 2023, compared to the same period in 2022. These changes reflect an improvement in product margins driven by a lower mix of revenue from our larger customers, offset by an increase in excess/obsolete inventory-related charges.

[0001596532-23-000274:mdna:29]
[same as prior period, unchanged from 0001596532-23-000197:mdna:29]

[0001596532-23-000274:mdna:30]
[same as prior period, unchanged from 0001596532-23-000197:mdna:30]

[0001596532-23-000274:mdna:31]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2023 |  | 2022 |  | Change in |  | 2023 |  | 2022 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 212,353 |  |  | $ | 187,807 |  |  | $ | 24,546 |  |  | 13.1 | % |  | $ | 643,437 |  |  | $ | 537,971 |  |  | $ | 105,466 |  |  | 19.6 | % |
| Sales and marketing |  | 102,033 |  |  | 81,401 |  |  | 20,632 |  |  | 25.3 |  |  | 293,496 |  |  | 241,512 |  |  | 51,984 |  |  | 21.5 |  |
| General and administrative |  | 25,338 |  |  | 23,425 |  |  | 1,913 |  |  | 8.2 |  |  | 76,787 |  |  | 69,420 |  |  | 7,367 |  |  | 10.6 |  |
| Total operating expenses |  | $ | 339,724 |  |  | $ | 292,633 |  |  | $ | 47,091 |  |  | 16.1 | % |  | $ | 1,013,720 |  |  | $ | 848,903 |  |  | $ | 164,817 |  |  | 19.4 | % |

[0001596532-23-000274:mdna:32]
[same as prior period, unchanged from 0001596532-23-000197:mdna:32]

[0001596532-23-000274:mdna:33]
[same as prior period, unchanged from 0001596532-23-000197:mdna:33]

[0001596532-23-000274:mdna:34]
Research and development expenses increased $24.5 million, or 13.1%, and $105.5 million, or 19.6% in the three and nine months ended September 30, 2023, respectively, compared to the same periods in 2022. The increases were primarily driven by an increase in personnel costs of $21.8 million and $71.9 million for the three and nine months ended September 30, 2023, respectively, compared to the same periods in 2022 primarily due to headcount growth. In addition, new product introduction costs increased by $29.2 million for the nine months ended September 30, 2023, respectively, compared to the

[0001596532-23-000274:mdna:35]
same period in 2022, which was primarily driven by increased non-recurring engineering costs and prototype expenses as we expand our product portfolio.

[0001596532-23-000274:mdna:36]
[same as prior period, unchanged from 0001596532-23-000197:mdna:35]

[0001596532-23-000274:mdna:37]
Sales and marketing expenses consist primarily of personnel costs, marketing, trade shows, and other promotional activities, and an allocated portion of facility and IT costs. We expect our sales and marketing expenses to increase in absolute dollars as we continue to expand our sales and marketing efforts worldwide.

[0001596532-23-000274:mdna:38]
Sales and marketing expenses increased $20.6 million, or 25.3%, and $52.0 million, or 21.5% for the three and nine months ended September 30, 2023, respectively, compared to the same periods in 2022, which was primarily caused by increased personnel costs largely driven by headcount growth, in addition to increased sales and marketing events and field demonstration costs.

[0001596532-23-000274:mdna:39]
[same as prior period, unchanged from 0001596532-23-000197:mdna:39]

[0001596532-23-000274:mdna:40]
[same as prior period, unchanged from 0001596532-23-000197:mdna:40]

[0001596532-23-000274:mdna:41]
General and administrative expenses increased $1.9 million, or 8.2%, and $7.4 million, or 10.6% in the three and nine months ended September 30, 2023, respectively, compared to the same periods in 2022, which was primarily attributable to an increase in personnel costs.

[0001596532-23-000274:mdna:42]
[same as prior period, unchanged from 0001596532-23-000197:mdna:42]

[0001596532-23-000274:mdna:43]
[same as prior period, unchanged from 0001596532-23-000197:mdna:43]

[0001596532-23-000274:mdna:44]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2023 |  | 2022 |  | Change in |  | 2023 |  | 2022 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 43,676 |  |  | $ | 6,929 |  |  | $ | 36,747 |  |  | 530.3 | % |  | $ | 98,391 |  |  | $ | 13,783 |  |  | $ | 84,608 |  |  | 613.9 | % |
| Gain (loss) on strategic investments |  | (473) |  |  | 708 |  |  | (1,181) |  |  | (166.8) |  |  | 18,699 |  |  | 24,121 |  |  | (5,422) |  |  | (22.5) |  |
| Other income (expense), net |  | (1,388) |  |  | (820) |  |  | (568) |  |  | 69.3 |  |  | (6,790) |  |  | (140) |  |  | (6,650) |  |  | 4,750.0 |  |
| Total other income (expense), net |  | $ | 41,815 |  |  | $ | 6,817 |  |  | $ | 34,998 |  |  | 513.4 | % |  | $ | 110,300 |  |  | $ | 37,764 |  |  | $ | 72,536 |  |  | 192.1 | % |

[0001596532-23-000274:mdna:45]
The favorable movements in other income (expense), net, were driven by interest income increases of $36.7 million and $84.6 million in the three and nine months ended September 30, 2023, respectively, compared to the same periods in 2022 primarily due to higher interest rates.

[0001596532-23-000274:mdna:46]
[same as prior period, unchanged from 0001596532-23-000197:mdna:46]

[0001596532-23-000274:mdna:47]
[same as prior period, unchanged from 0001596532-23-000197:mdna:47]

[0001596532-23-000274:mdna:48]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2023 |  | 2022 |  | Change in |  | 2023 |  | 2022 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Income before income taxes |  | $ | 644,510 |  |  | $ | 424,164 |  |  | $ | 220,346 |  |  | 51.9 | % |  | $ | 1,727,635 |  |  | $ | 1,095,951 |  |  | $ | 631,684 |  |  | 57.6 | % |
| Provision for income taxes |  | 99,183 |  |  | 70,165 |  |  | 29,018 |  |  | 41.4 | % |  | 253,950 |  |  | 170,594 |  |  | 83,356 |  |  | 48.9 | % |
| Effective tax rate |  | 15.4 | % |  | 16.5 | % |  |  |  |  |  | 14.7 | % |  | 15.6 | % |  |  |  |  |

[0001596532-23-000274:mdna:49]
The decrease in the effective tax rates in the three and nine months ended September 30, 2023, as compared to the same periods in 2022, was primarily due to an increase in tax benefits attributable to stock-based compensation.

[0001596532-23-000274:mdna:50]
[same as prior period, unchanged from 0001596532-23-000197:mdna:50]

[0001596532-23-000274:mdna:51]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of September 30, 2023, our total balance of cash, cash equivalents and marketable securities was approximately $4.5 billion, of which approximately $608.1 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-23-000274:mdna:52]
[same as prior period, unchanged from 0001596532-23-000197:mdna:52]

[0001596532-23-000274:mdna:53]
[same as prior period, unchanged from 0001596532-23-000197:mdna:53]

[0001596532-23-000274:mdna:54]
|  |  | Nine Months Ended September 30, |
|  |  | 2023 |  | 2022 |
| Cash provided by operating activities |  | $ | 1,507,550 |  |  | $ | 452,340 |  |
| Cash provided by (used in) investing activities |  | (350,497) |  |  | 299,152 |  |
| Cash used in financing activities |  | (82,421) |  |  | (649,939) |  |
| Effect of exchange rate changes |  | (934) |  |  | (6,090) |  |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 1,073,698 |  |  | $ | 95,463 |  |

[0001596532-23-000274:mdna:55]
[same as prior period, unchanged from 0001596532-23-000197:mdna:55]

[0001596532-23-000274:mdna:56]
During the nine months ended September 30, 2023, cash provided by operating activities was $1,507.6 million, primarily from net income of $1,473.7 million, non-cash adjustments to net income of $26.7 million and a net decrease of $7.2 million in working capital requirements. The non-cash adjustments to net income were driven by stock-based compensation and depreciation and amortization, largely offset by an increase in deferred taxes primarily due to the capitalization of research and development costs under Section 174 of the Internal Revenue Code ("IRC"). This decrease in working capital requirements primarily consisted of a $346.2 million increase in income tax payables largely related to an extension by the Internal Revenue Service ("IRS") of the due dates for estimated tax payments until October 2023, a $151.2 million increase in accounts payable and accrued liabilities due to an increase in business volume and timing of payments, a decrease in accounts receivable of $89.7 million driven by strong collections, and an increase in deferred revenue of $153.5 million primarily resulting from an increase in customer PCS contracts. These operating cash inflows were largely offset by a $603.8 million increase in inventory and a $118.6 million increase in prepaid and other assets.

[0001596532-23-000274:mdna:57]
During the nine months ended September 30, 2022, cash provided by operating activities was $452.3 million, primarily from net income of $925.4 million and non-cash adjustments to net income of $66.7 million driven by stock-based compensation and depreciation and amortization, and partly offset by a net increase of $539.7 million in working capital requirements. The increase in working capital requirements primarily consisted of a $449.8 million increase in inventory, a $69.0 million increase in prepaid expenses and other current assets, and a $17.9 million in other assets, which reflected increased inventory purchases and inventory deposits to contract manufacturers to mitigate supply chain constraints and meet customer demand. In addition, accounts receivable increased by $129.9 million due to increased product and service billings.  These operating cash outflows were partially offset by a $73.5 million increase in accounts payable, and a $41.1 million increase in income tax payables.

[0001596532-23-000274:mdna:58]
[same as prior period, unchanged from 0001596532-23-000197:mdna:58]

[0001596532-23-000274:mdna:59]
During the nine months ended September 30, 2023, cash used in investing activities was $350.5 million, consisting of  purchases of available-for-sale securities of $1,934.2 million, and purchases of property and equipment of $28.4 million. These amounts were partially offset by proceeds from maturities and sales of marketable securities of $1,614.5 million.

[0001596532-23-000274:mdna:60]
During the nine months ended September 30, 2022, cash provided by investing activities was $299.2 million, consisting of proceeds from sales and maturities of marketable securities of $1,464.6 million. These amounts were partially offset by purchases of available-for-sale securities of $973.5 million, and purchases of property and equipment of $34.2 million.

[0001596532-23-000274:mdna:61]
[same as prior period, unchanged from 0001596532-23-000197:mdna:62]

[0001596532-23-000274:mdna:62]
During the nine months ended September 30, 2023, cash used in financing activities was $82.4 million, consisting of payments for repurchases of our common stock from the open market of $112.3 million, and employee taxes withheld and paid of $23.9 million upon vesting of restricted stock units, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $53.8 million.

[0001596532-23-000274:mdna:63]
During the nine months ended September 30, 2022, cash used in financing activities was $649.9 million, consisting of payments for repurchases of our common stock from the open market of $667.5 million, and employee taxes withheld and paid of $25.5 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $43.1 million.

[0001596532-23-000274:mdna:64]
[same as prior period, unchanged from 0001596532-23-000197:mdna:65]

[0001596532-23-000274:mdna:65]
In October 2021, our board of directors authorized a $1.0 billion stock repurchase program (the “Repurchase Program”). This authorization allows us to repurchase shares of our common stock that will be funded from working capital and expires in the fourth quarter of 2024. The Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the company at any time without prior notice. During the three months ended September 30, 2023, we did not repurchase any shares. As of September 30, 2023, the remaining authorized amount for repurchases under the Repurchase Program was $144.5 million. Refer to Note 6. Stockholders' Equity and Stock-Based Compensation of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-23-000274:mdna:66]
[same as prior period, unchanged from 0001596532-23-000197:mdna:67]

[0001596532-23-000274:mdna:67]
[same as prior period, unchanged from 0001596532-23-000197:mdna:68]

[0001596532-23-000274:mdna:68]
[same as prior period, unchanged from 0001596532-23-000197:mdna:69]

[0001596532-23-000274:mdna:69]
[same as prior period, unchanged from 0001596532-23-000197:mdna:70]

[0001596532-23-000274:mdna:70]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of September 30, 2023, we had lease payment obligations, net of immaterial sublease income, of $74.2 million, with $22.0 million payable within one year.

[0001596532-23-000274:mdna:71]
[same as prior period, unchanged from 0001596532-23-000197:mdna:72]

[0001596532-23-000274:mdna:72]
Purchase obligations represent an estimate of all non-cancellable open purchase orders and contractual obligations, made either directly by Arista or by our contract manufacturers on our behalf, in the ordinary course of business for which we have not received the goods or services. As of September 30, 2023, we had $2.0 billion of such purchase obligations, of which $1.7 billion are expected to be received within one year, and $0.3 billion are expected to be received after one year.  These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-23-000274:mdna:73]
[same as prior period, unchanged from 0001596532-23-000197:mdna:74]

[0001596532-23-000274:mdna:74]
As of September 30, 2023, we have recorded long-term tax liabilities of $104.7 million related to uncertain tax positions; however, we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-23-000274:mdna:75]
In connection with the Tax Cuts and Jobs Act of 2017 (“TCJA”), effective from January 1, 2022, the TCJA eliminated the option to deduct research and development expenditures currently and requires taxpayers to capitalize and amortize them over five or fifteen years pursuant to IRC Section 174. We estimate the incremental cash tax impact resulting from these

[0001596532-23-000274:mdna:76]
regulations to be approximately $200.0 million for 2023. No material change to our effective tax rate has resulted from this new legislation.

[0001596532-23-000274:mdna:77]
During 2023, following a period of natural disasters that occurred throughout California, the IRS postponed estimated tax payments for certain taxpayers headquartered in designated countries in California until October 2023. As a result, we did not make estimated U.S. federal tax payments during the nine months ended September 30, 2023, and on October 16, 2023 we made an estimated income tax payment to the IRS of $352.0 million.

[0001596532-23-000274:mdna:78]
[same as prior period, unchanged from 0001596532-23-000197:mdna:77]

[0001596532-23-000274:mdna:79]
As of September 30, 2023, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-23-000274:mdna:80]
[same as prior period, unchanged from 0001596532-23-000197:mdna:79]

[0001596532-23-000274:mdna:81]
[same as prior period, unchanged from 0001596532-23-000197:mdna:80]

[0001596532-23-000274:mdna:82]
[same as prior period, unchanged from 0001596532-23-000197:mdna:81]

[0001596532-23-000274:mdna:83]
Refer to the subheading titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
