# ANET notes — 0001596532-23-000274


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-23-000274:notes:1]
[same as prior period, unchanged from 0001596532-23-000197:notes:1]

[0001596532-23-000274:notes:2]
[same as prior period, unchanged from 0001596532-23-000197:notes:2]

[0001596532-23-000274:notes:3]
[same as prior period, unchanged from 0001596532-23-000197:notes:3]

[0001596532-23-000274:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2023, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2022 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

[0001596532-23-000274:notes:5]
[same as prior period, unchanged from 0001596532-23-000197:notes:5]

[0001596532-23-000274:notes:6]
[same as prior period, unchanged from 0001596532-23-000197:notes:6]

[0001596532-23-000274:notes:7]
[same as prior period, unchanged from 0001596532-23-000197:notes:7]

[0001596532-23-000274:notes:8]
[same as prior period, unchanged from 0001596532-23-000197:notes:8]

[0001596532-23-000274:notes:9]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including inflation, monetary policy shifts, the recent banking crisis, recession risks, and potential supply chain and other disruptions from the Russia-Ukraine and Israel-Hamas conflicts, and the U.S. trade war with China.

[0001596532-23-000274:notes:10]
We have worked closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. We have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, and have begun to see some reduction in customer lead times on certain products. Over time, the recovery of capacity should allow us to ship products against previously committed deployment plans and accelerate some deployments where needed, while trying to limit building customer inventory.  On this basis, we expect some shipments against these deployment plans to extend into 2024. As customer lead times reduce more broadly, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to somewhat shorter demand-planning horizons which has resulted in lower demand levels.  Given the shipment and order patterns described above, near term revenue trends may not be reflective of current demand levels, but will benefit from deployment plans that had been previously committed. While inventory and working capital levels may continue to increase and remain elevated in the near term, we expect that purchase commitments will continue to decline as supplier lead times shorten.  Although these elevated inventory positions and purchase commitments are largely related to

[0001596532-23-000274:notes:11]
relatively early life cycle products, the larger magnitude of these balances, combined with a reduction in customer demand-planning horizons, has resulted in increased risk that we may not be able to sell all of this inventory, which in turn has resulted, and may in the future result, in the need for us to incur excess and obsolete inventory-related charges.

[0001596532-23-000274:notes:12]
In addition, inflation pressure in our supply chain, scarcity of some materials needed to build our products and disruptions to our manufacturing process have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. Our operating cash-flows have also been and may continue to be negatively impacted by significant component inventories on hand or at our contract manufacturers. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the recent conflicts between Russia-Ukraine, continued escalation of this conflict as well as the Israeli-Hamas conflict may negatively impact the global economy and our future operating results and financial condition.

[0001596532-23-000274:notes:13]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable; however, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that some of our customers, following a year of elevated purchases, must now consider changing technology roadmaps and priorities, including the need for the rapid deployment of AI and related technologies, resulting in some uncertainty as to future investment plans and a more constrained approach to some forecasts and orders in the near term. In addition, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

[0001596532-23-000274:notes:14]
[same as prior period, unchanged from 0001596532-23-000197:notes:14]

[0001596532-23-000274:notes:15]
We believe that all recently issued accounting pronouncements from the FASB will not have a material impact on our Consolidated Financial Statements or do not apply to our operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-23-000274:notes:16]
[same as prior period, unchanged from 0001596532-23-000197:notes:16]

[0001596532-23-000274:notes:17]
[same as prior period, unchanged from 0001596532-23-000197:notes:17]

[0001596532-23-000274:notes:18]
|  |  | September 30, 2023 |  | December 31, 2022 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 709,525 |  |  | $ | — |  |  | $ | — |  |  | $ | 709,525 |  |  | $ | 322,294 |  |  | $ | — |  |  | $ | — |  |  | $ | 322,294 |  |
| Commercial paper |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5,422 |  |  | — |  |  | 5,422 |  |
| U.S. government notes |  | — |  |  | — |  |  | — |  |  | — |  |  | 51,986 |  |  | — |  |  | — |  |  | 51,986 |  |
| Agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 17,559 |  |  | — |  |  | 17,559 |  |
|  |  | 709,525 |  |  | — |  |  | — |  |  | 709,525 |  |  | 374,280 |  |  | 22,981 |  |  | — |  |  | 397,261 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 27,764 |  |  | — |  |  | 27,764 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposits(1) |  | — |  |  | 7,000 |  |  | — |  |  | 7,000 |  |  | — |  |  | 10,492 |  |  | — |  |  | 10,492 |  |
| U.S. government notes |  | 901,551 |  |  | — |  |  | — |  |  | 901,551 |  |  | 993,955 |  |  | — |  |  | — |  |  | 993,955 |  |
| Corporate bonds |  | — |  |  | 1,125,203 |  |  | — |  |  | 1,125,203 |  |  | — |  |  | 1,113,134 |  |  | — |  |  | 1,113,134 |  |
| Agency securities |  | — |  |  | 645,267 |  |  | — |  |  | 645,267 |  |  | — |  |  | 215,380 |  |  | — |  |  | 215,380 |  |
| Marketable equity securities(2) |  | — |  |  | — |  |  | — |  |  | — |  |  | 19,061 |  |  | — |  |  | — |  |  | 19,061 |  |
|  |  | 901,551 |  |  | 1,805,234 |  |  | — |  |  | 2,706,785 |  |  | 1,013,016 |  |  | 1,339,006 |  |  | — |  |  | 2,352,022 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 858 |  |  | — |  |  | — |  |  | 858 |  |  | 4,271 |  |  | — |  |  | — |  |  | 4,271 |  |
| Total Financial Assets |  | $ | 1,611,934 |  |  | $ | 1,805,234 |  |  | $ | — |  |  | $ | 3,417,168 |  |  | $ | 1,391,567 |  |  | $ | 1,361,987 |  |  | $ | — |  |  | $ | 2,753,554 |  |

[0001596532-23-000274:notes:19]
[same as prior period, unchanged from 0001596532-23-000197:notes:19]

[0001596532-23-000274:notes:20]
(1) As of September 30, 2023 and December 31, 2022, all of our certificates of deposits were domestic deposits.

[0001596532-23-000274:notes:21]
(2) During the three months ended September 30, 2023, the Company sold all its shares of marketable equity securities for $23.9 million. This publicly-traded equity investment generated a realized loss of $1.0 million and an unrealized gain of $5.8 million for the three and nine months ended September 30, 2023, respectively. The initial cost of this investment was $3.0 million with no changes since our initial investment. The cumulative gain from the initial purchase was $20.9 million, the majority of which has been reflected in prior periods as net unrealized gains. The realized and unrealized gains/losses are included in Other income (expense), net on the unaudited Condensed Consolidated Statements of Operations. Refer to Note 3. Financial Statements Details.

[0001596532-23-000274:notes:22]
During the three and nine months ended September 30, 2023, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-23-000274:notes:23]
[same as prior period, unchanged from 0001596532-23-000197:notes:23]

[0001596532-23-000274:notes:24]
[same as prior period, unchanged from 0001596532-23-000197:notes:24]

[0001596532-23-000274:notes:25]
|  |  | September 30, 2023 |  | December 31, 2022 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 27,764 |  |  | $ | — |  |  | $ | — |  |  | $ | 27,764 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| U.S. government |  | 906,878 |  |  | — |  |  | (5,327) |  |  | 901,551 |  |  | 1,007,175 |  |  | 3 |  |  | (13,223) |  |  | 993,955 |  |
| Corporate bonds |  | 1,132,878 |  |  | 42 |  |  | (7,717) |  |  | 1,125,203 |  |  | 1,125,920 |  |  | 271 |  |  | (13,057) |  |  | 1,113,134 |  |
| Agency securities |  | 648,997 |  |  | 10 |  |  | (3,740) |  |  | 645,267 |  |  | 217,893 |  |  | 83 |  |  | (2,596) |  |  | 215,380 |  |
| Total |  | $ | 2,716,517 |  |  | $ | 52 |  |  | $ | (16,784) |  |  | $ | 2,699,785 |  |  | $ | 2,350,988 |  |  | $ | 357 |  |  | $ | (28,876) |  |  | $ | 2,322,469 |  |

[0001596532-23-000274:notes:26]
For debt securities in unrealized loss positions, it is not likely that we will be required to sell such securities before recovery of their amortized cost basis nor do we have the intent to sell such securities before maturity. We invest in debt securities that have maximum maturities of two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. Given the short-term and conservative nature of our portfolio, our debt securities are generally not subject to credit risk; therefore, we did not recognize any credit losses or non-credit-related impairments related to such securities for the three and nine months ended September 30, 2023. All unrealized losses were recognized in other comprehensive income (loss). Realized gains or losses were immaterial for the three and nine months ended September 30, 2023.

[0001596532-23-000274:notes:27]
[same as prior period, unchanged from 0001596532-23-000197:notes:27]

[0001596532-23-000274:notes:28]
|  |  | September 30, 2023 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 688,395 |  |  | $ | (3,625) |  |  | $ | 182,156 |  |  | $ | (1,702) |  |  | $ | 870,551 |  |  | $ | (5,327) |  |
| Corporate bonds |  | 925,541 |  |  | (5,928) |  |  | 163,152 |  |  | (1,789) |  |  | 1,088,693 |  |  | (7,717) |  |
| Agency securities |  | 542,013 |  |  | (3,158) |  |  | 62,479 |  |  | (582) |  |  | 604,492 |  |  | (3,740) |  |
| Total |  | $ | 2,155,949 |  |  | $ | (12,711) |  |  | $ | 407,787 |  |  | $ | (4,073) |  |  | $ | 2,563,736 |  |  | $ | (16,784) |  |

[0001596532-23-000274:notes:29]
As of September 30, 2023, we had no marketable debt securities with contractual maturities that exceed 24 months. The fair values of marketable debt securities, by remaining contractual maturities, are as follows (in thousands):

[0001596532-23-000274:notes:30]
|  |  | September 30, 2023 |
|  |  | Fair Value |
| Due in 1 year or less |  | $ | 1,517,054 |  |
| Due in 1 to 2 years |  | 1,182,731 |  |
| Total debt securities |  | $ | 2,699,785 |  |

[0001596532-23-000274:notes:31]
The weighted-average remaining duration of our marketable debt securities is approximately 0.9 years as of September 30, 2023. As we view these marketable debt securities as available to support current operations, we classify marketable debt securities with maturities beyond 12 months as current assets under the caption "Marketable securities" on the condensed consolidated balance sheets.

[0001596532-23-000274:notes:32]
[same as prior period, unchanged from 0001596532-23-000197:notes:32]

[0001596532-23-000274:notes:33]
[same as prior period, unchanged from 0001596532-23-000197:notes:33]

[0001596532-23-000274:notes:34]
[same as prior period, unchanged from 0001596532-23-000197:notes:34]

[0001596532-23-000274:notes:35]
We did not record any realized gains for our non-marketable equity securities during the three and nine months ended September 30, 2023 and September 30, 2022, and we recorded an immaterial amount of realized and unrealized losses for the three and nine months ended September 30, 2023 and September 30, 2022. Unrealized gains for our non-marketable equity securities are summarized below (in thousands):

[0001596532-23-000274:notes:36]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Unrealized gains on non-marketable equity securities (1) |  | $ | 500 |  |  | $ | 1,681 |  |  | $ | 13,901 |  |  | $ | 16,681 |  |

[0001596532-23-000274:notes:37]
[same as prior period, unchanged from 0001596532-23-000197:notes:37]

[0001596532-23-000274:notes:38]
[same as prior period, unchanged from 0001596532-23-000197:notes:38]

[0001596532-23-000274:notes:39]
The following table summarizes the activity related to our non-marketable equity securities as of September 30, 2023 and December 31, 2022 (in thousands):

[0001596532-23-000274:notes:40]
|  |  | September 30, 2023 |  | December 31, 2022 |
| Cost of investments(1) |  | $ | 31,656 |  |  | $ | 23,625 |  |
| Cumulative impairment and downward adjustment |  | — |  |  | (888) |  |
| Cumulative upward adjustment |  | 30,632 |  |  | 16,731 |  |
| Carrying amount of investments |  | $ | 62,288 |  |  | $ | 39,468 |  |

[0001596532-23-000274:notes:41]
(1) During the nine months ended September 30, 2023, we had an $8.0 million convertible note previously included in other assets, plus accrued interest of $0.6 million, that was converted to an equity investment and included in cost of investments.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-23-000274:notes:42]
[same as prior period, unchanged from 0001596532-23-000197:notes:42]

[0001596532-23-000274:notes:43]
(1) As of September 30, 2023 and December 31, 2022, all of our certificates of deposits were domestic deposits.
(2) During the three months ended September 30, 2023, the Company sold all its shares of marketable equity securities for $23.9 million. This publicly-traded equity investment generated a realized loss of $1.0 million and an unrealized gain of $5.8 million for the three and nine months ended September 30, 2023, respectively. The initial cost of this investment was $3.0 million with no changes since our initial investment. The cumulative gain from the initial purchase was $20.9 million, the majority of which has been reflected in prior periods as net unrealized gains. The realized and unrealized gains/losses are included in Other income (expense), net on the unaudited Condensed Consolidated Statements of Operations. Refer to Note 3. Financial Statements Details.The following table summarizes the amortized cost, unrealized gains and losses, and fair value of our debt securities measured at fair value on a recurring basis (in thousands):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-23-000274:notes:44]
[same as prior period, unchanged from 0001596532-23-000197:notes:44]

[0001596532-23-000274:notes:45]
[same as prior period, unchanged from 0001596532-23-000197:notes:45]

[0001596532-23-000274:notes:46]
|  |  | September 30, 2023 |  | December 31, 2022 |
| Cash and cash equivalents |  | $ | 1,748,818 |  |  | $ | 671,707 |  |
| Restricted cash included in other assets |  | 858 |  |  | 4,271 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 1,749,676 |  |  | $ | 675,978 |  |

[0001596532-23-000274:notes:47]
[same as prior period, unchanged from 0001596532-23-000197:notes:47]

[0001596532-23-000274:notes:48]
[same as prior period, unchanged from 0001596532-23-000197:notes:48]

[0001596532-23-000274:notes:49]
|  |  | September 30, 2023 |  | December 31, 2022 |
| Accounts receivable |  | $ | 846,577 |  |  | $ | 928,490 |  |
| Allowance for doubtful accounts |  | (2,485) |  |  | (19) |  |
| Product sales rebate and returns reserve |  | (10,718) |  |  | (5,375) |  |
| Accounts receivable, net |  | $ | 833,374 |  |  | $ | 923,096 |  |

[0001596532-23-000274:notes:50]
[same as prior period, unchanged from 0001596532-23-000197:notes:50]

[0001596532-23-000274:notes:51]
[same as prior period, unchanged from 0001596532-23-000197:notes:51]

[0001596532-23-000274:notes:52]
|  |  | September 30, 2023 |  | December 31, 2022 |
| Raw materials |  | $ | 944,329 |  |  | $ | 759,519 |  |
| Finished goods |  | 949,209 |  |  | 530,187 |  |
| Total inventories |  | $ | 1,893,538 |  |  | $ | 1,289,706 |  |

[0001596532-23-000274:notes:53]
[same as prior period, unchanged from 0001596532-23-000197:notes:53]

[0001596532-23-000274:notes:54]
[same as prior period, unchanged from 0001596532-23-000197:notes:54]

[0001596532-23-000274:notes:55]
|  |  | September 30, 2023 |  | December 31, 2022 |
| Inventory deposits |  | $ | 198,369 |  |  | $ | 162,047 |  |
| Other current assets |  | 274,114 |  |  | 152,170 |  |
| Total prepaid expenses and other current assets |  | $ | 472,483 |  |  | $ | 314,217 |  |

[0001596532-23-000274:notes:56]
[same as prior period, unchanged from 0001596532-23-000197:notes:56]

[0001596532-23-000274:notes:57]
[same as prior period, unchanged from 0001596532-23-000197:notes:57]

[0001596532-23-000274:notes:58]
|  |  | September 30, 2023 |  | December 31, 2022 |
| Land |  | $ | 44,017 |  |  | $ | 41,500 |  |
| Equipment and machinery |  | 142,205 |  |  | 122,407 |  |
| Computer hardware and software |  | 57,052 |  |  | 52,148 |  |
| Leasehold improvements |  | 32,146 |  |  | 30,102 |  |
| Furniture and fixtures |  | 3,559 |  |  | 3,575 |  |
| Construction-in-process |  | 4,422 |  |  | 2,124 |  |
| Property and equipment, gross |  | 283,401 |  |  | 251,856 |  |
| Less: accumulated depreciation |  | (180,809) |  |  | (156,847) |  |
| Property and equipment, net |  | $ | 102,592 |  |  | $ | 95,009 |  |

[0001596532-23-000274:notes:59]
Depreciation expense was $8.6 million and $6.9 million for the three months ended September 30, 2023 and 2022, respectively, and $23.5 million and $18.7 million for the nine months ended September 30, 2023 and 2022, respectively.

[0001596532-23-000274:notes:60]
[same as prior period, unchanged from 0001596532-23-000197:notes:60]

[0001596532-23-000274:notes:61]
[same as prior period, unchanged from 0001596532-23-000197:notes:61]

[0001596532-23-000274:notes:62]
|  |  | September 30, 2023 |  | December 31, 2022 |
| Accrued compensation-related costs |  | $ | 99,382 |  |  | $ | 117,053 |  |
| Accrued supplier liability |  | 183,148 |  |  | 71,481 |  |
| Accrued manufacturing costs |  | 56,740 |  |  | 45,379 |  |
| Accrued product development costs |  | 33,184 |  |  | 27,380 |  |
| Other |  | 37,617 |  |  | 31,194 |  |
| Total accrued liabilities |  | $ | 410,071 |  |  | $ | 292,487 |  |

[0001596532-23-000274:notes:63]
[same as prior period, unchanged from 0001596532-23-000197:notes:63]

[0001596532-23-000274:notes:64]
[same as prior period, unchanged from 0001596532-23-000197:notes:64]

[0001596532-23-000274:notes:65]
[same as prior period, unchanged from 0001596532-23-000197:notes:65]

[0001596532-23-000274:notes:66]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Contract liabilities, beginning balance |  | $ | 110,097 |  |  | $ | 101,600 |  |  | $ | 103,448 |  |  | $ | 93,382 |  |
| Less: Revenue recognized from beginning balance |  | (10,222) |  |  | (9,173) |  |  | (33,466) |  |  | (29,296) |  |
| Less: Beginning balance reclassified to deferred revenue |  | (5,306) |  |  | (9,898) |  |  | (5,228) |  |  | (2,998) |  |
| Add: Contract liabilities recognized |  | 25,712 |  |  | 18,247 |  |  | 55,527 |  |  | 39,688 |  |
| Contract liabilities, ending balance |  | $ | 120,281 |  |  | $ | 100,776 |  |  | $ | 120,281 |  |  | $ | 100,776 |  |

[0001596532-23-000274:notes:67]
As of September 30, 2023 and December 31, 2022, $52.5 million and $45.2 million of our contract liabilities, respectively, were included in "Other current liabilities" with the remaining balances included in "Other long-term liabilities" on the condensed consolidated balance sheets.

[0001596532-23-000274:notes:68]
[same as prior period, unchanged from 0001596532-23-000197:notes:68]

[0001596532-23-000274:notes:69]
[same as prior period, unchanged from 0001596532-23-000197:notes:69]

[0001596532-23-000274:notes:70]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Deferred revenue, beginning balance |  | $ | 1,084,904 |  |  | $ | 1,033,490 |  |  | $ | 1,041,246 |  |  | $ | 929,312 |  |
| Less: Revenue recognized from beginning balance |  | (173,494) |  |  | (234,515) |  |  | (506,859) |  |  | (457,309) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 283,341 |  |  | 142,069 |  |  | 660,364 |  |  | 469,041 |  |
| Deferred revenue, ending balance |  | $ | 1,194,751 |  |  | $ | 941,044 |  |  | $ | 1,194,751 |  |  | $ | 941,044 |  |

[0001596532-23-000274:notes:71]
[same as prior period, unchanged from 0001596532-23-000197:notes:71]

[0001596532-23-000274:notes:72]
Other performance obligations totaling $820.3 million as of September 30, 2023 include unbilled multi-year PCS and service contract amounts of $313.2 million and $507.1 million of binding contractual agreements with certain customers that are primarily related to future product shipments.

[0001596532-23-000274:notes:73]
[same as prior period, unchanged from 0001596532-23-000197:notes:73]

[0001596532-23-000274:notes:74]
Total revenue from our contract liabilities, deferred revenue and other performance obligations that will be recognized in future periods amounts to $2.1 billion. Included in this amount is the $507.1 million of binding contractual agreements related primarily to future product shipments that are expected to be recognized as revenue over the next two years. In addition, approximately 76% of the remaining $1.6 billion of this future revenue is expected to be recognized over the next two years and approximately 24% is expected to be recognized during the third to the fifth year.

[0001596532-23-000274:notes:75]
[same as prior period, unchanged from 0001596532-23-000197:notes:75]

[0001596532-23-000274:notes:76]
[same as prior period, unchanged from 0001596532-23-000197:notes:76]

[0001596532-23-000274:notes:77]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest income |  | $ | 43,676 |  |  | $ | 6,929 |  |  | $ | 98,391 |  |  | $ | 13,783 |  |
| Gain (loss) on strategic investments |  | (473) |  |  | 708 |  |  | 18,699 |  |  | 24,121 |  |
| Other income (expense), net |  | (1,388) |  |  | (820) |  |  | (6,790) |  |  | (140) |  |
| Total |  | $ | 41,815 |  |  | $ | 6,817 |  |  | $ | 110,300 |  |  | $ | 37,764 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-23-000274:notes:78]
[same as prior period, unchanged from 0001596532-23-000197:notes:78]

[0001596532-23-000274:notes:79]
[same as prior period, unchanged from 0001596532-23-000197:notes:79]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-23-000274:notes:80]
[same as prior period, unchanged from 0001596532-23-000197:notes:80]

[0001596532-23-000274:notes:81]
We had no material business acquisitions during the nine months ended September 30, 2023. During the year ended December 31, 2022, we completed two acquisitions of private companies for total consideration of $158.9 million including $4.0 million in common stock and the remainder in cash. The purchase prices included $62.3 million of intangible assets, $77.5 million of goodwill and $19.1 million of net tangible assets acquired. We also incurred certain acquisition-related expenses of $4.7 million, which primarily consisted of retention bonuses to continuing employees as well as professional and consulting fees.

[0001596532-23-000274:notes:82]
The purchase price allocation for the two acquisitions have been finalized. No changes were made to the purchase price allocation for the three and nine months ended September 30, 2023.

[0001596532-23-000274:notes:83]
[same as prior period, unchanged from 0001596532-23-000197:notes:83]

[0001596532-23-000274:notes:84]
No material changes were made to the carrying values of goodwill for the three and nine months ended September 30, 2023.

[0001596532-23-000274:notes:85]
[same as prior period, unchanged from 0001596532-23-000197:notes:85]

[0001596532-23-000274:notes:86]
[same as prior period, unchanged from 0001596532-23-000197:notes:86]

[0001596532-23-000274:notes:87]
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life (in years) |
|  | December 31, 2022 |  | Additions |  | September 30, 2023 |  | December 31, 2022 |  | Amortization |  | September 30, 2023 |  | December 31, 2022 |  | September 30, 2023 |  |
| Developed technology | $ | 154,930 |  |  | $ | — |  |  | $ | 154,930 |  |  | $ | (79,036) |  |  | $ | (19,262) |  |  | $ | (98,298) |  |  | $ | 75,894 |  |  | $ | 56,632 |  |  | 4.2 |
| Customer relationships | 54,620 |  |  | — |  |  | 54,620 |  |  | (14,097) |  |  | (5,775) |  |  | (19,872) |  |  | 40,523 |  |  | 34,748 |  |  | 5.0 |
| Trade name | 12,390 |  |  | — |  |  | 12,390 |  |  | (6,602) |  |  | (1,710) |  |  | (8,312) |  |  | 5,788 |  |  | 4,078 |  |  | 1.8 |
| Total | $ | 221,940 |  |  | $ | — |  |  | $ | 221,940 |  |  | $ | (99,735) |  |  | $ | (26,747) |  |  | $ | (126,482) |  |  | $ | 122,205 |  |  | $ | 95,458 |  |  | 4.4 |

[0001596532-23-000274:notes:88]
Amortization expense related to acquisition-related intangible assets was $8.1 million and $9.3 million for the three months ended September 30, 2023 and 2022, respectively, and $26.7 million and $24.3 million for the nine months ended September 30, 2023 and 2022, respectively.

[0001596532-23-000274:notes:89]
As of September 30, 2023, future estimated amortization expense related to the acquisition-related intangible assets is as follows (in thousands):

[0001596532-23-000274:notes:90]
|  |  | Future Amortization Expense |
| Remainder of 2023 |  | $ | 6,691 |  |
| 2024 |  | 26,759 |  |
| 2025 |  | 19,642 |  |
| 2026 |  | 17,260 |  |
| 2027 |  | 13,436 |  |
| Thereafter |  | 11,670 |  |
| Total |  | $ | 95,458 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-23-000274:notes:91]
Commitments and Contingencies
Purchase Commitments

[0001596532-23-000274:notes:92]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2023, we had non-cancellable purchase commitments of $2.0 billion, of which $1.7 billion have expected receipt dates within 12 months, and $0.3 billion have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-23-000274:notes:93]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $201.1 million and $192.5 million as of September 30, 2023 and December 31, 2022, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

[0001596532-23-000274:notes:94]
Guarantees

[0001596532-23-000274:notes:95]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-23-000274:notes:96]
Legal Proceedings

[0001596532-23-000274:notes:97]
WSOU Investments, LLC

[0001596532-23-000274:notes:98]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California.  On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement.  On July 1, 2022, the court stayed the case pending the resolution of an inter partes review of one of the patents-in-suit. On May 30, 2023, the US Patent Trial and Appeal Board (“PTAB”) ruled all challenged claims in the inter partes review unpatentable. The district court case remains stayed pending appeal and/or final resolution of the PTAB ruling.

[0001596532-23-000274:notes:99]
We intend to vigorously defend against the claims brought against us by WSOU; however, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-23-000274:notes:100]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated; however, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-23-000274:notes:101]
Other matters

[0001596532-23-000274:notes:102]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-23-000274:notes:103]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2023, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse 
impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-23-000274:notes:104]
[same as prior period, unchanged from 0001596532-23-000197:notes:104]

[0001596532-23-000274:notes:105]
In October 2021, our board of directors authorized a $1.0 billion stock repurchase program (the “Repurchase Program”). This authorization allows us to repurchase shares of our common stock that will be funded from working capital and expires in the fourth quarter of 2024. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the "Exchange Act"), or a combination of the foregoing. The Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the company at any time without prior notice. As of September 30, 2023, the remaining authorized amount for stock repurchases under the Repurchase Program was approximately $144.5 million.

[0001596532-23-000274:notes:106]
We did not repurchase any shares during the three months ended September 30, 2023. A summary of the stock repurchase activity under the Repurchase Program for the nine months ended September 30, 2023 is as follows (in thousands, except per share amounts):

[0001596532-23-000274:notes:107]
|  |  |  |  | Nine Months Ended |
|  |  |  |  | September 30, 2023 |
| Aggregate purchase price |  |  |  | $ | 112,279 |  |
| Shares repurchased |  |  |  | 954 |  |
| Average price paid per share |  |  |  | $ | 117.70 |  |

[0001596532-23-000274:notes:108]
[same as prior period, unchanged from 0001596532-23-000197:notes:108]

[0001596532-23-000274:notes:109]
[same as prior period, unchanged from 0001596532-23-000197:notes:109]

[0001596532-23-000274:notes:110]
[same as prior period, unchanged from 0001596532-23-000197:notes:110]

[0001596532-23-000274:notes:111]
[same as prior period, unchanged from 0001596532-23-000197:notes:111]

[0001596532-23-000274:notes:112]
Awards granted under the 2014 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Units (“RSUs”), Restricted Stock Awards (“RSAs”) or Stock Appreciation Rights (“SARs”). The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of the outstanding shares of our common stock on the immediately preceding December 31, but not to exceed 50 million shares, unless our board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2023, our board of directors authorized an increase of 9.2 million shares to the shares available for issuance under the 2014 Plan. As of September 30, 2023, there remained approximately 96.5 million shares available for issuance under the 2014 Plan.

[0001596532-23-000274:notes:113]
[same as prior period, unchanged from 0001596532-23-000197:notes:113]

[0001596532-23-000274:notes:114]
In April 2014, our board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding on the immediately preceding December 31, but not to exceed 10 million shares, unless our board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2023, our board of directors authorized an increase of 3.1 million shares to the shares available for issuance under the ESPP. During the nine months ended September 30, 2023, we issued 279,498 shares at a weighted-average purchase price of $105.69 per share under the ESPP. As of September 30, 2023, there remained approximately 23.4 million shares available for issuance under the ESPP.

[0001596532-23-000274:notes:115]
[same as prior period, unchanged from 0001596532-23-000197:notes:115]

[0001596532-23-000274:notes:116]
[same as prior period, unchanged from 0001596532-23-000197:notes:116]

[0001596532-23-000274:notes:117]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2022 |  | 5,769 |  |  | $ | 14.09 |  |  | 2.0 |  | $ | 618,774 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (2,694) |  |  | 9.00 |  |  |  |  |  |
| Options canceled |  | (2) |  |  | 8.10 |  |  |  |  |  |
| Balance—September 30, 2023 |  | 3,073 |  |  | $ | 18.56 |  |  | 1.8 |  | $ | 508,139 |  |
| Vested and exercisable—September 30, 2023 |  | 2,799 |  |  | $ | 16.61 |  |  | 1.5 |  | $ | 468,286 |  |

[0001596532-23-000274:notes:118]
[same as prior period, unchanged from 0001596532-23-000197:notes:118]

[0001596532-23-000274:notes:119]
[same as prior period, unchanged from 0001596532-23-000197:notes:119]

[0001596532-23-000274:notes:120]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2022 |  | 8,360 |  |  | $ | 85.83 |  |  | 1.7 |  | $ | 1,014,431 |  |
| RSUs granted |  | 2,575 |  |  | 156.34 |  |  |  |  |  |
| RSUs vested |  | (2,166) |  |  | 78.49 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (235) |  |  | 98.72 |  |  |  |  |  |
| Unvested balance—September 30, 2023 |  | 8,534 |  |  | $ | 109.13 |  |  | 1.9 |  | $ | 1,569,587 |  |

[0001596532-23-000274:notes:121]
[same as prior period, unchanged from 0001596532-23-000197:notes:121]

[0001596532-23-000274:notes:122]
[same as prior period, unchanged from 0001596532-23-000197:notes:122]

[0001596532-23-000274:notes:123]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cost of revenue |  | $ | 3,717 |  |  | $ | 2,992 |  |  | $ | 9,516 |  |  | $ | 6,613 |  |
| Research and development |  | 47,965 |  |  | 37,698 |  |  | 125,671 |  |  | 93,723 |  |
| Sales and marketing |  | 20,490 |  |  | 16,103 |  |  | 51,461 |  |  | 42,039 |  |
| General and administrative |  | 13,218 |  |  | 8,684 |  |  | 28,750 |  |  | 23,605 |  |
| Total stock-based compensation |  | $ | 85,390 |  |  | $ | 65,477 |  |  | $ | 215,398 |  |  | $ | 165,980 |  |

[0001596532-23-000274:notes:124]
As of September 30, 2023, there were $804.3 million of unamortized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 3.6 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-23-000274:notes:125]
[same as prior period, unchanged from 0001596532-23-000197:notes:125]

[0001596532-23-000274:notes:126]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 545,327 |  |  | $ | 353,999 |  |  | $ | 1,473,685 |  |  | $ | 925,357 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share, basic |  | 310,185 |  |  | 304,931 |  |  | 308,602 |  |  | 306,576 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity awards |  | 7,446 |  |  | 9,470 |  |  | 7,962 |  |  | 10,169 |  |
| Weighted-average shares used in computing net income per share, diluted |  | 317,631 |  |  | 314,401 |  |  | 316,564 |  |  | 316,745 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.76 |  |  | $ | 1.16 |  |  | $ | 4.78 |  |  | $ | 3.02 |  |
| Diluted |  | $ | 1.72 |  |  | $ | 1.13 |  |  | $ | 4.66 |  |  | $ | 2.92 |  |

[0001596532-23-000274:notes:127]
[same as prior period, unchanged from 0001596532-23-000197:notes:127]

[0001596532-23-000274:notes:128]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Stock options and RSUs |  | 4 |  |  | 292 |  |  | 191 |  |  | 379 |  |
| Employee stock purchase plan |  | 25 |  |  | 295 |  |  | 150 |  |  | 104 |  |
| Total |  | 29 |  |  | 587 |  |  | 341 |  |  | 483 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-23-000274:notes:129]
[same as prior period, unchanged from 0001596532-23-000197:notes:129]

[0001596532-23-000274:notes:130]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Income before income taxes |  | $ | 644,510 |  |  | $ | 424,164 |  |  | $ | 1,727,635 |  | $ | 1,095,951 |  |
| Provision for income taxes |  | 99,183 |  |  | 70,165 |  |  | $ | 253,950 |  | 170,594 |  |
| Effective tax rate |  | 15.4 | % |  | 16.5 | % |  | 14.7 | % |  | 15.6 | % |

[0001596532-23-000274:notes:131]
The decrease in the effective tax rates in the three and nine months ended September 30, 2023, as compared to the same periods in 2022, was primarily due to an increase in tax benefits attributable to stock-based compensation.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-23-000274:notes:132]
[same as prior period, unchanged from 0001596532-23-000197:notes:132]

[0001596532-23-000274:notes:133]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Americas(1) |  | $ | 1,184,717 |  |  | $ | 977,674 |  |  | $ | 3,454,237 |  |  | $ | 2,487,106 |  |
| Europe, Middle East and Africa |  | 173,175 |  |  | 110,793 |  |  | 469,114 |  |  | 350,136 |  |
| Asia-Pacific |  | 151,564 |  |  | 88,334 |  |  | 396,380 |  |  | 268,516 |  |
| Total revenue |  | $ | 1,509,456 |  |  | $ | 1,176,801 |  |  | $ | 4,319,731 |  |  | $ | 3,105,758 |  |

[0001596532-23-000274:notes:134]
(1) Includes $1,150.5 million and $969.2 million revenue generated from the U.S. for the three months ended September 30, 2023 and September 30, 2022, respectively, and $3,366.8 million and $2,456.8 million for the nine months ended September 30, 2023 and September 30, 2022, respectively.

[0001596532-23-000274:notes:135]
[same as prior period, unchanged from 0001596532-23-000197:notes:135]

[0001596532-23-000274:notes:136]
|  |  | September 30, 2023 |  | December 31, 2022 |
| United States |  | $ | 80,449 |  |  | $ | 71,540 |  |
| International |  | 22,143 |  |  | 23,469 |  |
| Total |  | $ | 102,592 |  |  | $ | 95,009 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001596532-23-000274:notes:137]
On September 12, 2023, Yvonne Wassenaar, a member of our Board of Directors, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of 819 shares of our common stock. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until December 16, 2024, or earlier if all transactions under the trading arrangement are completed.

[0001596532-23-000274:notes:138]
On September 8, 2023, John McCool, our Chief Platform Officer, and Senior Vice President of Engineering and Operations, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to: (i) 29,341 shares of our common stock; (ii) a number of shares of our common stock that may be earned in connection with grants of performance-based restricted stock units, which cannot be determined at this time; and (iii) a number of shares of our common stock that will be purchased under the 2014 ESPP during the term of the trading arrangement, which cannot be determined at this time. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until December 8, 2024, or earlier if all transactions under the trading arrangement are completed.

[0001596532-23-000274:notes:139]
On September 13, 2023, Marc Taxay, our Senior Vice President and General Counsel, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to (i) 39,135 shares of our common stock; and (ii) a number of shares of our common stock that may be earned in connection with grants of performance-based restricted stock units, which cannot be determined at this time. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until January 1, 2025, or earlier if all transactions under the trading arrangement are completed.
