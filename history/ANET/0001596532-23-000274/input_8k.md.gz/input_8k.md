# ANET 8-K — 0001596532-23-000272 filed 2023-10-30

## item codes, every 8-K on or before 2023-10-31

- 2023-10-30 0001596532-23-000272 — 2.02, 9.01
- 2023-07-31 0001596532-23-000196 — 2.02, 5.02, 9.01
- 2023-06-16 0001596532-23-000168 — 5.07
- 2023-05-01 0001596532-23-000101 — 2.02, 9.01
- 2023-02-13 0001596532-23-000015 — 2.02, 9.01
- 2022-10-31 0001596532-22-000292 — 2.02, 9.01
- 2022-10-25 0001596532-22-000282 — 5.03, 9.01
- 2022-08-01 0001596532-22-000218 — 2.02, 9.01
- 2022-07-25 0001596532-22-000205 — 5.02
- 2022-06-03 0001596532-22-000179 — 5.07
- 2022-05-02 0001596532-22-000111 — 2.02, 9.01
- 2022-03-29 0001596532-22-000100 — 5.02
- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2023-10-31

- none on or before 2023-10-31

## item 2.02 — earnings release, exhibit 99.1

[0001596532-23-000272:8k_2_02:1]
EX-99.1
2
ex991q323-earningsrelease.htm
EX-99.1

[0001596532-23-000272:8k_2_02:2]
Document

[0001596532-23-000272:8k_2_02:3]
Exhibit 99.1

[0001596532-23-000272:8k_2_02:4]
Arista Networks, Inc. Reports Third Quarter 2023 Financial Results

[0001596532-23-000272:8k_2_02:5]
SANTA CLARA, Calif.- October 30, 2023 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments, today announced financial results for its third quarter ended September 30, 2023.

[0001596532-23-000272:8k_2_02:6]
Third Quarter Financial Highlights

[0001596532-23-000272:8k_2_02:7]
“Arista once again delivered strong financial results in the third quarter,” says Jayshree Ullal, President and CEO of Arista Networks. “Customer momentum remained strong in both enterprise and cloud/AI sectors.”

[0001596532-23-000272:8k_2_02:8]
•Revenue of $1.509 billion, an increase of 3.5% compared to the second quarter of 2023, and an increase of 28.3% from the third quarter of 2022.

[0001596532-23-000272:8k_2_02:9]
•GAAP gross margin of 62.4%, compared to GAAP gross margin of 60.6% in the second quarter of 2023 and 60.3% in the third quarter of 2022.

[0001596532-23-000272:8k_2_02:10]
•Non-GAAP gross margin of 63.1%, compared to non-GAAP gross margin of 61.3% in the second quarter of 2023 and 61.2% in the third quarter of 2022.

[0001596532-23-000272:8k_2_02:11]
•GAAP net income of $545.3 million, or $1.72 per diluted share, compared to GAAP net income of $354.0 million, or $1.13 per diluted share in the third quarter of 2022.

[0001596532-23-000272:8k_2_02:12]
•Non-GAAP net income of $581.4 million, or $1.83 per diluted share, compared to non-GAAP net income of $391.9 million, or $1.25 per diluted share in the third quarter of 2022.

[0001596532-23-000272:8k_2_02:13]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO said, “The team continues to demonstrate strong discipline, working to normalize supply chain metrics while delivering incremental improvements to our 2023 outlook, which now calls for year-over-year revenue growth in excess of 33%.”

[0001596532-23-000272:8k_2_02:14]
Company Highlights

[0001596532-23-000272:8k_2_02:15]
•Arista Appointed by Spark as Private Telecommunications Cloud Networking Provider – Arista announced that it has been appointed by Spark as a private cloud networking provider to support Spark’s data centre networking services for a new private telecommunications cloud platform.

[0001596532-23-000272:8k_2_02:16]
•The Arrival of Open AI Networking – Arista and the founding members of the Ultra Ethernet Consortium, UEC, have set out on the mission to enhance the capabilities of Ethernet for AI and HPC.

[0001596532-23-000272:8k_2_02:17]
•Arista is Recognized by Newsweek as one of America’s Greenest Companies – Arista is pleased to be included in Newsweek’s first ranking of America's Greenest Companies which captures a snapshot in time of where the leading companies are—and sets a benchmark for future rankings.

[0001596532-23-000272:8k_2_02:18]
Financial Outlook

[0001596532-23-000272:8k_2_02:19]
For the fourth quarter of 2023, we expect:

[0001596532-23-000272:8k_2_02:20]
•Revenue between $1.500 billion to $1.550 billion

[0001596532-23-000272:8k_2_02:21]
•Non-GAAP gross margin of approximately 63%; and

[0001596532-23-000272:8k_2_02:22]
•Non-GAAP operating margin of approximately 42%.

[0001596532-23-000272:8k_2_02:23]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and potential non-recurring charges or benefits. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis because these exclusions can be uncertain or difficult to predict, including stock-based compensation expense which is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common

[0001596532-23-000272:8k_2_02:24]
stock. The actual amount of these exclusions will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-23-000272:8k_2_02:25]
Prepared Materials and Conference Call Information

[0001596532-23-000272:8k_2_02:26]
Arista's executives will discuss the third quarter 2023 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-23-000272:8k_2_02:27]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-23-000272:8k_2_02:28]
Forward-Looking Statements

[0001596532-23-000272:8k_2_02:29]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the fourth quarter of 2023 and statements regarding the benefits of Arista's products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: dependence on a limited number of end customers who represent a substantial portion of our revenue; adverse economic and geopolitical conditions and conflicts, including inflationary pressures which result in increased component costs and reduced information technology and network infrastructure spending, the Russia/Ukraine and Israel/Hamas conflicts; changes in our customers technology roadmaps and priorities including the need for the rapid deployment of artificial intelligence (“AI”) and related technologies; the impact of limited sources of supply on our business, including significant purchase commitments, excess inventory and extended lead times or supply changes; volatility in our revenue growth rate; variations in our results of operations, including as a result of seasonality; the rapid evolution of the networking market; any failure to successfully pursue new products and service offerings and expand into adjacent markets; variability in our gross margins, including as a result of changes in customer mix or product mix; intense competition; expansion of our international sales and operations; investments in or acquisitions of other businesses; fluctuations in currency exchange rates; any failure to raise any needed capital; our ability to attract new large end customers or sell additional products and services to existing end customers; our ability to grow sales of our switches; our ability to increase market awareness of our new products and services; a decrease in the sales prices of our products and services; a decline in maintenance renewals by end customers; product quality problems; our ability to anticipate technological shifts and develop products and product enhancements that meet those technological shifts; any failure to manage the supply of our products and product components, resulting in insufficient component supply and inventory or excess inventory; our dependence on third-party manufacturers to build our products; assertions by third parties of infringement or other violations by us of their intellectual property rights; our ability to protect our intellectual property rights; vulnerabilities in our products and failure of our products to detect security breaches; tax, tariff, import/export restrictions, Chinese regulations or other trade barriers; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-23-000272:8k_2_02:30]
2

[0001596532-23-000272:8k_2_02:31]
Non-GAAP Financial Measures

[0001596532-23-000272:8k_2_02:32]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangibles and other acquisition-related expenses, gains/losses on strategic investments, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-23-000272:8k_2_02:33]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-23-000272:8k_2_02:34]
About Arista Networks

[0001596532-23-000272:8k_2_02:35]
Arista Networks is an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments. Arista’s award-winning platforms deliver availability, agility, automation, analytics and security through an advanced network operating stack. For more information, visit www.arista.com.

[0001596532-23-000272:8k_2_02:36]
ARISTA and CloudVision are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-23-000272:8k_2_02:37]
ARISTA NETWORKS, INC.

[0001596532-23-000272:8k_2_02:38]
Condensed Consolidated Income Statements

[0001596532-23-000272:8k_2_02:39]
(Unaudited, in thousands, except per share amounts)

[0001596532-23-000272:8k_2_02:40]
|  |  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,285,548 |  |  | $ | 1,008,689 |  |  | $ | 3,719,179 |  |  | $ | 2,619,213 |  |
| Service |  | 223,908 |  |  | 168,112 |  |  | 600,552 |  |  | 486,545 |  |
| Total revenue |  | 1,509,456 |  |  | 1,176,801 |  |  | 4,319,731 |  |  | 3,105,758 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 522,866 |  |  | 432,569 |  |  | 1,565,341 |  |  | 1,102,012 |  |
| Service |  | 44,171 |  |  | 34,252 |  |  | 123,335 |  |  | 96,656 |  |
| Total cost of revenue |  | 567,037 |  |  | 466,821 |  |  | 1,688,676 |  |  | 1,198,668 |  |
| Gross profit |  | 942,419 |  |  | 709,980 |  |  | 2,631,055 |  |  | 1,907,090 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 212,353 |  |  | 187,807 |  |  | 643,437 |  |  | 537,971 |  |
| Sales and marketing |  | 102,033 |  |  | 81,401 |  |  | 293,496 |  |  | 241,512 |  |
| General and administrative |  | 25,338 |  |  | 23,425 |  |  | 76,787 |  |  | 69,420 |  |
| Total operating expenses |  | 339,724 |  |  | 292,633 |  |  | 1,013,720 |  |  | 848,903 |  |
| Income from operations |  | 602,695 |  |  | 417,347 |  |  | 1,617,335 |  |  | 1,058,187 |  |
| Other income (expense), net |  | 41,815 |  |  | 6,817 |  |  | 110,300 |  |  | 37,764 |  |
| Income before income taxes |  | 644,510 |  |  | 424,164 |  |  | 1,727,635 |  |  | 1,095,951 |  |
| Provision for income taxes |  | 99,183 |  |  | 70,165 |  |  | 253,950 |  |  | 170,594 |  |
| Net income |  | $ | 545,327 |  |  | $ | 353,999 |  |  | $ | 1,473,685 |  |  | $ | 925,357 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.76 |  |  | $ | 1.16 |  |  | $ | 4.78 |  |  | $ | 3.02 |  |
| Diluted |  | $ | 1.72 |  |  | $ | 1.13 |  |  | $ | 4.66 |  |  | $ | 2.92 |  |
| Weighted-average shares used in computing net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 310,185 |  |  | 304,931 |  |  | 308,602 |  |  | 306,576 |  |
| Diluted |  | 317,631 |  |  | 314,401 |  |  | 316,564 |  |  | 316,745 |  |

[0001596532-23-000272:8k_2_02:41]
4

[0001596532-23-000272:8k_2_02:42]
ARISTA NETWORKS, INC.

[0001596532-23-000272:8k_2_02:43]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-23-000272:8k_2_02:44]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-23-000272:8k_2_02:45]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| GAAP gross profit |  | $ | 942,419 |  |  | $ | 709,980 |  |  | $ | 2,631,055 |  |  | $ | 1,907,090 |  |
| GAAP gross margin |  | 62.4 | % |  | 60.3 | % |  | 60.9 | % |  | 61.4 | % |
| Stock-based compensation expense |  | 3,717 |  |  | 2,992 |  |  | 9,516 |  |  | 6,613 |  |
| Intangible asset amortization |  | 5,622 |  |  | 6,820 |  |  | 19,262 |  |  | 18,553 |  |
| Non-GAAP gross profit |  | $ | 951,758 |  |  | $ | 719,792 |  |  | $ | 2,659,833 |  |  | $ | 1,932,256 |  |
| Non-GAAP gross margin |  | 63.1 | % |  | 61.2 | % |  | 61.6 | % |  | 62.2 | % |
| GAAP income from operations |  | $ | 602,695 |  |  | $ | 417,347 |  |  | $ | 1,617,335 |  |  | $ | 1,058,187 |  |
| Stock-based compensation expense |  | 85,390 |  |  | 65,477 |  |  | 215,398 |  |  | 165,980 |  |
| Intangible asset amortization |  | 8,117 |  |  | 9,315 |  |  | 26,747 |  |  | 24,334 |  |
| Acquisition-related costs (1) |  | — |  |  | — |  |  | — |  |  | 4,691 |  |
| Non-GAAP income from operations |  | $ | 696,202 |  |  | $ | 492,139 |  |  | $ | 1,859,480 |  |  | $ | 1,253,192 |  |
| Non-GAAP operating margin |  | 46.1 | % |  | 41.8 | % |  | 43.0 | % |  | 40.4 | % |
| GAAP net income |  | $ | 545,327 |  |  | $ | 353,999 |  |  | $ | 1,473,685 |  |  | $ | 925,357 |  |
| Stock-based compensation expense |  | 85,390 |  |  | 65,477 |  |  | 215,398 |  |  | 165,980 |  |
| Intangible asset amortization |  | 8,117 |  |  | 9,315 |  |  | 26,747 |  |  | 24,334 |  |
| Acquisition-related costs (1) |  | — |  |  | — |  |  | — |  |  | 4,691 |  |
| (Gain)/loss on strategic investments |  | 473 |  |  | (708) |  |  | (18,699) |  |  | (24,121) |  |
| Tax benefit on stock-based awards |  | (45,667) |  |  | (27,636) |  |  | (133,561) |  |  | (76,325) |  |
| Income tax effect on non-GAAP exclusions |  | (12,253) |  |  | (8,524) |  |  | (28,488) |  |  | (16,805) |  |
| Non-GAAP net income |  | $ | 581,387 |  |  | $ | 391,923 |  |  | $ | 1,535,082 |  |  | $ | 1,003,111 |  |
| GAAP diluted net income per share |  | $ | 1.72 |  |  | $ | 1.13 |  |  | $ | 4.66 |  |  | $ | 2.92 |  |
| Non-GAAP adjustments to net income |  | 0.11 |  |  | 0.12 |  |  | 0.19 |  |  | 0.25 |  |
| Non-GAAP diluted net income per share |  | $ | 1.83 |  |  | $ | 1.25 |  |  | $ | 4.85 |  |  | $ | 3.17 |  |
| Weighted-average shares used in computing diluted net income per share |  | 317,631 |  |  | 314,401 |  |  | 316,564 |  |  | 316,745 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 3,717 |  |  | $ | 2,992 |  |  | $ | 9,516 |  |  | $ | 6,613 |  |
| Research and development |  | 47,965 |  |  | 37,698 |  |  | 125,671 |  |  | 93,723 |  |
| Sales and marketing |  | 20,490 |  |  | 16,103 |  |  | 51,461 |  |  | 42,039 |  |
| General and administrative |  | 13,218 |  |  | 8,684 |  |  | 28,750 |  |  | 23,605 |  |
| Total |  | $ | 85,390 |  |  | $ | 65,477 |  |  | $ | 215,398 |  |  | $ | 165,980 |  |

[0001596532-23-000272:8k_2_02:46]
_____________________________________________

[0001596532-23-000272:8k_2_02:47]
(1) Represent costs associated with business combinations, which primarily include retention bonuses, and professional and consulting fees.

[0001596532-23-000272:8k_2_02:48]
ARISTA NETWORKS, INC.

[0001596532-23-000272:8k_2_02:49]
Condensed Consolidated Balance Sheets

[0001596532-23-000272:8k_2_02:50]
(Unaudited, in thousands)

[0001596532-23-000272:8k_2_02:51]
|  |  | September 30, 2023 |  | December 31, 2022 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,748,818 |  |  | $ | 671,707 |  |
| Marketable securities |  | 2,706,785 |  |  | 2,352,022 |  |
| Accounts receivable |  | 833,374 |  |  | 923,096 |  |
| Inventories |  | 1,893,538 |  |  | 1,289,706 |  |
| Prepaid expenses and other current assets |  | 472,483 |  |  | 314,217 |  |
| Total current assets |  | 7,654,998 |  |  | 5,550,748 |  |
| Property and equipment, net |  | 102,592 |  |  | 95,009 |  |
| Acquisition-related intangible assets, net |  | 95,458 |  |  | 122,205 |  |
| Goodwill |  | 268,531 |  |  | 265,924 |  |
| Investments |  | 62,288 |  |  | 39,468 |  |
| Operating lease right-of-use assets |  | 58,888 |  |  | 53,390 |  |
| Deferred tax assets |  | 793,015 |  |  | 574,912 |  |
| Other assets |  | 33,265 |  |  | 73,754 |  |
| TOTAL ASSETS |  | $ | 9,069,035 |  |  | $ | 6,775,410 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 268,972 |  |  | $ | 232,572 |  |
| Accrued liabilities |  | 410,071 |  |  | 292,487 |  |
| Deferred revenue |  | 698,675 |  |  | 637,432 |  |
| Other current liabilities |  | 469,007 |  |  | 131,040 |  |
| Total current liabilities |  | 1,846,725 |  |  | 1,293,531 |  |
| Income taxes payable |  | 104,660 |  |  | 89,839 |  |
| Operating lease liabilities, non-current |  | 48,044 |  |  | 43,964 |  |
| Deferred revenue, non-current |  | 496,076 |  |  | 403,814 |  |
| Other long-term liabilities |  | 67,975 |  |  | 58,442 |  |
| TOTAL LIABILITIES |  | 2,563,480 |  |  | 1,889,590 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 31 |  |  | 31 |  |
| Additional paid-in capital |  | 2,028,301 |  |  | 1,780,714 |  |
| Retained earnings |  | 4,500,389 |  |  | 3,138,983 |  |
| Accumulated other comprehensive income (loss) |  | (23,166) |  |  | (33,908) |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 6,505,555 |  |  | 4,885,820 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 9,069,035 |  |  | $ | 6,775,410 |  |

[0001596532-23-000272:8k_2_02:52]
6

[0001596532-23-000272:8k_2_02:53]
ARISTA NETWORKS, INC.

[0001596532-23-000272:8k_2_02:54]
Condensed Consolidated Statements of Cash Flows

[0001596532-23-000272:8k_2_02:55]
(Unaudited, in thousands)

[0001596532-23-000272:8k_2_02:56]
|  |  | Nine Months Ended September 30, |
|  |  | 2023 |  | 2022 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 1,473,685 |  |  | $ | 925,357 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 56,233 |  |  | 45,169 |  |
| Stock-based compensation |  | 215,398 |  |  | 165,980 |  |
| Noncash lease expense |  | 13,615 |  |  | 13,837 |  |
| Deferred income taxes |  | (217,489) |  |  | (148,355) |  |
| Gain on strategic investments |  | (18,699) |  |  | (24,121) |  |
| Amortization (accretion) of investment premiums (discounts) |  | (22,389) |  |  | 14,167 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | 89,722 |  |  | (129,947) |  |
| Inventories |  | (603,832) |  |  | (449,792) |  |
| Other assets |  | (118,622) |  |  | (86,895) |  |
| Accounts payable |  | 33,740 |  |  | 73,480 |  |
| Accrued liabilities |  | 117,481 |  |  | 14,690 |  |
| Deferred revenue |  | 153,505 |  |  | (1,245) |  |
| Income taxes, net |  | 346,170 |  |  | 41,074 |  |
| Other liabilities |  | (10,968) |  |  | (1,059) |  |
| Net cash provided by operating activities |  | 1,507,550 |  |  | 452,340 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 1,564,950 |  |  | 1,277,821 |  |
| Proceeds from sale of marketable securities |  | 49,584 |  |  | 186,782 |  |
| Purchases of marketable securities |  | (1,934,156) |  |  | (973,489) |  |
| Purchases of property and equipment |  | (28,424) |  |  | (34,184) |  |
| Cash paid for business combinations, net of cash acquired |  | 1,799 |  |  | (145,087) |  |
| Investments in notes and privately-held companies |  | (4,250) |  |  | (12,691) |  |
| Net cash provided by (used in) investing activities |  | (350,497) |  |  | 299,152 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 53,797 |  |  | 43,073 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (23,939) |  |  | (25,542) |  |
| Repurchases of common stock |  | (112,279) |  |  | (667,470) |  |
| Net cash used in financing activities |  | (82,421) |  |  | (649,939) |  |
| Effect of exchange rate changes |  | (934) |  |  | (6,090) |  |
| NET INCREASE IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 1,073,698 |  |  | 95,463 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 675,978 |  |  | 625,050 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 1,749,676 |  |  | $ | 720,513 |  |

[0001596532-23-000272:8k_2_02:57]
Investor Contacts:

[0001596532-23-000272:8k_2_02:58]
Arista Networks, Inc.

[0001596532-23-000272:8k_2_02:59]
Liz Stine, 408-547-5885

[0001596532-23-000272:8k_2_02:60]
Investor Relations

[0001596532-23-000272:8k_2_02:61]
liz@arista.com
