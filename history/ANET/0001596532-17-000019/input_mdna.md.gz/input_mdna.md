# ANET MD&A — 0001596532-17-000019


## mdna

[0001596532-17-000019:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001596532-17-000019:mdna:2]
Overview

[0001596532-17-000019:mdna:3]
We are a leading supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation data centers for enterprise support. Our cloud networking solutions consist of our Extensible Operating System, or EOS, a set of network applications and our Ethernet switching and routing platforms. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. At the core of our cloud networking platform is EOS, which was purpose-built to be fully programmable and highly modular. The programmability of EOS has allowed us to create a set of software applications that address the requirements of cloud networking, including workflow automation, network visibility and analytics, and has also allowed us to rapidly integrate with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.

[0001596532-17-000019:mdna:4]
As of December 31, 2016, we have shipped more than 10 million cloud networking ports worldwide.  We have experienced rapid revenue growth over the last several years, increasing our revenue at a compound annual growth rate of 51.9% from 2011 to 2016. As we have grown the functionality of our EOS software, expanded the range of our product portfolio and increased the size of our sales force, our revenue has continued to grow rapidly. Our revenue for the year ended December 31, 2016 was $1.1 billion an increase of 34.8% compared to 2015. We have been profitable and cash flow positive for each year since 2010.

[0001596532-17-000019:mdna:5]
We believe that our cloud networking platform addresses the large and growing cloud networking segment of data center switching, which remains in the early stage of adoption. We expect to continue growing our organization to meet the needs of new and existing customers as they increasingly realize the performance and cost benefits of our cloud networking solutions and as they expand their cloud networks. We intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features and build upon our technology leadership. We believe one of our greatest strengths lies in our rapid development of new features and applications. We intend to continue expanding our sales and marketing teams and programs and carrying out associated marketing activities in key geographies. In order to support our strong growth, we have and may continue to accelerate our investment in infrastructure, such as enterprise resource planning software and other technologies to improve the efficiency of our operations. For a description of factors that may impact our future performance, see the disclosure in the section titled "Factors Affecting Our Performance" below.

[0001596532-17-000019:mdna:6]
Our Business Model

[0001596532-17-000019:mdna:7]
We derive revenue from sales of products and services. We generate revenue primarily from sales of our switching products which incorporate our EOS software. We generate the majority of our services revenue from post contract support, or PCS, which end customers typically purchase in conjunction with our products.

[0001596532-17-000019:mdna:8]
Since shipping our first products in 2008, our cumulative end-customer base has grown rapidly. Between December 31, 2011 and December 31, 2016, our cumulative end-customer base grew from approximately 1,100 to over 4,200. Our end customers span a range of industries and include large Internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others.

[0001596532-17-000019:mdna:9]
To continue to grow our revenue, it is important that we both obtain new customers and sell additional products to existing customers. Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic to the underlying merchant silicon architecture. Today, we combine our EOS software with merchant silicon into a family of switching and routing products. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We currently procure certain merchant silicon components from multiple vendors, and we continue to expand our relationships with these and other vendors. We work closely with third party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.  We have expanded our contract manufacturing capabilities to include Sanmina as an additional contract manufacturer.

[0001596532-17-000019:mdna:10]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators, original equipment manufacturer, or "OEM" partners and in conjunction with various technology partners. To facilitate channel coordination and increase productivity, we have created a partner program, the Arista Partner Program, to engage partners who provide value-added services and extend our reach into the marketplace. Authorized training partners provide technical training to our channel partners. Our partners commonly receive an order from an end customer prior to placing an order with us, and we confirm the identification of the end customer prior to accepting such orders. Our partners generally do not stock inventory received from us. Our sales organization is supported by systems engineers with deep technical expertise and responsibility for pre-sales technical

[0001596532-17-000019:mdna:11]
support and engineering for our end customers. Each sales team is responsible for a geographic territory, has responsibility for a number of major direct end-customer accounts or has assigned accounts in a specific vertical market.

[0001596532-17-000019:mdna:12]
Factors Affecting Our Performance

[0001596532-17-000019:mdna:13]
We believe that our future success will depend on many factors, including our ability to expand sales to our existing customers as well as to add new end customers. While these areas present significant opportunity, they also present risks that we must manage to ensure successful results. See the section titled “Risk Factors.” Additionally, we face intense competition especially from larger, well-established companies, and we must continue to expand the capabilities of our cloud networking platform to succeed in our market. We are also currently engaged in several lawsuits with Cisco, our largest competitor, whereby they claim that we have infringed their intellectual property rights.  We intend to vigorously defend against these Cisco lawsuits as summarized in the Legal Proceedings section below. However, we cannot be certain that any claims by Cisco would be resolved in our favor.  If we are unable to address these challenges, our business could be adversely affected.

[0001596532-17-000019:mdna:14]
Increasing Adoption of Cloud Networks. Networks are subject to increasing performance requirements due to the growing number of connected devices as well as new enterprise and consumer applications. Computing architectures are evolving to meet the need for constant connectivity and access to data and applications. We believe that cloud networks will continue to replace legacy network technologies. Our business and results of operations will be significantly affected by the speed with which organizations implement cloud networks.

[0001596532-17-000019:mdna:15]
Expanding Sales to Existing Customer Base. We expect that a substantial portion of our future sales will be follow-on sales to existing end customers. As noted above, one of our sales strategies is to target specific projects at our current end customers because they are familiar with the operational and economic benefits of our cloud networking solutions, thereby reducing the sales cycle into these customers. We believe this opportunity with current end customers to be significant given their existing and expected infrastructure spend.  We expect our business and results of operations will depend on our ability to sell additional products to our growing base of customers.

[0001596532-17-000019:mdna:16]
Adding New End Customers. We believe that the cloud networking market is still in the early stages of adoption. We intend to target new end customers by continuing to invest in our field sales force and extending our relationships with channel, technology and system-level partners. To date, we have primarily targeted end customers with the largest cloud data centers. A typical initial order involves the education of prospective customers about the technical merits and capabilities and potential cost savings of our products as compared to our competitors’ products. Our results of operations will depend on our ability to continue to add new customers. We believe that customer references have been, and will continue to be, an important factor in winning new business with special emphasis on four key verticals: the cloud titans, financial services, service and internet hosting providers and high tech enterprises.

[0001596532-17-000019:mdna:17]
Selling More Complex and Higher-Performance Configurations. Our results of operations have been, and we believe will continue to be, affected by our ability to sell more complex and higher-performance configurations of our products.  Our ability to sustain our revenue growth will depend, in part, upon our continued sales of these more robust configurations, and quarterly results of operations can be significantly impacted by the mix of products and product configurations sold during the period.

[0001596532-17-000019:mdna:18]
Leveraging Channel Partners. We expect to continue to derive a growing portion of our sales through our channel partners as they develop new end customers and expand sales to our existing end customers. We plan to continue to invest in our network of channel partners to enable them to reach new end customers more effectively, increase sales to existing customers and provide services and support effectively. We believe that increasing channel leverage will extend and improve our engagement with a broad set of customers.

[0001596532-17-000019:mdna:19]
Investing in Research and Development for Growth. We believe that the market for cloud networking is still in the early stages of adoption and we intend to continue investing for long-term growth. We expect to continue to invest heavily in software development in order to expand the capabilities of our cloud networking platform, introduce new products such as our 7280R platform, 7500R series and 7160 series, new releases and upgrades to our EOS software and new applications building upon our technology leadership. We believe one of our greatest strengths lies in the speed of our product development efforts. By investing in research and development, we believe we will be well positioned to continue our rapid growth and take advantage of our large market opportunity. We expect that our results of operations will be impacted by the timing and size of these product development investments.

[0001596532-17-000019:mdna:20]
Customer Concentration and Timing of Large Orders. Historically, large purchases by a relatively limited number of end customers have accounted for significant portion of our revenue. During the years ended December 31, 2016, 2015, and 2014, our largest end customer accounted for 16.4%, 12.0%, and 14.9% of our revenue, respectively. We have also experienced and continue to experience customer concentration on a quarterly basis. In addition, we have experienced increases in the size of our orders, including orders from existing customers, which could result in future increased customer concentration, depending on the timing of the fulfillment of those orders. We have also experienced unpredictability in the timing of large orders, especially with respect to our large end customers, due to the complexity of orders, the time it takes end customers to evaluate, test, qualify and accept our products and factors specific to our end customers. Due to these factors, we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. In addition, we have provided, and may in the future provide, pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur. Our gross margins may also fluctuate as a result of the timing of such sales to large end customers.

[0001596532-17-000019:mdna:21]
Components of Operating Results

[0001596532-17-000019:mdna:22]
Revenue

[0001596532-17-000019:mdna:23]
We generate revenue primarily from sales of our products, which incorporate our EOS software. We also derive a portion of our revenue from sales of post contract support, or PCS, and to a lesser extent professional services.  We generate PCS revenue from sales of technical support services contracts that are typically purchased in conjunction with our products and subsequent renewals of those contracts.  We expect our revenue may vary from period to period based on, among other things, the timing and size of orders, the delivery and acceptance of products, and the impact of significant transactions with unique terms and conditions that may require deferral of revenue.

[0001596532-17-000019:mdna:24]
Cost of Revenue

[0001596532-17-000019:mdna:25]
Cost of revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs in our manufacturing operations department, and other manufacturing-related costs associated with manufacturing our products and managing our inventory. We expect our cost of product revenue to increase as our product revenue increases. Cost of providing PCS and other services consists primarily of personnel costs for our global customer support organization.

[0001596532-17-000019:mdna:26]
Gross Margin

[0001596532-17-000019:mdna:27]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including sales to large end customers who generally receive lower pricing, the average sales price of our offerings, manufacturing-related costs, including costs associated with the introduction of additional contract manufacturing capacity, merchant silicon costs, supply chain sourcing and the mix of products sold. We expect our gross margins to fluctuate over time, depending on the factors described above and others.

[0001596532-17-000019:mdna:28]
Operating Expenses

[0001596532-17-000019:mdna:29]
Our operating expenses consist of research and development, sales and marketing and general and administrative expenses. The largest component of our operating expenses is personnel costs. Personnel costs consist of wages, benefits, bonuses and, with respect to sales and marketing expenses, sales commissions. Personnel costs also include stock-based compensation and travel expenses. We expect operating expenses to continue to increase in absolute dollars in the near term as we continue to invest in the growth of our business.

[0001596532-17-000019:mdna:30]
Research and Development Expenses

[0001596532-17-000019:mdna:31]
Research and development expenses consist primarily of personnel costs, with the remainder being prototype expenses, third-party engineering and contractor support costs, and an allocated portion of facility and IT costs and depreciation. Our research and development efforts are focused on maintaining and developing additional functionality for our existing products and on new product development, including new releases and upgrades to our EOS software and applications. We expense research and development costs as incurred. We expect our research and development expenses to increase in absolute dollars as we continue to invest heavily in software development in order to expand the capabilities of our cloud networking platform, introduce new products and features and build upon our technology leadership.

[0001596532-17-000019:mdna:32]
Sales and Marketing Expenses

[0001596532-17-000019:mdna:33]
Sales and marketing expenses consist primarily of personnel costs and also include costs related to marketing and promotional activities, with the remainder being an allocated portion of facility and IT costs and depreciation. We expect our sales and marketing expenses to increase in absolute dollars as we expand our sales and marketing efforts worldwide and expand our relationships with current and future channel partners and end customers.

[0001596532-17-000019:mdna:34]
General and Administrative Expenses

[0001596532-17-000019:mdna:35]
General and administrative expenses consist primarily of personnel costs, legal and professional fees, and an allocated portion of facility and IT costs and depreciation. General and administrative personnel costs include those for our executive, finance, human resources and legal functions. Our professional services costs are primarily due to external legal, accounting, and tax services.

[0001596532-17-000019:mdna:36]
Other Income (Expense), Net

[0001596532-17-000019:mdna:37]
Interest Expense

[0001596532-17-000019:mdna:38]
Interest expense consists primarily of interest expense from our lease financing obligation.  In fiscal 2014, interest expense also included interest expense on our subordinated convertible promissory notes, including our related party subordinated convertible promissory notes which were converted during fiscal 2014.

[0001596532-17-000019:mdna:39]
Other Income (Expense)

[0001596532-17-000019:mdna:40]
Other income (expense) consists primarily of interest income on marketable securities and foreign currency transaction gains and losses.  In addition, during fiscal 2014, other income (expense) consisted of gains on investments, and write-offs of debt discount on

[0001596532-17-000019:mdna:41]
notes payable which were repaid and converted during fiscal 2014.  We expect our foreign currency gains and losses to continue to fluctuate in the future due to changes in foreign currency exchange rates.

[0001596532-17-000019:mdna:42]
Provision for Income Taxes

[0001596532-17-000019:mdna:43]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. Earnings from our non-U.S. activities are subject to local country income tax and may be subject to U.S. income tax. Generally, our U.S. tax obligations are reduced by a credit for foreign income taxes paid on these earnings which avoids double taxation. Our tax expense to date consists of federal, state and foreign current and deferred income taxes.

[0001596532-17-000019:mdna:44]
50

[0001596532-17-000019:mdna:45]
Results of Operations

[0001596532-17-000019:mdna:46]
The following table summarizes historical results of operations for the periods presented and as a percentage of revenue for those periods.  We have derived the data for the years ended December 31, 2016, 2015 and 2014 from our consolidated financial statements included elsewhere in thus Form 10-K (in thousands, except for percentage of revenue).

[0001596532-17-000019:mdna:47]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Consolidated Statements of Operations Data: |  |  |  |  |  |
| Revenue: |  |  |  |  |  |
| Product | $ | 991,337 |  |  | $ | 744,877 |  |  | $ | 531,543 |  |
| Service | 137,830 |  |  | 92,714 |  |  | 52,563 |  |
| Total revenue | 1,129,167 |  |  | 837,591 |  |  | 584,106 |  |
| Cost of revenue (1): |  |  |  |  |  |
| Product | 369,768 |  |  | 263,585 |  |  | 174,004 |  |
| Service | 36,283 |  |  | 30,446 |  |  | 18,011 |  |
| Total cost of revenue | 406,051 |  |  | 294,031 |  |  | 192,015 |  |
| Gross profit | 723,116 |  |  | 543,560 |  |  | 392,091 |  |
| Operating expenses (1): |  |  |  |  |  |
| Research and development | 273,581 |  |  | 209,448 |  |  | 148,909 |  |
| Sales and marketing | 130,887 |  |  | 109,084 |  |  | 85,338 |  |
| General and administrative | 75,239 |  |  | 75,720 |  |  | 32,331 |  |
| Total operating expenses | 479,707 |  |  | 394,252 |  |  | 266,578 |  |
| Income from operations | 243,409 |  |  | 149,308 |  |  | 125,513 |  |
| Interest expense | (3,136 | ) |  | (3,152 | ) |  | (6,280 | ) |
| Other income (expense), net | 1,952 |  |  | (147 | ) |  | 2,275 |  |
| Total other income (expense), net | (1,184 | ) |  | (3,299 | ) |  | (4,005 | ) |
| Income before provision for income taxes | 242,225 |  |  | 146,009 |  |  | 121,508 |  |
| Provision for income taxes | 58,036 |  |  | 24,907 |  |  | 34,658 |  |
| Net income | $ | 184,189 |  |  | $ | 121,102 |  |  | $ | 86,850 |  |

[0001596532-17-000019:mdna:48]
(1) Includes stock-based compensation expense as follows:

[0001596532-17-000019:mdna:49]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Stock-Based Compensation Expense: |  |  |  |  |  |
| Cost of revenue | $ | 3,620 |  |  | $ | 3,048 |  |  | $ | 1,535 |  |
| Research and development | 31,892 |  |  | 25,515 |  |  | 14,986 |  |
| Sales and marketing | 15,666 |  |  | 11,454 |  |  | 7,643 |  |
| General and administrative | 7,854 |  |  | 5,286 |  |  | 3,455 |  |
| Total stock-based compensation | $ | 59,032 |  |  | $ | 45,303 |  |  | $ | 27,619 |  |

[0001596532-17-000019:mdna:50]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
|  | (as a percentage of revenue) |
| Revenue: |  |  |  |  |  |
| Product | 87.8 | % |  | 88.9 | % |  | 91.0 | % |
| Service | 12.2 |  |  | 11.1 |  |  | 9.0 |  |
| Total revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of revenue: |  |  |  |  |  |
| Product | 32.8 |  |  | 31.5 |  |  | 29.8 |  |
| Service | 3.2 |  |  | 3.6 |  |  | 3.1 |  |
| Total cost of revenue | 36.0 |  |  | 35.1 |  |  | 32.9 |  |
| Gross margin | 64.0 |  |  | 64.9 |  |  | 67.1 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 24.2 |  |  | 25.0 |  |  | 25.5 |  |
| Sales and marketing | 11.6 |  |  | 13.0 |  |  | 14.6 |  |
| General and administrative | 6.7 |  |  | 9.0 |  |  | 5.5 |  |
| Total operating expenses | 42.5 |  |  | 47.0 |  |  | 45.6 |  |
| Income from operations | 21.6 |  |  | 17.9 |  |  | 21.5 |  |
| Interest expense | (0.3 | ) |  | (0.4 | ) |  | (1.1 | ) |
| Other income (expense), net | 0.2 |  |  | — |  |  | 0.4 |  |
| Total other income (expense), net | (0.1 | ) |  | (0.4 | ) |  | (0.7 | ) |
| Income before provision for income taxes | 21.5 |  |  | 17.5 |  |  | 20.8 |  |
| Provision for income taxes | 5.1 |  |  | 3.0 |  |  | 5.9 |  |
| Net income | 16.3 | % |  | 14.5 | % |  | 14.9 | % |

[0001596532-17-000019:mdna:51]
52

[0001596532-17-000019:mdna:52]
Year Ended December 31, 2016 Compared to Year Ended December 31, 2015

[0001596532-17-000019:mdna:53]
Revenue, Cost of Revenue and Gross Profit (in thousands, except percentages)

[0001596532-17-000019:mdna:54]
|  | Year Ended December 31, |  |  |
|  | 2016 |  | 2015 |  | Change in |
|  | $ |  | % ofrevenue |  | $ |  | % ofrevenue |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 991,337 |  |  | 87.8 | % |  | $ | 744,877 |  |  | 88.9 | % |  | $ | 246,460 |  |  | 33.1 | % |
| Service | 137,830 |  |  | 12.2 |  |  | 92,714 |  |  | 11.1 |  |  | 45,116 |  |  | 48.7 |  |
| Total revenue | 1,129,167 |  |  | 100.0 |  |  | 837,591 |  |  | 100.0 |  |  | 291,576 |  |  | 34.8 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |
| Product | 369,768 |  |  | 32.8 |  |  | 263,585 |  |  | 31.5 |  |  | 106,183 |  |  | 40.3 |  |
| Service | 36,283 |  |  | 3.2 |  |  | 30,446 |  |  | 3.6 |  |  | 5,837 |  |  | 19.2 |  |
| Total cost of revenue | 406,051 |  |  | 36.0 |  |  | 294,031 |  |  | 35.1 |  |  | 112,020 |  |  | 38.1 |  |
| Gross profit | $ | 723,116 |  |  | 64.0 | % |  | $ | 543,560 |  |  | 64.9 | % |  | $ | 179,556 |  |  | 33.0 | % |
| Gross margin | 64.0 | % |  |  |  | 64.9 | % |  |  |  |  |  |  |

[0001596532-17-000019:mdna:55]
Revenue by Geography (in thousands, except percentages)

[0001596532-17-000019:mdna:56]
|  | Year Ended December 31, |
|  | 2016 |  | % of Total |  | 2015 |  | % of Total |
| Americas | $ | 874,740 |  |  | 77.5 | % |  | $ | 646,919 |  |  | 77.3 | % |
| Europe, Middle East and Africa | 168,789 |  |  | 14.9 |  |  | 128,400 |  |  | 15.3 |  |
| Asia-Pacific | 85,638 |  |  | 7.6 |  |  | 62,272 |  |  | 7.4 |  |
| Total revenue | $ | 1,129,167 |  |  | 100.0 | % |  | $ | 837,591 |  |  | 100.0 | % |

[0001596532-17-000019:mdna:57]
Revenue

[0001596532-17-000019:mdna:58]
Product revenue increased $246.5 million or 33.1% in the year ended December 31, 2016 compared to 2015. The increase during the period was primarily driven by increased shipments to our existing customers as they continue to grow and expand their businesses, increasing their demand for our products and related accessories. The introduction of new products contributed to our revenue growth, both with existing and new customers.  As of December 31, 2016, we have shipped more than 10 million cumulative cloud networking ports worldwide and our overall end-customer base has exceeded 4,200.  Service revenue increased 48.7% in the year ended December 31, 2016 as a result of continued growth in initial and renewal support contracts as our customer installed base continued to expand.  We also continued to experience pressure in product and service pricing due to competitive market conditions.  However, this pricing pressure was more than offset by the increased demand drivers outlined above.

[0001596532-17-000019:mdna:59]
Cost of Revenue and Gross Margin

[0001596532-17-000019:mdna:60]
Cost of revenue increased $112.0 million or 38.1% for the year ended December 31, 2016 compared to the same period in 2015. The increase in cost of revenue was primarily due to an increase in product shipment volumes.  In addition, we incurred increased costs as we added capacity to our manufacturing and operations infrastructure.  Gross margin decreased from 64.9% to 64.0% for the year ended December 31, 2016 compared to the same period in 2015.  The decrease during the period was primarily the result of changes in customer mix as we expanded our business including increased contributions from larger customers who typically receive higher discount levels, and increased costs associated with the expansion of manufacturing and operations capacity. These unfavorable changes were partially offset by improved service margins as we scale our services business.  We expect our gross margins in the first quarter of 2017 will reflect some further increases in product costs as we continue to invest in expanded contract manufacturing and supply chain operations.

[0001596532-17-000019:mdna:61]
Operating Expenses (in thousands, except percentages)

[0001596532-17-000019:mdna:62]
|  | Year Ended December 31, |  |  |
|  | 2016 |  | 2015 |  | Change in |
|  | $ |  | % ofrevenue |  | $ |  | % ofrevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 273,581 |  |  | 24.2 | % |  | $ | 209,448 |  |  | 25.0 | % |  | $ | 64,133 |  |  | 30.6 | % |
| Sales and marketing | 130,887 |  |  | 11.6 |  |  | 109,084 |  |  | 13.0 |  |  | 21,803 |  |  | 20.0 |  |
| General and administrative | 75,239 |  |  | 6.7 |  |  | 75,720 |  |  | 9.0 |  |  | (481 | ) |  | (0.6 | ) |
| Total operating expenses | $ | 479,707 |  |  | 42.5 | % |  | $ | 394,252 |  |  | 47.0 | % |  | $ | 85,455 |  |  | 21.7 | % |

[0001596532-17-000019:mdna:63]
Research and development.

[0001596532-17-000019:mdna:64]
Research and development expenses increased $64.1 million, or 30.6%, for the year ended December 31, 2016 compared to the same period in 2015. The increase was primarily due to an increase in personnel costs of $31.2 million resulting from an increase in compensation costs, including stock-based compensation and corporate bonus expense, primarily driven by headcount growth. Prototype spend and third-party engineering and consulting costs increased by $27.3 million, related to additional outsourced development projects, increased internal development activity related to new products and increased costs associated with litigation-related changes in product design. Facilities and IT infrastructure costs increased $3.1 million primarily due to continued expansion and support of our research and development activities.

[0001596532-17-000019:mdna:65]
Sales and marketing.

[0001596532-17-000019:mdna:66]
Sales and marketing expenses increased $21.8 million, or 20.0% for the year ended December 31, 2016 compared to the same period in 2015. The increase was primarily due to an increase in personnel costs of $21.0 million, reflecting increased compensation costs, including sales incentive compensation and corporate bonus expense, primarily driven by headcount growth and higher sales volumes.  In addition, sales and customer engineering consulting expenses mostly related to international expansion increased by $1.3 million, and marketing promotion, trade shows and events increased by $1.1 million, as compared to the same period in 2015.  The increase was partially offset by a decrease in product field demonstration costs of $1.7 million primarily related to significant costs incurred in the previous year due to several next generation product transitions.

[0001596532-17-000019:mdna:67]
General and administrative.

[0001596532-17-000019:mdna:68]
General and administrative expenses decreased $(0.5) million, or (0.6)%, for the year ended December 31, 2016 compared to the same period in 2015. The decrease was primarily due to a reduction in litigation expenses of $5.6 million during the year ended December 31, 2016 as compared to the same period in 2015.  This decrease was primarily related to the timing of litigation activities associated with the Cisco and OptumSoft legal matters outlined in Note 5 to the Consolidated Financial Statements.  This decrease was largely offset by an increase in personnel costs of $4.9 million in the year ended December 31, 2016 as compared to the same period in 2015.  This reflects increased compensation costs, including increased stock-based compensation and corporate bonus expense, primarily driven by headcount growth.

[0001596532-17-000019:mdna:69]
Other Income (Expense), Net (in thousands, except percentages)

[0001596532-17-000019:mdna:70]
|  | Year Ended December 31, |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (3,136 | ) |  | $ | (3,152 | ) |  | $ | 16 |  |  | (0.5 | )% |
| Other income (expense), net | 1,952 |  |  | (147 | ) |  | 2,099 |  |  | (1,427.9 | ) |
| Total other income (expense), net | $ | (1,184 | ) |  | $ | (3,299 | ) |  | $ | 2,115 |  |  | (64.1 | )% |

[0001596532-17-000019:mdna:71]
Other income (expense), net improved during the year ended December 31, 2016 compared to 2015 primarily due to a net increase in interest income as we expanded our marketable securities portfolio.

[0001596532-17-000019:mdna:72]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-17-000019:mdna:73]
|  | Year Ended December 31, |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Provision for income taxes | $ | 58,036 |  |  | $ | 24,907 |  |  | $ | 33,129 |  |  | 133.0 | % |
| Effective tax rate | 24.0 | % |  | 17.1 | % |  |  |  |  |

[0001596532-17-000019:mdna:74]
Provision for income taxes was approximately $58.0 million and $24.9 million for the year ended December 31, 2016 and 2015, respectively. The change in our provision was primarily due to an increase in profit before income taxes. The increase in the provision was also a result of additional state and foreign taxes, non-deductible permanent differences, offset by a shift in the geographic foreign

[0001596532-17-000019:mdna:75]
earnings mix taxed at a lower rate than the U.S. tax rate.  For further information regarding income taxes and the impact on our results of operations and financial position, see "Notes to Consolidated Financial Statements - Note 8, Income Taxes."

[0001596532-17-000019:mdna:76]
Year Ended December 31, 2015 Compared to Year Ended December 31, 2014

[0001596532-17-000019:mdna:77]
Revenue, Cost of Revenue and Gross Profit (in thousands, except percentages)

[0001596532-17-000019:mdna:78]
|  | Year Ended December 31, |  |  |
|  | 2015 |  | 2014 |  | Change in |
|  | $ |  | % ofrevenue |  | $ |  | % ofrevenue |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 744,877 |  |  | 88.9 | % |  | $ | 531,543 |  |  | 91.0 | % |  | $ | 213,334 |  |  | 40.1 | % |
| Service | 92,714 |  |  | 11.1 |  |  | 52,563 |  |  | 9.0 |  |  | 40,151 |  |  | 76.4 |  |
| Total revenue | 837,591 |  |  | 100.0 |  |  | 584,106 |  |  | 100.0 |  |  | 253,485 |  |  | 43.4 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |
| Product | 263,585 |  |  | 31.5 |  |  | 174,004 |  |  | 29.8 |  |  | 89,581 |  |  | 51.5 |  |
| Service | 30,446 |  |  | 3.6 |  |  | 18,011 |  |  | 3.1 |  |  | 12,435 |  |  | 69.0 |  |
| Total cost of revenue | 294,031 |  |  | 35.1 |  |  | 192,015 |  |  | 32.9 |  |  | 102,016 |  |  | 53.1 |  |
| Gross profit | $ | 543,560 |  |  | 64.9 | % |  | $ | 392,091 |  |  | 67.1 | % |  | $ | 151,469 |  |  | 38.6 | % |
| Gross margin | 64.9 | % |  |  |  | 67.1 | % |  |  |  |  |  |  |

[0001596532-17-000019:mdna:79]
Revenue by Geography (in thousands, except percentages)

[0001596532-17-000019:mdna:80]
|  | Year Ended December 31, |
|  | 2015 |  | % of Total |  | 2014 |  | % of Total |
| Americas | $ | 646,919 |  |  | 77.3 | % |  | $ | 465,544 |  |  | 79.7 | % |
| Europe, Middle East and Africa | 128,400 |  |  | 15.3 |  |  | 74,555 |  |  | 12.8 |  |
| Asia-Pacific | 62,272 |  |  | 7.4 |  |  | 44,007 |  |  | 7.5 |  |
| Total revenue | $ | 837,591 |  |  | 100.0 | % |  | $ | 584,106 |  |  | 100.0 | % |

[0001596532-17-000019:mdna:81]
Revenue

[0001596532-17-000019:mdna:82]
Product revenue increased $213.3 million or 40.1% for the year ended December 31, 2015 compared to 2014. We increased shipments to our existing customers during the year as they continued to grow their businesses and increase their demand for our products and related accessories. In addition, we continued to add new customers as we expanded our market presence and geographic footprint. Service revenue increased 76.4% in the year ended December 31, 2015 with growth in initial and renewal support contracts as our customer installed base continued to expand.  We also continued to experience fluctuations in product and service pricing due to competitive market pressures.  However, these were more than offset by the increased demand drivers outlined above.

[0001596532-17-000019:mdna:83]
Cost of Revenue and Gross Margin

[0001596532-17-000019:mdna:84]
Gross margin decreased from 67.1% to 64.9% for the year ended December 31, 2015 compared to the same period in 2014. This decrease in 2015 was primarily due to increased inventory-related obsolescence charges associated with upcoming product transitions and higher warranty costs, in addition to a greater mix of revenue from larger customers who typically receive higher discounts.

[0001596532-17-000019:mdna:85]
Operating Expenses (in thousands, except percentages)

[0001596532-17-000019:mdna:86]
|  | Year Ended December 31, |  |  |
|  | 2015 |  | 2014 |  | Change in |
|  | $ |  | % ofrevenue |  | $ |  | % ofrevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 209,448 |  |  | 25.0 | % |  | $ | 148,909 |  |  | 25.5 | % |  | $ | 60,539 |  |  | 40.7 | % |
| Sales and marketing | 109,084 |  |  | 13.0 |  |  | 85,338 |  |  | 14.6 |  |  | 23,746 |  |  | 27.8 |  |
| General and administrative | 75,720 |  |  | 9.0 |  |  | 32,331 |  |  | 5.5 |  |  | 43,389 |  |  | 134.2 |  |
| Total operating expenses | $ | 394,252 |  |  | 47.0 | % |  | $ | 266,578 |  |  | 45.6 | % |  | $ | 127,674 |  |  | 47.9 | % |

[0001596532-17-000019:mdna:87]
Research and development

[0001596532-17-000019:mdna:88]
Research and development expenses increased $60.5 million, or 40.7%, for the year ended December 31, 2015 compared to the same period in 2014. The increase was primarily due to an increase in personnel costs of $33.3 million, resulting from headcount growth, which drove an increase in compensation, including stock based compensation, as well as additional bonus expense under our corporate bonus plan.   Prototype spend and third-party engineering and consulting costs increased by $14.2 million, and facilities and IT infrastructure costs increased $8.6 million due to new product introductions and the continued expansion and support of our research and development activities.

[0001596532-17-000019:mdna:89]
Sales and marketing

[0001596532-17-000019:mdna:90]
Sales and marketing expenses increased $23.7 million, or 27.8%, for the year ended December 31, 2015 compared to the same period in 2014. The increase was primarily due to an increase in personnel costs of $17.0 million, resulting from increased compensation, including sales commissions, which was driven by headcount growth and higher sales volumes. The increase also related to additional product field demonstration costs of $6.0 million.

[0001596532-17-000019:mdna:91]
General and administrative

[0001596532-17-000019:mdna:92]
General and administrative expenses increased $43.4 million, or 134.2%, for the year ended December 31, 2015 compared to the same period in 2014. The increase was due to an increase in legal fees of $39.8 million primarily related to the Cisco and OptumSoft legal matters outlined in Note 5 to the Consolidated Financial Statements.  In addition, personnel costs increased by $4.1 million primarily reflecting additional corporate bonus expense and increased stock-based compensation charges during 2015.

[0001596532-17-000019:mdna:93]
Other Income (Expense), Net (in thousands, except percentages)

[0001596532-17-000019:mdna:94]
|  | Year Ended December 31, |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (3,152 | ) |  | $ | (6,280 | ) |  | $ | 3,128 |  |  | (49.8 | )% |
| Other income (expense), net | (147 | ) |  | 2,275 |  |  | (2,422 | ) |  | (106.5 | ) |
| Total other income (expense), net | $ | (3,299 | ) |  | $ | (4,005 | ) |  | $ | 706 |  |  | (17.6 | )% |

[0001596532-17-000019:mdna:95]
Interest expense. The reduction in interest expense during the year ended December 31, 2015 compared to the same period in 2014 is primarily related to repayment and conversion of our notes payable upon closing of our initial public offering during the second quarter of 2014.

[0001596532-17-000019:mdna:96]
Other income (expense), net. The unfavorable change in other income (expense), net during the year ended December 31, 2015, compared to the same period in 2014 was primarily due to a one-time gain on our notes receivable of $4.0 million in 2014, partially offset by a $0.7 million write-off related to the debt discount on notes payable during the second quarter of 2014, and a reduction in transactional exchange rate losses during 2015.

[0001596532-17-000019:mdna:97]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-17-000019:mdna:98]
|  | Year Ended December 31, |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
| Provision for income taxes | $ | 24,907 |  |  | $ | 34,658 |  |  | $ | (9,751 | ) |  | (28.1 | )% |
| Effective tax rate | 17.1 | % |  | 28.5 | % |  |  |  |  |

[0001596532-17-000019:mdna:99]
Provision for income taxes was approximately $24.9 million and $34.7 million for the year ended December 31, 2015 and 2014, respectively. The decrease in our provision was the result of foreign mix earnings taxed at a lower rate than the US tax rate, release of reserves due to expiration of the statute of limitations in certain domestic jurisdictions, and reinstatement of the federal R&D credit during 2015.  These decreases were partially offset by an increase in the provision due to increased profit before income taxes.

[0001596532-17-000019:mdna:100]
Liquidity and Capital Resources

[0001596532-17-000019:mdna:101]
Our principal sources of liquidity are cash and cash equivalents, marketable securities, and cash generated from operations. As of December 31, 2016, cash and cash equivalents were $567.9 million, of which approximately $111.7 million was held outside the U.S. in our foreign subsidiaries. We have not repatriated nor do we currently have plans to repatriate these funds, but if we were to repatriate cash held outside of the U.S. for domestic cash operations, we would be required to accrue and pay U.S. income taxes to repatriate these funds less any previously paid foreign income taxes. We consider the undistributed earnings of our foreign subsidiaries as of December 31, 2016 to be indefinitely reinvested, and, accordingly, no U.S. income taxes have been provided thereon.

[0001596532-17-000019:mdna:102]
Our cash and cash equivalents and marketable securities are held for working capital purposes.  We plan to continue to invest for long-term growth. We believe that our existing cash and cash equivalents together with cash flow from operations will be sufficient to meet our working capital requirements and our growth strategies for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the

[0001596532-17-000019:mdna:103]
timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities and manufacturing operations, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and costs incurred related to outstanding litigation claims. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-17-000019:mdna:104]
Cash Flows

[0001596532-17-000019:mdna:105]
|  |  | Year Ended December 31, |
|  |  | 2016 |  | 2015 |  | 2014 |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 131,440 |  |  | $ | 200,533 |  |  | $ | 131,875 |  |
| Cash provided by (used in) investing activities |  | (325,979 | ) |  | 184,170 |  |  | (249,362 | ) |
| Cash provided by financing activities |  | 75,600 |  |  | 63,105 |  |  | 243,978 |  |
| Effect of exchange rate changes |  | (464 | ) |  | (513 | ) |  | (124 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | (119,403 | ) |  | $ | 447,295 |  |  | $ | 126,367 |  |

[0001596532-17-000019:mdna:106]
Cash Flows from Operating Activities

[0001596532-17-000019:mdna:107]
Our primary source of cash from operating activities has been from cash collections from our customers. We expect cash inflows from operating activities to be affected by increased sales and timing of collections. Our primary uses of cash from operating activities have been for personnel costs, inventory purchases from our contract manufacturer, investment in research and development, and litigation expenses.

[0001596532-17-000019:mdna:108]
During the year ended December 31, 2016, cash provided by operating activities was $131.4 million, primarily from net income of $184.2 million with non-cash adjustments to net income of $15.7 million, partially offset by a net decrease in cash from changes in our operating assets and liabilities of $68.4 million.  The decrease in cash from changes in operating assets and liabilities was primarily due to an increase in working capital requirements with accounts receivable up $108.9 million, inventories up $144.4 million and inventory deposits (included in prepaid expenses and other assets) up $63.1 million.  These increases reflect substantial growth in the business and the expansion of our manufacturing and supply chain activities at our new contract manufacturer.  These working capital increases were partially offset by an increase in deferred revenue of $176.1 million reflecting ongoing growth in service and support contracts and a significant increase in product deferred revenue related to contract acceptance terms.  Other significant changes in operating assets and liabilities largely related to the overall growth of the business including an increase in accounts payable of $38.7 million, an increase in income taxes payable of $42.7 million, an increase in accrued liabilities of $30.6 million offset by further increases in prepaid expenses and current assets of $54.8 million which was primarily driven by an increase in deferred cost of inventory associated with the increased product revenue deferrals referenced above.

[0001596532-17-000019:mdna:109]
During the year ended December 31, 2015, cash provided by operating activities was $200.5 million, primarily from net income of $121.1 million, net non-cash charges of ($1.2) million, and a net increase in cash from changes in our operating assets and liabilities of $80.6 million.  The net increase in cash from changes in operating assets and liabilities was primarily due to an increase in deferred revenue of $90.3 million, largely related to short and long-term services contracts and product revenue deferrals related to contracts with acceptance terms. In addition, we experienced an increase in cash of $32.0 million from income taxes payable and an increase in our accounts payable and accrued liabilities of $29.4 million due to the timing of payments. These operating liability increases were offset by an increase in our accounts receivable of $47.3 million resulting from an increase in sales during the period. In addition, inventory increased $14.1 million during the period due to higher shipment volume, and prepaid expenses and current assets increased $7.8 million in the period.

[0001596532-17-000019:mdna:110]
During the year ended December 31, 2014, cash provided by operating activities was $131.9 million primarily from net income of $86.9 million, net non-cash charges of $11.0 million, and an increase of $33.2 million due to changes in our operating assets and liabilities. The increase in cash from operating assets and liabilities was primarily due an increase in deferred revenue of $47.6 million resulting from the increase in sales, an increase in accrued liabilities of $18.9 million largely related to our payroll and corporate bonus plan and an increase in accounts payable of $14.0 million due to the timing of our payments, partially offset by a reduction in cash from an increase in accounts receivable of $19.0 million from higher products shipments, an increase in inventories of $13.4 million to meet our customer demand, an increase of $15.3 million in cash paid for income taxes, and supplier rebates receivable resulting from our increased inventory purchases.

[0001596532-17-000019:mdna:111]
Cash Flows from Investing Activities

[0001596532-17-000019:mdna:112]
Our investing activities have consisted primarily of capital expenditures and net investment purchases of available for sale marketable securities. We expect to continue investing in these activities to support the continued growth of our business.

[0001596532-17-000019:mdna:113]
During the year ended December 31, 2016, cash used in investing activities was $326.0 million, consisting of purchases of available-for-sale securities of $439.7 million, purchases of property, equipment and other assets of $21.4 million, and an additional investment in a privately held company of $2.5 million.  Cash used was offset by cash provided by proceeds from the maturity of available-for-sale securities of $137.9 million.

[0001596532-17-000019:mdna:114]
During the year ended December 31, 2015, cash provided by investing activities was $184.2 million, consisting of proceeds from the maturity of available-for-sale securities of $208.2 million, offset by purchases of property, equipment and other assets of $19.2 million and increase in restricted cash of $4.0 million related to a security deposit required for a facility lease.

[0001596532-17-000019:mdna:115]
During the year ended December 31, 2014, cash used in investing activities was $249.4 million, consisting primarily of purchases of marketable securities of $210.0 million, purchases of property and equipment of $13.1 million and other investing activities of $38.2 million largely due to a $33.6 million equity investments in privately held companies, partially offset by the proceeds of the repayments of our notes receivable of $8.0 million and the release of our restricted cash into cash and cash equivalents of $4.0 million.

[0001596532-17-000019:mdna:116]
Cash Flows from Financing Activities

[0001596532-17-000019:mdna:117]
During the year ended December 31, 2016, cash provided by financing activities was $75.6 million, consisting primarily of the excess tax benefit associated with equity incentive plans of $42.9 million, proceeds from the exercise of stock options, net of repurchases, of $24.9 million, and proceeds from the issuance of common stock from our ESPP of $10.3 million.

[0001596532-17-000019:mdna:118]
During the year ended December 31, 2015, cash provided by financing activities was $63.1 million, consisting primarily of the excess tax benefit associated with equity incentive plans of $37.3 million, proceeds from the exercise of stock options, net of repurchases of $17.8 million and the proceeds from the issuance of common stock from our ESPP of $9.4 million.

[0001596532-17-000019:mdna:119]
During the year ended December 31, 2014, cash provided by financing activities was $244.0 million, consisting primarily of net proceeds raised from our initial public offering of $239.3 million, proceeds from the exercise of stock options, net of repurchases of $8.0 million and excess tax benefits from our equity incentive plans amounting to $17.4 million. These proceeds were partially offset by the repayment of our notes payable of $20.0 million.

[0001596532-17-000019:mdna:120]
Off-Balance Sheet Arrangements

[0001596532-17-000019:mdna:121]
As of December 31, 2016, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-17-000019:mdna:122]
Contractual Obligations and Commitments

[0001596532-17-000019:mdna:123]
Our contractual commitments will have an impact on our future liquidity. Our contractual obligations represent material expected or contractually committed future obligations with terms in excess of one year. We believe that we will be able to fund these obligations through cash generated from operations and from our existing cash balances.

[0001596532-17-000019:mdna:124]
The following summarizes our contractual obligations and commitments as of December 31, 2016 (in thousands):

[0001596532-17-000019:mdna:125]
|  |  | Payments Due by Period |
|  |  | Total |  | Less than1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than5 Years |
| Financing lease obligation(1) |  | $ | 43,626 |  |  | $ | 5,933 |  |  | $ | 12,406 |  |  | $ | 13,151 |  |  | $ | 12,136 |  |
| Operating lease obligations |  | 50,131 |  |  | 7,867 |  |  | 14,262 |  |  | 12,256 |  |  | 15,746 |  |
| Non-cancelable purchase obligations |  | 261,868 |  |  | 261,868 |  |  | — |  |  | — |  |  |  |
| Total |  | $ | 355,625 |  |  | $ | 275,668 |  |  | $ | 26,668 |  |  | $ | 25,407 |  |  | $ | 27,882 |  |

[0001596532-17-000019:mdna:126]
_________________

[0001596532-17-000019:mdna:127]
(1) Includes interest and land lease

[0001596532-17-000019:mdna:128]
The contractual obligation table above excludes tax liabilities of $16.1 million related to uncertain tax positions because we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-17-000019:mdna:129]
Critical Accounting Policies and Estimates

[0001596532-17-000019:mdna:130]
We have prepared our consolidated financial statements in accordance with GAAP and include our accounts and the accounts of our wholly owned subsidiaries. The preparation of these consolidated financial statements requires our management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities at the date of the financial statements, disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the applicable periods. We base our estimates, assumptions and judgments on historical experience and on various other factors that we believe to be reasonable under the circumstances. Different assumptions and judgments would change the estimates used in the preparation of our consolidated financial statements, which, in turn, could change the results from those reported. We evaluate our estimates, assumptions and judgments on an ongoing basis. The critical accounting estimates, assumptions and judgments that we believe have the most significant impact on our consolidated financial statements are the following:

[0001596532-17-000019:mdna:131]
Revenue Recognition

[0001596532-17-000019:mdna:132]
We generate revenue from sales of our products which incorporate our EOS software and accessories such as cables and optics to direct customers and channel partners together with post contract customer support (“PCS”). We typically sell products and PCS in a single transaction. We recognize revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery or performance has occurred; the sales price is fixed or determinable; and collectability is reasonably assured.

[0001596532-17-000019:mdna:133]
We define each of the four criteria above as follows:

[0001596532-17-000019:mdna:134]
| • | Persuasive evidence of an arrangement exists. Evidence of an arrangement consists of stand-alone purchase orders or purchase orders issued pursuant to the terms and conditions of a master sales agreement. It is our practice to identify an end customer prior to shipment to a reseller or distributor. |

[0001596532-17-000019:mdna:135]
| • | Delivery or performance has occurred. We use shipping documents or written evidence of customer acceptance, when applicable, to verify delivery or performance. We recognize product revenue upon transfer of title and risk of loss, which primarily is upon shipment to customers. We generally do not have significant obligations for future performance, rights of return, or pricing credits associated with our product sales. In instances where substantive acceptance provisions are specified in the customer arrangement, revenue and deferred cost of revenue is deferred until all acceptance criteria have been met. |

[0001596532-17-000019:mdna:136]
| • | The sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on payment terms and whether the sales price is subject to refund or adjustment. |

[0001596532-17-000019:mdna:137]
| • | Collectability is reasonably assured. We assess probability of collectability on a customer-by-customer basis. Our customers and channel partners are subjected to a credit review process that evaluates their financial condition and ability to pay for products and services. |

[0001596532-17-000019:mdna:138]
PCS is offered under renewable, fee-based contracts, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis. We initially defer PCS revenue and recognize it ratably over the life of the PCS contract, with the related expenses recognized as incurred. PCS contracts usually have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-17-000019:mdna:139]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of goods sold.

[0001596532-17-000019:mdna:140]
Multiple-Element Arrangements

[0001596532-17-000019:mdna:141]
Most of our arrangements, other than renewals of PCS, are multiple element arrangements with a combination of products and PCS. Products and PCS generally qualify as separate units of accounting. Our hardware deliverables include EOS software, which together deliver the essential functionality of our products. For multiple element arrangements, we allocate revenue to each unit of accounting based on the relative selling price. The relative selling price for each element is based upon the following hierarchy: vendor-specific objective evidence (“VSOE”), if available; third-party evidence (“TPE”), if VSOE is not available; and best estimate of selling price (“BESP”), if neither VSOE nor TPE is available. As we have not been able to establish VSOE or TPE for our products and most of our services, we generally utilize BESP for the purposes of allocating revenue to each unit of accounting.

[0001596532-17-000019:mdna:142]
| • | VSOE—We determine VSOE based on our historical pricing and discounting practices for the specific products and services when sold separately. In determining VSOE, we require that a substantial majority of the stand-alone selling prices fall within a reasonably narrow pricing range. |

[0001596532-17-000019:mdna:143]
| • | TPE—When VSOE cannot be established for deliverables in multiple-element arrangements, we apply judgment with respect to whether we can establish a selling price based on TPE. TPE is determined based on competitor prices for interchangeable products or services when sold separately to similarly situated customers. However, as our products contain a significant element of proprietary technology and offer substantially different features and functionality, the comparable pricing of products with similar functionality typically cannot be obtained. Additionally, as we are unable to reliably determine what competitors products’ selling prices are on a stand-alone basis, we are not able to obtain reliable evidence of TPE of selling price. |

[0001596532-17-000019:mdna:144]
| • | BESP—When we are unable to establish selling price using VSOE or TPE, we use BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service was sold regularly on a stand-alone basis. BESP is based on considering multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services were sold (domestic or international) and size of the end customer. |

[0001596532-17-000019:mdna:145]
We limit the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations, or subject to customer-specific return, acceptance or refund privileges.

[0001596532-17-000019:mdna:146]
We account for multiple agreements with a single partner as 1 arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single arrangement.

[0001596532-17-000019:mdna:147]
We may occasionally accept returns to address customer satisfaction issues even though there is no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period gross revenues. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-17-000019:mdna:148]
In May 2014, the Financial Accounting Standards Board (the "FASB") issued Accounting Standards Update ("ASU") 2014-09, “Revenue from Contracts with Customers,” which replaces current revenue recognition guidance. ASU 2014-09 requires revenue to be recognized when a customer obtains control of the promised goods or services. The amount of revenue recognized is limited to the final consideration received in exchange for the goods and services.

[0001596532-17-000019:mdna:149]
Management’s assessments of the potential impacts of the standard is underway. The standard is expected to impact the amount and timing of revenue recognized and the related disclosures on our consolidated financial statements.

[0001596532-17-000019:mdna:150]
We will adopt ASU 2014-09 during the first quarter of 2018 and we expect to adopt this new standard using the modified retrospective method that will result in a cumulative effect adjustment as of the date of adoption.

[0001596532-17-000019:mdna:151]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-17-000019:mdna:152]
Inventories primarily consist of finished goods purchased from third party contract manufacturers and are stated at the lower of cost (computed using the first-in, first-out method) or market value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancelable, including integrated circuits, which are held by our contract manufacturers.  We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value.  We also record a liability for non-cancelable, non-returnable purchase commitments with our component inventory suppliers for quantities in excess of our demand forecasts or that are considered obsolete.

[0001596532-17-000019:mdna:153]
Our contract manufacturers procure components and assemble products on our behalf based on our forecasts.  We generally incur a liability when the contract manufacturer has converted the component inventory to a finished product.  Historically, we have reimbursed our contract manufacturer for component inventory that has been rendered excess or obsolete due to manufacturing and engineering change orders resulting from design changes, or in cases where inventory levels greatly exceed our forecasts.

[0001596532-17-000019:mdna:154]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer liabilities.

[0001596532-17-000019:mdna:155]
Warranty

[0001596532-17-000019:mdna:156]
We offer a one-year warranty on all of our hardware products and a 90-day warranty against defects in the software embedded in the products. We use judgment and estimates when determining warranty costs based on historical costs to replace product returns within the warranty period at the time we recognize revenue. We accrue for potential warranty claims at the time of shipment as a component of cost of revenues based on historical experience and other relevant information. We reserve for specifically identified products if and when we determine we have a systemic product failure. Although we engage in extensive product quality programs, if actual product failure rates or use of materials differ from estimates, additional warranty costs may be incurred, which could reduce our gross margin. The accrued warranty liability is recorded in accrued liabilities in the accompanying consolidated balance sheets.

[0001596532-17-000019:mdna:157]
Stock-Based Compensation

[0001596532-17-000019:mdna:158]
Compensation expense related to stock-based transactions, including stock options, restricted stock units ("RSUs"), restricted stock awards (“RSAs”), and stock purchase rights under our employee stock purchase program is measured and recognized in the financial statements based on the estimated fair value of the equity granted. Stock-based compensation expense is generally recognized on a straight-line basis, net of estimated forfeitures, over the requisite service periods of the awards, which typically ranges from two to five years. The assumptions used in our option-pricing model represent management’s best estimates. These estimates involve inherent uncertainties and the application of management’s judgment. If factors change and different assumptions are used, our stock-based

[0001596532-17-000019:mdna:159]
compensation expense could be materially different in the future.  These assumptions and estimates are as follows:

[0001596532-17-000019:mdna:160]
Fair Value

[0001596532-17-000019:mdna:161]
The fair value of stock options are estimated on the grant date using the Black-Scholes-Merton option-pricing model. This model requires the input of subjective assumptions, including the expected term of the option and the expected volatility of the price of our common stock.

[0001596532-17-000019:mdna:162]
Expected Term

[0001596532-17-000019:mdna:163]
The expected term represents the period that our equity grants are expected to be outstanding. For option grants that are considered to be “simple,” we used the simplified method to determine the expected term which calculates the expected term as the average of the time-to-vesting and the contractual life of the options. For option grants that are not considered “simple,” the expected term is based on historical option exercise behavior and post-vesting cancellations of options by employees. For ESPP grants, the expected term is based on the length of the each purchase period with an offering period.

[0001596532-17-000019:mdna:164]
Expected Volatility

[0001596532-17-000019:mdna:165]
Our volatility has historically been derived from the average historical stock volatilities of a peer group of public companies within our industry that we consider to be comparable to our business over a period equivalent to the expected term of the stock-based grants. In late 2016, as sufficient but limited historical information became available, we transitioned our expected volatility model to include a combination of our peer group, and the limited historical and implied volatility of our common stock.

[0001596532-17-000019:mdna:166]
In addition to the assumptions used above, we have through fiscal 2016 applied an estimated forfeiture rate to calculate the stock-based compensation expense for our equity awards. Our forfeiture rate is based on an analysis of our actual forfeitures. We account for forfeitures as they occur and calculate a cumulative adjustment as it relates to equity transactions where prior forfeitures rates have previously and cumulatively been applied.

[0001596532-17-000019:mdna:167]
Income Taxes

[0001596532-17-000019:mdna:168]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-17-000019:mdna:169]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-17-000019:mdna:170]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-17-000019:mdna:171]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.

[0001596532-17-000019:mdna:172]
Loss Contingencies

[0001596532-17-000019:mdna:173]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. In assessing loss contingencies, we use significant judgment and assumptions to estimate the likelihood of loss, impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. We record a provision for contingent losses when it is both probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. We will record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements and (ii) the range of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.

[0001596532-17-000019:mdna:174]
Recent Accounting Pronouncements

[0001596532-17-000019:mdna:175]
Refer to “Recent Accounting Pronouncements” in Note 1 to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K.

[0001596532-17-000019:mdna:176]
62
