# ANET 8-K — 0001596532-17-000017 filed 2017-02-16

## item codes, every 8-K on or before 2017-02-17

- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2017-02-17

- none on or before 2017-02-17

## item 2.02 — earnings release, exhibit 99.1

[0001596532-17-000017:8k_2_02:1]
EX-99.1
2
ex991-earningsxfy16.htm
EXHIBIT 99.1

[0001596532-17-000017:8k_2_02:2]
Exhibit

[0001596532-17-000017:8k_2_02:3]
Exhibit 99.1

[0001596532-17-000017:8k_2_02:4]
Arista Networks, Inc. Reports Fourth Quarter and Full Year 2016 Financial Results

[0001596532-17-000017:8k_2_02:5]
Cloud Networking Pace Drives Stellar Revenue and Record EPS

[0001596532-17-000017:8k_2_02:6]
SANTA CLARA, Calif., February 16, 2017 - Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large data center and computing environments, today announced financial results for its fourth quarter and year ended December 31, 2016.

[0001596532-17-000017:8k_2_02:7]
Fourth Quarter Financial Highlights

[0001596532-17-000017:8k_2_02:8]
| • | Revenue of $328.0 million, an increase of 33.6% compared to the fourth quarter of 2015, and an increase of 13.0% from the third quarter of 2016. |

[0001596532-17-000017:8k_2_02:9]
| • | GAAP gross margin of 64.1%, compared to GAAP gross margin of 63.6% in the fourth quarter of 2015 and 64.2% in the third quarter of 2016. |

[0001596532-17-000017:8k_2_02:10]
| • | Non-GAAP gross margin of 64.4%, compared to non-GAAP gross margin of 64.0% in the fourth quarter of 2015 and 64.6% in the third quarter of 2016. |

[0001596532-17-000017:8k_2_02:11]
| • | GAAP net income of $58.8 million, or $0.79 per diluted share, compared to GAAP net income of $43.9 million, or $0.60 per diluted share, in the fourth quarter of 2015. |

[0001596532-17-000017:8k_2_02:12]
| • | Non-GAAP net income of $77.5 million, or $1.04 per diluted share, compared to non-GAAP net income of $57.5 million, or $0.80 per diluted share, in the fourth quarter of 2015. |

[0001596532-17-000017:8k_2_02:13]
"2016 was indeed a historic year for Arista, as we exceeded one billion dollars in annual sales within two years of becoming a public company,” stated Jayshree Ullal, Arista President and CEO. “Our customers are adopting cloud networking at an unprecedented pace.”

[0001596532-17-000017:8k_2_02:14]
Full Year Financial Highlights

[0001596532-17-000017:8k_2_02:15]
| • | Revenue of $1.1 billion, an increase of 34.8% compared to fiscal year 2015. |

[0001596532-17-000017:8k_2_02:16]
| • | GAAP gross margin of 64.0%, compared to GAAP gross margin of 64.9% in fiscal year 2015. |

[0001596532-17-000017:8k_2_02:17]
| • | Non-GAAP gross margin of 64.4%, compared to non-GAAP gross margin of 65.3% in fiscal year 2015. |

[0001596532-17-000017:8k_2_02:18]
| • | GAAP net income of $184.2 million, or $2.50 per diluted share, compared to GAAP net income of $121.1 million, or $1.67 per diluted share, in fiscal year 2015. |

[0001596532-17-000017:8k_2_02:19]
| • | Non-GAAP net income of $241.4 million or $3.30 per diluted share, compared to non-GAAP net income of $174.2 million, or $2.44 per diluted share, in fiscal year 2015. |

[0001596532-17-000017:8k_2_02:20]
Commenting on the company's financial results for the quarter, Ita Brennan, Arista’s CFO, said, “We are pleased with our outstanding financial performance in the fourth quarter, reflecting strong customer demand and consistent execution.”

[0001596532-17-000017:8k_2_02:21]
Fourth Quarter Company Highlights

[0001596532-17-000017:8k_2_02:22]
| • | Introduced Arista AlgoMatch™, an innovation that delivers advanced network policy enforcement for modern cloud networking along with the new Arista 7160 Series 25/100GbE programmable platforms. Arista AlgoMatch provides customers with more flexible and scalable solutions for access control, telemetry and secure cloud networking. The Arista 7160 Series utilizes new merchant silicon from Cavium to provide a programmable platform that lowers operational costs by supporting Flexible Profiles to reduce network complexity and delivers native 25GbE interfaces that support the new IEEE standard. |

[0001596532-17-000017:8k_2_02:23]
2016 Company Highlights

[0001596532-17-000017:8k_2_02:24]
| • | Delivered the Arista 7500R Universal Spine and Arista 7280R Universal Leaf platforms. |

[0001596532-17-000017:8k_2_02:25]
| • | Introduced the Arista FlexRoute™ Engine, which provides support for the full internet routing table, in hardware, and scales to more than one million routes on the Arista 7500R Universal Spine and Arista 7280R Universal Leaf platforms. |

[0001596532-17-000017:8k_2_02:26]
| • | Positioned by Gartner, Inc. in the “Leaders” quadrant of the 16 May 2016 Magic Quadrant for Data Center Networking. |

[0001596532-17-000017:8k_2_02:27]
| • | Announced next-generation, real-time telemetry and analytics capabilities that leverage Arista EOS® and CloudVision®. |

[0001596532-17-000017:8k_2_02:28]
| • | Initiated a strategic partnership with Hewlett Packard Enterprise ("HPE") to deliver on a common vision of secure Hybrid IT solutions. |

[0001596532-17-000017:8k_2_02:29]
| • | Unveiled the next phase of Arista EOS (Extensible Operating System) enabling network-wide state with NetDB™. |

[0001596532-17-000017:8k_2_02:30]
Financial Outlook

[0001596532-17-000017:8k_2_02:31]
For the first quarter of 2017, we expect:

[0001596532-17-000017:8k_2_02:32]
| • | Revenue between $320 and $330 million. |

[0001596532-17-000017:8k_2_02:33]
| • | Non-GAAP gross margin between 61% to 64%, and |

[0001596532-17-000017:8k_2_02:34]
| • | Non-GAAP operating margin of approximately 27%. |

[0001596532-17-000017:8k_2_02:35]
Guidance for non-GAAP financial measures excludes legal expenses of approximately $12 million associated with the OptumSoft and Cisco litigation, stock-based compensation and other non-recurring expenses.  A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below).

[0001596532-17-000017:8k_2_02:36]
Prepared Materials and Conference Call Information

[0001596532-17-000017:8k_2_02:37]
Arista executives will discuss fourth quarter and fiscal 2016 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial 1-877-201-0168 in the United States or 1-647-788-4901 from outside the US. The Conference ID is 49206884.

[0001596532-17-000017:8k_2_02:38]
The financial results conference call will also be available via live webcast on our investor relations website at investors.arista.com.  Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s Investor Relations website.

[0001596532-17-000017:8k_2_02:39]
Forward-Looking Statements

[0001596532-17-000017:8k_2_02:40]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the first quarter of fiscal 2017, statements regarding the adoption of cloud networking by our customers at an unprecedented pace, and statements regarding the benefits from the introduction of Arista AlgoMatch™ and the Arista 7160 Series platforms. Forward-looking statements are subject to a number of uncertainties and risks that could cause actual results to differ materially from those anticipated in the forward-looking statements including risks associated with: Arista Networks’ limited operating history; risks associated with Arista Networks’ rapid growth; Arista Networks’ customer concentration; Arista Networks’ dispute with Cisco Systems, Inc.  including Arista Networks’ ability to obtain a determination that alternative product implementations are not covered by remedial orders and our ability to manage our manufacturing and supply chain including the sourcing of components on commercially reasonable terms, if at all; risks associated with our customer’s adoption of our redesigned products and services and requests for more favorable terms and conditions; declines in the sales prices of our products and services; changes in customer order patterns or customer mix; increased competition in our products and service markets, including the data center market; dependence on the introduction and market acceptance of new product offerings and standards; rapid technological and market change; the evolution of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; Arista’s dispute with OptumSoft; and general market, political, economic and business conditions.  Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s Quarterly Reporting on Form 10-Q filed with the SEC on November 3, 2016, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at http://investors.arista.com and on the SEC’s website at www.sec.gov. All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-17-000017:8k_2_02:41]
Non-GAAP Financial Measures

[0001596532-17-000017:8k_2_02:42]
The company reports certain non-GAAP financial measures that exclude stock-based compensation expense, expenses associated with the OptumSoft and Cisco litigation, and other non-recurring charges. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends.  In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-17-000017:8k_2_02:43]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP net income, net income per diluted share, gross margin, or operating margin. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-17-000017:8k_2_02:44]
The Company’s guidance for non-GAAP financial measures excludes stock-based compensation, expenses associated with the OptumSoft and Cisco litigation, and other non-recurring charges. The Company has not reconciled its non-GAAP gross margin or its non-GAAP operating margin guidance to GAAP gross margin or GAAP operating margin, because we do not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling cash and non-cash items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. Stock-based compensation expense is impacted by the Company’s future hiring and retention needs, as well as the future fair market value of the Company’s common stock, all of which is difficult to predict and subject to constant change. The actual amount of stock-based compensation in the fiscal first quarter of 2017 will have a significant impact on the Company’s GAAP gross margin and GAAP operating margin. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measure is not available without unreasonable effort.

[0001596532-17-000017:8k_2_02:45]
About Arista Networks

[0001596532-17-000017:8k_2_02:46]
Arista Networks was founded to pioneer and deliver software-driven cloud networking solutions for large datacenter storage and computing environments. Arista’s award-winning platforms, ranging in Ethernet speeds from 10 to 100 gigabits per second, redefine scalability, agility and resilience. Arista has shipped more than ten million cloud networking ports worldwide with CloudVision and EOS, an advanced network operating system. Committed to open standards, Arista is a founding member of the 25/50GbE consortium. Arista Networks products are available worldwide directly and through partners.

[0001596532-17-000017:8k_2_02:47]
ARISTA, EOS, CloudVision, and AlgoMatch are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-17-000017:8k_2_02:48]
Additional information and resources can be found at: http://www.arista.com

[0001596532-17-000017:8k_2_02:49]
Investor Contact:

[0001596532-17-000017:8k_2_02:50]
Chuck Elliott

[0001596532-17-000017:8k_2_02:51]
Business and Investor Development

[0001596532-17-000017:8k_2_02:52]
elliott@arista.com

[0001596532-17-000017:8k_2_02:53]
Tel: (408) 547-5549

[0001596532-17-000017:8k_2_02:54]
Charles Yager

[0001596532-17-000017:8k_2_02:55]
Product and Investor Advocacy

[0001596532-17-000017:8k_2_02:56]
cyager@arista.com

[0001596532-17-000017:8k_2_02:57]
Tel: (408) 547-5892

[0001596532-17-000017:8k_2_02:58]
ARISTA NETWORKS, INC.

[0001596532-17-000017:8k_2_02:59]
Consolidated Statements of Income

[0001596532-17-000017:8k_2_02:60]
(Unaudited in thousands, except per share amounts)

[0001596532-17-000017:8k_2_02:61]
|  | Three Months Ended December 31, |  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 289,008 |  |  | $ | 217,325 |  |  | $ | 991,337 |  |  | $ | 744,877 |  |
| Service | 38,961 |  |  | 28,121 |  |  | 137,830 |  |  | 92,714 |  |
| Total revenue | 327,969 |  |  | 245,446 |  |  | 1,129,167 |  |  | 837,591 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 108,057 |  |  | 81,142 |  |  | 369,768 |  |  | 263,585 |  |
| Service | 9,757 |  |  | 8,136 |  |  | 36,283 |  |  | 30,446 |  |
| Total cost of revenue | 117,814 |  |  | 89,278 |  |  | 406,051 |  |  | 294,031 |  |
| Gross profit | 210,155 |  |  | 156,168 |  |  | 723,116 |  |  | 543,560 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 71,398 |  |  | 57,413 |  |  | 273,581 |  |  | 209,448 |  |
| Sales and marketing | 38,321 |  |  | 31,308 |  |  | 130,887 |  |  | 109,084 |  |
| General and administrative | 22,941 |  |  | 18,050 |  |  | 75,239 |  |  | 75,720 |  |
| Total operating expenses | 132,660 |  |  | 106,771 |  |  | 479,707 |  |  | 394,252 |  |
| Income from operations | 77,495 |  |  | 49,397 |  |  | 243,409 |  |  | 149,308 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (918 | ) |  | (746 | ) |  | (3,136 | ) |  | (3,152 | ) |
| Other income (expense), net | 560 |  |  | (109 | ) |  | 1,952 |  |  | (147 | ) |
| Total other income (expense), net | (358 | ) |  | (855 | ) |  | (1,184 | ) |  | (3,299 | ) |
| Income before provision for income taxes | 77,137 |  |  | 48,542 |  |  | 242,225 |  |  | 146,009 |  |
| Provision for income taxes | 18,354 |  |  | 4,618 |  |  | 58,036 |  |  | 24,907 |  |
| Net income | $ | 58,783 |  |  | $ | 43,924 |  |  | $ | 184,189 |  |  | $ | 121,102 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 58,527 |  |  | $ | 43,431 |  |  | $ | 182,965 |  |  | $ | 119,115 |  |
| Diluted | $ | 58,542 |  |  | $ | 43,464 |  |  | $ | 183,039 |  |  | $ | 119,264 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 0.84 |  |  | $ | 0.65 |  |  | $ | 2.66 |  |  | $ | 1.81 |  |
| Diluted | $ | 0.79 |  |  | $ | 0.60 |  |  | $ | 2.50 |  |  | $ | 1.67 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | 69,980 |  |  | 67,111 |  |  | 68,771 |  |  | 65,964 |  |
| Diluted | 74,384 |  |  | 72,062 |  |  | 73,222 |  |  | 71,411 |  |

[0001596532-17-000017:8k_2_02:62]
ARISTA NETWORKS, INC.

[0001596532-17-000017:8k_2_02:63]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-17-000017:8k_2_02:64]
(Unaudited in thousands, except percentages and per share amounts)

[0001596532-17-000017:8k_2_02:65]
|  | Three Months Ended December 31, |  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| GAAP gross profit | $ | 210,155 |  |  | $ | 156,168 |  |  | $ | 723,116 |  |  | $ | 543,560 |  |
| GAAP gross margin | 64.1 | % |  | 63.6 | % |  | 64.0 | % |  | 64.9 | % |
| Stock-based compensation expense | 1,004 |  |  | 842 |  |  | 3,620 |  |  | 3,048 |  |
| Non-GAAP gross profit | $ | 211,159 |  |  | $ | 157,010 |  |  | $ | 726,736 |  |  | $ | 546,608 |  |
| Non-GAAP gross margin | 64.4 | % |  | 64.0 | % |  | 64.4 | % |  | 65.3 | % |
| GAAP income from operations | $ | 77,495 |  |  | $ | 49,397 |  |  | $ | 243,409 |  |  | $ | 149,308 |  |
| Stock-based compensation expense | 16,324 |  |  | 12,978 |  |  | 59,032 |  |  | 45,303 |  |
| Litigation expense | 12,209 |  |  | 8,956 |  |  | 35,833 |  |  | 41,424 |  |
| Non-GAAP income from operations | $ | 106,028 |  |  | $ | 71,331 |  |  | $ | 338,274 |  |  | $ | 236,035 |  |
| Non-GAAP operating margin | 32.3 | % |  | 29.1 | % |  | 30.0 | % |  | 28.2 | % |
| GAAP net income | $ | 58,783 |  |  | $ | 43,924 |  |  | $ | 184,189 |  |  | $ | 121,102 |  |
| Stock-based compensation expense | 16,324 |  |  | 12,978 |  |  | 59,032 |  |  | 45,303 |  |
| Litigation expense | 12,209 |  |  | 8,956 |  |  | 35,833 |  |  | 41,424 |  |
| Release of income tax reserve | — |  |  | (968 | ) |  | (6,293 | ) |  | (7,344 | ) |
| Income tax effect on non-GAAP exclusions | (9,836 | ) |  | (7,424 | ) |  | (31,340 | ) |  | (26,292 | ) |
| Non-GAAP net income | $ | 77,480 |  |  | $ | 57,466 |  |  | $ | 241,421 |  |  | $ | 174,193 |  |
| Weighted average shares used in computing GAAP diluted income per share attributable to common stockholders | 74,384 |  |  | 72,062 |  |  | 73,222 |  |  | 71,411 |  |
| GAAP diluted net income per share attributable to common stockholders | $ | 0.79 |  |  | $ | 0.60 |  |  | $ | 2.50 |  |  | $ | 1.67 |  |
| Net income attributable to participating securities | — |  |  | 0.01 |  |  | 0.02 |  |  | 0.03 |  |
| Non-GAAP adjustments to net income | 0.25 |  |  | 0.19 |  |  | 0.78 |  |  | 0.74 |  |
| Non-GAAP diluted net income per share | $ | 1.04 |  |  | $ | 0.80 |  |  | $ | 3.30 |  |  | $ | 2.44 |  |
| Summary of Stock-Based Compensation Expense |  |  |  |  |  |  |  |
| Cost of revenue | $ | 1,004 |  |  | $ | 842 |  |  | $ | 3,620 |  |  | $ | 3,048 |  |
| Research and development | 8,830 |  |  | 7,171 |  |  | 31,892 |  |  | 25,515 |  |
| Sales and marketing | 4,292 |  |  | 3,316 |  |  | 15,666 |  |  | 11,454 |  |
| General and administrative | 2,198 |  |  | 1,649 |  |  | 7,854 |  |  | 5,286 |  |
| Total | $ | 16,324 |  |  | $ | 12,978 |  |  | $ | 59,032 |  |  | $ | 45,303 |  |

[0001596532-17-000017:8k_2_02:66]
ARISTA NETWORKS, INC.

[0001596532-17-000017:8k_2_02:67]
Consolidated Balance Sheets

[0001596532-17-000017:8k_2_02:68]
(Unaudited in thousands)

[0001596532-17-000017:8k_2_02:69]
|  | December 31, |
|  | 2016 |  | 2015 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 567,923 |  |  | $ | 687,326 |  |
| Marketable securities | 299,910 |  |  | — |  |
| Accounts receivable | 253,119 |  |  | 144,263 |  |
| Inventories | 236,490 |  |  | 92,129 |  |
| Prepaid expenses and other current assets | 168,684 |  |  | 50,610 |  |
| Total current assets | 1,526,126 |  |  | 974,328 |  |
| Property and equipment, net | 76,961 |  |  | 79,706 |  |
| Investments | 36,136 |  |  | 36,636 |  |
| Deferred tax assets | 70,960 |  |  | 48,429 |  |
| Other assets | 18,824 |  |  | 20,791 |  |
| TOTAL ASSETS | $ | 1,729,007 |  |  | $ | 1,159,890 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 79,457 |  |  | $ | 43,966 |  |
| Accrued liabilities | 90,951 |  |  | 60,971 |  |
| Deferred revenue | 273,350 |  |  | 122,049 |  |
| Other current liabilities | 15,795 |  |  | 8,025 |  |
| Total current liabilities | 459,553 |  |  | 235,011 |  |
| Income taxes payable | 14,498 |  |  | 14,060 |  |
| Lease financing obligations, non-current | 39,593 |  |  | 41,210 |  |
| Deferred revenue, non-current | 99,585 |  |  | 74,759 |  |
| Other long-term liabilities | 7,958 |  |  | 6,698 |  |
| TOTAL LIABILITIES | 621,187 |  |  | 371,738 |  |
| Commitments and contingencies |  |  |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 7 |  |  | 7 |  |
| Additional paid-in capital | 674,183 |  |  | 537,904 |  |
| Retained earnings | 435,105 |  |  | 250,916 |  |
| Accumulated other comprehensive loss | (1,475 | ) |  | (675 | ) |
| TOTAL STOCKHOLDERS’ EQUITY | 1,107,820 |  |  | 788,152 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 1,729,007 |  |  | $ | 1,159,890 |  |

[0001596532-17-000017:8k_2_02:70]
ARISTA NETWORKS, INC.

[0001596532-17-000017:8k_2_02:71]
Consolidated Statements of Cash Flows

[0001596532-17-000017:8k_2_02:72]
(Unaudited in thousands)

[0001596532-17-000017:8k_2_02:73]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 184,189 |  |  | $ | 121,102 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 19,749 |  |  | 13,671 |  |
| Stock-based compensation | 59,032 |  |  | 45,303 |  |
| Deferred income taxes | (21,720 | ) |  | (24,409 | ) |
| Excess tax benefit on stock based-compensation | (42,855 | ) |  | (37,251 | ) |
| Amortization of investment premiums | 1,493 |  |  | 1,471 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | (108,856 | ) |  | (47,281 | ) |
| Inventories | (144,361 | ) |  | (14,123 | ) |
| Prepaid expenses and other current assets | (115,074 | ) |  | (7,827 | ) |
| Other assets | 2,866 |  |  | (3,087 | ) |
| Accounts payable | 38,678 |  |  | 9,037 |  |
| Accrued liabilities | 30,629 |  |  | 20,398 |  |
| Deferred revenue | 176,126 |  |  | 90,340 |  |
| Income taxes payable | 42,650 |  |  | 32,018 |  |
| Other liabilities | 8,894 |  |  | 1,171 |  |
| Net cash provided by operating activities | 131,440 |  |  | 200,533 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Proceeds from marketable securities | 137,855 |  |  | 208,200 |  |
| Purchases of marketable securities | (439,711 | ) |  | — |  |
| Purchases of property and equipment | (21,419 | ) |  | (19,989 | ) |
| Other investing activities | (2,500 | ) |  | — |  |
| Change in restricted cash | (204 | ) |  | (4,041 | ) |
| Net cash provided by (used) in investing activities | (325,979 | ) |  | 184,170 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Principal payments of lease financing obligations | (1,336 | ) |  | (1,086 | ) |
| Proceeds from issuance of common stock upon exercising options, net of repurchases | 24,855 |  |  | 17,835 |  |
| Minimum tax withholding paid on behalf of employees for net share settlement | (1,100 | ) |  | — |  |
| Proceeds from issuance of common stock, employee stock purchase plan | 10,326 |  |  | 9,366 |  |
| Excess tax benefit on stock-based compensation | 42,855 |  |  | 37,251 |  |
| Issuance costs from initial public offering | — |  |  | (261 | ) |
| Net cash provided by financing activities | 75,600 |  |  | 63,105 |  |
| Effect of exchange rate changes | (464 | ) |  | (513 | ) |
| NET INCREASE/(DECREASE) IN CASH AND CASH EQUIVALENTS | (119,403 | ) |  | 447,295 |  |
| CASH AND CASH EQUIVALENTS—Beginning of year | 687,326 |  |  | 240,031 |  |
| CASH AND CASH EQUIVALENTS—End of year | $ | 567,923 |  |  | $ | 687,326 |  |
