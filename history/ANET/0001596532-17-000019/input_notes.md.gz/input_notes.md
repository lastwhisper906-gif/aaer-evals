# ANET notes — 0001596532-17-000019


## anet:ConcentrationRiskComponentsSupplierRiskPolicyTextBlock

[0001596532-17-000019:notes:1]
We work closely with third-party contract manufacturing suppliers to manufacture our products. As of December 31, 2016 and December 31, 2015, we had three and two suppliers, respectively, who provided substantially all of our electronic manufacturing services. Our contract manufacturing suppliers deliver our products to our third party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers. Our products rely on key components, including certain integrated circuit components and power supplies, some of which our contract manufacturers purchase on our behalf from a limited number of suppliers, including certain sole source providers. We do not have guaranteed supply contracts with any of our component suppliers, and our suppliers could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, or if we are unable to obtain alternative sources for these components, sales of our products could be delayed or halted entirely or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.


## anet:ScheduleofLeaseFinancingObligationsTableTextBlock

[0001596532-17-000019:notes:2]
As of December 31, 2016, the future minimum payments due under the lease financing obligation were as follows (in thousands):

[0001596532-17-000019:notes:3]
| Years Ending December 31, |  |
| 2017 | $ | 5,933 |  |
| 2018 | 6,113 |  |
| 2019 | 6,293 |  |
| 2020 | 6,477 |  |
| 2021 | 6,674 |  |
| Thereafter | 12,136 |  |
| Total payments | 43,626 |  |
| Less: interest and land lease expense | (26,045 | ) |
| Total payments under facility financing obligations | 17,581 |  |
| Property reverting to landlord | 23,630 |  |
| Present value of obligation | 41,211 |  |
| Less current portion | (1,618 | ) |
| Long-term portion of obligation | $ | 39,593 |  |


## anet:ScheduleofSharebasedCompensationSharesAvailableForGrantActivityTableTextBlock

[0001596532-17-000019:notes:4]
The following table presents the stock activity and the total number of shares available for grant as of December 31, 2016 (in thousands):

[0001596532-17-000019:notes:5]
|  |  | Number of Shares |
| Balance—December 31, 2015 |  | 10,495 |  |
| Authorized |  | 2,044 |  |
| Options granted |  | (441 | ) |
| RSUs granted |  | (816 | ) |
| Options canceled |  | 362 |  |
| Options repurchased |  | 5 |  |
| RSUs forfeited |  | 90 |  |
| Shares traded for taxes |  | 15 |  |
| Balance—December 31, 2016 |  | 11,754 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001596532-17-000019:notes:6]
The fair values of available-for-sale investments, by remaining contractual maturity, are as follows (in thousands):

[0001596532-17-000019:notes:7]
|  |  | December 31, 2016 |
| Due in 1 year or less |  | $ | 140,879 |  |
| Due in 1 year through 2 years |  | 159,031 |  |
| Total marketable securities |  | $ | 299,910 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001596532-17-000019:notes:8]
The accompanying consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and are prepared in accordance with U.S. generally accepted accounting principles (GAAP). All significant intercompany accounts and transactions have been eliminated.

[0001596532-17-000019:notes:9]
During fiscal 2015 and 2014, certain reclassifications of prior period amounts were made to conform to the current period presentation.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001596532-17-000019:notes:10]
We consider all highly liquid investments with stated maturity of three months or less at the time of purchase to be cash equivalents. Cash and cash equivalents consist of cash on deposit with various financial institutions and highly liquid investments in money market funds. Interest is accrued as earned. We have restricted cash pledged as collateral representing a security deposit required for a facility lease.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-17-000019:notes:11]
Commitments and Contingencies

[0001596532-17-000019:notes:12]
Operating Leases

[0001596532-17-000019:notes:13]
We lease various operating spaces in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2025. These arrangements require us to pay certain operating expenses, such as taxes, repairs, and insurance and contain renewal and escalation clauses. We recognize rent expense under these arrangements on a straight-line basis over the term of the lease.

[0001596532-17-000019:notes:14]
As of December 31, 2016, the aggregate future minimum payments under non-cancelable operating leases consist of the following (in thousands):

[0001596532-17-000019:notes:15]
| Years Ending December 31, |  |
| 2017 | $ | 7,867 |  |
| 2018 | 7,373 |  |
| 2019 | 6,889 |  |
| 2020 | 6,552 |  |
| 2021 | 5,704 |  |
| Thereafter | 15,746 |  |
| Total minimum future lease payments | $ | 50,131 |  |

[0001596532-17-000019:notes:16]
We recognize rent expense under these arrangements on a straight-line basis over the term of the lease.  Rent expense for all operating leases amounted to $8.1 million, $5.4 million and $2.1 million for the years ended December 31, 2016, 2015 and 2014, respectively.

[0001596532-17-000019:notes:17]
Financing Obligation—Build-to-Suit Lease

[0001596532-17-000019:notes:18]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013.  Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction, we were deemed the owner of the building (for accounting purposes only) during the construction period.  Upon completion of construction in 2013, we concluded that we had forms of continued economic involvement in the facility, and therefore did not meet with the provisions for sale-leaseback accounting. We continue to maintain involvement in the property post construction and lack transferability of the risks and rewards of ownership, due to our required maintenance of a $4.0 million letter of credit, in addition to our ability and option to sublease our portion of the leased building for fees substantially higher than our base rate.  Therefore, the lease is accounted for as a financing obligation and lease payments will be attributed to (1) a reduction of the principal financing obligation; (2) imputed interest expense; and (3) land lease expense, representing an imputed cost to lease the underlying land of the building.  At the conclusion of the initial lease term, we will de-recognize both the net book values of the asset and the remaining financing obligation.

[0001596532-17-000019:notes:19]
As of December 31, 2016 and 2015, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $41.2 million and $42.5 million, respectively. As of December 31, 2016, $1.6 million and $39.6 million were recorded as short-term and long-term financing obligations, respectively.

[0001596532-17-000019:notes:20]
Land lease expense under our lease financing obligation amounted to $1.3 million, $1.3 million and $1.2 million for the years ended December 31, 2016, 2015 and 2014 respectively.

[0001596532-17-000019:notes:21]
Purchase Commitments

[0001596532-17-000019:notes:22]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply.  We issue purchase orders to our contract manufacturers for finished product and a significant portion of these orders consist of firm non-cancelable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancelable, including integrated circuits, which are consigned to our contract manufacturers.   As of December 31, 2016, we had non-cancelable purchase commitments of $261.9 million.  In addition, we have provided deposits to secure our obligations to purchase inventory. We had $63.1 million and $2.3 million in deposits as of December 31, 2016 and December 31, 2015, respectively. These deposits are classified in other current and long term assets in our accompanying audited consolidated balance sheets.

[0001596532-17-000019:notes:23]
Guarantees

[0001596532-17-000019:notes:24]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-17-000019:notes:25]
Legal Proceedings

[0001596532-17-000019:notes:26]
OptumSoft, Inc. Matters

[0001596532-17-000019:notes:27]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies; and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-17-000019:notes:28]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft access to our software for evaluation by OptumSoft; (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches; (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers; (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us; and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors, who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dtd July 28, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.

[0001596532-17-000019:notes:29]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we assert our ownership of the software components at issue and our interpretation of the 2004 agreement.  Among other things, we assert that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components.  We ask the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also assert that, even if we are found not to own certain components, such components are licensed to us under the terms of the 2004 agreement.  However, there can be no assurance that our assertions will ultimately prevail in litigation.  On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue.  We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information.  While we believe we have meritorious defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-17-000019:notes:30]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015.  On December 16, 2015, the Court issued a Proposed Statement of Decision Following Phase 1 Trial, and on January 8, 2016, OptumSoft filed objections to that Proposed Statement of Decision.  On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I.  The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II including the application of the Court’s interpretation of the 2004 agreement as set forth in the Final Statement of Decision Following Phase I Trial to any other source code that OptumSoft claims to own following a review.  Phase II was previously scheduled to be tried in April 2016; however, that trial date has been vacated and a new trial date has not yet been set.

[0001596532-17-000019:notes:31]
We intend to vigorously defend against any claims brought against us by OptumSoft.  However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor.  For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft.  If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license.  An adverse litigation ruling could result in a significant damages award against us and injunctive relief.  In addition, OptumSoft could assert additional or different claims against us, including claims that our license from OptumSoft is invalid.

[0001596532-17-000019:notes:32]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible.  Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated.  However, the outcome of litigation is inherently uncertain.  Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-17-000019:notes:33]
Cisco Systems, Inc. (“Cisco”) Matters

[0001596532-17-000019:notes:34]
We are currently involved in several litigation matters with Cisco Systems, Inc. These matters are summarized below.

[0001596532-17-000019:notes:35]
Cisco Systems, Inc. v. Arista Networks, Inc. (Case No. 4:14-cv-05343) (“’43 Case”)

[0001596532-17-000019:notes:36]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the 875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”).  Cisco seeks, as relief for our alleged infringement in the ’43 Case, lost profits and/or reasonable royalty damages in an unspecified amount, including treble damages, attorney’s fees, and associated costs.  Cisco also seeks injunctive relief in the ’43 Case.  On February 10, 2015, the Court granted our unopposed motion to stay the ’43 Case until the proceedings before the United States International Trade Commission (“USITC”) pertaining to the same patents (as discussed below) became final.  Trial has not been scheduled in the ’43 Case.

[0001596532-17-000019:notes:37]
Cisco Systems, Inc. v. Arista Networks, Inc. (Case No. 5:14-cv-05344) (“’44 Case”)

[0001596532-17-000019:notes:38]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI” and U.S. Patent Nos.  7,047,526 and 7,953,886 (respectively, “the ’526 patent” and “the ’886 patent”).  As relief for our alleged patent infringement in the ’44 Case, Cisco seeks lost profits and/or reasonable royalty damages in an unspecified amount including treble damages, attorney’s fees, and associated costs as well as injunctive relief.  As relief for our alleged copyright infringement, Cisco seeks monetary damages for alleged lost profits, profits from our alleged infringement, statutory damages, attorney's fees, and associated costs.

[0001596532-17-000019:notes:39]
On February 13, 2015, we answered the complaint in the ’44 Case, denying the patent and copyright infringement allegations and raising numerous affirmative defenses.  On March 6, 2015, Cisco filed an amended complaint against us in the ’44 Case.  In response, we moved to dismiss Cisco’s allegations of willful patent infringement and pre-suit indirect patent infringement.  The Court granted the motion with leave to amend on July 2, 2015.  On July 23, 2015, Cisco filed an amended complaint.

[0001596532-17-000019:notes:40]
As described below, on May 25, 2016, our petition for Inter Partes Review (“IPR”) of the ’886 patent was instituted by the United States Patent Trial and Appeal Board (“PTAB”). Cisco subsequently agreed to dismiss its claims as to the ‘886 patent with prejudice.

[0001596532-17-000019:notes:41]
Summary judgment cross-motions in the ’44 Case were heard on August 4, 2016, and the Court denied all motions brought by both sides.  Trial began on November 28, 2016, and the jury rendered its verdict on December 14, 2016.  The jury found that Arista had proven its copyright defense of scenes a faire and that Cisco had failed to prove infringement of the ’526 patent, and on that basis judgment was entered in Arista’s favor on all claims on December 19, 2016.

[0001596532-17-000019:notes:42]
On January 17, 2017, Cisco filed a motion for judgment as a matter of law, challenging the sufficiency of the evidence in support of Arista's scenes a faire defense.  Cisco did not file any post-trial motion regarding the ’526 patent, nor did it file a motion for a new trial.  We also filed a motion for judgment as a matter of law on several issues.  The hearing on both parties’ motions is currently set for April 27, 2017.

[0001596532-17-000019:notes:43]
Arista Networks, Inc. v. Cisco Systems, Inc. (Case No. 5:16-cv-00923) (“’23 Case”)

[0001596532-17-000019:notes:44]
On February 24, 2016, we filed a complaint against Cisco in the District Court for the Northern District of California alleging antitrust violations and unfair competition.  On April 13, 2016, Cisco filed a motion to stay the ’23 Case, or in the alternative, to dismiss the complaint.  On August 23, 2016, the Court granted Cisco’s motion to stay the ’23 Case until judgment has been entered on Cisco’s copyright claims in the ’44 Case, which the Court anticipated by December 22, 2016.  Following the jury’s verdict in Arista’s favor in the ’44 Case, the parties filed a stipulation continuing the Case Management Conference until March 2, 2017.  Trial in the ’23 Case is set for August 3, 2018, and is not affected by the Court’s granting of the interim stay.

[0001596532-17-000019:notes:45]
Certain Network Devices, Related Software, and Components Thereof (Inv. No. 337-TA-944) (“944 Investigation”)

[0001596532-17-000019:notes:46]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we have violated Section 337 of the Tariff Act of 1930, as amended.  The USITC instituted Cisco’s complaint as Investigation No. 337-TA-944. Cisco initially alleged that certain of our switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents.  Cisco subsequently dropped the ’296 patent from the 944 Investigation.  Cisco sought, among other things, a limited exclusion order barring entry into the United States of accused switch products (including our 7000 Series of switches) and components and software therein and a cease and desist order against us restricting our activities with respect to our imported accused switch products and components and software therein.  On February 11, 2015, we responded to the complaint in the 944 Investigation by, among other things, denying the patent infringement allegations and raising numerous affirmative defenses.

[0001596532-17-000019:notes:47]
The Administrative Law Judge (“ALJ”) assigned to the 944 Investigation issued a procedural schedule calling for, among other events: an evidentiary hearing on September 9-11 and 15-17, 2015; issuance of an initial determination regarding our alleged violations on January 27, 2016; and a Target Date for completion of the investigation on May 27, 2016.  On January 27, 2016, the ALJ issued a revised procedural schedule extending the date for issuance of an initial determination to February 2, 2016 and extending the Target Date to June 2, 2016.

[0001596532-17-000019:notes:48]
On February 2, 2016, the ALJ issued his initial determination finding a violation of section 337 of the Tariff Act. More specifically, the ALJ found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringe asserted claims 1, 2, 8-11, and 17-19 of the ’537 patent; asserted claims 6, 7, 20, and 21 of the ’592 patent; and asserted claims 5, 7, 45, and 46 of the ’145 patent.  The ALJ did not find a violation of section 337 with respect to any asserted claims of the ’597 and ’164 patents.  On April 11, 2016, the Commission decided to review certain findings contained in the initial determination.  On June 23, 2016, the Commission issued its Final Determination, which found a violation with respect to the ’537, ’592, and ’145 patents, and found no violation with respect to the ’597 and ’164 patents.  The Commission also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software and components thereof that infringe one or more of claims 1, 2, 8-11, and 17-19 of the ’537 patent; claims 6, 7, 20, and 21 of the ’592 patent; and claims 5, 7, 45, and 46 of the ’145 patent.  On August 22, 2016, the Presidential review period for the 944 investigation expired.  The USITC orders will be in effect until the expiration of the ’537, ’592, and ’145 patents.

[0001596532-17-000019:notes:49]
Both we and Cisco filed petitions for review of the USITC’s Final Determination to the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”).  On August 26, 2016, the Federal Circuit consolidated the appeals, and on September 23, 2016, it issued an order setting an expedited briefing schedule.  The appeal is fully briefed and oral argument has not been scheduled.

[0001596532-17-000019:notes:50]
On August 26, 2016, Cisco filed an enforcement complaint under Section 337 of the Tariff Act of 1930, as amended, with the USITC.  Cisco alleges that we are violating the cease and desist and limited exclusion orders issued in the 944 Investigation by engaging in the “marketing, distribution, offering for sale, selling, advertising, and/or aiding or abetting other entities in the sale and/or distribution of products that Cisco alleges continue to infringe claims 1-2, 8-11, and 17-19 of the ’537 patent,” despite the design changes we have made to those products.  Cisco asks the USTIC to (1) enforce the cease and desist order; (2) modify the Commission’s limited exclusion order and/or cease and desist order “in any manner that would assist in the prevention of the unfair practices that were originally the basis for issuing such Order or assist in the detection of violations of such Order”; (3) impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000.00 or twice the domestic value of the articles entered or sold, whichever is higher”; (4) bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order”; and (5) impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.”  On September 28, 2016, the Commission instituted the enforcement proceeding.  The proceeding has been assigned to Administrative Law Judge Shaw, who presided over the underlying investigation.  On October 14, 2016, we responded to the complaint by, among other things, denying the patent infringement allegations and raising affirmative defenses.  On November 2, 2016, the ALJ issued an order setting the deadline for the initial determination for June 20, 2017 and the Target Date for September 20, 2017.  On November 3, 2016, the ALJ issued a scheduling order setting the evidentiary hearing in this proceeding for April 5, 2017.

[0001596532-17-000019:notes:51]
Certain Network Devices, Related Software, and Components Thereof (Inv. No. 337-TA-945) (“945 Investigation”)

[0001596532-17-000019:notes:52]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated Section 337 of the Tariff Act of 1930, as amended.  The USITC instituted Cisco’s complaint as Investigation No. 337-TA-945.  Cisco alleges that certain of our switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents.  Cisco seeks, among other things, a limited exclusion order barring entry into the United States of accused switch products (including our 7000 Series of switches) related software, and components thereof and a cease and desist order against us restricting our activities with respect to our imported accused switch products, related software, and components thereof.  On February 11, 2015, we responded to the notice of investigation and complaint in the 945 Investigation by, among other things, denying the patent infringement allegations and raising numerous affirmative defenses.

[0001596532-17-000019:notes:53]
The ALJ issued a procedural schedule calling for, among other events: an evidentiary hearing on November 9-20, 2015; issuance of an initial determination regarding our alleged violations on April 26, 2016; and a Target Date for completion on August 26, 2016.  On March 29, 2016, the ALJ issued a revised procedural schedule extending the deadline for issuance of an initial determination to August 26, 2016, and extending the Target Date to December 26, 2016.  On August 24, 2016, the ALJ issued a revised procedural schedule extending the deadline for issuance of an initial determination to November 7, 2016, and extending the Target Date to March 7, 2017.  On November 4, 2016, the ALJ issued a revised procedural schedule extending the deadline for issuance of an initial determination to December 7, 2016, and extending the Target Date to April 7, 2017.  On December 7, 2016, the ALJ issued a revised procedural schedule extending the deadline for issuance of an initial determination to December 9, 2016, and extending the Target Date to April 9, 2017.

[0001596532-17-000019:notes:54]
On December 9, 2016, the ALJ issued her initial determination finding a violation of section 337 of the Tariff Act. More specifically, the ALJ found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringe asserted claims 1, 7, 9, 10, and 15 of the ’577 patent; and asserted claims 1, 2, 4, 5, 7, 8, 10, 13, 19, 56, and 64 of the ’668 patent.  The ALJ did not find a violation of section 337 with respect to asserted claim 2 of the ’577 patent or any asserted claims of the ’853, ’492, ’875, and ’211 patents.  On December 29, 2016, Arista, Cisco and the OUII filed petitions for review of certain findings contained in the initial determination.  On January 3, 2017, the Commission extended the Target Date to April 17, 2017, and set the deadline for determining whether to review the final initial determination to February 15, 2017.  On January 27, 2017, the Commission further extended the Target Date to May 1, 2017, and set the deadline for determining whether to review the final initial determination to March 1, 2017.  If the Commission finds a violation in its Final Determination, that finding will be subject to a 60-day Presidential review period.

[0001596532-17-000019:notes:55]
Inter Partes Reviews

[0001596532-17-000019:notes:56]
We have filed petitions for Inter Partes Review (“IPR”) of the ’597, ’211, ’668, ’853, ’537, ’577, ’886, and ’526 patents.  IPRs relating to the ’597 (IPR No. 2015-00978) and ’211 (IPR No. 2015-00975) patents were instituted in October 2015 and hearings on these IPRs were completed in July 2016.  On September 28, 2016, the PTAB issued a final written decision finding claims 1, 14, 39-42, 71, 72, 84, and 85 of the ’597 patent unpatentable.  The PTAB also found that claims 29, 63, 64, 73, and 86 of the ’597 patent had not been shown to be unpatentable.  Cisco requested rehearing of the PTAB’s Final Written Decision on October 28, 2016, which the PTAB denied on January 13, 2017.  On January 23, 2017, we filed a notice of appeal with respect to this decision regarding claims 29, 63, 64, 73, and 86 of the ’597 patent.  On October 5, 2016, the PTAB issued a final written decision finding claims 1 and 12 of the ’211 patent unpatentable.  The PTAB also found that claims 2, 6-9, 13, 17-20 of the ’211 patent had not been shown to be unpatentable.  On December 5, 2016, we filed a notice of appeal with respect to this decision regarding claims 2, 6-9, 13, 17-20, which was docketed as Appeal No. 17-1313.  Cisco filed a notice of cross-appeal with respect to claims 1 and 12 on December 19, 2016, which was docketed as Appeal No. 17-1380.  The Court of Appeals for the Federal Circuit consolidated these appeals on December 20, 2016.  The briefing is set to be completed in July 2017.

[0001596532-17-000019:notes:57]
The IPR relating to the ’886 patent was instituted on May 25, 2016.  Following that decision, Cisco agreed to dismiss its claims as to the ʼ886 patent with prejudice, and we dismissed our counterclaims as to the ʼ886 patent without prejudice.

[0001596532-17-000019:notes:58]
IPRs relating to the ’668 (IPR No. 2016-00309), ’577 (IPR No. 2016-00303), ’853 (IPR No. 2016-0306), and ’537 (IPR No. 2016-0308) patents were instituted in June 2016 and are set for hearing in March 2017.  Final Written Decisions on these IPRs will be issued by June 2017.

[0001596532-17-000019:notes:59]
*  *  *  *  *

[0001596532-17-000019:notes:60]
We intend to vigorously defend against each of the Cisco’s lawsuits, as summarized in the preceding paragraphs.  However, we cannot be certain that any claims by Cisco would be resolved in our favor regardless of the merit of the claims.  Any adverse litigation ruling could result in the above described injunctive relief, could require a significant damages award against us or a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products to the extent that we are found to infringe any valid claims asserted against us by Cisco.

[0001596532-17-000019:notes:61]
For example, in the 944 Investigation, the USITC has issued a limited exclusion order barring entry into the United States of our network devices (including our 7000 Series of switches), related software, and components thereof that infringe one or more of the claims of the ʼ537, ʼ592, and ʼ145 patents specified above and a cease and desist order restricting our activities with respect to such imported products.  In addition, in the 945 Investigation, the ALJ has issued her initial determination finding a violation of section 337 of the Tariff Act with respect to the ‘668 and ‘577 patents, which is now subject to review by the Commission.

[0001596532-17-000019:notes:62]
To comply with these orders, we have sought to develop technical design-arounds that no longer infringe the patents that are the subject of the orders.  In any efforts to develop technical design-arounds for our products, we may be unable to do so in a manner that does not continue to infringe the patents or that is acceptable to our customers.  These development efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management.  Moreover, in the 944 Investigation and 945 Investigation, such design-arounds would require us to obtain approval of either the USITC or U.S. Customs and Border Protection (“CBP”) to resume the importation of the redesigned products into the United States.  We may not be successful in our efforts to obtain such approvals to import such modified products in a timely manner, or at all.  While a favorable ruling from the CBP would allow us to resume importation of our redesigned products into the United States, the USITC could still determine in an enforcement action that our redesigned products continue to infringe the patents that are the subject of any USITC orders. Any failure to effectively redesign our products, to obtain timely clearance from USITC or CBP to import such redesigned products, or to address the USITC findings in a manner that complies with the USITC orders, may cause a disruption to our product shipments and materially and adversely affect our business, prospects, reputation, results of operations, and financial condition.

[0001596532-17-000019:notes:63]
Specifically, in response to the USITC’s findings in the 944 Investigation, we have made design changes to our products for sale in the United States to address the features that were found to infringe the ’537, ’592, ’145 patents.  Following the issuance of the final determination in the 944 Investigation, we submitted a Section 177 ruling request to CBP seeking approval to import these redesigned products into the United States.  On November 18, 2016, we received a 177 ruling from CBP finding that our redesigned products did not infringe the ‘537, ’592, and ‘145 patents, and approving the importation of these redesigned products into the United States.  However, on January 13, 2017, at the request of Cisco Systems and without our input, CBP issued a letter to us revoking its prior November 18 ruling.  Due to this revocation, we can no longer import its products into the United States. CBP has informed us that it currently takes no position on whether our redesigned products infringe and will conduct an inter partes proceeding between Arista and Cisco to determine whether our redesigned products infringe and whether to approve them for importation into the United States. We do not yet know when CBP will complete the process and provide that ruling. The CBP may not rule in a timely fashion, and we may not receive a favorable ruling at the end of the process.

[0001596532-17-000019:notes:64]
Similarly, if the USITC finds in a Final Determination that we infringe any patent in the 945 Investigation, the USITC will likely issue remedial orders in that investigation as well.  If such orders are not disapproved by the United States Trade Representative, we would need to further modify our products to take our products outside the scope of any patents we are found to have infringed in the 945 Investigation and obtain the USITC and/or CBP approvals described above in order to resume importation of our redesigned products into the United States.

[0001596532-17-000019:notes:65]
If the USITC determines that our redesigned products continue to infringe the patents subject to any USITC limited exclusion order or cease and desist order in an enforcement action for either the 944 Investigation or the 945 Investigation, the USITC may impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000.00 or twice the domestic value of the articles entered or sold, whichever is higher,” bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order” or impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.”

[0001596532-17-000019:notes:66]
In order to comply with the USITC’s remedial orders, we have also made certain changes to our manufacturing, importation and shipping workflows. These changes have included shifting manufacturing and integration of our products to be sold in the United States to U.S. facilities. Such changes may be extremely costly, time consuming, and we may not be able to implement such changes successfully.  Any failure to successfully change our manufacturing and importation processes or shipping workflows in a manner that is compliant with the limited exclusion order and cease and desist order may cause a disruption in our product shipments and materially and adversely affect our business, prospects, reputation, results of operations, and financial condition.

[0001596532-17-000019:notes:67]
In connection with these changes, to the extent that we are required to make further modifications to our supply chain to obtain alternative U.S. sources for subcomponents, we may be unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, if at all, which could delay or halt entirely production of our products or require us to make further modifications to our products to incorporate new components that are available in the United States. Any of these events could result in lost sales, reduced gross margins or damage to our end-customer relationships, which would materially and adversely impact our business, financial condition, results of operations and prospects.

[0001596532-17-000019:notes:68]
Additionally, the existence of Cisco’s lawsuits against us could cause concern among our customers and partners and could adversely affect our business and results of operations.  Whether or not we prevail in the lawsuit, we expect that the litigation will be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-17-000019:notes:69]
With respect to the various legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated.  However, the outcome of litigation is inherently uncertain.  Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-17-000019:notes:70]
Other Matters

[0001596532-17-000019:notes:71]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.  We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated.   As of December 31, 2016, provisions recorded for contingent losses related to other claims and matters have not been significant.  Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows.  However, litigation is subject to inherent uncertainties and our view of these matters may change in the future.  Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001596532-17-000019:notes:72]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. In assessing loss contingencies, we use significant judgment and assumptions to estimate the likelihood of loss, impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. We record a provision for contingent losses when it is both probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. We will record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements and (ii) the range of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001596532-17-000019:notes:73]
Comprehensive income is comprised of net income and other comprehensive income. Unrealized gains and losses on available-for-sale investments and foreign currency translation adjustments are included in our other comprehensive income or loss.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-17-000019:notes:74]
Equity Award Plan Activities

[0001596532-17-000019:notes:75]
2014 Equity Incentive Plan

[0001596532-17-000019:notes:76]
In April 2014, the board of directors and stockholders approved the 2014 Equity Incentive Plan (the “2014 Plan”), effective on the first day that our common stock was publicly traded. Our board of directors has terminated the 2004 and 2011 equity plans as to future grants.  However, these plans will continue to govern the terms and conditions of the outstanding options previously granted thereunder.

[0001596532-17-000019:notes:77]
Awards granted under the 2014 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Awards (“RSAs”), Stock Appreciation Rights (“SARs”) or Restricted Stock Units (“RSUs”).  The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of our shares outstanding on the immediately preceding December 31, but not to exceed 12,500,000 shares, unless the board of directors, in its discretion, determines to make a smaller increase. As of December 31, 2016, there remained approximately 11.8 million shares available for issuance under the 2014 Plan.

[0001596532-17-000019:notes:78]
On February 6, 2017, our board of directors authorized an increase to the shares available for issuance under the plan of 3% of the total shares outstanding on December 31, 2016 effective January 1, 2017.  The increase amounted to 2,124,333 shares.

[0001596532-17-000019:notes:79]
2014 Employee Stock Purchase Plan

[0001596532-17-000019:notes:80]
In April 2014, the board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded.  The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding immediately preceding December 31, but not to exceed 2,500,000 shares, unless the board of directors, in its discretion, determines to make a smaller increase.

[0001596532-17-000019:notes:81]
Under our 2014 ESPP eligible employees are permitted to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the exercise date. Each offering period will be approximately two years starting on the first trading date after February 15 and August 15 of each year. Participants may purchase shares of common stock through payroll deductions up to 10% of their eligible compensation, subject to Internal Revenue Service mandated purchase limits. As of December 31, 2016, there remained 1,483,846 shares available for issuance under the ESPP.

[0001596532-17-000019:notes:82]
On February 6, 2017, our board of directors authorized an increase to shares available for issuance under the plan of 1% of the total shares outstanding on December 31, 2016 effective January 1, 2017.  The increase amounted to 708,111 shares.

[0001596532-17-000019:notes:83]
Stock Option Activities

[0001596532-17-000019:notes:84]
The following table summarizes the option activity under our stock plans and related information (in thousands, except years and per share amounts):

[0001596532-17-000019:notes:85]
|  |  | Options Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding |
| Balance—December 31, 2015 |  | 11,630 |  |  | $ | 24.49 |  |  | 7.6 |  | $ | 620,802 |  |
| Authorized |  |  |  |  |  |  |  |  |
| Options granted |  | 441 |  |  | 56.95 |  |  |  |  |  |
| Options exercised |  | (2,200 | ) |  | 11.32 |  |  |  |  |  |
| Options canceled |  | (362 | ) |  | 31.22 |  |  |  |  |  |
| Balance—December 31, 2016 |  | 9,509 |  |  | $ | 28.79 |  |  | 6.9 |  | $ | 646,394 |  |
| Vested and exercisable—December 31, 2016 |  | 3,642 |  |  | $ | 15.29 |  |  | 6.1 |  | $ | 296,738 |  |
| Vested and expected to vest—December 31, 2016 |  | 9,050 |  |  | $ | 28.23 |  |  | 6.9 |  | $ | 620,296 |  |

[0001596532-17-000019:notes:86]
_________________

[0001596532-17-000019:notes:87]
The weighted-average grant-date fair value of options granted during the year ended December 31, 2016 and 2015 was $23.66 and $29.20 per share, respectively. The aggregate intrinsic value of options exercised during the year ended December 31, 2016 was $147.6 million.

[0001596532-17-000019:notes:88]
Restricted Stock Unit (RSU) Activities

[0001596532-17-000019:notes:89]
A summary of the activity under our 2014 Plan and changes during the reporting period and a summary of information related to RSUs are presented below (in thousands, except years and per share amounts):

[0001596532-17-000019:notes:90]
|  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2015 | 893 |  |  | $ | 70.14 |  |  | 1.9 |  | $ | 69,509 |  |
| RSUs granted | 816 |  |  | 76.54 |  |  |  |  |  |
| RSUs vested | (244 | ) |  | 69.32 |  |  |  |  |  |
| RSUs forfeited/canceled | (90 | ) |  | 67.97 |  |  |  |  |  |
| Unvested balance—December 31, 2016 | 1,375 |  |  | $ | 74.23 |  |  | 1.8 |  | $ | 133,081 |  |
| RSUs vested and expected to vest—December 31, 2016 | 1,288 |  |  | $ | 74.14 |  |  | 1.7 |  | $ | 124,683 |  |

[0001596532-17-000019:notes:91]
Employee Stock Purchase Plan Activities

[0001596532-17-000019:notes:92]
During the year ended December 31, 2016, we issued 256,223 shares at an average purchase price of $40.30 under our ESPP.  Shares available for future issuance under our ESPP, subsequent to the increase authorized by our board of directors, are approximately 2.2 million.

[0001596532-17-000019:notes:93]
Shares Available for Grant

[0001596532-17-000019:notes:94]
Early Exercise of Stock Options

[0001596532-17-000019:notes:95]
We have historically allowed our employees and directors to exercise options prior to vesting. Upon an "early exercise" of these options, the unvested shares acquired through the exercise become options subject to our repurchase right that lapse in accordance with the original option vesting schedule. Upon termination of employment prior to our repurchase rights lapsing in full, we have a right to repurchase the unvested shares at the original purchase price. The proceeds received from the early exercise of stock options and are initially recorded in other liabilities and are reclassified to common stock and paid-in capital as our repurchase right lapse. For the year ended December 31, 2016, we repurchased 5,364 shares of common stock at the original exercise price due to the termination of the holders of the unvested shares. As of December 31, 2016, early exercised shares subject to repurchase were 0.3 million, with an aggregate value of $1.3 million.

[0001596532-17-000019:notes:96]
Stock-Based Compensation Expense

[0001596532-17-000019:notes:97]
Total stock-based compensation expense related to options, RSAs, ESPP and RSUs granted were charged to the department to which the associated employee reported as follow (in thousands):

[0001596532-17-000019:notes:98]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Cost of revenue | $ | 3,620 |  |  | $ | 3,048 |  |  | $ | 1,535 |  |
| Research and development | 31,892 |  |  | 25,515 |  |  | 14,986 |  |
| Sales and marketing | 15,666 |  |  | 11,454 |  |  | 7,643 |  |
| General and administrative | 7,854 |  |  | 5,286 |  |  | 3,455 |  |
| Total stock-based compensation | $ | 59,032 |  |  | $ | 45,303 |  |  | $ | 27,619 |  |

[0001596532-17-000019:notes:99]
Determination of Fair Value

[0001596532-17-000019:notes:100]
We record stock-based compensation awards based on fair value as of the grant date. For option awards and ESPP offerings we use the Black-Scholes-Merton option-pricing model to determine fair value. We recognize such costs as compensation expense generally on a straight-line basis over the requisite service period of the award.

[0001596532-17-000019:notes:101]
Stock Options

[0001596532-17-000019:notes:102]
For the years ended December 31, 2016, 2015 and 2014 the fair value of each stock option granted under our plans was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions and fair value per share:

[0001596532-17-000019:notes:103]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Expected term (in years) | 6.7 |  |  | 6.2 |  |  | 7.6 |  |
| Risk-free interest rate | 1.5 | % |  | 1.6 | % |  | 2.2 | % |
| Expected volatility | 38.9 | % |  | 42.9 | % |  | 47.7 | % |
| Dividend rate | — | % |  | — | % |  | — | % |

[0001596532-17-000019:notes:104]
As of December 31, 2016, the total unrecognized stock-based compensation expense for unvested stock options, net of expected forfeitures, was $87.4 million, which is expected to be recognized over a weighted-average period of 3.7 years. The total fair value of options vested for the year ended December 31, 2016 was $28.6 million.

[0001596532-17-000019:notes:105]
As of December 31, 2016, there was $87.6 million of unrecognized stock-based compensation expense related to unvested RSUs, net of estimated forfeitures. This amount is expected to be recognized over a weighted-average period of 3.4 years.

[0001596532-17-000019:notes:106]
ESPP

[0001596532-17-000019:notes:107]
The following table summarizes the assumptions relating to our ESPP:

[0001596532-17-000019:notes:108]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Expected term (in years) | 1.2 |  |  | 1.4 |  |  | 1.4 |  |
| Risk-free interest rate | 0.6 | % |  | 0.3 | % |  | 0.3 | % |
| Expected volatility | 31.8 | % |  | 34.8 | % |  | 36.3 | % |
| Dividend rate | — | % |  | — |  |  | — |  |

[0001596532-17-000019:notes:109]
As of December 31, 2016, the total unrecognized stock-based compensation expense related to unvested ESPP options, net of expected forfeitures, was $4.2 million, which is expected to be recognized over a weighted-average period of 1.5 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001596532-17-000019:notes:110]
Basic and diluted net income per share attributable to common stockholders is calculated in conformity with the two-class method required for participating securities. Our shares of common stock subject to repurchase are considered participating securities.  In addition, our convertible preferred stock prior to conversion to common shares upon our initial public offering in June 2014, were also considered to be participating securities. Under the two-class method, net income attributable to common stockholders is calculated as net income less earnings attributable to participating securities. In computing diluted net income attributable to common stockholders, undistributed earnings are re-allocated to reflect the potential impact of dilutive securities. Basic net income per common share is computed by dividing the net income attributable to common stockholders by the weighted-average number of common shares outstanding during the period. Diluted net income per share attributable to common stockholders is computed by dividing the net income attributable to common stockholders by the weighted-average number of common shares outstanding, including potential dilutive common shares assuming the dilutive effect of outstanding stock options, restricted stock units, and employee stock purchase plan using the treasury stock method. For purposes of this calculation, these amounts are excluded from the calculation of diluted net income per share of common stock if their effect is antidilutive.


## us-gaap:EarningsPerShareTextBlock

[0001596532-17-000019:notes:111]
Net Income Per Share Available to Common Stock

[0001596532-17-000019:notes:112]
The following table sets forth the computation of our basic and diluted net income per share available to common stock (in thousands, except per share amounts):

[0001596532-17-000019:notes:113]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Numerator: |  |  |  |  |  |
| Basic: |  |  |  |  |  |
| Net income | $ | 184,189 |  |  | $ | 121,102 |  |  | $ | 86,850 |  |
| Less: undistributed earnings allocated to participating securities | (1,224 | ) |  | (1,987 | ) |  | (17,961 | ) |
| Net income available to common stockholders, basic | $ | 182,965 |  |  | $ | 119,115 |  |  | $ | 68,889 |  |
| Diluted: |  |  |  |  |  |
| Net income attributable to common stockholders, basic | $ | 182,965 |  |  | $ | 119,115 |  |  | $ | 68,889 |  |
| Add: undistributed earnings allocated to participating securities | 74 |  |  | 149 |  |  | 1,635 |  |
| Net income attributable to common stockholders, diluted | $ | 183,039 |  |  | $ | 119,264 |  |  | $ | 70,524 |  |
| Denominator: |  |  |  |  |  |
| Basic: |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 68,771 |  |  | 65,964 |  |  | 48,427 |  |
| Diluted: |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 68,771 |  |  | 65,964 |  |  | 48,427 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |
| Stock options, RSUs and RSAs | 4,408 |  |  | 5,363 |  |  | 6,059 |  |
| Employee stock purchase plan | 43 |  |  | 84 |  |  | 104 |  |
| Stock purchase rights | — |  |  | — |  |  | — |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted | 73,222 |  |  | 71,411 |  |  | 54,590 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |
| Basic | $ | 2.66 |  |  | $ | 1.81 |  |  | $ | 1.42 |  |
| Diluted | $ | 2.50 |  |  | $ | 1.67 |  |  | $ | 1.29 |  |

[0001596532-17-000019:notes:114]
The following outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share available to common stockholders for the periods presented because including them would have been anti-dilutive (in thousands):

[0001596532-17-000019:notes:115]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Stock options and RSUs to purchase common stock | 2,594 |  |  | 2,427 |  |  | 1,263 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-17-000019:notes:116]
We measure and report our cash equivalents, restricted cash, and available-for-sale marketable securities at fair value. The following table set forth the fair value of our financial assets by level within the fair value hierarchy (in thousands):

[0001596532-17-000019:notes:117]
|  | December 31, 2016 |
|  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 305,182 |  |  | $ | — |  |  | $ | — |  |  | $ | 305,182 |  |
| Money market funds-restricted | 4,245 |  |  | — |  |  | — |  |  | 4,245 |  |
| Commercial Paper | 5,962 |  |  | — |  |  | — |  |  | 5,962 |  |
| U.S. government notes | 110,756 |  |  | — |  |  | — |  |  | 110,756 |  |
| Corporate bonds | — |  |  | 183,192 |  |  | — |  |  | 183,192 |  |
| Total financial assets | $ | 426,145 |  |  | $ | 183,192 |  |  | $ | — |  |  | $ | 609,337 |  |

[0001596532-17-000019:notes:118]
|  | December 31, 2015 |
|  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 104,156 |  |  | $ | — |  |  | $ | — |  |  | $ | 104,156 |  |
| U.S. government notes | 4,041 |  |  | — |  |  | — |  |  | 4,041 |  |
| Total financial assets | $ | 108,197 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,197 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-17-000019:notes:119]
Fair Value Measurements


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001596532-17-000019:notes:120]
Fair value is defined as the exchange price that would be received for an asset or an exit price that would be paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. These assets and liabilities include cash and cash equivalents, marketable securities, accounts receivable, accounts payable, and accrued liabilities. Cash equivalents, accounts receivable, accounts payable and accrued liabilities are stated at carrying amounts as reported in the consolidated financial statements, which approximates fair value due to their short-term nature.

[0001596532-17-000019:notes:121]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value.  We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs.  The three-tiers of the fair value hierarchy are as follows:

[0001596532-17-000019:notes:122]
Level I—Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date;

[0001596532-17-000019:notes:123]
Level II—Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities; and

[0001596532-17-000019:notes:124]
Level III—Unobservable inputs that are supported by little or no market data for the related assets or liabilities and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001596532-17-000019:notes:125]
The functional currency of our foreign subsidiaries is either the U.S. dollar or their local currency.

[0001596532-17-000019:notes:126]
Transaction re-measurement-Assets and liabilities denominated in a currency other than the foreign subsidiaries’ functional currency are re-measured into the functional currency using exchange rates in effect at the end of the reporting period, with gains and losses recorded in other income (expense), net in the consolidated statements of income. We recognized$0.7 million, $0.5 million, and $0.6 million, in transaction losses for the years ended December 31, 2016, 2015 and 2014, respectively.

[0001596532-17-000019:notes:127]
Translation-Assets and liabilities of subsidiaries denominated in foreign functional currencies are translated into U.S. dollars at the closing exchange rate on the balance sheet date and equity related balances are translated at historical exchange rates.  Revenues, costs and expenses in foreign functional currencies are translated using average exchange rates that approximate those in effect during the period. Translation adjustments are accumulated as a separate component of accumulated other comprehensive income within stockholders’ equity.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001596532-17-000019:notes:128]
The carrying amounts of our long-lived assets, including property and equipment and investments in privately held companies, are periodically reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. Recoverability of these assets is measured by comparison of the carrying amount of each asset to the future undiscounted cash flows the asset is expected to generate over their remaining lives. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-17-000019:notes:129]
Income Taxes

[0001596532-17-000019:notes:130]
The geographical breakdown of income before provision for income taxes is as follows (in thousands):

[0001596532-17-000019:notes:131]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Domestic | $ | 196,202 |  |  | $ | 129,240 |  |  | $ | 120,838 |  |
| Foreign | 46,023 |  |  | 16,769 |  |  | 670 |  |
| Income before provision for income taxes | $ | 242,225 |  |  | $ | 146,009 |  |  | $ | 121,508 |  |

[0001596532-17-000019:notes:132]
The components of the provision for income taxes are as follows (in thousands):

[0001596532-17-000019:notes:133]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Current provision for income taxes: |  |  |  |  |  |
| Federal | $ | 67,253 |  |  | $ | 43,706 |  |  | $ | 34,314 |  |
| State | 10,529 |  |  | 5,500 |  |  | 4,493 |  |
| Foreign | 2,016 |  |  | 1,588 |  |  | 3,306 |  |
| Total current | 79,798 |  |  | 50,794 |  |  | 42,113 |  |
| Deferred tax benefit: |  |  |  |  |  |
| Federal | (18,579 | ) |  | (23,896 | ) |  | (7,105 | ) |
| State | (3,564 | ) |  | (2,300 | ) |  | 230 |  |
| Foreign | 381 |  |  | 309 |  |  | (580 | ) |
| Total deferred | (21,762 | ) |  | (25,887 | ) |  | (7,455 | ) |
| Total provision for income taxes | $ | 58,036 |  |  | $ | 24,907 |  |  | $ | 34,658 |  |

[0001596532-17-000019:notes:134]
The reconciliation of the statutory federal income tax and our effective income tax is as follows:

[0001596532-17-000019:notes:135]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| U.S. federal statutory income tax | 35.00 | % |  | 35.00 | % |  | 35.00 | % |
| State tax, net of federal benefit | (0.03 | ) |  | (1.35 | ) |  | 1.19 |  |
| Foreign tax differential | (3.24 | ) |  | (2.16 | ) |  | 0.68 |  |
| Tax credits | (4.24 | ) |  | (6.72 | ) |  | (5.26 | ) |
| Change in valuation allowance | 1.71 |  |  | 2.84 |  |  | 1.92 |  |
| Permanent items | (1.02 | ) |  | (1.32 | ) |  | (0.86 | ) |
| Uncertain tax positions and associated interest | (1.46 | ) |  | (3.95 | ) |  | 0.37 |  |
| Stock-based compensation | (2.81 | ) |  | (5.29 | ) |  | (4.01 | ) |
| Other, net | 0.05 |  |  | 0.01 |  |  | (0.51 | ) |
| Total provision for income taxes | 23.96 | % |  | 17.06 | % |  | 28.52 | % |

[0001596532-17-000019:notes:136]
We have operations and a taxable presence in numerous jurisdictions outside the U.S. All of these countries except one jurisdiction have a lower tax rate than the U.S. The significant jurisdictions in which we have a presence include Cayman Islands, Ireland, and the United Kingdom.

[0001596532-17-000019:notes:137]
The tax effects of temporary differences that give rise to significant portions of deferred tax assets (liabilities) are as follows (in thousands):

[0001596532-17-000019:notes:138]
|  | December 31, |
|  | 2016 |  | 2015 |
| Deferred tax assets: |  |  |  |
| Property and equipment | $ | 473 |  |  | $ | 241 |  |
| Stock-based compensation | 23,071 |  |  | 15,859 |  |
| Reserves and accruals not currently deductible | 49,436 |  |  | 33,686 |  |
| Net operating losses | 1,140 |  |  | 221 |  |
| Tax credits | 15,015 |  |  | 12,465 |  |
| State taxes | — |  |  | 9 |  |
| Other | 194 |  |  | 380 |  |
| Gross deferred tax assets | 89,329 |  |  | 62,861 |  |
| Valuation allowance | (16,894 | ) |  | (12,655 | ) |
| Total deferred tax assets | 72,435 |  |  | 50,206 |  |
| Deferred tax liabilities: |  |  |  |
| Property and equipment | (198 | ) |  | (1,517 | ) |
| Accrued liabilities | (2,555 | ) |  | (728 | ) |
| Other | (3 | ) |  | (1 | ) |
| Total deferred tax liabilities | (2,756 | ) |  | (2,246 | ) |
| Net deferred tax assets | $ | 69,679 |  |  | $ | 47,960 |  |

[0001596532-17-000019:notes:139]
The following table presents the breakdown between non-current deferred tax assets and liabilities (in thousands):

[0001596532-17-000019:notes:140]
|  | December 31, |
|  | 2016 |  | 2015 |
| Deferred tax assets, non-current | 70,960 |  |  | 48,429 |  |
| Deferred tax liabilities, non-current | (1,281 | ) |  | (469 | ) |
| Total net deferred tax assets | $ | 69,679 |  |  |  | $47,960 |  |

[0001596532-17-000019:notes:141]
Recognition of deferred tax assets is appropriate when realization of these assets is more likely than not. We believe that all of the deferred tax assets were realizable with the exception of California and Canada deferred tax assets. Therefore, a valuation allowance of $16.9 million and $12.7 million was recorded as of December 31, 2016 and 2015, respectively, against the California and Canadian deferred tax assets as it was not more likely than not that these assets will be recognized. The net valuation allowance increased by $4.2 million and $3.7 million as of December 31, 2016 and 2015, respectively.

[0001596532-17-000019:notes:142]
As of December 31, 2016, we had no net operating loss carryforwards for federal and state income tax purposes. For foreign jurisdictions, we had combined foreign net operating loss carryforwards of $17.2 million which do not expire.

[0001596532-17-000019:notes:143]
As of December 31, 2016, we had no U.S. federal credit carryforwards and state credit carryforwards of $39.2 million, which can be carried over indefinitely.  For foreign jurisdictions, we had $1.1 million of Canadian scientific research and experimental development tax credit carry-forwards, which begin to expire in 2034.

[0001596532-17-000019:notes:144]
Utilization of the net operating losses and tax credit carryforwards may be subject to limitations due to ownership changes limitations provided in the Internal Revenue code and similar state or foreign provisions. In all years up to December 31, 2016, such limitations had no impact to our deferred tax assets.

[0001596532-17-000019:notes:145]
Our policy with respect to our undistributed foreign subsidiaries earnings is to consider those earnings to be indefinitely reinvested and, accordingly, no related provision for U.S. federal and state income taxes has been provided. Upon distribution of those earnings’ in the form of dividends or otherwise, we may be subject to both U.S. income taxes (subject to an adjustment for foreign tax credits) and withholding taxes in the various countries. As of December 31, 2016, 2015 and 2014, the undistributed earnings approximated $36.4 million, $16.4 million and $4.9 million, respectively. The determination of the future tax consequences of the remittance of these earnings is not practicable.

[0001596532-17-000019:notes:146]
Uncertain Tax Positions

[0001596532-17-000019:notes:147]
We recognize uncertain tax positions only to the extent that management believes that it is more likely than not the position will be sustained. The reconciliation of the beginning and ending amount of gross unrecognized tax benefits as of December 31, 2016, 2015 and 2014 was as follows (in thousands):

[0001596532-17-000019:notes:148]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Gross unrecognized tax benefits—beginning balance | $ | 22,239 |  |  | $ | 21,322 |  |  | $ | 16,973 |  |
| Increases related to tax positions taken in a prior year | 46 |  |  | 346 |  |  | 425 |  |
| Increases related to tax positions taken during current year | 11,359 |  |  | 7,385 |  |  | 4,355 |  |
| Decreases related to tax positions taken in a prior year | (426 | ) |  | (228 | ) |  | (431 | ) |
| Decreases related to settlements with taxing authorities | (432 | ) |  | — |  |  | — |  |
| Decreases related to lapse of statute of limitations | (5,871 | ) |  | (6,586 | ) |  | — |  |
| Gross unrecognized tax benefits—ending balance | $ | 26,915 |  |  | $ | 22,239 |  |  | $ | 21,322 |  |

[0001596532-17-000019:notes:149]
As of December 31, 2016, 2015 and 2014 the total amount of gross unrecognized tax benefits was $26.9 million, $22.2 million and $21.3 million of which $13.9 million, $13.0 million and $15.8 million would affect our effective tax rate if recognized, respectively.

[0001596532-17-000019:notes:150]
Our policy is to recognize interest and penalties accrued on any unrecognized tax benefits as a component of income tax expense. We have recorded a net benefit for interest and penalties of $0.5 million and net expense of $0.4 million in the years ended December 31, 2016 and 2015, respectively. As of December 31, 2016 and 2015, we recognized a liability for interest and penalties of $0.6 million and $1.1 million, respectively.

[0001596532-17-000019:notes:151]
We have been selected for examination by the Internal Revenue Service ("IRS") for our 2013 and 2014 tax years.  It is difficult to determine when the examinations will be settled or their final outcomes in the foreseeable future. We believe that we have adequately provided reserves for any reasonably foreseeable adjustment to our tax returns.

[0001596532-17-000019:notes:152]
The statute of limitations for Federal remains open for 2013 and forward.  Because of the net operating loss and tax credit carryforwards, all tax years remain open to state tax examination. The majority of our foreign tax returns are open to audit under the statute of limitations of the respective foreign countries, in which the subsidiaries are located. It is possible that the amount of existing unrecognized tax benefits may decrease within the next 12 months as a result of statute of limitation lapses in some of the jurisdictions, however, an estimate of the range cannot be made.


## us-gaap:IncomeTaxPolicyTextBlock

[0001596532-17-000019:notes:153]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-17-000019:notes:154]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-17-000019:notes:155]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-17-000019:notes:156]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.


## us-gaap:InventoryPolicyTextBlock

[0001596532-17-000019:notes:157]
Inventories primarily consist of finished goods purchased from third party contract manufacturers and are stated at the lower of cost (computed using the first-in, first-out method) or market value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancelable, including integrated circuits, which are held by our contract manufacturers.  We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value.  We also record a liability for non-cancelable, non-returnable purchase commitments with our component inventory suppliers for quantities in excess of our demand forecasts or that are considered obsolete.

[0001596532-17-000019:notes:158]
Our contract manufacturers procure components and assemble products on our behalf based on our forecasts.  We generally incur a liability when the contract manufacturer has converted the component inventory to a finished product.  Historically, we have recorded a liability and have reimbursed our contract manufacturer for component inventory that has been rendered excess or obsolete due to manufacturing and engineering change orders resulting from design changes, or in cases where inventory levels greatly exceed our forecasts.

[0001596532-17-000019:notes:159]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer liabilities.


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-17-000019:notes:160]
Investments

[0001596532-17-000019:notes:161]
Investments in Privately Held Companies

[0001596532-17-000019:notes:162]
As of December 31, 2016 and 2015, we held non-marketable equity investments of approximately $36.1 million and $33.6 million, respectively, in privately held companies which are accounted for under the cost method.  During the year ended 2016 we made an additional investment of $2.5 million in one of these companies.  To date, we have not recognized any impairment losses on our investments.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-17-000019:notes:163]
In May 2014, the FASB issued ASU No. 2014-09, Revenue From Contracts With Customers (Topic 606), (as amended in June 2016, by ASU No. 2016-12-Revenue-Narrow-Scope Improvements and Practical Expedients), which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition.

[0001596532-17-000019:notes:164]
In July 2015, the FASB issued ASU No. 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, deferring the effective date of the new revenue standard by one year. In March 2016, the FASB issued ASU No. 2016-08, Revenue From Contracts With Customers-Principal versus Agent Considerations (Reporting Revenue Gross versus Net), and ASU No. 2016-10, Revenue From Contracts With Customers-Identifying Performance Obligations and Licensing. ASU No. 2016-08 clarifies the implementation guidance regarding principal versus agent identification and related considerations. Specifically, the guidance provides clarification around performance obligations for goods or services provided by another entity, assisting in determining whether the entity is the provider of the goods or services, the principal, or whether the entity is providing for the arrangement of the goods or services, the agent.  ASU No. 2016-10 provides guidance around identifying whether promised goods or services are distinct and separately identifiable, whether promised goods or services are material or immaterial to the contract, and whether shipping and handling is considered an activity to fulfill a promise or an additional promised service. ASU No. 2016-10 also provides guidance around an entity's promise to grant a license providing a customer with either a right to use or a right to access the license, which then determines whether the obligation is satisfied at a point in time or over time, respectively.

[0001596532-17-000019:notes:165]
In May 2016, the FASB issued ASU No. 2016-11, Revenue Recognition (Topic 605) and Derivatives and Hedging (Topic 815): Rescission of SEC Guidance Because of Accounting Standards Updates 2014-09 and 2014-16 Pursuant to Staff Announcements at the March 3, 2016 EITF Meeting (SEC Update)") ("ASU 2016-11"), which rescinds various standards codified as part of Topic 605, Revenue Recognition in relation to the future adoption of Topic 606. These rescissions include changes to topics pertaining to revenue and expense recognition including accounting for shipping and handling fees and costs and accounting for consideration given by a vendor to a customer.

[0001596532-17-000019:notes:166]
The above standards are effective for fiscal years (and interim reporting periods within those years) beginning after December 15, 2017.  The guidance is effective for us beginning in our first quarter of fiscal 2018. Early adoption would be permitted for all entities but not until the fiscal year beginning after December 15, 2016. The standard permits the use of either the retrospective or cumulative effect transition method. The retrospective method requires a retrospective approach to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance. The cumulative approach requires a retrospective approach with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance.

[0001596532-17-000019:notes:167]
Management’s assessments of potential impacts of the standards are underway. The standards are expected to impact the amount and timing of revenue recognized and the related disclosures on our consolidated financial statements.

[0001596532-17-000019:notes:168]
We will adopt ASU 2014-09 during the first quarter of 2018 and expect to adopt the guidance under the modified retrospective method which we anticipate will result in a cumulative effect adjustment as of the date of adoption.

[0001596532-17-000019:notes:169]
In January 2016, the FASB issued ASU No, 2016-01, Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities, which enhances the reporting model for financial instruments to provide users of financial statements with more decision-useful information. The guidance will address certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. The standard is effective for us for our first quarter of fiscal 2018.  The guidance may be early adopted under early application guidance. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

[0001596532-17-000019:notes:170]
In February 2016, the FASB issued ASU No, 2016-02, Leases, which addresses the classification and recognition of lease assets and liabilities formerly classified as operating leases under GAAP. The guidance will address certain aspects of recognition and measurement, and quantitative and qualitative aspects of presentation and disclosure. The guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. The standard is effective for us for our first quarter of fiscal 2019.  The guidance will be applied to the earliest period presented using a modified retrospective approach. The guidance includes practical expedients that relate to identification, classification, and initial direct costs associated with leases commencing prior to the effective date, and the ability to apply hindsight in evaluating lease options related to extensions, terminations or asset purchases.  A practical expedient also exists to treat leases entered into prior effective date under existing GAAP unless the lease has been modified. The guidance may be early adopted. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

[0001596532-17-000019:notes:171]
In March 2016, the FASB amended the existing accounting standards for stock-based compensation, ASU 2016-09, Compensation-Stock Compensation: Improvements to Employee Share-Based Payment Accounting, which impact several aspects of accounting for share-based payment transactions, including the income tax consequences, forfeitures, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The standard is effective for us for our first quarter of fiscal 2017.  The manner of application varies by the various provisions of the guidance, with certain provisions applied on a retrospective or modified retrospective approach, while others are applied prospectively.

[0001596532-17-000019:notes:172]
Based on our assessment of the above standard, guidance related to forfeitures will be adopted under a modified retrospective transition method and a cumulative adjustment to beginning retained earnings will be recorded on the day of adoption.  Effective January 1, 2017, we will account for forfeitures as they occur and will calculate a cumulative adjustment as it relates to equity transactions where prior forfeitures rates have previously and cumulatively been applied.

[0001596532-17-000019:notes:173]
With the adoption of ASU 2016-09, we will prospectively record excess tax benefits generated from stock option exercises and other equity awards as a provision to income tax in the income statement, rather than equity.  In addition, we will apply the guidance under a modified retrospective transition method and account for previously unrecognized excess tax benefits through a cumulative-effect adjustment to beginning retained earnings.

[0001596532-17-000019:notes:174]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Task Force), which addresses eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. The guidance may be adopted early as of the beginning of an annual reporting period.  The guidance will be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  The standard is effective for us for our first quarter of fiscal 2018.  We are currently assessing the impact this guidance may have on our consolidated financial statements.

[0001596532-17-000019:notes:175]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which addresses recognition of current and deferred income taxes for intra-entity asset transfers when assets are sold to an outside party. Current GAAP prohibits the recognition of current and deferred income taxes until the asset has been sold to an outside party. This prohibition on recognition is considered an exception to the principle of comprehensive recognition of current and deferred income taxes in GAAP.  The new guidance requires an entity to recognize the income tax consequences when the transfer occurs eliminating the exception.  The guidance will be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  The standard is effective for us for our first quarter of fiscal 2018, and may be early adopted under early application guidance.  We are currently assessing the impact this guidance may have on our consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-17-000019:notes:176]
Organization and Summary of Significant Accounting Policies

[0001596532-17-000019:notes:177]
Organization

[0001596532-17-000019:notes:178]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our” or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System, a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switching and routing platforms. We were incorporated in October 2004 in the State of California under the name Arastra, Inc. In March 2008, we reincorporated in the State of Nevada and in October 2008 changed our name to Arista Networks, Inc. We reincorporated in the state of Delaware in March 2014. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-17-000019:notes:179]
Basis of Presentation and Principles of Consolidation

[0001596532-17-000019:notes:180]
During fiscal 2015 and 2014, certain reclassifications of prior period amounts were made to conform to the current period presentation. There were no reclassifications during fiscal 2016.

[0001596532-17-000019:notes:181]
Use of Estimates

[0001596532-17-000019:notes:182]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts and sales return reserve; determination of fair value for stock-based awards; accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; valuation of inventory; valuation of warranty accruals; contract manufacturing liabilities; and recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.

[0001596532-17-000019:notes:183]
Concentrations of Business and Credit Risk

[0001596532-17-000019:notes:184]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, marketable securities, restricted cash, and accounts receivable. Our cash, cash equivalents and restricted cash are invested in high quality financial instruments with banks and financial institutions. Such deposits may be in excess of insured limits provided on such deposits.

[0001596532-17-000019:notes:185]
Our accounts receivable are unsecured and represent amounts due to us based on contractual obligations of our customers. We mitigate credit risk in respect to accounts receivable by performing ongoing credit evaluations of our customers to assess the probability of accounts receivable collection based on a number of factors, including past transaction experience with the customer, evaluation of their credit history, the credit limits extended and review of the invoicing terms of the arrangement. In situations where a customer may be thinly capitalized and we have limited payment history with it, we will either establish a small credit limit or require it to prepay its purchases. We generally do not require our customers to provide collateral to support accounts receivable. We have recorded an allowance for doubtful accounts for those receivables that we have determined not to be collectible. We mitigate credit risk in respect to the notes receivable by performing ongoing credit evaluations of the borrower to assess the probability of collecting all amounts due to us under the existing contractual terms.

[0001596532-17-000019:notes:186]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators and original equipment manufacturer (“OEM”) partners and in conjunction with various technology partners.  Significant customers are those which represent more than 10% of our total net revenue during the period or net accounts receivable balance at each respective balance sheet date. For each significant customer, revenue as a percentage of total revenue and accounts receivable as a percentage of total accounts receivable are as follows:

[0001596532-17-000019:notes:187]
|  |  | Revenue |  | Accounts Receivable |
|  |  | Year Ended December 31, |  | December 31, |
|  |  | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |
| Customer A |  | 16 | % |  | 12 | % |  | 15 | % |  | 36 | % |  | 30 | % |

[0001596532-17-000019:notes:188]
Comprehensive Income

[0001596532-17-000019:notes:189]
Cash and Cash Equivalents

[0001596532-17-000019:notes:190]
We consider all highly liquid investments with stated maturity of three months or less at the time of purchase to be cash equivalents. Cash and cash equivalents consist of cash on deposit with various financial institutions and highly liquid investments in money market funds. Interest is accrued as earned. We have restricted cash pledged as collateral representing a security deposit required for a facility lease. As of December 31, 2016 and 2015, we had classified the restricted cash of $4.2 million and $4.0 million, respectively, as other assets in our accompanying consolidated balance sheet.

[0001596532-17-000019:notes:191]
Marketable Securities

[0001596532-17-000019:notes:192]
We classify all highly liquid investments with stated maturities of greater than three months as marketable securities. We determine the appropriate classification of our investments in marketable securities at the time of purchase and reevaluate such designation at each balance sheet date. We have classified and accounted for our marketable securities as available-for-sale. We may or may not hold securities with stated maturities greater than 12 months until maturity. After consideration of our risk versus reward objectives, as well as our liquidity requirements, we may sell these securities prior to their stated maturities. As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying consolidated balance sheets. We carry these securities at fair value, and report the unrealized gains and losses, net of taxes, as a component of stockholders’ equity, except for unrealized losses determined to be other-than-temporary, which we record as other income (expense), net. We determine any realized gains or losses on the sale of marketable securities on a specific identification method, and we record such gains and losses as a component of interest and other income, net.

[0001596532-17-000019:notes:193]
Accounts Receivable

[0001596532-17-000019:notes:194]
Accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts, and sales return reserves. We estimate our allowance for doubtful accounts based upon the collectability of the receivables in light of historical trends, adverse situations that may affect our customers’ ability to pay and prevailing economic conditions. This evaluation is done in order to identify issues which may impact the collectability of receivables and related estimated required allowance. Revisions to the allowance are recorded as an adjustment to bad debt expense. After appropriate collection efforts are exhausted, specific accounts receivable deemed to be uncollectible are charged against the allowance in the period they are deemed uncollectible. Recoveries of accounts receivable previously written-off are recorded as credits to bad debt expense. We estimate our sales return reserves based on historical return rates applied against current period gross revenues. Specific customer returns and allowances are considered when determining our sales return reserve estimate. Revisions to the reserve are recorded as adjustments to revenue and the sales return reserves.

[0001596532-17-000019:notes:195]
Foreign Currency

[0001596532-17-000019:notes:196]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-17-000019:notes:197]
For the years ended December 31, 2016, 2015 and 2014, we recorded inventory write-downs of $12.1 million, $9.0 million and $2.8 million, respectively.  In addition, our contract manufacturer and supplier liabilities totaled $6.3 million and $3.8 million as of December 31, 2016 and 2015, respectively.

[0001596532-17-000019:notes:198]
Property and Equipment

[0001596532-17-000019:notes:199]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is calculated using the straight-line method over the estimated useful lives of the related assets, generally from one to five years.  Our building is depreciated over 30 years and leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term. The leased building under our build to suit lease is capitalized and included in property and equipment as we were involved in the construction funding and did not meet the “sale-leaseback” criteria.

[0001596532-17-000019:notes:200]
Our investments in privately held companies are accounted for under the cost method and are included in investments, non-current in the accompanying consolidated balance sheets. Our investments under the cost method are recorded at historical cost at the time of investment.

[0001596532-17-000019:notes:201]
Impairment of Long-Lived Assets and Investments

[0001596532-17-000019:notes:202]
The carrying amounts of our long-lived assets, including property and equipment and investments in privately held companies, are periodically reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. Recoverability of these assets is measured by comparison of the carrying amount of each asset to the future undiscounted cash flows the asset is expected to generate over their remaining lives. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. No impairment of any long-lived assets or investments was identified for any of the periods presented.

[0001596532-17-000019:notes:203]
Loss Contingencies

[0001596532-17-000019:notes:204]
Revenue Recognition

[0001596532-17-000019:notes:205]
We generate revenue from sales of our products which incorporate our EOS software and accessories such as cables and optics to direct customers and channel partners together with post contract customer support (“PCS”). We typically sell products and PCS in a single transaction. We recognize revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery or performance has occurred; the sales price is fixed or determinable; and collectability is reasonably assured.

[0001596532-17-000019:notes:206]
We define each of the four criteria above as follows:

[0001596532-17-000019:notes:207]
| • | Persuasive evidence of an arrangement exists. Evidence of an arrangement consists of stand-alone purchase orders or purchase orders issued pursuant to the terms and conditions of a master sales agreement. It is our practice to identify an end customer prior to shipment to a reseller or distributor. |

[0001596532-17-000019:notes:208]
| • | Delivery or performance has occurred. We use shipping documents or written evidence of customer acceptance, when applicable, to verify delivery or performance. We recognize product revenue upon transfer of title and risk of loss, which primarily is upon shipment to customers. We generally do not have significant obligations for future performance, rights of return or pricing credits associated with our product sales. In instances where substantive acceptance provisions are specified in the customer arrangement, revenue and the related cost of revenue is deferred until all acceptance criteria have been met. |

[0001596532-17-000019:notes:209]
| • | The sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on payment terms and whether the sales price is subject to refund or adjustment. |

[0001596532-17-000019:notes:210]
| • | Collectability is reasonably assured. We assess probability of collectability on a customer-by-customer basis. Our customers and channel partners are subjected to a credit review process that evaluates their financial condition and ability to pay for products and services. |

[0001596532-17-000019:notes:211]
PCS is offered under renewable, fee-based contracts, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis. We initially defer PCS revenue and recognize it ratably over the life of the PCS contract, with the related expenses recognized as incurred. PCS contracts usually have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-17-000019:notes:212]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of goods sold.

[0001596532-17-000019:notes:213]
Multiple-Element Arrangements

[0001596532-17-000019:notes:214]
Most of our arrangements, other than renewals of PCS, are multiple element arrangements with a combination of products and PCS. Products and PCS generally qualify as separate units of accounting. Our hardware deliverables include EOS software, which together deliver the essential functionality of our products. For multiple element arrangements, we allocate revenue to each unit of accounting based on the relative selling price. The relative selling price for each element is based upon the following hierarchy: vendor-specific objective evidence (“VSOE”), if available; third-party evidence (“TPE”), if VSOE is not available; and best estimate of selling price (“BESP”), if neither VSOE nor TPE is available. As we have not been able to establish VSOE or TPE for our products and most of our services, we generally utilize BESP for the purposes of allocating revenue to each unit of accounting.

[0001596532-17-000019:notes:215]
| • | VSOE—We determine VSOE based on our historical pricing and discounting practices for the specific products and services when sold separately. In determining VSOE, we require that a substantial majority of the stand-alone selling prices fall within a reasonably narrow pricing range. |

[0001596532-17-000019:notes:216]
| • | TPE—When VSOE cannot be established for deliverables in multiple-element arrangements, we apply judgment with respect to whether we can establish a selling price based on TPE. TPE is determined based on competitor prices for interchangeable products or services when sold separately to similarly situated customers. However, as our products contain a significant element of proprietary technology and offer substantially different features and functionality, the comparable pricing of products with similar functionality typically cannot be obtained. Additionally, as we are unable to reliably determine what competitors products’ selling prices are on a stand-alone basis, we are not able to obtain reliable evidence of TPE of selling price. |

[0001596532-17-000019:notes:217]
| • | BESP—When we are unable to establish selling price using VSOE or TPE, we use BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service was sold regularly on a stand-alone basis. BESP is based on considering multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services were sold (domestic or international) and size of the end customer. |

[0001596532-17-000019:notes:218]
We limit the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations, or subject to customer-specific return, acceptance or refund privileges.

[0001596532-17-000019:notes:219]
We account for multiple agreements with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single arrangement.

[0001596532-17-000019:notes:220]
We may occasionally accept returns to address customer satisfaction issues even though there is no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period gross revenues. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-17-000019:notes:221]
Research and Development Expenses

[0001596532-17-000019:notes:222]
Costs related to the research, design and development of our products are charged to research and development expenses as incurred. Software development costs are capitalized beginning when a product’s technological feasibility has been established and ending when the product is available for general release to customers. Generally, our products are released soon after technological feasibility has been established. As a result, costs incurred subsequent to achieving technological feasibility have not been significant and accordingly, all software development costs have been expensed as incurred.

[0001596532-17-000019:notes:223]
Warranty

[0001596532-17-000019:notes:224]
We offer a one-year warranty on all of our hardware products and a 90-day warranty against defects in the software embedded in the products. We use judgment and estimates when determining warranty costs based on historical costs to replace product returns within the warranty period at the time we recognize revenue. We accrue for potential warranty claims at the time of shipment as a component of cost of revenues based on historical experience and other relevant information. We reserve for specifically identified products if and when we determine we have a systemic product failure. Although we engage in extensive product quality programs, if actual product failure rates or use of materials differ from estimates, additional warranty costs may be incurred, which could reduce our gross margin. The accrued warranty liability is recorded in accrued liabilities in the accompanying consolidated balance sheets.

[0001596532-17-000019:notes:225]
Post-Employment Benefits

[0001596532-17-000019:notes:226]
We have a 401(k) Plan that covers substantially all of our employees in the U.S. For the years ended December 31, 2016, 2015 and 2014, we did not provide a discretionary company match to employee contributions.  Effective January 1, 2017, we have elected to match 100% of employees' contributions up to a maximum of 3% of an employee's annual salary. Matching contributions will be immediately vested.

[0001596532-17-000019:notes:227]
Segment Reporting

[0001596532-17-000019:notes:228]
We develop, market and sell cloud networking solutions, which consist of our Gigabit Ethernet switches and related software. We have one business activity and there are no segment managers who are held accountable for operations or operating results below the Company level. Our chief operating decision maker is our Chief Executive Officer. Our Chief Executive Officer reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.  Accordingly, we have determined that we operate as one reportable segment.

[0001596532-17-000019:notes:229]
Stock-Based Compensation

[0001596532-17-000019:notes:230]
Compensation expense related to stock-based transactions, including stock options, restricted stock units ("RSUs"), restricted stock awards (“RSAs”), and stock purchase rights under our employee stock purchase program is measured and recognized in the financial statements based on the fair value of the equity granted, net of estimated forfeitures, on a straight-line basis over the requisite service periods of the awards, which typically ranges from two to five years.  Under ASU 2016-09, Compensation-Stock Compensation: Improvements to Employee Share-Based Payment Accounting, beginning the first quarter of fiscal 2017 we have elected to account for forfeitures as they occur and will no longer include an estimate of future forfeitures in the fair value measurement.

[0001596532-17-000019:notes:231]
Excess tax benefits associated with stock option exercises and other equity awards are recognized in additional paid in capital. The income tax benefits resulting from stock awards that were credited to stockholders' equity were $42.1 million, $37.0 million and $17.4 million, for the years ended December 31, 2016, 2015 and 2014, respectively.  With the adoption of ASU 2016-09, effective January 1, 2017 on a prospective basis, excess tax benefits generated from stock option exercises and other equity awards will be recorded as provision of income taxes in the income statement, rather than equity.

[0001596532-17-000019:notes:232]
Net Income per Share of Common Stock

[0001596532-17-000019:notes:233]
Recent Accounting Pronouncements


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001596532-17-000019:notes:234]
Property and equipment, net consists of the following (in thousands):

[0001596532-17-000019:notes:235]
|  | December 31, |
|  | 2016 |  | 2015 |
| Equipment and machinery | $ | 40,721 |  |  | $ | 29,101 |  |
| Computer hardware and software | 17,420 |  |  | 12,630 |  |
| Furniture and fixtures | 2,879 |  |  | 2,380 |  |
| Leasehold improvements | 29,498 |  |  | 24,372 |  |
| Building | 35,154 |  |  | 35,154 |  |
| Construction-in-process | 421 |  |  | 6,408 |  |
| Property and equipment, gross | 126,093 |  |  | 110,045 |  |
| Less: accumulated depreciation | (49,132 | ) |  | (30,339 | ) |
| Property and equipment, net | $ | 76,961 |  |  | $ | 79,706 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001596532-17-000019:notes:236]
Selected Quarterly Financial Information (Unaudited)

[0001596532-17-000019:notes:237]
The following tables set forth selected unaudited quarterly consolidated statements of income data for each of the quarters in the years ended December 31, 2016 and 2015:

[0001596532-17-000019:notes:238]
|  |  | Three Months Ended |
|  |  | Dec. 31, 2016 |  | Sep. 30, 2016 |  | Jun. 30, 2016 |  | Mar. 31, 2016 |  | Dec. 31, 2015 |  | Sep. 30, 2015 |  | Jun. 30, 2015 |  | Mar. 31, 2015 |
|  |  | (in thousands) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 289,008 |  |  | $ | 254,238 |  |  | $ | 235,616 |  |  | $ | 212,475 |  |  | $ | 217,325 |  |  | $ | 193,339 |  |  | $ | 174,072 |  |  | $ | 160,141 |  |
| Service |  | 38,961 |  |  | 36,023 |  |  | 33,125 |  |  | 29,721 |  |  | 28,121 |  |  | 24,209 |  |  | 21,480 |  |  | 18,904 |  |
| Total revenue |  | 327,969 |  |  | 290,261 |  |  | 268,741 |  |  | 242,196 |  |  | 245,446 |  |  | 217,548 |  |  | 195,552 |  |  | 179,045 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 108,057 |  |  | 94,777 |  |  | 88,021 |  |  | 78,913 |  |  | 81,142 |  |  | 67,990 |  |  | 60,014 |  |  | 54,439 |  |
| Service |  | 9,757 |  |  | 9,064 |  |  | 9,269 |  |  | 8,193 |  |  | 8,136 |  |  | 7,810 |  |  | 7,648 |  |  | 6,852 |  |
| Total cost of revenue |  | 117,814 |  |  | 103,841 |  |  | 97,290 |  |  | 87,106 |  |  | 89,278 |  |  | 75,800 |  |  | 67,662 |  |  | 61,291 |  |
| Gross profit |  | 210,155 |  |  | 186,420 |  |  | 171,451 |  |  | 155,090 |  |  | 156,168 |  |  | 141,748 |  |  | 127,890 |  |  | 117,754 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | 71,398 |  |  | 70,648 |  |  | 69,020 |  |  | 62,515 |  |  | 57,413 |  |  | 58,748 |  |  | 49,947 |  |  | 43,340 |  |
| Sales and marketing |  | 38,321 |  |  | 33,216 |  |  | 31,744 |  |  | 27,606 |  |  | 31,308 |  |  | 26,508 |  |  | 26,681 |  |  | 24,587 |  |
| General and administrative |  | 22,941 |  |  | 19,535 |  |  | 17,529 |  |  | 15,234 |  |  | 18,050 |  |  | 25,195 |  |  | 18,403 |  |  | 14,072 |  |
| Total operating expenses |  | 132,660 |  |  | 123,399 |  |  | 118,293 |  |  | 105,355 |  |  | 106,771 |  |  | 110,451 |  |  | 95,031 |  |  | 81,999 |  |
| Income from operations |  | 77,495 |  |  | 63,021 |  |  | 53,158 |  |  | 49,735 |  |  | 49,397 |  |  | 31,297 |  |  | 32,859 |  |  | 35,755 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | (918 | ) |  | (735 | ) |  | (732 | ) |  | (751 | ) |  | (746 | ) |  | (753 | ) |  | (832 | ) |  | (821 | ) |
| Other income (expense), net |  | 560 |  |  | 639 |  |  | 416 |  |  | 337 |  |  | (109 | ) |  | 13 |  |  | 417 |  |  | (468 | ) |
| Total other income (expense), net |  | (358 | ) |  | (96 | ) |  | (316 | ) |  | (414 | ) |  | (855 | ) |  | (740 | ) |  | (415 | ) |  | (1,289 | ) |
| Income before provision for income taxes |  | 77,137 |  |  | 62,925 |  |  | 52,842 |  |  | 49,321 |  |  | 48,542 |  |  | 30,557 |  |  | 32,444 |  |  | 34,466 |  |
| Provision for income taxes |  | 18,354 |  |  | 11,668 |  |  | 13,938 |  |  | 14,076 |  |  | 4,618 |  |  | 1,867 |  |  | 8,448 |  |  | 9,974 |  |
| Net income |  | $ | 58,783 |  |  | $ | 51,257 |  |  | $ | 38,904 |  |  | $ | 35,245 |  |  | $ | 43,924 |  |  | $ | 28,690 |  |  | $ | 23,996 |  |  | $ | 24,492 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.84 |  |  | $ | 0.74 |  |  | $ | 0.57 |  |  | $ | 0.52 |  |  | $ | 0.65 |  |  | $ | 0.42 |  |  | $ | 0.36 |  |  | $ | 0.37 |  |
| Diluted |  | $ | 0.79 |  |  | $ | 0.69 |  |  | $ | 0.53 |  |  | $ | 0.48 |  |  | $ | 0.60 |  |  | $ | 0.39 |  |  | $ | 0.33 |  |  | $ | 0.34 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001596532-17-000019:notes:239]
Related Party Transactions and Balances

[0001596532-17-000019:notes:240]
Certain members of our board of directors serve on the boards of our customers and one of our vendors. During the years ended December 31, 2016, 2015 and 2014, we recognized revenue of $76.1 million, $39.4 million and $29.6 million, respectively, from sales transactions with these related party customers. Amounts due from these related party customers were $8.7 million and $9.8 million as of December 31, 2016 and 2015, respectively. The amount incurred related to transactions with a related party vendor was $2.1 million and $2.7 million during the year ended December 31, 2016 and 2015.  There were no transactions with this related party vendor during the year ended December 31, 2014.


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001596532-17-000019:notes:241]
Accounts Receivable, net

[0001596532-17-000019:notes:242]
Accounts receivable, net consists of the following (in thousands):

[0001596532-17-000019:notes:243]
|  | December 31, |
|  | 2016 |  | 2015 |
| Accounts receivable | $ | 254,640 |  |  | $ | 145,792 |  |
| Allowance for doubtful accounts | (204 | ) |  | (963 | ) |
| Product sales return reserve | (1,317 | ) |  | (566 | ) |
| Accounts receivable, net | $ | 253,119 |  |  | $ | 144,263 |  |

[0001596532-17-000019:notes:244]
Allowance for Doubtful Accounts

[0001596532-17-000019:notes:245]
Activity in the allowance for doubtful accounts consists of the following (in thousands):

[0001596532-17-000019:notes:246]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Balance at the beginning of year | $ | 963 |  |  | $ | 1,063 |  |  | $ | 810 |  |
| Charged (credited) to expense | (292 | ) |  | 335 |  |  | 860 |  |
| Deductions (write-offs) | (467 | ) |  | (435 | ) |  | (607 | ) |
| Balance at the end of year | $ | 204 |  |  | $ | 963 |  |  | $ | 1,063 |  |

[0001596532-17-000019:notes:247]
Product Sales Return Reserve

[0001596532-17-000019:notes:248]
Activity in the sales return reserve consists of the following (in thousands):

[0001596532-17-000019:notes:249]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| Balance at the beginning of year | $ | 566 |  |  | $ | 2,031 |  |  | $ | 1,529 |  |
| Charged against revenue | 3,791 |  |  | 2,798 |  |  | 4,063 |  |
| Deductions | (4,371 | ) |  | (2,283 | ) |  | (2,943 | ) |
| Change in estimate | 1,331 |  |  | (1,980 | ) |  | (618 | ) |
| Balance at the end of year | $ | 1,317 |  |  | $ | 566 |  |  | $ | 2,031 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001596532-17-000019:notes:250]
Accrued liabilities consist of the following (in thousands):

[0001596532-17-000019:notes:251]
|  | December 31, |
|  | 2016 |  | 2015 |
| Accrued payroll related costs | $ | 52,854 |  |  | $ | 39,479 |  |
| Accrued warranty costs | 6,744 |  |  | 4,718 |  |
| Accrued manufacturing costs | 14,824 |  |  | 6,397 |  |
| Accrued professional fees | 6,829 |  |  | 4,875 |  |
| Accrued taxes | 1,098 |  |  | 1,347 |  |
| Other | 8,602 |  |  | 4,155 |  |
| Total accrued liabilities | $ | 90,951 |  |  | $ | 60,971 |  |


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001596532-17-000019:notes:252]
The following table summarizes the unrealized gains and losses and fair value of our available-for-sale marketable securities (in thousands):

[0001596532-17-000019:notes:253]
|  | December 31, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper | $ | 5,962 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,962 |  |
| U.S. government notes | 110,945 |  |  | 5 |  |  | (194 | ) |  | 110,756 |  |
| Corporate bonds | 183,455 |  |  | 109 |  |  | (372 | ) |  | 183,192 |  |
| Total marketable securities | $ | 300,362 |  |  | $ | 114 |  |  | $ | (566 | ) |  | $ | 299,910 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001596532-17-000019:notes:254]
Inventories consist of the following (in thousands):

[0001596532-17-000019:notes:255]
|  | December 31, |
|  | 2016 |  | 2015 |
| Raw materials | $ | 99,190 |  |  | $ | 29,831 |  |
| Finished goods | 137,300 |  |  | 62,298 |  |
| Total inventories | $ | 236,490 |  |  | $ | 92,129 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001596532-17-000019:notes:256]
Prepaid expenses and other current assets consists of the following (in thousands):

[0001596532-17-000019:notes:257]
|  | December 31, |
|  | 2016 |  | 2015 |
| Inventory deposit | $ | 60,315 |  |  | $ | — |  |
| Prepaid income taxes | 17,383 |  |  | 14,150 |  |
| Other current assets | 79,140 |  |  | 29,270 |  |
| Other prepaid expenses and deposits | 11,846 |  |  | 7,190 |  |
| Total prepaid expenses and other current assets | $ | 168,684 |  |  | $ | 50,610 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001596532-17-000019:notes:258]
The following table summarizes the activity related to our accrued liability for estimated future warranty costs (in thousands):

[0001596532-17-000019:notes:259]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |
| Warranty accrual, beginning of year | $ | 4,718 |  |  | $ | 3,204 |  |
| Liabilities accrued for warranties issued during the year | $ | 5,421 |  |  | 3,973 |  |
| Warranty costs incurred during the year | (3,395 | ) |  | (2,459 | ) |
| Warranty accrual, end of year | $ | 6,744 |  |  | $ | 4,718 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001596532-17-000019:notes:260]
The following table represents revenue based on the customer’s location, as determined by the customer’s shipping address (in thousands):

[0001596532-17-000019:notes:261]
|  | Year Ended December 31, |
|  | 2016 |  | 2015 |  | 2014 |
| United States | $ | 862,352 |  |  | $ | 634,413 |  |  | $ | 456,691 |  |
| Other Americas | 12,388 |  |  | 12,506 |  |  | 8,853 |  |
| Europe, Middle East and Africa | 168,789 |  |  | 128,400 |  |  | 74,555 |  |
| Asia Pacific | 85,638 |  |  | 62,272 |  |  | 44,007 |  |
| Total revenue | $ | 1,129,167 |  |  | $ | 837,591 |  |  | $ | 584,106 |  |

[0001596532-17-000019:notes:262]
Long lived assets, excluding intercompany receivables, investments in subsidiaries, privately held equity investments and deferred tax assets, net by location are summarized as follows (in thousands):

[0001596532-17-000019:notes:263]
|  | December 31, |
|  | 2016 |  | 2015 |
| United States | $ | 69,352 |  |  | $ | 70,719 |  |
| International | 7,609 |  |  | 8,987 |  |
| Total | $ | 76,961 |  |  | $ | 79,706 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-17-000019:notes:264]
Segment Information

[0001596532-17-000019:notes:265]
We have determined that we operate as one reportable segment. The following table represents revenue based on the customer’s location, as determined by the customer’s shipping address (in thousands):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-17-000019:notes:266]
Balance Sheet Components

[0001596532-17-000019:notes:267]
There were no marketable securities as of December 31, 2015. We did not realize any other-than-temporary losses on our marketable securities for the year ended December 31, 2016 and 2015. None of our marketable securities were in continuous unrealized loss positions for greater than twelve months as of December 31, 2016 and 2015.

[0001596532-17-000019:notes:268]
We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. As interest rates increase, those marketable securities purchased at a lower yield show a mark-to-market unrealized loss. The unrealized losses are due primarily to changes in credit spreads and interest rates. We expect to realize the full value of these investments upon maturity or sale.

[0001596532-17-000019:notes:269]
As of December 31, 2016, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale investments, by remaining contractual maturity, are as follows (in thousands):

[0001596532-17-000019:notes:270]
The weighted average remaining duration of our current marketable securities is approximately 0.9 years as of December 31, 2016.  As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying consolidated balance sheets.

[0001596532-17-000019:notes:271]
Inventories

[0001596532-17-000019:notes:272]
Prepaid Expenses and Other Current Assets

[0001596532-17-000019:notes:273]
Property and Equipment, net

[0001596532-17-000019:notes:274]
Depreciation expense was $19.4 million, $13.4 million and $10.0 million for the years ended December 31, 2016, 2015 and 2014, respectively.

[0001596532-17-000019:notes:275]
Accrued Liabilities

[0001596532-17-000019:notes:276]
Warranty Accrual

[0001596532-17-000019:notes:277]
There were no significant specific product warranty reserves recorded for the years ended December 31, 2016 or 2015.
