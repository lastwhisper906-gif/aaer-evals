# ANET 8-K — 0001596532-16-000253 filed 2016-05-05

## item codes, every 8-K on or before 2016-05-05

- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2016-05-05

- none on or before 2016-05-05

## item 2.02 — earnings release, exhibit 99.1

[0001596532-16-000253:8k_2_02:1]
EX-99.1
2
ex991q116.htm
EXHIBIT 99.1

[0001596532-16-000253:8k_2_02:2]
Exhibit

[0001596532-16-000253:8k_2_02:3]
Exhibit 99.1

[0001596532-16-000253:8k_2_02:4]
Arista Networks, Inc. Reports First Quarter 2016 Financial Results

[0001596532-16-000253:8k_2_02:5]
Cloud Networking Adoption Drives Revenue and EPS

[0001596532-16-000253:8k_2_02:6]
SANTA CLARA, Calif., May 5, 2016 - Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large data center and computing environments, today announced financial results for its first quarter ended March 31, 2016.

[0001596532-16-000253:8k_2_02:7]
First Quarter Financial Highlights

[0001596532-16-000253:8k_2_02:8]
| • | Revenue of $242.2 million, a decrease of 1.3% compared to the fourth quarter of 2015, and an increase of 35.3% from the first quarter of 2015. |

[0001596532-16-000253:8k_2_02:9]
| • | Non-GAAP gross margin of 64.4%, compared to non-GAAP gross margin of 64.0% in the fourth quarter of 2015 and 66.1% in the first quarter of 2015. |

[0001596532-16-000253:8k_2_02:10]
| • | GAAP gross margin of 64.0%, compared to GAAP gross margin of 63.6% in the fourth quarter of 2015 and 65.8% in the first quarter of 2015. |

[0001596532-16-000253:8k_2_02:11]
| • | Non-GAAP net income of $49.1 million, or $0.68 per diluted share, compared to non-GAAP net income of $35.5 million, or $0.50 per diluted share, in the first quarter of 2015. |

[0001596532-16-000253:8k_2_02:12]
| • | GAAP net income of $35.2 million, or $0.48 per diluted share, compared to GAAP net income of $24.5 million, or $0.34 per diluted share, in the first quarter of 2015. |

[0001596532-16-000253:8k_2_02:13]
"As we kick off 2016, we delivered a solid quarter,” stated Jayshree Ullal, Arista President and CEO. “We continue to experience increased relevance and acceptance from our customers in the ongoing shift to cloud networking.”

[0001596532-16-000253:8k_2_02:14]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, "We are pleased with our execution across all financial metrics in the first quarter and with our outlook for Q2 reflecting strong customer adoption of our new products.”

[0001596532-16-000253:8k_2_02:15]
Company Highlights

[0001596532-16-000253:8k_2_02:16]
| • | Introduced the Arista 7500R Series, a switching and routing platform for cloud service provider and for next generation enterprise data centers which leverages Arista’s Universal Spine architecture that drives scale and agile workload mobility across public, private and hybrid clouds. |

[0001596532-16-000253:8k_2_02:17]
| • | Announced Arista FlexRoute™ technology that delivers up to one million wire speed routes with MPLS (Multiprotocol Label Switching), Segment Routing, VXLAN (Virtual Extensible LAN) and EVPN (Ethernet Virtual Private Network) protocol support. |

[0001596532-16-000253:8k_2_02:18]
| • | Demonstrated integration with Checkpoint at RSA 2016, and with Palo Alto Networks at Palo Alto Ignite User conference, as a joint solution for inserting Firewall services into data center traffic flows using Arista's innovative Macro Segmentation Services (MSS). |

[0001596532-16-000253:8k_2_02:19]
Financial Outlook

[0001596532-16-000253:8k_2_02:20]
For the second quarter of 2016, we expect:

[0001596532-16-000253:8k_2_02:21]
| • | Revenue between $259 and $265 million; |

[0001596532-16-000253:8k_2_02:22]
| • | Non-GAAP gross margin between 62% to 65%; and |

[0001596532-16-000253:8k_2_02:23]
| • | Non-GAAP operating margin of approximately 26%. |

[0001596532-16-000253:8k_2_02:24]
Guidance for non-GAAP financial measures excludes legal expenses associated with the OptumSoft and Cisco litigation, stock-based compensation and other non-recurring expenses. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis.

[0001596532-16-000253:8k_2_02:25]
Prepared Materials and Conference Call Information

[0001596532-16-000253:8k_2_02:26]
Arista executives will discuss first quarter 2016 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial 1-877-201-0168 in the United States or 1-647-788-4901 from outside the US. The Conference ID is 86552790.

[0001596532-16-000253:8k_2_02:27]
The financial results conference call will also be available via live webcast on our investor relations website at investors.arista.com.  Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s Investor Relations website.

[0001596532-16-000253:8k_2_02:28]
Forward-Looking Statements

[0001596532-16-000253:8k_2_02:29]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the first quarter of fiscal 2016, statements regarding the ongoing shift to cloud networking, and statements regarding the benefits from the introduction of the Arista 7500R Series. Forward-looking statements are subject to a number of uncertainties and risks that could cause actual results to differ materially from those anticipated in the forward-looking statements including risks associated with: Arista Networks’ limited operating history; risks associated with Arista Networks’ rapid growth; Arista Networks’ customer concentration; Arista Networks’ dispute with Cisco Systems, Inc.  including Arista Networks’ ability to obtain a determination that alternative product implementations are not covered by remedial orders; Arista Networks’ dispute with OptumSoft, Inc.; requests for more favorable terms and conditions from our large end customers; declines in the sales prices of our products and services; changes in customer order patterns or customer mix; increased competition in our products and service markets, including the data center market; dependence on the introduction and market acceptance of new product offerings and standards; rapid technological and market change; the evolution of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; and general market, political, economic and business conditions.  Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s Form 10-K filed with the SEC on February 25, 2016, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at http://investors.arista.com and on the SEC’s website at www.sec.gov. All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-16-000253:8k_2_02:30]
Non-GAAP Financial Measures

[0001596532-16-000253:8k_2_02:31]
The company reports certain non-GAAP financial measures that exclude stock-based compensation expenses, expenses associated with the OptumSoft and Cisco litigation, and other non-recurring charges. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends.  In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-16-000253:8k_2_02:32]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP net income, net income per diluted share, gross margin, or operating margin. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-16-000253:8k_2_02:33]
About Arista Networks

[0001596532-16-000253:8k_2_02:34]
Arista Networks was founded to pioneer and deliver software-driven cloud networking solutions for large data center storage and computing environments. Arista’s award-winning platforms, ranging in Ethernet speeds from 10 to 100 gigabits per second, redefine scalability, agility and resilience. Arista has shipped more than five million cloud networking ports worldwide with CloudVision and EOS, an advanced network operating system. Committed to open standards, Arista is a founding member of the 25/50GbE consortium. Arista Networks products are available worldwide directly and through partners.

[0001596532-16-000253:8k_2_02:35]
ARISTA, EOS, CloudVision, Spline, NetDB and FlexRoute are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-16-000253:8k_2_02:36]
Additional information and resources can be found at: http://www.arista.com.

[0001596532-16-000253:8k_2_02:37]
| Media ContactAmanda JaramilloCorporate Communications(408) 547-5798amanda@arista.com |  | Investor ContactChuck ElliottProduct and Investor Advocacy(408) 547-5549chuck@arista.com |

[0001596532-16-000253:8k_2_02:38]
ARISTA NETWORKS, INC.

[0001596532-16-000253:8k_2_02:39]
Condensed Consolidated Statements of Income

[0001596532-16-000253:8k_2_02:40]
(Unaudited in thousands, except per share amounts)

[0001596532-16-000253:8k_2_02:41]
|  | Three Months Ended March 31, |
|  | 2016 |  | 2015 |
| Revenue: |  |  |  |
| Product | $ | 212,475 |  |  | $ | 160,141 |  |
| Service | 29,721 |  |  | 18,904 |  |
| Total revenue | 242,196 |  |  | 179,045 |  |
| Cost of revenue: |  |  |  |
| Product | 78,913 |  |  | 54,439 |  |
| Service | 8,193 |  |  | 6,852 |  |
| Total cost of revenue | 87,106 |  |  | 61,291 |  |
| Gross profit | 155,090 |  |  | 117,754 |  |
| Operating expenses: |  |  |  |
| Research and development | 62,515 |  |  | 43,340 |  |
| Sales and marketing | 27,606 |  |  | 24,587 |  |
| General and administrative | 15,234 |  |  | 14,072 |  |
| Total operating expenses | 105,355 |  |  | 81,999 |  |
| Income from operations | 49,735 |  |  | 35,755 |  |
| Other income (expense), net: |  |  |  |
| Interest expense | (751 | ) |  | (821 | ) |
| Other income (expense), net | 337 |  |  | (468 | ) |
| Total other income (expense), net | (414 | ) |  | (1,289 | ) |
| Income before provision for income taxes | 49,321 |  |  | 34,466 |  |
| Provision for income taxes | 14,076 |  |  | 9,974 |  |
| Net income | $ | 35,245 |  |  | $ | 24,492 |  |
| Net income attributable to common stockholders: |  |  |  |
| Basic | $ | 34,921 |  |  | $ | 24,032 |  |
| Diluted | $ | 34,941 |  |  | $ | 24,071 |  |
| Net income per share attributable to common stockholders: |  |  |  |
| Basic | $ | 0.52 |  |  | $ | 0.37 |  |
| Diluted | $ | 0.48 |  |  | $ | 0.34 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |
| Basic | 67,737 |  |  | 64,635 |  |
| Diluted | 72,214 |  |  | 70,722 |  |

[0001596532-16-000253:8k_2_02:42]
ARISTA NETWORKS, INC.

[0001596532-16-000253:8k_2_02:43]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-16-000253:8k_2_02:44]
(Unaudited in thousands, except percentages and per share amounts)

[0001596532-16-000253:8k_2_02:45]
|  | Three Months Ended March 31, |
|  | 2016 |  | 2015 |
| GAAP gross profit | $ | 155,090 |  |  | $ | 117,754 |  |
| GAAP gross margin | 64.0 | % |  | 65.8 | % |
| Stock-based compensation expense | 793 |  |  | 636 |  |
| Non-GAAP gross profit | $ | 155,883 |  |  | $ | 118,390 |  |
| Non-GAAP gross margin | 64.4 | % |  | 66.1 | % |
| GAAP income from operations | $ | 49,735 |  |  | $ | 35,755 |  |
| Stock-based compensation expense | 13,360 |  |  | 8,839 |  |
| Litigation expense | 7,005 |  |  | 6,670 |  |
| Non-GAAP income from operations | $ | 70,100 |  |  | $ | 51,264 |  |
| Non-GAAP operating margin | 28.9 | % |  | 28.6 | % |
| GAAP net income | $ | 35,245 |  |  | $ | 24,492 |  |
| Stock-based compensation expense | 13,360 |  |  | 8,839 |  |
| Litigation expense | 7,005 |  |  | 6,670 |  |
| Income tax effect on non-GAAP exclusions | (6,524 | ) |  | (4,469 | ) |
| Non-GAAP net income | $ | 49,086 |  |  | $ | 35,532 |  |
| Weighted-average shares used in computing diluted net income per share attributable to common stockholders | 72,214 |  |  | 70,722 |  |
| GAAP diluted net income per share attributable to common stockholders | $ | 0.48 |  |  | $ | 0.34 |  |
| Non-GAAP adjustments to net income | 0.20 |  |  | 0.16 |  |
| Non-GAAP diluted net income per share | $ | 0.68 |  |  | $ | 0.50 |  |
| Summary of Stock-Based Compensation Expense |  |  |  |
| Cost of revenue | $ | 793 |  |  | $ | 636 |  |
| Research and development | 7,457 |  |  | 4,928 |  |
| Sales and marketing | 3,647 |  |  | 2,409 |  |
| General and administrative | 1,463 |  |  | 866 |  |
| Total | $ | 13,360 |  |  | $ | 8,839 |  |

[0001596532-16-000253:8k_2_02:46]
ARISTA NETWORKS, INC.

[0001596532-16-000253:8k_2_02:47]
Consolidated Balance Sheets

[0001596532-16-000253:8k_2_02:48]
(Unaudited in thousands)

[0001596532-16-000253:8k_2_02:49]
|  | March 31, |  | December 31, |
|  | 2016 |  | 2015 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 710,663 |  |  | $ | 687,326 |  |
| Marketable securities | 51,589 |  |  | — |  |
| Accounts receivable | 135,119 |  |  | 144,263 |  |
| Inventories | 84,030 |  |  | 92,129 |  |
| Prepaid expenses and other current assets | 41,732 |  |  | 50,610 |  |
| Total current assets | 1,023,133 |  |  | 974,328 |  |
| Property and equipment, net | 79,944 |  |  | 79,706 |  |
| Investments | 36,636 |  |  | 36,636 |  |
| Deferred tax assets | 50,026 |  |  | 48,429 |  |
| Other assets | 20,208 |  |  | 20,791 |  |
| TOTAL ASSETS | $ | 1,209,947 |  |  | $ | 1,159,890 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 24,808 |  |  | $ | 43,966 |  |
| Accrued liabilities | 46,113 |  |  | 60,971 |  |
| Deferred revenue | 135,524 |  |  | 122,049 |  |
| Other current liabilities | 7,819 |  |  | 8,025 |  |
| Total current liabilities | 214,264 |  |  | 235,011 |  |
| Income taxes payable | 14,918 |  |  | 14,060 |  |
| Lease financing obligations, non-current | 40,827 |  |  | 41,210 |  |
| Deferred revenue, non-current | 83,696 |  |  | 74,759 |  |
| Other long-term liabilities | 6,385 |  |  | 6,698 |  |
| TOTAL LIABILITIES | 360,090 |  |  | 371,738 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock | 7 |  |  | 7 |  |
| Additional paid-in capital | 564,342 |  |  | 537,904 |  |
| Retained earnings | 286,161 |  |  | 250,916 |  |
| Accumulated other comprehensive loss | (653) |  |  | (675 | ) |
| TOTAL STOCKHOLDERS’ EQUITY | 849,857 |  |  | 788,152 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 1,209,947 |  |  | $ | 1,159,890 |  |

[0001596532-16-000253:8k_2_02:50]
ARISTA NETWORKS, INC.

[0001596532-16-000253:8k_2_02:51]
Consolidated Statements of Cash Flows

[0001596532-16-000253:8k_2_02:52]
(Unaudited in thousands)

[0001596532-16-000253:8k_2_02:53]
|  | Quarter Ended March 31, |
|  | 2016 |  | 2015 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 35,245 |  |  | $ | 24,492 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 4,779 |  |  | 2,893 |  |
| Stock-based compensation | 13,360 |  |  | 8,839 |  |
| Deferred income taxes | (1,597 | ) |  | 1,670 |  |
| Excess tax benefit on stock based-compensation | (6,012 | ) |  | (10,569 | ) |
| Amortization of investment premiums | — |  |  | 487 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | 9,144 |  |  | (16,075 | ) |
| Inventories | 8,099 |  |  | (10,706 | ) |
| Prepaid expenses and other current assets | 8,878 |  |  | 2,613 |  |
| Other assets | 533 |  |  | (3,502 | ) |
| Accounts payable | (16,123 | ) |  | (1,936 | ) |
| Accrued liabilities | (14,868 | ) |  | (12,358 | ) |
| Deferred revenue | 22,412 |  |  | 26,356 |  |
| Income taxes payable | 6,802 |  |  | 8,985 |  |
| Other liabilities | 464 |  |  | (422 | ) |
| Net cash provided by operating activities | 71,116 |  |  | 20,767 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of marketable securities | (51,638 | ) |  | — |  |
| Purchases of property and equipment | (7,962 | ) |  | (5,136 | ) |
| Purchases of intangible assets | (670 | ) |  | (667 | ) |
| Net cash used in investing activities | (60,270 | ) |  | (5,803 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Principal payments of lease financing obligations | (314 | ) |  | (255 | ) |
| Proceeds from issuance of common stock upon exercising options, net of repurchases | 1,862 |  |  | 5,322 |  |
| Proceeds from issuance of common stock, employee stock purchase plan | 4,888 |  |  | 4,856 |  |
| Excess tax benefit on stock-based compensation | 6,012 |  |  | 10,569 |  |
| Issuance costs from initial public offering | — |  |  | (261 | ) |
| Net cash provided by financing activities | 12,448 |  |  | 20,231 |  |
| Effect of exchange rate changes | 43 |  |  | (40 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 23,337 |  |  | 35,155 |  |
| CASH AND CASH EQUIVALENTS—Beginning of year | 687,326 |  |  | 240,031 |  |
| CASH AND CASH EQUIVALENTS—End of year | $ | 710,663 |  |  | $ | 275,186 |  |
