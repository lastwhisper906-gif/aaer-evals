# ANET MD&A — 0001596532-16-000255


## mdna

[0001596532-16-000255:mdna:1]
[same as prior period, unchanged from 0001596532-15-000176:mdna:1]

[0001596532-16-000255:mdna:2]
[same as prior period, unchanged from 0001596532-15-000176:mdna:2]

[0001596532-16-000255:mdna:3]
We are a leading supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation data centers for enterprise support. Our cloud networking solutions consist of our Extensible Operating System, or EOS, a set of network applications and our Ethernet switches. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. At the core of our cloud networking platform is EOS, which was purpose-built to be fully programmable and highly modular. The programmability of EOS has allowed us to create a set of software applications that address the requirements of cloud networking, including workflow automation, network visibility and analytics, and has also allowed us to rapidly integrate with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.

[0001596532-16-000255:mdna:4]
We were founded in 2004 to address the limitations of legacy networking products and to create a cloud networking platform that is open and programmable. From 2004 to 2008, our activities were focused on the development of our software, which resulted in the commercial release of our first product, the 7100 Series switches based on our EOS software, in 2008. Since then, we have continued to introduce new products utilizing EOS, including our 7500 Series switch and our 7050 Series switch in 2010, the second generation of our 7500 Series switch, called the 7500E modular switch, in May 2013, our 7300 Series switch in November 2013, our 7280E in July 2014.  In December 2014, we introduced our EOS+ software platform for networking programmability and automation, and in June 2015 we introduced CloudVision, a network-wide approach for workload orchestration and workflow automation.  In September 2015, we introduced our Macro Segmentation Services, or MSS, to provide automated insertion of security and other in-line layer 4-7 services within any software driven cloud networking infrastructure. MSS has been endorsed by many of our technology alliance ecosystem partners with whom we are currently partnering with to deliver MSS platform support. In addition, during 2015, we introduced our first 10/25/40/50/100G switches with our 7060, 7260 and 7320 series switches. In January 2016, Arista unveiled NetDB, the network-wide, state-oriented database that enhances the core system database (SysDB) of Arista EOS.  NetDB builds upon the SysDB architecture by adding software infrastructure improvements, including state-sharing and replication mechanisms for centrally storing network state, increased software table capacities up to 1M routes, and the ability to stream state in realtime from EOS devices. This extends the benefits of the state-based system across the entire network. And, during March 2016, we introduced our 7500R series, building on the 7500E series and providing 100GbE density and large table sizes in a single chassis. At up to 115 Tbps capacity, the 7500R supports up to one million routes, subsuming switching and routing functions into a Universal Spine platform for cloud-scale networks.

[0001596532-16-000255:mdna:5]
As of December 31, 2015, we have shipped more than five million switch ports. We have experienced rapid revenue growth over the last several years, increasing our revenue at a compound annual growth rate of 56.4% from 2011 to 2015. As we have grown the functionality of our EOS software, expanded the range of our switching portfolio and increased the size of our sales force, our revenue has continued to grow rapidly. To support our customers and revenue growth, we have expanded our international presence to include 20 foreign subsidiaries as of December 31, 2015, including for example Australia, Canada, France, Germany, India, Ireland, Japan, South Korea and the United Kingdom. Our revenue for the three months ended March 31, 2016 was $242.2 million an increase of 35.3% compared to the same period in 2015. We have been profitable and cash flow positive for each year since 2010.

[0001596532-16-000255:mdna:6]
[same as prior period, unchanged from 0001596532-15-000176:mdna:6]

[0001596532-16-000255:mdna:7]
[same as prior period, unchanged from 0001596532-15-000176:mdna:7]

[0001596532-16-000255:mdna:8]
We derive revenue from sales of products and services. We generate revenue primarily from sales of our switching products which incorporate our EOS software. We generate the majority of our services revenue from post contract support, or PCS, which end customers typically purchase in conjunction with our products.

[0001596532-16-000255:mdna:9]
Since shipping our first products in 2008, our cumulative end-customer base has grown rapidly. Between December 31, 2011 and December 31, 2015, our cumulative end-customer base grew from approximately 1,100 to over 3,700. Our end customers span a range of industries and include large Internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others.

[0001596532-16-000255:mdna:10]
To continue to grow our revenue, it is important that we both obtain new customers and sell additional products to existing customers. Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic to the underlying merchant silicon architecture. Today, we combine our EOS software with merchant silicon into a family of switching products. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We currently procure certain merchant silicon components from multiple vendors, and we continue to expand our relationships with these and other vendors. We work closely with third party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third party direct fulfillment facilities where our EOS software is installed on our products.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.  We intend to expand our contract manufacturing capabilities to include an additional contract manufacturer in San Jose, California.

[0001596532-16-000255:mdna:11]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators, original equipment manufacturer, or OEM partners and in conjunction with various technology partners. To facilitate channel coordination and increase productivity, we have created a partner program, the Arista Partner Program, to engage partners who provide value-added services and extend our reach into the marketplace. Authorized training partners provide technical training to our channel partners. Our partners commonly receive an order from an end customer prior to placing an order with us, and we confirm the identification of the end customer prior to accepting such orders. Our partners generally do not stock inventory received from us. Our sales organization is supported by systems engineers with deep technical expertise and responsibility for pre-sales technical support and engineering for our end customers. Each sales team is responsible for a geographic territory, has responsibility for a number of major direct end-customer accounts or has assigned accounts in a specific vertical market. During the three months ended March 31, 2016 and 2015, 75.4% and 70.8% or our revenue was generated from the Americas, substantially all from the U.S., 18.1% and 22.4% from Europe, the Middle East and Africa and 6.5% and 6.8% from the Asia-Pacific region, respectively.

[0001596532-16-000255:mdna:12]
[same as prior period, unchanged from 0001596532-15-000176:mdna:12]

[0001596532-16-000255:mdna:13]
We believe that our future success will depend on many factors, including our ability to expand sales to our existing customers as well as to add new end customers. While these areas present significant opportunity, they also present risks that we must manage to ensure successful results. See the section titled “Risk Factors.” Additionally, we face intense competition especially from larger, well-established companies, and we must continue to expand the capabilities of our cloud networking platform to succeed in our market. We are also currently engaged in lawsuits with Cisco, our largest competitor, whereby they claim that we have infringed their intellectual property rights.  We intend to vigorously defend against these Cisco lawsuits as summarized in the Legal Proceedings section below. However, we cannot be certain that any claims by Cisco would be resolved in our favor.  If we are unable to address these challenges, our business could be adversely affected.

[0001596532-16-000255:mdna:14]
[same as prior period, unchanged from 0001596532-15-000176:mdna:14]

[0001596532-16-000255:mdna:15]
Expanding Sales to Existing Customer Base. We expect that a substantial portion of our future sales will be follow-on sales to existing end customers. As noted above, one of our sales strategies is to target specific projects at our current end customers because they are familiar with the operational and economic benefits of our cloud networking solutions, thereby reducing the sales cycle into these customers. We believe this opportunity with current end customers to be significant given their existing and expected infrastructure spend.  We expect our business and results of operations will depend on our ability to sell additional products to our growing base of customers.

[0001596532-16-000255:mdna:16]
Adding New End Customers. We believe that the cloud networking market is still in the early stages of adoption. We intend to target new end customers by continuing to invest in our field sales force and extending our relationships with channel, technology and system-level partners. To date, we have primarily targeted end customers with the largest cloud data centers. A typical initial order involves the education of prospective customers about the technical merits and capabilities and potential cost savings of our products as compared to our competitors’ products. Our results of operations will depend on our ability to continue to add new customers. We believe that customer references have been, and will continue to be, an important factor in winning new business with special emphasis on four key verticals: the cloud titans, financial services, service and internet hosting providers and high tech enterprises.

[0001596532-16-000255:mdna:17]
Selling More Complex and Higher-Performance Configurations. Our results of operations have been, and we believe will continue to be, affected by our ability to sell more complex and higher-performance configurations of our products.  Our ability to sustain our revenue growth will depend, in part, upon our continued sales of these more robust configurations, and quarterly results of operations can be significantly impacted by the mix of products and product configurations sold during the period.

[0001596532-16-000255:mdna:18]
Leveraging Channel Partners. We expect to continue to derive a growing portion of our sales through our channel partners as they develop new end customers and expand sales to our existing end customers. We plan to continue to invest in our network of channel partners to enable them to reach new end customers more effectively, increase sales to existing customers and provide services and support effectively. We believe that increasing channel leverage will extend and improve our engagement with a broad set of customers.

[0001596532-16-000255:mdna:19]
Investing in Research and Development for Growth. We believe that the market for cloud networking is still in the early stages of adoption and we intend to continue investing for long-term growth. We expect to continue to invest heavily in software development in order to expand the capabilities of our cloud networking platform, introduce new products such as our 7500R series, new releases and upgrades to our EOS software and new applications building upon our technology leadership. We believe one of our greatest strengths lies in the speed of our product development efforts. By investing in research and development, we believe we will be well positioned to continue our rapid growth and take advantage of our large market opportunity. We expect that our results of operations will be impacted by the timing and size of these product development investments.

[0001596532-16-000255:mdna:20]
Customer Concentration and Timing of Large Orders. Historically, large purchases by a relatively limited number of end customers have accounted for a significant portion of our revenue. During the years ended December 31, 2015, 2014, and 2013, our largest end customer accounted for 12.0%, 14.9%, and 21.9% of our revenue, respectively.  We have also experienced and continue to experience customer concentration on a quarterly basis. In addition, we have experienced increases in the size of our orders, including orders from existing customers, which could result in future increased customer concentration, depending on the timing of the fulfillment of those orders. We have also experienced unpredictability in the timing of large orders, especially with respect to our large end customers, due to the complexity of orders, the time it takes end customers to evaluate, test, qualify and accept our products and factors specific to our end customers. Due to these factors, we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. In addition, we have provided, and may in the future provide, pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur. Our gross margins may also fluctuate as a result of the timing of such sales to large end customers.

[0001596532-16-000255:mdna:21]
[same as prior period, unchanged from 0001596532-15-000176:mdna:22]

[0001596532-16-000255:mdna:22]
[same as prior period, unchanged from 0001596532-15-000176:mdna:23]

[0001596532-16-000255:mdna:23]
We generate revenue primarily from sales of our switching products which incorporate our EOS software. We also derive a portion of our revenue from sales of post contract support, or PCS, and to a lesser extent professional services. We generate PCS revenue from sales of technical support services contracts that are typically purchased in conjunction with our products and subsequent renewals of those contracts. We offer PCS services under renewable, fee-based contracts, which include 24-hour technical support, hardware repair and replacement parts, bug fixes, patches and unspecified upgrades on a when-and-if available basis. We expect our revenue may vary from period to period based on, among other things, the timing and size of orders, the delivery and acceptance of products, the impact of significant transactions with unique terms and conditions that may require deferral of revenue and cyclicality of orders being placed by our customers. Additionally, we expect PCS revenue to increase in absolute dollars as we expand our installed base. Our ability to expand our installed base and increase our revenue is subject to numerous risks and uncertainties. See the section titled “Risk Factors.” We report revenue net of sales taxes.

[0001596532-16-000255:mdna:24]
[same as prior period, unchanged from 0001596532-15-000176:mdna:25]

[0001596532-16-000255:mdna:25]
[same as prior period, unchanged from 0001596532-15-000176:mdna:26]

[0001596532-16-000255:mdna:26]
[same as prior period, unchanged from 0001596532-15-000176:mdna:27]

[0001596532-16-000255:mdna:27]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including sales to large end customers who generally receive lower pricing, the average sales price of our offerings, manufacturing costs, including costs associated with the introduction of additional contract manufacturing capacity, merchant silicon costs and the mix of products sold. We expect our gross margins to fluctuate over time, depending on the factors described above and others. See the section titled “Risk Factors.”

[0001596532-16-000255:mdna:28]
[same as prior period, unchanged from 0001596532-15-000176:mdna:29]

[0001596532-16-000255:mdna:29]
[same as prior period, unchanged from 0001596532-15-000176:mdna:30]

[0001596532-16-000255:mdna:30]
[same as prior period, unchanged from 0001596532-15-000176:mdna:31]

[0001596532-16-000255:mdna:31]
[same as prior period, unchanged from 0001596532-15-000176:mdna:32]

[0001596532-16-000255:mdna:32]
[same as prior period, unchanged from 0001596532-15-000176:mdna:33]

[0001596532-16-000255:mdna:33]
Sales and marketing expenses consist primarily of personnel costs and also include costs related to marketing and promotional activities, with the remainder being an allocated portion of facility and IT costs and depreciation. We expect our sales and marketing expenses to increase in absolute dollars as we expand our sales and marketing efforts worldwide and expand our relationships with current and future channel partners and end customers.

[0001596532-16-000255:mdna:34]
[same as prior period, unchanged from 0001596532-15-000176:mdna:36]

[0001596532-16-000255:mdna:35]
General and administrative expenses consist primarily of personnel costs, legal and professional fees, and an allocated portion of facility and IT costs and depreciation. General and administrative personnel costs include those for our executive, finance, IT, human resources and legal functions. Our professional fees consist primarily of accounting, external legal and IT and other consulting costs. Refer to the discussion under “Legal Proceedings” subheading in Note 5. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for information related to pending litigation.

[0001596532-16-000255:mdna:36]
[same as prior period, unchanged from 0001596532-15-000176:mdna:38]

[0001596532-16-000255:mdna:37]
[same as prior period, unchanged from 0001596532-15-000176:mdna:39]

[0001596532-16-000255:mdna:38]
Interest expense consists mostly of interest expense from our lease financing obligation.

[0001596532-16-000255:mdna:39]
[same as prior period, unchanged from 0001596532-15-000176:mdna:41]

[0001596532-16-000255:mdna:40]
Other income (expense) consists mostly of foreign currency exchange gains and losses and interest income. Our foreign currency exchange gains and losses relate to transactions and asset and liability balances denominated in currencies other than the U.S. dollar. We expect our foreign currency gains and losses to continue to fluctuate in the future due to changes in foreign currency exchange rates.

[0001596532-16-000255:mdna:41]
[same as prior period, unchanged from 0001596532-15-000176:mdna:43]

[0001596532-16-000255:mdna:42]
[same as prior period, unchanged from 0001596532-15-000176:mdna:44]

[0001596532-16-000255:mdna:43]
[same as prior period, unchanged from 0001596532-15-000176:mdna:45]

[0001596532-16-000255:mdna:44]
[same as prior period, unchanged from 0001596532-15-000176:mdna:46]

[0001596532-16-000255:mdna:45]
[same as prior period, unchanged from 0001596532-15-000176:mdna:47]

[0001596532-16-000255:mdna:46]
The following table summarizes historical results of operations for the periods presented and as a percentage of revenue for those periods.  We have derived the data for the three months ended March 31, 2016 and 2015 from our unaudited condensed consolidated financial statements (in thousands, except for percentage of revenue).

[0001596532-16-000255:mdna:47]
|  | Three Months Ended March 31, |
|  | 2016 |  | 2015 |
| Revenue: |  |  |  |
| Product | $ | 212,475 |  |  | $ | 160,141 |  |
| Service | 29,721 |  |  | 18,904 |  |
| Total revenue | 242,196 |  |  | 179,045 |  |
| Cost of revenue (1): |  |  |  |
| Product | 78,913 |  |  | 54,439 |  |
| Service | 8,193 |  |  | 6,852 |  |
| Total cost of revenue | 87,106 |  |  | 61,291 |  |
| Gross profit | 155,090 |  |  | 117,754 |  |
| Operating expenses (1): |  |  |  |
| Research and development | 62,515 |  |  | 43,340 |  |
| Sales and marketing | 27,606 |  |  | 24,587 |  |
| General and administrative | 15,234 |  |  | 14,072 |  |
| Total operating expenses | 105,355 |  |  | 81,999 |  |
| Income from operations | 49,735 |  |  | 35,755 |  |
| Interest expense | (751 | ) |  | (821 | ) |
| Other income (expense), net | 337 |  |  | (468 | ) |
| Total other income (expense), net | (414 | ) |  | (1,289 | ) |
| Income before provision for income taxes | 49,321 |  |  | 34,466 |  |
| Provision for income taxes | 14,076 |  |  | 9,974 |  |
| Net income | $ | 35,245 |  |  | $ | 24,492 |  |

[0001596532-16-000255:mdna:48]
[same as prior period, unchanged from 0001596532-15-000176:mdna:50]

[0001596532-16-000255:mdna:49]
|  | Three Months Ended March 31, |
|  | 2016 |  | 2015 |
|  | (as a percentage of revenue) |
| Revenue: |  |  |  |
| Product | 87.7 | % |  | 89.4 | % |
| Service | 12.3 |  |  | 10.6 |  |
| Total revenue | 100.0 |  |  | 100.0 |  |
| Cost of revenue: |  |  |  |
| Product | 32.6 |  |  | 30.4 |  |
| Service | 3.4 |  |  | 3.8 |  |
| Total cost of revenue | 36.0 |  |  | 34.2 |  |
| Gross margin | 64.0 |  |  | 65.8 |  |
| Operating expenses: |  |  |  |
| Research and development | 25.8 |  |  | 24.2 |  |
| Sales and marketing | 11.4 |  |  | 13.7 |  |
| General and administrative | 6.3 |  |  | 7.9 |  |
| Total operating expenses | 43.5 |  |  | 45.8 |  |
| Income from operations | 20.5 |  |  | 20.0 |  |
| Interest expense | (0.2 | ) |  | (0.5 | ) |
| Other income (expense), net | 0.1 |  |  | (0.3 | ) |
| Total other income (expense), net | (0.1 | ) |  | (0.8 | ) |
| Income before provision for income taxes | 20.4 |  |  | 19.2 |  |
| Provision for income taxes | 5.8 |  |  | 5.6 |  |
| Net income | 14.6 | % |  | 13.6 | % |

[0001596532-16-000255:mdna:50]
[same as prior period, unchanged from 0001596532-15-000176:mdna:52]

[0001596532-16-000255:mdna:51]
[same as prior period, unchanged from 0001596532-15-000176:mdna:53]

[0001596532-16-000255:mdna:52]
|  | Three Months Ended March 31, |
|  | 2016 |  | 2015 |
| Cost of revenue | $ | 793 |  |  | $ | 636 |  |
| Research and development | 7,457 |  |  | 4,928 |  |
| Sales and marketing | 3,647 |  |  | 2,409 |  |
| General and administrative | 1,463 |  |  | 866 |  |
| Total stock-based compensation | $ | 13,360 |  |  | $ | 8,839 |  |

[0001596532-16-000255:mdna:53]
[same as prior period, unchanged from 0001596532-15-000176:mdna:55]

[0001596532-16-000255:mdna:54]
Three Months Ended March 31, 2016 Compared to Three Months Ended March 31, 2015

[0001596532-16-000255:mdna:55]
[same as prior period, unchanged from 0001596532-15-000176:mdna:57]

[0001596532-16-000255:mdna:56]
|  | Three Months Ended March 31, |
|  | 2016 |  | 2015 |  | Change in |
|  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |
| Product | $ | 212,475 |  |  | $ | 160,141 |  |  | $ | 52,334 |  |  | 32.7% |
| Service | 29,721 |  |  | 18,904 |  |  | 10,817 |  |  | 57.2 |
| Total revenue | 242,196 |  |  | 179,045 |  |  | 63,151 |  |  | 35.3 |
| Cost of revenue |  |  |  |  |  |  |  |
| Product | 78,913 |  |  | 54,439 |  |  | 24,474 |  |  | 45.0 |
| Service | 8,193 |  |  | 6,852 |  |  | 1,341 |  |  | 19.6 |
| Total cost of revenue | 87,106 |  |  | 61,291 |  |  | 25,815 |  |  | 42.1 |
| Gross profit | $ | 155,090 |  |  | $ | 117,754 |  |  | $ | 37,336 |  |  | 31.7% |
| Gross margin | 64.0 | % |  | 65.8 | % |  |  |  |  |

[0001596532-16-000255:mdna:57]
[same as prior period, unchanged from 0001596532-15-000176:mdna:59]

[0001596532-16-000255:mdna:58]
|  | Three Months Ended March 31, |
|  | 2016 |  | % of Total |  | 2015 |  | % of Total |
| Americas | $ | 182,641 |  |  | 75.4 % |  | $ | 126,757 |  |  | 70.8 % |
| Europe, Middle East and Africa | 43,739 |  |  | 18.1 |  | 40,090 |  |  | 22.4 |
| Asia-Pacific | 15,816 |  |  | 6.5 |  | 12,198 |  |  | 6.8 |
| Total revenue | $ | 242,196 |  |  | 100.0 % |  | $ | 179,045 |  |  | 100.0 % |

[0001596532-16-000255:mdna:59]
[same as prior period, unchanged from 0001596532-15-000176:mdna:61]

[0001596532-16-000255:mdna:60]
Revenue increased $63.2 million, or 35.3% in the three months ended March 31, 2016 compared to the same period in 2015.  We increased shipments to our existing customers during the period as they continued to grow and expand their business geographically, increasing their demand for our switch products and related accessories. Our revenue growth was primarily driven by existing customers, but we continued to add new customers as we expanded our market presence and geographic footprint.  Service revenue increased 57.2% during the three months ended March 31, 2016 compared to the same period in 2015 with growth in initial and renewal support contracts as our customer installed base continued to expand.  We also continued to experience fluctuations in product and service pricing due to competitive market pressures.  However, these were more than offset by the increased demand drivers outlined above.

[0001596532-16-000255:mdna:61]
[same as prior period, unchanged from 0001596532-15-000176:mdna:63]

[0001596532-16-000255:mdna:62]
Gross margin decreased from 65.8% to 64.0% for the three months ended March 31, 2016 compared to the same period in 2015.  This decrease during the period was primarily the result of changes in customer mix and to lesser extent product mix, as we expanded our business and increased the contribution of larger customers who typically receive higher discount levels.  In addition, we added capacity to our manufacturing and operations infrastructure, and had an increase in inventory-related obsolescence charges associated with product transitions.  These unfavorable changes were partially offset by improved service margins as we scale our services business.  We expect that our gross margin in the second quarter of 2016 will be relatively consistent with recent quarters.  While we do not have the ability to predict gross margins for periods beyond this time frame, we believe we may experience some increase in product costs as we ramp our new contract manufacturer and related supply chain operations.

[0001596532-16-000255:mdna:63]
[same as prior period, unchanged from 0001596532-15-000176:mdna:65]

[0001596532-16-000255:mdna:64]
|  | Three Months Ended March 31, |
|  | 2016 |  | 2015 |  | Change in |
|  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 62,515 |  |  | $ | 43,340 |  |  | $ | 19,175 |  |  | 44.2% |
| Sales and marketing | 27,606 |  |  | 24,587 |  |  | 3,019 |  |  | 12.3 |
| General and administrative | 15,234 |  |  | 14,072 |  |  | 1,162 |  |  | 8.3 |
| Total operating expenses | $ | 105,355 |  |  | $ | 81,999 |  |  | $ | 23,356 |  |  | 28.5% |

[0001596532-16-000255:mdna:65]
[same as prior period, unchanged from 0001596532-15-000176:mdna:67]

[0001596532-16-000255:mdna:66]
Research and development expenses increased $19.2 million, or 44.2%, for the three months ended March 31, 2016 compared to the same period in 2015. The increase was primarily due to an increase in personnel costs of $9.3 million, resulting from increases in headcount, stock based compensation as well as additional bonus expense under our corporate bonus plan. Prototype spend, third-party engineering and consulting costs increased by $6.3 million, and facilities and IT infrastructure costs increased $1.4 million due to new product introductions and the continued expansion and support of our research and development activities.

[0001596532-16-000255:mdna:67]
[same as prior period, unchanged from 0001596532-15-000176:mdna:70]

[0001596532-16-000255:mdna:68]
Sales and marketing expenses increased $3.0 million, or 12.3%, for the three months ended March 31, 2016 compared to the same period in 2015. The increase was primarily due to an increase in personnel costs of $4.3 million, resulting from increased headcount, additional sales incentive compensation due to higher sales volume, and additional corporate bonus expense. The increase was offset by a decrease in product field demonstration costs of $0.8 million.

[0001596532-16-000255:mdna:69]
[same as prior period, unchanged from 0001596532-15-000176:mdna:73]

[0001596532-16-000255:mdna:70]
General and administrative expenses increased $1.2 million, or 8.3%, for the three months ended March 31, 2016 compared to the same period in 2015. The increase was due to an increase in personnel costs of $0.9 million reflecting additional headcount, increased stock-based compensation charges, and additional bonus expenses under our corporate bonus program.  In addition, legal fees increased by $0.6 million primarily related to the Cisco and OptumSoft legal matters outlined in Note 5 to the Consolidated Financial Statements.

[0001596532-16-000255:mdna:71]
[same as prior period, unchanged from 0001596532-15-000176:mdna:76]

[0001596532-16-000255:mdna:72]
|  | Three Months Ended March 31, |
|  | 2016 |  | 2015 |  | Change in |
|  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (751 | ) |  | $ | (821 | ) |  | $ | 70 |  |  | 8.5% |
| Other income (expense), net | 337 |  |  | (468 | ) |  | 805 |  |  | 172.0 |
| Total other income (expense), net | $ | (414 | ) |  | $ | (1,289 | ) |  | $ | 875 |  |  | 67.9% |

[0001596532-16-000255:mdna:73]
[same as prior period, unchanged from 0001596532-15-000176:mdna:78]

[0001596532-16-000255:mdna:74]
Interest expense remained relatively constant during the three months ended March 31, 2016 compared to the same period in 2015 and primarily related to our lease financing obligation.

[0001596532-16-000255:mdna:75]
Other income (expense), net

[0001596532-16-000255:mdna:76]
The favorable change in other income (expense), net during the three months ended March 31, 2016 compared to the same period in 2015 was primarily the result of transactional exchange rate gains during the first quarter of 2016 compared to losses in the same period in 2015.

[0001596532-16-000255:mdna:77]
[same as prior period, unchanged from 0001596532-15-000176:mdna:82]

[0001596532-16-000255:mdna:78]
|  | Three Months Ended March 31, |
|  | 2016 |  | 2015 |  | Change in |
|  | $ |  | $ |  | $ |  | % |
| Provision for income taxes | $ | 14,076 |  |  | $ | 9,974 |  |  | $ | 4,102 |  |  | 41.1% |
| Effective tax rate | 28.5 | % |  | 28.9 | % |  |  |  |  |

[0001596532-16-000255:mdna:79]
[same as prior period, unchanged from 0001596532-15-000176:mdna:84]

[0001596532-16-000255:mdna:80]
Provision for income taxes was approximately $14.1 million and $10.0 million for the three months ended March 31, 2016 and 2015, respectively. The change in the provision was a result of an increase in profit before income taxes and the change in effective tax rate based on current geographical distribution of the earnings.

[0001596532-16-000255:mdna:81]
31

[0001596532-16-000255:mdna:82]
[same as prior period, unchanged from 0001596532-15-000176:mdna:87]

[0001596532-16-000255:mdna:83]
Our principal sources of liquidity are cash and cash equivalents, marketable securities, and cash generated from operations. As of March 31, 2016, cash and cash equivalents, and marketable securities were $762.3 million, of which approximately $55.1 million was held outside the U.S. in our foreign subsidiaries.  We have not repatriated nor do we currently have plans to repatriate these funds, but if we were to repatriate cash held outside of the U.S. for domestic cash operations, we would be required to accrue and pay U.S. income taxes to repatriate these funds less any previously paid foreign income taxes. We consider the undistributed earnings of our foreign subsidiaries as of March 31, 2016 to be indefinitely reinvested, and, accordingly, no U.S. income taxes have been provided thereon.

[0001596532-16-000255:mdna:84]
Our cash and cash equivalents, and marketable securities are held for working capital purposes. We expect our working capital requirements to increase by an aggregate of $50 to $100 million over the next several quarters as we transition to new products and ramp production and supply chain operations with a new contract manufacturer. In addition, we may incur incremental capital expenditures in the range of $5 to $10 million in relation to this manufacturing project. We plan to continue to invest for long-term growth. We believe that our existing cash and cash equivalents together with cash flow from operations will be sufficient to meet our working capital requirements and our growth strategies for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs and access to outsourcing our manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and costs incurred related to outstanding litigation claims. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-16-000255:mdna:85]
[same as prior period, unchanged from 0001596532-15-000176:mdna:90]

[0001596532-16-000255:mdna:86]
|  | March 31, 2016 |  | December 31, 2015 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 710,663 |  |  | $ | 687,326 |  |

[0001596532-16-000255:mdna:87]
|  | Three Months Ended March 31, |
|  | 2016 |  | 2015 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 71,116 |  |  | $ | 20,767 |  |
| Cash used in investing activities | (60,270 | ) |  | (5,803 | ) |
| Cash provided by financing activities | 12,448 |  |  | 20,231 |  |
| Effect of exchange rate changes | 43 |  |  | (40 | ) |
| Net increase in cash and cash equivalents | $ | 23,337 |  |  | $ | 35,155 |  |

[0001596532-16-000255:mdna:88]
[same as prior period, unchanged from 0001596532-15-000176:mdna:93]

[0001596532-16-000255:mdna:89]
Our primary source of cash from operating activities has been from cash collections from our customers. We expect cash inflows from operating activities to be affected by increased sales and timing of collections. Our primary uses of cash from operating activities have been for personnel costs, inventory purchases from our contract manufacturers, investment in research and development, and litigation expenses.

[0001596532-16-000255:mdna:90]
During the three months ended March 31, 2016, cash provided by operating activities was $71.1 million, primarily from net income of $35.2 million, a net increase in cash from changes in our operating assets and liabilities of $25.3 million, and net non-cash charges of $10.5 million. The net increase in cash from changes in operating assets and liabilities was primarily due to an increase in deferred revenue of $22.4 million mostly related to additional PCS contracts. In addition, we experienced an increase in cash of $6.8 million from changes in income tax payable, a decrease in our accounts receivable of $9.1 million resulting from strong collections during the period, a decrease in inventory of $8.1 million due to reductions in our finished goods inventory, and a reduction in prepaid expenses and current assets of $8.9 million primarily from a decrease in prepaid income taxes during the period. Operating cash flow increases were offset by a decrease in our accounts payable and accrued liabilities of $31.0 million primarily due corporate bonus payments and the timing of vendor payments.

[0001596532-16-000255:mdna:91]
During the three months ended March 31, 2015, cash provided by operating activities was $20.8 million, primarily from net income of $24.5 million and net non-cash charges of $3.5 million, partially offset by a net decrease from changes in our operating assets

[0001596532-16-000255:mdna:92]
and liabilities of $7.2 million. The net decrease in cash from changes in our operating assets and liabilities was primarily due to an increase in our accounts receivable of $16.3 million resulting from the increase in sales, a decrease in our accrued liabilities of $12.4 million primarily due to corporate bonus payments, as well as an increase in inventory of $10.7 million and an increase in other assets of $3.5 million. These operating cash flow decreases were partially offset by an increase in deferred revenue of $26.4 million due to an increase in our customer service install base and increases in product shipments with acceptance provisions, an increase in our income tax payable of $9.0 million, and a $2.6 million net decrease in prepaid expenses and other current assets.

[0001596532-16-000255:mdna:93]
[same as prior period, unchanged from 0001596532-15-000176:mdna:98]

[0001596532-16-000255:mdna:94]
[same as prior period, unchanged from 0001596532-15-000176:mdna:99]

[0001596532-16-000255:mdna:95]
During the three months ended March 31, 2016, cash used in investing activities was $60.3 million, consisting of purchases of available-for-sale securities of $51.6 million and purchases of property, equipment and other assets of $8.6 million.

[0001596532-16-000255:mdna:96]
During the three months ended March 31, 2015, cash used in investing activities was $5.8 million, consisting primarily of purchases of property and equipment of $5.1 million.

[0001596532-16-000255:mdna:97]
[same as prior period, unchanged from 0001596532-15-000176:mdna:102]

[0001596532-16-000255:mdna:98]
[same as prior period, unchanged from 0001596532-15-000176:mdna:103]

[0001596532-16-000255:mdna:99]
During the three months ended March 31, 2016, cash provided by financing activities was $12.4 million, consisting primarily of the excess tax benefit associated with equity incentive plans of $6.0 million, proceeds from the exercise of stock options, net of repurchases of $1.9 million and the proceeds from the issuance of common stock from our ESPP of $4.9 million.

[0001596532-16-000255:mdna:100]
During the three months ended March 31, 2015, cash provided by financing activities was $20.2 million, consisting primarily of proceeds from the exercise of stock options, net of repurchases of $5.3 million, the excess tax benefit associated with equity incentive plans of $10.6 million and the proceeds from the issuance of common stock from our ESPP of $4.9 million.

[0001596532-16-000255:mdna:101]
[same as prior period, unchanged from 0001596532-15-000176:mdna:106]

[0001596532-16-000255:mdna:102]
As of March 31, 2016, we did not have any relationships with any unconsolidated entities or financial partnerships, including entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-16-000255:mdna:103]
[same as prior period, unchanged from 0001596532-15-000176:mdna:108]

[0001596532-16-000255:mdna:104]
As of March 31, 2016, our principal commitments consist of obligations under operating leases and purchase commitments. There have been no significant changes to these obligations during the three months ended March 31, 2016, compared to the contractual obligations disclosed in our "Management's Discussion and Analysis of Financial Condition and Results of Operations" included in our Annual Report on Form 10-K, filed with the SEC on February 25, 2016, other than the purchase commitments described in Note 5. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements of this Quarterly Report on Form 10-Q.

[0001596532-16-000255:mdna:105]
[same as prior period, unchanged from 0001596532-15-000176:mdna:110]

[0001596532-16-000255:mdna:106]
Our unaudited condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles. The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. We believe the critical accounting policies and estimates discussed in the "Management's Discussion and Analysis of Financial Condition and Results of Operations" section of our Annual Report on Form 10-K filed with the SEC on February 25, 2016, reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting policies and estimates as disclosed in our Annual Report on Form 10-K.

[0001596532-16-000255:mdna:107]
[same as prior period, unchanged from 0001596532-15-000176:mdna:112]

[0001596532-16-000255:mdna:108]
Refer to “Recent Accounting Pronouncements” in Note 1 of Notes to Condensed Consolidated Financial Statements of this Quarterly Report on Form 10-Q.
