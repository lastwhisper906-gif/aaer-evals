# ANET notes — 0001596532-16-000255


## anet:ScheduleofSharebasedCompensationSharesAvailableForGrantActivityTableTextBlock

[0001596532-16-000255:notes:1]
The following table presents the stock activity and the total number of shares available for grant as of March 31, 2016 (in thousands):

[0001596532-16-000255:notes:2]
|  |  | Number of Shares |
| Balance—December 31, 2015 |  | 10,494 |  |
| Authorized |  | 2,044 |  |
| Options granted |  | (413 | ) |
| RSUs granted |  | (219 | ) |
| Options canceled |  | 161 |  |
| Options repurchased |  | 4 |  |
| RSUs forfeited |  | 41 |  |
| Balance—March 31, 2016 |  | 12,112 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001596532-16-000255:notes:3]
As of March 31, 2016, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale investments, by remaining contractual maturity, are as follows (in thousands):

[0001596532-16-000255:notes:4]
|  |  | March 31, 2016 |
| Due in 1 year or less |  | $ | 9,091 |  |
| Due in 1 year through 2 years |  | 42,498 |  |
| Total marketable securities |  | $ | 51,589 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001596532-16-000255:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") and following the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by U.S. GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2016, are not necessarily indicative of the results expected for the full fiscal year.

[0001596532-16-000255:notes:6]
The condensed consolidated balance sheet as of December 31, 2015 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by generally accepted accounting principles for complete financial statements.

[0001596532-16-000255:notes:7]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and are prepared in accordance with GAAP. All significant intercompany accounts and transactions have been eliminated.

[0001596532-16-000255:notes:8]
The accompanying unaudited condensed consolidated financial statements and related financial information should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2015, filed with the SEC on February 25, 2016.

[0001596532-16-000255:notes:9]
There have been no material changes to our significant accounting policies as of and for the three months ended March 31, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2015.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-16-000255:notes:10]
Commitments and Contingencies

[0001596532-16-000255:notes:11]
Operating Leases

[0001596532-16-000255:notes:12]
We lease various operating spaces in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2024. There have been no material changes in our operating lease commitments under contractual obligation, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2015.

[0001596532-16-000255:notes:13]
We recognize rent expense under these arrangements on a straight-line basis over the term of the lease.  Rent expense for all operating leases amounted to $2.3 million and $0.8 million for the three months ended March 31, 2016 and 2015, respectively.

[0001596532-16-000255:notes:14]
Financing Obligation—Build-to-Suit Lease

[0001596532-16-000255:notes:15]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013.  The underlying building asset is depreciated over the building’s estimated useful life of 30 years. At the conclusion of the initial lease term, we will de-recognize both the net book values of the asset and the remaining financing obligation. There have been no material changes in our financing obligation commitments under contractual obligation, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2015.

[0001596532-16-000255:notes:16]
As of March 31, 2016 and December 31, 2015, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $42.2 million and $42.5 million, respectively. As of March 31, 2016, $1.4 million and $40.8 million were recorded as short-term and long-term financing obligations, respectively.

[0001596532-16-000255:notes:17]
Land lease expense under our lease financing obligation included in rent expense above, amounted to $0.3 million for both the three months ended March 31, 2016 and 2015, respectively.

[0001596532-16-000255:notes:18]
Purchase Commitments

[0001596532-16-000255:notes:19]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply.  We issue purchase orders to our contract manufacturers for finished product and a significant portion of these orders consist of firm non-cancelable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancelable, including integrated circuits, which are consigned to our contract manufacturers.   As of March 31, 2016, we had non-cancelable purchase commitments of $57.3 million to our contract manufacturers and suppliers.

[0001596532-16-000255:notes:20]
We have provided restricted deposits to our third-party contract manufacturers and vendors to secure our obligations to purchase inventory. We had $2.3 million in restricted deposits as of March 31, 2016 and December 31, 2015. Restricted deposits are classified in other assets in our accompanying unaudited condensed consolidated balance sheets.

[0001596532-16-000255:notes:21]
Guarantees

[0001596532-16-000255:notes:22]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for lease facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-16-000255:notes:23]
Legal Proceedings

[0001596532-16-000255:notes:24]
OptumSoft, Inc. Matters

[0001596532-16-000255:notes:25]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-16-000255:notes:26]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft copies of certain components of our software for evaluation by OptumSoft, (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches, (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers, (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us, and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dtd July 27, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.

[0001596532-16-000255:notes:27]
OptumSoft has identified certain software components it claims to own, which are generally applicable tools and utility subroutines and not networking specific code. We cannot assure which software components OptumSoft may ultimately claim to own in the litigation or whether such claimed components are material.

[0001596532-16-000255:notes:28]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we assert our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we assert that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We ask the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also assert that, even if we are found not to own any particular components at issue, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation. On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have meritorious defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-16-000255:notes:29]
The parties tried the case for Phase I of the proceedings, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015.  On December 16, 2015, the Court issued a Proposed Statement of Decision Following Phase 1 Trial, and on January 8, 2016, OptumSoft filed objections to that Proposed Statement of Decision.  On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all of the software put at issue in Phase I.  The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II.  Phase II was previously scheduled to be tried in April 2016; that trial date has been vacated, however, and a new trial date has not yet been set.

[0001596532-16-000255:notes:30]
We intend to vigorously defend against any action brought against us by OptumSoft. However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor. For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft. If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license. An adverse litigation ruling could result in a significant damages award against us and injunctive relief. In addition, OptumSoft could assert additional or different claims against us, including claims that our license from OptumSoft is invalid.

[0001596532-16-000255:notes:31]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated at this time.  However, the outcome of litigation is inherently uncertain.  Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-16-000255:notes:32]
Cisco Systems, Inc. (“Cisco”) Matters

[0001596532-16-000255:notes:33]
On December 5, 2014, Cisco filed two complaints against us in District Court for the Northern District of California, which are proceeding as Case No. 4:14-cv-05343 (“’43 Case”) and Case No. 5:14-cv-05344 (“’44 Case”).  In the ’43 Case, Cisco alleges that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the 875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”).  Cisco seeks, as relief for our alleged infringement in the ’43 Case, lost profits and/or reasonable royalty damages in an unspecified amount, including treble damages, attorney’s fees, and associated costs.  Cisco also seeks injunctive relief in the ’43 Case.  On February 10, 2015, the court granted our unopposed motion to stay the ’43 Case until the proceedings before the United States International Trade Commission (“USITC”) pertaining to the same patents (as discussed below) become final.  In the ’44 Case, Cisco’s complaint alleges that we infringe U.S. Patent Nos. 7,047,526 and 7,953,886 (respectively, “the ’526 patent” and “the ’886 patent”), and further alleges that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI.”  As relief for our alleged patent infringement in the ’44 Case, Cisco seeks lost profits and/or reasonable royalty damages in an unspecified amount including treble damages, attorney’s fees, and associated costs as well as injunctive relief.  As relief for our alleged copyright infringement, Cisco seeks damages in an unspecified amount in the form of alleged lost profits, profits from our alleged infringement, statutory damages, attorney’s fees and associated costs.  Cisco also seeks injunctive relief against our alleged copyright infringement.  On February 13, 2015, we answered the complaint in the ’44 Case, denying the patent and copyright infringement allegations and also raising numerous affirmative defenses.  On March 6, 2015, Cisco filed an amended complaint against us the ’44 Case.  In response, we moved to dismiss Cisco’s allegations of willful patent infringement and pre-suit indirect patent infringement. The Court granted the motion with leave to amend on July 2, 2015. On July 23, 2015, Cisco filed an amended complaint. On January 25, 2016, we sought leave to file counterclaims against Cisco in the ’44 case for antitrust and unfair competition.  That motion was denied by order dated February 18, 2016, which also granted Arista leave to file those claims as a separate action.  On February 24, 2016, we filed a complaint containing our antitrust and unfair competition claims against Cisco in the District Court for the Northern District of California, which is proceeding as Case No. 5:16-cv-00923 (“’23 Case”).  In the ’23 Case, Cisco filed a motion to stay the litigation, or in the alternative, to dismiss the complaint on April 13, 2016, and a hearing on Cisco’s motion has been set for August 18, 2016. Trial has been set for November 21, 2016 in the ’44 Case. Trial has not been scheduled in the ’43 Case. Trial has not been scheduled in the ’23 Case.

[0001596532-16-000255:notes:34]
On December 19, 2014, Cisco filed two complaints against us in the USITC, alleging that Arista has violated Section 337 of the Tariff Act of 1930, as amended. The complaints have been instituted as ITC Inv. Nos. 337-TA-944 (“944 Investigation”) and 337-TA-945 (“945 Investigation”).   In the 944 Investigation, Cisco initially alleged that certain Arista switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents.  Cisco has subsequently dropped the ’296 patent from the 944 Investigation.  In the 945 Investigation, Cisco alleges that certain Arista switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents.  In both the 944 and 945 Investigations, Cisco seeks, among other things, a limited exclusion order barring entry into the United States of accused switch products (including 7000 Series of switches) and a cease and desist order against us restricting our activities with respect to our imported accused switch products.  On February 11, 2015, we responded to the notices of investigation and complaints in the 944 and 945 Investigations by, among other things, denying the patent infringement allegations and raising numerous affirmative defenses.

[0001596532-16-000255:notes:35]
The Administrative Law Judge assigned to the 944 Investigation issued a procedural schedule calling for, among other events:  an evidentiary hearing on Sept. 9-11 & 15-17, 2015; issuance of an initial determination regarding our alleged violations on January 27, 2016; and the Target Date for completion on May 27, 2016.  On January 27, 2016 the Administrative Law Judge issued a revised procedural schedule extending the date for issuance of an initial determination to February 2, 2016 and the Target Date to June 2, 2016. On February 26, 2016, the Commission issued a notice resetting the deadline for determining whether to review the initial determination to April 11, 2016 and the Target Date to June 9, 2016. The final determination in the 944 Investigation is then subject to Presidential review. The hearing has been completed and all post trial briefs have been submitted to the USITC.  On February 2, 2016, the Administrative Law Judge issued his initial determination finding a violation of section 337 of the Tariff Act.  More specifically, it was found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringe asserted claims 1, 2, 8-11, and 17-19 of the ’537 patent; asserted claims 6, 7, 20, and 21 of the ’592 patent; and asserted claims 5, 7, 45, and 46 of the ’145 patent.  A violation of section 337 was not found with respect to any asserted claims of the ’597 and ’164 patents.  On February 17, 2016, we filed a request for the Commission to review certain issues, including the infringement findings in the initial determination. On April 11, 2016, the Commission decided to review the initial determination on the following issues: (1) infringement of the ’537, ’597, ’592 and ’145 patents; (2) patentability of the ’597, ’592, and ’145 patents under 35 U.S.C. §101; (3) the construction of “said router configuration data managed by said database system and derived from configuration commands supplied by a user and executed by a router configuration subsystem before being stored in said database” of claims 1, 10, and 19 of the ’537 patent; (4) the construction of “a change to a configuration” / “a change in configuration” of claims 1, 39, and 71 of the ’597 patent; (5) equitable estoppel; (6) laches; (7) the technical prong of domestic industry for the ’537, ’597, ’592 and ’145 patents; (8) economic prong of domestic industry; and (9) importation; and to the extent any findings that the Commission reviews implicates the initial determination’s findings for the ’164 patent (e.g., intent to induce infringement), the Commission will review those findings for the ’164 patent.

[0001596532-16-000255:notes:36]
The Administrative Law Judge assigned to the 945 Investigation issued a procedural schedule calling for, among other events:  an evidentiary hearing on November 9-20, 2015; issuance of an initial determination regarding our alleged violations on April 26, 2016; and the Target Date for completion on August 26, 2016.  The evidentiary hearing was conducted in November 2015 and all post-hearing briefing has been completed. On March 29, 2016, the ALJ issued a revised procedural schedule extending the deadline for issuance of an initial determination to August 26, 2016, and the Target Date to December 26, 2016.  On April 19, 2016, the Commission determined not to review this decision. We are awaiting the initial determination from the Administrative Law Judge. The initial determination will be subject to review by the Commission, which will then issue a final determination and any remedial orders on December 26, 2016. If the final determination finds a violation, it will be subject to Presidential review.

[0001596532-16-000255:notes:37]
On April 1, 2015, we filed petitions for Inter Partes Review with the United States Patent Trial and Appeal Board (“PTAB”) seeking to invalidate Cisco’s ’597, ’211, and ’668 patents.  On April 10, 2015, we filed petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853 and ’577 patents.  On April 16, 2015, we filed additional petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853 and ’577 patents.  On August 11, 2015, we filed a second petition for Inter Partes Review of Cisco’s ’668 patent.  On October 6, 2015 we filed a second petition for Inter Partes Review of Cisco’s ’211 patent, which was denied on April 12, 2016.  On October 6, 2015, the PTAB granted our petition for Inter Partes Review of Cisco’s ’597 patent and our first petition for Inter Partes review of Cisco’s ’211 patents, but denied one of our petitions for Inter Partes Review of Cisco’s ’668 patent. On October 19, 2015 and October 22, 2015, the PTAB denied four petitions relating to the ’853 and ’577 patents. On November 18, 2015, we filed a request for rehearing on one of the denied petitions related to the ’577 patent, which was denied on February 29, 2016.  On December 9, 2015, we filed a petition for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’537 patent, and additional petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853, ’577, and ’668 patents.  On February 16, 2016, the PTAB denied our second petition for Inter Partes review of the ’668 patent. On March 17, 2016, we filed a request for rehearing on this decision, which was denied on March 29, 2016. We are awaiting decisions by the PTAB on our remaining petitions for Inter Partes Review of the ’537, ’853, ’577, and ’668 patents.  For those petitions that the PTAB grants, the PTAB must issue its final written decision on validity within twelve months of its institution decision.

[0001596532-16-000255:notes:38]
We intend to vigorously defend against Cisco’s lawsuits, as summarized in the preceding paragraphs.  However, we cannot be certain that any claims by Cisco would be resolved in our favor regardless of the merit of the claims.  For example, an adverse litigation ruling could result in a significant damages award against us, could further result in the above described injunctive relief, could result in a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products to the extent that we are found to infringe any valid claims asserted against us Cisco. In particular, with respect to the 944 and 945 Investigations, if our products are found to infringe any patents that are the subject of those investigations, the USITC would likely issue a limited exclusion order barring entry into the United States of our products (including 7000 Series of switches) and a cease and desist order restricting our activities with respect to our imported products. If we become subject to a limited exclusion order and it is not disapproved by the US Trade Representative, we will need to remove features or develop technical design-arounds in order to take the products outside of the scope of any patent found to have been infringed and the subject of a violation. We may not be successful in developing technical design-arounds that do not infringe the patents or that are acceptable to our customers. Our development efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management. Moreover, we may seek to obtain clearance for any such technical design-arounds from U.S. Customs and Border Patrol (“CBP”), and we may be unable to do so in a timely manner, if at all. In the case that we attempt to change our manufacturing, importation processes and shipping workflows to comply with any limited exclusion order or cease and desist order, such changes may be extremely costly, time consuming and we may not be able to implement such changes successfully. Any failure to develop effective technical design-arounds, obtain timely clearance of such technical design-arounds or successfully change our manufacturing, importation processes or shipping workflows may cause a disruption in our shipments and impact our revenues, business and reputation.  Any such adverse ruling could materially adversely affect our business, prospects, results of operation and financial condition.

[0001596532-16-000255:notes:39]
In the event that the USITC issues a limited exclusion order and cease and desist order, Cisco may also seek to enforce any limited exclusion order or cease and desist order by filing for an enforcement action at the USITC.  In such a proceeding, we would need to demonstrate that our technical design-arounds render our products non-infringing or otherwise outside the scope of the limited exclusion order or cease and desist order.  If we are unable to do so then any product shipments after the effective date of the limited exclusion order or cease and desist order (whether from existing imported inventory or from products assembled from foreign sourced components) could be subject to significant civil penalties, potential seizure of that inventory which was found to have an ineffective technical design-around, and an order prohibiting the importation of further products until we implement additional technical design-arounds.

[0001596532-16-000255:notes:40]
Additionally, the existence of this lawsuit could cause concern among our customers and partners and could adversely affect our business and results of operations.  Whether or not we prevail in the lawsuit, we expect that the litigation will be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-16-000255:notes:41]
With respect to the various legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated at this time.  However, the outcome of litigation is inherently uncertain.  Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-16-000255:notes:42]
Other Matters

[0001596532-16-000255:notes:43]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.  We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated.  Based on currently available information, management does not believe that liability relating to these other unresolved matters is probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows.  However, litigation is subject to inherent uncertainties and our view of these matters may change in the future.  Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-16-000255:notes:44]
Equity Award Plan Activities

[0001596532-16-000255:notes:45]
[same as prior period, unchanged from 0001596532-15-000176:notes:42]

[0001596532-16-000255:notes:46]
|  | Three Months Ended March 31, |
|  | 2016 |  | 2015 |
| Cost of revenue | $ | 793 |  |  | $ | 636 |  |
| Research and development | 7,457 |  |  | 4,928 |  |
| Sales and marketing | 3,647 |  |  | 2,409 |  |
| General and administrative | 1,463 |  |  | 866 |  |
| Total stock-based compensation | $ | 13,360 |  |  | $ | 8,839 |  |

[0001596532-16-000255:notes:47]
[same as prior period, unchanged from 0001596532-15-000176:notes:44]

[0001596532-16-000255:notes:48]
[same as prior period, unchanged from 0001596532-15-000176:notes:45]

[0001596532-16-000255:notes:49]
|  |  | Options and RSAs Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options and RSAs (in thousands) |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding (in thousands) |
| Outstanding—December 31, 2015 |  | 11,630 |  |  | $ | 24.49 |  |  | 7.6 |  | $ | 620,802 |  |
| Options granted |  | 413 |  |  | 56.33 |  |  |  |  |  |
| Options exercised |  | (288 | ) |  | 6.58 |  |  |  |  |  |
| Options canceled |  | (161 | ) |  | 24.34 |  |  |  |  |  |
| Outstanding—March 31, 2016 |  | 11,594 |  |  | $ | 26.08 |  |  | 7.5 |  | $ | 440,180 |  |
| Vested and exercisable—March 31, 2016 |  | 3,905 |  |  | $ | 9.47 |  |  | 6.5 |  | $ | 210,414 |  |
| Vested and expected to vest—March 31, 2016 |  | 10,982 |  |  | $ | 25.39 |  |  | 7.5 |  | $ | 424,280 |  |

[0001596532-16-000255:notes:50]
As of March 31, 2016, the total unrecognized stock-based compensation expense related to unvested stock options, net of expected forfeitures, was $112.1 million, which is expected to be recognized over a weighted-average period of 4.1 years.

[0001596532-16-000255:notes:51]
[same as prior period, unchanged from 0001596532-15-000176:notes:48]

[0001596532-16-000255:notes:52]
For the three months ended March 31, 2016, we repurchased 3,750 thousand shares of common stock at the original exercise price due to the termination of the holders of the unvested shares. As of March 31, 2016, shares held by employees and directors that were subject to repurchase were approximately 0.6 million with an aggregate price of $2.0 million.

[0001596532-16-000255:notes:53]
[same as prior period, unchanged from 0001596532-15-000176:notes:50]

[0001596532-16-000255:notes:54]
[same as prior period, unchanged from 0001596532-15-000176:notes:51]

[0001596532-16-000255:notes:55]
|  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2015 | 893 |  |  | $ | 70.14 |  |  | 1.9 |  | $ | 69,509 |  |
| RSUs granted | 219 |  |  | 57.56 |  |  |  |  |  |
| RSUs vested | (17 | ) |  | 69.26 |  |  |  |  |  |
| RSUs forfeited | (41 | ) |  | 67.86 |  |  |  |  |  |
| Unvested balance—March 31, 2016 | 1,054 |  |  | $ | 67.63 |  |  | 1.9 |  | $ | 66,495 |  |
| Vested and expected to vest—March 31, 2016 | 987 |  |  | $ | 67.67 |  |  | 1.8 |  | $ | 62,254 |  |

[0001596532-16-000255:notes:56]
As of March 31, 2016, there was $57.3 million of unrecognized stock-based compensation cost related to unvested RSUs, net of estimated forfeitures. This amount is expected to be recognized over a weighted-average period of 3.7 years.

[0001596532-16-000255:notes:57]
[same as prior period, unchanged from 0001596532-15-000176:notes:54]

[0001596532-16-000255:notes:58]
During the three months ended March 31, 2016, we issued 122,937 shares at an average purchase price of $39.76 under the 2014 Employee Stock Purchase Plan ("ESPP"). On February 17, 2015, the board authorized an increase to shares available for future issuance under the ESPP.  Per the ESPP, the increase is determined based on the lesser of 1% of total shares outstanding as of the first day of each fiscal year, or January 1, 2016, 2,500,000 shares or such amount as determined by our board of directors. The approved increase amounted to 681,315 shares. As of March 31, 2016, there remain 1,617,132 shares available for issuance under the ESPP.

[0001596532-16-000255:notes:59]
As of March 31, 2016, the total unrecognized stock-based compensation expense related to unvested ESPP options, net of expected forfeitures, was $3.3 million, which is expected to be recognized over a weighted-average period of 1.7 years.

[0001596532-16-000255:notes:60]
Shares Available for Grant


## us-gaap:EarningsPerShareTextBlock

[0001596532-16-000255:notes:61]
[same as prior period, unchanged from 0001596532-15-000176:notes:57]

[0001596532-16-000255:notes:62]
[same as prior period, unchanged from 0001596532-15-000176:notes:58]

[0001596532-16-000255:notes:63]
|  | Three Months Ended March 31, |
|  | 2016 |  | 2015 |
| Numerator: |  |  |  |
| Basic: |  |  |  |
| Net income | $ | 35,245 |  |  | $ | 24,492 |  |
| Less: undistributed earnings allocated to participating securities | (324 | ) |  | (460 | ) |
| Net income available to common stockholders, basic | $ | 34,921 |  |  | $ | 24,032 |  |
| Diluted: |  |  |  |
| Net income attributable to common stockholders, basic | $ | 34,921 |  |  | $ | 24,032 |  |
| Add: undistributed earnings allocated to participating securities | 20 |  |  | 39 |  |
| Net income attributable to common stockholders, diluted | $ | 34,941 |  |  | $ | 24,071 |  |
| Denominator: |  |  |  |
| Basic: |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 67,737 |  |  | 64,635 |  |
| Diluted: |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 67,737 |  |  | 64,635 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |
| Stock options and RSUs | 4,443 |  |  | 5,928 |  |
| Employee stock purchase plan | 34 |  |  | 159 |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted | 72,214 |  |  | 70,722 |  |
| Net income per share attributable to common stockholders: |  |  |  |
| Basic | $ | 0.52 |  |  | $ | 0.37 |  |
| Diluted | $ | 0.48 |  |  | $ | 0.34 |  |

[0001596532-16-000255:notes:64]
[same as prior period, unchanged from 0001596532-15-000176:notes:60]

[0001596532-16-000255:notes:65]
|  | Three Months Ended March 31, |
|  | 2016 |  | 2015 |
| Stock options and RSUs to purchase common stock | 3,763 |  |  | 1,906 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-16-000255:notes:66]
The following table sets forth the fair value of our financial assets by level within the fair value hierarchy (in thousands):

[0001596532-16-000255:notes:67]
|  | March 31, 2016 |
|  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 552,590 |  |  | $ | — |  |  | $ | — |  |  | $ | 552,590 |  |
| Money market funds-restricted | 4,041 |  |  | — |  |  | — |  |  | 4,041 |  |
| U.S. government notes | 9,091 |  |  | — |  |  | — |  |  | 9,091 |  |
| Corporate bonds | — |  |  | 42,498 |  |  | — |  |  | 42,498 |  |
| Total financial assets | $ | 565,722 |  |  | $ | 42,498 |  |  | $ | — |  |  | $ | 608,220 |  |

[0001596532-16-000255:notes:68]
|  | December 31, 2015 |
|  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 104,156 |  |  | $ | — |  |  | $ | — |  |  | $ | 104,156 |  |
| Money market funds-restricted | 4,041 |  |  | — |  |  | — |  |  | 4,041 |  |
| Total financial assets | $ | 108,197 |  |  | $ | — |  |  | $ | — |  |  | $ | 108,197 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-16-000255:notes:69]
[same as prior period, unchanged from 0001596532-15-000176:notes:65]

[0001596532-16-000255:notes:70]
[same as prior period, unchanged from 0001596532-15-000176:notes:66]

[0001596532-16-000255:notes:71]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value.  We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs. The three-tiers of the fair value hierarchy are as follows:

[0001596532-16-000255:notes:72]
Level I-Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date;

[0001596532-16-000255:notes:73]
Level II-Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities; and

[0001596532-16-000255:notes:74]
Level III-Unobservable inputs that are supported by little or no market data for the related assets or liabilities and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.

[0001596532-16-000255:notes:75]
We measure and report our cash equivalents and available-for-sale marketable securities at fair value. The following table sets forth the fair value of our financial assets by level within the fair value hierarchy (in thousands):


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-16-000255:notes:76]
[same as prior period, unchanged from 0001596532-15-000176:notes:72]

[0001596532-16-000255:notes:77]
Provision for income taxes was approximately $14.1 million and $10.0 million for the three months ended March 31, 2016 and 2015, respectively. The change in the provision was a result of an increase in profit before income taxes and the change in effective tax rate based on current geographical distribution of the earnings.

[0001596532-16-000255:notes:78]
[same as prior period, unchanged from 0001596532-15-000176:notes:74]

[0001596532-16-000255:notes:79]
We have been selected for examination by the Internal Revenue Service ("IRS") for our 2013 and 2014 tax years. It is difficult to determine when the examinations will be settled or their final outcomes in the foreseeable future.  We believe that we have adequately provided reserves for any reasonably foreseeable adjustment to our tax returns and we do not anticipate a significant impact to our gross unrecognized benefits within the next 12 months related to these years.

[0001596532-16-000255:notes:80]
Our gross unrecognized tax benefits as of March 31, 2016 were $22.5 million.  If the gross unrecognized tax benefits as of March 31, 2016 were realized in future periods, this could result in a tax benefit of $13.7 million within our provision of income taxes.  Because of the net operating loss and tax credit carryforwards, substantially all of our tax years remain open to tax examinations and we are unable to estimate the full range of possible adjustments to the balance of gross unrecognized tax benefits.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001596532-16-000255:notes:81]
[same as prior period, unchanged from 0001596532-15-000176:notes:82]

[0001596532-16-000255:notes:82]
[same as prior period, unchanged from 0001596532-15-000176:notes:83]

[0001596532-16-000255:notes:83]
As of March 31, 2016 and December 31, 2015, we held non-marketable equity investments of approximately $33.6 million in privately-held companies which are accounted for under the cost method. There were no impairments recognized on our investments for the three months ended March 31, 2016.

[0001596532-16-000255:notes:84]
[same as prior period, unchanged from 0001596532-15-000176:notes:85]

[0001596532-16-000255:notes:85]
As of March 31, 2016 and December 31, 2015, we have a $3.0 million promissory note with a privately-held company which was recorded at cost. The interest rate on the promissory note is 8.0% per annum and is payable quarterly. All unpaid principal and accrued interest on the promissory note is due and payable on the earlier of August 26, 2017 or upon a default.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-16-000255:notes:86]
In May 2014, the FASB issued ASU No. 2014-09, Revenue From Contracts With Customers, which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. In July 2015, the FASB deferred the effective date of the new revenue standard by one year. In March 2016, the FASB issued ASU No. 2016-08, Revenue From Contracts With Customers-Principal versus Agent Considerations (Reporting Revenue Gross versus Net), and ASU No. 2016-10, Revenue From Contracts With Customers-Identifying Performance Obligations and Licensing. ASU No. 2016-08 clarifies the implementation guidance regarding principal versus agent identification and related considerations. Specifically, the guidance provides clarification around performance obligations for goods or services provided by another entity, assisting in determining whether the entity is the provider of the goods or services, the principal, or whether the entity is providing for the arrangement of the goods or services, the agent.  ASU No. 2016-10 provides guidance around identifying whether promised goods or services are distinct and separately identifiable, whether promised goods or services are material or immaterial to the contract, and whether shipping and handling is considered an activity to fulfill a promise or an additional promised service. ASU No. 2016-10 also provides guidance around an entity's promise to grant a license providing a customer with either a right to use or a right to access the license, which then determines whether the obligation is satisfied at a point in time or over time, respectively.

[0001596532-16-000255:notes:87]
The above standards are effective for fiscal years (and interim reporting periods within those years) beginning after December 15, 2017.  The guidance is effective for us beginning in our first quarter of fiscal 2018. Early adoption would be permitted for all entities but not until the fiscal year beginning after December 15, 2016. The standard permits the use of either the retrospective or cumulative effect transition method. The retrospective method requires a retrospective approach to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance. The cumulative approach requires a retrospective approach with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. We are currently reviewing the provisions of the standard and have not yet selected a transition method nor have we determined the effect of the standard on our consolidated financial statements.

[0001596532-16-000255:notes:88]
In April 2015, the FASB issued ASU No. 2015-05, Intangibles—Goodwill and Other—Internal-Use Software, which  clarifies the circumstances under which a cloud computing customer would account for the arrangement as a license of internal-use software. A cloud computing arrangement would include a software license if (1) the customer has a contractual right to take possession of the software at any time during the hosting period without significant penalty and (2) it is feasible for the customer to either run the software on its own hardware or contract with another party unrelated to the vendor to host the software. If the arrangement does not contain a software license, it would be accounted for as a service contract. The guidance is effective for fiscal years beginning after December 15, 2015. The standard was effective for us for our first quarter of fiscal 2016, the adoption of which had no material impact on our consolidated financial statements.

[0001596532-16-000255:notes:89]
In July 2015, the FASB issued ASU No, 2015-11, Inventory: Simplifying the Measurement of Inventory, which simplifies the measurement of inventory to be measured at the lower of cost or net realizable value. The guidance applies to inventory measured using First in First Out ("FIFO") or average cost. The guidance is effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. The standard is effective for us for our first quarter of fiscal 2017.  The guidance can be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

[0001596532-16-000255:notes:90]
In November 2015, the FASB issued ASU 2015-17, Income Taxes - Balance Sheet Classification of Deferred Taxes, which will require the presentation of deferred tax liabilities and assets to be classified as noncurrent in a classified statement of financial position. The guidance is effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. The guidance can be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. The Company early adopted the guidance prospectively beginning in the fourth quarter of fiscal 2015. The adoption of the standard impacted presentation on the Company's Consolidated Financial Statements and related disclosures. No prior periods were retrospectively adjusted.

[0001596532-16-000255:notes:91]
In January 2016, the FASB issued ASU No, 2016-01, Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities, which enhances the reporting model for financial instruments to provide users of financial statements with more decision-useful information. The guidance will address certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. The guidance is effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. The standard is effective for us for our first quarter of fiscal 2018.  The guidance may be early adopted under early application guidance. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

[0001596532-16-000255:notes:92]
In February 2016, the FASB issued ASU No, 2016-02, Leases, which addresses the classification and recognition of lease assets and liabilities formerly classified as operating leases under GAAP. The guidance will address certain aspects of recognition and measurement, and quantitative and qualitative aspects of presentation and disclosure. The guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. The standard is effective for us for our first quarter of fiscal 2019.  The guidance will be applied to the earliest period presented using a modified retrospective approach. The guidance includes practical expedients that relate to identification, classification, and initial direct costs associated with leases commencing prior to the effective date, and the ability to apply hindsight in evaluating lease options related to extensions, terminations or asset purchases.  A practical expedient also exists to treat leases entered into prior effective date under existing GAAP unless the lease has been modified. The guidance may be early adopted. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

[0001596532-16-000255:notes:93]
In March 2016, the FASB amended the existing accounting standards for stock-based compensation, ASU 2016-09, Compensation-Stock Compensation: Improvements to Employee Share-Based Payment Accounting, which impact several aspects of accounting for share-based payment transactions, including the income tax consequences, forfeitures, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The guidance is effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. The standard is effective for us for our first quarter of fiscal 2017.  The guidance may be early adopted under early application guidance. If early adoption is elected, all amendments must be adopted in the same period. The manner of application varies by the various provisions of the guidance, with certain provisions applied on a retrospective or modified retrospective approach, while others are applied prospectively.  We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-16-000255:notes:94]
[same as prior period, unchanged from 0001596532-15-000176:notes:90]

[0001596532-16-000255:notes:95]
[same as prior period, unchanged from 0001596532-15-000176:notes:91]

[0001596532-16-000255:notes:96]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our” or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprises. Our cloud networking solutions consist of our Extensible Operating System, a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switches. We were incorporated in October 2004 and reincorporated in the state of Delaware in March 2014. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-16-000255:notes:97]
[same as prior period, unchanged from 0001596532-15-000176:notes:93]

[0001596532-16-000255:notes:98]
[same as prior period, unchanged from 0001596532-15-000176:notes:94]

[0001596532-16-000255:notes:99]
The preparation of the accompanying unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the unaudited condensed consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts and sales return reserve; determination of fair value for stock-based awards; accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; valuation of inventory; valuation of warranty accruals; and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions on an ongoing basis using historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. As future events and their effects cannot be determined with precision, actual results could differ from these estimates, and those differences could be material to the unaudited condensed consolidated financial statements.

[0001596532-16-000255:notes:100]
Significant Accounting Policies

[0001596532-16-000255:notes:101]
[same as prior period, unchanged from 0001596532-15-000176:notes:103]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001596532-16-000255:notes:102]
[same as prior period, unchanged from 0001596532-15-000176:notes:104]

[0001596532-16-000255:notes:103]
|  | March 31, 2016 |  | December 31, 2015 |
| Equipment and machinery | $ | 33,116 |  |  | $ | 29,101 |  |
| Computer hardware and software | 14,378 |  |  | 12,630 |  |
| Furniture and fixtures | 2,859 |  |  | 2,380 |  |
| Leasehold improvements | 28,578 |  |  | 24,372 |  |
| Building | 35,154 |  |  | 35,154 |  |
| Construction-in-process | 910 |  |  | 6,408 |  |
| Property and equipment, gross | 114,995 |  |  | 110,045 |  |
| Less: accumulated depreciation | (35,051 | ) |  | (30,339 | ) |
| Property and equipment, net | $ | 79,944 |  |  | $ | 79,706 |  |


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001596532-16-000255:notes:104]
[same as prior period, unchanged from 0001596532-15-000176:notes:106]

[0001596532-16-000255:notes:105]
|  | March 31, 2016 |  | December 31, 2015 |
| Accounts receivable | $ | 136,367 |  |  | $ | 145,792 |  |
| Allowance for doubtful accounts | (540 | ) |  | (963 | ) |
| Sales return reserve | (708 | ) |  | (566 | ) |
| Accounts receivable, net | $ | 135,119 |  |  | $ | 144,263 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001596532-16-000255:notes:106]
[same as prior period, unchanged from 0001596532-15-000176:notes:108]

[0001596532-16-000255:notes:107]
|  | March 31, 2016 |  | December 31, 2015 |
| Accrued payroll related costs | $ | 22,173 |  |  | $ | 39,479 |  |
| Accrued warranty costs | 4,883 |  |  | 4,718 |  |
| Accrued manufacturing costs | 6,094 |  |  | 6,397 |  |
| Accrued professional fees | 5,573 |  |  | 4,875 |  |
| Accrued taxes | 1,265 |  |  | 1,347 |  |
| Other | 6,125 |  |  | 4,155 |  |
| Total accrued liabilities | $ | 46,113 |  |  | $ | 60,971 |  |


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001596532-16-000255:notes:108]
The following table summarizes the unrealized gains and losses and fair value of our short term available-for-sale securities (in thousands):

[0001596532-16-000255:notes:109]
|  | March 31, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| U.S. government notes | $ | 9,089 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 9,091 |  |
| Corporate bonds | 42,549 |  |  | — |  |  | (51 | ) |  | 42,498 |  |
| Total marketable securities | $ | 51,638 |  |  | $ | 2 |  |  | $ | (51 | ) |  | $ | 51,589 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001596532-16-000255:notes:110]
[same as prior period, unchanged from 0001596532-15-000176:notes:113]

[0001596532-16-000255:notes:111]
|  | March 31, 2016 |  | December 31, 2015 |
| Raw materials | $ | 27,120 |  |  | $ | 29,831 |  |
| Finished goods | 56,910 |  |  | 62,298 |  |
| Total inventories | $ | 84,030 |  |  | $ | 92,129 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001596532-16-000255:notes:112]
[same as prior period, unchanged from 0001596532-15-000176:notes:115]

[0001596532-16-000255:notes:113]
|  | March 31, 2016 |  | December 31, 2015 |
| Prepaid income taxes | $ | 6,456 |  |  | $ | 14,150 |  |
| Other current assets | 27,766 |  |  | 29,270 |  |
| Other prepaids and deposits | 7,510 |  |  | 7,190 |  |
| Total prepaid expenses and other current assets | $ | 41,732 |  |  | $ | 50,610 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001596532-16-000255:notes:114]
[same as prior period, unchanged from 0001596532-15-000176:notes:117]

[0001596532-16-000255:notes:115]
|  | Three Months Ended March 31, |
|  | 2016 |  | 2015 |
| Warranty accrual, beginning of period | $ | 4,718 |  |  | $ | 3,204 |  |
| Liabilities accrued for warranties issued during the period | 693 |  |  | 783 |  |
| Warranty costs incurred during the period | (528 | ) |  | (301 | ) |
| Warranty accrual, end of period | $ | 4,883 |  |  | $ | 3,686 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001596532-16-000255:notes:116]
[same as prior period, unchanged from 0001596532-15-000176:notes:119]

[0001596532-16-000255:notes:117]
|  | Three Months Ended March 31, |
|  | 2016 |  | 2015 |
| United States | $ | 180,876 |  |  | $ | 123,153 |  |
| Other Americas | 1,765 |  |  | 3,604 |  |
| Europe, Middle East and Africa | 43,739 |  |  | 40,090 |  |
| Asia-Pacific | 15,816 |  |  | 12,198 |  |
| Total revenue | $ | 242,196 |  |  | $ | 179,045 |  |

[0001596532-16-000255:notes:118]
[same as prior period, unchanged from 0001596532-15-000176:notes:121]

[0001596532-16-000255:notes:119]
|  | March 31, 2016 |  | December 31, 2015 |
| United States | $ | 70,461 |  |  | $ | 70,719 |  |
| International | 9,483 |  |  | 8,987 |  |
| Total | $ | 79,944 |  |  | $ | 79,706 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-16-000255:notes:120]
[same as prior period, unchanged from 0001596532-15-000176:notes:123]

[0001596532-16-000255:notes:121]
[same as prior period, unchanged from 0001596532-15-000176:notes:124]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-16-000255:notes:122]
[same as prior period, unchanged from 0001596532-15-000176:notes:125]

[0001596532-16-000255:notes:123]
[same as prior period, unchanged from 0001596532-15-000176:notes:126]

[0001596532-16-000255:notes:124]
For the three months ended March 31, 2016, we did not realize any other-than-temporary losses on our marketable securities. None of our marketable securities have been in continuous unrealized loss positions for greater than twelve months as of March 31, 2016.  We had no marketable securities as of December 31, 2015.

[0001596532-16-000255:notes:125]
We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. As interest rates increase, those marketable securities purchased at a lower yield show a mark-to-market unrealized loss. The unrealized losses are due primarily to changes in credit spreads and interest rates. Because we do not intend to sell our investments and it is not more likely than not that we will be required to sell our investments before recovery of their amortized cost bases, which may be maturity, we do not consider our investments to be other-than-temporarily impaired at March 31, 2016. We expect to realize the full value of these investments upon maturity or sale.

[0001596532-16-000255:notes:126]
The weighted average remaining duration of our current marketable securities is approximately 1.1 years as of March 31, 2016.

[0001596532-16-000255:notes:127]
[same as prior period, unchanged from 0001596532-15-000176:notes:129]

[0001596532-16-000255:notes:128]
[same as prior period, unchanged from 0001596532-15-000176:notes:130]

[0001596532-16-000255:notes:129]
[same as prior period, unchanged from 0001596532-15-000176:notes:131]

[0001596532-16-000255:notes:130]
[same as prior period, unchanged from 0001596532-15-000176:notes:132]

[0001596532-16-000255:notes:131]
Building consists of capitalized construction costs of our leased building in Santa Clara, California. Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction, such as our financial involvement in structural elements of asset construction, making decisions related to tenant improvement costs and purchasing insurance not reimbursable by the buyer-lessor (the Landlord), we were deemed the owner of the building (for accounting purposes only) during the construction period. We continue to maintain involvement in the property post construction completion, and lack transferability of the risks and rewards of ownership, due to our required maintenance of a $4.0 million letter of credit, in addition to our ability and option to sublease our portion of the leased building for fees substantially higher than our base rate.  Due to our continuing involvement in the property post construction and lack of transferability of related risks and rewards of ownership to the Landlord after construction completion, we account for the building as a financing obligation. See “Note 5 - Commitments and Contingencies". Accordingly, as of March 31, 2016 and December 31, 2015, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the Landlord. The building was completed in 2014.

[0001596532-16-000255:notes:132]
Depreciation and amortization expense was $4.8 million and $2.9 million for the three months ended March 31, 2016 and 2015, respectively.

[0001596532-16-000255:notes:133]
[same as prior period, unchanged from 0001596532-15-000176:notes:135]

[0001596532-16-000255:notes:134]
[same as prior period, unchanged from 0001596532-15-000176:notes:136]

[0001596532-16-000255:notes:135]
We offer a one-year warranty on all of our hardware products and a 90-day warranty against defects in the software embedded in the products. The accrued warranty liability is recorded in accrued liabilities in the accompanying consolidated balance sheets.
