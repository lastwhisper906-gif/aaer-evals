# ANET notes — 0001596532-16-000291


## anet:ScheduleofSharebasedCompensationSharesAvailableForGrantActivityTableTextBlock

[0001596532-16-000291:notes:1]
The following table presents the stock activity and the total number of shares available for grant as of June 30, 2016 (in thousands):

[0001596532-16-000291:notes:2]
|  |  | Number of Shares |
| Balance—December 31, 2015 |  | 10,495 |  |
| Authorized |  | 2,044 |  |
| Options granted |  | (440 | ) |
| RSUs granted |  | (369 | ) |
| Options canceled |  | 232 |  |
| Options repurchased |  | 5 |  |
| RSUs forfeited |  | 56 |  |
| Shares traded for taxes |  | 9 |  |
| Balance—June 30, 2016 |  | 12,032 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001596532-16-000291:notes:3]
As of June 30, 2016, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale investments, by remaining contractual maturity, are as follows (in thousands):

[0001596532-16-000291:notes:4]
|  |  | June 30, 2016 |
| Due in 1 year or less |  | $ | 201,798 |  |
| Due in 1 year through 2 years |  | 90,962 |  |
| Total marketable securities |  | $ | 292,760 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001596532-16-000291:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") and following the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by U.S. GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2016, are not necessarily indicative of the results expected for the full fiscal year.

[0001596532-16-000291:notes:6]
The condensed consolidated balance sheet as of December 31, 2015 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by generally accepted accounting principles for complete financial statements.

[0001596532-16-000291:notes:7]
[same as prior period, unchanged from 0001596532-16-000255:notes:7]

[0001596532-16-000291:notes:8]
[same as prior period, unchanged from 0001596532-16-000255:notes:8]

[0001596532-16-000291:notes:9]
There have been no material changes to our significant accounting policies as of and for the six months ended June 30, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2015.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-16-000291:notes:10]
Commitments and Contingencies

[0001596532-16-000291:notes:11]
Operating Leases

[0001596532-16-000291:notes:12]
We lease various operating spaces in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2024. There have been no material changes in our operating lease commitments under contractual obligation, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2015.

[0001596532-16-000291:notes:13]
We recognize rent expense under these arrangements on a straight-line basis over the term of the lease.  Rent expense for all operating leases amounted to $2.4 million, $1.2 million,  $4.7 million, and $2.0 million for the three and six months ended June 30, 2016 and 2015, respectively.

[0001596532-16-000291:notes:14]
Financing Obligation—Build-to-Suit Lease

[0001596532-16-000291:notes:15]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013.  The underlying building asset is depreciated over the building’s estimated useful life of 30 years. At the conclusion of the initial lease term, we will de-recognize both the net book values of the asset and the remaining financing obligation. There have been no material changes in our financing obligation commitments under contractual obligation, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2015.

[0001596532-16-000291:notes:16]
As of June 30, 2016 and December 31, 2015, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $41.9 million and $42.5 million, respectively. As of June 30, 2016, $1.5 million and $40.4 million were recorded as short-term and long-term financing obligations, respectively.

[0001596532-16-000291:notes:17]
Land lease expense under our lease financing obligation included in rent expense above, amounted to $0.3 million and $0.6 million for both the three and six months ended June 30, 2016 and 2015, respectively.

[0001596532-16-000291:notes:18]
Purchase Commitments

[0001596532-16-000291:notes:19]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply.  We issue purchase orders to our contract manufacturers for finished product and a significant portion of these orders consist of firm non-cancelable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancelable, including integrated circuits, which are consigned to our contract manufacturers.   As of June 30, 2016, we had non-cancelable purchase commitments of $253.4 million up from $43.9 million as of December 31, 2015. This increase is primarily related to supply chain and production activities associated with our new U.S. operations and a planned increase in inventory levels in the third quarter of 2016.

[0001596532-16-000291:notes:20]
We have provided restricted deposits to our third-party contract manufacturers and vendors to secure our obligations to purchase inventory. We had $2.3 million in restricted deposits as of June 30, 2016 and December 31, 2015. Restricted deposits are classified in other assets in our accompanying unaudited condensed consolidated balance sheets.

[0001596532-16-000291:notes:21]
Guarantees

[0001596532-16-000291:notes:22]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for lease facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-16-000291:notes:23]
Legal Proceedings

[0001596532-16-000291:notes:24]
OptumSoft, Inc. Matters

[0001596532-16-000291:notes:25]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-16-000291:notes:26]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft copies of certain components of our software for evaluation by OptumSoft, (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches, (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers, (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us, and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dtd July 27, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.

[0001596532-16-000291:notes:27]
OptumSoft has identified certain software components it claims to own, which are generally applicable tools and utility subroutines and not networking specific code. We cannot assure which software components OptumSoft may ultimately claim to own in the litigation or whether such claimed components are material.

[0001596532-16-000291:notes:28]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we assert our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we assert that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We ask the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also assert that, even if we are found not to own any particular components at issue, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation. On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have meritorious defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-16-000291:notes:29]
The parties tried the case for Phase I of the proceedings, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015.  On December 16, 2015, the Court issued a Proposed Statement of Decision Following Phase 1 Trial, and on January 8, 2016, OptumSoft filed objections to that Proposed Statement of Decision.  On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all of the software put at issue in Phase I.  The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II.  Phase II was previously scheduled to be tried in April 2016; that trial date has been vacated, however, and a new trial date has not yet been set.

[0001596532-16-000291:notes:30]
We intend to vigorously defend against any action brought against us by OptumSoft. However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor. For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft. If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license. An adverse litigation ruling could result in a significant damages award against us and injunctive relief. In addition, OptumSoft could assert additional or different claims against us, including claims that our license from OptumSoft is invalid.

[0001596532-16-000291:notes:31]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated at this time.  However, the outcome of litigation is inherently uncertain.  Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-16-000291:notes:32]
Cisco Systems, Inc. (“Cisco”) Matters

[0001596532-16-000291:notes:33]
On December 5, 2014, Cisco filed two complaints against us in District Court for the Northern District of California, which are proceeding as Case No. 4:14-cv-05343 (“’43 Case”) and Case No. 5:14-cv-05344 (“’44 Case”).  In the ’43 Case, Cisco alleges that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the 875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”).  Cisco seeks, as relief for our alleged infringement in the ’43 Case, lost profits and/or reasonable royalty damages in an unspecified amount, including treble damages, attorney’s fees, and associated costs.  Cisco also seeks injunctive relief in the ’43 Case.  On February 10, 2015, the court granted our unopposed motion to stay the ’43 Case until the proceedings before the United States International Trade Commission (“USITC”) pertaining to the same patents (as discussed below) become final.  Trial has not been scheduled in the ’43 case.

[0001596532-16-000291:notes:34]
In the ’44 Case, Cisco’s complaint alleges that we infringe U.S. Patent Nos. 7,047,526 and 7,953,886 (respectively, “the ’526 patent” and “the ’886 patent”), and further alleges that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI.”  As relief for our alleged patent infringement in the ’44 Case, Cisco seeks lost profits and/or reasonable royalty damages in an unspecified amount including treble damages, attorney’s fees, and associated costs as well as injunctive relief. As relief for our alleged copyright infringement, Cisco seeks monetary damages for alleged lost profits, profits from our alleged infringement, statutory damages, attorney's fees and associated costs.  On February 13, 2015, we answered the complaint in the ’44 Case, denying the patent and copyright infringement allegations and also raising numerous affirmative defenses.  On March 6, 2015, Cisco filed an amended complaint against us the ’44 Case.  In response, we moved to dismiss Cisco’s allegations of willful patent infringement and pre-suit indirect patent infringement. The Court granted the motion with leave to amend on July 2, 2015. On July 23, 2015, Cisco filed an amended complaint.

[0001596532-16-000291:notes:35]
On January 25, 2016, we sought leave to file counterclaims against Cisco in the ’44 case for antitrust and unfair competition.  That motion was denied by order dated February 18, 2016, which also granted Arista leave to file those claims as a separate action.  On February 24, 2016, we filed a complaint containing our antitrust and unfair competition claims against Cisco in the District Court for the Northern District of California, which is proceeding as Case No. 5:16-cv-00923 (“’23 Case”).  In the ’23 Case, Cisco filed a motion to stay the litigation, or in the alternative, to dismiss the complaint on April 13, 2016, and a hearing on Cisco’s motion has been set for August 18, 2016. Trial has not been scheduled in the ’23 case.

[0001596532-16-000291:notes:36]
On May 17, 2016, the Patent and Trademark Appeals Board issued an order denying inter partes review on the ‘526 patent.  On May 25, 2016, the Patent and Trademark Appeals Board issued an order initiating inter partes review on the ‘886 patent.  In light of that order, in the ’44 case Cisco agreed to dismiss its claims as to the ‘886 patent with prejudice, and we dismissed our counterclaims as to the ‘886 patent without prejudice.  Summary judgment cross-motions in the ’44 case will be heard on August 4, 2016 and trial has been set for November 21, 2016.

[0001596532-16-000291:notes:37]
On December 19, 2014, Cisco filed two complaints against us in the USITC, alleging that Arista has violated Section 337 of the Tariff Act of 1930, as amended. The complaints have been instituted as ITC Inv. Nos. 337-TA-944 (“944 Investigation”) and 337-TA-945 (“945 Investigation”).   In the 944 Investigation, Cisco initially alleged that certain Arista switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents.  Cisco has subsequently dropped the ’296 patent from the 944 Investigation.  In the 945 Investigation, Cisco alleges that certain Arista switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents.  In both the 944 and 945 Investigations, Cisco seeks, among other things, a Limited Exclusion Order barring entry into the United States of accused switch products (including 7000 Series of switches) and components and software therein and a Cease and Desist Order against us restricting our activities with respect to our imported accused switch products and components and software therein.  On February 11, 2015, we responded to the notices of investigation and complaints in the 944 and 945 Investigations by, among other things, denying the patent infringement allegations and raising numerous affirmative defenses.

[0001596532-16-000291:notes:38]
The Administrative Law Judge assigned to the 944 Investigation issued a procedural schedule calling for, among other events:  an evidentiary hearing on September 9-11 and 15-17, 2015; issuance of an initial determination regarding our alleged violations on January 27, 2016; and the Target Date for completion on May 27, 2016.  On January 27, 2016 the Administrative Law Judge issued a revised procedural schedule extending the date for issuance of an initial determination to February 2, 2016 and the Target Date to June 2, 2016. On February 26, 2016, the Commission issued a notice resetting the deadline for determining whether to review the initial determination to April 11, 2016 and the Target Date to June 9, 2016. The hearing has been completed and all post trial briefs have been submitted to the USITC.  On February 2, 2016, the Administrative Law Judge issued his initial determination finding a violation of section 337 of the Tariff Act.  More specifically, it was found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringe asserted claims 1, 2, 8-11, and 17-19 of the ’537 patent; asserted claims 6, 7, 20, and 21 of the ’592 patent; and asserted claims 5, 7, 45, and 46 of the ’145 patent.  A violation of section 337 was not found with respect to any asserted claims of the ’597 and ’164 patents. On April 11, 2016, the Commission decided to review certain findings contained in the 944 initial determination. On June 23, 2016, the Commission issued its Final Determination, which found a violation with respect to the ’537, ’592, and ’145 patents, and found no violation with respect to the ’597 and ’164 patents.  The Commission also issued a Limited Exclusion Order and a Cease and Desist Order pertaining to network devices, related software and components thereof that infringe one or more of claims 1, 2, 8-11, and 17-19 of the ’537 patent, claims 6, 7, 20, and 21 of the ’592 patent, and claims 5, 7, 45, and 46 of the ’145 patent.  The Final Determination in the 944 Investigation is subject to Presidential review, which will be completed no later than August 22, 2016.

[0001596532-16-000291:notes:39]
The Administrative Law Judge assigned to the 945 Investigation issued a procedural schedule calling for, among other events:  an evidentiary hearing on November 9-20, 2015; issuance of an initial determination regarding our alleged violations on April 26, 2016; and the Target Date for completion on August 26, 2016.  The evidentiary hearing was conducted in November 2015 and all post-hearing briefing has been completed. On March 29, 2016, the ALJ issued a revised procedural schedule extending the deadline for issuance of an initial determination to August 26, 2016, and the Target Date to December 26, 2016.  On April 19, 2016, the Commission determined not to review this decision. We are awaiting the initial determination from the Administrative Law Judge. The initial determination will be subject to review by the Commission, which will then issue a Final Determination and any remedial orders on December 26, 2016. If the Final Determination finds a violation, it will be subject to Presidential review.

[0001596532-16-000291:notes:40]
On April 1, 2015, we filed petitions for Inter Partes Review with the United States Patent Trial and Appeal Board (“PTAB”) seeking to invalidate Cisco’s ’597, ’211, and ’668 patents.  On April 10, 2015, we filed petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853 and ’577 patents.  On April 16, 2015, we filed additional petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853 and ’577 patents.  On August 11, 2015, we filed a second petition for Inter Partes Review of Cisco’s ’668 patent.  On October 6, 2015 we filed a second petition for Inter Partes Review of Cisco’s ’211 patent, which was denied on April 12, 2016.  On October 6, 2015, the PTAB granted our petition for Inter Partes Review of Cisco’s ’597 patent and our first petition for Inter Partes review of Cisco’s ’211 patents, but denied one of our petitions for Inter Partes Review of Cisco’s ’668 patent. On October 19, 2015 and October 22, 2015, the PTAB denied four petitions relating to the ’853 and ’577 patents. On November 18, 2015, we filed a request for rehearing on one of the denied petitions related to the ’577 patent, which was denied on February 29, 2016.  On December 9, 2015, we filed a petition for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’537 patent, and additional petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853, ’577, and ’668 patents.  On February 16, 2016, the PTAB denied our second petition for Inter Partes review of the ’668 patent. On March 17, 2016, we filed a request for rehearing on this decision, which was denied on March 29, 2016. On June 6, 2016, the PTAB instituted an Inter Partes Review proceeding for the ’853 patent.  On June 11, 2016, the PTAB instituted Inter Partes Review proceedings for the ’577, ’668, and ’537 patents.  On June 27, 2016, we filed a request for rehearing with respect to certain claims of the ’537 patent which the PTAB did not include in the instituted Inter Partes Review proceeding and are awaiting a ruling on that request.  The PTAB must issue its final written decision on validity of the ’853 patent by June 6, 2017, and, for the ’577, ’668, and ’537 patents, by June 11, 2017.

[0001596532-16-000291:notes:41]
We intend to vigorously defend against Cisco’s lawsuits, as summarized in the preceding paragraphs.  However, we cannot be certain that any claims by Cisco would be resolved in our favor regardless of the merit of the claims.  For example, an adverse litigation ruling could result in a significant damages award against us, could further result in the above described injunctive relief, could result in a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products to the extent that we are found to infringe any valid claims asserted against us by Cisco.  Any such adverse ruling could materially adversely affect our business, prospects, reputation, results of operation and financial condition.

[0001596532-16-000291:notes:42]
In particular, with respect to the 944 Investigation, the USITC has issued a Limited Exclusion Order barring entry into the United States of our network devices (including 7000 Series of switches), related software and components thereof that infringe  one or more of  the claims of the ‘537, ‘592 and ‘145 patents specified above and a Cease and Desist Order restricting our activities with respect to such imported products. In the 945 Investigation, if our products are found to infringe any patents that are the subject of that investigation, such orders would likely be issued as well.  If the Limited Exclusion Order and Cease and Desist Order are not disapproved by the US Trade Representative, we will need to remove features or develop technical design-arounds in order to take the products outside of the scope of any patent found to have been infringed and the subject of a violation. We may not be successful in developing technical design-arounds that do not infringe the patents or that are acceptable to our customers. Our development efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management. Moreover, we may seek to obtain clearance for any such technical design-arounds from U.S. Customs and Border Patrol (“CBP”), and we may be unable to do so in a timely manner, if at all. In the case that we attempt to change our manufacturing, importation processes and shipping workflows to comply with the Limited Exclusion Order or Cease and Desist Order, such changes may be extremely costly, time consuming and we may not be able to implement such changes successfully. Any failure to develop effective technical design-arounds, obtain timely clearance of such technical design-arounds or successfully change our manufacturing, importation processes or shipping workflows in a manner that is compliant with the Limited Exclusion Order or Cease and Desist Order may cause a disruption in our shipments and materially and adversely affect our business, prospects, reputation, results of operations and financial condition.

[0001596532-16-000291:notes:43]
Cisco may also seek to enforce the Limited Exclusion Order and/or Cease and Desist Order issued in the 944 Investigation by filing for an enforcement action at the USITC.  The same would be true if such orders are issued in the 945 Investigation. In such a proceeding, we would need to demonstrate that our technical design-arounds render our products non-infringing or otherwise outside the scope of the Limited Exclusion Order or Cease and Desist Order.  If we are unable to do so then any product shipments after the effective date of the Limited Exclusion Order or Cease and Desist Order (whether from existing imported inventory or from products assembled from foreign sourced components) could be subject to significant civil penalties, potential seizure of that inventory which was found to have an ineffective technical design-around, and an order prohibiting the importation of further products until we implement additional technical design-arounds.

[0001596532-16-000291:notes:44]
Additionally, the existence of this lawsuit could cause concern among our customers and partners and could adversely affect our business and results of operations.  Whether or not we prevail in the lawsuit, we expect that the litigation will be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-16-000291:notes:45]
With respect to the various legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated at this time.  However, the outcome of litigation is inherently uncertain.  Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-16-000291:notes:46]
Other Matters

[0001596532-16-000291:notes:47]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.  We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated.  Based on currently available information, management does not believe that liability relating to these other unresolved matters is probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows.  However, litigation is subject to inherent uncertainties and our view of these matters may change in the future.  Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-16-000291:notes:48]
[same as prior period, unchanged from 0001596532-16-000255:notes:44]

[0001596532-16-000291:notes:49]
[same as prior period, unchanged from 0001596532-16-000255:notes:45]

[0001596532-16-000291:notes:50]
|  | Three Months EndedJune 30, | Six Months EndedJune 30, |
|  | 2016 |  | 2015 | 2016 |  | 2015 |
| Cost of revenue | $ | 868 |  |  | $ | 784 |  | $ | 1,661 |  |  | $ | 1,420 |  |
| Research and development | 7,595 |  |  | 6,379 |  | 15,052 |  |  | 11,307 |  |
| Sales and marketing | 3,780 |  |  | 2,865 |  | 7,427 |  |  | 5,274 |  |
| General and administrative | 1,989 |  |  | 1,180 |  | 3,452 |  |  | 2,046 |  |
| Total stock-based compensation | $ | 14,232 |  |  | $ | 11,208 |  | $ | 27,592 |  |  | $ | 20,047 |  |

[0001596532-16-000291:notes:51]
[same as prior period, unchanged from 0001596532-16-000255:notes:47]

[0001596532-16-000291:notes:52]
[same as prior period, unchanged from 0001596532-16-000255:notes:48]

[0001596532-16-000291:notes:53]
|  |  | Options and RSAs Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options and RSAs (in thousands) |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding (in thousands) |
| Outstanding—December 31, 2015 |  | 11,630 |  |  | $ | 24.49 |  |  | 7.6 |  | $ | 620,802 |  |
| Options granted |  | 440 |  |  | 56.88 |  |  |  |  |  |
| Options exercised |  | (825 | ) |  | 7.71 |  |  |  |  |  |
| Options canceled |  | (232 | ) |  | 29.16 |  |  |  |  |  |
| Outstanding—June 30, 2016 |  | 11,013 |  |  | $ | 26.94 |  |  | 7.3 |  | $ | 420,519 |  |
| Vested and exercisable—June 30, 2016 |  | 4,021 |  |  | $ | 13.25 |  |  | 6.4 |  | $ | 207,297 |  |
| Vested and expected to vest—June 30, 2016 |  | 10,449 |  |  | $ | 26.29 |  |  | 7.3 |  | $ | 405,623 |  |

[0001596532-16-000291:notes:54]
As of June 30, 2016, the total unrecognized stock-based compensation expense related to unvested stock options, net of expected forfeitures, was $103.6 million, which is expected to be recognized over a weighted-average period of 4.0 years.

[0001596532-16-000291:notes:55]
[same as prior period, unchanged from 0001596532-16-000255:notes:53]

[0001596532-16-000291:notes:56]
[same as prior period, unchanged from 0001596532-16-000255:notes:54]

[0001596532-16-000291:notes:57]
|  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2015 | 893 |  |  | $ | 70.14 |  |  | 1.9 |  | $ | 69,509 |  |
| RSUs granted | 369 |  |  | 61.81 |  |  |  |  |  |
| RSUs vested | (130 | ) |  | 69.02 |  |  |  |  |  |
| RSUs forfeited | (56 | ) |  | 67.29 |  |  |  |  |  |
| Unvested balance—June 30, 2016 | 1,076 |  |  | $ | 67.57 |  |  | 1.9 |  | $ | 69,302 |  |
| Vested and expected to vest—June 30, 2016 | 1,006 |  |  | $ | 67.60 |  |  | 1.8 |  | $ | 64,766 |  |

[0001596532-16-000291:notes:58]
As of June 30, 2016, there was $61.9 million of unrecognized stock-based compensation cost related to unvested RSUs, net of estimated forfeitures. This amount is expected to be recognized over a weighted-average period of 3.5 years.

[0001596532-16-000291:notes:59]
[same as prior period, unchanged from 0001596532-16-000255:notes:57]

[0001596532-16-000291:notes:60]
During the six months ended June 30, 2016, we issued 122,937 shares at an average purchase price of $39.76 under the 2014 Employee Stock Purchase Plan ("ESPP"). On February 17, 2015, the board authorized an increase to shares available for future issuance under the ESPP.  Per the ESPP, the increase is determined based on the lesser of 1% of total shares outstanding as of the first day of each fiscal year, or January 1, 2016, 2,500,000 shares or such amount as determined by our board of directors. The approved increase amounted to 681,315 shares. As of June 30, 2016, there remain 1,617,132 shares available for issuance under the ESPP.

[0001596532-16-000291:notes:61]
As of June 30, 2016, the total unrecognized stock-based compensation expense related to unvested ESPP options, net of expected forfeitures, was $2.1 million, which is expected to be recognized over a weighted-average period of 1.5 years.

[0001596532-16-000291:notes:62]
[same as prior period, unchanged from 0001596532-16-000255:notes:60]


## us-gaap:EarningsPerShareTextBlock

[0001596532-16-000291:notes:63]
[same as prior period, unchanged from 0001596532-16-000255:notes:61]

[0001596532-16-000291:notes:64]
[same as prior period, unchanged from 0001596532-16-000255:notes:62]

[0001596532-16-000291:notes:65]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Numerator: |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |
| Net income | $ | 38,904 |  |  | $ | 23,996 |  |  | $ | 74,149 |  |  | $ | 48,488 |  |
| Less: undistributed earnings allocated to participating securities | (287 | ) |  | (389 | ) |  | (614 | ) |  | (894 | ) |
| Net income available to common stockholders, basic | $ | 38,617 |  |  | $ | 23,607 |  |  | $ | 73,535 |  |  | $ | 47,594 |  |
| Diluted: |  |  |  |  |  |  |  |
| Net income attributable to common stockholders, basic | $ | 38,617 |  |  | $ | 23,607 |  |  | $ | 73,535 |  |  | $ | 47,594 |  |
| Add: undistributed earnings allocated to participating securities | 18 |  |  | 31 |  |  | 38 |  |  | 73 |  |
| Net income attributable to common stockholders, diluted | $ | 38,635 |  |  | $ | 23,638 |  |  | $ | 73,573 |  |  | $ | 47,667 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 68,275 |  |  | 65,524 |  |  | 68,006 |  |  | 65,018 |  |
| Diluted: |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 68,275 |  |  | 65,524 |  |  | 68,006 |  |  | 65,018 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options and RSUs | 4,488 |  |  | 5,497 |  |  | 4,466 |  |  | 5,708 |  |
| Employee stock purchase plan | 54 |  |  | 194 |  |  | 51 |  |  | 193 |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted | 72,817 |  |  | 71,215 |  |  | 72,523 |  |  | 70,919 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 0.57 |  |  | $ | 0.36 |  |  | $ | 1.08 |  |  | $ | 0.73 |  |
| Diluted | $ | 0.53 |  |  | $ | 0.33 |  |  | $ | 1.01 |  |  | $ | 0.67 |  |

[0001596532-16-000291:notes:66]
[same as prior period, unchanged from 0001596532-16-000255:notes:64]

[0001596532-16-000291:notes:67]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Stock options and RSUs to purchase common stock | 3,211 |  |  | 2,370 |  |  | 3,487 |  |  | 2,138 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-16-000291:notes:68]
[same as prior period, unchanged from 0001596532-16-000255:notes:66]

[0001596532-16-000291:notes:69]
|  | June 30, 2016 |
|  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 311,311 |  |  | $ | — |  |  | $ | — |  |  | $ | 311,311 |  |
| Money market funds-restricted | 4,041 |  |  | — |  |  | — |  |  | 4,041 |  |
| Commercial Paper | 17,975 |  |  | — |  |  | — |  |  | 17,975 |  |
| U.S. government notes | 125,424 |  |  | — |  |  | — |  |  | 125,424 |  |
| Corporate bonds | — |  |  | 149,361 |  |  | — |  |  | 149,361 |  |
| Total financial assets | $ | 458,751 |  |  | $ | 149,361 |  |  | $ | — |  |  | $ | 608,112 |  |

[0001596532-16-000291:notes:70]
[same as prior period, unchanged from 0001596532-16-000255:notes:68]


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-16-000291:notes:71]
[same as prior period, unchanged from 0001596532-16-000255:notes:69]

[0001596532-16-000291:notes:72]
[same as prior period, unchanged from 0001596532-16-000255:notes:70]

[0001596532-16-000291:notes:73]
[same as prior period, unchanged from 0001596532-16-000255:notes:71]

[0001596532-16-000291:notes:74]
[same as prior period, unchanged from 0001596532-16-000255:notes:72]

[0001596532-16-000291:notes:75]
[same as prior period, unchanged from 0001596532-16-000255:notes:73]

[0001596532-16-000291:notes:76]
[same as prior period, unchanged from 0001596532-16-000255:notes:74]

[0001596532-16-000291:notes:77]
[same as prior period, unchanged from 0001596532-16-000255:notes:75]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-16-000291:notes:78]
[same as prior period, unchanged from 0001596532-16-000255:notes:76]

[0001596532-16-000291:notes:79]
Provision for income taxes was approximately $13.9 million and $8.4 million for the three months ended June 30, 2016 and 2015, and $28.0 million and $18.4 million for the six months ended June 30, 2016 and 2015, respectively. The change in the provision was a result of an increase in profit before income taxes and the change in effective tax rate based on current geographical distribution of the earnings.

[0001596532-16-000291:notes:80]
[same as prior period, unchanged from 0001596532-16-000255:notes:78]

[0001596532-16-000291:notes:81]
[same as prior period, unchanged from 0001596532-16-000255:notes:79]

[0001596532-16-000291:notes:82]
Our gross unrecognized tax benefits as of June 30, 2016 were $23.5 million.  If the gross unrecognized tax benefits as of June 30, 2016 were realized in future periods, this could result in a tax benefit of $14.7 million within our provision of income taxes.  Because of the net operating loss and tax credit carryforwards, substantially all of our tax years remain open to tax examinations and we are unable to estimate the full range of possible adjustments to the balance of gross unrecognized tax benefits.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001596532-16-000291:notes:83]
[same as prior period, unchanged from 0001596532-16-000255:notes:81]

[0001596532-16-000291:notes:84]
[same as prior period, unchanged from 0001596532-16-000255:notes:82]

[0001596532-16-000291:notes:85]
As of June 30, 2016 and December 31, 2015, we held non-marketable equity investments of approximately $36.1 million and $33.6 million, respectively, in privately-held companies which are accounted for under the cost method. During the quarter ended June 30, 2016 we made an additional investment of $2.5 million in one of these companies, which was accounted for under the cost method. There were no impairments recognized on our investments for the six months ended June 30, 2016.

[0001596532-16-000291:notes:86]
[same as prior period, unchanged from 0001596532-16-000255:notes:84]

[0001596532-16-000291:notes:87]
As of June 30, 2016 and December 31, 2015, we have a $3.0 million promissory note with a privately-held company, which was recorded at cost. The interest rate on the promissory note is 8.0% per annum and is payable quarterly. All unpaid principal and accrued interest on the promissory note is due and payable on the earlier of August 26, 2017 or upon a default.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-16-000291:notes:88]
In May 2014, the FASB issued ASU No. 2014-09, Revenue From Contracts With Customers (Topic 606), (as amended in June 2016, by ASU No. 2016-12-Revenue-Narrow-Scope Improvements and Practical Expedients), which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition.

[0001596532-16-000291:notes:89]
In July 2015, the FASB issued ASU No. 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, deferring the effective date of the new revenue standard by one year. In March 2016, the FASB issued ASU No. 2016-08, Revenue From Contracts With Customers-Principal versus Agent Considerations (Reporting Revenue Gross versus Net), and ASU No. 2016-10, Revenue From Contracts With Customers-Identifying Performance Obligations and Licensing. ASU No. 2016-08 clarifies the implementation guidance regarding principal versus agent identification and related considerations. Specifically, the guidance provides clarification around performance obligations for goods or services provided by another entity, assisting in determining whether the entity is the provider of the goods or services, the principal, or whether the entity is providing for the arrangement of the goods or services, the agent.  ASU No. 2016-10 provides guidance around identifying whether promised goods or services are distinct and separately identifiable, whether promised goods or services are material or immaterial to the contract, and whether shipping and handling is considered an activity to fulfill a promise or an additional promised service. ASU No. 2016-10 also provides guidance around an entity's promise to grant a license providing a customer with either a right to use or a right to access the license, which then determines whether the obligation is satisfied at a point in time or over time, respectively.

[0001596532-16-000291:notes:90]
In May 2016, the FASB issued ASU No. 2016-11, Revenue Recognition (Topic 605) and Derivatives and Hedging (Topic 815): Rescission of SEC Guidance Because of Accounting Standards Updates 2014-09 and 2014-16 Pursuant to Staff Announcements at the March 3, 2016 EITF Meeting (SEC Update)") ("ASU 2016-11"), which rescinds various standards codified as part of Topic 605, Revenue Recognition in relation to the future adoption of Topic 606. These rescissions include changes to topics pertaining to revenue and expense recognition including accounting for shipping and handling fees and costs and accounting for consideration given by a vendor to a customer.

[0001596532-16-000291:notes:91]
The above standards are effective for fiscal years (and interim reporting periods within those years) beginning after December 15, 2017.  The guidance is effective for us beginning in our first quarter of fiscal 2018. Early adoption would be permitted for all entities but not until the fiscal year beginning after December 15, 2016. The standard permits the use of either the retrospective or cumulative effect transition method. The retrospective method requires a retrospective approach to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance. The cumulative approach requires a retrospective approach with the cumulative effect of initially applying the guidance recognized at the date. of initial application and providing certain additional disclosures as defined per the guidance. We are currently reviewing the provisions of the standard and have not yet selected a transition method nor have we determined the effect of the standard on our consolidated financial statements.

[0001596532-16-000291:notes:92]
In July 2015, the FASB issued ASU No, 2015-11, Inventory: Simplifying the Measurement of Inventory, which simplifies the measurement of inventory to be measured at the lower of cost or net realizable value. The guidance applies to inventory measured using First in First Out ("FIFO") or average cost. The guidance is effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. The standard is effective for us for our first quarter of fiscal 2017.  The guidance can be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

[0001596532-16-000291:notes:93]
In January 2016, the FASB issued ASU No, 2016-01, Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities, which enhances the reporting model for financial instruments to provide users of financial statements with more decision-useful information. The guidance will address certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. The guidance is effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. The standard is effective for us for our first quarter of fiscal 2018.  The guidance may be early adopted under early application guidance. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

[0001596532-16-000291:notes:94]
In February 2016, the FASB issued ASU No, 2016-02, Leases, which addresses the classification and recognition of lease assets and liabilities formerly classified as operating leases under GAAP. The guidance will address certain aspects of recognition and measurement, and quantitative and qualitative aspects of presentation and disclosure. The guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. The standard is effective for us for our first quarter of fiscal 2019.  The guidance will be applied to the earliest period presented using a modified retrospective approach. The guidance includes practical expedients that relate to identification, classification, and initial direct costs associated with leases commencing prior to the effective date, and the ability to apply hindsight in evaluating lease options related to extensions, terminations or asset purchases.  A practical expedient also exists to treat leases entered into prior effective date under existing GAAP unless the lease has been modified. The guidance may be early adopted. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

[0001596532-16-000291:notes:95]
In March 2016, the FASB amended the existing accounting standards for stock-based compensation, ASU 2016-09, Compensation-Stock Compensation: Improvements to Employee Share-Based Payment Accounting, which impact several aspects of accounting for share-based payment transactions, including the income tax consequences, forfeitures, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The guidance is effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. The standard is effective for us for our first quarter of fiscal 2017.  The guidance may be early adopted under early application guidance. If early adoption is elected, all amendments must be adopted in the same period. The manner of application varies by the various provisions of the guidance, with certain provisions applied on a retrospective or modified retrospective approach, while others are applied prospectively.  We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-16-000291:notes:96]
[same as prior period, unchanged from 0001596532-16-000255:notes:94]

[0001596532-16-000291:notes:97]
[same as prior period, unchanged from 0001596532-16-000255:notes:95]

[0001596532-16-000291:notes:98]
[same as prior period, unchanged from 0001596532-16-000255:notes:96]

[0001596532-16-000291:notes:99]
[same as prior period, unchanged from 0001596532-16-000255:notes:97]

[0001596532-16-000291:notes:100]
[same as prior period, unchanged from 0001596532-16-000255:notes:98]

[0001596532-16-000291:notes:101]
[same as prior period, unchanged from 0001596532-16-000255:notes:99]

[0001596532-16-000291:notes:102]
[same as prior period, unchanged from 0001596532-16-000255:notes:100]

[0001596532-16-000291:notes:103]
[same as prior period, unchanged from 0001596532-16-000255:notes:101]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001596532-16-000291:notes:104]
[same as prior period, unchanged from 0001596532-16-000255:notes:102]

[0001596532-16-000291:notes:105]
|  | June 30, 2016 |  | December 31, 2015 |
| Equipment and machinery | $ | 36,062 |  |  | $ | 29,101 |  |
| Computer hardware and software | 15,600 |  |  | 12,630 |  |
| Furniture and fixtures | 2,853 |  |  | 2,380 |  |
| Leasehold improvements | 29,466 |  |  | 24,372 |  |
| Building | 35,154 |  |  | 35,154 |  |
| Construction-in-process | 343 |  |  | 6,408 |  |
| Property and equipment, gross | 119,478 |  |  | 110,045 |  |
| Less: accumulated depreciation | (39,797 | ) |  | (30,339 | ) |
| Property and equipment, net | $ | 79,681 |  |  | $ | 79,706 |  |


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001596532-16-000291:notes:106]
[same as prior period, unchanged from 0001596532-16-000255:notes:104]

[0001596532-16-000291:notes:107]
|  | June 30, 2016 |  | December 31, 2015 |
| Accounts receivable | $ | 148,007 |  |  | $ | 145,792 |  |
| Allowance for doubtful accounts | (306 | ) |  | (963 | ) |
| Sales return reserve | (1,042 | ) |  | (566 | ) |
| Accounts receivable, net | $ | 146,659 |  |  | $ | 144,263 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001596532-16-000291:notes:108]
[same as prior period, unchanged from 0001596532-16-000255:notes:106]

[0001596532-16-000291:notes:109]
|  | June 30, 2016 |  | December 31, 2015 |
| Accrued payroll related costs | $ | 30,878 |  |  | $ | 39,479 |  |
| Accrued warranty costs | 4,841 |  |  | 4,718 |  |
| Accrued manufacturing costs | 6,920 |  |  | 6,397 |  |
| Accrued professional fees | 5,718 |  |  | 4,875 |  |
| Accrued taxes | 1,257 |  |  | 1,347 |  |
| Other | 5,496 |  |  | 4,155 |  |
| Total accrued liabilities | $ | 55,110 |  |  | $ | 60,971 |  |


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001596532-16-000291:notes:110]
[same as prior period, unchanged from 0001596532-16-000255:notes:108]

[0001596532-16-000291:notes:111]
|  | June 30, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper | $ | 17,924 |  |  | $ | 51 |  |  | $ | — |  |  | $ | 17,975 |  |
| U.S. government notes | 125,398 |  |  | 37 |  |  | (11 | ) |  | 125,424 |  |
| Corporate bonds | 149,231 |  |  | 235 |  |  | (105 | ) |  | 149,361 |  |
| Total marketable securities | $ | 292,553 |  |  | $ | 323 |  |  | $ | (116 | ) |  | $ | 292,760 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001596532-16-000291:notes:112]
[same as prior period, unchanged from 0001596532-16-000255:notes:110]

[0001596532-16-000291:notes:113]
|  | June 30, 2016 |  | December 31, 2015 |
| Raw materials | $ | 41,730 |  |  | $ | 29,831 |  |
| Finished goods | 76,400 |  |  | 62,298 |  |
| Total inventories | $ | 118,130 |  |  | $ | 92,129 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001596532-16-000291:notes:114]
[same as prior period, unchanged from 0001596532-16-000255:notes:112]

[0001596532-16-000291:notes:115]
|  | June 30, 2016 |  | December 31, 2015 |
| Prepaid income taxes | $ | 16,131 |  |  | $ | 14,150 |  |
| Other current assets | 27,513 |  |  | 29,270 |  |
| Other prepaid expenses and deposits | 9,803 |  |  | 7,190 |  |
| Total prepaid expenses and other current assets | $ | 53,447 |  |  | $ | 50,610 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001596532-16-000291:notes:116]
[same as prior period, unchanged from 0001596532-16-000255:notes:114]

[0001596532-16-000291:notes:117]
|  | Six Months EndedJune 30, |
|  | 2016 |  | 2015 |
| Warranty accrual, beginning of period | $ | 4,718 |  |  | $ | 3,204 |  |
| Liabilities accrued for warranties issued during the period | 1,438 |  |  | 1,602 |  |
| Warranty costs incurred during the period | (1,018 | ) |  | (834 | ) |
| Adjustments related to change in estimate | (297 | ) |  | — |  |
| Warranty accrual, end of period | $ | 4,841 |  |  | $ | 3,972 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001596532-16-000291:notes:118]
[same as prior period, unchanged from 0001596532-16-000255:notes:116]

[0001596532-16-000291:notes:119]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| United States | $ | 198,958 |  |  | $ | 148,303 |  |  | $ | 379,834 |  |  | $ | 271,456 |  |
| Other Americas | 2,359 |  |  | 2,560 |  |  | 4,124 |  |  | 6,164 |  |
| Europe, Middle East and Africa | 42,644 |  |  | 24,782 |  |  | 86,383 |  |  | 64,872 |  |
| Asia-Pacific | 24,780 |  |  | 19,907 |  |  | 40,596 |  |  | 32,105 |  |
| Total revenue | $ | 268,741 |  |  | $ | 195,552 |  |  | $ | 510,937 |  |  | $ | 374,597 |  |

[0001596532-16-000291:notes:120]
[same as prior period, unchanged from 0001596532-16-000255:notes:118]

[0001596532-16-000291:notes:121]
|  | June 30, 2016 |  | December 31, 2015 |
| United States | $ | 70,646 |  |  | $ | 70,719 |  |
| International | 9,035 |  |  | 8,987 |  |
| Total | $ | 79,681 |  |  | $ | 79,706 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-16-000291:notes:122]
[same as prior period, unchanged from 0001596532-16-000255:notes:120]

[0001596532-16-000291:notes:123]
[same as prior period, unchanged from 0001596532-16-000255:notes:121]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-16-000291:notes:124]
[same as prior period, unchanged from 0001596532-16-000255:notes:122]

[0001596532-16-000291:notes:125]
[same as prior period, unchanged from 0001596532-16-000255:notes:123]

[0001596532-16-000291:notes:126]
As of June 30, 2016, there have been no other-than-temporary losses on our marketable securities. None of our marketable securities have been in continuous unrealized loss positions for greater than twelve months as of June 30, 2016.  We had no marketable securities as of December 31, 2015.

[0001596532-16-000291:notes:127]
We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. As interest rates increase, those marketable securities purchased at a lower yield show a mark-to-market unrealized loss. The unrealized losses are due primarily to changes in credit spreads and interest rates. We expect to realize the full value of these investments upon maturity or sale.

[0001596532-16-000291:notes:128]
The weighted average remaining duration of our current marketable securities is approximately 0.8 years as of June 30, 2016.  As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying consolidated balance sheets.

[0001596532-16-000291:notes:129]
[same as prior period, unchanged from 0001596532-16-000255:notes:127]

[0001596532-16-000291:notes:130]
[same as prior period, unchanged from 0001596532-16-000255:notes:128]

[0001596532-16-000291:notes:131]
[same as prior period, unchanged from 0001596532-16-000255:notes:129]

[0001596532-16-000291:notes:132]
[same as prior period, unchanged from 0001596532-16-000255:notes:130]

[0001596532-16-000291:notes:133]
Building consists of capitalized construction costs of our leased building in Santa Clara, California. Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction, such as our financial involvement in structural elements of asset construction, making decisions related to tenant improvement costs and purchasing insurance not reimbursable by the buyer-lessor (the Landlord), we were deemed the owner of the building (for accounting purposes only) during the construction period. We continue to maintain involvement in the property post construction completion, and lack transferability of the risks and rewards of ownership, due to our required maintenance of a $4.0 million letter of credit, in addition to our ability and option to sublease our portion of the leased building for fees substantially higher than our base rate.  Due to our continuing involvement in the property post construction and lack of transferability of related risks and rewards of ownership to the Landlord after construction completion, we account for the building as a financing obligation. See “Note 5 - Commitments and Contingencies". Accordingly, as of June 30, 2016 and December 31, 2015, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the Landlord. The building was completed in 2014.

[0001596532-16-000291:notes:134]
Depreciation and amortization expense was $4.8 million, $3.3 million, $9.7 million, and $6.2 million for the three and six months ended June 30, 2016 and 2015, respectively.

[0001596532-16-000291:notes:135]
[same as prior period, unchanged from 0001596532-16-000255:notes:133]

[0001596532-16-000291:notes:136]
[same as prior period, unchanged from 0001596532-16-000255:notes:134]

[0001596532-16-000291:notes:137]
[same as prior period, unchanged from 0001596532-16-000255:notes:135]
