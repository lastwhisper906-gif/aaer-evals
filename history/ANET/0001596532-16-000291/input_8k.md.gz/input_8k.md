# ANET 8-K — 0001596532-16-000289 filed 2016-08-04

## item codes, every 8-K on or before 2016-08-05

- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2016-08-05

- none on or before 2016-08-05

## item 2.02 — earnings release, exhibit 99.1

[0001596532-16-000289:8k_2_02:1]
EX-99.1
2
ex991q216-earnings.htm
EXHIBIT 99.1

[0001596532-16-000289:8k_2_02:2]
Exhibit

[0001596532-16-000289:8k_2_02:3]
Exhibit 99.1

[0001596532-16-000289:8k_2_02:4]
Arista Networks, Inc. Reports Second Quarter 2016 Financial Results

[0001596532-16-000289:8k_2_02:5]
Cloud Networking Adoption Drives Record Revenue

[0001596532-16-000289:8k_2_02:6]
SANTA CLARA, Calif., August 4, 2016 - Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large data center and computing environments, today announced financial results for its second quarter ended June 30, 2016.

[0001596532-16-000289:8k_2_02:7]
Second Quarter Financial Highlights

[0001596532-16-000289:8k_2_02:8]
| • | Revenue of $268.7 million, an increase of 11.0% compared to the first quarter of 2016, and an increase of 37.4% from the second quarter of 2015. |

[0001596532-16-000289:8k_2_02:9]
| • | GAAP gross margin of 63.8%, compared to GAAP gross margin of 64.0% in the first quarter of 2016 and 65.4% in the second quarter of 2015. |

[0001596532-16-000289:8k_2_02:10]
| • | Non-GAAP gross margin of 64.1%, compared to non-GAAP gross margin of 64.4% in the first quarter of 2016 and 65.8% in the second quarter of 2015. |

[0001596532-16-000289:8k_2_02:11]
| • | GAAP net income of $38.9 million, or $0.53 per diluted share, compared to GAAP net income of $24.0 million, or $0.33 per diluted share, in the second quarter of 2015. |

[0001596532-16-000289:8k_2_02:12]
| • | Non-GAAP net income of $53.7 million, or $0.74 per diluted share, compared to non-GAAP net income of $38.8 million, or $0.54 per diluted share, in the second quarter of 2015. |

[0001596532-16-000289:8k_2_02:13]
"We are in the midst of a multi-year shift from legacy IT silos to cloud networking,” stated Jayshree Ullal, Arista President and CEO. “This quarter puts Arista at a billion-dollar run rate, which is a fitting validation of this trend, based on our innovative cloud-class, cloud-scale and cloud-converged offerings.”

[0001596532-16-000289:8k_2_02:14]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, “We are pleased with our financial performance in the second quarter which reflects strong adoption of our new products and consistent operational execution.”

[0001596532-16-000289:8k_2_02:15]
Company Highlights

[0001596532-16-000289:8k_2_02:16]
| • | Introduced the Arista 7280R Series Universal Leaf, a new fixed switching and routing platform for next generation data centers which leverages Arista’s Universal Cloud Network architecture to reduce operational costs through a single platform capable of a broad set of leaf networking use-cases, especially IP storage, routing and digital media. |

[0001596532-16-000289:8k_2_02:17]
| • | Positioned by Gartner, Inc. in the “Leaders” quadrant of the 16 May 2016 Magic Quadrant for Data Center Networking. |

[0001596532-16-000289:8k_2_02:18]
| • | Ranked as Number Two on the Forbes Fast Tech 25, a list of the 25 fastest growing Public Tech companies, based on three-year average sales growth of 63%. |

[0001596532-16-000289:8k_2_02:19]
Financial Outlook

[0001596532-16-000289:8k_2_02:20]
For the third quarter of 2016, we expect:

[0001596532-16-000289:8k_2_02:21]
| • | Revenue between $279 and $285 million. |

[0001596532-16-000289:8k_2_02:22]
| • | Non-GAAP gross margin between 62% to 65%, and |

[0001596532-16-000289:8k_2_02:23]
| • | Non-GAAP operating margin of approximately 26%. |

[0001596532-16-000289:8k_2_02:24]
Guidance for non-GAAP financial measures excludes legal expenses of approximately $11 million associated with the OptumSoft and Cisco litigation, stock-based compensation and other non-recurring expenses.  A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below).

[0001596532-16-000289:8k_2_02:25]
Prepared Materials and Conference Call Information

[0001596532-16-000289:8k_2_02:26]
Arista executives will discuss second quarter 2016 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial 1-877-201-0168 in the United States or 1-647-788-4901 from outside the US. The Conference ID is 43898212.

[0001596532-16-000289:8k_2_02:27]
The financial results conference call will also be available via live webcast on our investor relations website at investors.arista.com.  Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s Investor Relations website.

[0001596532-16-000289:8k_2_02:28]
Forward-Looking Statements

[0001596532-16-000289:8k_2_02:29]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the third quarter of fiscal 2016, statements regarding the ongoing shift to cloud networking, and statements regarding the benefits from the introduction of the Arista 7280R Series. Forward-looking statements are subject to a number of uncertainties and risks that could cause actual results to differ materially from those anticipated in the forward-looking statements including risks associated with: Arista Networks’ limited operating history; risks associated with Arista Networks’ rapid growth; Arista Networks’ customer concentration; Arista Networks’ dispute with Cisco Systems, Inc.  including Arista Networks’ ability to obtain a determination that alternative product implementations are not covered by remedial orders; Arista Networks’ dispute with OptumSoft, Inc.; requests for more favorable terms and conditions from our large end customers; declines in the sales prices of our products and services; changes in customer order patterns or customer mix; increased competition in our products and service markets, including the data center market; dependence on the introduction and market acceptance of new product offerings and standards; rapid technological and market change; the evolution of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; and general market, political, economic and business conditions.  Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s Quarterly Reporting on Form 10-Q filed with the SEC on May 5, 2016, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at http://investors.arista.com and on the SEC’s website at www.sec.gov. All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-16-000289:8k_2_02:30]
Non-GAAP Financial Measures

[0001596532-16-000289:8k_2_02:31]
The company reports certain non-GAAP financial measures that exclude stock-based compensation expenses, expenses associated with the OptumSoft and Cisco litigation, and other non-recurring charges. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends.  In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-16-000289:8k_2_02:32]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP net income, net income per diluted share, gross margin, or operating margin. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-16-000289:8k_2_02:33]
The Company’s guidance for non-GAAP financial measures excludes stock-based compensation, expenses associated with the OptumSoft and Cisco litigation, and other non-recurring charges. The Company has not reconciled its non-GAAP gross margin or its non-GAAP operating margin guidance to GAAP gross margin or GAAP operating margin, because we do not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling cash and non-cash items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. Share-based compensation expense is impacted by the Company’s future hiring and retention needs, as well as the future fair market value of the Company’s common stock, all of which is difficult to predict and subject to constant change. The actual amount of share-based compensation in the fiscal third quarter of 2016 will have a significant impact on the Company’s GAAP gross margin and GAAP operating margin. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measure is not available without unreasonable effort.

[0001596532-16-000289:8k_2_02:34]
About Arista Networks

[0001596532-16-000289:8k_2_02:35]
Arista Networks was founded to pioneer and deliver software-driven cloud networking solutions for large data center storage and computing environments. Arista’s award-winning platforms, ranging in Ethernet speeds from 10 to 100 gigabits per second, redefine scalability, agility and resilience. Arista has shipped more than five million cloud networking ports worldwide with CloudVision and EOS, an advanced network operating system. Committed to open standards, Arista is a founding member of the 25/50GbE consortium. Arista Networks products are available worldwide directly and through partners.

[0001596532-16-000289:8k_2_02:36]
ARISTA, EOS, CloudVision, Spline, NetDB and FlexRoute are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-16-000289:8k_2_02:37]
Additional information and resources can be found at: http://www.arista.com.

[0001596532-16-000289:8k_2_02:38]
| Media ContactAmanda JaramilloCorporate Communications(408) 547-5798amanda@arista.com |  | Investor ContactChuck ElliottProduct and Investor Advocacy(408) 547-5549chuck@arista.com |

[0001596532-16-000289:8k_2_02:39]
ARISTA NETWORKS, INC.

[0001596532-16-000289:8k_2_02:40]
Condensed Consolidated Statements of Income

[0001596532-16-000289:8k_2_02:41]
(Unaudited in thousands, except per share amounts)

[0001596532-16-000289:8k_2_02:42]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 235,616 |  |  | $ | 174,072 |  |  | $ | 448,091 |  |  | $ | 334,213 |  |
| Service | 33,125 |  |  | 21,480 |  |  | 62,846 |  |  | 40,384 |  |
| Total revenue | 268,741 |  |  | 195,552 |  |  | 510,937 |  |  | 374,597 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 88,021 |  |  | 60,014 |  |  | 166,934 |  |  | 114,453 |  |
| Service | 9,269 |  |  | 7,648 |  |  | 17,462 |  |  | 14,500 |  |
| Total cost of revenue | 97,290 |  |  | 67,662 |  |  | 184,396 |  |  | 128,953 |  |
| Gross profit | 171,451 |  |  | 127,890 |  |  | 326,541 |  |  | 245,644 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 69,020 |  |  | 49,947 |  |  | 131,535 |  |  | 93,287 |  |
| Sales and marketing | 31,744 |  |  | 26,681 |  |  | 59,350 |  |  | 51,268 |  |
| General and administrative | 17,529 |  |  | 18,403 |  |  | 32,763 |  |  | 32,475 |  |
| Total operating expenses | 118,293 |  |  | 95,031 |  |  | 223,648 |  |  | 177,030 |  |
| Income from operations | 53,158 |  |  | 32,859 |  |  | 102,893 |  |  | 68,614 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (732 | ) |  | (832 | ) |  | (1,483 | ) |  | (1,653 | ) |
| Other income (expense), net | 416 |  |  | 417 |  |  | 753 |  |  | (51 | ) |
| Total other income (expense), net | (316 | ) |  | (415 | ) |  | (730 | ) |  | (1,704 | ) |
| Income before provision for income taxes | 52,842 |  |  | 32,444 |  |  | 102,163 |  |  | 66,910 |  |
| Provision for income taxes | 13,938 |  |  | 8,448 |  |  | 28,014 |  |  | 18,422 |  |
| Net income | $ | 38,904 |  |  | $ | 23,996 |  |  | $ | 74,149 |  |  | $ | 48,488 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 38,617 |  |  | $ | 23,607 |  |  | $ | 73,535 |  |  | $ | 47,594 |  |
| Diluted | $ | 38,635 |  |  | $ | 23,638 |  |  | $ | 73,573 |  |  | $ | 47,667 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 0.57 |  |  | $ | 0.36 |  |  | $ | 1.08 |  |  | $ | 0.73 |  |
| Diluted | $ | 0.53 |  |  | $ | 0.33 |  |  | $ | 1.01 |  |  | $ | 0.67 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | 68,275 |  |  | 65,524 |  |  | 68,006 |  |  | 65,018 |  |
| Diluted | 72,817 |  |  | 71,215 |  |  | 72,523 |  |  | 70,919 |  |

[0001596532-16-000289:8k_2_02:43]
ARISTA NETWORKS, INC.

[0001596532-16-000289:8k_2_02:44]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-16-000289:8k_2_02:45]
(Unaudited in thousands, except percentages and per share amounts)

[0001596532-16-000289:8k_2_02:46]
|  | Three Months EndedMarch 31, |  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2016 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| GAAP gross profit | $ | 155,090 |  |  | $ | 171,451 |  |  | $ | 127,890 |  |  | $ | 326,541 |  |  | $ | 245,644 |  |
| GAAP gross margin | 64.0 | % |  | 63.8 | % |  | 65.4 | % |  | 63.9 | % |  | 65.6 | % |
| Stock-based compensation expense | 793 |  |  | 868 |  |  | 784 |  |  | 1,661 |  |  | 1,420 |  |
| Non-GAAP gross profit | $ | 155,883 |  |  | $ | 172,319 |  |  | $ | 128,674 |  |  | $ | 328,202 |  |  | $ | 247,064 |  |
| Non-GAAP gross margin | 64.4 | % |  | 64.1 | % |  | 65.8 | % |  | 64.2 | % |  | 66.0 | % |
| GAAP income from operations | $ | 49,735 |  |  | $ | 53,158 |  |  | $ | 32,859 |  |  | $ | 102,893 |  |  | $ | 68,614 |  |
| Stock-based compensation expense | 13,360 |  |  | 14,232 |  |  | 11,208 |  |  | 27,592 |  |  | 20,047 |  |
| Litigation expense | 7,005 |  |  | 7,594 |  |  | 9,909 |  |  | 14,599 |  |  | 16,579 |  |
| Non-GAAP income from operations | $ | 70,100 |  |  | $ | 74,984 |  |  | $ | 53,976 |  |  | $ | 145,084 |  |  | $ | 105,240 |  |
| Non-GAAP operating margin | 28.9 | % |  | 27.9 | % |  | 27.6 | % |  | 28.4 | % |  | 28.1 | % |
| GAAP net income | $ | 35,245 |  |  | $ | 38,904 |  |  | $ | 23,996 |  |  | $ | 74,149 |  |  | $ | 48,488 |  |
| Stock-based compensation expense | 13,360 |  |  | 14,232 |  |  | 11,208 |  |  | 27,592 |  |  | 20,047 |  |
| Litigation expense | 7,005 |  |  | 7,594 |  |  | 9,909 |  |  | 14,599 |  |  | 16,579 |  |
| Income tax effect on non-GAAP exclusions | (6,524 | ) |  | (7,056 | ) |  | (6,335 | ) |  | (13,580 | ) |  | (10,804 | ) |
| Non-GAAP net income | $ | 49,086 |  |  | $ | 53,674 |  |  | $ | 38,778 |  |  | $ | 102,760 |  |  | $ | 74,310 |  |
| Weighted-average shares used in computing diluted net income per share attributable to common stockholders | 72,214 |  |  | 72,817 |  |  | 71,215 |  |  | 72,523 |  |  | 70,919 |  |
| GAAP diluted net income per share attributable to common stockholders | $ | 0.48 |  |  | $ | 0.53 |  |  | $ | 0.33 |  |  | $ | 1.01 |  |  | $ | 0.67 |  |
| Net income attributable to participating securities | — |  |  | — |  |  | — |  |  | 0.01 |  |  | 0.01 |  |
| Non-GAAP adjustments to net income | 0.20 |  |  | 0.21 |  |  | 0.21 |  |  | 0.40 |  |  | 0.37 |  |
| Non-GAAP diluted net income per share | $ | 0.68 |  |  | $ | 0.74 |  |  | $ | 0.54 |  |  | $ | 1.42 |  |  | $ | 1.05 |  |
| Summary of Stock-Based Compensation Expense |  |  |  |  |  |  |  |  |  |
| Cost of revenue | $ | 793 |  |  | $ | 868 |  |  | $ | 784 |  |  | $ | 1,661 |  |  | $ | 1,420 |  |
| Research and development | 7,457 |  |  | 7,595 |  |  | 6,379 |  |  | 15,052 |  |  | 11,307 |  |
| Sales and marketing | 3,647 |  |  | 3,780 |  |  | 2,865 |  |  | 7,427 |  |  | 5,274 |  |
| General and administrative | 1,463 |  |  | 1,989 |  |  | 1,180 |  |  | 3,452 |  |  | 2,046 |  |
| Total | $ | 13,360 |  |  | $ | 14,232 |  |  | $ | 11,208 |  |  | $ | 27,592 |  |  | $ | 20,047 |  |

[0001596532-16-000289:8k_2_02:47]
ARISTA NETWORKS, INC.

[0001596532-16-000289:8k_2_02:48]
Consolidated Balance Sheets

[0001596532-16-000289:8k_2_02:49]
(Unaudited in thousands)

[0001596532-16-000289:8k_2_02:50]
|  | June 30, |  | December 31, |
|  | 2016 |  | 2015 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 531,058 |  |  | $ | 687,326 |  |
| Marketable securities | 292,760 |  |  | — |  |
| Accounts receivable | 146,659 |  |  | 144,263 |  |
| Inventories | 118,130 |  |  | 92,129 |  |
| Prepaid expenses and other current assets | 53,447 |  |  | 50,610 |  |
| Total current assets | 1,142,054 |  |  | 974,328 |  |
| Property and equipment, net | 79,681 |  |  | 79,706 |  |
| Investments | 39,136 |  |  | 36,636 |  |
| Deferred tax assets | 55,305 |  |  | 48,429 |  |
| Other assets | 18,812 |  |  | 20,791 |  |
| TOTAL ASSETS | $ | 1,334,988 |  |  | $ | 1,159,890 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 60,097 |  |  | $ | 43,966 |  |
| Accrued liabilities | 55,110 |  |  | 60,971 |  |
| Deferred revenue | 138,885 |  |  | 122,049 |  |
| Other current liabilities | 9,347 |  |  | 8,025 |  |
| Total current liabilities | 263,439 |  |  | 235,011 |  |
| Income taxes payable | 16,086 |  |  | 14,060 |  |
| Lease financing obligations, non-current | 40,438 |  |  | 41,210 |  |
| Deferred revenue, non-current | 91,439 |  |  | 74,759 |  |
| Other long-term liabilities | 6,754 |  |  | 6,698 |  |
| TOTAL LIABILITIES | 418,156 |  |  | 371,738 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 7 |  |  | 7 |  |
| Additional paid-in capital | 592,465 |  |  | 537,904 |  |
| Retained earnings | 325,065 |  |  | 250,916 |  |
| Accumulated other comprehensive loss | (705) |  |  | (675 | ) |
| TOTAL STOCKHOLDERS’ EQUITY | 916,832 |  |  | 788,152 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 1,334,988 |  |  | $ | 1,159,890 |  |

[0001596532-16-000289:8k_2_02:51]
ARISTA NETWORKS, INC.

[0001596532-16-000289:8k_2_02:52]
Consolidated Statements of Cash Flows

[0001596532-16-000289:8k_2_02:53]
(Unaudited in thousands)

[0001596532-16-000289:8k_2_02:54]
|  | Six Months Ended June 30, |
|  | 2016 |  | 2015 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 74,149 |  |  | $ | 48,488 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 9,662 |  |  | 6,246 |  |
| Stock-based compensation | 27,592 |  |  | 20,047 |  |
| Deferred income taxes | (6,876 | ) |  | (2,266 | ) |
| Excess tax benefit on stock-based compensation | (15,967 | ) |  | (22,975 | ) |
| Amortization of investment premiums | 385 |  |  | 883 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | (2,396 | ) |  | (25,360 | ) |
| Inventories | (26,001 | ) |  | (22,297 | ) |
| Prepaid expenses and other current assets | (2,838 | ) |  | (20,747 | ) |
| Other assets | 1,866 |  |  | (3,257 | ) |
| Accounts payable | 18,501 |  |  | 11,822 |  |
| Accrued liabilities | (5,196 | ) |  | 3,082 |  |
| Deferred revenue | 33,516 |  |  | 57,975 |  |
| Income taxes payable | 17,853 |  |  | 21,846 |  |
| Other liabilities | 1,779 |  |  | (114 | ) |
| Net cash provided by operating activities | 126,029 |  |  | 73,373 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of marketable securities | (292,938 | ) |  | — |  |
| Purchases of property and equipment | (12,042 | ) |  | (8,768 | ) |
| Purchases of intangible assets | (697 | ) |  | (705 | ) |
| Investment in privately-held companies | (2,500 | ) |  | — |  |
| Net cash used in investing activities | (308,177 | ) |  | (9,473 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Principal payments of lease financing obligations | (634 | ) |  | (514 | ) |
| Proceeds from issuance of common stock upon exercising options, net of repurchases | 6,317 |  |  | 11,991 |  |
| Minimum tax withholding paid on behalf of employees for net share settlement | (599 | ) |  | — |  |
| Proceeds from issuance of common stock, employee stock purchase plan | 4,888 |  |  | 4,856 |  |
| Excess tax benefit on stock-based compensation | 15,967 |  |  | 22,975 |  |
| Issuance costs from initial public offering | — |  |  | (261 | ) |
| Net cash provided by financing activities | 25,939 |  |  | 39,047 |  |
| Effect of exchange rate changes | (59 | ) |  | (20 | ) |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | (156,268 | ) |  | 102,927 |  |
| CASH AND CASH EQUIVALENTS—Beginning of year | 687,326 |  |  | 240,031 |  |
| CASH AND CASH EQUIVALENTS—End of year | $ | 531,058 |  |  | $ | 342,958 |  |
