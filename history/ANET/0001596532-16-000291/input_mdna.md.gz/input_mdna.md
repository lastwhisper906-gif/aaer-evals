# ANET MD&A — 0001596532-16-000291


## mdna

[0001596532-16-000291:mdna:1]
[same as prior period, unchanged from 0001596532-16-000255:mdna:1]

[0001596532-16-000291:mdna:2]
[same as prior period, unchanged from 0001596532-16-000255:mdna:2]

[0001596532-16-000291:mdna:3]
[same as prior period, unchanged from 0001596532-16-000255:mdna:3]

[0001596532-16-000291:mdna:4]
We were founded in 2004 to address the limitations of legacy networking products and to create a cloud networking platform that is open and programmable. From 2004 to 2008, our activities were focused on the development of our software, which resulted in the commercial release of our first product, the 7100 Series switches based on our EOS software, in 2008. Since then, we have continued to introduce new products utilizing EOS, including our 7500 Series switch and our 7050 Series switch in 2010, the second generation of our 7500 Series switch, called the 7500E modular switch, in May 2013, our 7300 Series switch in November 2013, our 7280E in July 2014.  In December 2014, we introduced our EOS+ software platform for networking programmability and automation, and in June 2015 we introduced CloudVision, a network-wide approach for workload orchestration and workflow automation.  In September 2015, we introduced our Macro Segmentation Services, or MSS, to provide automated insertion of security and other in-line layer 4-7 services within any software driven cloud networking infrastructure. MSS has been endorsed by many of our technology alliance ecosystem partners with whom we are currently partnering with to deliver MSS platform support. In addition, during 2015, we introduced our first 10/25/40/50/100G switches with our 7060, 7260 and 7320 series switches. In January 2016, Arista unveiled NetDB, the network-wide, state-oriented database that enhances the core system database (SysDB) of Arista EOS.  NetDB builds upon the SysDB architecture by adding software infrastructure improvements, including state-sharing and replication mechanisms for centrally storing network state, increased software table capacities up to 1M routes, and the ability to stream state in realtime from EOS devices. This extends the benefits of the state-based system across the entire network. During March 2016, we introduced our 7500R series, building on the 7500E series and providing 100GbE density and large table sizes in a single chassis. At up to 115 Tbps capacity, the 7500R supports up to one million routes, subsuming switching and routing functions into a Universal Spine platform for cloud-scale networks. In June 2016, we introduced our Arista 7280R Universal Leaf Network Platform, a compact form factor capable of a broad set of leaf networking use-cases, including IP storage, routing and digital media.

[0001596532-16-000291:mdna:5]
We have experienced rapid revenue growth over the last several years, increasing our revenue at a compound annual growth rate of 56.4% from 2011 to 2015. As we have grown the functionality of our EOS software, expanded the range of our switching portfolio and increased the size of our sales force, our revenue has continued to grow rapidly. To support our customers and revenue growth, we have expanded our international presence to include 23 foreign subsidiaries as of June 30, 2016, including Australia, Canada, France, Germany, India, Ireland, Japan, South Korea and the United Kingdom. Our revenue for the three and six months ended June 30, 2016 was $268.7 million and $510.9 million, respectively an increase of 37.4% and 36.4% compared to the same periods in 2015, respectively. We have been profitable and cash flow positive for each year since 2010.

[0001596532-16-000291:mdna:6]
[same as prior period, unchanged from 0001596532-16-000255:mdna:6]

[0001596532-16-000291:mdna:7]
[same as prior period, unchanged from 0001596532-16-000255:mdna:7]

[0001596532-16-000291:mdna:8]
[same as prior period, unchanged from 0001596532-16-000255:mdna:8]

[0001596532-16-000291:mdna:9]
Since shipping our first products in 2008, our cumulative end-customer base has grown rapidly. Between December 31, 2011 and June 30, 2016, our cumulative end-customer base grew from approximately 1,100 to nearly 4,000. Our end customers span a range of industries and include large Internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others.

[0001596532-16-000291:mdna:10]
To continue to grow our revenue, it is important that we both obtain new customers and sell additional products to existing customers. Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic to the underlying merchant silicon architecture. Today, we combine our EOS software with merchant silicon into a family of switching products. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We currently procure certain merchant silicon components from multiple vendors, and we continue to expand our relationships with these and other vendors. We work closely with third party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third party direct fulfillment facilities where our EOS software is installed on our products.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.  We have expanded our contract manufacturing capabilities to include an additional contract manufacturer in San Jose, California.

[0001596532-16-000291:mdna:11]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators, original equipment manufacturer, or OEM partners and in conjunction with various technology partners. To facilitate channel coordination and increase productivity, we have created a partner program, the Arista Partner Program, to engage partners who provide value-added services and extend our reach into the marketplace. Authorized training partners provide technical training to our channel partners. Our partners commonly receive an order from an end customer prior to placing an order with us, and we confirm the identification of the end customer prior to accepting such orders. Our partners generally do not stock inventory received from us. Our sales organization is supported by systems engineers with deep technical expertise and responsibility for pre-sales technical support and engineering for our end customers. Each sales team is responsible for a geographic territory, has responsibility for a number of major direct end-customer accounts or has assigned accounts in a specific vertical market.

[0001596532-16-000291:mdna:12]
[same as prior period, unchanged from 0001596532-16-000255:mdna:12]

[0001596532-16-000291:mdna:13]
We believe that our future success will depend on many factors, including our ability to expand sales to our existing customers as well as to add new end customers. While these areas present significant opportunity, they also present risks that we must manage to ensure successful results. See the section titled “Risk Factors.” Additionally, we face intense competition especially from larger, well-established companies, and we must continue to expand the capabilities of our cloud networking platform to succeed in our market. We are also currently engaged in lawsuits with Cisco, our largest competitor, whereby they claim that we have infringed their intellectual property rights.  We intend to vigorously defend against these Cisco lawsuits as summarized in the Legal Proceedings section below. However, we cannot be certain that any claims by Cisco would be resolved in our favor.  If we are unable to address these challenges, our business could be adversely affected.

[0001596532-16-000291:mdna:14]
Increasing Adoption of Cloud Networks. Networks are subject to increasing performance requirements due to the growing number of connected devices as well as new enterprise and consumer applications. Computing architectures are evolving to meet the need for constant connectivity and access to data and applications. We believe that cloud networks will continue to replace legacy network technologies. Our business and results of operations will be significantly affected by the speed with which organizations implement cloud networks.

[0001596532-16-000291:mdna:15]
[same as prior period, unchanged from 0001596532-16-000255:mdna:15]

[0001596532-16-000291:mdna:16]
[same as prior period, unchanged from 0001596532-16-000255:mdna:16]

[0001596532-16-000291:mdna:17]
[same as prior period, unchanged from 0001596532-16-000255:mdna:17]

[0001596532-16-000291:mdna:18]
[same as prior period, unchanged from 0001596532-16-000255:mdna:18]

[0001596532-16-000291:mdna:19]
Investing in Research and Development for Growth. We believe that the market for cloud networking is still in the early stages of adoption and we intend to continue investing for long-term growth. We expect to continue to invest heavily in software development in order to expand the capabilities of our cloud networking platform, introduce new products such as our 7280R platform and 7500R series, new releases and upgrades to our EOS software and new applications building upon our technology leadership. We believe one of our greatest strengths lies in the speed of our product development efforts. By investing in research and development, we believe we will be well positioned to continue our rapid growth and take advantage of our large market opportunity. We expect that our results of operations will be impacted by the timing and size of these product development investments.

[0001596532-16-000291:mdna:20]
Customer Concentration and Timing of Large Orders. Historically, large purchases by a relatively limited number of end customers have accounted for a significant portion of our revenue. During the years ended December 31, 2015, 2014, and 2013, our largest end customer accounted for 12.0%, 14.9%, and 21.9% of our revenue, respectively. We have also experienced and continue to experience customer concentration on a quarterly basis. In addition, we have experienced increases in the size of our orders, including orders from existing customers, which could result in future increased customer concentration, depending on the timing of the fulfillment of those orders. We have also experienced unpredictability in the timing of large orders, especially with respect to our large end customers, due to the complexity of orders, the time it takes end customers to evaluate, test, qualify and accept our products and factors specific to our end customers. Due to these factors, we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. In addition, we have provided, and may in the future provide, pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur. Our gross margins may also fluctuate as a result of the timing of such sales to large end customers.

[0001596532-16-000291:mdna:21]
[same as prior period, unchanged from 0001596532-16-000255:mdna:21]

[0001596532-16-000291:mdna:22]
[same as prior period, unchanged from 0001596532-16-000255:mdna:22]

[0001596532-16-000291:mdna:23]
We generate revenue primarily from sales of our switching products which incorporate our EOS software. We also derive a portion of our revenue from sales of post contract support, or PCS, and to a lesser extent professional services. We generate PCS revenue from sales of technical support services contracts that are typically purchased in conjunction with our products and subsequent renewals of those contracts. We offer PCS services under renewable, fee-based contracts, which include 24-hour technical support, hardware repair and replacement parts, bug fixes, patches and unspecified upgrades on a when-and-if available basis. We expect our revenue may vary from period to period based on, among other things, the timing and size of orders, the delivery and acceptance of products, and the impact of significant transactions with unique terms and conditions that may require deferral of revenue. Additionally, we expect PCS revenue to increase in absolute dollars as we expand our installed base. Our ability to expand our installed base and increase our revenue is subject to numerous risks and uncertainties. See the section titled “Risk Factors.” We report revenue net of sales taxes.

[0001596532-16-000291:mdna:24]
[same as prior period, unchanged from 0001596532-16-000255:mdna:24]

[0001596532-16-000291:mdna:25]
[same as prior period, unchanged from 0001596532-16-000255:mdna:25]

[0001596532-16-000291:mdna:26]
[same as prior period, unchanged from 0001596532-16-000255:mdna:26]

[0001596532-16-000291:mdna:27]
[same as prior period, unchanged from 0001596532-16-000255:mdna:27]

[0001596532-16-000291:mdna:28]
[same as prior period, unchanged from 0001596532-16-000255:mdna:28]

[0001596532-16-000291:mdna:29]
[same as prior period, unchanged from 0001596532-16-000255:mdna:29]

[0001596532-16-000291:mdna:30]
[same as prior period, unchanged from 0001596532-16-000255:mdna:30]

[0001596532-16-000291:mdna:31]
[same as prior period, unchanged from 0001596532-16-000255:mdna:31]

[0001596532-16-000291:mdna:32]
[same as prior period, unchanged from 0001596532-16-000255:mdna:32]

[0001596532-16-000291:mdna:33]
[same as prior period, unchanged from 0001596532-16-000255:mdna:33]

[0001596532-16-000291:mdna:34]
[same as prior period, unchanged from 0001596532-16-000255:mdna:34]

[0001596532-16-000291:mdna:35]
General and administrative expenses consist primarily of personnel costs, legal and professional fees, and an allocated portion of facility and IT costs and depreciation. General and administrative personnel costs include those for our executive, finance, IT, human resources and legal functions. Our professional fees consist primarily of accounting, external legal and IT and other consulting costs. Refer to the discussion under “Legal Proceedings” subheading in Note 5. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for information related to pending litigation.

[0001596532-16-000291:mdna:36]
[same as prior period, unchanged from 0001596532-16-000255:mdna:36]

[0001596532-16-000291:mdna:37]
[same as prior period, unchanged from 0001596532-16-000255:mdna:37]

[0001596532-16-000291:mdna:38]
[same as prior period, unchanged from 0001596532-16-000255:mdna:38]

[0001596532-16-000291:mdna:39]
[same as prior period, unchanged from 0001596532-16-000255:mdna:39]

[0001596532-16-000291:mdna:40]
Other income (expense) consists mostly of foreign currency exchange gains and losses and interest income. Our foreign currency exchange gains and losses primarily relate to transactions and asset and liability balances denominated in currencies other than the U.S. dollar. We expect our foreign currency gains and losses to continue to fluctuate in the future due to changes in foreign currency exchange rates.

[0001596532-16-000291:mdna:41]
[same as prior period, unchanged from 0001596532-16-000255:mdna:41]

[0001596532-16-000291:mdna:42]
[same as prior period, unchanged from 0001596532-16-000255:mdna:42]

[0001596532-16-000291:mdna:43]
[same as prior period, unchanged from 0001596532-16-000255:mdna:43]

[0001596532-16-000291:mdna:44]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is

[0001596532-16-000291:mdna:45]
made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-16-000291:mdna:46]
[same as prior period, unchanged from 0001596532-16-000255:mdna:45]

[0001596532-16-000291:mdna:47]
The following table summarizes historical results of operations for the periods presented and as a percentage of revenue for those periods.  We have derived the data for the three and six months ended June 30, 2016 and 2015 from our unaudited condensed consolidated financial statements (in thousands, except for percentage of revenue).

[0001596532-16-000291:mdna:48]
|  | Three Months EndedJune 30, | Six Months EndedJune 30, |
|  | 2016 |  | 2015 | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |  |
| Product | $ | 235,616 |  |  | $ | 174,072 |  | $ | 448,091 |  |  | $ | 334,213 |  |
| Service | 33,125 |  |  | 21,480 |  | 62,846 |  |  | 40,384 |  |
| Total revenue | 268,741 |  |  | 195,552 |  | 510,937 |  |  | 374,597 |  |
| Cost of revenue (1): |  |  |  |  |  |  |
| Product | 88,021 |  |  | 60,014 |  | 166,934 |  |  | 114,453 |  |
| Service | 9,269 |  |  | 7,648 |  | 17,462 |  |  | 14,500 |  |
| Total cost of revenue | 97,290 |  |  | 67,662 |  | 184,396 |  |  | 128,953 |  |
| Gross profit | 171,451 |  |  | 127,890 |  | 326,541 |  |  | 245,644 |  |
| Operating expenses (1): |  |  |  |  |  |  |
| Research and development | 69,020 |  |  | 49,947 |  | 131,535 |  |  | 93,287 |  |
| Sales and marketing | 31,744 |  |  | 26,681 |  | 59,350 |  |  | 51,268 |  |
| General and administrative | 17,529 |  |  | 18,403 |  | 32,763 |  |  | 32,475 |  |
| Total operating expenses | 118,293 |  |  | 95,031 |  | 223,648 |  |  | 177,030 |  |
| Income from operations | 53,158 |  |  | 32,859 |  | 102,893 |  |  | 68,614 |  |
| Interest expense | (732 | ) |  | (832 | ) | (1,483 | ) |  | (1,653 | ) |
| Other income (expense), net | 416 |  |  | 417 |  | 753 |  |  | (51 | ) |
| Total other income (expense), net | (316 | ) |  | (415 | ) | (730 | ) |  | (1,704 | ) |
| Income before provision for income taxes | 52,842 |  |  | 32,444 |  | 102,163 |  |  | 66,910 |  |
| Provision for income taxes | 13,938 |  |  | 8,448 |  | 28,014 |  |  | 18,422 |  |
| Net income | $ | 38,904 |  |  | $ | 23,996 |  | $ | 74,149 |  |  | $ | 48,488 |  |

[0001596532-16-000291:mdna:49]
26

[0001596532-16-000291:mdna:50]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (as a percentage of revenue) |
| Revenue: |  |  |  |  |  |  |  |
| Product | 87.7 | % |  | 89.0 | % |  | 87.7 | % |  | 89.2 | % |
| Service | 12.3 |  |  | 11.0 |  |  | 12.3 |  |  | 10.8 |  |
| Total revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 32.8 |  |  | 30.7 |  |  | 32.7 |  |  | 30.6 |  |
| Service | 3.4 |  |  | 3.9 |  |  | 3.4 |  |  | 3.8 |  |
| Total cost of revenue | 36.2 |  |  | 34.6 |  |  | 36.1 |  |  | 34.4 |  |
| Gross margin | 63.8 |  |  | 65.4 |  |  | 63.9 |  |  | 65.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 25.7 |  |  | 25.5 |  |  | 25.7 |  |  | 24.9 |  |
| Sales and marketing | 11.8 |  |  | 13.6 |  |  | 11.6 |  |  | 13.7 |  |
| General and administrative | 6.5 |  |  | 9.5 |  |  | 6.4 |  |  | 8.7 |  |
| Total operating expenses | 44.0 |  |  | 48.6 |  |  | 43.7 |  |  | 47.3 |  |
| Income from operations | 19.8 |  |  | 16.8 |  |  | 20.2 |  |  | 18.3 |  |
| Interest expense | (0.3 | ) |  | (0.4 | ) |  | (0.3 | ) |  | (0.4 | ) |
| Other income (expense), net | 0.2 |  |  | 0.2 |  |  | 0.1 |  |  | — |  |
| Total other income (expense), net | (0.1 | ) |  | (0.2 | ) |  | (0.2 | ) |  | (0.4 | ) |
| Income before provision for income taxes | 19.7 |  |  | 16.6 |  |  | 20.0 |  |  | 17.9 |  |
| Provision for income taxes | 5.2 |  |  | 4.3 |  |  | 5.5 |  |  | 5.0 |  |
| Net income | 14.5 | % |  | 12.3 | % |  | 14.5 | % |  | 12.9 | % |

[0001596532-16-000291:mdna:51]
[same as prior period, unchanged from 0001596532-16-000255:mdna:50]

[0001596532-16-000291:mdna:52]
[same as prior period, unchanged from 0001596532-16-000255:mdna:51]

[0001596532-16-000291:mdna:53]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cost of revenue | $ | 868 |  |  | $ | 784 |  |  | $ | 1,661 |  |  | $ | 1,420 |  |
| Research and development | 7,595 |  |  | 6,379 |  |  | 15,052 |  |  | 11,307 |  |
| Sales and marketing | 3,780 |  |  | 2,865 |  |  | 7,427 |  |  | 5,274 |  |
| General and administrative | 1,989 |  |  | 1,180 |  |  | 3,452 |  |  | 2,046 |  |
| Total stock-based compensation | $ | 14,232 |  |  | $ | 11,208 |  |  | $ | 27,592 |  |  | $ | 20,047 |  |

[0001596532-16-000291:mdna:54]
[same as prior period, unchanged from 0001596532-16-000255:mdna:48]

[0001596532-16-000291:mdna:55]
Three and Six Months Ended June 30, 2016 Compared to Three and Six Months Ended June 30, 2015

[0001596532-16-000291:mdna:56]
[same as prior period, unchanged from 0001596532-16-000255:mdna:55]

[0001596532-16-000291:mdna:57]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2016 |  | 2015 |  | Change in |  | 2016 |  | 2015 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 235,616 |  |  | $ | 174,072 |  |  | $ | 61,544 |  |  | 35.4% |  | $ | 448,091 |  |  | $ | 334,213 |  |  | $ | 113,878 |  |  | 34.1% |
| Service | 33,125 |  |  | 21,480 |  |  | 11,645 |  |  | 54.2 |  | 62,846 |  |  | 40,384 |  |  | 22,462 |  |  | 55.6 |
| Total revenue | 268,741 |  |  | 195,552 |  |  | 73,189 |  |  | 37.4 |  | 510,937 |  |  | 374,597 |  |  | 136,340 |  |  | 36.4 |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 88,021 |  |  | 60,014 |  |  | 28,007 |  |  | 46.7 |  | 166,934 |  |  | 114,453 |  |  | 52,481 |  |  | 45.9 |
| Service | 9,269 |  |  | 7,648 |  |  | 1,621 |  |  | 21.2 |  | 17,462 |  |  | 14,500 |  |  | 2,962 |  |  | 20.4 |
| Total cost of revenue | 97,290 |  |  | 67,662 |  |  | 29,628 |  |  | 43.8 |  | 184,396 |  |  | 128,953 |  |  | 55,443 |  |  | 43.0 |
| Gross profit | $ | 171,451 |  |  | $ | 127,890 |  |  | $ | 43,561 |  |  | 34.1% |  | $ | 326,541 |  |  | $ | 245,644 |  |  | $ | 80,897 |  |  | 32.9% |
| Gross margin | 63.8 | % |  | 65.4 | % |  |  |  |  |  | 63.9 | % |  | 65.6 | % |  |  |  |  |

[0001596532-16-000291:mdna:58]
[same as prior period, unchanged from 0001596532-16-000255:mdna:57]

[0001596532-16-000291:mdna:59]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2016 |  | % of Total |  | 2015 |  | % of Total |  | 2016 |  | % of Total |  | 2015 |  | % of Total |
| Americas | $ | 201,317 |  |  | 74.9 | % |  | $ | 150,863 |  |  | 77.1 | % |  | $ | 383,958 |  |  | 75.1 | % |  | $ | 277,620 |  |  | 74.1 | % |
| Europe, Middle East and Africa | 42,644 |  |  | 15.9 |  |  | 24,782 |  |  | 12.7 |  |  | 86,383 |  |  | 16.9 |  |  | 64,872 |  |  | 17.3 |  |
| Asia-Pacific | 24,780 |  |  | 9.2 |  |  | 19,907 |  |  | 10.2 |  |  | 40,596 |  |  | 8.0 |  |  | 32,105 |  |  | 8.6 |  |
| Total revenue | $ | 268,741 |  |  | 100.0 | % |  | $ | 195,552 |  |  | 100.0 | % |  | $ | 510,937 |  |  | 100.0 | % |  | $ | 374,597 |  |  | 100.0 | % |

[0001596532-16-000291:mdna:60]
[same as prior period, unchanged from 0001596532-16-000255:mdna:59]

[0001596532-16-000291:mdna:61]
Revenue increased 37.4% in the three months ended June 30, 2016 and 36.4% in the six months ended June 30, 2016, compared to the same periods in 2015.  We increased shipments to our existing customers as they continued to grow and expand their businesses, increasing their demand for our switch products and related accessories. The introduction of new products has contributed to our revenue growth, both with existing and new customers. Our overall customer count increased to almost 4,000 in the period as we expanded our market presence and geographical foot print. Service revenue increased 54.2% in the three months ended June 30, 2016 and 55.6% during the six months ended June 30, 2016 compared to the same periods in 2015, as a result of continued growth in initial and renewal support contracts as our customer installed base continues to expand.  We also continued to experience fluctuations in product and service pricing due to competitive market pressures.  However, these were more than offset by the increased demand drivers outlined above.

[0001596532-16-000291:mdna:62]
[same as prior period, unchanged from 0001596532-16-000255:mdna:61]

[0001596532-16-000291:mdna:63]
Cost of revenue increased $29.6 million in the three months ended June 30, 2016 and $55.4 million in the six months ended June 30, 2016, compared to the same periods in 2015. The increase in cost of revenue was primarily due to an increase in product shipment volume, an increase in costs to add capacity to our manufacturing and operations infrastructure, and to a lesser extent, an increase in expenses incurred to expand the infrastructure to support our growing customer installed base.  Gross margin decreased from 65.4% to 63.8% for the three months ended June 30, 2016 compared to the same period in 2015, and from 65.6% to 63.9% for the six months ended June 30, 2016 compared to the same periods in 2015, respectively.  The decrease during these periods was primarily the result of changes in customer mix and to a lesser extent product mix, as we expanded our business and increased the contribution of larger customers who typically receive higher discount levels. These unfavorable changes were partially offset by improved service margins as we scale our services business.  We expect that our gross margins in the third quarter of 2016 will be relatively consistent with our recent quarters.  While we do not have the ability to predict gross margins for periods beyond this time frame, we believe we may continue to experience some increase in product costs as we ramp our new contract manufacturer and related supply chain operations.

[0001596532-16-000291:mdna:64]
[same as prior period, unchanged from 0001596532-16-000255:mdna:63]

[0001596532-16-000291:mdna:65]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2016 |  | 2015 |  | Change in |  | 2016 |  | 2015 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 69,020 |  |  | $ | 49,947 |  |  | $ | 19,073 |  |  | 38.2% |  | $ | 131,535 |  |  | $ | 93,287 |  |  | $ | 38,248 |  |  | 41.0% |
| Sales and marketing | 31,744 |  |  | 26,681 |  |  | 5,063 |  |  | 19.0 |  | 59,350 |  |  | 51,268 |  |  | 8,082 |  |  | 15.8 |
| General and administrative | 17,529 |  |  | 18,403 |  |  | (874 | ) |  | (4.7) |  | 32,763 |  |  | 32,475 |  |  | 288 |  |  | 0.9 |
| Total operating expenses | $ | 118,293 |  |  | $ | 95,031 |  |  | $ | 23,262 |  |  | 24.5% |  | $ | 223,648 |  |  | $ | 177,030 |  |  | $ | 46,618 |  |  | 26.3% |

[0001596532-16-000291:mdna:66]
[same as prior period, unchanged from 0001596532-16-000255:mdna:65]

[0001596532-16-000291:mdna:67]
Research and development expenses increased $19.1 million, or 38.2%, for the three months ended June 30, 2016 compared to the same period in 2015. The increase was primarily due to an increase in personnel costs of $9.2 million, resulting from increases in headcount, stock-based compensation as well as additional bonus expense under our corporate bonus plan. Prototype spend, third-party engineering and consulting costs increased by $9.1 million related to the development of new products and some increased costs associated with litigation related changes in product design.

[0001596532-16-000291:mdna:68]
Research and development expenses increased $38.2 million, or 41.0%, for the six months ended June 30, 2016 compared to the same period in 2015. The increase was primarily due to an increase in personnel costs of $18.5 million, resulting from increases in headcount, stock-based compensation as well as additional bonus expense under our corporate bonus plan. Prototype spend, third-party engineering and consulting costs increased by $15.4 million related to the development of new products, and increased costs associated with litigation related changes in product design.  Facilities and IT infrastructure costs increased $1.8 million due to expansion of our business and support center footprint and continued expansion and support of our research and development activities.

[0001596532-16-000291:mdna:69]
[same as prior period, unchanged from 0001596532-16-000255:mdna:67]

[0001596532-16-000291:mdna:70]
Sales and marketing expenses increased $5.1 million, or 19.0%, for the three months ended June 30, 2016 compared to the same period in 2015. The increase was primarily due to an increase in personnel costs of $4.4 million, resulting from increased headcount, additional sales incentive compensation due to higher sales volume, and additional corporate bonus expense.

[0001596532-16-000291:mdna:71]
Sales and marketing expenses increased $8.1 million, or 15.8%, for the six months ended June 30, 2016 compared to the same period in 2015. The increase was primarily due to an increase in personnel costs of $8.7 million, resulting from increased headcount, additional sales incentive compensation due to higher sales volume, and additional corporate bonus expense. This increase was partially offset by a decrease in product field demonstration costs of $1.4 million primarily related to significant costs incurred in the previous year as we experienced several product transitions to our next generation products.

[0001596532-16-000291:mdna:72]
[same as prior period, unchanged from 0001596532-16-000255:mdna:69]

[0001596532-16-000291:mdna:73]
General and administrative expenses decreased $0.9 million, or 4.7%, for the three months ended June 30, 2016 compared to the same period in 2015.  This decrease was mostly due to a reduction in litigation expenses of $2.3 million related to the timing of litigation activities primarily related to the Cisco and OptumSoft legal matters outlined in Note 5 to the Consolidated Financial Statements.  This decrease was largely offset by an increase in personnel costs of $1.5 million reflecting additional headcount, increased stock-based compensation charges, and additional bonus expenses under our corporate bonus program.

[0001596532-16-000291:mdna:74]
General and administrative expenses increased $0.3 million, or 0.9%, for the three months ended June 30, 2016 compared to the same period in 2015. The increase was due to an increase in personnel costs of $2.4 million reflecting additional headcount, increased stock-based compensation charges, and additional bonus expenses under our corporate bonus program. This increase was largely offset by a reduction of litigation expenses of $1.7 million primarily related to the timing of litigation activities in the Cisco and OptumSoft legal matters outlined in Note 5 to the Consolidated Financial Statements.

[0001596532-16-000291:mdna:75]
[same as prior period, unchanged from 0001596532-16-000255:mdna:71]

[0001596532-16-000291:mdna:76]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2016 |  | 2015 |  | Change in |  | 2016 |  | 2015 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | $ | (732 | ) |  | $ | (832 | ) |  | $ | 100 |  |  | 12.0% |  | $ | (1,483 | ) |  | $ | (1,653 | ) |  | $ | 170 |  |  | 10.3% |
| Other income (expense), net | 416 |  |  | 417 |  |  | (1 | ) |  | 0.2 |  | 753 |  |  | (51 | ) |  | 804 |  |  | (1,576.5) |
| Total other income (expense), net | $ | (316 | ) |  | $ | (415 | ) |  | $ | 99 |  |  | 23.9% |  | $ | (730 | ) |  | $ | (1,704 | ) |  | $ | 974 |  |  | 57.2% |

[0001596532-16-000291:mdna:77]
[same as prior period, unchanged from 0001596532-16-000255:mdna:75]

[0001596532-16-000291:mdna:78]
Other income (expense), net during the three and six months ended June 30, 2016 compared to the same periods in 2015 included an increase in interest income as we expanded our marketable securities portfolio during the current quarter.   The increase in interest income in the three months ended June 30, 2016 was largely offset by an unfavorable change in foreign currency transaction losses.

[0001596532-16-000291:mdna:79]
[same as prior period, unchanged from 0001596532-16-000255:mdna:77]

[0001596532-16-000291:mdna:80]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2016 |  | 2015 |  | Change in |  | 2016 |  | 2015 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Provision for income taxes | $ | 13,938 |  |  | $ | 8,448 |  |  | $ | 5,490 |  |  | 65.0% |  | $ | 28,014 |  |  | $ | 18,422 |  |  | $ | 9,592 |  |  | 52.1% |
| Effective tax rate | 26.4 | % |  | 26.0 | % |  |  |  |  |  | 27.4 | % |  | 27.5 | % |  |  |  |  |

[0001596532-16-000291:mdna:81]
[same as prior period, unchanged from 0001596532-16-000255:mdna:79]

[0001596532-16-000291:mdna:82]
Provision for income taxes was approximately $13.9 million and $8.4 million for the three months and $28.0 million and $18.4 million for the six months ended June 30, 2016 and 2015, respectively. The change in the provision was a result of an increase in profit before income taxes and the change in effective tax rate primarily due to the geographical distribution of the earnings.

[0001596532-16-000291:mdna:83]
30

[0001596532-16-000291:mdna:84]
[same as prior period, unchanged from 0001596532-16-000255:mdna:82]

[0001596532-16-000291:mdna:85]
Our principal sources of liquidity are cash and cash equivalents, marketable securities, and cash generated from operations. As of June 30, 2016, cash and cash equivalents, and marketable securities were $823.8 million, of which approximately $91.1 million was held outside the U.S. in our foreign subsidiaries.  We have not repatriated nor do we currently have plans to repatriate these funds, but if we were to repatriate cash held outside of the U.S. for domestic cash operations, we would be required to accrue and pay U.S. income taxes to repatriate these funds less any previously paid foreign income taxes. We consider the undistributed earnings of our foreign subsidiaries as of June 30, 2016 to be indefinitely reinvested, and, accordingly, no U.S. income taxes have been provided thereon.

[0001596532-16-000291:mdna:86]
Our cash and cash equivalents, and marketable securities are held for working capital purposes. We expect to incur incremental working capital requirements of $100.0 million over the next quarter specifically related to new product transitions and the ramp of production and supply chain operations with our new contract manufacturer.  In addition, we may incur incremental capital expenditures of up to $10.0 million in relation to these manufacturing efforts. We plan to continue to invest for long-term growth. We believe that our existing cash and cash equivalents together with cash flow from operations will be sufficient to meet our working capital requirements and our growth strategies for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs and access to outsourcing our manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and costs incurred related to outstanding litigation claims. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-16-000291:mdna:87]
[same as prior period, unchanged from 0001596532-16-000255:mdna:85]

[0001596532-16-000291:mdna:88]
|  | June 30, 2016 |  | December 31, 2015 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 531,058 |  |  | $ | 687,326 |  |

[0001596532-16-000291:mdna:89]
|  | Six Months EndedJune 30, |
|  | 2016 |  | 2015 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 126,029 |  |  | $ | 73,373 |  |
| Cash used in investing activities | (308,177 | ) |  | (9,473 | ) |
| Cash provided by financing activities | 25,939 |  |  | 39,047 |  |
| Effect of exchange rate changes | (59 | ) |  | (20 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | (156,268 | ) |  | $ | 102,927 |  |

[0001596532-16-000291:mdna:90]
[same as prior period, unchanged from 0001596532-16-000255:mdna:88]

[0001596532-16-000291:mdna:91]
Our primary source of cash from operating activities has been from cash collections from our customers. We expect cash inflows from operating activities to be affected by increased sales and timing of collections. Our primary uses of cash from operating activities have been for personnel costs, inventory purchases from our contract manufacturers, investment in research and development, and litigation expenses.

[0001596532-16-000291:mdna:92]
During the six months ended June 30, 2016, cash provided by operating activities was $126.0 million, primarily from net income of $74.1 million, a net increase in cash from changes in our operating assets and liabilities of $37.1 million, and net non-cash adjustments to net income of $14.8 million. The increase in cash from changes in operating assets and liabilities was primarily due to an increase in deferred revenue of $33.5 million mostly related to new and renewed PCS contracts, an increase in accounts payable of $18.5 million primarily due to timing of vendor payments, and an increase in cash of $17.9 million from changes in income taxes payable. Cash outflows from changes in operating assets and liabilities primarily consisted of net inventory purchases of $26.0 million as we continue to build our inventory balances, and a reduction in accrued liabilities of $5.2 million primarily from corporate bonus and commission payments.

[0001596532-16-000291:mdna:93]
During the six months ended June 30, 2015, cash provided by operating activities was $73.4 million, primarily from net income of $48.5 million, net non-cash charges of $2.4 million and a net increase in our operating assets and liabilities of $22.5 million. The net increase in operating assets and liabilities was primarily due to an increase in deferred revenue of $58.0 million, largely related to short and long-term services contracts and product revenue deferrals related to contract acceptance terms and future deliverables. In addition, we experienced a net increase in our income tax payable of $21.8 million, and an increase in our accounts payable of $11.8 million due to the timing of our payments. These increases were partially offset by an increase in our accounts receivable of $25.8 million resulting from an increase in sales, an increase in inventory of $22.3 million due to increased shipment volume and an increase of $20.7 million in our prepaid expenses and current assets.

[0001596532-16-000291:mdna:94]
[same as prior period, unchanged from 0001596532-16-000255:mdna:93]

[0001596532-16-000291:mdna:95]
[same as prior period, unchanged from 0001596532-16-000255:mdna:94]

[0001596532-16-000291:mdna:96]
During the six months ended June 30, 2016, cash used in investing activities was $308.2 million, consisting of purchases of available-for-sale securities of $292.9 million, purchases of property, equipment and other assets of $12.7 million, and an additional investment in a privately-held company of $2.5 million.

[0001596532-16-000291:mdna:97]
During the six months ended June 30, 2015, cash used in investing activities was $9.5 million, consisting of purchases of property and equipment of $8.8 million, and purchases of intangible assets of $0.7 million.

[0001596532-16-000291:mdna:98]
[same as prior period, unchanged from 0001596532-16-000255:mdna:97]

[0001596532-16-000291:mdna:99]
[same as prior period, unchanged from 0001596532-16-000255:mdna:98]

[0001596532-16-000291:mdna:100]
During the six months ended June 30, 2016, cash provided by financing activities was $25.9 million, consisting primarily of the excess tax benefit associated with equity incentive plans of $16.0 million, proceeds from the exercise of stock options, net of repurchases of $6.3 million, proceeds from the issuance of common stock from our ESPP of $4.9 million.

[0001596532-16-000291:mdna:101]
During the six months ended June 30, 2015, cash provided by financing activities was $39.0 million, consisting primarily of the excess tax benefit on stock-based compensation of $23.0 million, proceeds from the exercise of stock options, net of repurchases of $12.0 million and the proceeds from the issuance of common stock from our ESPP of $4.9 million.

[0001596532-16-000291:mdna:102]
[same as prior period, unchanged from 0001596532-16-000255:mdna:101]

[0001596532-16-000291:mdna:103]
As of June 30, 2016, we did not have any relationships with any unconsolidated entities or financial partnerships, including entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-16-000291:mdna:104]
[same as prior period, unchanged from 0001596532-16-000255:mdna:103]

[0001596532-16-000291:mdna:105]
As of June 30, 2016, our principal commitments consist of obligations under operating leases and purchase commitments. There have been no significant changes to these obligations during the six months ended June 30, 2016, compared to the contractual obligations disclosed in our "Management's Discussion and Analysis of Financial Condition and Results of Operations" included in our Annual Report on Form 10-K, filed with the SEC on February 25, 2016, other than the purchase commitments described in Note 5. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements of this Quarterly Report on Form 10-Q.

[0001596532-16-000291:mdna:106]
[same as prior period, unchanged from 0001596532-16-000255:mdna:105]

[0001596532-16-000291:mdna:107]
[same as prior period, unchanged from 0001596532-16-000255:mdna:106]

[0001596532-16-000291:mdna:108]
[same as prior period, unchanged from 0001596532-16-000255:mdna:107]

[0001596532-16-000291:mdna:109]
[same as prior period, unchanged from 0001596532-16-000255:mdna:108]
