# ANET MD&A — 0001596532-21-000149


## mdna

[0001596532-21-000149:mdna:1]
[same as prior period, unchanged from 0001596532-20-000226:mdna:1]

[0001596532-21-000149:mdna:2]
[same as prior period, unchanged from 0001596532-20-000226:mdna:2]

[0001596532-21-000149:mdna:3]
Arista Networks pioneered software-driven, cognitive cloud networking for large-scale data center and campus workspace environments. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our Ethernet switching and routing platforms. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. In recent years, we have sought to bring the operational consistency and principles of cloud networking to the broader enterprise and campus markets with our Cognitive Cloud Networking approach. Our cognitive single-tier SplineTM campus network extends EOS across the campus workspace and the data center.  In addition, we acquired Mojo Networks, Inc. (“Mojo”), the inventor of Cognitive WiFiTM to extend these same cognitive principles to the wireless network. CloudVision®, our network-wide approach for workload orchestration and automation, leverages EOS and Cognitive WiFiTM features, to deliver a turnkey workflow orchestration and automation solution for cloud networking to our enterprise customers.

[0001596532-21-000149:mdna:4]
We generate revenue primarily from sales of our switching and routing platforms, which incorporate our EOS software, and related network applications. We also generate revenue from post-contract support, or PCS, which end customers typically purchase in conjunction with our products and renewals of PCS. We sell our products through both our direct sales force and our channel partners. As of December 31, 2020, we had delivered our cloud networking solutions to over 7,000 end customers worldwide.  Our end customers span a range of industries and include large internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others.

[0001596532-21-000149:mdna:5]
Historically, large purchases by a relatively limited number of end customers have accounted for a significant portion of our revenue. We have experienced unpredictability in the timing of orders from these large end customers primarily due to changes in demand patterns specific to these customers, the time it takes these end customers to evaluate, test, qualify and accept our products, and the overall complexity of these large orders. We expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. For example, sales to our end customers Microsoft and Facebook in fiscal 2019 collectively represented 40% of our total revenue, whereas sales to our end customer Microsoft in fiscal 2020 amounted to 21.5% of our revenues, with our end customer Facebook representing less than 10% of our revenues in

[0001596532-21-000149:mdna:6]
the period. In addition, we typically provide pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur.

[0001596532-21-000149:mdna:7]
We believe that cloud computing represents a fundamental shift from traditional legacy network architectures. As organizations of all sizes have moved workloads to the cloud, spending on cloud and next-generation data centers has increased rapidly, while traditional legacy IT spending has grown more slowly. Our cloud networking platforms are well positioned to address the growing cloud networking market, and to address increasing performance requirements driven by the growing number of connected devices, as well as the need for constant connectivity and access to data and applications.

[0001596532-21-000149:mdna:8]
The markets for cloud networking solutions are highly competitive and characterized by rapidly changing technology, changing end-customer needs, evolving industry standards, frequent introductions of new products and services and industry consolidation. We expect competition to intensify in the future as the market for cloud networking expands and existing competitors and new market entrants introduce new products or enhance existing products. Our future success is dependent upon our ability to continue to evolve and adapt to our rapidly changing environment. We must also continue to develop market leading products and features that address the needs of our existing and new customers, and increase sales in the enterprise data center switching, and campus workspace markets. We intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new end customers more effectively, increase sales to existing customers, and provide services and support. In addition, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our ability to rapidly develop new features and applications.

[0001596532-21-000149:mdna:9]
Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic with respect to the underlying merchant silicon architecture. The programmability of EOS has allowed us to expand our software applications to address the ever increasing demands of cloud networking, including workflow automation, network visibility, analytics and network detection and response, and has further allowed us to integrate rapidly with a wide range of third-party applications for virtualization, management, automation, orchestration and network services. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We work closely with third party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-21-000149:mdna:10]
[same as prior period, unchanged from 0001596532-20-000226:mdna:9]

[0001596532-21-000149:mdna:11]
The global coronavirus (“COVID-19”) pandemic and related shelter in place, travel and social distancing restrictions imposed by governments around the world in an effort to contain or slow its spread have negatively impacted the global economy, disrupted business, sales activities, supply chains and workforce participation, including our own, and created significant volatility and disruption of financial markets, and we expect that the global health crisis caused by COVID-19 could  negatively impact business activity in the future.

[0001596532-21-000149:mdna:12]
We have taken numerous steps, and will continue to take further actions, in our approach to address COVID-19. We have prioritized the protection of our employees during this pandemic and, as a result, have closed our offices across the globe (including our corporate headquarters), limiting access to only those employees providing essential activities, instructed employees to work from home, and implemented travel restrictions. We continue to work closely with our contract manufacturers and supply chain partners who have experienced delays in component sourcing, workforce disruptions and governmental restrictions on the production and export of their products. Although we have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, these delays have negatively impacted our ability to supply products to our customers on a timely basis. We are currently experiencing shortages and delays relating to certain components as a result of manufacturing and supply disruptions from the COVID-19 pandemic. We expect to continue to invest in working capital to address delays in component sourcing and the risk of future COVID-19 related supply chain disruptions, but we cannot be certain that such delays or disruptions will not occur. When the COVID-19 pandemic began, we initially experienced some volatility in customer demand, but sales activity subsequently stabilized and we have since experienced incremental improvements in overall demand.

[0001596532-21-000149:mdna:13]
The extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, including the duration and spread of the pandemic, the breadth and duration of governmental containment measures such as shelter in place, travel and social distancing restrictions as well as the reauthorization of or increase in such measures in the event of spikes in COVID-19 infection rates, the success of the COVID-19 vaccination deployment, and the impact on our customers, partners, contract manufacturers and supply chain, all of which are uncertain and cannot be predicted. However, any continued or renewed disruption in manufacturing and supply resulting from the COVID-19 pandemic or related containment measures could

[0001596532-21-000149:mdna:14]
negatively impact our business. We also believe that any extended or renewed COVID-19 related economic disruption could have a negative impact on demand from our customers in future periods. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

[0001596532-21-000149:mdna:15]
Although management is actively monitoring the impact of COVID-19 on the Company’s financial condition, liquidity, operations, suppliers, industry, and workforce, the full impact of the pandemic continues to evolve as of the date of this report. As such, the Company is unable to estimate the effects of COVID-19 on its future results of operations, financial condition, or liquidity.

[0001596532-21-000149:mdna:16]
[same as prior period, unchanged from 0001596532-20-000226:mdna:17]

[0001596532-21-000149:mdna:17]
Three Months Ended March 31, 2021 Compared to Three Months Ended March 31, 2020

[0001596532-21-000149:mdna:18]
Revenue, Cost of Revenue and Gross Margin (in thousands, except percentages)

[0001596532-21-000149:mdna:19]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2021 |  | 2020 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 539,145 |  |  | $ | 410,906 |  |  | $ | 128,239 |  |  | 31.2 | % |  |  |  |  |  |  |  |  |
| Service |  | 128,417 |  |  | 112,123 |  |  | 16,294 |  |  | 14.5 |  |  |  |  |  |  |  |  |  |
| Total revenue |  | 667,562 |  |  | 523,029 |  |  | 144,533 |  |  | 27.6 |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 218,433 |  |  | 163,629 |  |  | 54,804 |  |  | 33.5 |  |  |  |  |  |  |  |  |  |
| Service |  | 23,857 |  |  | 21,149 |  |  | 2,708 |  |  | 12.8 |  |  |  |  |  |  |  |  |  |
| Total cost of revenue |  | 242,290 |  |  | 184,778 |  |  | 57,512 |  |  | 31.1 |  |  |  |  |  |  |  |  |  |
| Gross profit |  | $ | 425,272 |  |  | $ | 338,251 |  |  | $ | 87,021 |  |  | 25.7 | % |  |  |  |  |  |  |  |  |
| Gross margin |  | 63.7 | % |  | 64.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001596532-21-000149:mdna:20]
[same as prior period, unchanged from 0001596532-20-000226:mdna:21]

[0001596532-21-000149:mdna:21]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2021 |  | % of Total |  | 2020 |  | % of Total |  |  |  |  |  |  |  |  |
| Americas |  | $ | 501,872 |  |  | 75.2 | % |  | $ | 400,660 |  |  | 76.6 | % |  |  |  |  |  |  |  |  |
| Europe, Middle East and Africa |  | 96,274 |  |  | 14.4 |  |  | 72,624 |  |  | 13.9 |  |  |  |  |  |  |  |  |  |
| Asia-Pacific |  | 69,416 |  |  | 10.4 |  |  | 49,745 |  |  | 9.5 |  |  |  |  |  |  |  |  |  |
| Total revenue |  | $ | 667,562 |  |  | 100.0 | % |  | $ | 523,029 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |

[0001596532-21-000149:mdna:22]
[same as prior period, unchanged from 0001596532-20-000226:mdna:23]

[0001596532-21-000149:mdna:23]
Product revenue primarily consists of sales of our switching and routing products, and software licenses. Service revenue is primarily derived from sales of post-contract support, or PCS, which is typically purchased in conjunction with our products, and subsequent renewals of those contracts. We expect our revenue may vary from period to period based on, among other things, the timing, size, and complexity of orders, especially with respect to our large end customers.

[0001596532-21-000149:mdna:24]
Product revenue increased $128.2 million, or 31.2%, for the three months ended March 31, 2021 compared to the same period in 2020.  The increase was primarily driven by increased demand for our switching and routing products from our existing customers. In addition, broader market acceptance of our campus and enterprise products has contributed to our revenue growth. Service revenue increased $16.3 million, or 14.5%, in the three months ended March 31, 2021, compared to the same period in 2020, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenues, representing 24.8% of total revenues in the three months ended March 31, 2021, slightly increased from 23.4% compared to the same period in the prior year, which was primarily due to the international expansion of our large end customers. We continued to experience competitive pricing pressure on our products and services.

[0001596532-21-000149:mdna:25]
[same as prior period, unchanged from 0001596532-20-000226:mdna:26]

[0001596532-21-000149:mdna:26]
Cost of product revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs of our manufacturing operations, and other costs associated with manufacturing our products and managing our inventory. Cost of service revenue primarily consists of personnel and other costs associated with

[0001596532-21-000149:mdna:27]
our global customer support and services organizations.

[0001596532-21-000149:mdna:28]
Cost of revenue increased $57.5 million, or 31.1% for the three months ended March 31, 2021 compared to the same period in 2020, which was primarily driven by a corresponding increase in product revenue and increased product transition related costs.

[0001596532-21-000149:mdna:29]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including pricing pressure on our products and services due to competition, the mix of sales to large end customers who generally receive lower pricing, manufacturing-related costs, including costs associated with supply chain sourcing activities, merchant silicon costs, the mix of products sold, and excess/obsolete inventory write-downs, including charges for excess/obsolete component inventory held by our contract manufacturers. We expect our gross margin to fluctuate over time, depending on the factors described above.

[0001596532-21-000149:mdna:30]
Gross margin decreased from 64.7% to 63.7% for the three months ended March 31, 2021 compared to the same period in 2020. The decrease was primarily driven by an increase in product transition related costs, including some excess and obsolete inventory-related charges, which was partially offset by a reduced proportion of sales to larger end customers who generally receive larger discounts.

[0001596532-21-000149:mdna:31]
[same as prior period, unchanged from 0001596532-20-000226:mdna:31]

[0001596532-21-000149:mdna:32]
[same as prior period, unchanged from 0001596532-20-000226:mdna:32]

[0001596532-21-000149:mdna:33]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2021 |  | 2020 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 132,487 |  |  | $ | 113,154 |  |  | $ | 19,333 |  |  | 17.1 | % |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 71,020 |  |  | 57,086 |  |  | 13,934 |  |  | 24.4 |  |  |  |  |  |  |  |  |  |
| General and administrative |  | 15,473 |  |  | 18,349 |  |  | (2,876) |  |  | (15.7) |  |  |  |  |  |  |  |  |  |
| Total operating expenses |  | $ | 218,980 |  |  | $ | 188,589 |  |  | $ | 30,391 |  |  | 16.1 | % |  |  |  |  |  |  |  |  |

[0001596532-21-000149:mdna:34]
[same as prior period, unchanged from 0001596532-20-000226:mdna:34]

[0001596532-21-000149:mdna:35]
Research and development expenses consist primarily of personnel costs, prototype expenses, third-party engineering costs, and an allocated portion of facility and IT costs. Our research and development efforts are focused on new product development and maintaining and developing additional functionality for our existing products, including new releases and upgrades to our EOS software and applications. We expect our research and development expenses to increase in absolute dollars as we continue to invest in software development in order to expand the capabilities of our cloud networking platform, introduce new products and features, and build upon our technology leadership.

[0001596532-21-000149:mdna:36]
Research and development expenses increased $19.3 million, or 17.1%, in the three months ended March 31, 2021 compared to the same period in 2020. The increase in the three months ended March 31, 2021 was primarily due to a $15.2 million increase in personnel costs driven by headcount growth, and an $11.5 million increase in new product introduction costs, including third party engineering and other product development costs. These increases were partially offset by a charge of $5.9 million in the three months ended March 31, 2020 for acquisition-related expenses associated with our acquisition of  Big Switch Networks ("Big Switch").

[0001596532-21-000149:mdna:37]
[same as prior period, unchanged from 0001596532-20-000226:mdna:37]

[0001596532-21-000149:mdna:38]
Sales and marketing expenses consist primarily of personnel costs, marketing, trade shows, and other promotional activities, and an allocated portion of facility and IT costs. We expect our sales and marketing expenses to increase in absolute dollars as we continue to expand our sales and marketing efforts worldwide.

[0001596532-21-000149:mdna:39]
Sales and marketing expenses increased $13.9 million, or 24.4%, for the three months ended March 31, 2021 compared to the same period in 2020. The increase in the three months ended March 31, 2021 included $16.3 million in personnel-related costs mostly driven by an increase in headcount, which was partially offset by a charge of $3.7 million in the three months ended March 31, 2020 for acquisition-related expenses associated with our acquisition of Big Switch.

[0001596532-21-000149:mdna:40]
[same as prior period, unchanged from 0001596532-20-000226:mdna:40]

[0001596532-21-000149:mdna:41]
General and administrative expenses consist primarily of personnel costs and professional services costs. General and administrative personnel costs include those for our executive, finance, human resources and legal functions. Our professional services costs are primarily related to external legal, accounting and tax services.

[0001596532-21-000149:mdna:42]
General and administrative expenses decreased $2.9 million, or 15.7%, in the three months ended March 31, 2021 compared to the same period in 2020.  The decrease for the three months ended March 31, 2021 was primarily related to $2.2 million in acquisition-related expenses associated with our acquisition of Big Switch in the three months ended March 31, 2020.

[0001596532-21-000149:mdna:43]
[same as prior period, unchanged from 0001596532-20-000226:mdna:43]

[0001596532-21-000149:mdna:44]
Other income, net consists primarily of interest income from our cash, cash equivalents and marketable securities, gains and losses on our investments in privately-held companies, and foreign currency transaction gains and losses. We expect other income, net may fluctuate in the future as a result of the re-measurement of our private company equity investments upon the occurrence of observable price changes and/or impairments, changes in interest rates or returns on our cash and cash equivalents and marketable securities, and foreign currency exchange rate fluctuations.

[0001596532-21-000149:mdna:45]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2021 |  | 2020 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Other income, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 2,045 |  |  | $ | 11,662 |  |  | $ | (9,617) |  |  | (82.5) | % |  |  |  |  |  |  |  |  |
| Other income (expense), net |  | (470) |  |  | 495 |  |  | (965) |  |  | (194.9) |  |  |  |  |  |  |  |  |  |
| Total other income, net |  | $ | 1,575 |  |  | $ | 12,157 |  |  | $ | (10,582) |  |  | (87.0) | % |  |  |  |  |  |  |  |  |

[0001596532-21-000149:mdna:46]
Interest income decreased in the current quarter compared to the same period in the prior year despite an increase in investment balances, which was primarily caused by significant declines in market interest rates and the increased weight of higher quality government and corporate bonds in our investment portfolio in response to the global market disruptions and uncertainties resulting from the COVID-19 pandemic.

[0001596532-21-000149:mdna:47]
[same as prior period, unchanged from 0001596532-20-000226:mdna:48]

[0001596532-21-000149:mdna:48]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. Earnings from our non-U.S. activities are subject to local country income tax and may also be subject to U.S. income tax. Generally, our U.S. tax obligations are reduced by a credit for foreign income taxes paid on these foreign earnings, which avoids double taxation. Our tax expense to date consists of federal, state and foreign current and deferred income taxes.

[0001596532-21-000149:mdna:49]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2021 |  | 2020 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Income before income taxes |  | $ | 207,867 |  |  | $ | 161,819 |  |  | $ | 46,048 |  |  | 28.5 | % |  |  |  |  |  |  |  |  |
| Provision for income taxes |  | 27,501 |  |  | 23,388 |  |  | 4,113 |  |  | 17.6 | % |  |  |  |  |  |  |  |  |
| Effective tax rate |  | 13.2 | % |  | 14.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001596532-21-000149:mdna:50]
For the three months ended March 31, 2021 and 2020, we recorded a provision of $27.5 million and $23.4 million for income taxes, respectively. The increase in income taxes was primarily due to an overall increase in worldwide earnings, which was partly offset by higher tax benefits attributable to stock-based awards in the three months ended March 31, 2021, as compared to the same period in 2020.

[0001596532-21-000149:mdna:51]
[same as prior period, unchanged from 0001596532-20-000226:mdna:52]

[0001596532-21-000149:mdna:52]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of March 31, 2021, our total balance of cash, cash equivalents and marketable securities was approximately $3.0 billion, of which approximately $440.5 million was held outside of the U.S. in our foreign subsidiaries.

[0001596532-21-000149:mdna:53]
Our cash, cash equivalents and marketable securities are held for general business purpose including the funding of working capital. Our marketable securities investment portfolio is primarily invested in highly-rated securities, with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations, will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of

[0001596532-21-000149:mdna:54]
new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and stock repurchases. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-21-000149:mdna:55]
Cash Flows (in thousands)

[0001596532-21-000149:mdna:56]
|  |  | Three Months Ended March 31, |
|  |  | 2021 |  | 2020 |
| Cash provided by operating activities |  | $ | 254,675 |  |  | $ | 194,847 |  |
| Cash used in investing activities |  | (217,949) |  |  | (329,478) |  |
| Cash used in financing activities |  | (85,770) |  |  | (212,553) |  |
| Effect of exchange rate changes |  | (838) |  |  | (2,691) |  |
| Net decrease in cash, cash equivalents and restricted cash |  | $ | (49,882) |  |  | $ | (349,875) |  |

[0001596532-21-000149:mdna:57]
[same as prior period, unchanged from 0001596532-20-000226:mdna:58]

[0001596532-21-000149:mdna:58]
During the three months ended March 31, 2021, cash provided by operating activities was $254.7 million, primarily from net income of $180.4 million and non-cash adjustments to net income of $61.3 million driven by stock-based compensation and depreciation and amortization, and a net decrease of $13.0 million in working capital requirements. Cash inflows from the decrease in working capital requirements primarily consisted of a $69.2 million increase in product and service deferred revenue driven by contacts with acceptance terms and continued growth in PCS contracts, which was largely offset by cash outflows of a $20.8 million decrease in accrued liabilities including the payment of corporate bonuses, a $15.3 million increase in prepaid expenses including increased deferred product cost of revenue, and a $10.4 million decrease in income taxes payables.

[0001596532-21-000149:mdna:59]
During the three months ended March 31, 2020, cash provided by operating activities was $194.8 million, primarily from net income of $138.4 million and non-cash adjustments to net income of $43.3 million driven by stock-based compensation and depreciation and amortization, and a net increase of $13.1 million in cash from changes in our operating assets and liabilities. Cash inflows from working capital changes primarily included a $46.3 million decrease in accounts receivable due to strong collections and timing of customer shipments in the current quarter, and a $25.8 million decrease in prepaid expenses due to a decrease in contract receivables and prepaid taxes. These cash inflows were partially offset by cash outflows of a $39.5 million decrease in accrued liabilities primarily due to payment of corporate bonuses in the current quarter, and a $17.7 million increase in inventories due to the timing of product shipments and receipts.

[0001596532-21-000149:mdna:60]
[same as prior period, unchanged from 0001596532-20-000226:mdna:61]

[0001596532-21-000149:mdna:61]
During the three months ended March 31, 2021, cash used in investing activities was $217.9 million, primarily consisting of purchases of available-for-sale securities of $590.5 million, and purchases of property and equipment of $5.1 million, partially offset by proceeds from maturities of marketable securities of $379.6 million.

[0001596532-21-000149:mdna:62]
During the three months ended March 31, 2020, cash used in investing activities was $329.5 million, consisting of purchases of available-for-sale securities of $674.6 million, $66.2 million for the acquisition of Big Switch, and purchases of property and equipment of $3.1 million, partially offset by proceeds from maturities of marketable securities of $414.5 million.

[0001596532-21-000149:mdna:63]
[same as prior period, unchanged from 0001596532-20-000226:mdna:64]

[0001596532-21-000149:mdna:64]
During the three months ended March 31, 2021, cash used in financing activities was $85.8 million, primarily consisting of payments for repurchases of our common stock from the open market of $101.4 million, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $18.1 million.

[0001596532-21-000149:mdna:65]
During the three months ended March 31, 2020, cash provided by financing activities was $212.6 million, consisting of payments for repurchases of our common stock from the open market of $227.9 million and taxes paid of $1.7 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $17.1 million.

[0001596532-21-000149:mdna:66]
[same as prior period, unchanged from 0001596532-20-000226:mdna:67]

[0001596532-21-000149:mdna:67]
From time to time, we repurchase our common stock pursuant to our Repurchase Program authorized by our board of directors in April 2019. The Repurchase Program allows for stock repurchases of up to $1.0 billion through April 2022, and these repurchases are funded from working capital. The Repurchase Program, does not obligate us to acquire any of our

[0001596532-21-000149:mdna:68]
common stock, and may be suspended or discontinued by us at any time without prior notice.  During the quarter ended March 31, 2021, we repurchased a total of $101.4 million of our common stock. As of March 31, 2021, the remaining authorized amount for repurchases under the Repurchase Program was $237.3 million. Refer to Note 6. Stockholders' Equity and Stock-based Compensation of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-21-000149:mdna:69]
[same as prior period, unchanged from 0001596532-20-000226:mdna:69]

[0001596532-21-000149:mdna:70]
As of March 31, 2021, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-21-000149:mdna:71]
[same as prior period, unchanged from 0001596532-20-000226:mdna:71]

[0001596532-21-000149:mdna:72]
Our contractual commitments will have an impact on our future liquidity.  Our contractual obligations represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalent and marketable securities. As of March 31, 2021, our principal commitments consist primarily of obligations under operating leases for offices and data centers and purchase commitments with our contract manufacturers and suppliers. See Note 5. Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for our purchase commitments as of March 31, 2021.

[0001596532-21-000149:mdna:73]
[same as prior period, unchanged from 0001596532-20-000226:mdna:73]

[0001596532-21-000149:mdna:74]
Our management’s discussion and analysis of financial condition and results of operations is based on our unaudited condensed consolidated financial statements, which have been prepared in accordance with GAAP.  The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. We believe the critical accounting policies and estimates in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our Annual Report on Form 10-K filed with the SEC on February 19, 2021 reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting policies and estimates as disclosed in our Annual Report on Form 10-K.

[0001596532-21-000149:mdna:75]
[same as prior period, unchanged from 0001596532-20-000226:mdna:75]

[0001596532-21-000149:mdna:76]
Refer to the sections titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
