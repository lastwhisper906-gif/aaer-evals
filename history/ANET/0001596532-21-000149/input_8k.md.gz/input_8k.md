# ANET 8-K — 0001596532-21-000138 filed 2021-05-04

## item codes, every 8-K on or before 2021-05-06

- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2021-05-06

- none on or before 2021-05-06

## item 2.02 — earnings release, exhibit 99.1

[0001596532-21-000138:8k_2_02:1]
EX-99.1
2
ex991q121-earningsrelease.htm
EX-99.1

[0001596532-21-000138:8k_2_02:2]
Document

[0001596532-21-000138:8k_2_02:3]
Exhibit 99.1

[0001596532-21-000138:8k_2_02:4]
Arista Networks, Inc. Reports First Quarter 2021 Financial Results

[0001596532-21-000138:8k_2_02:5]
SANTA CLARA, Calif.- May 4, 2021 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in cognitive cloud networking solutions for large datacenter and campus environments, today announced financial results for its first quarter ended March 31, 2021.

[0001596532-21-000138:8k_2_02:6]
“Arista begins the 2021 year with a flying start. Clearly, the focus on our cognitive cloud networking suite is resonating with customers across diverse data sets and applications,” stated Jayshree Ullal, President and CEO of Arista Networks.

[0001596532-21-000138:8k_2_02:7]
First Quarter Financial Highlights

[0001596532-21-000138:8k_2_02:8]
•Revenue of $667.6 million, an increase of 2.9% compared to the fourth quarter of 2020, and an increase of 27.6% from the first quarter of 2020.

[0001596532-21-000138:8k_2_02:9]
•GAAP gross margin of 63.7%, compared to GAAP gross margin of 63.9% in the fourth quarter of 2020 and 64.7% in the first quarter of 2020.

[0001596532-21-000138:8k_2_02:10]
•Non-GAAP gross margin of 64.7%, compared to non-GAAP gross margin of 65.0% in the fourth quarter of 2020 and 65.6% in the first quarter of 2020.

[0001596532-21-000138:8k_2_02:11]
•GAAP net income of $180.4 million, or $2.27 per diluted share, compared to GAAP net income of $138.4 million, or $1.73 per diluted share in the first quarter of 2020.

[0001596532-21-000138:8k_2_02:12]
•Non-GAAP net income of $198.8 million, or $2.50 per diluted share, compared to non-GAAP net income of $161.7 million, or $2.02 per diluted share in the first quarter of 2020.

[0001596532-21-000138:8k_2_02:13]
Commenting on the company’s financial results, Ita Brennan, Arista’s CFO said, “We experienced continued validation of our business diversification initiatives in the first quarter, with healthy demand across all our market and product sectors.”

[0001596532-21-000138:8k_2_02:14]
First Quarter Company Highlights

[0001596532-21-000138:8k_2_02:15]
•Arista Delivers Multi-Domain Segmentation for Zero Trust Enterprise — Arista Networks announced a new zero trust security framework for today's digital enterprise. Arista Multi-Domain Macro-Segmentation Service is a suite of capabilities for integrating security policy with the network through an open and consistent network segmentation approach across network domains.

[0001596532-21-000138:8k_2_02:16]
•Arista Completes 400G ZR Interoperability Testing — Arista Networks announced successful interoperability testing between multiple 400G ZR suppliers over Microsoft’s 120km open line system testbed. This multi-vendor testing sets the foundation for a healthy, interoperable, coherent optics ecosystem, providing customers with a multitude of options for building high speed Data Center Interconnect (DCI) networks.

[0001596532-21-000138:8k_2_02:17]
•Arista Advances Zero Trust Security Strategy with Enhancements to AI-driven Awake Security Platform  -—  Awake Security, the network detection and response (NDR) security division of Arista Networks, unveiled platform enhancements that strengthen its ability to detect advanced threats, protect the unmanaged attack surface and autonomously perform threat hunting and forensic investigations.

[0001596532-21-000138:8k_2_02:18]
Financial Outlook

[0001596532-21-000138:8k_2_02:19]
For the second quarter of 2021, we expect:

[0001596532-21-000138:8k_2_02:20]
•Revenue between $675 million to $695 million;

[0001596532-21-000138:8k_2_02:21]
•Non-GAAP gross margin of 63% to 65%; and

[0001596532-21-000138:8k_2_02:22]
•Non-GAAP operating margin of approximately 37%.

[0001596532-21-000138:8k_2_02:23]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and certain non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below under “Non-GAAP Financial Measures”).

[0001596532-21-000138:8k_2_02:24]
Prepared Materials and Conference Call Information

[0001596532-21-000138:8k_2_02:25]
Arista executives will discuss the first quarter financial results on a conference call at 1:30 p.m. Pacific Time today. To listen to the call via telephone, dial (833) 968-2211 in the United States or +1 (778) 560-2896 from international locations. The Conference ID is 9089156.

[0001596532-21-000138:8k_2_02:26]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-21-000138:8k_2_02:27]
Forward-Looking Statements

[0001596532-21-000138:8k_2_02:28]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the second quarter of 2021 and statements regarding the benefits of new products and product enhancements, and our leadership in cloud networking. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: the impact of the COVID-19 pandemic on our business; insufficient component supply and inventory; manufacturing capacity impacted by COVID-19 and increased lead times; interruptions or delays in shipments; the rapid evolution of the networking market; any failure to successfully pursue new products and service offerings and expand into adjacent markets; a decline in our revenue growth rate; unpredictability of our results of operations; adverse economic conditions or reduced information technology and network infrastructure spending; intense competition; expansion of our international sales and operations; investment or acquisition in other businesses; seasonality; our ability to attract new large end customers or sell products and services to existing end customers; our ability to increase market awareness of our company and new products and services; product quality problems; our ability to anticipate technological shifts and develop products to meet those technological shifts; our ability to protect, defend and maintain our intellectual property rights; vulnerabilities in our products and failure of our products to detect security breaches our intellectual property rights; and tax, tariff, import/export restrictions; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-21-000138:8k_2_02:29]
Non-GAAP Financial Measures

[0001596532-21-000138:8k_2_02:30]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangible assets, certain non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its

[0001596532-21-000138:8k_2_02:31]
financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-21-000138:8k_2_02:32]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-21-000138:8k_2_02:33]
The company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. The company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. A reconciliation of the non-GAAP financial measures guidance to the corresponding GAAP measures on a forward-looking basis is not available because stock-based compensation expense is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-21-000138:8k_2_02:34]
About Arista Networks

[0001596532-21-000138:8k_2_02:35]
Arista Networks is an industry leader in cognitive cloud networking solutions for large data center and campus environments. Arista’s award-winning platforms deliver availability, agility, automation analytics, and security through CloudVision® and Arista EOS®, an advanced network operating system.  For more information visit www.arista.com.

[0001596532-21-000138:8k_2_02:36]
ARISTA, CloudVision, CloudEOS and MSS are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners. Additional information and resources can be found at www.arista.com.

[0001596532-21-000138:8k_2_02:37]
| Investor Contacts |
| Arista Networks, Inc. Charles Yager, 408-547-5892 Product and Investor Advocacy cyager@arista.comor |
| Curtis McKee, 408-547-5549Corporate and Investor Developmentcurtism@arista.com |

[0001596532-21-000138:8k_2_02:38]
3

[0001596532-21-000138:8k_2_02:39]
ARISTA NETWORKS, INC.

[0001596532-21-000138:8k_2_02:40]
Condensed Consolidated Statements of Operations

[0001596532-21-000138:8k_2_02:41]
(Unaudited in thousands, except per share amounts)

[0001596532-21-000138:8k_2_02:42]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 539,145 |  |  | $ | 410,906 |  |  |  |  |  |
| Service |  | 128,417 |  |  | 112,123 |  |  |  |  |  |
| Total revenue |  | 667,562 |  |  | 523,029 |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 218,433 |  |  | 163,629 |  |  |  |  |  |
| Service |  | 23,857 |  |  | 21,149 |  |  |  |  |  |
| Total cost of revenue |  | 242,290 |  |  | 184,778 |  |  |  |  |  |
| Gross profit |  | 425,272 |  |  | 338,251 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 132,487 |  |  | 113,154 |  |  |  |  |  |
| Sales and marketing |  | 71,020 |  |  | 57,086 |  |  |  |  |  |
| General and administrative |  | 15,473 |  |  | 18,349 |  |  |  |  |  |
| Total operating expenses |  | 218,980 |  |  | 188,589 |  |  |  |  |  |
| Income from operations |  | 206,292 |  |  | 149,662 |  |  |  |  |  |
| Other income, net |  | 1,575 |  |  | 12,157 |  |  |  |  |  |
| Income before income taxes |  | 207,867 |  |  | 161,819 |  |  |  |  |  |
| Provision for income taxes |  | 27,501 |  |  | 23,388 |  |  |  |  |  |
| Net income |  | $ | 180,366 |  |  | $ | 138,431 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.36 |  |  | $ | 1.82 |  |  |  |  |  |
| Diluted |  | $ | 2.27 |  |  | $ | 1.73 |  |  |  |  |  |
| Weighted-average shares used in computing net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 76,306 |  |  | 76,264 |  |  |  |  |  |
| Diluted |  | 79,623 |  |  | 79,939 |  |  |  |  |  |

[0001596532-21-000138:8k_2_02:43]
ARISTA NETWORKS, INC.

[0001596532-21-000138:8k_2_02:44]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-21-000138:8k_2_02:45]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-21-000138:8k_2_02:46]
|  |  | Three Months Ended March 31, |  |  |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 425,272 |  |  | $ | 338,251 |  |  |  |  |  |  |  |
| GAAP gross margin |  | 63.7 | % |  | 64.7 | % |  |  |  |  |  |  |
| Stock-based compensation expense |  | 1,400 |  |  | 1,327 |  |  |  |  |  |  |  |
| Intangible asset amortization |  | 5,464 |  |  | 3,660 |  |  |  |  |  |  |  |
| Non-GAAP gross profit |  | $ | 432,136 |  |  | $ | 343,238 |  |  |  |  |  |  |  |
| Non-GAAP gross margin |  | 64.7 | % |  | 65.6 | % |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 206,292 |  |  | $ | 149,662 |  |  |  |  |  |  |  |
| Stock-based compensation expense |  | 37,553 |  |  | 27,556 |  |  |  |  |  |  |  |
| Intangible asset amortization |  | 7,430 |  |  | 4,902 |  |  |  |  |  |  |  |
| Acquisition-related costs (1) |  | — |  |  | 11,860 |  |  |  |  |  |  |  |
| Non-GAAP income from operations |  | $ | 251,275 |  |  | $ | 193,980 |  |  |  |  |  |  |  |
| Non-GAAP operating margin |  | 37.6 | % |  | 37.1 | % |  |  |  |  |  |  |
| GAAP net income |  | $ | 180,366 |  |  | $ | 138,431 |  |  |  |  |  |  |  |
| Stock-based compensation expense |  | 37,553 |  |  | 27,556 |  |  |  |  |  |  |  |
| Intangible asset amortization |  | 7,430 |  |  | 4,902 |  |  |  |  |  |  |  |
| Acquisition-related costs |  | — |  |  | 11,860 |  |  |  |  |  |  |  |
| Tax benefit on stock-based awards |  | (20,906) |  |  | (14,502) |  |  |  |  |  |  |  |
| Income tax effect on non-GAAP exclusions |  | (5,606) |  |  | (6,555) |  |  |  |  |  |  |  |
| Non-GAAP net income |  | $ | 198,837 |  |  | $ | 161,692 |  |  |  |  |  |  |  |
| GAAP diluted net income per share |  | $ | 2.27 |  |  | $ | 1.73 |  |  |  |  |  |  |  |
| Non-GAAP adjustments to net income |  | 0.23 |  |  | 0.29 |  |  |  |  |  |  |  |
| Non-GAAP diluted net income per share |  | $ | 2.50 |  |  | $ | 2.02 |  |  |  |  |  |  |  |
| Weighted-average shares used in computing diluted net income per share |  | 79,623 |  |  | 79,939 |  |  |  |  |  |  |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,400 |  |  | $ | 1,327 |  |  |  |  |  |  |  |
| Research and development |  | 21,982 |  |  | 15,928 |  |  |  |  |  |  |  |
| Sales and marketing |  | 10,085 |  |  | 6,396 |  |  |  |  |  |  |  |
| General and administrative |  | 4,086 |  |  | 3,905 |  |  |  |  |  |  |  |
| Total |  | $ | 37,553 |  |  | $ | 27,556 |  |  |  |  |  |  |  |
| (1) Represents non-recurring costs associated with our acquisition of Big Switch, and primarily includes severance, retention bonuses, professional and consulting fees, and facilities restructuring costs. |  |  |  |  |  |  |

[0001596532-21-000138:8k_2_02:47]
5

[0001596532-21-000138:8k_2_02:48]
ARISTA NETWORKS, INC.

[0001596532-21-000138:8k_2_02:49]
Condensed Consolidated Balance Sheets

[0001596532-21-000138:8k_2_02:50]
(Unaudited, in thousands)

[0001596532-21-000138:8k_2_02:51]
|  |  | March 31, 2021 |  | December 31, 2020 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 843,336 |  |  | $ | 893,219 |  |
| Marketable securities |  | 2,184,330 |  |  | 1,979,649 |  |
| Accounts receivable, net |  | 380,466 |  |  | 389,540 |  |
| Inventories |  | 483,168 |  |  | 479,668 |  |
| Prepaid expenses and other current assets |  | 111,595 |  |  | 94,922 |  |
| Total current assets |  | 4,002,895 |  |  | 3,836,998 |  |
| Property and equipment, net |  | 32,462 |  |  | 32,231 |  |
| Acquisition-related intangible assets, net |  | 115,359 |  |  | 122,790 |  |
| Goodwill |  | 188,277 |  |  | 189,696 |  |
| Investments |  | 10,314 |  |  | 8,314 |  |
| Operating lease right-of-use assets |  | 72,956 |  |  | 77,288 |  |
| Deferred tax assets |  | 438,277 |  |  | 441,531 |  |
| Other assets |  | 33,190 |  |  | 30,071 |  |
| TOTAL ASSETS |  | $ | 4,893,730 |  |  | $ | 4,738,919 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 136,885 |  |  | $ | 134,235 |  |
| Accrued liabilities |  | 122,466 |  |  | 143,357 |  |
| Deferred revenue |  | 457,799 |  |  | 396,259 |  |
| Other current liabilities |  | 69,382 |  |  | 94,392 |  |
| Total current liabilities |  | 786,532 |  |  | 768,243 |  |
| Income taxes payable |  | 55,314 |  |  | 53,053 |  |
| Operating lease liabilities, non-current |  | 67,770 |  |  | 72,397 |  |
| Deferred revenue, non-current |  | 262,232 |  |  | 254,568 |  |
| Deferred tax liabilities, non-current |  | 225,924 |  |  | 227,936 |  |
| Other long-term liabilities |  | 44,620 |  |  | 42,431 |  |
| TOTAL LIABILITIES |  | 1,442,392 |  |  | 1,418,628 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 8 |  | 8 |  |
| Additional paid-in capital |  | 1,345,569 |  | 1,292,431 |  |
| Retained earnings |  | 2,106,625 |  | 2,027,614 |  |
| Accumulated other comprehensive income (loss) |  | (864) |  | 238 |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 3,451,338 |  |  | 3,320,291 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 4,893,730 |  |  | $ | 4,738,919 |  |

[0001596532-21-000138:8k_2_02:52]
ARISTA NETWORKS, INC.

[0001596532-21-000138:8k_2_02:53]
Condensed Consolidated Statements of Cash Flows

[0001596532-21-000138:8k_2_02:54]
(Unaudited, in thousands)

[0001596532-21-000138:8k_2_02:55]
|  |  | Three Months Ended |
|  |  | 2021 |  | 2020 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 180,366 |  |  | $ | 138,431 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 12,658 |  |  | 10,208 |  |
| Stock-based compensation |  | 37,553 |  |  | 27,556 |  |
| Noncash lease expense |  | 4,243 |  |  | 4,073 |  |
| Deferred income taxes |  | 1,425 |  |  | 457 |  |
| Amortization of investment premiums |  | 5,446 |  |  | 1,042 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | 9,074 |  |  | 46,329 |  |
| Inventories |  | (3,500) |  |  | (17,691) |  |
| Prepaid expenses and other current assets |  | (15,272) |  |  | 25,751 |  |
| Other assets |  | (3,499) |  |  | 3,946 |  |
| Accounts payable |  | 2,833 |  |  | (6,386) |  |
| Accrued liabilities |  | (20,759) |  |  | (39,450) |  |
| Deferred revenue |  | 69,204 |  |  | 21 |  |
| Income taxes payable |  | (10,436) |  |  | 3,982 |  |
| Other liabilities |  | (14,661) |  |  | (3,422) |  |
| Net cash provided by operating activities |  | 254,675 |  |  | 194,847 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 379,605 |  |  | 414,503 |  |
| Purchases of marketable securities |  | (590,476) |  |  | (674,649) |  |
| Business acquisitions, net of cash acquired |  | — |  |  | (66,225) |  |
| Purchases of property and equipment |  | (5,096) |  |  | (3,107) |  |
| Escrow receipts from past business acquisitions |  | 18 |  |  | — |  |
| Purchases of investments in privately-held companies |  | (2,000) |  |  | — |  |
| Net cash used in investing activities |  | (217,949) |  |  | (329,478) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 18,081 |  |  | 17,082 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (2,496) |  |  | (1,740) |  |
| Repurchase of common stock |  | (101,355) |  |  | (227,895) |  |
| Net cash used in financing activities |  | (85,770) |  |  | (212,553) |  |
| Effect of exchange rate changes |  | (838) |  |  | (2,691) |  |
| NET DECREASE IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | (49,882) |  |  | (349,875) |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 897,454 |  |  | 1,115,515 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 847,572 |  |  | $ | 765,640 |  |

[0001596532-21-000138:8k_2_02:56]
7
