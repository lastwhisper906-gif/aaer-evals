# ANET notes — 0001596532-21-000149


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-21-000149:notes:1]
[same as prior period, unchanged from 0001596532-20-000226:notes:1]

[0001596532-21-000149:notes:2]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale internet companies, cloud service providers and next-generation enterprises. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-21-000149:notes:3]
[same as prior period, unchanged from 0001596532-20-000226:notes:3]

[0001596532-21-000149:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2021, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2020 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

[0001596532-21-000149:notes:5]
Our condensed consolidated financial statements and related financial information in this Quarterly Report on Form 10-Q should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2020, filed with the SEC on February 19, 2021.

[0001596532-21-000149:notes:6]
[same as prior period, unchanged from 0001596532-20-000226:notes:6]

[0001596532-21-000149:notes:7]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and accompanying notes. These estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; valuation of goodwill and acquisition-related intangible assets, accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; estimate of useful lives of long-lived assets including intangible assets; valuation of inventory and contract manufacturer/supplier liabilities; and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.

[0001596532-21-000149:notes:8]
[same as prior period, unchanged from 0001596532-20-000226:notes:8]

[0001596532-21-000149:notes:9]
The global coronavirus ("COVID-19") pandemic and resulting mitigation efforts by governments around the world to contain or slow its spread have negatively impacted the global economy, disrupted business, sales activities, global supply chains and workforce participation, including our own, and created significant volatility and disruption of financial markets.

[0001596532-21-000149:notes:10]
Our contract manufacturers and suppliers have experienced delays in component sourcing, production and export of their products, which have negatively impacted our supply chain and could negatively impact our business in the future. In addition, COVID-19 related disruptions may have a negative impact on demand from our customers in future periods. However, the extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, including the duration and spread of the pandemic and related mitigation efforts, the impact to our customers, partners, contract manufacturers and supply chain, as well as restrictions on travel and transport, all of which are uncertain and cannot be predicted. Management is actively monitoring the impact of the pandemic on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which the COVID-19 pandemic may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

[0001596532-21-000149:notes:11]
Recently Adopted Accounting Pronouncements

[0001596532-21-000149:notes:12]
Income Taxes

[0001596532-21-000149:notes:13]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for incomes taxes by removing certain exceptions to the general principles in Topic 740 and amending existing guidance to improve consistent application. This new standard is effective for our interim and annual periods beginning January 1, 2021. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. We adopted this new standard on January 1, 2021 with no material impact on our condensed consolidated financial statements.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-21-000149:notes:14]
Fair Value Measurements 
    We measure and report our cash equivalents, restricted cash, and available-for-sale marketable securities at fair value on a recurring basis. The following tables summarize the amortized costs, unrealized gains and losses and fair value of these financial assets by significant investment category and their levels within the fair value hierarchy (in thousands):

[0001596532-21-000149:notes:15]
|  |  | March 31, 2021 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 379,345 |  |  | $ | — |  |  | $ | — |  |  | $ | 379,345 |  |  | $ | 379,345 |  |  | $ | — |  |  | $ | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 46,658 |  |  | — |  |  | — |  |  | 46,658 |  |  | — |  |  | 46,658 |  |  | — |  |
| Certificate of deposits(1) |  | 80,069 |  |  | — |  |  | — |  |  | 80,069 |  |  | — |  |  | 80,069 |  |  | — |  |
| U.S. government notes |  | 661,366 |  |  | 190 |  |  | (38) |  |  | 661,518 |  |  | 661,518 |  |  | — |  |  | — |  |
| Corporate bonds |  | 972,063 |  |  | 709 |  |  | (522) |  |  | 972,250 |  |  | — |  |  | 972,250 |  |  | — |  |
| Agency securities |  | 423,551 |  |  | 287 |  |  | (3) |  |  | 423,835 |  |  | — |  |  | 423,835 |  |  | — |  |
|  |  | 2,183,707 |  |  | 1,186 |  |  | (563) |  |  | 2,184,330 |  |  | 661,518 |  |  | 1,522,812 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,236 |  |  | — |  |  | — |  |  | 4,236 |  |  | 4,236 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 2,567,288 |  |  | $ | 1,186 |  |  | $ | (563) |  |  | $ | 2,567,911 |  |  | $ | 1,045,099 |  |  | $ | 1,522,812 |  |  | $ | — |  |

[0001596532-21-000149:notes:16]
|  |  | December 31, 2020 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 438,854 |  |  | $ | — |  |  | $ | — |  |  | $ | 438,854 |  |  | $ | 438,854 |  |  | $ | — |  |  | $ | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 51,211 |  |  | — |  |  | — |  |  | 51,211 |  |  | — |  |  | 51,211 |  |  | — |  |
| Certificate of deposits(1) |  | 50,136 |  |  | 3 |  |  | — |  |  | 50,139 |  |  | — |  |  | 50,139 |  |  | — |  |
| U.S. government notes |  | 523,320 |  |  | 187 |  |  | (1) |  |  | 523,506 |  |  | 523,506 |  |  | — |  |  | — |  |
| Corporate bonds |  | 878,484 |  |  | 1,167 |  |  | (330) |  |  | 879,321 |  |  | — |  |  | 879,321 |  |  | — |  |
| Agency securities |  | 475,132 |  |  | 343 |  |  | (3) |  |  | 475,472 |  |  | — |  |  | 475,472 |  |  | — |  |
|  |  | 1,978,283 |  |  | 1,700 |  |  | (334) |  |  | 1,979,649 |  |  | 523,506 |  |  | 1,456,143 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,235 |  |  | — |  |  | — |  |  | 4,235 |  |  | 4,235 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 2,421,372 |  |  | $ | 1,700 |  |  | $ | (334) |  |  | $ | 2,422,738 |  |  | $ | 966,595 |  |  | $ | 1,456,143 |  |  | $ | — |  |

[0001596532-21-000149:notes:17]
[same as prior period, unchanged from 0001596532-20-000226:notes:28]

[0001596532-21-000149:notes:18]
(1) As of March 31, 2021 and December 31, 2020, all of our certificates of deposits were domestic deposits.

[0001596532-21-000149:notes:19]
As of March 31, 2021 and December 31, 2020, total unrealized losses of our marketable securities were immaterial. We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. We expect to realize the full value of these investments upon maturity or sale and therefore, we do not consider any of our marketable securities to be impaired as of March 31, 2021. We did not recognize any credit losses or non-credit-related impairments related to our available-for-sale marketable securities for the quarter ended March 31, 2021.

[0001596532-21-000149:notes:20]
As of March 31, 2021, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale marketable securities, by remaining contractual maturity, are as follows (in thousands):

[0001596532-21-000149:notes:21]
|  |  | March 31, 2021 |
| Due in 1 year or less |  | $ | 1,246,986 |  |
| Due in 1 to 2 years |  | 937,344 |  |
| Total marketable securities |  | $ | 2,184,330 |  |

[0001596532-21-000149:notes:22]
The weighted-average remaining duration of our current marketable securities is approximately 0.9 years as of  March 31, 2021.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-21-000149:notes:23]
[same as prior period, unchanged from 0001596532-20-000226:notes:34]

[0001596532-21-000149:notes:24]
The reconciliation of cash, cash equivalents and restricted cash reported in the accompanying unaudited condensed consolidated balance sheets to the total of the same such amounts in the accompanying unaudited condensed consolidated statements of cash flows is as follows (in thousands):

[0001596532-21-000149:notes:25]
|  |  | March 31, 2021 |  | December 31, 2020 |
| Cash and cash equivalents |  | $ | 843,336 |  |  | $ | 893,219 |  |
| Restricted cash included in other assets |  | 4,236 |  |  | 4,235 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 847,572 |  |  | $ | 897,454 |  |

[0001596532-21-000149:notes:26]
Accounts Receivable, net

[0001596532-21-000149:notes:27]
[same as prior period, unchanged from 0001596532-20-000226:notes:39]

[0001596532-21-000149:notes:28]
|  |  | March 31, 2021 |  | December 31, 2020 |
| Accounts receivable |  | $ | 385,204 |  |  | $ | 394,037 |  |
| Allowance for doubtful accounts |  | (549) |  |  | (659) |  |
| Product sales rebate and returns reserve |  | (4,189) |  |  | (3,838) |  |
| Accounts receivable, net |  | $ | 380,466 |  |  | $ | 389,540 |  |

[0001596532-21-000149:notes:29]
[same as prior period, unchanged from 0001596532-20-000226:notes:41]

[0001596532-21-000149:notes:30]
[same as prior period, unchanged from 0001596532-20-000226:notes:42]

[0001596532-21-000149:notes:31]
|  |  | March 31, 2021 |  | December 31, 2020 |
| Raw materials |  | $ | 234,941 |  |  | $ | 219,218 |  |
| Finished goods |  | 248,227 |  |  | 260,450 |  |
| Total inventories |  | $ | 483,168 |  |  | $ | 479,668 |  |

[0001596532-21-000149:notes:32]
[same as prior period, unchanged from 0001596532-20-000226:notes:44]

[0001596532-21-000149:notes:33]
[same as prior period, unchanged from 0001596532-20-000226:notes:45]

[0001596532-21-000149:notes:34]
|  |  | March 31, 2021 |  | December 31, 2020 |
| Inventory deposit |  | $ | 21,478 |  |  | $ | 18,783 |  |
| Prepaid income taxes |  | 3,612 |  |  | 267 |  |
| Other current assets |  | 69,790 |  |  | 60,556 |  |
| Other prepaid expenses and deposits |  | 16,715 |  |  | 15,316 |  |
| Total prepaid expenses and other current assets |  | $ | 111,595 |  |  | $ | 94,922 |  |

[0001596532-21-000149:notes:35]
Property and Equipment, net

[0001596532-21-000149:notes:36]
[same as prior period, unchanged from 0001596532-20-000226:notes:48]

[0001596532-21-000149:notes:37]
|  |  | March 31, 2021 |  | December 31, 2020 |
| Equipment and machinery |  | $ | 74,401 |  |  | $ | 70,655 |  |
| Computer hardware and software |  | 42,201 |  |  | 40,081 |  |
| Furniture and fixtures |  | 3,793 |  |  | 3,787 |  |
| Leasehold improvements |  | 31,499 |  |  | 31,448 |  |
| Construction-in-process |  | 470 |  |  | 1,441 |  |
| Property and equipment, gross |  | 152,364 |  |  | 147,412 |  |
| Less: accumulated depreciation |  | (119,902) |  |  | (115,181) |  |
| Property and equipment, net |  | $ | 32,462 |  |  | $ | 32,231 |  |

[0001596532-21-000149:notes:38]
Depreciation expense was $4.9 million and $5.2 million for the three months ended March 31, 2021 and 2020, respectively.

[0001596532-21-000149:notes:39]
[same as prior period, unchanged from 0001596532-20-000226:notes:51]

[0001596532-21-000149:notes:40]
[same as prior period, unchanged from 0001596532-20-000226:notes:52]

[0001596532-21-000149:notes:41]
|  |  | March 31, 2021 |  | December 31, 2020 |
| Accrued payroll related costs |  | $ | 42,670 |  |  | $ | 73,634 |  |
| Accrued manufacturing costs |  | 43,420 |  |  | 43,181 |  |
| Accrued product development costs |  | 15,084 |  |  | 6,733 |  |
| Accrued warranty costs |  | 10,043 |  |  | 9,314 |  |
| Other |  | 11,249 |  |  | 10,495 |  |
| Total accrued liabilities |  | $ | 122,466 |  |  | $ | 143,357 |  |

[0001596532-21-000149:notes:42]
[same as prior period, unchanged from 0001596532-20-000226:notes:54]

[0001596532-21-000149:notes:43]
[same as prior period, unchanged from 0001596532-20-000226:notes:55]

[0001596532-21-000149:notes:44]
|  |  | Three Months Ended March 31, |
|  |  | 2021 |  | 2020 |
| Warranty accrual, beginning of period |  | $ | 9,314 |  |  | $ | 6,742 |  |
| Liabilities accrued for warranties issued during the period |  | 3,456 |  |  | 1,070 |  |
| Warranty costs incurred during the period |  | (2,727) |  |  | (1,471) |  |
| Warranty accrual, end of period |  | $ | 10,043 |  |  | $ | 6,341 |  |

[0001596532-21-000149:notes:45]
Contract Assets

[0001596532-21-000149:notes:46]
The following table summarizes the beginning and ending balances of our contract assets (in thousands):

[0001596532-21-000149:notes:47]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Contract assets, beginning balance |  | $ | 16,380 |  |  | $ | 25,565 |  |  |  |  |  |
| Contract assets, ending balance |  | 9,762 |  |  | 9,636 |  |  |  |  |  |

[0001596532-21-000149:notes:48]
Contract Liabilities, Deferred Revenue and Other Performance Obligations

[0001596532-21-000149:notes:49]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a cancellable contract. The following table summarizes the activity related to our contract liabilities (in thousands):

[0001596532-21-000149:notes:50]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Contract liabilities, beginning balance |  | $ | 85,957 |  |  | $ | 61,050 |  |  |  |  |  |
| Less: Revenue recognized from beginning balance |  | (7,913) |  |  | (4,847) |  |  |  |  |  |
| Less: Beginning balance reclassified to deferred revenue |  | (12,492) |  |  | (2,433) |  |  |  |  |  |
| Add: Contract liabilities recognized |  | 14,913 |  |  | 10,555 |  |  |  |  |  |
| Contract liabilities, ending balance |  | $ | 80,465 |  |  | $ | 64,325 |  |  |  |  |  |

[0001596532-21-000149:notes:51]
As of March 31, 2021 and December 31, 2020, $35.9 million and $34.5 million, respectively, of our contract liabilities were recorded within other current liabilities with the remaining balance recorded within other long-term liabilities in the accompanying unaudited condensed consolidated balance sheets.

[0001596532-21-000149:notes:52]
Deferred revenue is comprised mainly of unearned revenue related to multi-year post-contract support ("PCS") contracts, services and product deferrals related to acceptance clauses. The following table summarizes the activity related to our deferred revenue (in thousands):

[0001596532-21-000149:notes:53]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Deferred revenue, beginning balance |  | $ | 650,827 |  |  | $ | 575,288 |  |  |  |  |  |
| Less: Revenue recognized from beginning balance |  | (107,442) |  |  | (100,377) |  |  |  |  |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 176,646 |  |  | 121,864 |  |  |  |  |  |
| Deferred revenue, ending balance |  | $ | 720,031 |  |  | $ | 596,775 |  |  |  |  |  |

[0001596532-21-000149:notes:54]
As of March 31, 2021, other performance obligations of $171.7 million were comprised mainly of unbilled multi-year PCS contract amounts that will be recognized as revenue in future periods.

[0001596532-21-000149:notes:55]
Revenue from Total Remaining Performance Obligations

[0001596532-21-000149:notes:56]
Revenue from total remaining performance obligations represents contract liabilities, deferred revenue and unbilled contract revenue that will be recognized in future periods.  As of March 31, 2021, approximately $972.2 million of revenue is

[0001596532-21-000149:notes:57]
expected to be recognized from total remaining performance obligations. We expect to recognize revenue on approximately 80% of these remaining performance obligations over the next two years and 20% during years 3 to 5.

[0001596532-21-000149:notes:58]
Other Income, net

[0001596532-21-000149:notes:59]
[same as prior period, unchanged from 0001596532-20-000226:notes:69]

[0001596532-21-000149:notes:60]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Interest income |  | $ | 2,045 |  |  | $ | 11,662 |  |  |  |  |  |
| Other income (expense), net |  | (470) |  |  | 495 |  |  |  |  |  |
| Total |  | $ | 1,575 |  |  | $ | 12,157 |  |  |  |  |  |


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-21-000149:notes:61]
[same as prior period, unchanged from 0001596532-20-000226:notes:71]

[0001596532-21-000149:notes:62]
Our investments in privately-held companies do not have readily determinable fair values. Their initial cost is adjusted to fair value on a non-recurring basis based on observable price changes from orderly transactions of identical or similar securities of the same issuer, or for impairment. These investments are classified within Level III of the fair value hierarchy as we estimate the value based on valuation methods using the observable transaction price at the transaction date and other significant unobservable inputs, such as volatility, rights, and obligations related to these securities. In addition, the valuation requires management judgment due to the absence of market price and lack of liquidity. The following table summarizes the activity related to our investments in privately-held companies as of March 31, 2021 and December 31, 2020 (in thousands):

[0001596532-21-000149:notes:63]
|  |  | March 31, 2021 |  | December 31, 2020 |
| Cost of investments |  | $ | 5,000 |  |  | $ | 3,000 |  |
| Cumulative impairment |  | — |  |  | — |  |
| Cumulative upward adjustment |  | 5,314 |  |  | 5,314 |  |
| Carrying amount of investments |  | $ | 10,314 |  |  | $ | 8,314 |  |

[0001596532-21-000149:notes:64]
During the current quarter and the quarter ended March 31, 2020, there were no realized or unrealized gains or losses recorded on our investments.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-21-000149:notes:65]
Commitments and Contingencies
Purchase Commitments

[0001596532-21-000149:notes:66]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of March 31, 2021, we had non-cancellable purchase commitments of $747.6 million, of which $712.7 million were to our contract manufacturers and suppliers. In addition, we had deposits to our contract manufacturers to secure our purchase commitments in the amount of $24.2 million and $21.5 million as of March 31, 2021 and December 31, 2020, respectively, which were included within prepaid expenses and other current assets and other assets on the unaudited condensed consolidated balance sheets.

[0001596532-21-000149:notes:67]
Guarantees

[0001596532-21-000149:notes:68]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-21-000149:notes:69]
Legal Proceedings

[0001596532-21-000149:notes:70]
WSOU Investments, LLC

[0001596532-21-000149:notes:71]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations.

[0001596532-21-000149:notes:72]
We intend to vigorously defend against the claims brought against us by WSOU. However, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-21-000149:notes:73]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated. However, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-21-000149:notes:74]
Other matters

[0001596532-21-000149:notes:75]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-21-000149:notes:76]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2021, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001596532-21-000149:notes:77]
Stockholders’ Equity and Stock-Based Compensation
Stock Repurchase Program

[0001596532-21-000149:notes:78]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the "Repurchase Program").  This authorization allows us to repurchase shares of our common stock and is funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the "Exchange Act") or a combination of the foregoing. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of March 31, 2021, the remaining authorized amount for stock repurchases under this program was approximately $237.3 million.

[0001596532-21-000149:notes:79]
A summary of the stock repurchase activity under the Repurchase Program is as follows (in thousands, except per share amounts):

[0001596532-21-000149:notes:80]
|  |  | Three Months Ended |  |  |  |  |
|  |  | March 31, 2021 |  |  |  |  |
| Aggregate purchase price |  | $ | 101,355 |  |  |  |  |  |
| Shares repurchased |  | 367 |  |  |  |  |  |
| Average price paid per share |  | $ | 275.88 |  |  |  |  |  |

[0001596532-21-000149:notes:81]
The aggregate purchase price of repurchased shares of our common stock is recorded as a reduction to retained earnings and common stock in our condensed consolidated statements of stockholders' equity. All shares repurchased under the Repurchase Program have been retired.

[0001596532-21-000149:notes:82]
Equity Award Plan Activities

[0001596532-21-000149:notes:83]
2014 Equity Incentive Plan

[0001596532-21-000149:notes:84]
The 2014 Equity Incentive Plan (the “2014 plan”) provides for the granting of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Units (“RSUs”), Restricted Stock Awards (“RSAs”) or Stock Appreciation Rights (“SARs”).  The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year by the lesser of (i) 12,500,000 shares, (ii) 3% of the outstanding shares of our common stock on the last day of our immediately preceding fiscal year, or (iii) such other amount as determined by our board of

[0001596532-21-000149:notes:85]
directors.  Effective January 1, 2021, our board of directors authorized an increase of 2,285,228 shares to the shares available for issuance under the 2014 Plan.  As of March 31, 2021, there remained approximately 23.4 million shares available for issuance under the 2014 Plan.

[0001596532-21-000149:notes:86]
2014 Employee Stock Purchase Plan

[0001596532-21-000149:notes:87]
Effective January 1, 2021, our board of directors authorized an increase of 761,742 shares to the shares available for issuance under our 2014 Employee Stock Purchase Plan (the “ESPP”).  Pursuant to the ESPP, the 2021 share increase was determined based on the lesser of 1% of the total shares of common stock outstanding on December 31, 2020, 2,500,000 shares, or such amount as determined by our board of directors. During the three months ended March 31, 2021, we issued 56,326  shares at a weighted-average purchase price of $182.76 per share under the ESPP. As of March 31, 2021, there remained 4.6 million shares available for issuance under the ESPP.

[0001596532-21-000149:notes:88]
Stock Option Activities

[0001596532-21-000149:notes:89]
The following table summarizes the option activity under our stock plans and related information (in thousands, except years and per share amounts):

[0001596532-21-000149:notes:90]
|  |  | Options Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding |
| Balance—December 31, 2020 |  | 3,430 |  |  | $ | 45.17 |  |  | 3.6 |  | $ | 841,659 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (263) |  |  | 29.57 |  |  |  |  |  |
| Options canceled |  | (12) |  |  | 36.08 |  |  |  |  |  |
| Balance—March 31, 2021 |  | 3,155 |  |  | $ | 46.51 |  |  | 3.4 |  | $ | 805,597 |  |
| Vested and exercisable—March 31, 2021 |  | 2,169 |  |  | $ | 34.55 |  |  | 3.0 |  | $ | 579,805 |  |

[0001596532-21-000149:notes:91]
Restricted Stock Unit (RSU) Activities

[0001596532-21-000149:notes:92]
A summary of the RSU activity is presented below (in thousands, except years and per share amounts):

[0001596532-21-000149:notes:93]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2020 |  | 1,816 |  |  | $ | 215.68 |  |  | 1.8 |  | $ | 527,574 |  |
| RSUs granted |  | 176 |  |  | 310.32 |  |  |  |  |  |
| RSUs vested |  | (139) |  |  | 199.41 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (46) |  |  | 225.87 |  |  |  |  |  |
| Unvested balance—March 31, 2021 |  | 1,807 |  |  | $ | 225.88 |  |  | 1.7 |  | $ | 545,194 |  |

[0001596532-21-000149:notes:94]
In the quarter ended March 31, 2021, we granted 69,620 performance-based RSUs (“PRSUs”) to our CEO and other key employees that include both service and performance-based conditions.

[0001596532-21-000149:notes:95]
These PRSUs will vest over the next three to four years and the ultimate number of shares eligible to vest will vary between 0% and 200% of the amount granted based on the achievement of certain performance metrics over the vesting period and each holder’s continued employment with Arista.

[0001596532-21-000149:notes:96]
Stock-Based Compensation Expense

[0001596532-21-000149:notes:97]
The following table summarizes the stock-based compensation expense related to our equity awards (in thousands):

[0001596532-21-000149:notes:98]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Cost of revenue |  | $ | 1,400 |  |  | $ | 1,327 |  |  |  |  |  |
| Research and development |  | 21,982 |  |  | 15,928 |  |  |  |  |  |
| Sales and marketing |  | 10,085 |  |  | 6,396 |  |  |  |  |  |
| General and administrative |  | 4,086 |  |  | 3,905 |  |  |  |  |  |
| Total stock-based compensation |  | $ | 37,553 |  |  | $ | 27,556 |  |  |  |  |  |

[0001596532-21-000149:notes:99]
As of March 31, 2021, there were $414.5 million of unamortized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 3.1 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-21-000149:notes:100]
Net Income Per Share
    The following table sets forth the computation of our basic and diluted net income per share (in thousands, except per share amounts):

[0001596532-21-000149:notes:101]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 180,366 |  |  | $ | 138,431 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share, basic |  | 76,306 |  |  | 76,264 |  |  |  |  |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Stock options and RSUs |  | 3,279 |  |  | 3,675 |  |  |  |  |  |
| Employee stock purchase plan |  | 38 |  |  | — |  |  |  |  |  |
| Weighted-average shares used in computing net income per share, diluted |  | 79,623 |  |  | 79,939 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.36 |  |  | $ | 1.82 |  |  |  |  |  |
| Diluted |  | $ | 2.27 |  |  | $ | 1.73 |  |  |  |  |  |

[0001596532-21-000149:notes:102]
The following weighted-average outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share for the periods presented because their effect would have been anti-dilutive for the periods presented (in thousands):

[0001596532-21-000149:notes:103]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Stock options and RSUs |  | 130 |  |  | 601 |  |  |  |  |  |
| Employee stock purchase plan |  | 10 |  |  | — |  |  |  |  |  |
| Total |  | 140 |  |  | 601 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-21-000149:notes:104]
|  |  | Three Months Ended March 31, |  |  |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
|  |  | (in thousands, except percentages) |  |  |  |  |
| Income before income taxes |  | $ | 207,867 |  |  | $ | 161,819 |  |  |  |  |  |
| Provision for income taxes |  | 27,501 |  |  | 23,388 |  |  |  |  |  |
| Effective tax rate |  | 13.2 | % |  | 14.5 | % |  |  |  |  |

[0001596532-21-000149:notes:105]
The effective tax rates above reflect tax expense recorded on pre-tax income in the three months ended March 31, 2021 and March 31, 2020. The change in effective tax rate in the three months ended March 31, 2021, as compared to the same period in 2020, was primarily due to an increase in tax benefits attributable to stock-based awards.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-21-000149:notes:106]
Geographical Information 
    We operate as one reportable segment. The following table represents revenue based on customers’ shipping addresses (in thousands):

[0001596532-21-000149:notes:107]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Americas |  | $ | 501,872 |  |  | $ | 400,660 |  |  |  |  |  |
| Europe, Middle East and Africa |  | 96,274 |  |  | 72,624 |  |  |  |  |  |
| Asia-Pacific |  | 69,416 |  |  | 49,745 |  |  |  |  |  |
| Total revenue |  | $ | 667,562 |  |  | $ | 523,029 |  |  |  |  |  |

[0001596532-21-000149:notes:108]
Long-lived assets, excluding intercompany receivables, investments in subsidiaries, privately-held equity investments and deferred tax assets, net by location are summarized as follows (in thousands):

[0001596532-21-000149:notes:109]
|  |  | March 31, 2021 |  | December 31, 2020 |
| United States |  | $ | 23,851 |  |  | $ | 24,110 |  |
| International |  | 8,611 |  |  | 8,121 |  |
| Total |  | $ | 32,462 |  |  | $ | 32,231 |  |
