# ANET notes — 0001596532-26-000078


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-26-000078:notes:1]
[same as prior period, unchanged from 0001596532-25-000286:notes:1]

[0001596532-26-000078:notes:2]
[same as prior period, unchanged from 0001596532-25-000286:notes:2]

[0001596532-26-000078:notes:3]
[same as prior period, unchanged from 0001596532-25-000286:notes:3]

[0001596532-26-000078:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and our wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2026, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2025 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated. Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.

[0001596532-26-000078:notes:5]
Our condensed consolidated financial statements and related financial information in this Quarterly Report on Form 10-Q should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2025.

[0001596532-26-000078:notes:6]
[same as prior period, unchanged from 0001596532-25-000286:notes:7]

[0001596532-26-000078:notes:7]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, valuation of inventory and contract manufacturer/supplier liabilities, accounting for income taxes, including the recognition of deferred tax assets and liabilities, valuation allowance on deferred tax assets and reserves for uncertain tax positions, and revenue recognition and deferred revenue. We evaluate our estimates and assumptions based on historical experience and other factors and adjust these estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from these estimates.

[0001596532-26-000078:notes:8]
[same as prior period, unchanged from 0001596532-25-000286:notes:9]

[0001596532-26-000078:notes:9]
In November 2024, the FASB issued ASU 2024-03, Disaggregation of Income Statement Expenses (Subtopic 220-40). The ASU requires the disaggregated disclosure of specific expense categories, including purchases of inventory, employee compensation, depreciation, and amortization, within relevant income statement captions, and also requires disclosure of the total amount of selling expenses along with the definition of selling expenses. The ASU is effective for annual periods beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027. Adoption of this ASU can either be applied prospectively to consolidated financial statements issued for reporting periods after the effective date of this ASU or retrospectively to any or all prior periods presented in the consolidated financial statements. Early adoption is also permitted. This ASU will result in the required additional disclosures being included in our consolidated financial statements, once adopted. We are currently evaluating the provisions of this ASU.

[0001596532-26-000078:notes:10]
On December 2025, the FASB issued ASU 2025-11, Interim Reporting (Topic 270) which is intended to streamline the guidance in ASC 270, Interim Reporting, and clarify when it applies. Under the amendments, an entity is subject to ASC 270 if it provides interim financial statements and notes in accordance with GAAP. ASU 2025-11 also addresses the form and content of such financial statements, interim disclosures requirements, and establishes a principle under which an entity must disclose events since the end of the last annual reporting period that have a material impact on the entity. ASU 2025-11 is effective for interim reporting periods within annual reporting periods beginning after December 15, 2027, and early adoption is permitted. We are currently evaluating the provisions of this ASU.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-26-000078:notes:11]
[same as prior period, unchanged from 0001596532-25-000286:notes:13]

[0001596532-26-000078:notes:12]
We measure and report our cash equivalents, restricted cash, and available-for-sale marketable securities at fair value on a recurring basis. We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs. The three-tiers of the fair value hierarchy are as follows: Level I—Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date,  Level II—Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities, and Level III—Inputs that are generally unobservable and typically reflect management's estimate of assumptions that market participants would use in pricing the asset or liability. We don't have any level III financial assets measured at fair value on a recurring basis. The following tables summarize the fair value of these financial assets by significant investment category and their levels within the fair value hierarchy (in millions):

[0001596532-26-000078:notes:13]
|  |  | March 31, 2026 |  | December 31, 2025 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 973.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 973.2 |  |  | $ | 1,174.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,174.8 |  |
| Commercial paper |  | — |  |  | 63.7 |  |  | — |  |  | 63.7 |  |  | — |  |  | 29.8 |  |  | — |  |  | 29.8 |  |
| Corporate bonds |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 6.6 |  |  | — |  |  | 6.6 |  |
| U.S. government notes |  | 48.4 |  |  | — |  |  | — |  |  | 48.4 |  |  | 124.9 |  |  | — |  |  | — |  |  | 124.9 |  |
| Agency securities |  | — |  |  | 20.0 |  |  | — |  |  | 20.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | 1,021.6 |  |  | 83.7 |  |  | — |  |  | 1,105.3 |  |  | 1,299.7 |  |  | 36.4 |  |  | — |  |  | 1,336.1 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 311.1 |  |  | — |  |  | 311.1 |  |  | — |  |  | 83.0 |  |  | — |  |  | 83.0 |  |
| U.S. government notes |  | 2,728.1 |  |  | — |  |  | — |  |  | 2,728.1 |  |  | 2,854.3 |  |  | — |  |  | — |  |  | 2,854.3 |  |
| Corporate bonds |  | — |  |  | 5,059.7 |  |  | — |  |  | 5,059.7 |  |  | — |  |  | 4,329.7 |  |  | — |  |  | 4,329.7 |  |
| Municipal bonds |  | — |  |  | 14.5 |  |  | — |  |  | 14.5 |  |  | — |  |  | 14.5 |  |  | — |  |  | 14.5 |  |
| Agency securities |  | — |  |  | 1,450.3 |  |  | — |  |  | 1,450.3 |  |  | — |  |  | 1,497.6 |  |  | — |  |  | 1,497.6 |  |
|  |  | 2,728.1 |  |  | 6,835.6 |  |  | — |  |  | 9,563.7 |  |  | 2,854.3 |  |  | 5,924.8 |  |  | — |  |  | 8,779.1 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted cash |  | 1.4 |  |  | — |  |  | — |  |  | 1.4 |  |  | 1.4 |  |  | — |  |  | — |  |  | 1.4 |  |
| Total Financial Assets |  | $ | 3,751.1 |  |  | $ | 6,919.3 |  |  | $ | — |  |  | $ | 10,670.4 |  |  | $ | 4,155.4 |  |  | $ | 5,961.2 |  |  | $ | — |  |  | $ | 10,116.6 |  |

[0001596532-26-000078:notes:14]
During the three months ended March 31, 2026, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-26-000078:notes:15]
[same as prior period, unchanged from 0001596532-25-000286:notes:18]

[0001596532-26-000078:notes:16]
|  |  | March 31, 2026 |  | December 31, 2025 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 374.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 374.8 |  |  | $ | 112.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 112.8 |  |
| U.S. government |  | 2,777.5 |  |  | 2.8 |  |  | (3.8) |  |  | 2,776.5 |  |  | 2,970.4 |  |  | 8.8 |  |  | — |  |  | 2,979.2 |  |
| Corporate bonds |  | 5,066.3 |  |  | 4.7 |  |  | (11.3) |  |  | 5,059.7 |  |  | 4,321.2 |  |  | 16.0 |  |  | (0.9) |  |  | 4,336.3 |  |
| Municipal bonds |  | 14.5 |  |  | — |  |  | — |  |  | 14.5 |  |  | 14.5 |  |  | — |  |  | — |  |  | 14.5 |  |
| Agency securities |  | 1,474.1 |  |  | 0.6 |  |  | (4.4) |  |  | 1,470.3 |  |  | 1,495.5 |  |  | 2.7 |  |  | (0.6) |  |  | 1,497.6 |  |
| Total |  | $ | 9,707.2 |  |  | $ | 8.1 |  |  | $ | (19.5) |  |  | $ | 9,695.8 |  |  | $ | 8,914.4 |  |  | $ | 27.5 |  |  | $ | (1.5) |  |  | $ | 8,940.4 |  |

[0001596532-26-000078:notes:17]
For debt securities in unrealized loss positions, it is not likely that we will be required to sell such securities before recovery of their amortized cost basis nor do we have the intent to sell such securities before maturity. We invest in debt securities that have maximum maturities of three years that are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these debt securities, the more susceptible they are to changes in market interest rates and bond yields. Given the relatively short-term and conservative nature of our portfolio, our debt securities are generally not subject to credit risk; therefore, we did not recognize any credit losses or non-credit-related impairments related to such securities for the three months ended March 31, 2026. All unrealized gains or losses were recognized in other comprehensive income (loss). Realized gains or losses were immaterial for the three months ended March 31, 2026.

[0001596532-26-000078:notes:18]
[same as prior period, unchanged from 0001596532-25-000286:notes:21]

[0001596532-26-000078:notes:19]
|  |  | March 31, 2026 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| Commercial paper |  | $ | 10.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 10.0 |  |  | $ | — |  |
| U.S. government notes |  | 1,560.6 |  |  | (3.8) |  |  | 10.0 |  |  | — |  |  | 1,570.6 |  |  | (3.8) |  |
| Corporate bonds |  | 2,925.3 |  |  | (11.3) |  |  | 6.0 |  |  | — |  |  | 2,931.3 |  |  | (11.3) |  |
| Municipal bonds |  | 11.4 |  |  | — |  |  | — |  |  | — |  |  | 11.4 |  |  | — |  |
| Agency securities |  | 1,053.0 |  |  | (4.4) |  |  | — |  |  | — |  |  | 1,053.0 |  |  | (4.4) |  |
| Total |  | $ | 5,560.3 |  |  | $ | (19.5) |  |  | $ | 16.0 |  |  | $ | — |  |  | $ | 5,576.3 |  |  | $ | (19.5) |  |

[0001596532-26-000078:notes:20]
As of March 31, 2026, we had no marketable debt securities with contractual maturities that exceeded three years. The fair values of marketable debt securities, by remaining contractual maturities, are as follows (in millions):

[0001596532-26-000078:notes:21]
|  |  | March 31, 2026 |
|  |  | Fair Value |
| Due in 1 year or less |  | $ | 3,501.6 |  |
| Due in 1 to 3 years |  | 6,062.1 |  |
| Total debt securities |  | $ | 9,563.7 |  |

[0001596532-26-000078:notes:22]
The weighted-average remaining duration of our marketable debt securities is approximately 1.4 years as of March 31, 2026. As we view these marketable debt securities as available to support current operations, we classify marketable debt securities with maturities beyond 12 months as current assets under the caption "Marketable securities" on the condensed consolidated balance sheets.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-26-000078:notes:23]
[same as prior period, unchanged from 0001596532-25-000286:notes:26]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-26-000078:notes:24]
[same as prior period, unchanged from 0001596532-25-000286:notes:27]

[0001596532-26-000078:notes:25]
[same as prior period, unchanged from 0001596532-25-000286:notes:28]

[0001596532-26-000078:notes:26]
|  |  | March 31, 2026 |  | December 31, 2025 |
| Raw materials |  | $ | 811.1 |  |  | $ | 611.2 |  |
| Finished goods(1) |  | 1,568.9 |  |  | 1,635.9 |  |
| Total inventories |  | $ | 2,380.0 |  |  | $ | 2,247.1 |  |

[0001596532-26-000078:notes:27]
(1) The balance includes evaluation inventory totaling $525.7 million and $403.7 million as of March 31, 2026 and December 31, 2025, respectively.

[0001596532-26-000078:notes:28]
Prepaid Expenses and Other Current Assets

[0001596532-26-000078:notes:29]
Prepaid expenses and other current assets consist of the following (in millions):

[0001596532-26-000078:notes:30]
|  |  | March 31, 2026 |  | December 31, 2025 |
| Deferred cost of goods sold(1) |  | $ | 1,546.5 |  |  | $ | 1,197.0 |  |
| Other prepaid expenses and deposits |  | 353.2 |  |  | 313.0 |  |
| Total prepaid expenses and other current assets |  | $ | 1,899.7 |  |  | $ | 1,510.0 |  |

[0001596532-26-000078:notes:31]
(1) The increase in the quarter ended March 31, 2026 was driven by a corresponding increase in deferred product revenue.

[0001596532-26-000078:notes:32]
[same as prior period, unchanged from 0001596532-25-000286:notes:31]

[0001596532-26-000078:notes:33]
[same as prior period, unchanged from 0001596532-25-000286:notes:32]

[0001596532-26-000078:notes:34]
|  |  | March 31, 2026 |  | December 31, 2025 |
| Land |  | $ | 47.3 |  |  | $ | 47.3 |  |
| Equipment and machinery |  | 199.4 |  |  | 188.3 |  |
| Computer hardware and software |  | 66.3 |  |  | 66.2 |  |
| Leasehold improvements |  | 38.2 |  |  | 38.4 |  |
| Furniture and fixtures |  | 3.7 |  |  | 3.7 |  |
| Construction-in-process |  | 151.8 |  |  | 107.9 |  |
| Property and equipment, gross |  | 506.7 |  |  | 451.8 |  |
| Less: accumulated depreciation |  | (256.4) |  |  | (248.7) |  |
| Property and equipment, net |  | $ | 250.3 |  |  | $ | 203.1 |  |

[0001596532-26-000078:notes:35]
[same as prior period, unchanged from 0001596532-25-000286:notes:35]

[0001596532-26-000078:notes:36]
[same as prior period, unchanged from 0001596532-25-000286:notes:36]

[0001596532-26-000078:notes:37]
[same as prior period, unchanged from 0001596532-25-000286:notes:37]

[0001596532-26-000078:notes:38]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2026 |  | 2025 |  |  |  |  |
| Contract liabilities, beginning balance |  | $ | 250.1 |  |  | $ | 160.8 |  |  |  |  |  |
| Less: Revenue recognized from beginning balance |  | (17.6) |  |  | (12.9) |  |  |  |  |  |
| Add: Contract liabilities recognized, net |  | 41.2 |  |  | 12.6 |  |  |  |  |  |
| Contract liabilities, ending balance |  | $ | 273.7 |  |  | $ | 160.5 |  |  |  |  |  |

[0001596532-26-000078:notes:39]
As of March 31, 2026 and December 31, 2025, $131.0 million and $114.0 million of our contract liabilities, respectively, were included in "Other current liabilities" with the remaining balances included in "Other long-term liabilities" on the condensed consolidated balance sheets.

[0001596532-26-000078:notes:40]
[same as prior period, unchanged from 0001596532-25-000286:notes:40]

[0001596532-26-000078:notes:41]
[same as prior period, unchanged from 0001596532-25-000286:notes:41]

[0001596532-26-000078:notes:42]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2026 |  | 2025 |  |  |  |  |
| Deferred revenue, beginning balance |  | $ | 5,372.4 |  |  | $ | 2,791.4 |  |  |  |  |  |
| Less: Revenue recognized from beginning balance |  | (1,264.4) |  |  | (418.3) |  |  |  |  |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 2,090.7 |  |  | 715.7 |  |  |  |  |  |
| Deferred revenue, ending balance |  | $ | 6,198.7 |  |  | $ | 3,088.8 |  |  |  |  |  |

[0001596532-26-000078:notes:43]
[same as prior period, unchanged from 0001596532-25-000286:notes:43]

[0001596532-26-000078:notes:44]
Other performance obligations totaling $1.2 billion as of March 31, 2026 include unbilled multi-year PCS and service contract amounts of $264.6 million, and $968.4 million of binding contractual agreements with certain customers that are primarily related to future product shipments.

[0001596532-26-000078:notes:45]
[same as prior period, unchanged from 0001596532-25-000286:notes:45]

[0001596532-26-000078:notes:46]
Total revenue from our contract liabilities, deferred revenue and other performance obligations that is expected to be recognized in future periods amounts to $7.7 billion as of March 31, 2026. Approximately 91% of this future revenue is expected to be recognized over the next two years and the remaining 9% is expected to be recognized during the third to the fifth year.

[0001596532-26-000078:notes:47]
[same as prior period, unchanged from 0001596532-25-000286:notes:47]

[0001596532-26-000078:notes:48]
[same as prior period, unchanged from 0001596532-25-000286:notes:48]

[0001596532-26-000078:notes:49]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2026 |  | 2025 |  |  |  |  |
| Interest income |  | $ | 109.2 |  |  | $ | 90.2 |  |  |  |  |  |
| Other income (expense), net |  | 4.4 |  |  | 6.0 |  |  |  |  |  |
| Total |  | $ | 113.6 |  |  | $ | 96.2 |  |  |  |  |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-26-000078:notes:50]
[same as prior period, unchanged from 0001596532-25-000286:notes:50]

[0001596532-26-000078:notes:51]
[same as prior period, unchanged from 0001596532-25-000286:notes:51]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-26-000078:notes:52]
Acquisition
On June 30, 2025, we completed the acquisition of the VeloCloud business ("VeloCloud") from Broadcom for total cash consideration of $300.0 million. VeloCloud's secure, AI-optimized cloud WAN portfolio provides seamless connectivity to customer sites of any type, complementing Arista's leading data center and campus wired/wireless portfolio. The preliminary purchase price allocation based on the estimated fair values of the assets acquired and liabilities assumed as of the acquisition date, included $268.4 million of intangible assets, $148.0 million of goodwill and $116.4 million of net tangible liabilities assumed as of June 30, 2025. A portion of the goodwill is deductible for tax purposes. There was no change in the carrying value of goodwill for the three months ended March 31, 2026.

[0001596532-26-000078:notes:53]
[same as prior period, unchanged from 0001596532-25-000286:notes:53]

[0001596532-26-000078:notes:54]
[same as prior period, unchanged from 0001596532-25-000286:notes:54]

[0001596532-26-000078:notes:55]
|  |  | March 31, 2026 |  | December 31, 2025 |
|  |  | Weighted-Average Remaining Useful Lives (in years) |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  |
| Developed technology |  | 3.8 |  | $ | 241.1 |  |  | $ | (145.9) |  |  | $ | 95.2 |  |  | $ | 241.1 |  |  | $ | (139.0) |  |  | $ | 102.1 |  |  |
| Customer relationships |  | 5.9 |  | 224.3 |  |  | (56.6) |  |  | 167.7 |  |  | 224.3 |  |  | (48.9) |  |  | 175.4 |  |  |
| Trade name |  | 4.3 |  | 24.9 |  |  | (14.3) |  |  | 10.6 |  |  | 24.9 |  |  | (13.6) |  |  | 11.3 |  |  |
| Total |  | 5.1 |  | $ | 490.3 |  |  | $ | (216.8) |  |  | $ | 273.5 |  |  | $ | 490.3 |  |  | $ | (201.5) |  |  | $ | 288.8 |  |  |

[0001596532-26-000078:notes:56]
[same as prior period, unchanged from 0001596532-25-000286:notes:56]

[0001596532-26-000078:notes:57]
|  |  | Future Amortization Expense |
| Remainder of 2026 |  | $ | 46.0 |  |
| 2027 |  | 57.4 |  |
| 2028 |  | 54.0 |  |
| 2029 |  | 23.6 |  |
| 2030 and thereafter |  | 92.5 |  |
| Total |  | $ | 273.5 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-26-000078:notes:58]
Commitments and Contingencies
Purchase Commitments

[0001596532-26-000078:notes:59]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders for finished goods and strategic components, including integrated circuits consigned to contract manufacturers, consists of non-cancellable commitments. Our purchase obligations also encompass software and technology licenses, property and equipment, and other corporate goods and services. As of March 31, 2026, we had non-cancellable purchase commitments not recorded on our balance sheet of $8.9 billion, of which $7.6 billion have expected receipt dates within 12 months, and $1.3 billion have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-26-000078:notes:60]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $95.5 million and $53.0 million as of March 31, 2026 and December 31, 2025, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

[0001596532-26-000078:notes:61]
Property Project

[0001596532-26-000078:notes:62]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office, lab and data center space. As of March 31, 2026, the estimated remaining capital expenditures related to this project are expected to be approximately $130.0 million to $150.0 million through the end of fiscal 2026 when we expect construction to be completed.

[0001596532-26-000078:notes:63]
Guarantees

[0001596532-26-000078:notes:64]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-26-000078:notes:65]
Legal Proceedings

[0001596532-26-000078:notes:66]
In the ordinary course of business, we are a party to various claims, litigation and other legal proceedings, including matters relating to intellectual property and patent disputes.

[0001596532-26-000078:notes:67]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2026, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-26-000078:notes:68]
[same as prior period, unchanged from 0001596532-25-000286:notes:68]

[0001596532-26-000078:notes:69]
In May 2025 our board of directors authorized a $1.5 billion stock repurchase program (the “Repurchase Program”). This authorization allows us to repurchase shares of our common stock that will be funded from working capital. Repurchases may be made at management's discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the "Exchange Act"), or a combination of the foregoing. The Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the Company at any time without prior notice. We did not repurchase any shares during the three months ended March 31, 2026. As of March 31, 2026, the remaining authorized amount for repurchases under the Repurchase Program was $817.9 million.

[0001596532-26-000078:notes:70]
[same as prior period, unchanged from 0001596532-25-000286:notes:74]

[0001596532-26-000078:notes:71]
[same as prior period, unchanged from 0001596532-25-000286:notes:85]

[0001596532-26-000078:notes:72]
[same as prior period, unchanged from 0001596532-25-000286:notes:86]

[0001596532-26-000078:notes:73]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |
| Unvested balance—December 31, 2025 |  | 28.1 |  |  | $ | 69.81 |  |
| RSUs granted |  | 1.0 |  |  | 133.67 |  |
| RSUs vested |  | (2.4) |  |  | 56.14 |  |
| RSUs forfeited/canceled |  | (0.4) |  |  | 62.41 |  |
| Unvested balance—March 31, 2026 |  | 26.3 |  |  | $ | 73.50 |  |

[0001596532-26-000078:notes:74]
[same as prior period, unchanged from 0001596532-25-000286:notes:88]

[0001596532-26-000078:notes:75]
[same as prior period, unchanged from 0001596532-25-000286:notes:89]

[0001596532-26-000078:notes:76]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2026 |  | 2025 |  |  |  |  |
| Cost of revenue |  | $ | 7.0 |  |  | $ | 5.5 |  |  |  |  |  |
| Research and development |  | 72.2 |  |  | 57.0 |  |  |  |  |  |
| Sales and marketing |  | 29.8 |  |  | 19.9 |  |  |  |  |  |
| General and administrative |  | 11.9 |  |  | 10.6 |  |  |  |  |  |
| Total stock-based compensation |  | $ | 120.9 |  |  | $ | 93.0 |  |  |  |  |  |

[0001596532-26-000078:notes:77]
As of March 31, 2026, there were $1.5 billion of unamortized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 4.2 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-26-000078:notes:78]
Net Income Per Share
    Basic net income per share is computed using the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed using the weighted-average number of shares of common stock outstanding during the period, including potential common shares assuming the dilutive effect of outstanding stock options, restricted stock units, and the employee stock purchase plan using the treasury stock method. Potential common shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share. The following table sets forth the computation of our basic and diluted net income per share (in millions, except per share amounts):

[0001596532-26-000078:notes:79]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2026 |  | 2025 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 1,022.9 |  |  | $ | 813.8 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Basic weighted-average shares outstanding |  | 1,257.7 |  |  | 1,260.0 |  |  |  |  |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity awards |  | 16.1 |  |  | 19.2 |  |  |  |  |  |
| Diluted weighted-average shares outstanding |  | 1,273.8 |  |  | 1,279.2 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.81 |  |  | $ | 0.65 |  |  |  |  |  |
| Diluted |  | $ | 0.80 |  |  | $ | 0.64 |  |  |  |  |  |

[0001596532-26-000078:notes:80]
[same as prior period, unchanged from 0001596532-25-000286:notes:95]

[0001596532-26-000078:notes:81]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2026 |  | 2025 |  |  |  |  |
| Employee equity awards |  | 0.7 |  |  | 0.9 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-26-000078:notes:82]
[same as prior period, unchanged from 0001596532-25-000286:notes:97]

[0001596532-26-000078:notes:83]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2026 |  | 2025 |  |  |  |  |
| Income before income taxes |  | $ | 1,271.4 |  |  | $ | 955.0 |  |  |  |  |  |
| Provision for income taxes |  | 248.5 |  |  | 141.2 |  |  |  |  |  |
| Effective tax rate |  | 19.5 | % |  | 14.8 | % |  |  |  |  |

[0001596532-26-000078:notes:84]
The increase in the effective tax rate in the three months ended March 31, 2026, as compared to the same period in 2025, was primarily due to a decrease in tax benefits attributable to equity-based compensation.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-26-000078:notes:85]
Segment and Geographical Information 
We operate as one reportable segment. The accounting policies of the reportable segment are the same as those described in the summary of significant accounting policies. Our chief operating decision maker ("CODM") is our Chief Executive Officer and Chairperson of the Board, who reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance. The financial information reviewed by the CODM reflects quarterly and year-to-date operating results, with a primary focus on revenue, gross margin, operating margin and net income as reported on the consolidated statements of income. Consolidated financial information is used by the CODM to evaluate performance and make decisions regarding resource allocation and other strategic initiatives. This consolidated financial information is also what is used to establish and approve operating budgets and forecasts. The measure of segment assets is reported on the consolidated balance sheets in total. There was no change for each of the periods presented in the measurement methods used to determine reported segment profit and loss.

[0001596532-26-000078:notes:86]
The CODM reviews cost of revenue and operating expenses, which are presented as separate line items on the Company’s consolidated statements of income. Other segment items that are included in the calculation of the Company’s net income include other income (expense), net, which is further described in Note 3. Financial Statements Details, and income taxes, which is further described in Note 8. Income Taxes. Other segment disclosures such as depreciation and amortization and stock-based compensation are disclosed in the Consolidated Statements of Cash Flows.

[0001596532-26-000078:notes:87]
[same as prior period, unchanged from 0001596532-25-000286:notes:102]

[0001596532-26-000078:notes:88]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2026 |  | 2025 |  |  |  |  |
| Americas(1) |  | $ | 2,290.1 |  |  | $ | 1,598.5 |  |  |  |  |  |
| Europe, Middle East and Africa |  | 235.0 |  |  | 174.6 |  |  |  |  |  |
| Asia-Pacific |  | 183.9 |  |  | 231.7 |  |  |  |  |  |
| Total revenue |  | $ | 2,709.0 |  |  | $ | 2,004.8 |  |  |  |  |  |

[0001596532-26-000078:notes:89]
(1) Includes $2,272.1 million and $1,581.5 million revenue generated from the U.S. for the three months ended March 31, 2026 and March 31, 2025, respectively.

[0001596532-26-000078:notes:90]
Long-lived assets, net, excluding intercompany receivables, investments in subsidiaries, investments in privately-held companies and deferred tax assets, by location are summarized as follows (in millions):

[0001596532-26-000078:notes:91]
|  |  | March 31, 2026 |  | December 31, 2025 |
| United States |  | $ | 228.8 |  |  | $ | 184.8 |  |
| International |  | 21.5 |  |  | 18.3 |  |
| Total |  | $ | 250.3 |  |  | $ | 203.1 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001596532-26-000078:notes:92]
On March 13, 2026, Kenneth Duda, our President, Chief Technology Officer and Director, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 520,000 shares of our common stock held in various trusts for the benefit of Mr. Duda’s family, for which Mr. Duda is the beneficial owner and which is intended to be treated as a single plan. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until June 21, 2027, or earlier if all transactions under the trading arrangement are completed.
