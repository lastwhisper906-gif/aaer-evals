# ANET MD&A — 0001596532-26-000078


## mdna

[0001596532-26-000078:mdna:1]
[same as prior period, unchanged from 0001596532-25-000286:mdna:1]

[0001596532-26-000078:mdna:2]
[same as prior period, unchanged from 0001596532-25-000286:mdna:2]

[0001596532-26-000078:mdna:3]
In a world where data is increasingly a precious commodity and competitive differentiator, Arista was founded to enable our customers to access all their centers of data in the quickest, most reliable, and secure manner. Over the last two decades, we have established ourselves as an industry leader in data-driven, client-to-cloud networking-as-a-service. Our “Centers of Data” strategy is a fundamental pivot from legacy, siloed networking to a unified, data-driven approach in which the network is a service that interconnects four primary domains: AI Centers, Data Centers, Campus Centers, and WAN Centers. Anchored by Arista’s state-oriented Extensible Operating System (EOS) and Network Data Lake (NetDL), our network-as-a-service platform delivers a seamless, consolidated networking experience regardless of data location.

[0001596532-26-000078:mdna:4]
Our solutions are differentiated because they:

[0001596532-26-000078:mdna:5]
•offer uncompromising reliability derived from the foundation of robust quality assurance capabilities, and a suite of automated diagnostics;

[0001596532-26-000078:mdna:6]
•are based on advanced open and standards-based technology that avoids what is often expensive vendor lock-in, and

[0001596532-26-000078:mdna:7]
•provide consistent real-time telemetry and intelligent automation to decrease the manual workload on the operator.

[0001596532-26-000078:mdna:8]
Our strategic differentiation enables us to deliver a comprehensive suite of products and services to a global scale. Through our network-as-a-service approach, we empower customers to seamlessly leverage their data across our entire platform. By combining world-class engineering with continuous innovation, we provide the predictable performance and simplicity needed to turn data into a sustainable competitive advantage in today’s AI-driven world.

[0001596532-26-000078:mdna:9]
The market for cloud networking is characterized by rapid technological evolution, intensifying competition, and the expansion of generative and agentic AI. To sustain our success and adapt to the market, we must increase sales in cloud, AI and enterprise data center Ethernet switching/routing markets, and campus workspace markets by leveraging our ability to rapidly develop new features and software applications. Our growth strategy relies on maintaining our agility and increasing our investment in research and development to deliver market-leading features to enhance the functionality of our existing cloud networking platform, expand our product offerings and build upon our technology leadership. In addition, we must continue to expand our global sales force and deepen our channel partnerships to reach new customers more effectively and increase sales to existing customers.

[0001596532-26-000078:mdna:10]
Historically, a limited number of customers have accounted for a significant portion of our revenue. Two of our customers accounted for more than 10% of our total revenue in each of the last three years. Sales to one end customer represented 16%, 15%, and 21% of our total revenue, and sales to the other end customer represented 26%, 20%, and 18% of our total revenue for the years ended December 31, 2025, 2024, and 2023, respectively. We have experienced unpredictability in the timing of orders from our high-volume customers, primarily due to the inherent complexity of large-scale orders and fluctuations in their specific demand. This includes reductions or shifts in their capital expenditure budgets, as well as the impact of their internal cost-reduction and efficiency initiatives. Furthermore, variability in customer concentration is driven by the timing of new product deployments, customer spending cycles, and the extensive periods required for evaluation, testing, and qualification. We expect this variability in concentration and sales timing to continue on both a quarterly and annual basis. Additionally, the pricing discounts typically required for these large-scale orders adversely impact our gross margins.

[0001596532-26-000078:mdna:11]
We believe an increased focus on the deployment of AI-enabled solutions by our large customers has accelerated the need for advanced technology offerings, including some offerings from potential new market entrants. This prioritization and acceleration of AI related infrastructure investment has, at times, come in conjunction with a reduction or changes in the mix of previously planned purchases and various cost reduction measures by these customers, including optimization and increased efficiency in non-AI related capital expenditures. In addition, although the focus on deployment of AI-enabled solutions has driven increased demand for networking, the long-term trajectory is unknown. As such, demand estimates for our new products are difficult to forecast and can create volatility in our revenue. We remain in a period of new product introductions and expanded use cases, particularly in the AI Ethernet market. This has resulted in increased customer trials and contracts with acceptance periods, and an increase in the volatility and magnitude of our evaluation inventory and product deferred revenue balances, which in turn may create variability in our revenue results on a quarterly and annual basis. In addition, if we are not able to satisfy the requirements under customer trials or contracts with acceptance periods, we may be required to accept product returns from our customers, which would prevent us from recognizing revenue on such transactions and may result in the write-down of inventory.

[0001596532-26-000078:mdna:12]
[same as prior period, unchanged from 0001596532-25-000286:mdna:11]

[0001596532-26-000078:mdna:13]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including the effects of, among other things, inflation, monetary policy shifts, recession risks, supply constraints and potential supply chain disruptions, changes in government administration policy positions, and geopolitical pressures, including the war in Iran and international trade measures and tariff uncertainty.

[0001596532-26-000078:mdna:14]
Management is actively collaborating with contract manufacturers and suppliers to optimize our supply chain in response to component constraints, evolving international trade policies, and tariff uncertainties. Ongoing supply constraints and future trade measures have and could continue to adversely affect our supply chain stability and increase our product costs. We are maintaining a disciplined fulfillment cadence to ensure reliable inventory deployment. As we build capacity to meet escalating demand, we are shipping products against previously committed demand/deployment plans and accelerating some shipments as needed. Simultaneously, we are balancing customers’ requirements and lead times against the availability and lead times of key components and products from our suppliers and contract manufacturers. Given the timing and prioritization of customer orders and shipment patterns, as well as the timing and outcome of customer trials and contracts with acceptance periods, near term revenue trends may not be reflective of current demand levels and may benefit from demand/deployment plans that have been previously committed.

[0001596532-26-000078:mdna:15]
In addition, we expect inventory and purchase commitments to remain elevated and subject to volatility as a result of new product introductions, shifts in customer demand, and fluctuations in supplier lead times. This volatility creates a heightened risk of excess or obsolete inventory and supplier liability charges. Simultaneously, supply chain inflation and material scarcity, such as the tightening of supply conditions in the memory and silicon markets, have continued to put pressure on our gross margin. If tariff or non-tariff measures escalate, and/or if supply conditions worsen and we are unable to pass on

[0001596532-26-000078:mdna:16]
these costs to customers, our gross margins could be further impacted. Additionally, broader macroeconomic instability could negatively affect demand. Given these unpredictable factors, current financial conditions discussed herein may not be indicative of future operating results and trends.

[0001596532-26-000078:mdna:17]
[same as prior period, unchanged from 0001596532-25-000286:mdna:16]

[0001596532-26-000078:mdna:18]
Three Months Ended March 31, 2026 Compared to Three Months Ended March 31, 2025

[0001596532-26-000078:mdna:19]
[same as prior period, unchanged from 0001596532-25-000286:mdna:18]

[0001596532-26-000078:mdna:20]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2026 |  | 2025 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,311.3 |  |  | $ | 1,692.5 |  |  | $ | 618.8 |  |  | 36.6 | % |  |  |  |  |  |  |  |  |
| Service |  | 397.7 |  |  | 312.3 |  |  | 85.4 |  |  | 27.3 |  |  |  |  |  |  |  |  |  |
| Total revenue |  | 2,709.0 |  |  | 2,004.8 |  |  | 704.2 |  |  | 35.1 |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 961.9 |  |  | 672.7 |  |  | 289.2 |  |  | 43.0 |  |  |  |  |  |  |  |  |  |
| Service |  | 70.3 |  |  | 56.0 |  |  | 14.3 |  |  | 25.5 |  |  |  |  |  |  |  |  |  |
| Total cost of revenue |  | 1,032.2 |  |  | 728.7 |  |  | 303.5 |  |  | 41.6 |  |  |  |  |  |  |  |  |  |
| Gross profit |  | $ | 1,676.8 |  |  | $ | 1,276.1 |  |  | $ | 400.7 |  |  | 31.4 | % |  |  |  |  |  |  |  |  |
| Gross margin |  | 61.9 | % |  | 63.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001596532-26-000078:mdna:21]
[same as prior period, unchanged from 0001596532-25-000286:mdna:20]

[0001596532-26-000078:mdna:22]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2026 |  | % of Total |  | 2025 |  | % of Total |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,290.1 |  |  | 84.5 | % |  | $ | 1,598.5 |  |  | 79.7 | % |  |  |  |  |  |  |  |  |
| Europe, Middle East and Africa |  | 235.0 |  |  | 8.7 |  |  | 174.6 |  |  | 8.7 |  |  |  |  |  |  |  |  |  |
| Asia-Pacific |  | 183.9 |  |  | 6.8 |  |  | 231.7 |  |  | 11.6 |  |  |  |  |  |  |  |  |  |
| Total revenue |  | $ | 2,709.0 |  |  | 100.0 | % |  | $ | 2,004.8 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |

[0001596532-26-000078:mdna:23]
[same as prior period, unchanged from 0001596532-25-000286:mdna:22]

[0001596532-26-000078:mdna:24]
Product revenue primarily consists of sales of our switching and routing products, and related network applications. Service revenue is primarily derived from sales of PCS, which are typically purchased in conjunction with our products, and subsequent renewals of those contracts. Our revenue may vary from period to period based on, among other things, customer demand, industry and customer cyclicality, the timing, size, and complexity of orders, especially with respect to our large customers, and the time it takes for customers to evaluate, test, qualify and accept our products and services.

[0001596532-26-000078:mdna:25]
Product revenue increased by $618.8 million, or 36.6% for the three months ended March 31, 2026, compared to the same period in 2025. This increase reflects healthy customer demand and higher shipments of our switching and routing platforms across our customer base. In addition, service revenue increased by $85.4 million, or 27.3% for the three months ended March 31, 2026, compared to the same period in 2025, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. Non-Americas revenue represented 15.5% of total revenue for the three months ended March 31, 2026, decreasing from 20.3% for the same period in the prior year, which was primarily influenced by changes in the geographic mix of sales to our large global customers.

[0001596532-26-000078:mdna:26]
[same as prior period, unchanged from 0001596532-25-000286:mdna:25]

[0001596532-26-000078:mdna:27]
Cost of product revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs of our manufacturing operations, including freight and tariffs, and other costs associated with manufacturing our products and managing our inventory and supply chain. Cost of service revenue primarily consists of personnel and other costs associated with our global customer support and services organizations.

[0001596532-26-000078:mdna:28]
Cost of revenue increased by $303.5 million, or 41.6% for the three months ended March 31, 2026, compared to the same period in 2025. These increases were primarily driven by a corresponding increase in product and service revenues.

[0001596532-26-000078:mdna:29]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including pricing pressure on our products and services due to competition, the mix of sales to large customers who

[0001596532-26-000078:mdna:30]
generally receive lower pricing, the mix of products sold, manufacturing-related costs, including costs associated with our manufacturing operations personnel, inflationary pressure and scarcity of materials in our supply chain, merchant silicon costs, and excess/obsolete inventory and supplier liability charges. We expect our gross margin to fluctuate over time, depending on the factors described above.

[0001596532-26-000078:mdna:31]
Gross margin decreased from 63.7% to 61.9% for the three months ended March 31, 2026, compared to the same period in 2025. The decrease was primarily driven by an increased proportion of our sales to large end customers who generally receive higher discounts.

[0001596532-26-000078:mdna:32]
[same as prior period, unchanged from 0001596532-25-000286:mdna:31]

[0001596532-26-000078:mdna:33]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. The largest component of our operating expenses is personnel costs and new product introduction costs. Personnel costs consist of wages, benefits, bonuses and, with respect to sales and marketing expenses, sales incentive compensation. Personnel costs also include stock-based compensation and travel-related expenses. New product introduction costs are primarily comprised of third-party engineering and prototype expenses.

[0001596532-26-000078:mdna:34]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2026 |  | 2025 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 343.7 |  |  | $ | 266.4 |  |  | $ | 77.3 |  |  | 29.0 | % |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 141.6 |  |  | 116.6 |  |  | 25.0 |  |  | 21.4 |  |  |  |  |  |  |  |  |  |
| General and administrative |  | 33.7 |  |  | 34.3 |  |  | (0.6) |  |  | (1.7) |  |  |  |  |  |  |  |  |  |
| Total operating expenses |  | $ | 519.0 |  |  | $ | 417.3 |  |  | $ | 101.7 |  |  | 24.4 | % |  |  |  |  |  |  |  |  |

[0001596532-26-000078:mdna:35]
[same as prior period, unchanged from 0001596532-25-000286:mdna:34]

[0001596532-26-000078:mdna:36]
Research and development expenses consist primarily of personnel costs, new product introduction costs and an allocated portion of facility and IT costs. Our research and development efforts are focused on new product development and maintaining and developing additional functionality for our existing products, including new releases and upgrades to our EOS software and applications. We expect our research and development expenses to increase in absolute dollars as we continue to invest in research and development in order to expand the capabilities of our cloud networking platform, introduce new products and features, and continue to invest in our technology.

[0001596532-26-000078:mdna:37]
Research and development expenses increased by $77.3 million, or 29.0% for the three months ended March 31, 2026, compared to the same period in 2025. The increase for the three months periods was primarily driven by a $10.9 million increase in personnel costs due to headcount growth, and a $52.1 million increase in new product introduction costs.

[0001596532-26-000078:mdna:38]
[same as prior period, unchanged from 0001596532-25-000286:mdna:37]

[0001596532-26-000078:mdna:39]
[same as prior period, unchanged from 0001596532-25-000286:mdna:38]

[0001596532-26-000078:mdna:40]
Sales and marketing expenses increased by $25.0 million, or 21.4% for the three months ended March 31, 2026, compared to the same period in 2025, which was primarily driven by increased personnel costs due to headcount growth.

[0001596532-26-000078:mdna:41]
[same as prior period, unchanged from 0001596532-25-000286:mdna:40]

[0001596532-26-000078:mdna:42]
[same as prior period, unchanged from 0001596532-25-000286:mdna:41]

[0001596532-26-000078:mdna:43]
General and administrative expenses decreased slightly by $0.6 million, or 1.7% for the three months ended March 31, 2026, compared to the same period in 2025.

[0001596532-26-000078:mdna:44]
[same as prior period, unchanged from 0001596532-25-000286:mdna:43]

[0001596532-26-000078:mdna:45]
[same as prior period, unchanged from 0001596532-25-000286:mdna:44]

[0001596532-26-000078:mdna:46]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2026 |  | 2025 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 109.2 |  |  | $ | 90.2 |  |  | $ | 19.0 |  |  | 21.1 | % |  |  |  |  |  |  |  |  |
| Other income (expense), net |  | 4.4 |  |  | 6.0 |  |  | (1.6) |  |  | (26.7) |  |  |  |  |  |  |  |  |  |
| Total other income (expense), net |  | $ | 113.6 |  |  | $ | 96.2 |  |  | $ | 17.4 |  |  | 18.1 | % |  |  |  |  |  |  |  |  |

[0001596532-26-000078:mdna:47]
The favorable movement in other income (expense), net, during the three months ended March 31, 2026, compared to the same period in 2025 was primarily driven by increased interest income of $19.0 million due to an increase in our cash and marketable securities balances.

[0001596532-26-000078:mdna:48]
[same as prior period, unchanged from 0001596532-25-000286:mdna:47]

[0001596532-26-000078:mdna:49]
[same as prior period, unchanged from 0001596532-25-000286:mdna:48]

[0001596532-26-000078:mdna:50]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2026 |  | 2025 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Income before income taxes |  | $ | 1,271.4 |  |  | $ | 955.0 |  |  | $ | 316.4 |  |  | 33.1 | % |  |  |  |  |  |  |  |  |
| Provision for income taxes |  | 248.5 |  |  | 141.2 |  |  | 107.3 |  |  | 76.0 | % |  |  |  |  |  |  |  |  |
| Effective tax rate |  | 19.5 | % |  | 14.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001596532-26-000078:mdna:51]
The increase in the effective tax rate in the three months ended March 31, 2026, as compared to the same period in 2025, was primarily due to a decrease in tax benefits attributable to equity-based compensation.

[0001596532-26-000078:mdna:52]
[same as prior period, unchanged from 0001596532-25-000286:mdna:52]

[0001596532-26-000078:mdna:53]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of March 31, 2026, our total balance of cash, cash equivalents and marketable securities was approximately $12.4 billion, of which approximately $377.0 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-26-000078:mdna:54]
Our cash, cash equivalents and marketable securities are held for general business purposes, including the funding of working capital. Our marketable securities investment portfolio is primarily invested in highly-rated securities, with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations, will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months and thereafter for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, stock repurchases, and capital expenditures, including the ongoing construction of a building for office, lab and data center space. In addition, we expect that our inventory and purchase commitments to remain elevated and subject to volatility as we ramp new product introductions. In particular, we have increased our purchase commitments to respond to the rapid deployment of AI networks, and to navigate the tightening supply within the memory and silicon markets and reduce overall lead times, which will increase our working capital requirements in the future. We regularly review our liquidity and funding sources to support our long-term growth and capital needs.

[0001596532-26-000078:mdna:55]
[same as prior period, unchanged from 0001596532-25-000286:mdna:56]

[0001596532-26-000078:mdna:56]
|  |  | Three Months Ended March 31, |
|  |  | 2026 |  | 2025 |
| Cash provided by operating activities |  | $ | 1,693.5 |  |  | $ | 641.7 |  |
| Cash used in investing activities |  | (865.3) |  |  | (765.9) |  |
| Cash used in financing activities |  | — |  |  | (793.8) |  |
| Effect of exchange rate changes |  | (2.6) |  |  | 0.7 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 825.6 |  |  | $ | (917.3) |  |

[0001596532-26-000078:mdna:57]
[same as prior period, unchanged from 0001596532-25-000286:mdna:58]

[0001596532-26-000078:mdna:58]
During the three months ended March 31, 2026, cash provided by operating activities was $1.7 billion, consisting of net income of $1.0 billion, a net decrease of $634.7 million in working capital requirements, and non-cash adjustments to net income of $35.9 million. The decrease in working capital requirements primarily consisted of an increase in deferred revenue of $826.2 million primarily resulting from an increase in customer PCS contracts and an increase in product deferred revenue related to customer contracts with acceptance terms, and a $352.9 million increase in income tax payables related to timing of payments. These cash inflows were partially offset by a $298.7 million increase in other assets driven by increased deferred cost of sales associated with higher product revenue deferrals, and a $133.0 million increase in inventory. The non-cash adjustments to net income were driven by stock-based compensation of $120.9 million, and offset by a $104.9 million increase in deferred taxes primarily due to the increase in deferred revenue.

[0001596532-26-000078:mdna:59]
During the three months ended March 31, 2025, cash provided by operating activities was $641.7 million, consisting of net income of $813.8 million, offset by a net increase of $159.7 million in working capital requirements. The increase in working capital requirements primarily consisted of an increase in accounts receivable of $295.4 million due to increased product and service billings, a $173.3 million decrease in other liabilities primarily due to timing of inventory-related receipts and payments, a $122.7 million increase in inventory and $113.7 million increase in other assets driven by increased deferred cost of sales associated with higher product revenue deferrals. These cash outflows were partly offset by a $241.3 million increase in income tax payables related to timing of payments, and an increase in deferred revenue of $297.4 million primarily resulting from an increase in customer PCS contracts and an increase in product deferred revenue related to customer contracts with acceptance terms.

[0001596532-26-000078:mdna:60]
[same as prior period, unchanged from 0001596532-25-000286:mdna:61]

[0001596532-26-000078:mdna:61]
During the three months ended March 31, 2026, cash used in investing activities was $0.9 billion, consisting of  purchases of marketable securities of $1.9 billion. These amounts were partially offset by proceeds from maturities and sales of marketable securities of $1.1 billion.

[0001596532-26-000078:mdna:62]
During the three months ended March 31, 2025, cash used in investing activities was $765.9 million, consisting of purchases of marketable securities of $1,545.5 million. These amounts were partially offset by proceeds from maturities and sales of marketable securities of $808.0 million.

[0001596532-26-000078:mdna:63]
[same as prior period, unchanged from 0001596532-25-000286:mdna:64]

[0001596532-26-000078:mdna:64]
During the three months ended March 31, 2026, net cash used in financing activities was negligible as proceeds from the issuance of stock under equity incentive plans was wholly offset by taxes paid under equity incentive and stock repurchase plans.

[0001596532-26-000078:mdna:65]
During the three months ended March 31, 2025, cash used in financing activities was $793.8 million, consisting of payments for repurchases of our common stock from the open market of $787.1 million.

[0001596532-26-000078:mdna:66]
[same as prior period, unchanged from 0001596532-25-000286:mdna:67]

[0001596532-26-000078:mdna:67]
From time to time, we repurchase shares of our common stock pursuant to repurchase programs that are funded from working capital. In May 2025, our board of directors authorized a $1.5 billion stock repurchase program (the "Repurchase Program"). The Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the Company at any time without prior notice. We did not repurchase any shares during the three months ended March 31, 2026. As of March 31, 2026, the remaining authorized amount for repurchases under the Repurchase Program was $817.9 million. Refer to Note 6. Stockholders' Equity and Stock-Based Compensation of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-26-000078:mdna:68]
[same as prior period, unchanged from 0001596532-25-000286:mdna:69]

[0001596532-26-000078:mdna:69]
[same as prior period, unchanged from 0001596532-25-000286:mdna:70]

[0001596532-26-000078:mdna:70]
[same as prior period, unchanged from 0001596532-25-000286:mdna:71]

[0001596532-26-000078:mdna:71]
[same as prior period, unchanged from 0001596532-25-000286:mdna:72]

[0001596532-26-000078:mdna:72]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders for finished goods and strategic components, including integrated circuits consigned to contract manufacturers, consists of non-cancellable commitments. Our purchase obligations also encompass software and technology licenses, property and equipment, and other corporate goods and services. As of March 31, 2026, we had $8.9 billion of such purchase obligations, of which $7.6 billion are expected to be received within one year, and $1.3 billion are expected to be received after one year. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-26-000078:mdna:73]
[same as prior period, unchanged from 0001596532-25-000286:mdna:74]

[0001596532-26-000078:mdna:74]
In 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office, lab and data center space. As of March 31, 2026, the estimated remaining capital expenditures related to this project are expected to be approximately $130.0 million to $150.0 million through the end of fiscal 2026 when we expect construction to be completed.

[0001596532-26-000078:mdna:75]
[same as prior period, unchanged from 0001596532-25-000286:mdna:76]

[0001596532-26-000078:mdna:76]
As of March 31, 2026, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-26-000078:mdna:77]
[same as prior period, unchanged from 0001596532-25-000286:mdna:78]

[0001596532-26-000078:mdna:78]
Our management’s discussion and analysis of financial condition and results of operations are based on our unaudited condensed consolidated financial statements, which have been prepared in accordance with GAAP. The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. We believe the critical accounting estimates in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our Annual Report on Form 10-K reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as disclosed in our Annual Report on Form 10-K.

[0001596532-26-000078:mdna:79]
[same as prior period, unchanged from 0001596532-25-000286:mdna:80]

[0001596532-26-000078:mdna:80]
[same as prior period, unchanged from 0001596532-25-000286:mdna:81]
