# ANET note change history — 0001596532-25-000286 → 0001596532-26-000078


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0001596532-26-000078:note_history:1]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders for finished goods and strategic components, including integrated circuits consigned to contract manufacturers, consists of non-cancellable commitments. Our purchase obligations also encompass software and technology licenses, property and equipment, and other corporate goods and services. As of March 31, 2026, we had non-cancellable purchase commitments not recorded on our balance sheet of $8.9 billion, of which $7.6 billion have expected receipt dates within 12 months, and $1.3 billion have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.
  (was, 2025-11-05, similarity 0.7003):
[0001596532-25-000286:note_history:1]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of purchase orders to our contract manufacturers for finished products consist of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2025, we had non-cancellable purchase commitments not recorded on our balance sheet of $4.8 billion, of which $4.3 billion have expected receipt dates within 12 months, and $0.5 billion have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

- changed (2026-05-06):
[0001596532-26-000078:note_history:2]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $95.5 million and $53.0 million as of March 31, 2026 and December 31, 2025, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.
  (was, 2025-11-05, similarity 0.9779):
[0001596532-25-000286:note_history:2]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $50.1 million and $95.8 million as of September 30, 2025 and December 31, 2024, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

- changed (2026-05-06):
[0001596532-26-000078:note_history:3]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office, lab and data center space. As of March 31, 2026, the estimated remaining capital expenditures related to this project are expected to be approximately $130.0 million to $150.0 million through the end of fiscal 2026 when we expect construction to be completed.
  (was, 2025-11-05, similarity 0.982):
[0001596532-25-000286:note_history:3]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office, lab and data center space. As of September 30, 2025, the estimated remaining capital expenditures related to this project are expected to be approximately $170.0 million to $200.0 million through the end of fiscal 2026 when we expect construction to be completed.

- changed (2026-05-06):
[0001596532-26-000078:note_history:4]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2026, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.
  (was, 2025-11-05, similarity 0.9932):
[0001596532-25-000286:note_history:4]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2025, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0001596532-26-000078:note_history:5]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and our wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2026, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2025 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated. Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.
  (was, 2025-11-05, similarity 0.9825):
[0001596532-25-000286:note_history:5]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and our wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2025, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2024 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated. Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.

- changed (2026-05-06):
[0001596532-26-000078:note_history:6]
Our condensed consolidated financial statements and related financial information in this Quarterly Report on Form 10-Q should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2025.
  (was, 2025-11-05, similarity 0.9452):
[0001596532-25-000286:note_history:6]
Our condensed consolidated financial statements and related financial information in this Quarterly Report on Form 10-Q should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024, filed with the SEC on February 18, 2025.

- changed (2026-05-06):
[0001596532-26-000078:note_history:7]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, valuation of inventory and contract manufacturer/supplier liabilities, accounting for income taxes, including the recognition of deferred tax assets and liabilities, valuation allowance on deferred tax assets and reserves for uncertain tax positions, and revenue recognition and deferred revenue. We evaluate our estimates and assumptions based on historical experience and other factors and adjust these estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from these estimates.
  (was, 2025-11-05, similarity 0.8905):
[0001596532-25-000286:note_history:7]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, valuation of inventory and contract manufacturer/supplier liabilities, accounting for income taxes, including the recognition of deferred tax assets and liabilities, valuation allowance on deferred tax assets and reserves for uncertain tax positions, revenue recognition and deferred revenue, valuation of goodwill and acquisition-related intangible assets, estimate of useful lives of long-lived assets including intangible assets, and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust these estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from these estimates.

- added (2026-05-06):
[0001596532-26-000078:note_history:8]
In November 2024, the FASB issued ASU 2024-03, Disaggregation of Income Statement Expenses (Subtopic 220-40). The ASU requires the disaggregated disclosure of specific expense categories, including purchases of inventory, employee compensation, depreciation, and amortization, within relevant income statement captions, and also requires disclosure of the total amount of selling expenses along with the definition of selling expenses. The ASU is effective for annual periods beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027. Adoption of this ASU can either be applied prospectively to consolidated financial statements issued for reporting periods after the effective date of this ASU or retrospectively to any or all prior periods presented in the consolidated financial statements. Early adoption is also permitted. This ASU will result in the required additional disclosures being included in our consolidated financial statements, once adopted. We are currently evaluating the provisions of this ASU.

- added (2026-05-06):
[0001596532-26-000078:note_history:9]
On December 2025, the FASB issued ASU 2025-11, Interim Reporting (Topic 270) which is intended to streamline the guidance in ASC 270, Interim Reporting, and clarify when it applies. Under the amendments, an entity is subject to ASC 270 if it provides interim financial statements and notes in accordance with GAAP. ASU 2025-11 also addresses the form and content of such financial statements, interim disclosures requirements, and establishes a principle under which an entity must disclose events since the end of the last annual reporting period that have a material impact on the entity. ASU 2025-11 is effective for interim reporting periods within annual reporting periods beginning after December 15, 2027, and early adoption is permitted. We are currently evaluating the provisions of this ASU.

- removed (2026-05-06):
[0001596532-25-000286:note_history:10]
On November 7, 2024, the Company announced a four-for-one forward stock split ("Stock Split") of the Company’s common stock that was effected through the filing of an amendment to the Company's Amended and Restated Certificate of Incorporation ("Amendment") on December 3, 2024. The Stock Split proportionately increased the authorized shares of common stock, and all share and per share amounts presented herein have been retroactively adjusted to reflect the impact of the Stock Split.

- removed (2026-05-06):
[0001596532-25-000286:note_history:11]
In December 2023, the Financial Accounting Standards Board ("FASB") issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2024. Early adoption is permitted for annual financial statements that have not yet been issued. The amendments should be applied on a prospective basis although retrospective application is permitted. We will adopt the standard in our 2025 annual period using a prospective transition method.

- removed (2026-05-06):
[0001596532-25-000286:note_history:12]
In November 2024, the FASB issued ASU 2024-03, Disaggregation of Income Statement Expenses (Subtopic 220-40). The ASU requires the disaggregated disclosure of specific expense categories, including purchases of inventory, employee

- removed (2026-05-06):
[0001596532-25-000286:note_history:13]
compensation, depreciation, and amortization, within relevant income statement captions. This ASU also requires disclosure of the total amount of selling expenses along with the definition of selling expenses. The ASU is effective for annual periods beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027. Adoption of this ASU can either be applied prospectively to consolidated financial statements issued for reporting periods after the effective date of this ASU or retrospectively to any or all prior periods presented in the consolidated financial statements. Early adoption is also permitted. This ASU will likely result in the required additional disclosures being included in our consolidated financial statements, once adopted. We are currently evaluating the impact of future adoption on our financial statement disclosures.
In July 2025, the FASB issued ASU 2025-05 Financial Instruments - Credit Losses (Topic 326) Measurement of Credit Losses for Accounts Receivable and Contract Assets, or ASU 2025-05. The ASU provides a practical expedient that allows entities to assume that current conditions as of the balance sheet date do not change for the remaining life of the asset when estimating expected credit losses for current accounts receivable and current contract assets. The amendments of ASU 2025-05 should be applied prospectively and are effective for annual and interim periods beginning after December 15, 2025, with early adoption permitted. We do not expect the adoption of ASU 2025-05 to have a material impact on our consolidated financial statements and related disclosures.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0001596532-26-000078:note_history:14]
|  |  | March 31, 2026 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| Commercial paper |  | $ | 10.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 10.0 |  |  | $ | — |  |
| U.S. government notes |  | 1,560.6 |  |  | (3.8) |  |  | 10.0 |  |  | — |  |  | 1,570.6 |  |  | (3.8) |  |
| Corporate bonds |  | 2,925.3 |  |  | (11.3) |  |  | 6.0 |  |  | — |  |  | 2,931.3 |  |  | (11.3) |  |
| Municipal bonds |  | 11.4 |  |  | — |  |  | — |  |  | — |  |  | 11.4 |  |  | — |  |
| Agency securities |  | 1,053.0 |  |  | (4.4) |  |  | — |  |  | — |  |  | 1,053.0 |  |  | (4.4) |  |
| Total |  | $ | 5,560.3 |  |  | $ | (19.5) |  |  | $ | 16.0 |  |  | $ | — |  |  | $ | 5,576.3 |  |  | $ | (19.5) |  |
  (was, 2025-11-05, similarity 0.6657):
[0001596532-25-000286:note_history:14]
|  |  | September 30, 2025 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| Commercial paper |  | $ | 9.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 9.8 |  |  | $ | — |  |
| U.S. government notes |  | 882.7 |  |  | (0.5) |  |  | 46.6 |  |  | (0.1) |  |  | 929.3 |  |  | (0.6) |  |
| Corporate bonds |  | 833.8 |  |  | (1.6) |  |  | 19.2 |  |  | — |  |  | 853.0 |  |  | (1.6) |  |
| Agency securities |  | 415.3 |  |  | (0.6) |  |  | 11.9 |  |  | — |  |  | 427.2 |  |  | (0.6) |  |
| Total |  | $ | 2,141.6 |  |  | $ | (2.7) |  |  | $ | 77.7 |  |  | $ | (0.1) |  |  | $ | 2,219.3 |  |  | $ | (2.8) |  |
