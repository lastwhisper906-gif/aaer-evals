# ANET 8-K — 0001596532-26-000074 filed 2026-05-05

## item codes, every 8-K on or before 2026-05-06

- 2026-05-05 0001596532-26-000074 — 2.02, 9.01
- 2026-02-12 0001596532-26-000010 — 2.02, 9.01
- 2025-11-04 0001596532-25-000284 — 2.02, 9.01
- 2025-09-08 0001596532-25-000258 — 5.02, 5.03, 8.01, 9.01
- 2025-08-05 0001596532-25-000214 — 2.02, 9.01
- 2025-06-16 0001596532-25-000170 — 5.02, 9.01
- 2025-06-03 0001596532-25-000148 — 5.07
- 2025-05-06 0001596532-25-000103 — 2.02, 5.02, 8.01, 9.01
- 2025-03-17 0001596532-25-000077 — 5.02, 8.01, 9.01
- 2025-02-18 0001596532-25-000018 — 2.02, 9.01
- 2024-12-03 0001596532-24-000402 — 5.03, 9.01
- 2024-11-07 0001596532-24-000366 — 2.02, 8.01, 9.01
- 2024-07-30 0001596532-24-000277 — 2.02, 9.01
- 2024-06-10 0001596532-24-000233 — 5.07
- 2024-05-24 0001596532-24-000219 — 8.01
- 2024-05-07 0001596532-24-000171 — 2.02, 8.01, 9.01
- 2024-04-23 0001596532-24-000155 — 5.02, 9.01
- 2024-04-19 0001596532-24-000152 — 5.02, 8.01
- 2024-02-28 0001596532-24-000095 — 8.01
- 2024-02-12 0001596532-24-000041 — 2.02, 9.01
- 2023-12-20 0001596532-23-000349 — 5.03, 9.01
- 2023-12-01 0001596532-23-000324 — 5.02, 8.01, 9.01
- 2023-10-30 0001596532-23-000272 — 2.02, 9.01
- 2023-07-31 0001596532-23-000196 — 2.02, 5.02, 9.01
- 2023-06-16 0001596532-23-000168 — 5.07
- 2023-05-01 0001596532-23-000101 — 2.02, 9.01
- 2023-02-13 0001596532-23-000015 — 2.02, 9.01
- 2022-10-31 0001596532-22-000292 — 2.02, 9.01
- 2022-10-25 0001596532-22-000282 — 5.03, 9.01
- 2022-08-01 0001596532-22-000218 — 2.02, 9.01
- 2022-07-25 0001596532-22-000205 — 5.02
- 2022-06-03 0001596532-22-000179 — 5.07
- 2022-05-02 0001596532-22-000111 — 2.02, 9.01
- 2022-03-29 0001596532-22-000100 — 5.02
- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2026-05-06

- none on or before 2026-05-06

## item 2.02 — earnings release, exhibit 99.1

[0001596532-26-000074:8k_2_02:1]
EX-99.1
2
ex991q126-earningsrelease.htm
EX-99.1

[0001596532-26-000074:8k_2_02:2]
Document

[0001596532-26-000074:8k_2_02:3]
Exhibit 99.1

[0001596532-26-000074:8k_2_02:4]
Arista Networks, Inc. Reports First Quarter 2026 Financial Results

[0001596532-26-000074:8k_2_02:5]
•Revenue of $2.709 billion in Q1 2026, representing 35.1% year-over-year growth, with a robust cash flow from operations of $1.69 billion

[0001596532-26-000074:8k_2_02:6]
•Announced the XPO MSA, designed to reduce networking racks by up to 75% and save up to 44% of floor space compared to traditional pluggable optics

[0001596532-26-000074:8k_2_02:7]
•Received a 2026 net promoter score of 89, indicating that 94% of customers are strongly positive about the company

[0001596532-26-000074:8k_2_02:8]
SANTA CLARA, Calif.- May 5, 2026 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus, and routing environments, today announced financial results for its first quarter ended March 31, 2026.

[0001596532-26-000074:8k_2_02:9]
First Quarter Financial Highlights

[0001596532-26-000074:8k_2_02:10]
"Arista is off to a strong start in Q1 2026, with both our results and our industry-leading net promoter score," said Jayshree Ullal, Chairperson and CEO of Arista Networks. “We are uniquely positioned to deliver the mission-critical confluence of secure client-to-campus-to-cloud and AI networking.”

[0001596532-26-000074:8k_2_02:11]
•Revenue of $2.709 billion, an increase of 8.9% compared to the fourth quarter of 2025, and an increase of 35.1% from the first quarter of 2025.

[0001596532-26-000074:8k_2_02:12]
•GAAP and non-GAAP operating margin of 42.7% and 47.8%, respectively, compared to GAAP and non-GAAP operating margin of 42.8% and 47.8% in the first quarter of 2025.

[0001596532-26-000074:8k_2_02:13]
•GAAP and non-GAAP diluted earnings per share of $0.80 and $0.87, respectively, compared to GAAP and non-GAAP diluted earnings per share of $0.64 and $0.661 in the first quarter of 2025.

[0001596532-26-000074:8k_2_02:14]
A reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release.

[0001596532-26-000074:8k_2_02:15]
Commenting on the company's financial results, Chantelle Breithaupt, Arista’s CFO, said, ”We are proud of our strong start to Fiscal 2026. While the macro and supply chain environments remain dynamic, our results are a testament to our team's disciplined execution. Delivering 35% revenue growth alongside $0.87 non-GAAP EPS demonstrates our ability to drive high-quality growth while maintaining a rigorous focus on the bottom line."

[0001596532-26-000074:8k_2_02:16]
Company Highlights

[0001596532-26-000074:8k_2_02:17]
•Arista announced XPO high-density liquid-cooled pluggable optics – Designed for next-generation AI data centers, XPO reduces networking racks by up to 75% and saves up to 44% of floor space compared to traditional pluggable optics, enabling shorter cable runs and lower-power AI scale-up interconnect technologies such as copper and RF.

[0001596532-26-000074:8k_2_02:18]
•Arista received a 2026 NPS Score of 89 – The updated net promoter score indicates that 94% of customers are strongly positive about the company. These industry-leading metrics are a testament to the company’s focus on driving customer success and satisfaction.

[0001596532-26-000074:8k_2_02:19]
•Powering AI Centers with AI Spines – Arista introduced the universal AI spine powered by the 7800 to deliver massive scale, predictable performance, and high‑speed interface support. Powerful features such as Virtual Output Queuing (VOQ) eliminate head‑of‑line blocking and large buffers absorb AI microbursts and prevent PFC storms.

[0001596532-26-000074:8k_2_02:20]
1 Prior period amounts have been updated to conform to the current period presentation. Refer to the Reconciliation of Selected GAAP to Non-GAAP Financial Measures for details

[0001596532-26-000074:8k_2_02:21]
Financial Outlook

[0001596532-26-000074:8k_2_02:22]
For the second quarter of 2026, we expect:

[0001596532-26-000074:8k_2_02:23]
•Revenue of approximately $2.8 billion;

[0001596532-26-000074:8k_2_02:24]
•Non-GAAP operating margin of 46 - 47%; and

[0001596532-26-000074:8k_2_02:25]
•Non-GAAP diluted net income per share of approximately $0.88.

[0001596532-26-000074:8k_2_02:26]
Guidance for non-GAAP financial measures excludes certain items, including stock-based compensation expense, intangible asset amortization, tax benefits on stock-based awards, the income tax effect on non-GAAP exclusions, and potential non-recurring charges or benefits. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis without unreasonable effort because these exclusions can be uncertain or difficult to predict, including stock-based compensation expense and tax benefits on stock-based awards, which is impacted by the timing of employee stock transactions, and the future fair market value of the company’s common stock. The actual amount of these exclusions will have a significant impact on the company's GAAP gross margin, operating margin, and net income per share.

[0001596532-26-000074:8k_2_02:27]
Prepared Materials and Conference Call Information

[0001596532-26-000074:8k_2_02:28]
Arista's executives will discuss the first quarter 2026 financial results on a conference call today at 1:30 PM Pacific Time. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-26-000074:8k_2_02:29]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conference call concludes, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-26-000074:8k_2_02:30]
ARISTA NETWORKS, INC.

[0001596532-26-000074:8k_2_02:31]
Condensed Consolidated Income Statements

[0001596532-26-000074:8k_2_02:32]
(Unaudited, in millions, except per share amounts)

[0001596532-26-000074:8k_2_02:33]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2026 |  | 2025 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,311.3 |  |  | $ | 1,692.5 |  |  |  |  |  |
| Service |  | 397.7 |  |  | 312.3 |  |  |  |  |  |
| Total revenue |  | 2,709.0 |  |  | 2,004.8 |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 961.9 |  |  | 672.7 |  |  |  |  |  |
| Service |  | 70.3 |  |  | 56.0 |  |  |  |  |  |
| Total cost of revenue |  | 1,032.2 |  |  | 728.7 |  |  |  |  |  |
| Gross profit |  | 1,676.8 |  |  | 1,276.1 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 343.7 |  |  | 266.4 |  |  |  |  |  |
| Sales and marketing |  | 141.6 |  |  | 116.6 |  |  |  |  |  |
| General and administrative |  | 33.7 |  |  | 34.3 |  |  |  |  |  |
| Total operating expenses |  | 519.0 |  |  | 417.3 |  |  |  |  |  |
| Income from operations |  | 1,157.8 |  |  | 858.8 |  |  |  |  |  |
| Other income (expense), net |  | 113.6 |  |  | 96.2 |  |  |  |  |  |
| Income before income taxes |  | 1,271.4 |  |  | 955.0 |  |  |  |  |  |
| Provision for income taxes |  | 248.5 |  |  | 141.2 |  |  |  |  |  |
| Net income |  | $ | 1,022.9 |  |  | $ | 813.8 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.81 |  |  | $ | 0.65 |  |  |  |  |  |
| Diluted |  | $ | 0.80 |  |  | $ | 0.64 |  |  |  |  |  |
| Weighted-average shares used in computing net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 1,257.7 |  |  | 1,260.0 |  |  |  |  |  |
| Diluted |  | 1,273.8 |  |  | 1,279.2 |  |  |  |  |  |

[0001596532-26-000074:8k_2_02:34]
3

[0001596532-26-000074:8k_2_02:35]
ARISTA NETWORKS, INC.

[0001596532-26-000074:8k_2_02:36]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-26-000074:8k_2_02:37]
(Unaudited, in millions, except percentages and per share amounts)

[0001596532-26-000074:8k_2_02:38]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2026 |  | 2025 |  |  |  |  |
| GAAP gross profit |  | $ | 1,676.8 |  |  | $ | 1,276.1 |  |  |  |  |  |
| GAAP gross margin |  | 61.9 | % |  | 63.7 | % |  |  |  |  |
| Stock-based compensation expense |  | 7.0 |  |  | 5.5 |  |  |  |  |  |
| Intangible asset amortization |  | 7.0 |  |  | 3.2 |  |  |  |  |  |
| Non-GAAP gross profit |  | $ | 1,690.8 |  |  | $ | 1,284.8 |  |  |  |  |  |
| Non-GAAP gross margin |  | 62.4 | % |  | 64.1 | % |  |  |  |  |
| GAAP income from operations |  | $ | 1,157.8 |  |  | $ | 858.8 |  |  |  |  |  |
| GAAP operating margin |  | 42.7 | % |  | 42.8 | % |  |  |  |  |
| Stock-based compensation expense |  | 120.9 |  |  | 93.0 |  |  |  |  |  |
| Intangible asset amortization |  | 15.3 |  |  | 5.6 |  |  |  |  |  |
| Non-GAAP income from operations |  | $ | 1,294.0 |  |  | $ | 957.4 |  |  |  |  |  |
| Non-GAAP operating margin |  | 47.8 | % |  | 47.8 | % |  |  |  |  |
| GAAP net income |  | $ | 1,022.9 |  |  | $ | 813.8 |  |  |  |  |  |
| Stock-based compensation expense |  | 120.9 |  |  | 93.0 |  |  |  |  |  |
| Intangible asset amortization |  | 15.3 |  |  | 5.6 |  |  |  |  |  |
| (Gains)/losses on strategic investments |  | (2.8) |  |  | (5.5) |  |  |  |  |  |
| Tax benefits on stock-based awards(1) |  | (34.4) |  |  | (48.0) |  |  |  |  |  |
| Income tax effect on non-GAAP exclusions(1) |  | (13.7) |  |  | (13.0) |  |  |  |  |  |
| Non-GAAP net income(1) |  | $ | 1,108.2 |  |  | $ | 845.9 |  |  |  |  |  |
| GAAP diluted net income per share |  | $ | 0.80 |  |  | $ | 0.64 |  |  |  |  |  |
| Non-GAAP adjustments to net income per share(1) |  | 0.07 |  |  | 0.02 |  |  |  |  |  |
| Non-GAAP diluted net income per share(1) |  | $ | 0.87 |  |  | $ | 0.66 |  |  |  |  |  |
| Weighted-average shares used in computing diluted net income per share |  | 1,273.8 |  |  | 1,279.2 |  |  |  |  |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 7.0 |  |  | $ | 5.5 |  |  |  |  |  |
| Research and development |  | 72.2 |  |  | 57.0 |  |  |  |  |  |
| Sales and marketing |  | 29.8 |  |  | 19.9 |  |  |  |  |  |
| General and administrative |  | 11.9 |  |  | 10.6 |  |  |  |  |  |
| Total |  | $ | 120.9 |  |  | $ | 93.0 |  |  |  |  |  |

[0001596532-26-000074:8k_2_02:39]
(1) Prior period amounts have been updated to conform to the current period presentation to reflect the change in methodology for calculating non-GAAP income taxes associated with stock-based awards. The retrospective application of this change resulted in an increase to non-GAAP net income of $19.7 million for the three months ended March 31, 2025. The impact of this change on non-GAAP diluted net income per share was an increase of $0.01 for the three months ended March 31, 2025. Please refer to the discussions under "Non-GAAP Financial Measures" for further information with respect to this change.

[0001596532-26-000074:8k_2_02:40]
ARISTA NETWORKS, INC.

[0001596532-26-000074:8k_2_02:41]
Condensed Consolidated Balance Sheets

[0001596532-26-000074:8k_2_02:42]
(Unaudited, in millions)

[0001596532-26-000074:8k_2_02:43]
|  |  | March 31, 2026 |  | December 31, 2025 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,789.5 |  |  | $ | 1,963.9 |  |
| Marketable securities |  | 9,563.7 |  |  | 8,779.1 |  |
| Accounts receivable |  | 1,923.8 |  |  | 1,886.9 |  |
| Inventories |  | 2,380.0 |  |  | 2,247.1 |  |
| Prepaid expenses and other current assets |  | 1,899.7 |  |  | 1,510.0 |  |
| Total current assets |  | 18,556.7 |  |  | 16,387.0 |  |
| Property and equipment, net |  | 250.3 |  |  | 203.1 |  |
| Goodwill |  | 416.1 |  |  | 416.1 |  |
| Deferred tax assets |  | 1,887.2 |  |  | 1,773.6 |  |
| Other assets |  | 546.2 |  |  | 668.8 |  |
| TOTAL ASSETS |  | $ | 21,656.5 |  |  | $ | 19,448.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 608.4 |  |  | $ | 651.7 |  |
| Accrued liabilities |  | 441.5 |  |  | 475.4 |  |
| Deferred revenue |  | 4,909.5 |  |  | 4,002.6 |  |
| Other current liabilities |  | 600.7 |  |  | 246.8 |  |
| Total current liabilities |  | 6,560.1 |  |  | 5,376.5 |  |
| Deferred revenue, non-current |  | 1,289.2 |  |  | 1,369.8 |  |
| Other long-term liabilities |  | 320.1 |  |  | 331.8 |  |
| TOTAL LIABILITIES |  | 8,169.4 |  |  | 7,078.1 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital |  | 3,036.4 |  |  | 2,911.8 |  |
| Retained earnings |  | 10,469.9 |  |  | 9,446.6 |  |
| Accumulated other comprehensive income (loss) |  | (19.3) |  |  | 12.0 |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 13,487.1 |  |  | 12,370.5 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 21,656.5 |  |  | $ | 19,448.6 |  |

[0001596532-26-000074:8k_2_02:44]
5

[0001596532-26-000074:8k_2_02:45]
ARISTA NETWORKS, INC.

[0001596532-26-000074:8k_2_02:46]
Condensed Consolidated Statements of Cash Flows

[0001596532-26-000074:8k_2_02:47]
(Unaudited, in millions)

[0001596532-26-000074:8k_2_02:48]
|  |  | Three Months Ended March 31, |
|  |  | 2026 |  | 2025 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 1,022.9 |  |  | $ | 813.8 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 23.3 |  |  | 13.8 |  |
| Stock-based compensation |  | 120.9 |  |  | 93.0 |  |
| Deferred income taxes |  | (104.9) |  |  | (107.1) |  |
| Other |  | (3.4) |  |  | (12.1) |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (36.9) |  |  | (295.4) |  |
| Inventories |  | (133.0) |  |  | (122.7) |  |
| Other assets |  | (298.7) |  |  | (113.7) |  |
| Accounts payable |  | (35.6) |  |  | 6.7 |  |
| Deferred revenue |  | 826.2 |  |  | 297.4 |  |
| Income taxes, net |  | 352.9 |  |  | 241.3 |  |
| Other liabilities |  | (40.2) |  |  | (173.3) |  |
| Net cash provided by operating activities |  | 1,693.5 |  |  | 641.7 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 739.9 |  |  | 799.2 |  |
| Proceeds from sale of marketable securities |  | 376.9 |  |  | 8.8 |  |
| Purchases of marketable securities |  | (1,932.6) |  |  | (1,545.5) |  |
| Purchases of property and equipment |  | (54.5) |  |  | (28.4) |  |
| Other |  | 5.0 |  |  | — |  |
| Net cash used in investing activities |  | (865.3) |  |  | (765.9) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 29.9 |  |  | 28.1 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (26.2) |  |  | (34.8) |  |
| Repurchases of common stock |  | — |  |  | (787.1) |  |
| Other |  | (3.7) |  |  | — |  |
| Net cash used in financing activities |  | — |  |  | (793.8) |  |
| Effect of exchange rate changes |  | (2.6) |  |  | 0.7 |  |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 825.6 |  |  | (917.3) |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 1,965.3 |  |  | 2,763.8 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 2,790.9 |  |  | $ | 1,846.5 |  |

[0001596532-26-000074:8k_2_02:49]
Forward-Looking Statements

[0001596532-26-000074:8k_2_02:50]
This press release contains “forward-looking statements” regarding our future performance, including but not limited to quotations from management, and statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin, and non-GAAP operating margin for the second quarter of 2026. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including but not limited to risks associated with: escalated or escalating U.S. tariffs and countermeasures and retaliatory actions taken by other countries; some of the key components in our products come from sole or limited sources of supply, which increases the risk of supply shortages, extended lead times or supply changes; key component supply constraints and inventory management; our reliance upon a predominant merchant silicon vendor; enhanced import/export restrictions, as well as countermeasures taken by affected countries; large purchases by a limited number of customers who represent a substantial portion of our revenue; adverse economic conditions, continuing uncertain economic conditions or reduced information technology and network infrastructure spending; volatility in our revenue and revenue growth rates; variability in our gross margins; variations in our results of operations; the rapid evolution of the networking market; failure to successfully carry out new products and service offerings and expand into adjacent markets; intense competition and industry consolidation; expansion of our international sales and operations; investments in or acquisitions of other businesses, products or technologies; industry cyclicality; fluctuations in currency exchange rates; failure to raise additional capital on terms satisfactory to us; our inability to attract new large customers or sell additional products and services to our existing customers; inability to grow sales of switching and routing platforms which generate most of our product revenue; inability to increase market awareness or acceptance of our new products and services; decreases in the sales prices of our products and services; long and unpredictable sales cycles; inability to offer high quality support and services offerings; declines in maintenance renewals and support contracts by customers; product quality problems, defects, errors or vulnerabilities in our products; failure to anticipate technological shifts; our dependence on third-party manufacturers to build our products; assertions by third parties of intellectual property rights infringement, misappropriation or other violations; failure or inability to protect or assert our intellectual property rights; cybersecurity incidents and breaches of our cybersecurity systems, or other security or privacy breaches or incidents; failure to detect cybersecurity incidents; failure to comply with government law and regulations; issues in the development and use of artificial intelligence, combined with an uncertain regulatory environment; future decisions to reduce or discontinue repurchasing our common stock pursuant to our stock repurchase programs; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission, including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof, and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-26-000074:8k_2_02:51]
Non-GAAP Financial Measures

[0001596532-26-000074:8k_2_02:52]
This press release and accompanying table contain certain non-GAAP financial measures, including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, intangible asset amortization, gains/losses on strategic investments, and the income tax effect of these non-GAAP exclusions, including the recognition of direct excess tax benefits associated with stock-based awards. Effective the fourth quarter of fiscal year 2025, the company updated its methodology for calculating the income tax effect of non-GAAP adjustments. Previously, the company’s calculation excluded all tax benefits associated with stock-based awards, consisting of both direct excess tax benefits and other discrete indirect effects. Under the updated methodology, the company continues to exclude direct excess tax benefits but

[0001596532-26-000074:8k_2_02:53]
7

[0001596532-26-000074:8k_2_02:54]
no longer excludes the discrete indirect effects of such awards. Management believes this change better aligns with industry practice and provides a more meaningful view of the company’s effective tax rate. All prior period non-GAAP results presented in this release have been recast to conform to the current period presentation.

[0001596532-26-000074:8k_2_02:55]
The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-26-000074:8k_2_02:56]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are, therefore, unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-26-000074:8k_2_02:57]
About Arista Networks

[0001596532-26-000074:8k_2_02:58]
Arista Networks is an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus, and routing environments. Its award-winning platforms deliver availability, agility, automation, analytics, and security through an advanced network operating stack. For more information, visit www.arista.com.

[0001596532-26-000074:8k_2_02:59]
ARISTA, CloudVision, and Etherlink are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners. Additional information and resources can be found at www.arista.com.

[0001596532-26-000074:8k_2_02:60]
| Investor Contacts: |  |
| Arista Networks, Inc. |
| Investor Advocacy |
| Rudolph Araujo |  |
| Rod Hall |  |
| +1 (408) 547-8080 |  |
| ir@arista.com |
