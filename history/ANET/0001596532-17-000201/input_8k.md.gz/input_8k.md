# ANET 8-K — 0001596532-17-000199 filed 2017-08-03

## item codes, every 8-K on or before 2017-08-04

- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2017-08-04

- none on or before 2017-08-04

## item 2.02 — earnings release, exhibit 99.1

[0001596532-17-000199:8k_2_02:1]
EX-99.1
2
ex991q217-earningsrelease.htm
EXHIBIT 99.1

[0001596532-17-000199:8k_2_02:2]
Exhibit

[0001596532-17-000199:8k_2_02:3]
Exhibit 99.1

[0001596532-17-000199:8k_2_02:4]
Arista Networks, Inc. Reports Second Quarter 2017 Financial Results

[0001596532-17-000199:8k_2_02:5]
New Cloud Networking Products Drive Record Profitable Growth

[0001596532-17-000199:8k_2_02:6]
SANTA CLARA, Calif.-- August 03, 2017 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large datacenter and computing environments, today announced financial results for its second quarter ended June 30, 2017.

[0001596532-17-000199:8k_2_02:7]
Second Quarter Financial Highlights

[0001596532-17-000199:8k_2_02:8]
| • | Revenue of $405.2 million, an increase of 20.8% compared to the first quarter of 2017, and an increase of 50.8% from the second quarter of 2016. |

[0001596532-17-000199:8k_2_02:9]
| • | GAAP gross margin of 64.1%, compared to GAAP gross margin of 63.9% in the first quarter of 2017 and 63.8% in the second quarter of 2016. |

[0001596532-17-000199:8k_2_02:10]
| • | Non-GAAP gross margin of 64.4%, compared to non-GAAP gross margin of 64.2% in the first quarter of 2017 and 64.1% in the second quarter of 2016. |

[0001596532-17-000199:8k_2_02:11]
| • | GAAP net income of $102.7 million, or $1.30 per diluted share, compared to GAAP net income of $38.9 million, or $0.53 per diluted share, in the second quarter of 2016. |

[0001596532-17-000199:8k_2_02:12]
| • | Non-GAAP net income of $105.5 million, or $1.34 per diluted share, compared to non-GAAP net income of $53.7 million, or $0.74 per diluted share, in the second quarter of 2016. |

[0001596532-17-000199:8k_2_02:13]
"As we complete our third anniversary of becoming a public company, I am pleased with our record results in Q2 2017,” stated Jayshree Ullal, Arista President and CEO. “Our substantial financial performance, customer success and industry recognition has accelerated the migration to mainstream cloud networking.”

[0001596532-17-000199:8k_2_02:14]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, "We are pleased with our exceptional performance in the quarter across all key financial metrics.”

[0001596532-17-000199:8k_2_02:15]
Company Highlights

[0001596532-17-000199:8k_2_02:16]
| • | Introduced the next generation R2 Series platforms based on merchant silicon that is twice the density and half the power of custom router silicon, delivering more than 150 Tbps of capacity for switching and routing powered by Arista’s software-driven EOS cloud technology. |

[0001596532-17-000199:8k_2_02:17]
| • | This is the third consecutive year Arista has been recognized as a leader and positioned the furthest for Completeness of Vision in the Leaders Quadrant of the July 2017 Gartner Magic Quadrant for Data Center Networking. |

[0001596532-17-000199:8k_2_02:18]
| • | Arista was awarded a 2017 Top Workplaces honor by the Bay Area News Group. |

[0001596532-17-000199:8k_2_02:19]
Financial Outlook

[0001596532-17-000199:8k_2_02:20]
For the third quarter of 2017, we expect:

[0001596532-17-000199:8k_2_02:21]
| • | Revenue between $405 and $420 million. |

[0001596532-17-000199:8k_2_02:22]
| • | Non-GAAP gross margin between 61% to 64%, and |

[0001596532-17-000199:8k_2_02:23]
| • | Non-GAAP operating margin of approximately 30%. |

[0001596532-17-000199:8k_2_02:24]
Guidance for non-GAAP financial measures excludes legal expenses of approximately $12 million associated with the OptumSoft and Cisco litigation, including bond costs related to the importation and sale of affected products and components during the presidential review period of the 945 investigation, stock-based compensation expense, including excess tax benefits on stock-based awards, and other non-recurring expenses. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below).

[0001596532-17-000199:8k_2_02:25]
Prepared Materials and Conference Call Information

[0001596532-17-000199:8k_2_02:26]
Arista executives will discuss second quarter 2017 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial 1-877-201-0168 in the United States or 1-647-788-4901 from outside the US. The Conference ID is 51037994.

[0001596532-17-000199:8k_2_02:27]
The financial results conference call will also be available via live webcast on our investor relations website at investors.arista.com. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s Investor Relations website.

[0001596532-17-000199:8k_2_02:28]
Forward-Looking Statements

[0001596532-17-000199:8k_2_02:29]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the third quarter of fiscal 2017, and statements regarding the benefits from the introduction of new products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements

[0001596532-17-000199:8k_2_02:30]
including risks associated with: Arista Networks’ dispute with Cisco Systems, Inc. including the ITC remedial orders which prohibit the importation of Arista products (or components thereof) into the U.S., or the sale of previously imported products,  that are covered by those remedial orders, Arista Networks’ ability to redesign its products in a manner not covered by such remedial orders and obtain appropriate governmental approvals for those redesigned products, any penalties assessed by the ITC if Arista does not obtain such governmental approvals and Arista Networks’ ability to manage our manufacturing and supply chain including the sourcing of components on commercially reasonable terms; Arista Networks’ limited operating history; Arista Networks’ rapid growth; Arista Networks’ customer concentration;  our customer’s adoption of our redesigned products and services; requests for more favorable terms and conditions from our large end customers; declines in the sales prices of our products and services; changes in customer order patterns or customer mix; increased competition in our products and service markets, including the datacenter market; dependence on the introduction and market acceptance of new product offerings and standards; rapid technological and market change; the evolution of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; Arista Networks’ dispute with OptumSoft; and general market, political, economic and business conditions. Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s most recent Quarterly Report on Form 10-Q filed with the SEC on May 8, 2017, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at http://investors.arista.com/and on the SEC’s website at http://www.sec.gov/.  All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-17-000199:8k_2_02:31]
Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner's research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001596532-17-000199:8k_2_02:32]
Non-GAAP Financial Measures

[0001596532-17-000199:8k_2_02:33]
The company reports certain non-GAAP financial measures that exclude stock-based compensation expense and related excess tax benefits, expenses associated with the OptumSoft and Cisco litigation, other non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-17-000199:8k_2_02:34]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP net income, net income per diluted share, gross margin, or operating margin. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-17-000199:8k_2_02:35]
The Company’s guidance for non-GAAP financial measures excludes stock-based compensation expense and related excess tax benefits, expenses associated with the OptumSoft and Cisco litigation, and other non-recurring items. The Company has not reconciled its non-GAAP gross margin or its non-GAAP operating margin guidance to GAAP gross margin or GAAP operating margin, because we do not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling  items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. Stock-based compensation expense is impacted by the Company’s future hiring and retention needs and the future fair market value of the Company’s common stock.  In addition, excess tax benefits on stock-based awards will fluctuate based on these same factors, as well as the timing of exercise or vesting of such awards, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense and excess tax benefits will have a significant impact on the Company’s GAAP gross margin and GAAP operating margin. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measure is not available without unreasonable effort.

[0001596532-17-000199:8k_2_02:36]
About Arista Networks

[0001596532-17-000199:8k_2_02:37]
Arista Networks was founded to pioneer and deliver software-driven cloud networking solutions for large datacenter storage and computing environments. Arista’s award-winning platforms, ranging in Ethernet speeds from 10 to 100 gigabits per second, redefine scalability, agility and resilience. Arista has shipped more than ten million cloud networking ports worldwide with CloudVision and EOS, an advanced network operating system. Committed to open standards, Arista is a founding member of the 25/50GbE consortium. Arista Networks products are available worldwide directly and through partners.

[0001596532-17-000199:8k_2_02:38]
ARISTA, EOS, CloudVision, and AlgoMatch are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-17-000199:8k_2_02:39]
Additional information and resources can be found at: http://www.arista.com

[0001596532-17-000199:8k_2_02:40]
| Media ContactAmanda JaramilloCorporate Communications(408) 547-5798amanda@arista.com |  | Investor ContactCharles YagerProduct and Investor Advocacy(408) 547-5892cyager@arista.com |

[0001596532-17-000199:8k_2_02:41]
ARISTA NETWORKS, INC.

[0001596532-17-000199:8k_2_02:42]
Condensed Consolidated Statements of Income

[0001596532-17-000199:8k_2_02:43]
(Unaudited in thousands, except per share amounts)

[0001596532-17-000199:8k_2_02:44]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 353,904 |  |  | $ | 235,616 |  |  | $ | 645,271 |  |  | $ | 448,091 |  |
| Service | 51,307 |  |  | 33,125 |  |  | 95,415 |  |  | 62,846 |  |
| Total revenue | 405,211 |  |  | 268,741 |  |  | 740,686 |  |  | 510,937 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 134,406 |  |  | 88,021 |  |  | 244,242 |  |  | 166,934 |  |
| Service | 11,028 |  |  | 9,269 |  |  | 22,457 |  |  | 17,462 |  |
| Total cost of revenue | 145,434 |  |  | 97,290 |  |  | 266,699 |  |  | 184,396 |  |
| Total gross profit | 259,777 |  |  | 171,451 |  |  | 473,987 |  |  | 326,541 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 81,194 |  |  | 69,020 |  |  | 162,804 |  |  | 131,535 |  |
| Sales and marketing | 38,630 |  |  | 31,744 |  |  | 75,657 |  |  | 59,350 |  |
| General and administrative | 23,319 |  |  | 17,529 |  |  | 45,474 |  |  | 32,763 |  |
| Total operating expenses | 143,143 |  |  | 118,293 |  |  | 283,935 |  |  | 223,648 |  |
| Income from operations | 116,634 |  |  | 53,158 |  |  | 190,052 |  |  | 102,893 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (623 | ) |  | (732 | ) |  | (1,338 | ) |  | (1,483 | ) |
| Other income (expense), net | 1,119 |  |  | 416 |  |  | 2,144 |  |  | 753 |  |
| Total other income (expense), net | 496 |  |  | (316 | ) |  | 806 |  |  | (730 | ) |
| Income before provision for income taxes | 117,130 |  |  | 52,842 |  |  | 190,858 |  |  | 102,163 |  |
| Provision for income taxes | 14,445 |  |  | 13,938 |  |  | 5,212 |  |  | 28,014 |  |
| Net income | $ | 102,685 |  |  | $ | 38,904 |  |  | $ | 185,646 |  |  | $ | 74,149 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 102,454 |  |  | $ | 38,617 |  |  | $ | 185,139 |  |  | $ | 73,535 |  |
| Diluted | $ | 102,474 |  |  | $ | 38,635 |  |  | $ | 185,182 |  |  | $ | 73,573 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 1.42 |  |  | $ | 0.57 |  |  | $ | 2.59 |  |  | $ | 1.08 |  |
| Diluted | $ | 1.30 |  |  | $ | 0.53 |  |  | $ | 2.37 |  |  | $ | 1.01 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | 71,992 |  |  | 68,275 |  |  | 71,555 |  |  | 68,006 |  |
| Diluted | 78,756 |  |  | 72,817 |  |  | 78,166 |  |  | 72,523 |  |

[0001596532-17-000199:8k_2_02:45]
ARISTA NETWORKS, INC.

[0001596532-17-000199:8k_2_02:46]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-17-000199:8k_2_02:47]
(Unaudited in thousands, except percentages and per share amounts)

[0001596532-17-000199:8k_2_02:48]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| GAAP gross profit | $ | 259,777 |  |  | $ | 171,451 |  |  | $ | 473,987 |  |  | $ | 326,541 |  |
| GAAP gross margin | 64.1 | % |  | 63.8 | % |  | 64.0 | % |  | 63.9 | % |
| Stock-based compensation expense | 1,087 |  |  | 868 |  |  | 2,111 |  |  | 1,661 |  |
| Non-GAAP gross profit | $ | 260,864 |  |  | $ | 172,319 |  |  | $ | 476,098 |  |  | $ | 328,202 |  |
| Non-GAAP gross margin | 64.4 | % |  | 64.1 | % |  | 64.3 | % |  | 64.2 | % |
| GAAP income from operations | $ | 116,634 |  |  | $ | 53,158 |  |  | $ | 190,052 |  |  | $ | 102,893 |  |
| Stock-based compensation expense | 18,400 |  |  | 14,232 |  |  | 34,839 |  |  | 27,592 |  |
| Litigation expense(1) | 11,957 |  |  | 7,594 |  |  | 23,423 |  |  | 14,599 |  |
| Non-GAAP income from operations | $ | 146,991 |  |  | $ | 74,984 |  |  | $ | 248,314 |  |  | $ | 145,084 |  |
| Non-GAAP operating margin | 36.3 | % |  | 27.9 | % |  | 33.5 | % |  | 28.4 | % |
| GAAP net income | $ | 102,685 |  |  | $ | 38,904 |  |  | $ | 185,646 |  |  | $ | 74,149 |  |
| Stock-based compensation expense | 18,400 |  |  | 14,232 |  |  | 34,839 |  |  | 27,592 |  |
| Litigation expense(1) | 11,957 |  |  | 7,594 |  |  | 23,423 |  |  | 14,599 |  |
| Excess tax benefit on share based awards | (19,079 | ) |  | — |  |  | (47,869 | ) |  | — |  |
| Income tax effect on non-GAAP exclusions | (8,493 | ) |  | (7,056 | ) |  | (18,762 | ) |  | (13,580 | ) |
| Non-GAAP net income | $ | 105,470 |  |  | $ | 53,674 |  |  | $ | 177,277 |  |  | $ | 102,760 |  |
| GAAP diluted net income per share attributable to common stockholders | $ | 1.30 |  |  | $ | 0.53 |  |  | $ | 2.37 |  |  | $ | 1.01 |  |
| Non-GAAP adjustments to net income | 0.04 |  |  | 0.21 |  |  | (0.10 | ) |  | 0.41 |  |
| Non-GAAP diluted net income per share | $ | 1.34 |  |  | $ | 0.74 |  |  | $ | 2.27 |  |  | $ | 1.42 |  |
| Weighted-average shares used in computing diluted net income per share attributable to common stockholders | 78,756 |  |  | 72,817 |  |  | 78,166 |  |  | 72,523 |  |
| Summary of Stock-Based Compensation Expense |  |  |  |  |  |  |  |
| Cost of revenue | $ | 1,087 |  |  | $ | 868 |  |  | $ | 2,111 |  |  | $ | 1,661 |  |
| Research and development | 10,342 |  |  | 7,595 |  |  | 19,929 |  |  | 15,052 |  |
| Sales and marketing | 4,080 |  |  | 3,780 |  |  | 7,536 |  |  | 7,427 |  |
| General and administrative | 2,891 |  |  | 1,989 |  |  | 5,263 |  |  | 3,452 |  |
| Total | $ | 18,400 |  |  | $ | 14,232 |  |  | $ | 34,839 |  |  | $ | 27,592 |  |

[0001596532-17-000199:8k_2_02:49]
| (1) | Amounts have been excluded from non-GAAP results as they represent non-recurring OptumSoft and Cisco litigation expenses, including bond costs related to the importation and sale of affected products and components during the presidential review period of the 945 investigation. |

[0001596532-17-000199:8k_2_02:50]
ARISTA NETWORKS, INC.

[0001596532-17-000199:8k_2_02:51]
Condensed Consolidated Balance Sheets

[0001596532-17-000199:8k_2_02:52]
(Unaudited in thousands)

[0001596532-17-000199:8k_2_02:53]
|  | June 30, 2017 |  | December 31, 2016 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 823,475 |  |  | $ | 567,923 |  |
| Marketable securities | 301,364 |  |  | 299,910 |  |
| Accounts receivable | 269,624 |  |  | 253,119 |  |
| Inventories | 363,803 |  |  | 236,490 |  |
| Prepaid expenses and other current assets | 190,923 |  |  | 168,684 |  |
| Total current assets | 1,949,189 |  |  | 1,526,126 |  |
| Property and equipment, net | 75,840 |  |  | 76,961 |  |
| Investments | 36,136 |  |  | 36,136 |  |
| Deferred tax assets | 81,469 |  |  | 70,960 |  |
| Other assets | 20,306 |  |  | 18,824 |  |
| TOTAL ASSETS | $ | 2,162,940 |  |  | $ | 1,729,007 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 80,418 |  |  | $ | 79,457 |  |
| Accrued liabilities | 84,413 |  |  | 90,951 |  |
| Deferred revenue | 426,750 |  |  | 273,350 |  |
| Other current liabilities | 19,216 |  |  | 15,795 |  |
| Total current liabilities | 610,797 |  |  | 459,553 |  |
| Income taxes payable | 19,970 |  |  | 14,498 |  |
| Lease financing obligations, non-current | 38,672 |  |  | 39,593 |  |
| Deferred revenue, non-current | 127,760 |  |  | 99,585 |  |
| Other long-term liabilities | 7,992 |  |  | 7,958 |  |
| TOTAL LIABILITIES | 805,191 |  |  | 621,187 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 7 |  |  | 7 |  |
| Additional paid-in capital | 737,436 |  |  | 674,183 |  |
| Retained earnings | 621,559 |  |  | 435,105 |  |
| Accumulated other comprehensive loss | (1,253) |  |  | (1,475 | ) |
| TOTAL STOCKHOLDERS’ EQUITY | 1,357,749 |  |  | 1,107,820 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 2,162,940 |  |  | $ | 1,729,007 |  |

[0001596532-17-000199:8k_2_02:54]
ARISTA NETWORKS, INC.

[0001596532-17-000199:8k_2_02:55]
Condensed Consolidated Statements of Cash Flows

[0001596532-17-000199:8k_2_02:56]
(Unaudited in thousands)

[0001596532-17-000199:8k_2_02:57]
|  | Six Months EndedJune 30, |
|  | 2017 |  | 2016 |
| Cash flows from operating activities |  |  |  |
| Net income | $ | 185,646 |  |  | $ | 74,149 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 10,033 |  |  | 9,662 |  |
| Stock-based compensation | 34,839 |  |  | 27,592 |  |
| Deferred income taxes | (8,515 | ) |  | (6,876 | ) |
| Amortization of investment premiums | 753 |  |  | 385 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (16,505 | ) |  | (2,396 | ) |
| Inventories | (127,313 | ) |  | (26,001 | ) |
| Prepaid expenses and other current assets | (22,239 | ) |  | (2,838 | ) |
| Other assets | (470 | ) |  | 1,866 |  |
| Accounts payable | 1,299 |  |  | 18,501 |  |
| Accrued liabilities | (5,981 | ) |  | (5,196 | ) |
| Deferred revenue | 181,575 |  |  | 33,516 |  |
| Income taxes payable | 5,380 |  |  | 17,853 |  |
| Other liabilities | 3,593 |  |  | 1,779 |  |
| Net cash provided by operating activities | 242,095 |  |  | 141,996 |  |
| Cash flows from investing activities |  |  |  |
| Proceeds from marketable securities | 112,053 |  |  | — |  |
| Purchases of marketable securities | (114,195 | ) |  | (292,938 | ) |
| Purchases of property and equipment | (9,534 | ) |  | (12,739 | ) |
| Investment in privately-held companies | — |  |  | (2,500 | ) |
| Change in restricted cash | (1,254 | ) |  | — |  |
| Net cash used in investing activities | (12,930 | ) |  | (308,177 | ) |
| Cash flows from financing activities |  |  |  |
| Principal payments of lease financing obligations | (773 | ) |  | (634 | ) |
| Proceeds from issuance of common stock under equity plans | 28,105 |  |  | 11,205 |  |
| Minimum tax withholding paid on behalf of employees for net share settlement | (1,356 | ) |  | (599 | ) |
| Net cash provided by financing activities | 25,976 |  |  | 9,972 |  |
| Effect of exchange rate changes | 411 |  |  | (59 | ) |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | 255,552 |  |  | (156,268 | ) |
| CASH AND CASH EQUIVALENTS—Beginning of period | 567,923 |  |  | 687,326 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 823,475 |  |  | $ | 531,058 |  |
