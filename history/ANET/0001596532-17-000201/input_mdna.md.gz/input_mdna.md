# ANET MD&A — 0001596532-17-000201


## mdna

[0001596532-17-000201:mdna:1]
[same as prior period, unchanged from 0001596532-17-000088:mdna:1]

[0001596532-17-000201:mdna:2]
[same as prior period, unchanged from 0001596532-17-000088:mdna:2]

[0001596532-17-000201:mdna:3]
[same as prior period, unchanged from 0001596532-17-000088:mdna:3]

[0001596532-17-000201:mdna:4]
[same as prior period, unchanged from 0001596532-17-000088:mdna:4]

[0001596532-17-000201:mdna:5]
[same as prior period, unchanged from 0001596532-17-000088:mdna:5]

[0001596532-17-000201:mdna:6]
[same as prior period, unchanged from 0001596532-17-000088:mdna:6]

[0001596532-17-000201:mdna:7]
[same as prior period, unchanged from 0001596532-17-000088:mdna:7]

[0001596532-17-000201:mdna:8]
[same as prior period, unchanged from 0001596532-17-000088:mdna:8]

[0001596532-17-000201:mdna:9]
Furthermore, to comply with the limited exclusion order and cease and desist order in the 945 Investigation as described above in Note 5, entitled Commitments and Contingencies, we have made design changes to our products for sale in the United States to address the features that were found to infringe the ’577 and ’668 patents.  We will continue to improve this with product modifications to meet ongoing customer requirements. As described in Note 5, we will need to complete these further modifications and seek qualification and acceptance by our customers. We will also need to obtain the necessary approvals described in Note 5 in order to resume importation of our redesigned products into the United States. On July 21, 2017, we submitted a Section 177 request to CBP seeking approval to import our redesigned products into the United States.

[0001596532-17-000201:mdna:10]
[same as prior period, unchanged from 0001596532-17-000088:mdna:9]

[0001596532-17-000201:mdna:11]
The following table summarizes historical results of operations for the periods presented and as a percentage of revenue for those periods.  We have derived the data for the three and six months ended June 30, 2017 and 2016 from our unaudited condensed consolidated financial statements (in thousands, except for percentages).

[0001596532-17-000201:mdna:12]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 353,904 |  |  | $ | 235,616 |  |  | $ | 645,271 |  |  | $ | 448,091 |  |
| Service | 51,307 |  |  | 33,125 |  |  | 95,415 |  |  | 62,846 |  |
| Total revenue | 405,211 |  |  | 268,741 |  |  | 740,686 |  |  | 510,937 |  |
| Cost of revenue (1): |  |  |  |  |  |  |  |
| Product | 134,406 |  |  | 88,021 |  |  | 244,242 |  |  | 166,934 |  |
| Service | 11,028 |  |  | 9,269 |  |  | 22,457 |  |  | 17,462 |  |
| Total cost of revenue | 145,434 |  |  | 97,290 |  |  | 266,699 |  |  | 184,396 |  |
| Gross profit | 259,777 |  |  | 171,451 |  |  | 473,987 |  |  | 326,541 |  |
| Operating expenses (1): |  |  |  |  |  |  |  |
| Research and development | 81,194 |  |  | 69,020 |  |  | 162,804 |  |  | 131,535 |  |
| Sales and marketing | 38,630 |  |  | 31,744 |  |  | 75,657 |  |  | 59,350 |  |
| General and administrative | 23,319 |  |  | 17,529 |  |  | 45,474 |  |  | 32,763 |  |
| Total operating expenses | 143,143 |  |  | 118,293 |  |  | 283,935 |  |  | 223,648 |  |
| Income from operations | 116,634 |  |  | 53,158 |  |  | 190,052 |  |  | 102,893 |  |
| Interest expense | (623 | ) |  | (732 | ) |  | (1,338 | ) |  | (1,483 | ) |
| Other income (expense), net | 1,119 |  |  | 416 |  |  | 2,144 |  |  | 753 |  |
| Total other income (expense), net | 496 |  |  | (316 | ) |  | 806 |  |  | (730 | ) |
| Income before provision for income taxes | 117,130 |  |  | 52,842 |  |  | 190,858 |  |  | 102,163 |  |
| Provision for income taxes | 14,445 |  |  | 13,938 |  |  | 5,212 |  |  | 28,014 |  |
| Net income | $ | 102,685 |  |  | $ | 38,904 |  |  | $ | 185,646 |  |  | $ | 74,149 |  |

[0001596532-17-000201:mdna:13]
28

[0001596532-17-000201:mdna:14]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (as a percentage of revenue) |
| Revenue: |  |  |  |  |  |  |  |
| Product | 87.3 | % |  | 87.7 | % |  | 87.1 | % |  | 87.7 | % |
| Service | 12.7 |  |  | 12.3 |  |  | 12.9 |  |  | 12.3 |  |
| Total revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 33.2 |  |  | 32.8 |  |  | 33.0 |  |  | 32.7 |  |
| Service | 2.7 |  |  | 3.4 |  |  | 3.0 |  |  | 3.4 |  |
| Total cost of revenue | 35.9 |  |  | 36.2 |  |  | 36.0 |  |  | 36.1 |  |
| Gross margin | 64.1 |  |  | 63.8 |  |  | 64.0 |  |  | 63.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 20.0 |  |  | 25.7 |  |  | 22.0 |  |  | 25.7 |  |
| Sales and marketing | 9.5 |  |  | 11.8 |  |  | 10.2 |  |  | 11.6 |  |
| General and administrative | 5.8 |  |  | 6.5 |  |  | 6.1 |  |  | 6.4 |  |
| Total operating expenses | 35.3 |  |  | 44.0 |  |  | 38.3 |  |  | 43.7 |  |
| Income from operations | 28.8 |  |  | 19.8 |  |  | 25.7 |  |  | 20.2 |  |
| Interest expense | (0.2 | ) |  | (0.3 | ) |  | (0.2 | ) |  | (0.3 | ) |
| Other income (expense), net | 0.3 |  |  | 0.2 |  |  | 0.3 |  |  | 0.1 |  |
| Total other income (expense), net | 0.1 |  |  | (0.1 | ) |  | 0.1 |  |  | (0.2 | ) |
| Income before provision for income taxes | 28.9 |  |  | 19.7 |  |  | 25.8 |  |  | 20.0 |  |
| Provision for income taxes | 3.6 |  |  | 5.2 |  |  | 0.7 |  |  | 5.5 |  |
| Net income | 25.3 | % |  | 14.5 | % |  | 25.1 | % |  | 14.5 | % |

[0001596532-17-000201:mdna:15]
[same as prior period, unchanged from 0001596532-17-000088:mdna:14]

[0001596532-17-000201:mdna:16]
(1) Includes stock-based compensation expense as follows (in thousands):

[0001596532-17-000201:mdna:17]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cost of revenue | $ | 1,087 |  |  | $ | 868 |  |  | $ | 2,111 |  |  | $ | 1,661 |  |
| Research and development | 10,342 |  |  | 7,595 |  |  | 19,929 |  |  | 15,052 |  |
| Sales and marketing | 4,080 |  |  | 3,780 |  |  | 7,536 |  |  | 7,427 |  |
| General and administrative | 2,891 |  |  | 1,989 |  |  | 5,263 |  |  | 3,452 |  |
| Total stock-based compensation | $ | 18,400 |  |  | $ | 14,232 |  |  | $ | 34,839 |  |  | $ | 27,592 |  |

[0001596532-17-000201:mdna:18]
Three and Six Months Ended June 30, 2017 Compared to Three and Six Months Ended June 30, 2016

[0001596532-17-000201:mdna:19]
[same as prior period, unchanged from 0001596532-17-000088:mdna:18]

[0001596532-17-000201:mdna:20]
[same as prior period, unchanged from 0001596532-17-000088:mdna:19]

[0001596532-17-000201:mdna:21]
[same as prior period, unchanged from 0001596532-17-000088:mdna:20]

[0001596532-17-000201:mdna:22]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including sales to large end customers who generally receive lower pricing, manufacturing-related costs including costs associated with supply chain sourcing activities, merchant silicon costs, and the mix of products sold. We expect our gross margins to fluctuate over time, depending on the factors described above and others.

[0001596532-17-000201:mdna:23]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2017 |  | 2016 |  | Change in |  | 2017 |  | 2016 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
|  | (in thousands, except percentages) |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 353,904 |  |  | $ | 235,616 |  |  | $ | 118,288 |  |  | 50.2% |  | $ | 645,271 |  |  | $ | 448,091 |  |  | $ | 197,180 |  |  | 44.0% |
| Service | 51,307 |  |  | 33,125 |  |  | 18,182 |  |  | 54.9 |  | 95,415 |  |  | 62,846 |  |  | 32,569 |  |  | 51.8 |
| Total revenue | 405,211 |  |  | 268,741 |  |  | 136,470 |  |  | 50.8 |  | 740,686 |  |  | 510,937 |  |  | 229,749 |  |  | 45.0 |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 134,406 |  |  | 88,021 |  |  | 46,385 |  |  | 52.7 |  | 244,242 |  |  | 166,934 |  |  | 77,308 |  |  | 46.3 |
| Service | 11,028 |  |  | 9,269 |  |  | 1,759 |  |  | 19.0 |  | 22,457 |  |  | 17,462 |  |  | 4,995 |  |  | 28.6 |
| Total cost of revenue | 145,434 |  |  | 97,290 |  |  | 48,144 |  |  | 49.5 |  | 266,699 |  |  | 184,396 |  |  | 82,303 |  |  | 44.6 |
| Gross profit | $ | 259,777 |  |  | $ | 171,451 |  |  | $ | 88,326 |  |  | 51.5% |  | $ | 473,987 |  |  | $ | 326,541 |  |  | $ | 147,446 |  |  | 45.2% |
| Gross margin | 64.1 | % |  | 63.8 | % |  |  |  |  |  | 64.0 | % |  | 63.9 | % |  |  |  |  |

[0001596532-17-000201:mdna:24]
[same as prior period, unchanged from 0001596532-17-000088:mdna:23]

[0001596532-17-000201:mdna:25]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2017 |  | % of Total |  | 2016 |  | % of Total |  | 2017 |  | % of Total |  | 2016 |  | % of Total |
|  | (in thousands, except percentages) |
| Americas | $ | 304,020 |  |  | 75.0 | % |  | $ | 201,317 |  |  | 74.9 | % |  | $ | 568,883 |  |  | 76.8 | % |  | $ | 383,958 |  |  | 75.1 | % |
| Europe, Middle East and Africa | 77,367 |  |  | 19.1 |  |  | 42,644 |  |  | 15.9 |  |  | 120,101 |  |  | 16.2 |  |  | 86,383 |  |  | 16.9 |  |
| Asia-Pacific | 23,824 |  |  | 5.9 |  |  | 24,780 |  |  | 9.2 |  |  | 51,702 |  |  | 7.0 |  |  | 40,596 |  |  | 8.0 |  |
| Total revenue | $ | 405,211 |  |  | 100.0 | % |  | $ | 268,741 |  |  | 100.0 | % |  | $ | 740,686 |  |  | 100.0 | % |  | $ | 510,937 |  |  | 100.0 | % |

[0001596532-17-000201:mdna:26]
[same as prior period, unchanged from 0001596532-17-000088:mdna:25]

[0001596532-17-000201:mdna:27]
Product revenue increased 50.2% in the three months ended June 30, 2017 and 44.0% in the six months ended June 30, 2017, compared to the same periods in 2016.  The increase was primarily driven by increased shipments to our existing customers as they continue to grow and expand their businesses, increasing their demand for our switch products and related accessories.  In addition, our newer products have continued to gain market acceptance, which has contributed to our revenue growth.  Service revenue increased 54.9% in the three months ended June 30, 2017 and 51.8% in the six months ended June 30, 2017, compared to the same periods in 2016, as a result of continued growth in initial and renewal support contracts as our customer installed base continued to expand.  We continue to experience pressure on both product and service pricing due to competitive market conditions.  However, this pricing pressure was more than offset by the increased demand drivers outlined above.

[0001596532-17-000201:mdna:28]
[same as prior period, unchanged from 0001596532-17-000088:mdna:27]

[0001596532-17-000201:mdna:29]
Cost of revenue increased $48.1 million in the three months ended June 30, 2017 and $82.3 million for the six months ended June 30, 2017, compared to the same periods in 2016. The increase in cost of revenue was primarily due to an increase in product shipment volumes and the corresponding increase in product revenue. Gross margin remained generally consistent, increasing slightly from 63.8% to 64.1% for the three months ended June 30, 2017 and 63.9% to 64.0% for the six months ended June 30, 2017, compared to the same periods in 2016.  Gross margin benefited from improved service margins as we scale our services business, but this improvement was partially offset by slightly lower product margins reflecting a somewhat higher mix of shipments to larger end customers who receive lower pricing terms due to volume discounts.

[0001596532-17-000201:mdna:30]
30

[0001596532-17-000201:mdna:31]
[same as prior period, unchanged from 0001596532-17-000088:mdna:30]

[0001596532-17-000201:mdna:32]
[same as prior period, unchanged from 0001596532-17-000088:mdna:31]

[0001596532-17-000201:mdna:33]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2017 |  | 2016 |  | Change in |  | 2017 |  | 2016 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
|  | (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 81,194 |  |  | $ | 69,020 |  |  | $ | 12,174 |  |  | 17.6% |  | $ | 162,804 |  |  | $ | 131,535 |  |  | $ | 31,269 |  |  | 23.8% |
| Sales and marketing | 38,630 |  |  | 31,744 |  |  | 6,886 |  |  | 21.7 |  | 75,657 |  |  | 59,350 |  |  | 16,307 |  |  | 27.5 |
| General and administrative | 23,319 |  |  | 17,529 |  |  | 5,790 |  |  | 33.0 |  | 45,474 |  |  | 32,763 |  |  | 12,711 |  |  | 38.8 |
| Total operating expenses | $ | 143,143 |  |  | $ | 118,293 |  |  | $ | 24,850 |  |  | 21.0% |  | $ | 283,935 |  |  | $ | 223,648 |  |  | $ | 60,287 |  |  | 27.0% |

[0001596532-17-000201:mdna:34]
[same as prior period, unchanged from 0001596532-17-000088:mdna:33]

[0001596532-17-000201:mdna:35]
[same as prior period, unchanged from 0001596532-17-000088:mdna:34]

[0001596532-17-000201:mdna:36]
Research and development expenses increased for the three and six months ended June 30, 2017 compared to the same periods in 2016.  The increase in each period was primarily due to increased personnel costs of $6.6 million and $14.6 million in the three and six months ended June 30, 2017, respectively as compared to the same periods in 2016.  These increases were driven by headcount growth, resulting in additional compensation costs including stock-based compensation charges.  In addition, prototype, third-party engineering and consulting costs grew $4.3 million and $14.7 million in the three and six months ended June 30, 2017, respectively as compared to the same periods in 2016.

[0001596532-17-000201:mdna:37]
[same as prior period, unchanged from 0001596532-17-000088:mdna:36]

[0001596532-17-000201:mdna:38]
[same as prior period, unchanged from 0001596532-17-000088:mdna:37]

[0001596532-17-000201:mdna:39]
Sales and marketing expenses increased for the three and six months ended June 30, 2017 compared to the same periods in 2016. The increase in each period was driven by personnel costs which increased by $5.0 million and $12.0 million in the three and six months ended June 30, 2017, respectively as compared to the same periods in 2016.  These increases were primarily due to headcount growth and higher sales volumes, driving increased compensation costs, including commissions.  In addition, sales support costs increased by $2.1 million and $4.1 million, in the three and six months ended June 30, 2017, respectively as compared to the same periods in 2016, reflecting increased professional services and field demonstration costs.

[0001596532-17-000201:mdna:40]
[same as prior period, unchanged from 0001596532-17-000088:mdna:39]

[0001596532-17-000201:mdna:41]
[same as prior period, unchanged from 0001596532-17-000088:mdna:40]

[0001596532-17-000201:mdna:42]
General and administrative expenses increased for the three and six months ended June 30, 2017 compared to the same periods in 2016.  The increase in each period was primarily due to an increase in Optumsoft and Cisco litigation related expenses of $4.4 million and $8.8 million in the three and six months ended June 30, 2017, respectively as compared to the same periods in 2016.  The amounts in each period include bond costs associated with the importation and sale of affected products and components during

[0001596532-17-000201:mdna:43]
the presidential review period of the 945 investigation.  In addition, other professional services and overall stock-based compensation charges increased by $1.3 million and $2.7 million in the three and six months ended June 30, 2017, respectively as compared to the same periods in 2016.

[0001596532-17-000201:mdna:44]
[same as prior period, unchanged from 0001596532-17-000088:mdna:42]

[0001596532-17-000201:mdna:45]
[same as prior period, unchanged from 0001596532-17-000088:mdna:43]

[0001596532-17-000201:mdna:46]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2017 |  | 2016 |  | Change in |  | 2017 |  | 2016 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
|  | (in thousands, except percentages) |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | $ | (623 | ) |  | $ | (732 | ) |  | $ | 109 |  |  | 14.9% |  | $ | (1,338 | ) |  | $ | (1,483 | ) |  | $ | 145 |  |  | 9.8% |
| Other income (expense), net | 1,119 |  |  | 416 |  |  | 703 |  |  | 169.0 |  | 2,144 |  |  | 753 |  |  | 1,391 |  |  | (184.7) |
| Total other income (expense), net | $ | 496 |  |  | $ | (316 | ) |  | $ | 812 |  |  | 257.0% |  | $ | 806 |  |  | $ | (730 | ) |  | $ | 1,536 |  |  | 210.4% |

[0001596532-17-000201:mdna:47]
[same as prior period, unchanged from 0001596532-17-000088:mdna:45]

[0001596532-17-000201:mdna:48]
Other income (expense), net improved during the three and six months ended June 30, 2017 compared to the same periods in 2016 primarily due to a net increase in interest income resulting from an increase in our marketable securities portfolio.

[0001596532-17-000201:mdna:49]
[same as prior period, unchanged from 0001596532-17-000088:mdna:47]

[0001596532-17-000201:mdna:50]
[same as prior period, unchanged from 0001596532-17-000088:mdna:48]

[0001596532-17-000201:mdna:51]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2017 |  | 2016 |  | Change in |  | 2017 |  | 2016 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
|  | (in thousands, except percentages) |
| Provision (benefit) for income taxes | $ | 14,445 |  |  | $ | 13,938 |  |  | $ | 507 |  |  | 3.6% |  | $ | 5,212 |  |  | $ | 28,014 |  |  | $ | (22,802 | ) |  | (81.4)% |
| Effective tax rate | 12.3 | % |  | 26.4 | % |  |  |  |  |  | 2.7 | % |  | 27.4 | % |  |  |  |  |

[0001596532-17-000201:mdna:52]
The effective tax rate for the three and six months ended June 30, 2017 was significantly lower than the U.S federal statutory rate primarily due to the recognition of excess tax benefits resulting from the adoption of ASU 2016-09, and earnings taxed at lower rates in foreign jurisdictions.  The decrease in the effective tax rate in the three and six months ended June 30, 2017, as compared to the same periods in 2016, was primarily due to the recognition of excess tax benefits as a component of the provision for income taxes attributable to the adoption of ASU 2016-09.  Prior to the adoption, these benefits were recorded as a component of shareholders' equity. Our future effective tax rate may fluctuate based upon our stock price and the amount of stock options exercised and equity awards vested in the quarter.

[0001596532-17-000201:mdna:53]
[same as prior period, unchanged from 0001596532-17-000088:mdna:51]

[0001596532-17-000201:mdna:54]
Our principal sources of liquidity are cash and cash equivalents, marketable securities, and cash generated from operations. As of June 30, 2017, cash and cash equivalents, and marketable securities were $1.1 billion, of which approximately $125.1 million was held outside the U.S. in our foreign subsidiaries.  We have not repatriated, nor do we currently have plans to repatriate these funds, but if we were to repatriate cash held outside of the U.S. for domestic cash operations, we would be required to accrue and pay U.S. income taxes to repatriate these funds, less any previously paid foreign income taxes. We consider the undistributed earnings of our foreign subsidiaries as of June 30, 2017 to be indefinitely reinvested, and, accordingly, no U.S. income taxes have been provided thereon.

[0001596532-17-000201:mdna:55]
Our cash and cash equivalents, and marketable securities are held for working capital purposes. We plan to continue to invest for long-term growth. We believe that our existing cash and cash equivalents together with cash flows from operations will be sufficient to meet our working capital requirements and our growth strategies for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development

[0001596532-17-000201:mdna:56]
activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs and access to outsourcing our manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and costs incurred related to outstanding litigation claims. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-17-000201:mdna:57]
[same as prior period, unchanged from 0001596532-17-000088:mdna:54]

[0001596532-17-000201:mdna:58]
|  | Six Months EndedJune 30, |
|  | 2017 |  | 2016 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 242,095 |  |  | $ | 141,996 |  |
| Cash used in by investing activities | (12,930 | ) |  | (308,177 | ) |
| Cash provided by financing activities | 25,976 |  |  | 9,972 |  |
| Effect of exchange rate changes | 411 |  |  | (59 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 255,552 |  |  | $ | (156,268 | ) |

[0001596532-17-000201:mdna:59]
[same as prior period, unchanged from 0001596532-17-000088:mdna:56]

[0001596532-17-000201:mdna:60]
During the six months ended June 30, 2017, cash provided by operating activities was $242.1 million, resulting from net income of $185.6 million non-cash adjustments to net income of $37.1 million, and a net increase in cash from changes in our operating assets and liabilities of $19.3 million.  Our operating cash benefited from increased deferred revenue of $181.6 million resulting from growth in product deferred revenue related to contract acceptance terms and ongoing growth in PCS contracts.  These increases were partially offset by growth in inventory of $127.3 million, supporting overall growth in the business and the expansion of our manufacturing and supply chain activities.  In addition, accounts receivable increased by $16.5 million related to timing of billing and cash collections, and prepaid expenses and current assets increased by $22.2 million primarily due to higher deferred cost of inventory associated with the increased product revenue deferrals referenced above, partially offset by a reduction in inventory deposits.

[0001596532-17-000201:mdna:61]
During the six months ended June 30, 2016, cash provided by operating activities was $142.0 million, primarily from net income of $74.1 million, net non-cash adjustments to net income of $30.8 million, and a net increase in cash from changes in our operating assets and liabilities of $37.1 million. The increase in cash from changes in operating assets and liabilities was primarily due to an increase in deferred revenue of $33.5 million mostly related to new and renewed PCS contracts, an increase in accounts payable of $18.5 million primarily due to timing of vendor payments, and an increase in cash of $17.9 million from changes in income taxes payable. Cash outflows from changes in operating assets and liabilities primarily consisted of net inventory purchases of $26.0 million as we continue to build our inventory balances.

[0001596532-17-000201:mdna:62]
[same as prior period, unchanged from 0001596532-17-000088:mdna:59]

[0001596532-17-000201:mdna:63]
During the six months ended June 30, 2017, cash used in investing activities was $12.9 million, consisting of purchases of available-for-sale securities of $114.2 million, offset by proceeds of $112.1 million and purchases of property, equipment and other assets of $9.5 million.

[0001596532-17-000201:mdna:64]
During the six months ended June 30, 2016, cash used in investing activities was $308.2 million, consisting of purchases of available-for-sale securities of $292.9 million, purchases of property, equipment and other assets of $12.7 million, and an additional investment in a privately-held company of $2.5 million.

[0001596532-17-000201:mdna:65]
[same as prior period, unchanged from 0001596532-17-000088:mdna:62]

[0001596532-17-000201:mdna:66]
During the six months ended June 30, 2017, cash provided by financing activities was $26.0 million, consisting primarily of proceeds from the issuance of common stock under employee equity incentive plans of $28.1 million.

[0001596532-17-000201:mdna:67]
During the six months ended June 30, 2016, cash provided by financing activities was $10.0 million, consisting primarily of proceeds from equity incentive plans of $11.2 million, offset by minimum tax withheld for employees and payments for lease financing obligations of $1.2 million.

[0001596532-17-000201:mdna:68]
[same as prior period, unchanged from 0001596532-17-000088:mdna:65]

[0001596532-17-000201:mdna:69]
As of June 30, 2017, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-17-000201:mdna:70]
[same as prior period, unchanged from 0001596532-17-000088:mdna:67]

[0001596532-17-000201:mdna:71]
As of June 30, 2017, our principal commitments consist of obligations under operating leases and purchase commitments. There have been no significant changes to these obligations during the six months ended June 30, 2017, compared to the contractual obligations disclosed in our "Management's Discussion and Analysis of Financial Condition and Results of Operations" included in our Annual Report on Form 10-K, filed with the SEC on February 17, 2017, other than the purchase commitments described in Note 5. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements of this Quarterly Report on Form 10-Q.

[0001596532-17-000201:mdna:72]
[same as prior period, unchanged from 0001596532-17-000088:mdna:70]

[0001596532-17-000201:mdna:73]
[same as prior period, unchanged from 0001596532-17-000088:mdna:71]

[0001596532-17-000201:mdna:74]
[same as prior period, unchanged from 0001596532-17-000088:mdna:72]

[0001596532-17-000201:mdna:75]
[same as prior period, unchanged from 0001596532-17-000088:mdna:73]

[0001596532-17-000201:mdna:76]
34
