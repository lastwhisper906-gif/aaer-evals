# ANET 8-K — 0001596532-26-000010 filed 2026-02-12

## item codes, every 8-K on or before 2026-02-17

- 2026-02-12 0001596532-26-000010 — 2.02, 9.01
- 2025-11-04 0001596532-25-000284 — 2.02, 9.01
- 2025-09-08 0001596532-25-000258 — 5.02, 5.03, 8.01, 9.01
- 2025-08-05 0001596532-25-000214 — 2.02, 9.01
- 2025-06-16 0001596532-25-000170 — 5.02, 9.01
- 2025-06-03 0001596532-25-000148 — 5.07
- 2025-05-06 0001596532-25-000103 — 2.02, 5.02, 8.01, 9.01
- 2025-03-17 0001596532-25-000077 — 5.02, 8.01, 9.01
- 2025-02-18 0001596532-25-000018 — 2.02, 9.01
- 2024-12-03 0001596532-24-000402 — 5.03, 9.01
- 2024-11-07 0001596532-24-000366 — 2.02, 8.01, 9.01
- 2024-07-30 0001596532-24-000277 — 2.02, 9.01
- 2024-06-10 0001596532-24-000233 — 5.07
- 2024-05-24 0001596532-24-000219 — 8.01
- 2024-05-07 0001596532-24-000171 — 2.02, 8.01, 9.01
- 2024-04-23 0001596532-24-000155 — 5.02, 9.01
- 2024-04-19 0001596532-24-000152 — 5.02, 8.01
- 2024-02-28 0001596532-24-000095 — 8.01
- 2024-02-12 0001596532-24-000041 — 2.02, 9.01
- 2023-12-20 0001596532-23-000349 — 5.03, 9.01
- 2023-12-01 0001596532-23-000324 — 5.02, 8.01, 9.01
- 2023-10-30 0001596532-23-000272 — 2.02, 9.01
- 2023-07-31 0001596532-23-000196 — 2.02, 5.02, 9.01
- 2023-06-16 0001596532-23-000168 — 5.07
- 2023-05-01 0001596532-23-000101 — 2.02, 9.01
- 2023-02-13 0001596532-23-000015 — 2.02, 9.01
- 2022-10-31 0001596532-22-000292 — 2.02, 9.01
- 2022-10-25 0001596532-22-000282 — 5.03, 9.01
- 2022-08-01 0001596532-22-000218 — 2.02, 9.01
- 2022-07-25 0001596532-22-000205 — 5.02
- 2022-06-03 0001596532-22-000179 — 5.07
- 2022-05-02 0001596532-22-000111 — 2.02, 9.01
- 2022-03-29 0001596532-22-000100 — 5.02
- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2026-02-17

- none on or before 2026-02-17

## item 2.02 — earnings release, exhibit 99.1

[0001596532-26-000010:8k_2_02:1]
EX-99.1
2
ex991q425-earningsrelease.htm
EX-99.1

[0001596532-26-000010:8k_2_02:2]
Document

[0001596532-26-000010:8k_2_02:3]
Exhibit 99.1

[0001596532-26-000010:8k_2_02:4]
Arista Networks, Inc. Reports Fourth Quarter and Year End 2025 Financial Results

[0001596532-26-000010:8k_2_02:5]
SANTA CLARA, Calif.- February 12, 2026 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus, and routing environments, today announced financial results for its fourth quarter and the full year ended December 31, 2025.

[0001596532-26-000010:8k_2_02:6]
“2025 was the year of validation of our Arista 2.0 momentum, as we hit the milestone of shipping a cumulative of 150 million ports,” stated Jayshree Ullal, Chairperson and CEO of Arista Networks. "We exceeded both our AI networking and campus expansion goals, delivering profitable growth and revenue of $9 billion."

[0001596532-26-000010:8k_2_02:7]
Fourth Quarter Financial Highlights

[0001596532-26-000010:8k_2_02:8]
•Revenue of $2.488 billion, an increase of 7.8% compared to the third quarter of 2025, and an increase of 28.9% from the fourth quarter of 2024.

[0001596532-26-000010:8k_2_02:9]
•GAAP gross margin of 62.9%, compared to GAAP gross margin of 64.6% in the third quarter of 2025 and 63.8% in the fourth quarter of 2024.

[0001596532-26-000010:8k_2_02:10]
•Non-GAAP gross margin of 63.4%, compared to non-GAAP gross margin of 65.2% in the third quarter of 2025 and 64.2% in the fourth quarter of 2024.

[0001596532-26-000010:8k_2_02:11]
•GAAP net income of $955.8 million, or $0.75 per diluted share, compared to GAAP net income of $801.0 million, or $0.62 per diluted share, in the fourth quarter of 2024.

[0001596532-26-000010:8k_2_02:12]
•Non-GAAP net income of $1.047 billion, or $0.82 per diluted share, compared to non-GAAP net income of $849.6 million1, or $0.661 per diluted share, in the fourth quarter of 2024.

[0001596532-26-000010:8k_2_02:13]
Full Year Financial Highlights

[0001596532-26-000010:8k_2_02:14]
•Revenue of $9.006 billion, an increase of 28.6% compared to fiscal year 2024.

[0001596532-26-000010:8k_2_02:15]
•GAAP gross margin of 64.1%, compared to GAAP gross margin of 64.1% in fiscal year 2024.

[0001596532-26-000010:8k_2_02:16]
•Non-GAAP gross margin of 64.6%, compared to non-GAAP gross margin of 64.6% in fiscal year 2024.

[0001596532-26-000010:8k_2_02:17]
•GAAP net income of $3.511 billion, or $2.75 per diluted share, compared to GAAP net income of $2.852 billion, or $2.23 per diluted share, in fiscal year 2024.

[0001596532-26-000010:8k_2_02:18]
•Non-GAAP net income of $3.806 billion or $2.98 per diluted share, compared to non-GAAP net income of $2.971 billion1 or $2.321 per diluted share, in fiscal year 2024.

[0001596532-26-000010:8k_2_02:19]
“Our Q4 results underscore the strong operating leverage inherent in our model, providing a powerful exit rate as we head into 2026," said Chantelle Breithaupt, Arista’s CFO. "By pairing 29% revenue growth with a disciplined 47.5% operating margin, Arista achieved a historic milestone: surpassing $1 billion in quarterly net income. Congratulations to the team."

[0001596532-26-000010:8k_2_02:20]
Fourth Quarter Company Highlights

[0001596532-26-000010:8k_2_02:21]
•Arista Networks Unveiled Next Generation Data and AI Center Networks

[0001596532-26-000010:8k_2_02:22]
The R4 series platforms for AI, data center, and routed backbone deployment deliver high performance, low AI job completion times, low power consumption, and integrated security, while helping customers reduce total cost of ownership.

[0001596532-26-000010:8k_2_02:23]
•Arista Introduced Innovations for Massive Scale Campus Mobility

[0001596532-26-000010:8k_2_02:24]
1 Prior period amounts have been updated to conform to the current period presentation. Refer to the Reconciliation of Selected GAAP to Non-GAAP Financial Measures for details.

[0001596532-26-000010:8k_2_02:25]
Arista Virtual Ethernet Segment with Proxy ARP (Arista VESPA) enables customers to deploy large-scale WLAN mobility domains.

[0001596532-26-000010:8k_2_02:26]
•Arista AVA uses Agentic AI to Streamline Network Operations

[0001596532-26-000010:8k_2_02:27]
Arista AVA (Autonomous Virtual Assist) was extended with additional agentic AI capabilities for use cases such as multi-domain event correlation, continuous monitoring, and network troubleshooting.

[0001596532-26-000010:8k_2_02:28]
•Arista Launched Cognitive Campus Switches for the Industrial Edge

[0001596532-26-000010:8k_2_02:29]
Arista’s new ruggedized platforms bring the power, reliability, and operational simplicity of EOS to demanding industrial or outdoor environments.

[0001596532-26-000010:8k_2_02:30]
Full Year Company Highlights

[0001596532-26-000010:8k_2_02:31]
•Arista introduced intelligent innovations for AI networking

[0001596532-26-000010:8k_2_02:32]
Capabilities such as Cluster Load Balancing (CLB) and CloudVision® Universal Network Observability™ (CV UNO™) maximize AI workload performance and deliver deep job-centric observability for enhanced troubleshooting.

[0001596532-26-000010:8k_2_02:33]
•Arista Networks to collaborate with industry leaders to deliver Ethernet for Scale-Up Networks (ESUN)

[0001596532-26-000010:8k_2_02:34]
ESUN was unveiled at the OCP Global Summit in October 2025 as an open OCP workstream committed to the goal of open standards-based solutions for scale-up, based on Ethernet, and open to all.

[0001596532-26-000010:8k_2_02:35]
•Arista Networks announced AI agents to streamline network operations

[0001596532-26-000010:8k_2_02:36]
With the combined power of open standards like MCP and the robust data and programmability of Arista's EOS and NetDL, organizations are empowered to build, manage, and secure the networks of the future.

[0001596532-26-000010:8k_2_02:37]
•Arista Networks Acquired the VeloCloud® SD-WAN Portfolio from Broadcom

[0001596532-26-000010:8k_2_02:38]
VeloCloud enables customers to securely and efficiently interconnect data centers and distributed campus/branch offices while complementing Arista's existing portfolio.

[0001596532-26-000010:8k_2_02:39]
•Arista Networks Recognized in the Leaders Quadrant of the 2025 Gartner® Magic Quadrant™ for Data Center Switching, published on March 31, 2025, and in the Visionaries Quadrant of the 2025 Gartner® Magic Quadrant™ for Enterprise Wired and Wireless LAN Infrastructure published on 25 June 2025

[0001596532-26-000010:8k_2_02:40]
Gartner positioned Arista Networks as the vendor with the highest Ability to Execute in the Magic Quadrant™ for Data Center Switching.

[0001596532-26-000010:8k_2_02:41]
•Arista Networks Expanded its Executive Ranks

[0001596532-26-000010:8k_2_02:42]
Todd Nightingale was appointed President and Chief Operating Officer, Kenneth Duda was promoted to President and Chief Technology Officer, and Tyson Lamoreaux was appointed Senior Vice President of Cloud and AI Networking.

[0001596532-26-000010:8k_2_02:43]
Financial Outlook

[0001596532-26-000010:8k_2_02:44]
For the first quarter of 2026, we expect:

[0001596532-26-000010:8k_2_02:45]
•Revenue of approximately $2.6 billion;

[0001596532-26-000010:8k_2_02:46]
•Non-GAAP gross margin between approximately 62-63%; and

[0001596532-26-000010:8k_2_02:47]
•Non-GAAP operating margin of approximately 46%.

[0001596532-26-000010:8k_2_02:48]
Guidance for non-GAAP financial measures excludes certain items, including stock-based compensation expense, intangible asset amortization, and potential non-recurring charges or benefits. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis without unreasonable effort because these exclusions can be uncertain or difficult to predict, including stock-based compensation expense which is impacted by the timing of employee stock transactions, the company’s future hiring

[0001596532-26-000010:8k_2_02:49]
and retention needs and the future fair market value of the company’s common stock. The actual amount of these exclusions will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-26-000010:8k_2_02:50]
Prepared Materials and Conference Call Information

[0001596532-26-000010:8k_2_02:51]
Arista's executives will discuss the fourth quarter and year end 2025 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-26-000010:8k_2_02:52]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website. In addition, please refer to the Earnings Presentation at https://investors.arista.com/ for a summary of our financial results.

[0001596532-26-000010:8k_2_02:53]
Forward-Looking Statements

[0001596532-26-000010:8k_2_02:54]
This press release contains “forward-looking statements” regarding our future performance, including but not limited to quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin, and non-GAAP operating margin for the first quarter of 2026, statements regarding Arista’s products, innovation, leadership and ability to execute and succeed in data-driven, client-to-cloud networking for AI, datacenter, campus, and routing environments. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including but not limited to risks associated with: escalated or escalating U.S. tariffs and countermeasures and retaliatory actions taken by other countries; enhanced import/export restrictions, such as enhanced export controls the U.S. has adopted targeting trade with China, as well as countermeasures taken by affected countries; large purchases by a limited number of customers who represent a substantial portion of our revenue; adverse economic conditions, continuing uncertain economic conditions or reduced information technology and network infrastructure spending; the impact of sole or limited sources of supply, supply shortages and extended lead times or supply changes; volatility in our revenue and revenue growth rates; variability in our gross margins; variations in our results of operations; the rapid evolution of the networking market; failure to successfully carry out new products and service offerings and expand into adjacent markets; intense competition and industry consolidation; expansion of our international sales and operations; investments in or acquisitions of other businesses, products or technologies; industry cyclicality; fluctuations in currency exchange rates; failure to raise additional capital on terms satisfactory to us; our inability to attract new large customers or sell additional products and services to our existing customers; inability to grow sales of switching and routing platforms which generate most of our product revenue; inability to increase market awareness or acceptance of our new products and services; decreases in the sales prices of our products and services; long and unpredictable sales cycles; inability to offer high quality support and services offerings; declines in maintenance renewals and support contracts by customers; product quality problems, defects, errors or vulnerabilities in our products; failure to anticipate technological shifts; insufficient component supply and inventory management; our reliance upon a predominant merchant silicon vendor; our dependence on third-party manufacturers to build our products; assertions by third parties of intellectual property rights infringement, misappropriation or other violations; failure or inability to protect or assert our intellectual property rights; cybersecurity incidents and breaches of our cybersecurity systems, or other security or privacy breaches or incidents; failure to detect cybersecurity incidents; failure to comply with government law and regulations; issues in the development and use of artificial intelligence, combined with an uncertain regulatory environment; future decisions to reduce or discontinue repurchasing our common stock pursuant to our stock repurchase programs; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission, including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/

[0001596532-26-000010:8k_2_02:55]
and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof, and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-26-000010:8k_2_02:56]
Non-GAAP Financial Measures

[0001596532-26-000010:8k_2_02:57]
This press release and accompanying table contain certain non-GAAP financial measures, including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, intangible asset amortization, gains/losses on strategic investments, and the income tax effect of these non-GAAP exclusions, including the recognition of direct excess tax benefits associated with stock-based awards, as well as non-recurring adjustments to our tax provision resulting from the enactment of the One Big Beautiful Bill Act (“OBBB Act”). Effective the fourth quarter and fiscal year 2025, the Company updated its methodology for calculating the income tax effect of Non-GAAP adjustments. Previously, the Company’s calculation excluded all tax benefits associated with stock-based awards, consisting of both direct excess tax benefits and other discrete indirect effects. Under the updated methodology, the Company continues to exclude direct excess tax benefits but no longer excludes the discrete indirect effects of such awards. Management believes this change better aligns with industry practice and provides a more meaningful view of the Company’s effective tax rate. All prior period Non-GAAP results presented in this release have been recast to conform to the current period presentation.

[0001596532-26-000010:8k_2_02:58]
The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-26-000010:8k_2_02:59]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are, therefore, unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-26-000010:8k_2_02:60]
Gartner®, Magic Quadrant™ for Data Center Switching, Andrew Lerner et al., 31 March 2025

[0001596532-26-000010:8k_2_02:61]
Gartner®, Magic Quadrant™ for Enterprise Wired and Wireless LAN Infrastructure, Mike Leibovitz et al., 25 June 2025

[0001596532-26-000010:8k_2_02:62]
GARTNER and MAGIC QUADRANT are trademarks of Gartner, Inc. and its affiliates.

[0001596532-26-000010:8k_2_02:63]
Gartner does not endorse any company, vendor, product or service depicted in its publications, and does not advise technology users to select only those vendors with the highest ratings or other designation.

[0001596532-26-000010:8k_2_02:64]
Gartner publications consist of the opinions of Gartner’s business and technology insights organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this publication, including any warranties of merchantability or fitness for a particular purpose.

[0001596532-26-000010:8k_2_02:65]
The Gartner content described herein (the “Gartner Content”) represents research opinion or viewpoints published, as part of a syndicated subscription service, by Gartner, Inc. ("Gartner"), and is not a representation of fact. Gartner Content speaks as of its original publication date (and not as of the date of this Earnings Press Release), and the opinions expressed in the Gartner Content are subject to change without notice.

[0001596532-26-000010:8k_2_02:66]
About Arista Networks

[0001596532-26-000010:8k_2_02:67]
Arista Networks is an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus, and routing environments. Its award-winning platforms deliver availability, agility, automation, analytics, and security through an advanced network operating stack. For more information, visit www.arista.com.

[0001596532-26-000010:8k_2_02:68]
ARISTA, CloudVision, and Etherlink are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners. Additional information and resources can be found at www.arista.com.

[0001596532-26-000010:8k_2_02:69]
ARISTA NETWORKS, INC.

[0001596532-26-000010:8k_2_02:70]
Condensed Consolidated Statements of Income

[0001596532-26-000010:8k_2_02:71]
(Unaudited, in millions, except per share amounts)

[0001596532-26-000010:8k_2_02:72]
|  |  | Three Months Ended December 31, |  | Twelve Months Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,095.7 |  |  | $ | 1,608.1 |  |  | $ | 7,576.9 |  |  | $ | 5,884.0 |  |
| Service |  | 392.1 |  |  | 322.3 |  |  | 1,428.8 |  |  | 1,119.1 |  |
| Total revenue |  | 2,487.8 |  |  | 1,930.4 |  |  | 9,005.7 |  |  | 7,003.1 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 853.2 |  |  | 643.6 |  |  | 2,978.7 |  |  | 2,299.0 |  |
| Service |  | 70.8 |  |  | 55.8 |  |  | 258.3 |  |  | 212.8 |  |
| Total cost of revenue |  | 924.0 |  |  | 699.4 |  |  | 3,237.0 |  |  | 2,511.8 |  |
| Total gross profit |  | 1,563.8 |  |  | 1,231.0 |  |  | 5,768.7 |  |  | 4,491.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 348.4 |  |  | 285.0 |  |  | 1,237.3 |  |  | 996.7 |  |
| Sales and marketing |  | 139.1 |  |  | 111.0 |  |  | 533.4 |  |  | 427.3 |  |
| General and administrative |  | 43.4 |  |  | 35.4 |  |  | 141.9 |  |  | 122.7 |  |
| Total operating expenses |  | 530.9 |  |  | 431.4 |  |  | 1,912.6 |  |  | 1,546.7 |  |
| Income from operations |  | 1,032.9 |  |  | 799.6 |  |  | 3,856.1 |  |  | 2,944.6 |  |
| Other income, net |  | 104.5 |  |  | 89.4 |  |  | 393.6 |  |  | 320.5 |  |
| Income before income taxes |  | 1,137.4 |  |  | 889.0 |  |  | 4,249.7 |  |  | 3,265.1 |  |
| Provision for income taxes |  | 181.6 |  |  | 88.0 |  |  | 738.3 |  |  | 413.0 |  |
| Net income |  | $ | 955.8 |  |  | $ | 801.0 |  |  | $ | 3,511.4 |  |  | $ | 2,852.1 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.76 |  |  | $ | 0.64 |  |  | $ | 2.79 |  |  | $ | 2.27 |  |
| Diluted |  | $ | 0.75 |  |  | $ | 0.62 |  |  | $ | 2.75 |  |  | $ | 2.23 |  |
| Weighted-average common shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 1,257.8 |  |  | 1,260.3 |  |  | 1,258.0 |  |  | 1,256.3 |  |
| Diluted |  | 1,275.8 |  |  | 1,283.4 |  |  | 1,275.7 |  |  | 1,281.1 |  |

[0001596532-26-000010:8k_2_02:73]
ARISTA NETWORKS, INC.

[0001596532-26-000010:8k_2_02:74]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-26-000010:8k_2_02:75]
(Unaudited, in millions, except percentages and per share amounts)

[0001596532-26-000010:8k_2_02:76]
|  |  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| GAAP gross profit |  | $ | 1,563.8 |  |  | $ | 1,231.0 |  |  | $ | 5,768.7 |  |  | $ | 4,491.3 |  |
| GAAP gross margin |  | 62.9 | % |  | 63.8 | % |  | 64.1 | % |  | 64.1 | % |
| Stock-based compensation expense |  | 7.6 |  |  | 4.3 |  |  | 26.9 |  |  | 15.8 |  |
| Intangible asset amortization |  | 7.0 |  |  | 4.2 |  |  | 19.8 |  |  | 16.8 |  |
| Non-GAAP gross profit |  | $ | 1,578.4 |  |  | $ | 1,239.5 |  |  | $ | 5,815.4 |  |  | $ | 4,523.9 |  |
| Non-GAAP gross margin |  | 63.4 | % |  | 64.2 | % |  | 64.6 | % |  | 64.6 | % |
| GAAP income from operations |  | $ | 1,032.9 |  |  | $ | 799.7 |  |  | $ | 3,856.1 |  |  | $ | 2,944.6 |  |
| GAAP operating margin |  | 41.5 | % |  | 41.4 | % |  | 42.8 | % |  | 42.0 | % |
| Stock-based compensation expense |  | 133.1 |  |  | 100.7 |  |  | 439.2 |  |  | 355.4 |  |
| Intangible asset amortization |  | 15.3 |  |  | 6.7 |  |  | 41.7 |  |  | 26.8 |  |
| Non-GAAP income from operations |  | $ | 1,181.3 |  |  | $ | 907.1 |  |  | $ | 4,337.0 |  |  | $ | 3,326.8 |  |
| Non-GAAP operating margin |  | 47.5 | % |  | 47.0 | % |  | 48.2 | % |  | 47.5 | % |
| GAAP net income |  | $ | 955.8 |  |  | $ | 801.0 |  |  | $ | 3,511.4 |  |  | $ | 2,852.1 |  |
| Stock-based compensation expense |  | 133.1 |  |  | 100.7 |  |  | 439.2 |  |  | 355.4 |  |
| Intangible asset amortization |  | 15.3 |  |  | 6.7 |  |  | 41.7 |  |  | 26.8 |  |
| Gain on strategic investments |  | (2.5) |  |  | — |  |  | (13.4) |  |  | (12.4) |  |
| Tax impact of OBBB |  | (12.0) |  |  | — |  |  | 22.6 |  |  | — |  |
| Tax benefit on stock-based awards2 |  | (29.8) |  |  | (44.0) |  |  | (146.9) |  |  | (191.7) |  |
| Income tax effect on non-GAAP exclusions2 |  | (13.3) |  |  | (14.8) |  |  | (48.6) |  |  | (59.4) |  |
| Non-GAAP net income2 |  | $ | 1,046.6 |  |  | $ | 849.6 |  |  | $ | 3,806.0 |  |  | $ | 2,970.8 |  |
| GAAP diluted net income per share |  | $ | 0.75 |  |  | $ | 0.62 |  |  | $ | 2.75 |  |  | $ | 2.23 |  |
| Non-GAAP adjustments to net income2 |  | 0.07 |  |  | 0.04 |  |  | 0.23 |  |  | 0.09 |  |
| Non-GAAP diluted net income per share2 |  | $ | 0.82 |  |  | $ | 0.66 |  |  | $ | 2.98 |  |  | $ | 2.32 |  |
| Weighted-average shares used in computing diluted net income per share |  | 1,275.8 |  |  | 1,283.4 |  |  | 1,275.7 |  |  | 1,281.1 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 7.6 |  |  | $ | 4.3 |  |  | $ | 26.9 |  |  | $ | 15.8 |  |
| Research and development |  | 75.9 |  |  | 59.0 |  |  | 260.7 |  |  | 211.8 |  |
| Sales and marketing |  | 32.5 |  |  | 22.1 |  |  | 104.1 |  |  | 78.8 |  |
| General and administrative |  | 17.1 |  |  | 15.4 |  |  | 47.5 |  |  | 49.0 |  |
| Total |  | $ | 133.1 |  |  | $ | 100.8 |  |  | $ | 439.2 |  |  | $ | 355.4 |  |

[0001596532-26-000010:8k_2_02:77]
2 Prior period amounts have been updated to conform to the current period presentation to reflect the change in methodology for calculating non-GAAP income taxes associated with stock-based awards. The retrospective application of this change resulted in an increase to non-GAAP income of $19.5 million and $61.3 million for the three months and fiscal year ended December 31, 2024, respectively. The impact of this change on non-GAAP diluted net income per share was an increase of $0.01 and $0.05 for the three months and fiscal year ended December 31, 2024, respectively. Please refer to the discussions under "Non-GAAP Financial Measures" for further information with respect to this change.

[0001596532-26-000010:8k_2_02:78]
ARISTA NETWORKS, INC.

[0001596532-26-000010:8k_2_02:79]
Condensed Consolidated Balance Sheets

[0001596532-26-000010:8k_2_02:80]
(Unaudited, in millions)

[0001596532-26-000010:8k_2_02:81]
|  |  | December 31, 2025 |  | December 31, 2024 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,963.9 |  |  | $ | 2,762.4 |  |
| Marketable securities |  | 8,779.1 |  |  | 5,541.1 |  |
| Accounts receivable, net |  | 1,886.9 |  |  | 1,140.5 |  |
| Inventories |  | 2,247.1 |  |  | 1,834.6 |  |
| Prepaid expenses and other current assets |  | 1,510.0 |  |  | 632.3 |  |
| Total current assets |  | 16,387.0 |  |  | 11,910.9 |  |
| Property and equipment, net |  | 203.1 |  |  | 98.8 |  |
| Goodwill |  | 416.1 |  |  | 268.5 |  |
| Deferred tax assets |  | 1,773.6 |  |  | 1,440.4 |  |
| Other assets |  | 668.8 |  |  | 325.3 |  |
| TOTAL ASSETS |  | $ | 19,448.6 |  |  | $ | 14,043.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 651.7 |  |  | $ | 381.1 |  |
| Accrued liabilities |  | 475.4 |  |  | 435.3 |  |
| Deferred revenue |  | 4,002.6 |  |  | 1,727.3 |  |
| Other current liabilities |  | 246.8 |  |  | 188.5 |  |
| Total current liabilities |  | 5,376.5 |  |  | 2,732.2 |  |
| Deferred revenue, non-current |  | 1,369.8 |  |  | 1,064.1 |  |
| Other long-term liabilities |  | 331.8 |  |  | 252.8 |  |
| TOTAL LIABILITIES |  | 7,078.1 |  |  | 4,049.1 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital |  | 2,911.8 |  |  | 2,465.4 |  |
| Retained earnings |  | 9,446.6 |  |  | 7,542.5 |  |
| Accumulated other comprehensive income (loss) |  | 12.0 |  |  | (13.2) |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 12,370.5 |  |  | 9,994.8 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 19,448.6 |  |  | $ | 14,043.9 |  |

[0001596532-26-000010:8k_2_02:82]
8

[0001596532-26-000010:8k_2_02:83]
ARISTA NETWORKS, INC.

[0001596532-26-000010:8k_2_02:84]
Condensed Consolidated Statements of Cash Flows

[0001596532-26-000010:8k_2_02:85]
(Unaudited, in millions)

[0001596532-26-000010:8k_2_02:86]
|  |  | Twelve Months Ended December 31, |  |  |
|  |  | 2025 |  | 2024 |  |  |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |  |  |
| Net income |  | $ | 3,511.4 |  |  | $ | 2,852.1 |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  | 72.6 |  |  | 62.0 |  |  |  |
| Stock-based compensation |  | 439.2 |  |  | 355.4 |  |  |  |
| Deferred income taxes |  | (312.0) |  |  | (492.9) |  |  |  |
| Other |  | (27.1) |  |  | (53.6) |  |  |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  | (746.4) |  |  | (106.1) |  |  |  |
| Inventories |  | (412.5) |  |  | 110.6 |  |  |  |
| Other assets |  | (937.4) |  |  | (234.2) |  |  |  |
| Accounts payable |  | 260.5 |  |  | (51.6) |  |  |  |
| Other liabilities |  | 119.4 |  |  | 47.8 |  |  |  |
| Deferred revenue |  | 2,452.0 |  |  | 1,285.2 |  |  |  |
| Income taxes, net |  | (47.8) |  |  | (66.5) |  |  |  |
| Net cash provided by operating activities |  | 4,371.9 |  |  | 3,708.2 |  |  |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 3,432.5 |  |  | 2,058.6 |  |  |  |
| Proceeds from sale of marketable securities |  | 144.3 |  |  | 48.8 |  |  |  |
| Purchases of marketable securities |  | (6,748.4) |  |  | (4,526.1) |  |  |  |
| Purchases of property, equipment and intangible assets |  | (119.5) |  |  | (32.0) |  |  |  |
| Cash paid for business combination, net of cash acquired |  | (300.0) |  |  | — |  |  |  |
| Other |  | 14.9 |  |  | (6.6) |  |  |  |
| Net cash used in investing activities |  | (3,576.2) |  |  | (2,457.3) |  |  |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 57.7 |  |  | 60.2 |  |  |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (50.5) |  |  | (58.4) |  |  |  |
| Repurchase of common stock |  | (1,603.1) |  |  | (423.6) |  |  |  |
| Net cash used in financing activities |  | (1,595.9) |  |  | (421.8) |  |  |  |
| Effect of exchange rate changes |  | 1.7 |  |  | (4.8) |  |  |  |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | (798.5) |  |  | 824.3 |  |  |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 2,763.8 |  |  | 1,939.5 |  |  |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 1,965.3 |  |  | $ | 2,763.8 |  |  |  |

[0001596532-26-000010:8k_2_02:87]
| Investor Contacts: |  |
| Arista Networks, Inc. |
| Investor Advocacy |
| Rudolph Araujo |  |
| Rod Hall |  |
| +1 (408) 547-8080 |  |
| ir@arista.com |

[0001596532-26-000010:8k_2_02:88]
10
