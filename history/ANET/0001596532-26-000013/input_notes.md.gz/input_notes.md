# ANET notes — 0001596532-26-000013


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001596532-26-000013:notes:1]
Portions of the registrant’s definitive Proxy Statement relating to its 2026 Annual Meeting of Stockholders to be filed pursuant to Regulation 14A within 120 days after the registrant’s fiscal year end of December 31, 2025 are incorporated by reference into Part III of this Annual Report on Form 10-K.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001596532-26-000013:notes:2]
We have developed and implemented a cybersecurity risk management program intended to protect the confidentiality, integrity, and availability of our critical systems and information. In addition, our Legal and Information Technology ("IT")/Information Security ("IS") teams work together to oversee our compliance with applicable laws and regulations and coordinate with subject matter experts throughout our business to identify, monitor and mitigate risk including information security risk management and cyber defense programs.

[0001596532-26-000013:notes:3]
Our cybersecurity risk management program is aligned with our overall enterprise risk management programs and shares common methodologies, reporting channels and governance processes that apply across the enterprise risk management programs to other legal, compliance, strategic, operational, and financial risk areas.

[0001596532-26-000013:notes:4]
Our cybersecurity risk management program includes:

[0001596532-26-000013:notes:5]
•an information security management systems policy, including a business continuity policy, acceptable use and physical security policies, and an incident response policy and plan for responding to cybersecurity incidents, among others;

[0001596532-26-000013:notes:6]
•risk assessments designed to help identify material cybersecurity risks to our critical systems, information, products, services, and our broader enterprise IT environment;

[0001596532-26-000013:notes:7]
•a security team principally responsible for managing (1) our cybersecurity risk assessment processes, (2) our security controls, and (3) our response to cybersecurity incidents;

[0001596532-26-000013:notes:8]
•the use of internal audit teams and external service providers, where appropriate, to assess, test or otherwise assist with aspects of our security controls;

[0001596532-26-000013:notes:9]
•cybersecurity awareness, data protection, and privacy training of our employees, incident response personnel, and senior management; and

[0001596532-26-000013:notes:10]
•a vetting and management process for third party service providers, suppliers, and vendors

[0001596532-26-000013:notes:11]
Through this program, our IT/Cybersecurity team identifies and executes improvements based upon its own assessments, public cybersecurity events and the identification of new risks by third parties, including our external cybersecurity consultants. As part of these continuous improvement efforts, there may be times when the IT/Cybersecurity team prioritizes certain cybersecurity fixes or program improvements over other measures, which could lead to new known or unknown risks being identified on an ongoing basis. Cybersecurity threat actors are often highly sophisticated and nimble in their attacks. Despite these efforts, we cannot guarantee that our priorities and efforts will prevent any cybersecurity incident from happening.

[0001596532-26-000013:notes:12]
We also engage in periodic testing programs, using both internal assets and external consultants, including penetration testing, and incorporate multiple layers of physical, logical and written controls into our cybersecurity risk management program. Our IT/Cybersecurity team leverages centralized identity management, encryption configurations and technologies on the systems, devices, and third-party connections used in our operations.

[0001596532-26-000013:notes:13]
We also maintain cyber liability insurance coverage. While we currently hold such coverage, we cannot be certain that our insurance coverage will be adequate for liabilities actually incurred, that insurance will continue to be available to us on economically reasonable terms, or at all, or that any future claim will not be excluded or otherwise be denied coverage by any insurer.

[0001596532-26-000013:notes:14]
As of the date of this report, we have not identified any risks from cybersecurity threats, including as a result of any previous cybersecurity incidents, that we believe have, or are likely to, materially affect us, our business strategy, results of operations, or financial condition. For additional information concerning risks from cybersecurity threats, please refer to Item 1A, “Risk Factors,” in this annual report on Form 10-K, including the risk factors in the category entitled, “Risks Related to Cybersecurity and Data Privacy”.


## cyd:CybersecurityRiskManagementPositionsOrCommitteesResponsibleTextBlock

[0001596532-26-000013:notes:15]
Our Board considers cybersecurity risk as part of its risk oversight function and has delegated to the Audit Committee (Committee) oversight of cybersecurity and other information technology risks. The Committee oversees management’s

[0001596532-26-000013:notes:16]
implementation of our cybersecurity risk management program. The Committee receives quarterly reports from our Vice President and Chief Information Security Officer ("CISO"), in conjunction with other senior managers, on cybersecurity risks. In addition, these managers update the Committee, as necessary, regarding any material cybersecurity incidents, as well as incidents with lesser impact potential. The Committee reports to the full Board on cybersecurity no less frequently than once annually. The full Board also receives briefings from management on our cyber risk management program on a periodic basis.


## cyd:CybersecurityRiskRoleOfManagementTextBlock

[0001596532-26-000013:notes:17]
Our Cybersecurity team, led by one of our Vice Presidents who also serves as our CISO, is responsible for assessing and managing risks from cybersecurity threats. The Cybersecurity team has primary responsibility for our overall cybersecurity risk management program and supervises both our internal cybersecurity personnel and our external cybersecurity consultants.


## cyd:CybersecurityRiskManagementExpertiseOfManagementResponsibleTextBlock

[0001596532-26-000013:notes:18]
Our CISO has over 20 years of experience in the cybersecurity industry and has been instrumental in building several key security technologies, viz. Network Intrusion Prevention Systems ("NIPS"), Host Intrusion Prevention Systems ("HIPS"), Web Application Firewalls ("WAF"), Whitelisting, Endpoint/Server Host Monitoring ("EDR") and Virtualization Based Security ("VBS"). Previously, our CISO served in senior executive and technical leadership roles in several security companies. In addition, our CISO has experience as a pen-tester and has in-depth knowledge of operating systems, networking and security products. Our CISO holds a bachelor’s degree in computer science and a master’s degree in software systems. In addition, our IS team includes over 20 members each with experience in network security related roles, with the two IS leads reporting to our CISO each having more than 20 years of security experience.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-26-000013:notes:19]
Organization and Summary of Significant Accounting Policies
Organization

[0001596532-26-000013:notes:20]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus and routing environments. Our cloud networking solutions consist of our EOS, a set of network applications and our Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-26-000013:notes:21]
Basis of Presentation and Principles of Consolidation

[0001596532-26-000013:notes:22]
The accompanying consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and are prepared in accordance with accounting principles generally accepted in the United States ("GAAP"). All significant intercompany accounts and transactions have been eliminated.

[0001596532-26-000013:notes:23]
On November 7, 2024, the Company announced a four-for-one forward stock split ("Stock Split") of the Company’s common stock that was effected through the filing of an amendment to the Company's Amended and Restated Certificate of Incorporation ("Amendment") on December 3, 2024. The Stock Split proportionately increased the authorized shares of common stock, and all share and per share amounts presented herein have been retroactively adjusted to reflect the impact of the Stock Split.

[0001596532-26-000013:notes:24]
Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.

[0001596532-26-000013:notes:25]
Use of Estimates

[0001596532-26-000013:notes:26]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, valuation of inventory and contract manufacturer/supplier liabilities, accounting for income taxes, including the recognition of deferred tax assets and liabilities, valuation allowance on deferred tax assets and reserves for uncertain tax positions, revenue recognition and deferred revenue, valuation of goodwill and acquisition-related intangible assets, estimate of useful lives of long-lived assets including intangible assets, and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust these estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from these estimates.

[0001596532-26-000013:notes:27]
Concentrations of Business and Credit Risk

[0001596532-26-000013:notes:28]
We work closely with third-party contract manufacturers to manufacture our products. As of December 31, 2025, we had three primary contract manufacturing partners, who provided the vast majority of our electronic manufacturing services. Our contract manufacturing partners deliver our products to our third-party direct fulfillment facilities. We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers. Our products rely on key components, including certain integrated circuit components and power supplies, some of which our contract manufacturing partners purchase on our behalf from a limited number of suppliers, including certain sole-source providers. In addition, we rely heavily on a single merchant silicon supplier for our switching chips. We generally do not have guaranteed supply contracts with our component suppliers, and our manufacturing partners could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, or if we are unable to obtain alternative sources for these components, sales of our products could be delayed or halted entirely, or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.

[0001596532-26-000013:notes:29]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, marketable securities, and accounts receivable. Our cash equivalents and marketable securities are invested in high

[0001596532-26-000013:notes:30]
quality financial instruments with banks and financial institutions. Such deposits may be in excess of insured limits provided on such deposits.

[0001596532-26-000013:notes:31]
Our accounts receivable are unsecured and represent amounts due to us based on contractual obligations of our customers. We mitigate credit risk with respect to accounts receivable by performing ongoing credit evaluations of our customers to assess the probability of collection based on a number of factors, including past transaction experience with the customer, evaluation of their credit history, the credit limits extended, review of the invoicing terms of the arrangement, and current economic conditions that may affect a customer’s ability to pay. In situations where a customer may be thinly capitalized and we have limited payment history with it, we will either establish a small credit limit or require it to prepay its purchases. We generally do not require our customers to provide collateral to support accounts receivable. We have recorded an allowance for doubtful accounts for accounts receivables that we have determined to be uncollectible. We mitigate credit risk with respect to accounts receivables by performing ongoing credit evaluations of the borrower to assess the probability of collecting all amounts due to us under the existing contractual terms.

[0001596532-26-000013:notes:32]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators and OEM partners, and in conjunction with various technology partners. Significant customers are those that represent more than 10% of our total revenue during the period. There were two end customers who represented more than 10% of our total revenue for the years ended 2025, 2024 and 2023. Sales to one end customer represented 16%, 15% and 21% of our total revenue, and sales to the other end customer represented 26%, 20% and 18% of our total revenue for the years ended December 31, 2025, 2024 and 2023, respectively. As of December 31, 2025, and 2024, our top two resellers accounted for 52% and 50% of total accounts receivable, respectively.

[0001596532-26-000013:notes:33]
Cash and Cash Equivalents

[0001596532-26-000013:notes:34]
We consider all highly liquid investments with original or remaining maturities of three months or less at the time of purchase to be cash equivalents. Cash and cash equivalents consist of cash on deposit with various financial institutions and highly liquid investments in money market funds. Interest is accrued as earned.

[0001596532-26-000013:notes:35]
Marketable Securities

[0001596532-26-000013:notes:36]
We classify all highly liquid investments in debt securities with maturities of greater than three months at the date of purchase as marketable securities. We have classified and accounted for our marketable debt securities as available-for-sale. We determine the appropriate classification of these investments at the time of purchase and reevaluate such designation at each balance sheet date. After consideration of our risk versus reward objectives, as well as our liquidity requirements, we may hold or sell these securities prior to their stated maturities. As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying consolidated balance sheets. We carry these securities at fair value. For marketable debt securities, we report the unrealized gains and losses, net of taxes, as a component of stockholders’ equity. We determine any realized gains or losses on the sale of marketable securities using the specific identification method, and record such gains and losses in other income, net in the accompanying consolidated statements of income.

[0001596532-26-000013:notes:37]
For our debt securities in an unrealized loss position, we determine whether a credit loss exists by considering, among other factors, current market conditions, credit quality of debt issuers, any changes to the rating of the security by a rating agency, and the extent to which fair value is less than cost. We would recognize an allowance for credit losses, up to the amount of the unrealized loss when appropriate, and write down the amortized cost basis of the investment if it is more likely than not we will be required to sell or we intend to sell the investment before recovery of its amortized cost basis.

[0001596532-26-000013:notes:38]
Accounts Receivable

[0001596532-26-000013:notes:39]
Accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts. We estimate our allowance for doubtful accounts based upon the collectability of the receivables in light of historical trends, reasonable and supportable information of our customers' economic conditions that may affect our customers’ ability to pay, and prevailing economic conditions. This evaluation is done in order to identify issues that may impact the collectability of receivables and related estimated required allowance. Revisions to the allowance are recorded as an adjustment to bad debt expense. After appropriate collection efforts are exhausted, specific accounts receivable deemed to be uncollectible are charged against the allowance in the period they are deemed uncollectible. Recoveries of accounts receivable previously written-off are recorded as credits to bad debt expense.

[0001596532-26-000013:notes:40]
Fair Value Measurements

[0001596532-26-000013:notes:41]
Fair value is defined as the exchange price that would be received for an asset or an exit price that would be paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. These assets and liabilities include cash and cash equivalents, marketable securities, accounts receivable, accounts payable, and accrued liabilities. Cash equivalents, accounts receivable, accounts payable and accrued liabilities are stated at carrying values in our consolidated financial statements, which approximate their fair value due to the short-term nature of these instruments.

[0001596532-26-000013:notes:42]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value. We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs. The three-tiers of the fair value hierarchy are as follows:

[0001596532-26-000013:notes:43]
Level I—Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date;

[0001596532-26-000013:notes:44]
Level II—Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities; and

[0001596532-26-000013:notes:45]
Level III—Unobservable inputs that are supported by little or no market data for the related assets or liabilities and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.

[0001596532-26-000013:notes:46]
Foreign Currency

[0001596532-26-000013:notes:47]
The functional currency of our foreign subsidiaries is either the U.S. dollar or their local currency depending on the nature of the subsidiaries’ activities.

[0001596532-26-000013:notes:48]
Transaction re-measurement - Assets and liabilities denominated in a currency other than a subsidiary’s functional currency are re-measured into the subsidiary's functional currency using exchange rates in effect at the end of the reporting period, with gains and losses recorded in other income, net in the consolidated statements of income. To date, foreign currency transaction gains and losses and exchange rate fluctuations have not been material to our consolidated financial statements.

[0001596532-26-000013:notes:49]
Translation - Assets and liabilities of subsidiaries denominated in foreign functional currencies are translated into U.S. dollars at the closing exchange rate on the balance sheet date and equity-related balances are translated at historical exchange rates. Revenues, costs and expenses in foreign functional currencies are translated using average exchange rates that approximate those in effect during the period. Translation adjustments are recorded within accumulated other comprehensive income, a separate component of total stockholders’ equity.

[0001596532-26-000013:notes:50]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-26-000013:notes:51]
Inventories primarily consist of finished goods, including evaluation inventory held at customers or partners, and strategic components, primarily integrated circuits. Inventories are stated at the lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Evaluation inventory consists of new products and/or use cases at customer or partner sites for trial purposes. Title to the inventory remains with Arista during the trial period and invoicing occurs only upon completion of the trial period and when/if the products have been accepted by the customer. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory. We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value. For the years ended December 31, 2025, 2024 and 2023, we recorded charges of $131.6 million, $267.2 million and $234.4 million, respectively, within cost of product revenue for inventory write-downs.

[0001596532-26-000013:notes:52]
Our contract manufacturers procure components and assemble products on our behalf and we procure strategic components from suppliers based on our forecasts. We record a liability and a corresponding charge for non-cancellable, non-returnable purchase commitments with our contract manufacturers and suppliers for quantities in excess of our demand forecasts or that are considered obsolete. For the year ended 2023, we recorded a charge of $113.0 million within cost of product revenue for such liabilities with our contract manufacturers and suppliers. Such charges were not material for the years ended December 31, 2025 and 2024.

[0001596532-26-000013:notes:53]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels.  Despite general improvements in the supply environment, fluctuations in supplier lead times and the persistence of some long-lead components require us to maintain elevated inventory levels and purchase commitments. To manage this continued volatility, we maintain extended demand-planning horizons and strategic inventory buffers to ensure continuity of supply and address forecast uncertainty. We expect inventory and purchase commitments to remain volatile due to new product introductions, fluctuating customer demand, and varying supplier lead times. There is, however, no guarantee that all suppliers will meet their commitments in the time frame committed or that actual customer demand will directly match our demand forecasts. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and/or outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer and supplier liabilities.

[0001596532-26-000013:notes:54]
Property and Equipment

[0001596532-26-000013:notes:55]
Property and equipment are stated at cost, less accumulated depreciation, except for land which is not depreciated. We capitalize any additions and improvements and expense maintenance and repairs as incurred. Depreciation is calculated using the straight-line method over the estimated useful lives of the related assets, generally three years. Our leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term.

[0001596532-26-000013:notes:56]
Business Combinations

[0001596532-26-000013:notes:57]
We use the acquisition method to account for our business combinations in accordance with Accounting Standards Codification ("ASC") 805 - Business Combinations. We allocate the total fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the consideration transferred over the fair values of the assets acquired and liabilities assumed is recorded as goodwill. The results of operations of the acquired businesses are included in our consolidated financial statements from the date of acquisition. Acquisition-related transaction and restructuring costs are expensed as incurred.

[0001596532-26-000013:notes:58]
During the measurement period, which is not to exceed one year from the acquisition date, we may record adjustments to the acquired assets and liabilities assumed, with a corresponding offset to goodwill or the preliminary purchase price, to reflect new information obtained about facts and circumstances that existed as of the acquisition date. Upon the conclusion of the measurement period, any subsequent adjustments are recorded to earnings.

[0001596532-26-000013:notes:59]
Goodwill and Acquired Intangible Assets

[0001596532-26-000013:notes:60]
Goodwill represents the excess of the purchase price over the fair value of net assets acquired in a business combination. The Company has one reporting unit and tests goodwill for impairment at least annually in the fourth quarter or more frequently if indicators of potential impairment exist. We first perform a qualitative assessment to determine whether it is more likely than not that the fair value of our reporting unit is less than its carrying amount. If the reporting unit does not pass the qualitative assessment, a quantitative test is performed by comparing the fair value of our reporting unit with its carrying amount. We would recognize an impairment loss for the amount by which the carrying amount exceeds the fair value. There were no impairment charges in any of the periods presented in the consolidated financial statements. See Note 4. Acquisition, Goodwill and Acquisition-Related Intangible Assets for additional information.

[0001596532-26-000013:notes:61]
Acquired intangible assets are carried at cost less accumulated amortization. All acquired intangible assets have been determined to have definite lives and are amortized on a straight-line basis over their estimated useful lives, ranging from three to eight years. Acquired intangible assets are reviewed for impairment under the long-lived asset model described below. There were no impairment charges in any of the periods presented in the consolidated financial statements. See Note 4. Acquisition, Goodwill and Acquisition-Related Intangible Assets for additional information.

[0001596532-26-000013:notes:62]
Impairment of Long-Lived Assets and Investments in Privately-Held Companies

[0001596532-26-000013:notes:63]
The carrying amounts of our long-lived assets, including property and equipment, intangible assets, ROU assets and investments in privately-held companies, are periodically reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. Recoverability of these assets is measured by comparison of the carrying amount of each asset to the future undiscounted cash flows the asset is expected to generate over its remaining life. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between

[0001596532-26-000013:notes:64]
the carrying value and the fair value of the impaired asset. No impairment of any long-lived assets was identified for any of the periods presented in the consolidated financial statements.

[0001596532-26-000013:notes:65]
Loss Contingencies

[0001596532-26-000013:notes:66]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. In assessing loss contingencies, we use significant judgments and assumptions to estimate the likelihood of loss, impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. We record a provision for contingent losses when it is both probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. We record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements, and (ii) the range of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.

[0001596532-26-000013:notes:67]
Revenue Recognition

[0001596532-26-000013:notes:68]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with post-contract customer support (“PCS”). We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

[0001596532-26-000013:notes:69]
•Identification of the contract, or contracts, with a customer

[0001596532-26-000013:notes:70]
•Identification of the performance obligations in the contract

[0001596532-26-000013:notes:71]
•Determination of the transaction price

[0001596532-26-000013:notes:72]
•Allocation of the transaction price to the performance obligations in the contract

[0001596532-26-000013:notes:73]
•Recognition of revenue when (or as) we satisfy the performance obligation

[0001596532-26-000013:notes:74]
Post-Contract Customer Support ("PCS")

[0001596532-26-000013:notes:75]
PCS, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts. We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernible pattern of delivery related to these promises. We do not provide unspecified upgrades on a set schedule and address customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years.

[0001596532-26-000013:notes:76]
Contracts with Multiple Performance Obligations

[0001596532-26-000013:notes:77]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts that contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price ("SSP"). Judgment is required to determine the SSP for each distinct performance obligation. We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

[0001596532-26-000013:notes:78]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as gross margin, market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to product category, actual and expected volume, discounting policies, and customer vertical and size.

[0001596532-26-000013:notes:79]
In determining if control has transferred, we consider whether certain indicators of the transfer of control are present, such as the transfer of title, present right to payment, significant risks and rewards of ownership, and customer acceptance when

[0001596532-26-000013:notes:80]
acceptance is not a formality. Revenue from sales of hardware is recognized when control transfers to the customer, which is generally when the product is shipped. We defer revenue recognition on customer contracts for new products or use cases, which contain customer-specified requirements that must be met prior to acceptance.

[0001596532-26-000013:notes:81]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and refund obligations. We include some or all of an estimate of the related at-risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

[0001596532-26-000013:notes:82]
Most of our contracts with customers have standard payment terms of 30 to 90 days. We have determined our contracts generally do not include a significant financing component because the Company and the customer have specific business reasons other than financing for entering into such contracts. Specifically, both we and our customers seek to ensure the customer has a simplified way of purchasing Arista products and services.

[0001596532-26-000013:notes:83]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

[0001596532-26-000013:notes:84]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical return rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-26-000013:notes:85]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

[0001596532-26-000013:notes:86]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

[0001596532-26-000013:notes:87]
Contract Balances

[0001596532-26-000013:notes:88]
A contract asset is recognized when we have a contractual right to consideration for both completed and partially completed performance obligations that have not yet been invoiced. Contract assets are included in other current assets in the accompanying consolidated balance sheets.

[0001596532-26-000013:notes:89]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a contract that is cancellable. Contract liabilities are included in other current liabilities and other long-term liabilities in the accompanying consolidated balance sheets

[0001596532-26-000013:notes:90]
Deferred revenue is comprised mainly of unearned revenue related to product deferrals from contracts with acceptance clauses and, annual and multi-year PCS contracts.

[0001596532-26-000013:notes:91]
Research and Development Expenses

[0001596532-26-000013:notes:92]
Costs related to the research, design and development of our products are charged to research and development expenses as incurred.

[0001596532-26-000013:notes:93]
Segment Reporting

[0001596532-26-000013:notes:94]
We develop, market and sell cloud networking solutions, which primarily consist of our switching and routing platforms and related network applications, and there are no segment managers who are held accountable for operations or operating results below the Company level. Our chief operating decision maker is our President, Chief Executive Officer and Chairperson of the Board, who reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance. Accordingly, we have determined that we operate as one reportable segment.

[0001596532-26-000013:notes:95]
Stock-Based Compensation

[0001596532-26-000013:notes:96]
Stock-based compensation cost for equity awards is measured at the grant-date fair value using appropriate valuation techniques and recognized as expense over the requisite service or performance period. We account for forfeitures when they occur.

[0001596532-26-000013:notes:97]
Stock-based compensation costs for stock options and restricted stock units ("RSUs") are recognized on a straight-line basis over the requisite service period, which is generally two to five years. The Company has granted RSUs that vest upon the satisfaction of both service-based and performance-based conditions ("PRSUs"). The service-based condition for these awards is generally satisfied over one to four years. The performance-based conditions are satisfied upon achieving specified performance targets, such as financial or operating metrics. We record stock-based compensation expense for performance-based equity awards on an accelerated attribution method over the requisite service period, and only if performance-based conditions are considered probable to be satisfied.

[0001596532-26-000013:notes:98]
See Note 6. Stockholders' Equity and Stock-Based Compensation for a detailed discussion of the Company’s stock plans, assumptions to the valuation techniques, and stock-based compensation expense.

[0001596532-26-000013:notes:99]
Income Taxes

[0001596532-26-000013:notes:100]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-26-000013:notes:101]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-26-000013:notes:102]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-26-000013:notes:103]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.

[0001596532-26-000013:notes:104]
The U.S. tax rules require U.S. tax on foreign earnings, known as global intangible low taxed income (“GILTI”). Under U.S. GAAP, we are allowed to make an accounting policy choice of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes (the “deferred method”). We selected the deferred method of accounting and recorded the associated basis differences anticipated to influence prospective GILTI calculations.

[0001596532-26-000013:notes:105]
Recently Adopted Accounting Pronouncements

[0001596532-26-000013:notes:106]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted

[0001596532-26-000013:notes:107]
for fiscal years beginning after December 15, 2024. We have adopted ASU 2023-09 for the year ended December 31, 2025 on a prospective basis. See Note 8, Income Taxes for the inclusion of the new required disclosure.

[0001596532-26-000013:notes:108]
Recent Accounting Pronouncements Not Yet Effective

[0001596532-26-000013:notes:109]
In November 2024, the FASB issued ASU 2024-03, Disaggregation of Income Statement Expenses (Subtopic 220-40). The ASU requires the disaggregated disclosure of specific expense categories, including purchases of inventory, employee compensation, depreciation, and amortization, within relevant income statement captions, and also requires disclosure of the total amount of selling expenses along with the definition of selling expenses. The ASU is effective for annual periods beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027. Adoption of this ASU can either be applied prospectively to consolidated financial statements issued for reporting periods after the effective date of this ASU or retrospectively to any or all prior periods presented in the consolidated financial statements. Early adoption is also permitted. This ASU will result in the required additional disclosures being included in our consolidated financial statements, once adopted. We are currently evaluating the provisions of this ASU.

[0001596532-26-000013:notes:110]
On December 2025, the FASB issued ASU 2025-11, Interim Reporting (Topic 270) which is intended to streamline the guidance in ASC 270, Interim Reporting, and clarify when it applies. Under the amendments, an entity is subject to ASC 270 if it provides interim financial statements and notes in accordance with GAAP. ASU 2025-11 also addresses the form and content of such financial statements, interim disclosures requirements, and establishes a principle under which an entity must disclose events since the end of the last annual reporting period that have a material impact on the entity. ASU 2025-11 is effective for interim reporting periods within annual reporting periods beginning after December 15, 2027, and early adoption is permitted. We are currently evaluating the provisions of this ASU.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-26-000013:notes:111]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted 
for fiscal years beginning after December 15, 2024. We have adopted ASU 2023-09 for the year ended December 31, 2025 on a prospective basis.
Recent Accounting Pronouncements Not Yet Effective


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-26-000013:notes:112]
Fair Value Measurements
Assets measured at fair values on a recurring basis

[0001596532-26-000013:notes:113]
We measure and report our cash equivalents, restricted cash, and available-for-sale marketable securities at fair value on a recurring basis. The following tables summarize the fair value of these financial assets by significant investment category and their levels within the fair value hierarchy (in millions):

[0001596532-26-000013:notes:114]
|  |  | December 31, 2025 |  | December 31, 2024 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,174.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,174.8 |  |  | $ | 1,707.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,707.5 |  |
| Commercial paper |  | — |  |  | 29.8 |  |  | — |  |  | 29.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate bonds |  | — |  |  | 6.6 |  |  | — |  |  | 6.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3.0 |  |  | — |  |  | 3.0 |  |
| U.S. government notes |  | 124.9 |  |  | — |  |  | — |  |  | 124.9 |  |  | 31.4 |  |  | — |  |  | — |  |  | 31.4 |  |
|  |  | 1,299.7 |  |  | 36.4 |  |  | — |  |  | 1,336.1 |  |  | 1,738.9 |  |  | 3.0 |  |  | — |  |  | 1,741.9 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 83.0 |  |  | — |  |  | 83.0 |  |  | — |  |  | 48.8 |  |  | — |  |  | 48.8 |  |
| U.S. government notes |  | 2,854.3 |  |  | — |  |  | — |  |  | 2,854.3 |  |  | 1,921.5 |  |  | — |  |  | — |  |  | 1,921.5 |  |
| Corporate bonds |  | — |  |  | 4,329.7 |  |  | — |  |  | 4,329.7 |  |  | — |  |  | 2,593.6 |  |  | — |  |  | 2,593.6 |  |
| Municipal bonds |  | — |  |  | 14.5 |  |  |  |  | 14.5 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Agency securities |  | — |  |  | 1,497.6 |  |  | — |  |  | 1,497.6 |  |  | — |  |  | 977.2 |  |  | — |  |  | 977.2 |  |
|  |  | 2,854.3 |  |  | 5,924.8 |  |  | — |  |  | 8,779.1 |  |  | 1,921.5 |  |  | 3,619.6 |  |  | — |  |  | 5,541.1 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted cash |  | 1.4 |  |  | — |  |  | — |  |  | 1.4 |  |  | 1.4 |  |  | — |  |  | — |  |  | 1.4 |  |
| Total Financial Assets |  | $ | 4,155.4 |  |  | $ | 5,961.2 |  |  | $ | — |  |  | $ | 10,116.6 |  |  | $ | 3,661.8 |  |  | $ | 3,622.6 |  |  | $ | — |  |  | $ | 7,284.4 |  |

[0001596532-26-000013:notes:115]
During the year ended on December 31, 2025, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-26-000013:notes:116]
The following table summarizes the amortized cost, unrealized gains and losses, and fair value of our debt securities measured at fair value on a recurring basis (in millions):

[0001596532-26-000013:notes:117]
|  |  | December 31, 2025 |  | December 31, 2024 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 112.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 112.8 |  |  | $ | 48.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 48.8 |  |
| U.S. government |  | 2,970.4 |  |  | 8.8 |  |  | — |  |  | 2,979.2 |  |  | 1,954.8 |  |  | 2.7 |  |  | (4.6) |  |  | 1,952.9 |  |
| Corporate bonds |  | 4,321.2 |  |  | 16.0 |  |  | (0.9) |  |  | 4,336.3 |  |  | 2,595.7 |  |  | 4.4 |  |  | (6.5) |  |  | 2,593.6 |  |
| Municipal bonds |  | 14.5 |  |  | — |  |  | — |  |  | 14.5 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Agency securities |  | 1,495.5 |  |  | 2.7 |  |  | (0.6) |  |  | 1,497.6 |  |  | 981.0 |  |  | 1.6 |  |  | (2.4) |  |  | 980.2 |  |
| Total |  | $ | 8,914.4 |  |  | $ | 27.5 |  |  | $ | (1.5) |  |  | $ | 8,940.4 |  |  | $ | 5,580.3 |  |  | $ | 8.7 |  |  | $ | (13.5) |  |  | $ | 5,575.5 |  |

[0001596532-26-000013:notes:118]
For debt securities in unrealized loss positions, it is not likely that we will be required to sell such securities before recovery of their amortized cost basis nor do we have the intent to sell such securities before maturity; we invest in debt securities that have maximum maturities of three years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. Given the short-term and conservative nature of our portfolio, our debt securities are exposed to minimal credit risk; therefore, we did not recognize any credit losses or non-credit-related impairments related to our available-for-sale marketable debt securities for the years ended 2025, 2024 and 2023. All unrealized losses were recognized in other comprehensive income (loss). Realized gains or losses were immaterial for the years ended 2025, 2024 and 2023.

[0001596532-26-000013:notes:119]
The following table is an analysis of our debt securities in unrealized loss positions (in millions):

[0001596532-26-000013:notes:120]
|  |  | December 31, 2025 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| Commercial paper |  | $ | 9.9 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 9.9 |  |  | $ | — |  |
| U.S. government notes |  | 260.8 |  |  | $ | — |  |  | 15.0 |  |  | — |  |  | 275.8 |  |  | — |  |
| Corporate bonds |  | 857.7 |  |  | (0.9) |  |  | 29.9 |  |  | — |  |  | 887.6 |  |  | (0.9) |  |
| Municipal bonds |  | 4.7 |  |  | — |  |  | — |  |  | — |  |  | 4.7 |  |  | — |  |
| Agency securities |  | 473.1 |  |  | (0.6) |  |  | — |  |  | — |  |  | 473.1 |  |  | (0.6) |  |
| Total |  | $ | 1,606.2 |  |  | $ | (1.5) |  |  | $ | 44.9 |  |  | $ | — |  |  | $ | 1,651.1 |  |  | $ | (1.5) |  |

[0001596532-26-000013:notes:121]
As of December 31, 2025, we had no marketable debt securities with contractual maturities that exceed 36 months. The fair values of marketable debt securities, by remaining contractual maturities, are as follows (in millions):

[0001596532-26-000013:notes:122]
|  |  | December 31, 2025 |
| Due in 1 year or less |  | $ | 3,267.4 |  |
| Due in 1 year through 3 years |  | 5,511.7 |  |
| Total marketable securities |  | $ | 8,779.1 |  |

[0001596532-26-000013:notes:123]
The weighted-average remaining duration of our marketable debt securities is approximately 1.4 years as of December 31, 2025.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-26-000013:notes:124]
The following tables summarize the fair value of these financial assets by significant investment category and their levels within the fair value hierarchy (in millions):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-26-000013:notes:125]
Financial Statements Details
Inventories

[0001596532-26-000013:notes:126]
Inventories consist of the following (in millions):

[0001596532-26-000013:notes:127]
|  |  | December 31, |
|  |  | 2025 |  | 2024 |
| Raw materials |  | $ | 611.2 |  |  | $ | 565.4 |  |
| Finished goods(1) |  | 1,635.9 |  |  | 1,269.2 |  |
| Total inventories |  | $ | 2,247.1 |  |  | $ | 1,834.6 |  |

[0001596532-26-000013:notes:128]
(1) The balance includes evaluation inventory totaling $403.7 million and $422.1 million as of December 31, 2025 and December 31, 2024, respectively.

[0001596532-26-000013:notes:129]
Prepaid Expenses and Other Current Assets

[0001596532-26-000013:notes:130]
Prepaid expenses and other current assets consist of the following (in millions):

[0001596532-26-000013:notes:131]
|  |  | December 31, |
|  |  | 2025 |  | 2024 |
| Deferred cost of goods sold(1) |  | $ | 1,197.0 |  |  | $ | 291.3 |  |
| Other prepaid expenses and deposits |  | 313.0 |  |  | 341.0 |  |
| Total prepaid expenses and other current assets |  | $ | 1,510.0 |  |  | $ | 632.3 |  |

[0001596532-26-000013:notes:132]
(1) The increase in 2025 was driven by a corresponding increase in deferred product revenue.

[0001596532-26-000013:notes:133]
Property and Equipment, net

[0001596532-26-000013:notes:134]
Property and equipment, net consists of the following (in millions):

[0001596532-26-000013:notes:135]
|  |  | December 31, |
|  |  | 2025 |  | 2024 |
| Land |  | $ | 47.3 |  |  | $ | 47.2 |  |
| Equipment and machinery |  | 188.3 |  |  | 160.7 |  |
| Computer hardware and software |  | 66.2 |  |  | 63.9 |  |
| Furniture and fixtures |  | 3.7 |  |  | 3.5 |  |
| Leasehold improvements |  | 38.4 |  |  | 34.7 |  |
| Construction-in-process |  | 107.9 |  |  | 8.2 |  |
| Property and equipment, gross |  | 451.8 |  |  | 318.2 |  |
| Less: accumulated depreciation |  | (248.7) |  |  | (219.4) |  |
| Property and equipment, net |  | $ | 203.1 |  |  | $ | 98.8 |  |

[0001596532-26-000013:notes:136]
Depreciation expense was $30.9 million, $34.0 million and $31.7 million for the years ended December 31, 2025, 2024 and 2023, respectively.

[0001596532-26-000013:notes:137]
Contract Liabilities, Deferred Revenue and Other Performance Obligations

[0001596532-26-000013:notes:138]
Contract Liabilities

[0001596532-26-000013:notes:139]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a cancellable contract. The following table summarizes the activity related to our contract liabilities (in millions):

[0001596532-26-000013:notes:140]
|  |  | Year Ended December 31, |
|  |  | 2025 |  | 2024 |
| Contract liabilities, beginning balance |  | $ | 160.8 |  |  | $ | 133.2 |  |
| Less: Revenue recognized from beginning balance |  | (63.1) |  |  | (58.3) |  |
| Add: Contract liabilities recognized |  | 152.4 |  |  | 85.9 |  |
| Contract liabilities, ending balance |  | $ | 250.1 |  |  | $ | 160.8 |  |

[0001596532-26-000013:notes:141]
As of December 31, 2025 and 2024, $114.0 million and $65.7 million, respectively, of our contract liabilities were recorded within other current liabilities with the remaining balance recorded within other long-term liabilities in the accompanying consolidated balance sheets.

[0001596532-26-000013:notes:142]
Deferred Revenue

[0001596532-26-000013:notes:143]
Deferred revenue is comprised mainly of unearned revenue related to product deferrals from contracts with acceptance clauses and, annual and multi-year PCS contracts. The following table summarizes the activity related to our deferred revenue (in millions):

[0001596532-26-000013:notes:144]
|  |  | Year Ended December 31, |
|  |  | 2025 |  | 2024 |
| Deferred revenue, beginning balance |  | $ | 2,791.4 |  |  | $ | 1,506.2 |  |
| Less: Revenue recognized from beginning balance |  | (1,691.5) |  |  | (860.2) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 4,272.5 |  |  | 2,145.4 |  |
| Deferred revenue, ending balance |  | $ | 5,372.4 |  |  | $ | 2,791.4 |  |

[0001596532-26-000013:notes:145]
Other Performance Obligations

[0001596532-26-000013:notes:146]
Other performance obligations totaling $503.1 million as of December 31, 2025 include unbilled multi-year PCS and service contract amounts of $275.5 million and $227.6 million of binding contractual agreements with certain customers that are primarily related to future product shipments.

[0001596532-26-000013:notes:147]
Revenue from Total Remaining Performance Obligations

[0001596532-26-000013:notes:148]
Total revenue from our contract liabilities, deferred revenue and other performance obligations that is expected to be recognized in future periods was $6.1 billion as of December 31, 2025. Approximately 90% of this future revenue is expected to be recognized over the next two years and the remaining 10% is expected to be recognized during the third to the fifth year.

[0001596532-26-000013:notes:149]
Other Income, Net

[0001596532-26-000013:notes:150]
Other income, net consists of the following (in millions):

[0001596532-26-000013:notes:151]
|  |  | Year Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Other income (expense), net: |  |  |  |  |  |  |
| Interest income |  | $ | 383.4 |  |  | $ | 311.0 |  |  | $ | 152.4 |  |
| Other income (expense) |  | 10.2 |  |  | 9.5 |  |  | 12.3 |  |
| Total other income, net |  | $ | 393.6 |  |  | $ | 320.5 |  |  | $ | 164.7 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-26-000013:notes:152]
The following table summarizes the activity related to our contract liabilities (in millions):

[0001596532-26-000013:notes:153]
The following table summarizes the activity related to our deferred revenue (in millions):


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-26-000013:notes:154]
Acquisition, Goodwill and Acquisition-Related Intangible Assets 
Acquisition and Goodwill

[0001596532-26-000013:notes:155]
On June 30, 2025, we completed the acquisition of the VeloCloud business ("VeloCloud") from Broadcom for total cash consideration of $300.0 million. VeloCloud's secure, AI-optimized cloud WAN portfolio provides seamless connectivity to customer sites of any type, complementing Arista's leading data center and campus wired/wireless portfolio. The preliminary purchase price allocation based on the estimated fair values of the assets acquired and liabilities assumed as of the acquisition date, included $268.4 million of intangible assets, $148.0 million of goodwill and $116.4 million of net tangible liabilities assumed as of June 30, 2025. A portion of the goodwill is deductible for tax purposes. The rest of the changes in the carrying value of goodwill for the year ended December 31, 2025 were not material.

[0001596532-26-000013:notes:156]
Acquisition-Related Intangible Assets

[0001596532-26-000013:notes:157]
Acquisition-related intangible assets, included in other assets, are subject to amortization on a straight-line basis over their estimated useful lives, as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. The following table presents details of our acquisition-related intangible assets as of December 31, 2025 and 2024 (in millions, except for years):

[0001596532-26-000013:notes:158]
|  | December 31, 2025 |  | December 31, 2024 |
|  | Weighted Average Remaining Useful Life (in years) |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| Developed technology | 4.0 |  | $ | 241.1 |  |  | $ | (139.0) |  |  | $ | 102.1 |  |  | $ | 154.9 |  |  | $ | (119.2) |  |  | $ | 35.7 |  |
| Customer relationships | 6.2 |  | 224.3 |  |  | (48.9) |  |  | 175.4 |  |  | 54.6 |  |  | (29.5) |  |  | 25.1 |  |
| Trade name | 4.5 |  | 24.9 |  |  | (13.6) |  |  | 11.3 |  |  | 12.4 |  |  | (11.2) |  |  | 1.2 |  |
| Total | 5.3 |  | $ | 490.3 |  |  | $ | (201.5) |  |  | $ | 288.8 |  |  | $ | 221.9 |  |  | $ | (159.9) |  |  | $ | 62.0 |  |

[0001596532-26-000013:notes:159]
Amortization expense related to acquisition-related intangible assets was $41.6 million, $26.8 million and $33.4 million for the years ended December 31, 2025, 2024 and 2023, respectively.

[0001596532-26-000013:notes:160]
As of December 31, 2025, future estimated amortization expense related to the acquired-related intangible assets is as follows (in millions):

[0001596532-26-000013:notes:161]
| Years Ending December 31, |  | Future Amortization Expense |
| 2026 |  | $ | 61.3 |  |
| 2027 |  | 57.4 |  |
| 2028 |  | 54.0 |  |
| 2029 and thereafter |  | 116.1 |  |
| Total |  | $ | 288.8 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-26-000013:notes:162]
Commitments and Contingencies
Purchase Commitments

[0001596532-26-000013:notes:163]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders for finished goods and strategic components, including integrated circuits consigned to contract manufacturers, consists of non-cancellable commitments. Our purchase obligations also encompass software and technology licenses, property and equipment, and other corporate goods and services. As of December 31, 2025, we had non-cancellable purchase commitments not recorded on our balance sheet of $6.8 billion, of which $6.3 billion have confirmed receipt dates within 12 months, and $0.5 billion have confirmed receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-26-000013:notes:164]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $53.0 million and $95.8 million as of December 31, 2025 and 2024, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the consolidated balance sheets.

[0001596532-26-000013:notes:165]
Leases

[0001596532-26-000013:notes:166]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of December 31, 2025, we had lease payment obligations, net of immaterial sublease income, of $90.5 million, with $22.1 million payable within 12 months.

[0001596532-26-000013:notes:167]
Property project

[0001596532-26-000013:notes:168]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office, lab and data center space. The estimated capital expenditures related to this project is expected to be approximately $170.0 million to $195.0 million through December 31, 2026 at which time construction is expected to be completed.

[0001596532-26-000013:notes:169]
Guarantees

[0001596532-26-000013:notes:170]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third-party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions, and our guarantee and indemnification arrangements have not had any material impact on our consolidated financial statements to date.

[0001596532-26-000013:notes:171]
Legal Proceedings

[0001596532-26-000013:notes:172]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-26-000013:notes:173]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of December 31, 2025, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-26-000013:notes:174]
Stockholders' Equity and Stock-Based Compensation
Stock Repurchase Program

[0001596532-26-000013:notes:175]
In May 2025, we completed repurchases under the $1.2 billion Prior Repurchase Program and our board of directors authorized the $1.5 billion New Repurchase Program. This authorization allows us to repurchase shares of our common stock that will be funded from working capital. Repurchases may be made at management's discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Exchange Act, or a combination of the foregoing. The New Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the Company at any time without prior notice. During the year ended December 31, 2025, we repurchased a total of $921.0 million of our common stock under our Prior Repurchase Program and $682.1 million of our common stock under our New Repurchase Program. As of December 31, 2025, the remaining authorized amount for stock repurchases under the New Repurchase Program was approximately $817.9 million.

[0001596532-26-000013:notes:176]
A summary of the stock repurchase activities for the years ended December 31, 2025 and 2024 is as follows (in millions, except per share amounts):

[0001596532-26-000013:notes:177]
|  |  | Year Ended December 31, |
|  |  | 2025 |  | 2024 |
| Aggregate purchase price(1) |  | $ | 1,603.1 |  |  | $ | 423.6 |  |
| Shares repurchased |  | 15.9 |  |  | 5.5 |  |
| Average price paid per share(1) |  | $ | 100.63 |  |  | $ | 77.13 |  |

[0001596532-26-000013:notes:178]
(1) Aggregate purchase price and average price paid per share for the year of 2025 include costs associated with the repurchases but exclude the 1% excise tax accrued on our share repurchases as a result of the Inflation Reduction Act of 2022.

[0001596532-26-000013:notes:179]
The aggregate purchase price of repurchased shares of our common stock is recorded as a reduction to retained earnings in our consolidated statements of stockholders' equity. All shares repurchased have been retired.

[0001596532-26-000013:notes:180]
Equity Award Plan Activities

[0001596532-26-000013:notes:181]
2014 Employee Stock Purchase Plan

[0001596532-26-000013:notes:182]
In April 2014, the board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (“ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding as of the preceding December 31. This annual increase is subject to a maximum of 40 million shares and may be reduced or waived at the discretion of the board of directors. As of December 31, 2025, there remained 104.1 million shares available for issuance under the ESPP.

[0001596532-26-000013:notes:183]
Under our ESPP, eligible employees are permitted to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the exercise date. Each offering period lasts approximately two years starting on the first trading date after February 15 and August 15 of each year, and includes purchase dates every six months on or after February 15 and August 15 of each year. Participants may purchase shares of common stock through payroll deductions up to 15% of their eligible compensation, subject to Internal Revenue Service mandated purchase limits.

[0001596532-26-000013:notes:184]
During the year ended December 31, 2025, we issued 0.7 million shares at an average purchase price of $67.27 per share under our ESPP.

[0001596532-26-000013:notes:185]
2014 Equity Incentive Plan

[0001596532-26-000013:notes:186]
On April 16, 2024, our board of directors adopted an amended and restated Arista Networks, Inc. 2014 Equity Plan ("Restated Plan"), effective April 17, 2024 ("Effective Date") subject to the approval of our stockholders, which was approved at the 2024 Annual Meeting of Stockholders on June 7, 2024.

[0001596532-26-000013:notes:187]
The Restated Plan provides for the grant of equity-based awards, including stock options, restricted stock units, restricted stock, stock appreciation rights, and performance awards. The share pool available under the prior version of the Company's 2014 Equity Incentive Plan ("Prior Plan") was extinguished, and the Restated Plan provides for a new share pool not to exceed (i) 52.8 million shares of our Common Stock (“Shares”), plus (ii) any Shares subject to awards under the Prior Plan that, on or after the Effective Date, expired or otherwise terminated without having been exercised in full, or that were forfeited to or repurchased by us, including net settlement of Shares subject to restricted stock units, with the maximum number of

[0001596532-26-000013:notes:188]
Shares to be added to the Restated Plan as a result of clause (ii) equal to 40.2 million Shares. The Restated Plan’s terms are substantially similar to the Prior Plan’s terms, including with respect to treatment of equity awards in the event of a “change in control” as defined under the Restated Plan, but with certain modifications, including the elimination of the automatic “evergreen” share reserve increase provided for under the Prior Plan. As of December 31, 2025, there remained approximately 45.0 million shares available for grant under the Restated Plan.

[0001596532-26-000013:notes:189]
Stock Option Activities

[0001596532-26-000013:notes:190]
The following table summarizes the option activity under our stock plans and related information (in millions, except years and per share amounts):

[0001596532-26-000013:notes:191]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (In Years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2024 |  | 3.1 |  |  | $ | 6.71 |  |  | 1.5 |  | $ | 320.9 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (2.2) |  |  | 4.10 |  |  |  |  |  |
| Options canceled |  | (0.1) |  |  | 14.70 |  |  |  |  |  |
| Balance—December 31, 2025 |  | 0.8 |  |  | $ | 12.93 |  |  | 2.7 |  | $ | 93.3 |  |
| Vested and exercisable—December 31, 2025 |  | 0.8 |  |  | $ | 12.93 |  |  | 2.7 |  | $ | 93.3 |  |

[0001596532-26-000013:notes:192]
We did not grant any stock options during the years ended December 31, 2025, 2024 and 2023. The aggregate intrinsic value of options exercised during the years ended December 31, 2025, 2024 and 2023 was $211.0 million, $495.1 million and $525.3 million, respectively. The total fair value of options vested for the year ended December 31, 2025 was not material. The total fair value of options vested for the years ended December 31, 2024 and 2023 was approximately $5.6 million and $8.7 million, respectively.

[0001596532-26-000013:notes:193]
Restricted Stock Unit (RSU) Activities

[0001596532-26-000013:notes:194]
A summary of the RSU activity is presented below (in millions, except years and per share amounts):

[0001596532-26-000013:notes:195]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |
| Balance—December 31, 2024 |  | 28.6 |  |  | $ | 45.46 |  |
| RSUs granted |  | 10.7 |  |  | 103.34 |  |
| RSUs vested |  | (8.6) |  |  | 37.98 |  |
| RSUs forfeited/canceled |  | (2.6) |  |  | 51.48 |  |
| Unvested balance—December 31, 2025 |  | 28.1 |  |  | $ | 69.81 |  |

[0001596532-26-000013:notes:196]
The weighted-average grant-date fair value of RSUs granted during the years ended December 31, 2025, 2024 and 2023 was $103.34, $72.61 and $39.49 per share, respectively. The total fair value of RSUs vested for the years ended December 31, 2025, 2024 and 2023 was approximately $310.1 million, $251.8 million, and $225.5 million, respectively.

[0001596532-26-000013:notes:197]
Stock-Based Compensation Expense

[0001596532-26-000013:notes:198]
The following table summarizes the stock-based compensation expense related to our equity awards (in millions):

[0001596532-26-000013:notes:199]
|  |  | Year Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Cost of revenue |  | $ | 26.9 |  |  | $ | 15.8 |  |  | $ | 12.8 |  |
| Research and development |  | 260.7 |  |  | 211.8 |  |  | 172.2 |  |
| Sales and marketing |  | 104.1 |  |  | 78.8 |  |  | 71.1 |  |
| General and administrative |  | 47.5 |  |  | 49.0 |  |  | 40.7 |  |
| Total stock-based compensation |  | $ | 439.2 |  |  | $ | 355.4 |  |  | $ | 296.8 |  |

[0001596532-26-000013:notes:200]
Determination of Fair Value

[0001596532-26-000013:notes:201]
We record stock-based compensation on equity awards based on their fair value as of the grant date. We value RSUs at the closing market price of our common stock on the grant date. For option awards and ESPP offerings, we use the Black-Scholes option pricing model to determine fair value. We recognize such costs as compensation expense generally on a straight-line basis over the requisite service period of the award. 
As of December 31, 2025, there were $1.5 billion of unrecognized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 4.3 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-26-000013:notes:202]
Net Income Per Share 
Basic net income per share is computed using the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed using the weighted-average number of shares of common stock outstanding during the period, including potential common shares assuming the dilutive effect of outstanding stock options, restricted stock units, and the employee stock purchase plan using the treasury stock method. Potential common shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share. The following table sets forth the computation of our basic and diluted net income per share attributable to common stockholders, as adjusted to give effect to the Stock Split (in millions, except per share amounts):

[0001596532-26-000013:notes:203]
|  |  | Year Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Net income |  | $ | 3,511.4 |  |  | $ | 2,852.1 |  |  | $ | 2,087.3 |  |
| Basic weighted-average shares outstanding |  | 1,258.0 |  |  | 1,256.3 |  |  | 1,237.4 |  |
| Add weighted-average effects of dilutive securities: |  |  |  |  |  |  |
| Employee equity awards |  | 17.7 |  |  | 24.8 |  |  | 31.1 |  |
| Diluted weighted-average shares outstanding |  | 1,275.7 |  |  | 1,281.1 |  |  | 1,268.5 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 2.79 |  |  | $ | 2.27 |  |  | $ | 1.69 |  |
| Diluted |  | $ | 2.75 |  |  | $ | 2.23 |  |  | $ | 1.65 |  |

[0001596532-26-000013:notes:204]
The following weighted-average outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share attributable to common stockholders because their effects would have been anti-dilutive for the periods presented, as adjusted to give effect to the Stock Split (in millions):

[0001596532-26-000013:notes:205]
|  |  | Year Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Employee equity awards |  | 1.2 |  |  | 0.3 |  |  | 1.0 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-26-000013:notes:206]
Income Taxes
The components of income before provision for income taxes are as follows (in millions):

[0001596532-26-000013:notes:207]
|  |  | Year Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Domestic |  | $ | 3,369.6 |  |  | $ | 2,635.6 |  |  | $ | 1,977.7 |  |
| Foreign |  | 880.1 |  |  | 629.5 |  |  | 444.3 |  |
| Income before income taxes |  | $ | 4,249.7 |  |  | $ | 3,265.1 |  |  | $ | 2,422.0 |  |

[0001596532-26-000013:notes:208]
The components of the provision for income taxes are as follows (in millions):

[0001596532-26-000013:notes:209]
|  |  | Year Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Current provision for income taxes: |  |  |  |  |  |  |
| Federal |  | $ | 785.3 |  |  | $ | 751.3 |  |  | $ | 574.4 |  |
| State |  | 142.9 |  |  | 114.7 |  |  | 106.9 |  |
| Foreign |  | 122.1 |  |  | 39.8 |  |  | 24.2 |  |
| Total current |  | 1,050.3 |  |  | 905.8 |  |  | 705.5 |  |
| Deferred tax expense (benefit): |  |  |  |  |  |  |
| Federal |  | (294.1) |  |  | (504.7) |  |  | (372.3) |  |
| State |  | (46.8) |  |  | (42.8) |  |  | (41.1) |  |
| Foreign |  | 28.9 |  |  | 54.7 |  |  | 42.6 |  |
| Total deferred tax expense (benefit) |  | (312.0) |  |  | (492.8) |  |  | (370.8) |  |
| Total provision for income taxes |  | $ | 738.3 |  |  | $ | 413.0 |  |  | $ | 334.7 |  |

[0001596532-26-000013:notes:210]
We adopted ASU 2023-09 "Income Taxes (Topic 740): Improvements to Income Tax Disclosures" on a prospective basis beginning with the year ended December 31, 2025. The following table presents required disclosure pursuant to ASU

[0001596532-26-000013:notes:211]
2023-09 and reconciles the U.S. federal statutory income tax amount and rate to our total provision for income taxes amount and rate for the year ended December 31, 2025 (in millions except for percentages):

[0001596532-26-000013:notes:212]
|  |  | Year Ended December 31, 2025 |
|  |  | Amount |  | Percent |
| U.S. federal statutory income tax rate |  | $ | 892.4 |  |  | 21.00 | % |
| State tax, net of federal benefit1 |  | 76.3 |  |  | 1.80 |  |
| Foreign Tax Effects |  |  |  |  |
| Ireland |  |  |  |  |
| Statutory tax rate difference between Ireland and US |  | (45.4) |  |  | (1.07) |  |
| Other |  | 12.6 |  |  | 0.30 |  |
| Other jurisdictions |  | (1.4) |  |  | (0.03) |  |
| Enactment of New Tax Laws |  | 22.6 |  |  | 0.53 |  |
| Effect of Cross Border Tax Laws |  |  |  |  |
| Net Controlled Foreign Corporation Tested Income |  | (32.6) |  |  | (0.77) |  |
| Other |  | 2.3 |  |  | 0.05 |  |
| Tax Credits |  |  |  |  |
| Research and Development Tax Credit |  | (54.8) |  |  | (1.29) |  |
| Nontaxable or Nondeductible Items |  |  |  |  |
| Stock-Based Compensation |  | (123.9) |  |  | (2.91) |  |
| Other |  | 1.2 |  |  | 0.02 |  |
| Changes in Unrecognized Tax Benefits |  | (11.0) |  |  | (0.26) |  |
| Total Provision for Income Taxes |  | $ | 738.3 |  |  | 17.37 | % |

[0001596532-26-000013:notes:213]
(1) State taxes in Georgia, Kentucky and Missouri for 2025 made up the majority (greater than 50 percent) of the tax effect in the state tax category.

[0001596532-26-000013:notes:214]
The following table presents the required disclosures prior to our adoption of ASU 2023-09 and reconciles the U.S. federal statutory income tax rate and our effective tax rate for the years ended December 31, 2024 and December 31, 2023 (in percentages):

[0001596532-26-000013:notes:215]
|  |  |  |  | Year Ended December 31, |
|  |  |  |  | 2024 |  | 2023 |
| U.S. federal statutory income tax rate |  |  |  | 21.00 | % |  | 21.00 | % |
| State tax, net of federal benefit |  |  |  | 1.75 |  |  | 2.13 |  |
| Taxes on foreign earnings differential |  |  |  | (2.38) |  |  | (1.96) |  |
| Tax credits |  |  |  | (2.79) |  |  | (2.74) |  |
| Stock-based compensation |  |  |  | (4.96) |  |  | (4.59) |  |
| Other, net |  |  |  | 0.03 |  |  | (0.03) |  |
| Effective tax rate |  |  |  | 12.65 | % |  | 13.81 | % |

[0001596532-26-000013:notes:216]
On July 4, 2025, the OBBB Act was signed into law in the U.S. This legislation contains a broad range of tax reform provisions affecting businesses. The full effects of the legislation on our annual effective tax rate and cash tax position are reflected in our twelve months ended December 31, 2025 period results.

[0001596532-26-000013:notes:217]
Our provision for income taxes and effective tax rate increased for the year ended December 31, 2025, as compared to 2024. The increase in our income taxes was primarily associated with a decrease in tax benefits attributable to equity-based compensation.  Excess tax benefits resulting from stock awards were $159.2 million, $212.3 million and $151.2 million for the years ended December 31, 2025, 2024 and 2023, respectively.

[0001596532-26-000013:notes:218]
The tax effects of temporary differences that give rise to significant portions of deferred tax assets (liabilities) are as follows (in millions) :

[0001596532-26-000013:notes:219]
|  |  | December 31, |
|  |  | 2025 |  | 2024 |
| Deferred tax assets: |  |  |  |  |
| Intangible assets |  | $ | 244.9 |  |  | $ | 273.9 |  |
| Reserves and accruals not currently deductible |  | 146.4 |  |  | 135.2 |  |
| Deferred revenue |  | 1,130.8 |  |  | 566.3 |  |
| Tax credits |  | 134.0 |  |  | 130.2 |  |
| Lease financing obligation |  | 17.7 |  |  | 13.7 |  |
| Capitalized research and development expenses |  | 417.0 |  |  | 634.5 |  |
| Stock-based compensation |  | 53.4 |  |  | 38.6 |  |
| Net operating losses |  | 19.7 |  |  | 25.9 |  |
| Other |  | 2.8 |  |  | 3.6 |  |
| Gross deferred tax assets |  | 2,166.7 |  |  | 1,821.9 |  |
| Valuation allowance |  | (195.8) |  |  | (179.8) |  |
| Total deferred tax assets |  | 1,970.9 |  |  | 1,642.1 |  |
| Deferred tax liabilities: |  |  |  |  |
| US tax on foreign earnings |  | (167.5) |  |  | (189.8) |  |
| Right of use asset |  | (15.7) |  |  | (11.6) |  |
| Other |  | (14.1) |  |  | (0.3) |  |
| Total deferred tax liabilities |  | (197.3) |  |  | (201.7) |  |
| Net deferred tax assets |  | $ | 1,773.6 |  |  | $ | 1,440.4 |  |

[0001596532-26-000013:notes:220]
The change in valuation allowance from December 31, 2024 to December 31, 2025 is substantially attributable to the uncertainty regarding the realizability of state deferred tax assets,

[0001596532-26-000013:notes:221]
As of December 31, 2025, we had $210.1 million and $120.5 million of net operating loss carryforwards for federal and state income tax purposes, respectively, from acquisitions. These federal and state losses will begin to expire in 2028 and 2029, respectively. We do not have any material foreign net operating losses.

[0001596532-26-000013:notes:222]
As of December 31, 2025, our state tax credit carryforwards for income tax purposes before valuation allowances were approximately $257.2 million, which can be carried over indefinitely. We have provided a valuation allowance of $195.8 million for deferred tax assets, primarily related to state carryforwards that we do not believe are more likely than not to be realized.

[0001596532-26-000013:notes:223]
Utilization of the net operating losses and tax credit carryforwards may be subject to limitations due to ownership change limitations provided in the Internal Revenue Code and similar state or foreign provisions.

[0001596532-26-000013:notes:224]
U.S. tax law generally requires U.S. shareholders of a controlled foreign corporation (“CFC”) to include the annual earnings of foreign subsidiaries into U.S. taxable income each year. Correspondingly, most of the undistributed earnings are deemed to be previously taxed for U.S. tax purposes and distributions of the unremitted earnings do not have any significant U.S. federal income tax impact. The determination of the future tax consequences of the remittance of these earnings is not practicable.

[0001596532-26-000013:notes:225]
Income Taxes Paid

[0001596532-26-000013:notes:226]
We have made tax payments and received refunds during the year ended December 31, 2025 as follows (in millions):

[0001596532-26-000013:notes:227]
|  |  | Year Ended December 31, 2025 |
| U.S. Federal |  | $ | 808.0 |  |
| State: |  |  |
| Other |  | 175.2 |  |
| Foreign: |  |  |
| Ireland |  | 90.3 |  |
| Other |  | 22.4 |  |
| Foreign subtotal: |  | 112.7 |  |
| Total cash paid for income taxes (net of refunds) |  | $ | 1,095.9 |  |

[0001596532-26-000013:notes:228]
Uncertain Tax Positions

[0001596532-26-000013:notes:229]
We recognize uncertain tax positions only to the extent that management believes that it is more likely than not that the position will be sustained. The reconciliation of the beginning and ending amount of gross unrecognized tax benefits as of December 31, 2025, 2024 and 2023 is as follows (in millions):

[0001596532-26-000013:notes:230]
|  |  | Year Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Gross unrecognized tax benefits—beginning balance |  | $ | 181.5 |  |  | $ | 163.3 |  |  | $ | 137.4 |  |
| Increases related to tax positions taken in a prior year |  | 8.2 |  |  | 0.3 |  |  | 4.7 |  |
| Increases related to tax positions taken during current year |  | 20.0 |  |  | 52.7 |  |  | 39.9 |  |
| Decreases related to tax positions taken in a prior year |  | (2.6) |  |  | (8.6) |  |  | (0.5) |  |
| Decreases related to lapse of statute of limitations |  | (15.4) |  |  | (26.0) |  |  | (18.2) |  |
| Decreases related to settlements with taxing authorities |  | — |  |  | (0.2) |  |  | — |  |
| Gross unrecognized tax benefits—ending balance |  | $ | 191.7 |  |  | $ | 181.5 |  |  | $ | 163.3 |  |

[0001596532-26-000013:notes:231]
As of December 31, 2025, 2024 and 2023, the total amount of gross unrecognized tax benefits was $191.7 million, $181.5 million and $163.3 million, respectively, of which $100.7 million, $103.4 million and $90.0 million would affect our effective tax rate if recognized.

[0001596532-26-000013:notes:232]
Our policy is to recognize interest and penalties accrued on any unrecognized tax benefits as a component of income tax expense. For the years ended December 31, 2025 and 2024, the net expense for interest and penalties and the recognized liability for interest and penalties were not material. 
The statute of limitations for Federal and most states remains open for 2022 and forward. Some states have net operating loss and tax credit carryforwards, and therefore remain open to examination. Our foreign tax returns, where the statute of limitations have not yet lapsed, are open to audit in the respective foreign countries where the subsidiaries are located.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-26-000013:notes:233]
Segment and Geographical Information 
We operate as one reportable segment. The accounting policies of the reportable segment are the same as those described in the summary of significant accounting policies. The financial information reviewed by the CODM reflects quarterly and year-to-date operating results, with a primary focus on revenue, gross margin, operating margin and net income as reported on the consolidated statements of income. Consolidated financial information is used by the CODM to evaluate performance and make decisions regarding resource allocation and other strategic initiatives. This consolidated financial information is also what is used to establish and approve operating budgets and forecasts. The measure of segment assets is reported on the consolidated balance sheets in total. There was no change for each of the periods presented in the measurement methods used to determine reported segment profit and loss.

[0001596532-26-000013:notes:234]
The CODM reviews the following significant segment expenses, which are presented separately on the Company’s consolidated statements of income: cost of revenue and operating expenses. Other segment items that are included in the calculation of the Company’s net income include other income (expense), net, which is further described in Note 3. Financial Statements Details and income taxes, which is further described in Note 8. Income Taxes. Other segment disclosures such as depreciation and amortization and stock-based compensation are disclosed in the Consolidated Statements of Cash Flows.

[0001596532-26-000013:notes:235]
The following table represents revenue based on customers' shipping addresses (in millions):

[0001596532-26-000013:notes:236]
|  |  | Year Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Americas(1) |  | $ | 7,122.1 |  |  | $ | 5,729.0 |  |  | $ | 4,651.2 |  |
| Europe, Middle East and Africa |  | 1,070.3 |  |  | 713.2 |  |  | 671.0 |  |
| Asia Pacific |  | 813.3 |  |  | 560.9 |  |  | 538.0 |  |
| Total revenue |  | $ | 9,005.7 |  |  | $ | 7,003.1 |  |  | $ | 5,860.2 |  |

[0001596532-26-000013:notes:237]
(1) Includes $7,063.8 million, $5,663.0 million and $4,541.5 million revenue generated from the U.S. for the three years ended December 31, 2025, 2024 and 2023, respectively

[0001596532-26-000013:notes:238]
Long-lived assets, excluding intercompany receivables, investments in subsidiaries, investments in privately-held companies and deferred tax assets, net by location are summarized as follows (in millions):

[0001596532-26-000013:notes:239]
|  |  | December 31, |
|  |  | 2025 |  | 2024 |
| United States |  | $ | 184.8 |  |  | $ | 83.5 |  |
| International |  | 18.3 |  |  | 15.3 |  |
| Total |  | $ | 203.1 |  |  | $ | 98.8 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001596532-26-000013:notes:240]
On November 14, 2025, Jayshree Ullal, our Chairperson and Chief Executive Officer, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of: (i) up to 5,726,000 shares of our common stock; and (ii) a number of shares of our common stock that may be earned in connection with grants of performance-based restricted stock units, which cannot be determined at this time. The duration of the trading arrangement is until February 20, 2027, or earlier if all transactions under the trading arrangement are completed. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c).

[0001596532-26-000013:notes:241]
On November 21, 2025, Yvonne Wassenaar, a member of our Board of Directors, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of up to an aggregate of 5,576 shares of our common stock. The duration of the trading arrangement is until February 26, 2027, or earlier if all transactions under the trading arrangement are completed. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c).

[0001596532-26-000013:notes:242]
On December 11, 2025, Chantelle Breithaupt, our Senior Vice President and Chief Financial Officer, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of a number of shares of our common stock that may be earned in connection with grants of performance-based restricted stock units, which cannot be determined at this time. The duration of the trading arrangement is until December 31, 2026, or earlier if all transactions under the trading arrangement are completed. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c).
