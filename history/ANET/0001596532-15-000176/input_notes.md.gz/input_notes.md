# ANET notes — 0001596532-15-000176


## anet:ConcentrationRiskComponentsSupplierRiskPolicyTextBlock

[0001596532-15-000176:notes:1]
We work closely with third-party contract manufacturing suppliers to manufacture our products. As of September 30, 2015 and December 31, 2014, two suppliers provided essentially all of our electronic manufacturing services. Our contract manufacturing suppliers deliver our products to one of three third party direct fulfillment facilities where our EOS software is installed on our products.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers. Our products rely on key components, including certain integrated circuit components and power supplies, some of which our contract manufacturers purchase on our behalf from a limited number of suppliers, including certain sole source providers. We do not have guaranteed supply contracts with any of our component suppliers, and our suppliers could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, sales of our products could be delayed or halted entirely or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001596532-15-000176:notes:2]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (" U.S. GAAP") and following the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by U.S. GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2015, are not necessarily indicative of the results expected for the full fiscal year.

[0001596532-15-000176:notes:3]
[same as prior period, unchanged from 0001596532-15-000112:notes:3]

[0001596532-15-000176:notes:4]
[same as prior period, unchanged from 0001596532-15-000112:notes:4]

[0001596532-15-000176:notes:5]
[same as prior period, unchanged from 0001596532-15-000112:notes:5]

[0001596532-15-000176:notes:6]
[same as prior period, unchanged from 0001596532-15-000112:notes:7]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-15-000176:notes:7]
Commitments and Contingencies

[0001596532-15-000176:notes:8]
Operating Leases

[0001596532-15-000176:notes:9]
We lease various operating spaces in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2024. These arrangements require us to pay certain operating expenses, such as taxes, repairs, and insurance and contain renewal and escalation clauses. We recognize rent expense under these arrangements on a straight-line basis over the term of the lease.

[0001596532-15-000176:notes:10]
Rent expense for all operating leases amounted to $2.0 million, $4.7 million, $0.8 million and $2.5 million for the three and nine months ended September 30, 2015 and 2014, respectively.

[0001596532-15-000176:notes:11]
Financing Obligation—Build-to-Suit Lease

[0001596532-15-000176:notes:12]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013.

[0001596532-15-000176:notes:13]
Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction such as our financial involvement in structural elements of asset construction, making decisions related to tenant improvement costs and purchasing insurance not reimbursable by the buyer-lessor (the "Landlord"), we are deemed the owner of the building (for accounting purposes only) during the construction period. We continue to maintain involvement in the property post construction completion and lack transferability of the risks and rewards of ownership, due to our required maintenance of a $4.0 million letter of credit, in addition to our ability and option to sublease our portion of the leased building for fees substantially higher than our base rate. Due to our continued involvement in the property and lack of transferability of related risks and rewards of ownership to the Landlord post construction, we account for the building and related improvements as a lease financing obligation. Accordingly, as of September 30, 2015 and December 31, 2014, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $42.9 million and $43.6 million, respectively. As of September 30, 2015, $1.3 million and $41.6 million were recorded as short-term and long-term financing obligations, respectively.

[0001596532-15-000176:notes:14]
Land lease expense under our lease financing obligation included in rent expense above, amounted to $0.3 million, $1.0 million, $0.3 million and $0.9 million for the three and nine months ended September 30, 2015 and 2014, respectively.

[0001596532-15-000176:notes:15]
Upon completion of construction in the third quarter of 2013, we evaluated the de-recognition of the asset and liability under the sale-leaseback accounting guidance. We concluded that we have forms of continued economic involvement in the facility, and therefore did not meet with the provisions for sale-leaseback accounting. Therefore, the lease is accounted for as a financing obligation and lease payments will be attributed to (1) a reduction of the principal financing obligation; (2) imputed interest expense; and (3) land lease expense (which is considered an operating lease and a component of cost of goods sold and operating expenses) representing an imputed cost to lease the underlying land of the building. In addition, the underlying building asset is depreciated over the building’s estimated useful life of 30 years. At the conclusion of the initial lease term, we will de-recognize both the net book values of the asset and the remaining financing obligation.

[0001596532-15-000176:notes:16]
Purchase Commitments

[0001596532-15-000176:notes:17]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. These forecasts are based on estimates of future demand for our products, historical trend analysis provided by our sales and product marketing organizations and adjusted for overall market conditions. We incur a liability when the contract manufacturer has converted the component inventory to a finished product. However, historically we have reimbursed our contract manufacturer and component suppliers for component inventory purchases when this inventory has been rendered excess or obsolete due to manufacturing and engineering change orders resulting from design changes, or in cases where inventory levels greatly exceed our forecasts. As of September 30, 2015 and December 31, 2014, we have recorded $4.5 million and $0.3 million related to the excess and obsolete component of our inventory liability to our contract manufacturers and vendors.  We have provided restricted deposits to our third-party contract manufacturers and vendors to secure our obligations to purchase inventory. We had $2.3 million in restricted deposits as of September 30, 2015 and December 31, 2014. Restricted deposits are classified in other assets in our accompanying unaudited condensed consolidated balance sheets.

[0001596532-15-000176:notes:18]
Guarantees

[0001596532-15-000176:notes:19]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers the unamortized value of the product based on its estimated useful life. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for lease facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-15-000176:notes:20]
Legal Proceedings

[0001596532-15-000176:notes:21]
OptumSoft, Inc. Matters

[0001596532-15-000176:notes:22]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-15-000176:notes:23]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft copies of certain components of our software for evaluation by OptumSoft, (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches, (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers, (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us, and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dtd July 27, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.

[0001596532-15-000176:notes:24]
OptumSoft has identified in confidential documents certain software components it claims to own, which are generally applicable tools and utility subroutines and not networking specific code. We cannot assure which software components OptumSoft may ultimately claim to own in the litigation or whether such claimed components are material.

[0001596532-15-000176:notes:25]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we assert our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we assert that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We ask the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also assert that, even if we are found not to own any particular components at issue, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation. On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have meritorious defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-15-000176:notes:26]
The parties tried the case for Phase I of the proceedings, relating to contract interpretation and application of the contract to certain claimed source code in September 2015.  A court decision for Phase I of the proceedings is expected by November 2015. The remaining issues are currently scheduled to be tried in April 2016.

[0001596532-15-000176:notes:27]
We intend to vigorously defend against any action brought against us by OptumSoft. However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor. For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft. If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license. An adverse litigation ruling could result in a significant damages award against us and injunctive relief. In addition, OptumSoft could assert additional or different claims against us, including claims that our license from OptumSoft is invalid.

[0001596532-15-000176:notes:28]
Additionally, the existence of this lawsuit could cause concern among our customers and potential customers and could adversely affect our business and results of operations. An adverse litigation ruling could also result in a significant damages award against us and the injunctive relief described above. In addition, if our license was ruled to have been terminated, and we were not able to negotiate a new license from OptumSoft on reasonable terms, we could be prohibited from selling products that incorporate OptumSoft intellectual property. Any such adverse ruling could materially adversely affect our business, prospects, results of operations and financial condition. Whether or not we prevail in a lawsuit, we expect that any litigation would be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-15-000176:notes:29]
Cisco Systems, Inc. (“Cisco”) Matters

[0001596532-15-000176:notes:30]
On December 5, 2014, Cisco filed two complaints against us in District Court for the Northern District of California, which are proceeding as Case No. 4:14-cv-05343 (“’43 Case”) and Case No. 5:14-cv-05344 (“’44 Case”).  In the ’43 Case, Cisco alleges that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the 875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”).  Cisco seeks, as relief for our alleged infringement in the ’43 Case, lost profits and/or reasonable royalty damages in an unspecified amount, including treble damages, attorney’s fees, and associated costs.  Cisco also seeks injunctive relief in the ’43 Case.  On February 10, 2015, the court granted our unopposed motion to stay the ’43 Case until the proceedings before the United States International Trade Commission (“USITC”) pertaining to the same patents (as discussed below) become final.  In the ’44 Case, Cisco’s complaint alleges that we infringe U.S. Patent Nos. 7,047,526 and 7,953,886 and further alleges that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI.”  As relief for our alleged patent infringement in the ’44 Case, Cisco seeks lost profits and/or reasonable royalty damages in an unspecified amount including treble damages, attorney’s fees, and associated costs as well as injunctive relief.  As relief from our alleged copyright infringement, Cisco seeks damages in an unspecified amount in the form of alleged lost profits, profits from our alleged infringement, statutory damages, attorney’s fees and associated costs.  Cisco also seeks injunctive relief against our alleged copyright infringement.  On February 13, 2015, we answered the complaint in the ’44 Case, denying the patent and copyright infringement allegations and also raising numerous affirmative defenses.  On March 6, 2015, Cisco filed an amended complaint against us the ’44 Case.  In response, we moved to dismiss Cisco’s allegations of willful patent infringement and pre-suit indirect patent infringement. The Court granted the motion with leave to amend on July 2, 2015.  On July 23, 2015, Cisco filed an amended complaint.  Trial has been set for August 1, 2016 in the ’44 Case.  Trial has not been scheduled in the ’43 Case.

[0001596532-15-000176:notes:31]
On December 19, 2014, Cisco filed two complaints against us in the USITC alleging that Arista has violated section 337 of the Tariff Act of 1930, as amended.  The complaints have been instituted as ITC Inv. Nos. 337-TA-944 (“944 Investigation”) and 337-TA-945 (“945 Investigation”).  In the 944 Investigation, Cisco initially alleged that certain Arista switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents.  Cisco has subsequently dropped the '296 patent from the 944 Investigation. In the 945 Investigation, Cisco alleges that certain Arista switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents.  In both the 944 and 945 Investigations, Cisco seeks, among other things, a limited exclusion order barring entry into the United States of accused switch products (including 7000 Series of switches) and a cease and desist order against us restricting our activities with respect to our imported accused switch products.  On February 11, 2015, we responded to the notices of investigation and complaints in the 944 and 945 Investigations by, among other things, denying any violation of section 337 of the Tariff Act and the patent infringement allegations, and raising numerous additional defenses.

[0001596532-15-000176:notes:32]
The Administrative Law Judge assigned to the 944 Investigation issued a procedural schedule calling for, among other events:  an evidentiary hearing on Sept. 9-11 & 15-17, 2015; issuance of an initial determination regarding our alleged violations on January 27, 2016; and the target date for completion on May 27, 2016. The final determination in the 944 Investigation is then subject to Presidential review. The hearing has been completed and all post trial briefs have been submitted to the ITC.

[0001596532-15-000176:notes:33]
The Administrative Law Judge assigned to the 945 Investigation issued a procedural schedule calling for, among other events:  issuance of an order construing the claims of the ’577, ’853, ’875, ’668, ’492, and ’211 patents tentatively on July 17, 2015; an evidentiary hearing on November 9-20, 2015; issuance of an initial determination regarding our alleged violations on April 26, 2016; and the target date for completion on August 26, 2016. The final determination in the 945 Investigation is then subject to Presidential review. To date, the Administrative Law Judge has not issued an order construing the claims in the 945 Investigation.

[0001596532-15-000176:notes:34]
On April 1, 2015, we filed petitions for Inter Partes Review with the United States Patent Trial and Appeal Board (“PTAB”) seeking to invalidate Cisco’s ’597, ’211, and ’668 patents.  On April 10, 2015, we filed petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853 and ’577 patents.  On April 16, 2015, we filed additional petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853 and ’577 patents.  On August 11, 2015, we filed a second petition for Inter Partes Review of Cisco’s ’668 patent.  On October 6, 2015 we filed a second petition for Inter Partes Review of Cisco’s ’211 patent.  On October 6, 2015, the PTAB granted our petitions for Inter Partes Review of Cisco’s ’597 and ’211 patents but denied one of our petitions for Inter Partes Review of Cisco’s ’668 patent. On October 19, 2015 and October 22, 2015, the PTAB denied four petitions relating to the ‘853 and ‘577 patents. We are awaiting decisions by the PTAB on our remaining petitions for Inter Partes Review of the ’668  patent.  For those petitions that PTAB grants, the PTAB must issue its final written decision on validity within twelve months of its institution decision.

[0001596532-15-000176:notes:35]
We intend to vigorously defend against Cisco’s lawsuits, as summarized in the preceding paragraphs.  However, we cannot be certain that, if litigated, any claims by Cisco would be resolved in our favor.  For example, an adverse litigation ruling could result in a significant damages award against us, could further result in the above described injunctive relief (including, among other things, an order excluding our products from importation into the United States), could result in a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products to the extent that we are found to infringe any valid claims asserted against us by Cisco. In particular, with respect to the 944 and 945 Investigations, if our products are found to infringe any patents that are the subject of those investigations, the USITC would likely issue a limited exclusion order barring entry into the United States of accused switch products (including 7000 Series of switches) and a cease and desist order restricting our activities with respect to our imported accused switch products. In the case that we attempt to modify our manufacturing and importation processes to comply with such orders, we may not be able to do so successfully or without substantial expense. Moreover, to the extent we are found to infringe on any valid claims asserted against us, and attempt to modify our products so that they are no longer infringing, we may not be able to do so successfully without substantial distraction to management or expense, if at all, and any such modified products may not be well received in the market.  Any such adverse ruling could materially adversely affect our business, prospects, results of operation and financial condition.  To the extent that we reached a negotiated settlement with Cisco, the settlement could require payment of substantial royalties.  Additionally, the existence of this lawsuit could cause concern among our customers and potential customers and could adversely affect our business and results of operations.  Whether or not we prevail in the lawsuit, we expect that the litigation will be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-15-000176:notes:36]
With respect to the various legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated at this time.  However, the outcome of litigation is inherently uncertain. Therefore, if one or more of these legal matters were resolved against us in a reporting period for amounts in excess of management’s expectations, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-15-000176:notes:37]
Other Matters

[0001596532-15-000176:notes:38]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. Based on currently available information, management does not believe that liability relating to these other unresolved matters is probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001596532-15-000176:notes:39]
[same as prior period, unchanged from 0001596532-15-000112:notes:39]

[0001596532-15-000176:notes:40]
|  | September 30, 2015 |  | December 31, 2014 |
| Liability for early exercised shares subject to repurchase | $ | 2,781 |  |  | $ | 4,616 |  |
| Sales tax payable | 4,308 |  |  | 3,101 |  |
| Lease financing obligations, current portion | 1,269 |  |  | 1,087 |  |
| Other | 1,402 |  |  | 2,445 |  |
| Total other current liabilities | $ | 9,760 |  |  | $ | 11,249 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-15-000176:notes:41]
[same as prior period, unchanged from 0001596532-15-000112:notes:41]

[0001596532-15-000176:notes:42]
[same as prior period, unchanged from 0001596532-15-000112:notes:42]

[0001596532-15-000176:notes:43]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cost of revenue | $ | 786 |  |  | $ | 480 |  |  | $ | 2,206 |  |  | $ | 992 |  |
| Research and development | 7,037 |  |  | 4,304 |  |  | 18,344 |  |  | 10,298 |  |
| Sales and marketing | 2,864 |  |  | 2,387 |  |  | 8,138 |  |  | 5,746 |  |
| General and administrative | 1,591 |  |  | 911 |  |  | 3,637 |  |  | 2,533 |  |
| Total stock-based compensation | $ | 12,278 |  |  | $ | 8,082 |  |  | $ | 32,325 |  |  | $ | 19,569 |  |

[0001596532-15-000176:notes:44]
[same as prior period, unchanged from 0001596532-15-000112:notes:44]

[0001596532-15-000176:notes:45]
[same as prior period, unchanged from 0001596532-15-000112:notes:45]

[0001596532-15-000176:notes:46]
|  |  |  | Options and RSAs Outstanding |  |  |  |  |
|  | Shares Available for Grant(in thousands) |  | Number of Shares UnderlyingOutstanding Options and RSAs (in thousands) |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding (in thousands) |
| Outstanding—December 31, 2014 | 11,612 |  |  | 13,654 |  |  | $ | 17.63 |  |  | 8.3 |  | $ | 598,775 |  |
| Options granted | (1,207 | ) |  | 1,207 |  |  | 66.69 |  |  |  |  |  |
| Options exercised | — |  |  | (1,961 | ) |  | 7.46 |  |  |  |  |  |
| Options canceled | 830 |  |  | (830 | ) |  | 20.72 |  |  |  |  |  |
| Early exercised shares repurchased | 17 |  |  | — |  |  | 3.94 |  |  |  |  |  |
| Outstanding—September 30, 2015 | 11,252 |  |  | 12,070 |  |  | $ | 23.97 |  |  | 7.9 |  | $ | 464,808 |  |
| Vested and exercisable—September 30, 2015 |  |  | 3,473 |  |  | $ | 7.77 |  |  | 6.8 |  | $ | 186,016 |  |
| Vested and expected to vest—September 30, 2015 |  |  | 11,083 |  |  | $ | 22.91 |  |  | 7.8 |  | $ | 437,637 |  |

[0001596532-15-000176:notes:47]
As of September 30, 2015, the total unrecognized stock-based compensation expense related to unvested stock options, net of expected forfeitures, was $116.4 million, which is expected to be recognized over a weighted-average period of 4.1 years.

[0001596532-15-000176:notes:48]
[same as prior period, unchanged from 0001596532-15-000112:notes:49]

[0001596532-15-000176:notes:49]
For the nine months ended September 30, 2015, we repurchased 17,000 shares of common stock at the original exercise price due to the termination of the holders of the unvested shares. As of September 30, 2015, shares held by employees and directors that were subject to repurchase were approximately $0.8 million with an aggregate price of $2.8 million.

[0001596532-15-000176:notes:50]
[same as prior period, unchanged from 0001596532-15-000112:notes:51]

[0001596532-15-000176:notes:51]
[same as prior period, unchanged from 0001596532-15-000112:notes:52]

[0001596532-15-000176:notes:52]
|  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2014 | 108 |  |  | $ | 75.56 |  |  | 2.0 |  | $ | 6,557 |  |
| RSUs granted | 607 |  |  | 71.01 |  |  |  |  |  |
| RSUs vested | (12 | ) |  | 74.52 |  |  |  |  |  |
| RSUs forfeited/canceled | (20 | ) |  | 72.23 |  |  |  |  |  |
| Unvested balance—September 30, 2015 | 683 |  |  | $ | 71.63 |  |  | 2.0 |  | $ | 41,782 |  |
| RSUs expected to vest—September 30, 2015 | 619 |  |  |  |  | 1.9 |  | $ | 37,877 |  |

[0001596532-15-000176:notes:53]
As of September 30, 2015, there was $39.6 million of unrecognized stock-based compensation cost related to unvested RSUs, net of estimated forfeitures. This amount is expected to be recognized over a weighted-average period of 3.8 years.

[0001596532-15-000176:notes:54]
[same as prior period, unchanged from 0001596532-15-000112:notes:55]

[0001596532-15-000176:notes:55]
During the nine months ended September 30, 2015, we issued 247,385 shares at an average purchase price of $37.86 under the 2014 Employee Stock Purchase Plan, or ESPP. On February 17, 2015, the board authorized an increase to shares available for future issuance under the ESPP.  Per the ESPP, the increase is determined based on the lesser of 1% of total shares outstanding as of the first day of each fiscal year, or January 1, 2015, 2,500,000 shares or such amount as determined by our board of directors. The approved increase amounted to 655,139 shares. As of September 30, 2015, there remain 1,058,754 shares available for issuance under the ESPP.

[0001596532-15-000176:notes:56]
As of September 30, 2015, the total unrecognized stock-based compensation expense related to unvested ESPP options, net of expected forfeitures, was $1.9 million, which is expected to be recognized over a weighted-average period of 1.3 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-15-000176:notes:57]
[same as prior period, unchanged from 0001596532-15-000112:notes:58]

[0001596532-15-000176:notes:58]
[same as prior period, unchanged from 0001596532-15-000112:notes:59]

[0001596532-15-000176:notes:59]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Numerator: |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |
| Net income | $ | 28,690 |  |  | $ | 21,866 |  |  | $ | 77,178 |  |  | $ | 55,813 |  |
| Less: undistributed earnings allocated to participating securities | (389 | ) |  | (681 | ) |  | (1,314 | ) |  | (15,257 | ) |
| Net income available to common stockholders, basic | $ | 28,301 |  |  | $ | 21,185 |  |  | $ | 75,864 |  |  | $ | 40,556 |  |
| Diluted: |  |  |  |  |  |  |  |
| Net income attributable to common stockholders, basic | $ | 28,301 |  |  | $ | 21,185 |  |  | $ | 75,864 |  |  | $ | 40,556 |  |
| Add: undistributed earnings allocated to participating securities | 28 |  |  | 70 |  |  | 103 |  |  | 1,353 |  |
| Net income attributable to common stockholders, diluted | $ | 28,329 |  |  | $ | 21,255 |  |  | $ | 75,967 |  |  | $ | 41,909 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 66,629 |  |  | 62,402 |  |  | 65,609 |  |  | 43,453 |  |
| Diluted: |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 66,629 |  |  | 62,402 |  |  | 65,609 |  |  | 43,453 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options and RSUs | 5,163 |  |  | 7,161 |  |  | 5,529 |  |  | 5,795 |  |
| Employee stock purchase plan | 95 |  |  | 174 |  |  | 94 |  |  | 75 |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted | 71,887 |  |  | 69,737 |  |  | 71,232 |  |  | 49,323 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 0.42 |  |  | $ | 0.34 |  |  | $ | 1.16 |  |  | $ | 0.93 |  |
| Diluted | $ | 0.39 |  |  | $ | 0.30 |  |  | $ | 1.07 |  |  | $ | 0.85 |  |

[0001596532-15-000176:notes:60]
[same as prior period, unchanged from 0001596532-15-000112:notes:61]

[0001596532-15-000176:notes:61]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Stock options and RSUs to purchase common stock | 2,544 |  |  | 120 |  |  | 2,275 |  |  | 1,480 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-15-000176:notes:62]
[same as prior period, unchanged from 0001596532-15-000112:notes:63]

[0001596532-15-000176:notes:63]
|  | September 30, 2015 |
|  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 105,164 |  |  | $ | — |  |  | $ | — |  |  | $ | 105,164 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| U.S. government notes | 150,117 |  |  | — |  |  | — |  |  | 150,117 |  |
| Total financial assets | $ | 255,281 |  |  | $ | — |  |  | $ | — |  |  | $ | 255,281 |  |

[0001596532-15-000176:notes:64]
[same as prior period, unchanged from 0001596532-15-000112:notes:65]


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-15-000176:notes:65]
[same as prior period, unchanged from 0001596532-15-000112:notes:66]

[0001596532-15-000176:notes:66]
[same as prior period, unchanged from 0001596532-15-000112:notes:67]

[0001596532-15-000176:notes:67]
[same as prior period, unchanged from 0001596532-15-000112:notes:68]

[0001596532-15-000176:notes:68]
[same as prior period, unchanged from 0001596532-15-000112:notes:69]

[0001596532-15-000176:notes:69]
[same as prior period, unchanged from 0001596532-15-000112:notes:70]

[0001596532-15-000176:notes:70]
[same as prior period, unchanged from 0001596532-15-000112:notes:71]

[0001596532-15-000176:notes:71]
Our financial instruments recorded at fair value on a recurring basis consist of Level I assets that include highly liquid money market funds that are included in cash and cash equivalents and U.S. government notes classified as marketable securities. We did not have any Level II or Level III financial instruments recorded at fair value on a recurring basis as of September 30, 2015 and December 31, 2014.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-15-000176:notes:72]
[same as prior period, unchanged from 0001596532-15-000112:notes:73]

[0001596532-15-000176:notes:73]
Provision for income taxes was approximately $1.9 million and $10.4 million for the three months ended September 30, 2015 and 2014 respectively, and $20.3 million and $27.6 million for the nine months ended September 30, 2015 and 2014, respectively. The change in our provision for income taxes was primarily due to the release of unrecognized tax benefits and related interest as a result of statute of limitation expiring in certain domestic jurisdictions.  The change in the provision was also a result of an increase in profit before income taxes and a decrease in the effective tax rate based on our current geographical distribution of the earnings.

[0001596532-15-000176:notes:74]
[same as prior period, unchanged from 0001596532-15-000112:notes:76]

[0001596532-15-000176:notes:75]
Uncertain Tax Positions

[0001596532-15-000176:notes:76]
We recognize uncertain tax positions only to the extent that management believes that it is more likely than not the position will be sustained.  In the three months ended September 30, 2015, the statute of limitations expired related to several unrecognized tax benefits for our domestic filings. This expiration of the statute provides that certain portions of these unrecognized tax benefits can no longer result in a tax liability to the taxing jurisdictions.  Associated with this statute lapse in the current quarter we have recognized a benefit of approximately $5.8 million.

[0001596532-15-000176:notes:77]
The reconciliation of the beginning and ending amount of gross unrecognized tax benefits for the nine months ended September 30, 2015 was as follows (in thousands):

[0001596532-15-000176:notes:78]
|  | Nine Months Ended September 30, |
|  | 2015 |
| Gross unrecognized tax benefits-beginning balance | $ | 21,322 |  |
| Increases related to tax positions taken in a prior year | 99 |  |
| Increases related to tax positions taken during current year | 51 |  |
| Decreases related to tax positions taken in a prior year | — |  |
| Decreases related to settlements with taxing authorities | — |  |
| Decreases related to lapse of statute of limitations | (5,786 | ) |
| Gross unrecognized tax benefits-ending balance | $ | 15,686 |  |

[0001596532-15-000176:notes:79]
There were no material movements in our unrecognized tax position for the nine months ended September 30, 2014. Our gross unrecognized tax benefits were $15.7 million as of September 30, 2015. If the gross unrecognized tax benefits as of September 30, 2015 were realized in future periods, this would result in a tax benefit of $10.1 million within our provision of income taxes.

[0001596532-15-000176:notes:80]
Our policy is to recognize interest and penalties accrued on any unrecognized tax benefits as a component of income tax expense.  Due to the lapsing of statute of limitation, we have recorded a net benefit for interest of $0.5 million for the nine months ended September 30, 2015. As of September 30, 2015 and December 31, 2014, we recognized a liability for interest and penalties of $1.0 million and $1.5 million, respectively.

[0001596532-15-000176:notes:81]
Because of the net operating loss and tax credit carryforwards, substantially all of our tax years remain open to federal and state tax examination. The majority of our foreign tax returns are open to audit under the statute of limitations of the respective foreign countries, in which the subsidiaries are located.  However, it is possible that unrecognized tax benefits may decrease in the future as the statute of limitation lapses in some of the jurisdictions over the next 12 months.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001596532-15-000176:notes:82]
[same as prior period, unchanged from 0001596532-15-000112:notes:78]

[0001596532-15-000176:notes:83]
[same as prior period, unchanged from 0001596532-15-000112:notes:79]

[0001596532-15-000176:notes:84]
We have equity investments of approximately $33.6 million in privately-held companies which are accounted for under the cost method. There were no impairments recognized on our investments for the three and nine months ended September 30, 2015 as there were no significant identified events or changes in circumstances that would be considered an indicator for impairment.

[0001596532-15-000176:notes:85]
[same as prior period, unchanged from 0001596532-15-000112:notes:81]

[0001596532-15-000176:notes:86]
We have a $3.0 million promissory note from a privately-held company which was recorded at cost. The interest rate on the promissory note is 8.0% per annum and is payable quarterly. All unpaid principal and accrued interest on the promissory note is due and payable on the earlier of August 26, 2017 or upon a default.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-15-000176:notes:87]
In May 2014, the FASB issued ASU No. 2014-09, Revenue From Contracts With Customers, which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition. In July 2015, the FASB deferred the effective date of the new revenue standard by one year. The standard is now effective for fiscal years (and interim reporting periods within those years) beginning after December 15, 2017.  The guidance is effective for us for our first quarter of fiscal 2018. Early adoption would be permitted for all entities but not before the original public entity effective date. The standard permits the use of either the retrospective or cumulative effect transition method. The retrospective method requires a retrospective approach to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance. The cumulative approach requires a retrospective approach with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance. We are currently reviewing the provisions of the standard and have not yet selected a transition method nor have we determined the effect of the standard on our consolidated financial statements.

[0001596532-15-000176:notes:88]
In April 2015, the FASB issued ASU No. 2015-05, Intangibles—Goodwill and Other—Internal-Use Software, which  clarifies the circumstances under which a cloud computing customer would account for the arrangement as a license of internal-use software. A cloud computing arrangement would include a software license if (1) the customer has a contractual right to take possession of the software at any time during the hosting period without significant penalty and (2) it is feasible for the customer to either run the software on its own hardware or contract with another party unrelated to the vendor to host the software. If the arrangement does not contain a software license, it would be accounted for as a service contract. The guidance is effective for fiscal years beginning after December 15, 2015. The standard is effective for us for our first quarter of fiscal 2016. Early adoption is permitted. The guidance can be applied retrospectively to each prior reporting period presented or prospectively to arrangements entered into, or materially modified, after the effective date. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

[0001596532-15-000176:notes:89]
In July 2015, the FASB issued ASU No, 2015-11, Inventory: Simplifying the Measurement of Inventory, which simplifies the measurement of inventory to be measured at the lower of cost or net realizable value. The guidance applies to inventory measured using First in First Out ("FIFO") or average cost. The guidance is effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. The standard is effective for us for our first quarter of fiscal 2017.  The guidance can be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-15-000176:notes:90]
[same as prior period, unchanged from 0001596532-15-000112:notes:86]

[0001596532-15-000176:notes:91]
[same as prior period, unchanged from 0001596532-15-000112:notes:87]

[0001596532-15-000176:notes:92]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our” or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprises. Our cloud networking solutions consist of our Extensible Operating System, a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switches. We were incorporated in October 2004 in the State of California under the name Arastra, Inc. In March 2008, we reincorporated in the State of Nevada and in October 2008 changed our name to Arista Networks, Inc. We reincorporated in the state of Delaware in March 2014. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-15-000176:notes:93]
[same as prior period, unchanged from 0001596532-15-000112:notes:89]

[0001596532-15-000176:notes:94]
[same as prior period, unchanged from 0001596532-15-000112:notes:90]

[0001596532-15-000176:notes:95]
[same as prior period, unchanged from 0001596532-15-000112:notes:91]

[0001596532-15-000176:notes:96]
[same as prior period, unchanged from 0001596532-15-000112:notes:92]

[0001596532-15-000176:notes:97]
[same as prior period, unchanged from 0001596532-15-000112:notes:93]

[0001596532-15-000176:notes:98]
[same as prior period, unchanged from 0001596532-15-000112:notes:94]

[0001596532-15-000176:notes:99]
[same as prior period, unchanged from 0001596532-15-000112:notes:95]

[0001596532-15-000176:notes:100]
[same as prior period, unchanged from 0001596532-15-000112:notes:96]

[0001596532-15-000176:notes:101]
[same as prior period, unchanged from 0001596532-15-000112:notes:97]

[0001596532-15-000176:notes:102]
We have reclassified deferred cost of revenue from inventories to other current assets as of June 30, 2015 as the balance does not represent property available for sale or used in the production process.  Commencing in the first quarter of fiscal 2015, we have disaggregated total revenue and cost of revenue into "Product" and "Service". Prior period balances have been reclassified to conform to this new presentation.

[0001596532-15-000176:notes:103]
[same as prior period, unchanged from 0001596532-15-000112:notes:99]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001596532-15-000176:notes:104]
[same as prior period, unchanged from 0001596532-15-000112:notes:100]

[0001596532-15-000176:notes:105]
|  | September 30, 2015 |  | December 31, 2014 |
| Equipment and machinery | $ | 25,434 |  |  | $ | 18,265 |  |
| Computer hardware and software | 11,223 |  |  | 7,772 |  |
| Furniture and fixtures | 1,880 |  |  | 1,373 |  |
| Leasehold improvements | 23,710 |  |  | 19,420 |  |
| Building | 35,154 |  |  | 35,154 |  |
| Construction-in-process | 4,349 |  |  | 6,532 |  |
| Property and equipment, gross | 101,750 |  |  | 88,516 |  |
| Less: accumulated depreciation | (26,502 | ) |  | (16,958 | ) |
| Property and equipment, net | $ | 75,248 |  |  | $ | 71,558 |  |


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001596532-15-000176:notes:106]
[same as prior period, unchanged from 0001596532-15-000112:notes:102]

[0001596532-15-000176:notes:107]
|  | September 30, 2015 |  | December 31, 2014 |
| Accounts receivable | $ | 162,479 |  |  | $ | 100,076 |  |
| Allowance for doubtful accounts | (1,679 | ) |  | (1,063 | ) |
| Sales return reserve | (570 | ) |  | (2,031 | ) |
| Accounts receivable, net | $ | 160,230 |  |  | $ | 96,982 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001596532-15-000176:notes:108]
[same as prior period, unchanged from 0001596532-15-000112:notes:104]

[0001596532-15-000176:notes:109]
|  | September 30, 2015 |  | December 31, 2014 |
| Accrued payroll related costs | $ | 27,347 |  |  | $ | 30,749 |  |
| Accrued warranty costs | 4,791 |  |  | 3,204 |  |
| Accrued manufacturing costs | 8,207 |  |  | 1,089 |  |
| Accrued professional fees | 15,360 |  |  | 2,354 |  |
| Accrued taxes | 1,078 |  |  | 1,577 |  |
| Other | 2,196 |  |  | 1,396 |  |
| Total accrued liabilities | $ | 58,979 |  |  | $ | 40,369 |  |


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001596532-15-000176:notes:110]
[same as prior period, unchanged from 0001596532-15-000112:notes:106]

[0001596532-15-000176:notes:111]
|  | September 30, 2015 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| U.S. government notes—due within one year | $ | 150,139 |  |  | $ | — |  |  | $ | (22 | ) |  | $ | 150,117 |  |

[0001596532-15-000176:notes:112]
[same as prior period, unchanged from 0001596532-15-000112:notes:108]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001596532-15-000176:notes:113]
[same as prior period, unchanged from 0001596532-15-000112:notes:109]

[0001596532-15-000176:notes:114]
|  | September 30, 2015 |  | December 31, 2014 |
| Raw materials | $ | 39,920 |  |  | $ | 17,094 |  |
| Finished goods | 70,001 |  |  | 60,912 |  |
| Total inventories | $ | 109,921 |  |  | $ | 78,006 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001596532-15-000176:notes:115]
[same as prior period, unchanged from 0001596532-15-000112:notes:111]

[0001596532-15-000176:notes:116]
|  | September 30, 2015 |  | December 31, 2014 |
| Prepaid income taxes | $ | 18,368 |  |  | $ | 25,212 |  |
| Other current assets | 36,765 |  |  | 11,512 |  |
| Other prepaids and deposits | 7,002 |  |  | 6,058 |  |
| Total prepaid expenses and other current assets | $ | 62,135 |  |  | $ | 42,782 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001596532-15-000176:notes:117]
[same as prior period, unchanged from 0001596532-15-000112:notes:113]

[0001596532-15-000176:notes:118]
|  | Nine Months Ended September 30, |
|  | 2015 |  | 2014 |
| Warranty accrual, beginning of period | $ | 3,204 |  |  | $ | 5,075 |  |
| Liabilities accrued for warranties issued during the period | 3,352 |  |  | 1,839 |  |
| Warranty costs incurred during the period | (1,765 | ) |  | (1,689 | ) |
| Adjustments related to change in estimate | — |  |  | (1,761 | ) |
| Warranty accrual, end of period | $ | 4,791 |  |  | $ | 3,464 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001596532-15-000176:notes:119]
[same as prior period, unchanged from 0001596532-15-000112:notes:115]

[0001596532-15-000176:notes:120]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| United States | $ | 166,466 |  |  | $ | 123,847 |  |  | $ | 437,922 |  |  | $ | 318,989 |  |
| Other Americas | 4,130 |  |  | 1,581 |  |  | 10,294 |  |  | 5,797 |  |
| Europe, Middle East and Africa | 29,457 |  |  | 21,485 |  |  | 94,329 |  |  | 53,827 |  |
| Asia-Pacific | 17,495 |  |  | 8,550 |  |  | 49,600 |  |  | 32,004 |  |
| Total revenue | $ | 217,548 |  |  | $ | 155,463 |  |  | $ | 592,145 |  |  | $ | 410,617 |  |

[0001596532-15-000176:notes:121]
[same as prior period, unchanged from 0001596532-15-000112:notes:117]

[0001596532-15-000176:notes:122]
|  | September 30, 2015 |  | December 31, 2014 |
| United States | $ | 67,342 |  |  | $ | 67,727 |  |
| International | 7,906 |  |  | 3,831 |  |
| Total | $ | 75,248 |  |  | $ | 71,558 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-15-000176:notes:123]
[same as prior period, unchanged from 0001596532-15-000112:notes:119]

[0001596532-15-000176:notes:124]
[same as prior period, unchanged from 0001596532-15-000112:notes:120]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-15-000176:notes:125]
[same as prior period, unchanged from 0001596532-15-000112:notes:121]

[0001596532-15-000176:notes:126]
[same as prior period, unchanged from 0001596532-15-000112:notes:122]

[0001596532-15-000176:notes:127]
We did not realize any other-than-temporary losses on our marketable securities for the three and nine months ended September 30, 2015 and 2014 or the year ended December 31, 2014. None of our marketable securities have been in continuous unrealized loss positions for greater than twelve months as of September 30, 2015.

[0001596532-15-000176:notes:128]
We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. As interest rates increase, those marketable securities purchased at a lower yield show a mark-to-market unrealized loss. The unrealized losses are due primarily to changes in credit spreads and interest rates. We expect to realize the full value of these investments upon maturity or sale. The weighted average remaining duration of our current marketable securities is approximately one month as of September 30, 2015.

[0001596532-15-000176:notes:129]
[same as prior period, unchanged from 0001596532-15-000112:notes:125]

[0001596532-15-000176:notes:130]
[same as prior period, unchanged from 0001596532-15-000112:notes:126]

[0001596532-15-000176:notes:131]
[same as prior period, unchanged from 0001596532-15-000112:notes:127]

[0001596532-15-000176:notes:132]
[same as prior period, unchanged from 0001596532-15-000112:notes:128]

[0001596532-15-000176:notes:133]
Building consists of capitalized construction costs of our leased building in Santa Clara, California. Based on the terms of the lease agreement and due to our involvement in certain aspects of the original construction, such as our financial involvement in structural elements of asset construction, making decisions related to tenant improvement costs and purchasing insurance not reimbursable by the buyer-lessor (the "Landlord"), we are deemed the owner of the building (for accounting purposes only) during the construction period. We continue to maintain involvement in the property post construction completion, and lack transferability of the risks and rewards of ownership, due to our required maintenance of a $4.0 million letter of credit in addition to our ability and option to sublease our portion of the leased building for fees substantially higher than our base rate.  Due to our continued involvement in the property and lack of transferability of related risks and rewards of ownership to the Landlord, we account for the building as a financing obligation. See “Note 5 - Commitments and Contingencies". Accordingly, as of September 30, 2015 and December 31, 2014, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the Landlord. The building was completed in 2014.

[0001596532-15-000176:notes:134]
Depreciation and amortization expense was $3.4 million, $9.7 million, $2.7 million and $7.4 million for the three and nine months ended September 30, 2015 and 2014, respectively.

[0001596532-15-000176:notes:135]
[same as prior period, unchanged from 0001596532-15-000112:notes:131]

[0001596532-15-000176:notes:136]
[same as prior period, unchanged from 0001596532-15-000112:notes:132]

[0001596532-15-000176:notes:137]
[same as prior period, unchanged from 0001596532-15-000112:notes:133]

[0001596532-15-000176:notes:138]
[same as prior period, unchanged from 0001596532-15-000112:notes:134]
