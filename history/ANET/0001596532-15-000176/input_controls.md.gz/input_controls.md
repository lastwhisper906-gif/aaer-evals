# ANET 10-Q controls and the auditor's report


## item_4_controls

[0001596532-15-000176:item_4_controls:1]
Item 4. Controls and Procedures

[0001596532-15-000176:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001596532-15-000176:item_4_controls:3]
Management, with the participation of our Chief Executive Officer ("CEO") and our Chief Financial Officer ("CFO"), evaluated the effectiveness of our disclosure controls and procedures as of September 30, 2015. The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act, means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported, within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the company’s management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure. Based on that evaluation, management has concluded that as of September 30, 2015, the Company’s disclosure controls and procedures were not effective at the reasonable level of assurance due to a material weakness in internal control over financial reporting.

[0001596532-15-000176:item_4_controls:4]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected on a timely basis. For the fiscal year ended 2014, we identified a material weakness in our internal control over financial reporting due to inadequate design and operation of review controls that are intended to ensure the accuracy of the calculations and related disclosures in our consolidated statement of cash flows prepared in accordance with U.S. generally accepted accounting principles.  As a result of this deficiency, our consolidated statement of cash flows for the year ended December 31, 2014 contained an error related to duplicate recognition of the excess tax benefits associated with our equity incentive plans resulting in a $17.4 million understatement of cash provided by operating activities and a corresponding $17.4 million overstatement of cash provided by financing activities. Despite the existence of this material weakness, we believe the consolidated financial statements included in this Form 10-Q for the quarter ended September 30, 2015 present, in all material respects, our financial position, results of operations, comprehensive loss and cash flows for the periods presented in conformity with U.S. generally accepted accounting principles.

[0001596532-15-000176:item_4_controls:5]
34

[0001596532-15-000176:item_4_controls:6]
The Audit Committee directed management to prepare a remediation plan concerning the material weakness described above. We are currently in the process of remediating the material weakness in our internal control over financial reporting and are implementing a number of measures designed to address the underlying causes of the material weakness. The remediation plan includes additional procedures surrounding the precision and accuracy of the review control over our statement of cash flows, which includes enhancing and segregating duties within our accounting and finance department and enhancing our internal review procedures during the financial statement close process. We believe that these additional processes and procedures will enable us to broaden the scope and quality of our controls relating to the oversight and review of our financial statements.

[0001596532-15-000176:item_4_controls:7]
Changes in Internal Control over Financial Reporting

[0001596532-15-000176:item_4_controls:8]
Except for the remediation efforts described above, there were no changes in our internal control over financial reporting identified in connection with the evaluation required by Rule 13a-15(d) and 15d-15(d) of the Securities and Exchange Act of 1934, that occurred during the three months ended September 30, 2015 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001596532-15-000176:item_4_controls:9]
Inherent Limitations of Internal Controls

[0001596532-15-000176:item_4_controls:10]
Our management, including our CEO and CFO, does not expect that our disclosure controls and procedures or our internal controls over financial reporting will prevent or detect all error and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system are met. Because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within the Company have been detected. These inherent limitations include the realities that judgments in decision-making can be faulty, and that breakdowns can occur because of a simple error or mistake. Additionally, controls can be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls also is based in part upon certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions. Over time, controls may become inadequate because of changes in conditions, or the degree of compliance with the policies or procedures may deteriorate. Because of the inherent limitations in a cost-effective control system, misstatements due to error or fraud may occur and not be detected.
