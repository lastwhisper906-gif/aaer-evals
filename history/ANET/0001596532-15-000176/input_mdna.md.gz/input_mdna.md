# ANET MD&A — 0001596532-15-000176


## mdna

[0001596532-15-000176:mdna:1]
[same as prior period, unchanged from 0001596532-15-000112:mdna:1]

[0001596532-15-000176:mdna:2]
[same as prior period, unchanged from 0001596532-15-000112:mdna:2]

[0001596532-15-000176:mdna:3]
We are a leading supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation data centers for enterprise support. Our cloud networking solutions consist of our Extensible Operating System, or EOS, a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switches. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. At the core of our cloud networking platform is EOS, which was purpose-built to be fully programmable and highly modular. The programmability of EOS has allowed us to create a set of software applications that address the requirements of cloud networking, including workflow automation, network visibility and analytics, and has also allowed us to rapidly integrate with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.

[0001596532-15-000176:mdna:4]
We were founded in 2004 to address the limitations of legacy networking products and to create a cloud networking platform that is open and programmable. From 2004 to 2008, our activities were focused on the development of our software, which resulted in the commercial release of our first product, the 7100 Series switches based on our EOS software, in 2008. Since then, we have continued to introduce new products utilizing EOS, including our 7500 Series switch and our 7050 Series switch in 2010, the second generation of our 7500 Series switch, called the 7500E modular switch, in May 2013, our 7300 Series switch in November 2013 and our 7280E in July 2014.  In December 2014, we introduced our EOS+ software platform for networking programmability and automation, and in June 2015 we introduced CloudVision, a network-wide approach for workload orchestration and workflow automation.  In September 2015, we introduced our Macro Segmentation Services (“MSS”) to provide automated insertion of security and other in-line layer 4-7 services within any software driven cloud networking infrastructure. MSS has been endorsed by many of our technology alliance ecosystem partners with whom we are currently partnering with to deliver MSS platform support. We also introduced our first 10/25/40/50/100G switches with our 7060, 7260 and 7320 series switches.

[0001596532-15-000176:mdna:5]
As of September 30, 2015, we have shipped more than five million switch ports. We have experienced rapid revenue growth over the last several years, increasing our revenue at a compound annual growth rate of 68.9% from 2010 to 2014. As we have grown the functionality of our EOS software, expanded the range of our switching portfolio and increased the size of our sales force, our revenue has continued to grow rapidly. To support our customers and revenue growth, we have expanded our international presence to include 20 foreign subsidiaries as of September 30, 2015, including for example Australia, Canada, France, Germany, India, Ireland, Japan, South Korea and the United Kingdom. Our revenue for the three and nine months ended September 30, 2015 was $217.5 million and $592.1 million an increase of 39.9% and 44.2%, respectively, compared to the same period in 2014. We have been profitable and cash flow positive for each year since 2010.

[0001596532-15-000176:mdna:6]
[same as prior period, unchanged from 0001596532-15-000112:mdna:6]

[0001596532-15-000176:mdna:7]
[same as prior period, unchanged from 0001596532-15-000112:mdna:7]

[0001596532-15-000176:mdna:8]
[same as prior period, unchanged from 0001596532-15-000112:mdna:8]

[0001596532-15-000176:mdna:9]
[same as prior period, unchanged from 0001596532-15-000112:mdna:9]

[0001596532-15-000176:mdna:10]
To continue to grow our revenue, it is important that we both obtain new customers and sell additional products to existing customers. Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic to the underlying merchant silicon architecture. Today, we combine our EOS software with merchant silicon into a family of switching products. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We currently procure certain merchant silicon components from multiple vendors, and we continue to expand our relationships with these and other vendors. We work closely with third party contract manufacturing suppliers to manufacture our products. Our contract manufacturing suppliers deliver our products to one of three third party direct fulfillment facilities where our EOS software is installed on our products.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-15-000176:mdna:11]
[same as prior period, unchanged from 0001596532-15-000112:mdna:12]

[0001596532-15-000176:mdna:12]
[same as prior period, unchanged from 0001596532-15-000112:mdna:13]

[0001596532-15-000176:mdna:13]
[same as prior period, unchanged from 0001596532-15-000112:mdna:14]

[0001596532-15-000176:mdna:14]
[same as prior period, unchanged from 0001596532-15-000112:mdna:15]

[0001596532-15-000176:mdna:15]
[same as prior period, unchanged from 0001596532-15-000112:mdna:16]

[0001596532-15-000176:mdna:16]
[same as prior period, unchanged from 0001596532-15-000112:mdna:17]

[0001596532-15-000176:mdna:17]
[same as prior period, unchanged from 0001596532-15-000112:mdna:18]

[0001596532-15-000176:mdna:18]
[same as prior period, unchanged from 0001596532-15-000112:mdna:19]

[0001596532-15-000176:mdna:19]
Investing in Research and Development for Growth. We believe that the market for cloud networking is still in the early stages of adoption and we intend to continue investing for long-term growth. We expect to continue to invest heavily in software development in order to expand the capabilities of our cloud networking platform, introduce new products including new releases and upgrades to our EOS software and new applications and build upon our technology leadership. We believe one of our greatest strengths lies in the speed

[0001596532-15-000176:mdna:20]
of our product development efforts. By investing in research and development, we believe we will be well positioned to continue our rapid growth and take advantage of our large market opportunity. We expect that our results of operations will be impacted by the timing and size of these product development investments.

[0001596532-15-000176:mdna:21]
[same as prior period, unchanged from 0001596532-15-000112:mdna:21]

[0001596532-15-000176:mdna:22]
[same as prior period, unchanged from 0001596532-15-000112:mdna:22]

[0001596532-15-000176:mdna:23]
[same as prior period, unchanged from 0001596532-15-000112:mdna:23]

[0001596532-15-000176:mdna:24]
We generate revenue primarily from sales of our switching products which incorporate our EOS software. We also derive a portion of our revenue from sales of post contract support, or PCS, and to a lesser extent CloudVision software subscription and professional services. We generate PCS revenue from sales of technical support services contracts that are typically purchased in conjunction with our products and subsequent renewals of those contracts. We offer PCS services under renewable, fee-based contracts, which include 24-hour technical support, hardware repair and replacement parts, bug fixes, patches and unspecified upgrades on a when-and-if available basis. We expect our revenue may vary from period to period based on, among other things, the timing and size of orders, the delivery and acceptance of products, the impact of significant transactions with unique terms and conditions that may require deferral of revenue and cyclicality of orders being placed by our customers. Additionally, we expect our software subscription and PCS revenue to increase in absolute dollars as we expand our installed base. Our ability to expand our installed base and increase our revenue is subject to numerous risks and uncertainties. See the section titled “Risk Factors.” We report revenue net of sales taxes.

[0001596532-15-000176:mdna:25]
[same as prior period, unchanged from 0001596532-15-000112:mdna:25]

[0001596532-15-000176:mdna:26]
[same as prior period, unchanged from 0001596532-15-000112:mdna:26]

[0001596532-15-000176:mdna:27]
[same as prior period, unchanged from 0001596532-15-000112:mdna:27]

[0001596532-15-000176:mdna:28]
[same as prior period, unchanged from 0001596532-15-000112:mdna:28]

[0001596532-15-000176:mdna:29]
[same as prior period, unchanged from 0001596532-15-000112:mdna:29]

[0001596532-15-000176:mdna:30]
[same as prior period, unchanged from 0001596532-15-000112:mdna:30]

[0001596532-15-000176:mdna:31]
[same as prior period, unchanged from 0001596532-15-000112:mdna:31]

[0001596532-15-000176:mdna:32]
[same as prior period, unchanged from 0001596532-15-000112:mdna:32]

[0001596532-15-000176:mdna:33]
[same as prior period, unchanged from 0001596532-15-000112:mdna:33]

[0001596532-15-000176:mdna:34]
Sales and marketing expenses consist primarily of personnel costs and also include costs related to marketing and promotional activities, with the remainder being an allocated portion of facility and IT costs and depreciation. We expect our sales and marketing

[0001596532-15-000176:mdna:35]
expenses to increase in absolute dollars as we expand our sales and marketing efforts worldwide and expand our relationships with current and future channel partners and end customers.

[0001596532-15-000176:mdna:36]
[same as prior period, unchanged from 0001596532-15-000112:mdna:35]

[0001596532-15-000176:mdna:37]
General and administrative expenses consist primarily of personnel costs, legal and professional fees, and an allocated portion of facility and IT costs and depreciation. General and administrative personnel costs include those for our executive, finance, IT, human resources and legal functions. Our professional fees consist primarily of accounting, external legal and IT and other consulting costs. We expect our general and administrative expenses to increase in absolute dollars to support our growing infrastructure needs and as we assume the reporting requirements and compliance obligations of a public company. In addition, we expect legal expense to increase significantly in absolute dollars for the foreseeable future due to legal costs related to ongoing IP litigation and potential future litigation claims. Refer to the discussion under “Legal Proceedings” subheading in Note 5. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for information related to pending litigation.

[0001596532-15-000176:mdna:38]
[same as prior period, unchanged from 0001596532-15-000112:mdna:37]

[0001596532-15-000176:mdna:39]
[same as prior period, unchanged from 0001596532-15-000112:mdna:38]

[0001596532-15-000176:mdna:40]
Interest expense consists of interest expense on our subordinated convertible promissory notes, including our related party subordinated convertible promissory notes which were converted during fiscal 2014 and interest expense from our lease financing obligation.

[0001596532-15-000176:mdna:41]
[same as prior period, unchanged from 0001596532-15-000112:mdna:40]

[0001596532-15-000176:mdna:42]
[same as prior period, unchanged from 0001596532-15-000112:mdna:41]

[0001596532-15-000176:mdna:43]
[same as prior period, unchanged from 0001596532-15-000112:mdna:42]

[0001596532-15-000176:mdna:44]
[same as prior period, unchanged from 0001596532-15-000112:mdna:43]

[0001596532-15-000176:mdna:45]
[same as prior period, unchanged from 0001596532-15-000112:mdna:44]

[0001596532-15-000176:mdna:46]
[same as prior period, unchanged from 0001596532-15-000112:mdna:45]

[0001596532-15-000176:mdna:47]
[same as prior period, unchanged from 0001596532-15-000112:mdna:46]

[0001596532-15-000176:mdna:48]
The following table summarizes historical results of operations for the periods presented and as a percentage of revenue for those periods.  We have derived the data for the three and nine months ended September 30, 2015 and 2014 from our unaudited condensed consolidated financial statements (in thousands, except for percentage of revenue).

[0001596532-15-000176:mdna:49]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 193,339 |  |  | $ | 141,455 |  |  | $ | 527,552 |  |  | $ | 374,338 |  |
| Service | 24,209 |  |  | 14,008 |  |  | 64,593 |  |  | 36,279 |  |
| Total revenue | 217,548 |  |  | 155,463 |  |  | 592,145 |  |  | 410,617 |  |
| Cost of revenue (1): |  |  |  |  |  |  |  |
| Product | 67,990 |  |  | 49,633 |  |  | 182,443 |  |  | 122,692 |  |
| Service | 7,810 |  |  | 4,873 |  |  | 22,310 |  |  | 12,274 |  |
| Total cost of revenue | 75,800 |  |  | 54,506 |  |  | 204,753 |  |  | 134,966 |  |
| Gross profit | 141,748 |  |  | 100,957 |  |  | 387,392 |  |  | 275,651 |  |
| Operating expenses (1): |  |  |  |  |  |  |  |
| Research and development | 58,748 |  |  | 36,231 |  |  | 152,035 |  |  | 104,565 |  |
| Sales and marketing | 26,508 |  |  | 20,956 |  |  | 77,776 |  |  | 60,322 |  |
| General and administrative | 25,195 |  |  | 9,896 |  |  | 57,670 |  |  | 24,253 |  |
| Total operating expenses | 110,451 |  |  | 67,083 |  |  | 287,481 |  |  | 189,140 |  |
| Income from operations | 31,297 |  |  | 33,874 |  |  | 99,911 |  |  | 86,511 |  |
| Interest expense | (753 | ) |  | (764 | ) |  | (2,406 | ) |  | (5,512 | ) |
| Other income (expense), net | 13 |  |  | (824 | ) |  | (38 | ) |  | 2,426 |  |
| Total other income (expense), net | (740 | ) |  | (1,588 | ) |  | (2,444 | ) |  | (3,086 | ) |
| Income before provision for income taxes | 30,557 |  |  | 32,286 |  |  | 97,467 |  |  | 83,425 |  |
| Provision for income taxes | 1,867 |  |  | 10,420 |  |  | 20,289 |  |  | 27,612 |  |
| Net income | $ | 28,690 |  |  | $ | 21,866 |  |  | $ | 77,178 |  |  | $ | 55,813 |  |

[0001596532-15-000176:mdna:50]
[same as prior period, unchanged from 0001596532-15-000112:mdna:54]

[0001596532-15-000176:mdna:51]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (as a percentage of revenue) |
| Revenue: |  |  |  |  |  |  |  |
| Product | 88.9 | % |  | 91.0 | % |  | 89.1 | % |  | 91.2 | % |
| Service | 11.1 |  |  | 9.0 |  |  | 10.9 |  |  | 8.8 |  |
| Total revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 31.2 |  |  | 31.9 |  |  | 30.8 |  |  | 29.9 |  |
| Service | 3.6 |  |  | 3.2 |  |  | 3.8 |  |  | 3.0 |  |
| Total cost of revenue | 34.8 |  |  | 35.1 |  |  | 34.6 |  |  | 32.9 |  |
| Gross margin | 65.2 |  |  | 64.9 |  |  | 65.4 |  |  | 67.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 27.0 |  |  | 23.3 |  |  | 25.7 |  |  | 25.5 |  |
| Sales and marketing | 12.2 |  |  | 13.5 |  |  | 13.1 |  |  | 14.7 |  |
| General and administrative | 11.6 |  |  | 6.4 |  |  | 9.8 |  |  | 5.9 |  |
| Total operating expenses | 50.8 |  |  | 43.2 |  |  | 48.6 |  |  | 46.1 |  |
| Income from operations | 14.4 |  |  | 21.7 |  |  | 16.8 |  |  | 21.0 |  |
| Interest expense | (0.3 | ) |  | (0.5 | ) |  | (0.4 | ) |  | (1.3 | ) |
| Other income (expense), net | — |  |  | (0.5 | ) |  | — |  |  | 0.6 |  |
| Total other income (expense), net | (0.3 | ) |  | (1.0 | ) |  | (0.4 | ) |  | (0.7 | ) |
| Income before provision for income taxes | 14.1 |  |  | 20.7 |  |  | 16.4 |  |  | 20.3 |  |
| Provision for income taxes | 0.9 |  |  | 6.7 |  |  | 3.4 |  |  | 6.7 |  |
| Net income | 13.2 | % |  | 14.0 | % |  | 13.0 | % |  | 13.6 | % |

[0001596532-15-000176:mdna:52]
[same as prior period, unchanged from 0001596532-15-000112:mdna:51]

[0001596532-15-000176:mdna:53]
[same as prior period, unchanged from 0001596532-15-000112:mdna:52]

[0001596532-15-000176:mdna:54]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cost of revenue | $ | 786 |  |  | $ | 480 |  |  | $ | 2,206 |  |  | $ | 992 |  |
| Research and development | 7,037 |  |  | 4,304 |  |  | 18,344 |  |  | 10,298 |  |
| Sales and marketing | 2,864 |  |  | 2,387 |  |  | 8,138 |  |  | 5,746 |  |
| General and administrative | 1,591 |  |  | 911 |  |  | 3,637 |  |  | 2,533 |  |
| Total stock-based compensation | $ | 12,278 |  |  | $ | 8,082 |  |  | $ | 32,325 |  |  | $ | 19,569 |  |

[0001596532-15-000176:mdna:55]
28

[0001596532-15-000176:mdna:56]
Three and Nine Months Ended September 30, 2015 Compared to Three and Nine Months Ended September 30, 2014

[0001596532-15-000176:mdna:57]
[same as prior period, unchanged from 0001596532-15-000112:mdna:56]

[0001596532-15-000176:mdna:58]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | Change in |  | 2015 |  | 2014 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 193,339 |  |  | $ | 141,455 |  |  | $ | 51,884 |  |  | 36.7% |  | $ | 527,552 |  |  | $ | 374,338 |  |  | $ | 153,214 |  |  | 40.9% |
| Service | 24,209 |  |  | 14,008 |  |  | 10,201 |  |  | 72.8 |  | 64,593 |  |  | 36,279 |  |  | 28,314 |  |  | 78.0 |
| Total revenue | $ | 217,548 |  |  | $ | 155,463 |  |  | $ | 62,085 |  |  | 39.9% |  | $ | 592,145 |  |  | $ | 410,617 |  |  | $ | 181,528 |  |  | 44.2% |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 67,990 |  |  | $ | 49,633 |  |  | $ | 18,357 |  |  | 37.0% |  | $ | 182,443 |  |  | $ | 122,692 |  |  | $ | 59,751 |  |  | 48.7% |
| Service | 7,810 |  |  | 4,873 |  |  | 2,937 |  |  | 60.3 |  | 22,310 |  |  | 12,274 |  |  | 10,036 |  |  | 81.8 |
| Total cost of revenue | $ | 75,800 |  |  | $ | 54,506 |  |  | $ | 21,294 |  |  | 39.1% |  | $ | 204,753 |  |  | $ | 134,966 |  |  | $ | 69,787 |  |  | 51.7% |
| Gross profit | $ | 141,748 |  |  | $ | 100,957 |  |  | $ | 40,791 |  |  | 40.4% |  | $ | 387,392 |  |  | $ | 275,651 |  |  | $ | 111,741 |  |  | 40.5% |
| Gross margin | 65.2 | % |  | 64.9 | % |  |  |  |  |  | 65.4 | % |  | 67.1 | % |  |  |  |  |

[0001596532-15-000176:mdna:59]
[same as prior period, unchanged from 0001596532-15-000112:mdna:58]

[0001596532-15-000176:mdna:60]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2015 |  | % of Total |  | 2014 |  | % of Total |  | 2015 |  | % of Total |  | 2014 |  | % of Total |
| Americas | $ | 170,596 |  |  | 78.5 % |  | $ | 125,428 |  |  | 80.7 % |  | $ | 448,216 |  |  | 75.7 % |  | $ | 324,786 |  |  | 79.1 % |
| Europe, Middle East and Africa | 29,457 |  |  | 13.5% |  | 21,485 |  |  | 13.8% |  | 94,329 |  |  | 15.9% |  | 53,827 |  |  | 13.1% |
| Asia-Pacific | 17,495 |  |  | 8.0% |  | 8,550 |  |  | 5.5% |  | 49,600 |  |  | 8.4% |  | 32,004 |  |  | 7.8% |
| Total revenue | $ | 217,548 |  |  | 100.0 % |  | $ | 155,463 |  |  | 100.0 % |  | $ | 592,145 |  |  | 100.0 % |  | $ | 410,617 |  |  | 100.0 % |

[0001596532-15-000176:mdna:61]
[same as prior period, unchanged from 0001596532-15-000112:mdna:60]

[0001596532-15-000176:mdna:62]
Revenue increased 39.9% in the three months ended September 30, 2015 and 44.2% in the nine months ended September 30, 2015, compared to the same periods in 2014. We increased shipments to our existing customers during these periods as they continued to grow their businesses and increase their demand for our switch products and related accessories. In addition, we continued to add new customers as we expanded our market presence and geographic footprint. Service revenue also increased in each of the periods presented primarily due to an increase in new and renewed support contracts for our switch products as a result of our growing customer install base. We continue to experience fluctuations in product and service pricing due to competitive market pressures, however, these were offset by the increased demand drivers outlined above.

[0001596532-15-000176:mdna:63]
[same as prior period, unchanged from 0001596532-15-000112:mdna:62]

[0001596532-15-000176:mdna:64]
Gross margin increased from 64.9% to 65.2% for the three months ended September 30, 2015 compared to September 30, 2014 , and decreased from 67.1% to 65.4% for the nine months ended September 30, 2015 compared to September 30, 2014. The increase in gross margin during the three months ended September 30, 2015 was primarily the result of changes in customer mix, with a more balanced revenue mix between customers, especially larger customers who typically receive higher discount levels than our other customers. The impact of this favorable customer mix was partially offset by certain inventory-related obsolescence charges associated with upcoming product transitions. The decrease in gross margin during the nine months ended September 30, 2015 was primarily related to certain inventory-related obsolescence charges recorded in the period, as well as increased product warranty charges resulting from an expanded customer base. In addition we invested in manufacturing and operations infrastructure as our revenues increased, adding capacity and expanding our footprint geographically.

[0001596532-15-000176:mdna:65]
[same as prior period, unchanged from 0001596532-15-000112:mdna:64]

[0001596532-15-000176:mdna:66]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | Change in |  | 2015 |  | 2014 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 58,748 |  |  | $ | 36,231 |  |  | $ | 22,517 |  |  | 62.1% |  | $ | 152,035 |  |  | $ | 104,565 |  |  | $ | 47,470 |  |  | 45.4% |
| Sales and marketing | 26,508 |  |  | 20,956 |  |  | 5,552 |  |  | 26.5 |  | 77,776 |  |  | 60,322 |  |  | 17,454 |  |  | 28.9 |
| General and administrative | 25,195 |  |  | 9,896 |  |  | 15,299 |  |  | 154.6 |  | 57,670 |  |  | 24,253 |  |  | 33,417 |  |  | 137.8 |
| Total operating expenses | $ | 110,451 |  |  | $ | 67,083 |  |  | $ | 43,368 |  |  | 64.6% |  | $ | 287,481 |  |  | $ | 189,140 |  |  | $ | 98,341 |  |  | 52.0% |

[0001596532-15-000176:mdna:67]
[same as prior period, unchanged from 0001596532-15-000112:mdna:66]

[0001596532-15-000176:mdna:68]
Research and development expenses increased $22.5 million, or 62.1%, for the three months ended September 30, 2015 compared to the same period in 2014. The increase was primarily due to an increase in personnel costs of $13.3 million, resulting from increased headcount, stock based compensation and additional bonus expense under our corporate bonus plan. In addition, prototype spend increased $4.2 million as a result of new product introductions and facilities, and IT and infrastructure build-out expenses increased $3.0 million due to the continued expansion and support of our research and development activities.

[0001596532-15-000176:mdna:69]
Research and development expenses increased $47.5 million, or 45.4%, for the nine months ended September 30, 2015 compared to the same period in 2014. The increase was primarily due to an increase in personnel costs of $29.7 million, resulting from increases in headcount, stock based compensation as well as additional bonus expense under our corporate bonus plan. In addition, research and development related facilities and IT and infrastructure build-out expenses increased $8.7 million, and prototype spend and non-recurring engineering costs increased $5.8 million due to the continued expansion and support of our research and development activities.

[0001596532-15-000176:mdna:70]
[same as prior period, unchanged from 0001596532-15-000112:mdna:69]

[0001596532-15-000176:mdna:71]
Sales and marketing expenses increased $5.6 million, or 26.5%, for the three months ended September 30, 2015 compared to the same period in 2014. The increase was primarily due to an increase in personnel costs of $3.2 million, related to increased headcount from and additional sales commissions resulting from higher sales volume. There was also an increase of $1.6 million in product demonstration costs.

[0001596532-15-000176:mdna:72]
Sales and marketing expenses increased $17.5 million, or 28.9%, for the nine months ended September 30, 2015 compared to the same period in 2014. The increase was primarily due to an increase in personnel costs of $10.8 million, resulting from increased headcount and additional sales commissions resulting from higher sales volume. The increase was also due to an increase of $5.6 million in product demonstration costs.

[0001596532-15-000176:mdna:73]
[same as prior period, unchanged from 0001596532-15-000112:mdna:72]

[0001596532-15-000176:mdna:74]
General and administrative expenses increased $15.3 million, or 154.6%, for the three months ended September 30, 2015 compared to the same period in 2014. The increase was primarily due to increased litigation expenses of $15.5 million related to the Cisco and OptumSoft legal matters, partially offset by decreased personnel costs of $0.2 million.

[0001596532-15-000176:mdna:75]
General and administrative expenses increased $33.4 million, or 137.8%, for the nine months ended September 30, 2015 compared to the same period in 2014. The increase was primarily due to an increase in litigation expenses of $31.6 million primarily related to the Cisco and OptumSoft legal matters and increased personnel costs of $1.6 million as a result of increased headcount.

[0001596532-15-000176:mdna:76]
[same as prior period, unchanged from 0001596532-15-000112:mdna:75]

[0001596532-15-000176:mdna:77]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | Change in |  | 2015 |  | 2014 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | $ | (753 | ) |  | $ | (764 | ) |  | $ | 11 |  |  | 1.4% |  | $ | (2,406 | ) |  | $ | (5,512 | ) |  | $ | 3,106 |  |  | 56.3% |
| Other income (expense), net | 13 |  |  | (824 | ) |  | 837 |  |  | 101.6% |  | (38 | ) |  | 2,426 |  |  | (2,464 | ) |  | (101.6)% |
| Total other income (expense), net | $ | (740 | ) |  | $ | (1,588 | ) |  | $ | 848 |  |  | 53.4% |  | $ | (2,444 | ) |  | $ | (3,086 | ) |  | $ | 642 |  |  | 20.8% |

[0001596532-15-000176:mdna:78]
[same as prior period, unchanged from 0001596532-15-000112:mdna:77]

[0001596532-15-000176:mdna:79]
Interest expense remained relatively constant during the three months ended September 30, 2015 compared to the same period in 2014 and primarily related to our lease financing obligation.  Interest expense decreased during the nine months ended September 30, 2015 compared to the same period in 2014 as a result of repayment and conversion of all our notes payable upon closing of our initial public offering during the second quarter of 2014.

[0001596532-15-000176:mdna:80]
[same as prior period, unchanged from 0001596532-15-000112:mdna:79]

[0001596532-15-000176:mdna:81]
The favorable change in other income (expense), net during the three months ended September 30, 2015 compared to the same period in 2014 was primarily a result of a reduction in transactional exchange rate losses. The unfavorable change in other income (expense), net during the nine months ended September 30, 2015, compared to the same period in 2014 was primarily due to a one-time gain on our notes receivable of $4.0 million in 2014, partially offset by a $0.7 million write-off related to the debt discount on notes payable during the second quarter of 2014, and a reduction in transactional exchange rate losses during 2015.

[0001596532-15-000176:mdna:82]
[same as prior period, unchanged from 0001596532-15-000112:mdna:81]

[0001596532-15-000176:mdna:83]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2015 |  | 2014 |  | Change in |  | 2015 |  | 2014 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Provision for income taxes | $ | 1,867 |  |  | $ | 10,420 |  |  | $ | (8,553 | ) |  | (82.1)% |  | $ | 20,289 |  |  | $ | 27,612 |  |  | $ | (7,323 | ) |  | (26.5)% |
| Effective tax rate | 6.1 | % |  | 32.3 | % |  |  |  |  |  | 20.8 | % |  | 33.1 | % |  |  |  |  |

[0001596532-15-000176:mdna:84]
[same as prior period, unchanged from 0001596532-15-000112:mdna:83]

[0001596532-15-000176:mdna:85]
Provision for income taxes was approximately $1.9 million and $10.4 million for the three months ended September 30, 2015 and 2014, respectively. The change in our provision for income taxes was primarily due to the statute of limitation expiring in certain domestic jurisdictions within the quarter allowing for the release of unrecognized tax benefits of $5.8 million and associated interest of $0.5 million.  The change in the provision was also a result of an increase in profit before income taxes and a decrease in the effective tax rate based on our current geographical distribution of the earnings.

[0001596532-15-000176:mdna:86]
Provision for income taxes was approximately $20.3 million and $27.6 million for the nine months ended September 30, 2015 and 2014, respectively. The change in our provision for income taxes was primarily due to the statute of limitation expiring in certain domestic jurisdictions within the quarter allowing for the release of unrecognized tax benefits of $5.8 million and associated interest of $0.5 million.  The change in the provision was also a result of an increase in profit before income taxes and a decrease in the effective tax rate based on our current geographical distribution of the earnings.

[0001596532-15-000176:mdna:87]
[same as prior period, unchanged from 0001596532-15-000112:mdna:86]

[0001596532-15-000176:mdna:88]
Our principal sources of liquidity are cash and cash equivalents, marketable securities, and cash generated from operations. As of September 30, 2015, cash and cash equivalents and marketable securities were $568.6 million, of which approximately $62.0 million was held outside the U.S. in our foreign subsidiaries. We have not repatriated nor do we currently have plans to repatriate these funds, but if we were to repatriate cash held outside of the U.S. for domestic cash operations, we would be required to accrue and pay U.S. income taxes to repatriate these funds less any previously paid foreign income taxes. We consider the undistributed earnings of our foreign subsidiaries as of September 30, 2015 to be indefinitely reinvested, and, accordingly, no U.S. income taxes have been provided thereon.

[0001596532-15-000176:mdna:89]
Our cash and cash equivalents and marketable securities are held for working capital purposes.  We plan to continue to invest for long-term growth. We believe that our existing cash and cash equivalents together with cash flow from operations will be sufficient to meet our working capital requirements and our growth strategies for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs and access to outsourcing our manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and the timely settlement of outstanding litigation claims. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-15-000176:mdna:90]
[same as prior period, unchanged from 0001596532-15-000112:mdna:89]

[0001596532-15-000176:mdna:91]
|  | September 30, 2015 |  | December 31, 2014 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 418,500 |  |  | $ | 240,031 |  |

[0001596532-15-000176:mdna:92]
|  | Nine Months Ended September 30, |
|  | 2015 |  | 2014 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 84,022 |  |  | $ | 98,704 |  |
| Cash provided by (used in) investing activities | 39,444 |  |  | (26,200 | ) |
| Cash provided by financing activities | 55,270 |  |  | 222,508 |  |
| Effect of exchange rate changes | (267 | ) |  | (80 | ) |
| Net increase in cash and cash equivalents | $ | 178,469 |  |  | $ | 294,932 |  |

[0001596532-15-000176:mdna:93]
[same as prior period, unchanged from 0001596532-15-000112:mdna:92]

[0001596532-15-000176:mdna:94]
[same as prior period, unchanged from 0001596532-15-000112:mdna:93]

[0001596532-15-000176:mdna:95]
During the nine months ended September 30, 2015, cash provided by operating activities was $84.0 million, primarily from net income of $77.2 million, and a net increase in cash from changes in our operating assets and liabilities of $10.7 million, partially offset by net non-cash charges of $(3.8) million. The net increase in cash from changes in operating assets and liabilities was primarily due to an increase in deferred revenue of $84.2 million, largely related to short and long-term services contracts and product revenue deferrals related to contract acceptance terms and future deliverables. In addition, we experienced an increase in cash of $24.8 million from changes in income tax payable related to excess tax benefits associated with equity incentive plans and an increase in our accounts payable and accrued liabilities of $18.0 million due to the timing of our payments. These operating liability increases were offset by an increase in our accounts receivable of $63.9 million resulting from an increase in sales during the period and slower collections in the three months ended September 30, 2015. In addition, inventory increased $31.9 million during the period due to higher shipment volume and prepaid expenses and current assets increased $19.4 million in the period.

[0001596532-15-000176:mdna:96]
During the nine months ended September 30, 2014, cash provided by operating activities was $98.7 million primarily from net income of $55.8 million, net non-cash charges of $23.1 million and a net increase in our operating assets and liabilities of $19.8 million. The change in our operating assets and liabilities was primarily due to an increase in our deferred revenue of $18.8 million resulting from the increase in sales, an increase in our accounts payables of $5.6 million from the timing of our payments and a decrease in inventories of $4.5 million as a result of improvements in the management of our consigned and finished goods inventory. We also had higher accrued expenses of $7.7 million that were primarily attributable to higher personnel costs from the increase in headcount, and included

[0001596532-15-000176:mdna:97]
contributions of $2.1 million received from the introduction of our employee stock purchase plan. These changes were partially offset by an increase in our prepaid expenses and other current assets of $8.8 million primarily from the prepayment of taxes and the renewal of our insurance policies. We also had an increase in our accounts receivable of $6.7 million resulting from higher product shipments as well as an increase in other assets of $2.1 million.

[0001596532-15-000176:mdna:98]
[same as prior period, unchanged from 0001596532-15-000112:mdna:97]

[0001596532-15-000176:mdna:99]
Our investing activities have consisted primarily of capital expenditures and net investment purchases of available for sale marketable securities. We expect to continue investing in these activities to support the continued growth of our business.

[0001596532-15-000176:mdna:100]
During the nine months ended September 30, 2015, cash provided by investing activities was $39.4 million, consisting of proceeds from the maturity of available-for-sale securities of $58.2 million, offset by purchases of property, equipment and other assets of $14.0 million and increase in restricted cash of $4.0 million related to a security deposit required for a facility lease.

[0001596532-15-000176:mdna:101]
During the nine months ended September 30, 2014, cash used in investing activities was $26.2 million, consisting primarily of purchases of property and equipment of $10.8 million and other investing activities of $19.5 million largely due to a $15.0 million equity investment in a privately held company partially offset by the release of our restricted cash of $4.0 million into cash and cash equivalents.

[0001596532-15-000176:mdna:102]
[same as prior period, unchanged from 0001596532-15-000112:mdna:101]

[0001596532-15-000176:mdna:103]
Our cash flows provided by financing activities primarily consisted of proceeds from the issuance of common stock and the excess tax benefits on stock-based compensation.

[0001596532-15-000176:mdna:104]
During the nine months ended September 30, 2015, cash provided by financing activities was $55.3 million, consisting primarily of the excess tax benefit associated with equity incentive plans of $32.4 million, proceeds from the exercise of stock options, net of repurchases of $14.6 million and the proceeds from the issuance of common stock from our ESPP of $9.4 million.

[0001596532-15-000176:mdna:105]
During the nine months ended September 30, 2014, cash provided by financing activities was $222.5 million, consisting primarily of net proceeds raised from our initial public offering of $239.6 million and proceeds from the exercise of stock options, net of repurchases of $2.6 million. These proceeds were partially offset by the repayment of our notes payable of $20.0 million.

[0001596532-15-000176:mdna:106]
[same as prior period, unchanged from 0001596532-15-000112:mdna:105]

[0001596532-15-000176:mdna:107]
As of September 30, 2015, we did not have any relationships with any unconsolidated entities or financial partnerships, including entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-15-000176:mdna:108]
[same as prior period, unchanged from 0001596532-15-000112:mdna:107]

[0001596532-15-000176:mdna:109]
There have been no significant changes during the nine months ended September 30, 2015 impacting our contractual obligations disclosed in our "Management's Discussion and Analysis of Financial Condition and Results of Operations" included in our Annual Report on Form 10-K, filed with the SEC on March 12, 2015 and our Amended Annual Report on Form 10-K/A, filed with the SEC on May 15, 2015.

[0001596532-15-000176:mdna:110]
[same as prior period, unchanged from 0001596532-15-000112:mdna:109]

[0001596532-15-000176:mdna:111]
[same as prior period, unchanged from 0001596532-15-000112:mdna:110]

[0001596532-15-000176:mdna:112]
[same as prior period, unchanged from 0001596532-15-000112:mdna:111]

[0001596532-15-000176:mdna:113]
[same as prior period, unchanged from 0001596532-15-000112:mdna:112]
