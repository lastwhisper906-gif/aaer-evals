# ANET MD&A — 0001596532-19-000104


## mdna

[0001596532-19-000104:mdna:1]
[same as prior period, unchanged from 0001596532-18-000233:mdna:1]

[0001596532-19-000104:mdna:2]
[same as prior period, unchanged from 0001596532-18-000233:mdna:2]

[0001596532-19-000104:mdna:3]
We are a leading supplier of cloud networking solutions that use software innovations to address the needs of large-scale internet companies, cloud service providers and next-generation data centers and campuses for enterprise support. Our cloud networking solutions consist of our Extensible Operating System, or EOS, a set of network applications and our Ethernet switching and routing platforms. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. At the core of our cloud networking platform is EOS, which was purpose-built to be fully programmable and highly modular. The programmability of EOS has allowed us to create a set of software applications that address the requirements of cloud networking, including workflow automation, network visibility and analytics, and has also

[0001596532-19-000104:mdna:4]
allowed us to rapidly integrate with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.

[0001596532-19-000104:mdna:5]
We believe that cloud networks will continue to replace legacy network technologies, and that our cloud networking platform addresses the large and growing cloud networking segment of data center switching, which remains in the early stage of adoption. Cloud networks are subject to increasing performance requirements due to the growing number of connected devices, as well as new enterprise and consumer applications. Computing architectures are evolving to meet the need for constant connectivity and access to data and applications. We expect to continue growing our organization to meet the needs of new and existing customers as they increasingly realize the performance and cost benefits of our cloud networking solutions and as they expand their cloud networks. Accordingly, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our rapid development of new features and applications.

[0001596532-19-000104:mdna:6]
We generate revenue primarily from sales of our switching products which incorporate our EOS software. We generate the majority of our services revenue from post contract support, or PCS, which end customers typically purchase in conjunction with our products. Our end customers span a range of industries and include large internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others. As we have grown the functionality of our EOS software, expanded the range of our product portfolio and increased the size of our sales force, our revenue has grown rapidly. We have also been profitable and operating cash flow positive for each year since 2010.

[0001596532-19-000104:mdna:7]
To continue to grow our revenue, it is important that we both obtain new customers and sell additional products to existing customers. We expect that a substantial portion of our future sales will be follow-on sales to existing customers. It is also important that we are successful in markets other than cloud data center networking, such as the campus switching and WiFi networking markets. We intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new end customers more effectively, increase sales to existing customers, and provide services and support effectively. In order to support our strong growth, we have and may continue to accelerate our investment in infrastructure, such as enterprise resource planning software and other technologies to improve the efficiency of our operations.

[0001596532-19-000104:mdna:8]
[same as prior period, unchanged from 0001596532-18-000233:mdna:8]

[0001596532-19-000104:mdna:9]
Historically, large purchases by a relatively limited number of end customers have accounted for significant portion of our revenue. We have experienced unpredictability in the timing of large orders, especially with respect to our large end customers, due to the complexity of orders, the time it takes end customers to evaluate, test, qualify and accept our products and other factors specific to our end customers. Due to these factors, we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. For example, our sales to Microsoft as an end-user in the fiscal year ended December 31, 2018, representing 27% of our revenue during fiscal 2018, benefited from certain factors that may not repeat in fiscal 2019 or future fiscal years and the percentage of our revenue from Microsoft in fiscal 2019 is expected to decline. In addition, we have provided, and may in the future provide, pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur. Our gross margins may also fluctuate as a result of the timing of such sales to large end customers.

[0001596532-19-000104:mdna:10]
[same as prior period, unchanged from 0001596532-18-000233:mdna:15]

[0001596532-19-000104:mdna:11]
Three Months Ended March 31, 2019 Compared to Three Months Ended March 31, 2018

[0001596532-19-000104:mdna:12]
[same as prior period, unchanged from 0001596532-18-000233:mdna:23]

[0001596532-19-000104:mdna:13]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 505,415 |  |  | $ | 407,617 |  |  | $ | 97,798 |  |  | 24.0 | % |
| Service |  | 90,009 |  |  | 64,872 |  |  | 25,137 |  |  | 38.7 |  |
| Total revenue |  | 595,424 |  |  | 472,489 |  |  | 122,935 |  |  | 26.0 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |
| Product |  | 198,152 |  |  | 156,691 |  |  | 41,461 |  |  | 26.5 |  |
| Service |  | 16,702 |  |  | 12,879 |  |  | 3,823 |  |  | 29.7 |  |
| Total cost of revenue |  | 214,854 |  |  | 169,570 |  |  | 45,284 |  |  | 26.7 |  |
| Gross profit |  | $ | 380,570 |  |  | $ | 302,919 |  |  | $ | 77,651 |  |  | 25.6 | % |
| Gross margin |  | 63.9 | % |  | 64.1 | % |  |  |  |  |

[0001596532-19-000104:mdna:14]
[same as prior period, unchanged from 0001596532-18-000233:mdna:25]

[0001596532-19-000104:mdna:15]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | % of Total |  | 2018 |  | % of Total |
| Americas |  | $ | 439,638 |  |  | 73.8 | % |  | $ | 315,498 |  |  | 66.8 | % |
| Europe, Middle East and Africa |  | 111,269 |  |  | 18.7 |  |  | 121,886 |  |  | 25.8 |  |
| Asia-Pacific |  | 44,517 |  |  | 7.5 |  |  | 35,105 |  |  | 7.4 |  |
| Total revenue |  | $ | 595,424 |  |  | 100.0 | % |  | $ | 472,489 |  |  | 100.0 | % |

[0001596532-19-000104:mdna:16]
[same as prior period, unchanged from 0001596532-18-000233:mdna:27]

[0001596532-19-000104:mdna:17]
We generate revenue primarily from sales of our products. We also derive a portion of our revenue from sales of PCS, which is typically purchased in conjunction with our products, and subsequent renewals of those contracts. We expect our revenue may vary from period to period based on, among other things, the timing and size of orders, the delivery and acceptance of products, and the impact of significant transactions.  In addition, while we expect our revenue to continue to grow in absolute dollars on a year-over-year basis, our revenue growth rates are expected to decline as our business scales.

[0001596532-19-000104:mdna:18]
Product revenue increased $97.8 million, or 24.0%, in the three months ended March 31, 2019, compared to the same period in 2018.  The increase was primarily driven by sales to our existing customers as they continued to expand and upgrade their cloud networks. In addition, our newer switch products have continued to gain market acceptance, which has contributed to our revenue growth.  Service revenue increased $25.1 million, or 38.7%, in the three months ended March 31, 2019, compared to the same period in 2018 as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. We continue to experience pricing pressure on our products and services due to competition, but demand for our products and growth in our installed base has more than offset this pricing pressure during the period. However, we have recently experienced a slowdown in demand from certain large end customers, and this slowdown could continue, which may impact our future revenue growth.

[0001596532-19-000104:mdna:19]
[same as prior period, unchanged from 0001596532-18-000233:mdna:30]

[0001596532-19-000104:mdna:20]
Cost of product revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs in our manufacturing operations department, and other manufacturing-related costs associated with manufacturing our products and managing our inventory. Cost of providing PCS and other services consists primarily of personnel costs for our global customer support organization. We expect our cost of revenue to continue to increase as our revenue increases.

[0001596532-19-000104:mdna:21]
Cost of revenue increased $45.3 million, or 26.7%, in the three months ended March 31, 2019 compared to the same period in 2018. The increase in cost of revenue was primarily due to the corresponding increases in product and service revenues.

[0001596532-19-000104:mdna:22]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including sales to large end customers who generally receive lower pricing, manufacturing-related costs including costs associated

[0001596532-19-000104:mdna:23]
with supply chain sourcing activities, merchant silicon costs, the mix of products sold, and excess/obsolete inventory write-downs, including charges for excess/obsolete component inventory held by our contract manufacturers. We expect our gross margins to fluctuate over time, depending on the factors described above.

[0001596532-19-000104:mdna:24]
Gross margin decreased from 64.1% to 63.9% for the three months ended March 31, 2019 compared to the same period in 2018. The decrease in gross margin was primarily driven by a decrease in product margin due to increased product transition costs including some excess and obsolescence inventory-related charges, mostly offset by a favorable customer mix with lower discounts on smaller volume transactions. Service margin continued to improve due to a relatively fixed services cost base and growing service revenues.

[0001596532-19-000104:mdna:25]
[same as prior period, unchanged from 0001596532-18-000233:mdna:33]

[0001596532-19-000104:mdna:26]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. The largest component of our operating expenses is personnel costs. Personnel costs consist of wages, benefits, bonuses and, with respect to sales and marketing expenses, sales commissions. Personnel costs also include stock-based compensation and travel expenses. We expect operating expenses to continue to increase in absolute dollars in the near term as we continue to invest in the growth of our business.

[0001596532-19-000104:mdna:27]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 119,669 |  |  | $ | 102,362 |  |  | $ | 17,307 |  |  | 16.9 | % |
| Sales and marketing |  | 51,053 |  |  | 42,140 |  |  | 8,913 |  |  | 21.2 |  |
| General and administrative |  | 15,506 |  |  | 19,679 |  |  | (4,173 | ) |  | (21.2 | ) |
| Total operating expenses |  | $ | 186,228 |  |  | $ | 164,181 |  |  | $ | 22,047 |  |  | 13.4 | % |

[0001596532-19-000104:mdna:28]
[same as prior period, unchanged from 0001596532-18-000233:mdna:37]

[0001596532-19-000104:mdna:29]
Research and development expenses consist primarily of personnel costs, prototype expenses, third-party engineering and contractor support costs, and an allocated portion of facility and IT costs including depreciation. Our research and development efforts are focused on maintaining and developing additional functionality for our existing products and on new product development, including new releases and upgrades to our EOS software and applications. We expect our research and development expenses to increase in absolute dollars as we continue to invest heavily in software development in order to expand the capabilities of our cloud networking platform, introduce new products and features and build upon our technology leadership.

[0001596532-19-000104:mdna:30]
Research and development expenses increased $17.3 million, or 16.9% for the three months ended March 31, 2019 compared to the same period in 2018. The increase included a $10.4 million increase in personnel costs driven primarily by growth in headcount, including headcount additions from the two acquisitions we completed in the third quarter of 2018, a $3.2 million increase in research and development related facilities and IT costs, increased IT services and headcount growth, and a $2.9 million increase in new products compliance testing and certification services costs.

[0001596532-19-000104:mdna:31]
[same as prior period, unchanged from 0001596532-18-000233:mdna:40]

[0001596532-19-000104:mdna:32]
Sales and marketing expenses consist primarily of personnel costs, marketing and promotional activities, and an allocated portion of facility and IT costs including depreciation. We expect our sales and marketing expenses to increase in absolute dollars as we continue to expand our sales and marketing efforts worldwide.

[0001596532-19-000104:mdna:33]
Sales and marketing expenses increased $8.9 million, or 21.2%, for the three months ended March 31, 2019 compared to the same period in 2018. The increase included a $5.5 million increase in personnel costs driven primarily by increased headcount and a $1.5 million higher field demo costs.

[0001596532-19-000104:mdna:34]
[same as prior period, unchanged from 0001596532-18-000233:mdna:43]

[0001596532-19-000104:mdna:35]
General and administrative expenses consist primarily of Cisco and OptumSoft litigation-related expenses, personnel costs, professional services fees, and an allocated portion of facility and IT costs including depreciation. General and administrative personnel costs include those for our executive, finance, human resources and legal functions. Our professional services fees are primarily due to external legal, accounting and tax services.

[0001596532-19-000104:mdna:36]
General and administrative expenses decreased $4.2 million, or 21.2%, for the three months ended March 31, 2019 compared to the same period in 2018. The decrease was primarily due to a $5.6 million decrease in litigation fees related to a reduced level of litigation activities as a result of the settlement of our litigation with Cisco in August 2018. This decrease was partially offset by a $1.2 million increase in other legal and professional fees, and a $1.1 million increase in personnel costs.

[0001596532-19-000104:mdna:37]
[same as prior period, unchanged from 0001596532-18-000233:mdna:48]

[0001596532-19-000104:mdna:38]
Other income (expense) consists primarily of interest income from our cash, cash equivalents and marketable securities, gains and losses on our investments in privately-held companies, foreign currency transaction gains and losses, and interest expense on finance lease obligations. Upon adoption of ASC 842 on January 1, 2019, we derecognized the finance lease obligation associated with our build-to-suit lease, and therefore will not incur further interest expense as it relates to this obligation.  See Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion. We expect other income (expense) may fluctuate in the future as a result of the re-measurement of our private company equity investments upon the occurrence of observable price changes and/or impairments, changes in interest rates or returns on our cash and cash equivalents and marketable securities, and foreign currency exchange rate fluctuations.

[0001596532-19-000104:mdna:39]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |
| Interest expense |  | $ | — |  |  | $ | (687 | ) |  | $ | 687 |  |  | (100.0 | )% |
| Other income, net |  | 12,333 |  |  | 4,843 |  |  | 7,490 |  |  | 154.7 | % |
| Total other income (expense), net |  | $ | 12,333 |  |  | $ | 4,156 |  |  | $ | 8,177 |  |  | 196.8 | % |

[0001596532-19-000104:mdna:40]
The increases in other income (expense), net, during the three months ended March 31, 2019 as compared to the same period of 2018 was primarily driven by a $6.5 million increase in interest income as we continued to generate cash and expand our marketable securities portfolios. In addition, during the three months ended March 31, 2019, we recorded a $1.2 million unrealized gain on our investment in a privately-held company. See Note 5. Investments of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-19-000104:mdna:41]
[same as prior period, unchanged from 0001596532-18-000233:mdna:52]

[0001596532-19-000104:mdna:42]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. Earnings from our non-U.S. activities are subject to local country income tax and may also be subject to U.S. income tax. Generally, our U.S. tax obligations are reduced by a credit for foreign income taxes paid on these foreign earnings which avoids double taxation. Our tax expense to date consists of federal, state and foreign current and deferred income taxes.

[0001596532-19-000104:mdna:43]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |
| Income before income taxes |  | $ | 206,675 |  |  | $ | 142,894 |  |  | $ | 63,781 |  |  | 44.6 | % |
| Provision for (benefit from) income taxes |  | 5,646 |  |  | (1,644 | ) |  | 7,290 |  |  | (443.4 | )% |
| Effective tax rate |  | 2.7 | % |  | (1.2 | )% |  |  |  |  |

[0001596532-19-000104:mdna:44]
For the three months ended March 31, 2019 and 2018, we recorded an expense of $5.6 million and a benefit of $1.6 million for income taxes, respectively. The change in our income taxes was attributable to the overall increase in worldwide earnings, which proportionally exceeded the increase in excess tax benefits attributable to equity compensation.

[0001596532-19-000104:mdna:45]
[same as prior period, unchanged from 0001596532-18-000233:mdna:62]

[0001596532-19-000104:mdna:46]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of March 31, 2019, our total balance of cash, cash equivalents and marketable securities was $2.2 billion, of which approximately $303.4 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-19-000104:mdna:47]
Our cash, cash equivalents and marketable securities are held for working capital purposes. Our marketable securities investment portfolio is primarily invested in highly-rated securities with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities together with cash generated from operations will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, costs incurred related to outstanding litigation claims, and stock repurchases. If we require or elect to seek additional capital through debt or

[0001596532-19-000104:mdna:48]
equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-19-000104:mdna:49]
[same as prior period, unchanged from 0001596532-18-000233:mdna:65]

[0001596532-19-000104:mdna:50]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 170,097 |  |  | $ | 195,541 |  |
| Cash used in investing activities |  | (35,220 | ) |  | (183,864 | ) |
| Cash provided by financing activities |  | 24,473 |  |  | 15,308 |  |
| Effect of exchange rate changes |  | 195 |  |  | (14 | ) |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 159,545 |  |  | $ | 26,971 |  |

[0001596532-19-000104:mdna:51]
[same as prior period, unchanged from 0001596532-18-000233:mdna:67]

[0001596532-19-000104:mdna:52]
During the three months ended March 31, 2019, cash provided by operating activities was $170.1 million, primarily from net income of $201.0 million and non-cash adjustments to net income of $28.7 million, offset partially by a net decrease of $59.6 million in cash from changes in our operating assets and liabilities. Our operating cash benefited from a $60.5 million reduction in accounts receivable resulting from strong cash collections in the quarter, and a $30.7 million decrease in prepaid expenses and other current assets including a reduction in deferred cost of inventory related to recognition of product deferred revenue. These favorable changes were more than offset by an $82.6 million increase in inventories primarily related to upcoming product transitions, a $50.8 million decrease in deferred revenue primarily due to the recognition of product deferred revenue in the quarter offset partially by an increase in deferred service revenue as our install base continues to grow, and a $19.0 million decline in accrued liabilities due to annual corporate bonus payments and timing of vendor payments related to product development activities and inventory purchases.

[0001596532-19-000104:mdna:53]
During the three months ended March 31, 2018, cash provided by operating activities was $195.5 million, primarily from net income of $144.5 million with non-cash adjustments to net income of $23.0 million, and a net increase of $28.0 million in cash from changes in our operating assets and liabilities. Our operating cash benefited $40.0 million from a decline in accounts receivable resulted from strong cash collections in the quarter, $38.1 million from decreased inventory driven by improved management and timing of receipts, and $20.0 million from an increase in accounts payable due to timing of inventory purchases and receipts. These favorable changes were partially offset by a $48.1 million decline in accrued liabilities due to corporate bonus payments and timing of vendor payments related to product development activities and inventory purchases, a $42.7 million decline in deferred revenue primarily due to revenue recognition as customers continued to certify and accept our 945 investigation-related product redesigns in the first quarter of 2018.

[0001596532-19-000104:mdna:54]
[same as prior period, unchanged from 0001596532-18-000233:mdna:70]

[0001596532-19-000104:mdna:55]
During the three months ended March 31, 2019, cash used in investing activities was $35.2 million, consisting of purchases of available-for-sale securities of $332.2 million, offset by proceeds of $302.3 million from maturities of marketable securities, and purchases of property and equipment of $5.2 million.

[0001596532-19-000104:mdna:56]
During the three months ended March 31, 2018, cash used in investing activities was $183.9 million, consisting of purchases of available-for-sale securities of $268.0 million, offset by proceeds of $90.4 million from maturities of marketable securities, and purchases of property, equipment and other assets of $6.3 million.

[0001596532-19-000104:mdna:57]
[same as prior period, unchanged from 0001596532-18-000233:mdna:73]

[0001596532-19-000104:mdna:58]
During the three months ended March 31, 2019, cash provided by financing activities was $24.5 million, consisting of proceeds from the issuance of common stock under employee equity incentive plans of $26.3 million, offset by minimum payroll taxes withheld of $1.9 million upon vesting of restricted stock units.

[0001596532-19-000104:mdna:59]
During the three months ended March 31, 2018, cash provided by financing activities was $15.3 million, consisting primarily of proceeds from the issuance of common stock under employee equity incentive plans of $17.3 million.

[0001596532-19-000104:mdna:60]
[same as prior period, unchanged from 0001596532-18-000233:mdna:76]

[0001596532-19-000104:mdna:61]
As of March 31, 2019, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-19-000104:mdna:62]
[same as prior period, unchanged from 0001596532-18-000233:mdna:78]

[0001596532-19-000104:mdna:63]
Our contractual obligations represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalent and marketable securities. As of March 31, 2019, our principal commitments consist primarily of obligations under operating leases for offices and data centers and purchase commitments with our contract manufacturers and suppliers. See Note 6. Leases and Note 7. Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for future payment commitments under leases and our purchase commitments as of March 31, 2019, respectively.

[0001596532-19-000104:mdna:64]
[same as prior period, unchanged from 0001596532-18-000233:mdna:80]

[0001596532-19-000104:mdna:65]
Our management’s discussion and analysis of financial condition and results of operations is based on our unaudited condensed consolidated financial statements, which have been prepared in accordance with GAAP.  The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. We believe the critical accounting policies and estimates discussed in the "Management's Discussion and Analysis of Financial Condition and Results of Operations" section of our Annual Report on Form 10-K filed with the SEC on February 15, 2019, reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting policies and estimates as disclosed in our Annual Report on Form 10-K.

[0001596532-19-000104:mdna:66]
[same as prior period, unchanged from 0001596532-18-000233:mdna:101]

[0001596532-19-000104:mdna:67]
Refer to the sections titled “Recently Adopted Accounting Pronouncements” and “Recent Accounting Pronouncements Not Yet Effective” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
