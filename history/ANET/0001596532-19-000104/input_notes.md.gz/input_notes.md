# ANET notes — 0001596532-19-000104


## anet:AssetsandLiabilitiesLesseeTableTextBlock

[0001596532-19-000104:notes:1]
The following table summarizes the supplemental balance sheet information related to our operating leases as of March 31, 2019 (in thousands).

[0001596532-19-000104:notes:2]
|  |  | Financial Statement Classification |  | March 31, 2019 |
| Right-of-use assets: |  |  |  |  |
| Operating lease right-of-use assets |  | Operating lease right-of-use assets |  | $ | 98,552 |  |
| Lease liabilities: |  |  |  |  |
| Operating lease liabilities, current |  | Other current liabilities |  | 14,139 |  |
| Operating lease liabilities, non-current |  | Operating lease liabilities, non-current |  | 93,616 |  |
| Total operating lease liabilities |  |  |  | $ | 107,755 |  |


## anet:LesseeWeightedAverageLeaseTermsAndDiscountRatesTableTextBlock

[0001596532-19-000104:notes:3]
|  |  | March 31, 2019 |
| Weighted-average remaining lease term — operating leases |  | 6.4 years |
| Weighted-average discount rate — operating leases |  | 5.1% |


## anet:ScheduleofSharebasedCompensationSharesAvailableForGrantActivityTableTextBlock

[0001596532-19-000104:notes:4]
The following table presents the stock activity and the total number of shares available for grant under the 2014 Plan as of March 31, 2019 (in thousands):

[0001596532-19-000104:notes:5]
|  |  | Number of Shares |
| Balance—December 31, 2018 |  | 15,386 |  |
| Options granted |  | (74 | ) |
| RSUs granted |  | (41 | ) |
| Options canceled |  | 8 |  |
| RSUs forfeited |  | 18 |  |
| Shares traded for taxes |  | 6 |  |
| Balance—March 31, 2019 |  | 15,303 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001596532-19-000104:notes:6]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2019, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2018 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant intercompany accounts and transactions have been eliminated.

[0001596532-19-000104:notes:7]
Our condensed consolidated financial statements and related financial information in this Quarterly Report on Form 10-Q should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2018, filed with the SEC on February 15, 2019.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-19-000104:notes:8]
[same as prior period, unchanged from 0001596532-18-000233:notes:7]

[0001596532-19-000104:notes:9]
[same as prior period, unchanged from 0001596532-18-000233:notes:8]

[0001596532-19-000104:notes:10]
The total fair value of consideration transferred for these acquisitions was approximately $117.4 million, which consisted of $101.8 million in cash and $15.6 million for the fair value of 58,072 shares of our common stock issued. The following table summarizes our preliminary purchase price allocation of the two acquisitions, in aggregate, based on the estimated fair value of the assets acquired and liabilities assumed at their respective acquisition dates (in thousands):

[0001596532-19-000104:notes:11]
|  |  | Purchase Price Allocation |
| Cash and cash equivalents |  | $ | 4,953 |  |
| Other tangible assets |  | 23,709 |  |
| Liabilities |  | (28,706 | ) |
| Intangible assets |  | 63,720 |  |
| Goodwill |  | 53,684 |  |
| Net assets acquired |  | $ | 117,360 |  |

[0001596532-19-000104:notes:12]
We continue the process of identifying and evaluating pending escrow claims related to inventory, tax and other liabilities.  Accordingly, the preliminary values reflected in the table above are subject to further measurement period adjustments.

[0001596532-19-000104:notes:13]
[same as prior period, unchanged from 0001596532-18-000233:notes:11]

[0001596532-19-000104:notes:14]
|  |  | Acquisition Date Fair Value |  | Estimated Useful Life |
| Developed technology |  | $ | 52,510 |  |  | 5 years |
| Customer relationships |  | 7,080 |  |  | 7 years |
| Trade name |  | 2,470 |  |  | 3 years |
| Others |  | 1,660 |  |  | 1 year |
| Total intangible assets acquired |  | $ | 63,720 |  |  |  |

[0001596532-19-000104:notes:15]
The goodwill of $53.7 million is primarily attributable to the expected synergies created by incorporating the solutions of the acquired businesses into our technology platform, and the value of the assembled workforce. We operate under a single reportable segment. The goodwill is not deductible for income taxes purposes.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-19-000104:notes:16]
7.    Commitments and Contingencies

[0001596532-19-000104:notes:17]
Leases

[0001596532-19-000104:notes:18]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2028. See Note 6 for our future minimum payment obligations under our leases as of March 31, 2019.

[0001596532-19-000104:notes:19]
Purchase Commitments

[0001596532-19-000104:notes:20]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of March 31, 2019, we had non-cancellable purchase commitments of $253.8 million, of which $216.2 million was to our contract manufacturers and suppliers. In addition, we have provided deposits to secure our obligations to purchase inventory. We had $22.3 million and $17.4 million in deposits as of March 31, 2019 and December 31, 2018, respectively. These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.

[0001596532-19-000104:notes:21]
Guarantees

[0001596532-19-000104:notes:22]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-19-000104:notes:23]
Legal Proceedings

[0001596532-19-000104:notes:24]
OptumSoft, Inc. Matters

[0001596532-19-000104:notes:25]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies; and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-19-000104:notes:26]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft access to our software for evaluation by OptumSoft; (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches; (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers; (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us; and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors, who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dated July 28, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.

[0001596532-19-000104:notes:27]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we asserted our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we asserted that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We asked the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also asserted that, even if we are found not to own certain components, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation. On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have meritorious defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-19-000104:notes:28]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II, including the application of the Court’s interpretation of the 2004 agreement to any other source code that OptumSoft claims to own and the trade secret misappropriation and confidentiality claims. The Phase II Trial is set for the first date the court is available after December 2, 2019.

[0001596532-19-000104:notes:29]
We intend to vigorously defend against any claims brought against us by OptumSoft.  However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor.  For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft.  If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license.  An adverse litigation ruling could result in a significant damages award against us and injunctive relief. In addition, OptumSoft could assert additional or different claims against us, including claims that our license from OptumSoft is invalid.

[0001596532-19-000104:notes:30]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated.  However, the outcome of litigation is inherently uncertain. Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-19-000104:notes:31]
Other Matters

[0001596532-19-000104:notes:32]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-19-000104:notes:33]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2019, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-19-000104:notes:34]
[same as prior period, unchanged from 0001596532-18-000233:notes:59]

[0001596532-19-000104:notes:35]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |
| Contract assets, beginning balance |  | $ | 6,341 |  |  | $ | — |  |
| Contract assets, ending balance |  | 5,699 |  |  | — |  |

[0001596532-19-000104:notes:36]
[same as prior period, unchanged from 0001596532-18-000233:notes:61]

[0001596532-19-000104:notes:37]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |
| Contract liabilities, beginning balance |  | $ | 32,595 |  |  | $ | 16,521 |  |
| Less: Revenue recognized from beginning balance |  | (2,826 | ) |  | (1,694 | ) |
| Less: Beginning balance reclassified to deferred revenue |  | (1,259 | ) |  | (806 | ) |
| Add: Contract liabilities recognized |  | 8,804 |  |  | 4,817 |  |
| Contract liabilities, ending balance |  | $ | 37,314 |  |  | $ | 18,838 |  |


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001596532-19-000104:notes:38]
[same as prior period, unchanged from 0001596532-18-000233:notes:63]

[0001596532-19-000104:notes:39]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |
| Deferred revenue, beginning balance (1) |  | $ | 587,227 |  |  | $ | 498,740 |  |
| Less: Revenue recognized from beginning balance |  | (190,597 | ) |  | (157,684 | ) |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 139,841 |  |  | 114,998 |  |
| Deferred revenue, ending balance |  | $ | 536,471 |  |  | $ | 456,054 |  |
| ______________________ |  |  |  |  |
| (1) The beginning balance of the three months ended March 31, 2018 excludes $16.5 million that was reclassified to other current liabilities and other long-term liabilities at January 1, 2018 as a result of our adoption of ASC 606. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-19-000104:notes:40]
8.    Equity Award Plan Activities

[0001596532-19-000104:notes:41]
[same as prior period, unchanged from 0001596532-18-000233:notes:68]

[0001596532-19-000104:notes:42]
Effective January 1, 2019, our board of directors authorized an increase of 756,679 shares to shares available for issuance under our 2014 Employee Stock Purchase Plan (the “ESPP”).  Pursuant to the ESPP, the 2019 share increase was determined based the lesser of 1% of the total shares of common stock outstanding on December 31, 2018, 2,500,000 shares, or such amount as determined by our board of directors. During the three months ended March 31, 2019, we issued 45,743 shares at a weighted-average purchase price of $190.31 per share, respectively, under the ESPP. As of March 31, 2019, there remained 3,244,374 shares available for issuance under the ESPP.

[0001596532-19-000104:notes:43]
[same as prior period, unchanged from 0001596532-18-000233:notes:71]

[0001596532-19-000104:notes:44]
[same as prior period, unchanged from 0001596532-18-000233:notes:72]

[0001596532-19-000104:notes:45]
|  |  | Options Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding |
| Balance—December 31, 2018 |  | 5,899 |  |  | $ | 37.09 |  |  | 5.2 |  | $ | 1,027,741 |  |
| Options granted |  | 74 |  |  | 225.25 |  |  |  |  |  |
| Options exercised |  | (613 | ) |  | 28.71 |  |  |  |  |  |
| Options canceled |  | (8 | ) |  | 35.06 |  |  |  |  |  |
| Balance—March 31, 2019 |  | 5,352 |  |  | $ | 40.64 |  |  | 5.1 |  | $ | 1,465,345 |  |
| Vested and exercisable—March 31, 2019 |  | 2,762 |  |  | $ | 26.11 |  |  | 4.5 |  | $ | 796,325 |  |

[0001596532-19-000104:notes:46]
[same as prior period, unchanged from 0001596532-18-000233:notes:74]

[0001596532-19-000104:notes:47]
A summary of the RSU activity under our 2014 equity incentive plan (“2014 Plan”) and related information are presented below (in thousands, except years and per share amounts):

[0001596532-19-000104:notes:48]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2018 |  | 1,308 |  |  | $ | 150.60 |  |  | 1.5 |  | $ | 275,638 |  |
| RSUs granted |  | 41 |  |  | 226.29 |  |  |  |  |  |
| RSUs vested |  | (132 | ) |  | 111.39 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (18 | ) |  | 175.69 |  |  |  |  |  |
| Unvested balance—March 31, 2019 |  | 1,199 |  |  | $ | 157.14 |  |  | 1.5 |  | $ | 376,948 |  |

[0001596532-19-000104:notes:49]
[same as prior period, unchanged from 0001596532-18-000233:notes:77]

[0001596532-19-000104:notes:50]
[same as prior period, unchanged from 0001596532-18-000233:notes:78]

[0001596532-19-000104:notes:51]
Total stock-based compensation expense related to options, restricted stock units, restricted stock, and employee stock purchase rights granted were allocated as follows (in thousands):

[0001596532-19-000104:notes:52]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |
| Cost of revenue |  | $ | 1,098 |  |  | $ | 1,202 |  |
| Research and development |  | 13,131 |  |  | 10,945 |  |
| Sales and marketing |  | 6,534 |  |  | 5,960 |  |
| General and administrative |  | 3,528 |  |  | 2,744 |  |
| Total stock-based compensation |  | $ | 24,291 |  |  | $ | 20,851 |  |

[0001596532-19-000104:notes:53]
As of March 31, 2019, unrecognized stock-based compensation expenses by award type and their expected weighted-average recognition periods are summarized in the following table (in thousands, except years).

[0001596532-19-000104:notes:54]
|  |  | March 31, 2019 |
|  |  | Stock Option |  | RSU |  | ESPP |  | Restricted Stock |
| Unrecognized stock-based compensation expense |  | $ | 58,501 |  |  | $ | 167,360 |  |  | $ | 6,871 |  |  | $ | 5,028 |  |
| Weighted-average amortization period |  | 3.8 years |  |  | 3.2 years |  |  | 1.0 years |  |  | 3.5 years |  |


## us-gaap:EarningsPerShareTextBlock

[0001596532-19-000104:notes:55]
9.    Net Income Per Share Available to Common Stock

[0001596532-19-000104:notes:56]
[same as prior period, unchanged from 0001596532-18-000233:notes:86]

[0001596532-19-000104:notes:57]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |
| Numerator: |  |  |  |  |
| Basic: |  |  |  |  |
| Net income |  | $ | 201,029 |  |  | $ | 144,538 |  |
| Less: undistributed earnings allocated to participating securities |  | (118 | ) |  | (89 | ) |
| Net income available to common stockholders, basic |  | $ | 200,911 |  |  | $ | 144,449 |  |
| Diluted: |  |  |  |  |
| Net income attributable to common stockholders, basic |  | $ | 200,911 |  |  | $ | 144,449 |  |
| Add: undistributed earnings allocated to participating securities |  | 7 |  |  | 7 |  |
| Net income attributable to common stockholders, diluted |  | $ | 200,918 |  |  | $ | 144,456 |  |
| Denominator: |  |  |  |  |
| Basic: |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 75,920 |  |  | 73,994 |  |
| Diluted: |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 75,920 |  |  | 73,994 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |
| Stock options and RSUs |  | 5,279 |  |  | 6,670 |  |
| Employee stock purchase plan |  | 2 |  |  | 57 |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted |  | 81,201 |  |  | 80,721 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |
| Basic |  | $ | 2.65 |  |  | $ | 1.95 |  |
| Diluted |  | $ | 2.47 |  |  | $ | 1.79 |  |

[0001596532-19-000104:notes:58]
[same as prior period, unchanged from 0001596532-18-000233:notes:88]

[0001596532-19-000104:notes:59]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |
| Stock options and RSUs to purchase common stock |  | 162 |  |  | 22 |  |
| Employee stock purchase plan |  | 105 |  |  | 26 |  |
| Total |  | 267 |  |  | 48 |  |


## us-gaap:EquitySecuritiesWithoutReadilyDeterminableFairValueTableTextBlock

[0001596532-19-000104:notes:60]
The following tables summarize activities related to our investments in privately-held companies during the three months ended March 31, 2019 and 2018 (in thousands):

[0001596532-19-000104:notes:61]
|  |  | Three Months Ended March 31, 2019 |
|  |  | Cost of Investments |  | Cumulative Downward Adjustment/ Impairment |  | Cumulative Upward Adjustment |  | Carrying Amount |
| Balance of investments held at the beginning of the period |  | $ | 44,136 |  |  | $ | (15,000 | ) |  | $ | 1,200 |  |  | $ | 30,336 |  |
| Additions |  | — |  |  | — |  |  | 1,150 |  |  | 1,150 |  |
| Balance of investments held at the end of the period |  | $ | 44,136 |  |  | $ | (15,000 | ) |  | $ | 2,350 |  |  | $ | 31,486 |  |

[0001596532-19-000104:notes:62]
|  |  | Three Months Ended March 31, 2018 |
|  |  | Cost of Investments |  | Cumulative Downward Adjustment/ Impairment |  | Cumulative Upward Adjustment |  | Carrying Amount |
| Balance of investments held at the beginning of the period |  | $ | 36,136 |  |  | $ | — |  |  | $ | — |  |  | $ | 36,136 |  |
| Additions |  | — |  |  | — |  |  | — |  |  | — |  |
| Balance of investments held at the end of the period |  | $ | 36,136 |  |  | $ | — |  |  | $ | — |  |  | $ | 36,136 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-19-000104:notes:63]
The following tables summarize the amortized costs, unrealized gains and losses and fair value of these financial assets by significant investment category and their level within the fair value hierarchy (in thousands):

[0001596532-19-000104:notes:64]
|  |  | March 31, 2019 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 445,647 |  |  | $ | — |  |  | $ | — |  |  | $ | 445,647 |  |  | $ | 445,647 |  |  | $ | — |  |  | $ | — |  |
| Agency securities |  | 22,200 |  |  | — |  |  | — |  |  | 22,200 |  |  | — |  |  | 22,200 |  |  | — |  |
| U.S. government notes |  | 4,993 |  |  | — |  |  | — |  |  | 4,993 |  |  | 4,993 |  |  | — |  |  | — |  |
|  |  | 472,840 |  |  | — |  |  | — |  |  | 472,840 |  |  | 450,640 |  |  | 22,200 |  |  | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 48,514 |  |  | — |  |  | — |  |  | 48,514 |  |  | — |  |  | 48,514 |  |  | — |  |
| Certificates of deposits (1) |  | 5,000 |  |  | — |  |  | — |  |  | 5,000 |  |  | — |  |  | 5,000 |  |  | — |  |
| U.S. government notes |  | 386,734 |  |  | 397 |  |  | (97 | ) |  | 387,034 |  |  | 387,034 |  |  | — |  |  | — |  |
| Corporate bonds |  | 642,662 |  |  | 1,326 |  |  | (279 | ) |  | 643,709 |  |  | — |  |  | 643,709 |  |  | — |  |
| Agency securities |  | 256,913 |  |  | 407 |  |  | (150 | ) |  | 257,170 |  |  | — |  |  | 257,170 |  |  | — |  |
|  |  | 1,339,823 |  |  | 2,130 |  |  | (526 | ) |  | 1,341,427 |  |  | 387,034 |  |  | 954,393 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,218 |  |  | — |  |  | — |  |  | 4,218 |  |  | 4,218 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 1,816,881 |  |  | $ | 2,130 |  |  | $ | (526 | ) |  | $ | 1,818,485 |  |  | $ | 841,892 |  |  | $ | 976,593 |  |  | $ | — |  |

[0001596532-19-000104:notes:65]
|  |  | December 31, 2018 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 322,080 |  |  | $ | — |  |  | $ | — |  |  | $ | 322,080 |  |  | $ | 322,080 |  |  | $ | — |  |  | $ | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 59,479 |  |  | — |  |  | — |  |  | 59,479 |  |  | — |  |  | 59,479 |  |  | — |  |
| Certificates of deposits (1) |  | 5,000 |  |  | — |  |  | — |  |  | 5,000 |  |  | — |  |  | 5,000 |  |  | — |  |
| U.S. government notes |  | 308,946 |  |  | 118 |  |  | (286 | ) |  | 308,778 |  |  | 308,778 |  |  | — |  |  | — |  |
| Corporate bonds |  | 660,353 |  |  | 264 |  |  | (1,399 | ) |  | 659,218 |  |  | — |  |  | 659,218 |  |  | — |  |
| Agency securities |  | 273,993 |  |  | 240 |  |  | (511 | ) |  | 273,722 |  |  | — |  |  | 273,722 |  |  | — |  |
|  |  | 1,307,771 |  |  | 622 |  |  | (2,196 | ) |  | 1,306,197 |  |  | 308,778 |  |  | 997,419 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,214 |  |  | — |  |  | — |  |  | 4,214 |  |  | 4,214 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 1,634,065 |  |  | $ | 622 |  |  | $ | (2,196 | ) |  | $ | 1,632,491 |  |  | $ | 635,072 |  |  | $ | 997,419 |  |  | $ | — |  |

[0001596532-19-000104:notes:66]
______________________

[0001596532-19-000104:notes:67]
(1) As of March 31, 2019 and December 31, 2018, all of our certificates of deposits were domestic deposits.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-19-000104:notes:68]
[same as prior period, unchanged from 0001596532-18-000233:notes:93]

[0001596532-19-000104:notes:69]
[same as prior period, unchanged from 0001596532-18-000233:notes:94]

[0001596532-19-000104:notes:70]
[same as prior period, unchanged from 0001596532-18-000233:notes:95]

[0001596532-19-000104:notes:71]
[same as prior period, unchanged from 0001596532-18-000233:notes:96]

[0001596532-19-000104:notes:72]
[same as prior period, unchanged from 0001596532-18-000233:notes:97]

[0001596532-19-000104:notes:73]
We measure and report our cash equivalents, restricted cash, and available-for-sale marketable securities at fair value on a recurring basis. The following tables summarize the amortized costs, unrealized gains and losses and fair value of these financial assets by significant investment category and their level within the fair value hierarchy (in thousands):

[0001596532-19-000104:notes:74]
We did not realize any other-than-temporary losses on our marketable securities for the three months ended March 31, 2019 and 2018. As of March 31, 2019 and 2018, total unrealized losses of our marketable securities that had been in a continuous unrealized loss position were immaterial. We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. As interest rates increase, those marketable securities purchased at a lower yield show a mark-to-market unrealized loss. The unrealized losses are due primarily to changes in credit spreads and interest rates. We expect to realize the full value of these investments upon maturity or sale and therefore, we do not consider any of our marketable securities to be other-than-temporarily impaired as of March 31, 2019.

[0001596532-19-000104:notes:75]
As of March 31, 2019, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale marketable securities, by remaining contractual maturity, are as follows (in thousands):

[0001596532-19-000104:notes:76]
|  |  | March 31, 2019 |
| Due in 1 year or less |  | $ | 976,638 |  |
| Due in 1 year through 2 years |  | 364,789 |  |
| Total marketable securities |  | $ | 1,341,427 |  |

[0001596532-19-000104:notes:77]
The weighted-average remaining duration of our current marketable securities is approximately 0.8 years as of March 31, 2019.  As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying unaudited condensed consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-19-000104:notes:78]
10.    Income Taxes

[0001596532-19-000104:notes:79]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Income before income taxes |  | $ | 206,675 |  |  | $ | 142,894 |  |
| Provision for (benefit from) income taxes |  | 5,646 |  |  | (1,644 | ) |
| Effective tax rate |  | 2.7 | % |  | (1.2 | )% |

[0001596532-19-000104:notes:80]
The effective tax rates above reflect tax expense recorded on pre-tax income in the three months ended March 31, 2019 and an overall tax benefit recorded on pre-tax income in the three months ended March 31, 2018. The change in effective tax rate in the three months ended March 31, 2019, as compared to the same period in 2018, was primarily due to the overall increase in worldwide earnings, which proportionally exceeded the increase in excess tax benefits attributable to equity compensation.

[0001596532-19-000104:notes:81]
[same as prior period, unchanged from 0001596532-18-000233:notes:107]


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-19-000104:notes:82]
[same as prior period, unchanged from 0001596532-18-000233:notes:111]

[0001596532-19-000104:notes:83]
[same as prior period, unchanged from 0001596532-18-000233:notes:112]

[0001596532-19-000104:notes:84]
Our investments are in the equity of privately-held companies, which do not have readily determinable fair values. The following tables summarize activities related to our investments in privately-held companies during the three months ended March 31, 2019 and 2018 (in thousands):

[0001596532-19-000104:notes:85]
As of March 31, 2019 and December 31, 2018, the carrying amount of the investments that have been remeasured to fair value as a result of impairment or observable transactions totaled $26.5 million and $22.3 million, respectively, and are classified within Level III of the fair value hierarchy.


## us-gaap:LeaseCostTableTextBlock

[0001596532-19-000104:notes:86]
The following table summarizes our lease costs for the three months ended March 31, 2019 (in thousands).

[0001596532-19-000104:notes:87]
|  |  | Financial Statement Classification |  | Three Months Ended March 31, 2019 |
| Operating lease costs: |  |  |  |  |
| Fixed lease costs |  | Operating expenses |  | $ | 5,483 |  |
| Variable lease costs |  | Operating expenses |  | 1,464 |  |
| Total operating lease costs |  |  |  | $ | 6,947 |  |


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0001596532-19-000104:notes:88]
6.    Leases

[0001596532-19-000104:notes:89]
Operating Leases

[0001596532-19-000104:notes:90]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2028. Some of our leases include options to extend the term of such leases for a period from three months to up to 10 years and/or options to early terminate the leases. As of March 31, 2019, we did not include any such options in determining the lease terms because we were not reasonably certain that we would exercise those options. Most of our leases require us to pay certain operating expenses in addition to base rent, such as taxes, repairs, and insurance and contain renewal and escalation clauses.

[0001596532-19-000104:notes:91]
Build-to-Suit Lease

[0001596532-19-000104:notes:92]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013. Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction, we were deemed the accounting owner of the building during the construction period in accordance with ASC 840. As a result, we recognized assets under construction and corresponding liabilities on the consolidated balance sheet. Upon completion of the construction in 2013, we concluded that we had forms of continued economic involvement in the facility, and therefore did not meet with the provisions for sale-leaseback accounting. Pursuant to ASC 840, we continued to carry the assets and liabilities capitalized during the construction period and accounted for the lease as a capital lease for the building and an operating lease for the underlying land.

[0001596532-19-000104:notes:93]
Upon our adoption of ASC 842 on January 1, 2019 (see Note 1), we derecognized the assets and the lease financing liabilities recorded for the building. The build-to-suit lease was re-classified as an operating lease effective January 1, 2019 in accordance with ASC 842.

[0001596532-19-000104:notes:94]
The operating lease costs in the table above include costs for long-term leases and short-term leases. Total short-term lease costs was immaterial. Fixed lease costs include expenses recognized for base rent payments on a straight-lined basis. Variable lease costs primarily include maintenance, utilities and operating expenses that are incremental to the fixed base rent payments, and are excluded from the calculation of ROU assets and operating lease liabilities.  For the three months ended March 31, 2019, cash paid for amounts associated with our operating lease liabilities was approximately $4.4 million, which was classified as operating activities in the condensed consolidated statements of cash flows.

[0001596532-19-000104:notes:95]
Prior to 2019, we recognized rent expense for our operating leases under the legacy guidance ASC 840. For the three months ended March 31, 2018, rent expense for all operating leases amounted to $2.8 million, and did not include maintenance, utilities and other operating expenses in accordance with ASC 840.

[0001596532-19-000104:notes:96]
The following table shows our undiscounted future fixed payment obligations under our recognized operating leases and a reconciliation to the operating lease liabilities as of March 31, 2019 (in thousands).

[0001596532-19-000104:notes:97]
|  |  | March 31, 2019 |
| Remainder of 2019 |  | $ | 14,013 |  |
| 2020 |  | 20,012 |  |
| 2021 |  | 20,773 |  |
| 2022 |  | 21,134 |  |
| 2023 |  | 17,598 |  |
| 2024 and thereafter |  | 35,870 |  |
| Total future fixed operating lease payments |  | 129,400 |  |
| Less: |  |  |
| Imputed interest |  | (21,645 | ) |
| Total operating lease liabilities |  | $ | 107,755 |  |


## us-gaap:LesseeLeasesPolicyTextBlock

[0001596532-19-000104:notes:98]
Our initial application date of ASC 842 is January 1, 2019. For the periods prior to 2019, our leases were accounted for under the legacy guidance in ASC 840.

[0001596532-19-000104:notes:99]
We determine if a contract contains a lease at inception. The lease term represents the non-cancellable period for which we have the right to use an underlying asset, which may include periods covered by certain options to extend and/or terminate the lease. Lease liabilities and corresponding right-of-use ("ROU") assets are recognized at the commencement date of a lease. Leases with an initial lease term of 12 months or less are not recorded on the balance sheet.

[0001596532-19-000104:notes:100]
A lease liability is the present value of our future fixed lease payments. As none of our leases provides an implicit interest rate, we use our estimated incremental borrowing rate as of the lease commencement date to determine the present value of future lease payments. Our discount rates are determined and applied at a company level. An ROU asset is calculated as the lease liability, adjusted by unamortized initial direct costs, unamortized lease incentives received, cumulative deferred or prepaid lease payments, and accumulated impairment losses.

[0001596532-19-000104:notes:101]
For fixed lease payments under operating leases, lease expense is recognized on a straight-lined basis over the lease term. For variable lease payments, lease expense is recognized when incurred. For operating leases that include both lease and non-lease components, we account for lease and non-lease components as a single lease component for all classes of underlying assets and, therefore, recognize non-lease payments as lease expense.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-19-000104:notes:102]
Recently Adopted Accounting Pronouncements

[0001596532-19-000104:notes:103]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2016-02, Leases (“ASU 2016-02”), and in July 2018, the FASB issued ASU 2018-11, Leases (Topic 842): Targeted Improvements (“ASU 2018-11”) (collectively referred to as "ASC 842"). Under the guidance, lessees are required to recognize assets and lease liabilities on the balance sheet for most leases including operating leases and provide enhanced disclosures. Companies are required to adopt this guidance using a modified retrospective approach and apply the transition provisions under the guidance at either 1) the later of the beginning of the earliest comparative period presented in the financial statements and the commencement date of the lease, or 2) the beginning of the period of adoption (i.e. on the effective date). Under the transition method using the second application date, a company initially applies the new leases standard at the adoption date and recognizes a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption.

[0001596532-19-000104:notes:104]
We adopted the guidance on January 1, 2019 using the modified retrospective transition method and initially applied the transition provisions at January 1, 2019, which allows us to continue to apply the legacy guidance in ASC 840 for periods prior to 2019. We elected the package of transition practical expedients, which, among other things, allows us to keep the historical lease classifications and not have to reassess the lease classification for any existing leases as of the date of adoption. We also made the following accounting policy elections as allowed by ASC 842:

[0001596532-19-000104:notes:105]
| • | to apply the short-term lease exception, which allows us to keep leases with an initial term of twelve months or less off the balance sheet. |

[0001596532-19-000104:notes:106]
| • | to account for each separate lease component of a contract and its associated non-lease components as a single lease component for all our leases. |

[0001596532-19-000104:notes:107]
As a result of the adoption, we recognized operating leases that were previously not recognized on the consolidated balance sheets. In addition, we derecognized the assets and the lease financing liabilities previously recorded for our headquarters building under a build-to-suit lease. Under ASC 842, this lease is recognized as an operating lease in our condensed consolidated financial statements beginning in the first quarter of 2019. The table below summarizes the impact of the adoption of ASC 842 on the condensed consolidated balance sheet as of January 1, 2019 (in thousands).

[0001596532-19-000104:notes:108]
|  |  |  |  | Adjustments for the Adoption of ASC 842 |  |  |
| Balance Sheet Line Item |  | December 31,2018 |  | Derecognition of Build-to-Suit Lease |  | Recognition of Operating Leases (1) |  | January 1,2019 |
| Property and equipment, net |  | $ | 75,355 |  |  | $ | (32,806 | ) |  | $ | — |  |  | $ | 42,549 |  |
| Operating lease right-of-use assets |  | — |  |  | — |  |  | 93,207 |  |  | 93,207 |  |
| Deferred tax assets |  | 126,492 |  |  | (1,165 | ) |  | — |  |  | 125,327 |  |
| Other current liabilities |  | 30,907 |  |  | (2,242 | ) |  | 12,391 |  |  | 41,056 |  |
| Operating lease liabilities, non-current |  | — |  |  | — |  |  | 88,230 |  |  | 88,230 |  |
| Finance lease liabilities, non-current |  | 35,431 |  |  | (35,431 | ) |  | — |  |  | — |  |
| Other long-term liabilities |  | 31,851 |  |  | — |  |  | (7,414 | ) |  | 24,437 |  |
| Retained earnings |  | 1,190,803 |  |  | 3,702 |  |  | — |  |  | 1,194,505 |  |
| __________________ |
| (1) Includes an operating lease for our corporate headquarters building under the build-to-suit arrangement, which was accounted for as a financing lease prior to 2019 and derecognized on January 1, 2019 upon the adoption of ASC 842. |

[0001596532-19-000104:notes:109]
Recent Accounting Pronouncements Not Yet Effective

[0001596532-19-000104:notes:110]
Credit Losses of Financial Instruments

[0001596532-19-000104:notes:111]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. For trade receivables, we will be required to estimate lifetime expected credit losses. For available-for-sale debt securities, we will be required to recognize an allowance for credit losses rather than a reduction to the carrying value of the asset. This standard is effective for us for our first quarter of 2020. We are currently assessing the impact this guidance may have on our consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-19-000104:notes:112]
[same as prior period, unchanged from 0001596532-18-000233:notes:138]

[0001596532-19-000104:notes:113]
[same as prior period, unchanged from 0001596532-18-000233:notes:139]

[0001596532-19-000104:notes:114]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our” or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System (“EOS”), a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-19-000104:notes:115]
[same as prior period, unchanged from 0001596532-18-000233:notes:141]

[0001596532-19-000104:notes:116]
[same as prior period, unchanged from 0001596532-18-000233:notes:142]

[0001596532-19-000104:notes:117]
The preparation of the accompanying condensed consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; valuation of goodwill and acquisition-related intangible assets, accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; estimate of useful lives of long-lived assets including intangible assets; valuation of inventory and contract manufacturer/supplier liabilities; recognition and measurement of contingent liabilities; valuation of equity investments in privately-held companies; determination of fair value for stock-based awards; estimate of incremental borrowing rate for determining the present value of future lease payments; and valuation of warranty accruals. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.

[0001596532-19-000104:notes:118]
[same as prior period, unchanged from 0001596532-18-000233:notes:144]

[0001596532-19-000104:notes:119]
During the three months ended March 31, 2019, we adopted ASC 842 - Leases, as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1. As a result, we added a new significant accounting policy "Leases" as described below. There have been no other significant changes to our accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2018, filed with the SEC on February 15, 2019.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001596532-19-000104:notes:120]
[same as prior period, unchanged from 0001596532-18-000233:notes:175]

[0001596532-19-000104:notes:121]
|  |  | March 31, 2019 |  | December 31, 2018 |
| Equipment and machinery |  | $ | 57,939 |  |  | $ | 55,912 |  |
| Computer hardware and software |  | 31,371 |  |  | 30,566 |  |
| Furniture and fixtures |  | 3,711 |  |  | 3,697 |  |
| Leasehold improvements |  | 31,089 |  |  | 36,447 |  |
| Building |  | — |  |  | 35,154 |  |
| Construction-in-process |  | 633 |  |  | 3,591 |  |
| Property and equipment, gross |  | 124,743 |  |  | 165,367 |  |
| Less: accumulated depreciation |  | (83,214 | ) |  | (90,012 | ) |
| Property and equipment, net |  | $ | 41,529 |  |  | $ | 75,355 |  |


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001596532-19-000104:notes:122]
[same as prior period, unchanged from 0001596532-18-000233:notes:177]

[0001596532-19-000104:notes:123]
|  |  | March 31, 2019 |  | December 31, 2018 |
| Accounts receivable |  | $ | 280,860 |  |  | $ | 340,897 |  |
| Allowance for doubtful accounts |  | (373 | ) |  | (507 | ) |
| Product sales rebate and returns reserve |  | (9,241 | ) |  | (8,613 | ) |
| Accounts receivable, net |  | $ | 271,246 |  |  | $ | 331,777 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001596532-19-000104:notes:124]
[same as prior period, unchanged from 0001596532-18-000233:notes:179]

[0001596532-19-000104:notes:125]
|  |  | March 31, 2019 |  | December 31, 2018 |
| Accrued payroll related costs |  | $ | 45,117 |  |  | $ | 70,755 |  |
| Accrued manufacturing costs |  | 25,968 |  |  | 31,336 |  |
| Accrued product development costs |  | 15,292 |  |  | 6,988 |  |
| Accrued warranty costs |  | 5,126 |  |  | 5,362 |  |
| Accrued professional fees |  | 8,652 |  |  | 5,678 |  |
| Accrued taxes |  | 889 |  |  | 839 |  |
| Other |  | 3,184 |  |  | 2,296 |  |
| Total accrued liabilities |  | $ | 104,228 |  |  | $ | 123,254 |  |


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001596532-19-000104:notes:126]
[same as prior period, unchanged from 0001596532-18-000233:notes:181]

[0001596532-19-000104:notes:127]
|  |  | March 31, 2019 |  | March 31, 2018 |
| Cash and cash equivalents |  | $ | 809,491 |  |  | $ | 886,160 |  |
| Restricted cash included in other assets |  | 4,218 |  |  | 5,508 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 813,709 |  |  | $ | 891,668 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001596532-19-000104:notes:128]
[same as prior period, unchanged from 0001596532-18-000233:notes:183]

[0001596532-19-000104:notes:129]
|  |  | March 31, 2019 |  | December 31, 2018 |
| Raw materials |  | $ | 102,836 |  |  | $ | 76,795 |  |
| Finished goods |  | 244,317 |  |  | 187,762 |  |
| Total inventories |  | $ | 347,153 |  |  | $ | 264,557 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001596532-19-000104:notes:130]
[same as prior period, unchanged from 0001596532-18-000233:notes:185]

[0001596532-19-000104:notes:131]
|  |  | March 31, 2019 |  | December 31, 2018 |
| Inventory deposit |  | $ | 19,555 |  |  | $ | 14,639 |  |
| Prepaid income taxes |  | 35,920 |  |  | 38,636 |  |
| Other current assets |  | 63,436 |  |  | 95,730 |  |
| Other prepaid expenses and deposits |  | 12,746 |  |  | 13,316 |  |
| Total prepaid expenses and other current assets |  | $ | 131,657 |  |  | $ | 162,321 |  |


## us-gaap:ScheduleOfOtherNonoperatingIncomeExpenseTableTextBlock

[0001596532-19-000104:notes:132]
[same as prior period, unchanged from 0001596532-18-000233:notes:187]

[0001596532-19-000104:notes:133]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |
| Interest income |  | $ | 11,898 |  |  | $ | 5,385 |  |
| Interest expense |  | — |  |  | (687 | ) |
| Gain on investment in privately-held companies |  | 1,150 |  |  | — |  |
| Other expense, net |  | (715 | ) |  | (542 | ) |
| Total |  | $ | 12,333 |  |  | $ | 4,156 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001596532-19-000104:notes:134]
[same as prior period, unchanged from 0001596532-18-000233:notes:189]

[0001596532-19-000104:notes:135]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |
| Warranty accrual, beginning of period |  | $ | 5,362 |  |  | $ | 7,415 |  |
| Liabilities accrued for warranties issued during the period |  | 932 |  |  | 1,557 |  |
| Warranty costs incurred during the period |  | (1,168 | ) |  | (1,538 | ) |
| Warranty accrual, end of period |  | $ | 5,126 |  |  | $ | 7,434 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001596532-19-000104:notes:136]
[same as prior period, unchanged from 0001596532-18-000233:notes:191]

[0001596532-19-000104:notes:137]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |
| Americas |  | $ | 439,638 |  |  | $ | 315,498 |  |
| Europe, Middle East and Africa |  | 111,269 |  |  | 121,886 |  |
| Asia-Pacific |  | 44,517 |  |  | 35,105 |  |
| Total revenue |  | $ | 595,424 |  |  | $ | 472,489 |  |

[0001596532-19-000104:notes:138]
[same as prior period, unchanged from 0001596532-18-000233:notes:193]

[0001596532-19-000104:notes:139]
|  |  | March 31, 2019 |  | December 31, 2018 |
| United States |  | $ | 35,339 |  |  | $ | 69,238 |  |
| International |  | 6,190 |  |  | 6,117 |  |
| Total |  | $ | 41,529 |  |  | $ | 75,355 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-19-000104:notes:140]
11.    Segment Information

[0001596532-19-000104:notes:141]
[same as prior period, unchanged from 0001596532-18-000233:notes:196]


## us-gaap:SubsequentEventsTextBlock

[0001596532-19-000104:notes:142]
12.    Subsequent Event

[0001596532-19-000104:notes:143]
Stock Repurchase Program

[0001596532-19-000104:notes:144]
Subsequent to March 31, 2019, our board of directors authorized a $1.0 billion stock repurchase program (the “Repurchase Program”).  This authorization allows us to repurchase shares of our common stock opportunistically and will be funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, or a combination of the foregoing. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-19-000104:notes:145]
[same as prior period, unchanged from 0001596532-18-000233:notes:197]

[0001596532-19-000104:notes:146]
[same as prior period, unchanged from 0001596532-18-000233:notes:198]

[0001596532-19-000104:notes:147]
Restricted cash included in other assets as of March 31, 2019 and March 31, 2018 primarily included $4.0 million pledged as collateral representing a security deposit required for a facility lease.  In addition, March 31, 2018 included $1.1 million related to a letter of credit issued to a business partner.

[0001596532-19-000104:notes:148]
[same as prior period, unchanged from 0001596532-18-000233:notes:200]

[0001596532-19-000104:notes:149]
[same as prior period, unchanged from 0001596532-18-000233:notes:201]

[0001596532-19-000104:notes:150]
[same as prior period, unchanged from 0001596532-18-000233:notes:202]

[0001596532-19-000104:notes:151]
[same as prior period, unchanged from 0001596532-18-000233:notes:203]

[0001596532-19-000104:notes:152]
On January 1, 2019, upon the adoption of ASC 842, we derecognized the building and certain leasehold improvements that were capitalized for our corporate headquarters building under a build-to-suit arrangement. See Note 1 and Note 6 for further details.

[0001596532-19-000104:notes:153]
Depreciation expense was $4.7 million and $5.3 million for the three months ended March 31, 2019 and 2018, respectively.

[0001596532-19-000104:notes:154]
[same as prior period, unchanged from 0001596532-18-000233:notes:205]

[0001596532-19-000104:notes:155]
[same as prior period, unchanged from 0001596532-18-000233:notes:206]

[0001596532-19-000104:notes:156]
Contract Balances

[0001596532-19-000104:notes:157]
As of March 31, 2019, $15.5 million of our contract liabilities was included in “Other current liabilities” with the remaining balance included in “Other long-term liabilities”.

[0001596532-19-000104:notes:158]
[same as prior period, unchanged from 0001596532-18-000233:notes:208]

[0001596532-19-000104:notes:159]
[same as prior period, unchanged from 0001596532-18-000233:notes:209]

[0001596532-19-000104:notes:160]
Revenue from remaining performance obligations represents contracted revenue that has not yet been recognized, which includes contract liabilities and deferred revenue that will be recognized as revenue in future periods. As of March 31, 2019, approximately $575.2 million of revenue is expected to be recognized from remaining performance obligations. We expect to recognize revenue on approximately 88% of these remaining performance obligations over the next 2 years and 12% during the 3rd to the 5th year.

[0001596532-19-000104:notes:161]
[same as prior period, unchanged from 0001596532-18-000233:notes:211]

[0001596532-19-000104:notes:162]
Upon the adoption of ASC 842 on January 1, 2019, we derecognized the lease financing obligation associated with a build-to-suit lease, and therefore did not incur interest expense in the quarter ended March 31, 2019. See Note 1 for further details.
