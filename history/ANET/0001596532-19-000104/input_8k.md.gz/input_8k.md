# ANET 8-K — 0001596532-19-000099 filed 2019-05-02

## item codes, every 8-K on or before 2019-05-06

- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2019-05-06

- none on or before 2019-05-06

## item 2.02 — earnings release, exhibit 99.1

[0001596532-19-000099:8k_2_02:1]
EX-99.1
2
ex991q119-earningsrelease.htm
EXHIBIT 99.1

[0001596532-19-000099:8k_2_02:2]
Exhibit

[0001596532-19-000099:8k_2_02:3]
Exhibit 99.1

[0001596532-19-000099:8k_2_02:4]
Arista Networks, Inc. Reports First Quarter 2019 Financial Results

[0001596532-19-000099:8k_2_02:5]
Places in the Cloud Networking Growth Continues with Record Earnings

[0001596532-19-000099:8k_2_02:6]
SANTA CLARA, Calif.- May 2, 2019 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven, cloud networking solutions for large datacenter and campus environments, today announced financial results for its first quarter ended March 31, 2019.

[0001596532-19-000099:8k_2_02:7]
First Quarter Financial Highlights

[0001596532-19-000099:8k_2_02:8]
| • | Revenue of $595.4 million, essentially flat compared to the fourth quarter of 2018, and an increase of 26% from the first quarter of 2018. |

[0001596532-19-000099:8k_2_02:9]
| • | GAAP gross margin of 63.9%, compared to GAAP gross margin of 62.9% in the fourth quarter of 2018 and 64.1% in the first quarter of 2018. |

[0001596532-19-000099:8k_2_02:10]
| • | Non-GAAP gross margin of 64.5%, compared to non-GAAP gross margin of 64.1% in the fourth quarter of 2018 and 64.4% in the first quarter of 2018. |

[0001596532-19-000099:8k_2_02:11]
| • | GAAP net income of $201.0 million, or $2.47 per diluted share, compared to GAAP net income of $144.5 million, or $1.79 per diluted share, in the first quarter of 2018. |

[0001596532-19-000099:8k_2_02:12]
| • | Non-GAAP net income of $187.7 million, or $2.31 per diluted share, compared to non-GAAP net income of $134.1 million, or $1.66 per diluted share in the first quarter of 2018. |

[0001596532-19-000099:8k_2_02:13]
“Arista's Q1 results demonstrate our consistent execution and profitability despite the seasonality of the quarter. We are witnessing the deployment of cloud principles into new enterprise markets.” stated Jayshree Ullal, Arista President and CEO.

[0001596532-19-000099:8k_2_02:14]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, “Our Q1 financial performance demonstrates the robustness of the business model with record earnings as we continue to diversify the business.”

[0001596532-19-000099:8k_2_02:15]
First Quarter Company Highlights

[0001596532-19-000099:8k_2_02:16]
| • | Arista Introduces Open Cloud-Scale Platform - Arista Networks announced at the 2019 OCP Global Summit the Arista 7360X Series, a new and disruptive platform that doubles system density while reducing power consumption and cost. By doubling the network diameter, customers can address the demand for higher bandwidth with reduced leaf-spine tiers while lowering both capex and opex. Cloud providers now have the ability to migrate to higher performance 100G or 400G while leveraging Arista EOS™ for single image consistency across the network. |

[0001596532-19-000099:8k_2_02:17]
| • | Arista Introduces Enhanced Ultra-low Latency, High-precision Network Application Platforms - Arista Networks announced the Arista 7130L Series, the next generation ultra-low latency, high-precision network application platform, with deterministic 5 nanosecond switching and virtually undetectable jitter. The 7130L Series consolidates FPGA (field-programmable gate array) based network applications, notably MetaMux, which enables lower latency data aggregation and is ideal for connecting electronic trading platforms directly to exchanges and MetaWatch for tapping and aggregating time-stamped packets for data analysis or compliance. |

[0001596532-19-000099:8k_2_02:18]
| • | CBC/Radio-Canada Selects Arista Networks for New Broadcast Facility - Arista Networks announced that CBC/Radio-Canada, Canada’s national public broadcaster, has chosen Arista Networks’ high performance switching infrastructure for its new “Maison de Radio-Canada” (MRC) in Montreal, a planned state-of-the-art facility that will be fully compliant with the SMPTE ST2110 suite of standards for professional media applications over managed IP networks. |

[0001596532-19-000099:8k_2_02:19]
| • | Arista Networks: Named One of the 2019 Best Workplaces in the Bay Area by Great Place to Work® and FORTUNE - Arista Networks announced that Great Place to Work and FORTUNE have honored Arista Networks as one of the 2019 Best Workplaces in the San Francisco Bay Area. The ranking considered more than 30,000 employee surveys from companies across the San Francisco Bay Area. Great Place to Work, a global people analytics and consulting firm, evaluated more than 60 elements of team members’ experience on the job. These included the extent to which employees trust leaders, the respect with which people are treated, the fairness of workplace decisions, and how much camaraderie there is among the team. Rankings are based on employees’ feedback and reward companies who best include all employees, no matter who they are or what they do for the organization. |

[0001596532-19-000099:8k_2_02:20]
$1 Billion Multi-Year Share Repurchase Authorization

[0001596532-19-000099:8k_2_02:21]
Arista’s board of directors has authorized a $1.0 billion stock repurchase program. This authorization allows the company to repurchase shares of its common stock opportunistically and will be funded from working capital. Repurchases may be made at management's discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The repurchase program, which expires in April 2022, does not obligate Arista to acquire any of its common stock, and may be suspended or discontinued by the company at any time without prior notice.

[0001596532-19-000099:8k_2_02:22]
Financial Outlook

[0001596532-19-000099:8k_2_02:23]
For the second quarter of 2019, we expect:

[0001596532-19-000099:8k_2_02:24]
| • | Revenue between $600 million and $610 million; |

[0001596532-19-000099:8k_2_02:25]
| • | Non-GAAP gross margin between 64% to 65%, and |

[0001596532-19-000099:8k_2_02:26]
| • | Non-GAAP operating margin of approximately 36% |

[0001596532-19-000099:8k_2_02:27]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below).

[0001596532-19-000099:8k_2_02:28]
Prepared Materials and Conference Call Information

[0001596532-19-000099:8k_2_02:29]
Arista executives will discuss the first quarter 2019 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (833) 287-7905 in the United States or (647) 689-4469 from outside the US. The Conference ID is 1076829.

[0001596532-19-000099:8k_2_02:30]
The financial results conference call will also be available via live webcast on our investor relations website at http://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-19-000099:8k_2_02:31]
Forward-Looking Statements

[0001596532-19-000099:8k_2_02:32]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the second quarter of fiscal 2019, and statements regarding the benefits from the introduction of new products and the diversification of the company’s business. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: Arista Networks’ limited operating history; Arista Networks’ rapid growth; Arista Networks’ customer concentration;  the evolution and growth of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; changes in our customers’ demand for our products and services; requests for

[0001596532-19-000099:8k_2_02:33]
more favorable terms and conditions from our large end customers; declines in the sales prices of our products and services; customer order patterns or customer mix; the timing of orders and manufacturing and customer lead times; increased competition in our products and service markets; dependence on the introduction and market acceptance of new product offerings and standards; the benefits and impact of acquisitions; rapid technological and market change; Arista Networks’ dispute with OptumSoft; our revenue growth rate; and general market, political, economic and business conditions. Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s most recent Annual Report on Form 10-K filed with the SEC on February 15, 2019, and other filings that the company makes to the SEC from time to time including any subsequent Quarterly Report on Form 10-Q. You can locate these reports through our website at http://investors.arista.com/ and on the SEC’s website at http://www.sec.gov/.  All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-19-000099:8k_2_02:34]
Non-GAAP Financial Measures

[0001596532-19-000099:8k_2_02:35]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, litigation-related expenses, amortization of acquisition-related intangible assets, other non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-19-000099:8k_2_02:36]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-19-000099:8k_2_02:37]
The company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. The company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. A reconciliation of the non-GAAP financial measures guidance to the corresponding GAAP measures on a forward-looking basis is not available because stock-based compensation expense is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-19-000099:8k_2_02:38]
About Arista Networks

[0001596532-19-000099:8k_2_02:39]
Arista Networks pioneered software-driven, cognitive cloud networking for large-scale datacenter and campus environments. Arista’s award-winning platforms redefine and deliver availability, agility, automation, analytics, and security. Arista has shipped more than twenty million cloud networking ports worldwide with CloudVision and EOS, an

[0001596532-19-000099:8k_2_02:40]
advanced network operating system. Committed to open standards across private, public and hybrid cloud solutions, Arista products are supported worldwide directly and through partners.

[0001596532-19-000099:8k_2_02:41]
ARISTA, EOS, CloudVision, Cognitive WiFi and AlgoMatch are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-19-000099:8k_2_02:42]
Additional information and resources can be found at: www.arista.com.

[0001596532-19-000099:8k_2_02:43]
| Investor Contacts: |
| Charles YagerProduct and Investor Advocacy(408) 547-5892cyager@arista.com |  | Chuck ElliottBusiness and Investor Development(408) 547-5549chuck@arista.com |

[0001596532-19-000099:8k_2_02:44]
4

[0001596532-19-000099:8k_2_02:45]
ARISTA NETWORKS, INC.

[0001596532-19-000099:8k_2_02:46]
Condensed Consolidated Statements of Operations

[0001596532-19-000099:8k_2_02:47]
(Unaudited in thousands, except per share amounts)

[0001596532-19-000099:8k_2_02:48]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |
| Revenue: |  |  |  |  |
| Product |  | $ | 505,415 |  |  | $ | 407,617 |  |
| Service |  | 90,009 |  |  | 64,872 |  |
| Total revenue |  | 595,424 |  |  | 472,489 |  |
| Cost of revenue: |  |  |  |  |
| Product |  | 198,152 |  |  | 156,691 |  |
| Service |  | 16,702 |  |  | 12,879 |  |
| Total cost of revenue |  | 214,854 |  |  | 169,570 |  |
| Total gross profit |  | 380,570 |  |  | 302,919 |  |
| Operating expenses: |  |  |  |  |
| Research and development |  | 119,669 |  |  | 102,362 |  |
| Sales and marketing |  | 51,053 |  |  | 42,140 |  |
| General and administrative |  | 15,506 |  |  | 19,679 |  |
| Total operating expenses |  | 186,228 |  |  | 164,181 |  |
| Income from operations |  | 194,342 |  |  | 138,738 |  |
| Other income (expense), net: |  |  |  |  |
| Interest expense |  | — |  |  | (687 | ) |
| Other income, net |  | 12,333 |  |  | 4,843 |  |
| Total other income (expense), net |  | 12,333 |  |  | 4,156 |  |
| Income before income taxes |  | 206,675 |  |  | 142,894 |  |
| Provision for (benefit from) income taxes |  | 5,646 |  |  | (1,644 | ) |
| Net income |  | $ | 201,029 |  |  | $ | 144,538 |  |
| Net income attributable to common stockholders: |  |  |  |  |
| Basic |  | $ | 200,911 |  |  | $ | 144,449 |  |
| Diluted |  | $ | 200,918 |  |  | $ | 144,456 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |
| Basic |  | $ | 2.65 |  |  | $ | 1.95 |  |
| Diluted |  | $ | 2.47 |  |  | $ | 1.79 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |
| Basic |  | 75,920 |  |  | 73,994 |  |
| Diluted |  | 81,201 |  |  | 80,721 |  |

[0001596532-19-000099:8k_2_02:49]
ARISTA NETWORKS, INC.

[0001596532-19-000099:8k_2_02:50]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-19-000099:8k_2_02:51]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-19-000099:8k_2_02:52]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |
| GAAP gross profit |  | $ | 380,570 |  |  | $ | 302,919 |  |
| GAAP gross margin |  | 63.9 | % |  | 64.1 | % |
| Stock-based compensation expense |  | 1,098 |  |  | 1,202 |  |
| Intangible asset amortization |  | 2,625 |  |  | — |  |
| Non-GAAP gross profit |  | $ | 384,293 |  |  | $ | 304,121 |  |
| Non-GAAP gross margin |  | 64.5 | % |  | 64.4 | % |
| GAAP income from operations |  | $ | 194,342 |  |  | $ | 138,738 |  |
| Stock-based compensation expense |  | 24,291 |  |  | 20,851 |  |
| Litigation expense |  | 1,448 |  |  | 7,085 |  |
| Intangible asset amortization |  | 3,499 |  |  | — |  |
| Non-GAAP income from operations |  | $ | 223,580 |  |  | $ | 166,674 |  |
| Non-GAAP operating margin |  | 37.5 | % |  | 35.3 | % |
| GAAP net income |  | $ | 201,029 |  |  | $ | 144,538 |  |
| Stock-based compensation expense |  | 24,291 |  |  | 20,851 |  |
| Litigation expense |  | 1,448 |  |  | 7,085 |  |
| Intangible asset amortization |  | 3,499 |  |  | — |  |
| Gain on investment in privately-held companies |  | (1,150 | ) |  | — |  |
| Tax benefit on stock-based awards |  | (37,054 | ) |  | (32,846 | ) |
| Income tax effect on non-GAAP exclusions |  | (4,333 | ) |  | (5,505 | ) |
| Non-GAAP net income |  | $ | 187,730 |  |  | $ | 134,123 |  |
| GAAP diluted net income per share attributable to common stockholders |  | $ | 2.47 |  |  | $ | 1.79 |  |
| Non-GAAP adjustments to net income |  | (0.16 | ) |  | (0.13 | ) |
| Non-GAAP diluted net income per share |  | $ | 2.31 |  |  | $ | 1.66 |  |
| Weighted-average shares used in computing diluted net income per share attributable to common stockholders |  | 81,201 |  |  | 80,721 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |
| Cost of revenue |  | $ | 1,098 |  |  | $ | 1,202 |  |
| Research and development |  | 13,131 |  |  | 10,945 |  |
| Sales and marketing |  | 6,534 |  |  | 5,960 |  |
| General and administrative |  | 3,528 |  |  | 2,744 |  |
| Total |  | $ | 24,291 |  |  | $ | 20,851 |  |

[0001596532-19-000099:8k_2_02:53]
6

[0001596532-19-000099:8k_2_02:54]
ARISTA NETWORKS, INC.

[0001596532-19-000099:8k_2_02:55]
Condensed Consolidated Balance Sheets

[0001596532-19-000099:8k_2_02:56]
(Unaudited, in thousands)

[0001596532-19-000099:8k_2_02:57]
|  |  | March 31, 2019 |  | December 31, 2018 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 809,491 |  |  | $ | 649,950 |  |
| Marketable securities |  | 1,341,427 |  |  | 1,306,197 |  |
| Accounts receivable |  | 271,246 |  |  | 331,777 |  |
| Inventories |  | 347,153 |  |  | 264,557 |  |
| Prepaid expenses and other current assets |  | 131,657 |  |  | 162,321 |  |
| Total current assets |  | 2,900,974 |  |  | 2,714,802 |  |
| Property and equipment, net |  | 41,529 |  |  | 75,355 |  |
| Acquisition-related intangible assets, net |  | 55,111 |  |  | 58,610 |  |
| Goodwill |  | 53,684 |  |  | 53,684 |  |
| Investments |  | 31,486 |  |  | 30,336 |  |
| Operating lease right-of-use assets |  | 98,552 |  |  | — |  |
| Deferred tax assets |  | 126,045 |  |  | 126,492 |  |
| Other assets |  | 25,063 |  |  | 22,704 |  |
| TOTAL ASSETS |  | $ | 3,332,444 |  |  | $ | 3,081,983 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 89,823 |  |  | $ | 93,757 |  |
| Accrued liabilities |  | 104,228 |  |  | 123,254 |  |
| Deferred revenue |  | 304,729 |  |  | 358,586 |  |
| Other current liabilities |  | 44,413 |  |  | 30,907 |  |
| Total current liabilities |  | 543,193 |  |  | 606,504 |  |
| Income taxes payable |  | 37,925 |  |  | 36,167 |  |
| Operating lease liabilities, non-current |  | 93,616 |  |  | — |  |
| Finance lease liabilities, non-current |  | — |  |  | 35,431 |  |
| Deferred revenue, non-current |  | 231,742 |  |  | 228,641 |  |
| Other long-term liabilities |  | 25,601 |  |  | 31,851 |  |
| TOTAL LIABILITIES |  | 932,077 |  |  | 938,594 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 8 |  |  | 8 |  |
| Additional paid-in capital |  | 1,005,405 |  |  | 956,572 |  |
| Retained earnings (1) |  | 1,395,534 |  |  | 1,190,803 |  |
| Accumulated other comprehensive loss |  | (580 | ) |  | (3,994 | ) |
| TOTAL STOCKHOLDERS’ EQUITY |  | 2,400,367 |  |  | 2,143,389 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 3,332,444 |  |  | $ | 3,081,983 |  |
| ____________________________ |  |  |  |  |
| (1) We adopted new lease accounting guidance under ASC 842, which resulted in a cumulative-effect adjustment of $3.7 million to retained earnings as of January 1, 2019. |

[0001596532-19-000099:8k_2_02:58]
ARISTA NETWORKS, INC.

[0001596532-19-000099:8k_2_02:59]
Condensed Consolidated Statements of Cash Flows

[0001596532-19-000099:8k_2_02:60]
(Unaudited, in thousands)

[0001596532-19-000099:8k_2_02:61]
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  | 2018 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 201,029 |  |  | $ | 144,538 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 8,362 |  |  | 5,697 |  |
| Stock-based compensation |  | 24,291 |  |  | 20,851 |  |
| Deferred income taxes |  | (718 | ) |  | (3,541 | ) |
| Gain on investment in privately-held companies |  | (1,150 | ) |  | — |  |
| Accretion of investment discounts |  | (2,069 | ) |  | (30 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | 60,531 |  |  | 40,007 |  |
| Inventories |  | (82,596 | ) |  | 38,067 |  |
| Prepaid expenses and other current assets |  | 30,664 |  |  | 13,722 |  |
| Other assets |  | 1,214 |  |  | (2,027 | ) |
| Accounts payable |  | (2,391 | ) |  | 20,040 |  |
| Accrued liabilities |  | (19,014 | ) |  | (48,140 | ) |
| Deferred revenue |  | (50,756 | ) |  | (42,686 | ) |
| Income taxes payable |  | 2,040 |  |  | 3,478 |  |
| Other liabilities |  | 660 |  |  | 5,565 |  |
| Net cash provided by operating activities |  | 170,097 |  |  | 195,541 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 302,264 |  |  | 90,448 |  |
| Purchases of marketable securities |  | (332,247 | ) |  | (267,976 | ) |
| Purchases of property and equipment |  | (5,237 | ) |  | (6,336 | ) |
| Net cash used in investing activities |  | (35,220 | ) |  | (183,864 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Principal payments of lease financing obligations |  | — |  |  | (456 | ) |
| Proceeds from issuance of common stock under equity plans |  | 26,323 |  |  | 17,300 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (1,850 | ) |  | (1,536 | ) |
| Net cash provided by financing activities |  | 24,473 |  |  | 15,308 |  |
| Effect of exchange rate changes |  | 195 |  |  | (14 | ) |
| NET INCREASE IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 159,545 |  |  | 26,971 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 654,164 |  |  | 864,697 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 813,709 |  |  | $ | 891,668 |  |

[0001596532-19-000099:8k_2_02:62]
8
