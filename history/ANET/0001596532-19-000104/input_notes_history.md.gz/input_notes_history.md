# ANET note change history — 0001596532-18-000233 → 0001596532-19-000104


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-05-06):
[0001596532-19-000104:note_history:1]
Leases

- added (2019-05-06):
[0001596532-19-000104:note_history:2]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2028. See Note 6 for our future minimum payment obligations under our leases as of March 31, 2019.

- changed (2019-05-06):
[0001596532-19-000104:note_history:3]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of March 31, 2019, we had non-cancellable purchase commitments of $253.8 million, of which $216.2 million was to our contract manufacturers and suppliers. In addition, we have provided deposits to secure our obligations to purchase inventory. We had $22.3 million and $17.4 million in deposits as of March 31, 2019 and December 31, 2018, respectively. These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.
  (was, 2018-11-05, similarity 0.9583):
[0001596532-18-000233:note_history:3]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2018, we had non-cancellable purchase commitments of $423.1 million, of which $370.4 million was to our contract manufacturers and suppliers. We have not recorded a liability related to these purchase commitments. In addition, we have provided deposits to secure our obligations to purchase inventory. We had $22.0 million and $36.9 million in deposits as of September 30, 2018 and December 31, 2017, respectively. These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.

- changed (2019-05-06):
[0001596532-19-000104:note_history:4]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.
  (was, 2018-11-05, similarity 0.9989):
[0001596532-18-000233:note_history:4]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

- changed (2019-05-06):
[0001596532-19-000104:note_history:5]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II, including the application of the Court’s interpretation of the 2004 agreement to any other source code that OptumSoft claims to own and the trade secret misappropriation and confidentiality claims. The Phase II Trial is set for the first date the court is available after December 2, 2019.
  (was, 2018-11-05, similarity 0.9479):
[0001596532-18-000233:note_history:5]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II, including the application of the Court’s interpretation of the 2004 agreement to any other source code that OptumSoft claims to own and the trade secret misappropriation and confidentiality claims. The Phase II Trial is set for September 23, 2019 by the judge.

- changed (2019-05-06):
[0001596532-19-000104:note_history:6]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2019, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.
  (was, 2018-11-05, similarity 0.9932):
[0001596532-18-000233:note_history:6]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2018, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.

- removed (2019-05-06):
[0001596532-18-000233:note_history:7]
Operating Leases

- removed (2019-05-06):
[0001596532-18-000233:note_history:8]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2025. There have been no material changes in our future minimum payment obligations under our operating leases that existed as of December 31, 2017, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2017, except as follows. During the nine months ended September 30, 2018, we entered into new leases primarily related to additional data center capacity and co-location services. As of September 30, 2018, the total minimum future payment commitment under these new leases was approximately $47.7 million, of which $1.2 million is due in 2018, with the remainder due in 2021 through 2028.

- removed (2019-05-06):
[0001596532-18-000233:note_history:9]
We recognize rent expense under these arrangements on a straight-line basis over the term of the leases. For the three months ended September 30, 2018 and 2017, rent expense for all operating leases amounted to $2.8 million and $2.5 million, respectively, and to $7.9 million and $7.5 million for the nine months ended September 30, 2018 and 2017, respectively.

- removed (2019-05-06):
[0001596532-18-000233:note_history:10]
Financing Obligation—Build-to-Suit Lease

- removed (2019-05-06):
[0001596532-18-000233:note_history:11]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013. The lease is accounted for as a financing obligation and the lease payments are attributed to (1) a reduction of the principal financing obligation; (2) imputed interest expense; and (3) land lease expense, representing an imputed cost to lease the underlying land of the building. There have been no material changes in our future minimum payment obligations under this financing lease, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2017. Land lease expense related to our lease financing obligation is classified as rent expense in our unaudited condensed consolidated statements of operations, and amounted to $0.3 million for the three months ended September 30, 2018 and 2017, and $1.0 million for the nine months ended September 30, 2018 and 2017, respectively.

- removed (2019-05-06):
[0001596532-18-000233:note_history:12]
Cisco Systems, Inc. (“Cisco”) Matters

- removed (2019-05-06):
[0001596532-18-000233:note_history:13]
On August 6, 2018, we entered into a settlement agreement with Cisco Systems, Inc. (“Cisco”) as described in Note 11 relating to several litigation matters which are summarized below.

- removed (2019-05-06):
[0001596532-18-000233:note_history:14]
Cisco Systems, Inc. v. Arista Networks, Inc. (Case No. 4:14-cv-05343) (“’43 Case”)

- removed (2019-05-06):
[0001596532-18-000233:note_history:15]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the ’875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”). Pursuant to the settlement with Cisco, as described in Note 11, the ’43 Case was dismissed on August 27, 2018.

- removed (2019-05-06):
[0001596532-18-000233:note_history:16]
Cisco Systems, Inc. v. Arista Networks, Inc. (Case No. 5:14-cv-05344) (“’44 Case”)

- removed (2019-05-06):
[0001596532-18-000233:note_history:17]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI” and U.S. Patent Nos. 7,047,526 and 7,953,886 (respectively, “the ’526 patent” and “the ’886 patent”). As relief for our alleged copyright infringement, Cisco sought monetary damages for alleged lost profits, profits from our alleged infringement, statutory damages, attorney’s fees, and associated costs. The ’526 patent is subject to a non-appealable final judgment of non-infringement and the ’886 patent was dismissed with prejudice.

- removed (2019-05-06):
[0001596532-18-000233:note_history:18]
On December 14, 2016, following a two-week trial, a jury found that we had proven our copyright defense of scenes a faire. Cisco filed a notice of appeal on June 6, 2017. Cisco did not appeal the jury’s noninfringement verdict on the ’526 patent but did appeal the jury’s finding that we established the defense of scenes a faire. On October 1, 2018, at the parties’ request and pursuant to the settlement agreement, the District Court vacated the jury verdict regarding our copyright defense and dismissed the case.

- removed (2019-05-06):
[0001596532-18-000233:note_history:19]
Arista Networks, Inc. v. Cisco Systems, Inc. (Case No. 5:16-cv-00923) (“’23 Case”)

- removed (2019-05-06):
[0001596532-18-000233:note_history:20]
On February 24, 2016, we filed a complaint against Cisco in the District Court for the Northern District of California alleging antitrust violations and unfair competition. On August 6, 2018, the Court vacated trial in light of the settlement with Cisco as describe in Note 11. Pursuant to the settlement with Cisco, the ’23 Case was dismissed.

- removed (2019-05-06):
[0001596532-18-000233:note_history:21]
Certain Network Devices, Related Software, and Components Thereof (Inv. No. 337-TA-944) (“944 Investigation”)

- removed (2019-05-06):
[0001596532-18-000233:note_history:22]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated 19 U.S.C. § 1337 (“Section 337”). The USITC instituted Cisco’s complaint as Investigation No. 337-TA-944. Cisco initially alleged that certain of our switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents.

- removed (2019-05-06):
[0001596532-18-000233:note_history:23]
On February 2, 2016, the Administrative Law Judge (“ALJ”) issued his initial determination finding a violation of Section 337. The ALJ found that a violation had occurred in the importation into the United States, the sale for importation or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringed asserted claims 1, 2, 8-11, and 17-19 of the ’537 patent; asserted claims 6, 7, 20, and 21 of the ’592 patent; and asserted claims 5, 7, 45, and 46 of the ’145 patent. The ALJ did not find a violation of Section 337 with respect to any asserted claims of the ’597 and ’164 patents. Cisco dropped the ’296 patent before the hearing. On June 23, 2016, the USITC issued its Final Determination, which found a violation with respect to the ’537, ’592, and ’145 patents, and found no violation with respect to the ’597 and ’164 patents. The USITC also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software, and components thereof that infringe one or more of claims 1, 2, 8-11, and 17-19 of the ’537 patent; claims 6, 7, 20, and 21 of the ’592 patent; and claims 5, 7, 45, and 46 of the ’145 patent. On August 22, 2016, the Presidential review period for the 944 Investigation expired. The USITC orders will be in effect until the expiration of the ’537, ’592, and ’145 patents.

- removed (2019-05-06):
[0001596532-18-000233:note_history:24]
Both we and Cisco filed petitions for review of the USITC’s Final Determination to the Federal Circuit. The appeal was fully briefed and oral argument was held on June 6, 2017. On September 27, 2017, the Federal Circuit affirmed the USITC’s Final Determination.

- removed (2019-05-06):
[0001596532-18-000233:note_history:25]
In response to the USITC’s findings in the 944 Investigation, we made design changes to our products for sale in the United States to address the features that were found to infringe the ’537, ’592, and ’145 patents. Following the issuance of the final determination in the 944 Investigation, we submitted a Section 177 ruling request to CBP seeking approval to import these redesigned products into the United States.

- removed (2019-05-06):
[0001596532-18-000233:note_history:26]
On August 26, 2016, Cisco filed an enforcement complaint under Section 337 with the USITC. Cisco alleged that we violated the cease and desist and limited exclusion orders issued in the 944 Investigation by engaging in the “marketing, distribution, offering for sale, selling, advertising, and/or aiding or abetting other entities in the sale and/or distribution of products that Cisco alleges continue to infringe claims 1-2, 8-11, and 17-19 of the ’537 patent,” despite the design changes we made to those products. On September 28, 2016, the USITC instituted the enforcement proceeding.

- removed (2019-05-06):
[0001596532-18-000233:note_history:27]
On April 7, 2017, we received a 177 ruling from CBP finding that our redesigned products did not infringe the relevant claims of the ’537, ’592, and ʼ145 patents, and approving the importation of those redesigned products into the United States.

- removed (2019-05-06):
[0001596532-18-000233:note_history:28]
On June 20, 2017, the ALJ issued his initial determination finding that we did not violate the June 23, 2016 cease and desist order. The initial determination also recommended a civil penalty of $307 million if the USITC decided to overturn the finding of no violation. On July 3, 2017, the parties filed petitions for review of certain findings in the initial determination.

- removed (2019-05-06):
[0001596532-18-000233:note_history:29]
On August 4, 2017, the USITC issued an order remanding the investigation to the ALJ to make additional findings on certain issues and issue a remand initial determination. The USITC ordered the ALJ to set a schedule for completion of any necessary remand proceedings and a new target date for the enforcement action (the “944 Enforcement Action”). The ALJ held a hearing on February 1, 2018 and issued a remand initial determination on June 4, 2018, again finding that we did not violate the June 23, 2016 cease and desist order. Pursuant to the settlement with Cisco, the 944 Enforcement Investigation was terminated on September 17, 2018.  The parties have jointly requested suspension of the remedial orders in the 944 Investigation, and on October 23, 2018, the ITC instituted a modification proceeding to determine how to modify the orders consistent with the parties’ request.

- removed (2019-05-06):
[0001596532-18-000233:note_history:30]
Certain Network Devices, Related Software, and Components Thereof (Inv. No. 337-TA-945) (“945 Investigation”)

- removed (2019-05-06):
[0001596532-18-000233:note_history:31]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated Section 337. The USITC instituted Cisco’s complaint as Investigation No. 337-TA-945. The remedial orders from the 945 Investigation are no longer in effect and will terminate when the USPTO issues a certificate cancelling the asserted claims of the ’668 patent based on the IPR proceeding described below.

- removed (2019-05-06):
[0001596532-18-000233:note_history:32]
Inter Partes Reviews

- removed (2019-05-06):
[0001596532-18-000233:note_history:33]
We have filed petitions for Inter Partes Review of the ’597, ’211, ’668, ’853, ’537, ’577, ’886, and ’526 patents. IPRs relating to the ’597 (IPR No. 2015-00978) and ’211 (IPR No. 2015-00975) patents were instituted in October 2015 and hearings on these IPRs were completed in July 2016. On September 28, 2016, the PTAB issued a final written decision finding claims 1, 14, 39-42, 71, 72, 84, and 85 of the ’597 patent unpatentable. The PTAB also found that claims 29, 63, 64, 73, and 86 of the ’597 patent had not been shown to be unpatentable. On October 5, 2016, the PTAB issued a final written decision finding claims 1 and 12 of the ’211 patent unpatentable. The PTAB also found that claims 2, 6-9, 13, and 17-20 of the ’211 patent had not been shown to be unpatentable. Both parties have appealed the final written decisions on the ’211 and ’537 patent IPRs.  The hearing for the ’211 IPR appeal was held in March 2018, and on March 28, 2018, the Federal Circuit remanded the matter back to the PTAB for further proceedings.

- removed (2019-05-06):
[0001596532-18-000233:note_history:34]
IPRs relating to the ’668 (IPR No. 2016-00309), ’577 (IPR No. 2016-00303), ’853 (IPR No. 2016-0306), and ’537 (IPR No. 2016-0308) patents were instituted in June 2016 and hearings were held on March 7, 2017. On May 25, 2017, the PTAB issued final written decisions finding claims 1, 7-10, 12-16, 18-22, 25, and 28-31 of ’577 patent unpatentable, and that claim 2 of the ’577 patent, claim 63 of the ’853 patent, and claims 1, 10, 19, and 21 of the ’537 patent had not been shown to be unpatentable. On June 1, 2017, the PTAB issued a final written decision finding claims 1-10, 12-13, 15-28, 30-31, 33-36, 55-64, 66-67, and 69-72 of the ’668 patent unpatentable. We filed a Notice of Appeal concerning the ’577 patent on July 21, 2017, and Notices of Appeal concerning the ‘853 and ’537 patents on July 26, 2017. Cisco cross-appealed concerning the ’577 patent on July 26, 2017 and filed a Notice of Appeal concerning the ’668 patent on August 1, 2017. For the appeals of the IPRs on the ’668 and ’577 patents, the Federal Circuit granted our motion for an expedited briefing schedule, and the hearings were held on February 9, 2018. On February 14, 2018, the Federal Circuit affirmed the PTAB’s final written decision on the ’668 patent.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: no_current_note, score: 0.0

- removed (2019-05-06):
[0001596532-18-000233:note_history:35]
11.    Legal Settlement

- removed (2019-05-06):
[0001596532-18-000233:note_history:36]
On August 6, 2018, we entered into a binding term sheet with Cisco (“Term Sheet”). Under the Term Sheet, we paid Cisco $400.0 million on August 20, 2018, and the parties obtained dismissals of all ongoing district court and USITC litigation between them. Cisco granted us a release for all past claims relating to the patents Cisco asserted against us in the district court and USITC, and we granted Cisco a release from all past antitrust and unfair competition claims. These mutual releases extended to the Company's and Cisco’s customers, contract manufacturers, and partners. The parties further agreed to a five-year stand-down period for any utility patent infringement claims either may have against features currently implemented in the other party’s products and services, with some carve-outs for products stemming from acquired companies. The parties further agreed to a three-year dispute resolution process for allegations by either party against new and/or modified features in the other party’s products. We also agreed to make certain modifications to our Command Line Interface (“CLI”).

- removed (2019-05-06):
[0001596532-18-000233:note_history:37]
Upon signing the Term Sheet, we recorded a legal settlement charge of $405.0 million to operating expenses, which included legal fees associated with the settlement in the three months ended June 30, 2018. We have also recorded a corresponding income tax benefit of $0.9 million and $99.9 million for the three and nine months ended September 30, 2018.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-05-06):
[0001596532-19-000104:note_history:38]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our” or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System (“EOS”), a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.
  (was, 2018-11-05, similarity 0.8117):
[0001596532-18-000233:note_history:38]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our” or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System (“EOS”), a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switching and routing platforms. We were incorporated in October 2004 in the State of California under the name Arastra, Inc. In March 2008, we reincorporated in the State of Nevada and in October 2008 changed our name to Arista Networks, Inc. We reincorporated in the state of Delaware in March 2014. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

- changed (2019-05-06):
[0001596532-19-000104:note_history:39]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2019, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2018 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant intercompany accounts and transactions have been eliminated.
  (was, 2018-11-05, similarity 0.9807):
[0001596532-18-000233:note_history:39]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2018, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2017 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant intercompany accounts and transactions have been eliminated.

- changed (2019-05-06):
[0001596532-19-000104:note_history:40]
Our condensed consolidated financial statements and related financial information in this Quarterly Report on Form 10-Q should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2018, filed with the SEC on February 15, 2019.
  (was, 2018-11-05, similarity 0.8414):
[0001596532-18-000233:note_history:40]
Our condensed consolidated financial statements and related financial information in this Quarterly Report on Form 10-Q should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2017, filed with the SEC on February 20, 2018. Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.

- changed (2019-05-06):
[0001596532-19-000104:note_history:41]
The preparation of the accompanying condensed consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; valuation of goodwill and acquisition-related intangible assets, accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; estimate of useful lives of long-lived assets including intangible assets; valuation of inventory and contract manufacturer/supplier liabilities; recognition and measurement of contingent liabilities; valuation of equity investments in privately-held companies; determination of fair value for stock-based awards; estimate of incremental borrowing rate for determining the present value of future lease payments; and valuation of warranty accruals. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.
  (was, 2018-11-05, similarity 0.7531):
[0001596532-18-000233:note_history:41]
The preparation of the accompanying condensed consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; valuation of goodwill and acquisition-related intangible assets, accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; estimate of useful lives of long-lived assets including intangible assets; valuation of inventory and contract manufacturer/supplier liabilities; recognition and measurement of contingent liabilities; valuation of equity investments in privately-held companies; determination of fair value for stock-based awards; and valuation of warranty accruals. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.

- added (2019-05-06):
[0001596532-19-000104:note_history:42]
During the three months ended March 31, 2019, we adopted ASC 842 - Leases, as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1. As a result, we added a new significant accounting policy "Leases" as described below. There have been no other significant changes to our accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2018, filed with the SEC on February 15, 2019.

- added (2019-05-06):
[0001596532-19-000104:note_history:43]
Our initial application date of ASC 842 is January 1, 2019. For the periods prior to 2019, our leases were accounted for under the legacy guidance in ASC 840.

- added (2019-05-06):
[0001596532-19-000104:note_history:44]
We determine if a contract contains a lease at inception. The lease term represents the non-cancellable period for which we have the right to use an underlying asset, which may include periods covered by certain options to extend and/or terminate the lease. Lease liabilities and corresponding right-of-use ("ROU") assets are recognized at the commencement date of a lease. Leases with an initial lease term of 12 months or less are not recorded on the balance sheet.

- added (2019-05-06):
[0001596532-19-000104:note_history:45]
A lease liability is the present value of our future fixed lease payments. As none of our leases provides an implicit interest rate, we use our estimated incremental borrowing rate as of the lease commencement date to determine the present value of future lease payments. Our discount rates are determined and applied at a company level. An ROU asset is calculated as the lease liability, adjusted by unamortized initial direct costs, unamortized lease incentives received, cumulative deferred or prepaid lease payments, and accumulated impairment losses.

- added (2019-05-06):
[0001596532-19-000104:note_history:46]
For fixed lease payments under operating leases, lease expense is recognized on a straight-lined basis over the lease term. For variable lease payments, lease expense is recognized when incurred. For operating leases that include both lease and non-lease components, we account for lease and non-lease components as a single lease component for all classes of underlying assets and, therefore, recognize non-lease payments as lease expense.

- added (2019-05-06):
[0001596532-19-000104:note_history:47]
Leases

- added (2019-05-06):
[0001596532-19-000104:note_history:48]
In February 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2016-02, Leases (“ASU 2016-02”), and in July 2018, the FASB issued ASU 2018-11, Leases (Topic 842): Targeted Improvements (“ASU 2018-11”) (collectively referred to as "ASC 842"). Under the guidance, lessees are required to recognize assets and lease liabilities on the balance sheet for most leases including operating leases and provide enhanced disclosures. Companies are required to adopt this guidance using a modified retrospective approach and apply the transition provisions under the guidance at either 1) the later of the beginning of the earliest comparative period presented in the financial statements and the commencement date of the lease, or 2) the beginning of the period of adoption (i.e. on the effective date). Under the transition method using the second application date, a company initially applies the new leases standard at the adoption date and recognizes a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption.

- added (2019-05-06):
[0001596532-19-000104:note_history:49]
We adopted the guidance on January 1, 2019 using the modified retrospective transition method and initially applied the transition provisions at January 1, 2019, which allows us to continue to apply the legacy guidance in ASC 840 for periods prior to 2019. We elected the package of transition practical expedients, which, among other things, allows us to keep the historical lease classifications and not have to reassess the lease classification for any existing leases as of the date of adoption. We also made the following accounting policy elections as allowed by ASC 842:

- added (2019-05-06):
[0001596532-19-000104:note_history:50]
| • | to apply the short-term lease exception, which allows us to keep leases with an initial term of twelve months or less off the balance sheet. |

- added (2019-05-06):
[0001596532-19-000104:note_history:51]
| • | to account for each separate lease component of a contract and its associated non-lease components as a single lease component for all our leases. |

- added (2019-05-06):
[0001596532-19-000104:note_history:52]
As a result of the adoption, we recognized operating leases that were previously not recognized on the consolidated balance sheets. In addition, we derecognized the assets and the lease financing liabilities previously recorded for our headquarters building under a build-to-suit lease. Under ASC 842, this lease is recognized as an operating lease in our condensed consolidated financial statements beginning in the first quarter of 2019. The table below summarizes the impact of the adoption of ASC 842 on the condensed consolidated balance sheet as of January 1, 2019 (in thousands).

- added (2019-05-06):
[0001596532-19-000104:note_history:53]
|  |  |  |  | Adjustments for the Adoption of ASC 842 |  |  |
| Balance Sheet Line Item |  | December 31,2018 |  | Derecognition of Build-to-Suit Lease |  | Recognition of Operating Leases (1) |  | January 1,2019 |
| Property and equipment, net |  | $ | 75,355 |  |  | $ | (32,806 | ) |  | $ | — |  |  | $ | 42,549 |  |
| Operating lease right-of-use assets |  | — |  |  | — |  |  | 93,207 |  |  | 93,207 |  |
| Deferred tax assets |  | 126,492 |  |  | (1,165 | ) |  | — |  |  | 125,327 |  |
| Other current liabilities |  | 30,907 |  |  | (2,242 | ) |  | 12,391 |  |  | 41,056 |  |
| Operating lease liabilities, non-current |  | — |  |  | — |  |  | 88,230 |  |  | 88,230 |  |
| Finance lease liabilities, non-current |  | 35,431 |  |  | (35,431 | ) |  | — |  |  | — |  |
| Other long-term liabilities |  | 31,851 |  |  | — |  |  | (7,414 | ) |  | 24,437 |  |
| Retained earnings |  | 1,190,803 |  |  | 3,702 |  |  | — |  |  | 1,194,505 |  |
| __________________ |
| (1) Includes an operating lease for our corporate headquarters building under the build-to-suit arrangement, which was accounted for as a financing lease prior to 2019 and derecognized on January 1, 2019 upon the adoption of ASC 842. |

- added (2019-05-06):
[0001596532-19-000104:note_history:54]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. For trade receivables, we will be required to estimate lifetime expected credit losses. For available-for-sale debt securities, we will be required to recognize an allowance for credit losses rather than a reduction to the carrying value of the asset. This standard is effective for us for our first quarter of 2020. We are currently assessing the impact this guidance may have on our consolidated financial statements.

- removed (2019-05-06):
[0001596532-18-000233:note_history:55]
During the nine months ended September 30, 2018, we completed two business acquisitions (see Note 2) and adopted several recent accounting pronouncements as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1. As a result, we updated certain significant accounting policies as described below. There have been no other significant changes to our accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

- removed (2019-05-06):
[0001596532-18-000233:note_history:56]
Investments in Privately-held Companies

- removed (2019-05-06):
[0001596532-18-000233:note_history:57]
Our equity investments in privately-held companies without readily determinable fair values are measured using the measurement alternative, defined by Accounting Standards Codification (“ASC”) 321-Investments-Equity Securities as cost, less impairments, and adjusted up or down based on observable price changes in orderly transactions for identical or similar investments of the same issuer. Any adjustments resulting from impairments and/or observable price changes are recorded as “Other income (expense), net” in our condensed consolidated statements of operations. Prior to 2018, such investments were accounted for under the cost method and were recorded at historical cost at the time of investment, with adjustments to the balance only in the event of an impairment.

- removed (2019-05-06):
[0001596532-18-000233:note_history:58]
Our equity investments in privately-held companies are included in “Investments” in our condensed consolidated balance sheets.

- removed (2019-05-06):
[0001596532-18-000233:note_history:59]
Revenue Recognition

- removed (2019-05-06):
[0001596532-18-000233:note_history:60]
Effective January 1, 2018, we adopted a new revenue recognition policy in accordance with ASC 606 - Revenue from Contracts with Customers (“ASC 606”) using the modified retrospective method as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1.  Prior to 2018, our revenue recognition policy was based on ASC 605 - Revenue Recognition (“ASC 605”), and is described in Note 1 of Notes to Consolidated Financial Statements under Item 8 of our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

- removed (2019-05-06):
[0001596532-18-000233:note_history:61]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with post-contract customer support (“PCS”). We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

- removed (2019-05-06):
[0001596532-18-000233:note_history:62]
| • | Identification of the contract, or contracts, with a customer |

- removed (2019-05-06):
[0001596532-18-000233:note_history:63]
| • | Identification of the performance obligations in the contract |

- removed (2019-05-06):
[0001596532-18-000233:note_history:64]
| • | Determination of the transaction price |

- removed (2019-05-06):
[0001596532-18-000233:note_history:65]
| • | Allocation of the transaction price to the performance obligations in the contract |

- removed (2019-05-06):
[0001596532-18-000233:note_history:66]
| • | Recognition of revenue when (or as) we satisfy the performance obligation |

- removed (2019-05-06):
[0001596532-18-000233:note_history:67]
Post-Contract Customer Support

- removed (2019-05-06):
[0001596532-18-000233:note_history:68]
Post-contract support, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernable pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and addresses customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

- removed (2019-05-06):
[0001596532-18-000233:note_history:69]
Contracts with Multiple Performance Obligations

- removed (2019-05-06):
[0001596532-18-000233:note_history:70]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts which contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is required to determine the SSP for each distinct performance obligation.  We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

- removed (2019-05-06):
[0001596532-18-000233:note_history:71]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services are sold, and the size of the end customer.

- removed (2019-05-06):
[0001596532-18-000233:note_history:72]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

- removed (2019-05-06):
[0001596532-18-000233:note_history:73]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

- removed (2019-05-06):
[0001596532-18-000233:note_history:74]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

- removed (2019-05-06):
[0001596532-18-000233:note_history:75]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

- removed (2019-05-06):
[0001596532-18-000233:note_history:76]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

- removed (2019-05-06):
[0001596532-18-000233:note_history:77]
Contract Balances

- removed (2019-05-06):
[0001596532-18-000233:note_history:78]
A contract asset is recognized when we have performed under the contract, but our right to consideration is conditional on something other than the passage of time. Contract assets are included in “Other current assets” on our condensed consolidated balance sheets.

- removed (2019-05-06):
[0001596532-18-000233:note_history:79]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a contract that is cancellable. Contract liabilities are included in “Other current liabilities” and “Other long-term liabilities” on our condensed consolidated balance sheets.

- removed (2019-05-06):
[0001596532-18-000233:note_history:80]
Assets Recognized from Costs to Obtain a Contract with a Customer

- removed (2019-05-06):
[0001596532-18-000233:note_history:81]
Effective January 1, 2018 in connection with the adoption of ASC 606, we recognize an asset for the incremental costs of obtaining a contract with a customer if we expect the benefit of those costs to be longer than one year. We have determined that certain sales commissions earned by our sales force meet the requirements for capitalization. These costs are deferred and then amortized over a period of benefit that we have determined to be five years. Total capitalized costs to obtain a contract are included in other current and long-term assets on our condensed consolidated balance sheets.

- removed (2019-05-06):
[0001596532-18-000233:note_history:82]
Business Combinations

- removed (2019-05-06):
[0001596532-18-000233:note_history:83]
We use the acquisition method to account for our business combinations in accordance with ASC 805 - Business Combinations (“ASC 805”). We allocate the total purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the consideration transferred over the fair values of the assets acquired and liabilities assumed is recorded as goodwill. The results of operations of the acquired businesses are included in our consolidated financial statements from the date of acquisition. Acquisition-related costs and restructuring costs are expensed as incurred.

- removed (2019-05-06):
[0001596532-18-000233:note_history:84]
Goodwill

- removed (2019-05-06):
[0001596532-18-000233:note_history:85]
We perform our annual goodwill impairment analysis in the fourth quarter of each year or more frequently if there are any events or circumstances that would indicate the carrying amount is not recoverable. We first perform a qualitative assessment to determine if it’s necessary to perform a quantitative assessment.  If after our qualitative assessment, we determine it is more likely than not that the fair value of the Company is less than its carrying amount, then a quantitative test is performed by comparing the fair value of the Company with its carrying amount in accordance with Accounting Standard Update (“ASU”) No. 2017-04, Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. We would recognize an impairment loss for the amount by which the carrying amount exceeds the fair value.

- removed (2019-05-06):
[0001596532-18-000233:note_history:86]
Intangible Assets

- removed (2019-05-06):
[0001596532-18-000233:note_history:87]
Intangible assets are carried at cost less accumulated amortization. All intangible assets have been determined to have definite lives and are amortized on a straight-line basis over their estimated remaining useful lives, ranging from one to seven years. Intangible assets are tested for impairment annually in the fourth quarter of each year or whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable.

- removed (2019-05-06):
[0001596532-18-000233:note_history:88]
Revenue Recognition

- removed (2019-05-06):
[0001596532-18-000233:note_history:89]
During May 2014, the Financial Accounting Standards Board (“FASB”) issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606). In 2016, the FASB issued ASU No. 2016-08, ASU No. 2016-10 and ASU No. 2016-12, which provide interpretive clarifications on the new guidance in Topic 606 (collectively, “the new standard”). Under the new standard, the recognition of revenue is based on consideration we expect to be entitled to from the transfer of goods or services to a customer.

- removed (2019-05-06):
[0001596532-18-000233:note_history:90]
The primary impact of the new standard is related to the deferral of incremental commission costs of obtaining customer service contracts, which were previously expensed as incurred. Under the new standard, we defer all such costs and amortize them over the expected period of benefit. The new standard also requires companies to account for termination clauses at the onset of an arrangement. While there is limited history of cancellations, our prepaid subscription offerings are generally cancellable by customers with 30 days’ notice, therefore, the subscription contracts are considered month-to-month. While these prepaid amounts have historically been recorded to deferred revenue, the new standard requires that we record these amounts as other liabilities.  In addition, the new standard may impact the amount and timing of revenue recognition of certain sales arrangements and the related disclosures on our consolidated financial statements.

- removed (2019-05-06):
[0001596532-18-000233:note_history:91]
We adopted the new standard in our first quarter of 2018 using the modified retrospective method, which resulted in a cumulative effect adjustment of $3.5 million that increased retained earnings to capitalize certain commission costs that were expensed in the prior year. Correspondingly, we increased prepaid expenses and other current assets by $2.0 million, other assets by $2.2 million, and decreased deferred tax assets by $0.7 million as of January 1, 2018. In addition, we reclassified $16.5 million of deferred revenue as of January 1, 2018 to other current liabilities and other long-term liabilities related to our prepaid subscription offerings. The impact of adopting the new standard was not material to our financial results for the three and nine months ended September 30, 2018 and we do not expect the impact to be material to the financial results for our fiscal 2018.

- removed (2019-05-06):
[0001596532-18-000233:note_history:92]
We apply a practical expedient to expense costs as incurred for costs to obtain a contract with a customer when the amortization period would have been one year or less, as well as the portfolio approach for the contracts reviewed. These costs include a portion of our sales force compensation program as we have determined annual compensation is commensurate with recurring sales activities.

- removed (2019-05-06):
[0001596532-18-000233:note_history:93]
Financial Instruments

- removed (2019-05-06):
[0001596532-18-000233:note_history:94]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which enhances the reporting model for financial instruments to provide users of financial statements with more decision-useful information. In February 2018, the FASB issued ASU 2018-03, Technical Corrections and Improvements to Financial Instruments, to clarify certain aspects of ASU 2016-01. ASU 2016-01 and ASU 2018-03 (collectively, the “new guidance”) address certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. We adopted this new guidance in our first quarter of fiscal 2018. Under the new guidance, there was no change in the accounting of our marketable securities as our investment policy only allows investments in debt securities. For our cost method equity investments in privately-held companies without readily determinable fair value, we elected to use the measurement alternative, defined as cost, less impairments, as adjusted up or down based on observable price changes in orderly transactions for identical or similar investments of the same issuer, which was adopted prospectively. Adjustments resulting from impairments and/or observable price changes are to be recorded as other income (expense) on a prospective basis.

- removed (2019-05-06):
[0001596532-18-000233:note_history:95]
The carrying amount of our equity investments and any related gain or loss may fluctuate in the future as a result of the re-measurement of such equity investments upon the occurrence of observable price changes and/or impairments.

- removed (2019-05-06):
[0001596532-18-000233:note_history:96]
Income Taxes on Intra-Entity Transfers of Assets

- removed (2019-05-06):
[0001596532-18-000233:note_history:97]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which addresses recognition of current and deferred income taxes for intra-entity asset transfers when assets are sold to an outside party. Current GAAP prohibits the recognition of current and deferred income taxes until the asset has been sold to an outside party. This prohibition on recognition is considered an exception to the principle of comprehensive recognition of current and deferred income taxes in GAAP. The new guidance requires an entity to recognize the income tax consequences when the transfer occurs eliminating the exception. The guidance must be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. We adopted this guidance in our first quarter of fiscal 2018. As a result, we recognized a cumulative effect adjustment in the condensed consolidated balance sheet as of September 30, 2018 by increasing the retained earnings and the deferred tax assets as of January 1, 2018 by approximately $0.1 million, respectively.

- removed (2019-05-06):
[0001596532-18-000233:note_history:98]
Restricted Cash in Statement of Cash Flows

- removed (2019-05-06):
[0001596532-18-000233:note_history:99]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force (“ASU 2016-18”), which requires that amounts generally described as restricted cash or restricted cash equivalents be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows.  This standard is required to be applied using a retrospective transition method to each period presented.  We retrospectively adopted ASU 2016-18 in our first quarter of fiscal 2018. As a result of the adoption, we adjusted the condensed consolidated statement of cash flows for the nine months ended September 30, 2017 to increase the beginning-of-period and end-of-period cash amounts by $4.2 million and $5.5 million, respectively, and to decrease net cash used in investing activities by $1.3 million.

- removed (2019-05-06):
[0001596532-18-000233:note_history:100]
Nonemployee Share-Based Payments

- removed (2019-05-06):
[0001596532-18-000233:note_history:101]
In June 2018, the FASB issued ASU 2018-07, Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting (“ASU 2018-07”), to simplify the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees with certain exceptions. Under the guidance, the measurement of equity-classified nonemployee awards will be fixed at the grant date, which may lower their cost and reduce volatility in the income statement. The guidance is effective for us for our first quarter of 2019. Early adoption is permitted. ASU 2018-07 shall be applied on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of the beginning of the fiscal year in which the guidance is adopted. We are currently assessing the impact this guidance may have on our consolidated financial statements.

- removed (2019-05-06):
[0001596532-18-000233:note_history:102]
In February 2016, the FASB issued ASU No. 2016-02, Leases (“ASU 2016-02”). In July 2018, the FASB issued ASU No. 2018-11, Leases (Topic 842): Targeted Improvements (“ASU 2018-11”). Under the guidance, lessees are required to recognize assets and lease liabilities on the balance sheet for most leases including operating leases and provide enhanced disclosures. There are optional practical expedients that a company may elect to apply. The guidance is effective for our first quarter of 2019 and may be early adopted. Companies can adopt this guidance using a modified retrospective approach or, pursuant to ASU 2018-11, using an additional optional transition method. Under the optional transition method, a company initially applies the new leases standard at the adoption date and recognizes a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption. We plan to adopt the guidance in the first quarter of 2019 using the additional optional transition method. Management’s evaluation of the new standard is underway, and we have identified the significant changes between the current guidance and the new guidance and expect to elect certain available transitional practical expedients.  In addition, we have developed a project plan, performed a risk assessment, and have summarized the terms of our major lease agreements. We are in the process of reviewing our existing lease agreements to assess the impact this guidance may have on our consolidated financial statements. We currently anticipate that the adoption of ASU 2016-02 will materially affect our consolidated balance sheets by recognizing new right-of-use assets and lease liabilities for operating leases, but will not have a material impact on our consolidated statements of operations.

- removed (2019-05-06):
[0001596532-18-000233:note_history:103]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. Credit losses relating to available-for-sale debt securities should be recorded through an allowance for credit losses. This standard is effective for us for our first quarter of 2020. We are currently assessing the impact this guidance may have on our consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2019-05-06):
[0001596532-18-000233:note_history:104]
Effective January 1, 2018, we adopted a new revenue recognition policy in accordance with ASC 606 - Revenue from Contracts with Customers (“ASC 606”) using the modified retrospective method as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1.  Prior to 2018, our revenue recognition policy was based on ASC 605 - Revenue Recognition (“ASC 605”), and is described in Note 1 of Notes to Consolidated Financial Statements under Item 8 of our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

- removed (2019-05-06):
[0001596532-18-000233:note_history:105]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with post-contract customer support (“PCS”). We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

- removed (2019-05-06):
[0001596532-18-000233:note_history:106]
| • | Identification of the contract, or contracts, with a customer |

- removed (2019-05-06):
[0001596532-18-000233:note_history:107]
| • | Identification of the performance obligations in the contract |

- removed (2019-05-06):
[0001596532-18-000233:note_history:108]
| • | Determination of the transaction price |

- removed (2019-05-06):
[0001596532-18-000233:note_history:109]
| • | Allocation of the transaction price to the performance obligations in the contract |

- removed (2019-05-06):
[0001596532-18-000233:note_history:110]
| • | Recognition of revenue when (or as) we satisfy the performance obligation |

- removed (2019-05-06):
[0001596532-18-000233:note_history:111]
Post-Contract Customer Support

- removed (2019-05-06):
[0001596532-18-000233:note_history:112]
Post-contract support, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernable pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and addresses customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

- removed (2019-05-06):
[0001596532-18-000233:note_history:113]
Contracts with Multiple Performance Obligations

- removed (2019-05-06):
[0001596532-18-000233:note_history:114]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts which contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is required to determine the SSP for each distinct performance obligation.  We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

- removed (2019-05-06):
[0001596532-18-000233:note_history:115]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services are sold, and the size of the end customer.

- removed (2019-05-06):
[0001596532-18-000233:note_history:116]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

- removed (2019-05-06):
[0001596532-18-000233:note_history:117]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

- removed (2019-05-06):
[0001596532-18-000233:note_history:118]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

- removed (2019-05-06):
[0001596532-18-000233:note_history:119]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

- removed (2019-05-06):
[0001596532-18-000233:note_history:120]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

- removed (2019-05-06):
[0001596532-18-000233:note_history:121]
Contract Balances

- removed (2019-05-06):
[0001596532-18-000233:note_history:122]
A contract asset is recognized when we have performed under the contract, but our right to consideration is conditional on something other than the passage of time. Contract assets are included in “Other current assets” on our condensed consolidated balance sheets.

- removed (2019-05-06):
[0001596532-18-000233:note_history:123]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a contract that is cancellable. Contract liabilities are included in “Other current liabilities” and “Other long-term liabilities” on our condensed consolidated balance sheets.

- removed (2019-05-06):
[0001596532-18-000233:note_history:124]
Assets Recognized from Costs to Obtain a Contract with a Customer

- removed (2019-05-06):
[0001596532-18-000233:note_history:125]
Effective January 1, 2018 in connection with the adoption of ASC 606, we recognize an asset for the incremental costs of obtaining a contract with a customer if we expect the benefit of those costs to be longer than one year. We have determined that certain sales commissions earned by our sales force meet the requirements for capitalization. These costs are deferred and then amortized over a period of benefit that we have determined to be five years. Total capitalized costs to obtain a contract are included in other current and long-term assets on our condensed consolidated balance sheets.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2019-05-06):
[0001596532-19-000104:note_history:126]
12.    Subsequent Event

- added (2019-05-06):
[0001596532-19-000104:note_history:127]
Stock Repurchase Program

- added (2019-05-06):
[0001596532-19-000104:note_history:128]
Subsequent to March 31, 2019, our board of directors authorized a $1.0 billion stock repurchase program (the “Repurchase Program”).  This authorization allows us to repurchase shares of our common stock opportunistically and will be funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, or a combination of the foregoing. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice.
