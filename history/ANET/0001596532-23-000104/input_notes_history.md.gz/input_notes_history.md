# ANET note change history — 0001596532-22-000294 → 0001596532-23-000104


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-02):
[0001596532-23-000104:note_history:1]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of March 31, 2023, we had non-cancellable purchase commitments of $2.9 billion, of which $2.4 billion have confirmed receipt dates within 12 months, and $0.5 billion have confirmed receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.
  (was, 2022-11-01, similarity 0.9933):
[0001596532-22-000294:note_history:1]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2022, we had non-cancellable purchase commitments of $4.3 billion, of which $3.1 billion have confirmed receipt dates within 12 months, and $1.2 billion have confirmed receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

- changed (2023-05-02):
[0001596532-23-000104:note_history:2]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $246.7 million and $192.5 million as of March 31, 2023 and December 31, 2022, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.
  (was, 2022-11-01, similarity 0.9779):
[0001596532-22-000294:note_history:2]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $124.7 million and $49.1 million as of September 30, 2022 and December 31, 2021, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

- changed (2023-05-02):
[0001596532-23-000104:note_history:3]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2023, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.
  (was, 2022-11-01, similarity 0.9932):
[0001596532-22-000294:note_history:3]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2022, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-02):
[0001596532-23-000104:note_history:4]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of next generation data center and campus workspace environments. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.
  (was, 2022-11-01, similarity 0.8966):
[0001596532-22-000294:note_history:4]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale internet companies, cloud service providers and next-generation enterprises. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

- changed (2023-05-02):
[0001596532-23-000104:note_history:5]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2023, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2022 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.
  (was, 2022-11-01, similarity 0.9807):
[0001596532-22-000294:note_history:5]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2022, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2021 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

- added (2023-05-02):
[0001596532-23-000104:note_history:6]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including inflation, monetary policy shifts, the recent banking crisis, recession risks, and potential supply chain and other disruptions from the Russia-Ukraine conflict and the U.S. trade war with China.

- added (2023-05-02):
[0001596532-23-000104:note_history:7]
We have continued to work closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. We have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, and have begun to see some reduction in customer lead times on certain products. As customer lead times improve more broadly, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to a somewhat shorter demand-planning horizon. While inventory and working capital levels may continue to increase and remain elevated in the near term, we expect that purchase commitments will continue to decline as supplier lead times begin to shorten.  Although these elevated inventory positions largely relate to early life cycle products, we cannot be certain that we will be able to sell this inventory which may result in excess and obsolete inventory charges in the future.

- added (2023-05-02):
[0001596532-23-000104:note_history:8]
In addition, inflation pressure in our supply chain, scarcity of some materials needed to build our products and disruptions to our manufacturing process have increased our cost of revenue and have impacted, and may continue to negatively

- added (2023-05-02):
[0001596532-23-000104:note_history:9]
impact our gross margin. Our operating cash-flows have also been and may continue to be negatively impacted by significant component inventories on hand or at our contract manufacturers. While we have seen some improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the Russia-Ukraine conflict, continued escalation of the conflict may negatively impact the global economy and our future operating results and financial condition.

- added (2023-05-02):
[0001596532-23-000104:note_history:10]
Management continues to actively monitor the impact of these macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable; however, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that our customers continue to grapple with the impact of these macroeconomic factors on their businesses and future investment plans, resulting in business uncertainty and a more constrained approach to forecasts and orders. In addition, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

- changed (2023-05-02):
[0001596532-23-000104:note_history:11]
Recent Accounting Pronouncements Not Yet Effective
  (was, 2022-11-01, similarity 0.6957):
[0001596532-22-000294:note_history:11]
Recently Adopted Accounting Pronouncements

- added (2023-05-02):
[0001596532-23-000104:note_history:12]
We believe that all recently issued accounting pronouncements from the FASB will not have a material impact on our Consolidated Financial Statements or do not apply to our operations.

- removed (2023-05-02):
[0001596532-22-000294:note_history:13]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including supply chain and labor shortages, inflation and monetary policy shifts, recession risks, the ongoing global coronavirus ("COVID-19") pandemic and potential disruptions from the Russia-Ukraine conflict and the U.S. trade war with China.

- removed (2023-05-02):
[0001596532-22-000294:note_history:14]
Our contract manufacturers and suppliers have experienced workforce disruptions, delays in component sourcing, production and export of their products and component shortages and increased component costs, which have disrupted our supply chain and have impacted and will likely continue to impact our ability to supply products to our customers on a timely basis. While overall demand remains strong across our customers base, we believe ongoing supply disruptions combined with other supply chain related constraints could impact our ability to fulfill this increased demand and as a result could negatively impact our business in future periods. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. Our operating cash flows have also been and may continue to be negatively impacted by increased component inventories on hand or at our contract manufacturers, awaiting supply of a limited number of scarce components necessary to build and ship the completed product. The extent of the impact on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, the impact to

- removed (2023-05-02):
[0001596532-22-000294:note_history:15]
our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. Management continues to actively monitor the impact of these macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which these factors may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

- removed (2023-05-02):
[0001596532-22-000294:note_history:16]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. ASU 2021-08 requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC 606. Under previous GAAP, an acquirer generally recognized assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 results in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption impact was immaterial to the condensed consolidated financial statements. The standard did not impact acquired contract assets or liabilities from business combinations occurring prior to the adoption date.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-02):
[0001596532-23-000104:note_history:17]
|  |  | March 31, 2023 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 274,507 |  |  | $ | (1,144) |  |  | $ | 439,448 |  |  | $ | (6,826) |  |  | $ | 713,955 |  |  | $ | (7,970) |  |
| Corporate bonds |  | 457,708 |  |  | (2,677) |  |  | 370,215 |  |  | (5,623) |  |  | 827,923 |  |  | (8,300) |  |
| Agency securities |  | 82,404 |  |  | (383) |  |  | 62,217 |  |  | (1,355) |  |  | 144,621 |  |  | (1,738) |  |
| Total |  | $ | 814,619 |  |  | $ | (4,204) |  |  | $ | 871,880 |  |  | $ | (13,804) |  |  | $ | 1,686,499 |  |  | $ | (18,008) |  |
  (was, 2022-11-01, similarity 0.9895):
[0001596532-22-000294:note_history:17]
|  |  | September 30, 2022 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 877,442 |  |  | $ | (13,026) |  |  | $ | 292,554 |  |  | $ | (4,976) |  |  | $ | 1,169,996 |  |  | $ | (18,002) |  |
| Corporate bonds |  | 625,577 |  |  | (13,314) |  |  | 258,208 |  |  | (5,035) |  |  | 883,785 |  |  | (18,349) |  |
| Agency securities |  | 155,296 |  |  | (2,807) |  |  | 24,176 |  |  | (491) |  |  | 179,472 |  |  | (3,298) |  |
| Total |  | $ | 1,658,315 |  |  | $ | (29,147) |  |  | $ | 574,938 |  |  | $ | (10,502) |  |  | $ | 2,233,253 |  |  | $ | (39,649) |  |
