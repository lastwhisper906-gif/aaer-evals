# ANET notes — 0001596532-23-000104


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-23-000104:notes:1]
[same as prior period, unchanged from 0001596532-22-000294:notes:1]

[0001596532-23-000104:notes:2]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of next generation data center and campus workspace environments. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-23-000104:notes:3]
[same as prior period, unchanged from 0001596532-22-000294:notes:3]

[0001596532-23-000104:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2023, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2022 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

[0001596532-23-000104:notes:5]
Our condensed consolidated financial statements and related financial information in this Quarterly Report on Form 10-Q should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2022, filed with the SEC on February 14, 2023.

[0001596532-23-000104:notes:6]
[same as prior period, unchanged from 0001596532-22-000294:notes:6]

[0001596532-23-000104:notes:7]
[same as prior period, unchanged from 0001596532-22-000294:notes:7]

[0001596532-23-000104:notes:8]
[same as prior period, unchanged from 0001596532-22-000294:notes:8]

[0001596532-23-000104:notes:9]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including inflation, monetary policy shifts, the recent banking crisis, recession risks, and potential supply chain and other disruptions from the Russia-Ukraine conflict and the U.S. trade war with China.

[0001596532-23-000104:notes:10]
We have continued to work closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. We have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, and have begun to see some reduction in customer lead times on certain products. As customer lead times improve more broadly, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to a somewhat shorter demand-planning horizon. While inventory and working capital levels may continue to increase and remain elevated in the near term, we expect that purchase commitments will continue to decline as supplier lead times begin to shorten.  Although these elevated inventory positions largely relate to early life cycle products, we cannot be certain that we will be able to sell this inventory which may result in excess and obsolete inventory charges in the future.

[0001596532-23-000104:notes:11]
In addition, inflation pressure in our supply chain, scarcity of some materials needed to build our products and disruptions to our manufacturing process have increased our cost of revenue and have impacted, and may continue to negatively

[0001596532-23-000104:notes:12]
impact our gross margin. Our operating cash-flows have also been and may continue to be negatively impacted by significant component inventories on hand or at our contract manufacturers. While we have seen some improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the Russia-Ukraine conflict, continued escalation of the conflict may negatively impact the global economy and our future operating results and financial condition.

[0001596532-23-000104:notes:13]
Management continues to actively monitor the impact of these macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable; however, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that our customers continue to grapple with the impact of these macroeconomic factors on their businesses and future investment plans, resulting in business uncertainty and a more constrained approach to forecasts and orders. In addition, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

[0001596532-23-000104:notes:14]
Recent Accounting Pronouncements Not Yet Effective

[0001596532-23-000104:notes:15]
We believe that all recently issued accounting pronouncements from the FASB will not have a material impact on our Consolidated Financial Statements or do not apply to our operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-23-000104:notes:16]
[same as prior period, unchanged from 0001596532-22-000294:notes:14]

[0001596532-23-000104:notes:17]
[same as prior period, unchanged from 0001596532-22-000294:notes:15]

[0001596532-23-000104:notes:18]
|  |  | March 31, 2023 |  | December 31, 2022 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 315,895 |  |  | $ | — |  |  | $ | — |  |  | $ | 315,895 |  |  | $ | 322,294 |  |  | $ | — |  |  | $ | — |  |  | $ | 322,294 |  |
| Commercial paper |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5,422 |  |  | — |  |  | 5,422 |  |
| U.S. government notes |  | 47,678 |  |  | — |  |  | — |  |  | 47,678 |  |  | 51,986 |  |  | — |  |  | — |  |  | 51,986 |  |
| Agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 17,559 |  |  | — |  |  | 17,559 |  |
|  |  | 363,573 |  |  | — |  |  | — |  |  | 363,573 |  |  | 374,280 |  |  | 22,981 |  |  | — |  |  | 397,261 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 87,825 |  |  | — |  |  | 87,825 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Certificate of deposits(1) |  | — |  |  | 14,496 |  |  | — |  |  | 14,496 |  |  | — |  |  | 10,492 |  |  | — |  |  | 10,492 |  |
| U.S. government notes |  | 839,675 |  |  | — |  |  | — |  |  | 839,675 |  |  | 993,955 |  |  | — |  |  | — |  |  | 993,955 |  |
| Corporate bonds |  | — |  |  | 1,040,610 |  |  | — |  |  | 1,040,610 |  |  | — |  |  | 1,113,134 |  |  | — |  |  | 1,113,134 |  |
| Agency securities |  | — |  |  | 378,693 |  |  | — |  |  | 378,693 |  |  | — |  |  | 215,380 |  |  | — |  |  | 215,380 |  |
| Marketable equity securities(2) |  | 13,490 |  |  | — |  |  | — |  |  | 13,490 |  |  | 19,061 |  |  | — |  |  | — |  |  | 19,061 |  |
|  |  | 853,165 |  |  | 1,521,624 |  |  | — |  |  | 2,374,789 |  |  | 1,013,016 |  |  | 1,339,006 |  |  | — |  |  | 2,352,022 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,284 |  |  | — |  |  | — |  |  | 4,284 |  |  | 4,271 |  |  | — |  |  | — |  |  | 4,271 |  |
| Total Financial Assets |  | $ | 1,221,022 |  |  | $ | 1,521,624 |  |  | $ | — |  |  | $ | 2,742,646 |  |  | $ | 1,391,567 |  |  | $ | 1,361,987 |  |  | $ | — |  |  | $ | 2,753,554 |  |

[0001596532-23-000104:notes:19]
[same as prior period, unchanged from 0001596532-22-000294:notes:17]

[0001596532-23-000104:notes:20]
(1) As of March 31, 2023 and December 31, 2022, all of our certificates of deposits were domestic deposits.

[0001596532-23-000104:notes:21]
(2) The $13.5 million represents the fair value of marketable equity securities as of March 31, 2023. This publicly-traded equity investment generated an unrealized loss of $5.6 million for the three months ended March 31, 2023, and an unrealized gain of $13.5 million for the three months ended March 31, 2022.  Total initial cost for this investment was $3.0 million with no changes since our initial investment. The unrealized gains and losses are included in Other income (expense), net on the unaudited Condensed Consolidated Statements of Operations. Refer to Note 3. Financial Statements Details.

[0001596532-23-000104:notes:22]
During the three months ended on March 31, 2023, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-23-000104:notes:23]
[same as prior period, unchanged from 0001596532-22-000294:notes:21]

[0001596532-23-000104:notes:24]
[same as prior period, unchanged from 0001596532-22-000294:notes:22]

[0001596532-23-000104:notes:25]
|  |  | March 31, 2023 |  | December 31, 2022 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 87,825 |  |  | $ | — |  |  | $ | — |  |  | $ | 87,825 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| U.S. government |  | 847,523 |  |  | 122 |  |  | (7,970) |  |  | 839,675 |  |  | 1,007,175 |  |  | 3 |  |  | (13,223) |  |  | 993,955 |  |
| Corporate bonds |  | 1,048,045 |  |  | 865 |  |  | (8,300) |  |  | 1,040,610 |  |  | 1,125,920 |  |  | 271 |  |  | (13,057) |  |  | 1,113,134 |  |
| Agency securities |  | 379,818 |  |  | 613 |  |  | (1,738) |  |  | 378,693 |  |  | 217,893 |  |  | 83 |  |  | (2,596) |  |  | 215,380 |  |
| Total |  | $ | 2,363,211 |  |  | $ | 1,600 |  |  | $ | (18,008) |  |  | $ | 2,346,803 |  |  | $ | 2,350,988 |  |  | $ | 357 |  |  | $ | (28,876) |  |  | $ | 2,322,469 |  |

[0001596532-23-000104:notes:26]
For debt securities in unrealized loss positions, it is not likely that we will be required to sell such securities before recovery of their amortized cost basis nor do we have the intent to sell such securities before maturity. We invest in debt securities that have maximum maturities of two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. Given the short-term and conservative nature of our portfolio, the unrealized losses are not related to credit risk; therefore, we did not recognize any credit losses or non-credit-related impairments related to our available-for-sale marketable debt securities for the three months ended March 31, 2023. All unrealized losses were recognized in other comprehensive income (loss). Realized losses were immaterial for the three months ended March 31, 2023.

[0001596532-23-000104:notes:27]
[same as prior period, unchanged from 0001596532-22-000294:notes:25]

[0001596532-23-000104:notes:28]
|  |  | March 31, 2023 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 274,507 |  |  | $ | (1,144) |  |  | $ | 439,448 |  |  | $ | (6,826) |  |  | $ | 713,955 |  |  | $ | (7,970) |  |
| Corporate bonds |  | 457,708 |  |  | (2,677) |  |  | 370,215 |  |  | (5,623) |  |  | 827,923 |  |  | (8,300) |  |
| Agency securities |  | 82,404 |  |  | (383) |  |  | 62,217 |  |  | (1,355) |  |  | 144,621 |  |  | (1,738) |  |
| Total |  | $ | 814,619 |  |  | $ | (4,204) |  |  | $ | 871,880 |  |  | $ | (13,804) |  |  | $ | 1,686,499 |  |  | $ | (18,008) |  |

[0001596532-23-000104:notes:29]
As of March 31, 2023, we had no marketable debt securities with contractual maturities that exceed 24 months. The fair values of marketable debt securities, by remaining contractual maturities, are as follows (in thousands):

[0001596532-23-000104:notes:30]
|  |  | March 31, 2023 |
|  |  | Fair Value |
| Due in 1 year or less |  | $ | 1,608,879 |  |
| Due in 1 to 2 years |  | 737,924 |  |
| Total debt securities |  | $ | 2,346,803 |  |

[0001596532-23-000104:notes:31]
The weighted-average remaining duration of our marketable debt securities is approximately 0.8 years as of March 31, 2023. As we view these marketable debt securities as available to support current operations, we classify marketable debt securities with maturities beyond 12 months as current assets under the caption "Marketable securities" on the condensed consolidated balance sheets.

[0001596532-23-000104:notes:32]
[same as prior period, unchanged from 0001596532-22-000294:notes:30]

[0001596532-23-000104:notes:33]
[same as prior period, unchanged from 0001596532-22-000294:notes:31]

[0001596532-23-000104:notes:34]
[same as prior period, unchanged from 0001596532-22-000294:notes:32]

[0001596532-23-000104:notes:35]
We did not record any realized gains or losses for our non-marketable equity securities measured at fair value on a non-recurring basis during the three months ended March 31, 2023 and March 31, 2022. We recorded unrealized gains of nil and $15.0 million on non-marketable equity securities based on observable price changes from orderly transactions of identical or similar securities in the three months ended March 31, 2023 and March 31, 2022, respectively. We recorded immaterial unrealized losses in the three months ended March 31, 2023. We evaluate our non-marketable equity securities for impairment at each reporting period via a qualitative assessment with various potential impairment indicators, including, but not limited to, an assessment of a significant adverse change in the economic environment, significant adverse changes in the general market condition of the geographies and industries in which our investees operate, and other publicly-available information that affected the value of the its non-marketable equity securities.

[0001596532-23-000104:notes:36]
The following table summarizes the activity related to our non-marketable equity securities as of March 31, 2023 and December 31, 2022 (in thousands):

[0001596532-23-000104:notes:37]
|  |  | March 31, 2023 |  | December 31, 2022 |
| Cost of investments |  | $ | 23,875 |  |  | $ | 23,625 |  |
| Cumulative impairment and downward adjustment |  | (1,205) |  |  | (888) |  |
| Cumulative upward adjustment |  | 16,731 |  |  | 16,731 |  |
| Carrying amount of investments |  | $ | 39,401 |  |  | $ | 39,468 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-23-000104:notes:38]
[same as prior period, unchanged from 0001596532-22-000294:notes:37]

[0001596532-23-000104:notes:39]
(1) As of March 31, 2023 and December 31, 2022, all of our certificates of deposits were domestic deposits.
(2) The $13.5 million represents the fair value of marketable equity securities as of March 31, 2023. This publicly-traded equity investment generated an unrealized loss of $5.6 million for the three months ended March 31, 2023, and an unrealized gain of $13.5 million for the three months ended March 31, 2022.  Total initial cost for this investment was $3.0 million with no changes since our initial investment. The unrealized gains and losses are included in Other income (expense), net on the unaudited Condensed Consolidated Statements of Operations. Refer to Note 3. Financial Statements Details.The following table summarizes the amortized cost, unrealized gains and losses, and fair value of our debt securities measured at fair value on a recurring basis (in thousands):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-23-000104:notes:40]
[same as prior period, unchanged from 0001596532-22-000294:notes:39]

[0001596532-23-000104:notes:41]
[same as prior period, unchanged from 0001596532-22-000294:notes:40]

[0001596532-23-000104:notes:42]
|  |  | March 31, 2023 |  | December 31, 2022 |
| Cash and cash equivalents |  | $ | 956,341 |  |  | $ | 671,707 |  |
| Restricted cash included in other assets |  | 4,284 |  |  | 4,271 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 960,625 |  |  | $ | 675,978 |  |

[0001596532-23-000104:notes:43]
[same as prior period, unchanged from 0001596532-22-000294:notes:42]

[0001596532-23-000104:notes:44]
[same as prior period, unchanged from 0001596532-22-000294:notes:43]

[0001596532-23-000104:notes:45]
|  |  | March 31, 2023 |  | December 31, 2022 |
| Accounts receivable |  | $ | 871,282 |  |  | $ | 928,490 |  |
| Allowance for doubtful accounts |  | (1,264) |  |  | (19) |  |
| Product sales rebate and returns reserve |  | (7,143) |  |  | (5,375) |  |
| Accounts receivable, net |  | $ | 862,875 |  |  | $ | 923,096 |  |

[0001596532-23-000104:notes:46]
[same as prior period, unchanged from 0001596532-22-000294:notes:45]

[0001596532-23-000104:notes:47]
[same as prior period, unchanged from 0001596532-22-000294:notes:46]

[0001596532-23-000104:notes:48]
|  |  | March 31, 2023 |  | December 31, 2022 |
| Raw materials |  | $ | 1,060,261 |  |  | $ | 759,519 |  |
| Finished goods |  | 622,442 |  |  | 530,187 |  |
| Total inventories |  | $ | 1,682,703 |  |  | $ | 1,289,706 |  |

[0001596532-23-000104:notes:49]
[same as prior period, unchanged from 0001596532-22-000294:notes:48]

[0001596532-23-000104:notes:50]
[same as prior period, unchanged from 0001596532-22-000294:notes:49]

[0001596532-23-000104:notes:51]
|  |  | March 31, 2023 |  | December 31, 2022 |
| Inventory deposits |  | $ | 243,923 |  |  | $ | 162,047 |  |
| Other current assets |  | 125,353 |  |  | 124,357 |  |
| Other prepaid expenses and deposits |  | 24,549 |  |  | 27,813 |  |
| Total prepaid expenses and other current assets |  | $ | 393,825 |  |  | $ | 314,217 |  |

[0001596532-23-000104:notes:52]
[same as prior period, unchanged from 0001596532-22-000294:notes:51]

[0001596532-23-000104:notes:53]
[same as prior period, unchanged from 0001596532-22-000294:notes:52]

[0001596532-23-000104:notes:54]
|  |  | March 31, 2023 |  | December 31, 2022 |
| Land |  | $ | 42,337 |  |  | $ | 41,500 |  |
| Equipment and machinery |  | 128,883 |  |  | 122,407 |  |
| Computer hardware and software |  | 50,892 |  |  | 52,148 |  |
| Leasehold improvements |  | 30,204 |  |  | 30,102 |  |
| Furniture and fixtures |  | 3,577 |  |  | 3,575 |  |
| Construction-in-process |  | 5,634 |  |  | 2,124 |  |
| Property and equipment, gross |  | 261,527 |  |  | 251,856 |  |
| Less: accumulated depreciation |  | (164,370) |  |  | (156,847) |  |
| Property and equipment, net |  | $ | 97,157 |  |  | $ | 95,009 |  |

[0001596532-23-000104:notes:55]
Depreciation expense was $7.1 million and $5.6 million for the three months ended March 31, 2023 and 2022, respectively.

[0001596532-23-000104:notes:56]
[same as prior period, unchanged from 0001596532-22-000294:notes:55]

[0001596532-23-000104:notes:57]
[same as prior period, unchanged from 0001596532-22-000294:notes:56]

[0001596532-23-000104:notes:58]
|  |  | March 31, 2023 |  | December 31, 2022 |
| Accrued compensation-related costs |  | $ | 57,776 |  |  | $ | 117,053 |  |
| Accrued Supplier liability |  | 78,168 |  |  | 71,481 |  |
| Accrued manufacturing costs |  | 138,530 |  |  | 45,379 |  |
| Accrued product development costs |  | 44,551 |  |  | 27,380 |  |
| Other |  | 32,739 |  |  | 31,194 |  |
| Total accrued liabilities |  | $ | 351,764 |  |  | $ | 292,487 |  |

[0001596532-23-000104:notes:59]
[same as prior period, unchanged from 0001596532-22-000294:notes:64]

[0001596532-23-000104:notes:60]
[same as prior period, unchanged from 0001596532-22-000294:notes:65]

[0001596532-23-000104:notes:61]
[same as prior period, unchanged from 0001596532-22-000294:notes:66]

[0001596532-23-000104:notes:62]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Contract liabilities, beginning balance |  | $ | 103,448 |  |  | $ | 93,382 |  |  |  |  |  |
| Less: Revenue recognized from beginning balance |  | (9,243) |  |  | (8,248) |  |  |  |  |  |
| Less: Beginning balance reclassified to deferred revenue |  | (4,382) |  |  | (3,837) |  |  |  |  |  |
| Add: Contract liabilities recognized |  | 15,224 |  |  | 17,125 |  |  |  |  |  |
| Contract liabilities, ending balance |  | $ | 105,047 |  |  | $ | 98,422 |  |  |  |  |  |

[0001596532-23-000104:notes:63]
As of March 31, 2023 and December 31, 2022, $46.9 million and $45.2 million of our contract liabilities, respectively, were included in "Other current liabilities" with the remaining balances included in "Other long-term liabilities" on the condensed consolidated balance sheets.

[0001596532-23-000104:notes:64]
[same as prior period, unchanged from 0001596532-22-000294:notes:69]

[0001596532-23-000104:notes:65]
[same as prior period, unchanged from 0001596532-22-000294:notes:70]

[0001596532-23-000104:notes:66]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Deferred revenue, beginning balance |  | $ | 1,041,246 |  |  | $ | 929,312 |  |  |  |  |  |
| Less: Revenue recognized from beginning balance |  | (214,450) |  |  | (128,136) |  |  |  |  |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 265,478 |  |  | 322,570 |  |  |  |  |  |
| Deferred revenue, ending balance |  | $ | 1,092,274 |  |  | $ | 1,123,746 |  |  |  |  |  |

[0001596532-23-000104:notes:67]
[same as prior period, unchanged from 0001596532-22-000294:notes:72]

[0001596532-23-000104:notes:68]
Other performance obligations totaling $1.0 billion as of March 31, 2023 include unbilled multi-year PCS and service contract amounts of $120.1 million and $908.6 million of binding contractual agreements with certain customers that are primarily related to future product shipments.

[0001596532-23-000104:notes:69]
[same as prior period, unchanged from 0001596532-22-000294:notes:74]

[0001596532-23-000104:notes:70]
Total revenue from our contract liabilities, deferred revenue and other performance obligations that will be recognized in future periods amounts to $2.2 billion. Included in this amount is the $908.6 million of binding contractual agreements related primarily to future product shipments. As of March 31, 2023, it is expected that the majority of the amounts allocated to these specific performance obligations will be recognized as revenue upon product shipment over the next two years. In addition, as of March 31, 2023, approximately 82% of the remaining $1.3 billion of this future revenue is expected to be recognized over the next two years and approximately 18% is expected to be recognized during the third to the fifth year.

[0001596532-23-000104:notes:71]
[same as prior period, unchanged from 0001596532-22-000294:notes:77]

[0001596532-23-000104:notes:72]
[same as prior period, unchanged from 0001596532-22-000294:notes:78]

[0001596532-23-000104:notes:73]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Interest income |  | $ | 22,509 |  |  | $ | 2,428 |  |  |  |  |  |
| Unrealized gain (loss) on equity investments |  | (5,571) |  |  | 28,497 |  |  |  |  |  |
| Other income (expense), net |  | (4,792) |  |  | 555 |  |  |  |  |  |
| Total |  | $ | 12,146 |  |  | $ | 31,480 |  |  |  |  |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-23-000104:notes:74]
[same as prior period, unchanged from 0001596532-22-000294:notes:80]

[0001596532-23-000104:notes:75]
[same as prior period, unchanged from 0001596532-22-000294:notes:81]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-23-000104:notes:76]
[same as prior period, unchanged from 0001596532-22-000294:notes:82]

[0001596532-23-000104:notes:77]
During the year ended December 31, 2022, we completed two acquisitions of private companies for total consideration of $158.9 million including $4.0 million in common stock and the remainder in cash. The purchase prices included $62.3 million of intangible assets, $77.5 million of goodwill and $19.1 million of net tangible assets acquired. We also incurred certain acquisition-related expenses of $4.7 million, which primarily consisted of retention bonuses to continuing employees as well as professional and consulting fees.

[0001596532-23-000104:notes:78]
The purchase price allocation for one of the acquisitions has been finalized, while for the other acquisition it is still subject to continuing management analysis. No changes were made to the purchase price allocation for the three months ended March 31, 2023.

[0001596532-23-000104:notes:79]
[same as prior period, unchanged from 0001596532-22-000294:notes:86]

[0001596532-23-000104:notes:80]
No changes were made to the carrying values of goodwill for the three months ended March 31, 2023.

[0001596532-23-000104:notes:81]
[same as prior period, unchanged from 0001596532-22-000294:notes:89]

[0001596532-23-000104:notes:82]
[same as prior period, unchanged from 0001596532-22-000294:notes:90]

[0001596532-23-000104:notes:83]
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life (in years) |
|  | December 31, 2022 |  | Additions |  | March 31, 2023 |  | December 31, 2022 |  | Amortization |  | March 31, 2023 |  | December 31, 2022 |  | March 31, 2023 |  |
| Developed technology | $ | 154,930 |  |  | $ | — |  |  | $ | 154,930 |  |  | $ | (79,036) |  |  | $ | (6,820) |  |  | $ | (85,856) |  |  | $ | 75,894 |  |  | $ | 69,074 |  |  | 4.3 |
| Customer relationships | 54,620 |  |  | — |  |  | 54,620 |  |  | (14,097) |  |  | (1,925) |  |  | (16,022) |  |  | 40,523 |  |  | 38,598 |  |  | 5.4 |
| Trade name | 12,390 |  |  | — |  |  | 12,390 |  |  | (6,602) |  |  | (570) |  |  | (7,172) |  |  | 5,788 |  |  | 5,218 |  |  | 2.3 |
| Others | 5,720 |  |  | — |  |  | 5,720 |  |  | (5,720) |  |  | — |  |  | (5,720) |  |  | — |  |  | — |  |  | 0.0 |
| Total | $ | 227,660 |  |  | $ | — |  |  | $ | 227,660 |  |  | $ | (105,455) |  |  | $ | (9,315) |  |  | $ | (114,770) |  |  | $ | 122,205 |  |  | $ | 112,890 |  |  | 4.6 |

[0001596532-23-000104:notes:84]
Amortization expense related to acquisition-related intangible assets was $9.3 million, and $7.3 million for the three months ended March 31, 2023 and 2022, respectively.

[0001596532-23-000104:notes:85]
As of March 31, 2023, future estimated amortization expense related to the acquisition-related intangible assets is as follows (in thousands):

[0001596532-23-000104:notes:86]
|  |  | Future Amortization Expense |
| Remainder of 2023 |  | $ | 24,123 |  |
| 2024 |  | 26,759 |  |
| 2025 |  | 19,642 |  |
| 2026 |  | 17,260 |  |
| 2027 |  | 13,436 |  |
| Thereafter |  | 11,670 |  |
| Total |  | $ | 112,890 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-23-000104:notes:87]
Commitments and Contingencies
Purchase Commitments

[0001596532-23-000104:notes:88]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of March 31, 2023, we had non-cancellable purchase commitments of $2.9 billion, of which $2.4 billion have confirmed receipt dates within 12 months, and $0.5 billion have confirmed receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-23-000104:notes:89]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $246.7 million and $192.5 million as of March 31, 2023 and December 31, 2022, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

[0001596532-23-000104:notes:90]
Guarantees

[0001596532-23-000104:notes:91]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-23-000104:notes:92]
Legal Proceedings

[0001596532-23-000104:notes:93]
WSOU Investments, LLC

[0001596532-23-000104:notes:94]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California.  On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement.  On July 1, 2022, the court stayed the case pending the resolution of an inter partes review of one of the patents-in-suit.

[0001596532-23-000104:notes:95]
We intend to vigorously defend against the claims brought against us by WSOU; however, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-23-000104:notes:96]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated; however, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-23-000104:notes:97]
Other matters

[0001596532-23-000104:notes:98]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-23-000104:notes:99]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2023, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-23-000104:notes:100]
[same as prior period, unchanged from 0001596532-22-000294:notes:108]

[0001596532-23-000104:notes:101]
Our board of directors has authorized a $1.0 billion stock repurchase program (the “Repurchase Program”). This authorization allows us to repurchase shares of our common stock that will be funded from working capital and expires in the fourth quarter of 2024. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the "Exchange Act"), or a combination of the foregoing. The Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the company at any time without prior notice.  As of March 31, 2023, the remaining authorized amount for stock repurchases under the Repurchase Program was approximately $174.5 million.

[0001596532-23-000104:notes:102]
A summary of the stock repurchase activity under the New Repurchase Program for the three months ended March 31, 2023 is as follows (in thousands, except per share amounts):

[0001596532-23-000104:notes:103]
|  |  |  |  |  |  | Three Months Ended |
|  |  |  |  |  |  | March 31, 2023 |
| Aggregate purchase price |  |  |  |  |  | $ | 82,275 |  |
| Shares repurchased |  |  |  |  |  | 735 |  |
| Average price paid per share |  |  |  |  |  | $ | 111.90 |  |

[0001596532-23-000104:notes:104]
[same as prior period, unchanged from 0001596532-22-000294:notes:112]

[0001596532-23-000104:notes:105]
[same as prior period, unchanged from 0001596532-22-000294:notes:113]

[0001596532-23-000104:notes:106]
[same as prior period, unchanged from 0001596532-22-000294:notes:114]

[0001596532-23-000104:notes:107]
[same as prior period, unchanged from 0001596532-22-000294:notes:115]

[0001596532-23-000104:notes:108]
Awards granted under the 2014 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Units (“RSUs”), Restricted Stock Awards (“RSAs”) or Stock Appreciation Rights (“SARs”). The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of the outstanding shares of our common stock on the immediately preceding December 31, but not to exceed 50,000,000 shares (the “2014 Plan Evergreen Increase”), unless our board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2023, our board of directors authorized an increase of 9.2 million shares to the shares available for issuance under the 2014 Plan. As of March 31, 2023, there remained approximately 99.4 million shares available for issuance under the 2014 Plan.

[0001596532-23-000104:notes:109]
[same as prior period, unchanged from 0001596532-22-000294:notes:117]

[0001596532-23-000104:notes:110]
In April 2014, our board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding on the immediately preceding December 31, but not to exceed 10,000,000 shares, unless our board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2023, our board of directors authorized an increase of 3.1 million shares to the shares available for issuance under the ESPP. During the three months ended March 31, 2023, we issued 139,758 shares at a weighted-average purchase price of $102.66 per share under the ESPP. As of March 31, 2023, there remained approximately 23.5 million shares available for issuance under the ESPP.

[0001596532-23-000104:notes:111]
[same as prior period, unchanged from 0001596532-22-000294:notes:119]

[0001596532-23-000104:notes:112]
[same as prior period, unchanged from 0001596532-22-000294:notes:120]

[0001596532-23-000104:notes:113]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2022 |  | 5,769 |  |  | $ | 14.09 |  |  | 2.0 |  | $ | 618,774 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (1,132) |  |  | 7.72 |  |  |  |  |  |
| Options canceled |  | (1) |  |  | 9.26 |  |  |  |  |  |
| Balance—March 31, 2023 |  | 4,636 |  |  | $ | 15.65 |  |  | 1.9 |  | $ | 705,637 |  |
| Vested and exercisable—March 31, 2023 |  | 4,225 |  |  | $ | 13.43 |  |  | 1.6 |  | $ | 652,547 |  |

[0001596532-23-000104:notes:114]
[same as prior period, unchanged from 0001596532-22-000294:notes:122]

[0001596532-23-000104:notes:115]
[same as prior period, unchanged from 0001596532-22-000294:notes:123]

[0001596532-23-000104:notes:116]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2022 |  | 8,360 |  |  | $ | 85.83 |  |  | 1.7 |  | $ | 1,014,431 |  |
| RSUs granted |  | 577 |  |  | 132.83 |  |  |  |  |  |
| RSUs vested |  | (733) |  |  | 77.09 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (86) |  |  | 94.48 |  |  |  |  |  |
| Unvested balance—March 31, 2023 |  | 8,118 |  |  | $ | 89.89 |  |  | 1.7 |  | $ | 1,362,671 |  |

[0001596532-23-000104:notes:117]
[same as prior period, unchanged from 0001596532-22-000294:notes:125]

[0001596532-23-000104:notes:118]
[same as prior period, unchanged from 0001596532-22-000294:notes:126]

[0001596532-23-000104:notes:119]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Cost of revenue |  | $ | 2,975 |  |  | $ | 1,309 |  |  |  |  |  |
| Research and development |  | 36,569 |  |  | 27,576 |  |  |  |  |  |
| Sales and marketing |  | 15,138 |  |  | 13,109 |  |  |  |  |  |
| General and administrative |  | 8,199 |  |  | 8,285 |  |  |  |  |  |
| Total stock-based compensation |  | $ | 62,881 |  |  | $ | 50,279 |  |  |  |  |  |

[0001596532-23-000104:notes:120]
As of March 31, 2023, there were $602.9 million of unamortized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 3.2 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-23-000104:notes:121]
[same as prior period, unchanged from 0001596532-22-000294:notes:129]

[0001596532-23-000104:notes:122]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 436,473 |  |  | $ | 272,259 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share, basic |  | 306,985 |  |  | 308,045 |  |  |  |  |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity awards |  | 8,593 |  |  | 11,607 |  |  |  |  |  |
| Weighted-average shares used in computing net income per share, diluted |  | 315,578 |  |  | 319,652 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.42 |  |  | $ | 0.88 |  |  |  |  |  |
| Diluted |  | $ | 1.38 |  |  | $ | 0.85 |  |  |  |  |  |

[0001596532-23-000104:notes:123]
[same as prior period, unchanged from 0001596532-22-000294:notes:132]

[0001596532-23-000104:notes:124]
|  |  | Three Months Ended March 31, |  |  |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |  |  |  |  |
| Stock options and RSUs |  | 21 |  |  | 64 |  |  |  |  |  |  |  |  |  |
| Employee stock purchase plan |  | 353 |  |  | 16 |  |  |  |  |  |  |  |  |  |
| Total |  | 374 |  |  | 80 |  |  |  |  |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-23-000104:notes:125]
[same as prior period, unchanged from 0001596532-22-000294:notes:134]

[0001596532-23-000104:notes:126]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |  |  |  |  |
| Income before income taxes |  | $ | 496,724 |  |  | $ | 309,467 |  |  |  |  |  |  |  |  |  |
| Provision for income taxes |  | 60,251 |  |  | 37,208 |  |  |  |  |  |  |  |  |  |
| Effective tax rate |  | 12.1 | % |  | 12.0 | % |  |  |  |  |  |  |  |  |

[0001596532-23-000104:notes:127]
Our provision for income taxes increased in the three months ended March 31, 2023, as compared to the same period in 2022, due to a corresponding increase in income before taxes, while our effective tax rate remained relatively stable over those same periods.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-23-000104:notes:128]
[same as prior period, unchanged from 0001596532-22-000294:notes:137]

[0001596532-23-000104:notes:129]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Americas(1) |  | $ | 1,115,011 |  |  | $ | 664,377 |  |  |  |  |  |
| Europe, Middle East and Africa |  | 128,316 |  |  | 134,805 |  |  |  |  |  |
| Asia-Pacific |  | 108,024 |  |  | 77,884 |  |  |  |  |  |
| Total revenue |  | $ | 1,351,351 |  |  | $ | 877,066 |  |  |  |  |  |

[0001596532-23-000104:notes:130]
(1) Includes $1.1 billion and  $648.9 million revenue generated from the U.S. for the three months ended March 31, 2023 and March 31, 2022, respectively.

[0001596532-23-000104:notes:131]
[same as prior period, unchanged from 0001596532-22-000294:notes:139]

[0001596532-23-000104:notes:132]
|  |  | March 31, 2023 |  | December 31, 2022 |
| United States |  | $ | 74,239 |  |  | $ | 71,540 |  |
| International |  | 22,918 |  |  | 23,469 |  |
| Total |  | $ | 97,157 |  |  | $ | 95,009 |  |
