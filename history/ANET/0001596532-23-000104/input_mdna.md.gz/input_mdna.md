# ANET MD&A — 0001596532-23-000104


## mdna

[0001596532-23-000104:mdna:1]
[same as prior period, unchanged from 0001596532-22-000294:mdna:1]

[0001596532-23-000104:mdna:2]
[same as prior period, unchanged from 0001596532-22-000294:mdna:2]

[0001596532-23-000104:mdna:3]
Arista Networks is an industry leader in data-driven, cognitive cloud networking for next-generation data center and campus workspace environments. At the core of Arista's platform is our EOS software, combined with a set of network applications and our Ethernet switching and routing products using merchant silicon, delivering a cloud networking solution with high performance scale and availability, and enabling network automation, visibility, and security. This flexible EOS-based platform provides customers with improved price/performance and accelerated time to market.

[0001596532-23-000104:mdna:4]
We generate revenue primarily from sales of our switching and routing platforms, which incorporate our EOS software, and related network applications. We also generate revenue from post-contract support ("PCS"), which end customers typically purchase in conjunction with our products, and renewals of PCS. We sell our products through both our direct sales force and our channel partners. As of December 31, 2022, we had delivered our cloud networking solutions to over 9,000 end customers worldwide. Our end customers span a range of industries and include large internet companies, service providers, financial services organizations, government agencies, media and entertainment companies, telecommunication service providers and other cloud service providers.

[0001596532-23-000104:mdna:5]
Historically, large purchases by a relatively limited number of end customers have accounted for a significant portion of our revenue. We have experienced unpredictability in the timing of orders from these large end customers primarily due to the time it takes these end customers to evaluate, test, qualify and accept our newer products, the overall complexity of these large orders and changes in demand patterns specific to these customers, including reductions in capital expenditures by these customers and the impact of cost reduction and other efficiency efforts by these customers. For example, sales to our end customers Microsoft and Meta Platforms in fiscal 2022 represented 16% and 26% of our total revenue, respectively, whereas sales to our end customer Microsoft in fiscal 2020 and 2021 amounted to 22% and 15% of our total revenue, respectively, with our end customer Meta Platforms representing less than 10% of our total revenue in both fiscal 2020 and 2021. This variability in customer concentration has been linked to the timing of new product deployments and spending cycles with these customers, and we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. In addition, some of our large customers have announced various cost reduction measures, including optimization and increased efficiency in their capital expenditures. In some instances, such measures have had, or may have, an impact on certain current or future projects and have reduced our visibility to customer demand, which may result in reductions in future demand and negatively impact our revenue. Furthermore, we typically provide pricing discounts to large end customers, which reduces gross margins for the period in which such sales occur.

[0001596532-23-000104:mdna:6]
[same as prior period, unchanged from 0001596532-22-000294:mdna:6]

[0001596532-23-000104:mdna:7]
The markets for cloud networking solutions are highly competitive and characterized by rapidly changing technology, changing end-customer needs, evolving industry standards, frequent introductions of new products and services, and industry consolidation. We expect competition to intensify in the future as the market for cloud networking expands and existing competitors and new market entrants introduce new products or enhance existing products. Our future success is dependent upon our ability to continue to evolve and adapt to our rapidly changing environment. We must also continue to develop market-leading products and features that address the needs of our existing and new customers, and increase sales in the enterprise data center switching and campus workspace markets. We intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new end customers more effectively, increase sales to existing customers, and provide services and support. In addition, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our ability to rapidly develop new features and applications.

[0001596532-23-000104:mdna:8]
[same as prior period, unchanged from 0001596532-22-000294:mdna:8]

[0001596532-23-000104:mdna:9]
[same as prior period, unchanged from 0001596532-22-000294:mdna:9]

[0001596532-23-000104:mdna:10]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including inflation, monetary policy shifts, the recent banking crisis, recession risks, and potential supply chain and other disruptions from the Russia-Ukraine conflict and the U.S. trade war with China.

[0001596532-23-000104:mdna:11]
We have continued to work closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. We have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, and have begun to see some reduction in customer lead times on certain products. As customer lead times improve more broadly, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to a somewhat shorter demand-planning horizon. While inventory and working capital levels may continue to increase and remain elevated in the near term, we expect that purchase commitments will continue to decline as supplier lead times begin to shorten.  Although these elevated inventory positions largely relate to early life cycle products, we cannot be certain that we will be able to sell this inventory which may result in excess and obsolete inventory charges in the future.

[0001596532-23-000104:mdna:12]
In addition, inflation pressure in our supply chain, scarcity of some materials needed to build our products and disruptions to our manufacturing process have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. Our operating cash-flows have also been and may continue to be negatively impacted by significant component inventories on hand or at our contract manufacturers. While we have seen some improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the Russia-Ukraine conflict, continued escalation of the conflict may negatively impact the global economy and our future operating results and financial condition.

[0001596532-23-000104:mdna:13]
Management continues to actively monitor the impact of these macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable; however, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that our customers continue to grapple with the impact of these macroeconomic factors on their businesses and future investment plans, resulting in business

[0001596532-23-000104:mdna:14]
uncertainty and a more constrained approach to forecasts and orders.  In addition, any prolonged economic disruptions or further deterioration  in the global economy could have a negative impact on demand from our customers in future periods. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

[0001596532-23-000104:mdna:15]
[same as prior period, unchanged from 0001596532-22-000294:mdna:13]

[0001596532-23-000104:mdna:16]
Three Months Ended March 31, 2023 Compared to Three Months Ended March 31, 2022

[0001596532-23-000104:mdna:17]
[same as prior period, unchanged from 0001596532-22-000294:mdna:15]

[0001596532-23-000104:mdna:18]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2023 |  | 2022 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,172,094 |  |  | $ | 724,718 |  |  | $ | 447,376 |  |  | 61.7 | % |  |  |  |  |  |  |  |  |
| Service |  | 179,257 |  |  | 152,348 |  |  | 26,909 |  |  | 17.7 |  |  |  |  |  |  |  |  |  |
| Total revenue |  | 1,351,351 |  |  | 877,066 |  |  | 474,285 |  |  | 54.1 |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 508,862 |  |  | 293,809 |  |  | 215,053 |  |  | 73.2 |  |  |  |  |  |  |  |  |  |
| Service |  | 37,982 |  |  | 29,412 |  |  | 8,570 |  |  | 29.1 |  |  |  |  |  |  |  |  |  |
| Total cost of revenue |  | 546,844 |  |  | 323,221 |  |  | 223,623 |  |  | 69.2 |  |  |  |  |  |  |  |  |  |
| Gross profit |  | $ | 804,507 |  |  | $ | 553,845 |  |  | $ | 250,662 |  |  | 45.3 | % |  |  |  |  |  |  |  |  |
| Gross margin |  | 59.5 | % |  | 63.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001596532-23-000104:mdna:19]
[same as prior period, unchanged from 0001596532-22-000294:mdna:17]

[0001596532-23-000104:mdna:20]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2023 |  | % of Total |  | 2022 |  | % of Total |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,115,011 |  |  | 82.5 | % |  | $ | 664,377 |  |  | 75.7 | % |  |  |  |  |  |  |  |  |
| Europe, Middle East and Africa |  | 128,316 |  |  | 9.5 |  |  | 134,805 |  |  | 15.4 |  |  |  |  |  |  |  |  |  |
| Asia-Pacific |  | 108,024 |  |  | 8.0 |  |  | 77,884 |  |  | 8.9 |  |  |  |  |  |  |  |  |  |
| Total revenue |  | $ | 1,351,351 |  |  | 100.0 | % |  | $ | 877,066 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |

[0001596532-23-000104:mdna:21]
[same as prior period, unchanged from 0001596532-22-000294:mdna:19]

[0001596532-23-000104:mdna:22]
[same as prior period, unchanged from 0001596532-22-000294:mdna:20]

[0001596532-23-000104:mdna:23]
Product revenue increased $447.4 million, or 61.7%, for the three months ended March 31, 2023 compared to the same period in 2022. The increase reflects strong demand for our switching and routing platforms from across our customer base, in particular healthy contributions from our large cloud customers. In addition, service revenue increased $26.9 million, or 17.7% for the three months ended March 31, 2023, compared to the same period in 2022, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenue represented 17.5% of total revenue for the three months ended March 31, 2023, decreasing from 24.3% for the same period in the prior year, which was primarily driven by increased purchases from large global customers in our Americas region.

[0001596532-23-000104:mdna:24]
[same as prior period, unchanged from 0001596532-22-000294:mdna:22]

[0001596532-23-000104:mdna:25]
[same as prior period, unchanged from 0001596532-22-000294:mdna:23]

[0001596532-23-000104:mdna:26]
Cost of revenue increased by $223.6 million, or 69.2% for the three months ended March 31, 2023 compared to the same period in 2022. These increases were primarily driven by a corresponding increase in product and service revenues,

[0001596532-23-000104:mdna:27]
combined with an increase in provisions for excess/obsolete inventory.

[0001596532-23-000104:mdna:28]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including pricing pressure on our products and services due to competition, the mix of sales to large end customers who generally receive lower pricing, the mix of products sold, manufacturing-related costs, including costs associated with supply chain sourcing activities, merchant silicon costs, and excess/obsolete inventory charges, including charges for excess/obsolete component inventory held by our contract manufacturers. We expect our gross margin to fluctuate over time, depending on the factors described above.

[0001596532-23-000104:mdna:29]
Gross margin decreased from 63.1% to 59.5% for the three months ended March 31, 2023 compared to the same periods in 2022. The decrease was primarily driven by an increased proportion of our sales to large end customers who generally receive higher discounts and an increase in provisions for excess/obsolete inventory, partly offset by the leverage of fixed overhead costs on a higher revenue base. In addition, our gross margins continue to be negatively impacted by significant material and logistics costs.

[0001596532-23-000104:mdna:30]
[same as prior period, unchanged from 0001596532-22-000294:mdna:28]

[0001596532-23-000104:mdna:31]
[same as prior period, unchanged from 0001596532-22-000294:mdna:29]

[0001596532-23-000104:mdna:32]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2023 |  | 2022 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 201,408 |  |  | $ | 172,006 |  |  | $ | 29,402 |  |  | 17.1 | % |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 93,492 |  |  | 80,739 |  |  | 12,753 |  |  | 15.8 |  |  |  |  |  |  |  |  |  |
| General and administrative |  | 25,029 |  |  | 23,113 |  |  | 1,916 |  |  | 8.3 |  |  |  |  |  |  |  |  |  |
| Total operating expenses |  | $ | 319,929 |  |  | $ | 275,858 |  |  | $ | 44,071 |  |  | 16.0 | % |  |  |  |  |  |  |  |  |

[0001596532-23-000104:mdna:33]
[same as prior period, unchanged from 0001596532-22-000294:mdna:31]

[0001596532-23-000104:mdna:34]
[same as prior period, unchanged from 0001596532-22-000294:mdna:32]

[0001596532-23-000104:mdna:35]
Research and development expenses increased $29.4 million, or 17.1% in the three months ended March 31, 2023 compared to the same period in 2022. The increases were primarily driven by an increase in personnel costs of $22.1 million for the three months ended March 31, 2023 compared to the same period in 2022 primarily due to headcount growth. In addition, new product introduction costs increased by $7.0 million for the three months ended March 31, 2023 compared to the same period in 2022.

[0001596532-23-000104:mdna:36]
[same as prior period, unchanged from 0001596532-22-000294:mdna:34]

[0001596532-23-000104:mdna:37]
[same as prior period, unchanged from 0001596532-22-000294:mdna:35]

[0001596532-23-000104:mdna:38]
Sales and marketing expenses increased $12.8 million, or 15.8% for the three months ended March 31, 2023 compared to the same period in 2022, which was primarily caused by increased personnel costs largely driven by headcount growth.

[0001596532-23-000104:mdna:39]
[same as prior period, unchanged from 0001596532-22-000294:mdna:37]

[0001596532-23-000104:mdna:40]
[same as prior period, unchanged from 0001596532-22-000294:mdna:38]

[0001596532-23-000104:mdna:41]
General and administrative expenses increased $1.9 million, or 8.3% in the three months ended March 31, 2023

[0001596532-23-000104:mdna:42]
compared to the same period in 2022.

[0001596532-23-000104:mdna:43]
[same as prior period, unchanged from 0001596532-22-000294:mdna:40]

[0001596532-23-000104:mdna:44]
[same as prior period, unchanged from 0001596532-22-000294:mdna:41]

[0001596532-23-000104:mdna:45]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2023 |  | 2022 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 22,509 |  |  | $ | 2,428 |  |  | $ | 20,081 |  |  | 827.1 | % |  |  |  |  |  |  |  |  |
| Unrealized gain (loss) on equity investments |  | (5,571) |  |  | 28,497 |  |  | (34,068) |  |  | (119.5) |  |  |  |  |  |  |  |  |  |
| Other income (expense), net |  | (4,792) |  |  | 555 |  |  | (5,347) |  |  | (963.4) |  |  |  |  |  |  |  |  |  |
| Total other income (expense), net |  | $ | 12,146 |  |  | $ | 31,480 |  |  | $ | (19,334) |  |  | (61.4) | % |  |  |  |  |  |  |  |  |

[0001596532-23-000104:mdna:46]
The movements in other income (expense), net, were driven by an unrealized loss on equity investments of $5.6 million in the three months ended March 31, 2023 compared to an unrealized gain of $28.5 million in the same period in 2022. This decrease in income was partly offset by an increase in interest income of $20.1 million in the three months ended March 31, 2023 due to higher interest rates.

[0001596532-23-000104:mdna:47]
[same as prior period, unchanged from 0001596532-22-000294:mdna:44]

[0001596532-23-000104:mdna:48]
[same as prior period, unchanged from 0001596532-22-000294:mdna:45]

[0001596532-23-000104:mdna:49]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2023 |  | 2022 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Income before income taxes |  | $ | 496,724 |  |  | $ | 309,467 |  |  | $ | 187,257 |  |  | 60.5 | % |  |  |  |  |  |  |  |  |
| Provision for income taxes |  | 60,251 |  |  | 37,208 |  |  | 23,043 |  |  | 61.9 | % |  |  |  |  |  |  |  |  |
| Effective tax rate |  | 12.1 | % |  | 12.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001596532-23-000104:mdna:50]
Our provision for income taxes increased in the three months ended March 31, 2023, as compared to the same period in 2022, due to a corresponding increase in income before taxes, while our effective tax rate remained relatively stable over those same periods.

[0001596532-23-000104:mdna:51]
[same as prior period, unchanged from 0001596532-22-000294:mdna:48]

[0001596532-23-000104:mdna:52]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of March 31, 2023, our total balance of cash, cash equivalents and marketable securities was approximately $3.3 billion, of which approximately $426.7 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-23-000104:mdna:53]
Our cash, cash equivalents and marketable securities are held for general business purposes, including the funding of working capital. The investment portfolio of our marketable securities is primarily invested in highly-rated securities, with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations, will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and stock repurchases. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If

[0001596532-23-000104:mdna:54]
we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-23-000104:mdna:55]
[same as prior period, unchanged from 0001596532-22-000294:mdna:51]

[0001596532-23-000104:mdna:56]
|  |  | Three Months Ended March 31, |
|  |  | 2023 |  | 2022 |
| Cash provided by operating activities |  | $ | 374,483 |  |  | $ | 217,138 |  |
| Cash used in investing activities |  | (21,747) |  |  | (72,615) |  |
| Cash used in financing activities |  | (68,403) |  |  | (129,809) |  |
| Effect of exchange rate changes |  | 314 |  |  | (481) |  |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 284,647 |  |  | $ | 14,233 |  |

[0001596532-23-000104:mdna:57]
[same as prior period, unchanged from 0001596532-22-000294:mdna:53]

[0001596532-23-000104:mdna:58]
During the three months ended March 31, 2023, cash provided by operating activities was $374.5 million, primarily from net income of $436.5 million and non-cash adjustments to net income of $18.6 million driven by stock-based compensation and depreciation and amortization, largely offset by an increase in deferred taxes associated with the capitalization of research and development costs under IRC Section 174. These increases were partly offset by a net increase of $80.6 million in working capital requirements, which primarily consisted of a $393.0 million increase in inventory and an $81.9 million increase in inventory deposits to our contract manufacturers in response to a significant increase in business volume and increased product lead times.  These operating cash outflows were largely offset by cash inflows from a $153.2 million increase in accounts payable and accrued liabilities and a $108.2 million increase in income tax payables related to significant business volume and timing of payments. In addition, we had cash inflows resulting from a decrease in accounts receivable of $60.2 million driven by strong collections, and an increase in deferred revenue of $51.0 million primarily resulting from an increase in customer PCS contracts.

[0001596532-23-000104:mdna:59]
During the three months ended March 31, 2022, cash provided by operating activities was $217.1 million, primarily from net income of $272.3 million, reduced by non-cash adjustments to net income of $35.4 million, and a net increase of $19.7 million in working capital requirements. Cash outflows from the increase in working capital requirements primarily consisted of a $131.9 million increase in accounts receivables due to increased product and service billings, a $108.0 million increase in prepaid and other current assets primarily driven by increased inventory deposits to our contract manufacturers and product deferred cost of sales driven by higher product revenue deferrals, and a $43.5 million increase in inventory to help mitigate the impact of supply chain disruptions. These operating cash outflows were largely offset by a $187.2 million increase in deferred revenue reflecting ongoing growth from PCS contracts, and increased product deferred revenue related to contracts with acceptance terms, and a $107.0 million increase in income taxes payable due to timing of payments, the impact of IRC Section 174 and an increase in pre-tax income.

[0001596532-23-000104:mdna:60]
[same as prior period, unchanged from 0001596532-22-000294:mdna:56]

[0001596532-23-000104:mdna:61]
During the three months ended March 31, 2023, cash used in investing activities was $21.7 million, consisting of  purchases of available-for-sale securities of $861.6 million, and purchases of property and equipment of $5.6 million. These amounts were partially offset by proceeds from maturities and sales of marketable securities of $845.7 million.

[0001596532-23-000104:mdna:62]
During the three months ended March 31, 2022, cash used in investing activities was $72.6 million, primarily consisting of purchases of available-for-sale securities of $412.6 million, a business acquisition of $37.6 million, purchases of non-marketable equity investments of $11.7 million, and purchases of property and equipment of $14.9 million, partially offset by proceeds from maturities of marketable securities of $404.2 million.

[0001596532-23-000104:mdna:63]
[same as prior period, unchanged from 0001596532-22-000294:mdna:59]

[0001596532-23-000104:mdna:64]
During the three months ended March 31, 2023, cash used in financing activities was $68.4 million, consisting of payments for repurchases of our common stock from the open market of $82.3 million, and employee taxes withheld and paid of $9.2 million upon vesting of restricted stock units, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $23.1 million.

[0001596532-23-000104:mdna:65]
During the three months ended March 31, 2022, cash used in financing activities was $129.8 million, primarily consisting of payments for repurchases of our common stock from the open market of $136.2 million, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $19.2 million.

[0001596532-23-000104:mdna:66]
[same as prior period, unchanged from 0001596532-22-000294:mdna:62]

[0001596532-23-000104:mdna:67]
Our board of directors has authorized a $1.0 billion stock repurchase program (the “Repurchase Program”). This authorization allows us to repurchase shares of our common stock that will be funded from working capital and expires in the fourth quarter of 2024. The Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the company at any time without prior notice.  During the three months ended March 31, 2023, we repurchased a total of $82.3 million of our common stock. As of March 31, 2023, the remaining authorized amount for repurchases under the Repurchase Program was $174.5 million. Refer to Note 6. Stockholders' Equity and Stock-Based Compensation of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of the Quarterly Report on Form 10-Q for further discussion.

[0001596532-23-000104:mdna:68]
[same as prior period, unchanged from 0001596532-22-000294:mdna:64]

[0001596532-23-000104:mdna:69]
[same as prior period, unchanged from 0001596532-22-000294:mdna:65]

[0001596532-23-000104:mdna:70]
[same as prior period, unchanged from 0001596532-22-000294:mdna:66]

[0001596532-23-000104:mdna:71]
[same as prior period, unchanged from 0001596532-22-000294:mdna:67]

[0001596532-23-000104:mdna:72]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of March 31, 2023, we had lease payment obligations, net of immaterial sublease income, of $81.2 million, with $21.6 million payable within one year.

[0001596532-23-000104:mdna:73]
[same as prior period, unchanged from 0001596532-22-000294:mdna:69]

[0001596532-23-000104:mdna:74]
Purchase obligations represent an estimate of all non-cancellable open purchase orders and contractual obligations, made either directly by Arista or by our contract manufacturers on our behalf, in the ordinary course of business for which we have not received the goods or services. As of March 31, 2023, we had $2.9 billion of such purchase obligations, of which $2.4 billion are expected to be received within one year, and $0.5 billion are expected to be received after one year.  These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-23-000104:mdna:75]
[same as prior period, unchanged from 0001596532-22-000294:mdna:71]

[0001596532-23-000104:mdna:76]
As of March 31, 2023, we have recorded long-term tax liabilities of $90.8 million related to uncertain tax positions; however, we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-23-000104:mdna:77]
In connection with the Tax Cuts and Jobs Act of 2017 (“TCJA”), effective from January 1st 2022, the TCJA eliminates the option to deduct research and development expenditures currently and requires taxpayers to capitalize and amortize them over five or fifteen years pursuant to IRC Section 174. We estimate the incremental cash tax impact resulting from these regulations to be approximately $190.0 million for 2023. No material change to our effective tax rate has resulted from this new legislation.

[0001596532-23-000104:mdna:78]
[same as prior period, unchanged from 0001596532-22-000294:mdna:75]

[0001596532-23-000104:mdna:79]
As of March 31, 2023, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-23-000104:mdna:80]
[same as prior period, unchanged from 0001596532-22-000294:mdna:77]

[0001596532-23-000104:mdna:81]
Our management’s discussion and analysis of financial condition and results of operations are based on our unaudited condensed consolidated financial statements, which have been prepared in accordance with GAAP.  The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. We believe the critical accounting estimates in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our Annual Report on Form 10-K filed with the SEC on February 14, 2023 reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as disclosed in our Annual Report on Form 10-K.

[0001596532-23-000104:mdna:82]
[same as prior period, unchanged from 0001596532-22-000294:mdna:79]

[0001596532-23-000104:mdna:83]
Refer to the subheading titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
