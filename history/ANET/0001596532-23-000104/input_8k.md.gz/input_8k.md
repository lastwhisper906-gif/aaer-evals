# ANET 8-K — 0001596532-23-000101 filed 2023-05-01

## item codes, every 8-K on or before 2023-05-02

- 2023-05-01 0001596532-23-000101 — 2.02, 9.01
- 2023-02-13 0001596532-23-000015 — 2.02, 9.01
- 2022-10-31 0001596532-22-000292 — 2.02, 9.01
- 2022-10-25 0001596532-22-000282 — 5.03, 9.01
- 2022-08-01 0001596532-22-000218 — 2.02, 9.01
- 2022-07-25 0001596532-22-000205 — 5.02
- 2022-06-03 0001596532-22-000179 — 5.07
- 2022-05-02 0001596532-22-000111 — 2.02, 9.01
- 2022-03-29 0001596532-22-000100 — 5.02
- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2023-05-02

- none on or before 2023-05-02

## item 2.02 — earnings release, exhibit 99.1

[0001596532-23-000101:8k_2_02:1]
EX-99.1
2
ex991q123-earningsrelease.htm
EX-99.1

[0001596532-23-000101:8k_2_02:2]
Document

[0001596532-23-000101:8k_2_02:3]
Exhibit 99.1

[0001596532-23-000101:8k_2_02:4]
Arista Networks, Inc. Reports First Quarter 2023 Financial Results

[0001596532-23-000101:8k_2_02:5]
SANTA CLARA, Calif.- May 1, 2023 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments, today announced financial results for its first quarter ended March 31, 2023.

[0001596532-23-000101:8k_2_02:6]
“Amid macroeconomic uncertainty and a gradually recovering supply chain, Arista continues to bring innovative, leading-edge platforms to market, while delivering superior customer and financial outcomes,” said Jayshree Ullal, President and CEO of Arista Networks. “Our Q1 results illustrate this with continued growth in revenue and profits.”

[0001596532-23-000101:8k_2_02:7]
First Quarter Financial Highlights

[0001596532-23-000101:8k_2_02:8]
•Revenue of $1.351 billion, an increase of 5.9% compared to the fourth quarter of 2022, and an increase of 54.1% from the first quarter of 2022.

[0001596532-23-000101:8k_2_02:9]
•GAAP gross margin of 59.5%, compared to GAAP gross margin of 60.3% in the fourth quarter of 2022 and 63.1% in the first quarter of 2022.

[0001596532-23-000101:8k_2_02:10]
•Non-GAAP gross margin of 60.3%, compared to non-GAAP gross margin of 61.0% in the fourth quarter of 2022 and 63.9% in the first quarter of 2022.

[0001596532-23-000101:8k_2_02:11]
•GAAP net income of $436.5 million, or $1.38 per diluted share, compared to GAAP net income of $272.3 million, or $0.85 per diluted share in the first quarter of 2022.

[0001596532-23-000101:8k_2_02:12]
•Non-GAAP net income of $452.5 million, or $1.43 per diluted share, compared to non-GAAP net income of $268.5 million, or $0.84 per diluted share in the first quarter of 2022.

[0001596532-23-000101:8k_2_02:13]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO said, “We are pleased with the continued strong revenue growth in the quarter, and with the team's focus on improving broader financial metrics as we move through the year."

[0001596532-23-000101:8k_2_02:14]
Company Highlights

[0001596532-23-000101:8k_2_02:15]
•Arista Showcases Next Generation Systems and Optics for Cloud, Internet Service Provider, and Enterprise Networks - Arista announced its range of products, and solutions along with perspectives on the petascale era of cloud networking and the systems and optics required to meet the demands of new AI/ML-driven network architectures.

[0001596532-23-000101:8k_2_02:16]
•Arista Modernizes Routing in the Wide Area Network - Arista introduced the Arista WAN Routing System, which combines three new networking offerings: enterprise-class routing platforms, carrier/cloud-neutral internet transit capabilities, and the CloudVision®Pathfinder Service to simplify and improve customer wide area networks.

[0001596532-23-000101:8k_2_02:17]
•The Arrival of AI Networking at Petascale - With Arista AI platforms, we continue to deliver the best combination of Ethernet versatility and IP protocol capabilities at petascale with a congestion free, lossless fabric for our customers' AI strategies.

[0001596532-23-000101:8k_2_02:18]
Financial Outlook

[0001596532-23-000101:8k_2_02:19]
For the second quarter of 2023, we expect:

[0001596532-23-000101:8k_2_02:20]
•Revenue between $1.350 billion to $1.400 billion

[0001596532-23-000101:8k_2_02:21]
•Non-GAAP gross margin of approximately 61%; and

[0001596532-23-000101:8k_2_02:22]
•Non-GAAP operating margin of approximately 40%

[0001596532-23-000101:8k_2_02:23]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and potential non-recurring charges or benefits. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis because these exclusions can be uncertain or difficult to predict, including stock-based compensation expense which is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock. The actual amount of these exclusions will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-23-000101:8k_2_02:24]
Prepared Materials and Conference Call Information

[0001596532-23-000101:8k_2_02:25]
Arista's executives will discuss the first quarter 2023 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-23-000101:8k_2_02:26]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-23-000101:8k_2_02:27]
Forward-Looking Statements

[0001596532-23-000101:8k_2_02:28]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the second quarter of 2023 and statements regarding the benefits of Arista's products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: dependence on a limited number of customers who represent a substantial portion of our revenue; adverse global economic and geopolitical conditions, including inflationary pressures which result in increased component costs and reduced information technology and network infrastructure spending, the Russia/Ukraine conflict; interruptions or delays in shipments; the impact of supply shortages and manufacturing disruptions on our business including significant purchase commitments, excess inventory and extended lead times; the rapid evolution of the networking market; any failure to successfully pursue new products and service offerings and expand into adjacent markets; a decline in our revenue growth rate; fluctuations in our results of operations including as a result of seasonality; variability in our gross margins including as a result of changes in customer mix or product mix; intense competition; expansion of our international sales and operations; investments in or acquisitions of other businesses; fluctuations in currency exchange rates; any failure to raise any needed capital; our ability to attract new large end customers or sell products and services to existing end customers and dependence on large end customers; our ability to increase market awareness of our company and new products and services; a decline in the sales prices of our products and services; a decline in maintenance renewals by customers; product quality problems; our ability to anticipate technological shifts and develop products to meet those technological shifts; the management of the supply of our products and product components; our dependence on third-party manufacturers to build our products; our ability to protect, defend and maintain our intellectual property rights; vulnerabilities in our products and failure of our products to detect security breaches; tax, tariff, import/export restrictions or other trade barriers; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-23-000101:8k_2_02:29]
2

[0001596532-23-000101:8k_2_02:30]
Non-GAAP Financial Measures

[0001596532-23-000101:8k_2_02:31]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangible assets, unrealized gains/losses on equity investments, certain non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-23-000101:8k_2_02:32]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-23-000101:8k_2_02:33]
About Arista Networks

[0001596532-23-000101:8k_2_02:34]
Arista Networks is an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments. Arista’s award-winning platforms deliver availability, agility, automation, analytics and security through an advanced network operating stack. For more information, visit www.arista.com.

[0001596532-23-000101:8k_2_02:35]
ARISTA and CloudVision, are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-23-000101:8k_2_02:36]
Investor Contacts:

[0001596532-23-000101:8k_2_02:37]
Arista Networks, Inc.

[0001596532-23-000101:8k_2_02:38]
Liz Stine, 408-547-5885

[0001596532-23-000101:8k_2_02:39]
Investor Relations

[0001596532-23-000101:8k_2_02:40]
liz@arista.com

[0001596532-23-000101:8k_2_02:41]
ARISTA NETWORKS, INC.

[0001596532-23-000101:8k_2_02:42]
Condensed Consolidated Income Statements

[0001596532-23-000101:8k_2_02:43]
(Unaudited, in thousands, except per share amounts)

[0001596532-23-000101:8k_2_02:44]
|  |  | Three Months Ended March 31, 2023 |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,172,094 |  |  | $ | 724,718 |  |  |  |  |  |
| Service |  | 179,257 |  |  | 152,348 |  |  |  |  |  |
| Total revenue |  | 1,351,351 |  |  | 877,066 |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 508,862 |  |  | 293,809 |  |  |  |  |  |
| Service |  | 37,982 |  |  | 29,412 |  |  |  |  |  |
| Total cost of revenue |  | 546,844 |  |  | 323,221 |  |  |  |  |  |
| Gross profit |  | 804,507 |  |  | 553,845 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 201,408 |  |  | 172,006 |  |  |  |  |  |
| Sales and marketing |  | 93,492 |  |  | 80,739 |  |  |  |  |  |
| General and administrative |  | 25,029 |  |  | 23,113 |  |  |  |  |  |
| Total operating expenses |  | 319,929 |  |  | 275,858 |  |  |  |  |  |
| Income from operations |  | 484,578 |  |  | 277,987 |  |  |  |  |  |
| Other income, net |  | 12,146 |  |  | 31,480 |  |  |  |  |  |
| Income before income taxes |  | 496,724 |  |  | 309,467 |  |  |  |  |  |
| Provision for income taxes |  | 60,251 |  |  | 37,208 |  |  |  |  |  |
| Net income |  | $ | 436,473 |  |  | $ | 272,259 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.42 |  |  | $ | 0.88 |  |  |  |  |  |
| Diluted |  | $ | 1.38 |  |  | $ | 0.85 |  |  |  |  |  |
| Weighted-average shares used in computing net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 306,985 |  |  | 308,045 |  |  |  |  |  |
| Diluted |  | 315,578 |  |  | 319,652 |  |  |  |  |  |

[0001596532-23-000101:8k_2_02:45]
4

[0001596532-23-000101:8k_2_02:46]
ARISTA NETWORKS, INC.

[0001596532-23-000101:8k_2_02:47]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-23-000101:8k_2_02:48]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-23-000101:8k_2_02:49]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| GAAP gross profit |  | $ | 804,507 |  |  | $ | 553,845 |  |  |  |  |  |
| GAAP gross margin |  | 59.5 | % |  | 63.1 | % |  |  |  |  |
| Stock-based compensation expense |  | 2,975 |  |  | 1,309 |  |  |  |  |  |
| Intangible asset amortization |  | 6,820 |  |  | 5,721 |  |  |  |  |  |
| Non-GAAP gross profit |  | $ | 814,302 |  |  | $ | 560,875 |  |  |  |  |  |
| Non-GAAP gross margin |  | 60.3 | % |  | 63.9 | % |  |  |  |  |
| GAAP income from operations |  | $ | 484,578 |  |  | $ | 277,987 |  |  |  |  |  |
| Stock-based compensation expense |  | 62,881 |  |  | 50,279 |  |  |  |  |  |
| Intangible asset amortization |  | 9,315 |  |  | 7,311 |  |  |  |  |  |
| Non-GAAP income from operations |  | $ | 556,774 |  |  | $ | 335,577 |  |  |  |  |  |
| Non-GAAP operating margin |  | 41.2 | % |  | 38.3 | % |  |  |  |  |
| GAAP net income |  | $ | 436,473 |  |  | $ | 272,259 |  |  |  |  |  |
| Stock-based compensation expense |  | 62,881 |  |  | 50,279 |  |  |  |  |  |
| Intangible asset amortization |  | 9,315 |  |  | 7,311 |  |  |  |  |  |
| Unrealized loss (gain) on equity investments |  | 5,571 |  |  | (28,497) |  |  |  |  |  |
| Tax benefit on stock-based awards |  | (50,062) |  |  | (30,964) |  |  |  |  |  |
| Income tax effect on non-GAAP exclusions |  | (11,716) |  |  | (1,880) |  |  |  |  |  |
| Non-GAAP net income |  | $ | 452,462 |  |  | $ | 268,508 |  |  |  |  |  |
| GAAP diluted net income per share |  | $ | 1.38 |  |  | $ | 0.85 |  |  |  |  |  |
| Non-GAAP adjustments to net income |  | 0.05 |  |  | (0.01) |  |  |  |  |  |
| Non-GAAP diluted net income per share |  | $ | 1.43 |  |  | $ | 0.84 |  |  |  |  |  |
| Weighted-average shares used in computing diluted net income per share |  | 315,578 |  |  | 319,652 |  |  |  |  |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 2,975 |  |  | $ | 1,309 |  |  |  |  |  |
| Research and development |  | 36,569 |  |  | 27,576 |  |  |  |  |  |
| Sales and marketing |  | 15,138 |  |  | 13,109 |  |  |  |  |  |
| General and administrative |  | 8,199 |  |  | 8,285 |  |  |  |  |  |
| Total |  | $ | 62,881 |  |  | $ | 50,279 |  |  |  |  |  |

[0001596532-23-000101:8k_2_02:50]
ARISTA NETWORKS, INC.

[0001596532-23-000101:8k_2_02:51]
Condensed Consolidated Balance Sheets

[0001596532-23-000101:8k_2_02:52]
(Unaudited, in thousands)

[0001596532-23-000101:8k_2_02:53]
|  |  | March 31, 2023 |  | December 31, 2022 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 956,341 |  |  | $ | 671,707 |  |
| Marketable securities |  | 2,374,789 |  |  | 2,352,022 |  |
| Accounts receivable |  | 862,875 |  |  | 923,096 |  |
| Inventories |  | 1,682,703 |  |  | 1,289,706 |  |
| Prepaid expenses and other current assets |  | 393,825 |  |  | 314,217 |  |
| Total current assets |  | 6,270,533 |  |  | 5,550,748 |  |
| Property and equipment, net |  | 97,157 |  |  | 95,009 |  |
| Acquisition-related intangible assets, net |  | 112,890 |  |  | 122,205 |  |
| Goodwill |  | 265,924 |  |  | 265,924 |  |
| Investments |  | 39,401 |  |  | 39,468 |  |
| Operating lease right-of-use assets |  | 64,003 |  |  | 53,390 |  |
| Deferred tax assets |  | 646,066 |  |  | 574,912 |  |
| Other assets |  | 47,092 |  |  | 73,754 |  |
| TOTAL ASSETS |  | $ | 7,543,066 |  |  | $ | 6,775,410 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 330,171 |  |  | $ | 232,572 |  |
| Accrued liabilities |  | 351,764 |  |  | 292,487 |  |
| Deferred revenue |  | 671,700 |  |  | 637,432 |  |
| Other current liabilities |  | 231,274 |  |  | 131,040 |  |
| Total current liabilities |  | 1,584,909 |  |  | 1,293,531 |  |
| Income taxes payable |  | 94,733 |  |  | 89,839 |  |
| Operating lease liabilities, non-current |  | 55,291 |  |  | 43,964 |  |
| Deferred revenue, non-current |  | 420,574 |  |  | 403,814 |  |
| Other long-term liabilities |  | 58,385 |  |  | 58,442 |  |
| TOTAL LIABILITIES |  | 2,213,892 |  |  | 1,889,590 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 31 |  |  | 31 |  |
| Additional paid-in capital |  | 1,857,467 |  |  | 1,780,714 |  |
| Retained earnings |  | 3,493,181 |  |  | 3,138,983 |  |
| Accumulated other comprehensive income (loss) |  | (21,505) |  |  | (33,908) |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 5,329,174 |  |  | 4,885,820 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 7,543,066 |  |  | $ | 6,775,410 |  |

[0001596532-23-000101:8k_2_02:54]
6

[0001596532-23-000101:8k_2_02:55]
ARISTA NETWORKS, INC.

[0001596532-23-000101:8k_2_02:56]
Condensed Consolidated Statements of Cash Flows

[0001596532-23-000101:8k_2_02:57]
(Unaudited, in thousands)

[0001596532-23-000101:8k_2_02:58]
|  |  | Three Months Ended March 31, |
|  |  | 2023 |  | 2022 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 436,473 |  |  | $ | 272,259 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 20,905 |  |  | 13,091 |  |
| Stock-based compensation |  | 62,881 |  |  | 50,279 |  |
| Noncash lease expense |  | 4,633 |  |  | 4,532 |  |
| Deferred income taxes |  | (71,153) |  |  | (81,822) |  |
| Unrealized loss (gain) on equity investments |  | 5,571 |  |  | (28,497) |  |
| Amortization (accretion) of investment premiums (discounts) |  | (4,220) |  |  | 7,033 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | 60,221 |  |  | (131,861) |  |
| Inventories |  | (392,997) |  |  | (43,531) |  |
| Prepaid expenses and other current assets |  | (82,278) |  |  | (107,999) |  |
| Other assets |  | 26,361 |  |  | (640) |  |
| Accounts payable |  | 94,564 |  |  | 2,478 |  |
| Accrued liabilities |  | 58,655 |  |  | (29,666) |  |
| Deferred revenue |  | 51,028 |  |  | 187,194 |  |
| Income taxes, net |  | 108,200 |  |  | 106,992 |  |
| Other liabilities |  | (4,361) |  |  | (2,704) |  |
| Net cash provided by operating activities |  | 374,483 |  |  | 217,138 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 824,021 |  |  | 404,176 |  |
| Proceeds from sale of marketable securities |  | 21,725 |  |  | — |  |
| Purchases of marketable securities |  | (861,612) |  |  | (412,614) |  |
| Purchases of property and equipment |  | (5,631) |  |  | (14,876) |  |
| Business acquisitions, net of cash acquired |  | — |  |  | (37,610) |  |
| Investments and notes receivable in privately-held companies |  | (250) |  |  | (11,691) |  |
| Net cash used in investing activities |  | (21,747) |  |  | (72,615) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 23,096 |  |  | 19,160 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (9,224) |  |  | (12,741) |  |
| Repurchases of common stock |  | (82,275) |  |  | (136,228) |  |
| Net cash used in financing activities |  | (68,403) |  |  | (129,809) |  |
| Effect of exchange rate changes |  | 314 |  |  | (481) |  |
| NET INCREASE IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 284,647 |  |  | 14,233 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 675,978 |  |  | 625,050 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 960,625 |  |  | $ | 639,283 |  |
