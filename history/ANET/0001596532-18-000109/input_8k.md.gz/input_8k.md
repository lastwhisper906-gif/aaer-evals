# ANET 8-K — 0001596532-18-000101 filed 2018-05-03

## item codes, every 8-K on or before 2018-05-04

- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2018-05-04

- none on or before 2018-05-04

## item 2.02 — earnings release, exhibit 99.1

[0001596532-18-000101:8k_2_02:1]
EX-99.1
2
ex991q118-earningsrelease.htm
EXHIBIT 99.1

[0001596532-18-000101:8k_2_02:2]
Exhibit

[0001596532-18-000101:8k_2_02:3]
Exhibit 99.1

[0001596532-18-000101:8k_2_02:4]
Arista Networks, Inc. Reports First Quarter 2018 Financial Results

[0001596532-18-000101:8k_2_02:5]
Cloud Networking Adoption Continues with Record Revenue

[0001596532-18-000101:8k_2_02:6]
SANTA CLARA, Calif.-- May 3, 2018 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large datacenter and computing environments, today announced financial results for its first quarter ended March 31, 2018.

[0001596532-18-000101:8k_2_02:7]
First Quarter Financial Highlights

[0001596532-18-000101:8k_2_02:8]
| • | Revenue of $472.5 million, an increase of 1.0% compared to the fourth quarter of 2017, and an increase of 40.8% from the first quarter of 2017. |

[0001596532-18-000101:8k_2_02:9]
| • | GAAP gross margin of 64.1%, compared to GAAP gross margin of 65.7% in the fourth quarter of 2017 and 63.9% in the first quarter of 2017. |

[0001596532-18-000101:8k_2_02:10]
| • | Non-GAAP gross margin of 64.4%, compared to non-GAAP gross margin of 65.9% in the fourth quarter of 2017 and 64.2% in the first quarter of 2017. |

[0001596532-18-000101:8k_2_02:11]
| • | GAAP net income of $144.5 million, or $1.79 per diluted share, compared to GAAP net income of $83.0 million, or $1.07 per diluted share, in the first quarter of 2017. |

[0001596532-18-000101:8k_2_02:12]
| • | Non-GAAP net income of $134.1 million, or $1.66 per diluted share, compared to non-GAAP net income of $71.8 million, or $0.93 per diluted share, in the first quarter of 2017. |

[0001596532-18-000101:8k_2_02:13]
“As we kick off 2018, I am pleased with our performance this quarter.” stated Jayshree Ullal, Arista President and CEO. “We continue to experience meaningful relevance and expansion as customers shift to cloud networking.”

[0001596532-18-000101:8k_2_02:14]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, “We are pleased with the strength of the business in the first quarter, driving healthy year over year revenue and earnings growth.”

[0001596532-18-000101:8k_2_02:15]
Company Highlights

[0001596532-18-000101:8k_2_02:16]
| • | Arista Networks announced an expanded family of platforms delivering 10x performance for switching and routing. The new generation of 25G and 100G systems add new capabilities for visibility, load balancing, network segmentation, scale and allow both Cloud and Enterprise customers to easily migrate their networks, retaining operational consistency. |

[0001596532-18-000101:8k_2_02:17]
| • | Arista Networks recognized as a leader with the top score in the current offering and strategy categories in The Forrester WaveTM: Hardware Platforms for Software-Defined Networking, Q1 2018. |

[0001596532-18-000101:8k_2_02:18]
| • | San Francisco Business Times and Silicon Valley Business Journal published “The Bay Area Best Places To Work”. 130 companies have been selected for the Top Workplaces award and Arista Ranked in the Top 10 of the Large Companies Category. |

[0001596532-18-000101:8k_2_02:19]
Financial Outlook

[0001596532-18-000101:8k_2_02:20]
For the second quarter of 2018, we expect:

[0001596532-18-000101:8k_2_02:21]
| • | Revenue between $500 and $514 million, |

[0001596532-18-000101:8k_2_02:22]
| • | Non-GAAP gross margin between 62% to 64%, and |

[0001596532-18-000101:8k_2_02:23]
| • | Non-GAAP operating margin of approximately 32% to 34%. |

[0001596532-18-000101:8k_2_02:24]
Guidance for non-GAAP financial measures excludes estimated legal expenses of approximately $6 million associated with the OptumSoft and Cisco litigation, stock-based compensation expense, and other non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below).

[0001596532-18-000101:8k_2_02:25]
Prepared Materials and Conference Call Information

[0001596532-18-000101:8k_2_02:26]
Arista executives will discuss first quarter 2018 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (833) 287-7905 in the United States or (647) 689-4469 from outside the US. The Conference ID is 6899956.

[0001596532-18-000101:8k_2_02:27]
The financial results conference call will also be available via live webcast on our investor relations website at http://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s Investor Relations website.

[0001596532-18-000101:8k_2_02:28]
Forward-Looking Statements

[0001596532-18-000101:8k_2_02:29]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the second quarter of fiscal 2018, and statements regarding the benefits from the introduction of new products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: Arista Networks’ dispute with Cisco Systems, Inc. including the ITC remedial orders which prohibit the importation of Arista products (or components thereof) into the U.S., or the sale of previously imported products  that are covered by those remedial orders, Arista Networks’ ability to redesign its products in a manner not covered by such remedial orders and obtain appropriate governmental approvals for those redesigned products, any penalties assessed by the ITC if Arista’s redesigned products are covered by such remedial orders and Arista Networks’ ability to manage our manufacturing and supply chain including the sourcing of components on commercially reasonable terms; Arista Networks’ limited operating history; Arista Networks’ rapid growth; Arista Networks’ customer concentration;  our customer’s adoption of our redesigned products and services; requests for more favorable terms and conditions from our large end customers; declines in the sales prices of our products and services; changes in customer demand for our products and services, customer order patterns or customer mix; the timing of orders and manufacturing and customer lead times; increased competition in our products and service markets; dependence on the introduction and market acceptance of new product offerings and standards; rapid technological and market change; the evolution of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; Arista Networks’ dispute with OptumSoft; and general market, political, economic and business conditions. Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s most recent Annual Report on Form 10-K filed with the SEC on February 20, 2018, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at http://investors.arista.com/and on the SEC’s website at http://www.sec.gov/.  All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-18-000101:8k_2_02:30]
Non-GAAP Financial Measures

[0001596532-18-000101:8k_2_02:31]
The company reports certain non-GAAP financial measures that exclude stock-based compensation expense and related excess tax benefits, expenses associated with the OptumSoft and Cisco litigation, other non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures

[0001596532-18-000101:8k_2_02:32]
is useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-18-000101:8k_2_02:33]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP net income, net income per diluted share, gross margin, or operating margin. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-18-000101:8k_2_02:34]
The Company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, expenses associated with the OptumSoft and Cisco litigation, and other non-recurring items. The Company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. Stock-based compensation expense is impacted by the Company’s future hiring and retention needs and the future fair market value of the Company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the Company’s GAAP gross margin and GAAP operating margin. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measure is not available without unreasonable effort.

[0001596532-18-000101:8k_2_02:35]
About Arista Networks

[0001596532-18-000101:8k_2_02:36]
Arista Networks was founded to pioneer and deliver software-driven cloud networking solutions for large datacenter storage and computing environments. Arista’s award-winning platforms, ranging in Ethernet speeds from 10 to 100 gigabits per second, redefine scalability, agility and resilience. Arista has shipped more than fifteen million cloud networking ports worldwide with CloudVision and EOS, an advanced network operating system. Committed to open standards, Arista is a founding member of the 25/50GbE consortium. Arista Networks products are available worldwide directly and through partners.

[0001596532-18-000101:8k_2_02:37]
ARISTA, EOS, CloudVision, Flexroute and AlgoMatch are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-18-000101:8k_2_02:38]
Additional information and resources can be found at: http://www.arista.com/.

[0001596532-18-000101:8k_2_02:39]
| Investor Contacts: |
| Charles YagerProduct and Investor Advocacy(408) 547-5892cyager@arista.com |  | Chuck ElliottBusiness and Investor Development(408) 547-5549chuck@arista.com |

[0001596532-18-000101:8k_2_02:40]
ARISTA NETWORKS, INC.

[0001596532-18-000101:8k_2_02:41]
Condensed Consolidated Statements of Income

[0001596532-18-000101:8k_2_02:42]
(Unaudited in thousands, except per share amounts)

[0001596532-18-000101:8k_2_02:43]
|  |  | Three Months Ended March 31, |
|  |  | 2018 |  | 2017 |
| Revenue: |  |  |  |  |
| Product |  | $ | 407,617 |  |  | $ | 291,367 |  |
| Service |  | 64,872 |  |  | 44,108 |  |
| Total revenue |  | 472,489 |  |  | 335,475 |  |
| Cost of revenue: |  |  |  |  |
| Product |  | 156,691 |  |  | 109,836 |  |
| Service |  | 12,879 |  |  | 11,429 |  |
| Total cost of revenue |  | 169,570 |  |  | 121,265 |  |
| Total gross profit |  | 302,919 |  |  | 214,210 |  |
| Operating expenses: |  |  |  |  |
| Research and development |  | 102,362 |  |  | 81,610 |  |
| Sales and marketing |  | 42,140 |  |  | 37,027 |  |
| General and administrative |  | 19,679 |  |  | 22,155 |  |
| Total operating expenses |  | 164,181 |  |  | 140,792 |  |
| Income from operations |  | 138,738 |  |  | 73,418 |  |
| Other income (expense), net: |  |  |  |  |
| Interest expense |  | (687 | ) |  | (715 | ) |
| Other income (expense), net |  | 4,843 |  |  | 1,025 |  |
| Total other income (expense), net |  | 4,156 |  |  | 310 |  |
| Income before benefit from income taxes |  | 142,894 |  |  | 73,728 |  |
| Benefit from income taxes |  | (1,644 | ) |  | (9,233 | ) |
| Net income |  | $ | 144,538 |  |  | $ | 82,961 |  |
| Net income attributable to common stockholders: |  |  |  |  |
| Basic |  | $ | 144,449 |  |  | $ | 82,694 |  |
| Diluted |  | $ | 144,456 |  |  | $ | 82,716 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |
| Basic |  | $ | 1.95 |  |  | $ | 1.16 |  |
| Diluted |  | $ | 1.79 |  |  | $ | 1.07 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |
| Basic |  | 73,994 |  |  | 71,114 |  |
| Diluted |  | 80,721 |  |  | 77,516 |  |

[0001596532-18-000101:8k_2_02:44]
4

[0001596532-18-000101:8k_2_02:45]
ARISTA NETWORKS, INC.

[0001596532-18-000101:8k_2_02:46]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-18-000101:8k_2_02:47]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-18-000101:8k_2_02:48]
|  |  | Three Months Ended March 31, |
|  |  | 2018 |  | 2017 |
| GAAP gross profit |  | $ | 302,919 |  |  | $ | 214,210 |  |
| GAAP gross margin |  | 64.1 | % |  | 63.9 | % |
| Stock-based compensation expense |  | 1,202 |  |  | 1,024 |  |
| Non-GAAP gross profit |  | $ | 304,121 |  |  | $ | 215,234 |  |
| Non-GAAP gross margin |  | 64.4 | % |  | 64.2 | % |
| GAAP income from operations |  | $ | 138,738 |  |  | $ | 73,418 |  |
| Stock-based compensation expense |  | 20,851 |  |  | 16,439 |  |
| Litigation expense |  | 7,085 |  |  | 11,466 |  |
| Non-GAAP income from operations |  | $ | 166,674 |  |  | $ | 101,323 |  |
| Non-GAAP operating margin |  | 35.3 | % |  | 30.2 | % |
| GAAP net income |  | $ | 144,538 |  |  | $ | 82,961 |  |
| Stock-based compensation expense |  | 20,851 |  |  | 16,439 |  |
| Litigation expense |  | 7,085 |  |  | 11,466 |  |
| Excess tax benefit on share based awards |  | (25,321 | ) |  | (28,790 | ) |
| Income tax effect on non-GAAP exclusions |  | (13,030 | ) |  | (10,269 | ) |
| Non-GAAP net income |  | $ | 134,123 |  |  | $ | 71,807 |  |
| GAAP diluted net income per share attributable to common stockholders |  | $ | 1.79 |  |  | $ | 1.07 |  |
| Non-GAAP adjustments to net income |  | (0.13 | ) |  | (0.14 | ) |
| Non-GAAP diluted net income per share |  | $ | 1.66 |  |  | $ | 0.93 |  |
| Weighted-average shares used in computing diluted net income per share attributable to common stockholders |  | 80,721 |  |  | 77,516 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |
| Cost of revenue |  | $ | 1,202 |  |  | $ | 1,024 |  |
| Research and development |  | 10,945 |  |  | 9,587 |  |
| Sales and marketing |  | 5,960 |  |  | 3,456 |  |
| General and administrative |  | 2,744 |  |  | 2,372 |  |
| Total |  | $ | 20,851 |  |  | $ | 16,439 |  |

[0001596532-18-000101:8k_2_02:49]
ARISTA NETWORKS, INC.

[0001596532-18-000101:8k_2_02:50]
Condensed Consolidated Balance Sheets

[0001596532-18-000101:8k_2_02:51]
(Unaudited, in thousands)

[0001596532-18-000101:8k_2_02:52]
|  |  | March 31, 2018 |  | December 31, 2017 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 886,160 |  |  | $ | 859,192 |  |
| Marketable securities |  | 851,880 |  |  | 676,363 |  |
| Accounts receivable |  | 207,339 |  |  | 247,346 |  |
| Inventories |  | 268,131 |  |  | 306,198 |  |
| Prepaid expenses and other current assets |  | 165,664 |  |  | 177,330 |  |
| Total current assets |  | 2,379,174 |  |  | 2,266,429 |  |
| Property and equipment, net |  | 73,825 |  |  | 74,279 |  |
| Investments |  | 36,136 |  |  | 36,136 |  |
| Deferred tax assets |  | 68,020 |  |  | 65,125 |  |
| Other assets |  | 22,879 |  |  | 18,891 |  |
| TOTAL ASSETS |  | $ | 2,580,034 |  |  | $ | 2,460,860 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 70,431 |  |  | $ | 52,200 |  |
| Accrued liabilities |  | 85,728 |  |  | 133,827 |  |
| Deferred revenue |  | 274,677 |  |  | 327,706 |  |
| Other current liabilities |  | 26,943 |  |  | 16,172 |  |
| Total current liabilities |  | 457,779 |  |  | 529,905 |  |
| Income taxes payable |  | 37,358 |  |  | 34,067 |  |
| Lease financing obligations, non-current |  | 37,138 |  |  | 37,673 |  |
| Deferred revenue, non-current |  | 181,377 |  |  | 187,556 |  |
| Other long-term liabilities |  | 21,343 |  |  | 9,745 |  |
| TOTAL LIABILITIES |  | 734,995 |  |  | 798,946 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 8 |  |  | 7 |  |
| Additional paid-in capital |  | 841,431 |  |  | 804,731 |  |
| Retained earnings (1) |  | 1,007,226 |  |  | 859,114 |  |
| Accumulated other comprehensive loss |  | (3,626 | ) |  | (1,938 | ) |
| TOTAL STOCKHOLDERS’ EQUITY |  | 1,845,039 |  |  | 1,661,914 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 2,580,034 |  |  | $ | 2,460,860 |  |
| ____________________________ |  |  |  |  |
| (1) The adoption of ASU 2014-09, Revenue from Contracts with Customers (Topic 606), and ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, in the first quarter of 2018 resulted in an adjustment to increase the retained earnings balance by $3.6 million as of January 1, 2018. |

[0001596532-18-000101:8k_2_02:53]
6

[0001596532-18-000101:8k_2_02:54]
ARISTA NETWORKS, INC.

[0001596532-18-000101:8k_2_02:55]
Condensed Consolidated Statements of Cash Flows

[0001596532-18-000101:8k_2_02:56]
(Unaudited, in thousands)

[0001596532-18-000101:8k_2_02:57]
|  |  | Three Months Ended March 31, |
|  |  | 2018 |  | 2017 As Adjusted (1) |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 144,538 |  |  | $ | 82,961 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 5,697 |  |  | 4,939 |  |
| Stock-based compensation |  | 20,851 |  |  | 16,439 |  |
| Deferred income taxes |  | (3,541 | ) |  | 2,521 |  |
| Amortization (accretion) of investment premiums (discounts) |  | (30 | ) |  | 330 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | 40,007 |  |  | 44,057 |  |
| Inventories |  | 38,067 |  |  | (50,296 | ) |
| Prepaid expenses and other current assets |  | 13,722 |  |  | (29,051 | ) |
| Other assets |  | (2,027 | ) |  | 69 |  |
| Accounts payable |  | 20,040 |  |  | (18,648 | ) |
| Accrued liabilities |  | (48,140 | ) |  | (15,143 | ) |
| Deferred revenue |  | (42,686 | ) |  | 124,236 |  |
| Income taxes payable |  | 3,478 |  |  | 2,923 |  |
| Other liabilities |  | 5,565 |  |  | (2,475 | ) |
| Net cash provided by operating activities |  | 195,541 |  |  | 162,862 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 90,448 |  |  | 64,488 |  |
| Purchases of marketable securities |  | (267,976 | ) |  | (61,511 | ) |
| Purchases of property and equipment |  | (6,336 | ) |  | (4,645 | ) |
| Net cash used in investing activities (1) |  | (183,864 | ) |  | (1,668 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Principal payments of lease financing obligations |  | (456 | ) |  | (383 | ) |
| Proceeds from issuance of common stock under equity plans |  | 17,300 |  |  | 19,481 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (1,536 | ) |  | (580 | ) |
| Net cash provided by financing activities |  | 15,308 |  |  | 18,518 |  |
| Effect of exchange rate changes |  | (14 | ) |  | 184 |  |
| NET INCREASE IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 26,971 |  |  | 179,896 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period (1) |  | 864,697 |  |  | 572,168 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period (1) |  | $ | 891,668 |  |  | $ | 752,064 |  |
| ____________________________________ |  |  |  |  |
| (1) The adoption of ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash ("ASU 2016-18"), in the first quarter of 2018 requires the Company to include restricted cash together with cash and cash equivalents when reconciling the beginning-of-period and end-of-period amounts presented on the statements of cash flows. As a result, for the three months ended March 31, 2017, the beginning-of-period and end-of-period amounts increased by $4.2 million and $5.5 million, respectively, and net cash used in investing activities increased by $1.3 million. |

[0001596532-18-000101:8k_2_02:58]
7
