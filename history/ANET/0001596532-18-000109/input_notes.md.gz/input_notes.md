# ANET notes — 0001596532-18-000109


## anet:InvestmentsPrivatelyHeldCompaniesPolicyTextBlock

[0001596532-18-000109:notes:1]
Our equity investments in privately-held companies without readily determinable fair values are measured using the measurement alternative, defined by Accounting Standards Codification (“ASC”) 321-Investments-Equity Securities as cost, less impairments, and adjusted up or down based on observable price changes in orderly transactions for identical or similar investments of the same issuer. Any adjustments resulting from impairments and/or observable price changes are recorded as other income (expense) in our consolidated statement of income. Prior to 2018, such investments were accounted for under the cost method and were recorded at historical cost at the time of investment, with adjustments to the balance only in the event of an impairment.

[0001596532-18-000109:notes:2]
Our equity investments in privately-held companies are included in investments, non-current, in our consolidated balance sheets.


## anet:ScheduleofSharebasedCompensationSharesAvailableForGrantActivityTableTextBlock

[0001596532-18-000109:notes:3]
The following table presents the stock activity and the total number of shares available for grant as of March 31, 2018 (in thousands):

[0001596532-18-000109:notes:4]
|  |  | Number of Shares |
| Balance—December 31, 2017 |  | 13,512 |  |
| Authorized |  | 2,211 |  |
| RSUs granted |  | (153 | ) |
| Options canceled |  | 18 |  |
| RSUs forfeited |  | 25 |  |
| Shares traded for taxes |  | 7 |  |
| Balance—March 31, 2018 |  | 15,620 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001596532-18-000109:notes:5]
The fair values of available-for-sale investments, by remaining contractual maturity, are as follows (in thousands):

[0001596532-18-000109:notes:6]
|  |  | March 31, 2018 |
| Due in 1 year or less |  | $ | 559,733 |  |
| Due in 1 year through 2 years |  | 292,147 |  |
| Total marketable securities |  | $ | 851,880 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001596532-18-000109:notes:7]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2018, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2017 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant intercompany accounts and transactions have been eliminated.

[0001596532-18-000109:notes:8]
Our condensed consolidated financial statements and related financial information in this Quarterly Report on Form 10-Q should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2017, filed with the SEC on February 20, 2018. Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-18-000109:notes:9]
5.    Commitments and Contingencies

[0001596532-18-000109:notes:10]
Operating Leases

[0001596532-18-000109:notes:11]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2025. There have been no material changes in our future minimum payment obligations under our operating leases that existed as of December 31, 2017, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2017, except as follows. During the three months ended March 31, 2018, we entered into new leases primarily related to additional data center capacity and co-location services. As of March 31, 2018, the total minimum future payment commitment under these new leases was approximately $43.6 million, of which $0.5 million is due in 2018, with the remainder due in 2021 through 2028.

[0001596532-18-000109:notes:12]
We recognize rent expense under these arrangements on a straight-line basis over the term of the leases. For the three months ended March 31, 2018 and 2017, rent expense for all operating leases amounted to $2.5 million and $2.4 million, respectively.

[0001596532-18-000109:notes:13]
Financing Obligation—Build-to-Suit Lease

[0001596532-18-000109:notes:14]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013. The lease is accounted for as a financing obligation and the lease payments are attributed to (1) a reduction of the principal financing obligation; (2) imputed interest expense; and (3) land lease expense, representing an imputed cost to lease the underlying land of the building. There have been no material changes in our future minimum payment obligations under this financing lease, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2017. Land lease expense related to our lease financing obligation is classified as rent expense in our unaudited condensed consolidated statements of income, and amounted to $0.3 million for the three months ended March 31, 2018 and 2017.

[0001596532-18-000109:notes:15]
Purchase Commitments

[0001596532-18-000109:notes:16]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished product and a significant portion of these orders consist of firm non-cancelable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancelable, including integrated circuits, which are consigned to our contract manufacturers. As of March 31, 2018, we had non-cancellable purchase commitments of $251.1 million, of which $197.7 million was to our contract manufacturers and suppliers. We have not recorded a liability related to these purchase commitments. In addition, we have provided deposits to secure our obligations to purchase inventory. We had $27.2 million and $36.9 million in deposits as of March 31, 2018 and December 31, 2017, respectively. These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.

[0001596532-18-000109:notes:17]
Guarantees

[0001596532-18-000109:notes:18]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-18-000109:notes:19]
Legal Proceedings

[0001596532-18-000109:notes:20]
OptumSoft, Inc. Matters

[0001596532-18-000109:notes:21]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies; and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-18-000109:notes:22]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft access to our software for evaluation by OptumSoft; (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches; (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers; (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us; and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors, who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dated July 28, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.

[0001596532-18-000109:notes:23]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we assert our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we assert that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We ask the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also assert that, even if we are found not to own certain components, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation. On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have meritorious defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-18-000109:notes:24]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On December 16, 2015, the Court issued a Proposed Statement of Decision Following Phase 1 Trial, and on January 8, 2016, OptumSoft filed objections to that Proposed Statement of Decision. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II including the application of the Court’s interpretation of the 2004 agreement as set forth in the Final Statement of Decision Following Phase I Trial to any other source code that OptumSoft claims to own following a review. The Phase II Trial is set to begin on March 4, 2019.

[0001596532-18-000109:notes:25]
We intend to vigorously defend against any claims brought against us by OptumSoft.  However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor.  For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft.  If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license.  An adverse litigation ruling could result in a significant damages award against us and injunctive relief. In addition, OptumSoft could assert additional or different claims against us, including claims that our license from OptumSoft is invalid.

[0001596532-18-000109:notes:26]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated.  However, the outcome of litigation is inherently uncertain. Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-18-000109:notes:27]
Cisco Systems, Inc. (“Cisco”) Matters

[0001596532-18-000109:notes:28]
We are currently involved in several litigation matters with Cisco Systems, Inc. These matters are summarized below.

[0001596532-18-000109:notes:29]
Cisco Systems, Inc. v. Arista Networks, Inc. (Case No. 4:14-cv-05343) (“’43 Case”)

[0001596532-18-000109:notes:30]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the 875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”). Cisco seeks, as relief for our alleged infringement in the ’43 Case, lost profits and/or reasonable royalty damages in an unspecified amount, including treble damages, attorney’s fees, and associated costs. Cisco also seeks injunctive relief in the ’43 Case. On February 10, 2015, the Court granted our unopposed motion to stay the ’43 Case until the proceedings before the United States International Trade Commission (“USITC”) pertaining to the same patents (as discussed below) became final. Trial has not been scheduled in the ’43 Case.

[0001596532-18-000109:notes:31]
On March 6, 2018, the Court issued an order directing the parties to file a joint status report updating the Court on the progress of the 944 and 945 Investigations (as defined below) and when the parties expected the stay of the ’43 Case might be lifted or the case dismissed. In Cisco’s portion of the joint status report, Cisco proposed that the judge lift the stay as to the ’597, ’164, ’592, ’145, ’492, ’296, and ’875 patents. We opposed Cisco’s proposal. The judge has not yet responded to Cisco’s proposal, and the stay on the ’43 Case currently remains in place.

[0001596532-18-000109:notes:32]
Cisco Systems, Inc. v. Arista Networks, Inc. (Case No. 5:14-cv-05344) (“’44 Case”)

[0001596532-18-000109:notes:33]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI” and U.S. Patent Nos. 7,047,526 and 7,953,886 (respectively, “the ’526 patent” and “the ’886 patent”). As relief for our alleged patent infringement in the ’44 Case, Cisco seeks lost profits and/or reasonable royalty damages in an unspecified amount including treble damages, attorney’s fees, and associated costs as well as injunctive relief. As relief for our alleged copyright infringement, Cisco seeks monetary damages for alleged lost profits, profits from our alleged infringement, statutory damages, attorney’s fees, and associated costs.

[0001596532-18-000109:notes:34]
As described below, on May 25, 2016, our petition for Inter Partes Review (“IPR”) of the ’886 patent was instituted by the United States Patent Trial and Appeal Board (“PTAB”). Cisco subsequently agreed to dismiss its claims as to the ’886 patent with prejudice.

[0001596532-18-000109:notes:35]
On December 14, 2016, following a two-week trial, a jury found that we had proven our copyright defense of scenes a faire and that Cisco had failed to prove infringement of the ’526 patent. On that basis, judgment was entered in our favor on all claims on December 19, 2016.

[0001596532-18-000109:notes:36]
On January 17, 2017, Cisco filed a motion for judgment as a matter of law, challenging the sufficiency of the evidence in support of our scenes a faire defense. Cisco did not file any post-trial motion regarding the ’526 patent, nor did it file a motion for a new trial. We also filed a conditional motion for judgment as a matter of law and/or for a new trial on several grounds, which would be at issue only if the court granted Cisco’s motion. The hearing on both parties’ motions was held on April 27, 2017. On May 10, 2017, the court denied Cisco’s motion and denied our motions as moot.

[0001596532-18-000109:notes:37]
Cisco filed a notice of appeal on June 6, 2017. Cisco did not appeal the jury’s noninfringement verdict on the ‘526 patent but did appeal the jury’s finding that we established the defense of scenes a faire. The parties have submitted their appeal briefs to the U.S. Court of Appeals of the Federal Circuit (“Federal Circuit”). The Federal Circuit has not set a date for oral argument.

[0001596532-18-000109:notes:38]
Arista Networks, Inc. v. Cisco Systems, Inc. (Case No. 5:16-cv-00923) (“’23 Case”)

[0001596532-18-000109:notes:39]
On February 24, 2016, we filed a complaint against Cisco in the District Court for the Northern District of California alleging antitrust violations and unfair competition. On August 23, 2016, the Court granted Cisco’s motion to stay the ’23 Case until judgment was entered on Cisco’s copyright claims in the ’44 Case. On March 2, 2017, the Court lifted the stay.

[0001596532-18-000109:notes:40]
On March 23, 2017, Cisco filed a motion to dismiss our complaint in the ’23 Case. On October 10, 2017, the Court issued an order granting in part and denying in part Cisco’s motion to dismiss, with leave for us to amend to cure any deficiencies as to the claims that were dismissed. On October 31, 2017, we filed an amended complaint, and on November 14, 2017, Cisco filed its answer.  On February 14, 2018, the Court struck certain defenses asserted by Cisco.  Both Cisco and we have filed pretrial motions, including motions for summary judgment, and the trial is set for August 3, 2018.

[0001596532-18-000109:notes:41]
Certain Network Devices, Related Software, and Components Thereof (Inv. No. 337-TA-944) (“944 Investigation”)

[0001596532-18-000109:notes:42]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated 19 U.S.C. § 1337 (“Section 337”). The USITC instituted Cisco’s complaint as Investigation No. 337-TA-944. Cisco initially alleged that certain of our switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents. Cisco subsequently dropped the ’296 patent from the 944 Investigation. Cisco sought, among other things, a limited exclusion order barring entry into the United States of accused switch products (including our 7000 Series of switches) and components and software therein and a cease and desist order against us restricting our activities with respect to our imported accused switch products and components and software therein.

[0001596532-18-000109:notes:43]
On February 2, 2016, the Administrative Law Judge (“ALJ”) issued his initial determination finding a violation of Section 337. More specifically, the ALJ found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringed asserted claims 1, 2, 8-11, and 17-19 of the ’537 patent; asserted claims 6, 7, 20, and 21 of the ’592 patent; and asserted claims 5, 7, 45, and 46 of the ’145 patent. The ALJ did not find a violation of Section 337 with respect to any asserted claims of the ’597 and ’164 patents. On June 23, 2016, the USITC issued its Final Determination, which found a violation with respect to the ’537, ’592, and ’145 patents, and found no violation with respect to the ’597 and ’164 patents. The USITC also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software and components thereof that infringe one or more of claims 1, 2, 8-11, and 17-19 of the ’537 patent; claims 6, 7, 20, and 21 of the ’592 patent; and claims 5, 7, 45, and 46 of the ’145 patent. On August 22, 2016, the Presidential review period for the 944 Investigation expired. The USITC orders will be in effect until the expiration of the ’537, ’592, and ’145 patents.

[0001596532-18-000109:notes:44]
Both we and Cisco filed petitions for review of the USITC’s Final Determination to the Federal Circuit. The appeal was fully briefed and oral argument was held on June 6, 2017. On September 27, 2017, the Federal Circuit affirmed the USITC’s Final Determination.

[0001596532-18-000109:notes:45]
On August 26, 2016, Cisco filed an enforcement complaint under Section 337 with the USITC. Cisco alleges that we are violating the cease and desist and limited exclusion orders issued in the 944 Investigation by engaging in the “marketing, distribution, offering for sale, selling, advertising, and/or aiding or abetting other entities in the sale and/or distribution of products that Cisco alleges continue to infringe claims 1-2, 8-11, and 17-19 of the ’537 patent,” despite the design changes we have made to those products. Cisco asks the USITC to (1) enforce the cease and desist order; (2) modify the USITC’s limited exclusion order and/or cease and desist order “in any manner that would assist in the prevention of the unfair practices that were originally the basis for issuing such Order or assist in the detection of violations of such Order”; (3) impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000 or twice the domestic value of the articles entered or sold, whichever is higher”; (4) bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order”; and (5) impose “such other remedies and sanctions as are appropriate and within the USITC’s authority.” On September 28, 2016, the USITC instituted the enforcement proceeding. The proceeding has been assigned to ALJ Shaw, who presided over the underlying investigation. The target date for the investigation was initially set for September 20, 2017. On June 20, 2017, the ALJ issued his initial determination finding that we did not violate the June 23, 2016 cease and desist order. The initial determination also recommended a civil penalty of $307 million if the USITC decided to overturn the finding of no violation. On July 3, 2017, the parties filed petitions for review of certain findings in the initial determination.

[0001596532-18-000109:notes:46]
On August 4, 2017, the USITC issued an order remanding the investigation to the ALJ to make additional findings on certain issues and issue a remand initial determination. The USITC ordered the ALJ to set a schedule for completion of any necessary remand proceedings and a new target date for the enforcement action (the “944 Enforcement Action”). On August 25, 2017 the ALJ issued an Initial Determination setting a June 4, 2018 deadline for the remand initial determination and September 4, 2018 as the new target date for the enforcement action. On September 18, 2017, the USITC determined not to review the Initial Determination setting the target date.  The ALJ held a hearing on February 1, 2018.

[0001596532-18-000109:notes:47]
Certain Network Devices, Related Software, and Components Thereof (Inv. No. 337-TA-945) (“945 Investigation”)

[0001596532-18-000109:notes:48]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated Section 337. The USITC instituted Cisco’s complaint as Investigation No. 337-TA-945. Cisco alleged that certain of our switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents. Cisco sought, among other things, a limited exclusion order barring entry into the United States of accused switch products (including our 7000 Series of switches) related software, and components therein and a cease and desist order against us restricting our activities with respect to our imported accused switch products and components and software therein.

[0001596532-18-000109:notes:49]
On December 9, 2016, the ALJ issued her initial determination finding a violation of Section 337. More specifically, the ALJ found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringe asserted claims 1, 7, 9, 10, and 15 of the ’577 patent and asserted claims 1, 2, 4, 5, 7, 8, 10, 13, 19, 56, and 64 of the ’668 patent. The ALJ did not find a violation of Section 337 with respect to asserted claim 2 of the ’577 patent or any asserted claims of the ’853, ’492, ’875, and ’211 patents.

[0001596532-18-000109:notes:50]
On May 4, 2017, the USITC issued its Final Determination, which found a violation with respect to the ’577 and ’668 patents, and found no violation with respect to the ’211, ’853, ’875 and ’492 patents. The USITC also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software and components thereof that infringe one or more of claims 1, 7, 9, 10, and 15 of the ’577 patent and 1, 2, 4, 5, 7, 8, 10, 13, 18, 56, and 64 of the ’668 patent. On July 4, 2017, the 60-day Presidential review period for the 945 Investigation expired. During the 60-day Presidential review period, the USITC Orders permitted us to continue importing and selling products covered by the orders so long as we paid a 5% bond. Because the United States Trade Representative did not disapprove the USITC’s final determination, the limited exclusion order and cease and desist order are now in full effect.

[0001596532-18-000109:notes:51]
On May 25, 2017 and June 1, 2017, the PTAB issued final written decisions finding all claims of the ’577 and ’668 patents that we were found to have infringed in the 945 Investigation unpatentable. On June 1, 2017 and June 2, 2017, we filed emergency petitions to suspend the remedial orders in the 945 Investigation. On July 20, 2017, the USITC issued a notice denying our petition to suspend the remedial orders. On July 21, 2017, we filed a motion to stay the remedial orders in the 945 Investigation pending disposition of the relevant appeals and sought expedited consideration of our motion. On September 11, 2017, the USITC denied our motion to stay.

[0001596532-18-000109:notes:52]
On June 30, 2017, Cisco filed a petition for review of the USITC’s Final Determination to the Federal Circuit regarding the ’853, ’492, ’875 and ’211 patents. On July 21, 2017, we filed a petition for review of the Final Determination to the Federal Circuit.

[0001596532-18-000109:notes:53]
On August 25, 2017 we filed a motion with the Federal Circuit requesting that the Federal Circuit stay the remedial orders pending the completion of the appeal of the 945 Investigation. On September 22, 2017, the Federal Circuit issued an order denying our motion to stay, but ordered that our redesigned products be allowed to enter the country “unless and until USITC proceedings are initiated and completed to produce an enforceable determination that such a redesign is barred” by a USITC remedial order.

[0001596532-18-000109:notes:54]
On September 27, 2017, Cisco filed a petition with the USITC requesting that the USITC institute a modification proceeding (“945 Modification Proceeding”) to determine whether our redesigned products infringe the patent claims underlying the remedial orders in the 945 Investigation. On October 27, 2017, the USITC instituted the 945 Modification Proceeding. The proceeding has been assigned to ALJ McNamara, who presided over the underlying investigation.

[0001596532-18-000109:notes:55]
The ALJ held a hearing on January 26, 2018 and issued a recommended determination (“RD”) on March 23, 2018.  The RD found that our redesigned products do not infringe the ’577 patent but do infringe the ’668 patent. The RD will be subject to review by the USITC after which the USITC will issue a final determination. The USITC has not set a target date for the final determination.

[0001596532-18-000109:notes:56]
On April 5, 2018, the USITC issued an order suspending enforcement of the remedial orders as to the ’668 patent  following the Federal Circuit’s affirmance of the PTAB’s final written decision for the ’668 patent.

[0001596532-18-000109:notes:57]
Inter Partes Reviews

[0001596532-18-000109:notes:58]
We have filed petitions for Inter Partes Review of the ’597, ’211, ’668, ’853, ’537, ’577, ’886, and ’526 patents. IPRs relating to the ’597 (IPR No. 2015-00978) and ’211 (IPR No. 2015-00975) patents were instituted in October 2015 and hearings on these IPRs were completed in July 2016. On September 28, 2016, the PTAB issued a final written decision finding claims 1, 14, 39-42, 71, 72, 84, and 85 of the ’597 patent unpatentable. The PTAB also found that claims 29, 63, 64, 73, and 86 of the ’597 patent had not been shown to be unpatentable. On October 5, 2016, the PTAB issued a final written decision finding claims 1 and 12 of the ’211 patent unpatentable. The PTAB also found that claims 2, 6-9, 13, 17-20 of the ’211 patent had not been shown to be unpatentable. Both parties have appealed the final written decisions on the ’211 and ’537 patent IPRs.  The hearing for the ’211 IPR appeal was held in March 2018, and on March 28, 2018, the Federal Circuit remanded the matter back to the PTAB for further proceedings.

[0001596532-18-000109:notes:59]
The IPR relating to the ’886 patent was instituted on May 25, 2016. Following that decision, Cisco agreed to dismiss its claims as to the ʼ886 patent with prejudice, and we dismissed our counterclaims as to the ʼ886 patent without prejudice.

[0001596532-18-000109:notes:60]
IPRs relating to the ’668 (IPR No. 2016-00309), ’577 (IPR No. 2016-00303), ’853 (IPR No. 2016-0306), and ’537 (IPR No. 2016-0308) patents were instituted in June 2016 and hearings were held on March 7, 2017. On May 25, 2017, the PTAB issued final written decisions finding claims 1, 7-10, 12-16, 18-22, 25, and 28-31 of ’577 patent unpatentable, and that claim 2 of the ’577 patent, claim 63 of the ’853 patent, and claims 1, 10, 19, and 21 of the ’537 patent had not been shown to be unpatentable. On June 1, 2017, the PTAB issued a final written decision finding claims 1-10, 12-13, 15-28, 30-31, 33-36, 55-64, 66-67, and 69-72 of the ’668 patent unpatentable. We filed a Notice of Appeal concerning the ’577 patent on July 21, 2017, and Notices of Appeal concerning the ‘853 and ’537 patents on July 26, 2017. Cisco cross-appealed concerning the ’577 patent on July 26, 2017 and filed a Notice of Appeal concerning the ’668 patent on August 1, 2017. For the appeals of the IPRs on the ’668 and ’577 patents, the Federal Circuit granted our motion for an expedited briefing schedule, and the hearings were held on February 9, 2018. On February 14, 2018, the Federal Circuit affirmed the PTAB’s final written decision on the ’668 patent.

[0001596532-18-000109:notes:61]
* * * * *

[0001596532-18-000109:notes:62]
We intend to vigorously defend against each of the Cisco lawsuits, as summarized in the preceding paragraphs. However, we cannot be certain that any claims by Cisco will be resolved in our favor regardless of the merit of the claims. Any adverse litigation ruling could result in injunctive relief and USITC remedial orders, including the above described injunctive relief, could lead to significant penalties assessed or damages awarded against us or a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products.

[0001596532-18-000109:notes:63]
For example, in the 944 Investigation, the USITC issued a limited exclusion order barring entry into the United States of our network devices (including our 7000 Series of switches), related software, and components thereof that infringe one or more of the claims of the ’537, ʼ592, and ʼ145 patents specified above and a cease and desist order restricting our activities with respect to such imported products. In the 945 Investigation, the USITC issued a limited exclusion order barring entry into the United States of our network devices, related software, and components thereof that infringe one or more of the claims of the ’577 and ’668 patents specified above and a cease and desist order restricting our activities with respect to such imported products.

[0001596532-18-000109:notes:64]
To comply with these orders, we have sought to develop technical redesigns that no longer infringe the patents that are the subject of the orders. In any efforts to develop these technical redesigns for our products, we may be unable to do so in a manner that does not continue to infringe the patents or that is acceptable to our customers. Our redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management. Moreover, our ability to import redesigned products into the United States is based on rulings from U.S. Customs and Border Protection (“CBP”) and the Federal Circuit. While these favorable rulings currently allow us to import our redesigned products into the United States, the USITC could determine in an enforcement action or modification proceeding that our redesigned products continue to infringe the patents that are the subject of any USITC orders. In addition, the Federal Circuit or CBP could decide to withdraw or alter their rulings based on a change in circumstances. Any failure to effectively redesign our products, obtain customer acceptance of those redesigned products, retain authorization to import those redesigned products, or address the USITC findings in a manner that complies with the USITC orders, may cause a disruption to our product shipments, a rejection or return of our redesigned products by (or a delay or loss of sales to) customers, subject us to penalties or damage awards, and materially and adversely affect our business, revenues, prospects, reputation, results of operations, and financial condition.

[0001596532-18-000109:notes:65]
Specifically, in response to the USITC’s findings in the 944 Investigation, we have made design changes to our products for sale in the United States to address the features that were found to infringe the ’537, ’592, and ’145 patents. Following the issuance of the final determination in the 944 Investigation, we submitted a Section 177 ruling request to CBP seeking approval to import these redesigned products into the United States. On November 18, 2016, we received a 177 ruling from CBP finding that our redesigned products did not infringe the relevant claims of the ʼ537, ’592, and ʼ145 patents, and approving the importation of those redesigned products into the United States. On January 13, 2017, at the request of Cisco and without our input, CBP issued a letter to us revoking its prior November 18 ruling. CBP subsequently conducted an inter partes proceeding between Arista and Cisco to determine whether our redesigned products infringe and whether to approve them for importation into the United States. On April 7, 2017, following the inter partes proceeding, CBP again ruled that our redesigned products do not infringe the relevant claims of the ’537, ’592, and ’145 patents and again approved those redesigns for importation into the United States. On September 12, 2017, Cisco filed a second request with CBP seeking to revoke our approval to import our redesigns relating to the 944 Investigation. We have opposed Cisco’s request, and CBP has not yet ruled on Cisco’s request.

[0001596532-18-000109:notes:66]
Similarly, on May 4, 2017, the USITC issued a limited exclusion order and cease and desist order in the 945 Investigation with respect to the ’668 and ’577 patents. We have made design changes to our products for sale in the United States to address the features that were found to infringe the ’577 and ’668 patents. In particular, the ’577 patent was directed to a feature that is implemented in the merchant silicon chips that we purchase from third-party suppliers. Because we do not design, build or manufacture these merchant silicon chips, we are limited in further modifications that we can make to our products for this patent. Our redesign efforts therefore consisted of removing the feature found to infringe the ’577 patent in all of our products until this patent expires on June 30, 2018, and providing an alternative feature to address the ‘577 patent for a subset of those products. The redesign efforts to address the 945 Investigation findings could be extremely costly and time consuming for us and our customers as well as disruptive to our other development activities and distracting to management. If the redesigned products are unacceptable to our customers, our business, revenues, deferred revenue balances, prospects, reputation, results of operations or financial condition could be materially and adversely affected.

[0001596532-18-000109:notes:67]
Because the USITC did not suspend its orders in the 945 Investigation, despite a PTAB finding that every relevant claim of the ’668 and ’577 patents is unpatentable, we were barred from importing our redesigned products into the United States until we received approval from CBP. On July 21, 2017, we submitted a Part 177 request to CBP seeking approval to import our redesigned products into the United States. Following the Federal Circuit’s order on September 22, 2017, allowing us to import our redesigned products, we withdrew our request. On October 12, 2017, CBP, over Cisco’s objection, terminated the Part 177 proceedings, and confirmed that it will permit entry of our redesigns pursuant to the Federal Circuit’s September 22, 2017 order.

[0001596532-18-000109:notes:68]
Following a February 14, 2018 Federal Circuit opinion affirming the PTAB’s finding that the asserted claims of the ’668 patent are invalid, on April 5, 2018, the USITC suspended enforcement of its remedial orders in the 945 Investigation as to the ’668 patent. This suspension will remain in effect until the cancellation of the asserted claims of the ’668 patent or the reversal or vacatur of the Federal Circuit’s decision. While remote, there is some possibility that the Supreme Court could decide on the merits to vacate or reverse the Federal Circuit’s affirmance of the PTAB’s final written decision concerning the ’668 patent. Likewise, the Federal Circuit may vacate or reverse the PTAB’s final written decision concerning the ’577 patent.

[0001596532-18-000109:notes:69]
In either the 944 Enforcement Action or the 945 Modification Proceeding, if the USITC determines that our redesigned products infringe any of the patents that are the subject of USITC remedial orders, those redesigned products will also be barred from import into the United States, or sale after importation. In addition, the USITC may impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000 or twice the domestic value of the articles entered or sold, whichever is higher,” bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order,” or impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.” In the 944 Enforcement Action, the ALJ recommended a civil penalty of $307 million if the USITC were to reverse the ALJ’s finding of no violation. Any such finding by the USITC in either the 944 Enforcement Action or the 945 Modification Proceeding could materially and adversely affect our business, prospects, reputation, results of operations and financial condition.

[0001596532-18-000109:notes:70]
An adverse finding in the 944 Enforcement Action or the 945 Modification Proceeding would take effect immediately upon USITC’s issuance of the final determination, without any Presidential review period. To address such a finding, we would have to further redesign our products to make them non-infringing, and until we made such changes we would not be able to import or ship our products to customers. Our further redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management.  We may not be able to further redesign the products in a manner that does not continue to infringe the patents or that is acceptable to customers. We may not be able to complete, and our customers may not be able to qualify, such further redesigned products in a timely fashion, if at all, following the issuance of an adverse final determination, leading to a delay or cancellation of purchases by some customers until those redesigned products are qualified or accepted by such customers, a rejection or return of our redesigned products by some customers or a loss of sales to some customers who are unable to qualify or accept the redesigned products. Our redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management.

[0001596532-18-000109:notes:71]
For example, in the 944 Enforcement Action, although the ALJ issued an initial determination finding that our redesigned products did not violate the June 23, 2016 cease and desist order, if the ALJ modifies the initial determination during the remand proceeding, or if the USITC finds a violation in its final determination on September 4, 2018, we will no longer be able to import or ship our products in the U.S. until we make further changes to address those findings, which could materially and adversely affect our business, revenues, prospects, reputation, results of operations or financial condition. We would also need to obtain USITC or CBP approval to resume importation of such redesigned products into the United States. In addition, the USITC would not provide a service and support exception for our previously redesigned products, and customers may be required to upgrade to new products to obtain service and support. If we are unable to obtain such approvals or provide such service and support exception, our business, prospects, reputation, results of operations or financial condition could be materially and adversely affected. In addition, if we are found to have violated the USITC’s orders while those orders remain in effect, we may be subject to the penalties described above.

[0001596532-18-000109:notes:72]
In the 945 Modification Proceeding, while the USITC has suspended enforcement of its remedial orders as to the ’668 patent, the RD finds that our redesigned products infringe the ’668 patent. If the USITC adopts that finding, and the Federal Circuit’s decision is reversed by the Supreme Court or vacated as a result of a constitutional ruling on the IPR process, we will no longer be able to import or ship our products in the U.S. until we make further changes to address those findings. Likewise, if the USITC reverses the finding pursuant to the RD that our redesigned products do not infringe the ’577 patent, we will no longer be able to import or ship our products in the U.S. unless and until we make further changes to address those findings; the PTAB decision finding the relevant claims of the ’577 patent are affirmed on appeal and the United States Patent and Trademark Office (“Patent Office”) cancels those claims; or the ’577 patent expires on June 30, 2018. Any requirement that we further modify our products to comply with the ITC’s orders in the 945 Investigation could materially and adversely affect our business, revenues, prospects, reputation, results of operations or financial condition. We would also need to obtain USITC or CBP approval to resume importation of any such redesigned products into the United States. In addition, the USITC would not provide a service and support exception for our previously redesigned products, and customers may be required to upgrade to new products to obtain service and support. If we are unable to obtain such approvals or provide such service and support exception, our business, revenues, prospects, reputation, results of operations or financial condition could be materially and adversely affected. In addition, even if the PTAB decisions on the ’577 and ’688 patents are ultimately affirmed on appeal and the patent claims are canceled, if we are found to have violated the USITC’s orders while those orders were in effect, we may be subject to the penalties described above.

[0001596532-18-000109:notes:73]
To comply with the USITC’s remedial orders, we have also made certain changes to our manufacturing, importation and shipping workflows. These changes have included shifting manufacturing and integration of our products to be sold in the United States to U.S. facilities. Such changes may be extremely costly, time consuming, and we may not be able to implement such changes successfully. Any failure to successfully change our manufacturing and importation processes or shipping workflows in a manner that is compliant with the limited exclusion orders and cease and desist orders may cause a disruption in our product shipments and materially and adversely affect our business, prospects, reputation, results of operations, and financial condition.

[0001596532-18-000109:notes:74]
In connection with these changes, to the extent that we are required to make further modifications to our supply chain to obtain alternative U.S. sources for subcomponents, we may be unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, if at all, which could delay or halt entirely production of our products or require us to make further modifications to our products to incorporate new components that are available in the United States. Any of these events could result in lost sales, reduced gross margins or damage to our end-customer relationships, which would materially and adversely impact our business, financial condition, results of operations and prospects.

[0001596532-18-000109:notes:75]
Additionally, the existence of Ciscoʼs lawsuits against us could cause concern among our customers and partners and could adversely affect our business and results of operations. Many of our customers and partners require us to indemnify and defend them against third party infringement claims and pay damages in the case of adverse rulings. These claims could harm our relationships with our customers or channel partners, cause them to delay or defer purchasing decisions or deter them from doing business with us. From time to time, we may also be required to provide additional assurances beyond our standard terms. Whether or not we prevail in the lawsuit, we expect that the litigation will be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-18-000109:notes:76]
With respect to the various legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated.  However, the outcome of litigation is inherently uncertain. Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-18-000109:notes:77]
Other Matters

[0001596532-18-000109:notes:78]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-18-000109:notes:79]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2018, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-18-000109:notes:80]
6.    Equity Award Plan Activities

[0001596532-18-000109:notes:81]
2014 Equity Incentive Plan

[0001596532-18-000109:notes:82]
Effective January 1, 2018, our board of directors authorized an increase of 2,211,176 shares to the shares available for issuance under the 2014 Equity Incentive Plan (the “2014 Plan”).  Pursuant to the 2014 Plan, the 2018 share increase is determined based on the lesser of 3% of total shares of common stock outstanding as of December 31, 2017, 12,500,000 shares, or such amount as determined by our board of directors. As of March 31, 2018, there remained approximately 23.8 million shares available for issuance under the 2014 Plan.

[0001596532-18-000109:notes:83]
2014 Employee Stock Purchase Plan

[0001596532-18-000109:notes:84]
Effective January 1, 2018, our board of directors authorized an increase of 737,058 shares to shares available for issuance under our 2014 Employee Stock Purchase Plan (the “ESPP”).  Pursuant to the ESPP, the 2018 share increase is determined based the lesser of 1% of the total shares of common stock outstanding on December 31, 2017, 2,500,000 shares, or such amount as determined by our board of directors. As of March 31, 2018, there remained approximately 2,615,207 shares available for issuance under the ESPP.

[0001596532-18-000109:notes:85]
During the three months ended March 31, 2018, we issued  108,890 shares at a weighted-average purchase price of $67.09 under the ESPP.

[0001596532-18-000109:notes:86]
[same as prior period, unchanged from 0001596532-17-000251:notes:86]

[0001596532-18-000109:notes:87]
The following table summarizes the option activity under our stock plans and related information (in thousands, except years and per share amounts):

[0001596532-18-000109:notes:88]
|  |  | Options Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding |
| Balance—December 31, 2017 |  | 7,024 |  |  | $ | 33.05 |  |  | 6.1 |  | $ | 1,422,637 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (394 | ) |  | 25.39 |  |  |  |  |  |
| Options canceled |  | (18 | ) |  | 41.58 |  |  |  |  |  |
| Balance—March 31, 2018 |  | 6,612 |  |  | $ | 33.48 |  |  | 5.9 |  | $ | 1,466,783 |  |
| Vested and exercisable—March 31, 2018 |  | 2,911 |  |  | $ | 22.71 |  |  | 5.3 |  | $ | 676,982 |  |

[0001596532-18-000109:notes:89]
[same as prior period, unchanged from 0001596532-17-000251:notes:91]

[0001596532-18-000109:notes:90]
A summary of the RSU activity under our stock plans and related information are presented below (in thousands, except years and per share amounts):

[0001596532-18-000109:notes:91]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2017 |  | 1,537 |  |  | $ | 104.29 |  |  | 1.6 |  | $ | 362,119 |  |
| RSUs granted |  | 153 |  |  | 279.87 |  |  |  |  |  |
| RSUs vested |  | (136 | ) |  | 87.07 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (25 | ) |  | 121.92 |  |  |  |  |  |
| Unvested balance—March 31, 2018 |  | 1,529 |  |  | $ | 123.10 |  |  | 1.6 |  | $ | 390,315 |  |

[0001596532-18-000109:notes:92]
Shares Available for Grant

[0001596532-18-000109:notes:93]
Stock-Based Compensation Expense

[0001596532-18-000109:notes:94]
Total stock-based compensation expense related to options, restricted stock awards, restricted stock units and employee stock purchase rights granted were allocated as follows (in thousands):

[0001596532-18-000109:notes:95]
|  |  | Three Months Ended March 31, |
|  |  | 2018 |  | 2017 |
| Cost of revenue |  | $ | 1,202 |  |  | $ | 1,024 |  |
| Research and development |  | 10,945 |  |  | 9,587 |  |
| Sales and marketing |  | 5,960 |  |  | 3,456 |  |
| General and administrative |  | 2,744 |  |  | 2,372 |  |
| Total stock-based compensation |  | $ | 20,851 |  |  | $ | 16,439 |  |

[0001596532-18-000109:notes:96]
As of March 31, 2018, unrecognized stock-based compensation expenses by award type and their expected weighted-average recognition periods are summarized in the following table (in thousands, except years).

[0001596532-18-000109:notes:97]
|  |  | March 31, 2018 |
|  |  | Stock Option |  | RSU |  | ESPP |
| Unrecognized stock-based compensation expense |  | $ | 61,271 |  |  | $ | 174,249 |  |  | $ | 4,996 |  |
| Weighted-average amortization period |  | 3.5 years |  |  | 3.5 years |  |  | 1.1 years |  |


## us-gaap:EarningsPerShareTextBlock

[0001596532-18-000109:notes:98]
7.    Net Income Per Share Available to Common Stock

[0001596532-18-000109:notes:99]
[same as prior period, unchanged from 0001596532-17-000251:notes:100]

[0001596532-18-000109:notes:100]
|  |  | Three Months Ended March 31, |
|  |  | 2018 |  | 2017 |
| Numerator: |  |  |  |  |
| Basic: |  |  |  |  |
| Net income |  | $ | 144,538 |  |  | $ | 82,961 |  |
| Less: undistributed earnings allocated to participating securities |  | (89 | ) |  | (267 | ) |
| Net income available to common stockholders, basic |  | $ | 144,449 |  |  | $ | 82,694 |  |
| Diluted: |  |  |  |  |
| Net income attributable to common stockholders, basic |  | $ | 144,449 |  |  | $ | 82,694 |  |
| Add: undistributed earnings allocated to participating securities |  | 7 |  |  | 22 |  |
| Net income attributable to common stockholders, diluted |  | $ | 144,456 |  |  | $ | 82,716 |  |
| Denominator: |  |  |  |  |
| Basic: |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 73,994 |  |  | 71,114 |  |
| Diluted: |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 73,994 |  |  | 71,114 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |
| Stock options and RSUs |  | 6,670 |  |  | 6,321 |  |
| Employee stock purchase plan |  | 57 |  |  | 81 |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted |  | 80,721 |  |  | 77,516 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |
| Basic |  | $ | 1.95 |  |  | $ | 1.16 |  |
| Diluted |  | $ | 1.79 |  |  | $ | 1.07 |  |

[0001596532-18-000109:notes:101]
The following weighted-average outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share available to common stockholders for the periods presented because including them would have been anti-dilutive (in thousands):

[0001596532-18-000109:notes:102]
|  |  | Three Months Ended March 31, |
|  |  | 2018 |  | 2017 |
| Stock options and RSUs to purchase common stock |  | 22 |  |  | 188 |  |
| Employee stock purchase plan |  | 26 |  |  | — |  |
| Total |  | 48 |  |  | 188 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-18-000109:notes:103]
The following tables set forth the fair value of our financial assets by level within the fair value hierarchy (in thousands):

[0001596532-18-000109:notes:104]
|  |  | March 31, 2018 |
|  |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 644,273 |  |  | $ | — |  |  | $ | — |  |  | $ | 644,273 |  |
| Money market funds - restricted |  | 5,508 |  |  | — |  |  | — |  |  | 5,508 |  |
| Commercial paper |  | — |  |  | 21,820 |  |  | — |  |  | 21,820 |  |
| U.S. government notes |  | 206,802 |  |  | — |  |  | — |  |  | 206,802 |  |
| Corporate bonds |  | — |  |  | 382,165 |  |  | — |  |  | 382,165 |  |
| Agency securities |  | — |  |  | 241,093 |  |  | — |  |  | 241,093 |  |
| Total financial assets |  | $ | 856,583 |  |  | $ | 645,078 |  |  | $ | — |  |  | $ | 1,501,661 |  |

[0001596532-18-000109:notes:105]
|  |  | December 31, 2017 |
|  |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 701,145 |  |  | $ | — |  |  | $ | — |  |  | $ | 701,145 |  |
| Money market funds - restricted |  | 5,505 |  |  | — |  |  | — |  |  | 5,505 |  |
| Commercial paper |  | — |  |  | 11,924 |  |  | — |  |  | 11,924 |  |
| U.S. government notes |  | 136,647 |  |  | — |  |  | — |  |  | 136,647 |  |
| Corporate bonds |  | — |  |  | 312,484 |  |  | — |  |  | 312,484 |  |
| Agency securities |  | — |  |  | 228,036 |  |  | — |  |  | 228,036 |  |
| Total financial assets |  | $ | 843,297 |  |  | $ | 552,444 |  |  | $ | — |  |  | $ | 1,395,741 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-18-000109:notes:106]
2.    Fair Value Measurements

[0001596532-18-000109:notes:107]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying condensed consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value. We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs. The three-tiers of the fair value hierarchy are as follows:

[0001596532-18-000109:notes:108]
Level I - Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date;

[0001596532-18-000109:notes:109]
Level II - Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities; and

[0001596532-18-000109:notes:110]
Level III - Unobservable inputs that are supported by little or no market data for the related assets or liabilities and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.

[0001596532-18-000109:notes:111]
We measure and report our cash equivalents, restricted cash, and available-for-sale marketable securities at fair value. The following tables set forth the fair value of our financial assets by level within the fair value hierarchy (in thousands):


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-18-000109:notes:112]
8.    Income Taxes

[0001596532-18-000109:notes:113]
|  |  | Three Months Ended March 31, |
|  |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Benefit from income taxes |  | $ | (1,644 | ) |  | $ | (9,233 | ) |
| Effective tax rate |  | (1.2 | )% |  | (12.5 | )% |

[0001596532-18-000109:notes:114]
We had income taxes benefit of $1.6 million and $9.2 million in the three months ended March 31, 2018 and 2017, respectively. The change in the effective tax rate in the three months ended March 31, 2018, as compared to the same period in 2017, was primarily due to the overall increase in earnings and the inclusion of foreign earnings in the U.S. which proportionally exceeded the increase in excess tax benefits attributable to equity compensation.  These changes were all taxed at a lower U.S. corporate tax rate under the Tax Cuts and Jobs Act (the “Tax Act”) passed in December 2017.

[0001596532-18-000109:notes:115]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. Earnings from our non-U.S. activities are subject to local country income tax and may be subject to U.S. income tax.

[0001596532-18-000109:notes:116]
On December 22, 2017, the U.S. government enacted comprehensive tax legislation. The Tax Act makes broad and complex changes to the U.S. tax code, including, but not limited to, (1) reducing the U.S. federal corporate tax rate from 35 percent to 21 percent; (2) requiring companies to pay a one-time transition tax on certain unrepatriated earnings of foreign subsidiaries; (3) generally eliminating U.S. federal income taxes on dividends from foreign subsidiaries; (4) requiring a current inclusion in U.S. federal taxable income of certain earnings of controlled foreign corporations; and (5) creating the base erosion anti-abuse tax (“BEAT”), a new minimum tax.

[0001596532-18-000109:notes:117]
The Tax Act includes provisions for Global Intangible Low-Taxed Income (“GILTI”) wherein taxes on foreign income are imposed in excess of a deemed return on tangible assets of foreign corporations. This income will effectively be taxed at a 10.5% tax rate in general. Our deferred tax assets and liabilities are still being evaluated to determine if they should be recognized for the basis differences expected to reverse as a result of GILTI provisions that are effective for us after the calendar year ending December 31, 2017. Because of the complexity of the new provisions, we are continuing to evaluate how the provisions will be accounted for under the U.S. GAAP wherein companies are allowed to make an accounting policy election of either (i) account for GILTI as a component of tax expense in the period in which we are subject to the rules (the “period cost method”), or (ii) account for GILTI in our measurement of deferred taxes (the “deferred method”). Currently, we have not elected a method but we have included an estimate of the impact to our effective tax rate for the year ended December 31, 2018.  A formal election will only be made  after our completion of the analysis of the GILTI provisions and our election method will depend, in part, on analyzing our global income to determine whether we expect to have future U.S. inclusions in our taxable income related to GILTI and, if so, the impact that is expected.

[0001596532-18-000109:notes:118]
As of March 31, 2018, we have not yet completed our accounting for the tax effects of the enactment of the Tax Act.  We recognized a provisional tax amount of $51.8 million in the fourth quarter of 2017 for the transition tax liability and the revaluation of our deferred income taxes as a result of the rate change. In the three months ended March 31, 2018, we did not revise this estimate.  In addition, we recorded a reasonable estimate for the effect of the new legislation as discussed above, which impacts the US income tax liabilities for the year ending December 31, 2018. Our estimates may also be affected as we gain a more thorough understanding of the tax law. These changes could be material to income tax expense. We will continue to refine our estimates related to the impact of the Tax Act during the one year measurement period allowed under Staff Accounting Bulletin 118 (“SAB 118”).

[0001596532-18-000109:notes:119]
We have been selected for examination by the Internal Revenue Service (“IRS”) for our 2014 tax year.  It is difficult to determine when the examinations will be settled or their final outcomes in the foreseeable future. We believe that we have adequately provided reserves for any reasonably foreseeable adjustment to our tax returns.


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-18-000109:notes:120]
4.    Investments

[0001596532-18-000109:notes:121]
Investments in Privately-Held Companies

[0001596532-18-000109:notes:122]
We adopted ASU 2016-01 in the three months ended March 31, 2018. See Note 1. As of March 31, 2018 and December 31, 2017, we held non-marketable equity investments of approximately $36.1 million in privately-held companies. Such equity investments do not have readily determinable fair values. To date, we have not recorded any adjustments to the carrying amounts of our equity investments resulting from impairment or observable price changes in orderly transactions for identical or similar investments of the same issuer.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-18-000109:notes:123]
Recently Adopted Accounting Pronouncements

[0001596532-18-000109:notes:124]
Revenue Recognition

[0001596532-18-000109:notes:125]
During May 2014, the Financial Accounting Standards Board (“FASB”) issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606). In 2016, the FASB issued ASU No. 2016-08, ASU No. 2016-10 and ASU No. 2016-12, which provide interpretive clarifications on the new guidance in Topic 606 (collectively, “the new standard”). Under the new standard, the recognition of revenue is based on consideration we expect to be entitled to from the transfer of goods or services to a customer.

[0001596532-18-000109:notes:126]
The primary impact of the new standard is related to the deferral of incremental commission costs of obtaining customer service contracts, which were previously expensed as incurred. Under the new standard, we defer all such costs and amortize them over the expected period of benefit. The new standard also requires companies to account for termination clauses at the onset of an arrangement. While there is limited history of cancellations, our prepaid subscription offerings are generally cancellable by customers with 30 days’ notice, therefore, the subscription contracts are considered month-to-month. While these prepaid amounts have historically been recorded to deferred revenue, the new standard requires that we record these amounts as other liabilities.  In addition, the new standard may impact the amount and timing of revenue recognition of certain sales arrangements and the related disclosures on our consolidated financial statements.

[0001596532-18-000109:notes:127]
We adopted the new standard in our first quarter of 2018 using the modified retrospective method, which resulted in a cumulative effect adjustment of $3.5 million that increased retained earnings to capitalize certain commission costs that were expensed in the prior year. Correspondingly, we increased prepaid expenses and other current assets by $2.0 million, other assets by $2.2 million, and decreased deferred tax assets by $0.7 million as of January 1, 2018. In addition, we reclassified $16.5 million of deferred revenue as of January 1, 2018 to other current liabilities and other long-term liabilities related to our prepaid subscription offerings. The impact of adopting the new standard was not material to our financial results for the three months ended March 31, 2018 and we do not expect the impact to the financial results for our fiscal 2018 to be material.

[0001596532-18-000109:notes:128]
We apply a practical expedient to expense costs as incurred for costs to obtain a contract with a customer when the amortization period would have been one year or less, as well as the portfolio approach for the contracts reviewed. These costs include a portion of our sales force compensation program as we have determined annual compensation is commensurate with recurring sales activities.

[0001596532-18-000109:notes:129]
Financial Instruments

[0001596532-18-000109:notes:130]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which enhances the reporting model for financial instruments to provide users of financial statements with more decision-useful information. In February 2018, the FASB issued ASU 2018-03, Technical Corrections and Improvements to Financial Instruments, to clarify certain aspects of ASU 2016-01. ASU 2016-01 and ASU 2018-03 (collectively, the “new guidance”) address certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. We adopted this new guidance in our first quarter of fiscal 2018. Under the new guidance, there was no change in the accounting of our marketable securities as our investment policy only allows investments in debt securities. For our cost method equity investments in privately-held companies without readily determinable fair value, we elected to use the measurement alternative, defined as cost, less impairments, as adjusted up or down based on observable price changes in orderly transactions for identical or similar investments of the same issuer, which was adopted prospectively. Adjustments resulting from impairments and/or observable price changes are to be recorded as other income (expense) on a prospective basis.

[0001596532-18-000109:notes:131]
Based on our assessment under the new guidance, there was no impact on our condensed consolidated financial statements from the adoption of the new guidance in the first quarter of 2018. However, the carrying amount of our equity investments and any related gain or loss may fluctuate in the future as a result of the re-measurement of such equity investments upon the occurrence of observable price changes and/or impairments.

[0001596532-18-000109:notes:132]
Income Taxes on Intra-Entity Transfers of Assets

[0001596532-18-000109:notes:133]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which addresses recognition of current and deferred income taxes for intra-entity asset transfers when assets are sold to an outside party. Current GAAP prohibits the recognition of current and deferred income taxes until the asset has been sold to an outside party. This prohibition on recognition is considered an exception to the principle of comprehensive recognition of current and deferred income taxes in GAAP. The new guidance requires an entity to recognize the income tax consequences when the transfer occurs eliminating the exception. The guidance must be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. We adopted this guidance in our first quarter of fiscal 2018. As a result, we recognized a cumulative effect adjustment in the condensed consolidated balance sheet as of March 31, 2018 by increasing the beginning balance of the retained earnings and the deferred tax assets by approximately $0.1 million, respectively.

[0001596532-18-000109:notes:134]
Restricted Cash in Statement of Cash Flows

[0001596532-18-000109:notes:135]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force, which requires that amounts generally described as restricted cash or restricted cash equivalents be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows.  This standard is required to be applied using a retrospective transition method to each period presented.  We retrospectively adopted ASU 2016-18 in our first quarter of fiscal 2018. As a result of the adoption, we adjusted the condensed consolidated statement of cash flows for the three months ended March 31, 2017 to increase the beginning-of-period and end-of-period cash amounts by $4.2 million and $5.5 million, respectively, and to decrease net cash used in investing activities by $1.3 million.

[0001596532-18-000109:notes:136]
Recent Accounting Pronouncements Not Yet Effective

[0001596532-18-000109:notes:137]
Leases

[0001596532-18-000109:notes:138]
In February 2016, the FASB issued ASU No, 2016-02, Leases. Under the guidance, lessees are required to recognize assets and lease liabilities on the balance sheet for most leases including operating leases and provide enhanced disclosures. There are optional practical expedients that a company may elect to apply. The guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years and may be early adopted.  As currently issued, companies are required to adopt this guidance to the earliest period presented using a modified retrospective approach. We are in the process of reviewing our existing lease agreements to assess the impact this guidance may have on our consolidated financial statements. We currently anticipate that the adoption of ASU 2016-02 will materially affect our consolidated balance sheets by recognizing new right-of-use assets and lease liabilities for operating leases, but will not have a material impact on our consolidated income statements.

[0001596532-18-000109:notes:139]
Credit Losses of Financial Instruments

[0001596532-18-000109:notes:140]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. Credit losses relating to available-for-sale debt securities should be recorded through an allowance for credit losses. This standard is effective for us for our first quarter of 2020. We are currently assessing the impact this guidance may have on our consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-18-000109:notes:141]
1.    Organization and Summary of Significant Accounting Policies

[0001596532-18-000109:notes:142]
Organization

[0001596532-18-000109:notes:143]
[same as prior period, unchanged from 0001596532-17-000251:notes:143]

[0001596532-18-000109:notes:144]
[same as prior period, unchanged from 0001596532-17-000251:notes:144]

[0001596532-18-000109:notes:145]
[same as prior period, unchanged from 0001596532-17-000251:notes:145]

[0001596532-18-000109:notes:146]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; valuation of inventory and contract manufacturer/supplier liabilities; recognition and measurement of contingent liabilities; valuation of equity investments; determination of fair value for stock-based awards; and valuation of warranty accruals. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.

[0001596532-18-000109:notes:147]
Significant Accounting Policies

[0001596532-18-000109:notes:148]
During the three months ended March 31, 2018, we adopted several recent accounting pronouncements as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1. As a result, we updated certain significant accounting policies as described below. There have been no other significant changes to our accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

[0001596532-18-000109:notes:149]
Investments

[0001596532-18-000109:notes:150]
Effective January 1, 2018, we adopted a new revenue recognition policy in accordance with ASC 606 using the modified retrospective method as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1.  Prior to 2018, our revenue recognition policy was based on ASC 605 Revenue Recognition, and is described in Note 1 of Notes to Consolidated Financial Statements under Item 8 of our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

[0001596532-18-000109:notes:151]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with post-contract customer support (“PCS”). We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

[0001596532-18-000109:notes:152]
| • | Identification of the contract, or contracts, with a customer |

[0001596532-18-000109:notes:153]
| • | Identification of the performance obligations in the contract |

[0001596532-18-000109:notes:154]
| • | Determination of the transaction price |

[0001596532-18-000109:notes:155]
| • | Allocation of the transaction price to the performance obligations in the contract |

[0001596532-18-000109:notes:156]
| • | Recognition of revenue when (or as) we satisfy the performance obligation |

[0001596532-18-000109:notes:157]
Post-Contract Customer Support

[0001596532-18-000109:notes:158]
Post-contract support, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernable pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and addresses customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-18-000109:notes:159]
Contracts with Multiple Performance Obligations

[0001596532-18-000109:notes:160]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts which contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is required to determine the SSP for each distinct performance obligation.  We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

[0001596532-18-000109:notes:161]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services are sold, and the size of the end customer.

[0001596532-18-000109:notes:162]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

[0001596532-18-000109:notes:163]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

[0001596532-18-000109:notes:164]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-18-000109:notes:165]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

[0001596532-18-000109:notes:166]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

[0001596532-18-000109:notes:167]
Assets Recognized from Costs to Obtain a Contract with a Customer

[0001596532-18-000109:notes:168]
Effective January 1, 2018 in accordance with ASC 606, we recognize an asset for the incremental costs of obtaining a contract with a customer if we expect the benefit of those costs to be longer than one year. We have determined that certain sales commissions earned by our sales force meet the requirements to be capitalized. These costs are deferred and then amortized over a period of benefit that we have determined to be five years. Total capitalized costs to obtain a contract are included in other current and long-term assets on our consolidated balance sheets.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001596532-18-000109:notes:169]
[same as prior period, unchanged from 0001596532-17-000251:notes:148]

[0001596532-18-000109:notes:170]
|  |  | March 31, 2018 |  | December 31, 2017 |
| Equipment and machinery |  | $ | 49,470 |  |  | $ | 47,711 |  |
| Computer hardware and software |  | 24,048 |  |  | 22,124 |  |
| Furniture and fixtures |  | 3,063 |  |  | 3,020 |  |
| Leasehold improvements |  | 30,567 |  |  | 30,548 |  |
| Building |  | 35,154 |  |  | 35,154 |  |
| Construction-in-process |  | 5,549 |  |  | 4,742 |  |
| Property and equipment, gross |  | 147,851 |  |  | 143,299 |  |
| Less: accumulated depreciation |  | (74,026 | ) |  | (69,020 | ) |
| Property and equipment, net |  | $ | 73,825 |  |  | $ | 74,279 |  |


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001596532-18-000109:notes:171]
Accounts Receivable, Net

[0001596532-18-000109:notes:172]
[same as prior period, unchanged from 0001596532-17-000251:notes:150]

[0001596532-18-000109:notes:173]
|  |  | March 31, 2018 |  | December 31, 2017 |
| Accounts receivable |  | $ | 214,977 |  |  | $ | 254,881 |  |
| Allowance for doubtful accounts |  | (149 | ) |  | (112 | ) |
| Product sales rebate and returns reserve |  | (7,489 | ) |  | (7,423 | ) |
| Accounts receivable, net |  | $ | 207,339 |  |  | $ | 247,346 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001596532-18-000109:notes:174]
[same as prior period, unchanged from 0001596532-17-000251:notes:152]

[0001596532-18-000109:notes:175]
|  |  | March 31, 2018 |  | December 31, 2017 |
| Accrued payroll related costs |  | $ | 28,773 |  |  | $ | 56,626 |  |
| Accrued manufacturing costs |  | 27,924 |  |  | 35,703 |  |
| Accrued product development costs |  | 10,520 |  |  | 21,201 |  |
| Accrued warranty costs |  | 7,434 |  |  | 7,415 |  |
| Accrued professional fees |  | 5,751 |  |  | 7,086 |  |
| Accrued taxes |  | 690 |  |  | 794 |  |
| Other |  | 4,636 |  |  | 5,002 |  |
| Total accrued liabilities |  | $ | 85,728 |  |  | $ | 133,827 |  |


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001596532-18-000109:notes:176]
The following table summarizes the unrealized gains and losses and fair value of our available-for-sale marketable securities (in thousands):

[0001596532-18-000109:notes:177]
|  |  | March 31, 2018 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 21,820 |  |  | $ | — |  |  | $ | — |  |  | $ | 21,820 |  |
| U.S. government notes |  | 207,359 |  |  | — |  |  | (557 | ) |  | 206,802 |  |
| Corporate bonds |  | 384,229 |  |  | 1 |  |  | (2,065 | ) |  | 382,165 |  |
| Agency securities |  | 242,114 |  |  | — |  |  | (1,021 | ) |  | 241,093 |  |
| Total marketable securities |  | $ | 855,522 |  |  | $ | 1 |  |  | $ | (3,643 | ) |  | $ | 851,880 |  |

[0001596532-18-000109:notes:178]
|  |  | December 31, 2017 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 11,924 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,924 |  |
| U.S. government notes |  | 137,025 |  |  | — |  |  | (378 | ) |  | 136,647 |  |
| Corporate bonds |  | 313,080 |  |  | 20 |  |  | (616 | ) |  | 312,484 |  |
| Agency securities |  | 215,923 |  |  | 2 |  |  | (617 | ) |  | 215,308 |  |
| Total marketable securities |  | $ | 677,952 |  |  | $ | 22 |  |  | $ | (1,611 | ) |  | $ | 676,363 |  |


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001596532-18-000109:notes:179]
The following table is a reconciliation of cash, cash equivalents and restricted cash reported within the accompanying condensed consolidated balance sheets that sum to the total of the same such amounts shown in the accompanying condensed consolidated statements of cash flows (in thousands):

[0001596532-18-000109:notes:180]
|  |  | March 31, 2018 |  | March 31, 2017 |
| Cash and cash equivalents |  | $ | 886,160 |  |  | $ | 746,567 |  |
| Restricted cash included in other assets |  | 5,508 |  |  | 5,497 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 891,668 |  |  | $ | 752,064 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001596532-18-000109:notes:181]
[same as prior period, unchanged from 0001596532-17-000251:notes:157]

[0001596532-18-000109:notes:182]
|  |  | March 31, 2018 |  | December 31, 2017 |
| Raw materials |  | $ | 62,305 |  |  | $ | 69,673 |  |
| Finished goods |  | 205,826 |  |  | 236,525 |  |
| Total inventories |  | $ | 268,131 |  |  | $ | 306,198 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001596532-18-000109:notes:183]
Prepaid expenses and other current assets consists of the following (in thousands):

[0001596532-18-000109:notes:184]
|  |  | March 31, 2018 |  | December 31, 2017 |
| Inventory deposit |  | $ | 24,423 |  |  | $ | 34,141 |  |
| Prepaid income taxes |  | 41,048 |  |  | 38,134 |  |
| Other current assets |  | 82,837 |  |  | 96,215 |  |
| Other prepaid expenses and deposits |  | 17,356 |  |  | 8,840 |  |
| Total prepaid expenses and other current assets |  | $ | 165,664 |  |  | $ | 177,330 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001596532-18-000109:notes:185]
[same as prior period, unchanged from 0001596532-17-000251:notes:161]

[0001596532-18-000109:notes:186]
|  |  | Three Months Ended March 31, |
|  |  | 2018 |  | 2017 |
| Warranty accrual, beginning of period |  | $ | 7,415 |  |  | $ | 6,744 |  |
| Liabilities accrued for warranties issued during the period |  | 1,557 |  |  | 1,859 |  |
| Warranty costs incurred during the period |  | (1,538 | ) |  | (945 | ) |
| Warranty accrual, end of period |  | $ | 7,434 |  |  | $ | 7,658 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001596532-18-000109:notes:187]
[same as prior period, unchanged from 0001596532-17-000251:notes:163]

[0001596532-18-000109:notes:188]
|  |  | Three Months Ended March 31, |
|  |  | 2018 |  | 2017 |
| Americas |  | $ | 315,498 |  |  | $ | 264,863 |  |
| Europe, Middle East and Africa |  | 121,886 |  |  | 42,734 |  |
| Asia-Pacific |  | 35,105 |  |  | 27,878 |  |
| Total revenue |  | $ | 472,489 |  |  | $ | 335,475 |  |

[0001596532-18-000109:notes:189]
Long-lived assets, excluding intercompany receivables, investments in subsidiaries, privately-held equity investments and deferred tax assets, net by location are summarized as follows (in thousands):

[0001596532-18-000109:notes:190]
|  |  | March 31, 2018 |  | December 31, 2017 |
| United States |  | $ | 68,277 |  |  | $ | 69,128 |  |
| International |  | 5,548 |  |  | 5,151 |  |
| Total |  | $ | 73,825 |  |  | $ | 74,279 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-18-000109:notes:191]
9.    Segment Information

[0001596532-18-000109:notes:192]
[same as prior period, unchanged from 0001596532-17-000251:notes:168]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-18-000109:notes:193]
3.    Financial Statements Details

[0001596532-18-000109:notes:194]
Cash, Cash Equivalents and Restricted Cash

[0001596532-18-000109:notes:195]
Restricted cash included in other assets as of March 31, 2018 and March 31, 2017 primarily included $4.0 million pledged as collateral representing a security deposit required for a facility lease and $1.1 million related to a letter of credit issued to a business partner.

[0001596532-18-000109:notes:196]
[same as prior period, unchanged from 0001596532-17-000251:notes:170]

[0001596532-18-000109:notes:197]
We did not realize any other-than-temporary losses on our marketable securities for the three months ended March 31, 2018 and 2017. We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. As interest rates increase, those marketable securities purchased at a lower yield show a mark-to-market unrealized loss. The unrealized losses are due primarily to changes in credit spreads and interest rates. We expect to realize the full value of these investments upon maturity or sale and therefore, we do not consider any of our marketable securities to be other-than-temporarily impaired as of March 31, 2018.

[0001596532-18-000109:notes:198]
As of March 31, 2018, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale investments, by remaining contractual maturity, are as follows (in thousands):

[0001596532-18-000109:notes:199]
The weighted-average remaining duration of our current marketable securities is approximately 0.8 years as of March 31, 2018.  As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying unaudited condensed consolidated balance sheets.

[0001596532-18-000109:notes:200]
[same as prior period, unchanged from 0001596532-17-000251:notes:175]

[0001596532-18-000109:notes:201]
[same as prior period, unchanged from 0001596532-17-000251:notes:176]

[0001596532-18-000109:notes:202]
Property and Equipment, Net

[0001596532-18-000109:notes:203]
Depreciation expense was $5.3 million and $4.8 million for the three months ended March 31, 2018 and 2017, respectively.

[0001596532-18-000109:notes:204]
[same as prior period, unchanged from 0001596532-17-000251:notes:179]

[0001596532-18-000109:notes:205]
[same as prior period, unchanged from 0001596532-17-000251:notes:180]

[0001596532-18-000109:notes:206]
Deferred Revenue and Performance Obligations

[0001596532-18-000109:notes:207]
Deferred revenue is comprised mainly of unearned revenue related to multi-year PCS contracts, services and product deferrals related to acceptance clauses. During the three months ended March 31, 2018 and 2017, $159.4 million and $171.4 million of deferred revenue was recognized, respectively, which was included in the deferred revenue balances at the beginning of the respective periods.

[0001596532-18-000109:notes:208]
Transaction Price Allocated to the Remaining Performance Obligations

[0001596532-18-000109:notes:209]
As of March 31, 2018, approximately $475.0 million of revenue is expected to be recognized from remaining performance obligations for product and PCS contracts. We expect to recognize revenue on approximately 82% of these remaining performance obligations over the next 2 years and 18% during the 3rd to the 5th year. The remaining performance obligations as of March 31, 2018 included $18.8 million related to our prepaid subscription offerings which are recorded as other liabilities.
