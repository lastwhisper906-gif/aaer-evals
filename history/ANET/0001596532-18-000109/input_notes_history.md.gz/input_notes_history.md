# ANET note change history — 0001596532-17-000251 → 0001596532-18-000109


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-04):
[0001596532-18-000109:note_history:1]
5.    Commitments and Contingencies
  (was, 2017-11-03, similarity 0.9667):
[0001596532-17-000251:note_history:1]
Commitments and Contingencies

- added (2018-05-04):
[0001596532-18-000109:note_history:2]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2025. There have been no material changes in our future minimum payment obligations under our operating leases that existed as of December 31, 2017, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2017, except as follows. During the three months ended March 31, 2018, we entered into new leases primarily related to additional data center capacity and co-location services. As of March 31, 2018, the total minimum future payment commitment under these new leases was approximately $43.6 million, of which $0.5 million is due in 2018, with the remainder due in 2021 through 2028.

- added (2018-05-04):
[0001596532-18-000109:note_history:3]
We recognize rent expense under these arrangements on a straight-line basis over the term of the leases. For the three months ended March 31, 2018 and 2017, rent expense for all operating leases amounted to $2.5 million and $2.4 million, respectively.

- added (2018-05-04):
[0001596532-18-000109:note_history:4]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013. The lease is accounted for as a financing obligation and the lease payments are attributed to (1) a reduction of the principal financing obligation; (2) imputed interest expense; and (3) land lease expense, representing an imputed cost to lease the underlying land of the building. There have been no material changes in our future minimum payment obligations under this financing lease, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2017. Land lease expense related to our lease financing obligation is classified as rent expense in our unaudited condensed consolidated statements of income, and amounted to $0.3 million for the three months ended March 31, 2018 and 2017.

- changed (2018-05-04):
[0001596532-18-000109:note_history:5]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished product and a significant portion of these orders consist of firm non-cancelable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancelable, including integrated circuits, which are consigned to our contract manufacturers. As of March 31, 2018, we had non-cancellable purchase commitments of $251.1 million, of which $197.7 million was to our contract manufacturers and suppliers. We have not recorded a liability related to these purchase commitments. In addition, we have provided deposits to secure our obligations to purchase inventory. We had $27.2 million and $36.9 million in deposits as of March 31, 2018 and December 31, 2017, respectively. These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.
  (was, 2017-11-03, similarity 0.6603):
[0001596532-17-000251:note_history:5]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply.  We issue purchase orders to our contract manufacturers for finished product and a significant portion of these orders consist of firm non-cancelable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancelable, including integrated circuits, which are consigned to our contract manufacturers.   As of September 30, 2017, we had non-cancelable purchase commitments of $131.8 million.  In addition, we have provided deposits to secure our obligations to purchase inventory. We had $34.7 million and $63.1 million in deposits as of September 30, 2017 and December 31, 2016, respectively. These deposits are classified in other current and long term assets in our accompanying unaudited condensed consolidated balance sheets.

- changed (2018-05-04):
[0001596532-18-000109:note_history:6]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.
  (was, 2017-11-03, similarity 0.9994):
[0001596532-17-000251:note_history:6]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for lease facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

- changed (2018-05-04):
[0001596532-18-000109:note_history:7]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft access to our software for evaluation by OptumSoft; (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches; (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers; (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us; and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors, who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dated July 28, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.
  (was, 2017-11-03, similarity 0.9979):
[0001596532-17-000251:note_history:7]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft access to our software for evaluation by OptumSoft; (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches; (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers; (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us; and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit.  David Cheriton, one of our founders and a former member of our board of directors, who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft.  The 2010 David R. Cheriton Irrevocable Trust dtd July 28, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.

- changed (2018-05-04):
[0001596532-18-000109:note_history:8]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On December 16, 2015, the Court issued a Proposed Statement of Decision Following Phase 1 Trial, and on January 8, 2016, OptumSoft filed objections to that Proposed Statement of Decision. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II including the application of the Court’s interpretation of the 2004 agreement as set forth in the Final Statement of Decision Following Phase I Trial to any other source code that OptumSoft claims to own following a review. The Phase II Trial is set to begin on March 4, 2019.
  (was, 2017-11-03, similarity 0.912):
[0001596532-17-000251:note_history:8]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015.  On December 16, 2015, the Court issued a Proposed Statement of Decision Following Phase 1 Trial, and on January 8, 2016, OptumSoft filed objections to that Proposed Statement of Decision.  On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I.  The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II including the application of the Court’s interpretation of the 2004 agreement as set forth in the Final Statement of Decision Following Phase I Trial to any other source code that OptumSoft claims to own following a review.  Phase II was previously scheduled to be tried in April 2016; however, that trial date has been vacated and a new trial date has not yet been set.

- added (2018-05-04):
[0001596532-18-000109:note_history:9]
On March 6, 2018, the Court issued an order directing the parties to file a joint status report updating the Court on the progress of the 944 and 945 Investigations (as defined below) and when the parties expected the stay of the ’43 Case might be lifted or the case dismissed. In Cisco’s portion of the joint status report, Cisco proposed that the judge lift the stay as to the ’597, ’164, ’592, ’145, ’492, ’296, and ’875 patents. We opposed Cisco’s proposal. The judge has not yet responded to Cisco’s proposal, and the stay on the ’43 Case currently remains in place.

- changed (2018-05-04):
[0001596532-18-000109:note_history:10]
As described below, on May 25, 2016, our petition for Inter Partes Review (“IPR”) of the ’886 patent was instituted by the United States Patent Trial and Appeal Board (“PTAB”). Cisco subsequently agreed to dismiss its claims as to the ’886 patent with prejudice.
  (was, 2017-11-03, similarity 0.996):
[0001596532-17-000251:note_history:10]
As described below, on May 25, 2016, our petition for Inter Partes Review (“IPR”) of the ’886 patent was instituted by the United States Patent Trial and Appeal Board (“PTAB”).  Cisco subsequently agreed to dismiss its claims as to the ‘886 patent with prejudice.

- changed (2018-05-04):
[0001596532-18-000109:note_history:11]
On December 14, 2016, following a two-week trial, a jury found that we had proven our copyright defense of scenes a faire and that Cisco had failed to prove infringement of the ’526 patent. On that basis, judgment was entered in our favor on all claims on December 19, 2016.
  (was, 2017-11-03, similarity 0.979):
[0001596532-17-000251:note_history:11]
On December 14, 2016, following a two-week trial, the jury found that we had proven our copyright defense of scenes a faire and that Cisco had failed to prove infringement of the ’526 patent, and on that basis judgment was entered in our favor on all claims on December 19, 2016.

- added (2018-05-04):
[0001596532-18-000109:note_history:12]
Cisco filed a notice of appeal on June 6, 2017. Cisco did not appeal the jury’s noninfringement verdict on the ‘526 patent but did appeal the jury’s finding that we established the defense of scenes a faire. The parties have submitted their appeal briefs to the U.S. Court of Appeals of the Federal Circuit (“Federal Circuit”). The Federal Circuit has not set a date for oral argument.

- changed (2018-05-04):
[0001596532-18-000109:note_history:13]
On February 24, 2016, we filed a complaint against Cisco in the District Court for the Northern District of California alleging antitrust violations and unfair competition. On August 23, 2016, the Court granted Cisco’s motion to stay the ’23 Case until judgment was entered on Cisco’s copyright claims in the ’44 Case. On March 2, 2017, the Court lifted the stay.
  (was, 2017-11-03, similarity 0.9541):
[0001596532-17-000251:note_history:13]
On February 24, 2016, we filed a complaint against Cisco in the District Court for the Northern District of California alleging antitrust violations and unfair competition.  On August 23, 2016, the Court granted Cisco’s motion to stay the ’23 Case until judgment was entered on Cisco’s copyright claims in the ’44 Case.  On March 2, 2017, the Court lifted the stay and trial is set for August 3, 2018.

- changed (2018-05-04):
[0001596532-18-000109:note_history:14]
On March 23, 2017, Cisco filed a motion to dismiss our complaint in the ’23 Case. On October 10, 2017, the Court issued an order granting in part and denying in part Cisco’s motion to dismiss, with leave for us to amend to cure any deficiencies as to the claims that were dismissed. On October 31, 2017, we filed an amended complaint, and on November 14, 2017, Cisco filed its answer.  On February 14, 2018, the Court struck certain defenses asserted by Cisco.  Both Cisco and we have filed pretrial motions, including motions for summary judgment, and the trial is set for August 3, 2018.
  (was, 2017-11-03, similarity 0.6561):
[0001596532-17-000251:note_history:14]
On March 23, 2017, Cisco filed a motion to dismiss our complaint in the ’23 Case.  On October 10, 2017, the Court issued an order granting in part and denying in part Cisco’s motion to dismiss, with leave for us to amend to cure any deficiencies as to the claims that were dismissed.

- changed (2018-05-04):
[0001596532-18-000109:note_history:15]
On February 2, 2016, the Administrative Law Judge (“ALJ”) issued his initial determination finding a violation of Section 337. More specifically, the ALJ found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringed asserted claims 1, 2, 8-11, and 17-19 of the ’537 patent; asserted claims 6, 7, 20, and 21 of the ’592 patent; and asserted claims 5, 7, 45, and 46 of the ’145 patent. The ALJ did not find a violation of Section 337 with respect to any asserted claims of the ’597 and ’164 patents. On June 23, 2016, the USITC issued its Final Determination, which found a violation with respect to the ’537, ’592, and ’145 patents, and found no violation with respect to the ’597 and ’164 patents. The USITC also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software and components thereof that infringe one or more of claims 1, 2, 8-11, and 17-19 of the ’537 patent; claims 6, 7, 20, and 21 of the ’592 patent; and claims 5, 7, 45, and 46 of the ’145 patent. On August 22, 2016, the Presidential review period for the 944 Investigation expired. The USITC orders will be in effect until the expiration of the ’537, ’592, and ’145 patents.
  (was, 2017-11-03, similarity 0.9885):
[0001596532-17-000251:note_history:15]
On February 2, 2016, the Administrative Law Judge (“ALJ”) issued his initial determination finding a violation of Section 337.  More specifically, the ALJ found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringed asserted claims 1, 2, 8-11, and 17-19 of the ’537 patent; asserted claims 6, 7, 20, and 21 of the ’592 patent; and asserted claims 5, 7, 45, and 46 of the ’145 patent.  The ALJ did not find a violation of Section 337 with respect to any asserted claims of the ’597 and ’164 patents.  On June 23, 2016, the Commission issued its Final Determination, which found a violation with respect to the ’537, ’592, and ’145 patents, and found no violation with respect to the ’597 and ’164 patents.  The Commission also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software and components thereof that infringe one or more of claims 1, 2, 8-11, and 17-19 of the ’537 patent; claims 6, 7, 20, and 21 of the ’592 patent; and claims 5, 7, 45, and 46 of the ’145 patent.  On August 22, 2016, the Presidential review period for the 944 Investigation expired.  The USITC orders will be in effect until the expiration of the ’537, ’592, and ’145 patents.

- changed (2018-05-04):
[0001596532-18-000109:note_history:16]
Both we and Cisco filed petitions for review of the USITC’s Final Determination to the Federal Circuit. The appeal was fully briefed and oral argument was held on June 6, 2017. On September 27, 2017, the Federal Circuit affirmed the USITC’s Final Determination.
  (was, 2017-11-03, similarity 0.8545):
[0001596532-17-000251:note_history:16]
Both we and Cisco filed petitions for review of the USITC’s Final Determination to the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”).  The appeal was fully briefed and oral argument was held on June 6, 2017.  On September 27, 2017, the Federal Circuit affirmed the USITC’s Final Determination.

- changed (2018-05-04):
[0001596532-18-000109:note_history:17]
On August 26, 2016, Cisco filed an enforcement complaint under Section 337 with the USITC. Cisco alleges that we are violating the cease and desist and limited exclusion orders issued in the 944 Investigation by engaging in the “marketing, distribution, offering for sale, selling, advertising, and/or aiding or abetting other entities in the sale and/or distribution of products that Cisco alleges continue to infringe claims 1-2, 8-11, and 17-19 of the ’537 patent,” despite the design changes we have made to those products. Cisco asks the USITC to (1) enforce the cease and desist order; (2) modify the USITC’s limited exclusion order and/or cease and desist order “in any manner that would assist in the prevention of the unfair practices that were originally the basis for issuing such Order or assist in the detection of violations of such Order”; (3) impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000 or twice the domestic value of the articles entered or sold, whichever is higher”; (4) bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order”; and (5) impose “such other remedies and sanctions as are appropriate and within the USITC’s authority.” On September 28, 2016, the USITC instituted the enforcement proceeding. The proceeding has been assigned to ALJ Shaw, who presided over the underlying investigation. The target date for the investigation was initially set for September 20, 2017. On June 20, 2017, the ALJ issued his initial determination finding that we did not violate the June 23, 2016 cease and desist order. The initial determination also recommended a civil penalty of $307 million if the USITC decided to overturn the finding of no violation. On July 3, 2017, the parties filed petitions for review of certain findings in the initial determination.
  (was, 2017-11-03, similarity 0.9837):
[0001596532-17-000251:note_history:17]
On August 26, 2016, Cisco filed an enforcement complaint under Section 337 with the USITC.  Cisco alleges that we are violating the cease and desist and limited exclusion orders issued in the 944 Investigation by engaging in the “marketing, distribution, offering for sale, selling, advertising, and/or aiding or abetting other entities in the sale and/or distribution of products that Cisco alleges continue to infringe claims 1-2, 8-11, and 17-19 of the ’537 patent,” despite the design changes we have made to those products.  Cisco asks the USITC to (1) enforce the cease and desist order; (2) modify the Commission’s limited exclusion order and/or cease and desist order “in any manner that would assist in the prevention of the unfair practices that were originally the basis for issuing such Order or assist in the detection of violations of such Order”; (3) impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000 or twice the domestic value of the articles entered or sold, whichever is higher”; (4) bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order”; and (5) impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.”  On September 28, 2016, the Commission instituted the enforcement proceeding.  The proceeding has been assigned to ALJ Judge Shaw, who presided over the underlying investigation.  The target date for the investigation was initially set for September 20, 2017.  On June 20, 2017, the ALJ issued his initial determination finding that we did not violate the June 23, 2016 cease and desist order.  The initial determination also recommended a civil penalty of $307 million if the Commission decided to overturn the finding of no violation.  On July 3, 2017, the parties filed petitions for review of certain findings in the initial determination.

- changed (2018-05-04):
[0001596532-18-000109:note_history:18]
On August 4, 2017, the USITC issued an order remanding the investigation to the ALJ to make additional findings on certain issues and issue a remand initial determination. The USITC ordered the ALJ to set a schedule for completion of any necessary remand proceedings and a new target date for the enforcement action (the “944 Enforcement Action”). On August 25, 2017 the ALJ issued an Initial Determination setting a June 4, 2018 deadline for the remand initial determination and September 4, 2018 as the new target date for the enforcement action. On September 18, 2017, the USITC determined not to review the Initial Determination setting the target date.  The ALJ held a hearing on February 1, 2018.
  (was, 2017-11-03, similarity 0.8683):
[0001596532-17-000251:note_history:18]
On August 4, 2017, the Commission issued an order remanding the investigation to the ALJ to make additional findings on certain issues and issue a remand initial determination.  The Commission ordered the ALJ to set a schedule for completion of any necessary remand proceedings and a new target date for the enforcement action.  On August 25, 2017 the ALJ issued an Initial Determination setting a June 4, 2018 deadline for the remand initial determination and September 4, 2018 as the new target date for the enforcement action.  The ALJ also set a briefing schedule and a February 1, 2018 hearing.  On September 18, 2017, the Commission determined not to review the Initial Determination setting the target date.

- changed (2018-05-04):
[0001596532-18-000109:note_history:19]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated Section 337. The USITC instituted Cisco’s complaint as Investigation No. 337-TA-945. Cisco alleged that certain of our switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents. Cisco sought, among other things, a limited exclusion order barring entry into the United States of accused switch products (including our 7000 Series of switches) related software, and components therein and a cease and desist order against us restricting our activities with respect to our imported accused switch products and components and software therein.
  (was, 2017-11-03, similarity 0.9255):
[0001596532-17-000251:note_history:19]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated Section 337.  The USITC instituted Cisco’s complaint as Investigation No. 337-TA-945.  Cisco alleges that certain of our switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents.  Cisco seeks, among other things, a limited exclusion order barring entry into the United States of accused switch products (including our 7000 Series of switches) related software, and components thereof and a cease and desist order against us restricting our activities with respect to our imported accused switch products, related software, and components thereof.

- changed (2018-05-04):
[0001596532-18-000109:note_history:20]
On December 9, 2016, the ALJ issued her initial determination finding a violation of Section 337. More specifically, the ALJ found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringe asserted claims 1, 7, 9, 10, and 15 of the ’577 patent and asserted claims 1, 2, 4, 5, 7, 8, 10, 13, 19, 56, and 64 of the ’668 patent. The ALJ did not find a violation of Section 337 with respect to asserted claim 2 of the ’577 patent or any asserted claims of the ’853, ’492, ’875, and ’211 patents.
  (was, 2017-11-03, similarity 0.8128):
[0001596532-17-000251:note_history:20]
On December 9, 2016, the ALJ issued her initial determination finding a violation of Section 337.  More specifically, the ALJ found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringe asserted claims 1, 7, 9, 10, and 15 of the ’577 patent and asserted claims 1, 2, 4, 5, 7, 8, 10, 13, 19, 56, and 64 of the ’668 patent.  The ALJ did not find a violation of Section 337 with respect to asserted claim 2 of the ’577 patent or any asserted claims of the ’853, ’492, ’875, and ’211 patents.  On December 29, 2016, we, Cisco and the Office of Unfair Import Investigation (“OUII”) filed petitions for review of certain findings contained in the initial determination.  On March 1, 2017, the Commission issued a notice that it was reviewing the final initial determination in part on certain issues.

- changed (2018-05-04):
[0001596532-18-000109:note_history:21]
On May 4, 2017, the USITC issued its Final Determination, which found a violation with respect to the ’577 and ’668 patents, and found no violation with respect to the ’211, ’853, ’875 and ’492 patents. The USITC also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software and components thereof that infringe one or more of claims 1, 7, 9, 10, and 15 of the ’577 patent and 1, 2, 4, 5, 7, 8, 10, 13, 18, 56, and 64 of the ’668 patent. On July 4, 2017, the 60-day Presidential review period for the 945 Investigation expired. During the 60-day Presidential review period, the USITC Orders permitted us to continue importing and selling products covered by the orders so long as we paid a 5% bond. Because the United States Trade Representative did not disapprove the USITC’s final determination, the limited exclusion order and cease and desist order are now in full effect.
  (was, 2017-11-03, similarity 0.8918):
[0001596532-17-000251:note_history:21]
On May 4, 2017, the Commission issued its Final Determination, which found a violation with respect to the ’577 and ’668 patents, and found no violation with respect to the ’211, ’853, ’875 and ’492 patents.  The Commission also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software and components thereof that infringe one or more of claims 1, 7, 9, 10, and 15 of the ’577 patent and 1, 2, 4, 5, 7, 8, 10, 13, 18, 56, and 64 of the ’668 patent.  The 60-day Presidential review period for the 945 Investigation expired on July 4, 2017.  During the 60-day Presidential review period, the USITC Orders permitted Arista to continue importing and selling products covered by the orders so long as we paid a 5% bond.  Because the United States Trade Representative did not disapprove the USITC’s final determination, the limited exclusion order and cease and desist order are now in full effect.

- changed (2018-05-04):
[0001596532-18-000109:note_history:22]
On May 25, 2017 and June 1, 2017, the PTAB issued final written decisions finding all claims of the ’577 and ’668 patents that we were found to have infringed in the 945 Investigation unpatentable. On June 1, 2017 and June 2, 2017, we filed emergency petitions to suspend the remedial orders in the 945 Investigation. On July 20, 2017, the USITC issued a notice denying our petition to suspend the remedial orders. On July 21, 2017, we filed a motion to stay the remedial orders in the 945 Investigation pending disposition of the relevant appeals and sought expedited consideration of our motion. On September 11, 2017, the USITC denied our motion to stay.
  (was, 2017-11-03, similarity 0.9789):
[0001596532-17-000251:note_history:22]
On May 25, 2017 and June 1, 2017, the PTAB issued final written decisions finding all claims of the ’577 and ’668 patents that we were found to have infringed in the 945 Investigation unpatentable.  On June 1, 2017 and June 2, 2017, we filed emergency petitions to suspend the remedial orders in the 945 Investigation.  On July 20, 2017, the Commission issued a notice denying our petition to suspend the remedial orders.  On July 21, 2017, we filed a motion to stay the remedial orders in the 945 Investigation pending disposition of the relevant appeals and sought expedited consideration of our motion.  On September 11, 2017, the Commission denied our motion to stay.

- changed (2018-05-04):
[0001596532-18-000109:note_history:23]
On August 25, 2017 we filed a motion with the Federal Circuit requesting that the Federal Circuit stay the remedial orders pending the completion of the appeal of the 945 Investigation. On September 22, 2017, the Federal Circuit issued an order denying our motion to stay, but ordered that our redesigned products be allowed to enter the country “unless and until USITC proceedings are initiated and completed to produce an enforceable determination that such a redesign is barred” by a USITC remedial order.
  (was, 2017-11-03, similarity 0.9417):
[0001596532-17-000251:note_history:23]
On August 25, 2017 we filed a motion with the U.S. Court of Appeals for the Federal Circuit requesting that the Federal Circuit stay the remedial orders pending the completion of the appeal of the 945 Investigation.  On September 22, 2017, the Federal Circuit issued an order denying our motion to stay, but ordered that our redesigned products be allowed to enter the country “unless and until Commission proceedings are initiated and completed to produce an enforceable determination that such a redesign is barred” by a Commission remedial order.

- added (2018-05-04):
[0001596532-18-000109:note_history:24]
On September 27, 2017, Cisco filed a petition with the USITC requesting that the USITC institute a modification proceeding (“945 Modification Proceeding”) to determine whether our redesigned products infringe the patent claims underlying the remedial orders in the 945 Investigation. On October 27, 2017, the USITC instituted the 945 Modification Proceeding. The proceeding has been assigned to ALJ McNamara, who presided over the underlying investigation.

- added (2018-05-04):
[0001596532-18-000109:note_history:25]
The ALJ held a hearing on January 26, 2018 and issued a recommended determination (“RD”) on March 23, 2018.  The RD found that our redesigned products do not infringe the ’577 patent but do infringe the ’668 patent. The RD will be subject to review by the USITC after which the USITC will issue a final determination. The USITC has not set a target date for the final determination.

- added (2018-05-04):
[0001596532-18-000109:note_history:26]
On April 5, 2018, the USITC issued an order suspending enforcement of the remedial orders as to the ’668 patent  following the Federal Circuit’s affirmance of the PTAB’s final written decision for the ’668 patent.

- changed (2018-05-04):
[0001596532-18-000109:note_history:27]
We have filed petitions for Inter Partes Review of the ’597, ’211, ’668, ’853, ’537, ’577, ’886, and ’526 patents. IPRs relating to the ’597 (IPR No. 2015-00978) and ’211 (IPR No. 2015-00975) patents were instituted in October 2015 and hearings on these IPRs were completed in July 2016. On September 28, 2016, the PTAB issued a final written decision finding claims 1, 14, 39-42, 71, 72, 84, and 85 of the ’597 patent unpatentable. The PTAB also found that claims 29, 63, 64, 73, and 86 of the ’597 patent had not been shown to be unpatentable. On October 5, 2016, the PTAB issued a final written decision finding claims 1 and 12 of the ’211 patent unpatentable. The PTAB also found that claims 2, 6-9, 13, 17-20 of the ’211 patent had not been shown to be unpatentable. Both parties have appealed the final written decisions on the ’211 and ’537 patent IPRs.  The hearing for the ’211 IPR appeal was held in March 2018, and on March 28, 2018, the Federal Circuit remanded the matter back to the PTAB for further proceedings.
  (was, 2017-11-03, similarity 0.9085):
[0001596532-17-000251:note_history:27]
We have filed petitions for Inter Partes Review of the ’597, ’211, ’668, ’853, ’537, ’577, ’886, and ’526 patents.  IPRs relating to the ’597 (IPR No. 2015-00978) and ’211 (IPR No. 2015-00975) patents were instituted in October 2015 and hearings on these IPRs were completed in July 2016.  On September 28, 2016, the PTAB issued a final written decision finding claims 1, 14, 39-42, 71, 72, 84, and 85 of the ’597 patent unpatentable.  The PTAB also found that claims 29, 63, 64, 73, and 86 of the ’597 patent had not been shown to be unpatentable.  On October 5, 2016, the PTAB issued a final written decision finding claims 1 and 12 of the ’211 patent unpatentable.  The PTAB also found that claims 2, 6-9, 13, 17-20 of the ’211 patent had not been shown to be unpatentable.  Both parties have appealed the final written decisions on the ’211 and ’537 patent IPRs.

- changed (2018-05-04):
[0001596532-18-000109:note_history:28]
IPRs relating to the ’668 (IPR No. 2016-00309), ’577 (IPR No. 2016-00303), ’853 (IPR No. 2016-0306), and ’537 (IPR No. 2016-0308) patents were instituted in June 2016 and hearings were held on March 7, 2017. On May 25, 2017, the PTAB issued final written decisions finding claims 1, 7-10, 12-16, 18-22, 25, and 28-31 of ’577 patent unpatentable, and that claim 2 of the ’577 patent, claim 63 of the ’853 patent, and claims 1, 10, 19, and 21 of the ’537 patent had not been shown to be unpatentable. On June 1, 2017, the PTAB issued a final written decision finding claims 1-10, 12-13, 15-28, 30-31, 33-36, 55-64, 66-67, and 69-72 of the ’668 patent unpatentable. We filed a Notice of Appeal concerning the ’577 patent on July 21, 2017, and Notices of Appeal concerning the ‘853 and ’537 patents on July 26, 2017. Cisco cross-appealed concerning the ’577 patent on July 26, 2017 and filed a Notice of Appeal concerning the ’668 patent on August 1, 2017. For the appeals of the IPRs on the ’668 and ’577 patents, the Federal Circuit granted our motion for an expedited briefing schedule, and the hearings were held on February 9, 2018. On February 14, 2018, the Federal Circuit affirmed the PTAB’s final written decision on the ’668 patent.
  (was, 2017-11-03, similarity 0.9206):
[0001596532-17-000251:note_history:28]
IPRs relating to the ’668 (IPR No. 2016-00309), ’577 (IPR No. 2016-00303), ’853 (IPR No. 2016-0306), and ’537 (IPR No. 2016-0308) patents were instituted in June 2016 and hearings were held on March 7, 2017.  On May 25, 2017, the PTAB issued final written decisions finding claims 1, 7-10, 12-16, 18-22, 25, and 28-31 of ’577 patent unpatentable, and that claim 2 of the ’577 patent, claim 63 of the ’853 patent, and claims 1, 10, 19, and 21 of the ’537 patent had not been shown to be unpatentable.  On June 1, 2017, the PTAB issued a final written decision finding claims 1-10, 12-13, 15-28, 30-31, 33-36, 55-64, 66-67, and 69-72 of the ’668 patent unpatentable.  We filed a Notice of Appeal concerning the ’577 patent on July 21, 2017, and Notices of Appeal concerning the ‘853 and ’537 patents on July 26, 2017.  Cisco cross-appealed concerning the ’577 patent on July 26, 2017 and filed a Notice of Appeal concerning the ’668 patent on August 1, 2017.  For the appeals of the IPRs on the ’668 and ’577 patents, the Federal Circuit granted our motion for an expedited briefing schedule, and the briefing will be completed in November 2017.

- changed (2018-05-04):
[0001596532-18-000109:note_history:29]
We intend to vigorously defend against each of the Cisco lawsuits, as summarized in the preceding paragraphs. However, we cannot be certain that any claims by Cisco will be resolved in our favor regardless of the merit of the claims. Any adverse litigation ruling could result in injunctive relief and USITC remedial orders, including the above described injunctive relief, could lead to significant penalties assessed or damages awarded against us or a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products.
  (was, 2017-11-03, similarity 0.9765):
[0001596532-17-000251:note_history:29]
We intend to vigorously defend against each of the Cisco lawsuits, as summarized in the preceding paragraphs.  However, we cannot be certain that any claims by Cisco will be resolved in our favor regardless of the merit of the claims.  Any adverse litigation ruling could result in injunctive relief, including the above described injunctive relief, could lead to significant penalties assessed or damages awarded against us or a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products.

- added (2018-05-04):
[0001596532-18-000109:note_history:30]
Similarly, on May 4, 2017, the USITC issued a limited exclusion order and cease and desist order in the 945 Investigation with respect to the ’668 and ’577 patents. We have made design changes to our products for sale in the United States to address the features that were found to infringe the ’577 and ’668 patents. In particular, the ’577 patent was directed to a feature that is implemented in the merchant silicon chips that we purchase from third-party suppliers. Because we do not design, build or manufacture these merchant silicon chips, we are limited in further modifications that we can make to our products for this patent. Our redesign efforts therefore consisted of removing the feature found to infringe the ’577 patent in all of our products until this patent expires on June 30, 2018, and providing an alternative feature to address the ‘577 patent for a subset of those products. The redesign efforts to address the 945 Investigation findings could be extremely costly and time consuming for us and our customers as well as disruptive to our other development activities and distracting to management. If the redesigned products are unacceptable to our customers, our business, revenues, deferred revenue balances, prospects, reputation, results of operations or financial condition could be materially and adversely affected.

- changed (2018-05-04):
[0001596532-18-000109:note_history:31]
Because the USITC did not suspend its orders in the 945 Investigation, despite a PTAB finding that every relevant claim of the ’668 and ’577 patents is unpatentable, we were barred from importing our redesigned products into the United States until we received approval from CBP. On July 21, 2017, we submitted a Part 177 request to CBP seeking approval to import our redesigned products into the United States. Following the Federal Circuit’s order on September 22, 2017, allowing us to import our redesigned products, we withdrew our request. On October 12, 2017, CBP, over Cisco’s objection, terminated the Part 177 proceedings, and confirmed that it will permit entry of our redesigns pursuant to the Federal Circuit’s September 22, 2017 order.
  (was, 2017-11-03, similarity 0.8661):
[0001596532-17-000251:note_history:31]
Because the USITC did not suspend its orders in the 945 Investigation, despite a PTAB finding that every relevant claim of the ’668 and ’577 patents is unpatentable, we were previously barred from importing our redesigned products into the United States until we received approval from CBP.  On July 21, 2017, we submitted a Part 177 request to CBP seeking approval to import our redesigned products into the United States.  Following the Federal Circuit’s order on September 22, 2017, allowing us to import our redesigned products, we withdrew our request.  On October 12, 2017, CBP, over Cisco’s objection, terminated the Part 177 proceedings, and confirmed that it will permit entry of our redesigns pursuant to the Federal Circuit’s September 22, 2017 order.

- added (2018-05-04):
[0001596532-18-000109:note_history:32]
Following a February 14, 2018 Federal Circuit opinion affirming the PTAB’s finding that the asserted claims of the ’668 patent are invalid, on April 5, 2018, the USITC suspended enforcement of its remedial orders in the 945 Investigation as to the ’668 patent. This suspension will remain in effect until the cancellation of the asserted claims of the ’668 patent or the reversal or vacatur of the Federal Circuit’s decision. While remote, there is some possibility that the Supreme Court could decide on the merits to vacate or reverse the Federal Circuit’s affirmance of the PTAB’s final written decision concerning the ’668 patent. Likewise, the Federal Circuit may vacate or reverse the PTAB’s final written decision concerning the ’577 patent.

- changed (2018-05-04):
[0001596532-18-000109:note_history:33]
In either the 944 Enforcement Action or the 945 Modification Proceeding, if the USITC determines that our redesigned products infringe any of the patents that are the subject of USITC remedial orders, those redesigned products will also be barred from import into the United States, or sale after importation. In addition, the USITC may impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000 or twice the domestic value of the articles entered or sold, whichever is higher,” bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order,” or impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.” In the 944 Enforcement Action, the ALJ recommended a civil penalty of $307 million if the USITC were to reverse the ALJ’s finding of no violation. Any such finding by the USITC in either the 944 Enforcement Action or the 945 Modification Proceeding could materially and adversely affect our business, prospects, reputation, results of operations and financial condition.
  (was, 2017-11-03, similarity 0.9173):
[0001596532-17-000251:note_history:33]
In either the 944 or 945 Investigations, if the USITC determines that our redesigned products infringe patents that are the subject of USITC remedial orders, those products will be barred from import into the United States, or sale after importation.  In addition, the USITC may impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000 or twice the domestic value of the articles entered or sold, whichever is higher,” bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order,” or impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.”  In the 944 Investigation, the ALJ recommended a civil penalty of $307 million if the Commission were to reverse ALJ’s finding of no violation.  Any such finding by the USITC could materially and adversely affect our business, prospects, reputation, results of operations and financial condition.

- added (2018-05-04):
[0001596532-18-000109:note_history:34]
An adverse finding in the 944 Enforcement Action or the 945 Modification Proceeding would take effect immediately upon USITC’s issuance of the final determination, without any Presidential review period. To address such a finding, we would have to further redesign our products to make them non-infringing, and until we made such changes we would not be able to import or ship our products to customers. Our further redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management.  We may not be able to further redesign the products in a manner that does not continue to infringe the patents or that is acceptable to customers. We may not be able to complete, and our customers may not be able to qualify, such further redesigned products in a timely fashion, if at all, following the issuance of an adverse final determination, leading to a delay or cancellation of purchases by some customers until those redesigned products are qualified or accepted by such customers, a rejection or return of our redesigned products by some customers or a loss of sales to some customers who are unable to qualify or accept the redesigned products. Our redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management.

- changed (2018-05-04):
[0001596532-18-000109:note_history:35]
For example, in the 944 Enforcement Action, although the ALJ issued an initial determination finding that our redesigned products did not violate the June 23, 2016 cease and desist order, if the ALJ modifies the initial determination during the remand proceeding, or if the USITC finds a violation in its final determination on September 4, 2018, we will no longer be able to import or ship our products in the U.S. until we make further changes to address those findings, which could materially and adversely affect our business, revenues, prospects, reputation, results of operations or financial condition. We would also need to obtain USITC or CBP approval to resume importation of such redesigned products into the United States. In addition, the USITC would not provide a service and support exception for our previously redesigned products, and customers may be required to upgrade to new products to obtain service and support. If we are unable to obtain such approvals or provide such service and support exception, our business, prospects, reputation, results of operations or financial condition could be materially and adversely affected. In addition, if we are found to have violated the USITC’s orders while those orders remain in effect, we may be subject to the penalties described above.
  (was, 2017-11-03, similarity 0.6506):
[0001596532-17-000251:note_history:35]
An adverse finding in an enforcement action or modification proceeding would take effect immediately upon USITC’s issuance of the final determination, without any Presidential review period.  To address such a finding, we would have to further redesign our products to make them non-infringing, and until we made such changes we would not be able to import or ship our products to customers.  In such a situation, we may not be able to do so in a manner that does not continue to infringe the patents or that is acceptable to customers.  We may not be able to complete, and our customers may not be able to qualify, such redesigned products in a timely fashion, if at all, following the issuance of an adverse final determination, leading to an inability to sell or ship products to customers.  Our redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management.  For example, in the enforcement action for the 944 Investigation, although the ALJ issued an initial determination finding that our redesigned products did not violate the June 23, 2016 cease and desist order, if the ALJ modifies the initial determination during the remand proceeding, or if the Commission finds a violation in its final determination on September 4, 2018, we will no longer be able to import or ship our products in the U.S. until we make further changes to address those findings, which could materially and adversely affect our business, revenues, prospects, reputation, results of operations or financial condition.  We would also need to obtain USITC or CBP approval to resume importation of such redesigned products into the United States.  In addition, the USITC would not provide a service and support exception for our previously redesigned products, and customers may be required to upgrade to new products to obtain service and support.  If we are unable to obtain such approvals or provide such service and support exception, our business, prospects, reputation, results of operations or financial condition could be materially and adversely affected.

- added (2018-05-04):
[0001596532-18-000109:note_history:36]
In the 945 Modification Proceeding, while the USITC has suspended enforcement of its remedial orders as to the ’668 patent, the RD finds that our redesigned products infringe the ’668 patent. If the USITC adopts that finding, and the Federal Circuit’s decision is reversed by the Supreme Court or vacated as a result of a constitutional ruling on the IPR process, we will no longer be able to import or ship our products in the U.S. until we make further changes to address those findings. Likewise, if the USITC reverses the finding pursuant to the RD that our redesigned products do not infringe the ’577 patent, we will no longer be able to import or ship our products in the U.S. unless and until we make further changes to address those findings; the PTAB decision finding the relevant claims of the ’577 patent are affirmed on appeal and the United States Patent and Trademark Office (“Patent Office”) cancels those claims; or the ’577 patent expires on June 30, 2018. Any requirement that we further modify our products to comply with the ITC’s orders in the 945 Investigation could materially and adversely affect our business, revenues, prospects, reputation, results of operations or financial condition. We would also need to obtain USITC or CBP approval to resume importation of any such redesigned products into the United States. In addition, the USITC would not provide a service and support exception for our previously redesigned products, and customers may be required to upgrade to new products to obtain service and support. If we are unable to obtain such approvals or provide such service and support exception, our business, revenues, prospects, reputation, results of operations or financial condition could be materially and adversely affected. In addition, even if the PTAB decisions on the ’577 and ’688 patents are ultimately affirmed on appeal and the patent claims are canceled, if we are found to have violated the USITC’s orders while those orders were in effect, we may be subject to the penalties described above.

- changed (2018-05-04):
[0001596532-18-000109:note_history:37]
To comply with the USITC’s remedial orders, we have also made certain changes to our manufacturing, importation and shipping workflows. These changes have included shifting manufacturing and integration of our products to be sold in the United States to U.S. facilities. Such changes may be extremely costly, time consuming, and we may not be able to implement such changes successfully. Any failure to successfully change our manufacturing and importation processes or shipping workflows in a manner that is compliant with the limited exclusion orders and cease and desist orders may cause a disruption in our product shipments and materially and adversely affect our business, prospects, reputation, results of operations, and financial condition.
  (was, 2017-11-03, similarity 0.9626):
[0001596532-17-000251:note_history:37]
To comply with the USITC’s remedial orders, we have also made certain changes to our manufacturing, importation and shipping workflows.  These changes have included shifting manufacturing and integration of our products to be sold in the United States to U.S. facilities.  Such changes may be extremely costly, time consuming, and we may not be able to implement such changes successfully.  Any failure to successfully change our manufacturing and importation processes or shipping workflows in a manner that is compliant with the limited exclusion order and cease and desist order may cause a disruption in our product shipments and materially and adversely affect our business, prospects, reputation, results of operations, and financial condition.

- added (2018-05-04):
[0001596532-18-000109:note_history:38]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

- changed (2018-05-04):
[0001596532-18-000109:note_history:39]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2018, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.
  (was, 2017-11-03, similarity 0.8715):
[0001596532-17-000251:note_history:39]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.  We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated.   As of September 30, 2017, provisions recorded for contingent losses related to other claims and matters have not been significant.  Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows.  However, litigation is subject to inherent uncertainties and our view of these matters may change in the future.  Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.

- removed (2018-05-04):
[0001596532-17-000251:note_history:40]
We lease various operating spaces in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2025. We recognize rent expense under these arrangements on a straight-line basis over the term of the lease.  Rent expense for all operating leases amounted to $2.5 million and $2.3 million for the three months ended September 30, 2017 and 2016, respectively, and $7.5 million and $7.0 million for the nine months ended September 30, 2017 and 2016, respectively. There have been no material changes in our operating lease commitments under contractual obligation, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2016.

- removed (2018-05-04):
[0001596532-17-000251:note_history:41]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013.  The underlying building asset is depreciated over the building’s estimated useful life of 30 years.  At the conclusion of the initial lease term, we will de-recognize both the net book values of the asset and the remaining financing obligation.  There have been no material changes in our operating lease commitments under contractual obligation, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2016.

- removed (2018-05-04):
[0001596532-17-000251:note_history:42]
As of September 30, 2017 and December 31, 2016, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $40.0 million and $41.2 million, respectively. As of September 30, 2017, $1.8 million and $38.2 million were recorded as short-term and long-term financing obligations, respectively.

- removed (2018-05-04):
[0001596532-17-000251:note_history:43]
Land lease expense related to our lease financing obligation is classified as rent expense in our unaudited condensed consolidated statements of income, and amounted to $0.3 million and $1.0 million for the three and nine months ended  September 30, 2017, respectively, and $0.3 million and $1.0 million for the three and nine months ended September 30, 2016, respectively.

- removed (2018-05-04):
[0001596532-17-000251:note_history:44]
Cisco filed a notice of appeal on June 6, 2017, and the parties are in the process of submitting their appeal briefs.

- removed (2018-05-04):
[0001596532-17-000251:note_history:45]
On September 27, 2017, Cisco filed a petition with the USITC requesting that the Commission institute a modification proceeding to determine whether our redesigned products infringe the patent claims underlying the remedial orders in the 945 Investigation.  On October 27, 2017, the Commission instituted the modification proceeding.  The USITC has assigned Mary Joan McNamara as the ALJ to oversee the proceeding.  The Commission has set a deadline of five months for the ALJ to issue a recommended determination on what, if any, modifications to the remedial orders issued in the 945 Investigation are appropriate.  This deadline may be extended by one month upon a showing of good cause.  The recommended determination will be subject to review by the Commission after which the Commission will issue a final determination.  The Commission has not set a target date for the final determination.  On November 1, 2017, Cisco filed a request for an expedited “limited recommended determination” on certain issues relating to the ’577 patent.  Cisco’s request seeks completion of briefing by December 11, 2017 and a recommended determination “as soon as practicable” after that.

- removed (2018-05-04):
[0001596532-17-000251:note_history:46]
Similarly, on May 4, 2017, the USITC issued a limited exclusion order and cease and desist order in the 945 Investigation with respect to the ’668 and ’577 patents.  We have made design changes to our products for sale in the United States to address the features that were found to infringe the ’577 and ’668 patents.  We are making ongoing modifications to our products to also ensure that they continue to meet customer requirements, and we are working with our customers to qualify those modified products for use in our customers’ networks.  In particular, the ’577 patent was directed to a feature that is implemented in the merchant silicon chips that we purchase from third-party suppliers.  Because we do not design, build or manufacture these merchant silicon chips, we are limited in further modifications that we can make to our products for this patent.  We are deploying these additional modifications for a subset of our products, and for all of our products we will remove the features found to infringe until the ’577 patent expires on June 30, 2018.  These redesign and qualification efforts could be extremely costly and time consuming for us and our customers as well as disruptive to our other development activities and distracting to management.  We may not be able to complete, and our customers may not be able to qualify these redesigned products in a timely fashion, if at all.  For example, some of our customers continue to test and qualify our redesigned products which address the ’577 and ’668 patents to ensure that they meet their network requirements.  This could result in an inability to ship those redesigned products to our customers, a delay or cancellation of purchases by, some customers until those further modifications are completed and/or qualified or a rejection or return of our redesigned products or a delay or loss of sales to some customers, any of which could materially and adversely affect our business, revenues, deferred revenue balances, prospects, reputation, results of operations or financial condition.

- removed (2018-05-04):
[0001596532-17-000251:note_history:47]
In the 945 Investigation, while the USITC orders are based upon patent claims that the PTAB has found to be invalid, these orders will remain in effect unless and until the PTAB decisions are affirmed on appeal and the PTO cancels the patents.  If the Commission finds a violation in its final determination for the modification proceeding, we will no longer be able to import or ship our products in the U.S. until we make further changes to address those findings and/or until the PTAB decisions are so affirmed and the PTO cancels the patents, which could materially and adversely affect our business, revenues, prospects, reputation, results of operations or financial condition.  We would also need to obtain USITC or CBP approval to resume importation of any such redesigned products into the United States.  In addition, the USITC would not provide a service and support exception for our previously redesigned products, and customers may be required to upgrade to new products to obtain service and support.  If we are unable to obtain such approvals or provide such service and support exception, our business, revenues, prospects, reputation, results of operations or financial condition could be materially and adversely affected.  In addition, even if the PTAB decisions are affirmed on appeal, and the patent claims are canceled, if we are found to have violated the USITC’s orders while those orders remain in effect, we may be subject to penalties.

- removed (2018-05-04):
[0001596532-17-000251:note_history:48]
In the Matter of Certain Semiconductor Devices, Semiconductor Device Packages, and Products Containing Same (U.S. International Trade Commission Investigation No. 337-TA-1010) (the “1010 Investigation”)

- removed (2018-05-04):
[0001596532-17-000251:note_history:49]
On May 23, 2016, Tessera Technologies, Inc., Tessera, Inc., and Invensas Corp. (“Tessera”) filed a complaint in the USITC alleging that Broadcom Limited, Broadcom Corporation, Avago Technologies Limited, and Avago Technologies U.S. Inc. (“Broadcom”) and certain of Broadcom's customers violated 19 U.S.C. § 1337 (“Section 337”).  On June 20, 2016, the USITC instituted Tessera’s complaint as Investigation No. 337-TA-1010.

- removed (2018-05-04):
[0001596532-17-000251:note_history:50]
Tessera alleges that certain Broadcom semiconductor devices infringe U.S. Patent Nos. 6,856,007; 6,849,946; and 6,133,136.  Tessera further alleges that Broadcom’s downstream customers, Arista Networks, Inc.; ARRIS International plc; ARRIS Group, Inc.; ARRIS Technology, Inc.; ARRIS Enterprises LLC; ARRIS Solutions, Inc.; Pace Ltd.; Pace Americas, LLC; Pace USA; LLC, ASUSteK Computer Inc.; ASUS Computer International; Comcast Cable Communications, LLC; Comcast Cable Communications Management, LLC; Comcast Business Communications, LLC; HTC Corporation; HTC America, Inc.; NETGEAR, Inc.; Technicolor S.A.; Technicolor USA, Inc.; and Technicolor Connected Home USA LLC (“Downstream Respondents”) are violating Section 337 by importing, selling after importation, or selling for importation products that incorporate the accused Broadcom semiconductor devices.  The accused Company products include certain models of our switching products.

- removed (2018-05-04):
[0001596532-17-000251:note_history:51]
Tessera seeks the following relief: (1) a permanent limited exclusion order excluding from importation into the U.S. all of Broadcom’s semiconductor devices and semiconductor device packages, as well as Downstream Respondents’ products containing Broadcom’s semiconductor devices that infringe one or more of the three patents-in-suit and (2) a permanent cease and desist order prohibiting Broadcom and the Downstream Respondents and related companies from importing, marketing, advertising, demonstrating, warehousing inventory for distribution, offering for sale, selling, qualifying for use in the products of others, distributing, or using the accused Broadcom semiconductor devices and Downstream Respondents’ products containing Respondents’ semiconductor devices and semiconductor device packages that infringe one or more of the three patents subject to the USITC Investigation.

- removed (2018-05-04):
[0001596532-17-000251:note_history:52]
An evidentiary hearing was held from March 27-31, 2017.  On June 30, 2017, the ALJ issued an initial determination that found a violation with respect to the ’946 patent and no violation with respect the ’136 and ’007 patents.  The ALJ recommended that the Commission issue limited exclusion and cease and desist orders and recommended a 100% bond for imports during the Presidential review period.  The Commission has indicated it will review the initial determination, and the target date for the final determination is December 1, 2017.

- removed (2018-05-04):
[0001596532-17-000251:note_history:53]
To the extent claims made by Tessera in the USITC Investigation against us are based solely on functionality residing in Broadcom’s products, Broadcom has agreed to defend us at no cost to us.

- removed (2018-05-04):
[0001596532-17-000251:note_history:54]
*  *  *  *  *

- removed (2018-05-04):
[0001596532-17-000251:note_history:55]
An adverse final determination from the Commission could result in issuance of remedial orders that could prevent Broadcom, Arista, and the other Downstream Respondents from selling infringing products for import into the United States, importing infringing products into the United States, or selling infringing products after importation into the United States.  This could include both the infringing semiconductor devices as well as downstream products, including our Ethernet switches, that incorporate those devices.  During the 60-day Presidential review period following the final determination, Broadcom, Arista, and the other Downstream Respondents could continue to import and sell infringing products by paying a bond.  The ALJ’s recommended bond is 100% of the entered value of the product.  Following the end of the Presidential review period, if the U.S. Trade Representative chooses not to disapprove the final determination, the remedial orders would go into full effect.

- removed (2018-05-04):
[0001596532-17-000251:note_history:56]
If the USITC orders go into full effect, to continue importing and selling products found to be infringing, Broadcom and its manufacturers would need to develop redesigned products that do not infringe, and we would have to integrate these devices into its own products, or Broadcom and/or the Downstream Respondents would need to obtain a license from Tessera.  It may not be possible to do this in a timely fashion, if at all.  Because the asserted patents are directed towards technology used in the manufacture of the semiconductor devices not manufactured or designed by us, we would be dependent on Broadcom and its manufacturers to create such redesigned products.

- removed (2018-05-04):
[0001596532-17-000251:note_history:57]
Before Broadcom, Arista, or the other Downstream Respondents could import redesigned products into the United States, the products would have to be approved by CBP or the USITC.  We may not be successful in any efforts to obtain such approvals in a timely manner, or at all.  While a favorable ruling from CBP would allow Broadcom, Arista, and the other Downstream Respondents to resume importation of our redesigned products into the United States, the USITC could ultimately determine in an enforcement action that such redesigned products continue to infringe the patents that are the subject of the USITC orders.

- removed (2018-05-04):
[0001596532-17-000251:note_history:58]
Any failure to effectively redesign these products and obtain timely clearance from CBP or USITC to import such redesigned products or to obtain a license from Tessera may cause a disruption to our product shipments and materially and adversely affect our business, revenues, prospects, reputation, results of operations, and financial condition.  However, it is our belief that at this stage of the legal proceedings, the likelihood of a loss is remote.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-05-04):
[0001596532-18-000109:note_history:59]
1.    Organization and Summary of Significant Accounting Policies
  (was, 2017-11-03, similarity 0.9833):
[0001596532-17-000251:note_history:59]
Organization and Summary of Significant Accounting Policies

- added (2018-05-04):
[0001596532-18-000109:note_history:60]
Organization

- changed (2018-05-04):
[0001596532-18-000109:note_history:61]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2018, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2017 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant intercompany accounts and transactions have been eliminated.
  (was, 2017-11-03, similarity 0.7495):
[0001596532-17-000251:note_history:61]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles ("GAAP") and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2017, are not necessarily indicative of the results expected for the full fiscal year.  The condensed consolidated balance sheet as of December 31, 2016 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements.  Our unaudited condensed consolidated financial statements ("consolidated financial statements") include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and are prepared in accordance with GAAP.  All significant intercompany accounts and transactions have been eliminated.

- added (2018-05-04):
[0001596532-18-000109:note_history:62]
Our condensed consolidated financial statements and related financial information in this Quarterly Report on Form 10-Q should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2017, filed with the SEC on February 20, 2018. Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.

- changed (2018-05-04):
[0001596532-18-000109:note_history:63]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; valuation of inventory and contract manufacturer/supplier liabilities; recognition and measurement of contingent liabilities; valuation of equity investments; determination of fair value for stock-based awards; and valuation of warranty accruals. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.
  (was, 2017-11-03, similarity 0.7041):
[0001596532-17-000251:note_history:63]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts and sales return reserve; determination of fair value for stock-based awards; accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; valuation of inventory; valuation of warranty accruals; contract manufacturing liabilities; and recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.

- changed (2018-05-04):
[0001596532-18-000109:note_history:64]
Significant Accounting Policies
  (was, 2017-11-03, similarity 0.6349):
[0001596532-17-000251:note_history:64]
Recent Accounting Pronouncements

- added (2018-05-04):
[0001596532-18-000109:note_history:65]
During the three months ended March 31, 2018, we adopted several recent accounting pronouncements as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1. As a result, we updated certain significant accounting policies as described below. There have been no other significant changes to our accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

- added (2018-05-04):
[0001596532-18-000109:note_history:66]
Investments

- added (2018-05-04):
[0001596532-18-000109:note_history:67]
Our equity investments in privately-held companies without readily determinable fair values are measured using the measurement alternative, defined by Accounting Standards Codification (“ASC”) 321-Investments-Equity Securities as cost, less impairments, and adjusted up or down based on observable price changes in orderly transactions for identical or similar investments of the same issuer. Any adjustments resulting from impairments and/or observable price changes are recorded as other income (expense) in our consolidated statement of income. Prior to 2018, such investments were accounted for under the cost method and were recorded at historical cost at the time of investment, with adjustments to the balance only in the event of an impairment.

- added (2018-05-04):
[0001596532-18-000109:note_history:68]
Our equity investments in privately-held companies are included in investments, non-current, in our consolidated balance sheets.

- added (2018-05-04):
[0001596532-18-000109:note_history:69]
Revenue Recognition

- added (2018-05-04):
[0001596532-18-000109:note_history:70]
Effective January 1, 2018, we adopted a new revenue recognition policy in accordance with ASC 606 using the modified retrospective method as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1.  Prior to 2018, our revenue recognition policy was based on ASC 605 Revenue Recognition, and is described in Note 1 of Notes to Consolidated Financial Statements under Item 8 of our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

- added (2018-05-04):
[0001596532-18-000109:note_history:71]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with post-contract customer support (“PCS”). We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

- added (2018-05-04):
[0001596532-18-000109:note_history:72]
| • | Identification of the contract, or contracts, with a customer |

- added (2018-05-04):
[0001596532-18-000109:note_history:73]
| • | Identification of the performance obligations in the contract |

- added (2018-05-04):
[0001596532-18-000109:note_history:74]
| • | Determination of the transaction price |

- added (2018-05-04):
[0001596532-18-000109:note_history:75]
| • | Allocation of the transaction price to the performance obligations in the contract |

- added (2018-05-04):
[0001596532-18-000109:note_history:76]
| • | Recognition of revenue when (or as) we satisfy the performance obligation |

- added (2018-05-04):
[0001596532-18-000109:note_history:77]
Post-Contract Customer Support

- added (2018-05-04):
[0001596532-18-000109:note_history:78]
Post-contract support, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernable pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and addresses customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

- added (2018-05-04):
[0001596532-18-000109:note_history:79]
Contracts with Multiple Performance Obligations

- added (2018-05-04):
[0001596532-18-000109:note_history:80]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts which contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is required to determine the SSP for each distinct performance obligation.  We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

- added (2018-05-04):
[0001596532-18-000109:note_history:81]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services are sold, and the size of the end customer.

- added (2018-05-04):
[0001596532-18-000109:note_history:82]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

- added (2018-05-04):
[0001596532-18-000109:note_history:83]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

- added (2018-05-04):
[0001596532-18-000109:note_history:84]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

- added (2018-05-04):
[0001596532-18-000109:note_history:85]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

- added (2018-05-04):
[0001596532-18-000109:note_history:86]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

- added (2018-05-04):
[0001596532-18-000109:note_history:87]
Assets Recognized from Costs to Obtain a Contract with a Customer

- added (2018-05-04):
[0001596532-18-000109:note_history:88]
Effective January 1, 2018 in accordance with ASC 606, we recognize an asset for the incremental costs of obtaining a contract with a customer if we expect the benefit of those costs to be longer than one year. We have determined that certain sales commissions earned by our sales force meet the requirements to be capitalized. These costs are deferred and then amortized over a period of benefit that we have determined to be five years. Total capitalized costs to obtain a contract are included in other current and long-term assets on our consolidated balance sheets.

- added (2018-05-04):
[0001596532-18-000109:note_history:89]
Revenue Recognition

- added (2018-05-04):
[0001596532-18-000109:note_history:90]
During May 2014, the Financial Accounting Standards Board (“FASB”) issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606). In 2016, the FASB issued ASU No. 2016-08, ASU No. 2016-10 and ASU No. 2016-12, which provide interpretive clarifications on the new guidance in Topic 606 (collectively, “the new standard”). Under the new standard, the recognition of revenue is based on consideration we expect to be entitled to from the transfer of goods or services to a customer.

- added (2018-05-04):
[0001596532-18-000109:note_history:91]
The primary impact of the new standard is related to the deferral of incremental commission costs of obtaining customer service contracts, which were previously expensed as incurred. Under the new standard, we defer all such costs and amortize them over the expected period of benefit. The new standard also requires companies to account for termination clauses at the onset of an arrangement. While there is limited history of cancellations, our prepaid subscription offerings are generally cancellable by customers with 30 days’ notice, therefore, the subscription contracts are considered month-to-month. While these prepaid amounts have historically been recorded to deferred revenue, the new standard requires that we record these amounts as other liabilities.  In addition, the new standard may impact the amount and timing of revenue recognition of certain sales arrangements and the related disclosures on our consolidated financial statements.

- added (2018-05-04):
[0001596532-18-000109:note_history:92]
We adopted the new standard in our first quarter of 2018 using the modified retrospective method, which resulted in a cumulative effect adjustment of $3.5 million that increased retained earnings to capitalize certain commission costs that were expensed in the prior year. Correspondingly, we increased prepaid expenses and other current assets by $2.0 million, other assets by $2.2 million, and decreased deferred tax assets by $0.7 million as of January 1, 2018. In addition, we reclassified $16.5 million of deferred revenue as of January 1, 2018 to other current liabilities and other long-term liabilities related to our prepaid subscription offerings. The impact of adopting the new standard was not material to our financial results for the three months ended March 31, 2018 and we do not expect the impact to the financial results for our fiscal 2018 to be material.

- added (2018-05-04):
[0001596532-18-000109:note_history:93]
We apply a practical expedient to expense costs as incurred for costs to obtain a contract with a customer when the amortization period would have been one year or less, as well as the portfolio approach for the contracts reviewed. These costs include a portion of our sales force compensation program as we have determined annual compensation is commensurate with recurring sales activities.

- added (2018-05-04):
[0001596532-18-000109:note_history:94]
Financial Instruments

- added (2018-05-04):
[0001596532-18-000109:note_history:95]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which enhances the reporting model for financial instruments to provide users of financial statements with more decision-useful information. In February 2018, the FASB issued ASU 2018-03, Technical Corrections and Improvements to Financial Instruments, to clarify certain aspects of ASU 2016-01. ASU 2016-01 and ASU 2018-03 (collectively, the “new guidance”) address certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. We adopted this new guidance in our first quarter of fiscal 2018. Under the new guidance, there was no change in the accounting of our marketable securities as our investment policy only allows investments in debt securities. For our cost method equity investments in privately-held companies without readily determinable fair value, we elected to use the measurement alternative, defined as cost, less impairments, as adjusted up or down based on observable price changes in orderly transactions for identical or similar investments of the same issuer, which was adopted prospectively. Adjustments resulting from impairments and/or observable price changes are to be recorded as other income (expense) on a prospective basis.

- added (2018-05-04):
[0001596532-18-000109:note_history:96]
Based on our assessment under the new guidance, there was no impact on our condensed consolidated financial statements from the adoption of the new guidance in the first quarter of 2018. However, the carrying amount of our equity investments and any related gain or loss may fluctuate in the future as a result of the re-measurement of such equity investments upon the occurrence of observable price changes and/or impairments.

- added (2018-05-04):
[0001596532-18-000109:note_history:97]
Income Taxes on Intra-Entity Transfers of Assets

- changed (2018-05-04):
[0001596532-18-000109:note_history:98]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which addresses recognition of current and deferred income taxes for intra-entity asset transfers when assets are sold to an outside party. Current GAAP prohibits the recognition of current and deferred income taxes until the asset has been sold to an outside party. This prohibition on recognition is considered an exception to the principle of comprehensive recognition of current and deferred income taxes in GAAP. The new guidance requires an entity to recognize the income tax consequences when the transfer occurs eliminating the exception. The guidance must be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. We adopted this guidance in our first quarter of fiscal 2018. As a result, we recognized a cumulative effect adjustment in the condensed consolidated balance sheet as of March 31, 2018 by increasing the beginning balance of the retained earnings and the deferred tax assets by approximately $0.1 million, respectively.
  (was, 2017-11-03, similarity 0.7833):
[0001596532-17-000251:note_history:98]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which addresses recognition of current and deferred income taxes for intra-entity asset transfers when assets are sold to an outside party. Current GAAP prohibits the recognition of current and deferred income taxes until the asset has been sold to an outside party. This prohibition on recognition is considered an exception to the principle of comprehensive recognition of current and deferred income taxes in GAAP.  The new guidance requires an entity to recognize the income tax consequences when the transfer occurs eliminating the exception.  The guidance will be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  The standard is effective for us for our first quarter of fiscal 2018. We are currently assessing the impact this guidance may have on our consolidated financial statements.

- added (2018-05-04):
[0001596532-18-000109:note_history:99]
Restricted Cash in Statement of Cash Flows

- added (2018-05-04):
[0001596532-18-000109:note_history:100]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force, which requires that amounts generally described as restricted cash or restricted cash equivalents be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows.  This standard is required to be applied using a retrospective transition method to each period presented.  We retrospectively adopted ASU 2016-18 in our first quarter of fiscal 2018. As a result of the adoption, we adjusted the condensed consolidated statement of cash flows for the three months ended March 31, 2017 to increase the beginning-of-period and end-of-period cash amounts by $4.2 million and $5.5 million, respectively, and to decrease net cash used in investing activities by $1.3 million.

- added (2018-05-04):
[0001596532-18-000109:note_history:101]
Recent Accounting Pronouncements Not Yet Effective

- added (2018-05-04):
[0001596532-18-000109:note_history:102]
Leases

- added (2018-05-04):
[0001596532-18-000109:note_history:103]
In February 2016, the FASB issued ASU No, 2016-02, Leases. Under the guidance, lessees are required to recognize assets and lease liabilities on the balance sheet for most leases including operating leases and provide enhanced disclosures. There are optional practical expedients that a company may elect to apply. The guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years and may be early adopted.  As currently issued, companies are required to adopt this guidance to the earliest period presented using a modified retrospective approach. We are in the process of reviewing our existing lease agreements to assess the impact this guidance may have on our consolidated financial statements. We currently anticipate that the adoption of ASU 2016-02 will materially affect our consolidated balance sheets by recognizing new right-of-use assets and lease liabilities for operating leases, but will not have a material impact on our consolidated income statements.

- added (2018-05-04):
[0001596532-18-000109:note_history:104]
Credit Losses of Financial Instruments

- removed (2018-05-04):
[0001596532-17-000251:note_history:105]
Our consolidated financial statements and related financial information should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2016, filed with the SEC on February 17, 2017.

- removed (2018-05-04):
[0001596532-17-000251:note_history:106]
In March 2016, the Financial Accounting Standards Board (the “FASB”) amended the existing accounting standard for stock-based compensation, issuing Accounting Standards Update (“ASU”) 2016-09, Compensation-Stock Compensation: Improvements to Employee Share-Based Payment Accounting, which impacts several aspects of accounting for share-based payment transactions, including the income tax consequences, forfeitures, classification of awards as either equity or liabilities, and classification on the statement of cash flows. We adopted this standard during our first fiscal quarter of 2017. The impact of the adoption was as follows:

- removed (2018-05-04):
[0001596532-17-000251:note_history:107]
| • | Income tax accounting - The standard eliminates additional paid-in-capital (“APIC”) pools and requires excess tax benefits and tax deficiencies on share-based awards to be recognized in the income statement prospectively as discrete items upon exercise or vesting of such awards. The standard also requires excess tax benefits to be recognized regardless of whether the benefit reduces taxes payable. We adopted the guidance related to the timing of previously unrecognized excess tax benefits on a modified retrospective basis, which resulted in the recognition of a cumulative effect adjustment of $1.8 million that increased retained earnings and increased our long-term deferred income tax as of January 1, 2017. |

- removed (2018-05-04):
[0001596532-17-000251:note_history:108]
| • | Earnings per share - Because excess benefits are no longer recognized in APIC, the assumed proceeds from applying the treasury stock method when calculating dilutive shares was amended to exclude the amount of excess tax benefits that would be recognized upon exercise or vesting of such awards. As a result, this reduces the assumed shares to be repurchased under the treasury stock method, thereby increasing the amount of dilutive shares used to compute earnings per share. We adopted the guidance related to the exclusion of excess tax benefits in calculating earnings per share on a prospective basis. |

- removed (2018-05-04):
[0001596532-17-000251:note_history:109]
| • | Forfeitures of stock options and awards - Under the new standard, we can make an accounting policy election to either estimate the number of share-based awards that are expected to vest, or account for forfeitures when they occur. We elected to account for forfeitures when they occur and adopted this change on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as a $1.0 million decrease to retained earnings as of January 1, 2017. |

- removed (2018-05-04):
[0001596532-17-000251:note_history:110]
| • | Cash flow presentation of excess tax benefits - Prior to the new standard, we were required to present excess tax benefits on share-based awards as a cash inflow from financing activities with a corresponding cash outflow from operating activities. The new standard required that these excess tax benefits be classified with other income tax cash flows as an operating activity. We elected to adopt the guidance related to the presentation of excess tax benefits in our condensed consolidated statements of cash flows on a retrospective basis. |

- removed (2018-05-04):
[0001596532-17-000251:note_history:111]
In April 2015, the FASB issued ASU 2015-05, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement, providing guidance on fees paid in a cloud computing arrangement.  If a cloud computing arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. We adopted this standard in our first quarter of fiscal 2017 on a prospective basis, and the adoption did not have a material impact on our consolidated financial statements.

- removed (2018-05-04):
[0001596532-17-000251:note_history:112]
In July 2015, the FASB issued ASU No, 2015-11, Inventory: Simplifying the Measurement of Inventory, which simplifies the measurement of inventory to be measured at the lower of cost or net realizable value.  The guidance is effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years.  We adopted this standard in our first quarter of fiscal 2017 on a prospective basis, and the adoption did not have a material impact on our consolidated financial statements.

- removed (2018-05-04):
[0001596532-17-000251:note_history:113]
In May 2014, the FASB issued ASU No. 2014-09, Revenue From Contracts With Customers (Topic 606), (as amended in June 2016, by ASU No. 2016-12-Revenue-Narrow-Scope Improvements and Practical Expedients, and in December 2016, by ASU No. 2016-20-Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers), which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition.

- removed (2018-05-04):
[0001596532-17-000251:note_history:114]
In July 2015, the FASB issued ASU No. 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, deferring the effective date of the new revenue standard by one year. In March 2016, the FASB issued ASU No. 2016-08, Revenue From Contracts With Customers-Principal versus Agent Considerations (Reporting Revenue Gross versus Net), and ASU No. 2016-10, Revenue From Contracts With Customers-Identifying Performance Obligations and Licensing. ASU No. 2016-08 clarifies the implementation guidance regarding principal versus agent identification and related considerations. Specifically, the guidance provides clarification around performance obligations for goods or services provided by another entity, assisting in determining whether the entity is the provider of the goods or services, the principal, or whether the entity is providing for the arrangement of the goods or services, the agent.  ASU No. 2016-10 provides guidance around identifying whether promised goods or services are distinct and separately identifiable, whether promised goods or services are material or immaterial to the contract, and whether shipping and handling is considered an activity to fulfill a promise or an additional promised service. ASU No. 2016-10 also provides guidance around an entity's promise to grant a license providing a customer with either a right to use or a right to access the license, which then determines whether the obligation is satisfied at a point in time or over time, respectively.

- removed (2018-05-04):
[0001596532-17-000251:note_history:115]
In May 2016, the FASB issued ASU No. 2016-11, Revenue Recognition (Topic 605) and Derivatives and Hedging (Topic 815): Rescission of SEC Guidance Because of Accounting Standards Updates 2014-09 and 2014-16 Pursuant to Staff Announcements at the March 3, 2016 EITF Meeting (SEC Update)") ("ASU 2016-11"), which rescinds various standards codified as part of Topic 605, Revenue Recognition in relation to the future adoption of Topic 606. These rescissions include changes to topics pertaining to revenue and expense recognition including accounting for shipping and handling fees and costs and accounting for consideration given by a vendor to a customer.

- removed (2018-05-04):
[0001596532-17-000251:note_history:116]
The above standards are effective for fiscal years (and interim reporting periods within those years) beginning after December 15, 2017.  The guidance is effective for us beginning in our first quarter of fiscal 2018. Early adoption would be permitted for all entities but not until the fiscal year beginning after December 15, 2016. The standard permits the use of either the retrospective or cumulative effect transition method. The retrospective method requires a retrospective approach to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance. The cumulative approach requires a retrospective approach with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance.

- removed (2018-05-04):
[0001596532-17-000251:note_history:117]
The standards are expected to impact the amount and timing of revenue recognized and the related disclosures on our consolidated financial statements.  The standard will also require that we defer all incremental commission costs to obtain a customer contract. We are currently evaluating the accounting, transition and disclosure requirements of the standard and are in the process of assessing the financial statement impact upon adoption.  We will adopt ASU 2014-09 during the first quarter of 2018, and expect to adopt the guidance under the modified retrospective method which we anticipate will result in a cumulative effect adjustment as of the date of adoption.

- removed (2018-05-04):
[0001596532-17-000251:note_history:118]
In January 2016, the FASB issued ASU No, 2016-01, Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities, which enhances the reporting model for financial instruments to provide users of financial statements with more decision-useful information. The guidance will address certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. The standard is effective for us for our first quarter of fiscal 2018, and may be early adopted under early application guidance.  While we are currently assessing the impact this guidance may have on our consolidated financial statements, we expect the adoption of this standard to increase the variability of other income (expense), net on our consolidated financial statements as a result of changes in the fair value of our marketable equity securities.

- removed (2018-05-04):
[0001596532-17-000251:note_history:119]
In February 2016, the FASB issued ASU No, 2016-02, Leases, which addresses the classification and recognition of lease assets and liabilities formerly classified as operating leases under GAAP. The guidance will address certain aspects of recognition and measurement, and quantitative and qualitative aspects of presentation and disclosure. The guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. The standard is effective for us for our first quarter of fiscal 2019.  The guidance will be applied to the earliest period presented using a modified retrospective approach. The guidance includes practical expedients that relate to identification, classification, and initial direct costs associated with leases commencing prior to the effective date, and the ability to apply hindsight in evaluating lease options related to extensions, terminations or asset purchases.  A practical expedient also exists to treat leases entered into prior effective date under existing GAAP unless the lease has been modified. The guidance may be early adopted. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

- removed (2018-05-04):
[0001596532-17-000251:note_history:120]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Task Force), which addresses eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. The guidance may be adopted early as of the beginning of an annual reporting period.  The guidance will be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  The standard is effective for us for our first quarter of fiscal 2018.  While we are currently assessing the impact this guidance may have on our consolidated financial statements, we do not expect the guidance to have a material impact on our consolidated financial statements.

- removed (2018-05-04):
[0001596532-17-000251:note_history:121]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force which requires that amounts generally described as restricted cash or restricted cash equivalents be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. This standard is effective for us for our first quarter of fiscal 2018, and may be early adopted. We do not anticipate this standard will have a material impact on our consolidated financial statements.

- removed (2018-05-04):
[0001596532-17-000251:note_history:122]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (Topic 718) Scope of Modification Accounting which addresses providing clarity to reduce diversity in practice, cost and complexity in the application of modification accounting when there is a change in terms or conditions of a share-based payment award.  The guidance will be applied on a prospective basis to awards modified on or after the adoption date. This standard is effective for us for our first quarter of fiscal 2018, and may be early adopted. We do not anticipate this standard will have a material impact on our consolidated financial statements.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-05-04):
[0001596532-18-000109:note_history:123]
Effective January 1, 2018, we adopted a new revenue recognition policy in accordance with ASC 606 using the modified retrospective method as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1.  Prior to 2018, our revenue recognition policy was based on ASC 605 Revenue Recognition, and is described in Note 1 of Notes to Consolidated Financial Statements under Item 8 of our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

- added (2018-05-04):
[0001596532-18-000109:note_history:124]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with post-contract customer support (“PCS”). We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

- added (2018-05-04):
[0001596532-18-000109:note_history:125]
| • | Identification of the contract, or contracts, with a customer |

- added (2018-05-04):
[0001596532-18-000109:note_history:126]
| • | Identification of the performance obligations in the contract |

- added (2018-05-04):
[0001596532-18-000109:note_history:127]
| • | Determination of the transaction price |

- added (2018-05-04):
[0001596532-18-000109:note_history:128]
| • | Allocation of the transaction price to the performance obligations in the contract |

- added (2018-05-04):
[0001596532-18-000109:note_history:129]
| • | Recognition of revenue when (or as) we satisfy the performance obligation |

- added (2018-05-04):
[0001596532-18-000109:note_history:130]
Post-Contract Customer Support

- added (2018-05-04):
[0001596532-18-000109:note_history:131]
Post-contract support, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernable pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and addresses customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

- added (2018-05-04):
[0001596532-18-000109:note_history:132]
Contracts with Multiple Performance Obligations

- added (2018-05-04):
[0001596532-18-000109:note_history:133]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts which contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is required to determine the SSP for each distinct performance obligation.  We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

- added (2018-05-04):
[0001596532-18-000109:note_history:134]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services are sold, and the size of the end customer.

- added (2018-05-04):
[0001596532-18-000109:note_history:135]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

- added (2018-05-04):
[0001596532-18-000109:note_history:136]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

- added (2018-05-04):
[0001596532-18-000109:note_history:137]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

- added (2018-05-04):
[0001596532-18-000109:note_history:138]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

- added (2018-05-04):
[0001596532-18-000109:note_history:139]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

- added (2018-05-04):
[0001596532-18-000109:note_history:140]
Assets Recognized from Costs to Obtain a Contract with a Customer

- added (2018-05-04):
[0001596532-18-000109:note_history:141]
Effective January 1, 2018 in accordance with ASC 606, we recognize an asset for the incremental costs of obtaining a contract with a customer if we expect the benefit of those costs to be longer than one year. We have determined that certain sales commissions earned by our sales force meet the requirements to be capitalized. These costs are deferred and then amortized over a period of benefit that we have determined to be five years. Total capitalized costs to obtain a contract are included in other current and long-term assets on our consolidated balance sheets.
