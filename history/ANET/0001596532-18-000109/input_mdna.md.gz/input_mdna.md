# ANET MD&A — 0001596532-18-000109


## mdna

[0001596532-18-000109:mdna:1]
Item 2.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001596532-18-000109:mdna:2]
[same as prior period, unchanged from 0001596532-17-000251:mdna:2]

[0001596532-18-000109:mdna:3]
[same as prior period, unchanged from 0001596532-17-000251:mdna:3]

[0001596532-18-000109:mdna:4]
We believe that cloud networks will continue to replace legacy network technologies, and that our cloud networking platform addresses the large and growing cloud networking segment of data center switching, which remains in the early stage of adoption. Cloud networks are subject to increasing performance requirements due to the growing number of connected devices, as well as new enterprise and consumer applications. Computing architectures are evolving to meet the need for constant connectivity and access to data and applications. We expect to continue growing our organization to meet the needs of new and existing customers as they increasingly realize the performance and cost benefits of our cloud networking solutions and as they expand their cloud networks. Accordingly, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our rapid development of new features and applications.

[0001596532-18-000109:mdna:5]
We generate revenue primarily from sales of our switching products which incorporate our EOS software. We generate the majority of our services revenue from post contract support, or PCS, which end customers typically purchase in conjunction with our products. Our end customers span a range of industries and include large Internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others. As we have grown the functionality of our EOS software, expanded the range of our product portfolio and increased the size of our sales force, our revenue has continued to grow rapidly. We have also been profitable and operating cash flow positive for each year since 2010.

[0001596532-18-000109:mdna:6]
To continue to grow our revenue, it is important that we both obtain new customers and sell additional products to existing customers. We expect that a substantial portion of our future sales will be follow-on sales to existing customers. We intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new end customers more effectively, increase sales to existing customers, and provide services and support effectively. In order to support our strong growth, we have and may continue to accelerate our investment in infrastructure, such as enterprise resource planning software and other technologies to improve the efficiency of our operations.

[0001596532-18-000109:mdna:7]
[same as prior period, unchanged from 0001596532-17-000251:mdna:7]

[0001596532-18-000109:mdna:8]
[same as prior period, unchanged from 0001596532-17-000251:mdna:8]

[0001596532-18-000109:mdna:9]
Furthermore, to comply with the limited exclusion order and cease and desist order in the 945 Investigation as described in Note 5 of Notes to Condensed Consolidated Financial Statements of this Form 10-Q, we have made design changes to our products for sale in the United States to address the features that were found to infringe the patent claims underlying the remedial orders in the 945

[0001596532-18-000109:mdna:10]
Investigation.  We made significant progress with respect to customer certification of these redesigns during the first quarter of 2018, with final certification pending for a limited number of specific use cases at the end of the period.  We will continue to work with customers to further improve the redesigns in order to meet their requirements, including consideration of the impact of the expiration of the ‘577 patent on June 30, 2018, and the likely invalidation of the ‘668 patent. We will need to complete any outstanding product modifications and qualification and acceptance processes for these customer use cases, and any inability to do so in a timely manner may result in an impact to our business, our revenue and our deferred revenue balances.

[0001596532-18-000109:mdna:11]
We also filed a motion with the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”) requesting that it stay the orders of the United States International Trade Commission (“USITC”), pending completion of the appeals of the decisions of the PTAB, and sought an expedited schedule for those appeals. On September 22, 2017, the Federal Circuit denied the motion to stay, but has allowed us to import our redesigned products into the United States without being blocked by the USITC’s orders, subject to any determinations by the USITC in subsequent proceedings regarding the redesigned products. On October 27, 2017, the USITC instituted a modification proceeding to determine whether our redesigned products infringe the patent claims underlying the remedial orders in the 945 Investigation.  The ALJ held a hearing on January 26, 2018 and issued a recommended determination (“RD”) on March 23, 2018.  The RD found that our redesigned products do not infringe the ’577 patent but do infringe the ’668 patent. The RD will be subject to review by the USITC after which the USITC will issue a final determination. The USITC has not set a target date for the final determination. On April 5, 2018, the USITC issued an order suspending enforcement of the remedial orders as to the ’668 patent.

[0001596532-18-000109:mdna:12]
[same as prior period, unchanged from 0001596532-17-000251:mdna:12]

[0001596532-18-000109:mdna:13]
The following table summarizes historical results of operations for the periods presented and as a percentage of revenue for those periods.  We have derived the data for the three months ended March 31, 2018 and 2017 from our unaudited condensed consolidated financial statements included in this Form 10-Q.

[0001596532-18-000109:mdna:14]
|  |  | Three Months Ended March 31, |
|  |  | 2018 |  | 2017 |
|  |  | (in thousands) |
| Consolidated Statements of Operations Data: |  |  |  |  |
| Revenue |  |  |  |  |
| Product |  | $ | 407,617 |  |  | $ | 291,367 |  |
| Service |  | 64,872 |  |  | 44,108 |  |
| Total revenue |  | 472,489 |  |  | 335,475 |  |
| Cost of revenue (1) |  |  |  |  |
| Product |  | 156,691 |  |  | 109,836 |  |
| Service |  | 12,879 |  |  | 11,429 |  |
| Total cost of revenue |  | 169,570 |  |  | 121,265 |  |
| Gross profit |  | 302,919 |  |  | 214,210 |  |
| Operating expenses (1) |  |  |  |  |
| Research and development |  | 102,362 |  |  | 81,610 |  |
| Sales and marketing |  | 42,140 |  |  | 37,027 |  |
| General and administrative |  | 19,679 |  |  | 22,155 |  |
| Total operating expenses |  | 164,181 |  |  | 140,792 |  |
| Income from operations |  | 138,738 |  |  | 73,418 |  |
| Other income (expense), net |  |  |  |  |
| Interest expense |  | (687 | ) |  | (715 | ) |
| Other income (expense), net |  | 4,843 |  |  | 1,025 |  |
| Total other income (expense), net |  | 4,156 |  |  | 310 |  |
| Income before benefit from income taxes |  | 142,894 |  |  | 73,728 |  |
| Benefit from income taxes |  | (1,644 | ) |  | (9,233 | ) |
| Net income |  | $ | 144,538 |  |  | $ | 82,961 |  |
| __________________________ |  |  |  |  |

[0001596532-18-000109:mdna:15]
(1) Includes stock-based compensation expense as follows:

[0001596532-18-000109:mdna:16]
25

[0001596532-18-000109:mdna:17]
|  |  | Three Months Ended March 31, |
|  |  | 2018 |  | 2017 |
|  |  | (in thousands) |
| Stock-Based Compensation Expense: |  |  |  |  |
| Cost of revenue |  | $ | 1,202 |  |  | $ | 1,024 |  |
| Research and development |  | 10,945 |  |  | 9,587 |  |
| Sales and marketing |  | 5,960 |  |  | 3,456 |  |
| General and administrative |  | 2,744 |  |  | 2,372 |  |
| Total stock-based compensation |  | $ | 20,851 |  |  | $ | 16,439 |  |

[0001596532-18-000109:mdna:18]
|  |  | Three Months Ended March 31, |
|  |  | 2018 |  | 2017 |
|  |  | (as a percentage of revenue) |
| Revenue |  |  |  |  |
| Product |  | 86.3 | % |  | 86.9 | % |
| Service |  | 13.7 |  |  | 13.1 |  |
| Total revenue |  | 100.0 |  |  | 100.0 |  |
| Cost of revenue |  |  |  |  |
| Product |  | 33.2 |  |  | 32.7 |  |
| Service |  | 2.7 |  |  | 3.4 |  |
| Total cost of revenue |  | 35.9 |  |  | 36.1 |  |
| Gross margin |  | 64.1 |  |  | 63.9 |  |
| Operating expenses |  |  |  |  |
| Research and development |  | 21.6 |  |  | 24.4 |  |
| Sales and marketing |  | 8.9 |  |  | 11.0 |  |
| General and administrative |  | 4.2 |  |  | 6.6 |  |
| Total operating expenses |  | 34.7 |  |  | 42.0 |  |
| Income from operations |  | 29.4 |  |  | 21.9 |  |
| Interest expense |  | (0.1 | ) |  | (0.2 | ) |
| Other income (expense), net |  | 0.9 |  |  | 0.3 |  |
| Total other income (expense), net |  | 0.8 |  |  | 0.1 |  |
| Income before benefit from income taxes |  | 30.2 |  |  | 22.0 |  |
| Benefit from income taxes |  | (0.4 | ) |  | (2.8 | ) |
| Net income |  | 30.6 | % |  | 24.8 | % |

[0001596532-18-000109:mdna:19]
Three Months Ended March 31, 2018 Compared to Three Months Ended March 31, 2017

[0001596532-18-000109:mdna:20]
Revenue, Cost of Revenue and Gross Profit (in thousands, except percentages)

[0001596532-18-000109:mdna:21]
|  |  | Three Months Ended March 31, |  | Change in |
|  |  | 2018 |  | 2017 |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 407,617 |  |  | $ | 291,367 |  |  | $ | 116,250 |  |  | 39.9 | % |
| Service |  | 64,872 |  |  | 44,108 |  |  | 20,764 |  |  | 47.1 |  |
| Total revenue |  | 472,489 |  |  | 335,475 |  |  | 137,014 |  |  | 40.8 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |
| Product |  | 156,691 |  |  | 109,836 |  |  | 46,855 |  |  | 42.7 |  |
| Service |  | 12,879 |  |  | 11,429 |  |  | 1,450 |  |  | 12.7 |  |
| Total cost of revenue |  | 169,570 |  |  | 121,265 |  |  | 48,305 |  |  | 39.8 |  |
| Gross profit |  | $ | 302,919 |  |  | $ | 214,210 |  |  | $ | 88,709 |  |  | 41.4 | % |
| Gross margin |  | 64.1 | % |  | 63.9 | % |  |  |  |  |

[0001596532-18-000109:mdna:22]
Revenue by Geography (in thousands, except percentages)

[0001596532-18-000109:mdna:23]
|  |  | Three Months Ended March 31, |
|  |  | 2018 |  | % of Total |  | 2017 |  | % of Total |
| Americas |  | $ | 315,498 |  |  | 66.8 | % |  | $ | 264,863 |  |  | 79.0 | % |
| Europe, Middle East and Africa |  | 121,886 |  |  | 25.8 |  |  | 42,734 |  |  | 12.7 |  |
| Asia-Pacific |  | 35,105 |  |  | 7.4 |  |  | 27,878 |  |  | 8.3 |  |
| Total revenue |  | $ | 472,489 |  |  | 100.0 | % |  | $ | 335,475 |  |  | 100.0 | % |

[0001596532-18-000109:mdna:24]
[same as prior period, unchanged from 0001596532-17-000251:mdna:29]

[0001596532-18-000109:mdna:25]
Product revenue increased $116.3 million, or 39.9%, in the three months ended March 31, 2018 compared to the same period in 2017. The increase was primarily driven by our existing customers as they continued to expand their businesses. In addition, our newer switch products have continued to gain market acceptance, which has contributed to our revenue growth.  Service revenue increased $20.8 million, or 47.1%, in the three months ended March 31, 2018 compared to the same period in 2017 as a result of continued growth in initial and renewal support contracts as our customer installed base continued to expand. We continue to experience pricing pressure on our products and services due to competition, but demand for our products and growth in our installed base more than offset this pricing pressure.

[0001596532-18-000109:mdna:26]
Excluding the reclassification to other current and noncurrent liabilities in connection with our adoption of ASC 606, deferred revenue decreased $42.7 million from December 31, 2017 to March 31, 2018, which was primarily due to a decrease in deferred product revenue as customers continued to certify and accept our 945 investigation-related product redesigns. We expect to continue to work with these customers to complete their remaining qualification activities and expect to recognize any remaining 945 investigation-related deferred revenue as revenue at that time.

[0001596532-18-000109:mdna:27]
We expect our revenue may vary from period to period based on, among other things, the timing and size of orders, the delivery and acceptance of products, and the impact of significant transactions.  In addition, while we expect our revenue to continue to grow in absolute dollars on a year over year basis, our revenue growth rates are expected to decline as our business scales.

[0001596532-18-000109:mdna:28]
[same as prior period, unchanged from 0001596532-17-000251:mdna:31]

[0001596532-18-000109:mdna:29]
Cost of revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs in our manufacturing operations department, and other manufacturing-related costs associated with manufacturing our products and managing our inventory.  Cost of revenue increased $48.3 million or 39.8% for the three months ended March 31, 2018 compared to the same period in 2017. The increase in cost of revenue was primarily due to the corresponding increase in product revenue. We expect our cost of product revenue to increase as our product revenue increases. Cost of providing PCS and other services consists primarily of personnel costs for our global customer support organization.

[0001596532-18-000109:mdna:30]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including sales to large end customers who generally receive lower pricing, manufacturing-related costs including costs associated with supply chain sourcing activities, merchant silicon costs, the mix of products sold, and excess/obsolete inventory write-downs, including charges for excess/obsolete component inventory held by our contract manufacturers. Gross margin remained consistent, increasing slightly from 63.9% to 64.1% for the three months ended March 31, 2018 compared to the same period in 2017. This increase was primarily driven by relatively fixed manufacturing overhead and service costs as we scaled our business, partially offset by a decrease

[0001596532-18-000109:mdna:31]
in product margins due primarily to product mix. We expect our gross margins to fluctuate over time, depending on the factors described above.

[0001596532-18-000109:mdna:32]
Operating Expenses (in thousands, except percentages)

[0001596532-18-000109:mdna:33]
[same as prior period, unchanged from 0001596532-17-000251:mdna:35]

[0001596532-18-000109:mdna:34]
|  |  | Three Months Ended March 31, |  | Change in |
|  |  | 2018 |  | 2017 |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 102,362 |  |  | $ | 81,610 |  |  | $ | 20,752 |  |  | 25.4 | % |
| Sales and marketing |  | 42,140 |  |  | 37,027 |  |  | 5,113 |  |  | 13.8 |  |
| General and administrative |  | 19,679 |  |  | 22,155 |  |  | (2,476 | ) |  | (11.2 | ) |
| Total operating expenses |  | $ | 164,181 |  |  | $ | 140,792 |  |  | $ | 23,389 |  |  | 16.6 | % |

[0001596532-18-000109:mdna:35]
Research and development.

[0001596532-18-000109:mdna:36]
Research and development expenses increased $20.8 million, or 25.4%, for the three months ended March 31, 2018 compared to the same period in 2017. The increase was primarily due to an $11.0 million increase in personnel costs, including stock-based compensation and corporate bonuses, driven primary by headcount growth and an increase in the grant-date fair value of equity awards, a $9.2 million increase in third-party engineering costs driven by additional outsourced development projects, and a $1.9 million increase in facility and IT costs due to headcount growth and increased business activities.

[0001596532-18-000109:mdna:37]
We expect our research and development expenses to increase in absolute dollars as we continue to invest heavily in software development in order to expand the capabilities of our cloud networking platform, introduce new products and features and build upon our technology leadership.

[0001596532-18-000109:mdna:38]
Sales and marketing.

[0001596532-18-000109:mdna:39]
Sales and marketing expenses increased $5.1 million, or 13.8% for the three months ended March 31, 2018 compared to the same period in 2017. The increase was primarily due to a $4.7 million increase in personnel costs, including higher stock-based compensation, driven by headcount growth and an increase in the grant date fair value of equity awards.

[0001596532-18-000109:mdna:40]
We expect our sales and marketing expenses to increase in absolute dollars as we continue to expand our sales and marketing efforts worldwide.

[0001596532-18-000109:mdna:41]
General and administrative.

[0001596532-18-000109:mdna:42]
General and administrative expenses decreased $2.5 million, or 11.2%, for the three months ended March 31, 2018 compared to the same period in 2017. The decrease was primarily due to a $4.4 million decrease in litigation related expenses due to the timing of litigation activities associated with our ongoing Cisco legal matters. This decrease was offset partially by a $1.0 million increase in personnel related costs, including increased stock-based compensation, driven by increased headcount and an increase in the grant-date fair value of our equity awards.

[0001596532-18-000109:mdna:43]
We expect our general and administrative expenses to fluctuate in absolute dollars from period to period depending on the timing and progress of our litigation activities.

[0001596532-18-000109:mdna:44]
Other Income (Expense), Net (in thousands, except percentages)

[0001596532-18-000109:mdna:45]
|  |  | Three Months Ended March 31, |  | Change in |
|  |  | 2018 |  | 2017 |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |
| Interest expense |  | $ | (687 | ) |  | $ | (715 | ) |  | $ | 28 |  |  | (3.9 | )% |
| Other income (expense), net |  | 4,843 |  |  | 1,025 |  |  | 3,818 |  |  | 372.5 |  |
| Total other income (expense), net |  | $ | 4,156 |  |  | $ | 310 |  |  | $ | 3,846 |  |  | 1,240.6 | % |

[0001596532-18-000109:mdna:46]
Other income (expense), net increased during the three months ended March 31, 2018 compared to the same period in 2017 primarily due to an increase in interest income as we continued to generate cash and expand our marketable securities portfolios.

[0001596532-18-000109:mdna:47]
We expect our interest income continue to grow in 2018 as we continue to grow our cash balance and invest our excess cash in marketable securities. We expect our foreign currency gains and losses continue to fluctuate in the future due to changes in foreign currency exchange rates. In connection with our adoption of ASU 2016-01, other income (expense) may fluctuate in the future as a result

[0001596532-18-000109:mdna:48]
28

[0001596532-18-000109:mdna:49]
of the re-measurement of our private company equity investments upon the occurrence of observable price changes and/or impairments.  See Note 1 of Notes to Condensed Consolidated Financial Statements for details of this new guidance.

[0001596532-18-000109:mdna:50]
Benefit from Income Taxes (in thousands, except percentages)

[0001596532-18-000109:mdna:51]
[same as prior period, unchanged from 0001596532-17-000251:mdna:52]

[0001596532-18-000109:mdna:52]
|  |  | Three Months Ended March 31, |  | Change in |
|  |  | 2018 |  | 2017 |  | $ |  | % |
| Benefit from income taxes |  | $ | (1,644 | ) |  | $ | (9,233 | ) |  | $ | 7,589 |  |  | (82.2 | ) |
| Effective tax rate |  | (1.2 | )% |  | (12.5 | )% |  |  |  |  |  |  |

[0001596532-18-000109:mdna:53]
The change in the effective tax rate in the three months ended March 31, 2018, as compared to the same period in 2017, was primarily due to the overall increase in earnings and the inclusion of foreign earnings in the U.S. which proportionally exceeded the increase in excess tax benefits attributable to equity compensation.  These changes were all taxed at a lower U.S. corporate tax rate under the Tax Cuts and Jobs Act (the “Tax Act”) passed in December 2017.

[0001596532-18-000109:mdna:54]
On December 22, 2017, the U.S. government enacted comprehensive tax legislation. The Tax Act makes broad and complex changes to the U.S. tax code, including, but not limited to, (1) reducing the U.S. federal corporate tax rate from 35 percent to 21 percent; (2) requiring companies to pay a one-time transition tax on certain unrepatriated earnings of foreign subsidiaries; (3) generally eliminating U.S. federal income taxes on dividends from foreign subsidiaries; (4) requiring a current inclusion in U.S. federal taxable income of certain earnings of controlled foreign corporations; and (5) creating the base erosion anti-abuse tax (“BEAT”), a new minimum tax.

[0001596532-18-000109:mdna:55]
The Tax Act includes provisions for Global Intangible Low-Taxed Income (“GILTI”) wherein taxes on foreign income are imposed in excess of a deemed return on tangible assets of foreign corporations. This income will effectively be taxed at a 10.5% tax rate in general. Our deferred tax assets and liabilities are still being evaluated to determine if they should be recognized for the basis differences expected to reverse as a result of GILTI provisions that are effective for us after the calendar year ending December 31, 2017. Because of the complexity of the new provisions, we are continuing to evaluate how the provisions will be accounted for under U.S. GAAP wherein companies are allowed to make an accounting policy election of either (i) account for GILTI as a component of tax expense in the period in which we are subject to the rules (the “period cost method”), or (ii) account for GILTI in our measurement of deferred taxes (the “deferred method”). Currently, we have not elected a method but we have included an estimate of the impact to our effective tax rate for the year ended December 31, 2018.  A formal election will only be made  after our completion of the analysis of the GILTI provisions and our election method will depend, in part, on analyzing our global income to determine whether we expect to have future U.S. inclusions in our taxable income related to GILTI and, if so, the impact that is expected.

[0001596532-18-000109:mdna:56]
As of March 31, 2018, we have not yet completed our accounting for the tax effects of the enactment of the Tax Act.  We recognized a provisional tax amount of $51.8 million in the fourth quarter of 2017 for the transition tax liability and the revaluation of our deferred income taxes as a result of the rate change. In the three months ended March 31, 2018, we did not revise this estimate.  In addition, we recorded a reasonable estimate for the effect of the new legislation as discussed above, which impacts the US income tax liabilities for the year ending December 31, 2018. Our estimates may also be affected as we gain a more thorough understanding of the tax law. These changes could be material to income tax expense. We will continue to refine our estimates related to the impact of the Tax Act during the one year measurement period allowed under Staff Accounting Bulletin 118 (“SAB 118”).

[0001596532-18-000109:mdna:57]
[same as prior period, unchanged from 0001596532-17-000251:mdna:55]

[0001596532-18-000109:mdna:58]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of March 31, 2018, our total balance of cash, cash equivalents and marketable securities was $1.7 billion, of which approximately $197.3 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-18-000109:mdna:59]
Our cash, cash equivalents and marketable securities are held for working capital purposes. Our marketable securities investment portfolio is primarily invested in highly-rated securities with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities together with cash generated from operations will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and costs incurred related to outstanding litigation claims. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If

[0001596532-18-000109:mdna:60]
we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-18-000109:mdna:61]
[same as prior period, unchanged from 0001596532-17-000251:mdna:59]

[0001596532-18-000109:mdna:62]
|  |  | Three Months Ended March 31, |
|  |  | 2018 |  | 2017 As Adjusted (1) |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 195,541 |  |  | $ | 162,862 |  |
| Cash used in investing activities (1) |  | (183,864 | ) |  | (1,668 | ) |
| Cash provided by financing activities |  | 15,308 |  |  | 18,518 |  |
| Effect of exchange rate changes |  | (14 | ) |  | 184 |  |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 26,971 |  |  | $ | 179,896 |  |
| ___________________________ |  |  |  |  |
| (1) Cash used in investing activities for the three months ended March 31, 2017 was adjusted as a result of our adoption of ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash, in the first quarter of 2018. See Note 1 of Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Form 10-Q for more information. |

[0001596532-18-000109:mdna:63]
[same as prior period, unchanged from 0001596532-17-000251:mdna:61]

[0001596532-18-000109:mdna:64]
During the three months ended March 31, 2018, cash provided by operating activities was $195.5 million, primarily from net income of $144.5 million with non-cash adjustments to net income of $23.0 million, and a net increase of $28.0 million in cash from changes in our operating assets and liabilities. Our operating cash benefited $40.0 million from a decline in accounts receivable resulted from strong cash collections in the quarter, $38.1 million from decreased inventory driven by improved management and timing of receipts, and $20.0 million from an increase in accounts payable due to timing of inventory purchases and receipts. These favorable changes were partially offset by a $48.1 million decline in accrued liabilities due to corporate bonus payments and timing of vendor payments related to product development activities and inventory purchases, a $42.7 million decline in deferred revenue primarily due to revenue recognition as customers continued to certify and accept our 945 investigation-related product redesigns in the first quarter of 2018.

[0001596532-18-000109:mdna:65]
During the three months ended March 31, 2017, cash provided by operating activities was $162.9 million, resulting from net income of $83.0 million, non-cash adjustments to net income of $24.2 million, and a net increase in cash from changes in our operating assets and liabilities of $55.7 million. Our operating cash benefited from increased deferred revenue of $124.2 million resulting from growth in product deferred revenue related to contract acceptance terms and ongoing growth in PCS contracts. In addition, we experienced strong cash collections in the period, generating $44.1 million of cash. These increases were partially offset by growth in inventory of $50.3 million, supporting overall growth in the business and the expansion of our manufacturing and supply chain activities. In addition, accounts payable and accrued liabilities declined $33.8 million primarily due to corporate bonus payments and the timing of vendor payments related to inventory purchases. Prepaid expenses and current assets increased by $29.1 million primarily due to higher deferred cost of inventory associated with the increased product revenue deferrals referenced above, and an increase in income taxes receivable from excess tax benefits generated from stock option exercises and vesting of stock awards.

[0001596532-18-000109:mdna:66]
[same as prior period, unchanged from 0001596532-17-000251:mdna:65]

[0001596532-18-000109:mdna:67]
During the three months ended March 31, 2018, cash used in investing activities was $183.9 million, consisting of purchases of available-for-sale securities of $268.0 million, offset by proceeds of $90.4 million from maturities of marketable securities, and purchases of property and equipment of $6.3 million.

[0001596532-18-000109:mdna:68]
During the three months ended March 31, 2017, cash used in investing activities was $1.7 million, consisting of purchases of available-for-sale securities of $61.5 million, offset by proceeds of $64.5 million and purchases of property, equipment and other assets of $4.6 million.

[0001596532-18-000109:mdna:69]
[same as prior period, unchanged from 0001596532-17-000251:mdna:68]

[0001596532-18-000109:mdna:70]
During the three months ended March 31, 2018, cash provided by financing activities was $15.3 million, consisting primarily of proceeds from the issuance of common stock under employee equity incentive plans of $17.3 million.

[0001596532-18-000109:mdna:71]
During the three months ended March 31, 2017, cash provided by financing activities was $18.5 million, consisting primarily of proceeds from the issuance of common stock under employee equity incentive plans of $19.5 million.

[0001596532-18-000109:mdna:72]
[same as prior period, unchanged from 0001596532-17-000251:mdna:71]

[0001596532-18-000109:mdna:73]
As of March 31, 2018, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-18-000109:mdna:74]
[same as prior period, unchanged from 0001596532-17-000251:mdna:73]

[0001596532-18-000109:mdna:75]
Our contractual obligations represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalent and marketable securities. As of March 31, 2018, our principal commitments consist primarily of obligations under operating and financing leases for offices and data centers and purchase commitments with our contract manufacturers and suppliers. There have been no significant changes to these obligations during the three months ended March 31, 2018, compared to the contractual obligations disclosed in our “Management's Discussion and Analysis of Financial Condition and Results of Operations” included in our Annual Report on Form 10-K, filed with the SEC on February 20, 2018, other than the new operating leases entered into in 2018 and the purchase commitments described in Note 5 of Notes to Condensed Consolidated Financial Statements of this Form 10-Q.

[0001596532-18-000109:mdna:76]
[same as prior period, unchanged from 0001596532-17-000251:mdna:75]

[0001596532-18-000109:mdna:77]
Our management’s discussion and analysis of financial condition and results of operations is based on our unaudited condensed consolidated financial statements, which have been prepared in accordance with GAAP.  The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001596532-18-000109:mdna:78]
During the three months ended March 31, 2018, we adopted the new revenue recognition guidance under ASC 606 as discussed in the section titled Recently Adopted Accounting Pronouncements of  Note 1 of Notes to Condensed Consolidated Financial Statements of this Form 10-Q. As a result, we updated our critical accounting policy on revenue recognition as follows. There have been no changes to our other critical accounting policies and estimates discussed in the section titled Management's Discussion and Analysis of Financial Condition and Results of Operations under PART II, Item 7, of our Annual Report on Form 10-K filed with the SEC on February 20, 2018. We believe our critical accounting policies and estimates reflect our significant judgments and estimates used in the preparation of the condensed consolidated financial statements in this Form 10-Q.

[0001596532-18-000109:mdna:79]
Revenue Recognition

[0001596532-18-000109:mdna:80]
The following revenue recognition policy was effective January 1, 2018 following our adoption of the new revenue recognition guidance under ASC 606 using the modified retrospective method as discussed in the section titled Recently Adopted Accounting Pronouncements of Note 1 of Notes to Condensed Consolidated Financial Statements of this Form 10-Q.  Prior to 2018, our revenue recognition policy was under ASC 605, Revenue Recognition, and is described in Note 1 of Notes to Consolidated Financial Statements under PART II, Item 8, of our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

[0001596532-18-000109:mdna:81]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with PCS. We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

[0001596532-18-000109:mdna:82]
| • | Identification of the contract, or contracts, with a customer |

[0001596532-18-000109:mdna:83]
| • | Identification of the performance obligations in the contract |

[0001596532-18-000109:mdna:84]
| • | Determination of the transaction price |

[0001596532-18-000109:mdna:85]
| • | Allocation of the transaction price to the performance obligations in the contract |

[0001596532-18-000109:mdna:86]
| • | Recognition of revenue when (or as) we satisfy the performance obligation |

[0001596532-18-000109:mdna:87]
Post-Contract Customer Support

[0001596532-18-000109:mdna:88]
PCS, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernable pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and addresses customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-18-000109:mdna:89]
Contracts with Multiple Performance Obligations

[0001596532-18-000109:mdna:90]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts which contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the SSP. Judgment is required to determine the SSP for each distinct performance obligation.  We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

[0001596532-18-000109:mdna:91]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services are sold, and the size of the end customer.

[0001596532-18-000109:mdna:92]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

[0001596532-18-000109:mdna:93]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

[0001596532-18-000109:mdna:94]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-18-000109:mdna:95]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

[0001596532-18-000109:mdna:96]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

[0001596532-18-000109:mdna:97]
[same as prior period, unchanged from 0001596532-17-000251:mdna:77]

[0001596532-18-000109:mdna:98]
Refer to the sections titled “Recently Adopted Accounting Pronouncements” and “Recent Accounting Pronouncements Not Yet Effective” in Note 1 of Notes to Condensed Consolidated Financial Statements of this Form 10-Q.
