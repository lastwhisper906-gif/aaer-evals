# ANET MD&A — 0001596532-23-000197


## mdna

[0001596532-23-000197:mdna:1]
[same as prior period, unchanged from 0001596532-23-000104:mdna:1]

[0001596532-23-000197:mdna:2]
[same as prior period, unchanged from 0001596532-23-000104:mdna:2]

[0001596532-23-000197:mdna:3]
[same as prior period, unchanged from 0001596532-23-000104:mdna:3]

[0001596532-23-000197:mdna:4]
[same as prior period, unchanged from 0001596532-23-000104:mdna:4]

[0001596532-23-000197:mdna:5]
[same as prior period, unchanged from 0001596532-23-000104:mdna:5]

[0001596532-23-000197:mdna:6]
[same as prior period, unchanged from 0001596532-23-000104:mdna:6]

[0001596532-23-000197:mdna:7]
[same as prior period, unchanged from 0001596532-23-000104:mdna:7]

[0001596532-23-000197:mdna:8]
[same as prior period, unchanged from 0001596532-23-000104:mdna:8]

[0001596532-23-000197:mdna:9]
[same as prior period, unchanged from 0001596532-23-000104:mdna:9]

[0001596532-23-000197:mdna:10]
[same as prior period, unchanged from 0001596532-23-000104:mdna:10]

[0001596532-23-000197:mdna:11]
We have continued to work closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. We have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, and have begun to see some reduction in customer lead times on certain products. Over time, the recovery of capacity should allow us to ship products against previously committed deployment plans and accelerate some deployments where needed, while trying to limit building customer inventory.  On this basis, we now expect some shipments against these deployment schedules to extend into 2024. As customer lead times reduce more broadly, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to somewhat shorter demand-planning horizons which has resulted in lower demand levels.  Given the shipment and order patterns described above, near term revenue trends may not be reflective of current demand levels, but will benefit from deployment plans that had been previously committed. While inventory and working capital levels may continue to increase and remain elevated in the near term, we expect that purchase commitments will continue to decline as supplier lead times shorten.  Although these elevated inventory positions are largely related to early life cycle products, we cannot be certain that we will be able to sell all of this inventory, which may in the future result in excess and obsolete inventory charges.

[0001596532-23-000197:mdna:12]
In addition, inflation pressure in our supply chain, scarcity of some materials needed to build our products and disruptions to our manufacturing process have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. Our operating cash-flows have also been and may continue to be negatively impacted by significant component inventories on hand or at our contract manufacturers. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the Russia-Ukraine conflict, continued escalation of the conflict may negatively impact the global economy and our future operating results and financial condition.

[0001596532-23-000197:mdna:13]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational

[0001596532-23-000197:mdna:14]
and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable; however, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that our customers, following a year of elevated purchases, must now consider changing technology roadmaps and priorities, including the need for the rapid deployment of AI and related technologies, resulting in some uncertainty as to future investment plans and a more constrained approach to some forecasts and orders in the near term. In addition, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

[0001596532-23-000197:mdna:15]
[same as prior period, unchanged from 0001596532-23-000104:mdna:15]

[0001596532-23-000197:mdna:16]
Three and Six Months Ended June 30, 2023 Compared to Three and Six Months Ended June 30, 2022

[0001596532-23-000197:mdna:17]
[same as prior period, unchanged from 0001596532-23-000104:mdna:17]

[0001596532-23-000197:mdna:18]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | Change in |  | 2023 |  | 2022 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,261,537 |  |  | $ | 885,806 |  |  | $ | 375,731 |  |  | 42.4 | % |  | $ | 2,433,631 |  |  | $ | 1,610,524 |  |  | $ | 823,107 |  |  | 51.1 | % |
| Service |  | 197,387 |  |  | 166,085 |  |  | 31,302 |  |  | 18.8 |  |  | 376,644 |  |  | 318,433 |  |  | 58,211 |  |  | 18.3 |  |
| Total revenue |  | 1,458,924 |  |  | 1,051,891 |  |  | 407,033 |  |  | 38.7 |  |  | 2,810,275 |  |  | 1,928,957 |  |  | 881,318 |  |  | 45.7 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 533,613 |  |  | 375,634 |  |  | 157,979 |  |  | 42.1 |  |  | 1,042,475 |  |  | 669,443 |  |  | 373,032 |  |  | 55.7 |  |
| Service |  | 41,182 |  |  | 32,992 |  |  | 8,190 |  |  | 24.8 |  |  | 79,164 |  |  | 62,404 |  |  | 16,760 |  |  | 26.9 |  |
| Total cost of revenue |  | 574,795 |  |  | 408,626 |  |  | 166,169 |  |  | 40.7 |  |  | 1,121,639 |  |  | 731,847 |  |  | 389,792 |  |  | 53.3 |  |
| Gross profit |  | $ | 884,129 |  |  | $ | 643,265 |  |  | $ | 240,864 |  |  | 37.4 | % |  | $ | 1,688,636 |  |  | $ | 1,197,110 |  |  | $ | 491,526 |  |  | 41.1 | % |
| Gross margin |  | 60.6 | % |  | 61.2 | % |  |  |  |  |  | 60.1 | % |  | 62.1 | % |  |  |  |  |

[0001596532-23-000197:mdna:19]
[same as prior period, unchanged from 0001596532-23-000104:mdna:19]

[0001596532-23-000197:mdna:20]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2023 |  | % of Total |  | 2022 |  | % of Total |  | 2023 |  | % of Total |  | 2022 |  | % of Total |
| Americas |  | $ | 1,154,509 |  |  | 79.1 | % |  | $ | 845,055 |  |  | 80.4 | % |  | $ | 2,269,520 |  |  | 80.8 | % |  | $ | 1,509,432 |  |  | 78.3 | % |
| Europe, Middle East and Africa |  | 167,623 |  |  | 11.5 |  |  | 104,538 |  |  | 9.9 |  |  | 295,939 |  |  | 10.5 |  |  | 239,343 |  |  | 12.4 |  |
| Asia-Pacific |  | 136,792 |  |  | 9.4 |  |  | 102,298 |  |  | 9.7 |  |  | 244,816 |  |  | 8.7 |  |  | 180,182 |  |  | 9.3 |  |
| Total revenue |  | $ | 1,458,924 |  |  | 100.0 | % |  | $ | 1,051,891 |  |  | 100.0 | % |  | $ | 2,810,275 |  |  | 100.0 | % |  | $ | 1,928,957 |  |  | 100.0 | % |

[0001596532-23-000197:mdna:21]
[same as prior period, unchanged from 0001596532-23-000104:mdna:21]

[0001596532-23-000197:mdna:22]
[same as prior period, unchanged from 0001596532-23-000104:mdna:22]

[0001596532-23-000197:mdna:23]
Product revenue increased $375.7 million, or 42.4%, and $823.1 million, or 51.1% for the three and six months ended June 30, 2023, respectively, compared to the same periods in 2022. The increase reflects strong demand for our switching and routing platforms from across our customer base. In addition, service revenue increased $31.3 million, or 18.8%, and $58.2 million, or 18.3% for the three and six months ended June 30, 2023, respectively, compared to the same period in 2022, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenue represented 20.9% and 19.2% of total revenue for the three and six months ended June 30, 2023, respectively, changing from 19.6%  and 21.7% for the same periods in the prior year, which was primarily driven by changes in the geographic mix of sales to our large global customers.

[0001596532-23-000197:mdna:24]
[same as prior period, unchanged from 0001596532-23-000104:mdna:24]

[0001596532-23-000197:mdna:25]
[same as prior period, unchanged from 0001596532-23-000104:mdna:25]

[0001596532-23-000197:mdna:26]
Cost of revenue increased by $166.2 million, or 40.7%, and $389.8 million, or 53.3% for the three and six months ended June 30, 2023, respectively, compared to the same periods in 2022. These increases were primarily driven by a corresponding increase in product and service revenues, combined with an increase in provisions for excess/obsolete inventory.

[0001596532-23-000197:mdna:27]
[same as prior period, unchanged from 0001596532-23-000104:mdna:28]

[0001596532-23-000197:mdna:28]
Gross margin decreased from 61.2% to 60.6% for the three months ended June 30, 2023, and decreased from 62.1% to 60.1% for the six months ended June 30, 2023, compared to the same periods in 2022. These decreases were primarily driven by a higher mix of revenue from our larger customers combined with an increase in provisions for excess/obsolete inventory, partly offset by the leverage of fixed overhead costs on a higher revenue base.

[0001596532-23-000197:mdna:29]
[same as prior period, unchanged from 0001596532-23-000104:mdna:30]

[0001596532-23-000197:mdna:30]
[same as prior period, unchanged from 0001596532-23-000104:mdna:31]

[0001596532-23-000197:mdna:31]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | Change in |  | 2023 |  | 2022 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 229,676 |  |  | $ | 178,158 |  |  | $ | 51,518 |  |  | 28.9 | % |  | $ | 431,084 |  |  | $ | 350,164 |  |  | $ | 80,920 |  |  | 23.1 | % |
| Sales and marketing |  | 97,971 |  |  | 79,372 |  |  | 18,599 |  |  | 23.4 |  |  | 191,463 |  |  | 160,111 |  |  | 31,352 |  |  | 19.6 |  |
| General and administrative |  | 26,420 |  |  | 22,882 |  |  | 3,538 |  |  | 15.5 |  |  | 51,449 |  |  | 45,995 |  |  | 5,454 |  |  | 11.9 |  |
| Total operating expenses |  | $ | 354,067 |  |  | $ | 280,412 |  |  | $ | 73,655 |  |  | 26.3 | % |  | $ | 673,996 |  |  | $ | 556,270 |  |  | $ | 117,726 |  |  | 21.2 | % |

[0001596532-23-000197:mdna:32]
[same as prior period, unchanged from 0001596532-23-000104:mdna:33]

[0001596532-23-000197:mdna:33]
[same as prior period, unchanged from 0001596532-23-000104:mdna:34]

[0001596532-23-000197:mdna:34]
Research and development expenses increased $51.5 million, or 28.9%, and $80.9 million, or 23.1% in the three and six months ended June 30, 2023, respectively, compared to the same periods in 2022. The increases were primarily driven by an increase in personnel costs of $27.6 million and $49.7 million for the three and six months ended June 30, 2023, respectively, compared to the same periods in 2022 primarily due to headcount growth. In addition, new product introduction costs increased by $24.4 million and $31.5 million for the three and six months ended June 30, 2023, respectively, compared to the same periods in 2022.

[0001596532-23-000197:mdna:35]
[same as prior period, unchanged from 0001596532-23-000104:mdna:36]

[0001596532-23-000197:mdna:36]
Sales and marketing expenses consist primarily of personnel costs, marketing, trade shows, and other promotional activities, and an allocated portion of facility and IT costs. We expect our sales and marketing expenses to increase in absolute

[0001596532-23-000197:mdna:37]
dollars as we continue to expand our sales and marketing efforts worldwide.

[0001596532-23-000197:mdna:38]
Sales and marketing expenses increased $18.6 million, or 23.4%, and $31.4 million, or 19.6% for the three and six months ended June 30, 2023, respectively, compared to the same periods in 2022, which was primarily caused by increased personnel costs largely driven by headcount growth, in addition to increased sales and marketing events and field demonstration costs.

[0001596532-23-000197:mdna:39]
[same as prior period, unchanged from 0001596532-23-000104:mdna:39]

[0001596532-23-000197:mdna:40]
[same as prior period, unchanged from 0001596532-23-000104:mdna:40]

[0001596532-23-000197:mdna:41]
General and administrative expenses increased $3.5 million, or 15.5%, and $5.5 million, or 11.9% in the three and six months ended June 30, 2023, respectively, compared to the same periods in 2022.

[0001596532-23-000197:mdna:42]
[same as prior period, unchanged from 0001596532-23-000104:mdna:43]

[0001596532-23-000197:mdna:43]
Other income (expense), net consists primarily of interest income from our cash, cash equivalents and marketable securities, gains and losses on our equity investments in privately-held companies and marketable equity securities, and foreign currency transaction gains and losses. We expect other income (expense), net may fluctuate in the future as a result of the re-measurement of our equity investments upon the occurrence of observable price changes and/or impairments, changes in interest rates or returns on our cash and cash equivalents and marketable securities, and foreign currency exchange rate fluctuations.

[0001596532-23-000197:mdna:44]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | Change in |  | 2023 |  | 2022 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 32,206 |  |  | $ | 4,427 |  |  | $ | 27,779 |  |  | 627.5 | % |  | $ | 54,715 |  |  | $ | 6,855 |  |  | $ | 47,860 |  |  | 698.2 | % |
| Unrealized gain (loss) on equity investments |  | 24,743 |  |  | (5,084) |  |  | 29,827 |  |  | 586.7 |  |  | 19,172 |  |  | 23,413 |  |  | (4,241) |  |  | (18.1) |  |
| Other income (expense), net |  | (610) |  |  | 124 |  |  | (734) |  |  | (591.9) |  |  | (5,402) |  |  | 679 |  |  | (6,081) |  |  | (895.6) |  |
| Total other income (expense), net |  | $ | 56,339 |  |  | $ | (533) |  |  | $ | 56,872 |  |  | 10,670.2 | % |  | $ | 68,485 |  |  | $ | 30,947 |  |  | $ | 37,538 |  |  | 121.3 | % |

[0001596532-23-000197:mdna:45]
The favorable movements in other income (expense), net, were driven by an unrealized gain on equity investments of $24.7 million in the three months ended June 30, 2023 compared to an unrealized loss of $5.1 million in the same period in 2022. In addition, interest income increased $27.8 million and $47.9 million in the three and six months ended June 30, 2023, respectively, compared to the same periods in 2022 due to higher interest rates.

[0001596532-23-000197:mdna:46]
[same as prior period, unchanged from 0001596532-23-000104:mdna:47]

[0001596532-23-000197:mdna:47]
[same as prior period, unchanged from 0001596532-23-000104:mdna:48]

[0001596532-23-000197:mdna:48]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | Change in |  | 2023 |  | 2022 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Income before income taxes |  | $ | 586,401 |  |  | $ | 362,320 |  |  | $ | 224,081 |  |  | 61.8 | % |  | $ | 1,083,125 |  |  | $ | 671,787 |  |  | $ | 411,338 |  |  | 61.2 | % |
| Provision for income taxes |  | 94,516 |  |  | 63,221 |  |  | 31,295 |  |  | 49.5 | % |  | 154,767 |  |  | 100,429 |  |  | 54,338 |  |  | 54.1 | % |
| Effective tax rate |  | 16.1 | % |  | 17.4 | % |  |  |  |  |  | 14.3 | % |  | 14.9 | % |  |  |  |  |

[0001596532-23-000197:mdna:49]
The decrease in the effective tax rates in the three and six months ended June 30, 2023, as compared to the same periods in 2022, was primarily due to an increase in tax benefits attributable to stock-based compensation.

[0001596532-23-000197:mdna:50]
[same as prior period, unchanged from 0001596532-23-000104:mdna:51]

[0001596532-23-000197:mdna:51]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of June 30, 2023, our total balance of cash, cash equivalents and marketable securities was approximately $3.7 billion, of which approximately $455.2 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-23-000197:mdna:52]
Our cash, cash equivalents and marketable securities are held for general business purposes, including the funding of working capital. The investment portfolio of our marketable securities is primarily invested in highly-rated securities, with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations, will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and stock repurchases. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-23-000197:mdna:53]
[same as prior period, unchanged from 0001596532-23-000104:mdna:55]

[0001596532-23-000197:mdna:54]
|  |  | Six Months Ended June 30, |
|  |  | 2023 |  | 2022 |
| Cash provided by operating activities |  | $ | 808,573 |  |  | $ | 318,235 |  |
| Cash provided by (used in) investing activities |  | (124,653) |  |  | 172,959 |  |
| Cash used in financing activities |  | (97,635) |  |  | (615,699) |  |
| Effect of exchange rate changes |  | 429 |  |  | (3,041) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 586,714 |  |  | $ | (127,546) |  |

[0001596532-23-000197:mdna:55]
[same as prior period, unchanged from 0001596532-23-000104:mdna:57]

[0001596532-23-000197:mdna:56]
During the six months ended June 30, 2023, cash provided by operating activities was $808.6 million, primarily from net income of $928.4 million and non-cash adjustments to net income of $16.9 million driven by stock-based compensation and depreciation and amortization, largely offset by an increase in deferred taxes associated with the capitalization of research and development costs under Section 174 of the Internal Revenue Code ("IRC"). These increases were partly offset by a net increase of $136.7 million in working capital requirements, which primarily consisted of a $574.6 million increase in inventory and a $137.0 million increase in inventory deposits to our contract manufacturers in response to a significant increase in business volume.  These operating cash outflows were largely offset by cash inflows from a $185.3 million increase in accounts payable and accrued liabilities due to an increase in business volume and timing of payments, and a $198.1 million increase in income tax payables related to an increase in taxable income, combined with an extension by the Internal Revenue Service ("IRS") of the due dates for estimated tax payments until October 2023. In addition, we had cash inflows resulting from a decrease in accounts receivable of $143.4 million driven by strong collections, and an increase in deferred revenue of $43.7 million primarily resulting from an increase in customer PCS contracts.

[0001596532-23-000197:mdna:57]
During the six months ended June 30, 2022, cash provided by operating activities was $318.2 million, primarily from net income of $571.4 million and non-cash adjustments to net income of $19.8 million driven by stock-based compensation and depreciation and amortization, and partly offset by a net increase of $272.9 million in working capital requirements. The increase in working capital requirements primarily consisted of a $202.1 million increase in inventory and a $158.1 million increase in prepaid expenses and other current assets, which reflected increased inventory purchases and inventory deposits to contract manufacturers to mitigate supply chain constraints and meet customer demand. The increase in other current assets also reflected increased deferred product cost of sales due to a corresponding increase in deferred product revenue, as well as an increase in contract assets and other miscellaneous receivables. In addition, accounts receivable increased by $64.3 million due to increased product and service billings. These operating cash outflows were partially offset by a $91.2 million increase in product and service deferred revenue driven by customer contracts with acceptance terms and PCS contracts, a $71.2 million increase in accounts payable, and a $10.8 million increase in income tax payables.

[0001596532-23-000197:mdna:58]
[same as prior period, unchanged from 0001596532-23-000104:mdna:60]

[0001596532-23-000197:mdna:59]
During the six months ended June 30, 2023, cash used in investing activities was $124.7 million, consisting of  purchases of available-for-sale securities of $1,392.0 million, and purchases of property and equipment of $17.2 million. These amounts were partially offset by proceeds from maturities and sales of marketable securities of $1,287.0 million.

[0001596532-23-000197:mdna:60]
During the six months ended June 30, 2022, cash provided by investing activities was $173.0 million, consisting of proceeds from maturities of marketable securities of $829.7 million and proceeds from sale of marketable securities of $165.7

[0001596532-23-000197:mdna:61]
million, which was used to fund the business acquisitions and to repurchase our common stock. These amounts were partially offset by purchases of available-for-sale securities of $642.0 million, and purchases of property and equipment of $23.7 million.

[0001596532-23-000197:mdna:62]
[same as prior period, unchanged from 0001596532-23-000104:mdna:63]

[0001596532-23-000197:mdna:63]
During the six months ended June 30, 2023, cash used in financing activities was $97.6 million, consisting of payments for repurchases of our common stock from the open market of $112.3 million, and employee taxes withheld and paid of $15.8 million upon vesting of restricted stock units, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $30.4 million.

[0001596532-23-000197:mdna:64]
During the six months ended June 30, 2022, cash used in financing activities was $615.7 million, consisting of payments for repurchases of our common stock from the open market of $619.9 million, and employee taxes withheld and paid of $18.8 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $23.0 million.

[0001596532-23-000197:mdna:65]
[same as prior period, unchanged from 0001596532-23-000104:mdna:66]

[0001596532-23-000197:mdna:66]
Our board of directors has authorized a $1.0 billion stock repurchase program (the “Repurchase Program”). This authorization allows us to repurchase shares of our common stock that will be funded from working capital and expires in the fourth quarter of 2024. The Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the company at any time without prior notice.  During the three months ended June 30, 2023, we repurchased a total of $30.0 million of our common stock. As of June 30, 2023, the remaining authorized amount for repurchases under the Repurchase Program was $144.5 million. Refer to Note 6. Stockholders' Equity and Stock-Based Compensation of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of the Quarterly Report on Form 10-Q for further discussion.

[0001596532-23-000197:mdna:67]
[same as prior period, unchanged from 0001596532-23-000104:mdna:68]

[0001596532-23-000197:mdna:68]
[same as prior period, unchanged from 0001596532-23-000104:mdna:69]

[0001596532-23-000197:mdna:69]
[same as prior period, unchanged from 0001596532-23-000104:mdna:70]

[0001596532-23-000197:mdna:70]
[same as prior period, unchanged from 0001596532-23-000104:mdna:71]

[0001596532-23-000197:mdna:71]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of June 30, 2023, we had lease payment obligations, net of immaterial sublease income, of $78.0 million, with $21.6 million payable within one year.

[0001596532-23-000197:mdna:72]
[same as prior period, unchanged from 0001596532-23-000104:mdna:73]

[0001596532-23-000197:mdna:73]
Purchase obligations represent an estimate of all non-cancellable open purchase orders and contractual obligations, made either directly by Arista or by our contract manufacturers on our behalf, in the ordinary course of business for which we have not received the goods or services. As of June 30, 2023, we had $2.2 billion of such purchase obligations, of which $1.9 billion are expected to be received within one year, and $0.3 billion are expected to be received after one year.  These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-23-000197:mdna:74]
[same as prior period, unchanged from 0001596532-23-000104:mdna:75]

[0001596532-23-000197:mdna:75]
As of June 30, 2023, we have recorded long-term tax liabilities of $98.7 million related to uncertain tax positions; however, we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-23-000197:mdna:76]
In connection with the Tax Cuts and Jobs Act of 2017 (“TCJA”), effective from January 1st 2022, the TCJA eliminates the option to deduct research and development expenditures currently and requires taxpayers to capitalize and amortize them over five or fifteen years pursuant to IRC Section 174. We estimate the incremental cash tax impact resulting from these regulations to be approximately $210.0 million for 2023. No material change to our effective tax rate has resulted from this new legislation.

[0001596532-23-000197:mdna:77]
[same as prior period, unchanged from 0001596532-23-000104:mdna:78]

[0001596532-23-000197:mdna:78]
As of June 30, 2023, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-23-000197:mdna:79]
[same as prior period, unchanged from 0001596532-23-000104:mdna:80]

[0001596532-23-000197:mdna:80]
[same as prior period, unchanged from 0001596532-23-000104:mdna:81]

[0001596532-23-000197:mdna:81]
[same as prior period, unchanged from 0001596532-23-000104:mdna:82]

[0001596532-23-000197:mdna:82]
Refer to the subheading titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
