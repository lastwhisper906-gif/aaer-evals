# ANET notes — 0001596532-23-000197


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-23-000197:notes:1]
[same as prior period, unchanged from 0001596532-23-000104:notes:1]

[0001596532-23-000197:notes:2]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of next generation data center and campus workspace environments. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-23-000197:notes:3]
[same as prior period, unchanged from 0001596532-23-000104:notes:3]

[0001596532-23-000197:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2023, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2022 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

[0001596532-23-000197:notes:5]
[same as prior period, unchanged from 0001596532-23-000104:notes:5]

[0001596532-23-000197:notes:6]
[same as prior period, unchanged from 0001596532-23-000104:notes:6]

[0001596532-23-000197:notes:7]
[same as prior period, unchanged from 0001596532-23-000104:notes:7]

[0001596532-23-000197:notes:8]
[same as prior period, unchanged from 0001596532-23-000104:notes:8]

[0001596532-23-000197:notes:9]
[same as prior period, unchanged from 0001596532-23-000104:notes:9]

[0001596532-23-000197:notes:10]
We have continued to work closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. We have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, and have begun to see some reduction in customer lead times on certain products. Over time, the recovery of capacity should allow us to ship products against previously committed deployment plans and accelerate some deployments where needed, while trying to limit building customer inventory.  On this basis, we now expect some shipments against these deployment schedules to extend into 2024. As customer lead times reduce more broadly, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to somewhat shorter demand-planning horizons which has resulted in lower demand levels.  Given the shipment and order patterns described above, near term revenue trends may not be reflective of current demand levels, but will benefit from deployment plans that had been previously committed. While inventory and working capital levels may continue to increase and remain elevated in the near term, we expect that purchase commitments will continue to decline as supplier lead times shorten.  Although these elevated inventory positions are largely related to early

[0001596532-23-000197:notes:11]
life cycle products, we cannot be certain that we will be able to sell all of this inventory, which may in the future result in excess and obsolete inventory charges.

[0001596532-23-000197:notes:12]
In addition, inflation pressure in our supply chain, scarcity of some materials needed to build our products and disruptions to our manufacturing process have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. Our operating cash-flows have also been and may continue to be negatively impacted by significant component inventories on hand or at our contract manufacturers. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the Russia-Ukraine conflict, continued escalation of the conflict may negatively impact the global economy and our future operating results and financial condition.

[0001596532-23-000197:notes:13]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable; however, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that our customers, following a year of elevated purchase, must now consider changing technology roadmaps and priorities, including the need for the rapid deployment of artificial intelligence ("AI") and related technologies, resulting in some uncertainty as to future investment plans and a more constrained approach to some forecasts and orders in the near term. In addition, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

[0001596532-23-000197:notes:14]
[same as prior period, unchanged from 0001596532-23-000104:notes:14]

[0001596532-23-000197:notes:15]
We believe that all recently issued accounting pronouncements from the FASB will not have a material impact on our Consolidated Financial Statements or do not apply to our operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-23-000197:notes:16]
[same as prior period, unchanged from 0001596532-23-000104:notes:16]

[0001596532-23-000197:notes:17]
[same as prior period, unchanged from 0001596532-23-000104:notes:17]

[0001596532-23-000197:notes:18]
|  |  | June 30, 2023 |  | December 31, 2022 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 574,779 |  |  | $ | — |  |  | $ | — |  |  | $ | 574,779 |  |  | $ | 322,294 |  |  | $ | — |  |  | $ | — |  |  | $ | 322,294 |  |
| Commercial paper |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5,422 |  |  | — |  |  | 5,422 |  |
| U.S. government notes |  | 99,898 |  |  | — |  |  | — |  |  | 99,898 |  |  | 51,986 |  |  | — |  |  | — |  |  | 51,986 |  |
| Agency securities |  | — |  |  | 14,986 |  |  | — |  |  | 14,986 |  |  | — |  |  | 17,559 |  |  | — |  |  | 17,559 |  |
|  |  | 674,677 |  |  | 14,986 |  |  | — |  |  | 689,663 |  |  | 374,280 |  |  | 22,981 |  |  | — |  |  | 397,261 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 88,960 |  |  | — |  |  | 88,960 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposits(1) |  | — |  |  | 6,998 |  |  | — |  |  | 6,998 |  |  | — |  |  | 10,492 |  |  | — |  |  | 10,492 |  |
| U.S. government notes |  | 783,513 |  |  | — |  |  | — |  |  | 783,513 |  |  | 993,955 |  |  | — |  |  | — |  |  | 993,955 |  |
| Corporate bonds |  | — |  |  | 1,051,495 |  |  | — |  |  | 1,051,495 |  |  | — |  |  | 1,113,134 |  |  | — |  |  | 1,113,134 |  |
| Agency securities |  | — |  |  | 523,491 |  |  | — |  |  | 523,491 |  |  | — |  |  | 215,380 |  |  | — |  |  | 215,380 |  |
| Marketable equity securities(2) |  | 24,833 |  |  | — |  |  | — |  |  | 24,833 |  |  | 19,061 |  |  | — |  |  | — |  |  | 19,061 |  |
|  |  | 808,346 |  |  | 1,670,944 |  |  | — |  |  | 2,479,290 |  |  | 1,013,016 |  |  | 1,339,006 |  |  | — |  |  | 2,352,022 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 856 |  |  | — |  |  | — |  |  | 856 |  |  | 4,271 |  |  | — |  |  | — |  |  | 4,271 |  |
| Total Financial Assets |  | $ | 1,483,879 |  |  | $ | 1,685,930 |  |  | $ | — |  |  | $ | 3,169,809 |  |  | $ | 1,391,567 |  |  | $ | 1,361,987 |  |  | $ | — |  |  | $ | 2,753,554 |  |

[0001596532-23-000197:notes:19]
[same as prior period, unchanged from 0001596532-23-000104:notes:19]

[0001596532-23-000197:notes:20]
(1) As of June 30, 2023 and December 31, 2022, all of our certificates of deposits were domestic deposits.

[0001596532-23-000197:notes:21]
(2) The $24.8 million represents the fair value of marketable equity securities as of June 30, 2023. This publicly-traded equity investment generated an unrealized gain of $5.8 million for the six months ended June 30, 2023, and an unrealized gain of $11.3 million for the three months ended June 30, 2023.  Total initial cost for this investment was $3.0 million with no changes since our initial investment. The unrealized gains and losses are included in Other income (expense), net on the unaudited Condensed Consolidated Statements of Operations. Refer to Note 3. Financial Statements Details.

[0001596532-23-000197:notes:22]
During the three and six months ended June 30, 2023, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-23-000197:notes:23]
[same as prior period, unchanged from 0001596532-23-000104:notes:23]

[0001596532-23-000197:notes:24]
[same as prior period, unchanged from 0001596532-23-000104:notes:24]

[0001596532-23-000197:notes:25]
|  |  | June 30, 2023 |  | December 31, 2022 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 88,960 |  |  | $ | — |  |  | $ | — |  |  | $ | 88,960 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| U.S. government |  | 790,970 |  |  | 34 |  |  | (7,491) |  |  | 783,513 |  |  | 1,007,175 |  |  | 3 |  |  | (13,223) |  |  | 993,955 |  |
| Corporate bonds |  | 1,059,915 |  |  | 111 |  |  | (8,531) |  |  | 1,051,495 |  |  | 1,125,920 |  |  | 271 |  |  | (13,057) |  |  | 1,113,134 |  |
| Agency securities |  | 527,766 |  |  | 8 |  |  | (4,283) |  |  | 523,491 |  |  | 217,893 |  |  | 83 |  |  | (2,596) |  |  | 215,380 |  |
| Total |  | $ | 2,467,611 |  |  | $ | 153 |  |  | $ | (20,305) |  |  | $ | 2,447,459 |  |  | $ | 2,350,988 |  |  | $ | 357 |  |  | $ | (28,876) |  |  | $ | 2,322,469 |  |

[0001596532-23-000197:notes:26]
For debt securities in unrealized loss positions, it is not likely that we will be required to sell such securities before recovery of their amortized cost basis nor do we have the intent to sell such securities before maturity. We invest in debt securities that have maximum maturities of two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. Given the short-term and conservative nature of our portfolio, our debt securities are generally not subject to credit risk; therefore, we did not recognize any credit losses or non-credit-related impairments related to such securities for the three and six months ended June 30, 2023. All unrealized losses were recognized in other comprehensive income (loss). Realized losses were immaterial for the three and six months ended June 30, 2023.

[0001596532-23-000197:notes:27]
[same as prior period, unchanged from 0001596532-23-000104:notes:27]

[0001596532-23-000197:notes:28]
|  |  | June 30, 2023 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 457,325 |  |  | $ | (3,346) |  |  | $ | 291,908 |  |  | $ | (4,145) |  |  | $ | 749,233 |  |  | $ | (7,491) |  |
| Corporate bonds |  | 743,043 |  |  | (4,714) |  |  | 256,414 |  |  | (3,817) |  |  | 999,457 |  |  | (8,531) |  |
| Agency securities |  | 432,179 |  |  | (3,063) |  |  | 61,730 |  |  | (1,220) |  |  | 493,909 |  |  | (4,283) |  |
| Total |  | $ | 1,632,547 |  |  | $ | (11,123) |  |  | $ | 610,052 |  |  | $ | (9,182) |  |  | $ | 2,242,599 |  |  | $ | (20,305) |  |

[0001596532-23-000197:notes:29]
As of June 30, 2023, we had no marketable debt securities with contractual maturities that exceed 24 months. The fair values of marketable debt securities, by remaining contractual maturities, are as follows (in thousands):

[0001596532-23-000197:notes:30]
|  |  | June 30, 2023 |
|  |  | Fair Value |
| Due in 1 year or less |  | $ | 1,494,804 |  |
| Due in 1 to 2 years |  | 952,655 |  |
| Total debt securities |  | $ | 2,447,459 |  |

[0001596532-23-000197:notes:31]
The weighted-average remaining duration of our marketable debt securities is approximately 0.9 years as of June 30, 2023. As we view these marketable debt securities as available to support current operations, we classify marketable debt securities with maturities beyond 12 months as current assets under the caption "Marketable securities" on the condensed consolidated balance sheets.

[0001596532-23-000197:notes:32]
[same as prior period, unchanged from 0001596532-23-000104:notes:32]

[0001596532-23-000197:notes:33]
[same as prior period, unchanged from 0001596532-23-000104:notes:33]

[0001596532-23-000197:notes:34]
[same as prior period, unchanged from 0001596532-23-000104:notes:34]

[0001596532-23-000197:notes:35]
We did not record any realized gains for our non-marketable equity securities during the three and six months ended June 30, 2023 and June 30, 2022, and we recorded an immaterial amount of realized and unrealized losses for the three and six months ended June 30, 2023 and June 30, 2022. Unrealized gains for our non-marketable equity securities are summarized below (in thousands):

[0001596532-23-000197:notes:36]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Unrealized gains on non-marketable equity securities (1) |  | $ | 13,401 |  |  | $ | — |  |  | $ | 13,401 |  |  | $ | 15,000 |  |

[0001596532-23-000197:notes:37]
(1) These unrealized gains were recorded on investments that were re-measured to fair value as of the date observable transactions occurred.

[0001596532-23-000197:notes:38]
We evaluate our non-marketable equity securities for impairment at each reporting period via a qualitative assessment with various potential impairment indicators, including, but not limited to, an assessment of a significant adverse change in the economic environment, significant adverse changes in the general market condition of the geographies and industries in which our investees operate, and other publicly-available information that affected the value of the non-marketable equity securities.

[0001596532-23-000197:notes:39]
The following table summarizes the activity related to our non-marketable equity securities as of June 30, 2023 and December 31, 2022 (in thousands):

[0001596532-23-000197:notes:40]
|  |  | June 30, 2023 |  | December 31, 2022 |
| Cost of investments(1) |  | $ | 31,656 |  |  | $ | 23,625 |  |
| Cumulative impairment and downward adjustment |  | — |  |  | (888) |  |
| Cumulative upward adjustment |  | 30,132 |  |  | 16,731 |  |
| Carrying amount of investments |  | $ | 61,788 |  |  | $ | 39,468 |  |

[0001596532-23-000197:notes:41]
(1) During the three months ended June 30, 2023, we had an $8.0 million convertible note previously included in other assets, plus accrued interest of  $0.6 million, that was converted to an equity investment and included in cost of investments.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-23-000197:notes:42]
[same as prior period, unchanged from 0001596532-23-000104:notes:38]

[0001596532-23-000197:notes:43]
(1) As of June 30, 2023 and December 31, 2022, all of our certificates of deposits were domestic deposits.
(2) The $24.8 million represents the fair value of marketable equity securities as of June 30, 2023. This publicly-traded equity investment generated an unrealized gain of $5.8 million for the six months ended June 30, 2023, and an unrealized gain of $11.3 million for the three months ended June 30, 2023.  Total initial cost for this investment was $3.0 million with no changes since our initial investment. The unrealized gains and losses are included in Other income (expense), net on the unaudited Condensed Consolidated Statements of Operations. Refer to Note 3. Financial Statements Details.The following table summarizes the amortized cost, unrealized gains and losses, and fair value of our debt securities measured at fair value on a recurring basis (in thousands):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-23-000197:notes:44]
[same as prior period, unchanged from 0001596532-23-000104:notes:40]

[0001596532-23-000197:notes:45]
[same as prior period, unchanged from 0001596532-23-000104:notes:41]

[0001596532-23-000197:notes:46]
|  |  | June 30, 2023 |  | December 31, 2022 |
| Cash and cash equivalents |  | $ | 1,261,836 |  |  | $ | 671,707 |  |
| Restricted cash included in other assets |  | 856 |  |  | 4,271 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 1,262,692 |  |  | $ | 675,978 |  |

[0001596532-23-000197:notes:47]
[same as prior period, unchanged from 0001596532-23-000104:notes:43]

[0001596532-23-000197:notes:48]
[same as prior period, unchanged from 0001596532-23-000104:notes:44]

[0001596532-23-000197:notes:49]
|  |  | June 30, 2023 |  | December 31, 2022 |
| Accounts receivable |  | $ | 793,306 |  |  | $ | 928,490 |  |
| Allowance for doubtful accounts |  | (4,917) |  |  | (19) |  |
| Product sales rebate and returns reserve |  | (8,663) |  |  | (5,375) |  |
| Accounts receivable, net |  | $ | 779,726 |  |  | $ | 923,096 |  |

[0001596532-23-000197:notes:50]
[same as prior period, unchanged from 0001596532-23-000104:notes:46]

[0001596532-23-000197:notes:51]
[same as prior period, unchanged from 0001596532-23-000104:notes:47]

[0001596532-23-000197:notes:52]
|  |  | June 30, 2023 |  | December 31, 2022 |
| Raw materials |  | $ | 1,050,253 |  |  | $ | 759,519 |  |
| Finished goods |  | 814,081 |  |  | 530,187 |  |
| Total inventories |  | $ | 1,864,334 |  |  | $ | 1,289,706 |  |

[0001596532-23-000197:notes:53]
[same as prior period, unchanged from 0001596532-23-000104:notes:49]

[0001596532-23-000197:notes:54]
[same as prior period, unchanged from 0001596532-23-000104:notes:50]

[0001596532-23-000197:notes:55]
|  |  | June 30, 2023 |  | December 31, 2022 |
| Inventory deposits |  | $ | 298,827 |  |  | $ | 162,047 |  |
| Other current assets |  | 167,544 |  |  | 152,170 |  |
| Total prepaid expenses and other current assets |  | $ | 466,371 |  |  | $ | 314,217 |  |

[0001596532-23-000197:notes:56]
[same as prior period, unchanged from 0001596532-23-000104:notes:52]

[0001596532-23-000197:notes:57]
[same as prior period, unchanged from 0001596532-23-000104:notes:53]

[0001596532-23-000197:notes:58]
|  |  | June 30, 2023 |  | December 31, 2022 |
| Land |  | $ | 42,567 |  |  | $ | 41,500 |  |
| Equipment and machinery |  | 137,496 |  |  | 122,407 |  |
| Computer hardware and software |  | 56,887 |  |  | 52,148 |  |
| Leasehold improvements |  | 32,083 |  |  | 30,102 |  |
| Furniture and fixtures |  | 3,589 |  |  | 3,575 |  |
| Construction-in-process |  | 1,721 |  |  | 2,124 |  |
| Property and equipment, gross |  | 274,343 |  |  | 251,856 |  |
| Less: accumulated depreciation |  | (172,638) |  |  | (156,847) |  |
| Property and equipment, net |  | $ | 101,705 |  |  | $ | 95,009 |  |

[0001596532-23-000197:notes:59]
Depreciation expense was $7.8 million and $6.2 million for the three months ended June 30, 2023 and 2022, respectively, and $14.9 million and $11.8 million for the six months ended June 30, 2023 and 2022, respectively.

[0001596532-23-000197:notes:60]
[same as prior period, unchanged from 0001596532-23-000104:notes:56]

[0001596532-23-000197:notes:61]
[same as prior period, unchanged from 0001596532-23-000104:notes:57]

[0001596532-23-000197:notes:62]
|  |  | June 30, 2023 |  | December 31, 2022 |
| Accrued compensation-related costs |  | $ | 88,984 |  |  | $ | 117,053 |  |
| Accrued supplier liability |  | 135,623 |  |  | 71,481 |  |
| Accrued manufacturing costs |  | 49,095 |  |  | 45,379 |  |
| Accrued product development costs |  | 47,254 |  |  | 27,380 |  |
| Other |  | 42,080 |  |  | 31,194 |  |
| Total accrued liabilities |  | $ | 363,036 |  |  | $ | 292,487 |  |

[0001596532-23-000197:notes:63]
[same as prior period, unchanged from 0001596532-23-000104:notes:59]

[0001596532-23-000197:notes:64]
[same as prior period, unchanged from 0001596532-23-000104:notes:60]

[0001596532-23-000197:notes:65]
[same as prior period, unchanged from 0001596532-23-000104:notes:61]

[0001596532-23-000197:notes:66]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Contract liabilities, beginning balance |  | $ | 105,047 |  |  | $ | 98,422 |  |  | $ | 103,448 |  |  | $ | 93,382 |  |
| Less: Revenue recognized from beginning balance |  | (9,941) |  |  | (8,589) |  |  | (22,105) |  |  | (19,076) |  |
| Less: Beginning balance reclassified to deferred revenue |  | (4,962) |  |  | (4,338) |  |  | (4,145) |  |  | (3,606) |  |
| Add: Contract liabilities recognized |  | 19,953 |  |  | 16,105 |  |  | 32,899 |  |  | 30,900 |  |
| Contract liabilities, ending balance |  | $ | 110,097 |  |  | $ | 101,600 |  |  | $ | 110,097 |  |  | $ | 101,600 |  |

[0001596532-23-000197:notes:67]
As of June 30, 2023 and December 31, 2022, $48.8 million and $45.2 million of our contract liabilities, respectively, were included in "Other current liabilities" with the remaining balances included in "Other long-term liabilities" on the condensed consolidated balance sheets.

[0001596532-23-000197:notes:68]
[same as prior period, unchanged from 0001596532-23-000104:notes:64]

[0001596532-23-000197:notes:69]
[same as prior period, unchanged from 0001596532-23-000104:notes:65]

[0001596532-23-000197:notes:70]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Deferred revenue, beginning balance |  | $ | 1,092,274 |  |  | $ | 1,123,746 |  |  | $ | 1,041,246 |  |  | $ | 929,312 |  |
| Less: Revenue recognized from beginning balance |  | (263,353) |  |  | (309,594) |  |  | (395,056) |  |  | (322,954) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 255,983 |  |  | 219,338 |  |  | 438,714 |  |  | 427,132 |  |
| Deferred revenue, ending balance |  | $ | 1,084,904 |  |  | $ | 1,033,490 |  |  | $ | 1,084,904 |  |  | $ | 1,033,490 |  |

[0001596532-23-000197:notes:71]
[same as prior period, unchanged from 0001596532-23-000104:notes:67]

[0001596532-23-000197:notes:72]
Other performance obligations totaling $812.8 million as of June 30, 2023 include unbilled multi-year PCS and service contract amounts of $95.8 million and $717.0 million of binding contractual agreements with certain customers that are primarily related to future product shipments.

[0001596532-23-000197:notes:73]
[same as prior period, unchanged from 0001596532-23-000104:notes:69]

[0001596532-23-000197:notes:74]
Total revenue from our contract liabilities, deferred revenue and other performance obligations that will be recognized in future periods amounts to $2.0 billion. Included in this amount is the $717.0 million of binding contractual agreements related primarily to future product shipments that will be recognized as revenue over the next two years. In addition, approximately 82% of the remaining $1.3 billion of this future revenue is expected to be recognized over the next two years and approximately 18% is expected to be recognized during the third to the fifth year.

[0001596532-23-000197:notes:75]
[same as prior period, unchanged from 0001596532-23-000104:notes:71]

[0001596532-23-000197:notes:76]
[same as prior period, unchanged from 0001596532-23-000104:notes:72]

[0001596532-23-000197:notes:77]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest income |  | $ | 32,206 |  |  | $ | 4,427 |  |  | $ | 54,715 |  |  | $ | 6,855 |  |
| Unrealized gain (loss) on equity investments |  | 24,743 |  |  | (5,084) |  |  | 19,172 |  |  | 23,413 |  |
| Other income (expense), net |  | (610) |  |  | 124 |  |  | (5,402) |  |  | 679 |  |
| Total |  | $ | 56,339 |  |  | $ | (533) |  |  | $ | 68,485 |  |  | $ | 30,947 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-23-000197:notes:78]
[same as prior period, unchanged from 0001596532-23-000104:notes:74]

[0001596532-23-000197:notes:79]
[same as prior period, unchanged from 0001596532-23-000104:notes:75]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-23-000197:notes:80]
[same as prior period, unchanged from 0001596532-23-000104:notes:76]

[0001596532-23-000197:notes:81]
We had no material business acquisitions during the six months ended June 30, 2023. During the year ended December 31, 2022, we completed two acquisitions of private companies for total consideration of $158.9 million including $4.0 million in common stock and the remainder in cash. The purchase prices included $62.3 million of intangible assets, $77.5 million of goodwill and $19.1 million of net tangible assets acquired. We also incurred certain acquisition-related expenses of $4.7 million, which primarily consisted of retention bonuses to continuing employees as well as professional and consulting fees.

[0001596532-23-000197:notes:82]
The purchase price allocation for the two acquisitions have been finalized. No changes were made to the purchase price allocation for the three and six months ended June 30, 2023.

[0001596532-23-000197:notes:83]
[same as prior period, unchanged from 0001596532-23-000104:notes:79]

[0001596532-23-000197:notes:84]
No material changes were made to the carrying values of goodwill for the three and six months ended June 30, 2023.

[0001596532-23-000197:notes:85]
[same as prior period, unchanged from 0001596532-23-000104:notes:81]

[0001596532-23-000197:notes:86]
Acquisition-related intangible assets, excluding those that are fully amortized, were as follows (in thousands, except years):

[0001596532-23-000197:notes:87]
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life (in years) |
|  | December 31, 2022 |  | Additions |  | June 30, 2023 |  | December 31, 2022 |  | Amortization |  | June 30, 2023 |  | December 31, 2022 |  | June 30, 2023 |  |
| Developed technology | $ | 154,930 |  |  | $ | — |  |  | $ | 154,930 |  |  | $ | (79,036) |  |  | $ | (13,640) |  |  | $ | (92,676) |  |  | $ | 75,894 |  |  | $ | 62,254 |  |  | 4.3 |
| Customer relationships | 54,620 |  |  | — |  |  | 54,620 |  |  | (14,097) |  |  | (3,850) |  |  | (17,947) |  |  | 40,523 |  |  | 36,673 |  |  | 5.2 |
| Trade name | 12,390 |  |  | — |  |  | 12,390 |  |  | (6,602) |  |  | (1,140) |  |  | (7,742) |  |  | 5,788 |  |  | 4,648 |  |  | 2.1 |
| Total | $ | 221,940 |  |  | $ | — |  |  | $ | 221,940 |  |  | $ | (99,735) |  |  | $ | (18,630) |  |  | $ | (118,365) |  |  | $ | 122,205 |  |  | $ | 103,575 |  |  | 4.5 |

[0001596532-23-000197:notes:88]
Amortization expense related to acquisition-related intangible assets was $9.3 million, and $7.7 million for the three months ended June 30, 2023 and 2022, respectively, and $18.6 million and $15.0 million for the six months ended June 30, 2023 and 2022, respectively.

[0001596532-23-000197:notes:89]
As of June 30, 2023, future estimated amortization expense related to the acquisition-related intangible assets is as follows (in thousands):

[0001596532-23-000197:notes:90]
|  |  | Future Amortization Expense |
| Remainder of 2023 |  | $ | 14,808 |  |
| 2024 |  | 26,759 |  |
| 2025 |  | 19,642 |  |
| 2026 |  | 17,260 |  |
| 2027 |  | 13,436 |  |
| Thereafter |  | 11,670 |  |
| Total |  | $ | 103,575 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-23-000197:notes:91]
Commitments and Contingencies
Purchase Commitments

[0001596532-23-000197:notes:92]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of June 30, 2023, we had non-cancellable purchase commitments of $2.2 billion, of which $1.9 billion have confirmed receipt dates within 12 months, and $0.3 billion have confirmed receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-23-000197:notes:93]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $301.6 million and $192.5 million as of June 30, 2023 and December 31, 2022, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

[0001596532-23-000197:notes:94]
Guarantees

[0001596532-23-000197:notes:95]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-23-000197:notes:96]
Legal Proceedings

[0001596532-23-000197:notes:97]
WSOU Investments, LLC

[0001596532-23-000197:notes:98]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California.  On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement.  On July 1, 2022, the court stayed the case pending the resolution of an inter partes review of one of the patents-in-suit. On May 30, 2023, the US Patent Trial and Appeal Board (“PTAB”) ruled all challenged claims in the inter partes review unpatentable. The district court case remains stayed pending appeal and/or final resolution of the PTAB ruling.

[0001596532-23-000197:notes:99]
We intend to vigorously defend against the claims brought against us by WSOU; however, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-23-000197:notes:100]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated; however, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-23-000197:notes:101]
Other matters

[0001596532-23-000197:notes:102]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-23-000197:notes:103]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of June 30, 2023, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse 
impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-23-000197:notes:104]
[same as prior period, unchanged from 0001596532-23-000104:notes:100]

[0001596532-23-000197:notes:105]
Our board of directors has authorized a $1.0 billion stock repurchase program (the “Repurchase Program”). This authorization allows us to repurchase shares of our common stock that will be funded from working capital and expires in the fourth quarter of 2024. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the "Exchange Act"), or a combination of the foregoing. The Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the company at any time without prior notice.  As of June 30, 2023, the remaining authorized amount for stock repurchases under the Repurchase Program was approximately $144.5 million.

[0001596532-23-000197:notes:106]
A summary of the stock repurchase activity under the Repurchase Program for the three and six months ended June 30, 2023 is as follows (in thousands, except per share amounts):

[0001596532-23-000197:notes:107]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | June 30, 2023 |  | June 30, 2023 |
| Aggregate purchase price |  | $ | 30,004 |  |  | $ | 112,279 |  |
| Shares repurchased |  | 219 |  |  | 954 |  |
| Average price paid per share |  | $ | 137.21 |  |  | $ | 117.70 |  |

[0001596532-23-000197:notes:108]
[same as prior period, unchanged from 0001596532-23-000104:notes:104]

[0001596532-23-000197:notes:109]
[same as prior period, unchanged from 0001596532-23-000104:notes:105]

[0001596532-23-000197:notes:110]
[same as prior period, unchanged from 0001596532-23-000104:notes:106]

[0001596532-23-000197:notes:111]
[same as prior period, unchanged from 0001596532-23-000104:notes:107]

[0001596532-23-000197:notes:112]
Awards granted under the 2014 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Units (“RSUs”), Restricted Stock Awards (“RSAs”) or Stock Appreciation Rights (“SARs”). The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of the outstanding shares of our common stock on the immediately preceding December 31, but not to exceed 50 million shares (the “2014 Plan Evergreen Increase”), unless our board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2023, our board of directors authorized an increase of 9.2 million shares to the shares available for issuance under the 2014 Plan. As of June 30, 2023, there remained approximately 98.0 million shares available for issuance under the 2014 Plan.

[0001596532-23-000197:notes:113]
[same as prior period, unchanged from 0001596532-23-000104:notes:109]

[0001596532-23-000197:notes:114]
In April 2014, our board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding on the immediately preceding December 31, but not to exceed 10 million shares, unless our board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2023, our board of directors authorized an increase of 3.1 million shares to the shares available for issuance under the ESPP. During the six months ended June 30, 2023, we issued 139,758 shares at a weighted-average purchase price of $102.66 per share under the ESPP. As of June 30, 2023, there remained approximately 23.5 million shares available for issuance under the ESPP.

[0001596532-23-000197:notes:115]
[same as prior period, unchanged from 0001596532-23-000104:notes:111]

[0001596532-23-000197:notes:116]
[same as prior period, unchanged from 0001596532-23-000104:notes:112]

[0001596532-23-000197:notes:117]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2022 |  | 5,769 |  |  | $ | 14.09 |  |  | 2.0 |  | $ | 618,774 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (1,930) |  |  | 8.32 |  |  |  |  |  |
| Options canceled |  | (1) |  |  | 9.26 |  |  |  |  |  |
| Balance—June 30, 2023 |  | 3,838 |  |  | $ | 17.00 |  |  | 1.8 |  | $ | 556,820 |  |
| Vested and exercisable—June 30, 2023 |  | 3,497 |  |  | $ | 14.89 |  |  | 1.5 |  | $ | 514,659 |  |

[0001596532-23-000197:notes:118]
[same as prior period, unchanged from 0001596532-23-000104:notes:114]

[0001596532-23-000197:notes:119]
[same as prior period, unchanged from 0001596532-23-000104:notes:115]

[0001596532-23-000197:notes:120]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2022 |  | 8,360 |  |  | $ | 85.83 |  |  | 1.7 |  | $ | 1,014,431 |  |
| RSUs granted |  | 2,498 |  |  | 155.81 |  |  |  |  |  |
| RSUs vested |  | (1,416) |  |  | 77.40 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (180) |  |  | 95.49 |  |  |  |  |  |
| Unvested balance—June 30, 2023 |  | 9,262 |  |  | $ | 106.28 |  |  | 1.9 |  | $ | 1,500,987 |  |

[0001596532-23-000197:notes:121]
[same as prior period, unchanged from 0001596532-23-000104:notes:117]

[0001596532-23-000197:notes:122]
[same as prior period, unchanged from 0001596532-23-000104:notes:118]

[0001596532-23-000197:notes:123]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cost of revenue |  | $ | 2,824 |  |  | $ | 2,312 |  |  | $ | 5,799 |  |  | $ | 3,621 |  |
| Research and development |  | 41,137 |  |  | 28,449 |  |  | 77,706 |  |  | 56,025 |  |
| Sales and marketing |  | 15,833 |  |  | 12,827 |  |  | 30,971 |  |  | 25,936 |  |
| General and administrative |  | 7,333 |  |  | 6,636 |  |  | 15,532 |  |  | 14,921 |  |
| Total stock-based compensation |  | $ | 67,127 |  |  | $ | 50,224 |  |  | $ | 130,008 |  |  | $ | 100,503 |  |

[0001596532-23-000197:notes:124]
As of June 30, 2023, there were $868.7 million of unamortized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 3.7 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-23-000197:notes:125]
[same as prior period, unchanged from 0001596532-23-000104:notes:121]

[0001596532-23-000197:notes:126]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 491,885 |  |  | $ | 299,099 |  |  | $ | 928,358 |  |  | $ | 571,358 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share, basic |  | 308,636 |  |  | 306,754 |  |  | 307,810 |  |  | 307,399 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity awards |  | 7,849 |  |  | 9,827 |  |  | 8,221 |  |  | 10,641 |  |
| Weighted-average shares used in computing net income per share, diluted |  | 316,485 |  |  | 316,581 |  |  | 316,031 |  |  | 318,040 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.59 |  |  | $ | 0.98 |  |  | $ | 3.02 |  |  | $ | 1.86 |  |
| Diluted |  | $ | 1.55 |  |  | $ | 0.94 |  |  | $ | 2.94 |  |  | $ | 1.80 |  |

[0001596532-23-000197:notes:127]
[same as prior period, unchanged from 0001596532-23-000104:notes:123]

[0001596532-23-000197:notes:128]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Stock options and RSUs |  | 548 |  |  | 781 |  |  | 285 |  |  | 423 |  |
| Employee stock purchase plan |  | 77 |  |  | — |  |  | 213 |  |  | 8 |  |
| Total |  | 625 |  |  | 781 |  |  | 498 |  |  | 431 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-23-000197:notes:129]
[same as prior period, unchanged from 0001596532-23-000104:notes:125]

[0001596532-23-000197:notes:130]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Income before income taxes |  | $ | 586,401 |  |  | $ | 362,320 |  |  | $ | 1,083,125 |  | $ | 671,787 |  |
| Provision for income taxes |  | 94,516 |  |  | 63,221 |  |  | $ | 154,767 |  | 100,429 |  |
| Effective tax rate |  | 16.1 | % |  | 17.4 | % |  | 14.3 | % |  | 14.9 | % |

[0001596532-23-000197:notes:131]
The decrease in the effective tax rates in the three and six months ended June 30, 2023, as compared to the same periods in 2022, was primarily due to an increase in tax benefits attributable to stock-based compensation.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-23-000197:notes:132]
[same as prior period, unchanged from 0001596532-23-000104:notes:128]

[0001596532-23-000197:notes:133]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Americas(1) |  | $ | 1,154,509 |  |  | $ | 845,055 |  |  | $ | 2,269,520 |  |  | $ | 1,509,432 |  |
| Europe, Middle East and Africa |  | 167,623 |  |  | 104,538 |  |  | 295,939 |  |  | 239,343 |  |
| Asia-Pacific |  | 136,792 |  |  | 102,298 |  |  | 244,816 |  |  | 180,182 |  |
| Total revenue |  | $ | 1,458,924 |  |  | $ | 1,051,891 |  |  | $ | 2,810,275 |  |  | $ | 1,928,957 |  |

[0001596532-23-000197:notes:134]
(1) Includes $1,121.7 million and $838.7 million revenue generated from the U.S. for the three months ended June 30, 2023 and June 30, 2022, respectively, and $2,216.3 million and $1,487.6 million for the six months ended June 30, 2023 and June 30, 2022, respectively.

[0001596532-23-000197:notes:135]
[same as prior period, unchanged from 0001596532-23-000104:notes:131]

[0001596532-23-000197:notes:136]
|  |  | June 30, 2023 |  | December 31, 2022 |
| United States |  | $ | 81,667 |  |  | $ | 71,540 |  |
| International |  | 20,038 |  |  | 23,469 |  |
| Total |  | $ | 101,705 |  |  | $ | 95,009 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001596532-23-000197:notes:137]
On June 14, 2023, Kelly Battles, a member of our Board of Directors, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of 1,418 shares of our common stock. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until September 13, 2024, or earlier if all transactions under the trading arrangement are completed.

[0001596532-23-000197:notes:138]
On June 14, 2023, Charles Giancarlo, a member of our Board of Directors, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 24,000 shares of our common stock. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until September 16, 2024, or earlier if all transactions under the trading arrangement are completed.

[0001596532-23-000197:notes:139]
On June 8, 2023, Ita Brennan, our Chief Financial Officer, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 58,000 shares of our common stock. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until September 8, 2024, or earlier if all transactions under the trading arrangement are completed.
