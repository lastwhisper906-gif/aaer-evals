# ANET 8-K — 0001596532-25-000103 filed 2025-05-06

## item codes, every 8-K on or before 2025-05-07

- 2025-05-06 0001596532-25-000103 — 2.02, 5.02, 8.01, 9.01
- 2025-03-17 0001596532-25-000077 — 5.02, 8.01, 9.01
- 2025-02-18 0001596532-25-000018 — 2.02, 9.01
- 2024-12-03 0001596532-24-000402 — 5.03, 9.01
- 2024-11-07 0001596532-24-000366 — 2.02, 8.01, 9.01
- 2024-07-30 0001596532-24-000277 — 2.02, 9.01
- 2024-06-10 0001596532-24-000233 — 5.07
- 2024-05-24 0001596532-24-000219 — 8.01
- 2024-05-07 0001596532-24-000171 — 2.02, 8.01, 9.01
- 2024-04-23 0001596532-24-000155 — 5.02, 9.01
- 2024-04-19 0001596532-24-000152 — 5.02, 8.01
- 2024-02-28 0001596532-24-000095 — 8.01
- 2024-02-12 0001596532-24-000041 — 2.02, 9.01
- 2023-12-20 0001596532-23-000349 — 5.03, 9.01
- 2023-12-01 0001596532-23-000324 — 5.02, 8.01, 9.01
- 2023-10-30 0001596532-23-000272 — 2.02, 9.01
- 2023-07-31 0001596532-23-000196 — 2.02, 5.02, 9.01
- 2023-06-16 0001596532-23-000168 — 5.07
- 2023-05-01 0001596532-23-000101 — 2.02, 9.01
- 2023-02-13 0001596532-23-000015 — 2.02, 9.01
- 2022-10-31 0001596532-22-000292 — 2.02, 9.01
- 2022-10-25 0001596532-22-000282 — 5.03, 9.01
- 2022-08-01 0001596532-22-000218 — 2.02, 9.01
- 2022-07-25 0001596532-22-000205 — 5.02
- 2022-06-03 0001596532-22-000179 — 5.07
- 2022-05-02 0001596532-22-000111 — 2.02, 9.01
- 2022-03-29 0001596532-22-000100 — 5.02
- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2025-05-07

- none on or before 2025-05-07

## item 2.02 — earnings release, exhibit 99.1

[0001596532-25-000103:8k_2_02:1]
EX-99.1
2
ex991q125-earningsrelease.htm
EX-99.1

[0001596532-25-000103:8k_2_02:2]
Document

[0001596532-25-000103:8k_2_02:3]
Exhibit 99.1

[0001596532-25-000103:8k_2_02:4]
Arista Networks, Inc. Reports First Quarter 2025 Financial Results

[0001596532-25-000103:8k_2_02:5]
Board of Directors Authorizes Additional $1.5B Stock Repurchase Program

[0001596532-25-000103:8k_2_02:6]
SANTA CLARA, Calif.- May 6, 2025 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus, and routing environments, today announced financial results for its first quarter ended March 31, 2025.

[0001596532-25-000103:8k_2_02:7]
First Quarter Financial Highlights

[0001596532-25-000103:8k_2_02:8]
“As we enter 2025, AI, cloud, and enterprise customers continue to drive network transformation. We surpassed $2B in revenue for the first time in Q1 2025 despite the unknowns around tariffs," stated Jayshree Ullal, Chairperson and CEO of Arista Networks. "Arista's trifecta of innovation, growth, and profitability is reflected in our results.”

[0001596532-25-000103:8k_2_02:9]
•Revenue of $2.005 billion, an increase of 3.9% compared to the fourth quarter of 2024, and an increase of 27.6% from the first quarter of 2024.

[0001596532-25-000103:8k_2_02:10]
•GAAP gross margin of 63.7%, compared to GAAP gross margin of 63.8% in the fourth quarter of 2024 and 63.7% in the first quarter of 2024.

[0001596532-25-000103:8k_2_02:11]
•Non-GAAP gross margin of 64.1%, compared to non-GAAP gross margin of 64.2% in the fourth quarter of 2024 and 64.2% in the first quarter of 2024.

[0001596532-25-000103:8k_2_02:12]
•GAAP net income of $813.8 million, or $0.64 per diluted share, compared to GAAP net income of $637.7 million, or $0.50 per diluted share in the first quarter of 2024.

[0001596532-25-000103:8k_2_02:13]
•Non-GAAP net income of $826.2 million, or $0.65 per diluted share, compared to non-GAAP net income of $637.7 million, or $0.50 per diluted share in the first quarter of 2024.

[0001596532-25-000103:8k_2_02:14]
Commenting on the company's financial results, Chantelle Breithaupt, Arista’s CFO, said, "With a continued focus on execution, Arista maintained its financial performance of delivering both strong growth and profitability. In Q1 2025, we also completed the highest level of stock repurchases in Arista's history, quarterly or annually, at $787M, reflecting our strong conviction in the long-term value of the business."

[0001596532-25-000103:8k_2_02:15]
Stock Repurchase Program

[0001596532-25-000103:8k_2_02:16]
In May 2025, Arista’s Board of Directors authorized an additional program to repurchase up to $1.5 billion. The actual timing and amount of repurchases will be dependent on market and business conditions, capital requirements, stock price, acquisition opportunities and other factors.

[0001596532-25-000103:8k_2_02:17]
Company Highlights

[0001596532-25-000103:8k_2_02:18]
•Arista introduces intelligent innovations for AI networking – Arista introduced advanced capabilities to maximize AI cluster performance and efficiency. Cluster Load Balancing (CLB) in Arista EOS ® maximizes AI workload performance with consistent, low-latency network flows, while Arista CloudVision® Universal Network Observability™ (CV UNO™) now offers AI job-centric observability for enhanced troubleshooting and rapid issue inference, ensuring job completion reliability at scale.

[0001596532-25-000103:8k_2_02:19]
•Arista Networks Recognized in the Leaders Quadrant of the 2025 Gartner® Magic Quadrant™ for Data Center Switching, published on March 31, 2025 - Gartner positioned Arista Networks as the vendor with the highest ability to execute in the report.

[0001596532-25-000103:8k_2_02:20]
Financial Outlook

[0001596532-25-000103:8k_2_02:21]
For the second quarter of 2025, we expect:

[0001596532-25-000103:8k_2_02:22]
•Revenue of approximately $2.1 billion

[0001596532-25-000103:8k_2_02:23]
•Non-GAAP gross margin of approximately 63%; and

[0001596532-25-000103:8k_2_02:24]
•Non-GAAP operating margin of approximately 46%.

[0001596532-25-000103:8k_2_02:25]
Guidance for non-GAAP financial measures excludes certain items, including stock-based compensation expense, intangible asset amortization, and potential non-recurring charges or benefits. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis without unreasonable effort because these exclusions can be uncertain or difficult to predict, including stock-based compensation expense, which is impacted by the timing of employee stock transactions, the company’s future hiring and retention needs and the future fair market value of the company’s common stock. The actual amount of these exclusions will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-25-000103:8k_2_02:26]
Prepared Materials and Conference Call Information

[0001596532-25-000103:8k_2_02:27]
Arista's executives will discuss the first quarter 2025 financial results on a conference call today at 1:30 PM Pacific time. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-25-000103:8k_2_02:28]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-25-000103:8k_2_02:29]
Forward-Looking Statements

[0001596532-25-000103:8k_2_02:30]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin, and non-GAAP operating margin for the second quarter of 2025, statements regarding the benefits of Arista's products, and statements regarding Arista's  innovation, growth, and profitability, and its conviction in the long-term value of the business. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: escalated or escalating U.S. tariffs and countermeasures taken by affected countries; enhanced import/export restrictions, such as enhanced export controls the U.S. has adopted targeting trade with China, as well as countermeasures taken by affected countries; large purchases by a limited number of customers who represent a substantial portion of our revenue; adverse economic and geopolitical conditions and conflicts, continuing uncertain economic conditions or reduced information technology and network infrastructure spending; the impact of sole or limited sources of supply, supply shortages and extended lead times or supply changes; volatility in our revenue growth rate; variations in our results of operations; the rapid evolution of the networking market; failure to successfully carry out new products and service offerings and expand into adjacent markets; variability in our gross margins; intense competition and industry consolidation; expansion of our international sales and operations; investments in or acquisitions of other businesses; seasonality and industry cyclicality; fluctuations in currency exchange rates; failure to raise additional capital on favorable terms; our inability to attract new large customers or sell additional products and services to our existing customers; inability to grow sales of switches which generate most of our product revenue; large customers requiring more favorable terms; inability to increase market awareness or acceptance of our new products and services; decreases in the sales prices of our products and services; long and unpredictable sales cycles; inability to offer high quality support and services; declines in maintenance renewals by customers; product quality problems; failure to anticipate technological shifts; the

[0001596532-25-000103:8k_2_02:31]
complexity of managing the supply of our products and product components; our dependence on third-party manufacturers to build our products; assertions by third parties of intellectual property rights infringement; failure or inability to protect or assert our intellectual property rights; defects, errors or vulnerabilities in our products, the failure of our products to detect security breaches or incidents, the misuse of our products or the risks or product liability; breaches of our cybersecurity systems, or other security or privacy breaches or incidents; failure to comply with government law and regulations; issues in the development and use of artificial intelligence, combined with an uncertain regulatory environment; risks related to future decisions to reduce or discontinue repurchasing our common stock pursuant to our stock repurchase programs; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission, including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof, and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-25-000103:8k_2_02:32]
Non-GAAP Financial Measures

[0001596532-25-000103:8k_2_02:33]
This press release and accompanying table contain certain non-GAAP financial measures, including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, intangible asset amortization, gains/losses on strategic investments, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-25-000103:8k_2_02:34]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are, therefore, unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-25-000103:8k_2_02:35]
Gartner®, Magic Quadrant™ for Data Center Switching,  Andrew Lerner et al., 31 March 2025

[0001596532-25-000103:8k_2_02:36]
GARTNER is a registered trademark and service mark of Gartner, Inc. and/or its affiliates in the U.S. and internationally, and MAGIC QUADRANT is a registered trademark of Gartner, Inc. and/or its affiliates and are used herein with permission. All rights reserved.

[0001596532-25-000103:8k_2_02:37]
Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner’s research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001596532-25-000103:8k_2_02:38]
The Gartner content described herein (the “Gartner Content”) represents research opinion or viewpoints published, as part of a syndicated subscription service, by Gartner, Inc. ("Gartner"), and is not a representation of fact. Gartner

[0001596532-25-000103:8k_2_02:39]
Content speaks as of its original publication date (and not as of the date of this Earnings Press Release), and the opinions expressed in the Gartner Content are subject to change without notice.

[0001596532-25-000103:8k_2_02:40]
About Arista Networks

[0001596532-25-000103:8k_2_02:41]
Arista Networks is an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus, and routing environments. Its award-winning platforms deliver availability, agility, automation, analytics, and security through an advanced network operating stack. For more information, visit www.arista.com.

[0001596532-25-000103:8k_2_02:42]
ARISTA, CloudVision, and Etherlink are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-25-000103:8k_2_02:43]
4

[0001596532-25-000103:8k_2_02:44]
ARISTA NETWORKS, INC.

[0001596532-25-000103:8k_2_02:45]
Condensed Consolidated Income Statements

[0001596532-25-000103:8k_2_02:46]
(Unaudited, in millions, except per share amounts)

[0001596532-25-000103:8k_2_02:47]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,692.5 |  |  | $ | 1,328.8 |  |  |  |  |  |
| Service |  | 312.3 |  |  | 242.6 |  |  |  |  |  |
| Total revenue |  | 2,004.8 |  |  | 1,571.4 |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 672.7 |  |  | 521.7 |  |  |  |  |  |
| Service |  | 56.0 |  |  | 48.3 |  |  |  |  |  |
| Total cost of revenue |  | 728.7 |  |  | 570.0 |  |  |  |  |  |
| Gross profit |  | 1,276.1 |  |  | 1,001.4 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 266.4 |  |  | 208.4 |  |  |  |  |  |
| Sales and marketing |  | 116.6 |  |  | 105.1 |  |  |  |  |  |
| General and administrative |  | 34.3 |  |  | 27.7 |  |  |  |  |  |
| Total operating expenses |  | 417.3 |  |  | 341.2 |  |  |  |  |  |
| Income from operations |  | 858.8 |  |  | 660.2 |  |  |  |  |  |
| Other income (expense), net |  | 96.2 |  |  | 62.6 |  |  |  |  |  |
| Income before income taxes |  | 955.0 |  |  | 722.8 |  |  |  |  |  |
| Provision for income taxes |  | 141.2 |  |  | 85.1 |  |  |  |  |  |
| Net income |  | $ | 813.8 |  |  | $ | 637.7 |  |  |  |  |  |
| Net income per share (1): |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.65 |  |  | $ | 0.51 |  |  |  |  |  |
| Diluted |  | $ | 0.64 |  |  | $ | 0.50 |  |  |  |  |  |
| Weighted-average shares used in computing net income per share(1): |  |  |  |  |  |  |  |  |
| Basic |  | 1,260.0 |  |  | 1,252.1 |  |  |  |  |  |
| Diluted |  | 1,279.2 |  |  | 1,279.4 |  |  |  |  |  |

[0001596532-25-000103:8k_2_02:48]
(1) Prior period results have been adjusted to reflect the four-for-one stock split effected in December 2024.

[0001596532-25-000103:8k_2_02:49]
ARISTA NETWORKS, INC.

[0001596532-25-000103:8k_2_02:50]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-25-000103:8k_2_02:51]
(Unaudited, in millions, except percentages and per share amounts)

[0001596532-25-000103:8k_2_02:52]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| GAAP gross profit |  | $ | 1,276.1 |  |  | $ | 1,001.4 |  |  |  |  |  |
| GAAP gross margin |  | 63.7 | % |  | 63.7 | % |  |  |  |  |
| Stock-based compensation expense |  | 5.5 |  |  | 3.4 |  |  |  |  |  |
| Intangible asset amortization |  | 3.2 |  |  | 4.2 |  |  |  |  |  |
| Non-GAAP gross profit |  | $ | 1,284.8 |  |  | $ | 1,009.0 |  |  |  |  |  |
| Non-GAAP gross margin |  | 64.1 | % |  | 64.2 | % |  |  |  |  |
| GAAP income from operations |  | $ | 858.8 |  |  | $ | 660.1 |  |  |  |  |  |
| GAAP operating margin |  | 42.8 | % |  | 42.0 | % |  |  |  |  |
| Stock-based compensation expense |  | 93.0 |  |  | 77.2 |  |  |  |  |  |
| Intangible asset amortization |  | 5.6 |  |  | 6.7 |  |  |  |  |  |
| Non-GAAP income from operations |  | $ | 957.4 |  |  | $ | 744.0 |  |  |  |  |  |
| Non-GAAP operating margin |  | 47.8 | % |  | 47.4 | % |  |  |  |  |
| GAAP net income |  | $ | 813.8 |  |  | $ | 637.7 |  |  |  |  |  |
| Stock-based compensation expense |  | 93.0 |  |  | 77.2 |  |  |  |  |  |
| Intangible asset amortization |  | 5.6 |  |  | 6.7 |  |  |  |  |  |
| (Gains)/losses on strategic investments |  | (5.5) |  |  | — |  |  |  |  |  |
| Tax benefits on stock-based awards |  | (66.1) |  |  | (70.8) |  |  |  |  |  |
| Income tax effect on non-GAAP exclusions |  | (14.6) |  |  | (13.1) |  |  |  |  |  |
| Non-GAAP net income |  | $ | 826.2 |  |  | $ | 637.7 |  |  |  |  |  |
| GAAP diluted net income per share (1) |  | $ | 0.64 |  |  | $ | 0.50 |  |  |  |  |  |
| Non-GAAP adjustments to net income (1) |  | 0.01 |  |  | — |  |  |  |  |  |
| Non-GAAP diluted net income per share (1) |  | $ | 0.65 |  |  | $ | 0.50 |  |  |  |  |  |
| Weighted-average shares used in computing diluted net income per share (1) |  | 1,279.2 |  |  | 1,279.4 |  |  |  |  |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 5.5 |  |  | $ | 3.4 |  |  |  |  |  |
| Research and development |  | 57.0 |  |  | 43.8 |  |  |  |  |  |
| Sales and marketing |  | 19.9 |  |  | 18.9 |  |  |  |  |  |
| General and administrative |  | 10.6 |  |  | 11.1 |  |  |  |  |  |
| Total |  | $ | 93.0 |  |  | $ | 77.2 |  |  |  |  |  |

[0001596532-25-000103:8k_2_02:53]
(1) Prior period results have been adjusted to reflect the four-for-one stock split effected in December 2024.

[0001596532-25-000103:8k_2_02:54]
6

[0001596532-25-000103:8k_2_02:55]
ARISTA NETWORKS, INC.

[0001596532-25-000103:8k_2_02:56]
Condensed Consolidated Balance Sheets

[0001596532-25-000103:8k_2_02:57]
(Unaudited, in millions)

[0001596532-25-000103:8k_2_02:58]
|  |  | March 31, 2025 |  | December 31, 2024 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,845.1 |  |  | $ | 2,762.4 |  |
| Marketable securities |  | 6,304.5 |  |  | 5,541.1 |  |
| Accounts receivable |  | 1,435.9 |  |  | 1,140.5 |  |
| Inventories |  | 1,957.3 |  |  | 1,834.6 |  |
| Prepaid expenses and other current assets |  | 733.5 |  |  | 632.3 |  |
| Total current assets |  | 12,276.3 |  |  | 11,910.9 |  |
| Property and equipment, net |  | 123.9 |  |  | 98.8 |  |
| Acquisition-related intangible assets, net |  | 56.4 |  |  | 62.0 |  |
| Goodwill |  | 268.5 |  |  | 268.5 |  |
| Deferred tax assets |  | 1,544.3 |  |  | 1,440.4 |  |
| Other assets |  | 245.2 |  |  | 263.3 |  |
| TOTAL ASSETS |  | $ | 14,514.6 |  |  | $ | 14,043.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 389.1 |  |  | $ | 381.1 |  |
| Accrued liabilities |  | 263.1 |  |  | 435.3 |  |
| Deferred revenue |  | 2,072.7 |  |  | 1,727.3 |  |
| Income taxes payable |  | 249.1 |  |  | 50.1 |  |
| Other current liabilities |  | 147.6 |  |  | 138.4 |  |
| Total current liabilities |  | 3,121.6 |  |  | 2,732.2 |  |
| Deferred revenue, non-current |  | 1,016.1 |  |  | 1,064.1 |  |
| Other long-term liabilities |  | 257.8 |  |  | 252.8 |  |
| TOTAL LIABILITIES |  | 4,395.5 |  |  | 4,049.1 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital |  | 2,551.7 |  |  | 2,465.4 |  |
| Retained earnings |  | 7,569.2 |  |  | 7,542.5 |  |
| Accumulated other comprehensive income (loss) |  | (1.9) |  |  | (13.2) |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 10,119.1 |  |  | 9,994.8 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 14,514.6 |  |  | $ | 14,043.9 |  |

[0001596532-25-000103:8k_2_02:59]
ARISTA NETWORKS, INC.

[0001596532-25-000103:8k_2_02:60]
Condensed Consolidated Statements of Cash Flows

[0001596532-25-000103:8k_2_02:61]
(Unaudited, in millions)

[0001596532-25-000103:8k_2_02:62]
|  |  | Three Months Ended March 31, |
|  |  | 2025 |  | 2024 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 813.8 |  |  | $ | 637.7 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 13.8 |  |  | 15.6 |  |
| Stock-based compensation |  | 93.0 |  |  | 77.2 |  |
| Deferred income taxes |  | (107.1) |  |  | (77.8) |  |
| Other |  | (12.1) |  |  | (7.8) |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (295.4) |  |  | (65.5) |  |
| Inventories |  | (122.7) |  |  | (80.0) |  |
| Other assets |  | (113.7) |  |  | 38.1 |  |
| Accounts payable |  | 6.7 |  |  | (207.2) |  |
| Deferred revenue |  | 297.4 |  |  | 157.0 |  |
| Income taxes, net |  | 241.3 |  |  | 157.5 |  |
| Other liabilities |  | (173.3) |  |  | (131.0) |  |
| Net cash provided by operating activities |  | 641.7 |  |  | 513.8 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 799.2 |  |  | 590.4 |  |
| Proceeds from sale of marketable securities |  | 8.8 |  |  | 36.8 |  |
| Purchases of marketable securities |  | (1,545.5) |  |  | (912.4) |  |
| Purchases of property and equipment |  | (28.4) |  |  | (9.4) |  |
| Other |  | — |  |  | (1.0) |  |
| Net cash used in investing activities |  | (765.9) |  |  | (295.6) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 28.1 |  |  | 25.1 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (34.8) |  |  | (25.5) |  |
| Repurchases of common stock |  | (787.1) |  |  | (62.7) |  |
| Net cash used in financing activities |  | (793.8) |  |  | (63.1) |  |
| Effect of exchange rate changes |  | 0.7 |  |  | (1.6) |  |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | (917.3) |  |  | 153.5 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 2,763.8 |  |  | 1,939.5 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 1,846.5 |  |  | $ | 2,093.0 |  |

[0001596532-25-000103:8k_2_02:63]
| Investor Contacts: |  |
| Arista Networks, Inc. |
| Investor Advocacy |
| Rudolph Araujo |  |
| Rod Hall |  |
| +1 (408) 547-8080 |  |
| ir@arista.com |

[0001596532-25-000103:8k_2_02:64]
8

## item 5.02 — body, verbatim

[0001596532-25-000103:8k_body:1]
ITEM 5.02 Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001596532-25-000103:8k_body:2]
Resignation of Marc Taxay as General Counsel

[0001596532-25-000103:8k_body:3]
On May 1, 2025, Marc Taxay, the Company’s General Counsel, notified the company of his intention to resign from the Company effective May 7, 2025. Mr. Taxay’s decision was not the result of any disagreement with the Company. The Company and Board thank Mr. Taxay for his exceptional service and significant contributions during his tenure and wish him the best in future endeavors.
