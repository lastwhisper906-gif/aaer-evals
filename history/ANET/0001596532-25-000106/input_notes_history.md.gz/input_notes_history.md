# ANET note change history — 0001596532-24-000368 → 0001596532-25-000106


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0001596532-25-000106:note_history:1]
Commitments and Contingencies
Purchase Commitments
  (was, 2024-11-08, similarity 0.7907):
[0001596532-24-000368:note_history:1]
Commitments and Contingencies
Leases

- changed (2025-05-07):
[0001596532-25-000106:note_history:2]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of purchase orders to our contract manufacturers for finished products consist of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of March 31, 2025, we had non-cancellable purchase commitments not recorded on our balance sheet of $3.5 billion, of which $3.0 billion have expected receipt dates within 12 months, and $0.5 billion have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.
  (was, 2024-11-08, similarity 0.9217):
[0001596532-24-000368:note_history:2]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2024, we had non-cancellable purchase commitments not recorded on our balance sheet of $2.4 billion, of which $2.0 billion have expected receipt dates within 12 months, and $0.4 billion have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

- changed (2025-05-07):
[0001596532-25-000106:note_history:3]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $80.1 million and $95.8 million as of March 31, 2025 and December 31, 2024, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.
  (was, 2024-11-08, similarity 0.9779):
[0001596532-24-000368:note_history:3]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $116.5 million and $133.3 million as of September 30, 2024 and December 31, 2023, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

- added (2025-05-07):
[0001596532-25-000106:note_history:4]
Property project

- added (2025-05-07):
[0001596532-25-000106:note_history:5]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office, lab and data center space. The estimated remaining capital expenditures related to this project are expected to be approximately $215.0 million to $240.0 million for the next two years, with construction expected to be completed by the end of fiscal 2026.

- changed (2025-05-07):
[0001596532-25-000106:note_history:6]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California.  On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement. On July 1, 2022, the court stayed the case pending the resolution of an inter partes review of one of the patents-in-suit. On May 30, 2023, the US Patent Trial and Appeal Board (“PTAB”) ruled all challenged claims in the inter partes review unpatentable. On March 10, 2025, the Federal Circuit affirmed the PTAB’s decision. The parties subsequently agreed to stay the litigation for an additional 90 days to allow WSOU to change counsel.
  (was, 2024-11-08, similarity 0.8737):
[0001596532-24-000368:note_history:6]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California.  On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement. On July 1, 2022, the court stayed the case pending the resolution of an inter partes review of one of the patents-in-suit. On May 30, 2023, the US Patent Trial and Appeal Board (“PTAB”) ruled all challenged claims in the inter partes review unpatentable. The district court case remains stayed pending appeal and/or final resolution of the PTAB ruling.

- changed (2025-05-07):
[0001596532-25-000106:note_history:7]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2025, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.
  (was, 2024-11-08, similarity 0.8715):
[0001596532-24-000368:note_history:7]
claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.

- removed (2025-05-07):
[0001596532-24-000368:note_history:8]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of September 30, 2024, we had lease payment obligations, net of immaterial sublease income, of $69.8 million, with $24.1 million payable within one year.

- removed (2025-05-07):
[0001596532-24-000368:note_history:9]
Purchase Commitments

- removed (2025-05-07):
[0001596532-24-000368:note_history:10]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2024, provisions recorded for contingent losses related to other


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0001596532-25-000106:note_history:11]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus and routing environments. Our cloud networking solutions consist of our Extensible Operating System ("EOS®"), a set of network applications and our Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.
  (was, 2024-11-08, similarity 0.8551):
[0001596532-24-000368:note_history:11]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of next generation data center, campus and routing environments. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

- changed (2025-05-07):
[0001596532-25-000106:note_history:12]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2025, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2024 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated. Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.
  (was, 2024-11-08, similarity 0.9307):
[0001596532-24-000368:note_history:12]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP have been condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2024, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2023 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

- added (2025-05-07):
[0001596532-25-000106:note_history:13]
On November 7, 2024, the Company announced a four-for-one forward stock split ("Stock Split") of the Company’s common stock that was effected through the filing of an amendment to the Company's Amended and Restated Certificate of Incorporation ("Amendment") on December 3, 2024. The Stock Split proportionately increased the authorized shares of common stock, and all share and per share amounts presented herein have been retroactively adjusted to reflect the impact of the Stock Split.

- changed (2025-05-07):
[0001596532-25-000106:note_history:14]
In December 2023, the Financial Accounting Standards Board ("FASB")  issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2024. Early adoption is permitted for annual financial statements that have not yet been issued. The amendments should be applied on a prospective basis although retrospective
  (was, 2024-11-08, similarity 0.8615):
[0001596532-24-000368:note_history:14]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2024. Early adoption is permitted for annual financial statements that have not yet been issued. The amendments should be applied on a prospective basis although retrospective application is permitted. As of September 30, 2024, we have not early adopted ASU 2023-09 and we are currently evaluating the impact of future adoption on our financial disclosures.

- added (2025-05-07):
[0001596532-25-000106:note_history:15]
application is permitted. We will adopt the standard in our 2025 annual period and are currently evaluating the impact that the updated standard will have on our financial statement disclosures.

- added (2025-05-07):
[0001596532-25-000106:note_history:16]
In November 2024, the FASB issued ASU No. 2024-03, Disaggregation of Income Statement Expenses (Subtopic 220-40). The ASU requires the disaggregated disclosure of specific expense categories, including purchases of inventory, employee compensation, depreciation, and amortization, within relevant income statement captions. This ASU also requires disclosure of the total amount of selling expenses along with the definition of selling expenses. The ASU is effective for annual periods beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027. Adoption of this ASU can either be applied prospectively to consolidated financial statements issued for reporting periods after the effective date of this ASU or retrospectively to any or all prior periods presented in the consolidated financial statements. Early adoption is also permitted. This ASU will likely result in the required additional disclosures being included in our consolidated financial statements, once adopted. We are currently evaluating the impact of future adoption on our financial statement disclosures.

- removed (2025-05-07):
[0001596532-24-000368:note_history:17]
Risks and Uncertainties

- removed (2025-05-07):
[0001596532-24-000368:note_history:18]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including the effects of, among other things, inflation, monetary policy shifts, recession risks, potential supply chain disruptions, and geopolitical pressures.

- removed (2025-05-07):
[0001596532-24-000368:note_history:19]
Our business is emerging from a period of unprecedented global supply chain disruptions.  Throughout this period, we made significant supply chain investments, including funding additional working capital and incremental purchase commitments in response to extended visibility to deployment plans from our customers. We have worked closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. Increased capacity has allowed us to ship products against previously committed demand/deployment plans and accelerate some deployments where needed, while trying to minimize building customer inventory, and to some extent balancing customer lead times with those currently experienced from our key suppliers. As a result, some shipments against these previously committed demand/deployment plans have extended into 2024.

- removed (2025-05-07):
[0001596532-24-000368:note_history:20]
As the global supply chain has experienced some improvements and as customer lead times have been reduced from their peak, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to shorter demand-planning horizons. Given these shipment and order patterns, near term revenue trends may not be solely reflective of current demand levels, but as discussed above will benefit from demand/deployment plans that had been

- removed (2025-05-07):
[0001596532-24-000368:note_history:21]
previously committed. We expect that our inventory and purchase commitments will remain volatile as we ramp new product introductions. The magnitude of these balances, combined with a reduction in customer demand-planning horizons and shifting customer product priorities, has resulted in increased risk that we may not be able to sell all of this inventory, which in turn has resulted in additional excess and obsolete inventory and supplier liability charges. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods.

- removed (2025-05-07):
[0001596532-24-000368:note_history:22]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. In addition, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. Recent technologies, such as generative AI models, have emerged, and while they have driven increased demand for networking, the long-term trajectory is unknown. As such, demand estimates for our new products may be inaccurate and create volatility in our revenue and inventory levels. Furthermore, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial conditions discussed herein may not be indicative of future operating results and trends.

- removed (2025-05-07):
[0001596532-24-000368:note_history:23]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280)-Improvements to Reportable Segment Disclosures. The ASU requires that an entity disclose significant segment expenses impacting profit and loss that are regularly provided to the chief operating decision maker. The update is required to be applied retrospectively to prior periods presented, based on the significant segment expense categories identified and disclosed in the period of adoption. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. As of September 30, 2024, we have not early adopted ASU 2023-07 and we are currently evaluating the impact of future adoption on our financial disclosures.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0001596532-25-000106:note_history:24]
The following table is an analysis of our debt securities in unrealized loss positions (in millions):
  (was, 2024-11-08, similarity 0.9458):
[0001596532-24-000368:note_history:24]
The following table is an analysis of our debt securities in unrealized loss positions (in thousands):

- added (2025-05-07):
[0001596532-25-000106:note_history:25]
|  |  | March 31, 2025 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 859.3 |  |  | $ | (1.6) |  |  | $ | — |  |  | $ | — |  |  | $ | 859.3 |  |  | $ | (1.6) |  |
| Corporate bonds |  | 896.6 |  |  | (2.7) |  |  | 2.8 |  |  | — |  |  | 899.4 |  |  | (2.7) |  |
| Agency securities |  | 483.5 |  |  | (0.9) |  |  | — |  |  | — |  |  | 483.5 |  |  | (0.9) |  |
| Total |  | $ | 2,239.4 |  |  | $ | (5.2) |  |  | $ | 2.8 |  |  | $ | — |  |  | $ | 2,242.2 |  |  | $ | (5.2) |  |

- removed (2025-05-07):
[0001596532-24-000368:note_history:26]
|  |  | September 30, 2024 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 62,724 |  |  | $ | (74) |  |  | $ | 127,869 |  |  | $ | (146) |  |  | $ | 190,593 |  |  | $ | (220) |  |
| Corporate bonds |  | 221,914 |  |  | (133) |  |  | 101,990 |  |  | (114) |  |  | 323,904 |  |  | (247) |  |
| Agency securities |  | 129,773 |  |  | (189) |  |  | 102,796 |  |  | (41) |  |  | 232,569 |  |  | (230) |  |
| Total |  | $ | 414,411 |  |  | $ | (396) |  |  | $ | 332,655 |  |  | $ | (301) |  |  | $ | 747,066 |  |  | $ | (697) |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2025-05-07):
[0001596532-24-000368:note_history:27]
Subsequent event
         Arista’s board of directors has approved a four-for-one forward stock split to make Arista’s common stock more accessible to a broader base of investors.

- removed (2025-05-07):
[0001596532-24-000368:note_history:28]
The four-for-one forward stock split will be effected through the filing of an amendment to Arista’s Amended and Restated Certificate of Incorporation that will proportionately increase the authorized shares of common stock.

- removed (2025-05-07):
[0001596532-24-000368:note_history:29]
Our stockholders will receive an additional three shares of common stock for each share held as of the effective time of the filing of the amendment on December 3, 2024. Prior to market open on December 4, 2024, trading is expected to commence on a split-adjusted basis. The following table reflects basic and diluted weighted average shares and net income per share on an unaudited pro forma basis giving effect to the stock split as if it had been effective for all periods presented (in thousands, except per share amounts).

- removed (2025-05-07):
[0001596532-24-000368:note_history:30]
|  |  | Pro Forma (Unaudited) |
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 747,938 |  |  | $ | 545,327 |  |  | $ | 2,051,058 |  |  | $ | 1,473,685 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Basic weighted-average shares outstanding |  | 1,257,928 |  |  | 1,240,740 |  |  | 1,254,968 |  |  | 1,234,408 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity awards |  | 23,864 |  |  | 29,784 |  |  | 25,344 |  |  | 31,848 |  |
| Diluted weighted-average shares outstanding |  | 1,281,792 |  |  | 1,270,524 |  |  | 1,280,312 |  |  | 1,266,256 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.59 |  |  | $ | 0.44 |  |  | $ | 1.63 |  |  | $ | 1.19 |  |
| Diluted |  | $ | 0.58 |  |  | $ | 0.43 |  |  | $ | 1.60 |  |  | $ | 1.16 |  |
